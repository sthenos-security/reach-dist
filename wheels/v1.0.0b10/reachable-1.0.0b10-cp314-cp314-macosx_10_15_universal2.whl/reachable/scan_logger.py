# Copyright © 2026 Sthenos Security. All rights reserved.

"""
REACHABLE Scan Logger

Clean, structured output with two modes:
- Default: High-level phases with timing and key metrics
- Debug (--debug): Adds scanner execution details and policy coverage

The output structure is IDENTICAL in both modes - debug just adds
additional sections at the end.

NOTE: ScanLogger prints directly to sys.__stdout__ to bypass TeeOutput
suppression. This ensures our structured output always appears while
verbose scanner output is suppressed in default mode.
"""

import sys
import time
from datetime import datetime
from typing import Optional, Dict, List, Any
from pathlib import Path

class ScanLogger:
    """
    Structured scan logger with consistent output in both modes.
    
    Default mode shows:
    - Scan header
    - Phase progress with timing
    - Results summary
    - Scan complete banner
    
    Debug mode adds:
    - Scanner execution table
    - Policy coverage breakdown
    - Compliance mapping summary
    """
    
    def __init__(self, debug: bool = False, log_file: Optional[Path] = None):
        self.debug = debug
        self.log_file = log_file
        self._log_fh = None
        
        # Keep reference to original stdout (before any tee wrapping)
        self._terminal = sys.__stdout__
        
        # Timing
        self.scan_start: Optional[float] = None
        self.phase_timings: Dict[int, Dict[str, Any]] = {}
        
        # Scanner execution tracking
        self.scanners: List[Dict[str, Any]] = []
        
        # Policy tracking
        self.policies: Dict[str, Dict[str, int]] = {
            'secrets': {},
            'cwe': {},
            'malware': {},
            'config': {},
        }
        
        # Compliance tracking
        self.compliance: Dict[str, int] = {}
        
        # Results counts
        self.counts: Dict[str, Any] = {}
        
        # Open log file
        if log_file:
            log_file.parent.mkdir(parents=True, exist_ok=True)
            self._log_fh = open(log_file, 'a')  # Append mode since TeeOutput also writes
    
    def __del__(self):
        if self._log_fh:
            self._log_fh.close()
    
    # =========================================================================
    # Core Output - prints to terminal AND log file
    # =========================================================================
    
    def _write(self, message: str, newline: bool = True):
        """Write to console (bypassing tee) and log file"""
        end = "\n" if newline else ""
        
        # Print to original terminal (bypasses any stdout wrapping)
        self._terminal.write(message + end)
        self._terminal.flush()
        
        # Also write to log file
        if self._log_fh:
            self._log_fh.write(message + end)
            self._log_fh.flush()
    
    def _write_log_only(self, message: str):
        """Write only to log file (for verbose details)"""
        if self._log_fh:
            self._log_fh.write(message + "\n")
            self._log_fh.flush()
    
    # =========================================================================
    # Convenience methods for logging levels (v4.4.4)
    # =========================================================================
    
    def info(self, message: str):
        """Log info message to terminal and log file"""
        self._write(message)
    
    def error(self, message: str):
        """Log error message to terminal and log file"""
        self._write(f"\u274c {message}")
    
    def warning(self, message: str):
        """Log warning message to terminal and log file"""
        self._write(f"\u26a0\ufe0f  {message}")
    
    def debug_msg(self, message: str):
        """Log debug message - only if debug mode is enabled"""
        if self.debug:
            self._write(f"[DEBUG] {message}")
        else:
            self._write_log_only(f"[DEBUG] {message}")
    
    # =========================================================================
    # Scan Lifecycle
    # =========================================================================
    
    def scan_start_msg(self, repo_name: str, repo_path: Path, version: str,
                        license_info: dict = None, repo_stats: dict = None,
                        scan_context = None):
        """
        Print scan header with Sthenos branding.
        
        Args:
            repo_name: Repository name
            repo_path: Path to repository
            version: REACHABLE version
            license_info: Dict with days_remaining, install_time, etc.
            repo_stats: Dict with branch, scan_count, first_scan_date
            scan_context: ScanContext object for language/build system info
        """
        self.scan_start = time.time()
        
        # Combined banner with version and copyright
        self._write("")
        self._write("╭────────────────────────────────────────╮")
        self._write(f"│  REACHABLE v{version:<25}  │")
        self._write("│  © 2026 Sthenos Security               │")
        self._write("╰────────────────────────────────────────╯")
        
        # License expiration (shown below banner)
        if license_info:
            days = license_info.get('days_remaining', 0)
            if days > 7:
                self._write(f"📝 License: {days} days remaining")
            elif days > 0:
                self._write(f"⚠️  License: {days} days remaining (expiring soon!)")
            else:
                self._write("❌ License: EXPIRED")
        
        self._write(f"Target: {repo_name}" + (" [DEBUG]" if self.debug else ""))
        self._write(f"  Path: {repo_path}")
        
        # Repo stats (if available)
        if repo_stats:
            branch = repo_stats.get('branch', 'unknown')
            scan_count = repo_stats.get('scan_count', 0)
            first_scan = repo_stats.get('first_scan_date')
            today = datetime.now().strftime('%Y-%m-%d')
            
            self._write("")
            self._write(f"📅 Today:       {today}")
            self._write(f"🌿 Branch:      {branch}")
            if first_scan:
                self._write(f"📆 First scan:  {first_scan}")
            self._write(f"🔢 Scan #:      {scan_count + 1} (this repo)")
        
        # Language and Build System info (always shown)
        if scan_context:
            self._print_analysis_scope(scan_context)
        
        self._write("")
    
    def _print_analysis_scope(self, scan_context):
        """
        Print language and build system analysis scope.
        
        NOTE: Update SUPPORTED_LANGS, PARTIAL_LANGS, SUPPORTED_BUILD, PARTIAL_BUILD
        when adding new language or build system support. See ROADMAP.md.
        """
        self._write("")
        self._write("🔍 ANALYSIS SCOPE")
        self._write("─" * 40)
        
        # === LANGUAGE SUPPORT ===
        # Update these sets when adding new language support!
        # See: docs/TECHNICAL_PLANNING.md "Language Support" section
        SUPPORTED_LANGS = {'Python', 'JavaScript/TypeScript', 'Go', 'Java'}
        PARTIAL_LANGS = {'Rust', 'Ruby'}  # SBOM/CVE only, no reachability
        
        detected = scan_context.detected_languages
        file_counts = scan_context.total_files if hasattr(scan_context, 'total_files') else {}
        
        supported = []
        partial = []
        unsupported = []
        
        for lang in detected:
            if lang in SUPPORTED_LANGS:
                supported.append(lang)
            elif lang in PARTIAL_LANGS:
                partial.append(lang)
            elif lang != 'Unknown':
                unsupported.append(lang)
        
        # Show supported languages
        if supported:
            lang_str = ', '.join(supported)
            self._write(f"  ✅ Languages:   {lang_str}")
        
        # Show partial support
        if partial:
            lang_str = ', '.join(partial)
            self._write(f"  ⚠️  Partial:     {lang_str} (CVE only, no reachability)")
        
        # Show unsupported
        if unsupported:
            lang_str = ', '.join(unsupported)
            self._write(f"  ❓ Skipped:     {lang_str} (not yet supported)")
        
        # Show file counts
        if file_counts:
            total = sum(file_counts.values())
            # Group by support status
            analyzed = sum(v for k, v in file_counts.items() 
                          if k.capitalize() in {'Python', 'Javascript', 'Go', 'Java'}
                          or k in {'python', 'javascript', 'go', 'java'})
            if total > 0:
                self._write(f"  📁 Files:       {total} total")
        
        # Build systems
        self._print_build_systems(scan_context)
        
        self._write("─" * 40)
    
    def _print_build_systems(self, scan_context):
        """
        Detect and print build systems.
        
        NOTE: Update SUPPORTED_BUILD, PARTIAL_BUILD, UNSUPPORTED_BUILD
        when adding new build system support. See ROADMAP.md.
        """
        repo_path = scan_context.repo_path
        
        # === BUILD SYSTEM SUPPORT ===
        # Update these dicts when adding new build system support!
        # See: docs/TECHNICAL_PLANNING.md "Build System Roadmap" section
        SUPPORTED_BUILD = {
            'pip/poetry': ('requirements.txt', 'pyproject.toml', 'Pipfile'),
            'npm/yarn/pnpm': ('package.json',),
            'go.mod': ('go.mod',),
            'Maven': ('pom.xml',),
            'Gradle': ('build.gradle', 'build.gradle.kts'),
        }
        
        PARTIAL_BUILD = {
            'Cargo': ('Cargo.toml',),   # Rust - SBOM only
            'Bundler': ('Gemfile',),     # Ruby - SBOM only
        }
        
        UNSUPPORTED_BUILD = {
            'Bazel': ('WORKSPACE', 'WORKSPACE.bazel'),
            'Buck2': ('BUCK', '.buckconfig'),
            'CMake': ('CMakeLists.txt',),
            'NuGet': ('*.csproj', 'packages.config'),
            'Composer': ('composer.json',),
        }
        
        detected_supported = []
        detected_partial = []
        detected_unsupported = []
        
        # Check supported
        for name, files in SUPPORTED_BUILD.items():
            for f in files:
                if list(repo_path.rglob(f)):
                    detected_supported.append(name)
                    break
        
        # Check partial
        for name, files in PARTIAL_BUILD.items():
            for f in files:
                if list(repo_path.rglob(f)):
                    detected_partial.append(name)
                    break
        
        # Check unsupported
        for name, files in UNSUPPORTED_BUILD.items():
            for f in files:
                # Handle wildcards
                if '*' in f:
                    pattern = f
                else:
                    pattern = f
                if list(repo_path.rglob(pattern)):
                    detected_unsupported.append(name)
                    break
        
        # Print build systems
        if detected_supported:
            self._write(f"  ✅ Build:       {', '.join(detected_supported)}")
        
        if detected_partial:
            self._write(f"  ⚠️  Partial:     {', '.join(detected_partial)} (CVE only)")
        
        if detected_unsupported:
            self._write(f"  ❓ Skipped:     {', '.join(detected_unsupported)} (not yet supported)")
    
    # =========================================================================
    # Phase Tracking
    # =========================================================================
    
    def phase_start(self, phase_num: int, name: str, scanner: str = None, 
                    total_phases: int = 5):
        """Start a phase - outputs immediately"""
        self.phase_timings[phase_num] = {
            'name': name,
            'scanner': scanner,
            'start': time.time(),
            'end': None,
            'elapsed': None,
            'result': None
        }
        
        scanner_str = f" ({scanner})" if scanner else ""
        self._write(f"[{phase_num}/{total_phases}] {name}{scanner_str}...", newline=False)
    
    def phase_end(self, phase_num: int, result: str = None):
        """End a phase - completes the line"""
        if phase_num not in self.phase_timings:
            return
        
        phase = self.phase_timings[phase_num]
        phase['end'] = time.time()
        phase['elapsed'] = phase['end'] - phase['start']
        phase['result'] = result
        
        elapsed = phase['elapsed']
        result_str = f" → {result}" if result else ""
        self._write(f" ✅ ({elapsed:.1f}s){result_str}")
    
    def phase_error(self, phase_num: int, error: str):
        """Report phase error"""
        self._write(f" ❌ {error}")
    
    # =========================================================================
    # Scanner & Policy Tracking (for debug report)
    # =========================================================================
    
    def track_scanner(self, name: str, status: str = "success", 
                      duration: float = 0, result: str = ""):
        """Track scanner execution"""
        self.scanners.append({
            'name': name,
            'status': status,
            'duration': duration,
            'result': result
        })
        # Always log to file
        self._write_log_only(f"  Scanner: {name} - {status} ({duration:.1f}s) - {result}")
    
    def track_policy(self, category: str, policy_id: str, count: int):
        """Track policy findings"""
        if category not in self.policies:
            self.policies[category] = {}
        self.policies[category][policy_id] = count
    
    def track_compliance(self, framework: str, count: int):
        """Track compliance mapping"""
        self.compliance[framework] = count
    
    def set_counts(self, **kwargs):
        """Set result counts"""
        self.counts.update(kwargs)
    
    # =========================================================================
    # Summary Output
    # =========================================================================
    
    def print_timing_summary(self):
        """Print timing breakdown"""
        if not self.phase_timings:
            return
        
        self._write("")
        self._write("⏱️  TIMING")
        self._write("─" * 60)
        
        total = sum(p.get('elapsed', 0) or 0 for p in self.phase_timings.values())
        
        for phase_num in sorted(self.phase_timings.keys()):
            phase = self.phase_timings[phase_num]
            elapsed = phase.get('elapsed', 0) or 0
            name = phase['name'][:28]
            
            # Progress bar
            bar_len = int((elapsed / total * 20) if total > 0 else 0)
            bar = "█" * bar_len + "░" * (20 - bar_len)
            
            # Slow phase marker
            marker = " ⚠️" if elapsed > 30 else ""
            
            self._write(f"  {phase_num}. {name:<28} {elapsed:>6.1f}s {bar}{marker}")
        
        self._write("─" * 60)
        self._write(f"     {'TOTAL':<28} {total:>6.1f}s")
    
    def print_results_summary(self):
        """Print results summary - v4.5.17: Enhanced to match dashboard detail"""
        self._write("")
        self._write("📊 RESULTS")
        self._write("─" * 68)
        
        # Get all counts
        cves_total = self.counts.get('cves_total', 0)
        cves_reachable = self.counts.get('cves_reachable', 0)
        cves_unknown = self.counts.get('cves_unknown', 0)
        cves_unreachable = cves_total - cves_reachable - cves_unknown
        
        malware_static = self.counts.get('malware_static', 0) or self.counts.get('malware_count', 0) or 0
        malware_dynamic = self.counts.get('malware_dynamic', 0) or self.counts.get('sandbox_malicious', 0) or 0
        malware_total = malware_static + malware_dynamic
        malware_reachable = self.counts.get('malware_reachable', 0)
        
        secrets_total = self.counts.get('secrets_total', 0)
        secrets_reachable = self.counts.get('secrets_reachable', 0)
        secrets_unknown = self.counts.get('secrets_unknown', 0)
        secrets_unreachable = secrets_total - secrets_reachable - secrets_unknown
        
        cwe_total = self.counts.get('cwe_total', 0)
        cwe_reachable = self.counts.get('cwe_reachable', 0)
        cwe_unknown = self.counts.get('cwe_unknown', 0)
        cwe_unreachable = cwe_total - cwe_reachable - cwe_unknown
        
        config_total = self.counts.get('config_total', 0)
        
        # Header
        self._write(f"  {'Signal':<18} {'Total':>6} {'Reach':>6} {'Unkn':>6} {'Unreach':>7} {'Filtered':>9}")
        self._write("  " + "─" * 64)
        
        # Helper to format line with noise reduction
        def fmt_line(name, total, reachable, unknown=0):
            unreachable = total - reachable - unknown
            if total > 0:
                # Noise reduction = what we filtered out (unreachable / total)
                filtered_pct = round((unreachable / total) * 100, 1)
                filtered_str = f"{filtered_pct}%"
            else:
                filtered_str = "-"
            self._write(f"  {name:<18} {total:>6} {reachable:>6} {unknown:>6} {unreachable:>7} {filtered_str:>9}")
        
        # 1. CVE Vulnerabilities
        fmt_line("CVE Vulnerabilities", cves_total, cves_reachable, cves_unknown)
        
        # 2. Malware (Static + Dynamic)
        if malware_total > 0:
            self._write(f"  {'Malware (Static)':<18} {malware_static:>6} {malware_reachable:>6} {'-':>6} {'-':>7} {'🚨':>9}")
            self._write(f"  {'Malware (Dynamic)':<18} {malware_dynamic:>6} {malware_dynamic:>6} {'-':>6} {'-':>7} {'🚨':>9}")
        else:
            self._write(f"  {'Malware (Static)':<18} {0:>6} {'-':>6} {'-':>6} {'-':>7} {'-':>9}")
            self._write(f"  {'Malware (Dynamic)':<18} {0:>6} {'-':>6} {'-':>6} {'-':>7} {'-':>9}")
        
        # 3. Exposed Secrets
        fmt_line("Exposed Secrets", secrets_total, secrets_reachable, secrets_unknown)
        
        # 4. Code Weaknesses (CWE)
        fmt_line("Code Weaknesses", cwe_total, cwe_reachable, cwe_unknown)
        
        # 5. Config Issues (always unknown reachability, NOT in risk score)
        self._write(f"  {'Config Issues':<18} {config_total:>6} {'-':>6} {config_total:>6} {'-':>7} {'N/A':>9}  ⚠️  NOT IN RISK SCORE")
        
        self._write("  " + "─" * 64)
        
        # Totals row
        total_all = cves_total + malware_total + secrets_total + cwe_total + config_total
        total_reachable = cves_reachable + malware_reachable + secrets_reachable + cwe_reachable
        total_unknown = cves_unknown + secrets_unknown + cwe_unknown + config_total
        total_unreachable = total_all - total_reachable - total_unknown
        
        if total_all > 0:
            total_filtered = round((total_unreachable / total_all) * 100, 1)
            self._write(f"  {'TOTAL':<18} {total_all:>6} {total_reachable:>6} {total_unknown:>6} {total_unreachable:>7} {total_filtered:>8}%")
        else:
            self._write(f"  {'TOTAL':<18} {0:>6} {0:>6} {0:>6} {0:>7} {'-':>9}")
        
        self._write("─" * 68)
        
        # Action summary with breakdown
        # Actionable = reachable + unknown (need attention)
        actionable = total_reachable + total_unknown
        
        # Build breakdown string for reachable items
        reachable_parts = []
        if cves_reachable > 0:
            reachable_parts.append(f"{cves_reachable} CVE")
        if malware_reachable > 0:
            reachable_parts.append(f"{malware_reachable} malware")
        if secrets_reachable > 0:
            reachable_parts.append(f"{secrets_reachable} secrets")
        if cwe_reachable > 0:
            reachable_parts.append(f"{cwe_reachable} CWE")
        
        # Build breakdown string for unknown items
        unknown_parts = []
        if cves_unknown > 0:
            unknown_parts.append(f"{cves_unknown} CVE")
        if secrets_unknown > 0:
            unknown_parts.append(f"{secrets_unknown} secrets")
        if cwe_unknown > 0:
            unknown_parts.append(f"{cwe_unknown} CWE")
        if config_total > 0:
            unknown_parts.append(f"{config_total} config")
        
        self._write(f"")
        self._write(f"  🎯 ACTION REQUIRED: {actionable} issues need attention")
        if reachable_parts:
            self._write(f"     ✅ Reachable ({total_reachable}): {', '.join(reachable_parts)}")
        if unknown_parts:
            self._write(f"     ❓ Unknown ({total_unknown}): {', '.join(unknown_parts)}")
        
        # Global noise reduction
        if total_all > 0 and total_unreachable > 0:
            self._write(f"  📉 NOISE REDUCTION: {total_filtered}% ({total_unreachable} issues) filtered as unreachable")
        
        self._write("─" * 68)
    
    def print_scan_complete(self, risk_score: int, risk_level: str, output_dir: Path):
        """Print scan complete banner"""
        total_time = time.time() - self.scan_start if self.scan_start else 0
        
        self._write("")
        self._write("=" * 60)
        self._write("✅ SCAN COMPLETE")
        self._write("=" * 60)
        self._write("")
        self._write(f"📊 Risk Score: {risk_score}/1000 ({risk_level})")
        self._write(f"⏱️  Total Time: {total_time:.1f}s")
        self._write("")
        
        # Show dashboard with clickable path
        dashboard_path = output_dir / "dashboard" / "index.html"
        self._write(f"📁 Results:")
        self._write(f"   📊 Dashboard: file://{dashboard_path.absolute()}")
        
        # Show repo.db at repo level (v4.5.10: always show correct path)
        # Structure: ~/.reachable/scans/{repo-hash}/{branch}/{timestamp}/
        # repo.db is at: ~/.reachable/scans/{repo-hash}/repo.db
        repo_db = output_dir.parent.parent / 'repo.db'
        self._write(f"   💾 Database:  {repo_db}")
        
        self._write(f"   📝 Log:       {output_dir}/scan.log")
        self._write("")
    
    # =========================================================================
    # Debug Report (only shown with --debug)
    # =========================================================================
    
    def print_debug_report(self):
        """Print debug report - only in debug mode (writes to log file only)"""
        if not self.debug:
            return
        
        # v4.5.9: Debug details go to log file only, not terminal
        # Dashboard path already shown in SCAN COMPLETE section
        self._write_log_only("")
        self._write_log_only("=" * 60)
        self._write_log_only("DEBUG: EXECUTION DETAILS")
        self._write_log_only("=" * 60)
        
        # Scanner execution (log file only)
        if self.scanners:
            self._write_log_only("")
            self._write_log_only("SCANNER EXECUTION")
            self._write_log_only("─" * 60)
            self._write_log_only(f"  {'Scanner':<16} {'Status':<8} {'Time':>8}   {'Result':<20}")
            self._write_log_only("─" * 60)
            
            for s in self.scanners:
                status_icon = "OK" if s['status'] == 'success' else "ERR" if s['status'] == 'error' else "SKIP"
                self._write_log_only(f"  {s['name']:<16} {status_icon:<8} {s['duration']:>7.1f}s   {s['result'][:20]:<20}")
            
            self._write_log_only("─" * 60)
        
        # Policy coverage (log file only)
        has_policies = any(len(p) > 0 for p in self.policies.values())
        if has_policies:
            self._write_log_only("")
            self._write_log_only("POLICY COVERAGE")
            self._write_log_only("─" * 60)
            
            for category, policies in self.policies.items():
                if not policies:
                    continue
                    
                total = sum(policies.values())
                self._write_log_only(f"  {category.upper()} ({total} findings)")
                
                # Show top 5 policies
                sorted_policies = sorted(policies.items(), key=lambda x: x[1], reverse=True)
                for policy_id, count in sorted_policies[:5]:
                    # Clean up policy ID for display
                    display_id = policy_id.split('.')[-1] if '.' in policy_id else policy_id
                    display_id = display_id[:35]
                    self._write_log_only(f"    {display_id:<35} {count:>4}")
                
                if len(sorted_policies) > 5:
                    other = sum(c for _, c in sorted_policies[5:])
                    self._write_log_only(f"    {'(other)':<35} {other:>4}")
                
                self._write_log_only("")
        
        # Compliance mapping (log file only)
        if self.compliance:
            self._write_log_only("COMPLIANCE MAPPED")
            self._write_log_only("─" * 60)
            for framework, count in sorted(self.compliance.items()):
                self._write_log_only(f"  {framework:<30} {count:>4} controls")
            self._write_log_only("")
        
        self._write_log_only("=" * 60)
        self._write_log_only("")

# =========================================================================
# Global instance helpers
# =========================================================================

_logger: Optional[ScanLogger] = None

def get_logger() -> ScanLogger:
    global _logger
    if _logger is None:
        _logger = ScanLogger()
    return _logger

def init_logger(debug: bool = False, log_file: Path = None) -> ScanLogger:
    global _logger
    _logger = ScanLogger(debug=debug, log_file=log_file)
    return _logger
