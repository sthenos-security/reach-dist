#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.

"""
REACHABLE CLI - Security Analysis with Reachability-Based Prioritization

Commands:
    scan        Analyze a repository for security issues
    dashboard   Generate or access scan dashboard (CI/CD friendly)
    selftest    Verify installation
    doctor      Check system dependencies
    cache       Manage local caches
    system      System info, storage management, cleanup
    primer      Quick-start guide and playbook
    version     Show version info

Usage:
    reachctl scan /path/to/repo
    reachctl scan /path/to/repo --debug
    reachctl dashboard --generate
    reachctl dashboard --path              # CI/CD: get artifact path
    reachctl system                        # Show system info
    reachctl system df                     # Disk usage breakdown
    reachctl system prune --dry-run        # Preview cleanup
    reachctl system prune                  # Clean up old data
"""

# Suppress urllib3/OpenSSL warnings on macOS
import warnings
warnings.filterwarnings('ignore', message='.*urllib3.*')
warnings.filterwarnings('ignore', message='.*OpenSSL.*')

import argparse
import sys
import json
import shutil
import subprocess
import io
from pathlib import Path
from typing import Optional
import warnings

from . import __version__

# Suppress urllib3 OpenSSL warning on macOS (LibreSSL vs OpenSSL)
warnings.filterwarnings('ignore', message='.*urllib3 v2 only supports OpenSSL.*')
warnings.filterwarnings('ignore', category=DeprecationWarning, module='urllib3')

class TeeOutput:
    """Tee stdout to both console and a log file, with optional console suppression"""
    def __init__(self, log_path: Path, console_enabled: bool = True):
        self.terminal = sys.stdout
        self.log_file = open(log_path, 'w', encoding='utf-8')
        self.log_path = log_path
        self.console_enabled = console_enabled
    
    def write(self, message):
        if self.console_enabled:
            self.terminal.write(message)
        self.log_file.write(message)
        self.log_file.flush()
    
    def flush(self):
        if self.console_enabled:
            self.terminal.flush()
        self.log_file.flush()
    
    def enable_console(self):
        """Re-enable console output"""
        self.console_enabled = True
    
    def disable_console(self):
        """Suppress console output (still logs to file)"""
        self.console_enabled = False
    
    def close(self):
        self.log_file.close()
    
    def __enter__(self):
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()

def _check_venv_activation():
    """Check if running in activated venv and warn if not."""
    import sys
    from pathlib import Path
    
    # Check if we're in a venv
    in_venv = (
        hasattr(sys, 'real_prefix') or  # virtualenv
        (hasattr(sys, 'base_prefix') and sys.base_prefix != sys.prefix)  # venv
    )
    
    if in_venv:
        return  # All good
    
    # Not in venv - check if running from source (./reachctl)
    cli_path = Path(__file__).resolve()
    project_root = cli_path.parent.parent
    venv_dir = project_root / 'venv'
    
    # Only warn if venv exists but isn't activated
    if venv_dir.exists():
        print()
        print("\033[93m" + "=" * 60 + "\033[0m")  # Yellow
        print("\033[93m⚠️  WARNING: Virtual environment not activated\033[0m")
        print("\033[93m" + "=" * 60 + "\033[0m")
        print()
        print("Some tools (semgrep, guarddog) may not be available.")
        print()
        print("To activate:")
        print(f"  source {venv_dir}/bin/activate")
        print()
        print("Or run setup first:")
        print("  ./setup.sh && source venv/bin/activate")
        print()
        print("-" * 60)
        print()


def run_command(cmd: list, description: str, capture=False, check=True, env=None) -> Optional[str]:
    """Run a shell command with error handling.
    
    Args:
        cmd: Command and arguments
        description: Human-readable description for error messages
        capture: If True, return stdout
        check: If True, exit on non-zero return code
        env: Optional environment variables dict
    """
    try:
        if capture:
            result = subprocess.run(cmd, check=check, capture_output=True, text=True, env=env)
            return result.stdout
        else:
            result = subprocess.run(cmd, check=check, capture_output=True, text=True, env=env)
            return None
    except subprocess.CalledProcessError as e:
        if check:
            print(f"❌ Error during {description}")
            if e.stderr:
                print(f"   {e.stderr}")
            sys.exit(1)
        return None
    except FileNotFoundError:
        print(f"❌ Command not found: {cmd[0]}")
        print(f"   Please ensure {cmd[0]} is installed")
        sys.exit(1)

def check_github_connectivity(verbose: bool = False):
    """Check GitHub token and SSH access for library cloning"""
    import os
    
    if verbose:
        print()
        print("🔐 Checking GitHub Connectivity...")
    
    has_auth = False
    
    # Check for GitHub token
    token_vars = ['GITHUB_TOKEN', 'GH_TOKEN', 'MCP_GITHUB_TOKEN']
    token_found = False
    token_var = None
    
    for var in token_vars:
        if os.getenv(var):
            token_found = True
            token_var = var
            break
    
    if token_found:
        if verbose:
            print(f"   ✅ GitHub token found: ${token_var}")
        has_auth = True
    else:
        if verbose:
            print(f"   ℹ️  No GitHub token (checked: {', '.join(token_vars)})")
    
    # Check SSH access
    try:
        result = subprocess.run(
            ['ssh', '-T', 'git@github.com'],
            capture_output=True,
            text=True,
            timeout=5
        )
        # SSH to GitHub always returns exit code 1, but with specific message
        if 'successfully authenticated' in result.stderr.lower():
            username = ''
            if 'Hi ' in result.stderr:
                username = result.stderr.split('Hi ')[1].split('!')[0]
            if verbose:
                print(f"   ✅ SSH access configured{f' (user: {username})' if username else ''}")
            has_auth = True
        else:
            if verbose:
                print("   ℹ️  SSH access not configured")
    except (subprocess.TimeoutExpired, FileNotFoundError):
        if verbose:
            print("   ℹ️  SSH check skipped (not available)")
    
    if verbose:
        if has_auth:
            print("   ✅ GitHub authentication available - can clone private repositories")
        else:
            print("   ⚠️  No GitHub authentication - only public repositories accessible")
            print("   💡 To enable:")
            print("      Token: export GITHUB_TOKEN='ghp_your_token'")
            print("      SSH:   ssh-keygen && add to https://github.com/settings/keys")
        print()

def selftest(args=None):
    """Run validation on built-in test cases
    
    Args:
        args: Parsed arguments with --integration, --coverage, --quiet flags
    """
    # Try to use the new test runner
    try:
        from pathlib import Path
        tests_dir = Path(__file__).parent.parent / 'tests'
        run_tests_path = tests_dir / 'run_tests.py'
        
        if run_tests_path.exists():
            # Use the comprehensive test runner
            sys.path.insert(0, str(tests_dir))
            from run_tests import TestRunner
            
            integration = getattr(args, 'integration', False) if args else False
            coverage = getattr(args, 'coverage', False) if args else False
            quiet = getattr(args, 'quiet', False) if args else False
            
            runner = TestRunner(verbose=not quiet)
            result = runner.run_all(integration=integration, coverage=coverage)
            sys.exit(result)
    except ImportError:
        pass  # Fall back to built-in tests
    except Exception as e:
        print(f"Error loading test runner: {e}")
        # Fall back to built-in tests
    
    # Fallback: Original selftest implementation
    print("=" * 70)
    print("REACHABLE SELFTEST - Validating Installation")
    print("=" * 70)
    print()
    
    # Find project root
    cli_dir = Path(__file__).parent.parent
    tests_dir = cli_dir / "tests"
    
    print(f"📂 Project root: {cli_dir}")
    print(f"🧪 Tests directory: {tests_dir}")
    print()
    
    # Run basic import validation first
    print("=" * 70)
    print("PHASE 1: Module Import Validation")
    print("=" * 70)
    
    modules_to_test = [
        ('reachable.reachable', 'ReachabilityAnalyzer'),
        ('reachable.cli', 'main'),
        ('reachable.semgrep_scanner', 'SemgrepScanner'),
        ('reachable.health_metrics', 'HealthMetrics'),
        ('reachable.correlation_engine', 'ComprehensiveCorrelationEngine'),
        ('reachable.java_parser', 'JavaEcosystemAnalyzer'),
        ('reachable.go_parser', 'GoParser'),
        ('reachable.javascript_parser', 'JavaScriptParser'),
        ('reachable.yara_scanner', 'scan_directory'),  # Function, not class
        ('reachable.guarddog_scanner', 'GuardDogScanner'),
        ('reachable.phantom_detector', 'PhantomDetector'),
        ('reachable.trufflehog_scanner', 'TruffleHogScanner'),
        ('reachable.entropy_scanner', 'EntropyScanner'),
    ]
    
    import_failures = 0
    for module_name, class_name in modules_to_test:
        try:
            module = __import__(module_name, fromlist=[class_name])
            if hasattr(module, class_name):
                print(f"  ✅ {module_name}.{class_name}")
            else:
                print(f"  ⚠️  {module_name} - missing {class_name}")
                import_failures += 1
        except Exception as e:
            print(f"  ❌ {module_name}: {e}")
            import_failures += 1
    
    print()
    if import_failures > 0:
        print(f"⚠️  {import_failures} import issues found")
    else:
        print("✅ All core modules loaded successfully")
    
    # Run unit tests if available
    print()
    print("=" * 70)
    print("PHASE 2: Unit Tests")
    print("=" * 70)
    
    if tests_dir.exists():
        test_runner = tests_dir / "run_unit_tests.py"
        if test_runner.exists():
            print(f"Running: python {test_runner}")
            print("-" * 70)
            try:
                result = subprocess.run(
                    [sys.executable, str(test_runner)],
                    cwd=cli_dir,
                    timeout=300  # 5 minute timeout
                )
                if result.returncode != 0:
                    print()
                    print("⚠️  Some unit tests failed")
            except subprocess.TimeoutExpired:
                print("⚠️  Tests timed out after 5 minutes")
            except Exception as e:
                print(f"⚠️  Error running tests: {e}")
        else:
            # Try pytest - but handle gracefully if not installed
            try:
                # Check if pytest is available first
                result = subprocess.run(
                    [sys.executable, '-c', 'import pytest'],
                    capture_output=True,
                    timeout=10
                )
                if result.returncode == 0:
                    # pytest is available, run tests
                    result = subprocess.run(
                        [sys.executable, '-m', 'pytest', str(tests_dir), '-v', '--tb=short'],
                        cwd=cli_dir,
                        timeout=300
                    )
                else:
                    print("⚠️  pytest not installed - skipping unit tests")
                    print("   Install with: pip install pytest")
            except subprocess.TimeoutExpired:
                print("⚠️  Tests timed out")
            except Exception as e:
                print(f"⚠️  Error running tests: {e}")
    else:
        print("Tests directory not found - skipping unit tests")
        print("(This is normal for customer distributions)")
    
    # Quick functional test
    print()
    print("=" * 70)
    print("PHASE 3: Quick Functional Validation")
    print("=" * 70)
    
    try:
        from reachable.reachable import ReachabilityAnalyzer
        print("  ✅ ReachabilityAnalyzer instantiation ready")
        
        from reachable.java_parser import JavaEcosystemAnalyzer
        print("  ✅ JavaEcosystemAnalyzer ready (Maven/Gradle support)")
        
        from reachable.yara_rules_manager import YaraRulesManager
        manager = YaraRulesManager()
        status = manager.get_cache_status()
        print(f"  ✅ YARA Rules Manager ready ({status['total_rules']} rules cached)")
        
        # Run preflight check for tools and vulndb
        print()
        print("  Tool Status (via preflight check):")
        try:
            from .preflight import preflight_check
            preflight = preflight_check(fix=False, quiet=True, verbose=False)
            for check in preflight.checks:
                icon = {'ok': '✅', 'warn': '⚠️', 'fail': '❌'}.get(check['status'], '❓')
                msg = f" ({check['message']})" if check['message'] else ""
                print(f"    {icon} {check['name']}{msg}")
            
            if not preflight.ok:
                print()
                print("    💡 Run 'reachctl doctor' to install missing tools")
        except Exception as e:
            print(f"    ⚠️  Preflight check failed: {e}")
        
        print()
        print("=" * 70)
        print("✅ SELFTEST PASSED - REACHABLE is ready to use")
        print("=" * 70)
        print()
        print("Next steps:")
        print("  reachctl scan /path/to/your/project")
        print("  reachctl doctor    # Check all dependencies")
        print()
        sys.exit(0)
        
    except Exception as e:
        print(f"  ❌ Functional test failed: {e}")
        print()
        print("=" * 70)
        print("❌ SELFTEST FAILED")
        print("=" * 70)
        sys.exit(1)

def show_primer(args):
    """Show built-in playbook/quick-start guide"""
    print()
    print("REACHABLE Primer")
    print("=" * 60)
    print()
    print("WHAT IS REACHABLE?")
    print("  REACHABLE is a security scanner that reduces noise by identifying")
    print("  which security issues in your application code are truly exploitable.")
    print("  By analyzing executable code paths, it reveals real exposure to")
    print("  cyber threats and attacks — not theoretical risk.")
    print()
    print("  • Multi-signal analysis: CVEs, Secrets, CWEs, Malware, Config, Health, Compliance")
    print("  • Reachability-based noise reduction across application code")
    print("  • Executive dashboard with risk scoring")
    print()
    print("INSTALLATION & PATH SETUP")
    print("  After installing via wheel, add this to ~/.zshrc or ~/.bashrc:")
    print()
    print('    export PATH="$HOME/.reachable/venv/bin:$PATH"')
    print()
    print("  Then reload your shell:")
    print("    source ~/.zshrc")
    print()
    print("QUICK START")
    print("  reachctl scan .              # Scan current directory")
    print("  reachctl scan . --enable-ai  # Include AI/LLM security analysis")
    print("  reachctl doctor              # Check tool dependencies")
    print("  reachctl selftest            # Verify installation works")
    print()
    print("  Note: First scan takes longer (~1-2 min extra) while REACHABLE")
    print("  downloads vulnerability databases and sets up tool environments.")
    print("  Subsequent scans are much faster.")
    print()
    print("GITHUB AUTHENTICATION")
    print("  REACHABLE clones vulnerable library source code for reachability")
    print("  analysis. This requires GitHub access with read permissions on all repos.")
    print()
    print("  Option 1: SSH Key (recommended for developers)")
    print("    # Check if SSH is configured:")
    print("    ssh -T git@github.com")
    print("    # If not, generate and add to GitHub:")
    print("    ssh-keygen -t ed25519")
    print("    # Add ~/.ssh/id_ed25519.pub to https://github.com/settings/keys")
    print()
    print("  Option 2: GitHub Token (recommended for CI/CD)")
    print("    export GITHUB_TOKEN='ghp_your_token_here'")
    print("    # Token needs 'repo' scope for read access to public AND private repos")
    print("    # Create at: https://github.com/settings/tokens")
    print()
    print("  Option 3: MCP GitHub Token (for Claude Desktop MCP integration)")
    print("    export MCP_GITHUB_TOKEN='ghp_your_token_here'")
    print("    # Same scope requirements as GITHUB_TOKEN ('repo' for full read access)")
    print("    # Used when cloning via MCP server; falls back to git if unavailable")
    print()
    print("  Token Scope Required:")
    print("    'repo' - Grants read access to public and private repositories")
    print("             Required for cloning vulnerable library source code")
    print()
    print("  Priority: MCP_GITHUB_TOKEN > GITHUB_TOKEN > GH_TOKEN > SSH")
    print()
    print("  Without authentication:")
    print("    • Public repositories: ✅ Works (rate-limited)")
    print("    • Private repositories: ❌ Cannot clone")
    print()
    print("CONFIGURATION")
    print("  ~/.reachable/                # REACHABLE home directory")
    print("  ~/.reachable/venv/bin/       # Executables (reachctl, semgrep, etc.)")
    print("  ~/.reachable/scans/          # Scan results and dashboards")
    print()
    print("OUTPUT LOCATIONS")
    print("  ~/.reachable/scans/<repo>/<branch>/latest/dashboard/          # Dashboard")
    print("  ~/.reachable/scans/<repo>/<branch>/latest/reachable-report.json.gz  # Full report")
    print("  ~/.reachable/scans/<repo>/repo.db                             # SQLite database")
    print()
    print("RAW DATA (from syft/grype, before REACHABLE analysis)")
    print("  ~/.reachable/scans/<repo>/<branch>/latest/sbom.json.gz   # Raw SBOM (syft)")
    print("  ~/.reachable/scans/<repo>/<branch>/latest/vulns.json.gz  # Raw vulnerabilities (grype)")
    print()
    print("DEBUGGING")
    print("  reachctl scan . --debug      # Verbose output (shows all tool output)")
    print("  reachctl doctor              # Check & install missing tools")
    print("  reachctl cache --status      # Check cache sizes")
    print("  reachctl db --status         # Check scan database")
    print("  reachctl vulndb --status     # Check vulnerability DB age")
    print("  reachctl system              # System info and storage usage")
    print()
    print("STORAGE MANAGEMENT")
    print("  reachctl system              # Overview: storage, sandboxes, DB status")
    print("  reachctl system df           # Detailed disk usage breakdown")
    print("  reachctl system df -v        # Include top files by size")
    print("  reachctl system prune --dry-run  # Preview what would be deleted")
    print("  reachctl system prune        # Clean up old scans (>21 days, >20 per branch)")
    print("  reachctl system prune --max-age 7 --max-scans 5  # Custom retention")
    print()
    print("  Storage locations:")
    print("    ~/.reachable/scans/        # Scan results, dashboards, databases")
    print("    ~/.reachable/cache/        # Grype DB, SBOM cache, call graphs")
    print("    ~/.reachable/tools/        # Local tool binaries (syft, grype)")
    print()
    print("CI/CD INTEGRATION")
    print("  reachctl scan . --fail-on high --quiet   # Exit non-zero on high+ findings")
    print("  reachctl dashboard --path                # Get artifact path for upload")
    print()
    print("  CI/CD Environment Variables:")
    print("    GITHUB_TOKEN     - For cloning vulnerable libraries")
    print("    REACHABLE_CACHE_DIR - Custom cache location for CI caching")
    print()
    print("AI/LLM SECURITY ANALYSIS")
    print("  reachctl scan . --enable-ai     # Add AI security to standard scan")
    print("  reachctl scan . --ai-only       # Run ONLY AI security analysis")
    print()
    print("  OWASP LLM Top 10 Coverage:")
    print("    LLM01 - Prompt Injection")
    print("    LLM02 - Sensitive Information Disclosure")
    print("    LLM03 - Supply Chain (AI dependencies)")
    print("    LLM05 - Improper Output Handling")
    print("    LLM06 - Excessive Agency (dangerous tools)")
    print("    + MCP Security, Model Controls, AI Primitives")
    print()
    print("  Supported Frameworks:")
    print("    Python: langchain, openai, anthropic, llama_index")
    print("    TypeScript/JS: @langchain/*, openai, @anthropic-ai/*")
    print("    Go: sashabaranov/go-openai, tmc/langchaingo")
    print()
    print("EXAMPLES")
    print("  # Basic scan")
    print("  reachctl scan ~/myapp")
    print()
    print("  # CI/CD with threshold")
    print("  reachctl scan . --fail-on high --quiet")
    print()
    print("  # Scan AI/LLM application")
    print("  reachctl scan ~/my-chatbot --enable-ai")
    print()
    print("  # Check storage usage")
    print("  reachctl system df")
    print()
    print("  # Clean up old scans")
    print("  reachctl system prune")
    print()
    print("UNINSTALL / REINSTALL")
    print("  # Uninstall completely")
    print("  rm -rf ~/.reachable")
    print("  # Also remove PATH line from ~/.zshrc or ~/.bashrc")
    print()
    print("  # Upgrade (installer uses --force-reinstall)")
    print("  ./install.sh                 # Re-run to upgrade")
    print()
    print("  # Clean reinstall")
    print("  rm -rf ~/.reachable && ./install.sh")
    print()
    print("SUPPORT")
    print("  adazzi@sthenosec.com")
    print()

def open_dashboard(args):
    """Generate or access scan dashboard"""
    import webbrowser
    from pathlib import Path
    import json
    
    # Get REACHABLE home directory
    reachable_home = Path.home() / '.reachable' / 'scans'
    
    # List mode
    if getattr(args, 'list', False):
        if not reachable_home.exists():
            print("No scans found.")
            return
        print("Available dashboards:")
        print()
        found = False
        for scan_dir in sorted(reachable_home.iterdir()):
            if scan_dir.is_dir():
                latest = scan_dir / 'latest'
                if latest.exists() and latest.is_symlink():
                    dashboard = latest / 'dashboard' / 'index.html'
                    if dashboard.exists():
                        found = True
                        # Extract repo name from directory (remove hash suffix)
                        dir_name = scan_dir.name
                        repo_name = dir_name.rsplit('-', 1)[0] if '-' in dir_name else dir_name
                        print(f"  {repo_name}")
                        print(f"    reachctl dashboard --repo {repo_name}")
        if not found:
            print("  (none)")
        return
    
    # Helper: find latest scan dir, accounting for branch subdirectories
    def find_latest_in_repo(repo_dir: Path) -> Optional[Path]:
        """Find latest scan in repo dir, checking for branch subdirectories.
        
        Structure can be either:
          - {repo}/latest/  (old structure)
          - {repo}/{branch}/latest/  (new structure with branches)
        """
        # Check old structure first
        direct_latest = repo_dir / 'latest'
        if direct_latest.exists() and (direct_latest / 'dashboard' / 'index.html').exists():
            return direct_latest  # Return symlink path, not resolved target
        
        # Check for branch subdirectories (new structure)
        latest_scan = None
        latest_mtime = 0
        
        for subdir in repo_dir.iterdir():
            if not subdir.is_dir():
                continue
            # Skip non-branch directories
            if subdir.name.startswith('.'):
                continue
            
            branch_latest = subdir / 'latest'
            if branch_latest.exists():
                dashboard = branch_latest / 'dashboard' / 'index.html'
                if dashboard.exists():
                    mtime = branch_latest.stat().st_mtime
                    if mtime > latest_mtime:
                        latest_mtime = mtime
                        latest_scan = branch_latest  # Return symlink path, not resolved target
        
        return latest_scan
    
    # Helper: fuzzy match repo name against scan directories
    def find_scan_dir(search_term: str) -> Optional[Path]:
        """Find scan directory by fuzzy matching repo name or path"""
        if not reachable_home.exists():
            return None
        
        search_lower = search_term.lower()
        matches = []
        
        for sd in reachable_home.iterdir():
            if not sd.is_dir():
                continue
            
            dir_name = sd.name.lower()
            # Extract repo name (remove hash suffix like -abc123)
            repo_name = dir_name.rsplit('-', 1)[0] if '-' in dir_name else dir_name
            
            # Exact match
            if repo_name == search_lower or dir_name == search_lower:
                latest = find_latest_in_repo(sd)
                if latest:
                    return latest
            
            # Partial match (search term contained in repo name)
            if search_lower in repo_name or search_lower in dir_name:
                latest = find_latest_in_repo(sd)
                if latest:
                    matches.append((sd, latest))
        
        # Return best match (most recent if multiple)
        if matches:
            # Sort by modification time, newest first
            matches.sort(key=lambda x: x[0].stat().st_mtime, reverse=True)
            return matches[0][1]
        
        return None
    
    # Determine scan directory
    repo = getattr(args, 'repo', None)
    scan_dir = None
    
    if repo:
        repo_input = repo
        repo_path = Path(repo).resolve()
        
        # Check if it's a direct path to a scan output directory
        if repo_path.exists() and repo_path.is_dir():
            # Check if it looks like a scan output dir (has reachable-report.json)
            if (repo_path / 'reachable-report.json').exists() or (repo_path / 'reachable-report.json.gz').exists():
                scan_dir = repo_path
            else:
                # It's a repo path, look for scans by repo name
                scan_dir = find_scan_dir(repo_path.name)
        else:
            # It's a repo name, search in scans with fuzzy matching
            scan_dir = find_scan_dir(repo)
        
        if not scan_dir:
            print(f"No scan found for: {repo_input}", file=sys.stderr)
            print()
            print("Available repos:", file=sys.stderr)
            if reachable_home.exists():
                for sd in sorted(reachable_home.iterdir()):
                    if sd.is_dir():
                        dir_name = sd.name
                        repo_name = dir_name.rsplit('-', 1)[0] if '-' in dir_name else dir_name
                        print(f"  {repo_name}", file=sys.stderr)
            print()
            print("Usage: reachctl dashboard --repo <name>", file=sys.stderr)
            sys.exit(1)
    else:
        # Find most recent scan with a dashboard across all repos
        if reachable_home.exists():
            # Collect all valid dashboards with their mtimes
            valid_scans = []
            for repo_dir in reachable_home.iterdir():
                if not repo_dir.is_dir():
                    continue
                latest = find_latest_in_repo(repo_dir)
                if latest:
                    valid_scans.append((latest, latest.stat().st_mtime))
            
            if valid_scans:
                # Sort by mtime, newest first
                valid_scans.sort(key=lambda x: x[1], reverse=True)
                scan_dir = valid_scans[0][0]
    
    if not scan_dir:
        print("No scan found. Run a scan first:", file=sys.stderr)
        print("  reachctl scan /path/to/repo", file=sys.stderr)
        sys.exit(1)
    
    # Generate mode - regenerate dashboard from scan results
    if getattr(args, 'generate', False):
        # Find report file
        report_file = scan_dir / 'reachable-report.json'
        if not report_file.exists():
            report_file = scan_dir / 'reachable-report.json.gz'
        
        if not report_file.exists():
            print(f"Report not found in: {scan_dir}", file=sys.stderr)
            sys.exit(1)
        
        # Load report
        try:
            if str(report_file).endswith('.gz'):
                import gzip
                with gzip.open(report_file, 'rt') as f:
                    results = json.load(f)
            else:
                with open(report_file) as f:
                    results = json.load(f)
        except Exception as e:
            print(f"Failed to load report: {e}", file=sys.stderr)
            sys.exit(1)
        
        # Determine output directory
        output_dir = Path(args.output).resolve() if args.output else scan_dir
        
        # Generate dashboard
        try:
            from reachable.dashboard_v2.generator import DashboardV2Generator
            
            generator = DashboardV2Generator()
            dashboard_dir = generator.generate_from_report(results, output_dir)
            dashboard_path = dashboard_dir / 'index.html'
            
            print(f"Dashboard generated: {dashboard_path}")
            
            # Output path if requested
            if getattr(args, 'path', False):
                print(dashboard_path.absolute())
            
            # Open if requested
            if getattr(args, 'open', False):
                url = f"file://{dashboard_path.absolute()}"
                webbrowser.open(url)
                
        except ImportError as e:
            print(f"Dashboard generator not available: {e}", file=sys.stderr)
            sys.exit(1)
        except Exception as e:
            print(f"Dashboard generation failed: {e}", file=sys.stderr)
            sys.exit(1)
        
        return
    
    # Default: find existing dashboard
    dashboard = scan_dir / 'dashboard' / 'index.html'
    
    if not dashboard.exists():
        print(f"Dashboard not found: {dashboard}", file=sys.stderr)
        print()
        print("Generate with: reachctl dashboard --generate", file=sys.stderr)
        sys.exit(1)
    
    # Path-only mode (for CI/CD)
    if getattr(args, 'path', False):
        print(dashboard.absolute())
        return
    
    # Open mode
    if getattr(args, 'open', False):
        url = f"file://{dashboard.absolute()}"
        print(f"Opening: {url}")
        webbrowser.open(url)
        return
    
    # Default: print path info (CI/CD friendly)
    print(f"Dashboard: {dashboard.absolute()}")
    print(f"URL: file://{dashboard.absolute()}")
    print()
    print("Options:")
    print("  --path       Print path only (for CI/CD artifacts)")
    print("  --open       Open in browser")
    print("  --generate   Regenerate from scan results")

def generate_sbom(repo_path: Path, output_dir: Path, verbose: bool = False) -> Path:
    """Generate SBOM using Syft (reuses existing logic)"""
    from .vulndb import get_syft_path
    
    if verbose:
        print("[1/5] Generating SBOM...")
    sbom_file = output_dir / "sbom.json"
    
    # Use local syft from ~/.reachable/tools/bin/ if available
    syft_path = get_syft_path()
    
    result = run_command(
        [str(syft_path), 'scan', f'dir:{repo_path}', '-o', 'json', '-q'],
        'SBOM generation',
        capture=True
    )
    
  
    try:
        from .compression import save_json
        sbom_data = json.loads(result)
        actual_file = save_json(sbom_data, sbom_file, compress=True)
        if verbose:
            print(f"   ✓ SBOM saved to {actual_file.name} (compressed)")
        return actual_file
    except ImportError:
        # Fallback to uncompressed
        sbom_file.write_text(result)
        if verbose:
            print(f"   ✓ SBOM saved to {sbom_file}")
        return sbom_file

def scan_vulnerabilities(sbom_file: Path, output_dir: Path, verbose: bool = False) -> Path:
    """Scan for vulnerabilities using Grype with cached DB.
    
    Uses local grype from ~/.reachable/tools/bin/ and cached vulnerability
    database from ~/.reachable/cache/grype-db/. Auto-refreshes DB if > 24h old.
    """
    from .vulndb import VulnDBManager, get_grype_path
    
    if verbose:
        print()
        print("[2/5] Scanning for vulnerabilities...")
    vulns_file = output_dir / "vulns.json"
    
    # Ensure vulnerability DB is fresh (auto-refresh if > 24h old)
    db_mgr = VulnDBManager()
    db_mgr.ensure_fresh(verbose=verbose)
    
    # Use local grype from ~/.reachable/tools/bin/ if available
    grype_path = get_grype_path()
    
    actual_sbom_file = sbom_file
    temp_sbom = None
    
    if str(sbom_file).endswith('.gz'):
        import gzip
        import tempfile
        
        # Decompress to temp file for Grype
        temp_sbom = output_dir / "sbom_temp.json"
        with gzip.open(sbom_file, 'rt') as f_in:
            temp_sbom.write_text(f_in.read())
        actual_sbom_file = temp_sbom
    
    try:
        # Run grype with cached DB location
        result = run_command(
            [str(grype_path), f'sbom:{actual_sbom_file}', '-o', 'json', '-q'],
            'vulnerability scanning',
            capture=True,
            env=db_mgr.get_grype_env()
        )
        
        vulns_file.write_text(result)
        
        # Count vulnerabilities
        vulns_data = json.loads(result)
        vuln_count = len(vulns_data.get('matches', []))
        
        if verbose:
            print(f"   ✓ Found {vuln_count} vulnerabilities (Syft SBOM + Grype scanner)")
            print(f"   ✓ Results saved to {vulns_file}")
        
        return vulns_file
    finally:
        # Clean up temp file
        if temp_sbom and temp_sbom.exists():
            temp_sbom.unlink()

def clone_vulnerable_libs(vulns_file: Path, libs_dir: Path, scan_ctx=None, verbose: bool = False) -> tuple:
    """Clone vulnerable libraries using smart lib manager"""
    if verbose:
        print()
        print("[3/5] Cloning vulnerable library source code...")
    
    from .lib_manager import LibraryManager
    
    with open(vulns_file) as f:
        vulns_data = json.load(f)
    
    # Pass scan context to library manager for ecosystem hints
    manager = LibraryManager(libs_dir, scan_context=scan_ctx)
    cloned_paths = manager.clone_vulnerable_libraries(vulns_data)
    
    # Capture library manager metrics (includes obsolete packages)
    lib_metrics = manager.metrics
    
    # IMPORTANT: Return libs_dir even if nothing was freshly cloned
    # (libraries may already exist from previous runs)
    if libs_dir.exists() and any(libs_dir.iterdir()):
        return libs_dir, lib_metrics
    elif cloned_paths:
        return libs_dir, lib_metrics
    else:
        if verbose:
            print("   ⚠️  No vulnerable libraries found or cloning failed")
        return None, lib_metrics

def run_dynamic_malware_sandbox(sbom_file: Path, output_dir: Path) -> Optional[dict]:
    """
    Run dynamic malware sandbox analysis on dependencies.
    
    Platform behavior:
    - macOS: Requires Colima (not Docker Desktop - insecure for malware testing)
    - Linux: Firecracker sandbox (not yet implemented)
    
    Static malware analysis (GuardDog) always runs separately.
    
    Args:
        sbom_file: Path to SBOM JSON file
        output_dir: Output directory for results
        
    Returns:
        Sandbox results dict or None if sandbox unavailable
    """
    import platform
    import time
    
    system = platform.system().lower()
    print("   🔒 Dynamic Malware Sandbox")
    print(f"      Platform: {platform.system()} ({platform.machine()})")
    
    start_time = time.time()
    
    # ==========================================================================
    # LINUX: Firecracker sandbox (not yet implemented)
    # ==========================================================================
    if system == 'linux':
        print("      ⚠️  Firecracker sandbox not yet implemented on Linux")
        print("      💡 Static malware analysis (GuardDog) still runs")
        print("      📋 Firecracker support planned for v4.7.x")
        return {
            "verdict": "NOT_RUN",
            "reason": "Firecracker sandbox not yet implemented on Linux",
            "platform": "linux",
            "packages_tested": 0,
            "findings": [],
            "static_malware": "enabled",
            "dynamic_malware": "not_implemented",
            "duration_ms": int((time.time() - start_time) * 1000)
        }
    
    # ==========================================================================
    # macOS: Colima + Docker jail required (Docker Desktop is insecure)
    # ==========================================================================
    if system == 'darwin':
        colima_status = _check_colima_status()
        
        if colima_status == 'not_installed':
            print("      ⚠️  Colima not installed - dynamic sandbox skipped")
            print("      ")
            print("      To enable dynamic malware detection, install Colima:")
            print("         brew install colima docker")
            print("         colima start --cpu 2 --memory 4")
            print("      ")
            print("      Alternative (manual):")
            print("         Download from: https://github.com/abiosoft/colima/releases")
            print("      ")
            print("      📋 Static malware analysis (GuardDog) still runs")
            
            return {
                "verdict": "NOT_RUN",
                "reason": "Colima not installed",
                "platform": "darwin",
                "packages_tested": 0,
                "findings": [],
                "static_malware": "enabled",
                "dynamic_malware": "skipped",
                "install_instructions": "brew install colima docker && colima start",
                "duration_ms": int((time.time() - start_time) * 1000)
            }
        
        if colima_status == 'stopped':
            print("      🔄 Starting Colima VM...")
            if not _start_colima():
                print("      ❌ Failed to start Colima")
                return {
                    "verdict": "NOT_RUN",
                    "reason": "Failed to start Colima VM",
                    "platform": "darwin",
                    "packages_tested": 0,
                    "findings": [],
                    "static_malware": "enabled",
                    "dynamic_malware": "skipped",
                    "duration_ms": int((time.time() - start_time) * 1000)
                }
            print("      ✅ Colima started")
        else:
            print("      ✅ Colima running (secure VM isolation)")
        
        # Ensure sandbox image exists
        if not _ensure_sandbox_image():
            print("      ⚠️  Sandbox image not available")
            return {
                "verdict": "NOT_RUN",
                "reason": "Sandbox Docker image not available",
                "platform": "darwin",
                "packages_tested": 0,
                "findings": [],
                "static_malware": "enabled",
                "dynamic_malware": "skipped",
                "duration_ms": int((time.time() - start_time) * 1000)
            }
        
        # Run sandbox analysis
        print("      🐳 Running behavioral analysis in Colima sandbox...")
        result = _run_colima_sandbox(sbom_file, output_dir)
        
        if result:
            result['platform'] = 'darwin'
            result['runtime'] = 'colima'
            result['static_malware'] = 'enabled'
            result['dynamic_malware'] = 'enabled'
        
        return result
    
    # ==========================================================================
    # Other platforms: Not supported
    # ==========================================================================
    print(f"      ⚠️  Dynamic malware sandbox not supported on {system}")
    return {
        "verdict": "NOT_RUN",
        "reason": f"Platform {system} not supported for dynamic analysis",
        "platform": system,
        "packages_tested": 0,
        "findings": [],
        "static_malware": "enabled",
        "dynamic_malware": "not_supported",
        "duration_ms": int((time.time() - start_time) * 1000)
    }


def _check_colima_status() -> str:
    """
    Check Colima installation and running status.
    
    Returns:
        'running' - Colima is installed and running
        'stopped' - Colima is installed but not running
        'not_installed' - Colima is not installed
    """
    try:
        # Check if colima command exists
        if not shutil.which('colima'):
            return 'not_installed'
        
        # Check if colima is running
        # colima status returns 0 if running, non-zero if not
        result = subprocess.run(
            ['colima', 'status'],
            capture_output=True, text=True, timeout=10
        )
        
        # Check both stdout and stderr for status indicators
        output = (result.stdout + result.stderr).lower()
        
        if result.returncode == 0:
            return 'running'
        elif 'not running' in output or 'not exist' in output:
            return 'stopped'
        else:
            # Fallback: try docker info to see if docker daemon is accessible
            try:
                docker_result = subprocess.run(
                    ['docker', 'info'],
                    capture_output=True, timeout=5
                )
                if docker_result.returncode == 0:
                    return 'running'
            except:
                pass
            return 'stopped'
            
    except FileNotFoundError:
        return 'not_installed'
    except subprocess.TimeoutExpired:
        return 'stopped'
    except Exception:
        return 'not_installed'


def _start_colima() -> bool:
    """
    Start Colima VM with appropriate resources for sandbox.
    
    Returns:
        True if Colima started successfully, False otherwise
    """
    try:
        print("         (this may take 2-3 minutes on first run)")
        result = subprocess.run(
            ['colima', 'start', '--cpu', '2', '--memory', '4', '--disk', '10'],
            capture_output=False, text=True, timeout=300  # 5 min timeout, show output
        )
        if result.returncode == 0:
            # Give Docker daemon time to initialize
            import time
            time.sleep(5)
            return True
        else:
            print("         Colima start returned error")
            return False
    except subprocess.TimeoutExpired:
        print("         Timeout waiting for Colima to start")
        return False
    except Exception as e:
        print(f"         Error: {e}")
        return False


def _get_docker_client():
    """
    Get Docker client, trying Colima socket first on macOS.
    
    Returns:
        docker.DockerClient or None
    """
    import platform
    
    try:
        import docker
    except ImportError:
        return None
    
    # On macOS, try Colima socket first
    if platform.system() == 'Darwin':
        colima_socket = Path.home() / '.colima' / 'default' / 'docker.sock'
        if colima_socket.exists():
            try:
                client = docker.DockerClient(base_url=f'unix://{colima_socket}')
                client.ping()
                return client
            except:
                pass
    
    # Try default socket
    try:
        client = docker.from_env()
        client.ping()
        return client
    except:
        return None


def _ensure_sandbox_image() -> bool:
    """
    Ensure the sandbox Docker image is available.
    Uses Dockerfile hash to detect if rebuild is needed (cache invalidation).
    
    Returns:
        True if image is available, False otherwise
    """
    import hashlib
    
    try:
        import docker
    except ImportError:
        print("         Docker SDK not installed (pip install docker)")
        return False
    
    client = _get_docker_client()
    if not client:
        print("         Docker not running - start Colima first")
        return False
    
    image_name = "reachable/sandbox:latest"
    
    # Find sandbox directory
    sandbox_dir = Path(__file__).parent.parent / "sandbox"
    dockerfile = sandbox_dir / "Dockerfile"
    
    if not dockerfile.exists():
        sandbox_dir = Path(__file__).parent / "sandbox"
        dockerfile = sandbox_dir / "Dockerfile"
    
    if not dockerfile.exists():
        print("         Dockerfile not found")
        return False
    
    # Compute hash of Dockerfile + runner.py (detection rules)
    hasher = hashlib.sha256()
    hasher.update(dockerfile.read_bytes())
    runner_py = sandbox_dir / "runner.py"
    if runner_py.exists():
        hasher.update(runner_py.read_bytes())
    current_hash = hasher.hexdigest()[:12]  # Short hash for label
    
    # Check if image exists with matching hash
    try:
        image = client.images.get(image_name)
        cached_hash = image.labels.get('reachable.sandbox.hash', '')
        
        if cached_hash == current_hash:
            print("      ✅ Sandbox image ready (cached)")
            return True
        else:
            print(f"      🔄 Sandbox image outdated (rebuilding...)")
    except docker.errors.ImageNotFound:
        print("      🔨 Building sandbox image (first time only)...")
    
    # Build image with hash label
    try:
        print(f"         Building from {sandbox_dir}")
        image, build_logs = client.images.build(
            path=str(sandbox_dir),
            tag=image_name,
            labels={'reachable.sandbox.hash': current_hash},
            rm=True,
            quiet=False
        )
        print("      ✅ Sandbox image built")
        return True
    except Exception as e:
        print(f"         Build failed: {e}")
        return False


def _run_colima_sandbox(sbom_file: Path, output_dir: Path) -> Optional[dict]:
    """
    Internal: Run Docker-based sandbox when Colima is available.
    
    Colima provides a proper VM isolation layer, making it safe to run
    potentially malicious code (unlike Docker Desktop on macOS).
    """
    # Delegate to the existing sandbox analysis logic
    return run_sandbox_analysis(sbom_file, output_dir)


def run_sandbox_analysis(sbom_file: Path, output_dir: Path) -> Optional[dict]:
    """
    Run behavioral sandbox analysis on dependencies (internal implementation).
    
    Uses hybrid testing: batch first, then individual tests if issues found.
    
    Args:
        sbom_file: Path to SBOM JSON file
        output_dir: Output directory for results
        
    Returns:
        Sandbox results dict or None if sandbox unavailable
    """
    print("      🔒 Checking sandbox prerequisites...")
    
    # Check 1: Docker Python SDK
    docker_sdk_installed = False
    try:
        import docker
        docker_sdk_installed = True
        print("   ✓ Docker SDK: installed")
    except ImportError:
        print("   ✗ Docker SDK: not installed")
        print("   📦 Installing docker Python SDK...")
        import subprocess
        try:
            subprocess.check_call(
                [sys.executable, "-m", "pip", "install", "docker", "-q"],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL
            )
            import docker
            docker_sdk_installed = True
            print("   ✓ Docker SDK: installed successfully")
        except Exception as e:
            print(f"   ✗ Docker SDK: installation failed - {e}")
            print("   💡 Run manually: pip install docker")
            return {
                "verdict": "NOT_RUN",
                "reason": "Could not install docker Python SDK",
                "packages_tested": 0,
                "findings": [],
                "prerequisites": {
                    "docker_sdk": False,
                    "docker_daemon": False
                }
            }
    
    # Check 2: Docker daemon running
    docker_daemon_running = False
    daemon_error = None
    try:
        client = docker.from_env()
        client.ping()
        docker_daemon_running = True
        docker_version = client.version().get('Version', 'unknown')
        print(f"   ✓ Docker daemon: running (v{docker_version})")
    except Exception as e:
        daemon_error = str(e)
        if "connection refused" in daemon_error.lower() or "connect" in daemon_error.lower():
            print("   ✗ Docker daemon: not running")
            print("   💡 Start Docker Desktop or run: sudo systemctl start docker")
        elif "permission denied" in daemon_error.lower():
            print("   ✗ Docker daemon: permission denied")
            print("   💡 Add user to docker group: sudo usermod -aG docker $USER")
        else:
            print(f"   ✗ Docker daemon: {daemon_error}")
    
    if not docker_daemon_running:
        return {
            "verdict": "NOT_RUN",
            "reason": daemon_error or "Docker daemon not available",
            "packages_tested": 0,
            "findings": [],
            "prerequisites": {
                "docker_sdk": docker_sdk_installed,
                "docker_daemon": False,
                "error": daemon_error
            }
        }
    
    # Both prerequisites met
    try:
        from .sandbox.runner import SandboxRunner, Verdict
        from .comprehensive_metrics import SandboxMetrics
    except ImportError as e:
        print(f"   ⚠️  Sandbox module not available: {e}")
        return None
    
    # Create runner (Docker is confirmed available)
    runner = SandboxRunner(timeout=300, parallel=4)
    
    # Parse SBOM to get packages (handles both compressed and uncompressed)
    try:
        try:
            from .compression import load_json
            sbom = load_json(sbom_file)
        except ImportError:
            with open(sbom_file) as f:
                sbom = json.load(f)
    except Exception as e:
        print(f"   ⚠️  Could not read SBOM: {e}")
        return None
    
    # Extract packages from SBOM (Syft format uses 'artifacts', CycloneDX uses 'components')
    packages = []
    
    # Try Syft format first (artifacts), then CycloneDX (components)
    components = sbom.get('artifacts', []) or sbom.get('components', [])
    
    if not components:
        print("   ℹ️  No packages found in SBOM")
        return {
            "verdict": "CLEAN",
            "reason": "No packages in SBOM",
            "packages_tested": 0,
            "findings": []
        }
    
    npm_count = 0
    pip_count = 0
    skipped_count = 0
    skipped_by_type = {}  # Track why packages were skipped
    
    for comp in components:
        name = comp.get('name', '')
        version = comp.get('version')
        
        # Syft format uses 'type', CycloneDX uses 'purl'
        pkg_type = comp.get('type', '').lower()
        purl = comp.get('purl', '')
        
        # Determine ecosystem
        ecosystem = None
        if pkg_type in ('npm', 'node'):
            ecosystem = 'npm'
            npm_count += 1
        elif pkg_type in ('pip', 'pypi', 'python'):
            ecosystem = 'pip'
            pip_count += 1
        elif 'pkg:pypi' in purl:
            ecosystem = 'pip'
            pip_count += 1
        elif 'pkg:npm' in purl:
            ecosystem = 'npm'
            npm_count += 1
        elif pkg_type in ('go-module', 'go', 'golang') or 'pkg:golang' in purl:
            skipped_count += 1
            skipped_by_type['Go'] = skipped_by_type.get('Go', 0) + 1
            continue  # Skip Go packages (different install mechanism)
        elif pkg_type in ('maven', 'gradle', 'java') or 'pkg:maven' in purl:
            skipped_count += 1
            skipped_by_type['Java/Maven'] = skipped_by_type.get('Java/Maven', 0) + 1
            continue  # Skip Java packages
        elif pkg_type in ('cargo', 'rust') or 'pkg:cargo' in purl:
            skipped_count += 1
            skipped_by_type['Rust'] = skipped_by_type.get('Rust', 0) + 1
            continue  # Skip Rust packages
        elif pkg_type in ('gem', 'ruby') or 'pkg:gem' in purl:
            skipped_count += 1
            skipped_by_type['Ruby'] = skipped_by_type.get('Ruby', 0) + 1
            continue  # Skip Ruby packages
        else:
            skipped_count += 1
            skipped_by_type['Other'] = skipped_by_type.get('Other', 0) + 1
            continue  # Skip unknown ecosystems
        
        if name and ecosystem:
            packages.append((name, ecosystem, version))
    
    if not packages:
        reason = f"No pip/npm packages found in SBOM to sandbox test"
        if skipped_count > 0:
            reason += f" ({skipped_count} Go/Java/other packages skipped)"
        print(f"   ℹ️  {reason}")
        return {
            "verdict": "CLEAN",
            "reason": reason,
            "packages_tested": 0,
            "findings": [],
            "stats": {
                "npm_packages": npm_count,
                "pip_packages": pip_count,
                "skipped_packages": skipped_count,
                "sbom_total": len(components)
            }
        }
    
    # Show breakdown before testing
    print(f"   🔒 Sandbox will test {len(packages)} packages:")
    print(f"      • npm: {npm_count}")
    print(f"      • pip: {pip_count}")
    if skipped_count > 0:
        skipped_detail = ", ".join(f"{k}: {v}" for k, v in sorted(skipped_by_type.items(), key=lambda x: -x[1]))
        print(f"      • skipped: {skipped_count} ({skipped_detail})")
        print(f"        ℹ️  Why skipped:")
        print(f"           • Go modules: No install-time hooks (uses go.mod declarative imports)")
        print(f"           • Java/Maven: Build-time dependencies (Gradle/Maven manages lifecycle)")
        print(f"           • Other: Ecosystem not yet supported for behavioral testing")
        print(f"        💡 Tip: These packages are still scanned by GuardDog static analysis")
    print()
    print(f"   🐳 Running behavioral sandbox analysis...")
    print(f"      Strategy: Batch test all → individual tests if suspicious")
    
    # Use hybrid testing for efficiency
    def progress_callback(phase, current, total, pkg):
        if phase == "batch":
            if current == 0:
                print(f"      Phase 1: Batch testing all packages...")
            else:
                print(f"      Phase 1: Complete")
        elif phase == "individual":
            print(f"      Phase 2: Testing {pkg} ({current}/{total})...")
    
    try:
        result = runner.test_hybrid(packages, progress_callback=progress_callback)
        
        # Convert to metrics for structured data
        metrics = SandboxMetrics.from_hybrid_result(result)
        
        # Count malicious/suspicious for risk score integration
        malicious_count = len(result.malicious_packages) if result.malicious_packages else 0
        suspicious_count = len(result.batch_result.suspicious_packages) if result.batch_result.suspicious_packages else 0
        
        # Map WARNING → suspicious, CRITICAL → malicious for risk score
        if result.verdict.value == "CRITICAL" and malicious_count == 0:
            malicious_count = 1  # At least one if CRITICAL verdict
        elif result.verdict.value == "WARNING" and suspicious_count == 0:
            suspicious_count = 1  # At least one if WARNING verdict
        
        # Build result dict for JSON/dashboard
        sandbox_data = {
            "verdict": result.verdict.value,
            "capability_score": metrics.min_capability_score,
            "packages_tested": metrics.packages_tested,
            "duration_ms": result.duration_ms,
            "strategy": "hybrid",
            # Summary for risk score integration (matches sandbox_executor format)
            "summary": {
                "malicious": malicious_count,
                "suspicious": suspicious_count,
                "clean": metrics.packages_tested - malicious_count - suspicious_count,
                "verdict_explanation": {
                    "CLEAN": "No suspicious behavior detected",
                    "INFO": "Minor activity detected, not concerning",
                    "WARNING": "Suspicious behavior (HIGH severity) - network calls, env access",
                    "CRITICAL": "Malicious behavior confirmed - credential theft, exfiltration",
                    "ERROR": "Sandbox execution failed"
                }.get(result.verdict.value, "Unknown verdict")
            },
            "findings": [
                {
                    "rule": f.rule,
                    "severity": f.severity.value if hasattr(f.severity, 'value') else str(f.severity),
                    "description": f.description,
                    "phase": f.phase,
                    "evidence": f.evidence
                }
                for f in result.batch_result.findings
            ],
            "malicious_packages": result.malicious_packages,
            "suspicious_packages": result.batch_result.suspicious_packages,
            "metrics": metrics.to_dict(),
            "batch": {
                "verdict": result.batch_result.verdict.value,
                "duration_ms": result.batch_result.duration_ms,
                "findings_count": len(result.batch_result.findings)
            },
            "individual_tests": len(result.individual_results)
        }
        
        # Add individual findings
        for r in result.individual_results:
            for f in r.findings:
                sandbox_data["findings"].append({
                    "rule": f.rule,
                    "severity": f.severity.value if hasattr(f.severity, 'value') else str(f.severity),
                    "description": f.description,
                    "phase": f.phase,
                    "evidence": f.evidence,
                    "package": r.package
                })
        
        # Print summary with explanation
        verdict_icon = {
            "CLEAN": "✅",
            "INFO": "ℹ️",
            "WARNING": "⚠️",
            "CRITICAL": "🚨",
            "ERROR": "❌"
        }.get(result.verdict.value, "❓")
        
        verdict_explanation = {
            "CLEAN": "No suspicious install-time behavior",
            "INFO": "Minor activity detected",
            "WARNING": f"Suspicious behavior ({suspicious_count} packages) - review issues",
            "CRITICAL": f"MALICIOUS behavior ({malicious_count} packages) - immediate action needed",
            "ERROR": "Sandbox execution failed"
        }.get(result.verdict.value, "")
        
        print(f"      {verdict_icon} Sandbox verdict: {result.verdict.value}")
        if verdict_explanation:
            print(f"         → {verdict_explanation}")
        if result.malicious_packages:
            print(f"      🚨 Malicious packages: {', '.join(result.malicious_packages)}")
        if result.batch_result.suspicious_packages:
            print(f"      ⚠️  Suspicious packages: {', '.join(result.batch_result.suspicious_packages[:5])}")
            if len(result.batch_result.suspicious_packages) > 5:
                print(f"         ... and {len(result.batch_result.suspicious_packages) - 5} more")
            
            # Show details about WHY packages are suspicious 
            if result.batch_result.findings:
                print(f"      📋 Suspicious behaviors detected:")
                finding_types = {}
                for finding in result.batch_result.findings[:20]:  # Limit output
                    finding_type = finding.finding_type if hasattr(finding, 'finding_type') else 'unknown'
                    finding_types[finding_type] = finding_types.get(finding_type, 0) + 1
                for ftype, count in sorted(finding_types.items(), key=lambda x: -x[1])[:5]:
                    print(f"         • {ftype}: {count} occurrences")
                if len(result.batch_result.findings) > 20:
                    print(f"         ... and {len(result.batch_result.findings) - 20} more issues")
        print(f"      ⏱️  Duration: {result.duration_ms}ms")
        
        return sandbox_data
        
    except Exception as e:
        print(f"   ⚠️  Sandbox error: {e}")
        import traceback
        traceback.print_exc()
        return {
            "verdict": "ERROR",
            "reason": str(e),
            "packages_tested": len(packages),
            "findings": []
        }

def run_reachability_analysis(
    repo_path: Path,
    sbom_file: Path,
    vulns_file: Path,
    libs_dir: Optional[Path],
    output_dir: Path,
    enable_dynamic_malware: bool = True,
    debug: bool = False,
    progress_callback = None,
):
    """Run reachability analysis (reuses existing reachable.py)"""
    # Import existing analyzer
    from .reachable import ReachabilityAnalyzer
    
    # Create and run analyzer
    analyzer = ReachabilityAnalyzer(
        app_dir=repo_path,
        libs_dir=libs_dir,
        sbom_file=sbom_file,
        vulns_file=vulns_file,
        verbose=debug,  # Only print details in debug mode
        progress_callback=progress_callback,
    )
    
    results = analyzer.analyze()
    
    # Run dynamic malware sandbox analysis if enabled
    # Note: Static malware analysis (GuardDog) always runs as part of reachability analysis
    sandbox_results = None
    if enable_dynamic_malware:
        if progress_callback:
            progress_callback(15, 15, "Dynamic Malware Sandbox", "Checking platform...")
        sandbox_results = run_dynamic_malware_sandbox(sbom_file, output_dir)
        if progress_callback:
            progress_callback(15, 15, "Dynamic Malware Sandbox", "Complete")
    if sandbox_results:
        results['dynamic_malware'] = sandbox_results
        # Also add to security_scans for dashboard compatibility
        if 'security_scans' not in results:
            results['security_scans'] = {}
        results['security_scans']['dynamic_malware'] = sandbox_results
    
    # Save results
    print()
    print("[5/5] Saving results...")
    
    # Helper to add timestamp to any dict
    from datetime import datetime
    def add_timestamp(data: dict) -> dict:
        """Add scan timestamp to JSON output"""
        data['_metadata'] = {
            'generated_at': datetime.now().isoformat() + 'Z',
            'reachable_version': results.get('reachable_version', __version__),
            'schema': 'REACHABLE'
        }
        return data
    
  
    try:
        from .compression import save_json as save_json_compressed
        use_compression = True
    except ImportError:
        use_compression = False
    
    # 1. Main report (everything) - use compression for large reports
    report_file = output_dir / "reachable-report.json"
    if use_compression:
        actual_file = save_json_compressed(results, report_file, compress=True)
        print(f"   ✓ Master report: {actual_file.name} (compressed)")
    else:
        with open(report_file, 'w') as f:
            json.dump(results, f, indent=2)
        print(f"   ✓ Master report: reachable-report.json")
    
    # Note: sbom.json and vulns.json already created in steps 1-2
    print(f"   ℹ️  Core files: sbom.json, vulns.json (created earlier)")
    
    # Legacy mode: create individual JSON files in raw/ (disabled by default)
    # Set to True for backward compatibility with older integrations
    legacy_raw = False
  
    # But always create for scan-manifest.json (needed for CI/CD)
    raw_dir = output_dir / "raw"
    raw_dir.mkdir(exist_ok=True)
    
    if legacy_raw:
        print("   💾 Legacy mode: Creating detailed JSON files in raw/")
    
    # Generate scan manifest for CI/CD coordination
    scan_id = results.get('metadata', {}).get('scan_id', 
              results.get('metadata', {}).get('scan_timing', {}).get('start_timestamp', 'unknown'))
    git_info = results.get('metadata', {}).get('git_info')
    scan_manifest = {
        'schema_version': '3.0',
        'scan_id': scan_id,
        'generated_at': results.get('metadata', {}).get('generated_at', ''),
        'generator_version': results.get('reachable_version', 'unknown'),
        'target': {
            'path': str(results.get('metadata', {}).get('analysis_target', {}).get('app_directory', '')),
            'git_commit': git_info.get('commit_sha') if git_info else None,
            'git_branch': git_info.get('branch') if git_info else None,
        },
        'components': {},
        'outputs': {
            'report': str(report_file.name),
            'dashboard': 'dashboard/index.html',
            'dashboard_data': 'dashboard/data.json',
        }
    }
    
    # 2. Save detailed data files to raw/ subfolder
    print(f"   📊 Saving detailed data files to raw/...")
    
    # CVEs - detailed findings with remediation
    if 'reachable' in results or 'unreachable' in results:
        cve_data = add_timestamp({
            "summary": {
                "total_cves": len(results.get('reachable', {})) + len(results.get('unreachable', {})),
                "reachable": len(results.get('reachable', {})),
                "unreachable": len(results.get('unreachable', {})),
                "by_severity": results.get('summary', {}).get('totals', {})
            },
            "reachable_cves": results.get('reachable', {}),
            "unreachable_cves": results.get('unreachable', {}),
            "exploitability": results.get('threat_intelligence', {})
        })
        
      
        if legacy_raw:
            cve_file = raw_dir / "cves.json"
            with open(cve_file, 'w') as f:
                json.dump(cve_data, f, indent=2)
            print(f"      ✓ raw/cves.json ({len(cve_data['reachable_cves']) + len(cve_data['unreachable_cves'])} CVEs)")
            scan_manifest['components']['cves'] = {'status': 'complete', 'file': 'raw/cves.json'}
        else:
          
            print(f"      ✓ CVEs in database ({len(cve_data['reachable_cves']) + len(cve_data['unreachable_cves'])} CVEs)")
            scan_manifest['components']['cves'] = {'status': 'complete', 'location': 'database'}
    
    # Secrets - with locations and reachability
    if 'security_scans' in results and 'secrets' in results['security_scans']:
        secrets_data = results['security_scans']['secrets']
        if secrets_data:
            secrets_data = add_timestamp(secrets_data if isinstance(secrets_data, dict) else {"findings": secrets_data})
            security_file = raw_dir / "security_findings.json"
            with open(security_file, 'w') as f:
                json.dump(secrets_data, f, indent=2)
            total_secrets = secrets_data.get('total_findings', 0)
            print(f"      ✓ raw/security_findings.json ({total_secrets} secrets)")
            scan_manifest['components']['secrets'] = {'status': 'complete', 'file': 'raw/security_findings.json'}
    
    # Malware - tier 1/2/3 detections
    if 'malware_detection' in results and results['malware_detection']:
        malware_data = add_timestamp(results['malware_detection'])
        malware_file = raw_dir / "malware.json"
        with open(malware_file, 'w') as f:
            json.dump(malware_data, f, indent=2)
        malicious = malware_data.get('malicious_packages', 0)
        if isinstance(malicious, list):
            malicious = len(malicious)
        print(f"      ✓ raw/malware.json ({malicious} malicious packages)")
        scan_manifest['components']['malware'] = {'status': 'complete', 'file': 'raw/malware.json'}
    
    # Sandbox - behavioral analysis findings
    sandbox_data = None
    if 'sandbox' in results and results['sandbox']:
        sandbox_data = results['sandbox']
    elif 'security_scans' in results and 'sandbox' in results['security_scans']:
        sandbox_data = results['security_scans']['sandbox']
    
    if sandbox_data:
        sandbox_data = add_timestamp(sandbox_data if isinstance(sandbox_data, dict) else {"findings": sandbox_data})
        sandbox_file = raw_dir / "sandbox.json"
        with open(sandbox_file, 'w') as f:
            json.dump(sandbox_data, f, indent=2)
        verdict = sandbox_data.get('verdict', 'N/A')
        findings = sandbox_data.get('findings', [])
        if not isinstance(findings, list):
            findings = []
        findings_count = len(findings)
        critical_count = sum(1 for f in findings if isinstance(f, dict) and f.get('severity') == 'CRITICAL')
        print(f"      ✓ raw/sandbox.json (verdict: {verdict}, {findings_count} issues, {critical_count} critical)")
        scan_manifest['components']['sandbox'] = {'status': 'complete', 'file': 'raw/sandbox.json'}
    
    # Package Health - unmaintained/risky packages
    if 'tool_execution_log' in results and 'package_health_analyzer' in results['tool_execution_log']:
        health_log = results['tool_execution_log']['package_health_analyzer']
        if health_log.get('executed'):
            health_data = add_timestamp({
                "summary": {
                    "total_packages": health_log['metrics']['packages_analyzed'],
                    "health_distribution": health_log['metrics']['health_distribution'],
                    "unmaintained": health_log['metrics']['health_distribution'].get('CRITICAL', 0),
                    "risky": health_log['metrics']['health_distribution'].get('MEDIUM', 0)
                },
                "findings": results.get('findings', {}).get('package_health_issues', [])
            })
            health_file = raw_dir / "health.json"
            with open(health_file, 'w') as f:
                json.dump(health_data, f, indent=2)
            print(f"      ✓ raw/health.json ({health_data['summary']['total_packages']} packages)")
            scan_manifest['components']['health'] = {'status': 'complete', 'file': 'raw/health.json'}
    
    # Correlation - threat correlations (large file, use compression)
    if 'correlation' in results and results['correlation']:
        correlation_data = add_timestamp(results['correlation'])
        correlation_file = raw_dir / "correlation.json"
        if use_compression:
            actual_file = save_json_compressed(correlation_data, correlation_file, compress=True)
            total_threats = correlation_data.get('summary', {}).get('total_composite_threats', 0)
            print(f"      ✓ raw/{actual_file.name} ({total_threats} composite threats)")
            scan_manifest['components']['correlation'] = {'status': 'complete', 'file': f'raw/{actual_file.name}'}
        else:
            with open(correlation_file, 'w') as f:
                json.dump(correlation_data, f, indent=2)
            total_threats = correlation_data.get('summary', {}).get('total_composite_threats', 0)
            print(f"      ✓ raw/correlation.json ({total_threats} composite threats)")
            scan_manifest['components']['correlation'] = {'status': 'complete', 'file': 'raw/correlation.json'}
    
    # Attack Surface - phantom deps, shadow imports
    if 'findings' in results and 'attack_surface' in results['findings']:
        attack_surface_data = add_timestamp(results['findings']['attack_surface'])
        attack_surface_file = raw_dir / "attack_surface.json"
        with open(attack_surface_file, 'w') as f:
            json.dump(attack_surface_data, f, indent=2)
        phantom = attack_surface_data.get('phantom_dependencies', {}).get('count', 0)
        print(f"      ✓ raw/attack_surface.json ({phantom} phantom dependencies)")
        scan_manifest['components']['attack_surface'] = {'status': 'complete', 'file': 'raw/attack_surface.json'}
    
    # Call graphs (keep in output_dir for easy access, also copy to raw/)
    if 'call_graph_exports' in results:
        for format_name, content in results['call_graph_exports'].items():
            graph_file = output_dir / f"call-graph.{format_name}"
            with open(graph_file, 'w') as f:
                f.write(content)
            # Also save to raw/
            raw_graph_file = raw_dir / f"call-graph.{format_name}"
            with open(raw_graph_file, 'w') as f:
                f.write(content)
        print(f"      ✓ call-graph.json (+ raw/)")
        scan_manifest['components']['call_graph'] = {'status': 'complete', 'file': 'raw/call-graph.json'}
    
    # Save scan manifest
    manifest_file = raw_dir / "scan-manifest.json"
    with open(manifest_file, 'w') as f:
        json.dump(scan_manifest, f, indent=2)
    print(f"      ✓ raw/scan-manifest.json (CI/CD coordination)")
    
    # Populate database with all findings (after raw files exist)
    # v4.5.8: Store to repo.db (per-repo database with history)
    # v4.5.10: Extract and pass risk data to DB storage
    overall_risk = results.get('summary', {}).get('overall_risk', {})
    db_risk_score = overall_risk.get('risk_score', 0)
    db_risk_level = overall_risk.get('risk_level', None)
    store_scan_to_database(output_dir, use_legacy_raw=legacy_raw, repo_path=repo_path,
                           risk_score=db_risk_score, risk_level=db_risk_level)
    
    # Store repo.db path in results for dashboard generator
    from .database_storage import get_repo_db_path
    results['_repo_db_path'] = str(get_repo_db_path(repo_path))
    
    return results

def _generate_dashboard(results: dict, output_dir: Path, skip: bool = False) -> None:
    """Generate Dashboard v2 (funnel visualization with Executive + Engineering views)"""
    if skip:
        print(f"      ⏭️  Dashboard skipped (--no-dashboard)")
        return
    
    try:
        from reachable.dashboard_v2.generator import DashboardV2Generator
        
        generator = DashboardV2Generator()
        dashboard_dir = generator.generate_from_report(results, output_dir)
        # Dashboard path is shown in scan_complete banner - no need to repeat here
    except Exception as e:
        print(f"      ⚠ Dashboard generation failed: {e}")

def print_summary(results: dict):
    """Print summary (reuses existing format)"""
    print()
    print("=" * 70)
    print("ANALYSIS COMPLETE")
    print("=" * 70)
    
    summary = results.get('summary', {})
    totals = summary.get('totals', {})
    
    print()
    print("📊 CVE Summary:")
    total_cves = totals.get('cves_total', summary.get('total_cves', 0))
    print(f"   Total CVEs found: {total_cves}")
    
    # Severity breakdown
    critical = totals.get('cves_critical', 0)
    high = totals.get('cves_high', 0)
    medium = totals.get('cves_medium', 0)
    low = totals.get('cves_low', 0)
    
    if critical + high + medium + low > 0:
        print(f"   📋 Severity Breakdown:")
        if critical > 0:
            print(f"      🔴 Critical: {critical}")
        if high > 0:
            print(f"      🟠 High: {high}")
        if medium > 0:
            print(f"      🟡 Medium: {medium}")
        if low > 0:
            print(f"      🟢 Low: {low}")
    
    print()
    reachable = totals.get('cves_reachable', summary.get('reachable_cves', 0))
    unreachable = totals.get('cves_unreachable', summary.get('unreachable_cves', 0))
    print(f"   ✅ REACHABLE: {reachable} (require immediate attention)")
    print(f"   ❌ UNREACHABLE: {unreachable} (Risk: LOW)")
    print(f"   📉 Risk Reduction: {summary.get('risk_reduction_pct', 0):.1f}%")
    
    print()
    print("📈 Code Coverage:")
    print(f"   Functions analyzed: {summary.get('total_functions', 0)}")
    reachable_count = summary.get('reachable_functions', 0)
    total_funcs = summary.get('total_functions', 1)
    pct = (reachable_count / total_funcs * 100) if total_funcs > 0 else 0
    print(f"   Reachable from entrypoints: {reachable_count} ({pct:.1f}%)")
    print()

def _get_repo_stats(repo_path: Path) -> dict:
    """
    Get repository scan statistics from repo.db.
    
    Returns:
        dict with branch, scan_count, first_scan_date
    """
    import subprocess
    from .database_storage import get_repo_db_path
    
    stats = {
        'branch': 'unknown',
        'scan_count': 0,
        'first_scan_date': None,
    }
    
    # Get current git branch
    try:
        result = subprocess.run(
            ['git', 'rev-parse', '--abbrev-ref', 'HEAD'],
            capture_output=True, text=True, cwd=repo_path, timeout=5
        )
        if result.returncode == 0:
            stats['branch'] = result.stdout.strip()
    except:
        pass
    
    # Get scan history from repo.db
    try:
        import sqlite3
        repo_db_path = get_repo_db_path(repo_path)
        if repo_db_path.exists():
            conn = sqlite3.connect(str(repo_db_path))
            cursor = conn.cursor()
            
            # Get total scan count for this repo
            cursor.execute("SELECT COUNT(*) FROM scans WHERE status = 'complete'")
            stats['scan_count'] = cursor.fetchone()[0]
            
            # Get first scan date
            cursor.execute("SELECT MIN(timestamp) FROM scans")
            first = cursor.fetchone()[0]
            if first:
                stats['first_scan_date'] = first[:10]  # YYYY-MM-DD
            
            conn.close()
    except:
        pass
    
    return stats

def scan_repo(args):
    """Scan an arbitrary repository"""
    from .output_manager import OutputManager
    from .output_modes import print_quiet_summary, print_enhanced_summary, print_verbose_summary
    from .scan_logger import ScanLogger
    from .database_storage import RepoDatabase, get_repo_db_path
    from .preflight import preflight_check
    from . import __version__
    import time
    
    # Preflight check - ensure all tools are ready (auto-fix if missing)
    quiet_mode = getattr(args, 'quiet', False)
    preflight = preflight_check(fix=True, quiet=quiet_mode, skip_vulndb=False)
    if not preflight.ok:
        print("\n❌ Cannot start scan - missing dependencies:")
        for issue in preflight.issues:
            print(f"  - {issue}")
        print("\nRun 'reachctl doctor' to resolve.")
        sys.exit(1)
    
    # Initialize structured logger
    debug_mode = getattr(args, 'debug', False)
    quiet_mode = getattr(args, 'quiet', False)
    fail_on_threshold = getattr(args, 'fail_on', 'none')
    
    repo_path = Path(args.repo).resolve()
    
    # Initialize output manager first to get output_dir
    custom_output = Path(args.output).resolve() if args.output else None
    output_mgr = OutputManager(repo_path, custom_output)
    output_dir = output_mgr.scan_dir
    
    # Initialize logger with log file
    log_path = output_dir / "scan.log"
    logger = ScanLogger(debug=debug_mode, log_file=log_path)
    
    # Get license info for banner
    license_info = None
    try:
        from .license import validate_license
        license_info = validate_license()
    except:
        pass
    
    # Get repo stats for banner
    repo_stats = _get_repo_stats(repo_path)
    
    # Initialize scan context early for language/build system detection in header
    from .scan_context import ScanContext
    scan_ctx = ScanContext(repo_path, output_dir)
    
    # Print scan header with analysis scope (before tee takes over)
    logger.scan_start_msg(repo_path.name, repo_path, __version__, 
                          license_info=license_info, repo_stats=repo_stats,
                          scan_context=scan_ctx)
    
    # Use output manager for all paths
    libs_dir = output_mgr.scan_dir / "libs"
    
    # Tee output to log file - suppress console unless in debug mode
    # Quiet mode also suppresses console (for CI/CD)
    # This captures all verbose output from scanners to the log file
    # while showing only our structured output on console
    console_enabled = debug_mode and not quiet_mode
    tee = TeeOutput(log_path, console_enabled=console_enabled)
    original_stdout = sys.stdout
    sys.stdout = tee
    
    try:
        # Validate inputs
        if not repo_path.exists():
            logger.info(f"❌ Error: Repository not found: {repo_path}")
            sys.exit(1)
        
        if not repo_path.is_dir():
            logger.info(f"❌ Error: Not a directory: {repo_path}")
            sys.exit(1)
        
        # scan_ctx already initialized above for header display
        if debug_mode:
            scan_ctx.print_scan_header()
        
        # Check GitHub connectivity (for library cloning) - only show in debug mode
        check_github_connectivity(verbose=debug_mode)
        
        # Print scan plan for monorepos (only in debug mode)
        if debug_mode:
            scan_ctx.print_scan_plan()
        
        # Save scan plan (what we're going to scan)
        scan_plan = {
            'timestamp': output_mgr.timestamp,
            'repo_path': str(repo_path),
            'repo_name': output_mgr.repo_name,
            'project_type': scan_ctx.project_type,
            'languages': scan_ctx.detected_languages,
            'is_monorepo': scan_ctx.is_monorepo,
            'subprojects': scan_ctx.subprojects,
            'file_counts': scan_ctx.total_files
        }
        output_mgr.save_scan_plan(scan_plan)
        
        # Initialize scan metadata (tool versions, policies)
        scan_metadata = {
            'scan_started': output_mgr.timestamp,
            'command': ' '.join(sys.argv),
            'scan_dir': str(output_dir),
            'tools_used': {},
            'policies_applied': {}
        }
        
        # Run analysis pipeline (reuses all existing logic!)
        # Step 1: Generate SBOM (reuses existing syft logic)
        logger.phase_start(1, "SBOM Generation", "Syft", total_phases=5)
        sbom_file = generate_sbom(repo_path, output_dir, verbose=debug_mode)
        logger.phase_end(1, f"Created {sbom_file.name}")
        
        # Step 2: Scan vulnerabilities (reuses existing grype logic)
        logger.phase_start(2, "Vulnerability Scan", "Grype", total_phases=5)
        vulns_file = scan_vulnerabilities(sbom_file, output_dir, verbose=debug_mode)
        logger.phase_end(2, "CVE scan complete")
        
        # Step 3: Clone vulnerable libs (NEW smart cloning)
        logger.phase_start(3, "Library Cloning", "MCP/Git", total_phases=5)
        libs_path, lib_metrics = clone_vulnerable_libs(vulns_file, libs_dir, scan_ctx, verbose=debug_mode)
        cloned_count = lib_metrics.get('mcp_success', 0) + lib_metrics.get('git_success', 0) + lib_metrics.get('cache_hits', 0)
        logger.phase_end(3, f"{cloned_count} libraries cloned")
        
        # Step 4 & 5: Reachability analysis (reuses existing reachable.py)
        logger.phase_start(4, "Security Analysis", "Multi-Signal Analysis", total_phases=5)
        if debug_mode:
            scan_ctx.print_phase_header(4, 5, "Running Security Analysis", "Multi-Signal Analysis", 
                                       f"Analyzing {scan_ctx.project_type} project with {', '.join(scan_ctx.detected_languages)}")
        
        # Check dynamic malware sandbox settings
        enable_dynamic_malware = not getattr(args, 'no_dynamic_malware', False)
        
        analysis_start = time.time()
        last_step_time = [analysis_start]  # Use list to allow mutation in closure
        
        def progress_callback(step: int, total: int, name: str, status: str):
            """Show intermediate progress during Security Analysis"""
            now = time.time()
            step_elapsed = now - last_step_time[0]
            total_elapsed = now - analysis_start
            last_step_time[0] = now
            # Print inline progress update
            sys.__stdout__.write(f"\r    [{step}/{total}] {name}: {status} ({step_elapsed:.1f}s)".ljust(70))
            sys.__stdout__.flush()
            if step == total:
                sys.__stdout__.write("\n")
                sys.__stdout__.flush()
        
        results = run_reachability_analysis(
            repo_path,
            sbom_file,
            vulns_file,
            libs_path,
            output_dir,
            enable_dynamic_malware=enable_dynamic_malware,
            debug=debug_mode,
            progress_callback=progress_callback,
        )
        logger.phase_end(4, "Analysis complete")
        
        # Add library metrics to results (includes obsolete packages info)
        results['library_metrics'] = lib_metrics
        
        # Optional: Run deployment advisories scan (IaC/config)
        if getattr(args, 'enable_config_mgt', False):
            logger.phase_start(5, "Config Scanning", "Checkov/Semgrep", total_phases=6)
            
            from .deployment_advisories import DeploymentAdvisoriesScanner, print_advisories
            
            use_checkov = getattr(args, 'use_checkov', False)
            adv_scanner = DeploymentAdvisoriesScanner(use_checkov=use_checkov)
            adv_result = adv_scanner.scan(repo_path)
            
            # Save results
            adv_file = output_dir / "deployment-advisories.json"
            import json
            with open(adv_file, 'w') as f:
                json.dump(adv_result.to_dict(), f, indent=2)
            
            # Add to results (but clearly marked as NOT in risk score)
            results['deployment_advisories'] = {
                'enabled': True,
                'included_in_risk_score': False,
                'total': len(adv_result.advisories),
                'by_category': adv_result.by_category,
                'by_severity': adv_result.by_severity,
                'source': adv_result.source,
                'output_file': str(adv_file),
            }
            
            logger.phase_end(5, f"{len(adv_result.advisories)} advisories found")
            
            # Print summary in debug mode
            if debug_mode:
                print_advisories(adv_result, verbose=True)
        else:
            results['deployment_advisories'] = {
                'enabled': False,
                'message': 'Use --enable-config-mgt to scan IaC/deployment configs',
            }
        
        # Optional: Run AI security scan (OWASP LLM Top 10)
        enable_ai = getattr(args, 'enable_ai', False)
        ai_only = getattr(args, 'ai_only', False)
        if enable_ai or ai_only:
            phase_num = 6 if getattr(args, 'enable_config_mgt', False) else 5
            total = 6 if getattr(args, 'enable_config_mgt', False) else 5
            logger.phase_start(phase_num, "AI Security", "OWASP LLM Top 10", total_phases=total)
            
            try:
                from .ai import AISecurityScanner, AIScanConfig
                
                ai_scanner = AISecurityScanner(config=AIScanConfig.full())
                ai_findings = list(ai_scanner.scan(repo_path))
                
                # Group by OWASP category
                by_owasp = {}
                by_severity = {'ERROR': 0, 'WARNING': 0, 'INFO': 0}
                for f in ai_findings:
                    cat = f.owasp_category or 'OTHER'
                    if cat not in by_owasp:
                        by_owasp[cat] = []
                    by_owasp[cat].append(f.to_dict())
                    by_severity[f.severity] = by_severity.get(f.severity, 0) + 1
                
                # Save AI results
                ai_file = output_dir / "ai-security.json"
                import json
                with open(ai_file, 'w') as f:
                    json.dump({
                        'total': len(ai_findings),
                        'by_owasp': {k: len(v) for k, v in by_owasp.items()},
                        'by_severity': by_severity,
                        'findings': [finding.to_dict() for finding in ai_findings],
                    }, f, indent=2, default=str)
                
                # Add to results
                results['ai_security'] = {
                    'enabled': True,
                    'included_in_risk_score': False,  # Not yet
                    'total': len(ai_findings),
                    'by_owasp': {k: len(v) for k, v in by_owasp.items()},
                    'by_severity': by_severity,
                    'critical_findings': sum(1 for f in ai_findings if f.is_critical),
                    'output_file': str(ai_file),
                }
                
                logger.phase_end(phase_num, f"{len(ai_findings)} AI findings")
                
                # Print summary in debug mode
                if debug_mode and ai_findings:
                    print(f"\n  AI Security Findings:")
                    for cat, count in sorted(by_owasp.items(), key=lambda x: len(x[1]), reverse=True):
                        print(f"    {cat}: {len(count)} findings")
            except ImportError as e:
                logger._write(f"\n  ⚠️  AI module not available: {e}")
                results['ai_security'] = {'enabled': False, 'error': str(e)}
                logger.phase_end(phase_num, "skipped (module unavailable)")
            except Exception as e:
                logger._write(f"\n  ⚠️  AI scan error: {e}")
                if debug_mode:
                    import traceback
                    logger._write(traceback.format_exc())
                results['ai_security'] = {'enabled': False, 'error': str(e)}
                logger.phase_end(phase_num, "error")
        else:
            results['ai_security'] = {
                'enabled': False,
                'message': 'Use --enable-ai for OWASP LLM Top 10 analysis',
            }
        
        # Print timing summary
        logger.print_timing_summary()
        
        # Extract results for summary - with error handling
        try:
            summary = results.get('summary', {})
            totals = summary.get('totals', {})
            
            # Set counts for logger (v4.5.17: Enhanced with unknown counts)
            # Get security_scans for malware breakdown
            security_scans = results.get('security_scans', {})
            dynamic_malware = results.get('dynamic_malware', security_scans.get('dynamic_malware', {}))
            
            logger.set_counts(
                # CVEs
                cves_total=totals.get('cves_total', 0),
                cves_reachable=totals.get('cves_reachable', 0),
                cves_unknown=totals.get('cves_unknown', 0),
                # Malware (static + dynamic)
                malware_static=totals.get('malware_total', 0),
                malware_dynamic=dynamic_malware.get('summary', {}).get('malicious', 0) if dynamic_malware else 0,
                malware_reachable=totals.get('malware_reachable', 0),
                malware_count=totals.get('malware_total', 0),  # backward compat
                # Secrets
                secrets_total=totals.get('secrets_total', 0),
                secrets_reachable=totals.get('secrets_reachable', 0),
                secrets_unknown=totals.get('secrets_unknown', 0),
                # CWE
                cwe_total=totals.get('cwe_total', 0),
                cwe_reachable=totals.get('cwe_reachable', 0),
                cwe_unknown=totals.get('cwe_unknown', 0),
                # Config (always unknown)
                config_total=totals.get('config_total', 0),
            )
            
            # Print results summary
            logger.print_results_summary()
            
            # Get risk score (v4.5.3 fix: risk is nested in overall_risk)
            overall_risk = summary.get('overall_risk', {})
            risk_score = overall_risk.get('risk_score', 0)
            risk_level = overall_risk.get('risk_level', 'UNKNOWN')
            
            # Print scan complete banner with dashboard link
            logger.print_scan_complete(risk_score, risk_level, output_dir)
            
            # Print debug report if in debug mode
            logger.print_debug_report()
            
        except Exception as summary_err:
            # Make sure we see any errors in summary generation
            logger._write(f"⚠️  Error generating summary: {summary_err}")
            import traceback
            logger._write(traceback.format_exc())
        
        # Generate dashboard
        _generate_dashboard(results, output_dir, skip=False)
        
        # Create 'latest' symlink
        output_mgr.create_latest_symlink()
        
        # Auto-trim now handled inside store_scan_to_database (repo.db cleanup)
        
        # Quiet mode: print single-line summary
        if quiet_mode:
            print_quiet_summary(results, output_dir)
        
        # === FAIL-ON THRESHOLD CHECK (v4.5.0) ===
        exit_code = 0
        if fail_on_threshold != 'none':
            from .sarif_exporter import check_threshold
            should_fail, reason = check_threshold(results, fail_on_threshold)
            if should_fail:
                if quiet_mode:
                    # v4.5.2: Always show gate result in CI/CD (use real stdout)
                    sys.__stdout__.write(f"🚨 CI/CD GATE FAILED: {reason}\n")
                    sys.__stdout__.flush()
                else:
                    print(f"\n🚨 CI/CD GATE FAILED: {reason}")
                    print(f"   Threshold: --fail-on {fail_on_threshold}")
                exit_code = 1
            else:
                if quiet_mode:
                    # v4.5.2: Always show gate result in CI/CD (use real stdout)
                    sys.__stdout__.write(f"✅ CI/CD gate passed: {reason}\n")
                    sys.__stdout__.flush()
                else:
                    print(f"\n✅ CI/CD gate passed: {reason}")
        
        # Store exit code for later (after finally block)
        scan_exit_code = exit_code
        
    except Exception as e:
        # Use multiple approaches to ensure error is visible
        error_msg = f"❌ Error during analysis: {e}"
        try:
            logger._write("")
            logger._write(error_msg)
        except:
            pass
        # Also print to original stdout directly (sys is already imported at module level)
        sys.__stdout__.write(f"\n{error_msg}\n")
        sys.__stdout__.flush()
        import traceback
        traceback.print_exc(file=sys.__stdout__)
        sys.exit(1)
    finally:
        # Close log file and restore stdout
        sys.stdout = original_stdout
        tee.close()
    
    # Exit with appropriate code (after finally block)
    # scan_exit_code is set in the try block based on --fail-on threshold
    if 'scan_exit_code' in locals() and scan_exit_code != 0:
        sys.exit(scan_exit_code)

def _is_dev_build() -> bool:
    """Check if this is a development build (not customer distribution)"""
    from pathlib import Path
    import os
    
    # Check for .dev marker file (present in dev, removed in customer builds)
    dev_marker = Path(__file__).parent / '.dev'
    if dev_marker.exists():
        return True
    
    # Check for compiled Cython modules (customer builds have these)
    core_dir = Path(__file__).parent / 'core'
    if core_dir.exists():
        compiled = list(core_dir.glob('*.so')) + list(core_dir.glob('*.pyd'))
        if compiled:
            return False  # Customer build has compiled modules
    
    # Check environment variable override
    if os.environ.get('REACHABLE_DEV_MODE') == '1':
        return True
    
    return True  # Default: dev build

def format_size(size_bytes: int) -> str:
    """Format bytes as human-readable size"""
    for unit in ['B', 'KB', 'MB', 'GB']:
        if size_bytes < 1024:
            return f"{size_bytes:.1f} {unit}"
        size_bytes /= 1024
    return f"{size_bytes:.1f} TB"

def run_admin_command(args):
    """Handle admin subcommands"""
    if not args.admin_command:
        print("Usage: reachctl admin <cache|test|version|doctor>")
        print()
        print("Admin commands:")
        print("  cache    Cache management (--clear, --status)")
        print("  test     Run test suite")
        print("  version  Show detailed version info")
        print("  doctor   Check system dependencies")
        sys.exit(1)
    
    if args.admin_command == 'cache':
        admin_cache(args)
    elif args.admin_command == 'test':
        admin_test(args)
    elif args.admin_command == 'version':
        admin_version()
    elif args.admin_command == 'doctor':
        admin_doctor()
    else:
        print(f"Unknown admin command: {args.admin_command}")
        sys.exit(1)

def admin_cache(args):
    """Cache management commands"""
    from pathlib import Path
    import shutil
    
    cache_base = Path.home() / '.reachable'
    reachable_pkg = Path(__file__).parent  # The reachable package directory
    
    cache_dirs = {
        'libs': cache_base / 'libs',
        'guarddog': cache_base / 'guarddog',  # GuardDog malware scan results
        'vuln_db': cache_base / 'vuln-db',
        'epss': cache_base / 'epss',
        'scans': cache_base / 'scans',
        'sbom_cache': cache_base / 'sbom-cache',
    }
    
    # Find all __pycache__ directories in the reachable package
    pycache_dirs = list(reachable_pkg.rglob('__pycache__'))
    
    if args.status:
        print("=" * 60)
        print("REACHABLE CACHE STATUS")
        print("=" * 60)
        print()
        print(f"Cache location: {cache_base}")
        print()
        
        total_size = 0
        for name, path in cache_dirs.items():
            if path.exists():
                size = sum(f.stat().st_size for f in path.rglob('*') if f.is_file())
                total_size += size
                file_count = sum(1 for _ in path.rglob('*') if _.is_file())
                print(f"  {name:15} {format_size(size):>10}  ({file_count} files)")
            else:
                print(f"  {name:15} {'(empty)':>10}")
        
        # Show bytecode cache size
        bytecode_size = 0
        bytecode_files = 0
        for pycache in pycache_dirs:
            if pycache.exists():
                bytecode_size += sum(f.stat().st_size for f in pycache.rglob('*.pyc') if f.is_file())
                bytecode_files += sum(1 for f in pycache.rglob('*.pyc') if f.is_file())
        if bytecode_size > 0:
            total_size += bytecode_size
            print(f"  {'bytecode':15} {format_size(bytecode_size):>10}  ({bytecode_files} .pyc files)")
        else:
            print(f"  {'bytecode':15} {'(empty)':>10}")
        
        print()
        print(f"  {'TOTAL':15} {format_size(total_size):>10}")
        return
    
    # Warm caches
    if args.warm:
        admin_cache_warm()
        return
    
    # Determine what to clear
    targets = []
    clear_bytecode = False
    if args.clear:
        targets = ['libs', 'vuln_db', 'epss', 'sbom_cache']
        clear_bytecode = True  # v4.5.3: Also clear bytecode cache
    elif args.clear_libs:
        targets = ['libs']
    elif args.clear_vuln:
        targets = ['vuln_db']
    elif args.clear_epss:
        targets = ['epss']
    
    if not targets:
        print("No cache target specified")
        return
    
    # Confirm unless --force
    if not args.force:
        print("This will clear the following caches:")
        for name in targets:
            path = cache_dirs.get(name)
            if path and path.exists():
                size = sum(f.stat().st_size for f in path.rglob('*') if f.is_file())
                print(f"  - {name}: {format_size(size)}")
        confirm = input("Continue? [y/N] ").strip().lower()
        if confirm != 'y':
            print("Cancelled.")
            return
    
    # Clear caches
    for name in targets:
        path = cache_dirs.get(name)
        if path and path.exists():
            try:
                shutil.rmtree(path)
                print(f"Cleared {name}: {path}")
            except Exception as e:
                print(f"Failed to clear {name}: {e}")
        else:
            print(f"{name}: already empty")
    
    # v4.5.3: Clear bytecode cache to avoid stale .pyc issues
    if clear_bytecode:
        bytecode_cleared = 0
        for pycache in pycache_dirs:
            if pycache.exists():
                try:
                    shutil.rmtree(pycache)
                    bytecode_cleared += 1
                except Exception as e:
                    print(f"Failed to clear {pycache}: {e}")
        if bytecode_cleared > 0:
            print(f"Cleared bytecode: {bytecode_cleared} __pycache__ directories")
        else:
            print("bytecode: already empty")
    
    print("Cache cleared successfully")

def admin_cache_warm():
    """Pre-warm caches by creating tool venvs and downloading data"""
    from pathlib import Path
    import os
    
    print("=" * 60)
    print("REACHABLE CACHE WARM-UP")
    print("=" * 60)
    print()
    
    # Show CI/CD cache tip
    cache_dir = os.environ.get('REACHABLE_CACHE_DIR')
    if cache_dir:
        print(f"✅ REACHABLE_CACHE_DIR set: {cache_dir}")
    else:
        cache_dir = Path.home() / '.reachable-cache'
        print(f"💡 Tip: Set REACHABLE_CACHE_DIR for CI/CD caching")
        print(f"   export REACHABLE_CACHE_DIR=/path/to/ci-cache")
    print()
    
    # 1. GuardDog venv
    print("📦 1/3: GuardDog venv...")
    try:
        from reachable.guarddog_scanner import GuardDogScanner
        scanner = GuardDogScanner()
        if scanner.is_available():
            print("   ✅ GuardDog venv ready")
        else:
            print("   ❌ GuardDog setup failed")
    except Exception as e:
        print(f"   ⚠️  GuardDog check failed: {e}")
    
    # 2. Semgrep (uses system install, but check availability)
    print("📦 2/3: Semgrep...")
    try:
        import subprocess
        result = subprocess.run(['semgrep', '--version'], capture_output=True, timeout=5)
        if result.returncode == 0:
            version = result.stdout.decode().strip()
            print(f"   ✅ Semgrep available: {version}")
        else:
            print("   ⚠️  Semgrep not installed (pip install semgrep)")
    except FileNotFoundError:
        print("   ⚠️  Semgrep not installed (pip install semgrep)")
    except Exception as e:
        print(f"   ⚠️  Semgrep check failed: {e}")
    
    # 3. Grype/Syft (external tools)
    print("📦 3/3: Grype & Syft...")
    tools_ok = True
    for tool in ['grype', 'syft']:
        try:
            import subprocess
            result = subprocess.run([tool, 'version'], capture_output=True, timeout=5)
            if result.returncode == 0:
                print(f"   ✅ {tool} available")
            else:
                print(f"   ⚠️  {tool} not working properly")
                tools_ok = False
        except FileNotFoundError:
            print(f"   ❌ {tool} not installed")
            tools_ok = False
        except Exception as e:
            print(f"   ⚠️  {tool} check failed: {e}")
            tools_ok = False
    
    print()
    print("=" * 60)
    
    # CI/CD cache instructions
    cache_base = Path(cache_dir) if cache_dir else Path.home() / '.reachable-cache'
    print("📋 CI/CD Cache Configuration:")
    print()
    print("   GitHub Actions:")
    print("   ```yaml")
    print("   - uses: actions/cache@v3")
    print("     with:")
    print("       path: ~/.reachable-cache")
    print("       key: reachable-cache-${{ runner.os }}-v1")
    print("   ```")
    print()
    print("   GitLab CI:")
    print("   ```yaml")
    print("   cache:")
    print("     paths:")
    print("       - ~/.reachable-cache/")
    print("     key: reachable-${CI_COMMIT_REF_SLUG}")
    print("   ```")
    print()
    print(f"   Cache location: {cache_base}")
    print()
    if cache_base.exists():
        size = sum(f.stat().st_size for f in cache_base.rglob('*') if f.is_file())
        print(f"   Current size: {format_size(size)}")
    print("=" * 60)

def admin_test(args):
    """Run test suite"""
    import subprocess
    from pathlib import Path
    
    print("=" * 60)
    print("REACHABLE TEST SUITE")
    print("=" * 60)
    
    test_dir = Path(__file__).parent.parent / 'tests'
    if not test_dir.exists():
        test_dir = Path(__file__).parent / 'tests'
    
    if not test_dir.exists():
        print("Test directory not found")
        print("Tests are only available in the development distribution")
        sys.exit(1)
    
    cmd = ['python', '-m', 'pytest', str(test_dir)]
    
    if args.verbose:
        cmd.append('-v')
    if args.quick:
        cmd.extend(['-m', 'not slow and not network'])
    if args.coverage:
        cmd.extend(['--cov=reachable', '--cov-report=html', '--cov-report=term'])
    if args.filter:
        cmd.extend(['-k', args.filter])
    
    print(f"Command: {' '.join(cmd)}")
    print("-" * 60)
    
    try:
        result = subprocess.run(cmd, cwd=Path(__file__).parent.parent)
        sys.exit(result.returncode)
    except FileNotFoundError:
        print("pytest not installed. Install with: pip install pytest pytest-cov")
        sys.exit(1)

def admin_version():
    """Show detailed version information"""
    from pathlib import Path
    import platform
    
    print("=" * 60)
    print("REACHABLE VERSION INFO")
    print("=" * 60)
    print()
    print(f"REACHABLE Version:  {__version__}")
    print(f"Build Type:         {'Development' if _is_dev_build() else 'Customer Release'}")
    print()
    print("System:")
    print(f"  Python:           {platform.python_version()}")
    print(f"  Platform:         {platform.system()} {platform.release()}")
    print(f"  Architecture:     {platform.machine()}")
    
    import shutil
    print()
    print("External Tools:")
    for tool in ['syft', 'grype', 'semgrep', 'guarddog', 'trufflehog']:
        path = shutil.which(tool)
        status = path if path else "not found"
        print(f"  {tool:12} {status}")

def admin_db(args):
    """Manage scan databases and storage (v4.5.9)"""
    from pathlib import Path
    from .database_storage import RepoDatabase
    from .storage_cleanup import StorageCleanup, get_storage_stats, trim_storage
    
    reachable_home = Path.home() / '.reachable'
    scans_dir = reachable_home / 'scans'
    
    verbose = getattr(args, 'verbose', False)
    dry_run = getattr(args, 'dry_run', False)
    
    # Default to --status if no option specified
    if not any([getattr(args, 'status', False), getattr(args, 'trim', False), getattr(args, 'optimize', False)]):
        args.status = True
    
    if getattr(args, 'status', False):
        # Show database status
        print("=" * 60)
        print("REACHABLE DATABASE STATUS")
        print("=" * 60)
        print()
        
        if not scans_dir.exists():
            print("No scans directory found.")
            return
        
        total_size = 0
        total_scans = 0
        repos = []
        
        for repo_dir in sorted(scans_dir.iterdir()):
            if not repo_dir.is_dir():
                continue
            
            repo_db = repo_dir / 'repo.db'
            if not repo_db.exists():
                continue
            
            try:
                db_size = repo_db.stat().st_size
                total_size += db_size
                
                # Query scan count
                import sqlite3
                conn = sqlite3.connect(str(repo_db))
                cursor = conn.cursor()
                cursor.execute("SELECT COUNT(*) FROM scans WHERE status = 'complete'")
                scan_count = cursor.fetchone()[0]
                total_scans += scan_count
                
                # Get last scan time
                cursor.execute("SELECT MAX(timestamp) FROM scans")
                last_scan = cursor.fetchone()[0] or 'never'
                conn.close()
                
                repos.append({
                    'name': repo_dir.name.rsplit('-', 1)[0],
                    'scans': scan_count,
                    'size': db_size,
                    'last_scan': last_scan[:16] if last_scan != 'never' else last_scan,
                })
            except Exception as e:
                repos.append({'name': repo_dir.name, 'error': str(e)})
        
        # Print summary
        print(f"Total repositories: {len(repos)}")
        print(f"Total scans: {total_scans}")
        print(f"Total size: {total_size / (1024*1024):.1f} MB")
        
        if verbose and repos:
            print()
            print("Per-repository breakdown:")
            print("-" * 60)
            for repo in repos:
                if 'error' in repo:
                    print(f"  {repo['name']}: ERROR - {repo['error']}")
                else:
                    print(f"  {repo['name']}:")
                    print(f"    Scans: {repo['scans']}, Size: {repo['size']/1024:.1f} KB")
                    print(f"    Last scan: {repo['last_scan']}")
    
    elif getattr(args, 'trim', False):
        # Trim old scans - comprehensive cleanup (filesystem + database)
        # Uses storage_cleanup module for full cleanup
        result = trim_storage(
            reachable_home=reachable_home,
            retention_days=30,
            min_scans_keep=5,
            dry_run=dry_run,
            verbose=True
        )
    
    elif getattr(args, 'optimize', False):
        # Optimize databases
        print("=" * 60)
        print("REACHABLE DATABASE OPTIMIZE")
        print("=" * 60)
        print()
        
        if not scans_dir.exists():
            print("No scans directory found.")
            return
        
        for repo_dir in sorted(scans_dir.iterdir()):
            if not repo_dir.is_dir():
                continue
            
            repo_db = repo_dir / 'repo.db'
            if not repo_db.exists():
                continue
            
            try:
                size_before = repo_db.stat().st_size
                
                db = RepoDatabase(repo_db)
                db.optimize()
                db.close()
                
                size_after = repo_db.stat().st_size
                reclaimed = size_before - size_after
                
                repo_name = repo_dir.name.rsplit('-', 1)[0]
                if reclaimed > 0:
                    print(f"  {repo_name}: {reclaimed/1024:.1f} KB reclaimed")
                elif verbose:
                    print(f"  {repo_name}: already optimized")
            except Exception as e:
                print(f"  {repo_dir.name}: ERROR - {e}")
        
        print()
        print("Optimization complete.")

def admin_doctor(args=None):
    """Check system health and dependencies, auto-fix missing tools by default.
    
    Uses the centralized preflight_check() function.
    """
    from .preflight import preflight_check
    
    # Auto-fix by default (use --no-fix to just check)
    fix_mode = not getattr(args, 'no_fix', False) if args else True
    
    print("=" * 60)
    print("REACHABLE SYSTEM CHECK")
    print("=" * 60)
    print()
    
    # Run preflight check (handles everything)
    result = preflight_check(fix=fix_mode, quiet=False, verbose=True)
    
    print()
    if not result.ok:
        print(f"❌ {len(result.issues)} issue(s) found:")
        for issue in result.issues:
            print(f"  - {issue}")

        sys.exit(1)
    elif result.has_warnings:
        print("✅ All required tools present (with warnings)")
        print("   Warnings will auto-resolve on first scan.")
    else:
        print("✅ All checks passed - system ready")
    
    # Check for optional TruffleHog (active secret verification)
    trufflehog_installed = shutil.which('trufflehog') is not None
    print()
    print("OPTIONAL ENHANCEMENTS:")
    if trufflehog_installed:
        print("  ✅ trufflehog - Active secret verification available")
    else:
        print("  💡 trufflehog - For active secret verification (validates credentials against APIs)")
        print("     Install: brew install trufflehog  # or: pip install trufflehog")

def sandbox_command(args):
    """
    Manage dynamic malware sandbox.
    
    Platform-specific:
    - macOS: Colima (brew install/uninstall)
    - Linux: Firecracker (not yet implemented)
    """
    import platform
    
    system = platform.system().lower()
    
    print("=" * 60)
    print("REACHABLE DYNAMIC MALWARE SANDBOX")
    print("=" * 60)
    print()
    print(f"Platform: {platform.system()} ({platform.machine()})")
    print()
    
    # Default to --status if no option specified
    if getattr(args, 'init', False):
        _sandbox_init(system)
    elif getattr(args, 'remove', False):
        _sandbox_remove(system)
    else:
        # Default behavior: show status
        _sandbox_status(system)


def _sandbox_status(system: str):
    """Check sandbox installation status"""
    
    if system == 'darwin':
        print("Checking Colima status...")
        print()
        
        colima_status = _check_colima_status()
        
        if colima_status == 'not_installed':
            print("  Colima:        ❌ NOT INSTALLED")
            print("  Docker CLI:    " + _check_docker_cli_status())
            print()
            print("  Dynamic malware sandbox is NOT available.")
            print("  Run: reachctl sandbox --init")
            sys.exit(1)
        elif colima_status == 'stopped':
            print("  Colima:        ⚠️  INSTALLED but stopped")
            print("  Docker CLI:    " + _check_docker_cli_status())
            print()
            print("  Sandbox installed but not running.")
            print("  It will auto-start during scans, or run: colima start")
        else:
            print("  Colima:        ✅ RUNNING")
            print("  Docker CLI:    " + _check_docker_cli_status())
            
            # Check sandbox image
            image_status = _check_sandbox_image_status()
            print(f"  Sandbox Image: {image_status}")
            print()
            print("  Dynamic malware sandbox is READY.")
    
    elif system == 'linux':
        print("  Firecracker:   ⚠️  NOT YET IMPLEMENTED")
        print()
        print("  Linux sandbox (Firecracker) planned for v4.7.x")
        print("  Static malware analysis (GuardDog) is always available.")
    
    else:
        print(f"  Platform {system} not supported for dynamic sandbox.")
        print("  Static malware analysis (GuardDog) is always available.")
        sys.exit(1)


def _sandbox_init(system: str):
    """Install sandbox components"""
    
    if system == 'darwin':
        print("Installing Colima for macOS...")
        print()
        
        # Check if already installed
        colima_status = _check_colima_status()
        if colima_status != 'not_installed':
            print("  ✅ Colima is already installed")
            if colima_status == 'stopped':
                print("  🔄 Starting Colima...")
                if _start_colima():
                    print("  ✅ Colima started")
                else:
                    print("  ❌ Failed to start Colima")
                    sys.exit(1)
            if _ensure_sandbox_image():
                print()
                print("  Sandbox is ready!")
            else:
                print()
                print("  ⚠️  Sandbox image not ready - will build on first scan")
            return
        
        # Check for brew
        if not shutil.which('brew'):
            print("  ❌ Homebrew not found")
            print()
            print("  Please install Homebrew first:")
            print("    /bin/bash -c \"$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)\"")
            print()
            print("  Or install Colima manually:")
            print("    https://github.com/abiosoft/colima/releases")
            sys.exit(1)
        
        # Install colima and docker CLI via brew
        print("  📦 Installing colima and docker via Homebrew...")
        print("     (this may take a few minutes)")
        print()
        
        try:
            result = subprocess.run(
                ['brew', 'install', 'colima', 'docker'],
                timeout=600,  # 10 minute timeout
                capture_output=False  # Show output to user
            )
            if result.returncode != 0:
                print()
                print("  ❌ Installation failed")
                sys.exit(1)
        except subprocess.TimeoutExpired:
            print("  ❌ Installation timed out")
            sys.exit(1)
        except Exception as e:
            print(f"  ❌ Installation error: {e}")
            sys.exit(1)
        
        print()
        print("  ✅ Colima and Docker CLI installed")
        
        # Start Colima
        print("  🔄 Starting Colima VM...")
        print("     (first start downloads VM image, may take 2-3 minutes)")
        if _start_colima():
            print("  ✅ Colima started")
        else:
            print("  ❌ Failed to start Colima")
            print("  Try manually: colima start --cpu 2 --memory 4")
            sys.exit(1)
        
        # Build sandbox image
        _ensure_sandbox_image()
        
        print()
        print("=" * 60)
        print("✅ SANDBOX INSTALLATION COMPLETE")
        print("=" * 60)
        print()
        print("Dynamic malware detection is now enabled.")
        print("Run 'reachctl scan /path/to/repo' to use it.")
    
    elif system == 'linux':
        print("  ⚠️  Linux sandbox (Firecracker) not yet implemented")
        print()
        print("  Planned for v4.7.x")
        print("  Static malware analysis (GuardDog) is always available.")
        sys.exit(0)
    
    else:
        print(f"  ❌ Platform {system} not supported")
        sys.exit(1)


def _sandbox_remove(system: str):
    """Remove sandbox components"""
    
    if system == 'darwin':
        print("Removing Colima sandbox...")
        print()
        
        # Check if installed
        colima_status = _check_colima_status()
        if colima_status == 'not_installed':
            print("  ℹ️  Colima is not installed")
            return
        
        # Stop Colima if running
        if colima_status == 'running':
            print("  🔄 Stopping Colima...")
            try:
                subprocess.run(['colima', 'stop'], timeout=60, capture_output=True)
                print("  ✅ Colima stopped")
            except Exception as e:
                print(f"  ⚠️  Failed to stop Colima: {e}")
        
        # Delete Colima VM
        print("  🗑️  Deleting Colima VM...")
        try:
            subprocess.run(['colima', 'delete', '-f'], timeout=60, capture_output=True)
            print("  ✅ Colima VM deleted")
        except Exception as e:
            print(f"  ⚠️  Failed to delete VM: {e}")
        
        # Check for brew
        if not shutil.which('brew'):
            print()
            print("  ⚠️  Homebrew not found - cannot uninstall packages")
            print("  Colima VM deleted, but binaries remain.")
            print("  Remove manually if needed.")
            return
        
        # Uninstall via brew
        print("  📦 Uninstalling colima via Homebrew...")
        try:
            result = subprocess.run(
                ['brew', 'uninstall', 'colima'],
                timeout=120,
                capture_output=True,
                text=True
            )
            if result.returncode == 0:
                print("  ✅ Colima uninstalled")
            else:
                print(f"  ⚠️  Uninstall warning: {result.stderr[:100]}")
        except Exception as e:
            print(f"  ⚠️  Uninstall error: {e}")
        
        # Ask about docker CLI
        print()
        print("  ℹ️  Docker CLI was NOT removed (may be used by other tools)")
        print("  To remove: brew uninstall docker")
        
        print()
        print("=" * 60)
        print("✅ SANDBOX REMOVED")
        print("=" * 60)
        print()
        print("Dynamic malware detection is now disabled.")
        print("Static malware analysis (GuardDog) still works.")
    
    elif system == 'linux':
        print("  ℹ️  Linux sandbox (Firecracker) not yet implemented")
        print("  Nothing to remove.")
    
    else:
        print(f"  ℹ️  Platform {system} has no sandbox to remove")


def _check_docker_cli_status() -> str:
    """Check if docker CLI is installed"""
    if shutil.which('docker'):
        try:
            result = subprocess.run(
                ['docker', '--version'],
                capture_output=True, text=True, timeout=5
            )
            if result.returncode == 0:
                version = result.stdout.strip().split()[2].rstrip(',')
                return f"✅ installed (v{version})"
        except:
            pass
        return "✅ installed"
    return "❌ not installed"


def _check_sandbox_image_status() -> str:
    """Check if sandbox Docker image exists and is up-to-date"""
    import hashlib
    
    try:
        import docker
    except ImportError:
        return "❓ unknown (docker SDK not installed)"
    
    client = _get_docker_client()
    if not client:
        return "❓ unknown (Docker not connected)"
    
    # Compute current hash
    sandbox_dir = Path(__file__).parent.parent / "sandbox"
    dockerfile = sandbox_dir / "Dockerfile"
    if not dockerfile.exists():
        sandbox_dir = Path(__file__).parent / "sandbox"
        dockerfile = sandbox_dir / "Dockerfile"
    
    if dockerfile.exists():
        hasher = hashlib.sha256()
        hasher.update(dockerfile.read_bytes())
        runner_py = sandbox_dir / "runner.py"
        if runner_py.exists():
            hasher.update(runner_py.read_bytes())
        current_hash = hasher.hexdigest()[:12]
    else:
        current_hash = None
    
    # Check image
    try:
        image = client.images.get("reachable/sandbox:latest")
        cached_hash = image.labels.get('reachable.sandbox.hash', '')
        
        if current_hash and cached_hash == current_hash:
            return f"✅ ready (cached, hash: {cached_hash})"
        elif cached_hash:
            return f"⚠️  outdated (will rebuild on next scan)"
        else:
            return "✅ ready (no hash - legacy build)"
    except docker.errors.ImageNotFound:
        return "⚠️  not built (will build on first scan)"
    except Exception as e:
        return f"❓ unknown ({e})"


def store_scan_to_database(output_dir: Path, use_legacy_raw: bool = False, repo_path: Path = None,
                           risk_score: int = 0, risk_level: str = None) -> None:
    """
    Store scan findings to per-repo database (repo.db)
    
    Architecture:
        ~/.reachable/scans/{repo-hash}/repo.db  <- ONE db per repo
        
    Args:
        output_dir: Scan session directory (for reading JSON files)
        use_legacy_raw: If True, also create raw/ files for compatibility
        repo_path: Repository root path (required for repo.db location)
    """
    import json
    import gzip
    from pathlib import Path
    from .database_storage import RepoDatabase, get_repo_db_path
    
    raw_dir = output_dir / 'raw'
    created_items = []
    
    # Determine repo.db path
    if repo_path is None:
        # Fallback: try to get from scan-plan.json
        scan_plan_file = output_dir / 'scan-plan.json'
        if scan_plan_file.exists():
            with open(scan_plan_file) as f:
                plan = json.load(f)
                repo_path = Path(plan.get('repo_path', '/tmp/unknown'))
        else:
            repo_path = Path('/tmp/unknown')
    
    repo_db_path = get_repo_db_path(repo_path)
    db_exists = repo_db_path.exists()
    
  
    if use_legacy_raw and not raw_dir.exists():
        raw_dir.mkdir(exist_ok=True)
        created_items.append("✓ Created raw/ directory (legacy mode)")
    
    # Initialize RepoDatabase and start scan
    try:
        from . import __version__
        
        # Get branch and commit from scan-plan or git
        branch = 'unknown'
        commit_hash = None
        scan_plan_file = output_dir / 'scan-plan.json'
        if scan_plan_file.exists():
            with open(scan_plan_file) as f:
                plan = json.load(f)
                # Try to get branch from output_dir path structure
                # Path: ~/.reachable/scans/{repo-hash}/{branch}/{timestamp}/
                parts = output_dir.parts
                if len(parts) >= 2:
                    branch = parts[-2]  # Second to last is branch
        
        # Initialize repo database (creates schema if needed)
        db = RepoDatabase(repo_db_path)
        
        # Start a new scan record
        scan_id = db.start_scan(
            branch=branch,
            commit_hash=commit_hash,
            scan_dir=str(output_dir),
            version=__version__
        )
        
        # Collect findings from JSON files
        cve_findings = []
        secret_findings = []
        cwe_findings = []
        config_findings = []  # v4.5.18: Separate config findings
        
        # v4.5.18 BUG FIX: Import CVEs from reachable-report.json (has reachability data)
        # NOT from vulns.json (raw grype output without reachability)
        report_file = output_dir / 'reachable-report.json.gz'
        if not report_file.exists():
            report_file = output_dir / 'reachable-report.json'
        
        seen_cve_ids = set()  # Deduplicate CVEs
        
        if report_file.exists():
            try:
                if str(report_file).endswith('.gz'):
                    with gzip.open(report_file, 'rt') as f:
                        report_data = json.load(f)
                else:
                    with open(report_file) as f:
                        report_data = json.load(f)
                
                # Process REACHABLE CVEs
                for cve_id, cve_data in report_data.get('reachable', {}).items():
                    if cve_id in seen_cve_ids:
                        continue
                    seen_cve_ids.add(cve_id)
                    
                    # Check if reachability is actually unknown
                    if cve_data.get('reachability_unknown', False):
                        app_reach = 'UNKNOWN'
                    else:
                        app_reach = 'REACHABLE'
                    
                    cve_findings.append({
                        'id': cve_id,
                        'severity': cve_data.get('severity', 'MEDIUM'),
                        'title': cve_id,
                        'description': (cve_data.get('description', '') or '')[:500],
                        'package': cve_data.get('package', ''),
                        'version': cve_data.get('version', ''),
                        'app_reachability': app_reach,
                        'cvss_score': cve_data.get('cvss_score', 0.0) or 0.0,
                        'fix_status': 'fix_available' if cve_data.get('is_fixable') else 'no_fix',
                        'fix_version': ','.join(cve_data.get('fix_versions', [])) or None,
                        'scanner': 'grype'
                    })
                
                # Process UNREACHABLE CVEs
                for cve_id, cve_data in report_data.get('unreachable', {}).items():
                    if cve_id in seen_cve_ids:
                        continue
                    seen_cve_ids.add(cve_id)
                    
                    # Check if reachability is actually unknown
                    if cve_data.get('reachability_unknown', False):
                        app_reach = 'UNKNOWN'
                    else:
                        app_reach = 'NOT_REACHABLE'
                    
                    cve_findings.append({
                        'id': cve_id,
                        'severity': cve_data.get('severity', 'MEDIUM'),
                        'title': cve_id,
                        'description': (cve_data.get('description', '') or '')[:500],
                        'package': cve_data.get('package', ''),
                        'version': cve_data.get('version', ''),
                        'app_reachability': app_reach,
                        'cvss_score': cve_data.get('cvss_score', 0.0) or 0.0,
                        'fix_status': 'fix_available' if cve_data.get('is_fixable') else 'no_fix',
                        'fix_version': ','.join(cve_data.get('fix_versions', [])) or None,
                        'scanner': 'grype'
                    })
                    
            except Exception as e:
                created_items.append(f"⚠️  Error loading report: {e}")
        
        # Fallback to vulns.json if report doesn't exist (shouldn't happen normally)
        if not cve_findings:
            vulns_file = output_dir / 'vulns.json'
            if vulns_file.exists():
                with open(vulns_file) as f:
                    vulns_data = json.load(f)
                    
                for match in vulns_data.get('matches', []):
                    vuln = match.get('vulnerability', {})
                    artifact = match.get('artifact', {})
                    cve_id = vuln.get('id', '')
                    if cve_id in seen_cve_ids:
                        continue
                    seen_cve_ids.add(cve_id)
                    
                    cve_findings.append({
                        'id': cve_id,
                        'severity': vuln.get('severity', 'MEDIUM'),
                        'title': cve_id,
                        'description': (vuln.get('description', '') or '')[:500],
                        'package': artifact.get('name', ''),
                        'version': artifact.get('version', ''),
                        'app_reachability': 'UNKNOWN',  # No reachability data in fallback
                        'cvss_score': vuln.get('cvss', [{}])[0].get('metrics', {}).get('baseScore', 0.0) if vuln.get('cvss') else 0.0,
                        'fix_status': 'fix_available' if vuln.get('fix', {}).get('versions') else 'no_fix',
                        'fix_version': ','.join(vuln.get('fix', {}).get('versions', [])) or None,
                        'scanner': 'grype'
                    })
        
        # Store CVE findings
        if cve_findings:
            db.store_findings(cve_findings, 'cve')
        
        # Import security findings (secrets, CWEs, config)
        # v4.5.18 BUG FIX: Read from reachable-report.json (analyzed data)
        # and properly classify findings by type with correct reachability
        
        # Helper to determine if file is config (not code)
        CONFIG_EXTENSIONS = ('.yaml', '.yml', '.json', '.tf', '.hcl', '.toml', '.ini', '.cfg', '.conf')
        CONFIG_PATTERNS = ('dockerfile', 'docker-compose', '.github/')
        CODE_EXTENSIONS = ('.go', '.py', '.js', '.ts', '.java', '.rb', '.rs', '.c', '.cpp', '.cs', '.php', '.swift', '.kt')
        
        def is_config_file(filepath: str) -> bool:
            """Check if file is a config file (not code)"""
            if not filepath:
                return False
            filepath_lower = filepath.lower()
            # Code files are never config, even in config directories
            if any(filepath_lower.endswith(ext) for ext in CODE_EXTENSIONS):
                return False
            # Check config extension
            if any(filepath_lower.endswith(ext) for ext in CONFIG_EXTENSIONS):
                return True
            # Check config patterns (Dockerfile, etc.)
            if any(pattern in filepath_lower for pattern in CONFIG_PATTERNS):
                return True
            return False
        
        # Config rule patterns from cwe_reachability.py
        CONFIG_RULE_PATTERNS = [
            'dockerfile.', 'docker-compose.', 'kubernetes.', 'k8s.',
            'terraform.', 'cloudformation.', 'helm.', 'yaml.',
            'cicd.', 'github-actions.', 'gitlab-ci.', 'jenkins.',
            'security-headers', 'cors.', 'ssl.', 'tls.',
        ]
        
        def determine_reachability(finding: dict, is_config: bool, finding_type: str = 'cwe') -> str:
            """Determine app_reachability for a finding
            
            Rules (from cwe_reachability.py and ARCHITECTURE.md):
            - CONFIG files: Always UNKNOWN (except secrets with confirmed loaders)
            - CONFIG rule patterns: Always UNKNOWN  
            - CWE: Use is_reachable boolean (NOT reachable_via)
            - Secrets: Use reachability field + reachability_confidence
            """
            # For secrets: check loader confirmation FIRST (overrides config file check)
            if finding_type == 'secret':
                confidence = finding.get('reachability_confidence', '').upper()
                reachable_via = finding.get('reachable_via', [])
                if confidence == 'CONFIRMED' and reachable_via and len(reachable_via) > 0:
                    return 'REACHABLE'  # Loader confirmed, even in config file
                
                # Check explicit reachability field
                reach = finding.get('reachability', '').lower()
                if reach == 'reachable':
                    return 'REACHABLE'
                elif reach in ('not_reachable', 'unreachable'):
                    return 'NOT_REACHABLE'
                
                # UNKNOWN_EXPLOITABLE or no confidence = UNKNOWN
                return 'UNKNOWN'
            
            # For CWE/config: config files are UNKNOWN
            if is_config:
                return 'UNKNOWN'
            
            # Check if rule_id indicates config issue
            rule_id = finding.get('rule_id', '').lower()
            if any(pattern in rule_id for pattern in CONFIG_RULE_PATTERNS):
                return 'UNKNOWN'
            
            # For CWE: use is_reachable boolean directly
            if finding_type == 'cwe':
                is_reach = finding.get('is_reachable')
                if is_reach is True:
                    return 'REACHABLE'
                elif is_reach is False:
                    return 'NOT_REACHABLE'
                return 'UNKNOWN'
            
            return 'UNKNOWN'
        
        # Process findings from report if available
        if report_file.exists():
            try:
                df = report_data.get('detailed_findings', {})
                
                # Process CWE findings (from detailed_findings.cwe.findings)
                cwe_data = df.get('cwe', {})
                cwe_findings_list = cwe_data.get('findings', []) if isinstance(cwe_data, dict) else []
                
                for finding in cwe_findings_list:
                    filepath = finding.get('file', '')
                    is_config = is_config_file(filepath)
                    app_reach = determine_reachability(finding, is_config, 'cwe')
                    
                    finding_dict = {
                        'id': finding.get('finding_id', f"{finding.get('rule_id', '')}_{filepath}_{finding.get('line', 0)}"),
                        'severity': finding.get('severity', 'MEDIUM'),
                        'title': finding.get('message', 'CWE Finding')[:200],
                        'description': finding.get('message', ''),
                        'file': filepath,
                        'line': finding.get('line'),
                        'app_reachability': app_reach,
                        'cwe_id': finding.get('cwe_id') or finding.get('policy_id', '').replace('CWE-', ''),
                        'scanner': 'semgrep'
                    }
                    
                    if is_config:
                        config_findings.append(finding_dict)
                    else:
                        cwe_findings.append(finding_dict)
                
                # Process SECRET findings (from detailed_findings.secrets.findings)
                secrets_data = df.get('secrets', {})
                secrets_findings_list = secrets_data.get('findings', []) if isinstance(secrets_data, dict) else []
                
                for finding in secrets_findings_list:
                    # Only process actual secrets, not CWE/config issues
                    if not finding.get('is_actual_secret'):
                        continue  # Skip - already processed in CWE loop
                    
                    filepath = finding.get('file', '')
                    is_config = is_config_file(filepath)
                    app_reach = determine_reachability(finding, is_config, 'secret')
                    
                    finding_dict = {
                        'id': finding.get('finding_id') or finding.get('type') or f"secret_{filepath}_{finding.get('line', 0)}",
                        'severity': finding.get('severity', 'HIGH'),
                        'title': finding.get('message', 'Secret Finding')[:200],
                        'description': finding.get('message', ''),
                        'file': filepath,
                        'line': finding.get('line'),
                        'app_reachability': app_reach,
                        'secret_type': finding.get('type', 'unknown'),
                        'scanner': finding.get('scanner', 'semgrep')
                    }
                    secret_findings.append(finding_dict)
                    
            except Exception as e:
                created_items.append(f"⚠️  Error processing detailed findings: {e}")
        
        # Fallback to security_findings.json if report doesn't have detailed_findings
        
        # Store secret and CWE findings
        if secret_findings:
            db.store_findings(secret_findings, 'secret')
        if cwe_findings:
            db.store_findings(cwe_findings, 'cwe')
        if config_findings:
            db.store_findings(config_findings, 'config')
        
        # Complete the scan with risk data
        db.complete_scan(duration_seconds=0, risk_score=risk_score, risk_level=risk_level)
        
        # Auto-trim old scans (30 days / 20 per branch)
        trim_result = db.cleanup_old_scans()
        if trim_result.get('scans_deleted', 0) > 0:
            created_items.append(f"✓ Trimmed {trim_result['scans_deleted']} old scans")
        
        db.close()
        
        db_size_kb = repo_db_path.stat().st_size / 1024
        if not db_exists:
            created_items.append(f"✓ Created repo.db ({db_size_kb:.1f}KB)")
        else:
            created_items.append(f"✓ Updated repo.db ({db_size_kb:.1f}KB, scan #{scan_id})")
        
        # Also create symlink for backward compatibility
        legacy_db = output_dir / 'scan.db'
        if not legacy_db.exists():
            try:
                legacy_db.symlink_to(repo_db_path)
            except:
                pass  # Symlink not critical
            
    except Exception as e:
        created_items.append(f"✗ Database error: {str(e)}")
    
  
    if use_legacy_raw:
        # Legacy file creation (for compatibility)
        # ... existing legacy code ...
        created_items.append("✓ Created legacy raw/ files (compatibility mode)")
    
    # Print results
    if created_items:
        print("\n📦 Database Features:")
        for item in created_items:
            print(f"   {item}")
        
        if not use_legacy_raw:
            print("   💡 raw/ directory eliminated - all scans stored in repo.db")
            print("   💡 Use --legacy-raw to create raw files for compatibility")

def main():
    """Main CLI entry point"""
    
    # Check if venv is activated (warn if not)
    _check_venv_activation()
    
    parser = argparse.ArgumentParser(
        prog='reachctl',
        description='REACHABLE - Security vulnerability analysis with reachability intelligence',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  reachctl scan /path/to/repo    Analyze repository
  reachctl selftest              Verify installation
  reachctl doctor                Check dependencies

After scanning, open the dashboard:
  file://~/.reachable/scans/<repo>/latest/dashboard/index.html

© 2026 Sthenos Security. All rights reserved.
Support: adazzi@sthenosec.com
        """
    )
    
    parser.add_argument('--version', '-V', action='store_true',
                       help='Show version and exit')
    
    subparsers = parser.add_subparsers(dest='command', metavar='COMMAND')
    
    # ==========================================================================
    # scan - Main command
    # ==========================================================================
    scan_parser = subparsers.add_parser(
        'scan', 
        help='Analyze repository for vulnerabilities, secrets, and malware',
        description='Run complete security analysis on a repository'
    )
    scan_parser.add_argument('repo', metavar='PATH',
                            help='Path to repository to scan')
    
    # Options
    scan_parser.add_argument('--output', '-o', metavar='DIR',
                            help='Output directory (default: ~/.reachable/scans/<repo>)')
    scan_parser.add_argument('--fail-on', choices=['critical', 'high', 'medium', 'any', 'none'],
                            default='none',
                            help='Exit non-zero if findings meet threshold (default: none)')
    scan_parser.add_argument('--quiet', '-q', action='store_true',
                            help='Minimal output (CI-friendly)')
    scan_parser.add_argument('--debug', '-d', action='store_true',
                            help='Verbose output for debugging')
    scan_parser.add_argument('--enable-ai', action='store_true',
                            help='Enable AI security analysis (OWASP LLM Top 10, MCP security)')
    scan_parser.add_argument('--ai-only', action='store_true',
                            help='Run only AI security analysis (skip CVE/secrets/config)')
    
    # ==========================================================================
    # dashboard - Generate or access scan dashboard
    # ==========================================================================
    dashboard_parser = subparsers.add_parser(
        'dashboard', 
        help='Generate or access scan dashboard',
        description='Generate dashboard from scan results or get path for CI/CD artifacts'
    )
    dashboard_parser.add_argument('--repo', '-r', metavar='NAME',
                                 help='Repository name (fuzzy match) or path')
    dashboard_parser.add_argument('--generate', '-g', action='store_true',
                                 help='Regenerate dashboard from scan results')
    dashboard_parser.add_argument('--output', '-o', metavar='DIR',
                                 help='Output directory for generated dashboard')
    dashboard_parser.add_argument('--path', '-p', action='store_true',
                                 help='Print dashboard path only (for CI/CD artifacts)')
    dashboard_parser.add_argument('--open', action='store_true',
                                 help='Open dashboard in browser')
    dashboard_parser.add_argument('--list', '-l', action='store_true',
                                 help='List all available dashboards')
    
    # ==========================================================================
    # selftest - Verify installation
    # ==========================================================================
    selftest_parser = subparsers.add_parser(
        'selftest', 
        help='Verify installation and run validation tests',
        description='Check that REACHABLE is properly installed and configured'
    )
    selftest_parser.add_argument('--integration', '-i', action='store_true',
                                  help='Run integration tests against reach-testbed')
    selftest_parser.add_argument('--coverage', '-c', action='store_true',
                                  help='Run with coverage report')
    selftest_parser.add_argument('--quiet', '-q', action='store_true',
                                  help='Minimal output')
    
    # ==========================================================================
    # doctor - System health check
    # ==========================================================================
    doctor_parser = subparsers.add_parser(
        'doctor', 
        help='Check system dependencies and configuration',
        description='Verify all required and optional tools are available'
    )
    doctor_parser.add_argument('--no-fix', action='store_true',
                              help='Check only, do not auto-install missing tools')
    
    # ==========================================================================
    # cache - Cache management
    # ==========================================================================
    cache_parser = subparsers.add_parser(
        'cache', 
        help='Manage local caches',
        description='View, clear, or warm up REACHABLE caches'
    )
    cache_group = cache_parser.add_mutually_exclusive_group(required=True)
    cache_group.add_argument('--status', action='store_true',
                            help='Show cache usage and sizes')
    cache_group.add_argument('--clear', action='store_true',
                            help='Clear all caches')
    cache_group.add_argument('--clear-libs', action='store_true',
                            help='Clear library cache only')
    cache_group.add_argument('--warm', action='store_true',
                            help='Pre-warm caches for faster scans')
    cache_parser.add_argument('--force', '-f', action='store_true',
                             help='Skip confirmation prompts')
    
    # ==========================================================================
    # db - Database management (v4.5.8)
    # ==========================================================================
    db_parser = subparsers.add_parser(
        'db', 
        help='Manage scan databases',
        description='View status, trim old scans, or optimize databases'
    )
    db_parser.add_argument('--repo', '-r', metavar='NAME',
                          help='Repository name (fuzzy match) - default: all repos')
    db_group = db_parser.add_mutually_exclusive_group(required=False)  # Default to --status
    db_group.add_argument('--status', action='store_true',
                         help='Show database status and sizes (default)')
    db_group.add_argument('--trim', action='store_true',
                         help='Trim old scans (30 days / 20 per branch)')
    db_group.add_argument('--optimize', action='store_true',
                         help='Optimize databases (VACUUM)')
    db_parser.add_argument('--dry-run', action='store_true',
                          help='Show what would be deleted without deleting')
    db_parser.add_argument('--verbose', '-v', action='store_true',
                          help='Show detailed information')
    
    # ==========================================================================
    # primer - Quick-start guide
    # ==========================================================================
    primer_parser = subparsers.add_parser(
        'primer', 
        help='Quick-start guide and playbook',
        description='Built-in playbook with overview, install/config tips, debugging, and examples'
    )
    
    # ==========================================================================
    # sandbox - Dynamic malware sandbox management
    # ==========================================================================
    sandbox_parser = subparsers.add_parser(
        'sandbox', 
        help='Manage dynamic malware sandbox',
        description='Install, remove, or check status of the dynamic malware sandbox (Colima on macOS)'
    )
    sandbox_group = sandbox_parser.add_mutually_exclusive_group(required=False)  # Default to --status
    sandbox_group.add_argument('--init', action='store_true',
                              help='Install sandbox (Colima on macOS)')
    sandbox_group.add_argument('--remove', action='store_true',
                              help='Remove sandbox')
    sandbox_group.add_argument('--status', action='store_true',
                              help='Check sandbox status (default)')
    
    # ==========================================================================
    # vulndb - Vulnerability database management
    # ==========================================================================
    vulndb_parser = subparsers.add_parser(
        'vulndb', 
        help='Manage grype vulnerability database',
        description='View status, update, or clear the grype CVE database cache'
    )
    vulndb_group = vulndb_parser.add_mutually_exclusive_group(required=False)  # Default to --status
    vulndb_group.add_argument('--status', action='store_true',
                             help='Show vulnerability DB status (default)')
    vulndb_group.add_argument('--update', action='store_true',
                             help='Force refresh the vulnerability database')
    vulndb_group.add_argument('--reset', action='store_true',
                             help='Delete and rebuild the database from scratch')
    
    # ==========================================================================
    # pipeline - Distributed CI/CD execution
    # ==========================================================================
    from .pipeline_cli import setup_pipeline_parser
    setup_pipeline_parser(subparsers)
    
    # ==========================================================================
    # system - System info, storage management, cleanup
    # ==========================================================================
    system_parser = subparsers.add_parser(
        'system',
        help='System information and storage management',
        description='View storage usage, manage caches, and prune old data'
    )
    system_parser.add_argument('action', nargs='?', default='info',
                               choices=['info', 'df', 'prune'],
                               help='info: show system info (default), df: disk usage breakdown, prune: clean up old data')
    system_parser.add_argument('--verbose', '-v', action='store_true',
                               help='Show detailed information')
    system_parser.add_argument('--json', action='store_true',
                               help='Output in JSON format')
    system_parser.add_argument('--dry-run', action='store_true',
                               help='Show what would be deleted without actually deleting')
    system_parser.add_argument('--max-age', type=int, default=21,
                               help='Delete scans older than N days (default: 21)')
    system_parser.add_argument('--max-scans', type=int, default=20,
                               help='Keep only N scans per branch (default: 20)')
    
    # ==========================================================================
    # version - Show version
    # ==========================================================================
    version_parser = subparsers.add_parser(
        'version', 
        help='Show version and tool information'
    )
    version_parser.add_argument('--wheel', '-w', action='store_true',
                               help='Show wheel package verification info')
    
    # Parse arguments
    args = parser.parse_args()
    
    # Handle --version flag at top level
    if getattr(args, 'version', False) and args.command is None:
        print_version()
        sys.exit(0)
    
    # No command specified
    if not args.command:
        parser.print_help()
        sys.exit(1)
    
    # Check license before running any command (except version/help)
    # This enforces the 30-day evaluation period
    try:
        from .license import check_license_or_exit
        quiet = getattr(args, 'quiet', False)
        check_license_or_exit(quiet=quiet)
    except ImportError:
        pass  # License module not available, continue
    
    # Route to command handlers
    if args.command == 'scan':
        scan_repo(args)
    elif args.command == 'dashboard':
        open_dashboard(args)
    elif args.command == 'selftest':
        selftest(args)
    elif args.command == 'doctor':
        admin_doctor(args)
    elif args.command == 'cache':
        # Map to existing admin_cache function
        admin_cache(args)
    elif args.command == 'db':
        admin_db(args)
    elif args.command == 'sandbox':
        sandbox_command(args)
    elif args.command == 'vulndb':
        vulndb_command(args)
    elif args.command == 'system':
        system_command(args)
    elif args.command == 'pipeline':
        from .pipeline_cli import pipeline_command
        sys.exit(pipeline_command(args))
    elif args.command == 'primer':
        show_primer(args)
    elif args.command == 'version':
        print_version(args)
    else:
        parser.print_help()
        sys.exit(1)


def system_command(args):
    """
    System information and storage management.
    
    Actions:
        info  - Show system overview (storage, sandboxes, DB status)
        df    - Detailed disk usage breakdown
        prune - Clean up old scans and compress older dashboards
    """
    from .storage_utils import (
        print_system_info, 
        get_system_info, 
        get_storage_breakdown,
        prune_storage,
        format_size
    )
    
    action = getattr(args, 'action', 'info')
    verbose = getattr(args, 'verbose', False)
    json_output = getattr(args, 'json', False)
    
    if action == 'info':
        print_system_info(verbose=verbose, json_output=json_output)
    
    elif action == 'df':
        # Detailed disk usage
        storage = get_storage_breakdown()
        
        if json_output:
            import json
            print(json.dumps(storage, indent=2, default=str))
            return
        
        print("=" * 70)
        print("REACHABLE DISK USAGE")
        print("=" * 70)
        
        if not storage['exists']:
            print("\n~/.reachable does not exist yet")
            return
        
        print(f"\nTotal: {storage['total_human']}")
        print(f"Path:  {storage['path']}")
        
        # Components
        if storage.get('components'):
            print("\n" + "-" * 50)
            print("COMPONENTS")
            print("-" * 50)
            for name, data in sorted(storage['components'].items(), key=lambda x: x[1]['size'], reverse=True):
                pct = (data['size'] / storage['total'] * 100) if storage['total'] > 0 else 0
                print(f"  {name:15} {data['size_human']:>12}  ({pct:5.1f}%)  {data['file_count']:>6,} files")
        
        # Cache breakdown
        if storage.get('cache_breakdown'):
            print("\n" + "-" * 50)
            print("CACHE BREAKDOWN")
            print("-" * 50)
            for name, data in sorted(storage['cache_breakdown'].items(), key=lambda x: x[1]['size'], reverse=True):
                print(f"  {name:25} {data['size_human']:>12}")
        
        # Top repositories
        if storage.get('top_repos'):
            print("\n" + "-" * 50)
            print("TOP REPOSITORIES (by size)")
            print("-" * 50)
            for repo in storage['top_repos']:
                print(f"  {repo['name'][:40]:40} {repo['size_human']:>10}")
                print(f"    {repo['scan_count']} scans, {repo['branch_count']} branches, DB: {repo['db_size_human']}")
                if repo.get('newest_scan'):
                    print(f"    Last scan: {repo['newest_scan'][:19]}")
        
        # Top files
        if storage.get('top_files') and verbose:
            print("\n" + "-" * 50)
            print("TOP FILES (by size)")
            print("-" * 50)
            for f in storage['top_files']:
                print(f"  {f['size_human']:>12}  {f['path']}")
        
        print()
    
    elif action == 'prune':
        # Clean up old data
        dry_run = getattr(args, 'dry_run', False)
        max_age = getattr(args, 'max_age', 21)
        max_scans = getattr(args, 'max_scans', 20)
        
        print("=" * 70)
        print("REACHABLE STORAGE PRUNE")
        print("=" * 70)
        
        if dry_run:
            print("\n⚠️  DRY RUN - No changes will be made\n")
        
        print(f"Settings:")
        print(f"  Max scan age:        {max_age} days")
        print(f"  Max scans per branch: {max_scans}")
        print(f"  Compress after:      14 days")
        print()
        
        result = prune_storage(
            max_age_days=max_age,
            max_scans_per_branch=max_scans,
            compress_after_days=14,
            dry_run=dry_run,
            verbose=verbose
        )
        
        print("\n" + "-" * 50)
        print("RESULTS")
        print("-" * 50)
        print(f"  Scans deleted:         {result['scans_deleted']}")
        print(f"  Directories deleted:   {result['dirs_deleted']}")
        print(f"  Directories compressed: {result['dirs_compressed']}")
        print(f"  Space freed:           {result['bytes_freed_human']}")
        
        if result.get('errors'):
            print("\n⚠️  Errors:")
            for err in result['errors']:
                print(f"  • {err}")
        
        if dry_run:
            print("\n💡 Run without --dry-run to apply changes")
        else:
            print("\n✅ Cleanup complete")
        
        print()


def vulndb_command(args):
    """
    Manage grype vulnerability database.
    
    The vulnerability DB is cached locally at ~/.reachable/cache/grype-db/
    and auto-refreshed if older than 24 hours during scans.
    """
    from .vulndb import VulnDBManager
    
    print("=" * 60)
    print("REACHABLE VULNERABILITY DATABASE")
    print("=" * 60)
    print()
    
    mgr = VulnDBManager()
    
    if getattr(args, 'update', False):
        # Force update
        print("Updating vulnerability database...")
        print()
        if mgr.update(force=True, verbose=True):
            print()
            print("✅ Vulnerability database updated successfully.")
        else:
            print()
            print("❌ Failed to update vulnerability database.")
            sys.exit(1)
    
    elif getattr(args, 'reset', False):
        # Clear and rebuild
        print("Resetting vulnerability database...")
        print()
        if mgr.clear(verbose=True):
            print()
            print("Downloading fresh database...")
            if mgr.update(force=True, verbose=True):
                print()
                print("✅ Vulnerability database reset successfully.")
            else:
                print()
                print("❌ Failed to download new database.")
                sys.exit(1)
        else:
            print()
            print("❌ Failed to clear database.")
            sys.exit(1)
    
    else:
        # Default: show status
        status = mgr.get_status()
        
        print(f"Location:    {status['location']}")
        print()
        
        if status['exists']:
            print(f"  Status:      ✅ Available")
            print(f"  Size:        {status['size_mb']:.1f} MB")
            
            if status['age_hours'] is not None:
                age_hours = status['age_hours']
                if age_hours < 1:
                    age_str = f"{int(age_hours * 60)} minutes"
                elif age_hours < 24:
                    age_str = f"{age_hours:.1f} hours"
                else:
                    age_str = f"{age_hours / 24:.1f} days"
                print(f"  Age:         {age_str}")
                print(f"  Last Update: {status['last_update']}")
                
                if status['is_stale']:
                    print()
                    print(f"  ⚠️  Database is stale (> {status['max_age_hours']}h old)")
                    print(f"      Will auto-refresh on next scan, or run:")
                    print(f"      reachctl vulndb --update")
                else:
                    print()
                    print(f"  ✅ Database is fresh (auto-refresh at {status['max_age_hours']}h)")
            else:
                print(f"  Age:         Unknown (no timestamp)")
        else:
            print(f"  Status:      ❌ Not initialized")
            print()
            print("  The database will be downloaded automatically on first scan.")
            print("  Or run: reachctl vulndb --update")
        
        print()
        print("Commands:")
        print("  reachctl vulndb --status   Show this status")
        print("  reachctl vulndb --update   Force refresh now")
        print("  reachctl vulndb --reset    Delete and rebuild from scratch")

def print_version(args=None):
    """Print version information with tool locations"""
    from . import __version__, __git_info__, __build_date__
    import platform
    import re
    
    # Version line
    print(f"REACHABLE {__version__}")
    print()
    
    # Python info
    print(f"Python:   {platform.python_version()}")
    print(f"Platform: {platform.system().lower()}")
    print()
    
    # Base tools - check ONLY our managed locations (not system PATH)
    print("Base Tools:")
    
    # Define tool locations
    reachable_home = Path.home() / '.reachable'
    venv_bin = reachable_home / 'venv' / 'bin'           # Python tools (semgrep)
    tools_bin = reachable_home / 'tools' / 'bin'         # Local syft/grype binaries
    guarddog_venv_bin = reachable_home / 'guarddog-venv' / 'bin'  # Isolated guarddog
    
    def get_version(tool_path: Path, tool_name: str) -> str:
        """Get version from tool, return None if not found."""
        if not tool_path.exists():
            return None
        try:
            # Use --version for most tools, 'version' for syft/grype
            version_arg = 'version' if tool_name in ('syft', 'grype') else '--version'
            result = subprocess.run(
                [str(tool_path), version_arg],
                capture_output=True, text=True, timeout=10
            )
            if result.returncode == 0:
                output = result.stdout.strip() or result.stderr.strip()
                # Extract version number (X.Y.Z pattern)
                match = re.search(r'(\d+\.\d+\.?\d*)', output)
                if match:
                    return match.group(1)
                return 'installed'
        except Exception:
            pass
        return None
    
    # Syft & Grype in tools/bin/
    for tool in ['syft', 'grype']:
        tool_path = tools_bin / tool
        version = get_version(tool_path, tool)
        if version:
            print(f"  {tool}: {version} (tools)")
        else:
            print(f"  {tool}: not found")
    
    # Semgrep in venv/bin/
    semgrep_path = venv_bin / 'semgrep'
    version = get_version(semgrep_path, 'semgrep')
    if version:
        print(f"  semgrep: {version} (venv)")
    else:
        print(f"  semgrep: not found")
    
    # GuardDog in isolated venv
    guarddog_path = guarddog_venv_bin / 'guarddog'
    version = get_version(guarddog_path, 'guarddog')
    if version:
        print(f"  guarddog: {version} (isolated-venv)")
    else:
        print(f"  guarddog: not found")
    
    print()
    
    # Commit info
    git = __git_info__
    if git.get("sha"):
        commit_line = f"Commit: {git['sha']}"
        if git.get("date"):
            commit_line += f" ({git['date']})"
        if git.get("branch"):
            commit_line += f" [{git['branch']}]"
        print(commit_line)
    
    # Build date (only for wheel installs from CI/CD)
    if __build_date__:
        print(f"Build: {__build_date__}")
    
    print()
    print(f"© 2026 Sthenos Security. All rights reserved.")

if __name__ == '__main__':
    main()
