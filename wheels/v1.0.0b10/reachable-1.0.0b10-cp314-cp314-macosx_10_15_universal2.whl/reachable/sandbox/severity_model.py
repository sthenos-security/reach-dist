# Copyright © 2026 Sthenos Security. All rights reserved.

"""
REACHABLE Sandbox Severity Model v4.5.18

Refined severity definitions for dynamic malware sandbox analysis.
Key insight: The "sensitive read + outbound chain" distinguishes MEDIUM from HIGH.

Architecture Note (JSON-First):
==============================
This module is part of the analysis engine that produces reachable-report.json.
The report is the single source of truth for each scan. repo.db stores historical
data for trends/queries but dashboard reads from report, not DB.

Flow:
    Scanners → Raw JSON → Analysis Engine → reachable-report.json → repo.db
                                                    ↓
                                              Dashboard (data.json)
"""

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional, Set


class Severity(Enum):
    """
    Sandbox finding severity levels.
    
    The key differentiator between MEDIUM and HIGH is the 
    "sensitive read + outbound chain" - did we see BOTH:
      1. Access to sensitive data (creds, tokens, env vars)
      2. Attempt to send data outbound
    
    If both are present → HIGH or CRITICAL
    If only one → MEDIUM (suspicious but ambiguous)
    """
    INFO = "INFO"
    LOW = "LOW"
    MEDIUM = "MEDIUM"
    HIGH = "HIGH"
    CRITICAL = "CRITICAL"


# =============================================================================
# KNOWN BAD INDICATORS (for threat intel matching)
# =============================================================================

# Known malicious domains (simplified - in production, use threat intel feed)
KNOWN_BAD_DOMAINS = {
    # Typosquatting C2 domains
    "pypi-stats.com",
    "npm-stats.org", 
    "githubusercontent.com.evil.com",
    # Known malware C2
    "pastebin.com",  # Often used for payload hosting
    "requestbin.net",
    "webhook.site",
    "pipedream.net",
    # Crypto mining pools
    "pool.minergate.com",
    "xmr.pool.mining",
}

# Known malicious IPs (simplified - in production, use threat intel feed)
KNOWN_BAD_IPS = {
    "45.33.32.156",  # Example - scanme.nmap.org used in tests
}

# Sensitive environment variables that indicate credential access
SENSITIVE_ENV_VARS = {
    # Cloud credentials
    "AWS_ACCESS_KEY_ID", "AWS_SECRET_ACCESS_KEY", "AWS_SESSION_TOKEN",
    "AZURE_CLIENT_SECRET", "AZURE_TENANT_ID",
    "GOOGLE_APPLICATION_CREDENTIALS", "GCP_SERVICE_ACCOUNT",
    # CI/CD tokens
    "GITHUB_TOKEN", "GH_TOKEN", "GITLAB_TOKEN", "BITBUCKET_TOKEN",
    "CI_JOB_TOKEN", "CIRCLE_TOKEN", "TRAVIS_TOKEN",
    # Package registry tokens
    "NPM_TOKEN", "NPM_AUTH_TOKEN", "PYPI_TOKEN", "PYPI_API_TOKEN",
    # Database credentials
    "DATABASE_URL", "DB_PASSWORD", "MYSQL_PASSWORD", "POSTGRES_PASSWORD",
    # Generic secrets
    "SECRET_KEY", "API_KEY", "PRIVATE_KEY", "AUTH_TOKEN",
}

# Sensitive file paths that indicate credential harvesting
SENSITIVE_FILE_PATHS = {
    # SSH keys
    "/.ssh/id_rsa", "/.ssh/id_ed25519", "/.ssh/id_ecdsa",
    "/.ssh/config", "/.ssh/known_hosts",
    # Cloud credentials
    "/.aws/credentials", "/.aws/config",
    "/.azure/credentials",
    "/.config/gcloud/credentials.db",
    # Package manager credentials  
    "/.npmrc", "/.pypirc", "/.netrc",
    # Git credentials
    "/.git-credentials", "/.gitconfig",
    # Browser data
    "/.config/google-chrome/", "/.mozilla/firefox/",
    # Crypto wallets
    "/.bitcoin/wallet.dat", "/.ethereum/keystore/",
}

# Persistence mechanisms
PERSISTENCE_PATHS = {
    "/etc/cron.d/", "/etc/cron.daily/", "/var/spool/cron/",
    "/.bashrc", "/.bash_profile", "/.profile", "/.zshrc",
    "/etc/systemd/system/", "/etc/init.d/",
    "/.config/autostart/",
}


# =============================================================================
# SEVERITY CLASSIFICATION LOGIC
# =============================================================================

@dataclass
class BehaviorContext:
    """Tracks observed behaviors to determine severity chain"""
    sensitive_env_accessed: Set[str] = field(default_factory=set)
    sensitive_files_read: Set[str] = field(default_factory=set)
    outbound_attempts: List[Dict[str, Any]] = field(default_factory=list)
    known_bad_contacted: List[str] = field(default_factory=list)
    executables_created: List[str] = field(default_factory=list)
    persistence_attempts: List[str] = field(default_factory=list)
    shell_commands: List[str] = field(default_factory=list)
    
    @property
    def has_sensitive_read(self) -> bool:
        """Did we observe access to sensitive data?"""
        return bool(self.sensitive_env_accessed or self.sensitive_files_read)
    
    @property
    def has_outbound_attempt(self) -> bool:
        """Did we observe outbound network attempt?"""
        return bool(self.outbound_attempts)
    
    @property
    def has_exfil_chain(self) -> bool:
        """The key indicator: sensitive read + outbound attempt"""
        return self.has_sensitive_read and self.has_outbound_attempt
    
    @property
    def has_persistence(self) -> bool:
        """Did we observe persistence mechanism?"""
        return bool(self.persistence_attempts)
    
    @property
    def contacted_known_bad(self) -> bool:
        """Did we contact known malicious infrastructure?"""
        return bool(self.known_bad_contacted)


def classify_severity(event: Dict[str, Any], context: BehaviorContext) -> Severity:
    """
    Classify a single event's severity based on context.
    
    This is the core logic that implements the refined severity model:
    
    CRITICAL - Confirmed malicious with evidence:
      • Credential theft: reads tokens/SSH keys/cloud creds + outbound attempt
      • Data exfiltration: sensitive data read + successfully sent outbound
      • Arbitrary code execution with persistence
      • Crypto-mining with persistence mechanism
      • Destructive behavior
    
    HIGH - Clear malicious intent, incomplete proof of exfil:
      • Contacts known bad domains/IPs (threat intel match)
      • Downloads + executes second-stage payload
      • Reads sensitive env/files AND attempts outbound (the chain!)
      • Process injection-like behavior
      • Reverse shell patterns
    
    MEDIUM - Suspicious or policy-violating but ambiguous:
      • Unexpected outbound to non-registry domains (no sensitive read first)
      • Unusual shelling out to system commands
      • Probing environment/system (but no exfil attempt)
      • Obfuscated scripts
    
    LOW - Minor policy violation:
      • Accessing non-sensitive env vars
      • Writing to unexpected but harmless locations
    
    INFO - Telemetry / benign:
      • Checks OS/CI vars for compatibility
      • Telemetry to known vendor endpoints
    """
    event_type = event.get("event", "")
    
    # =========================================================================
    # CRITICAL: Confirmed credential theft / exfiltration / persistence
    # =========================================================================
    
    # Credential file access + outbound = CRITICAL
    if event_type == "honeypot_access":
        path = event.get("path", "")
        if any(sens in path for sens in SENSITIVE_FILE_PATHS):
            context.sensitive_files_read.add(path)
            if context.has_outbound_attempt:
                return Severity.CRITICAL  # Exfil chain complete!
            return Severity.HIGH  # Credential access alone is HIGH
    
    # Persistence mechanism = CRITICAL
    if event_type == "file_write":
        path = event.get("path", "")
        if any(pers in path for pers in PERSISTENCE_PATHS):
            context.persistence_attempts.append(path)
            return Severity.CRITICAL
    
    # Destructive commands = CRITICAL
    if event_type in ("blocked_execution", "process_exec"):
        cmd = event.get("command", "") or event.get("binary", "")
        args = event.get("args", [])
        full_cmd = f"{cmd} {' '.join(args) if args else ''}"
        
        # rm -rf / or similar
        if "rm " in full_cmd and ("-rf" in full_cmd or "-fr" in full_cmd):
            if "/" in full_cmd and not full_cmd.endswith("node_modules"):
                return Severity.CRITICAL
    
    # =========================================================================
    # HIGH: Clear malicious intent, incomplete exfil proof
    # =========================================================================
    
    # Known bad domain/IP contact = HIGH
    if event_type == "network_blocked":
        dest = event.get("destination", "") or event.get("host", "")
        context.outbound_attempts.append(event)
        
        if dest in KNOWN_BAD_DOMAINS or dest in KNOWN_BAD_IPS:
            context.known_bad_contacted.append(dest)
            return Severity.HIGH
        
        # If we already read sensitive data, this completes the chain
        if context.has_sensitive_read:
            return Severity.HIGH  # Exfil chain!
    
    # Sensitive env var access = HIGH (or CRITICAL if outbound already seen)
    if event_type == "env_access":
        var = event.get("variable", "")
        if var in SENSITIVE_ENV_VARS or any(var.startswith(p) for p in ["AWS_", "GITHUB_", "NPM_", "CI_"]):
            context.sensitive_env_accessed.add(var)
            if context.has_outbound_attempt:
                return Severity.CRITICAL  # Chain complete
            return Severity.HIGH
    
    # Download + execute pattern = HIGH
    if event_type == "blocked_execution":
        binary = event.get("binary", "")
        if binary in ("curl", "wget", "nc", "ncat"):
            # Check if this is piping to shell
            args = event.get("args", [])
            if any("|" in str(a) or "bash" in str(a) or "sh" in str(a) for a in args):
                return Severity.HIGH
            # Download attempt alone
            if context.has_sensitive_read:
                return Severity.HIGH
            return Severity.MEDIUM  # Just download attempt, no sensitive context
    
    # Reverse shell patterns = HIGH
    if event_type in ("blocked_execution", "suspicious_argument"):
        reason = event.get("reason", "")
        if "reverse" in reason.lower() or "shell" in reason.lower():
            return Severity.HIGH
    
    # =========================================================================
    # MEDIUM: Suspicious but ambiguous (no exfil chain)
    # =========================================================================
    
    # Network to non-registry domain (but no sensitive read first)
    if event_type == "network_blocked":
        dest = event.get("destination", "") or event.get("host", "")
        # Allow known package registries
        allowed_hosts = ["registry.npmjs.org", "pypi.org", "files.pythonhosted.org", 
                        "github.com", "raw.githubusercontent.com"]
        if not any(allowed in dest for allowed in allowed_hosts):
            if not context.has_sensitive_read:
                return Severity.MEDIUM  # Suspicious but no chain
    
    # Unusual shell commands (but not destructive)
    if event_type == "process_exec":
        cmd = event.get("command", "")
        suspicious_commands = ["base64", "xxd", "openssl", "gpg", "tar", "zip"]
        if cmd in suspicious_commands:
            context.shell_commands.append(cmd)
            return Severity.MEDIUM
    
    # Obfuscated/encoded patterns
    if event_type == "suspicious_argument":
        reason = event.get("reason", "").lower()
        if "obfuscated" in reason or "encoded" in reason or "base64" in reason:
            return Severity.MEDIUM
    
    # Environment probing without sensitive vars
    if event_type == "env_access":
        var = event.get("variable", "")
        if var not in SENSITIVE_ENV_VARS:
            return Severity.LOW  # Just checking env, not sensitive
    
    # =========================================================================
    # LOW: Minor policy violations
    # =========================================================================
    
    # File write outside allowed paths (but not persistence)
    if event_type == "file_write":
        path = event.get("path", "")
        allowed = ["/work/", "/tmp/", "/var/log/"]
        if not any(path.startswith(p) for p in allowed):
            if not any(pers in path for pers in PERSISTENCE_PATHS):
                return Severity.LOW
    
    # =========================================================================
    # INFO: Telemetry / benign behavior
    # =========================================================================
    
    # Env scrubbing notification
    if event_type == "env_scrubbed":
        return Severity.INFO
    
    # Known telemetry endpoints (example - expand as needed)
    if event_type == "network_blocked":
        dest = event.get("destination", "")
        telemetry_hosts = ["sentry.io", "bugsnag.com", "datadog", "newrelic"]
        if any(t in dest for t in telemetry_hosts):
            return Severity.INFO
    
    # Default: INFO for unrecognized events
    return Severity.INFO


def determine_verdict(findings: List[Dict[str, Any]], context: BehaviorContext) -> str:
    """
    Determine overall verdict based on findings and context.
    
    Verdict mapping:
      CRITICAL → Any CRITICAL finding OR confirmed exfil chain
      WARNING  → Any HIGH finding OR suspicious behavior pattern
      INFO     → Only MEDIUM/LOW/INFO findings
      CLEAN    → No findings at all
    """
    if not findings:
        return "CLEAN"
    
    severities = [f.get("severity", "INFO") for f in findings]
    
    # Any CRITICAL → CRITICAL verdict
    if "CRITICAL" in severities:
        return "CRITICAL"
    
    # Exfil chain detected → CRITICAL even if individual findings are HIGH
    if context.has_exfil_chain and context.contacted_known_bad:
        return "CRITICAL"
    
    # Any HIGH → WARNING verdict
    if "HIGH" in severities:
        return "WARNING"
    
    # Multiple MEDIUM findings suggest pattern → WARNING
    medium_count = severities.count("MEDIUM")
    if medium_count >= 3:
        return "WARNING"
    
    # Just MEDIUM/LOW/INFO → INFO verdict (not CLEAN, there were findings)
    if "MEDIUM" in severities:
        return "INFO"
    
    return "CLEAN"


# =============================================================================
# MALWARE REACHABILITY MODEL (for static malware - GuardDog)
# =============================================================================

class MalwareReachability(Enum):
    """
    Reachability status for STATIC malware analysis (GuardDog/YARA).
    
    This applies to packages detected with malicious patterns.
    Dynamic sandbox analysis does NOT use this - install-time hooks
    execute regardless of import.
    
    REACHABLE:
      Package is imported/used in application code.
      → Malicious payload CAN execute at runtime
      → Priority: CRITICAL - remove immediately
    
    NOT_REACHABLE:
      Package is in dependency tree but never imported.
      → "Dead dependency" - payload won't run at runtime
      → Priority: HIGH - still remove (install hooks may have run)
    
    UNKNOWN:
      Can't determine if package is used.
      → Dynamic import, eval(), reflection, etc.
      → Priority: HIGH - assume worst case
    """
    REACHABLE = "REACHABLE"
    NOT_REACHABLE = "NOT_REACHABLE"
    UNKNOWN = "UNKNOWN"


@dataclass
class MalwareFinding:
    """
    A malware finding from static analysis (GuardDog/YARA).
    
    Note: This is separate from sandbox findings because:
    1. Static analysis looks at package code patterns
    2. Reachability analysis determines if code will execute
    3. Sandbox analysis looks at install-time behavior (no reachability)
    """
    package: str
    version: Optional[str]
    rule_id: str
    severity: Severity
    description: str
    reachability: MalwareReachability
    import_path: Optional[List[str]] = None  # Call path if reachable
    evidence: Dict[str, Any] = field(default_factory=dict)
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "package": self.package,
            "version": self.version,
            "rule_id": self.rule_id,
            "severity": self.severity.value,
            "description": self.description,
            "reachability": self.reachability.value,
            "import_path": self.import_path,
            "evidence": self.evidence,
        }


# =============================================================================
# DOCUMENTATION: JSON-FIRST ARCHITECTURE
# =============================================================================

"""
JSON-First Architecture for REACHABLE
=====================================

Why JSON-First (not DB-First):
1. Debuggability: `zcat report.json.gz | jq .` beats SQL queries
2. CI/CD Artifacts: JSON compresses well, easy to upload/download
3. Immutability: Each scan is a snapshot, no race conditions
4. Portability: Works everywhere without SQLite dependencies
5. Schema Evolution: Just add fields, no migrations needed

Data Flow:
----------

    ┌─────────────────────────────────────────────────────────┐
    │  RAW SCANNER OUTPUT (kept for audit/debug)              │
    │                                                         │
    │  sbom.json.gz      ← Syft SBOM (all packages)          │
    │  vulns.json.gz     ← Grype CVE matches (no reachability)│
    │  security_findings.json ← Semgrep/GuardDog raw          │
    └─────────────────────────────────────────────────────────┘
                              ↓
    ┌─────────────────────────────────────────────────────────┐
    │  ANALYSIS ENGINE (reachable.py)                         │
    │                                                         │
    │  • Call graph construction                              │
    │  • Reachability analysis                                │
    │  • Severity classification                              │
    │  • Threat correlation                                   │
    │  • Risk scoring                                         │
    └─────────────────────────────────────────────────────────┘
                              ↓
    ┌─────────────────────────────────────────────────────────┐
    │  reachable-report.json.gz  ← SINGLE SOURCE OF TRUTH     │
    │                                                         │
    │  Contains:                                              │
    │  • reachable{}: CVEs with REACHABLE status             │
    │  • unreachable{}: CVEs with NOT_REACHABLE status       │
    │  • detailed_findings.cwe.findings[]: Code issues       │
    │  • detailed_findings.secrets.findings[]: Secrets       │
    │  • security_scans.malware_packages[]: Static malware   │
    │  • dynamic_malware{}: Sandbox results                  │
    │  • summary.overall_risk{}: Risk score & level          │
    └─────────────────────────────────────────────────────────┘
                              ↓
              ┌───────────────┴───────────────┐
              ↓                               ↓
    ┌─────────────────────┐       ┌─────────────────────┐
    │  repo.db            │       │  dashboard/         │
    │  (historical data)  │       │  ├── index.html     │
    │                     │       │  └── data.json      │
    │  • Trend queries    │       │                     │
    │  • Scan history     │       │  Reads from report, │
    │  • Deduplication    │       │  NOT from DB        │
    └─────────────────────┘       └─────────────────────┘


File Locations:
---------------
~/.reachable/scans/{repo-hash}/
├── repo.db                          # Per-repo database (historical)
├── {branch}/
│   ├── latest -> 2025-01-13-...     # Symlink to latest scan
│   └── 2025-01-13-10-30-00/         # Timestamped scan directory
│       ├── reachable-report.json.gz # SOURCE OF TRUTH
│       ├── sbom.json.gz             # Raw SBOM (audit)
│       ├── vulns.json.gz            # Raw CVEs (audit)
│       ├── scan.log                 # Scanner output log
│       ├── dashboard/
│       │   ├── index.html
│       │   └── data.json            # Derived from report
│       └── raw/                     # Optional detailed files
│           ├── scan-manifest.json   # CI/CD coordination
│           └── correlation.json.gz  # Threat correlations


Reachability Model by Signal Type:
----------------------------------

CVE (from Grype → reachable-report.json):
  • REACHABLE: Vulnerable function called from app code
  • NOT_REACHABLE: Package in deps but vulnerable code not called
  • UNKNOWN: Can't determine (no call graph, dynamic loading)

CWE (from Semgrep):
  • REACHABLE: Code pattern in reachable function
  • NOT_REACHABLE: Dead code / unreachable branch
  • UNKNOWN: Config files (Dockerfile, YAML) - no code path analysis

Secrets (from Semgrep):
  • REACHABLE: Secret in code that gets executed
  • NOT_REACHABLE: Secret in test file / dead code
  • UNKNOWN: Secret in config file

Static Malware (from GuardDog):
  • REACHABLE: Malicious package is imported/used
  • NOT_REACHABLE: In deps but never imported (dead dep)
  • UNKNOWN: Dynamic import, can't determine

Dynamic Malware (from Sandbox):
  • NO REACHABILITY - install hooks execute regardless of import
  • Uses verdict (CLEAN/WARNING/CRITICAL) instead
  • Metrics: packages_tested, findings[], duration_ms

Config Issues (from Semgrep):
  • ALWAYS UNKNOWN - config files have no code paths
  • Dockerfile, YAML, Terraform, etc.
  • Stored as finding_type='config' in DB
"""
