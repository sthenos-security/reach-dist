#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.

"""
REACHABLE Enhanced Secrets Scanner

Properly separates:
1. Hardcoded SECRETS (API keys, passwords, tokens)
2. SAST findings (code quality/security issues)

Provides remediation guidance for secrets.
"""

import os
import re
from pathlib import Path
from typing import Dict, List, Any, Tuple
from dataclasses import dataclass, field

# =============================================================================
# CLASSIFICATION RULES
# =============================================================================

# Semgrep rules that detect ACTUAL SECRETS (not just security issues)
SECRET_RULE_PATTERNS = [
    # Generic secret patterns
    r'generic.*secret',
    r'hardcoded.*secret',
    r'hardcoded.*password',
    r'hardcoded.*token',
    r'hardcoded.*key',
    r'hardcoded.*credential',
    
    # API keys
    r'api[-_]?key',
    r'apikey',
    
    # Cloud provider secrets
    r'aws[-_]?(access|secret|key)',
    r'gcp[-_]?(key|credential)',
    r'azure[-_]?(key|secret|credential)',
    
    # Service-specific
    r'github[-_]?token',
    r'slack[-_]?token',
    r'stripe[-_]?key',
    r'twilio[-_]?(sid|token)',
    r'sendgrid[-_]?key',
    r'mailchimp[-_]?key',
    
    # Certificates/Keys
    r'private[-_]?key',
    r'rsa[-_]?key',
    r'ssh[-_]?key',
    r'pem[-_]?key',
    
    # Database
    r'database[-_]?(password|url|connection)',
    r'db[-_]?(password|url|connection)',
    r'mysql[-_]?(password|root)',
    r'postgres[-_]?(password|url)',
    r'mongo[-_]?(password|url)',
    r'redis[-_]?(password|url)',
    
    # JWT/OAuth
    r'jwt[-_]?secret',
    r'oauth[-_]?(secret|token)',
    r'client[-_]?secret',
    
    # Generic patterns
    r'password',
    r'passwd',
    r'secret',
    r'credential',
    r'auth[-_]?token',
    r'bearer[-_]?token',
    r'session[-_]?secret',
]

# Semgrep rules that are SAST (not secrets)
SAST_RULE_PATTERNS = [
    # Dockerfile issues (NOT secrets - code quality/security config)
    r'dockerfile\.security',
    r'docker\.security',
    r'dockerfile.*root',
    r'docker.*root',
    r'dockerfile.*user',
    r'dockerfile.*add',
    r'dockerfile.*copy',
    r'docker.*privileged',
    r'container.*root',
    r'run[-_]?as[-_]?root',
    
    # Language-specific code issues
    r'go\.lang\.security',
    r'python\.lang\.security',
    r'javascript\.lang\.security',
    r'java\.lang\.security',
    r'ruby\.lang\.security',
    r'rust\.lang\.security',
    r'typescript\.security',
    r'php\.security',
    r'csharp\.security',
    
    # OWASP vulnerabilities (code issues, not secrets)
    r'injection',
    r'sql[-_]?injection',
    r'nosql[-_]?injection',
    r'ldap[-_]?injection',
    r'command[-_]?injection',
    r'os[-_]?command',
    r'xss',
    r'cross[-_]?site[-_]?scripting',
    r'xxe',
    r'xml[-_]?external[-_]?entity',
    r'ssrf',
    r'server[-_]?side[-_]?request',
    
    # Authentication/Authorization issues (not secrets)
    r'missing[-_]?auth',
    r'insecure[-_]?auth',
    r'weak[-_]?auth',
    r'broken[-_]?auth',
    r'auth[-_]?bypass',
    
    # Configuration issues (not exposed secrets)
    r'insecure[-_]?config',
    r'security[-_]?misconfiguration',
    r'missing[-_]?header',
    r'csrf',
    r'cors',
    r'clickjacking',
    r'http[-_]?only',
    r'secure[-_]?flag',
    r'debug[-_]?mode',
    r'verbose[-_]?error',
    
    # Cryptography issues (algorithm choices, not secrets)
    r'weak[-_]?crypto',
    r'insecure[-_]?hash',
    r'weak[-_]?hash',
    r'weak[-_]?random',
    r'insecure[-_]?random',
    r'md5',
    r'sha1[^0-9]',
    r'des[^a-z]',
    r'rc4',
    r'ecb[-_]?mode',
    
    # Input validation
    r'path[-_]?traversal',
    r'directory[-_]?traversal',
    r'lfi',  # Local file inclusion
    r'rfi',  # Remote file inclusion
    r'open[-_]?redirect',
    r'unsafe[-_]?deserialization',
    r'insecure[-_]?deserialization',
    r'prototype[-_]?pollution',
    r'regex[-_]?dos',
    r'redos',
    
    # Access control
    r'missing[-_]?user',
    r'privilege[-_]?escalation',
    r'insecure[-_]?direct[-_]?object',
    r'idor',
    r'broken[-_]?access[-_]?control',
    
    # Memory/Resource issues (code quality)
    r'buffer[-_]?overflow',
    r'memory[-_]?leak',
    r'resource[-_]?leak',
    r'use[-_]?after[-_]?free',
    r'race[-_]?condition',
    r'toctou',  # Time of check to time of use
    
    # Logging issues (not secrets)
    r'log[-_]?injection',
    r'log[-_]?forging',
    r'sensitive[-_]?data[-_]?exposure',  # Generic, not specific secret
]

def is_secret_finding(rule_id: str) -> bool:
    """
    Check if a Semgrep rule ID is a secret detection rule.
    
    Args:
        rule_id: The Semgrep rule ID
        
    Returns:
        True if this is a secret detection rule
    """
    rule_lower = rule_id.lower()
    
    # Check if it matches a SAST pattern (not a secret)
    for pattern in SAST_RULE_PATTERNS:
        if re.search(pattern, rule_lower):
            return False
    
    # Check if it matches a secret pattern
    for pattern in SECRET_RULE_PATTERNS:
        if re.search(pattern, rule_lower):
            return True
    
    # Default: if it has "secret" in the name, it's a secret
    return 'secret' in rule_lower

def classify_secret_type(rule_id: str, message: str = "", content: str = "") -> str:
    """
    Classify the type of secret detected.
    
    Returns one of:
    - api_key
    - password
    - token
    - private_key
    - public_key (v4.5.x: HIGH severity - pairing unknown)
    - database_credential
    - cloud_credential
    - certificate
    - jwt_secret
    - generic_secret
    
    v4.5.x: Added public_key detection. Public keys alone are not secrets,
    but we flag them as HIGH because we cannot prove there's no matching
    private key in the codebase. If pairing is later proven absent, can
    downgrade to LOW.
    """
    combined = (rule_id + " " + message).lower()
    content_lower = content.lower() if content else ""
    
    # v4.5.x: Check for PUBLIC keys first (content-based detection)
    # These are NOT secrets by themselves, but flag as HIGH since pairing unknown
    if is_public_key_content(content) or is_public_key_content(message):
        return 'public_key'
    if any(x in combined for x in ['public-key', 'public_key', 'pubkey']):
        # Only if explicitly labeled as public
        if 'private' not in combined:
            return 'public_key'
    
    if any(x in combined for x in ['api-key', 'apikey', 'api_key']):
        return 'api_key'
    elif any(x in combined for x in ['password', 'passwd', 'pwd']):
        return 'password'
    elif any(x in combined for x in ['token', 'bearer', 'auth']):
        return 'token'
    elif any(x in combined for x in ['private-key', 'private_key', 'rsa', 'ssh', 'pem']):
        return 'private_key'
    elif any(x in combined for x in ['database', 'mysql', 'postgres', 'mongo', 'redis', 'db']):
        return 'database_credential'
    elif any(x in combined for x in ['aws', 'gcp', 'azure', 'cloud']):
        return 'cloud_credential'
    elif any(x in combined for x in ['cert', 'certificate', 'ssl', 'tls']):
        return 'certificate'
    elif any(x in combined for x in ['jwt', 'oauth', 'client-secret']):
        return 'jwt_secret'
    else:
        return 'generic_secret'


def is_public_key_content(content: str) -> bool:
    """
    Check if content contains a PUBLIC key (not a secret).
    
    v4.5.x: Public keys are flagged as HIGH (not CRITICAL) because:
    - Public key alone is not exploitable
    - But we can't prove there's no matching private key
    - If keypair pairing is implemented and no match found → LOW
    
    Returns:
        True if content appears to be a public key
    """
    if not content:
        return False
    
    content_upper = content.upper()
    
    # PEM-encoded public keys
    public_markers = [
        '-----BEGIN PUBLIC KEY-----',
        '-----BEGIN RSA PUBLIC KEY-----',
        '-----BEGIN EC PUBLIC KEY-----',
        '-----BEGIN SSH2 PUBLIC KEY-----',
    ]
    
    # Check for public key markers WITHOUT private key markers
    has_public = any(marker in content_upper for marker in public_markers)
    has_private = 'PRIVATE KEY' in content_upper
    
    if has_public and not has_private:
        return True
    
    # SSH public keys (ssh-rsa, ssh-ed25519, etc.)
    ssh_public_patterns = [
        'ssh-rsa AAAA',
        'ssh-ed25519 AAAA',
        'ssh-ecdsa AAAA',
        'ecdsa-sha2-nistp',
    ]
    if any(pattern.lower() in content.lower() for pattern in ssh_public_patterns):
        return True
    
    # .pub file extension in path/filename
    if content.endswith('.pub'):
        return True
    
    return False

# =============================================================================
# REMEDIATION GUIDANCE
# =============================================================================

@dataclass
class SecretRemediation:
    """Remediation guidance for a detected secret"""
    secret_type: str
    severity: str
    immediate_actions: List[str] = field(default_factory=list)
    git_cleanup: List[str] = field(default_factory=list)
    prevention: List[str] = field(default_factory=list)
    alternatives: List[str] = field(default_factory=list)
    
    def to_dict(self) -> Dict:
        return {
            'secret_type': self.secret_type,
            'severity': self.severity,
            'immediate_actions': self.immediate_actions,
            'git_cleanup': self.git_cleanup,
            'prevention': self.prevention,
            'alternatives': self.alternatives
        }

def get_remediation(secret_type: str, is_committed: bool = True) -> SecretRemediation:
    """
    Get remediation guidance for a secret type.
    
    Args:
        secret_type: The type of secret (api_key, password, etc.)
        is_committed: Whether the secret was committed to git
        
    Returns:
        SecretRemediation object with guidance
    """
    # Common immediate actions
    immediate = [
        "1. REVOKE the exposed secret immediately",
        "2. ROTATE to a new secret value",
        "3. UPDATE all systems using this secret",
    ]
    
    # Git cleanup steps (if committed)
    git_cleanup = []
    if is_committed:
        git_cleanup = [
            "PURGE from git history:",
            "  Option A: BFG Repo-Cleaner (recommended)",
            "    $ bfg --delete-files <filename> <repo>",
            "    $ git reflog expire --expire=now --all",
            "    $ git gc --prune=now --aggressive",
            "",
            "  Option B: git filter-repo",
            "    $ git filter-repo --invert-paths --path <file>",
            "",
            "After cleanup:",
            "  $ git push origin --force --all",
            "  Notify team to re-clone repository",
        ]
    
    # Type-specific guidance
    alternatives = []
    prevention = [
        "Add to .gitignore: *.pem, *.key, .env, secrets.*",
        "Use pre-commit hooks: detect-secrets, gitleaks",
        "Enable GitHub secret scanning",
    ]
    
    # v4.5.x: Public key handling - HIGH severity (pairing unknown)
    if secret_type == 'public_key':
        immediate = [
            "1. VERIFY if a matching private key exists in this repository",
            "2. If private key found → treat as CRITICAL (keypair exposed)",
            "3. If no private key → this is likely safe (public keys are meant to be shared)",
        ]
        alternatives = [
            "Public keys are designed to be shared - verify no private key is exposed",
            "Store private keys in secure key management (AWS KMS, HashiCorp Vault)",
            "Use certificate managers for key distribution",
        ]
        prevention = [
            "Add *.pem, *.key to .gitignore for private keys",
            "Use asymmetric encryption with proper key separation",
            "Never commit private keys - only public keys if needed",
        ]
        # HIGH because we can't prove no private key exists
        # Would be LOW if we could prove no pairing
        severity = "HIGH"
        
        return SecretRemediation(
            secret_type=secret_type,
            severity=severity,
            immediate_actions=immediate,
            git_cleanup=[],  # No cleanup needed for public keys alone
            prevention=prevention,
            alternatives=alternatives
        )
    
    if secret_type == 'api_key':
        alternatives = [
            "Use environment variables: export API_KEY=xxx",
            "Use secrets manager: AWS Secrets Manager, HashiCorp Vault",
            "Use .env files (gitignored): API_KEY=xxx",
        ]
        severity = "CRITICAL"
    elif secret_type == 'password':
        alternatives = [
            "Use secrets manager for database passwords",
            "Use IAM roles instead of passwords where possible",
            "Use connection pooling with rotated credentials",
        ]
        severity = "CRITICAL"
    elif secret_type == 'private_key':
        alternatives = [
            "Store in secure key management system (AWS KMS, GCP KMS)",
            "Use short-lived certificates instead of static keys",
            "Use hardware security modules (HSM) for critical keys",
        ]
        severity = "CRITICAL"
    elif secret_type == 'cloud_credential':
        alternatives = [
            "AWS: Use IAM roles, not access keys",
            "GCP: Use service account impersonation",
            "Azure: Use Managed Identity",
            "All: Use temporary credentials with short TTL",
        ]
        severity = "CRITICAL"
    elif secret_type == 'database_credential':
        alternatives = [
            "Use IAM database authentication",
            "Use secrets manager with automatic rotation",
            "Use connection strings from environment variables",
        ]
        severity = "CRITICAL"
    elif secret_type == 'token':
        alternatives = [
            "Use short-lived tokens with automatic refresh",
            "Store in secure token service",
            "Use OAuth 2.0 with proper token management",
        ]
        severity = "HIGH"
    elif secret_type == 'jwt_secret':
        alternatives = [
            "Use asymmetric keys (RS256) instead of symmetric secrets",
            "Store JWT secrets in secrets manager",
            "Implement key rotation with multiple valid keys",
        ]
        severity = "CRITICAL"
    elif secret_type == 'certificate':
        alternatives = [
            "Use certificate manager (AWS ACM, Let's Encrypt)",
            "Store in secure certificate store",
            "Use short-lived certificates with auto-renewal",
        ]
        severity = "HIGH"
    else:
        alternatives = [
            "Use environment variables",
            "Use a secrets manager",
            "Never commit secrets to version control",
        ]
        severity = "HIGH"
    
    return SecretRemediation(
        secret_type=secret_type,
        severity=severity,
        immediate_actions=immediate,
        git_cleanup=git_cleanup,
        prevention=prevention,
        alternatives=alternatives
    )

# =============================================================================
# FINDING PROCESSING
# =============================================================================

def separate_findings(findings: List[Dict]) -> Tuple[List[Dict], List[Dict]]:
    """
    Separate findings into secrets and SAST findings.
    
    Args:
        findings: List of Semgrep findings
        
    Returns:
        (secrets_list, sast_list)
    """
    secrets = []
    sast = []
    
    for finding in findings:
        rule_id = finding.get('rule_id', finding.get('check_id', ''))
        
        if is_secret_finding(rule_id):
            # Enhance secret finding
            # v4.5.x: Pass content for public key detection
            content = finding.get('extra', {}).get('lines', '') or finding.get('snippet', '')
            secret_type = classify_secret_type(rule_id, finding.get('message', ''), content)
            remediation = get_remediation(secret_type)
            
            finding['secret_type'] = secret_type
            finding['remediation'] = remediation.to_dict()
            finding['category'] = 'secret'
            secrets.append(finding)
        else:
            finding['category'] = 'sast'
            sast.append(finding)
    
    return secrets, sast

def get_project_from_path(file_path: str, repo_root: str) -> str:
    """
    Extract project name from file path.
    
    Args:
        file_path: Absolute path to file
        repo_root: Root directory of repository
        
    Returns:
        Project name
    """
    try:
        rel_path = os.path.relpath(file_path, repo_root)
        parts = rel_path.split(os.sep)
        
        # Skip common non-project directories
        skip_dirs = {'.', '..', 'src', 'lib', 'pkg', 'internal', 'cmd'}
        
        for part in parts:
            if part and part not in skip_dirs:
                return part
        
        return 'root'
    except:
        return 'unknown'

def format_secret_for_cli(secret: Dict, repo_root: str = None) -> str:
    """
    Format a secret finding for CLI output.
    
    Args:
        secret: Secret finding dict
        repo_root: Repository root for relative paths
        
    Returns:
        Formatted string for CLI output
    """
    file_path = secret.get('file', secret.get('path', 'unknown'))
    line = secret.get('line', secret.get('start', {}).get('line', '?'))
    rule_id = secret.get('rule_id', secret.get('check_id', 'unknown'))
    severity = secret.get('severity', 'unknown')
    secret_type = secret.get('secret_type', 'unknown')
    
    # Make path relative if repo_root provided
    if repo_root and file_path.startswith(repo_root):
        file_path = os.path.relpath(file_path, repo_root)
    elif repo_root:
        try:
            file_path = os.path.relpath(file_path, repo_root)
        except:
            pass
    
    # Color coding
    severity_icon = {
        'ERROR': '🔴',
        'CRITICAL': '🔴',
        'WARNING': '🟠',
        'HIGH': '🟠',
        'INFO': '🔵',
        'LOW': '🔵',
    }.get(severity.upper(), '⚪')
    
    return f"   {severity_icon} {file_path}:{line} [{secret_type}]"

def print_secrets_summary(secrets: List[Dict], sast: List[Dict], repo_root: str = None):
    """
    Print a summary of secrets and SAST findings to CLI.
    
    Args:
        secrets: List of secret findings
        sast: List of SAST findings
        repo_root: Repository root for relative paths
    """
    print(f"\n   🔐 SECRETS DETECTED: {len(secrets)}")
    
    if secrets:
        # Group by severity
        by_severity = {}
        for s in secrets:
            sev = s.get('severity', 'unknown').upper()
            by_severity[sev] = by_severity.get(sev, 0) + 1
        
        severity_str = ", ".join(f"{k}: {v}" for k, v in sorted(by_severity.items()))
        print(f"      By Severity: {severity_str}")
        
        # Group by type
        by_type = {}
        for s in secrets:
            t = s.get('secret_type', 'unknown')
            by_type[t] = by_type.get(t, 0) + 1
        
        type_str = ", ".join(f"{k}: {v}" for k, v in sorted(by_type.items()))
        print(f"      By Type: {type_str}")
        
        # Show top locations
        print(f"\n   📍 SECRET LOCATIONS (top 10):")
        for secret in secrets[:10]:
            print(format_secret_for_cli(secret, repo_root))
        
        if len(secrets) > 10:
            print(f"      ... and {len(secrets) - 10} more")
        
        # Remediation summary
        print(f"\n   🔧 REMEDIATION:")
        print(f"      1. REVOKE exposed secrets immediately")
        print(f"      2. ROTATE to new values")
        print(f"      3. Use secrets manager (Vault, AWS Secrets Manager)")
        print(f"      4. Purge from git history if committed")
    
    if sast:
        print(f"\n   🔍 SAST ISSUES: {len(sast)}")
        by_cat = {}
        for f in sast:
            rule = f.get('rule_id', 'unknown').split('.')[0]
            by_cat[rule] = by_cat.get(rule, 0) + 1
        cat_str = ", ".join(f"{k}: {v}" for k, v in sorted(by_cat.items())[:5])
        print(f"      Categories: {cat_str}")

# =============================================================================
# MAIN PROCESSING
# =============================================================================

def process_semgrep_results(
    results: List[Dict],
    repo_root: str = None
) -> Dict[str, Any]:
    """
    Process Semgrep results, separating secrets from SAST.
    
    Args:
        results: List of Semgrep findings
        repo_root: Repository root path
        
    Returns:
        Dictionary with separated and enhanced findings
    """
    secrets, sast = separate_findings(results)
    
    # Calculate stats
    secrets_by_severity = {}
    secrets_by_type = {}
    secrets_by_project = {}
    
    for s in secrets:
        sev = s.get('severity', 'unknown').upper()
        secrets_by_severity[sev] = secrets_by_severity.get(sev, 0) + 1
        
        t = s.get('secret_type', 'unknown')
        secrets_by_type[t] = secrets_by_type.get(t, 0) + 1
        
        proj = get_project_from_path(s.get('file', ''), repo_root or '')
        secrets_by_project[proj] = secrets_by_project.get(proj, 0) + 1
    
    sast_by_category = {}
    for f in sast:
        rule = f.get('rule_id', 'unknown').split('.')[0]
        sast_by_category[rule] = sast_by_category.get(rule, 0) + 1
    
    return {
        'secrets': {
            'total': len(secrets),
            'findings': secrets,
            'by_severity': secrets_by_severity,
            'by_type': secrets_by_type,
            'by_project': secrets_by_project,
            'critical_count': secrets_by_severity.get('ERROR', 0) + secrets_by_severity.get('CRITICAL', 0),
            'high_count': secrets_by_severity.get('WARNING', 0) + secrets_by_severity.get('HIGH', 0),
        },
        'sast': {
            'total': len(sast),
            'findings': sast,
            'by_category': sast_by_category,
        },
        'total_findings': len(results),
    }

if __name__ == '__main__':
    print("=" * 70)
    print("Enhanced Secrets Scanner - Classification Demo")
    print("=" * 70)
    
    # Test rule classification
    test_rules = [
        "generic-secret-detection",
        "hardcoded-password",
        "aws-access-key-id",
        "dockerfile.security.missing-user.missing-user",
        "go.lang.security.audit.xss.no-direct-write-to-responsewriter",
        "python.lang.security.sql-injection",
        "secrets.detected.api-key",
        "jwt-secret-hardcoded",
    ]
    
    print("\nRule Classification:")
    for rule in test_rules:
        is_secret = is_secret_finding(rule)
        classification = "SECRET" if is_secret else "SAST"
        print(f"  {rule}")
        print(f"    → {classification}")
        if is_secret:
            secret_type = classify_secret_type(rule)
            print(f"    → Type: {secret_type}")
    
    print("\n" + "=" * 70)
    print("Remediation Example (API Key):")
    print("=" * 70)
    remediation = get_remediation('api_key', is_committed=True)
    print(f"\nSeverity: {remediation.severity}")
    print("\nImmediate Actions:")
    for action in remediation.immediate_actions:
        print(f"  {action}")
    print("\nGit Cleanup:")
    for step in remediation.git_cleanup[:5]:
        print(f"  {step}")
    print("\nAlternatives:")
    for alt in remediation.alternatives:
        print(f"  • {alt}")
