#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.

"""
REACHABLE Correlation Engine v2.0 - Comprehensive Multi-Signal Fusion

INPUTS CORRELATED:
1. CVEs - Vulnerability findings with severity
2. Reachability - Code path analysis from entrypoints  
3. Exploitability - KEV, EPSS, Exploit-DB, Metasploit
4. Malware - Package malware (GuardDog) + Code patterns (Semgrep)
5. Secrets - Hardcoded credentials with reachability
6. Health Metrics - Package maintenance, popularity, outdated
7. Attack Surface - Phantom deps, shadow imports
8. SAST - Insecure code constructs

RISK FORMULA:
    CompositeRisk = Σ(Signal_Score × Signal_Weight × Amplifiers)
"""

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Set, Any
from enum import Enum
from datetime import datetime
import json

try:
    from reachable.correlation_metrics import (
        CorrelationMetricsCollector, CorrelationLogger, LogLevel, create_dashboard_data
    )
    HAS_METRICS = True
except ImportError:
    HAS_METRICS = False

# Import metrics collector
try:
    from reachable.correlation_metrics import (
        CorrelationMetricsCollector as MetricsCollector,
        CorrelationLogger as MetricsLogger,
        create_dashboard_data
    )
    METRICS_AVAILABLE = True
except ImportError:
    METRICS_AVAILABLE = False
    MetricsCollector = None
    MetricsLogger = None

class SignalType(Enum):
    CVE = "cve"
    REACHABILITY = "reachability"
    KEV = "kev"
    EPSS = "epss"
    CVSS = "cvss"
    EXPLOIT_DB = "exploit_db"
    METASPLOIT = "metasploit"
    MALWARE_PACKAGE = "malware_package"
    MALWARE_CODE = "malware_code"
    SECRET = "secret"
    HEALTH_MAINTENANCE = "health_maintenance"
    HEALTH_POPULARITY = "health_popularity"
    HEALTH_OUTDATED = "health_outdated"
    PHANTOM_DEP = "phantom_dep"
    SHADOW_IMPORT = "shadow_import"
    SAST_FINDING = "sast_finding"

@dataclass
class SignalContribution:
    signal_type: SignalType
    raw_value: Any
    normalized_score: float
    weight: float
    weighted_score: float
    amplifier: float = 1.0
    final_contribution: float = 0.0
    evidence: str = ""
    source: str = ""
    
    def to_dict(self) -> Dict:
        return {
            'signal': self.signal_type.value,
            'raw_value': str(self.raw_value) if not isinstance(self.raw_value, (int, float, bool, str)) else self.raw_value,
            'normalized_score': round(self.normalized_score, 2),
            'weight': self.weight,
            'weighted_score': round(self.weighted_score, 2),
            'amplifier': self.amplifier,
            'final_contribution': round(self.final_contribution, 2),
            'evidence': self.evidence,
            'source': self.source
        }

@dataclass 
class EntityRiskProfile:
    entity_id: str
    entity_type: str
    base_risk_score: float = 0.0
    amplified_risk_score: float = 0.0
    final_risk_score: float = 0.0
    reachability_amplifier: float = 1.0
    correlation_amplifier: float = 1.0
    exploit_amplifier: float = 1.0
    kev_amplifier: float = 1.0
    malware_amplifier: float = 1.0
    signal_contributions: List[SignalContribution] = field(default_factory=list)
    risk_level: str = "LOW"
    priority_rank: int = 0
    threat_types: List[str] = field(default_factory=list)
    remediation_priority: str = ""
    remediation_actions: List[str] = field(default_factory=list)
    correlation_reasoning: str = ""
    
    # Extended metadata for detailed reporting
    file_path: str = ""
    line_number: int = 0
    description: str = ""
    secret_type: str = ""
    fix_version: str = ""
    package_name: str = ""
    package_version: str = ""
    cvss_score: float = 0.0
    severity: str = ""
    call_paths: List[str] = field(default_factory=list)  # How vulnerability is reached
    affected_functions: List[str] = field(default_factory=list)  # App functions affected
    
    # Secret verification status (from TruffleHog)
    is_active: Optional[bool] = None  # True=verified active, False=verified inactive, None=not verified
    verification_status: str = "UNVERIFIED"  # ACTIVE, INACTIVE, UNVERIFIED
    
    def to_dict(self) -> Dict:
        total_amp = (self.reachability_amplifier * self.correlation_amplifier *
                    self.exploit_amplifier * self.kev_amplifier * self.malware_amplifier)
        
        # Build calculation detail for transparency
        signal_sum_parts = []
        for s in self.signal_contributions:
            if s.normalized_score > 0:
                signal_sum_parts.append(f"{s.signal_type.value}({s.normalized_score:.0f}×{s.weight})")
        
        amp_parts = []
        if self.reachability_amplifier != 1.0:
            amp_parts.append(f"reach={self.reachability_amplifier}")
        if self.correlation_amplifier != 1.0:
            amp_parts.append(f"corr={self.correlation_amplifier}")
        if self.exploit_amplifier != 1.0:
            amp_parts.append(f"exploit={self.exploit_amplifier}")
        if self.kev_amplifier != 1.0:
            amp_parts.append(f"kev={self.kev_amplifier}")
        if self.malware_amplifier != 1.0:
            amp_parts.append(f"malware={self.malware_amplifier}")
        
        return {
            'entity_id': self.entity_id,
            'entity_type': self.entity_type,
            'risk_scores': {
                'final': round(self.final_risk_score, 2),
                'base': round(self.base_risk_score, 2),
                'amplified': round(self.amplified_risk_score, 2)
            },
            'risk_level': self.risk_level,
            'priority_rank': self.priority_rank,
            'threat_types': self.threat_types,
            'amplifiers': {
                'reachability': self.reachability_amplifier,
                'correlation': self.correlation_amplifier,
                'exploit': self.exploit_amplifier,
                'kev': self.kev_amplifier,
                'malware': self.malware_amplifier,
                'total': round(total_amp, 2)
            },
            'signal_breakdown': [s.to_dict() for s in self.signal_contributions],
            'calculation_formula': {
                'base_score_formula': f"Σ(signal × weight) = {' + '.join(signal_sum_parts[:5])}{'...' if len(signal_sum_parts) > 5 else ''} = {self.base_risk_score:.2f}",
                'amplifier_formula': f"{'×'.join(amp_parts) if amp_parts else '1.0'} = {total_amp:.2f}",
                'final_formula': f"min({self.base_risk_score:.2f} × {total_amp:.2f}, 100) = {self.final_risk_score:.2f}",
                'capped': self.amplified_risk_score > 100
            },
            'remediation': {
                'priority': self.remediation_priority,
                'actions': self.remediation_actions
            },
            'reasoning': self.correlation_reasoning,
            # Extended metadata
            'metadata': {
                'file_path': self.file_path,
                'line_number': self.line_number,
                'description': self.description,
                'secret_type': self.secret_type,
                'fix_version': self.fix_version,
                'package_name': self.package_name,
                'package_version': self.package_version,
                'cvss_score': self.cvss_score,
                'severity': self.severity,
                'call_paths': self.call_paths,
                'affected_functions': self.affected_functions,
                # Secret verification (TruffleHog)
                'is_active': self.is_active,
                'verification_status': self.verification_status
            }
        }

@dataclass
class AttackPath:
    path_id: str
    stages: List[Dict] = field(default_factory=list)
    entry_point: str = ""
    exit_point: str = ""
    total_risk: float = 0.0
    threat_count: int = 0
    is_exploitable: bool = False
    exploit_chain: List[str] = field(default_factory=list)
    recommendation: str = ""
    
    def to_dict(self) -> Dict:
        return {
            'path_id': self.path_id,
            'stages': self.stages,
            'entry_point': self.entry_point,
            'exit_point': self.exit_point,
            'total_risk': round(self.total_risk, 2),
            'threat_count': self.threat_count,
            'is_exploitable': self.is_exploitable,
            'exploit_chain': self.exploit_chain,
            'recommendation': self.recommendation
        }

@dataclass
class CorrelationMetrics:
    total_cves: int = 0
    reachable_cves: int = 0
    unreachable_cves: int = 0
    total_secrets: int = 0
    reachable_secrets: int = 0
    total_packages: int = 0
    malicious_packages: int = 0
    malware_patterns: int = 0
    health_analyzed: int = 0
    phantom_deps: int = 0
    shadow_imports: int = 0
    sast_findings: int = 0
    kev_matches: int = 0
    epss_high: int = 0
    exploit_db_available: int = 0
    metasploit_available: int = 0
    entities_analyzed: int = 0
    critical_entities: int = 0
    high_entities: int = 0
    medium_entities: int = 0
    low_entities: int = 0
    reachability_amplified: int = 0
    correlation_amplified: int = 0
    exploit_amplified: int = 0
    kev_amplified: int = 0
    attack_paths_found: int = 0
    exploitable_paths: int = 0
    start_time: str = ""
    end_time: str = ""
    duration_ms: float = 0.0
    
    def to_dict(self) -> Dict:
        return {
            'inputs': {
                'cves': {'total': self.total_cves, 'reachable': self.reachable_cves, 'unreachable': self.unreachable_cves},
                'secrets': {'total': self.total_secrets, 'reachable': self.reachable_secrets},
                'packages': {'total': self.total_packages, 'malicious': self.malicious_packages},
                'malware_patterns': self.malware_patterns,
                'health_analyzed': self.health_analyzed,
                'attack_surface': {'phantom_deps': self.phantom_deps, 'shadow_imports': self.shadow_imports},
                'sast_findings': self.sast_findings
            },
            'exploitability': {
                'kev_matches': self.kev_matches,
                'epss_high': self.epss_high,
                'exploit_db': self.exploit_db_available,
                'metasploit': self.metasploit_available
            },
            'results': {
                'entities_analyzed': self.entities_analyzed,
                'by_risk_level': {
                    'critical': self.critical_entities,
                    'high': self.high_entities,
                    'medium': self.medium_entities,
                    'low': self.low_entities
                }
            },
            'amplifications': {
                'reachability': self.reachability_amplified,
                'correlation': self.correlation_amplified,
                'exploit': self.exploit_amplified,
                'kev': self.kev_amplified
            },
            'attack_paths': {'found': self.attack_paths_found, 'exploitable': self.exploitable_paths},
            'processing': {
                'start_time': self.start_time,
                'end_time': self.end_time,
                'duration_ms': round(self.duration_ms, 2)
            }
        }

class CorrelationLogger:
    def __init__(self, verbose: bool = True):
        self.verbose = verbose
        self.logs: List[Dict] = []
    
    def log(self, level: str, component: str, message: str, data: Dict = None):
        entry = {
            'timestamp': datetime.now().isoformat(),
            'level': level,
            'component': component,
            'message': message,
            'data': data or {}
        }
        self.logs.append(entry)
        
        if self.verbose:
            icon = {'INFO': 'ℹ️', 'DEBUG': '🔍', 'WARN': '⚠️', 'ERROR': '❌', 'SIGNAL': '📊'}.get(level, '•')
            print(f"      {icon} [{component}] {message}")
    
    def signal(self, signal_type: str, entity: str, score: float, evidence: str):
        self.log('SIGNAL', signal_type, f"{entity}: score={score:.1f}", {
            'entity': entity, 'score': score, 'evidence': evidence
        })
    
    def get_logs(self) -> List[Dict]:
        return self.logs

class ComprehensiveCorrelationEngine:
    SIGNAL_WEIGHTS = {
        SignalType.CVE: 0.18,
        SignalType.REACHABILITY: 0.15,
        SignalType.KEV: 0.12,
        SignalType.EPSS: 0.08,
        SignalType.CVSS: 0.05,
        SignalType.EXPLOIT_DB: 0.06,
        SignalType.METASPLOIT: 0.06,
        SignalType.MALWARE_PACKAGE: 0.10,
        SignalType.MALWARE_CODE: 0.05,
        SignalType.SECRET: 0.08,
        SignalType.HEALTH_MAINTENANCE: 0.04,  # Increased: unmaintained = high risk
        SignalType.HEALTH_POPULARITY: 0.02,
        SignalType.HEALTH_OUTDATED: 0.01,
        SignalType.PHANTOM_DEP: 0.06,  # INCREASED: phantom deps invisible to SCA!
        SignalType.SHADOW_IMPORT: 0.03,  # INCREASED: can cause dep confusion
        SignalType.SAST_FINDING: 0.01,
    }
    
    AMPLIFIERS = {
        'reachable': 1.0,
        'unreachable': 0.2,
        'multiple_threats': 1.5,
        'exploit_available': 2.0,
        'metasploit_available': 2.5,
        'in_kev': 3.0,
        'malware_detected': 5.0,
    }
    
    RISK_THRESHOLDS = {'CRITICAL': 75, 'HIGH': 50, 'MEDIUM': 25, 'LOW': 0}
    
    def __init__(self, call_graph: Dict = None, reachable_functions: Set = None, 
                 entrypoints: Set = None, verbose: bool = True):
        self.call_graph = call_graph or {}
        self.reachable_functions = reachable_functions or set()
        self.entrypoints = entrypoints or set()
        self.verbose = verbose
        
        # Initialize comprehensive metrics collector
        if METRICS_AVAILABLE and MetricsCollector:
            self.metrics_collector = MetricsCollector()
            self.adv_logger = MetricsLogger(verbose=verbose, metrics=self.metrics_collector)
        else:
            self.metrics_collector = None
            self.adv_logger = None
        
        # Legacy logger and metrics
        self.logger = CorrelationLogger(verbose=verbose)
        self.metrics = CorrelationMetrics()
        
        self.cve_data: Dict = {}
        self.exploitability_data: Dict = {}
        self.malware_packages: Dict = {}
        self.malware_code: Dict = {}
        self.secrets: List = []
        self.health_metrics: Dict = {}
        self.attack_surface: Dict = {}
        self.sast_findings: List = []
        self.entity_profiles: Dict[str, EntityRiskProfile] = {}
        self.attack_paths: List[AttackPath] = []
    
    def correlate(self, cve_data: Dict = None, exploitability_data: Dict = None,
                  malware_packages: Dict = None, malware_code: Dict = None,
                  secrets: List = None, health_metrics: Dict = None,
                  attack_surface: Dict = None, sast_findings: List = None) -> Dict:
        import time
        start_time = time.time()
        self.metrics.start_time = datetime.now().isoformat()
        
        self.cve_data = cve_data or {}
        self.exploitability_data = exploitability_data or {}
        self.malware_packages = malware_packages or {}
        self.malware_code = malware_code or {}
        self.secrets = secrets or []
        self.health_metrics = health_metrics or {}
        self.attack_surface = attack_surface or {}
        self.sast_findings = sast_findings or []
        
        # Log inputs using advanced logger
        if self.adv_logger:
            self.adv_logger.section("CORRELATION ENGINE v2.0")
            self.adv_logger.feature_start('cve', len(self.cve_data))
            self.adv_logger.feature_start('secrets', len(self.secrets))
            self.adv_logger.feature_start('malware_package', len(self.malware_packages))
            self.adv_logger.feature_start('health_maintenance', len(self.health_metrics))
            self.adv_logger.feature_start('phantom_deps', len(self.attack_surface.get('phantom_deps', [])))
        
        self.logger.log('INFO', 'INIT', 'Starting correlation', {
            'cves': len(self.cve_data), 'exploitability': len(self.exploitability_data),
            'malware_packages': len(self.malware_packages), 'secrets': len(self.secrets),
            'health_metrics': len(self.health_metrics)
        })
        
        self._count_inputs()
        
        # Build profiles - section headers moved inside methods (only print when data exists)
        self._build_package_profiles()
        self._build_secret_profiles()
        self._build_cwe_profiles()
        self._build_file_profiles()
        self._analyze_attack_paths()
        self._calculate_rankings()
        
        self.metrics.end_time = datetime.now().isoformat()
        self.metrics.duration_ms = (time.time() - start_time) * 1000
        self.metrics.entities_analyzed = len(self.entity_profiles)
        
        # Finalize metrics
        if self.metrics_collector:
            self.metrics_collector.attack_paths_found = len(self.attack_paths)
            self.metrics_collector.exploitable_paths = sum(1 for p in self.attack_paths if p.is_exploitable)
            self.metrics_collector.finalize()
        
        self.logger.log('INFO', 'COMPLETE', f'Correlation complete: {self.metrics.entities_analyzed} entities', {
            'critical': self.metrics.critical_entities, 'high': self.metrics.high_entities,
            'duration_ms': round(self.metrics.duration_ms, 2)
        })
        
        return self._generate_report()
    
    def _count_inputs(self):
        # CVEs
        self.metrics.total_cves = len(self.cve_data)
        for cve_id, cve in self.cve_data.items():
            if cve.get('is_reachable', False):
                self.metrics.reachable_cves += 1
        self.metrics.unreachable_cves = self.metrics.total_cves - self.metrics.reachable_cves
        
        # Secrets
        self.metrics.total_secrets = len(self.secrets)
        for secret in self.secrets:
            if secret.get('is_reachable', False):
                self.metrics.reachable_secrets += 1
        
        # Packages
        packages = set()
        for cve in self.cve_data.values():
            if cve.get('package'):
                packages.add(cve['package'])
        packages.update(self.malware_packages.keys())
        packages.update(self.health_metrics.keys())
        self.metrics.total_packages = len(packages)
        
        # Malware packages
        for pkg, malware in self.malware_packages.items():
            is_malicious = (hasattr(malware, 'is_malicious') and malware.is_malicious) or \
                          (isinstance(malware, dict) and malware.get('is_malicious'))
            if is_malicious:
                self.metrics.malicious_packages += 1
        
        # Malware code patterns
        if isinstance(self.malware_code, dict):
            self.metrics.malware_patterns = self.malware_code.get('total_patterns', 0)
        
        # Health metrics
        self.metrics.health_analyzed = len(self.health_metrics)
        
        # Attack surface
        self.metrics.phantom_deps = len(self.attack_surface.get('phantom_deps', []))
        self.metrics.shadow_imports = len(self.attack_surface.get('shadow_imports', []))
        
        # SAST
        self.metrics.sast_findings = len(self.sast_findings)
        
        # Exploitability
        for cve_id, exploit in self.exploitability_data.items():
            if exploit.get('kev', {}).get('in_catalog'):
                self.metrics.kev_matches += 1
            epss = exploit.get('epss', {}).get('score')
            if epss and epss > 0.5:
                self.metrics.epss_high += 1
            if exploit.get('exploit_db', {}).get('exploit_available'):
                self.metrics.exploit_db_available += 1
            if exploit.get('metasploit', {}).get('module_available'):
                self.metrics.metasploit_available += 1
        
        # Log input counts using advanced logger
        if self.adv_logger:
            self.adv_logger.info('INPUTS', f"CVEs: {self.metrics.total_cves} ({self.metrics.reachable_cves} reachable)")
            self.adv_logger.info('INPUTS', f"Secrets: {self.metrics.total_secrets} ({self.metrics.reachable_secrets} reachable)")
            self.adv_logger.info('INPUTS', f"Packages: {self.metrics.total_packages} ({self.metrics.malicious_packages} malicious)")
            self.adv_logger.info('INPUTS', f"Exploitability: KEV={self.metrics.kev_matches}, EPSS>0.5={self.metrics.epss_high}, Exploit-DB={self.metrics.exploit_db_available}")
            
            # Update metrics collector
            if self.metrics_collector:
                self.metrics_collector.feature_metrics['cve'].items_received = self.metrics.total_cves
                self.metrics_collector.feature_metrics['cve'].items_with_findings = self.metrics.reachable_cves
                self.metrics_collector.feature_metrics['secrets'].items_received = self.metrics.total_secrets
                self.metrics_collector.feature_metrics['secrets'].items_with_findings = self.metrics.reachable_secrets
                self.metrics_collector.feature_metrics['kev'].items_with_findings = self.metrics.kev_matches
                self.metrics_collector.feature_metrics['epss'].items_with_findings = self.metrics.epss_high
                self.metrics_collector.feature_metrics['exploit_db'].items_with_findings = self.metrics.exploit_db_available
                self.metrics_collector.feature_metrics['metasploit'].items_with_findings = self.metrics.metasploit_available
                self.metrics_collector.feature_metrics['malware_package'].items_with_findings = self.metrics.malicious_packages
                self.metrics_collector.feature_metrics['phantom_deps'].items_with_findings = self.metrics.phantom_deps
    
    def _build_package_profiles(self):
        packages = set()
        for cve in self.cve_data.values():
            if cve.get('package'):
                packages.add(cve['package'])
        packages.update(self.malware_packages.keys())
        packages.update(self.health_metrics.keys())
        for phantom in self.attack_surface.get('phantom_deps', []):
            packages.add(phantom)
        
        for pkg in packages:
            profile = self._build_single_package_profile(pkg)
            if profile and profile.final_risk_score > 0:
                self.entity_profiles[f"pkg:{pkg}"] = profile
    
    def _build_single_package_profile(self, package: str) -> Optional[EntityRiskProfile]:
        profile = EntityRiskProfile(entity_id=package, entity_type='package')
        contributions = []
        threat_types = set()
        reasoning_parts = []
        
        # CVE signals
        pkg_cves = [(cve_id, info) for cve_id, info in self.cve_data.items() if info.get('package') == package]
        
        if pkg_cves:
            threat_types.add('cve')
            severity_scores = {'CRITICAL': 100, 'HIGH': 75, 'MEDIUM': 50, 'LOW': 25}
            max_severity = 0
            max_cve = None
            is_any_reachable = False
            
            for cve_id, info in pkg_cves:
                sev = info.get('severity', 'LOW').upper()
                score = severity_scores.get(sev, 25)
                if score > max_severity:
                    max_severity = score
                    max_cve = cve_id
                if info.get('is_reachable'):
                    is_any_reachable = True
            
            weight = self.SIGNAL_WEIGHTS[SignalType.CVE]
            contributions.append(SignalContribution(
                signal_type=SignalType.CVE, raw_value=f"{len(pkg_cves)} CVEs",
                normalized_score=max_severity, weight=weight, weighted_score=max_severity * weight,
                amplifier=1.0, final_contribution=max_severity * weight,
                evidence=f"{len(pkg_cves)} CVEs, max={max_cve}", source="Grype"
            ))
            self.logger.signal('CVE', package, max_severity * weight, f"{len(pkg_cves)} CVEs")
            reasoning_parts.append(f"{len(pkg_cves)} CVEs (max: {max_cve})")
            
            # Reachability
            weight = self.SIGNAL_WEIGHTS[SignalType.REACHABILITY]
            reach_score = 100 if is_any_reachable else 0
            reach_amp = self.AMPLIFIERS['reachable'] if is_any_reachable else self.AMPLIFIERS['unreachable']
            profile.reachability_amplifier = reach_amp
            
            if is_any_reachable:
                self.metrics.reachability_amplified += 1
                reasoning_parts.append("REACHABLE from entrypoints")
            else:
                reasoning_parts.append("NOT reachable (80% reduction)")
            
            contributions.append(SignalContribution(
                signal_type=SignalType.REACHABILITY, raw_value=is_any_reachable,
                normalized_score=reach_score, weight=weight, weighted_score=reach_score * weight,
                amplifier=reach_amp, final_contribution=reach_score * weight * reach_amp,
                evidence="Reachable" if is_any_reachable else "Unreachable", source="REACHABLE AST"
            ))
            
            # Exploitability signals
            for cve_id, info in pkg_cves:
                exploit = self.exploitability_data.get(cve_id, {})
                
                # KEV
                if exploit.get('kev', {}).get('in_catalog'):
                    threat_types.add('kev')
                    profile.kev_amplifier = self.AMPLIFIERS['in_kev']
                    self.metrics.kev_amplified += 1
                    weight = self.SIGNAL_WEIGHTS[SignalType.KEV]
                    contributions.append(SignalContribution(
                        signal_type=SignalType.KEV, raw_value=True, normalized_score=100,
                        weight=weight, weighted_score=100 * weight,
                        amplifier=self.AMPLIFIERS['in_kev'],
                        final_contribution=100 * weight * self.AMPLIFIERS['in_kev'],
                        evidence=f"{cve_id} in CISA KEV", source="CISA KEV"
                    ))
                    reasoning_parts.append(f"⚠️ {cve_id} IN KEV (3× amplifier)")
                
                # EPSS
                epss_score = exploit.get('epss', {}).get('score')
                if epss_score is not None:
                    epss_norm = epss_score * 100
                    weight = self.SIGNAL_WEIGHTS[SignalType.EPSS]
                    contributions.append(SignalContribution(
                        signal_type=SignalType.EPSS, raw_value=epss_score,
                        normalized_score=epss_norm, weight=weight, weighted_score=epss_norm * weight,
                        amplifier=1.0, final_contribution=epss_norm * weight,
                        evidence=f"EPSS: {epss_score:.4f}", source="FIRST EPSS"
                    ))
                    if epss_score > 0.5:
                        reasoning_parts.append(f"High EPSS: {epss_score:.2%}")
                
                # CVSS
                cvss_score = exploit.get('cvss', {}).get('score')
                if cvss_score:
                    cvss_norm = cvss_score * 10
                    weight = self.SIGNAL_WEIGHTS[SignalType.CVSS]
                    contributions.append(SignalContribution(
                        signal_type=SignalType.CVSS, raw_value=cvss_score,
                        normalized_score=cvss_norm, weight=weight, weighted_score=cvss_norm * weight,
                        amplifier=1.0, final_contribution=cvss_norm * weight,
                        evidence=f"CVSS: {cvss_score}", source="NVD"
                    ))
                
                # Exploit-DB
                if exploit.get('exploit_db', {}).get('exploit_available'):
                    threat_types.add('public_exploit')
                    profile.exploit_amplifier = max(profile.exploit_amplifier, self.AMPLIFIERS['exploit_available'])
                    self.metrics.exploit_amplified += 1
                    weight = self.SIGNAL_WEIGHTS[SignalType.EXPLOIT_DB]
                    contributions.append(SignalContribution(
                        signal_type=SignalType.EXPLOIT_DB, raw_value=True, normalized_score=100,
                        weight=weight, weighted_score=100 * weight,
                        amplifier=self.AMPLIFIERS['exploit_available'],
                        final_contribution=100 * weight * self.AMPLIFIERS['exploit_available'],
                        evidence=f"Public exploit for {cve_id}", source="Exploit-DB"
                    ))
                    reasoning_parts.append("Public exploit (2× amplifier)")
                
                # Metasploit
                if exploit.get('metasploit', {}).get('module_available'):
                    threat_types.add('metasploit')
                    profile.exploit_amplifier = max(profile.exploit_amplifier, self.AMPLIFIERS['metasploit_available'])
                    weight = self.SIGNAL_WEIGHTS[SignalType.METASPLOIT]
                    contributions.append(SignalContribution(
                        signal_type=SignalType.METASPLOIT, raw_value=True, normalized_score=100,
                        weight=weight, weighted_score=100 * weight,
                        amplifier=self.AMPLIFIERS['metasploit_available'],
                        final_contribution=100 * weight * self.AMPLIFIERS['metasploit_available'],
                        evidence=f"Metasploit module", source="Metasploit"
                    ))
                    reasoning_parts.append("Metasploit module (2.5× amplifier)")
        
        # Malware signals
        malware = self.malware_packages.get(package)
        if malware:
            is_malicious = getattr(malware, 'is_malicious', False) if hasattr(malware, 'is_malicious') else malware.get('is_malicious', False)
            if is_malicious:
                threat_types.add('malware')
                profile.malware_amplifier = self.AMPLIFIERS['malware_detected']
                weight = self.SIGNAL_WEIGHTS[SignalType.MALWARE_PACKAGE]
                risk_level = getattr(malware, 'risk_level', 'HIGH') if hasattr(malware, 'risk_level') else malware.get('risk_level', 'HIGH')
                malware_score = {'CRITICAL': 100, 'HIGH': 80, 'MEDIUM': 50, 'LOW': 25}.get(risk_level, 50)
                contributions.append(SignalContribution(
                    signal_type=SignalType.MALWARE_PACKAGE, raw_value=risk_level,
                    normalized_score=malware_score, weight=weight, weighted_score=malware_score * weight,
                    amplifier=self.AMPLIFIERS['malware_detected'],
                    final_contribution=malware_score * weight * self.AMPLIFIERS['malware_detected'],
                    evidence=f"Malicious: {risk_level}", source="GuardDog"
                ))
                reasoning_parts.append(f"🚨 MALICIOUS ({risk_level}) - 5× amplifier")
        
        # Health metrics
        health = self.health_metrics.get(package)
        if health:
            maint_risk = getattr(health, 'maintenance_risk', None) or (health.get('maintenance_risk') if isinstance(health, dict) else None)
            if maint_risk:
                maint_scores = {'CRITICAL': 100, 'RISKY': 60, 'HEALTHY': 0, 'UNKNOWN': 20}
                maint_score = maint_scores.get(maint_risk, 20)
                if maint_score > 0:
                    weight = self.SIGNAL_WEIGHTS[SignalType.HEALTH_MAINTENANCE]
                    contributions.append(SignalContribution(
                        signal_type=SignalType.HEALTH_MAINTENANCE, raw_value=maint_risk,
                        normalized_score=maint_score, weight=weight, weighted_score=maint_score * weight,
                        amplifier=1.0, final_contribution=maint_score * weight,
                        evidence=f"Maintenance: {maint_risk}", source="Health Analyzer"
                    ))
                    if maint_risk == 'CRITICAL':
                        threat_types.add('unmaintained')
                        reasoning_parts.append("UNMAINTAINED (>2 years)")
        
        # Phantom dependency
        if package in self.attack_surface.get('phantom_deps', []):
            threat_types.add('phantom')
            weight = self.SIGNAL_WEIGHTS[SignalType.PHANTOM_DEP]
            contributions.append(SignalContribution(
                signal_type=SignalType.PHANTOM_DEP, raw_value=True,
                normalized_score=100, weight=weight, weighted_score=100 * weight,
                amplifier=1.0, final_contribution=100 * weight,
                evidence="Phantom dep - not in manifest", source="Import Analyzer"
            ))
            reasoning_parts.append("PHANTOM DEP - invisible to SCA")
        
        # Correlation amplifier
        if len(threat_types) > 1:
            profile.correlation_amplifier = self.AMPLIFIERS['multiple_threats']
            self.metrics.correlation_amplified += 1
            reasoning_parts.append(f"Multiple threats ({len(threat_types)}) - 1.5× amplifier")
        
        # Calculate scores
        profile.signal_contributions = contributions
        profile.threat_types = list(threat_types)
        profile.base_risk_score = sum(c.weighted_score for c in contributions)
        
        total_amp = (profile.reachability_amplifier * profile.correlation_amplifier *
                    profile.exploit_amplifier * profile.kev_amplifier * profile.malware_amplifier)
        profile.amplified_risk_score = profile.base_risk_score * total_amp
        profile.final_risk_score = min(100, profile.amplified_risk_score)
        
        if profile.final_risk_score >= self.RISK_THRESHOLDS['CRITICAL']:
            profile.risk_level = 'CRITICAL'
            self.metrics.critical_entities += 1
        elif profile.final_risk_score >= self.RISK_THRESHOLDS['HIGH']:
            profile.risk_level = 'HIGH'
            self.metrics.high_entities += 1
        elif profile.final_risk_score >= self.RISK_THRESHOLDS['MEDIUM']:
            profile.risk_level = 'MEDIUM'
            self.metrics.medium_entities += 1
        else:
            profile.risk_level = 'LOW'
            self.metrics.low_entities += 1
        
        profile.correlation_reasoning = " | ".join(reasoning_parts) if reasoning_parts else "No signals"
        profile.remediation_priority = profile.risk_level
        
        # Populate package metadata
        profile.package_name = package
        
        # Get fix info and call paths from CVE data
        if pkg_cves:
            # Get the highest severity CVE's fix info
            best_cve_id = max_cve
            best_cve_info = next((info for cve_id, info in pkg_cves if cve_id == best_cve_id), {})
            
            profile.package_version = best_cve_info.get('version', '')
            profile.cvss_score = best_cve_info.get('cvss_score', 0) or 0
            profile.severity = best_cve_info.get('severity', '').upper()
            
            # Get fix versions
            fix_versions = best_cve_info.get('fix_versions', [])
            if fix_versions:
                profile.fix_version = fix_versions[0] if isinstance(fix_versions, list) else fix_versions
            
            # Extract call paths from vulnerable_functions_detail
            call_paths_set = set()
            affected_funcs_set = set()
            
            for cve_id, info in pkg_cves:
                # Get reachable functions
                reachable_funcs = info.get('reachable_functions', [])
                for func in reachable_funcs[:5]:  # Limit to top 5
                    affected_funcs_set.add(func)
                
                # Get call paths from vulnerable_functions_detail
                vuln_details = info.get('vulnerable_functions_detail', [])
                for vfd in vuln_details:
                    reach = vfd.get('reachability', {})
                    call_path = reach.get('call_path')
                    if call_path:
                        call_paths_set.add(call_path)
            
            profile.call_paths = list(call_paths_set)[:5]  # Limit to 5 paths
            profile.affected_functions = list(affected_funcs_set)[:10]  # Limit to 10 functions
            
            # Build description from CVE data
            desc_parts = []
            for cve_id, info in pkg_cves[:3]:
                cve_desc = info.get('description', '')[:100] if info.get('description') else ''
                if cve_desc:
                    desc_parts.append(f"{cve_id}: {cve_desc}")
            profile.description = " | ".join(desc_parts) if desc_parts else f"{len(pkg_cves)} CVEs in {package}"
        
        if 'kev' in threat_types:
            profile.remediation_actions.append("IMMEDIATE: Patch KEV CVE within 24-72h")
        if 'malware' in threat_types:
            profile.remediation_actions.append("CRITICAL: Remove malicious package")
        if 'cve' in threat_types:
            if profile.fix_version:
                profile.remediation_actions.append(f"Upgrade {package} to {profile.fix_version}")
            else:
                profile.remediation_actions.append("Check for patched version or apply workaround")
        if 'unmaintained' in threat_types:
            profile.remediation_actions.append("Consider replacing unmaintained package")
        if 'phantom' in threat_types:
            profile.remediation_actions.append(f"Add {package} to requirements/package.json manifest")
        
        return profile
    
    def _build_secret_profiles(self):
        for secret in self.secrets:
            # CRITICAL: Only process ACTUAL secrets, not CWE code findings
            # CWE findings (is_actual_secret=False) should NOT be labeled as "SECRET"
            is_actual_secret = secret.get('is_actual_secret', False)
            if not is_actual_secret:
                continue  # Skip CWE findings - they are code issues, not credentials
            
            file_path = secret.get('path', '') or secret.get('file', '')
            line = secret.get('line', 0)
            is_reachable = secret.get('is_reachable', False)
            severity = secret.get('severity', 'warning')
            secret_type = secret.get('check_id', '') or secret.get('rule_id', '') or secret.get('secret_type', 'unknown')
            message = secret.get('message', '') or secret.get('description', '')
            
            entity_id = f"{file_path}:{line}"
            if f"secret:{entity_id}" in self.entity_profiles:
                continue
            
            profile = EntityRiskProfile(entity_id=entity_id, entity_type='secret')
            
            # Populate metadata
            profile.file_path = file_path
            profile.line_number = line
            profile.secret_type = secret_type
            profile.description = message[:500] if message else f"Hardcoded {secret_type} detected"
            profile.severity = severity.upper()
            
            secret_scores = {'error': 100, 'warning': 60, 'info': 30}
            secret_score = secret_scores.get(severity.lower(), 60)
            weight = self.SIGNAL_WEIGHTS[SignalType.SECRET]
            
            profile.signal_contributions.append(SignalContribution(
                signal_type=SignalType.SECRET, raw_value=secret.get('check_id', 'secret'),
                normalized_score=secret_score, weight=weight, weighted_score=secret_score * weight,
                amplifier=1.0, final_contribution=secret_score * weight,
                evidence=f"Secret: {secret_type}", source="Semgrep"
            ))
            
            reach_weight = self.SIGNAL_WEIGHTS[SignalType.REACHABILITY]
            reach_score = 100 if is_reachable else 0
            reach_amp = self.AMPLIFIERS['reachable'] if is_reachable else self.AMPLIFIERS['unreachable']
            profile.reachability_amplifier = reach_amp
            
            profile.signal_contributions.append(SignalContribution(
                signal_type=SignalType.REACHABILITY, raw_value=is_reachable,
                normalized_score=reach_score, weight=reach_weight, weighted_score=reach_score * reach_weight,
                amplifier=reach_amp, final_contribution=reach_score * reach_weight * reach_amp,
                evidence="Reachable" if is_reachable else "Unreachable", source="REACHABLE AST"
            ))
            
            profile.threat_types = ['secret']
            profile.base_risk_score = sum(c.weighted_score for c in profile.signal_contributions)
            profile.amplified_risk_score = profile.base_risk_score * profile.reachability_amplifier
            profile.final_risk_score = min(100, profile.amplified_risk_score)
            
            # Set verification status from TruffleHog (if available)
            # 'verified' field from TruffleHog means the secret was tested and IS ACTIVE
            verified = secret.get('verified', None)
            if verified is True:
                profile.is_active = True
                profile.verification_status = "ACTIVE"
            elif verified is False:
                profile.is_active = False
                profile.verification_status = "INACTIVE"
            else:
                profile.is_active = None
                profile.verification_status = "UNVERIFIED"
            
            # v4.5.25: Set risk_level and severity based on reachability + verification
            # Reachable + Active = CRITICAL (confirmed exposure)
            # Reachable + Unverified = CRITICAL (assume active until proven otherwise - worst case)
            # Reachable + Inactive = LOW (already revoked, cleanup only)
            # Unreachable = demoted to LOW
            if is_reachable:
                if profile.verification_status == "ACTIVE":
                    profile.risk_level = 'CRITICAL'
                    profile.severity = 'CRITICAL'
                elif profile.verification_status == "INACTIVE":
                    profile.risk_level = 'LOW'
                    profile.severity = 'LOW'
                else:  # UNVERIFIED - assume worst case = CRITICAL
                    profile.risk_level = 'CRITICAL'
                    profile.severity = 'CRITICAL'
            else:
                # Unreachable secrets - demote severity
                profile.risk_level = 'LOW'
                profile.severity = 'LOW'
            
            # ONLY add remediation guidance for REACHABLE secrets
            profile.remediation_priority = profile.risk_level if is_reachable else ""
            file_name = file_path.split('/')[-1] if file_path else 'file'
            
            if is_reachable:
                # Remediation depends on verification status
                if profile.verification_status == "ACTIVE":
                    # CRITICAL: Secret is confirmed active - must act immediately
                    profile.remediation_actions = [
                        f"⚠️ VERIFIED ACTIVE - IMMEDIATE ACTION REQUIRED",
                        f"1. REVOKE: Immediately invalidate this credential NOW",
                        f"2. ROTATE: Generate new credentials and update all systems",
                        f"3. SECURE: Move to secrets manager (Vault, AWS Secrets Manager)",
                        f"4. AUDIT: Check for unauthorized access using this credential"
                    ]
                elif profile.verification_status == "INACTIVE":
                    # Secret already revoked/expired - lower priority
                    profile.remediation_actions = [
                        f"✓ VERIFIED INACTIVE - Secret is no longer valid",
                        f"1. SECURE: Ensure new credentials are in secrets manager",
                        f"2. CLEANUP: Remove hardcoded value from source code",
                        f"(Optional) Clean git history if compliance requires it"
                    ]
                else:
                    # Unverified - assume active until proven otherwise
                    profile.remediation_actions = [
                        f"1. REVOKE: Immediately invalidate this credential in provider dashboard",
                        f"2. ROTATE: Generate new credentials and update all systems",
                        f"3. SECURE: Move to secrets manager (Vault, AWS Secrets Manager)",
                        f"4. VERIFY: Run 'trufflehog --only-verified' to check if active",
                        f"(Optional) Clean git history if compliance requires it"
                    ]
            # Unreachable secrets: no remediation actions (lower priority)
            
            profile.correlation_reasoning = f"Secret ({severity}) {'reachable' if is_reachable else 'unreachable'}"
            
            if profile.final_risk_score > 0:
                self.entity_profiles[f"secret:{entity_id}"] = profile
    
    def _build_cwe_profiles(self):
        """Build profiles for CWE code security findings (NOT secrets)."""
        for finding in self.secrets:
            # ONLY process CWE findings (is_actual_secret=False)
            is_actual_secret = finding.get('is_actual_secret', False)
            if is_actual_secret:
                continue  # Skip actual secrets - they're handled in _build_secret_profiles
            
            file_path = finding.get('path', '') or finding.get('file', '')
            line = finding.get('line', 0)
            is_reachable = finding.get('is_reachable', False)
            severity = finding.get('severity', 'warning')
            rule_id = finding.get('rule_id', '') or finding.get('check_id', '')
            message = finding.get('message', '') or finding.get('description', '')
            cwe_id = finding.get('cwe_id', 'CWE-Unknown')
            
            entity_id = f"{file_path}:{line}"
            if f"cwe:{entity_id}" in self.entity_profiles or f"config:{entity_id}" in self.entity_profiles:
                continue
            
            # v4.4.0: Detect platform/config files vs app code
            is_platform_code = self._is_platform_code(file_path, rule_id)
            
            if is_platform_code:
                # Platform/config code - UNKNOWN reachability
                profile = EntityRiskProfile(entity_id=entity_id, entity_type='config')
                profile.threat_types = ['config']
                reach_amp = 1.0  # No amplification for config (unknown reachability)
                reachability_label = "Unknown (platform code)"
            else:
                # App code - standard reachability analysis
                profile = EntityRiskProfile(entity_id=entity_id, entity_type='cwe')
                profile.threat_types = ['cwe']
                reach_amp = self.AMPLIFIERS['reachable'] if is_reachable else self.AMPLIFIERS['unreachable']
                reachability_label = "Reachable" if is_reachable else "Unreachable"
            
            # Populate metadata
            profile.file_path = file_path
            profile.line_number = line
            profile.secret_type = rule_id  # Using secret_type field for rule_id
            profile.description = message[:500] if message else f"Code weakness: {rule_id}"
            profile.severity = severity.upper()
            
            # CWE/Config scoring - lower than secrets since these are code issues, not credentials
            cwe_scores = {'error': 70, 'warning': 40, 'info': 20}
            cwe_score = cwe_scores.get(severity.lower(), 40)
            weight = self.SIGNAL_WEIGHTS.get(SignalType.SECRET, 0.08)  # Use lower weight
            
            profile.signal_contributions.append(SignalContribution(
                signal_type=SignalType.SECRET, raw_value=rule_id,
                normalized_score=cwe_score, weight=weight, weighted_score=cwe_score * weight,
                amplifier=1.0, final_contribution=cwe_score * weight,
                evidence=f"{'CONFIG' if is_platform_code else 'CWE'}: {rule_id}", source="Semgrep"
            ))
            
            reach_weight = self.SIGNAL_WEIGHTS[SignalType.REACHABILITY]
            reach_score = 100 if is_reachable and not is_platform_code else 0
            profile.reachability_amplifier = reach_amp
            
            profile.signal_contributions.append(SignalContribution(
                signal_type=SignalType.REACHABILITY, raw_value=is_reachable if not is_platform_code else 'unknown',
                normalized_score=reach_score, weight=reach_weight, weighted_score=reach_score * reach_weight,
                amplifier=reach_amp, final_contribution=reach_score * reach_weight * reach_amp,
                evidence=reachability_label, source="REACHABLE AST"
            ))
            
            profile.base_risk_score = sum(c.weighted_score for c in profile.signal_contributions)
            profile.amplified_risk_score = profile.base_risk_score * profile.reachability_amplifier
            profile.final_risk_score = min(100, profile.amplified_risk_score)
            
            if profile.final_risk_score >= self.RISK_THRESHOLDS['HIGH']:
                profile.risk_level = 'HIGH'
            elif profile.final_risk_score >= self.RISK_THRESHOLDS['MEDIUM']:
                profile.risk_level = 'MEDIUM'
            else:
                profile.risk_level = 'LOW'
            
            # Remediation depends on type
            if is_platform_code:
                # Config/platform issues - reachability is UNKNOWN
                profile.remediation_actions = [
                    f"1. REVIEW: Assess environment-specific impact at {file_path}:{line}",
                    f"2. FIX: Address the configuration issue based on deployment context",
                    f"3. VERIFY: Check runtime security controls (e.g., PodSecurityPolicy, AppArmor)"
                ]
                profile.correlation_reasoning = f"CONFIG ({severity}) - reachability UNKNOWN (platform code)"
            elif is_reachable:
                profile.remediation_actions = [
                    f"1. FIX: Address the code weakness at {file_path}:{line}",
                    f"2. REVIEW: Check for similar patterns in codebase",
                    f"3. TEST: Add security tests to prevent regression"
                ]
                profile.correlation_reasoning = f"CWE ({severity}) reachable"
            else:
                profile.remediation_actions = [
                    f"1. MONITOR: Track code weakness at {file_path}:{line}",
                    f"2. DEPRIORITIZE: Code path is not reachable from entrypoints"
                ]
                profile.correlation_reasoning = f"CWE ({severity}) unreachable"
            
            # Use appropriate key for entity type
            entity_key = f"config:{entity_id}" if is_platform_code else f"cwe:{entity_id}"
            if profile.final_risk_score > 0:
                self.entity_profiles[entity_key] = profile
    
    def _is_platform_code(self, file_path: str, rule_id: str) -> bool:
        """
        Determine if a finding is in platform/infrastructure code vs application code.
        
        Platform code has UNKNOWN reachability because its exploitability depends on
        the deployment environment, not code paths.
        
        v4.4.0: Two-dimensional risk assessment
        - App code: standard reachability analysis
        - Platform code: reachability = UNKNOWN, severity = standard
        """
        file_lower = (file_path or '').lower()
        rule_lower = (rule_id or '').lower()
        
        # Platform file patterns
        platform_file_patterns = [
            'dockerfile', '.docker',
            '.yaml', '.yml',
            '.tf', '.hcl', 'terraform',
            'kubernetes', 'k8s', 'kustomize',
            'helm/', 'charts/',
            'compose', 'docker-compose',
            '.json',  # Often config files
            'ansible/', 'playbook',
            'cloudformation', '.cfn',
        ]
        
        # Platform rule patterns (Semgrep rule IDs)
        platform_rule_patterns = [
            'dockerfile.', 'docker.',
            'kubernetes.', 'k8s.',
            'terraform.', 'tf.',
            'yaml.', 'yml.',
            'helm.', 'chart.',
            'config.', 'misconfig',
            'container.', 'pod.',
            'cloud.', 'aws.', 'gcp.', 'azure.',
            'iam.', 'securitygroup',
            'missing-user', 'privileged', 'root-user',
        ]
        
        # Check file path
        if any(p in file_lower for p in platform_file_patterns):
            return True
        
        # Check rule ID
        if any(r in rule_lower for r in platform_rule_patterns):
            return True
        
        return False
    
    def _build_file_profiles(self):
        if not isinstance(self.malware_code, dict):
            return
        
        patterns = self.malware_code.get('patterns', [])
        for pattern in patterns:
            file_path = pattern.get('file', '')
            if not file_path or f"file:{file_path}" in self.entity_profiles:
                continue
            
            profile = EntityRiskProfile(entity_id=file_path, entity_type='file')
            category = pattern.get('category', 'unknown')
            risk_weight = pattern.get('risk_weight', 10)
            weight = self.SIGNAL_WEIGHTS[SignalType.MALWARE_CODE]
            score = min(100, risk_weight * 10)
            
            profile.signal_contributions.append(SignalContribution(
                signal_type=SignalType.MALWARE_CODE, raw_value=category,
                normalized_score=score, weight=weight, weighted_score=score * weight,
                amplifier=1.0, final_contribution=score * weight,
                evidence=f"Pattern: {category}", source="Semgrep Malware"
            ))
            
            profile.threat_types = ['malware_code']
            profile.base_risk_score = score * weight
            profile.final_risk_score = min(100, profile.base_risk_score)
            profile.correlation_reasoning = f"Malware pattern: {category}"
            
            if profile.final_risk_score > 0:
                self.entity_profiles[f"file:{file_path}"] = profile
    
    def _analyze_attack_paths(self):
        path_count = 0
        for entity_key, profile in self.entity_profiles.items():
            if profile.entity_type != 'package' or profile.risk_level not in ['CRITICAL', 'HIGH']:
                continue
            
            pkg = profile.entity_id
            pkg_cves = [(cve_id, info) for cve_id, info in self.cve_data.items()
                       if info.get('package') == pkg and info.get('is_reachable')]
            
            if pkg_cves:
                for cve_id, info in pkg_cves[:3]:
                    funcs = info.get('affected_functions', [])
                    path_count += 1
                    path = AttackPath(
                        path_id=f"path_{path_count}",
                        entry_point=list(self.entrypoints)[0] if self.entrypoints else "main",
                        exit_point=funcs[0] if funcs else pkg,
                        stages=[
                            {'type': 'entry', 'location': 'entrypoint'},
                            {'type': 'call_chain', 'through': 'reachable code'},
                            {'type': 'vulnerability', 'cve': cve_id, 'package': pkg}
                        ],
                        total_risk=profile.final_risk_score,
                        threat_count=len(profile.threat_types),
                        is_exploitable='public_exploit' in profile.threat_types or 'metasploit' in profile.threat_types,
                        exploit_chain=[cve_id],
                        recommendation=f"Patch {cve_id} in {pkg}"
                    )
                    self.attack_paths.append(path)
        
        self.metrics.attack_paths_found = len(self.attack_paths)
        self.metrics.exploitable_paths = sum(1 for p in self.attack_paths if p.is_exploitable)
    
    def _calculate_rankings(self):
        sorted_entities = sorted(self.entity_profiles.values(), key=lambda p: (-p.final_risk_score, -len(p.threat_types)))
        for rank, profile in enumerate(sorted_entities, 1):
            profile.priority_rank = rank
    
    def _generate_report(self) -> Dict:
        sorted_profiles = sorted(self.entity_profiles.values(), key=lambda p: -p.final_risk_score)
        
        # Get comprehensive metrics if available
        detailed_metrics = None
        feature_status = []
        amplifier_usage = []
        correlation_logs = []
        
        if self.metrics_collector:
            detailed_metrics = self.metrics_collector.to_dict()
            
            # Build feature status for dashboard
            for key, fm in self.metrics_collector.feature_metrics.items():
                fm_dict = fm.to_dict()
                feature_status.append({
                    'name': fm.feature_name,
                    'key': key,
                    'enabled': fm.enabled,
                    'items': fm.items_received,
                    'findings': fm.items_with_findings,
                    'signals': fm.signals_generated,
                    'contribution': round(fm.total_score_contribution, 2),
                    'status': 'active' if fm.items_with_findings > 0 else 'enabled'
                })
            
            # Build amplifier usage for dashboard
            for key, am in self.metrics_collector.amplifier_metrics.items():
                if am.times_applied > 0:
                    amplifier_usage.append({
                        'name': am.amplifier_name,
                        'key': key,
                        'multiplier': am.multiplier,
                        'times_applied': am.times_applied,
                        'entities': am.entities_affected[:10],
                        'total_boost': round(am.total_score_boost, 2)
                    })
            
            # Get recent logs
            correlation_logs = self.metrics_collector.get_logs(limit=100)
        
        return {
            'correlation_version': '2.0',
            'generated_at': datetime.now().isoformat(),
            'summary': {
                'total_entities': len(self.entity_profiles),
                'by_risk_level': {
                    'critical': self.metrics.critical_entities,
                    'high': self.metrics.high_entities,
                    'medium': self.metrics.medium_entities,
                    'low': self.metrics.low_entities
                },
                'inputs_processed': {
                    'cves': self.metrics.total_cves,
                    'reachable_cves': self.metrics.reachable_cves,
                    'secrets': self.metrics.total_secrets,
                    'packages': self.metrics.total_packages,
                    'health_metrics': self.metrics.health_analyzed,
                    'malware_patterns': self.metrics.malware_patterns,
                    'phantom_deps': self.metrics.phantom_deps,
                    'shadow_imports': self.metrics.shadow_imports,
                    'sast_findings': self.metrics.sast_findings
                },
                'exploitability': {
                    'kev_matches': self.metrics.kev_matches,
                    'epss_high': self.metrics.epss_high,
                    'exploit_db': self.metrics.exploit_db_available,
                    'metasploit': self.metrics.metasploit_available
                },
                'amplifications_applied': {
                    'kev': self.metrics.kev_amplified,
                    'exploit': self.metrics.exploit_amplified,
                    'correlation': self.metrics.correlation_amplified,
                    'reachability': self.metrics.reachability_amplified
                },
                'attack_paths': self.metrics.attack_paths_found,
                'exploitable_paths': self.metrics.exploitable_paths
            },
            'metrics': self.metrics.to_dict(),
            'detailed_metrics': detailed_metrics,
            'feature_status': feature_status,
            'amplifier_usage': amplifier_usage,
            'signal_weights': {k.value: v for k, v in self.SIGNAL_WEIGHTS.items()},
            'amplifiers': self.AMPLIFIERS,
            'risk_thresholds': self.RISK_THRESHOLDS,
            'top_risks': [p.to_dict() for p in sorted_profiles[:20]],
            'packages': {k.replace('pkg:', ''): v.to_dict() for k, v in self.entity_profiles.items() if v.entity_type == 'package'},
            'secrets': {k.replace('secret:', ''): v.to_dict() for k, v in self.entity_profiles.items() if v.entity_type == 'secret'},
            'files': {k.replace('file:', ''): v.to_dict() for k, v in self.entity_profiles.items() if v.entity_type == 'file'},
            'attack_paths': [p.to_dict() for p in self.attack_paths],
            'audit_log': self.logger.get_logs(),
            'correlation_logs': correlation_logs
        }

def correlate_all_signals(cve_data=None, exploitability_data=None, malware_packages=None,
                          malware_code=None, secrets=None, health_metrics=None,
                          attack_surface=None, call_graph=None, reachable_functions=None,
                          entrypoints=None, verbose=True) -> Dict:
    engine = ComprehensiveCorrelationEngine(
        call_graph=call_graph, reachable_functions=reachable_functions,
        entrypoints=entrypoints, verbose=verbose
    )
    return engine.correlate(
        cve_data=cve_data, exploitability_data=exploitability_data,
        malware_packages=malware_packages, malware_code=malware_code,
        secrets=secrets, health_metrics=health_metrics, attack_surface=attack_surface
    )

if __name__ == '__main__':
    print("=" * 70)
    print("REACHABLE Correlation Engine v2.0 - Demo")
    print("=" * 70)
    
    sample_cves = {
        'CVE-2023-1234': {'package': 'urllib3', 'severity': 'CRITICAL', 'is_reachable': True},
        'CVE-2023-5678': {'package': 'requests', 'severity': 'HIGH', 'is_reachable': False}
    }
    sample_exploitability = {
        'CVE-2023-1234': {'kev': {'in_catalog': True}, 'epss': {'score': 0.85}, 'exploit_db': {'exploit_available': True}}
    }
    sample_secrets = [{'path': 'config.py', 'line': 10, 'is_reachable': True, 'severity': 'error'}]
    
    result = correlate_all_signals(
        cve_data=sample_cves, exploitability_data=sample_exploitability,
        secrets=sample_secrets, verbose=True
    )
    
    print("\n" + "=" * 70)
    print("RESULTS SUMMARY")
    print("=" * 70)
    print(json.dumps(result['summary'], indent=2))
