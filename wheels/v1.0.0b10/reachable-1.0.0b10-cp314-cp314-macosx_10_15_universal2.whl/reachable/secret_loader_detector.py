#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.

"""
REACHABLE Secret Loader Detector (Policy SECRET-REACH-001)

Detects code patterns that LOAD secrets from environment variables, config files,
SDKs, or file system. Maps these loaders to the call graph to determine if secrets
are actually reachable from application entrypoints.

VERSION: 1.0.0
"""

import os
import re
import ast
import time
from pathlib import Path
from typing import Dict, List, Set, Optional, Tuple, Any
from dataclasses import dataclass, field
from enum import Enum


class LoaderType(Enum):
    ENV_VAR = "env_var"
    DOTENV = "dotenv"
    CONFIG_FILE = "config_file"
    SDK_AWS = "sdk_aws"
    SDK_GCP = "sdk_gcp"
    SDK_AZURE = "sdk_azure"
    SDK_STRIPE = "sdk_stripe"
    SDK_TWILIO = "sdk_twilio"
    SDK_SENDGRID = "sdk_sendgrid"
    SDK_OPENAI = "sdk_openai"
    SDK_GITHUB = "sdk_github"
    SDK_SLACK = "sdk_slack"
    PRIVATE_KEY_FILE = "private_key_file"
    JWT_SIGNING = "jwt_signing"
    SSH_KEY = "ssh_key"
    DATABASE_URL = "database_url"
    VIPER = "viper"
    SPRING = "spring"
    UNKNOWN = "unknown"


class LoadableStatus(Enum):
    YES = "yes"
    NO = "no"
    UNKNOWN = "unknown"


class ReachabilityStatus(Enum):
    REACHABLE = "reachable"
    NOT_REACHABLE = "not_reachable"
    UNKNOWN = "unknown"


@dataclass
class LoaderFinding:
    file_path: str
    line_number: int
    column: int
    function_name: Optional[str]
    class_name: Optional[str]
    loader_type: LoaderType
    secret_names: List[str]
    pattern_matched: str
    language: str
    is_import_time: bool = False
    sdk_secrets: List[str] = field(default_factory=list)
    is_reachable: Optional[bool] = None
    reachable_via: List[str] = field(default_factory=list)
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'file': self.file_path,
            'line': self.line_number,
            'column': self.column,
            'function': self.function_name,
            'class': self.class_name,
            'loader_type': self.loader_type.value,
            'secret_names': self.secret_names,
            'pattern': self.pattern_matched,
            'language': self.language,
            'is_import_time': self.is_import_time,
            'sdk_secrets': self.sdk_secrets,
            'is_reachable': self.is_reachable,
            'reachable_via': self.reachable_via,
        }


@dataclass
class SecretLoaderResult:
    total_files_scanned: int = 0
    total_loaders_found: int = 0
    loaders: List[LoaderFinding] = field(default_factory=list)
    secrets_with_loaders: Dict[str, List[LoaderFinding]] = field(default_factory=dict)
    secret_loadable_status: Dict[str, LoadableStatus] = field(default_factory=dict)
    secret_reachability_status: Dict[str, ReachabilityStatus] = field(default_factory=dict)
    reachable_secrets: Set[str] = field(default_factory=set)
    unreachable_secrets: Set[str] = field(default_factory=set)
    unknown_secrets: Set[str] = field(default_factory=set)
    sdk_implicit_secrets: Dict[str, List[str]] = field(default_factory=dict)
    scan_time_ms: float = 0.0
    errors: List[str] = field(default_factory=list)
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'policy': 'SECRET-REACH-001',
            'total_files_scanned': self.total_files_scanned,
            'total_loaders_found': self.total_loaders_found,
            'loaders': [l.to_dict() for l in self.loaders],
            'secrets_with_loaders': {k: [l.to_dict() for l in v] for k, v in self.secrets_with_loaders.items()},
            'summary': {
                'reachable': list(self.reachable_secrets),
                'unreachable': list(self.unreachable_secrets),
                'unknown': list(self.unknown_secrets),
            },
            'sdk_implicit_secrets': self.sdk_implicit_secrets,
            'scan_time_ms': round(self.scan_time_ms, 2),
        }


# Python env patterns: (regex, pattern_name)
PYTHON_ENV_PATTERNS = [
    (r"os\.getenv\s*\(\s*['\"]([^'\"]+)['\"]", "os.getenv"),
    (r"os\.environ\s*\[\s*['\"]([^'\"]+)['\"]", "os.environ[]"),
    (r"os\.environ\.get\s*\(\s*['\"]([^'\"]+)['\"]", "os.environ.get"),
    (r"(?<![a-zA-Z_])environ\s*\[\s*['\"]([^'\"]+)['\"]", "environ[]"),
    (r"(?<![a-zA-Z_])environ\.get\s*\(\s*['\"]([^'\"]+)['\"]", "environ.get"),
    (r"(?<![a-zA-Z_.])getenv\s*\(\s*['\"]([^'\"]+)['\"]", "getenv"),
]

PYTHON_DOTENV_PATTERNS = [
    (r"load_dotenv\s*\(", "load_dotenv"),
    (r"dotenv\.get_key\s*\([^,]+,\s*['\"]([^'\"]+)['\"]", "dotenv.get_key"),
]

JAVASCRIPT_ENV_PATTERNS = [
    (r"process\.env\.([A-Z_][A-Z0-9_]*)", "process.env"),
    (r"process\.env\s*\[\s*['\"]([^'\"]+)['\"]", "process.env[]"),
    (r"const\s*\{\s*([A-Z_][A-Z0-9_,\s]*)\s*\}\s*=\s*process\.env", "destructure"),
    (r"require\s*\(\s*['\"]dotenv['\"]\s*\)\.config\s*\(", "dotenv.config"),
]

GO_ENV_PATTERNS = [
    (r'os\.Getenv\s*\(\s*"([^"]+)"', "os.Getenv"),
    (r'os\.LookupEnv\s*\(\s*"([^"]+)"', "os.LookupEnv"),
]

GO_VIPER_PATTERNS = [
    (r'viper\.Get\s*\(\s*"([^"]+)"', "viper.Get"),
    (r'viper\.GetString\s*\(\s*"([^"]+)"', "viper.GetString"),
    (r'viper\.BindEnv\s*\(\s*"([^"]+)"', "viper.BindEnv"),
    (r'viper\.AutomaticEnv\s*\(', "viper.AutomaticEnv"),
]

RUBY_ENV_PATTERNS = [
    (r"ENV\s*\[\s*['\"]([^'\"]+)['\"]", "ENV[]"),
    (r"ENV\.fetch\s*\(\s*['\"]([^'\"]+)['\"]", "ENV.fetch"),
]

JAVA_ENV_PATTERNS = [
    (r'System\.getenv\s*\(\s*"([^"]+)"', "System.getenv"),
    (r'System\.getProperty\s*\(\s*"([^"]+)"', "System.getProperty"),
]

RUST_ENV_PATTERNS = [
    (r'std::env::var\s*\(\s*"([^"]+)"', "std::env::var"),
    (r'(?<![a-zA-Z_])env::var\s*\(\s*"([^"]+)"', "env::var"),
]

CSHARP_ENV_PATTERNS = [
    (r'Environment\.GetEnvironmentVariable\s*\(\s*"([^"]+)"', "GetEnvironmentVariable"),
    (r'Configuration\s*\[\s*"([^"]+)"\s*\]', "Configuration[]"),
]

# SDK implicit loaders
SDK_IMPLICIT_LOADERS = {
    'sdk_aws': {
        'patterns': [
            (r'boto3\.Session\s*\(', 'boto3.Session'),
            (r'boto3\.client\s*\(', 'boto3.client'),
            (r'boto3\.resource\s*\(', 'boto3.resource'),
        ],
        'implicit_secrets': ['AWS_ACCESS_KEY_ID', 'AWS_SECRET_ACCESS_KEY', 'AWS_SESSION_TOKEN'],
    },
    'sdk_gcp': {
        'patterns': [
            (r'google\.auth\.default\s*\(', 'google.auth.default'),
            (r'from\s+google\.cloud\s+import', 'google.cloud'),
        ],
        'implicit_secrets': ['GOOGLE_APPLICATION_CREDENTIALS', 'GOOGLE_CLOUD_PROJECT'],
    },
    'sdk_azure': {
        'patterns': [
            (r'DefaultAzureCredential\s*\(', 'DefaultAzureCredential'),
            (r'EnvironmentCredential\s*\(', 'EnvironmentCredential'),
        ],
        'implicit_secrets': ['AZURE_CLIENT_ID', 'AZURE_CLIENT_SECRET', 'AZURE_TENANT_ID'],
    },
    'sdk_stripe': {
        'patterns': [
            (r'stripe\.api_key\s*=', 'stripe.api_key'),
            (r'import\s+stripe', 'import stripe'),
        ],
        'implicit_secrets': ['STRIPE_SECRET_KEY', 'STRIPE_API_KEY'],
    },
    'sdk_twilio': {
        'patterns': [
            (r'twilio\.rest\.Client\s*\(', 'twilio.rest.Client'),
        ],
        'implicit_secrets': ['TWILIO_ACCOUNT_SID', 'TWILIO_AUTH_TOKEN'],
    },
    'sdk_sendgrid': {
        'patterns': [
            (r'sendgrid\.SendGridAPIClient\s*\(', 'SendGridAPIClient'),
        ],
        'implicit_secrets': ['SENDGRID_API_KEY'],
    },
    'sdk_openai': {
        'patterns': [
            (r'openai\.api_key\s*=', 'openai.api_key'),
            (r'openai\.OpenAI\s*\(', 'openai.OpenAI'),
            (r'OpenAI\s*\(\s*\)', 'OpenAI()'),
        ],
        'implicit_secrets': ['OPENAI_API_KEY'],
    },
    'sdk_github': {
        'patterns': [
            (r'Github\s*\(\s*\)', 'Github()'),
            (r'from\s+github\s+import\s+Github', 'import Github'),
        ],
        'implicit_secrets': ['GITHUB_TOKEN', 'GH_TOKEN'],
    },
    'sdk_slack': {
        'patterns': [
            (r'WebClient\s*\(\s*token\s*=', 'WebClient(token=)'),
            (r'from\s+slack_sdk\s+import', 'import slack_sdk'),
        ],
        'implicit_secrets': ['SLACK_BOT_TOKEN', 'SLACK_TOKEN'],
    },
}

# Private key patterns: (regex, pattern_name, language)
PRIVATE_KEY_PATTERNS = [
    (r"open\s*\(\s*['\"]([^'\"]*(?:key|pem|p12|pfx)[^'\"]*)['\"]", "open(key_file)", "python"),
    (r"load_pem_private_key\s*\(", "load_pem_private_key", "python"),
    (r"RSAKey\.from_private_key_file\s*\(", "RSAKey.from_private_key_file", "python"),
    (r"jwt\.encode\s*\([^)]*key\s*=", "jwt.encode(key=)", "python"),
    (r'ioutil\.ReadFile\s*\(\s*"([^"]*(?:key|pem)[^"]*)"', "ioutil.ReadFile(key)", "go"),
    (r'x509\.ParsePKCS[18]PrivateKey\s*\(', "x509.ParsePKCSPrivateKey", "go"),
    (r"fs\.readFileSync\s*\(\s*['\"]([^'\"]*(?:key|pem)[^'\"]*)['\"]", "fs.readFileSync(key)", "javascript"),
    (r"crypto\.createPrivateKey\s*\(", "crypto.createPrivateKey", "javascript"),
]

# Config file patterns
CONFIG_FILE_PATTERNS = [
    (r"ConfigParser\s*\(\s*\)\.read\s*\(", "ConfigParser.read", "python"),
    (r"yaml\.safe_load\s*\(", "yaml.safe_load", "python"),
    (r"yaml\.load\s*\(", "yaml.load", "python"),
    (r"toml\.load\s*\(", "toml.load", "python"),
    (r"viper\.ReadInConfig\s*\(", "viper.ReadInConfig", "go"),
    (r"require\s*\(\s*['\"]config['\"]\s*\)", "require('config')", "javascript"),
    (r"@Value\s*\(\s*['\"\$]\{([^}]+)\}", "@Value", "java"),
]

# Database URL patterns
DATABASE_URL_PATTERNS = [
    (r"create_engine\s*\(\s*os\.getenv\s*\(\s*['\"]([^'\"]+)['\"]", "create_engine(getenv())", "python"),
    (r"psycopg2\.connect\s*\(", "psycopg2.connect", "python"),
    (r"MongoClient\s*\(", "MongoClient", "python"),
    (r"redis\.from_url\s*\(", "redis.from_url", "python"),
    (r"mongoose\.connect\s*\(", "mongoose.connect", "javascript"),
]

LANGUAGE_EXTENSIONS = {
    '.py': 'python', '.js': 'javascript', '.mjs': 'javascript', '.ts': 'typescript',
    '.tsx': 'typescript', '.jsx': 'javascript', '.go': 'go', '.rb': 'ruby',
    '.java': 'java', '.rs': 'rust', '.cs': 'csharp',
}


def detect_language(file_path: str) -> str:
    ext = Path(file_path).suffix.lower()
    return LANGUAGE_EXTENSIONS.get(ext, 'unknown')


def normalize_secret_name(name: str) -> str:
    return name.upper().replace('-', '_').strip()


def extract_function_name_python(source: str, line_number: int) -> Tuple[Optional[str], Optional[str]]:
    try:
        tree = ast.parse(source)
    except SyntaxError:
        return None, None
    
    enclosing_func = None
    enclosing_class = None
    
    for node in ast.walk(tree):
        if isinstance(node, ast.ClassDef):
            if hasattr(node, 'lineno') and hasattr(node, 'end_lineno'):
                if node.lineno <= line_number <= (node.end_lineno or line_number + 1000):
                    enclosing_class = node.name
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            if hasattr(node, 'lineno') and hasattr(node, 'end_lineno'):
                if node.lineno <= line_number <= (node.end_lineno or line_number + 1000):
                    enclosing_func = node.name
    
    return enclosing_func, enclosing_class


def extract_function_name_generic(source: str, line_number: int, language: str) -> Tuple[Optional[str], Optional[str]]:
    lines = source.split('\n')
    if line_number > len(lines):
        return None, None
    
    func_name = None
    class_name = None
    
    func_patterns = {
        'javascript': [r'function\s+(\w+)\s*\(', r'(?:const|let|var)\s+(\w+)\s*=\s*(?:async\s+)?(?:function|\()'],
        'typescript': [r'function\s+(\w+)\s*[<(]', r'(?:public|private|protected)?\s*(?:async\s+)?(\w+)\s*\([^)]*\)'],
        'go': [r'func\s+(?:\([^)]+\)\s+)?(\w+)\s*\('],
        'ruby': [r'def\s+(\w+)'],
        'java': [r'(?:public|private|protected)?\s*(?:static\s+)?(?:\w+\s+)?(\w+)\s*\([^)]*\)\s*(?:throws|{)'],
        'rust': [r'fn\s+(\w+)\s*[<(]', r'pub\s+fn\s+(\w+)\s*[<(]'],
        'csharp': [r'(?:public|private|protected|internal)?\s*(?:static\s+)?(?:async\s+)?(?:\w+\s+)?(\w+)\s*\([^)]*\)'],
    }
    
    class_patterns = {
        'javascript': [r'class\s+(\w+)'],
        'typescript': [r'class\s+(\w+)'],
        'go': [r'type\s+(\w+)\s+struct'],
        'ruby': [r'class\s+(\w+)'],
        'java': [r'class\s+(\w+)'],
        'rust': [r'struct\s+(\w+)', r'impl\s+(\w+)'],
        'csharp': [r'class\s+(\w+)'],
    }
    
    patterns = func_patterns.get(language, [])
    c_patterns = class_patterns.get(language, [])
    
    for i in range(line_number - 1, max(0, line_number - 100), -1):
        if i >= len(lines):
            continue
        line = lines[i]
        
        if not func_name:
            for pattern in patterns:
                match = re.search(pattern, line)
                if match:
                    func_name = match.group(1)
                    break
        
        if not class_name:
            for pattern in c_patterns:
                match = re.search(pattern, line)
                if match:
                    class_name = match.group(1)
                    break
        
        if func_name and class_name:
            break
    
    return func_name, class_name


def is_import_time(source: str, line_number: int, language: str) -> bool:
    if language == 'python':
        func_name, _ = extract_function_name_python(source, line_number)
        return func_name is None
    else:
        func_name, _ = extract_function_name_generic(source, line_number, language)
        return func_name is None


class SecretLoaderDetector:
    def __init__(self, verbose: bool = False):
        self.verbose = verbose
    
    def scan(self, target_dir: Path) -> SecretLoaderResult:
        start_time = time.time()
        result = SecretLoaderResult()
        target_dir = Path(target_dir)
        
        if not target_dir.exists():
            result.errors.append(f"Target directory does not exist: {target_dir}")
            return result
        
        source_files = self._find_source_files(target_dir)
        result.total_files_scanned = len(source_files)
        
        if self.verbose:
            print(f"   🔍 Scanning {len(source_files)} files for secret loaders...")
        
        for file_path in source_files:
            try:
                loaders = self._scan_file(file_path, target_dir)
                result.loaders.extend(loaders)
            except Exception as e:
                result.errors.append(f"Error scanning {file_path}: {e}")
        
        result.total_loaders_found = len(result.loaders)
        
        # Build index
        for loader in result.loaders:
            for secret_name in loader.secret_names:
                normalized = normalize_secret_name(secret_name)
                if normalized not in result.secrets_with_loaders:
                    result.secrets_with_loaders[normalized] = []
                result.secrets_with_loaders[normalized].append(loader)
            
            for sdk_secret in loader.sdk_secrets:
                normalized = normalize_secret_name(sdk_secret)
                if normalized not in result.secrets_with_loaders:
                    result.secrets_with_loaders[normalized] = []
                result.secrets_with_loaders[normalized].append(loader)
        
        # SDK implicit secrets index
        for loader in result.loaders:
            if loader.sdk_secrets:
                sdk_type = loader.loader_type.value
                if sdk_type not in result.sdk_implicit_secrets:
                    result.sdk_implicit_secrets[sdk_type] = []
                for secret in loader.sdk_secrets:
                    if secret not in result.sdk_implicit_secrets[sdk_type]:
                        result.sdk_implicit_secrets[sdk_type].append(secret)
        
        result.scan_time_ms = (time.time() - start_time) * 1000
        
        if self.verbose:
            print(f"   ✅ Found {result.total_loaders_found} loaders for {len(result.secrets_with_loaders)} secrets")
        
        return result
    
    def _find_source_files(self, target_dir: Path) -> List[Path]:
        source_files = []
        skip_dirs = {'.git', 'node_modules', '__pycache__', '.venv', 'venv', 'vendor', 'dist', 'build'}
        
        for root, dirs, files in os.walk(target_dir):
            dirs[:] = [d for d in dirs if d not in skip_dirs and not d.endswith('.egg-info')]
            
            for filename in files:
                file_path = Path(root) / filename
                if file_path.suffix.lower() in LANGUAGE_EXTENSIONS:
                    try:
                        if file_path.stat().st_size < 1_000_000:
                            source_files.append(file_path)
                    except OSError:
                        pass
        
        return source_files
    
    def _scan_file(self, file_path: Path, target_dir: Path) -> List[LoaderFinding]:
        loaders = []
        
        try:
            content = file_path.read_text(errors='replace')
        except Exception:
            return loaders
        
        rel_path = str(file_path.relative_to(target_dir))
        language = detect_language(str(file_path))
        
        if language == 'python':
            loaders.extend(self._scan_patterns(content, rel_path, language, PYTHON_ENV_PATTERNS, LoaderType.ENV_VAR))
            loaders.extend(self._scan_patterns(content, rel_path, language, PYTHON_DOTENV_PATTERNS, LoaderType.DOTENV))
        elif language in ('javascript', 'typescript'):
            loaders.extend(self._scan_patterns(content, rel_path, language, JAVASCRIPT_ENV_PATTERNS, LoaderType.ENV_VAR))
        elif language == 'go':
            loaders.extend(self._scan_patterns(content, rel_path, language, GO_ENV_PATTERNS, LoaderType.ENV_VAR))
            loaders.extend(self._scan_patterns(content, rel_path, language, GO_VIPER_PATTERNS, LoaderType.VIPER))
        elif language == 'ruby':
            loaders.extend(self._scan_patterns(content, rel_path, language, RUBY_ENV_PATTERNS, LoaderType.ENV_VAR))
        elif language == 'java':
            loaders.extend(self._scan_patterns(content, rel_path, language, JAVA_ENV_PATTERNS, LoaderType.ENV_VAR))
        elif language == 'rust':
            loaders.extend(self._scan_patterns(content, rel_path, language, RUST_ENV_PATTERNS, LoaderType.ENV_VAR))
        elif language == 'csharp':
            loaders.extend(self._scan_patterns(content, rel_path, language, CSHARP_ENV_PATTERNS, LoaderType.ENV_VAR))
        
        # SDK loaders (all languages)
        loaders.extend(self._scan_sdk_loaders(content, rel_path, language))
        
        # Private key loaders
        loaders.extend(self._scan_typed_patterns(content, rel_path, language, PRIVATE_KEY_PATTERNS, LoaderType.PRIVATE_KEY_FILE))
        
        # Config file loaders
        loaders.extend(self._scan_typed_patterns(content, rel_path, language, CONFIG_FILE_PATTERNS, LoaderType.CONFIG_FILE))
        
        # Database URL loaders
        loaders.extend(self._scan_typed_patterns(content, rel_path, language, DATABASE_URL_PATTERNS, LoaderType.DATABASE_URL))
        
        return loaders
    
    def _scan_patterns(self, content: str, file_path: str, language: str, 
                       patterns: List[Tuple], loader_type: LoaderType) -> List[LoaderFinding]:
        loaders = []
        
        for pattern_tuple in patterns:
            pattern, pattern_name = pattern_tuple[0], pattern_tuple[1]
            
            for match in re.finditer(pattern, content, re.MULTILINE):
                start_pos = match.start()
                line_number = content[:start_pos].count('\n') + 1
                line_start = content.rfind('\n', 0, start_pos) + 1
                column = start_pos - line_start + 1
                
                secret_names = []
                if match.groups():
                    captured = match.group(1)
                    if ',' in captured:
                        secret_names = [n.strip() for n in captured.split(',') if n.strip()]
                    else:
                        secret_names = [captured]
                
                if language == 'python':
                    func_name, class_name = extract_function_name_python(content, line_number)
                else:
                    func_name, class_name = extract_function_name_generic(content, line_number, language)
                
                import_time = is_import_time(content, line_number, language)
                
                loader = LoaderFinding(
                    file_path=file_path,
                    line_number=line_number,
                    column=column,
                    function_name=func_name,
                    class_name=class_name,
                    loader_type=loader_type,
                    secret_names=secret_names,
                    pattern_matched=pattern_name,
                    language=language,
                    is_import_time=import_time,
                )
                loaders.append(loader)
        
        return loaders
    
    def _scan_typed_patterns(self, content: str, file_path: str, language: str,
                             patterns: List[Tuple], default_type: LoaderType) -> List[LoaderFinding]:
        loaders = []
        
        for pattern_tuple in patterns:
            pattern, pattern_name, pattern_lang = pattern_tuple
            
            if pattern_lang != language:
                continue
            
            for match in re.finditer(pattern, content, re.MULTILINE):
                start_pos = match.start()
                line_number = content[:start_pos].count('\n') + 1
                line_start = content.rfind('\n', 0, start_pos) + 1
                column = start_pos - line_start + 1
                
                secret_names = []
                if match.groups():
                    secret_names = [match.group(1)]
                
                if language == 'python':
                    func_name, class_name = extract_function_name_python(content, line_number)
                else:
                    func_name, class_name = extract_function_name_generic(content, line_number, language)
                
                # Determine loader type
                loader_type = default_type
                if 'jwt' in pattern_name.lower():
                    loader_type = LoaderType.JWT_SIGNING
                elif 'ssh' in pattern_name.lower() or 'rsa' in pattern_name.lower():
                    loader_type = LoaderType.SSH_KEY
                elif '@value' in pattern_name.lower():
                    loader_type = LoaderType.SPRING
                
                loader = LoaderFinding(
                    file_path=file_path,
                    line_number=line_number,
                    column=column,
                    function_name=func_name,
                    class_name=class_name,
                    loader_type=loader_type,
                    secret_names=secret_names,
                    pattern_matched=pattern_name,
                    language=language,
                    is_import_time=is_import_time(content, line_number, language),
                )
                loaders.append(loader)
        
        return loaders
    
    def _scan_sdk_loaders(self, content: str, file_path: str, language: str) -> List[LoaderFinding]:
        loaders = []
        
        for sdk_name, sdk_config in SDK_IMPLICIT_LOADERS.items():
            for pattern_tuple in sdk_config['patterns']:
                pattern, pattern_name = pattern_tuple
                
                for match in re.finditer(pattern, content, re.MULTILINE):
                    start_pos = match.start()
                    line_number = content[:start_pos].count('\n') + 1
                    line_start = content.rfind('\n', 0, start_pos) + 1
                    column = start_pos - line_start + 1
                    
                    if language == 'python':
                        func_name, class_name = extract_function_name_python(content, line_number)
                    else:
                        func_name, class_name = extract_function_name_generic(content, line_number, language)
                    
                    import_time = is_import_time(content, line_number, language)
                    
                    loader = LoaderFinding(
                        file_path=file_path,
                        line_number=line_number,
                        column=column,
                        function_name=func_name,
                        class_name=class_name,
                        loader_type=LoaderType[sdk_name.upper()],
                        secret_names=[],
                        pattern_matched=pattern_name,
                        language=language,
                        is_import_time=import_time,
                        sdk_secrets=sdk_config['implicit_secrets'],
                    )
                    loaders.append(loader)
        
        return loaders
    
    def analyze_reachability(self, result: SecretLoaderResult, call_graph: Dict[str, Set[str]],
                             reachable_functions: Set[str], entrypoints: Set[str]) -> SecretLoaderResult:
        if self.verbose:
            print(f"   🔗 Analyzing reachability for {len(result.loaders)} loaders...")
        
        reachable_lower = {f.lower() for f in reachable_functions}
        
        for loader in result.loaders:
            if loader.is_import_time:
                loader.is_reachable = True
                loader.reachable_via = ['<import-time>']
                continue
            
            if loader.function_name:
                func_key = loader.function_name.lower()
                
                candidates = [
                    func_key,
                    f"{loader.file_path}:{loader.function_name}",
                    f"{Path(loader.file_path).stem}.{loader.function_name}",
                ]
                
                if loader.class_name:
                    candidates.extend([
                        f"{loader.class_name}.{loader.function_name}",
                        f"{Path(loader.file_path).stem}.{loader.class_name}.{loader.function_name}",
                    ])
                
                for candidate in candidates:
                    if candidate.lower() in reachable_lower or candidate in reachable_functions:
                        loader.is_reachable = True
                        loader.reachable_via = [candidate]
                        break
                
                if loader.is_reachable is None:
                    for reachable_func in reachable_functions:
                        if func_key in reachable_func.lower():
                            loader.is_reachable = True
                            loader.reachable_via = [reachable_func]
                            break
            
            if loader.is_reachable is None:
                file_stem = Path(loader.file_path).stem.lower()
                entrypoint_names = {'main', 'index', 'app', 'server', 'handler', 'api', 'wsgi', 'asgi'}
                if file_stem in entrypoint_names:
                    loader.is_reachable = True
                    loader.reachable_via = ['<entrypoint-file>']
        
        # Update secret-level status
        for secret_name, loaders_list in result.secrets_with_loaders.items():
            result.secret_loadable_status[secret_name] = LoadableStatus.YES
            
            any_reachable = any(l.is_reachable for l in loaders_list if l.is_reachable is not None)
            all_unreachable = all(l.is_reachable == False for l in loaders_list)
            
            if any_reachable:
                result.secret_reachability_status[secret_name] = ReachabilityStatus.REACHABLE
                result.reachable_secrets.add(secret_name)
            elif all_unreachable:
                result.secret_reachability_status[secret_name] = ReachabilityStatus.NOT_REACHABLE
                result.unreachable_secrets.add(secret_name)
            else:
                result.secret_reachability_status[secret_name] = ReachabilityStatus.UNKNOWN
                result.unknown_secrets.add(secret_name)
        
        if self.verbose:
            print(f"   ✅ Reachability: {len(result.reachable_secrets)} reachable, "
                  f"{len(result.unreachable_secrets)} unreachable, {len(result.unknown_secrets)} unknown")
        
        return result
    
    def apply_to_secrets(self, loader_result: SecretLoaderResult, 
                         secret_findings: List[Dict]) -> List[Dict]:
        secrets_by_name = loader_result.secrets_with_loaders
        
        for finding in secret_findings:
            if not finding.get('is_actual_secret', True):
                continue
            
            secret_name = self._extract_secret_name(finding)
            if not secret_name:
                finding['loadable'] = 'unknown'
                finding['loader_reachability'] = 'unknown'
                continue
            
            normalized_name = normalize_secret_name(secret_name)
            
            if normalized_name in secrets_by_name:
                found_loaders = secrets_by_name[normalized_name]
                finding['loadable'] = 'yes'
                finding['loaders'] = [l.to_dict() for l in found_loaders[:5]]
                
                status = loader_result.secret_reachability_status.get(normalized_name)
                if status == ReachabilityStatus.REACHABLE:
                    finding['is_reachable'] = True
                    finding['loader_reachability'] = 'reachable'
                    finding['reachable_via'] = found_loaders[0].reachable_via if found_loaders else []
                elif status == ReachabilityStatus.NOT_REACHABLE:
                    finding['is_reachable'] = False
                    finding['loader_reachability'] = 'not_reachable'
                else:
                    finding['loader_reachability'] = 'unknown'
            else:
                finding['loadable'] = 'no'
                finding['loader_reachability'] = 'unknown'
            
            # Check SDK implicit loaders
            for sdk_type, sdk_secrets in loader_result.sdk_implicit_secrets.items():
                if normalized_name in [normalize_secret_name(s) for s in sdk_secrets]:
                    finding['loadable'] = 'yes'
                    finding['loaded_by_sdk'] = sdk_type
                    if normalized_name in loader_result.reachable_secrets:
                        finding['is_reachable'] = True
                        finding['loader_reachability'] = 'reachable'
                    break
        
        return secret_findings
    
    def _extract_secret_name(self, finding: Dict) -> Optional[str]:
        for fld in ['key', 'key_name', 'secret_name', 'check_id', 'rule_id']:
            if fld in finding and finding[fld]:
                name = finding[fld]
                if '.' in name:
                    parts = name.split('.')
                    last_part = parts[-1]
                    if last_part.isupper() or '_' in last_part:
                        return last_part
                return name
        
        message = finding.get('message', '')
        env_match = re.search(r"['\"]([A-Z][A-Z0-9_]+)['\"]", message)
        if env_match:
            return env_match.group(1)
        
        return None


def print_results(result: SecretLoaderResult, verbose: bool = False):
    print("\n" + "=" * 70)
    print("SECRET-REACH-001: Secret Loader Detection")
    print("=" * 70)
    
    print(f"\n📁 Files scanned: {result.total_files_scanned}")
    print(f"🔍 Loaders found: {result.total_loaders_found}")
    print(f"🔑 Unique secrets with loaders: {len(result.secrets_with_loaders)}")
    
    if result.reachable_secrets or result.unreachable_secrets or result.unknown_secrets:
        print(f"\n📊 Reachability Summary:")
        print(f"   ✅ Reachable: {len(result.reachable_secrets)}")
        print(f"   ❌ Unreachable: {len(result.unreachable_secrets)}")
        print(f"   ❓ Unknown: {len(result.unknown_secrets)}")
    
    if result.sdk_implicit_secrets:
        print(f"\n🔌 SDK Implicit Secrets:")
        for sdk, secrets in result.sdk_implicit_secrets.items():
            print(f"   {sdk}: {', '.join(secrets[:3])}{'...' if len(secrets) > 3 else ''}")
    
    if verbose and result.loaders:
        print(f"\n📋 Loaders ({min(20, len(result.loaders))} shown):")
        for loader in result.loaders[:20]:
            reach_icon = "✅" if loader.is_reachable else ("❌" if loader.is_reachable == False else "❓")
            func_info = f" in {loader.function_name}()" if loader.function_name else " <module-level>"
            secrets = ', '.join(loader.secret_names[:3]) if loader.secret_names else '<SDK implicit>'
            print(f"   {reach_icon} {loader.file_path}:{loader.line_number}{func_info}")
            print(f"      Secrets: {secrets}")
    
    print(f"\n⏱️  Scan time: {result.scan_time_ms:.2f}ms")


if __name__ == '__main__':
    import sys
    target = Path(sys.argv[1]) if len(sys.argv) > 1 else Path('.')
    verbose = '-v' in sys.argv or '--verbose' in sys.argv
    
    detector = SecretLoaderDetector(verbose=True)
    result = detector.scan(target)
    print_results(result, verbose=verbose)
