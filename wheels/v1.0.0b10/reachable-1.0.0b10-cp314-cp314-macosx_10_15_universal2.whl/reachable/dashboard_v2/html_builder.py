#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.

"""
HTML generation for dashboard.
Handles template loading, logo setup, and HTML creation.
"""

import json
import os
import shutil
from pathlib import Path
from typing import Dict, Any

from .utils import get_version


# Path constants
MODULE_DIR = Path(__file__).parent
TEMPLATE_SHELL_PATH = MODULE_DIR / 'template-shell.html'
STYLES_PATH = MODULE_DIR / 'styles.css'
SCRIPTS_PATH = MODULE_DIR / 'scripts.js'
TEMPLATE_PATH = MODULE_DIR / 'template.html'  # Legacy single-file template
ASSETS_DIR = MODULE_DIR.parent / 'assets'
LOGO_PATH = ASSETS_DIR / 'logo.png'
LOGO_PATH_FALLBACK = ASSETS_DIR / 'sthenos-logo-cropped.png'
CENTRAL_ASSETS_DIR = Path.home() / '.reachable' / 'assets'


def setup_logo(dashboard_dir: Path):
    CENTRAL_ASSETS_DIR.mkdir(parents=True, exist_ok=True)
    central_logo = CENTRAL_ASSETS_DIR / 'logo.png'
    if not central_logo.exists():
        if LOGO_PATH.exists():
            shutil.copy(LOGO_PATH, central_logo)
        elif LOGO_PATH_FALLBACK.exists():
            shutil.copy(LOGO_PATH_FALLBACK, central_logo)
    dashboard_logo = dashboard_dir / 'logo.png'
    if dashboard_logo.exists() or dashboard_logo.is_symlink():
        dashboard_logo.unlink()
    if central_logo.exists():
        try:
            os.symlink(central_logo, dashboard_logo)
        except OSError:
            shutil.copy(central_logo, dashboard_logo)


def create_index_html(dashboard_dir: Path, data: Dict[str, Any]):
    """Create index.html from template with embedded data (for file:// support)"""
    index_path = dashboard_dir / 'index.html'
    setup_logo(dashboard_dir)
    template = _load_template()
    
    if template:
        version = get_version()
        data['version'] = version
        template = template.replace('{{VERSION}}', version)
        data_json = json.dumps(data, default=str)
        
        # FIX: Inject data AFTER scripts.js so dashboardData exists, then assign to it
        data_script = f'''<script>
// Embedded dashboard data (works with file:// protocol)
dashboardData = {data_json};
renderDashboard();
initTrendsChart(dashboardData);
</script>
</body>'''
        
        template = template.replace('</body>', data_script)
        index_path.write_text(template)
    else:
        create_fallback_html(index_path)


def _load_template() -> str:
    """Load template from split files or single file"""
    if (TEMPLATE_SHELL_PATH.exists() and 
        STYLES_PATH.exists() and 
        SCRIPTS_PATH.exists()):
        shell = TEMPLATE_SHELL_PATH.read_text()
        styles = STYLES_PATH.read_text()
        scripts = SCRIPTS_PATH.read_text()
        return shell.replace('{{STYLES}}', styles).replace('{{SCRIPTS}}', scripts)
    elif TEMPLATE_PATH.exists():
        return TEMPLATE_PATH.read_text()
    return ''


def create_fallback_html(path: Path):
    """Create minimal fallback dashboard"""
    html = '''<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>REACHABLE Security Dashboard</title>
    <style>
        body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; background: #0f172a; color: #e2e8f0; padding: 20px; margin: 0; }
        .header { background: linear-gradient(90deg, #1e40af 0%, #7c3aed 100%); padding: 20px; border-radius: 12px; margin-bottom: 20px; }
        .header h1 { margin: 0; font-size: 24px; }
        .error { background: #dc2626; padding: 20px; border-radius: 12px; margin: 20px 0; }
        .card { background: #1e293b; padding: 20px; border-radius: 12px; margin: 10px 0; }
        table { width: 100%; border-collapse: collapse; }
        th, td { padding: 10px; text-align: left; border-bottom: 1px solid #334155; }
        th { color: #94a3b8; }
        .badge { display: inline-block; padding: 2px 8px; border-radius: 4px; font-size: 12px; font-weight: 500; }
        .badge-critical { background: #dc2626; color: white; }
        .badge-high { background: #f59e0b; color: black; }
        .badge-medium { background: #eab308; color: black; }
        .badge-low { background: #22c55e; color: white; }
    </style>
</head>
<body>
    <div class="header"><h1>REACHABLE Security Dashboard</h1><p id="scanInfo">Loading...</p></div>
    <div id="errorContainer"></div>
    <div class="card"><h2>Summary</h2><div id="summaryContainer">Loading...</div></div>
    <div class="card"><h2>Findings</h2><table><thead><tr><th>ID</th><th>Type</th><th>Severity</th><th>Description</th></tr></thead><tbody id="findingsTable"></tbody></table></div>
    <script>
        fetch('data.json').then(r => r.json()).then(data => {
            document.getElementById('scanInfo').textContent = data.scan.display + ' | Risk: ' + data.risk_level;
            document.getElementById('summaryContainer').innerHTML = '<p>CVEs: '+data.summary.cves+'</p><p>Secrets: '+data.summary.secrets+'</p>';
            const tbody = document.getElementById('findingsTable');
            data.findings.slice(0,50).forEach(f => { tbody.innerHTML += '<tr><td>'+f.id+'</td><td>'+f.type+'</td><td>'+f.severity+'</td><td>'+(f.description||'').substring(0,100)+'</td></tr>'; });
        }).catch(err => { document.getElementById('errorContainer').innerHTML = '<div class="error"><h3>Failed to load</h3><p>'+err.message+'</p></div>'; });
    </script>
</body>
</html>'''
    path.write_text(html)
