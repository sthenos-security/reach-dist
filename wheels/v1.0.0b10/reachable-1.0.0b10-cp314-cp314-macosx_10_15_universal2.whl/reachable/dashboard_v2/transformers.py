#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.

"""
Report transformation and issue extraction.
Transforms raw report data into dashboard format.
"""

from pathlib import Path
from typing import Dict, Any, List

from .utils import get_version, normalize_severity, determine_finding_type
from .metrics import calculate_risk_level


def transform_report(report: Dict[str, Any]) -> Dict[str, Any]:
    """Transform full report to dashboard format with complete metrics"""
    summary = report.get('summary', {})
    totals = summary.get('totals', {})
    metadata = report.get('metadata', {})
    target = metadata.get('analysis_target', {})
    git_info = metadata.get('git_info', {}) or target.get('git', {})
    sandbox = report.get('sandbox', {})
    sandbox_summary = sandbox.get('summary', {})
    
    # Extract repo info
    app_dir = target.get('app_directory', '')
    repo_name = Path(app_dir).name if app_dir else 'unknown'
    branch = git_info.get('branch', 'main')
    commit = git_info.get('commit_short') or (git_info.get('commit_sha') or '')[:8]
    commit_date = git_info.get('commit_date', '')
    
    # Try to get GitHub URL from various sources
    github_url = (
        git_info.get('remote_url') or 
        git_info.get('github_url') or 
        target.get('github_url') or 
        metadata.get('github_url') or
        ''
    )
    # Clean up GitHub URL
    if github_url:
        github_url = github_url.rstrip('/')
        if github_url.endswith('.git'):
            github_url = github_url[:-4]
        if github_url.startswith('git@github.com:'):
            github_url = 'https://github.com/' + github_url[15:]
    
    # Build metrics
    metrics = _build_metrics(totals, sandbox_summary, metadata, sandbox)
    
    # Build security issues list
    issues = extract_issues_from_report(report)
    
    # Calculate risk level based on reachable issues
    summary_for_risk = {
        'malware_total': metrics.get('malware_total', 0),
        'suspicious_total': metrics.get('suspicious_total', 0),
    }
    risk_level = calculate_risk_level(summary_for_risk, metrics, issues)
    
    # Determine scan date
    scan_date = ''
    if commit_date:
        scan_date = commit_date.split(' ')[0] if ' ' in commit_date else commit_date
    
    return {
        'version': report.get('reachable_version') or get_version(),
        'scan': {
            'repository': repo_name,
            'branch': branch,
            'commit': commit,
            'date': scan_date,
            'display': f"{repo_name} @ {branch}",
            'github_url': github_url,
            'repo_root': app_dir,
        },
        'risk_level': risk_level,
        'metrics': metrics,
        'summary': {
            'cves': f"{metrics['cves_total']} total, {metrics['cves_reachable']} reachable",
            'secrets': f"{metrics['secrets_total']} total, {metrics['secrets_reachable']} reachable",
            'malware': f"{metrics['malware_total']} malicious packages",
            'sast': f"{metrics['sast_total']} code issues, {metrics['sast_reachable']} reachable",
        },
        'issues': issues,
    }


def _build_metrics(totals: Dict, sandbox_summary: Dict, metadata: Dict, sandbox: Dict) -> Dict[str, Any]:
    """Build comprehensive metrics for funnel visualization"""
    # Raw signals (before reachability filtering)
    raw_cves = totals.get('cves_total', 0)
    raw_malware = totals.get('malware_total', 0)
    raw_suspicious = sandbox_summary.get('suspicious', 0)
    raw_secrets = totals.get('secrets_total', 0)
    raw_sast = totals.get('cwe_total', 0)
    raw_cwe = totals.get('cwe_total', 0)
    
    # Reachable signals (after reachability filtering)
    reach_cves = totals.get('cves_reachable', 0)
    reach_malware = totals.get('malware_total', 0)  # Malware is always "reachable"
    reach_secrets = totals.get('secrets_reachable', 0) or totals.get('secrets_reachable_actual', 0)
    reach_sast = totals.get('cwe_reachable', 0)
    reach_cwe = totals.get('cwe_reachable', 0)
    
    return {
        # CVE/Vulnerable Packages
        'cves_total': raw_cves,
        'cves_reachable': reach_cves,
        'cves_critical': totals.get('cves_critical', 0),
        'cves_high': totals.get('cves_high', 0),
        'cves_medium': totals.get('cves_medium', 0),
        'cves_low': totals.get('cves_low', 0),
        # Malware
        'malware_total': raw_malware,
        'malware_reachable': reach_malware,
        # Suspicious (Sandbox)
        'suspicious_total': raw_suspicious,
        'suspicious_reachable': 0,
        # Secrets
        'secrets_total': raw_secrets,
        'secrets_reachable': reach_secrets,
        'secrets_critical': totals.get('secrets_critical', 0),
        # SAST/Code vulnerabilities
        'sast_total': raw_sast,
        'sast_reachable': reach_sast,
        # License
        'license_total': 0,
        'license_reachable': 0,
        # CWE patterns
        'cwe_total': raw_cwe,
        'cwe_reachable': reach_cwe,
        # Totals
        'raw_total': raw_cves + raw_malware + raw_suspicious + raw_secrets + raw_sast + totals.get('config_total', 0),
        'reachable_total': reach_cves + reach_malware + reach_secrets + reach_sast + totals.get('config_total', 0),
        # Other
        'packages_scanned': totals.get('total_packages', 0),
        'source_files_scanned': totals.get('source_files_scanned', 0) or metadata.get('source_files_scanned', 0),
        'sandbox_packages_tested': sandbox.get('packages_tested', 0),
        # v4.4.2: Threat Intel metrics
        'kev_total': totals.get('kev_matches', 0),
        'epss_high': totals.get('epss_high', 0),
        'threat_intel_total': (totals.get('kev_matches', 0) or 0) + (totals.get('epss_high', 0) or 0),
        # v4.4.2: Supply Chain metrics
        'phantom_deps': totals.get('phantom_deps', 0),
        'shadow_imports': totals.get('shadow_imports', 0),
        'dead_deps': totals.get('dead_deps', 0),
        # v4.4.2: Library Health metrics
        'health_critical': totals.get('health_critical', 0),
        'unhealthy_packages': totals.get('unhealthy_packages', 0),
        # v4.4.2: Direct vs Transitive dependencies
        'direct_deps': totals.get('direct_deps', 0),
        'transitive_deps': totals.get('transitive_deps', 0),
        # v4.4.4: Threat Intel (KEV/EPSS)
        'threatintel_total': (totals.get('kev_matches', 0) or 0) + (totals.get('epss_high', 0) or 0),
        'threatintel_reachable': (totals.get('kev_reachable', 0) or totals.get('kev_matches', 0) or 0) + 
                                  (totals.get('epss_high_reachable', 0) or totals.get('epss_high', 0) or 0),
        # v4.4.4: Phantom Libraries
        'phantom_total': totals.get('phantom_deps', 0) or 0,
        'phantom_reachable': totals.get('phantom_reachable', 0) or totals.get('phantom_deps', 0) or 0,
        # v4.4.5: Config Issues
        'config_total': totals.get('config_total', 0),
        'config_unknown': totals.get('config_unknown', totals.get('config_total', 0)),
        # v4.5.4: Attack Surface metrics
        'entrypoints': totals.get('entrypoints', 0),
        'functions_total': totals.get('functions_total', 0),
        'functions_reachable': totals.get('functions_reachable', 0),
    }


def extract_issues_from_report(report: Dict[str, Any]) -> List[Dict[str, Any]]:
    """Extract all security issues from report with remediation and compliance data"""
    issues = []
    
    # Extract CVEs from reachable
    issues.extend(_extract_cves(report.get('reachable', {}), is_reachable=True))
    
    # Extract CVEs from unreachable
    issues.extend(_extract_cves(report.get('unreachable', {}), is_reachable=False))
    
    # Extract secrets/CWE/CONFIG from detailed_findings
    detailed = report.get('detailed_findings', {})
    issues.extend(_extract_secrets_and_code_findings(detailed.get('secrets', {})))
    
    # Extract malware findings
    issues.extend(_extract_malware_findings(detailed.get('malware', {}), report))
    
    # Extract dynamic malware findings
    issues.extend(_extract_dynamic_malware(report))
    
    return issues


def _extract_cves(cve_dict: Dict[str, Any], is_reachable: bool) -> List[Dict[str, Any]]:
    """Extract CVE issues from reachable/unreachable dict"""
    issues = []
    
    for cve_id, cve_data in cve_dict.items():
        remediation = cve_data.get('remediation', {})
        raw_sev = cve_data.get('severity', 'MEDIUM')
        is_fixable = cve_data.get('is_fixable', False)
        
        # Determine fix_status
        fix_status = 'fix_available' if is_fixable else 'no_fix'
        if cve_data.get('fix_state') == 'wont-fix':
            fix_status = 'wont_fix'
        
        issues.append({
            'id': cve_id,
            'type': 'CVE',
            'severity': raw_sev,
            'raw_severity': raw_sev,
            'is_reachable': is_reachable,
            'reachability_state': 'reachable' if is_reachable else 'not_reachable',
            'title': cve_id,
            'description': cve_data.get('description', ''),
            'message': cve_data.get('description', ''),
            'package': cve_data.get('package', ''),
            'version': cve_data.get('version', ''),
            'file_path': '',
            'is_transitive': cve_data.get('is_transitive', False),
            'fix_available': is_fixable,
            'fix_status': fix_status,
            'call_path': cve_data.get('reachability_path') or cve_data.get('call_path') if is_reachable else None,
            'remediation': {
                'action': remediation.get('action', 'UPGRADE' if is_reachable else 'MONITOR'),
                'fixed_in': remediation.get('fixed_in', ''),
                'summary': remediation.get('summary', ''),
                'steps': remediation.get('steps', []),
                'workaround': remediation.get('workaround'),
                'references': remediation.get('references', []),
            },
            'compliance_mapping': cve_data.get('compliance_mapping', {}),
            'exploitability': cve_data.get('exploitability', {}),
        })
    
    return issues


def _extract_secrets_and_code_findings(secrets_data: Dict[str, Any]) -> List[Dict[str, Any]]:
    """Extract secrets, CWE, and CONFIG findings"""
    issues = []
    
    for idx, finding in enumerate(secrets_data.get('findings', []), 1):
        is_secret = finding.get('is_actual_secret', False)
        raw_sev = finding.get('severity', 'MEDIUM')
        rule_id = finding.get('rule_id', '')
        file_path = finding.get('file', '')
        
        # Determine finding type
        ftype = determine_finding_type(is_secret, rule_id, file_path)
        
        # Normalize severity
        severity = normalize_severity(raw_sev, rule_id, file_path)
        
        # Determine reachability state
        reachability_state = _determine_reachability_state(finding, ftype)
        
        # FIX: Compute is_reachable based on type and state
        # - SECRET unknown → True (conservative - assume exposed)
        # - CONFIG unknown → None (runtime-dependent)
        # - reachable → True
        # - not_reachable → False
        if reachability_state == 'reachable':
            is_reachable = True
        elif reachability_state == 'not_reachable':
            is_reachable = False
        elif reachability_state == 'unknown':
            if ftype == 'SECRET':
                is_reachable = True  # Conservative: unknown secrets treated as reachable
            elif ftype == 'CONFIG':
                is_reachable = None  # Runtime-dependent
            else:
                is_reachable = False
        else:
            is_reachable = finding.get('is_reachable')
        
        remediation = finding.get('remediation', {})
        issues.append({
            'id': finding.get('rule_id', f"{ftype}-{idx}"),
            'type': ftype,
            'severity': severity,
            'raw_severity': raw_sev,
            'is_reachable': is_reachable,
            'reachability_state': reachability_state,
            'title': finding.get('rule_id', ''),
            'description': finding.get('message', ''),
            'message': finding.get('message', ''),
            'package': '',
            'file_path': finding.get('file', ''),
            'line': finding.get('line'),
            'cwe_id': finding.get('cwe_id', ''),
            'call_path': finding.get('reachability_path') or finding.get('call_path'),
            'remediation': {
                'action': remediation.get('action', 'CODE_FIX'),
                'steps': remediation.get('steps', []),
                'references': [],
            },
            'compliance_mapping': finding.get('compliance_mapping', {}),
        })
    
    return issues


def _determine_reachability_state(finding: Dict[str, Any], ftype: str) -> str:
    """
    Determine reachability state for a finding.
    
    v4.5.16: UNIFIED REACHABILITY MODEL
    States: reachable / not_reachable / unknown
    """
    cwe_reachability = finding.get('cwe_reachability', '').lower()
    is_reachable = finding.get('is_reachable')
    reachability_confidence = finding.get('reachability_confidence', '')
    
    if ftype == 'CONFIG':
        return 'unknown'  # Runtime-dependent
    elif cwe_reachability in ('reachable', 'config_issue'):
        return 'reachable'
    elif cwe_reachability in ('unreachable', 'not_reachable'):
        return 'not_reachable'
    elif cwe_reachability == 'test_only':
        return 'not_reachable'
    elif is_reachable is True:
        return 'reachable'
    elif is_reachable is False:
        reachability_field = finding.get('reachability', 'unknown').lower()
        if reachability_field in ('unknown', ''):
            return 'unknown'
        else:
            return 'not_reachable'
    elif reachability_confidence and reachability_confidence.startswith('UNKNOWN'):
        return 'unknown'
    elif 'is_reachable' not in finding and not cwe_reachability:
        return 'unknown'
    else:
        return 'unknown'


def _extract_malware_findings(malware_data: Dict[str, Any], report: Dict[str, Any]) -> List[Dict[str, Any]]:
    """Extract malware findings with reachability context"""
    issues = []
    
    # Get used packages for reachability check
    used_packages = set(p.lower() for p in report.get('used_packages', []))
    imported_packages = set(p.lower() for p in report.get('imported_packages', []))
    all_used = used_packages | imported_packages
    
    function_imports = report.get('function_imports', {})
    
    for idx, finding in enumerate(malware_data.get('findings', []), 1):
        has_dynamic_evidence = finding.get('dynamic_evidence') or finding.get('sandbox_result')
        verdict = 'MALWARE' if has_dynamic_evidence else 'SUSPICIOUS'
        
        # Build evidence structure
        evidence = {}
        if finding.get('static_indicators') or finding.get('guarddog_findings'):
            evidence['static'] = {
                'scanner': 'GuardDog',
                'indicators': finding.get('static_indicators', finding.get('guarddog_findings', [])),
                'confidence': finding.get('static_confidence', 0.0),
            }
        if has_dynamic_evidence:
            evidence['dynamic'] = {
                'scanner': 'Sandbox',
                'behaviors': finding.get('dynamic_evidence', finding.get('sandbox_result', {}).get('behaviors', [])),
                'confidence': finding.get('dynamic_confidence', 0.0),
            }
        
        # Check if malicious package is actually imported/used
        pkg_name = finding.get('package', '').lower()
        pkg_in_imports = any(
            pkg_name in imp.lower() 
            for imps in function_imports.values() 
            for imp in imps
        )
        
        # Determine malware reachability
        if pkg_name in all_used or pkg_in_imports:
            malware_reachable = True
            malware_reachability_state = 'reachable'
            malware_severity = 'CRITICAL' if verdict == 'MALWARE' else 'HIGH'
        else:
            malware_reachable = False
            malware_reachability_state = 'not_reachable'
            malware_severity = 'HIGH' if verdict == 'MALWARE' else 'MEDIUM'
        
        # Build remediation
        if malware_reachable:
            remediation_steps = [
                f"🚨 URGENT: {finding.get('package', 'package')} is IMPORTED in your code",
                f"Remove {finding.get('package', 'the package')} from dependencies IMMEDIATELY",
                'Audit for any data exfiltration or unauthorized access',
                'Rotate any credentials that may have been exposed',
                'Review install-time hooks and scripts',
            ]
        else:
            remediation_steps = [
                f"⚠️ {finding.get('package', 'package')} is in dependencies but NOT directly imported",
                f"Remove {finding.get('package', 'the package')} from dependencies",
                'Check if it is a transitive dependency (required by another package)',
                'May have executed install-time hooks - audit for side effects',
            ]
        
        issues.append({
            'id': finding.get('package', f"MAL-{idx}"),
            'type': verdict,
            'severity': malware_severity,
            'raw_severity': 'CRITICAL' if verdict == 'MALWARE' else 'HIGH',
            'is_reachable': malware_reachable,
            'reachability_state': malware_reachability_state,
            'title': f"Malicious package: {finding.get('package', 'unknown')}",
            'description': finding.get('description', finding.get('reason', '')),
            'message': finding.get('reason', finding.get('description', '')),
            'package': finding.get('package', ''),
            'version': finding.get('version', ''),
            'file_path': '',
            'call_path': finding.get('reachability_path') or finding.get('call_path'),
            'evidence': evidence,
            'remediation': {
                'action': 'REMOVE_IMMEDIATELY' if malware_reachable else 'REMOVE',
                'steps': remediation_steps,
                'references': finding.get('references', []),
            },
            'compliance_mapping': {
                'CWE-TOP-25': ['CWE-506'],
                'OWASP': ['A08:2021'],
            },
        })
    
    return issues


def _extract_dynamic_malware(report: Dict[str, Any]) -> List[Dict[str, Any]]:
    """Extract dynamic malware findings from sandbox results"""
    issues = []
    
    dynamic_malware = report.get('dynamic_malware', {}) or report.get('security_scans', {}).get('dynamic_malware', {})
    if not dynamic_malware or dynamic_malware.get('verdict') in ('NOT_RUN', 'CLEAN', None):
        return issues
    
    # Add sandbox findings
    for finding in dynamic_malware.get('findings', []):
        severity = finding.get('severity', 'HIGH')
        if severity == 'CRITICAL' or dynamic_malware.get('verdict') == 'CRITICAL':
            verdict_type = 'MALWARE'
        else:
            verdict_type = 'SUSPICIOUS'
        
        pkg_name = finding.get('package', 'unknown')
        issues.append({
            'id': f"SANDBOX-{pkg_name}-{finding.get('rule', 'unknown')}",
            'type': verdict_type,
            'severity': severity,
            'raw_severity': severity,
            'is_reachable': True,
            'reachability_state': 'reachable',
            'title': f"Dynamic analysis: {finding.get('rule', 'Suspicious behavior')}",
            'description': finding.get('description', ''),
            'message': finding.get('description', ''),
            'package': pkg_name,
            'version': '',
            'file_path': '',
            'call_path': finding.get('reachability_path') or finding.get('call_path'),
            'evidence': {
                'dynamic': {
                    'scanner': 'Colima Sandbox',
                    'behaviors': [finding.get('evidence', finding.get('description', ''))],
                    'phase': finding.get('phase', 'install'),
                }
            },
            'remediation': {
                'action': 'INVESTIGATE_IMMEDIATELY',
                'steps': [
                    f"Review {pkg_name} for malicious behavior",
                    'Check for network calls during installation',
                    'Audit credential access patterns',
                    'Consider removing or replacing the package',
                ],
                'references': [],
            },
            'compliance_mapping': {
                'CWE-TOP-25': ['CWE-506'],
                'OWASP': ['A08:2021'],
            },
        })
    
    # Add malicious packages from sandbox verdict
    for pkg in dynamic_malware.get('malicious_packages', []):
        if not any(i.get('package') == pkg and i.get('type') == 'MALWARE' for i in issues):
            issues.append({
                'id': f"SANDBOX-{pkg}",
                'type': 'MALWARE',
                'severity': 'CRITICAL',
                'raw_severity': 'CRITICAL',
                'is_reachable': True,
                'reachability_state': 'reachable',
                'title': f"Malicious package confirmed: {pkg}",
                'description': 'Dynamic sandbox analysis confirmed malicious behavior',
                'message': 'Package exhibited malicious behavior during installation',
                'package': pkg,
                'version': '',
                'file_path': '',
                'evidence': {
                    'dynamic': {
                        'scanner': 'Colima Sandbox',
                        'behaviors': ['Confirmed malicious during dynamic analysis'],
                        'phase': 'install',
                    }
                },
                'remediation': {
                    'action': 'REMOVE_IMMEDIATELY',
                    'steps': [
                        f"Remove {pkg} from dependencies immediately",
                        'Audit for data exfiltration',
                        'Rotate any credentials',
                        'Review git history for when package was added',
                    ],
                    'references': [],
                },
                'compliance_mapping': {
                    'CWE-TOP-25': ['CWE-506'],
                    'OWASP': ['A08:2021'],
                },
            })
    
    return issues
