#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.

"""
Utility functions for dashboard generation.
"""

from pathlib import Path


def get_version() -> str:
    """Get REACHABLE version with multiple fallbacks"""
    # Try 1: Import from parent package
    try:
        from reachable import __version__
        if __version__ and __version__ != '0.0.0':
            return __version__
    except ImportError:
        pass
    
    # Try 2: Import from _version.py directly
    try:
        from reachable._version import __version__ as v
        if v and v != '0.0.0':
            return v
    except ImportError:
        pass
    
    # Try 3: Read VERSION file (dev mode)
    try:
        version_file = Path(__file__).parent.parent.parent / 'VERSION'
        if version_file.exists():
            return version_file.read_text().strip()
    except Exception:
        pass
    
    return '0.0.0'


def normalize_severity(severity: str, rule_id: str = '', file_path: str = '') -> str:
    """
    Normalize Semgrep severity to standard levels.
    
    Mapping:
    - ERROR → CRITICAL (but capped at HIGH for config issues)
    - WARNING → HIGH
    - INFO → LOW
    
    Config issues (Dockerfile, K8s, Terraform, etc.) are capped at HIGH
    because CRITICAL should be reserved for RCE/actively exploited vulns.
    """
    if not severity:
        return 'MEDIUM'
    s = severity.upper()
    
    # Detect if this is a config/infrastructure issue
    is_config_issue = False
    file_lower = (file_path or '').lower()
    rule_lower = (rule_id or '').lower()
    
    config_patterns = [
        'dockerfile', '.yaml', '.yml', 'terraform', '.tf',
        'kubernetes', 'k8s', 'helm', 'kustomize',
        '.json',  # Config files
    ]
    config_rules = [
        'dockerfile.', 'kubernetes.', 'terraform.', 
        'yaml.', 'json.', 'config.', 'misconfig',
    ]
    
    if any(p in file_lower for p in config_patterns):
        is_config_issue = True
    if any(r in rule_lower for r in config_rules):
        is_config_issue = True
    
    # Normalize severity
    if s == 'ERROR':
        # Cap config issues at HIGH - CRITICAL is for RCE/exploited vulns
        return 'HIGH' if is_config_issue else 'CRITICAL'
    if s == 'WARNING':
        return 'HIGH'
    if s == 'INFO':
        return 'LOW'
    return s


def determine_finding_type(is_secret: bool, rule_id: str, file_path: str) -> str:
    """
    Determine finding type: SECRET, CONFIG, or CWE (v4.4.0)
    
    - SECRET: Actual credentials/tokens
    - CONFIG: Dockerfile, Kubernetes, Terraform misconfigurations  
    - CWE: Application code weaknesses
    """
    if is_secret:
        return 'SECRET'
    
    file_lower = (file_path or '').lower()
    rule_lower = (rule_id or '').lower()
    
    # Config patterns in file path
    config_file_patterns = [
        'dockerfile', '.yaml', '.yml', 'terraform', '.tf', '.hcl',
        'kubernetes', 'k8s', 'helm', 'kustomize', 'compose',
    ]
    
    # Config patterns in rule ID
    config_rule_patterns = [
        'dockerfile.', 'kubernetes.', 'terraform.', 'helm.',
        'yaml.', 'json.', 'config.', 'misconfig', 'k8s.',
        'container.', 'cloud.', 'aws.', 'gcp.', 'azure.',
    ]
    
    if any(p in file_lower for p in config_file_patterns):
        return 'CONFIG'
    if any(r in rule_lower for r in config_rule_patterns):
        return 'CONFIG'
    
    return 'CWE'
