#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.

"""
REACHABLE Dashboard v2 Generator
Funnel visualization with Executive + Engineering views

Architecture (Option B):
    repo.db (SQLite) → data.json → index.html (reads data.json)

Output:
    dashboard/
    ├── index.html    # Static dashboard (from template)
    ├── data.json     # Dashboard-specific data (~50KB)
    └── logo.png      # Sthenos logo (copied from assets)

This module orchestrates dashboard generation by coordinating:
- loaders.py: Database and JSON loading
- transformers.py: Report transformation
- metrics.py: Metrics calculation
- html_builder.py: HTML generation
- utils.py: Utility functions
"""

import json
from pathlib import Path
from typing import Dict, Any

from .utils import get_version
from .loaders import (
    load_from_database,
    load_from_json,
    get_repo_metadata,
    get_scan_history,
)
from .transformers import transform_report
from .html_builder import create_index_html

# Re-export version for backward compatibility
REACHABLE_VERSION = get_version()


class DashboardV2Generator:
    """
    Generate funnel-based dashboard with Executive + Engineering views
    
    Reads from:
    1. repo.db (preferred - single source of truth, at repo level)
    2. reachable-report.json.gz (fallback)
    
    Outputs:
    - dashboard/index.html
    - dashboard/data.json
    - logo.png
    """
    
    def __init__(self):
        self.data = {}
    
    def generate_from_scan_dir(self, scan_dir: Path) -> Path:
        """
        Generate dashboard from scan directory
        
        Auto-detects best source:
        1. repo.db (preferred - at repo level: ../../repo.db)
        2. reachable-report.json.gz (fallback)
        
        Args:
            scan_dir: Scan output directory
            
        Returns:
            Path to dashboard directory
        """
        scan_dir = Path(scan_dir)
        
        # Try database first (v4.5.x+ preferred)
        repo_db_path = scan_dir.parent.parent / 'repo.db'
        if repo_db_path.exists():
            self.data = load_from_database(repo_db_path)
        else:
            # Fallback to JSON
            json_file = self._find_json_report(scan_dir)
            if json_file:
                report = load_from_json(json_file)
                self.data = transform_report(report)
            else:
                raise FileNotFoundError(
                    f"No data source found in {scan_dir}. "
                    "Expected: repo.db (at repo level) or reachable-report.json.gz"
                )
        
        # Add repo-level metadata
        self.data['repo_metadata'] = get_repo_metadata(scan_dir)
        
        # Add scan history for trends visualization
        self.data['scan_history'] = get_scan_history(scan_dir, days=90)
        
        # Create dashboard
        return self._create_dashboard(scan_dir)
    
    def generate_from_report(self, report: Dict[str, Any], output_dir: Path) -> Path:
        """
        Generate dashboard from report dictionary
        
        Args:
            report: Full reachable report data
            output_dir: Where to create dashboard/
            
        Returns:
            Path to dashboard directory
        """
        self.data = transform_report(report)
        
        # Add repo-level metadata
        self.data['repo_metadata'] = get_repo_metadata(output_dir)
        
        # Add scan history for trends visualization
        self.data['scan_history'] = get_scan_history(output_dir, days=90)
        
        return self._create_dashboard(output_dir)
    
    def _find_json_report(self, scan_dir: Path) -> Path:
        """Find JSON report file in scan directory"""
        json_candidates = [
            scan_dir / 'reachable-report.json.gz',
            scan_dir / 'reachable-report_json.gz',
            scan_dir / 'reachable-report.json',
            scan_dir / 'report.json',
        ]
        
        for candidate in json_candidates:
            if candidate.exists():
                return candidate
        return None
    
    def _create_dashboard(self, scan_dir: Path) -> Path:
        """Create dashboard directory with files"""
        dashboard_dir = scan_dir / 'dashboard'
        dashboard_dir.mkdir(exist_ok=True)
        
        # Write data.json
        data_path = dashboard_dir / 'data.json'
        with open(data_path, 'w') as f:
            json.dump(self.data, f, indent=2, default=str)
        
        # Create index.html
        create_index_html(dashboard_dir, self.data)
        
        return dashboard_dir


def generate_dashboard(scan_dir: Path) -> Path:
    """
    Convenience function to generate dashboard
    
    Args:
        scan_dir: Scan output directory (repo.db at parent level or report JSON)
        
    Returns:
        Path to dashboard directory
    """
    generator = DashboardV2Generator()
    return generator.generate_from_scan_dir(scan_dir)


if __name__ == '__main__':
    import sys
    
    if len(sys.argv) < 2:
        print("Usage: python generator.py <scan_dir>")
        sys.exit(1)
    
    scan_dir = Path(sys.argv[1])
    dashboard_dir = generate_dashboard(scan_dir)
    print(f"✅ Dashboard generated: {dashboard_dir}")
    print(f"   Open: file://{dashboard_dir / 'index.html'}")
