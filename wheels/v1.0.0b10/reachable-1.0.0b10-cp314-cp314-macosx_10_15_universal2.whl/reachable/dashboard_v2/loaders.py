#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.

"""
Data loaders for dashboard generation.
Handles loading from SQLite database and JSON files.
"""

import gzip
import json
import sqlite3
from pathlib import Path
from typing import Dict, Any, List, Optional

from .utils import get_version
from .metrics import calculate_metrics_from_summary, calculate_risk_level, format_summary


def load_from_database(db_path: Path) -> Dict[str, Any]:
    """Load dashboard data directly from SQLite database"""
    conn = sqlite3.connect(str(db_path))
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    
    try:
        # Get scan metadata
        metadata = _get_scan_metadata(cursor)
        
        # Get issues summary (was 'findings')
        issues_summary = _get_issues_summary(cursor)
        
        # Get all security issues for table
        issues = _get_all_issues(cursor)
        
        # Calculate metrics
        metrics = calculate_metrics_from_summary(issues_summary)
        
        # v4.5.10: Read risk_level from scans table (stored at scan time)
        risk_level = _get_stored_risk_level(cursor)
        if not risk_level:
            # Fallback: recalculate if not stored (legacy scans)
            risk_level = calculate_risk_level(issues_summary, metrics, issues)
        
        return {
            'version': get_version(),
            'scan': metadata,
            'risk_level': risk_level,
            'metrics': metrics,
            'summary': format_summary(issues_summary),
            'issues': issues,
        }
        
    finally:
        conn.close()


def load_from_json(json_path: Path) -> Dict[str, Any]:
    """Load report from JSON file (gzipped or plain)"""
    if str(json_path).endswith('.gz'):
        with gzip.open(json_path, 'rt', encoding='utf-8') as f:
            return json.load(f)
    else:
        with open(json_path, 'r', encoding='utf-8') as f:
            return json.load(f)


def get_repo_metadata(scan_dir: Path) -> Dict[str, Any]:
    """
    Get repo-level metadata from repo.db: scan count, first scan date, db size
    """
    try:
        repo_root = scan_dir.parent.parent
        repo_db = repo_root / 'repo.db'
        
        if not repo_db.exists():
            branch_dir = scan_dir.parent
            scan_dirs = sorted([
                d for d in branch_dir.iterdir() 
                if d.is_dir() and d.name[0].isdigit() and len(d.name) >= 15
            ])
            return {
                'scan_number': len(scan_dirs),
                'first_scan': scan_dirs[0].name[:8] if scan_dirs else '',
                'db_size_display': 'N/A',
            }
        
        conn = sqlite3.connect(str(repo_db))
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        
        cursor.execute("SELECT COUNT(*) as cnt FROM scans WHERE status = 'complete'")
        scan_count = cursor.fetchone()['cnt']
        
        cursor.execute("""
            SELECT MIN(timestamp) as first_scan 
            FROM scans WHERE status = 'complete'
        """)
        row = cursor.fetchone()
        first_scan = row['first_scan'] if row else None
        
        first_scan_display = ''
        if first_scan:
            try:
                from datetime import datetime
                dt = datetime.fromisoformat(first_scan.replace('Z', '+00:00'))
                first_scan_display = dt.strftime('%Y-%m-%d')
            except:
                first_scan_display = first_scan[:10] if len(first_scan) >= 10 else first_scan
        
        conn.close()
        
        db_size_bytes = repo_db.stat().st_size
        db_size_mb = round(db_size_bytes / (1024 * 1024), 2)
        
        return {
            'scan_number': scan_count,
            'first_scan': first_scan_display,
            'db_size_mb': db_size_mb,
            'db_size_display': f"{db_size_mb} MB" if db_size_mb >= 1 else f"{round(db_size_bytes / 1024, 1)} KB",
        }
        
    except Exception as e:
        return {'error': str(e)}


def get_scan_history(scan_dir: Path, days: int = 30) -> List[Dict[str, Any]]:
    """Get scan history for trends visualization"""
    try:
        repo_root = scan_dir.parent.parent
        repo_db = repo_root / 'repo.db'
        
        if not repo_db.exists():
            return []
        
        conn = sqlite3.connect(str(repo_db))
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        
        cursor.execute("PRAGMA table_info(scans)")
        columns = [col[1] for col in cursor.fetchall()]
        has_config = 'config_count' in columns
        has_unknown = 'unknown_count' in columns
        
        if has_config and has_unknown:
            cursor.execute("""
                SELECT 
                    id, timestamp, branch, total_findings, reachable_findings,
                    critical_count, high_count, medium_count, low_count,
                    risk_level, config_count, unknown_count
                FROM scans 
                WHERE status = 'complete'
                AND timestamp >= datetime('now', '-' || ? || ' days')
                ORDER BY timestamp ASC
            """, (days,))
        elif has_config:
            cursor.execute("""
                SELECT 
                    id, timestamp, branch, total_findings, reachable_findings,
                    critical_count, high_count, medium_count, low_count,
                    risk_level, config_count
                FROM scans 
                WHERE status = 'complete'
                AND timestamp >= datetime('now', '-' || ? || ' days')
                ORDER BY timestamp ASC
            """, (days,))
        else:
            cursor.execute("""
                SELECT 
                    id, timestamp, branch, total_findings, reachable_findings,
                    critical_count, high_count, medium_count, low_count,
                    risk_level
                FROM scans 
                WHERE status = 'complete'
                AND timestamp >= datetime('now', '-' || ? || ' days')
                ORDER BY timestamp ASC
            """, (days,))
        
        history = []
        for row in cursor.fetchall():
            try:
                config = row['config_count'] or 0
            except (IndexError, KeyError):
                config = 0
            try:
                unknown = row['unknown_count'] or 0
            except (IndexError, KeyError):
                unknown = 0
            history.append({
                'scan_id': row['id'],
                'timestamp': row['timestamp'],
                'branch': row['branch'],
                'total_issues': row['total_findings'] or 0,
                'reachable_issues': row['reachable_findings'] or 0,
                'critical': row['critical_count'] or 0,
                'high': row['high_count'] or 0,
                'medium': row['medium_count'] or 0,
                'low': row['low_count'] or 0,
                'risk_level': row['risk_level'] or 'UNKNOWN',
                'unknown_reachability': unknown,
                'config_count': config,
            })
        
        conn.close()
        return history
        
    except Exception:
        return []


# --- Private helpers for database loading ---

def _get_stored_risk_level(cursor) -> Optional[str]:
    """Read risk_level from scans table"""
    try:
        cursor.execute("SELECT risk_level FROM scans ORDER BY id DESC LIMIT 1")
        row = cursor.fetchone()
        if row and row['risk_level']:
            return row['risk_level']
    except:
        pass
    return None


def _get_scan_metadata(cursor) -> Dict[str, Any]:
    """Extract scan metadata from database"""
    try:
        cursor.execute("SELECT * FROM scan_summary LIMIT 1")
        row = cursor.fetchone()
        if row:
            return {
                'repository': row['repo_path'].split('/')[-1] if row['repo_path'] else 'unknown',
                'branch': 'main',
                'commit': '',
                'display': row['repo_path'].split('/')[-1] if row['repo_path'] else 'unknown',
            }
    except:
        pass
    
    try:
        cursor.execute("""
            SELECT repo_path, branch, commit_sha 
            FROM scans 
            ORDER BY id DESC LIMIT 1
        """)
        row = cursor.fetchone()
        if row:
            repo_path = row['repo_path'] if 'repo_path' in row.keys() else ''
            return {
                'repository': repo_path.split('/')[-1] if repo_path else 'unknown',
                'branch': row['branch'] if 'branch' in row.keys() else 'main',
                'commit': (row['commit_sha'] or '')[:8] if 'commit_sha' in row.keys() else '',
                'display': repo_path.split('/')[-1] if repo_path else 'unknown',
            }
    except:
        pass
    
    return {
        'repository': 'unknown',
        'branch': 'main',
        'commit': '',
        'display': 'unknown',
    }


def _get_issues_summary(cursor) -> Dict[str, int]:
    """Get aggregated findings counts from database"""
    summary = {
        'cves_total': 0,
        'cves_reachable': 0,
        'cves_critical': 0,
        'cves_high': 0,
        'cves_medium': 0,
        'cves_low': 0,
        'secrets_total': 0,
        'secrets_reachable': 0,
        'cwe_total': 0,
        'cwe_reachable': 0,
        'config_total': 0,
        'config_unknown': 0,
        'malware_total': 0,
    }
    
    try:
        # FIX: Use app_reachability column (not is_reachable)
        cursor.execute("""
            SELECT 
                finding_type,
                severity,
                app_reachability,
                COUNT(*) as count
            FROM findings
            GROUP BY finding_type, severity, app_reachability
        """)
    except:
        return summary
    
    for row in cursor.fetchall():
        ftype = (row['finding_type'] or '').lower()
        sev = (row['severity'] or '').upper()
        reachability = (row['app_reachability'] or '').upper()
        count = row['count']
        
        # FIX: Proper reachability mapping
        # REACHABLE → reachable
        # NOT_REACHABLE → not reachable
        # UNKNOWN → depends on type (secrets=reachable, config=unknown)
        is_reachable = reachability == 'REACHABLE'
        is_unknown = reachability == 'UNKNOWN'
        
        if ftype == 'cve':
            summary['cves_total'] += count
            if is_reachable:
                summary['cves_reachable'] += count
            if sev == 'CRITICAL':
                summary['cves_critical'] += count
            elif sev == 'HIGH':
                summary['cves_high'] += count
            elif sev == 'MEDIUM':
                summary['cves_medium'] += count
            elif sev == 'LOW':
                summary['cves_low'] += count
        
        elif ftype == 'secret':
            summary['secrets_total'] += count
            # FIX: UNKNOWN secrets treated as reachable (conservative)
            if is_reachable or is_unknown:
                summary['secrets_reachable'] += count
        
        elif ftype == 'cwe':
            summary['cwe_total'] += count
            if is_reachable:
                summary['cwe_reachable'] += count
        
        elif ftype == 'config':
            summary['config_total'] += count
            summary['config_unknown'] += count  # All config is unknown reachability
        
        elif ftype == 'malware':
            summary['malware_total'] += count
    
    return summary


def _get_all_issues(cursor) -> List[Dict[str, Any]]:
    """Get all findings for the issues table"""
    findings = []
    
    try:
        # FIX: Use app_reachability column
        cursor.execute("""
            SELECT 
                id,
                finding_type,
                finding_id,
                severity,
                title,
                description,
                file_path,
                line_number,
                package_name,
                package_version,
                app_reachability,
                app_reachability_confidence,
                app_reachability_path,
                cwe_id
            FROM findings
            ORDER BY 
                CASE severity 
                    WHEN 'CRITICAL' THEN 1 
                    WHEN 'HIGH' THEN 2 
                    WHEN 'MEDIUM' THEN 3 
                    WHEN 'LOW' THEN 4 
                    ELSE 5 
                END,
                CASE app_reachability
                    WHEN 'REACHABLE' THEN 1
                    WHEN 'UNKNOWN' THEN 2
                    ELSE 3
                END
        """)
    except:
        return findings
    
    for row in cursor.fetchall():
        ftype = (row['finding_type'] or '').upper()
        reachability = (row['app_reachability'] or '').upper()
        
        # FIX: Proper is_reachable mapping based on type and reachability
        # - REACHABLE → True
        # - NOT_REACHABLE → False
        # - UNKNOWN + SECRET → True (conservative - we don't know so assume worst)
        # - UNKNOWN + CONFIG → None (special case - runtime dependent)
        # - UNKNOWN + other → False
        if reachability == 'REACHABLE':
            is_reachable = True
            reachability_state = 'reachable'
        elif reachability == 'NOT_REACHABLE':
            is_reachable = False
            reachability_state = 'not_reachable'
        elif reachability == 'UNKNOWN':
            if ftype == 'SECRET':
                # Unknown secrets treated as reachable (conservative)
                is_reachable = True
                reachability_state = 'unknown'
            elif ftype == 'CONFIG':
                # Config is runtime-dependent, not code-reachable
                is_reachable = None
                reachability_state = 'unknown'
            else:
                is_reachable = False
                reachability_state = 'unknown'
        else:
            is_reachable = False
            reachability_state = 'unknown'
        
        # Parse call_path from JSON string
        call_path = None
        if row['app_reachability_path']:
            try:
                call_path = json.loads(row['app_reachability_path'])
            except:
                call_path = None
        
        findings.append({
            'id': row['finding_id'] or f"{ftype}-{row['id']}",
            'type': ftype,
            'severity': row['severity'] or 'UNKNOWN',
            'is_reachable': is_reachable,
            'reachability_state': reachability_state,
            'title': row['title'] or row['finding_id'] or '',
            'description': row['description'] or '',
            'package': f"{row['package_name'] or ''} {row['package_version'] or ''}".strip(),
            'file_path': row['file_path'] or '',
            'line': row['line_number'],
            'cwe_id': row['cwe_id'],
            'call_path': call_path,
        })
    
    return findings
