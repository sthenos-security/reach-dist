#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.

"""
Pipeline CLI - Distributed CI/CD Execution Support

Commands for running REACHABLE in distributed/parallel CI/CD pipelines.
Each step can run independently on different runners/containers.

Usage:
    reachctl pipeline init <repo>           # Initialize scan session
    reachctl pipeline step <step> [opts]    # Run individual analysis step
    reachctl pipeline finalize [opts]       # Merge results, generate dashboard
    reachctl pipeline status                # Check pipeline state
"""

import argparse
import json
import os
import sys
import time
from datetime import datetime
from pathlib import Path
from typing import Optional, Dict, Any

# Pipeline steps that can run in parallel
PIPELINE_STEPS = {
    'sbom': 'Generate SBOM with Syft',
    'vulns': 'Scan vulnerabilities with Grype (requires sbom)',
    'secrets': 'Scan for secrets with Semgrep',
    'cwe': 'Scan for CWE issues with Semgrep', 
    'malware': 'Scan for malware with GuardDog',
    'iac': 'Scan Infrastructure as Code (K8s, Docker, Terraform)',
    'health': 'Analyze package health',
}

# Steps that can run in parallel (no dependencies on each other)
PARALLEL_STEPS = ['secrets', 'cwe', 'malware', 'iac', 'health']

# Steps with dependencies
STEP_DEPENDENCIES = {
    'sbom': [],
    'vulns': ['sbom'],
    'secrets': ['sbom'],
    'cwe': [],
    'malware': ['sbom'],
    'iac': [],
    'health': ['sbom'],
}


def get_pipeline_state_path(session_dir: Path) -> Path:
    """Get path to pipeline state file."""
    return session_dir / '.pipeline-state.json'


def load_pipeline_state(session_dir: Path) -> Dict[str, Any]:
    """Load pipeline state from session directory."""
    state_path = get_pipeline_state_path(session_dir)
    if state_path.exists():
        with open(state_path) as f:
            return json.load(f)
    return {}


def save_pipeline_state(session_dir: Path, state: Dict[str, Any]) -> None:
    """Save pipeline state to session directory."""
    state_path = get_pipeline_state_path(session_dir)
    state['updated_at'] = datetime.now().isoformat()
    with open(state_path, 'w') as f:
        json.dump(state, f, indent=2)


def pipeline_init(args) -> int:
    """
    Initialize a distributed pipeline scan session.
    
    Creates:
        - Session directory with unique ID
        - Pipeline state file for coordination
        - Outputs session ID for downstream steps
    
    Usage:
        SESSION_ID=$(reachctl pipeline init /path/to/repo)
        # Use SESSION_ID in subsequent steps
    """
    from .output_manager import OutputManager
    from . import __version__
    
    repo_path = Path(args.repo).resolve()
    
    if not repo_path.exists():
        print(f"Error: Repository not found: {repo_path}", file=sys.stderr)
        return 1
    
    # Create output directory
    output_mgr = OutputManager(repo_path)
    session_dir = output_mgr.scan_dir
    session_id = output_mgr.timestamp
    
    # Initialize pipeline state
    state = {
        'session_id': session_id,
        'repo_path': str(repo_path),
        'repo_name': output_mgr.repo_name,
        'session_dir': str(session_dir),
        'created_at': datetime.now().isoformat(),
        'version': __version__,
        'status': 'initialized',
        'steps': {step: {'status': 'pending'} for step in PIPELINE_STEPS},
    }
    
    # Save state
    save_pipeline_state(session_dir, state)
    
    # Create scan plan
    from .scan_context import ScanContext
    scan_ctx = ScanContext(repo_path, session_dir)
    
    scan_plan = {
        'timestamp': session_id,
        'repo_path': str(repo_path),
        'repo_name': output_mgr.repo_name,
        'project_type': scan_ctx.project_type,
        'languages': scan_ctx.detected_languages,
        'is_monorepo': scan_ctx.is_monorepo,
        'pipeline_mode': True,
    }
    output_mgr.save_scan_plan(scan_plan)
    
    # Output for CI/CD capture
    if args.json:
        print(json.dumps({
            'session_id': session_id,
            'session_dir': str(session_dir),
            'repo_name': output_mgr.repo_name,
        }))
    else:
        print(f"Session initialized: {session_id}")
        print(f"Directory: {session_dir}")
        
        if args.verbose:
            print()
            print("Next steps:")
            print(f"  reachctl pipeline step sbom --session {session_id}")
            print(f"  reachctl pipeline step vulns --session {session_id}")
            print("  # ... run other steps in parallel ...")
            print(f"  reachctl pipeline finalize --session {session_id}")
    
    return 0


def pipeline_step(args) -> int:
    """
    Run a single pipeline step.
    
    Steps can run in parallel on different runners.
    Results are written to session directory for later merge.
    
    Usage:
        reachctl pipeline step sbom --session <id>
        reachctl pipeline step vulns --session <id>
        reachctl pipeline step secrets --session <id>
    """
    step_name = args.step
    
    if step_name not in PIPELINE_STEPS:
        print(f"Error: Unknown step '{step_name}'", file=sys.stderr)
        print(f"Available steps: {', '.join(PIPELINE_STEPS.keys())}", file=sys.stderr)
        return 1
    
    # Find session directory
    session_dir = _resolve_session_dir(args.session)
    if not session_dir:
        print(f"Error: Session not found: {args.session}", file=sys.stderr)
        return 1
    
    # Load state
    state = load_pipeline_state(session_dir)
    if not state:
        print(f"Error: Invalid session (no state file)", file=sys.stderr)
        return 1
    
    repo_path = Path(state['repo_path'])
    
    # Check dependencies
    for dep in STEP_DEPENDENCIES.get(step_name, []):
        dep_status = state['steps'].get(dep, {}).get('status')
        if dep_status != 'complete':
            print(f"Error: Step '{step_name}' requires '{dep}' to complete first", file=sys.stderr)
            print(f"       Current status of '{dep}': {dep_status}", file=sys.stderr)
            return 1
    
    # Mark step as running
    state['steps'][step_name] = {
        'status': 'running',
        'started_at': datetime.now().isoformat(),
        'runner': os.environ.get('GITHUB_RUN_ID', os.environ.get('CI_JOB_ID', 'local')),
    }
    save_pipeline_state(session_dir, state)
    
    # Run the step
    start_time = time.time()
    try:
        result = _run_step(step_name, repo_path, session_dir, args)
        duration = time.time() - start_time
        
        # Update state
        state['steps'][step_name] = {
            'status': 'complete',
            'started_at': state['steps'][step_name]['started_at'],
            'completed_at': datetime.now().isoformat(),
            'duration_seconds': round(duration, 2),
            'result': result,
        }
        save_pipeline_state(session_dir, state)
        
        if args.json:
            print(json.dumps({
                'step': step_name,
                'status': 'complete',
                'duration': round(duration, 2),
                'result': result,
            }))
        else:
            print(f"✅ Step '{step_name}' complete ({duration:.1f}s)")
        
        return 0
        
    except Exception as e:
        duration = time.time() - start_time
        
        state['steps'][step_name] = {
            'status': 'failed',
            'started_at': state['steps'][step_name]['started_at'],
            'failed_at': datetime.now().isoformat(),
            'duration_seconds': round(duration, 2),
            'error': str(e),
        }
        save_pipeline_state(session_dir, state)
        
        print(f"❌ Step '{step_name}' failed: {e}", file=sys.stderr)
        return 1


def _run_step(step_name: str, repo_path: Path, session_dir: Path, args) -> Dict[str, Any]:
    """Execute a single pipeline step."""
    
    if step_name == 'sbom':
        return _step_sbom(repo_path, session_dir, args)
    elif step_name == 'vulns':
        return _step_vulns(repo_path, session_dir, args)
    elif step_name == 'secrets':
        return _step_secrets(repo_path, session_dir, args)
    elif step_name == 'cwe':
        return _step_cwe(repo_path, session_dir, args)
    elif step_name == 'malware':
        return _step_malware(repo_path, session_dir, args)
    elif step_name == 'iac':
        return _step_iac(repo_path, session_dir, args)
    elif step_name == 'health':
        return _step_health(repo_path, session_dir, args)
    else:
        raise ValueError(f"Unknown step: {step_name}")


def _step_sbom(repo_path: Path, session_dir: Path, args) -> Dict[str, Any]:
    """Generate SBOM with Syft."""
    from .vulndb import get_syft_path
    from .compression import save_json
    import subprocess
    
    syft_path = get_syft_path()
    sbom_file = session_dir / 'sbom.json'
    
    result = subprocess.run(
        [str(syft_path), 'scan', f'dir:{repo_path}', '-o', 'json', '-q'],
        capture_output=True, text=True
    )
    
    if result.returncode != 0:
        raise RuntimeError(f"Syft failed: {result.stderr}")
    
    sbom_data = json.loads(result.stdout)
    actual_file = save_json(sbom_data, sbom_file, compress=True)
    
    # Count packages
    artifacts = sbom_data.get('artifacts', [])
    
    return {
        'file': str(actual_file.name),
        'packages': len(artifacts),
    }


def _step_vulns(repo_path: Path, session_dir: Path, args) -> Dict[str, Any]:
    """Scan vulnerabilities with Grype."""
    from .vulndb import VulnDBManager, get_grype_path
    from .compression import load_json
    import subprocess
    import gzip
    
    grype_path = get_grype_path()
    db_mgr = VulnDBManager()
    db_mgr.ensure_fresh(verbose=False)
    
    # Load SBOM
    sbom_file = session_dir / 'sbom.json.gz'
    if not sbom_file.exists():
        sbom_file = session_dir / 'sbom.json'
    
    if not sbom_file.exists():
        raise RuntimeError("SBOM not found - run 'sbom' step first")
    
    # Decompress if needed
    temp_sbom = None
    if str(sbom_file).endswith('.gz'):
        temp_sbom = session_dir / 'sbom_temp.json'
        with gzip.open(sbom_file, 'rt') as f_in:
            temp_sbom.write_text(f_in.read())
        actual_sbom = temp_sbom
    else:
        actual_sbom = sbom_file
    
    try:
        result = subprocess.run(
            [str(grype_path), f'sbom:{actual_sbom}', '-o', 'json', '-q'],
            capture_output=True, text=True,
            env=db_mgr.get_grype_env()
        )
        
        if result.returncode != 0:
            raise RuntimeError(f"Grype failed: {result.stderr}")
        
        vulns_data = json.loads(result.stdout)
        vulns_file = session_dir / 'vulns.json'
        vulns_file.write_text(result.stdout)
        
        matches = vulns_data.get('matches', [])
        
        return {
            'file': 'vulns.json',
            'total_cves': len(matches),
            'by_severity': _count_by_severity(matches),
        }
    finally:
        if temp_sbom and temp_sbom.exists():
            temp_sbom.unlink()


def _step_secrets(repo_path: Path, session_dir: Path, args) -> Dict[str, Any]:
    """Scan for secrets with Semgrep."""
    from .semgrep_scanner import SemgrepScanner
    
    scanner = SemgrepScanner(repo_path)
    results = scanner.scan_secrets()
    
    # Save results
    secrets_file = session_dir / 'secrets.json'
    with open(secrets_file, 'w') as f:
        json.dump(results, f, indent=2)
    
    findings = results.get('findings', [])
    
    return {
        'file': 'secrets.json',
        'total': len(findings),
    }


def _step_cwe(repo_path: Path, session_dir: Path, args) -> Dict[str, Any]:
    """Scan for CWE issues with Semgrep."""
    from .semgrep_scanner import SemgrepScanner
    
    scanner = SemgrepScanner(repo_path)
    results = scanner.scan_cwe()
    
    # Save results
    cwe_file = session_dir / 'cwe.json'
    with open(cwe_file, 'w') as f:
        json.dump(results, f, indent=2)
    
    findings = results.get('findings', [])
    
    return {
        'file': 'cwe.json',
        'total': len(findings),
    }


def _step_malware(repo_path: Path, session_dir: Path, args) -> Dict[str, Any]:
    """Scan for malware with GuardDog."""
    from .guarddog_scanner import GuardDogScanner
    from .compression import load_json
    
    # Load SBOM for package list
    sbom_file = session_dir / 'sbom.json.gz'
    if not sbom_file.exists():
        sbom_file = session_dir / 'sbom.json'
    
    sbom_data = load_json(sbom_file) if sbom_file.exists() else {}
    
    scanner = GuardDogScanner()
    results = scanner.scan_from_sbom(sbom_data)
    
    # Save results
    malware_file = session_dir / 'malware.json'
    with open(malware_file, 'w') as f:
        json.dump(results, f, indent=2)
    
    return {
        'file': 'malware.json',
        'packages_scanned': results.get('packages_scanned', 0),
        'malicious': results.get('malicious_count', 0),
    }


def _step_iac(repo_path: Path, session_dir: Path, args) -> Dict[str, Any]:
    """Scan Infrastructure as Code (K8s, Docker, Terraform)."""
    from .k8s_scanner import K8sSecurityScanner
    from .docker_compose_scanner import DockerComposeScanner
    
    results = {
        'findings': [],
        'total_findings': 0,
        'by_type': {},
    }
    
    # Scan Kubernetes manifests
    k8s_scanner = K8sSecurityScanner()
    k8s_findings = k8s_scanner.scan_directory(repo_path)
    results['findings'].extend(k8s_findings)
    results['by_type']['kubernetes'] = len(k8s_findings)
    
    # Scan Docker Compose files
    docker_scanner = DockerComposeScanner()
    docker_findings = docker_scanner.scan_directory(repo_path)
    results['findings'].extend(docker_findings)
    results['by_type']['docker'] = len(docker_findings)
    
    results['total_findings'] = len(results['findings'])
    
    # Save results
    iac_file = session_dir / 'iac.json'
    with open(iac_file, 'w') as f:
        json.dump(results, f, indent=2)
    
    return {
        'file': 'iac.json',
        'total': results['total_findings'],
        'by_type': results['by_type'],
    }


def _step_health(repo_path: Path, session_dir: Path, args) -> Dict[str, Any]:
    """Analyze package health."""
    from .health_metrics import HealthMetrics
    from .compression import load_json
    
    # Load SBOM
    sbom_file = session_dir / 'sbom.json.gz'
    if not sbom_file.exists():
        sbom_file = session_dir / 'sbom.json'
    
    sbom_data = load_json(sbom_file) if sbom_file.exists() else {}
    
    analyzer = HealthMetrics()
    results = analyzer.analyze_from_sbom(sbom_data)
    
    # Save results
    health_file = session_dir / 'health.json'
    with open(health_file, 'w') as f:
        json.dump(results, f, indent=2)
    
    return {
        'file': 'health.json',
        'packages_analyzed': results.get('total_packages', 0),
    }


def _count_by_severity(matches: list) -> Dict[str, int]:
    """Count CVEs by severity."""
    counts = {'CRITICAL': 0, 'HIGH': 0, 'MEDIUM': 0, 'LOW': 0, 'UNKNOWN': 0}
    for match in matches:
        sev = match.get('vulnerability', {}).get('severity', 'UNKNOWN').upper()
        if sev in counts:
            counts[sev] += 1
        else:
            counts['UNKNOWN'] += 1
    return counts


def pipeline_finalize(args) -> int:
    """
    Finalize pipeline: merge results and generate dashboard.
    
    Combines results from all steps into:
        - reachable-report.json (master report)
        - dashboard/index.html
        - repo.db (findings database)
    
    Usage:
        reachctl pipeline finalize --session <id>
    """
    # Find session directory
    session_dir = _resolve_session_dir(args.session)
    if not session_dir:
        print(f"Error: Session not found: {args.session}", file=sys.stderr)
        return 1
    
    # Load state
    state = load_pipeline_state(session_dir)
    if not state:
        print(f"Error: Invalid session", file=sys.stderr)
        return 1
    
    # Check all required steps completed
    required_steps = ['sbom', 'vulns']
    for step in required_steps:
        if state['steps'].get(step, {}).get('status') != 'complete':
            print(f"Error: Required step '{step}' not complete", file=sys.stderr)
            return 1
    
    repo_path = Path(state['repo_path'])
    
    print("Finalizing pipeline...")
    print()
    
    # Load all step results
    step_results = {}
    for step_name in PIPELINE_STEPS:
        step_file = session_dir / f'{step_name}.json'
        if step_file.exists():
            with open(step_file) as f:
                step_results[step_name] = json.load(f)
            print(f"  ✓ Loaded {step_name}")
    
    # Run reachability analysis on CVEs
    print("  → Running reachability analysis...")
    from .reachable import ReachabilityAnalyzer
    
    sbom_file = session_dir / 'sbom.json.gz'
    if not sbom_file.exists():
        sbom_file = session_dir / 'sbom.json'
    
    vulns_file = session_dir / 'vulns.json'
    
    analyzer = ReachabilityAnalyzer(
        app_dir=repo_path,
        libs_dir=session_dir / 'libs',
        sbom_file=sbom_file,
        vulns_file=vulns_file,
        verbose=args.verbose,
    )
    
    results = analyzer.analyze()
    
    # Merge in other step results
    if 'secrets' in step_results:
        results['security_scans'] = results.get('security_scans', {})
        results['security_scans']['secrets'] = step_results['secrets']
    
    if 'malware' in step_results:
        results['malware_detection'] = step_results['malware']
    
    if 'iac' in step_results:
        results['iac_findings'] = step_results['iac']
    
    if 'health' in step_results:
        results['package_health'] = step_results['health']
    
    # Save master report
    print("  → Saving master report...")
    from .compression import save_json
    report_file = session_dir / 'reachable-report.json'
    save_json(results, report_file, compress=True)
    
    # Generate dashboard
    print("  → Generating dashboard...")
    from .dashboard_v2.generator import DashboardV2Generator
    generator = DashboardV2Generator()
    dashboard_dir = generator.generate_from_report(results, session_dir)
    
    # Store to database
    print("  → Updating database...")
    from .cli import store_scan_to_database
    overall_risk = results.get('summary', {}).get('overall_risk', {})
    store_scan_to_database(
        session_dir, 
        repo_path=repo_path,
        risk_score=overall_risk.get('risk_score', 0),
        risk_level=overall_risk.get('risk_level'),
    )
    
    # Update state
    state['status'] = 'complete'
    state['completed_at'] = datetime.now().isoformat()
    save_pipeline_state(session_dir, state)
    
    # Create latest symlink
    from .output_manager import OutputManager
    output_mgr = OutputManager(repo_path)
    output_mgr.create_latest_symlink()
    
    print()
    print("=" * 60)
    print("✅ PIPELINE COMPLETE")
    print("=" * 60)
    print()
    print(f"Dashboard: {dashboard_dir / 'index.html'}")
    print(f"Report:    {session_dir / 'reachable-report.json.gz'}")
    
    # Check threshold if specified
    if args.fail_on and args.fail_on != 'none':
        from .sarif_exporter import check_threshold
        should_fail, reason = check_threshold(results, args.fail_on)
        if should_fail:
            print()
            print(f"🚨 CI/CD GATE FAILED: {reason}")
            return 1
        else:
            print()
            print(f"✅ CI/CD gate passed: {reason}")
    
    return 0


def pipeline_status(args) -> int:
    """Show pipeline status."""
    session_dir = _resolve_session_dir(args.session)
    if not session_dir:
        print(f"Error: Session not found: {args.session}", file=sys.stderr)
        return 1
    
    state = load_pipeline_state(session_dir)
    if not state:
        print(f"Error: Invalid session", file=sys.stderr)
        return 1
    
    if args.json:
        print(json.dumps(state, indent=2))
        return 0
    
    print("=" * 60)
    print(f"Pipeline Status: {state['session_id']}")
    print("=" * 60)
    print()
    print(f"Repository: {state['repo_name']}")
    print(f"Status:     {state['status']}")
    print(f"Created:    {state['created_at']}")
    print()
    print("Steps:")
    
    for step_name, step_info in state['steps'].items():
        status = step_info.get('status', 'unknown')
        icon = {
            'pending': '⏳',
            'running': '🔄',
            'complete': '✅',
            'failed': '❌',
        }.get(status, '❓')
        
        duration = step_info.get('duration_seconds', '')
        duration_str = f" ({duration}s)" if duration else ""
        
        print(f"  {icon} {step_name}: {status}{duration_str}")
    
    return 0


def _resolve_session_dir(session: str) -> Optional[Path]:
    """Resolve session ID or path to session directory."""
    if not session:
        return None
    
    # Check if it's a direct path
    session_path = Path(session)
    if session_path.exists() and session_path.is_dir():
        return session_path
    
    # Check in scans directory
    scans_dir = Path.home() / '.reachable' / 'scans'
    
    # Try to find by session ID (timestamp)
    for repo_dir in scans_dir.iterdir():
        if not repo_dir.is_dir():
            continue
        
        # Check each branch directory
        for branch_dir in repo_dir.iterdir():
            if not branch_dir.is_dir():
                continue
            
            session_dir = branch_dir / session
            if session_dir.exists():
                return session_dir
    
    return None


def setup_pipeline_parser(subparsers) -> None:
    """Add pipeline subcommand to main CLI parser."""
    pipeline_parser = subparsers.add_parser(
        'pipeline',
        help='Distributed CI/CD pipeline commands',
        description='Run REACHABLE in distributed/parallel CI/CD pipelines'
    )
    
    pipeline_subs = pipeline_parser.add_subparsers(dest='pipeline_command')
    
    # init
    init_parser = pipeline_subs.add_parser(
        'init',
        help='Initialize a pipeline scan session'
    )
    init_parser.add_argument('repo', help='Path to repository')
    init_parser.add_argument('--json', action='store_true', help='Output JSON')
    init_parser.add_argument('--verbose', '-v', action='store_true')
    
    # step
    step_parser = pipeline_subs.add_parser(
        'step',
        help='Run a single pipeline step'
    )
    step_parser.add_argument('step', choices=list(PIPELINE_STEPS.keys()),
                            help='Step to run')
    step_parser.add_argument('--session', '-s', required=True,
                            help='Session ID or path')
    step_parser.add_argument('--json', action='store_true', help='Output JSON')
    step_parser.add_argument('--verbose', '-v', action='store_true')
    
    # finalize
    finalize_parser = pipeline_subs.add_parser(
        'finalize',
        help='Merge results and generate dashboard'
    )
    finalize_parser.add_argument('--session', '-s', required=True,
                                help='Session ID or path')
    finalize_parser.add_argument('--fail-on', choices=['critical', 'high', 'medium', 'any', 'none'],
                                default='none', help='Exit threshold')
    finalize_parser.add_argument('--json', action='store_true', help='Output JSON')
    finalize_parser.add_argument('--verbose', '-v', action='store_true')
    
    # status
    status_parser = pipeline_subs.add_parser(
        'status',
        help='Show pipeline status'
    )
    status_parser.add_argument('--session', '-s', required=True,
                              help='Session ID or path')
    status_parser.add_argument('--json', action='store_true', help='Output JSON')


def pipeline_command(args) -> int:
    """Handle pipeline subcommands."""
    if not hasattr(args, 'pipeline_command') or not args.pipeline_command:
        print("Usage: reachctl pipeline <init|step|finalize|status>")
        print()
        print("Commands:")
        print("  init      Initialize a pipeline scan session")
        print("  step      Run a single pipeline step")
        print("  finalize  Merge results and generate dashboard")
        print("  status    Show pipeline status")
        print()
        print("Steps available:")
        for step, desc in PIPELINE_STEPS.items():
            print(f"  {step:10} {desc}")
        return 1
    
    if args.pipeline_command == 'init':
        return pipeline_init(args)
    elif args.pipeline_command == 'step':
        return pipeline_step(args)
    elif args.pipeline_command == 'finalize':
        return pipeline_finalize(args)
    elif args.pipeline_command == 'status':
        return pipeline_status(args)
    else:
        print(f"Unknown pipeline command: {args.pipeline_command}")
        return 1
