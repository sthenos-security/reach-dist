# Copyright © 2026 Sthenos Security. All rights reserved.

"""
REACHABLE - Vulnerability Exploitability & Reachability Assessment
"""

from pathlib import Path
import subprocess

def _get_version() -> str:
    """Read version from package metadata, _version.py, or VERSION file"""
    # Priority 1: Try _version.py (baked at build time)
    try:
        from ._version import __version__ as baked_version
        if baked_version and baked_version != "0.0.0":
            return baked_version
    except ImportError:
        pass
    
    # Priority 2: Try importlib.metadata (wheel metadata)
    try:
        from importlib.metadata import version
        v = version("reachable")
        if v and v != "0.0.0":
            return v
    except Exception:
        pass
    
    # Priority 3: VERSION file (dev mode)
    version_file = Path(__file__).parent.parent / "VERSION"
    if version_file.exists():
        return version_file.read_text().strip()
    
    return "0.0.0"

def _get_git_info() -> dict:
    """
    Get git commit info: sha, date, branch.
    Returns dict with keys: sha, date, branch (any may be None)
    """
    info = {"sha": None, "date": None, "branch": None}
    
    # Check for GIT_INFO file (baked into wheel by CI/CD)
    git_info_file = Path(__file__).parent / "GIT_INFO"
    if git_info_file.exists():
        for line in git_info_file.read_text().strip().split("\n"):
            if "=" in line:
                k, v = line.split("=", 1)
                info[k.strip().lower()] = v.strip()
        return info
    
    # Dev mode - get from git
    repo_root = Path(__file__).parent.parent
    try:
        # Short SHA
        result = subprocess.run(
            ["git", "rev-parse", "--short", "HEAD"],
            capture_output=True, text=True, cwd=repo_root, timeout=5
        )
        if result.returncode == 0:
            info["sha"] = result.stdout.strip()
        
        # Commit date
        result = subprocess.run(
            ["git", "log", "-1", "--format=%cd", "--date=short"],
            capture_output=True, text=True, cwd=repo_root, timeout=5
        )
        if result.returncode == 0:
            info["date"] = result.stdout.strip()
        
        # Branch
        result = subprocess.run(
            ["git", "rev-parse", "--abbrev-ref", "HEAD"],
            capture_output=True, text=True, cwd=repo_root, timeout=5
        )
        if result.returncode == 0:
            info["branch"] = result.stdout.strip()
    except Exception:
        pass
    
    return info

def _get_build_date() -> str:
    """Get CI/CD build date if available (wheel only)"""
    build_date_file = Path(__file__).parent / "BUILD_DATE"
    if build_date_file.exists():
        return build_date_file.read_text().strip()
    return None

__version__ = _get_version()
__git_info__ = _get_git_info()
__build_date__ = _get_build_date()
__all__ = ["__version__", "__git_info__", "__build_date__"]
