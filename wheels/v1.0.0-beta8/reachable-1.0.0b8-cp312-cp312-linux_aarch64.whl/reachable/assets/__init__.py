# Assets package - contains static files (logos, etc.)
