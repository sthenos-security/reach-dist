#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.

"""
Grype Vulnerability Database Management

Manages the local cache of grype's vulnerability database to speed up scans.
The DB is refreshed automatically if older than 24 hours.

Cache location: ~/.reachable/cache/grype-db/
Timestamp file: ~/.reachable/cache/grype-db/.last_update

Usage:
    from reachable.vulndb import VulnDBManager
    
    mgr = VulnDBManager()
    mgr.ensure_fresh()  # Auto-refresh if > 24h old
    env = mgr.get_grype_env()  # Get env vars for grype subprocess
"""

import os
import subprocess
import time
from datetime import datetime, timedelta
from pathlib import Path
from typing import Optional, Tuple

# Constants
GRYPE_DB_CACHE_DIR = Path.home() / '.reachable' / 'cache' / 'grype-db'
GRYPE_DB_TIMESTAMP_FILE = GRYPE_DB_CACHE_DIR / '.last_update'
GRYPE_DB_MAX_AGE_HOURS = 24

# Tool locations
TOOLS_BIN = Path.home() / '.reachable' / 'tools' / 'bin'


class VulnDBManager:
    """Manages grype vulnerability database caching and updates."""
    
    def __init__(self, cache_dir: Optional[Path] = None, max_age_hours: int = GRYPE_DB_MAX_AGE_HOURS):
        """
        Initialize VulnDB manager.
        
        Args:
            cache_dir: Override cache directory (default: ~/.reachable/cache/grype-db/)
            max_age_hours: Maximum age before auto-refresh (default: 24)
        """
        self.cache_dir = cache_dir or GRYPE_DB_CACHE_DIR
        self.timestamp_file = self.cache_dir / '.last_update'
        self.max_age_hours = max_age_hours
        self._grype_path: Optional[Path] = None
    
    @property
    def grype_path(self) -> Path:
        """Get path to grype binary, preferring local tools/bin."""
        if self._grype_path is None:
            # Check local tools first
            local_grype = TOOLS_BIN / 'grype'
            if local_grype.exists():
                self._grype_path = local_grype
            else:
                # Fall back to system PATH
                import shutil
                system_grype = shutil.which('grype')
                if system_grype:
                    self._grype_path = Path(system_grype)
                else:
                    raise FileNotFoundError(
                        "grype not found. Install with:\n"
                        "  brew install grype  # macOS\n"
                        "  Or run the REACHABLE installer"
                    )
        return self._grype_path
    
    def get_db_age(self) -> Optional[timedelta]:
        """
        Get age of the cached vulnerability database.
        
        Returns:
            timedelta since last update, or None if no cache exists
        """
        if not self.timestamp_file.exists():
            return None
        
        try:
            timestamp_str = self.timestamp_file.read_text().strip()
            last_update = datetime.fromisoformat(timestamp_str)
            return datetime.now() - last_update
        except (ValueError, OSError):
            return None
    
    def get_db_age_hours(self) -> Optional[float]:
        """Get age in hours, or None if no cache."""
        age = self.get_db_age()
        if age is None:
            return None
        return age.total_seconds() / 3600
    
    def is_stale(self) -> bool:
        """Check if DB needs refresh (> max_age_hours old or doesn't exist)."""
        age_hours = self.get_db_age_hours()
        if age_hours is None:
            return True  # No cache exists
        return age_hours > self.max_age_hours
    
    def get_status(self) -> dict:
        """
        Get detailed status of the vulnerability database.
        
        Returns:
            dict with status info
        """
        age_hours = self.get_db_age_hours()
        db_exists = self.cache_dir.exists() and any(self.cache_dir.glob('*'))
        
        # Calculate size
        db_size = 0
        if db_exists:
            for f in self.cache_dir.rglob('*'):
                if f.is_file():
                    db_size += f.stat().st_size
        
        # Get last update time
        last_update = None
        if self.timestamp_file.exists():
            try:
                last_update = self.timestamp_file.read_text().strip()
            except OSError:
                pass
        
        return {
            'exists': db_exists,
            'location': str(self.cache_dir),
            'size_mb': db_size / (1024 * 1024),
            'age_hours': age_hours,
            'last_update': last_update,
            'is_stale': self.is_stale(),
            'max_age_hours': self.max_age_hours,
            'grype_path': str(self.grype_path) if self._grype_path else None,
        }
    
    def update(self, force: bool = False, verbose: bool = True) -> bool:
        """
        Update the vulnerability database.
        
        Args:
            force: Update even if not stale
            verbose: Print progress messages
            
        Returns:
            True if update succeeded
        """
        if not force and not self.is_stale():
            if verbose:
                age = self.get_db_age_hours()
                print(f"   ✓ Vulnerability DB is fresh ({age:.1f}h old, max {self.max_age_hours}h)")
            return True
        
        # Ensure cache directory exists
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        
        if verbose:
            if self.is_stale():
                age = self.get_db_age_hours()
                if age is None:
                    print("   🔄 Downloading vulnerability database (first time)...")
                else:
                    print(f"   🔄 Refreshing vulnerability database ({age:.1f}h old > {self.max_age_hours}h limit)...")
            else:
                print("   🔄 Force-refreshing vulnerability database...")
        
        try:
            # Run grype db update with custom cache dir
            env = self.get_grype_env()
            result = subprocess.run(
                [str(self.grype_path), 'db', 'update'],
                env=env,
                capture_output=True,
                text=True,
                timeout=300  # 5 minute timeout
            )
            
            if result.returncode != 0:
                if verbose:
                    print(f"   ❌ DB update failed: {result.stderr[:200]}")
                return False
            
            # Update timestamp
            self._update_timestamp()
            
            if verbose:
                size_mb = self.get_status()['size_mb']
                print(f"   ✓ Vulnerability DB updated ({size_mb:.1f} MB)")
            
            return True
            
        except subprocess.TimeoutExpired:
            if verbose:
                print("   ❌ DB update timed out (5 min)")
            return False
        except FileNotFoundError:
            if verbose:
                print("   ❌ grype not found")
            return False
        except Exception as e:
            if verbose:
                print(f"   ❌ DB update error: {e}")
            return False
    
    def ensure_fresh(self, verbose: bool = False) -> bool:
        """
        Ensure DB is fresh, updating if necessary.
        
        This is the main method to call before running grype scans.
        It will automatically refresh if the DB is older than max_age_hours.
        
        Args:
            verbose: Print progress messages
            
        Returns:
            True if DB is ready (fresh or successfully updated)
        """
        if not self.is_stale():
            return True
        return self.update(verbose=verbose)
    
    def clear(self, verbose: bool = True) -> bool:
        """
        Clear the vulnerability database cache.
        
        Args:
            verbose: Print progress messages
            
        Returns:
            True if cleared successfully
        """
        import shutil
        
        if not self.cache_dir.exists():
            if verbose:
                print("   ✓ Vulnerability DB already empty")
            return True
        
        try:
            # Get size before clearing
            size_mb = self.get_status()['size_mb']
            
            shutil.rmtree(self.cache_dir)
            
            if verbose:
                print(f"   ✓ Cleared vulnerability DB ({size_mb:.1f} MB freed)")
            
            return True
            
        except Exception as e:
            if verbose:
                print(f"   ❌ Failed to clear DB: {e}")
            return False
    
    def get_grype_env(self) -> dict:
        """
        Get environment variables for running grype with cached DB.
        
        Returns:
            dict of environment variables to pass to subprocess
        """
        env = os.environ.copy()
        env['GRYPE_DB_CACHE_DIR'] = str(self.cache_dir)
        return env
    
    def _update_timestamp(self):
        """Update the last_update timestamp file."""
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        self.timestamp_file.write_text(datetime.now().isoformat())


def get_tool_path(tool: str) -> Path:
    """
    Get path to a tool binary, preferring local tools/bin.
    
    Args:
        tool: Tool name ('syft', 'grype', etc.)
        
    Returns:
        Path to tool binary
        
    Raises:
        FileNotFoundError if tool not found
    """
    # Check local tools first
    local_tool = TOOLS_BIN / tool
    if local_tool.exists():
        return local_tool
    
    # Fall back to system PATH
    import shutil
    system_tool = shutil.which(tool)
    if system_tool:
        return Path(system_tool)
    
    raise FileNotFoundError(f"{tool} not found in {TOOLS_BIN} or system PATH")


def get_syft_path() -> Path:
    """Get path to syft binary."""
    return get_tool_path('syft')


def get_grype_path() -> Path:
    """Get path to grype binary."""
    return get_tool_path('grype')


# Module-level convenience functions
_manager: Optional[VulnDBManager] = None

def get_manager() -> VulnDBManager:
    """Get or create the singleton VulnDBManager."""
    global _manager
    if _manager is None:
        _manager = VulnDBManager()
    return _manager


def ensure_fresh_db(verbose: bool = False) -> bool:
    """Ensure vulnerability DB is fresh (< 24h old)."""
    return get_manager().ensure_fresh(verbose=verbose)


def get_grype_env() -> dict:
    """Get environment variables for running grype."""
    return get_manager().get_grype_env()


def get_db_status() -> dict:
    """Get vulnerability DB status."""
    return get_manager().get_status()
