#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.

"""
REACHABLE Dashboard v2 Generator
Funnel visualization with Executive + Engineering views

Architecture (Option B):
    repo.db (SQLite) → data.json → index.html (reads data.json)

Output:
    dashboard/
    ├── index.html    # Static dashboard (from template)
    ├── data.json     # Dashboard-specific data (~50KB)
    └── logo.png      # Sthenos logo (copied from assets)
"""

import gzip
import json
import shutil
import sqlite3
from pathlib import Path
from typing import Dict, Any, List, Optional
from datetime import datetime

# Import version from package
try:
    from . import __version__ as REACHABLE_VERSION
except ImportError:
    REACHABLE_VERSION = '0.0.0'

class DashboardV2Generator:
    """
    Generate funnel-based dashboard with Executive + Engineering views
    
    Reads from:
    1. repo.db (preferred - single source of truth, at repo level)
    2. reachable-report.json.gz (fallback)
    
    Outputs:
    - dashboard/index.html
    - dashboard/data.json
    - logo.png
    """
    
    TEMPLATE_PATH = Path(__file__).parent / 'template.html'
    ASSETS_DIR = Path(__file__).parent.parent / 'assets'
    LOGO_PATH = ASSETS_DIR / 'logo.png'  # New logo file
    LOGO_PATH_FALLBACK = ASSETS_DIR / 'sthenos-logo-cropped.png'  # Legacy fallback
    
    # Central location for assets (shared across all dashboards)
    CENTRAL_ASSETS_DIR = Path.home() / '.reachable' / 'assets'
    
    def __init__(self):
        self.data = {}
    
    def generate_from_scan_dir(self, scan_dir: Path) -> Path:
        """
        Generate dashboard from scan directory
        
        Auto-detects best source:
        1. repo.db (preferred - at repo level: ../../repo.db)
        2. reachable-report.json.gz (fallback)
        
        Args:
            scan_dir: Scan output directory
            
        Returns:
            Path to dashboard directory
        """
        scan_dir = Path(scan_dir)
        
        # Try database first (v4.5.x+ preferred)
        # repo.db is at repo level: ~/.reachable/scans/{repo-hash}/repo.db
        # scan_dir is: ~/.reachable/scans/{repo-hash}/{branch}/{timestamp}/
        repo_db_path = scan_dir.parent.parent / 'repo.db'
        if repo_db_path.exists():
            self.data = self._load_from_database(repo_db_path)
        else:
            # Fallback to JSON - try multiple naming conventions
            json_candidates = [
                scan_dir / 'reachable-report.json.gz',
                scan_dir / 'reachable-report_json.gz',  # underscore variant
                scan_dir / 'reachable-report.json',
                scan_dir / 'report.json',
            ]
            
            json_file = None
            for candidate in json_candidates:
                if candidate.exists():
                    json_file = candidate
                    break
            
            if json_file:
                self.data = self._load_from_json(json_file)
            else:
                raise FileNotFoundError(
                    f"No data source found in {scan_dir}. "
                    "Expected: repo.db (at repo level) or reachable-report.json.gz"
                )
        
        # v4.5.8: Add repo-level metadata (scan count, first scan, db size)
        self._add_repo_metadata(scan_dir)
        
        # Create dashboard directory
        dashboard_dir = scan_dir / 'dashboard'
        dashboard_dir.mkdir(exist_ok=True)
        
        # Write data.json
        data_path = dashboard_dir / 'data.json'
        with open(data_path, 'w') as f:
            json.dump(self.data, f, indent=2, default=str)
        
        # Copy template as index.html
        self._create_index_html(dashboard_dir)
        
        return dashboard_dir
    
    def _add_repo_metadata(self, scan_dir: Path):
        """
        Add repo-level metadata from repo.db: scan count, first scan date, db size
        
        Path: scan_dir = ~/.reachable/scans/{repo-hash}/{branch}/{timestamp}/
        repo.db is at: ~/.reachable/scans/{repo-hash}/repo.db
        """
        try:
            # Navigate up to repo root (scan_dir/../..)
            repo_root = scan_dir.parent.parent
            repo_db = repo_root / 'repo.db'
            
            if not repo_db.exists():
                # Fallback to directory counting
                branch_dir = scan_dir.parent
                scan_dirs = sorted([
                    d for d in branch_dir.iterdir() 
                    if d.is_dir() and d.name[0].isdigit() and len(d.name) >= 15
                ])
                self.data['repo_metadata'] = {
                    'scan_number': len(scan_dirs),
                    'first_scan': scan_dirs[0].name[:8] if scan_dirs else '',
                    'db_size_display': 'N/A',
                }
                return
            
            import sqlite3
            conn = sqlite3.connect(str(repo_db))
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            
            # Get scan count
            cursor.execute("SELECT COUNT(*) as cnt FROM scans WHERE status = 'complete'")
            scan_count = cursor.fetchone()['cnt']
            
            # Get first scan date
            cursor.execute("""
                SELECT MIN(timestamp) as first_scan 
                FROM scans WHERE status = 'complete'
            """)
            row = cursor.fetchone()
            first_scan = row['first_scan'] if row else None
            
            # Format first scan date
            first_scan_display = ''
            if first_scan:
                try:
                    from datetime import datetime
                    dt = datetime.fromisoformat(first_scan.replace('Z', '+00:00'))
                    first_scan_display = dt.strftime('%Y-%m-%d')
                except:
                    first_scan_display = first_scan[:10] if len(first_scan) >= 10 else first_scan
            
            conn.close()
            
            # Get DB size
            db_size_bytes = repo_db.stat().st_size
            db_size_mb = round(db_size_bytes / (1024 * 1024), 2)
            
            # Add to data
            self.data['repo_metadata'] = {
                'scan_number': scan_count,
                'first_scan': first_scan_display,
                'db_size_mb': db_size_mb,
                'db_size_display': f"{db_size_mb} MB" if db_size_mb >= 1 else f"{round(db_size_bytes / 1024, 1)} KB",
            }
            
        except Exception as e:
            # Don't fail dashboard generation if metadata fetch fails
            self.data['repo_metadata'] = {'error': str(e)}
    
    def generate_from_report(self, report: Dict[str, Any], output_dir: Path) -> Path:
        """
        Generate dashboard from report dictionary
        
        Args:
            report: Full reachable report data
            output_dir: Where to create dashboard/
            
        Returns:
            Path to dashboard directory
        """
        self.data = self._transform_report(report)
        
        dashboard_dir = output_dir / 'dashboard'
        dashboard_dir.mkdir(exist_ok=True)
        
        # Write data.json
        data_path = dashboard_dir / 'data.json'
        with open(data_path, 'w') as f:
            json.dump(self.data, f, indent=2, default=str)
        
        # Create index.html
        self._create_index_html(dashboard_dir)
        
        return dashboard_dir
    
    def _load_from_database(self, db_path: Path) -> Dict[str, Any]:
        """Load dashboard data directly from SQLite database"""
        conn = sqlite3.connect(str(db_path))
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        
        try:
            # Get scan metadata
            metadata = self._get_scan_metadata(cursor)
            
            # Get issues summary (was 'findings')
            issues_summary = self._get_issues_summary(cursor)
            
            # Get all security issues for table
            issues = self._get_all_issues(cursor)
            
            # Calculate metrics
            metrics = self._calculate_metrics(issues_summary)
            
            # v4.5.10: Read risk_level from scans table (stored at scan time)
            # instead of recalculating with different formula
            risk_level = self._get_stored_risk_level(cursor)
            if not risk_level:
                # Fallback: recalculate if not stored (legacy scans)
                risk_level = self._calculate_risk_level(issues_summary, metrics, issues)
            
            return {
                'version': REACHABLE_VERSION,
                'scan': metadata,
                'risk_level': risk_level,
                'metrics': metrics,
                'summary': self._format_summary(issues_summary),
                'issues': issues,  # Using 'issues' not 'findings'
            }
            
        finally:
            conn.close()
    
    def _get_stored_risk_level(self, cursor) -> Optional[str]:
        """Read risk_level from scans table (v4.5.10 - single source of truth)"""
        try:
            cursor.execute("SELECT risk_level FROM scans ORDER BY id DESC LIMIT 1")
            row = cursor.fetchone()
            if row and row['risk_level']:
                return row['risk_level']
        except:
            pass
        return None

    def _get_scan_metadata(self, cursor) -> Dict[str, Any]:
        """Extract scan metadata from database"""
        # Try scan_summary table
        cursor.execute("SELECT * FROM scan_summary LIMIT 1")
        row = cursor.fetchone()
        
        if row:
            return {
                'repository': row['repo_path'].split('/')[-1] if row['repo_path'] else 'unknown',
                'branch': 'main',  # TODO: Store in DB
                'commit': '',
                'display': row['repo_path'].split('/')[-1] if row['repo_path'] else 'unknown',
            }
        
        return {
            'repository': 'unknown',
            'branch': 'main',
            'commit': '',
            'display': 'unknown',
        }
    
    def _get_issues_summary(self, cursor) -> Dict[str, int]:
        """Get aggregated findings counts from database"""
        cursor.execute("""
            SELECT 
                finding_type,
                severity,
                is_reachable,
                COUNT(*) as count
            FROM findings
            GROUP BY finding_type, severity, is_reachable
        """)
        
        summary = {
            'cves_total': 0,
            'cves_reachable': 0,
            'cves_critical': 0,
            'cves_high': 0,
            'cves_medium': 0,
            'cves_low': 0,
            'secrets_total': 0,
            'secrets_reachable': 0,
            'cwe_total': 0,
            'cwe_reachable': 0,
            'config_total': 0,
            'config_unknown': 0,
            'malware_total': 0,
        }
        
        for row in cursor.fetchall():
            ftype = row['finding_type']
            sev = (row['severity'] or '').upper()
            reachable = row['is_reachable']
            count = row['count']
            
            if ftype == 'cve':
                summary['cves_total'] += count
                if reachable:
                    summary['cves_reachable'] += count
                if sev == 'CRITICAL':
                    summary['cves_critical'] += count
                elif sev == 'HIGH':
                    summary['cves_high'] += count
                elif sev == 'MEDIUM':
                    summary['cves_medium'] += count
                elif sev == 'LOW':
                    summary['cves_low'] += count
            
            elif ftype == 'secret':
                summary['secrets_total'] += count
                if reachable:
                    summary['secrets_reachable'] += count
            
            elif ftype == 'cwe':
                summary['cwe_total'] += count
                if reachable:
                    summary['cwe_reachable'] += count
            
            elif ftype == 'config':
                summary['config_total'] += count
                summary['config_unknown'] += count  # Config is always unknown/env-dependent
            
            elif ftype == 'malware':
                summary['malware_total'] += count
        
        return summary
    
    def _get_all_issues(self, cursor) -> List[Dict[str, Any]]:
        """Get all findings for the issues table"""
        cursor.execute("""
            SELECT 
                id,
                finding_type,
                finding_id,
                severity,
                title,
                description,
                file_path,
                line_number,
                package_name,
                package_version,
                is_reachable,
                reachability_confidence,
                cve_id,
                cwe_id,
                app_reachability_path
            FROM findings
            ORDER BY 
                CASE severity 
                    WHEN 'CRITICAL' THEN 1 
                    WHEN 'HIGH' THEN 2 
                    WHEN 'MEDIUM' THEN 3 
                    WHEN 'LOW' THEN 4 
                    ELSE 5 
                END,
                is_reachable DESC
        """)
        
        findings = []
        for row in cursor.fetchall():
            # Parse call_path from JSON string
            call_path = None
            if row['app_reachability_path']:
                try:
                    call_path = json.loads(row['app_reachability_path'])
                except:
                    call_path = None
            
            findings.append({
                'id': row['finding_id'] or f"{row['finding_type'].upper()}-{row['id']}",
                'type': row['finding_type'].upper(),
                'severity': row['severity'] or 'UNKNOWN',
                'is_reachable': 1 if row['is_reachable'] else 0,
                'title': row['title'] or row['finding_id'] or '',
                'description': row['description'] or '',
                'package': f"{row['package_name'] or ''} {row['package_version'] or ''}".strip(),
                'file_path': row['file_path'] or '',
                'line': row['line_number'],
                'cve_id': row['cve_id'],
                'cwe_id': row['cwe_id'],
                'call_path': call_path,  # v4.5.10: Call path for reachability visualization
            })
        
        return findings
    
    def _load_from_json(self, json_path: Path) -> Dict[str, Any]:
        """Load and transform from JSON report"""
        if str(json_path).endswith('.gz'):
            with gzip.open(json_path, 'rt', encoding='utf-8') as f:
                report = json.load(f)
        else:
            with open(json_path, 'r', encoding='utf-8') as f:
                report = json.load(f)
        
        return self._transform_report(report)
    
    def _transform_report(self, report: Dict[str, Any]) -> Dict[str, Any]:
        """Transform full report to dashboard format with complete metrics"""
        summary = report.get('summary', {})
        totals = summary.get('totals', {})
        risk = summary.get('overall_risk', {})
        metadata = report.get('metadata', {})
        target = metadata.get('analysis_target', {})
        git_info = metadata.get('git_info', {}) or target.get('git', {})
        sandbox = report.get('sandbox', {})
        sandbox_summary = sandbox.get('summary', {})
        
        # Extract repo info
        app_dir = target.get('app_directory', '')
        repo_name = Path(app_dir).name if app_dir else 'unknown'
        branch = git_info.get('branch', 'main')
        commit = git_info.get('commit_short') or (git_info.get('commit_sha') or '')[:8]
        commit_date = git_info.get('commit_date', '')
        
        # Try to get GitHub URL from various sources
        github_url = (
            git_info.get('remote_url') or 
            git_info.get('github_url') or 
            target.get('github_url') or 
            metadata.get('github_url') or
            ''
        )
        # Clean up GitHub URL (remove .git suffix, convert SSH to HTTPS)
        if github_url:
            github_url = github_url.rstrip('/')
            if github_url.endswith('.git'):
                github_url = github_url[:-4]
            if github_url.startswith('git@github.com:'):
                github_url = 'https://github.com/' + github_url[15:]
        
        # Calculate totals for funnel visualization
        # Raw signals (before reachability filtering)
        raw_cves = totals.get('cves_total', 0)
        raw_malware = totals.get('malware_total', 0)
        raw_suspicious = sandbox_summary.get('suspicious', 0)
        raw_secrets = totals.get('secrets_total', 0)
        raw_sast = totals.get('cwe_total', 0)  # SAST = Semgrep code findings
        raw_license = 0  # TODO: Extract from license analysis
        raw_cwe = totals.get('cwe_total', 0)
        
        # Reachable signals (after reachability filtering)
        reach_cves = totals.get('cves_reachable', 0)
        reach_malware = totals.get('malware_total', 0)  # Malware is always "reachable" (critical)
        reach_suspicious = 0  # Sandbox suspicious needs triage
        reach_secrets = totals.get('secrets_reachable', 0) or totals.get('secrets_reachable_actual', 0)
        reach_sast = totals.get('cwe_reachable', 0)
        reach_license = 0
        reach_cwe = totals.get('cwe_reachable', 0)
        
        # Build comprehensive metrics for funnel
        metrics = {
            # CVE/Vulnerable Packages
            'cves_total': raw_cves,
            'cves_reachable': reach_cves,
            'cves_critical': totals.get('cves_critical', 0),
            'cves_high': totals.get('cves_high', 0),
            'cves_medium': totals.get('cves_medium', 0),
            'cves_low': totals.get('cves_low', 0),
            # Malware
            'malware_total': raw_malware,
            'malware_reachable': reach_malware,
            # Suspicious (Sandbox)
            'suspicious_total': raw_suspicious,
            'suspicious_reachable': reach_suspicious,
            # Secrets
            'secrets_total': raw_secrets,
            'secrets_reachable': reach_secrets,
            'secrets_critical': totals.get('secrets_critical', 0),
            # SAST/Code vulnerabilities
            'sast_total': raw_sast,
            'sast_reachable': reach_sast,
            # License
            'license_total': raw_license,
            'license_reachable': reach_license,
            # CWE patterns
            'cwe_total': raw_cwe,
            'cwe_reachable': reach_cwe,
            # Totals
            'raw_total': raw_cves + raw_malware + raw_suspicious + raw_secrets + raw_sast + totals.get('config_total', 0),
            'reachable_total': reach_cves + reach_malware + reach_suspicious + reach_secrets + reach_sast + totals.get('config_total', 0),
            # Other
            'packages_scanned': totals.get('total_packages', 0),
            'source_files_scanned': totals.get('source_files_scanned', 0) or metadata.get('source_files_scanned', 0),
            'sandbox_packages_tested': sandbox.get('packages_tested', 0),
            # v4.4.2: Threat Intel metrics
            'kev_total': totals.get('kev_matches', 0) or summary.get('exploitability', {}).get('kev_matches', 0),
            'epss_high': totals.get('epss_high', 0) or summary.get('exploitability', {}).get('epss_high', 0),
            'threat_intel_total': (totals.get('kev_matches', 0) or 0) + (totals.get('epss_high', 0) or 0),
            # v4.4.2: Supply Chain metrics
            'phantom_deps': totals.get('phantom_deps', 0) or summary.get('supply_chain', {}).get('phantom_deps', 0),
            'shadow_imports': totals.get('shadow_imports', 0) or summary.get('supply_chain', {}).get('shadow_imports', 0),
            'dead_deps': totals.get('dead_deps', 0) or summary.get('supply_chain', {}).get('dead_deps', 0),
            # v4.4.2: Library Health metrics
            'health_critical': totals.get('health_critical', 0) or summary.get('health', {}).get('critical', 0),
            'unhealthy_packages': totals.get('unhealthy_packages', 0) or summary.get('health', {}).get('unhealthy', 0),
            # v4.4.2: Direct vs Transitive dependencies
            'direct_deps': totals.get('direct_deps', 0),
            'transitive_deps': totals.get('transitive_deps', 0),
            # v4.4.4: Threat Intel (KEV/EPSS) - 8 signal types
            'threatintel_total': (totals.get('kev_matches', 0) or 0) + (totals.get('epss_high', 0) or 0),
            'threatintel_reachable': (totals.get('kev_reachable', 0) or totals.get('kev_matches', 0) or 0) + (totals.get('epss_high_reachable', 0) or totals.get('epss_high', 0) or 0),
            # v4.4.4: Phantom Libraries - supply chain risks
            'phantom_total': totals.get('phantom_deps', 0) or summary.get('supply_chain', {}).get('phantom_deps', 0) or 0,
            'phantom_reachable': totals.get('phantom_reachable', 0) or totals.get('phantom_deps', 0) or 0,
            # v4.4.5: Config Issues - env-dependent (Dockerfile, K8s, Terraform)
            'config_total': totals.get('config_total', 0),
            'config_unknown': totals.get('config_unknown', totals.get('config_total', 0)),
            # v4.5.4: Attack Surface metrics
            'entrypoints': totals.get('entrypoints', 0),
            'functions_total': totals.get('functions_total', 0),
            'functions_reachable': totals.get('functions_reachable', 0),
        }
        
        # Build security issues list (not "findings")
        issues = self._extract_issues_from_report(report)
        
        # Recalculate risk level based on reachable issues
        summary_for_risk = {
            'malware_total': metrics.get('malware_total', 0),
            'suspicious_total': metrics.get('suspicious_total', 0),
        }
        risk_level = self._calculate_risk_level(summary_for_risk, metrics, issues)
        
        # Determine scan date
        scan_date = ''
        if commit_date:
            scan_date = commit_date.split(' ')[0] if ' ' in commit_date else commit_date
        
        return {
            'version': report.get('reachable_version') or REACHABLE_VERSION,
            'scan': {
                'repository': repo_name,
                'branch': branch,
                'commit': commit,
                'date': scan_date,
                'display': f"{repo_name} @ {branch}",
                'github_url': github_url,
                'repo_root': app_dir,  # Local path prefix to strip for GitHub links
            },
            'risk_level': risk_level,
            'metrics': metrics,
            'summary': {
                'cves': f"{metrics['cves_total']} total, {metrics['cves_reachable']} reachable",
                'secrets': f"{metrics['secrets_total']} total, {metrics['secrets_reachable']} reachable",
                'malware': f"{metrics['malware_total']} malicious packages",
                'sast': f"{metrics['sast_total']} code issues, {metrics['sast_reachable']} reachable",
            },
            'issues': issues,  # Using 'issues' not 'findings'
        }
    
    def _extract_issues_from_report(self, report: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Extract all security issues from report with remediation and compliance data (v4.4.0)"""
        issues = []
        
        # Extract CVEs from reachable
        for cve_id, cve_data in report.get('reachable', {}).items():
            remediation = cve_data.get('remediation', {})
            raw_sev = cve_data.get('severity', 'MEDIUM')
            is_fixable = cve_data.get('is_fixable', False)
            
            # Determine fix_status
            fix_status = 'fix_available' if is_fixable else 'no_fix'
            if cve_data.get('fix_state') == 'wont-fix':
                fix_status = 'wont_fix'
            
            issues.append({
                'id': cve_id,
                'type': 'CVE',
                'severity': raw_sev,  # CVE severity is already normalized
                'raw_severity': raw_sev,
                'is_reachable': True,
                'reachability_state': 'reachable',
                'title': cve_id,
                'description': cve_data.get('description', ''),
                'message': cve_data.get('description', ''),
                'package': cve_data.get('package', ''),
                'version': cve_data.get('version', ''),
                'file_path': '',
                'is_transitive': cve_data.get('is_transitive', False),
                'fix_available': is_fixable,
                'fix_status': fix_status,
                'call_path': cve_data.get('reachability_path') or cve_data.get('call_path'),  # v4.5.10
                'remediation': {
                    'action': remediation.get('action', 'UPGRADE'),
                    'fixed_in': remediation.get('fixed_in', ''),
                    'summary': remediation.get('summary', ''),
                    'steps': remediation.get('steps', []),
                    'workaround': remediation.get('workaround'),
                    'references': remediation.get('references', []),
                },
                'compliance_mapping': cve_data.get('compliance_mapping', {}),
                'exploitability': cve_data.get('exploitability', {}),
            })
        
        # Extract CVEs from unreachable
        for cve_id, cve_data in report.get('unreachable', {}).items():
            remediation = cve_data.get('remediation', {})
            raw_sev = cve_data.get('severity', 'MEDIUM')
            is_fixable = cve_data.get('is_fixable', False)
            
            # Determine fix_status
            fix_status = 'fix_available' if is_fixable else 'no_fix'
            if cve_data.get('fix_state') == 'wont-fix':
                fix_status = 'wont_fix'
                
            issues.append({
                'id': cve_id,
                'type': 'CVE',
                'severity': raw_sev,  # CVE severity is already normalized
                'raw_severity': raw_sev,
                'is_reachable': False,
                'reachability_state': 'not_reachable',
                'title': cve_id,
                'description': cve_data.get('description', ''),
                'message': cve_data.get('description', ''),
                'package': cve_data.get('package', ''),
                'version': cve_data.get('version', ''),
                'file_path': '',
                'is_transitive': cve_data.get('is_transitive', False),
                'fix_available': is_fixable,
                'fix_status': fix_status,
                'call_path': None,  # Unreachable = no call path
                'remediation': {
                    'action': remediation.get('action', 'MONITOR'),
                    'fixed_in': remediation.get('fixed_in', ''),
                    'summary': remediation.get('summary', ''),
                    'steps': remediation.get('steps', []),
                    'workaround': remediation.get('workaround'),
                    'references': remediation.get('references', []),
                },
                'compliance_mapping': cve_data.get('compliance_mapping', {}),
                'exploitability': cve_data.get('exploitability', {}),
            })
        
        # Extract secrets/CWE/CONFIG from detailed_findings (v4.4.0)
        detailed = report.get('detailed_findings', {})
        
        # Process secrets findings (which includes CWE/SAST findings)
        # Note: detailed_findings.cwe contains the same findings with different IDs,
        # so we only process from secrets to avoid duplication
        secrets_data = detailed.get('secrets', {})
        for idx, finding in enumerate(secrets_data.get('findings', []), 1):
            is_secret = finding.get('is_actual_secret', False)
            
            # Keep raw severity from tool
            raw_sev = finding.get('severity', 'MEDIUM')
            rule_id = finding.get('rule_id', '')
            file_path = finding.get('file', '')
            
            # Determine finding type: SECRET, CONFIG, or CWE
            ftype = self._determine_finding_type(is_secret, rule_id, file_path)
            
            # Normalize for risk calculation (ERROR→HIGH for config, ERROR→CRITICAL for code vulns)
            severity = self._normalize_severity(raw_sev, rule_id, file_path)
            
            # Determine reachability state
            # v4.5.2: Check for UNKNOWN reachability (standalone secrets, config files)
            # CONFIG has UNKNOWN reachability (environment-dependent)
            # Secrets with reachability='unknown' or reachability_confidence='UNKNOWN*' are also unknown
            reachability_field = finding.get('reachability', '').lower()
            reachability_confidence = finding.get('reachability_confidence', '')
            is_reachable = finding.get('is_reachable')
            
            if ftype == 'CONFIG':
                reachability_state = 'unknown'
            elif reachability_field == 'unknown':
                reachability_state = 'unknown'
            elif reachability_confidence and reachability_confidence.startswith('UNKNOWN'):
                reachability_state = 'unknown'
            elif is_reachable is None and 'is_reachable' not in finding:
                # Key not present = unknown
                reachability_state = 'unknown'
            elif is_reachable:
                reachability_state = 'reachable'
            else:
                reachability_state = 'not_reachable'
            
            remediation = finding.get('remediation', {})
            issues.append({
                'id': finding.get('rule_id', f"{ftype}-{idx}"),
                'type': ftype,
                'severity': severity,  # Normalized severity
                'raw_severity': raw_sev,  # Original tool severity
                'is_reachable': is_reachable,
                'reachability_state': reachability_state,
                'title': finding.get('rule_id', ''),
                'description': finding.get('message', ''),
                'message': finding.get('message', ''),
                'package': '',
                'file_path': finding.get('file', ''),
                'line': finding.get('line'),
                'cwe_id': finding.get('cwe_id', ''),
                'call_path': finding.get('reachability_path') or finding.get('call_path'),  # v4.5.10
                'remediation': {
                    'action': remediation.get('action', 'CODE_FIX'),
                    'steps': remediation.get('steps', []),
                    'references': [],
                },
                'compliance_mapping': finding.get('compliance_mapping', {}),
            })
        
        # Extract malware findings (v4.4.0: separate MALWARE vs SUSPICIOUS)
        # v4.5.9: Enhanced to handle both static (GuardDog) and dynamic (Colima sandbox) malware
        malware_data = detailed.get('malware', {})
        for idx, finding in enumerate(malware_data.get('findings', []), 1):
            # Determine if MALWARE (confirmed) or SUSPICIOUS (static only)
            has_dynamic_evidence = finding.get('dynamic_evidence') or finding.get('sandbox_result')
            verdict = 'MALWARE' if has_dynamic_evidence else 'SUSPICIOUS'
            
            # Build evidence structure
            evidence = {}
            if finding.get('static_indicators') or finding.get('guarddog_findings'):
                evidence['static'] = {
                    'scanner': 'GuardDog',
                    'indicators': finding.get('static_indicators', finding.get('guarddog_findings', [])),
                    'confidence': finding.get('static_confidence', 0.0),
                }
            if has_dynamic_evidence:
                evidence['dynamic'] = {
                    'scanner': 'Sandbox',
                    'behaviors': finding.get('dynamic_evidence', finding.get('sandbox_result', {}).get('behaviors', [])),
                    'confidence': finding.get('dynamic_confidence', 0.0),
                }
            
            issues.append({
                'id': finding.get('package', f"MAL-{idx}"),
                'type': verdict,
                'severity': 'CRITICAL' if verdict == 'MALWARE' else 'HIGH',
                'raw_severity': 'CRITICAL' if verdict == 'MALWARE' else 'HIGH',
                'is_reachable': True,  # Malware is always considered reachable (worst case)
                'reachability_state': 'reachable',
                'title': f"Malicious package: {finding.get('package', 'unknown')}",
                'description': finding.get('description', finding.get('reason', '')),
                'message': finding.get('reason', finding.get('description', '')),
                'package': finding.get('package', ''),
                'version': finding.get('version', ''),
                'file_path': '',
                'call_path': finding.get('reachability_path') or finding.get('call_path'),  # v4.5.10
                'evidence': evidence,
                'remediation': {
                    'action': 'REMOVE_IMMEDIATELY',
                    'steps': [
                        f"Remove {finding.get('package', 'the package')} from dependencies",
                        'Audit for any data exfiltration or unauthorized access',
                        'Rotate any credentials that may have been exposed',
                        'Review install-time hooks and scripts',
                    ],
                    'references': finding.get('references', []),
                },
                'compliance_mapping': {
                    'CWE-TOP-25': ['CWE-506'],  # Embedded malicious code
                    'OWASP': ['A08:2021'],  # Software and Data Integrity Failures
                },
            })
        
        # v4.5.9: Extract dynamic malware findings from sandbox results
        dynamic_malware = report.get('dynamic_malware', {}) or report.get('security_scans', {}).get('dynamic_malware', {})
        if dynamic_malware and dynamic_malware.get('verdict') not in ('NOT_RUN', 'CLEAN', None):
            # Add sandbox findings as MALWARE type
            for finding in dynamic_malware.get('findings', []):
                severity = finding.get('severity', 'HIGH')
                if severity == 'CRITICAL' or dynamic_malware.get('verdict') == 'CRITICAL':
                    verdict_type = 'MALWARE'
                else:
                    verdict_type = 'SUSPICIOUS'
                
                pkg_name = finding.get('package', 'unknown')
                issues.append({
                    'id': f"SANDBOX-{pkg_name}-{finding.get('rule', 'unknown')}",
                    'type': verdict_type,
                    'severity': severity,
                    'raw_severity': severity,
                    'is_reachable': True,
                    'reachability_state': 'reachable',
                    'title': f"Dynamic analysis: {finding.get('rule', 'Suspicious behavior')}",
                    'description': finding.get('description', ''),
                    'message': finding.get('description', ''),
                    'package': pkg_name,
                    'version': '',
                    'file_path': '',
                    'call_path': finding.get('reachability_path') or finding.get('call_path'),  # v4.5.10
                    'evidence': {
                        'dynamic': {
                            'scanner': 'Colima Sandbox',
                            'behaviors': [finding.get('evidence', finding.get('description', ''))],
                            'phase': finding.get('phase', 'install'),
                        }
                    },
                    'remediation': {
                        'action': 'INVESTIGATE_IMMEDIATELY',
                        'steps': [
                            f"Review {pkg_name} for malicious behavior",
                            'Check for network calls during installation',
                            'Audit credential access patterns',
                            'Consider removing or replacing the package',
                        ],
                        'references': [],
                    },
                    'compliance_mapping': {
                        'CWE-TOP-25': ['CWE-506'],
                        'OWASP': ['A08:2021'],
                    },
                })
            
            # Add malicious packages from sandbox verdict
            for pkg in dynamic_malware.get('malicious_packages', []):
                if not any(i.get('package') == pkg and i.get('type') == 'MALWARE' for i in issues):
                    issues.append({
                        'id': f"SANDBOX-{pkg}",
                        'type': 'MALWARE',
                        'severity': 'CRITICAL',
                        'raw_severity': 'CRITICAL',
                        'is_reachable': True,
                        'reachability_state': 'reachable',
                        'title': f"Malicious package confirmed: {pkg}",
                        'description': 'Dynamic sandbox analysis confirmed malicious behavior',
                        'message': 'Package exhibited malicious behavior during installation',
                        'package': pkg,
                        'version': '',
                        'file_path': '',
                        'evidence': {
                            'dynamic': {
                                'scanner': 'Colima Sandbox',
                                'behaviors': ['Confirmed malicious during dynamic analysis'],
                                'phase': 'install',
                            }
                        },
                        'remediation': {
                            'action': 'REMOVE_IMMEDIATELY',
                            'steps': [
                                f"Remove {pkg} from dependencies immediately",
                                'Audit for data exfiltration',
                                'Rotate any credentials',
                                'Review git history for when package was added',
                            ],
                            'references': [],
                        },
                        'compliance_mapping': {
                            'CWE-TOP-25': ['CWE-506'],
                            'OWASP': ['A08:2021'],
                        },
                    })
        
        return issues
    
    def _normalize_severity(self, severity: str, rule_id: str = '', file_path: str = '') -> str:
        """
        Normalize Semgrep severity to standard levels.
        
        Mapping:
        - ERROR → CRITICAL (but capped at HIGH for config issues)
        - WARNING → HIGH
        - INFO → LOW
        
        Config issues (Dockerfile, K8s, Terraform, etc.) are capped at HIGH
        because CRITICAL should be reserved for RCE/actively exploited vulns.
        """
        if not severity:
            return 'MEDIUM'
        s = severity.upper()
        
        # Detect if this is a config/infrastructure issue
        is_config_issue = False
        file_lower = (file_path or '').lower()
        rule_lower = (rule_id or '').lower()
        
        config_patterns = [
            'dockerfile', '.yaml', '.yml', 'terraform', '.tf',
            'kubernetes', 'k8s', 'helm', 'kustomize',
            '.json',  # Config files
        ]
        config_rules = [
            'dockerfile.', 'kubernetes.', 'terraform.', 
            'yaml.', 'json.', 'config.', 'misconfig',
        ]
        
        if any(p in file_lower for p in config_patterns):
            is_config_issue = True
        if any(r in rule_lower for r in config_rules):
            is_config_issue = True
        
        # Normalize severity
        if s == 'ERROR':
            # Cap config issues at HIGH - CRITICAL is for RCE/exploited vulns
            return 'HIGH' if is_config_issue else 'CRITICAL'
        if s == 'WARNING':
            return 'HIGH'
        if s == 'INFO':
            return 'LOW'
        return s
    
    def _determine_finding_type(self, is_secret: bool, rule_id: str, file_path: str) -> str:
        """
        Determine finding type: SECRET, CONFIG, or CWE (v4.4.0)
        
        - SECRET: Actual credentials/tokens
        - CONFIG: Dockerfile, Kubernetes, Terraform misconfigurations  
        - CWE: Application code weaknesses
        """
        if is_secret:
            return 'SECRET'
        
        file_lower = (file_path or '').lower()
        rule_lower = (rule_id or '').lower()
        
        # Config patterns in file path
        config_file_patterns = [
            'dockerfile', '.yaml', '.yml', 'terraform', '.tf', '.hcl',
            'kubernetes', 'k8s', 'helm', 'kustomize', 'compose',
        ]
        
        # Config patterns in rule ID
        config_rule_patterns = [
            'dockerfile.', 'kubernetes.', 'terraform.', 'helm.',
            'yaml.', 'json.', 'config.', 'misconfig', 'k8s.',
            'container.', 'cloud.', 'aws.', 'gcp.', 'azure.',
        ]
        
        if any(p in file_lower for p in config_file_patterns):
            return 'CONFIG'
        if any(r in rule_lower for r in config_rule_patterns):
            return 'CONFIG'
        
        return 'CWE'
    
    def _calculate_metrics(self, summary: Dict[str, int]) -> Dict[str, Any]:
        """Calculate dashboard metrics from summary (v4.4.4: 8 signal types)"""
        return {
            'cves_total': summary['cves_total'],
            'cves_reachable': summary['cves_reachable'],
            'cves_critical': summary['cves_critical'],
            'cves_high': summary['cves_high'],
            'cves_no_fix': summary.get('cves_no_fix', 0),
            'security_findings_total': summary['secrets_total'] + summary['cwe_total'] + summary.get('config_total', 0),
            'security_findings_reachable': summary['secrets_reachable'] + summary['cwe_reachable'],
            'security_findings_critical': summary['secrets_reachable'],  # Reachable secrets are critical
            'secrets_total': summary['secrets_total'],
            'secrets_reachable': summary['secrets_reachable'],
            'cwe_total': summary['cwe_total'],
            'cwe_reachable': summary['cwe_reachable'],
            'config_total': summary.get('config_total', 0),
            'config_unknown': summary.get('config_total', 0),  # Config always has UNKNOWN reachability
            'sast_findings': summary['cwe_total'],
            'malware_total': summary['malware_total'],
            'malware_reachable': summary['malware_total'],  # Malware always considered reachable
            'suspicious_total': summary.get('suspicious_total', 0),
            'suspicious_reachable': summary.get('suspicious_reachable', 0),
            # v4.4.4: Threat Intel (KEV/EPSS)
            'threatintel_total': summary.get('threatintel_total', 0),
            'threatintel_reachable': summary.get('threatintel_reachable', summary.get('threatintel_total', 0)),
            # v4.4.4: Phantom Libraries
            'phantom_total': summary.get('phantom_total', 0),
            'phantom_reachable': summary.get('phantom_reachable', summary.get('phantom_total', 0)),
            'packages_scanned': 0,  # TODO: Get from metrics table
            'sandbox_packages_tested': 0,
            'raw_total': (summary['cves_total'] + summary['secrets_total'] + 
                         summary['cwe_total'] + summary['malware_total'] + 
                         summary.get('suspicious_total', 0) + summary.get('config_total', 0) +
                         summary.get('threatintel_total', 0) + summary.get('phantom_total', 0)),
        }
    
    def _calculate_risk_level(self, summary: Dict[str, int], metrics: Dict[str, Any], issues: List[Dict[str, Any]] = None) -> str:
        """
        Calculate overall risk level based on reachable issues.
        
        Priority (highest severity reachable issue determines posture):
        1. Any malware → CRITICAL
        2. Any CRITICAL severity reachable → CRITICAL  
        3. Any KEV or high EPSS reachable → CRITICAL (actively exploited)
        4. Any HIGH severity reachable → HIGH
        5. Any MEDIUM severity reachable → MEDIUM
        6. Otherwise → LOW
        """
        # Malware is always critical
        if summary.get('malware_total', 0) > 0 or summary.get('suspicious_total', 0) > 0:
            return 'CRITICAL'
        
        # Check for actively exploited vulnerabilities (KEV/EPSS amplifiers)
        if metrics.get('kev_total', 0) > 0 or metrics.get('epss_high', 0) > 0:
            return 'CRITICAL'
        
        # Count reachable issues by severity
        issues_list = issues or self.data.get('issues', [])
        reachable_critical = 0
        reachable_high = 0
        reachable_medium = 0
        
        for issue in issues_list:
            if issue.get('reachability_state') == 'reachable' or issue.get('is_reachable'):
                sev = (issue.get('severity') or 'MEDIUM').upper()
                if sev == 'CRITICAL':
                    reachable_critical += 1
                elif sev == 'HIGH':
                    reachable_high += 1
                elif sev == 'MEDIUM':
                    reachable_medium += 1
        
        # Determine posture based on highest reachable severity
        if reachable_critical > 0:
            return 'CRITICAL'
        if reachable_high > 0:
            return 'HIGH'
        if reachable_medium > 0:
            return 'MEDIUM'
        
        return 'LOW'
    
    def _format_summary(self, summary: Dict[str, int]) -> Dict[str, str]:
        """Format summary for display (v4.4.0)"""
        return {
            'cves': f"{summary['cves_total']} total, {summary['cves_reachable']} reachable",
            'cves_no_fix': f"{summary.get('cves_no_fix', 0)} without fix",
            'security_findings': f"{summary['secrets_total'] + summary['cwe_total'] + summary.get('config_total', 0)} total",
            'secrets': f"{summary['secrets_total']} secrets",
            'config': f"{summary.get('config_total', 0)} config issues",
            'cwe': f"{summary['cwe_total']} code weaknesses (CWE)",
            'malware': f"{summary['malware_total']} malicious packages",
            'suspicious': f"{summary.get('suspicious_total', 0)} suspicious packages",
        }
    
    def _setup_logo(self, dashboard_dir: Path):
        """
        Setup logo for dashboard using central location.
        
        Strategy:
        1. Ensure central assets dir exists (~/.reachable/assets/)
        2. Copy logo to central location if not present
        3. Create symlink from dashboard/logo.png → central location
        
        This avoids duplicating the logo file in every dashboard directory.
        """
        import os
        
        # Ensure central assets directory exists
        self.CENTRAL_ASSETS_DIR.mkdir(parents=True, exist_ok=True)
        
        # Central logo location
        central_logo = self.CENTRAL_ASSETS_DIR / 'logo.png'
        
        # Copy logo to central location if not present
        if not central_logo.exists():
            # Try new logo first, then fallback
            if self.LOGO_PATH.exists():
                shutil.copy(self.LOGO_PATH, central_logo)
            elif self.LOGO_PATH_FALLBACK.exists():
                shutil.copy(self.LOGO_PATH_FALLBACK, central_logo)
        
        # Create symlink in dashboard directory
        dashboard_logo = dashboard_dir / 'logo.png'
        
        # Remove existing file/symlink if present
        if dashboard_logo.exists() or dashboard_logo.is_symlink():
            dashboard_logo.unlink()
        
        # Create symlink pointing to central logo
        if central_logo.exists():
            try:
                os.symlink(central_logo, dashboard_logo)
            except OSError:
                # Fallback: copy if symlink fails (e.g., Windows without admin)
                shutil.copy(central_logo, dashboard_logo)
    
    def _create_index_html(self, dashboard_dir: Path):
        """Create index.html from template with embedded data (for file:// support)"""
        index_path = dashboard_dir / 'index.html'
        
        # Setup logo: use central location with symlink to avoid duplication
        self._setup_logo(dashboard_dir)
        
        if self.TEMPLATE_PATH.exists():
            template = self.TEMPLATE_PATH.read_text()
            
            # Get version from package
            version = self.data.get('version') or REACHABLE_VERSION
            
            # Replace {{VERSION}} placeholder in template
            template = template.replace('{{VERSION}}', version)
            
            # Embed data inline to work with file:// protocol (no CORS issues)
            data_json = json.dumps(self.data, default=str)
            
            # Replace the fetch block with inline data (match exact whitespace from template)
            fetch_pattern = '''// Load data
        fetch('data.json')
            .then(r => r.json())
            .then(data => { dashboardData = data; renderDashboard(); })
            .catch(e => {
                console.error('Failed to load data:', e);
                document.getElementById('issuesBody').innerHTML = '<tr><td colspan="11" class="loading">Error loading data. Check console.</td></tr>';
            });'''
            
            inline_data = f'''// Embedded data (works with file:// protocol)
        dashboardData = {data_json};
        renderDashboard();'''
            
            if fetch_pattern in template:
                template = template.replace(fetch_pattern, inline_data)
            else:
                # Fallback: simple replacement of the fetch line
                template = template.replace(
                    "fetch('data.json')",
                    f"(function() {{ dashboardData = {data_json}; renderDashboard(); }})(); // fetch('data.json')"
                )
            
            index_path.write_text(template)
        else:
            # Generate fallback HTML
            self._create_fallback_html(index_path)
    
    def _create_fallback_html(self, path: Path):
        """Create minimal fallback dashboard"""
        html = '''<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>REACHABLE Security Dashboard</title>
    <style>
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background: #0f172a;
            color: #e2e8f0;
            padding: 20px;
            margin: 0;
        }
        .header {
            background: linear-gradient(90deg, #1e40af 0%, #7c3aed 100%);
            padding: 20px;
            border-radius: 12px;
            margin-bottom: 20px;
        }
        .header h1 { margin: 0; font-size: 24px; }
        .error {
            background: #dc2626;
            padding: 20px;
            border-radius: 12px;
            margin: 20px 0;
        }
        .card {
            background: #1e293b;
            padding: 20px;
            border-radius: 12px;
            margin: 10px 0;
        }
        table { width: 100%; border-collapse: collapse; }
        th, td { padding: 10px; text-align: left; border-bottom: 1px solid #334155; }
        th { color: #94a3b8; }
        .badge {
            display: inline-block;
            padding: 2px 8px;
            border-radius: 4px;
            font-size: 12px;
            font-weight: 500;
        }
        .badge-critical { background: #dc2626; color: white; }
        .badge-high { background: #f59e0b; color: black; }
        .badge-medium { background: #eab308; color: black; }
        .badge-low { background: #22c55e; color: white; }
        .badge-reachable { background: #ef4444; color: white; }
        .badge-unreachable { background: #22c55e; color: white; }
    </style>
</head>
<body>
    <div class="header">
        <h1>🔒 REACHABLE Security Dashboard</h1>
        <p id="scanInfo">Loading...</p>
    </div>
    
    <div id="errorContainer"></div>
    
    <div class="card">
        <h2>📊 Summary</h2>
        <div id="summaryContainer">Loading...</div>
    </div>
    
    <div class="card">
        <h2>🔍 Findings</h2>
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Type</th>
                    <th>Severity</th>
                    <th>Reachable</th>
                    <th>Description</th>
                </tr>
            </thead>
            <tbody id="findingsTable">
            </tbody>
        </table>
    </div>
    
    <script>
        fetch('data.json')
            .then(response => response.json())
            .then(data => {
                // Update scan info
                document.getElementById('scanInfo').textContent = 
                    `${data.scan.display} | Risk: ${data.risk_level}`;
                
                // Update summary
                const summary = data.summary;
                document.getElementById('summaryContainer').innerHTML = `
                    <p>CVEs: ${summary.cves}</p>
                    <p>Secrets: ${summary.secrets}</p>
                    <p>SAST: ${summary.sast}</p>
                    <p>Malware: ${summary.malware}</p>
                `;
                
                // Update findings table
                const tbody = document.getElementById('findingsTable');
                data.findings.slice(0, 50).forEach(f => {
                    const sevClass = `badge-${f.severity.toLowerCase()}`;
                    const reachClass = f.is_reachable ? 'badge-reachable' : 'badge-unreachable';
                    tbody.innerHTML += `
                        <tr>
                            <td>${f.id}</td>
                            <td>${f.type}</td>
                            <td><span class="badge ${sevClass}">${f.severity}</span></td>
                            <td><span class="badge ${reachClass}">${f.is_reachable ? 'YES' : 'NO'}</span></td>
                            <td>${(f.description || '').substring(0, 100)}...</td>
                        </tr>
                    `;
                });
            })
            .catch(err => {
                document.getElementById('errorContainer').innerHTML = `
                    <div class="error">
                        <h3>⚠️ Failed to load data</h3>
                        <p>${err.message}</p>
                        <p>Make sure data.json exists in the same directory.</p>
                    </div>
                `;
            });
    </script>
</body>
</html>'''
        path.write_text(html)

def generate_dashboard(scan_dir: Path) -> Path:
    """
    Convenience function to generate dashboard
    
    Args:
        scan_dir: Scan output directory (repo.db at parent level or report JSON)
        
    Returns:
        Path to dashboard directory
    """
    generator = DashboardV2Generator()
    return generator.generate_from_scan_dir(scan_dir)

if __name__ == '__main__':
    import sys
    
    if len(sys.argv) < 2:
        print("Usage: python generator.py <scan_dir>")
        sys.exit(1)
    
    scan_dir = Path(sys.argv[1])
    dashboard_dir = generate_dashboard(scan_dir)
    print(f"✅ Dashboard generated: {dashboard_dir}")
    print(f"   Open: file://{dashboard_dir / 'index.html'}")
