#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.

"""
REACHABLE v4.4.5 - Database Storage Module

Per-repo database architecture as specified in DESIGN_v4.4.0.md:
- ONE repo.db per repository (not per-scan)
- Historical scan tracking via scans table
- Cache tables for SBOM and call graphs
- Automatic retention management
- Eliminates redundant raw/ directory
"""

import sqlite3
import json
import gzip
import hashlib
from pathlib import Path
from typing import Dict, Any, List, Optional, Tuple
from datetime import datetime, timedelta
import time

class RepoDatabase:
    """
    v4.4.5: Per-repository database following DESIGN_v4.4.0.md
    
    Structure:
        ~/.reachable/scans/{repo-hash}/repo.db
        
    Contains:
        - scans: Historical scan metadata
        - findings: All findings with scan_id FK
        - sbom_cache: Cached SBOMs by commit
        - call_graph_cache: Cached call graphs
        - large_objects: Compressed blobs (reports, correlation)
    """
    
    # Retention settings (v4.5.8: 30 days per user request)
    MAX_SCANS_PER_BRANCH = 30
    MAX_SCAN_AGE_DAYS = 30
    
    def __init__(self, db_path: Path):
        """Initialize per-repo database"""
        self.db_path = Path(db_path)
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        
        # Secure the .reachable directory (contains sensitive scan data)
        reachable_home = Path.home() / '.reachable'
        if reachable_home.exists():
            try:
                reachable_home.chmod(0o700)  # Owner only
            except OSError:
                pass  # May fail on some filesystems
        
        self.conn = None
        self._current_scan_id = None
        self._initialize_database()
    
    def _initialize_database(self):
        """Create v4.4.5 schema per DESIGN_v4.4.0.md"""
        self.conn = sqlite3.connect(str(self.db_path))
        self.conn.row_factory = sqlite3.Row  # Enable dict-like access
        
        # Secure the database file (contains sensitive security data)
        try:
            self.db_path.chmod(0o600)  # Owner read/write only
        except OSError:
            pass  # May fail on some filesystems
        
        # Performance optimizations
        self.conn.execute("PRAGMA journal_mode=WAL")
        self.conn.execute("PRAGMA synchronous=NORMAL")
        self.conn.execute("PRAGMA cache_size=10000")
        self.conn.execute("PRAGMA temp_store=MEMORY")
        
        # Create schema
        self.conn.executescript("""
            -- ===========================================
            -- SCANS TABLE: Historical scan tracking
            -- ===========================================
            CREATE TABLE IF NOT EXISTS scans (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                branch TEXT NOT NULL,
                commit_hash TEXT,
                commit_short TEXT,
                scan_dir TEXT,                    -- Path to scan session directory
                timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
                duration_seconds REAL,
                version TEXT,                     -- REACHABLE version
                
                -- Summary stats
                total_findings INTEGER DEFAULT 0,
                reachable_findings INTEGER DEFAULT 0,
                critical_count INTEGER DEFAULT 0,
                high_count INTEGER DEFAULT 0,
                medium_count INTEGER DEFAULT 0,
                low_count INTEGER DEFAULT 0,
                
                -- Risk
                risk_score INTEGER DEFAULT 0,
                risk_level TEXT,                  -- 'CRITICAL', 'HIGH', 'MEDIUM', 'LOW'
                
                -- Status
                status TEXT DEFAULT 'running'     -- 'running', 'complete', 'failed'
            );
            
            -- ===========================================
            -- FINDINGS TABLE: All finding types
            -- ===========================================
            CREATE TABLE IF NOT EXISTS findings (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                scan_id INTEGER NOT NULL REFERENCES scans(id) ON DELETE CASCADE,
                
                -- Finding identification
                finding_type TEXT NOT NULL,       -- 'cve', 'cwe', 'config', 'secret', 'malware', 'suspicious'
                finding_id TEXT,                  -- CVE-ID, rule ID, etc.
                
                -- Severity/Risk
                severity TEXT,                    -- 'CRITICAL', 'HIGH', 'MEDIUM', 'LOW', 'INFO'
                risk_level TEXT,                  -- After all adjustments
                cvss_score REAL,
                
                -- Reachability (two-dimensional per design doc)
                app_reachability TEXT DEFAULT 'UNKNOWN',        -- 'REACHABLE', 'NOT_REACHABLE', 'UNKNOWN'
                app_reachability_confidence TEXT DEFAULT 'LOW', -- 'HIGH', 'MEDIUM', 'LOW'
                app_reachability_path TEXT,                     -- JSON array of function names
                platform_exposure TEXT DEFAULT 'UNKNOWN',       -- 'EXPOSED', 'MITIGATED', 'UNKNOWN'
                
                -- Fix availability (CVEs)
                fix_status TEXT,                  -- 'no_fix', 'fix_available', 'wont_fix'
                fix_version TEXT,
                
                -- Location
                file_path TEXT,
                line_number INTEGER,
                
                -- Package info
                package_name TEXT,
                package_version TEXT,
                
                -- Details
                title TEXT,
                description TEXT,
                cwe_id TEXT,
                secret_type TEXT,
                
                -- Malware evidence (JSON blobs)
                evidence_static TEXT,             -- GuardDog/Semgrep findings
                evidence_dynamic TEXT,            -- Sandbox findings
                
                -- Compliance
                compliance_mapping TEXT,          -- JSON: {framework: [controls]}
                
                -- Metadata
                scanner TEXT,
                raw_data TEXT,                    -- Full original finding as JSON
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            );
            
            -- ===========================================
            -- SBOM CACHE: Reuse across scans
            -- ===========================================
            CREATE TABLE IF NOT EXISTS sbom_cache (
                commit_hash TEXT PRIMARY KEY,
                sbom_format TEXT DEFAULT 'cyclonedx',
                sbom_data BLOB,                   -- gzip compressed
                package_count INTEGER,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            );
            
            -- ===========================================
            -- CALL GRAPH CACHE: Reuse if source unchanged
            -- ===========================================
            CREATE TABLE IF NOT EXISTS call_graph_cache (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                commit_hash TEXT NOT NULL,
                source_hash TEXT NOT NULL,        -- Hash of source files
                graph_data BLOB,                  -- gzip compressed
                function_count INTEGER,
                edge_count INTEGER,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                UNIQUE(commit_hash, source_hash)
            );
            
            -- ===========================================
            -- LARGE OBJECTS: Compressed blob storage
            -- ===========================================
            CREATE TABLE IF NOT EXISTS large_objects (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                scan_id INTEGER REFERENCES scans(id) ON DELETE CASCADE,
                object_type TEXT NOT NULL,        -- 'report', 'correlation', 'vulns'
                compression TEXT DEFAULT 'gzip',
                size_original INTEGER,
                size_compressed INTEGER,
                data BLOB,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                UNIQUE(scan_id, object_type)
            );
            
            -- ===========================================
            -- METRICS: Timing and performance data
            -- ===========================================
            CREATE TABLE IF NOT EXISTS metrics (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                scan_id INTEGER REFERENCES scans(id) ON DELETE CASCADE,
                metric_type TEXT,
                metric_name TEXT,
                metric_value REAL,
                metadata TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            );
            
            -- ===========================================
            -- INDEXES
            -- ===========================================
            CREATE INDEX IF NOT EXISTS idx_scans_branch ON scans(branch);
            CREATE INDEX IF NOT EXISTS idx_scans_timestamp ON scans(timestamp);
            CREATE INDEX IF NOT EXISTS idx_findings_scan ON findings(scan_id);
            CREATE INDEX IF NOT EXISTS idx_findings_type ON findings(finding_type);
            CREATE INDEX IF NOT EXISTS idx_findings_severity ON findings(severity);
            CREATE INDEX IF NOT EXISTS idx_findings_reachability ON findings(app_reachability);
            CREATE INDEX IF NOT EXISTS idx_findings_package ON findings(package_name);
            CREATE INDEX IF NOT EXISTS idx_sbom_commit ON sbom_cache(commit_hash);
            CREATE INDEX IF NOT EXISTS idx_callgraph_commit ON call_graph_cache(commit_hash);
            CREATE INDEX IF NOT EXISTS idx_large_objects_scan ON large_objects(scan_id);
        """)
        
        self.conn.commit()
    
    # =========================================================================
    # SCAN MANAGEMENT
    # =========================================================================
    
    def start_scan(self, branch: str, commit_hash: str, scan_dir: str, version: str) -> int:
        """
        Start a new scan and return scan_id.
        
        All subsequent operations use this scan_id.
        """
        cursor = self.conn.cursor()
        cursor.execute("""
            INSERT INTO scans (branch, commit_hash, commit_short, scan_dir, version, status)
            VALUES (?, ?, ?, ?, ?, 'running')
        """, (branch, commit_hash, commit_hash[:8] if commit_hash else None, scan_dir, version))
        
        self.conn.commit()
        self._current_scan_id = cursor.lastrowid
        return self._current_scan_id
    
    def complete_scan(self, duration_seconds: float, risk_score: int = 0, risk_level: str = None):
        """Mark current scan as complete and update summary stats."""
        if not self._current_scan_id:
            return
        
        # Calculate summary stats from findings
        # v4.5.10: Use UPPER() for case-insensitive severity matching (data has 'Critical', not 'CRITICAL')
        cursor = self.conn.cursor()
        cursor.execute("""
            SELECT 
                COUNT(*) as total,
                SUM(CASE WHEN app_reachability = 'REACHABLE' THEN 1 ELSE 0 END) as reachable,
                SUM(CASE WHEN UPPER(severity) = 'CRITICAL' THEN 1 ELSE 0 END) as critical,
                SUM(CASE WHEN UPPER(severity) = 'HIGH' THEN 1 ELSE 0 END) as high,
                SUM(CASE WHEN UPPER(severity) = 'MEDIUM' THEN 1 ELSE 0 END) as medium,
                SUM(CASE WHEN UPPER(severity) = 'LOW' THEN 1 ELSE 0 END) as low
            FROM findings WHERE scan_id = ?
        """, (self._current_scan_id,))
        
        stats = cursor.fetchone()
        
        cursor.execute("""
            UPDATE scans SET 
                status = 'complete',
                duration_seconds = ?,
                total_findings = ?,
                reachable_findings = ?,
                critical_count = ?,
                high_count = ?,
                medium_count = ?,
                low_count = ?,
                risk_score = ?,
                risk_level = ?
            WHERE id = ?
        """, (
            duration_seconds,
            stats['total'] or 0,
            stats['reachable'] or 0,
            stats['critical'] or 0,
            stats['high'] or 0,
            stats['medium'] or 0,
            stats['low'] or 0,
            risk_score,
            risk_level,
            self._current_scan_id
        ))
        
        self.conn.commit()
    
    def fail_scan(self, error_message: str = None):
        """Mark current scan as failed."""
        if not self._current_scan_id:
            return
        
        self.conn.execute("""
            UPDATE scans SET status = 'failed' WHERE id = ?
        """, (self._current_scan_id,))
        self.conn.commit()
    
    @property
    def scan_id(self) -> Optional[int]:
        """Get current scan ID."""
        return self._current_scan_id
    
    # =========================================================================
    # FINDINGS STORAGE
    # =========================================================================
    
    def store_findings(self, findings: List[Dict[str, Any]], finding_type: str) -> int:
        """
        Store findings using batch insert.
        
        Args:
            findings: List of finding dictionaries
            finding_type: 'cve', 'cwe', 'config', 'secret', 'malware', 'suspicious'
            
        Returns:
            Number of findings stored
        """
        if not findings or not self._current_scan_id:
            return 0
        
        batch_data = []
        
        for f in findings:
            # Map is_reachable to app_reachability
            app_reach = 'UNKNOWN'
            if f.get('is_reachable') is True:
                app_reach = 'REACHABLE'
            elif f.get('is_reachable') is False:
                app_reach = 'NOT_REACHABLE'
            elif f.get('app_reachability'):
                app_reach = f['app_reachability']
            
            batch_data.append((
                self._current_scan_id,
                finding_type,
                f.get('id', f.get('finding_id', f.get('cve_id', ''))),
                f.get('severity', 'MEDIUM'),
                f.get('risk_level'),
                f.get('cvss_score', f.get('cvss', 0.0)),
                app_reach,
                f.get('reachability_confidence', f.get('app_reachability_confidence', 'LOW')),
                json.dumps(f.get('reachability_path', f.get('call_path', []))) if f.get('reachability_path') or f.get('call_path') else None,
                f.get('platform_exposure', 'UNKNOWN'),
                f.get('fix_status'),
                f.get('fix_version', f.get('fixed_in')),
                f.get('file', f.get('file_path', '')),
                f.get('line', f.get('line_number', 0)),
                f.get('package', f.get('package_name', '')),
                f.get('version', f.get('package_version', '')),
                f.get('title', f.get('message', ''))[:500] if f.get('title') or f.get('message') else None,
                f.get('description', '')[:1000] if f.get('description') else None,
                f.get('cwe_id', f.get('cwe', '')),
                f.get('secret_type', f.get('rule_id', '')),
                json.dumps(f.get('evidence_static')) if f.get('evidence_static') else None,
                json.dumps(f.get('evidence_dynamic')) if f.get('evidence_dynamic') else None,
                json.dumps(f.get('compliance_mapping')) if f.get('compliance_mapping') else None,
                f.get('scanner', ''),
                json.dumps(f) if len(json.dumps(f)) < 10000 else None  # Store raw if not too large
            ))
        
        cursor = self.conn.cursor()
        cursor.executemany("""
            INSERT INTO findings (
                scan_id, finding_type, finding_id, severity, risk_level, cvss_score,
                app_reachability, app_reachability_confidence, app_reachability_path,
                platform_exposure, fix_status, fix_version,
                file_path, line_number, package_name, package_version,
                title, description, cwe_id, secret_type,
                evidence_static, evidence_dynamic, compliance_mapping,
                scanner, raw_data
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, batch_data)
        
        self.conn.commit()
        return cursor.rowcount
    
    def store_cves(self, vulns_data: Dict[str, Any]) -> int:
        """Store CVEs from vulns.json format."""
        cves = []
        
        # Handle various vulns.json formats
        if isinstance(vulns_data, list):
            cves = vulns_data
        elif 'matches' in vulns_data:
            # Grype format
            for match in vulns_data.get('matches', []):
                vuln = match.get('vulnerability', {})
                artifact = match.get('artifact', {})
                cves.append({
                    'id': vuln.get('id'),
                    'severity': vuln.get('severity', 'UNKNOWN'),
                    'cvss_score': vuln.get('cvss', [{}])[0].get('metrics', {}).get('baseScore') if vuln.get('cvss') else None,
                    'description': vuln.get('description', '')[:500],
                    'fix_status': 'fix_available' if vuln.get('fix', {}).get('versions') else 'no_fix',
                    'fix_version': ','.join(vuln.get('fix', {}).get('versions', [])) or None,
                    'package': artifact.get('name'),
                    'version': artifact.get('version'),
                    'file_path': artifact.get('locations', [{}])[0].get('path') if artifact.get('locations') else None
                })
        elif 'reachable_cves' in vulns_data or 'unreachable_cves' in vulns_data:
            for cve_id, data in vulns_data.get('reachable_cves', {}).items():
                data['id'] = cve_id
                data['is_reachable'] = True
                cves.append(data)
            for cve_id, data in vulns_data.get('unreachable_cves', {}).items():
                data['id'] = cve_id
                data['is_reachable'] = False
                cves.append(data)
        
        return self.store_findings(cves, 'cve')
    
    # =========================================================================
    # CACHE MANAGEMENT
    # =========================================================================
    
    def get_cached_sbom(self, commit_hash: str) -> Optional[Dict]:
        """Get cached SBOM for commit if exists."""
        cursor = self.conn.cursor()
        cursor.execute("""
            SELECT sbom_data FROM sbom_cache WHERE commit_hash = ?
        """, (commit_hash,))
        
        row = cursor.fetchone()
        if row and row['sbom_data']:
            try:
                return json.loads(gzip.decompress(row['sbom_data']).decode())
            except:
                return None
        return None
    
    def cache_sbom(self, commit_hash: str, sbom_data: Dict, sbom_format: str = 'cyclonedx'):
        """Cache SBOM for commit."""
        compressed = gzip.compress(json.dumps(sbom_data).encode())
        package_count = len(sbom_data.get('components', sbom_data.get('packages', [])))
        
        self.conn.execute("""
            INSERT OR REPLACE INTO sbom_cache (commit_hash, sbom_format, sbom_data, package_count)
            VALUES (?, ?, ?, ?)
        """, (commit_hash, sbom_format, compressed, package_count))
        self.conn.commit()
    
    def get_cached_call_graph(self, commit_hash: str, source_hash: str) -> Optional[Dict]:
        """Get cached call graph if exists."""
        cursor = self.conn.cursor()
        cursor.execute("""
            SELECT graph_data FROM call_graph_cache 
            WHERE commit_hash = ? AND source_hash = ?
        """, (commit_hash, source_hash))
        
        row = cursor.fetchone()
        if row and row['graph_data']:
            try:
                return json.loads(gzip.decompress(row['graph_data']).decode())
            except:
                return None
        return None
    
    def cache_call_graph(self, commit_hash: str, source_hash: str, graph_data: Dict):
        """Cache call graph."""
        compressed = gzip.compress(json.dumps(graph_data).encode())
        function_count = len(graph_data.get('functions', graph_data.get('nodes', [])))
        edge_count = len(graph_data.get('calls', graph_data.get('edges', [])))
        
        self.conn.execute("""
            INSERT OR REPLACE INTO call_graph_cache 
            (commit_hash, source_hash, graph_data, function_count, edge_count)
            VALUES (?, ?, ?, ?, ?)
        """, (commit_hash, source_hash, compressed, function_count, edge_count))
        self.conn.commit()
    
    # =========================================================================
    # LARGE OBJECT STORAGE
    # =========================================================================
    
    def store_large_object(self, object_type: str, data: Any, compress: bool = True) -> Dict:
        """
        Store large object with compression.
        
        Args:
            object_type: 'report', 'correlation', 'vulns', etc.
            data: Data to store (will be JSON serialized)
            compress: Whether to gzip compress
            
        Returns:
            Dict with storage stats
        """
        if not self._current_scan_id:
            return {}
        
        json_data = json.dumps(data) if not isinstance(data, (str, bytes)) else data
        if isinstance(json_data, str):
            json_data = json_data.encode()
        
        original_size = len(json_data)
        
        if compress:
            compressed_data = gzip.compress(json_data)
            compression = 'gzip'
        else:
            compressed_data = json_data
            compression = 'none'
        
        compressed_size = len(compressed_data)
        
        self.conn.execute("""
            INSERT OR REPLACE INTO large_objects 
            (scan_id, object_type, compression, size_original, size_compressed, data)
            VALUES (?, ?, ?, ?, ?, ?)
        """, (self._current_scan_id, object_type, compression, original_size, compressed_size, compressed_data))
        self.conn.commit()
        
        ratio = (1 - compressed_size / original_size) * 100 if original_size > 0 else 0
        return {
            'original_size': original_size,
            'compressed_size': compressed_size,
            'compression_ratio': f"{ratio:.1f}%"
        }
    
    def get_large_object(self, object_type: str, scan_id: int = None) -> Optional[Any]:
        """Retrieve large object."""
        scan_id = scan_id or self._current_scan_id
        if not scan_id:
            return None
        
        cursor = self.conn.cursor()
        cursor.execute("""
            SELECT data, compression FROM large_objects 
            WHERE scan_id = ? AND object_type = ?
        """, (scan_id, object_type))
        
        row = cursor.fetchone()
        if row:
            data = row['data']
            if row['compression'] == 'gzip':
                data = gzip.decompress(data)
            return json.loads(data.decode())
        return None
    
    # =========================================================================
    # METRICS
    # =========================================================================
    
    def store_metrics(self, metrics: Dict[str, Any]):
        """Store scan metrics."""
        if not self._current_scan_id:
            return
        
        batch_data = []
        for metric_type, values in metrics.items():
            if isinstance(values, dict):
                for name, value in values.items():
                    if isinstance(value, (int, float)):
                        batch_data.append((self._current_scan_id, metric_type, name, value, None))
            elif isinstance(values, (int, float)):
                batch_data.append((self._current_scan_id, 'general', metric_type, values, None))
        
        if batch_data:
            self.conn.executemany("""
                INSERT INTO metrics (scan_id, metric_type, metric_name, metric_value, metadata)
                VALUES (?, ?, ?, ?, ?)
            """, batch_data)
            self.conn.commit()
    
    # =========================================================================
    # RETENTION & CLEANUP
    # =========================================================================
    
    def cleanup_old_scans(self, branch: str = None, 
                         max_scans: int = None, 
                         max_age_days: int = None) -> Dict[str, int]:
        """
        Clean up old scan data.
        
        Args:
            branch: Specific branch to clean (None = all)
            max_scans: Keep only this many scans per branch
            max_age_days: Delete scans older than this
            
        Returns:
            Dict with cleanup stats
        """
        max_scans = max_scans or self.MAX_SCANS_PER_BRANCH
        max_age_days = max_age_days or self.MAX_SCAN_AGE_DAYS
        
        cursor = self.conn.cursor()
        deleted_scans = 0
        deleted_findings = 0
        
        # Get branches to process
        if branch:
            branches = [branch]
        else:
            cursor.execute("SELECT DISTINCT branch FROM scans")
            branches = [row['branch'] for row in cursor.fetchall()]
        
        for br in branches:
            # Delete by count (keep last N)
            cursor.execute("""
                SELECT id FROM scans 
                WHERE branch = ? AND status = 'complete'
                ORDER BY timestamp DESC
                LIMIT -1 OFFSET ?
            """, (br, max_scans))
            
            old_ids = [row['id'] for row in cursor.fetchall()]
            
            # Delete by age
            cutoff = datetime.now() - timedelta(days=max_age_days)
            cursor.execute("""
                SELECT id FROM scans 
                WHERE branch = ? AND timestamp < ?
            """, (br, cutoff.isoformat()))
            
            old_ids.extend([row['id'] for row in cursor.fetchall()])
            old_ids = list(set(old_ids))  # Dedupe
            
            if old_ids:
                # Count findings to delete
                placeholders = ','.join('?' * len(old_ids))
                cursor.execute(f"""
                    SELECT COUNT(*) as cnt FROM findings WHERE scan_id IN ({placeholders})
                """, old_ids)
                deleted_findings += cursor.fetchone()['cnt']
                
                # Delete (CASCADE will handle findings, large_objects, metrics)
                cursor.execute(f"""
                    DELETE FROM scans WHERE id IN ({placeholders})
                """, old_ids)
                deleted_scans += cursor.rowcount
        
        # Clean up orphaned cache entries (older than 30 days, not used)
        cursor.execute("""
            DELETE FROM sbom_cache 
            WHERE created_at < datetime('now', '-30 days')
            AND commit_hash NOT IN (SELECT DISTINCT commit_hash FROM scans)
        """)
        
        cursor.execute("""
            DELETE FROM call_graph_cache 
            WHERE created_at < datetime('now', '-30 days')
        """)
        
        self.conn.commit()
        
        # Reclaim space
        self.conn.execute("VACUUM")
        
        return {
            'scans_deleted': deleted_scans,
            'findings_deleted': deleted_findings
        }
    
    # =========================================================================
    # QUERY HELPERS
    # =========================================================================
    
    def get_scan_history(self, branch: str = None, limit: int = 10) -> List[Dict]:
        """Get scan history for branch."""
        cursor = self.conn.cursor()
        
        if branch:
            cursor.execute("""
                SELECT * FROM scans WHERE branch = ? ORDER BY timestamp DESC LIMIT ?
            """, (branch, limit))
        else:
            cursor.execute("""
                SELECT * FROM scans ORDER BY timestamp DESC LIMIT ?
            """, (limit,))
        
        return [dict(row) for row in cursor.fetchall()]
    
    def get_findings_summary(self, scan_id: int = None) -> Dict[str, Any]:
        """Get findings summary for scan."""
        scan_id = scan_id or self._current_scan_id
        if not scan_id:
            return {}
        
        cursor = self.conn.cursor()
        cursor.execute("""
            SELECT 
                finding_type,
                COUNT(*) as total,
                SUM(CASE WHEN app_reachability = 'REACHABLE' THEN 1 ELSE 0 END) as reachable,
                SUM(CASE WHEN severity = 'CRITICAL' THEN 1 ELSE 0 END) as critical,
                SUM(CASE WHEN severity = 'HIGH' THEN 1 ELSE 0 END) as high
            FROM findings 
            WHERE scan_id = ?
            GROUP BY finding_type
        """, (scan_id,))
        
        return {row['finding_type']: dict(row) for row in cursor.fetchall()}
    
    def get_findings(self, scan_id: int = None, 
                    finding_type: str = None,
                    reachable_only: bool = False) -> List[Dict]:
        """Get findings with optional filters."""
        scan_id = scan_id or self._current_scan_id
        if not scan_id:
            return []
        
        query = "SELECT * FROM findings WHERE scan_id = ?"
        params = [scan_id]
        
        if finding_type:
            query += " AND finding_type = ?"
            params.append(finding_type)
        
        if reachable_only:
            query += " AND app_reachability = 'REACHABLE'"
        
        cursor = self.conn.cursor()
        cursor.execute(query, params)
        
        return [dict(row) for row in cursor.fetchall()]
    
    def get_database_stats(self) -> Dict[str, Any]:
        """Get database statistics."""
        cursor = self.conn.cursor()
        
        stats = {}
        
        # Table sizes
        for table in ['scans', 'findings', 'sbom_cache', 'call_graph_cache', 'large_objects']:
            cursor.execute(f"SELECT COUNT(*) as cnt FROM {table}")
            stats[f'{table}_count'] = cursor.fetchone()['cnt']
        
        # Database file size
        stats['db_size_bytes'] = self.db_path.stat().st_size if self.db_path.exists() else 0
        stats['db_size_mb'] = stats['db_size_bytes'] / (1024 * 1024)
        
        return stats
    
    # =========================================================================
    # EXPORT
    # =========================================================================
    
    def export_scan_report(self, scan_id: int = None) -> Dict[str, Any]:
        """Export complete scan report as JSON."""
        scan_id = scan_id or self._current_scan_id
        if not scan_id:
            return {}
        
        cursor = self.conn.cursor()
        
        # Get scan metadata
        cursor.execute("SELECT * FROM scans WHERE id = ?", (scan_id,))
        scan = dict(cursor.fetchone()) if cursor.fetchone() else {}
        
        # Get all findings
        cursor.execute("SELECT * FROM findings WHERE scan_id = ?", (scan_id,))
        findings = [dict(row) for row in cursor.fetchall()]
        
        # Get large objects
        large_objects = {}
        for obj_type in ['correlation', 'vulns']:
            obj = self.get_large_object(obj_type, scan_id)
            if obj:
                large_objects[obj_type] = obj
        
        return {
            'scan': scan,
            'findings': findings,
            **large_objects
        }
    
    # =========================================================================
    # LIFECYCLE
    # =========================================================================
    
    def optimize(self):
        """Optimize database."""
        self.conn.execute("VACUUM")
        self.conn.execute("ANALYZE")
        self.conn.commit()
    
    def close(self):
        """Close database connection."""
        if self.conn:
            self.conn.close()
            self.conn = None

# =============================================================================
# HELPER FUNCTIONS
# =============================================================================

def get_repo_db_path(repo_path: str, reachable_home: Path = None) -> Path:
    """
    Get the path to repo.db for a repository.
    
    Structure: ~/.reachable/scans/{repo-slug}/repo.db
    
    Uses the SAME slug calculation as output_manager.py to ensure
    scan directories and repo.db are in the same location.
    
    The repo.db is shared across all branches of the same repository.
    The `scans` table has a `branch` column to differentiate scans.
    """
    if reachable_home is None:
        reachable_home = Path.home() / '.reachable'
    
    # Import get_repo_slug to ensure consistent path calculation
    # This avoids the bug where database_storage used MD5 but output_manager used SHA256
    from .output_manager import get_repo_slug
    
    repo_slug = get_repo_slug(str(repo_path))
    
    return reachable_home / 'scans' / repo_slug / 'repo.db'

def compute_source_hash(source_dir: Path, extensions: List[str] = None) -> str:
    """Compute hash of source files for cache invalidation."""
    extensions = extensions or ['.py', '.js', '.ts', '.go', '.java', '.kt']
    
    hasher = hashlib.md5()
    
    for ext in extensions:
        for f in sorted(source_dir.rglob(f'*{ext}')):
            try:
                hasher.update(f.read_bytes())
            except:
                pass
    
    return hasher.hexdigest()[:16]

# =============================================================================
# BACKWARD COMPATIBILITY
# =============================================================================

class DatabaseStorage(RepoDatabase):
    """
    Backward compatibility wrapper.
    
    Maps old per-scan DatabaseStorage API to new per-repo RepoDatabase.
    """
    
    def __init__(self, db_path: Path):
        """Initialize with backward compatibility."""
        super().__init__(db_path)
        # Auto-start a scan for compatibility
        self._current_scan_id = None
    
    def store_findings_batch(self, findings: List[Dict], finding_type: str):
        """Backward compatible batch store."""
        if not self._current_scan_id:
            # Create a default scan for backward compatibility
            self._current_scan_id = self.start_scan('default', None, str(self.db_path.parent), 'legacy')
        return self.store_findings(findings, finding_type)

if __name__ == "__main__":
    print("REACHABLE v4.4.5 - Database Storage Module")
    print("=" * 60)
    print("Per-repo database architecture per DESIGN_v4.4.0.md")
    print()
    print("Features:")
    print("  • Per-repo database (not per-scan)")
    print("  • Historical scan tracking")
    print("  • SBOM/call-graph caching")
    print("  • Automatic retention cleanup")
    print("  • Compressed blob storage")
    print("  • Two-dimensional reachability model")
