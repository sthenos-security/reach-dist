// Copyright © 2026 Sthenos Security. All rights reserved.
//
// Joern CPG query script for JS/TS reachability analysis.
// Compatible with Joern v4.x (v4.0.100+)
//
// Joern's NonForkingScriptRunner injects --param values as @main function
// parameters. All helpers must be defined INSIDE exec so that the last
// top-level expression of the script is the @main def itself (not a helper
// def which would evaluate to Unit and trigger E007).

import java.nio.file.{Files, Paths}
import scala.util.Try
import io.shiftleft.semanticcpg.language._

@main def exec(
  inputPath: String,
  entrypoints: String = "",
  outPath: String = "/tmp/call-graph-js.json"
): String = {

  // ── Helpers ────────────────────────────────────────────────────────────────

  def extractPackage(filePath: String): String = {
    val nmPattern = ".*node_modules/(@[^/]+/[^/]+|[^/]+)/.*".r
    filePath match {
      case nmPattern(pkg) => pkg
      case _ =>
        val parts = filePath.split("[./]").filter(p => p.nonEmpty && !p.startsWith("<"))
        if (parts.nonEmpty) parts(0) else ""
    }
  }

  def quote(s: String): String =
    "\"" + s.replace("\\", "\\\\").replace("\"", "\\\"") + "\""

  // ── 1. Load project into CPG ───────────────────────────────────────────────

  importCode(inputPath)

  // ── 2. Resolve entrypoints ─────────────────────────────────────────────────

  val entrypointFiles: Set[String] = entrypoints.split(",")
    .map(_.trim)
    .filter(_.nonEmpty)
    .toSet

  val entrypointMethods: Set[String] =
    if (entrypointFiles.nonEmpty) {
      cpg.method.l
        .filter { m =>
          val fn = m.filename
          entrypointFiles.exists(ep => fn.endsWith(ep) || fn.contains(ep))
        }
        .map(_.fullName)
        .toSet
    } else {
      cpg.method
        .nameExact("main", "handler", "start", "bootstrap", "app")
        .fullName.l
        .toSet
    }

  // ── 3. BFS reachability ────────────────────────────────────────────────────

  val reachableMethods: Set[String] =
    if (entrypointMethods.nonEmpty) {
      entrypointMethods.flatMap { ep =>
        Try {
          cpg.method
            .fullNameExact(ep)
            .repeat(m => m.callee)(_.emit.dedup.maxDepth(15))
            .fullName.l
            .toSet
        }.getOrElse(Set.empty[String])
      }
    } else {
      Set.empty[String]
    }

  // ── 4. Find third-party calls ──────────────────────────────────────────────

  val thirdPartyCalls = cpg.call.l.flatMap { call =>
    Try {
      val calleeFn   = call.methodFullName
      val calleeFile = Try(call.callee.filename.l.headOption.getOrElse("")).getOrElse("")
      val inNodeModules = calleeFile.contains("node_modules") || calleeFn.contains("node_modules")

      if (!inNodeModules) None
      else {
        val callerFile   = Try(call.location.filename).getOrElse("").replace(inputPath, "").stripPrefix("/")
        val callerLine   = call.lineNumber.getOrElse(0)
        val callerFuncFn = Try(call.method.fullName).getOrElse("<module>")
        val callerFunc   = callerFuncFn.split("[./]").lastOption.getOrElse("<module>")
        val pkgName      = extractPackage(if (calleeFile.nonEmpty) calleeFile else calleeFn)

        if (pkgName.isEmpty) None
        else {
          val isReachable = (reachableMethods.contains(callerFuncFn) || reachableMethods.isEmpty).toString
          Some(Map(
            "caller_file"  -> callerFile,
            "caller_line"  -> callerLine.toString,
            "caller_func"  -> callerFunc,
            "callee"       -> calleeFn,
            "package"      -> pkgName,
            "is_reachable" -> isReachable
          ))
        }
      }
    }.getOrElse(None)
  }

  // ── 5. Write JSON output ───────────────────────────────────────────────────

  val jsonLines = thirdPartyCalls.map { m =>
    s"""{"caller_file":${quote(m("caller_file"))},"caller_line":${m("caller_line")},"caller_func":${quote(m("caller_func"))},"callee":${quote(m("callee"))},"package":${quote(m("package"))},"is_reachable":${quote(m("is_reachable"))}}"""
  }

  Files.writeString(Paths.get(outPath), "[\n" + jsonLines.mkString(",\n") + "\n]")

  println(s"joern_query: wrote ${thirdPartyCalls.size} call records to $outPath")
  println(s"joern_query: ${reachableMethods.size} methods reachable from ${entrypointMethods.size} entrypoints")

  s"ok: ${thirdPartyCalls.size} records"
}
