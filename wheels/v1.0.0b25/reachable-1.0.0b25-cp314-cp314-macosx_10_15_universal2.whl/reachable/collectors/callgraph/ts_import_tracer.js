#!/usr/bin/env node
// Copyright © 2026 Sthenos Security. All rights reserved.
//
// ts-morph based import tracer — Layer 3 fallback when Joern is not available.
//
// Traces which source files import which npm packages. Does NOT build a full
// callgraph (layer 4) — only tells us which packages are imported somewhere
// in the source tree reachable from entrypoints.
//
// Usage:
//   node ts_import_tracer.js <srcDir> <outPath> [entrypoints...]
//
// Output JSON: same schema as joern_query.sc output so normalizer is unified.
//   [
//     {
//       "caller_file": "src/api/routes.ts",
//       "caller_line": 1,
//       "caller_func": "<import>",
//       "callee": "<import>",
//       "package": "axios",
//       "is_reachable": "true"
//     }, ...
//   ]
//
// Note: is_reachable is "true" for all results from this tracer because
// import-level tracing can't distinguish reachable from unreachable calls.
// The normalizer treats all ts-morph results as UNKNOWN (not REACHABLE) to
// reflect the lower confidence vs Joern.

const fs = require('fs');
const path = require('path');

const srcDir   = process.argv[2];
const outPath  = process.argv[3] || '/tmp/call-graph-js.json';
const extraEps = process.argv.slice(4);

if (!srcDir) {
  console.error('Usage: node ts_import_tracer.js <srcDir> <outPath> [entrypoints...]');
  process.exit(1);
}

// ── JS/TS extensions ──────────────────────────────────────────────────────────
const EXTENSIONS = new Set(['.ts', '.tsx', '.js', '.jsx', '.mjs', '.cjs']);

// ── Collect all source files (exclude node_modules, dist, build) ─────────────
function collectFiles(dir) {
  const results = [];
  const skipDirs = new Set(['node_modules', 'dist', 'build', '.git', '__pycache__', 'coverage']);

  function walk(current) {
    let entries;
    try { entries = fs.readdirSync(current, { withFileTypes: true }); }
    catch { return; }

    for (const entry of entries) {
      if (entry.isDirectory()) {
        if (!skipDirs.has(entry.name) && !entry.name.startsWith('.')) {
          walk(path.join(current, entry.name));
        }
      } else if (entry.isFile() && EXTENSIONS.has(path.extname(entry.name))) {
        if (!entry.name.endsWith('.test.ts') &&
            !entry.name.endsWith('.spec.ts') &&
            !entry.name.endsWith('.test.js') &&
            !entry.name.endsWith('.spec.js') &&
            !entry.name.endsWith('.config.ts') &&
            !entry.name.endsWith('.config.js')) {
          results.push(path.join(current, entry.name));
        }
      }
    }
  }

  walk(dir);
  return results;
}

// ── Extract import statements from source file ────────────────────────────────
function extractImports(filePath) {
  let source;
  try { source = fs.readFileSync(filePath, 'utf8'); }
  catch { return []; }

  const imports = [];

  // Remove block comments
  const clean = source
    .replace(/\/\*[\s\S]*?\*\//g, '')
    .replace(/\/\/.*$/gm, '');

  // ESM: import ... from '...'
  const esmPattern = /import\s+(?:[\s\S]*?\s+from\s+)?['"]([^'"]+)['"]/g;
  // CJS: require('...')
  const cjsPattern = /require\s*\(\s*['"]([^'"]+)['"]\s*\)/g;
  // Dynamic: import('...')
  const dynPattern = /import\s*\(\s*['"]([^'"]+)['"]\s*\)/g;

  for (const pattern of [esmPattern, cjsPattern, dynPattern]) {
    let m;
    while ((m = pattern.exec(clean)) !== null) {
      const mod = m[1];
      if (!mod.startsWith('.') && !mod.startsWith('/')) {
        // Normalize to package name
        let pkg;
        if (mod.startsWith('@')) {
          const parts = mod.split('/');
          pkg = parts.length >= 2 ? `${parts[0]}/${parts[1]}` : mod;
        } else {
          pkg = mod.split('/')[0];
        }
        // Find approximate line number
        const upTo = source.indexOf(m[0]);
        const line = upTo >= 0 ? source.slice(0, upTo).split('\n').length : 1;
        imports.push({ pkg, line });
      }
    }
  }

  return imports;
}

// ── Detect entrypoints ────────────────────────────────────────────────────────
function detectEntrypoints(dir) {
  const eps = [...extraEps];

  const pkgJsonPath = path.join(dir, 'package.json');
  if (fs.existsSync(pkgJsonPath)) {
    try {
      const pkg = JSON.parse(fs.readFileSync(pkgJsonPath, 'utf8'));
      if (pkg.main) eps.push(path.resolve(dir, pkg.main));
      if (typeof pkg.exports === 'string') eps.push(path.resolve(dir, pkg.exports));
      if (pkg.exports && typeof pkg.exports === 'object') {
        Object.values(pkg.exports).forEach(v => {
          if (typeof v === 'string' && (v.endsWith('.ts') || v.endsWith('.js'))) {
            eps.push(path.resolve(dir, v));
          }
        });
      }
    } catch {}
  }

  // Convention-based fallback
  for (const candidate of [
    'src/index.ts', 'src/app.ts', 'src/server.ts', 'src/main.ts',
    'src/index.js', 'src/app.js', 'src/server.js',
    'index.ts', 'index.js', 'app.ts', 'app.js',
  ]) {
    const full = path.join(dir, candidate);
    if (fs.existsSync(full)) eps.push(full);
  }

  return [...new Set(eps.map(e => path.resolve(e)))];
}

// ── Main ──────────────────────────────────────────────────────────────────────
const srcDirAbs   = path.resolve(srcDir);
const allFiles    = collectFiles(srcDirAbs);
const entrypoints = detectEntrypoints(srcDirAbs);

const results = [];

for (const filePath of allFiles) {
  const relFile = path.relative(srcDirAbs, filePath);
  const imports = extractImports(filePath);

  for (const { pkg, line } of imports) {
    results.push({
      caller_file:  relFile,
      caller_line:  line,
      caller_func:  '<import>',
      callee:       '<import>',
      package:      pkg,
      // ts-morph is import-level only — we can't confirm runtime reachability.
      // Mark "import_traced" so normalizer can apply UNKNOWN (not REACHABLE).
      is_reachable: 'import_traced',
    });
  }
}

// Deduplicate by (file, package)
const seen = new Set();
const deduped = results.filter(r => {
  const key = `${r.caller_file}:${r.package}`;
  if (seen.has(key)) return false;
  seen.add(key);
  return true;
});

fs.writeFileSync(outPath, JSON.stringify(deduped, null, 2));
console.log(`ts_import_tracer: ${deduped.size || deduped.length} import records → ${outPath}`);
console.log(`ts_import_tracer: scanned ${allFiles.length} files, ${entrypoints.length} entrypoints detected`);
