#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.

"""
Pipeline CLI - Distributed CI/CD Execution Support

Five steps (consolidated from seven):

  scan     Syft + Grype combined. Syft writes temp file → Grype reads it → temp deleted.
           SBOM dict cached in repo.db. Output: raw/grype-vulns.json
  secrets  Semgrep secrets + CWE merged → raw/security-findings.json
  malware  GuardDog. SBOM from db.get_cached_sbom(). Output: raw/malware.json
  iac      K8s + Docker Compose scanners. Output: raw/iac.json
  health   Registry health. SBOM from db.get_cached_sbom(). Output: raw/health.json

finalize   RA(grype-vulns.json) → cve-analyzed.json
           ingest(session_dir, db)
           store_package_health()
           complete_scan()
           generate_from_scan_dir()  ← DB → dashboard

Design axioms
─────────────
1. repo.db is the single source of truth.
2. ingester.py is the ONLY code path that writes findings to DB.
3. raw/ files exist solely to feed the ingester.
4. Syft and Grype share a temp file deleted after Grype reads it.
5. finalize reads DB to generate dashboard — never raw JSON.
"""

import json
import logging
import os
import tempfile
import time
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Step registry
# ---------------------------------------------------------------------------

PIPELINE_STEPS = {
    "scan":    "Generate SBOM (Syft) + scan vulnerabilities (Grype) — combined step",
    "secrets": "Scan secrets + CWE with Semgrep — combined, merged output",
    "malware": "Scan for malware with GuardDog (SBOM from DB cache)",
    "iac":     "Scan Infrastructure as Code (Kubernetes, Docker Compose)",
    "health":  "Analyze package health via registry APIs (SBOM from DB cache)",
    "ai":      "Scan for AI/LLM security issues (OWASP LLM Top 10)",
    "dlp":     "Scan for DLP/PII data exposure (taint analysis)",
}

PARALLEL_STEPS: List[str] = ["secrets", "malware", "iac", "health", "ai", "dlp"]

STEP_DEPENDENCIES: Dict[str, List[str]] = {
    "scan":    [],
    "secrets": [],
    "malware": ["scan"],
    "iac":     [],
    "health":  ["scan"],
    "ai":      [],
    "dlp":     [],
}

# ---------------------------------------------------------------------------
# State management — sidecar architecture (zero write contention)
# ---------------------------------------------------------------------------

def get_pipeline_state_path(session_dir: Path) -> Path:
    return session_dir / ".pipeline-state.json"


def _get_step_state_path(session_dir: Path, step_name: str) -> Path:
    return session_dir / f".step-{step_name}.json"


def _write_json_atomic(path: Path, data: Dict[str, Any]) -> None:
    """Atomic write via temp-file + os.replace(). Readers never see partial files."""
    data["updated_at"] = datetime.now().isoformat()
    payload = json.dumps(data, indent=2)
    fd, tmp = tempfile.mkstemp(dir=path.parent, prefix=path.name + ".tmp-")
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            f.write(payload)
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp, path)
    except Exception:
        try:
            os.unlink(tmp)
        except OSError:
            pass
        raise


def _read_json_safe(path: Path) -> Dict[str, Any]:
    try:
        text = path.read_text(encoding="utf-8").strip()
        return json.loads(text) if text else {}
    except (OSError, json.JSONDecodeError):
        return {}


def load_pipeline_state(session_dir: Path) -> Dict[str, Any]:
    """Merge init state + per-step sidecars into unified dict."""
    init_state = _read_json_safe(get_pipeline_state_path(session_dir))
    if not init_state:
        return {}
    steps = init_state.get("steps", {})
    for step_name in list(steps.keys()):
        sidecar = _get_step_state_path(session_dir, step_name)
        if sidecar.exists():
            step_data = _read_json_safe(sidecar)
            if step_data:
                steps[step_name] = step_data
    init_state["steps"] = steps
    return init_state


def save_pipeline_state(session_dir: Path, state: Dict[str, Any]) -> None:
    _write_json_atomic(get_pipeline_state_path(session_dir), state)


def save_step_state(session_dir: Path, step_name: str, step_data: Dict[str, Any]) -> None:
    _write_json_atomic(_get_step_state_path(session_dir, step_name), step_data)


# ---------------------------------------------------------------------------
# pipeline init
# ---------------------------------------------------------------------------

def pipeline_init(args) -> int:
    """Initialize a pipeline session: create session dir, start DB scan record."""
    from reachable import __version__
    from reachable.database.storage import RepoDatabase, get_repo_db_path
    from reachable.output.manager import OutputManager

    repo_path = Path(args.repo).resolve()
    if not repo_path.exists():
        logger.error(f"Error: Repository not found: {repo_path}")
        return 1

    output_mgr = OutputManager(repo_path)
    session_dir = output_mgr.scan_dir
    session_id = output_mgr.timestamp

    branch, commit = _get_git_context(repo_path)

    db_path = get_repo_db_path(repo_path)
    db = RepoDatabase(db_path)
    scan_id = db.start_scan(
        branch=branch,
        commit_hash=commit,
        scan_dir=str(session_dir),
        version=__version__,
    )
    db.close()

    state = {
        "session_id": session_id,
        "repo_path": str(repo_path),
        "repo_name": output_mgr.repo_name,
        "session_dir": str(session_dir),
        "db_path": str(db_path),
        "scan_id": scan_id,
        "branch": branch,
        "commit": commit,
        "created_at": datetime.now().isoformat(),
        "version": __version__,
        "status": "initialized",
        "steps": {step: {"status": "pending"} for step in PIPELINE_STEPS},
    }
    save_pipeline_state(session_dir, state)

    try:
        from reachable.core.context import ScanContext
        scan_ctx = ScanContext(repo_path, session_dir)
        output_mgr.save_scan_plan({
            "timestamp": session_id,
            "repo_path": str(repo_path),
            "repo_name": output_mgr.repo_name,
            "project_type": scan_ctx.project_type,
            "languages": scan_ctx.detected_languages,
            "pipeline_mode": True,
        })
    except Exception:
        pass

    if getattr(args, "json", False):
        print(json.dumps({
            "session_id": session_id,
            "session_dir": str(session_dir),
            "db_path": str(db_path),
            "scan_id": scan_id,
            "repo_name": output_mgr.repo_name,
            "branch": branch,
            "commit": commit,
        }))
    else:
        print(f"Session: {session_id}")
        print(f"Directory: {session_dir}")
        print(f"DB: {db_path}  scan_id={scan_id}")

    return 0


# ---------------------------------------------------------------------------
# pipeline step
# ---------------------------------------------------------------------------

def pipeline_step(args) -> int:
    step_name = args.step
    if step_name not in PIPELINE_STEPS:
        logger.error(f"Error: Unknown step '{step_name}'. Available: {', '.join(PIPELINE_STEPS)}")
        return 1

    session_dir = _resolve_session_dir(args.session)
    if not session_dir:
        logger.error(f"Error: Session not found: {args.session}")
        return 1

    state = load_pipeline_state(session_dir)
    if not state:
        logger.error("Error: Invalid session (no state file)")
        return 1

    repo_path = Path(state["repo_path"])

    for dep in STEP_DEPENDENCIES.get(step_name, []):
        dep_status = state["steps"].get(dep, {}).get("status")
        if dep_status != "complete":
            logger.error(f"Error: '{step_name}' requires '{dep}' to complete first (status: {dep_status})")
            return 1

    started_at = datetime.now().isoformat()
    save_step_state(session_dir, step_name, {
        "status": "running",
        "started_at": started_at,
        "runner": os.environ.get("GITHUB_RUN_ID", os.environ.get("CI_JOB_ID", "local")),
    })

    t0 = time.time()
    try:
        result = _run_step(step_name, repo_path, session_dir, state, args)
        duration = time.time() - t0
        save_step_state(session_dir, step_name, {
            "status": "complete",
            "started_at": started_at,
            "completed_at": datetime.now().isoformat(),
            "duration_seconds": round(duration, 2),
            "result": result,
        })
        if getattr(args, "json", False):
            logger.info(json.dumps({"step": step_name, "status": "complete",
                                    "duration": round(duration, 2), "result": result}))
        else:
            logger.info(f"Step '{step_name}' complete ({duration:.1f}s)")
        return 0
    except Exception as e:
        duration = time.time() - t0
        save_step_state(session_dir, step_name, {
            "status": "failed",
            "started_at": started_at,
            "failed_at": datetime.now().isoformat(),
            "duration_seconds": round(duration, 2),
            "error": str(e),
        })
        logger.error(f"Step '{step_name}' failed: {e}")
        if getattr(args, "verbose", False):
            import traceback
            logger.error(traceback.format_exc())
        return 1


def _run_step(step_name, repo_path, session_dir, state, args):
    if step_name == "scan":
        return _step_scan(repo_path, session_dir, state, args)
    elif step_name == "secrets":
        return _step_secrets(repo_path, session_dir, args)
    elif step_name == "malware":
        return _step_malware(repo_path, session_dir, state, args)
    elif step_name == "iac":
        return _step_iac(repo_path, session_dir, args)
    elif step_name == "health":
        return _step_health(repo_path, session_dir, state, args)
    elif step_name == "ai":
        return _step_ai(repo_path, session_dir, args)
    elif step_name == "dlp":
        return _step_dlp(repo_path, session_dir, args)
    else:
        raise ValueError(f"Unknown step: {step_name}")


# ---------------------------------------------------------------------------
# Step implementations
# ---------------------------------------------------------------------------

def _step_scan(repo_path: Path, session_dir: Path, state: Dict[str, Any], args) -> Dict[str, Any]:
    """Syft (SBOM) + Grype (vulns) in one step. Temp SBOM file deleted after Grype reads it."""
    import subprocess

    from reachable.collectors.vulns.grype import VulnDBManager, get_grype_path, get_syft_path

    raw_dir = session_dir / "raw"
    raw_dir.mkdir(exist_ok=True)

    syft_path = get_syft_path()
    grype_path = get_grype_path()

    # Syft → temp file
    logger.info("  Syft: generating SBOM...")
    fd, sbom_tmp_str = tempfile.mkstemp(suffix=".json", prefix="sbom-")
    sbom_tmp = Path(sbom_tmp_str)
    os.close(fd)
    try:
        syft_r = subprocess.run(
            [str(syft_path), "scan", f"dir:{repo_path}", "-o", "json", "-q"],
            capture_output=True, text=True,
        )
        if syft_r.returncode != 0:
            raise RuntimeError(f"Syft failed: {syft_r.stderr[:500]}")
        sbom_data = json.loads(syft_r.stdout)
        sbom_tmp.write_text(syft_r.stdout, encoding="utf-8")
        artifacts = sbom_data.get("artifacts", [])
        logger.info(f"  Syft: {len(artifacts)} packages")

        # Grype reads the temp SBOM file
        logger.info("  Grype: scanning vulnerabilities...")
        db_mgr = VulnDBManager()
        db_mgr.ensure_fresh(verbose=False)
        grype_r = subprocess.run(
            [str(grype_path), f"sbom:{sbom_tmp}", "-o", "json", "-q"],
            capture_output=True, text=True, env=db_mgr.get_grype_env(),
        )
        if grype_r.returncode != 0:
            raise RuntimeError(f"Grype failed: {grype_r.stderr[:500]}")
        vulns_data = json.loads(grype_r.stdout)
        matches = vulns_data.get("matches", [])
        logger.info(f"  Grype: {len(matches)} CVEs")

        # Write grype raw output for ReachabilityAnalyzer in finalize
        (raw_dir / "grype-vulns.json").write_text(grype_r.stdout, encoding="utf-8")

    finally:
        try:
            sbom_tmp.unlink()
        except OSError:
            pass

    # Cache SBOM in DB for malware + health steps
    db_path = Path(state.get("db_path", ""))
    commit = state.get("commit") or ""
    if db_path.exists() and commit:
        try:
            from reachable.database.storage import RepoDatabase
            db = RepoDatabase(db_path)
            db.cache_sbom(commit, sbom_data)
            db.close()
            logger.info(f"  SBOM cached in DB (commit {commit[:8]})")
        except Exception as e:
            logger.warning(f"  SBOM DB cache failed (malware/health will error): {e}")

    return {
        "file": "raw/grype-vulns.json",
        "packages": len(artifacts),
        "total_cves": len(matches),
        "by_severity": _count_by_severity(matches),
    }


def _step_secrets(repo_path: Path, session_dir: Path, args) -> Dict[str, Any]:
    """Semgrep secrets scan + CWE scan — merged into one security-findings.json."""
    from reachable.collectors.secrets.semgrep import SemgrepScanner

    raw_dir = session_dir / "raw"
    raw_dir.mkdir(exist_ok=True)
    scanner = SemgrepScanner(repo_path)

    logger.info("  Semgrep: secrets scan...")
    secrets_r = scanner.scan_secrets()
    logger.info("  Semgrep: CWE scan...")
    cwe_r = scanner.scan_cwe()

    merged_findings = secrets_r.get("findings", []) + cwe_r.get("findings", [])
    merged = {
        "findings": merged_findings,
        "secrets_count": len(secrets_r.get("findings", [])),
        "cwe_count": len(cwe_r.get("findings", [])),
        "total": len(merged_findings),
    }
    with open(raw_dir / "security-findings.json", "w") as f:
        json.dump(merged, f, indent=2)

    logger.info(f"  Semgrep: {merged['secrets_count']} secrets, {merged['cwe_count']} CWE")
    return {"file": "raw/security-findings.json",
            "secrets": merged["secrets_count"],
            "cwe": merged["cwe_count"],
            "total": merged["total"]}


def _step_malware(repo_path: Path, session_dir: Path, state: Dict[str, Any], args) -> Dict[str, Any]:
    """GuardDog malware scan. Reads SBOM from DB — no file I/O."""
    from reachable.collectors.malware.guarddog import GuardDogScanner

    raw_dir = session_dir / "raw"
    raw_dir.mkdir(exist_ok=True)

    sbom_data = _get_sbom_from_db(state)
    if not sbom_data:
        raise RuntimeError("SBOM not in DB cache — 'scan' step must complete first")

    logger.info("  GuardDog: scanning packages...")
    scanner = GuardDogScanner()
    results = scanner.scan_from_sbom(sbom_data)

    with open(raw_dir / "malware.json", "w") as f:
        json.dump(results, f, indent=2)

    scanned = results.get("packages_scanned", 0)
    malicious = results.get("malicious_count", 0)
    logger.info(f"  GuardDog: {scanned} scanned, {malicious} malicious")
    return {"file": "raw/malware.json", "packages_scanned": scanned, "malicious": malicious}


def _step_iac(repo_path: Path, session_dir: Path, args) -> Dict[str, Any]:
    """K8s + Docker Compose security scan."""
    import dataclasses

    from reachable.iac.docker_compose import DockerComposeScanner
    from reachable.iac.k8s_scanner import K8sSecurityScanner

    raw_dir = session_dir / "raw"
    raw_dir.mkdir(exist_ok=True)

    results = {"findings": [], "total_findings": 0, "by_type": {}}

    logger.info("  K8s scanner...")
    k8s = K8sSecurityScanner()
    k8s_f = k8s.scan_directory(repo_path)
    k8s_dicts = [dataclasses.asdict(f) if dataclasses.is_dataclass(f) else f for f in k8s_f]
    results["findings"].extend(k8s_dicts)
    results["by_type"]["kubernetes"] = len(k8s_f)

    logger.info("  Docker Compose scanner...")
    dc = DockerComposeScanner()
    dc_f = dc.scan_directory(repo_path)
    dc_dicts = [dataclasses.asdict(f) if dataclasses.is_dataclass(f) else f for f in dc_f]
    results["findings"].extend(dc_dicts)
    results["by_type"]["docker"] = len(dc_f)

    results["total_findings"] = len(results["findings"])
    with open(raw_dir / "iac.json", "w") as f:
        json.dump(results, f, indent=2)

    logger.info(f"  IAC: {results['total_findings']} findings")
    return {"file": "raw/iac.json", "total": results["total_findings"], "by_type": results["by_type"]}


def _step_health(repo_path: Path, session_dir: Path, state: Dict[str, Any], args) -> Dict[str, Any]:
    """Package health via registry APIs. Reads SBOM from DB — no file I/O."""
    from reachable.collectors.health.collector import PackageHealthCollector

    raw_dir = session_dir / "raw"
    raw_dir.mkdir(exist_ok=True)

    sbom_data = _get_sbom_from_db(state)
    if not sbom_data:
        raise RuntimeError("SBOM not in DB cache — 'scan' step must complete first")

    logger.info("  Package health checks...")
    collector = PackageHealthCollector(sbom_data=sbom_data)
    report = collector.collect()
    results = report.to_dict()

    with open(raw_dir / "health.json", "w") as f:
        json.dump(results, f, indent=2, default=str)

    total = results.get("total_packages", 0)
    logger.info(f"  Health: {total} packages analyzed")
    return {"file": "raw/health.json", "packages_analyzed": total}


def _step_ai(repo_path: Path, session_dir: Path, args) -> Dict[str, Any]:
    """AI/LLM security scan (OWASP LLM Top 10 + MITRE ATLAS). No dependencies."""
    from reachable.ai import AIScanConfig, AISecurityScanner

    raw_dir = session_dir / "raw"
    raw_dir.mkdir(exist_ok=True)

    logger.info("  AI/LLM security scan...")
    scanner = AISecurityScanner(config=AIScanConfig.full())
    findings_list = list(scanner.scan(repo_path))

    by_owasp: Dict[str, int] = {}
    by_severity: Dict[str, int] = {"ERROR": 0, "WARNING": 0, "INFO": 0}
    for f in findings_list:
        cat = f.owasp_category or "OTHER"
        by_owasp[cat] = by_owasp.get(cat, 0) + 1
        by_severity[f.severity] = by_severity.get(f.severity, 0) + 1

    results = {
        "total": len(findings_list),
        "by_owasp": by_owasp,
        "by_severity": by_severity,
        "findings": [f.to_dict() for f in findings_list],
    }
    with open(raw_dir / "ai-security.json", "w") as f:
        json.dump(results, f, indent=2, default=str)

    logger.info(f"  AI: {len(findings_list)} findings ({by_owasp})")
    return {"file": "raw/ai-security.json", "total": len(findings_list), "by_owasp": by_owasp}


def _step_dlp(repo_path: Path, session_dir: Path, args) -> Dict[str, Any]:
    """DLP/PII taint analysis. No dependencies."""
    from reachable.dlp import DLPScanConfig, DLPScanner

    raw_dir = session_dir / "raw"
    raw_dir.mkdir(exist_ok=True)

    logger.info("  DLP/PII taint scan...")
    scanner = DLPScanner(config=DLPScanConfig.full())
    scanner.scan(repo_path)
    stats = scanner.statistics

    results = {
        "total": stats.get("total_findings", 0),
        "discovery_findings": stats.get("discovery_findings", 0),
        "taint_findings": stats.get("taint_findings", 0),
        "ai_findings": stats.get("ai_findings", 0),
        "by_pii_type": stats.get("by_pii_type", {}),
        "by_severity": stats.get("by_severity", {}),
        "by_sink_type": stats.get("by_sink_type", {}),
        "findings": [f.to_dict() for f in scanner.findings],
    }
    with open(raw_dir / "dlp-security.json", "w") as f:
        json.dump(results, f, indent=2, default=str)

    total = stats.get("total_findings", 0)
    logger.info(f"  DLP: {total} findings")
    return {"file": "raw/dlp-security.json", "total": total}


# ---------------------------------------------------------------------------
# pipeline finalize
# ---------------------------------------------------------------------------

def pipeline_finalize(args) -> int:
    """Run reachability analysis, ingest raw/ files into DB, generate dashboard."""
    session_dir = _resolve_session_dir(args.session)
    if not session_dir:
        logger.error(f"Error: Session not found: {args.session}")
        return 1

    state = load_pipeline_state(session_dir)
    if not state:
        logger.error("Error: Invalid session")
        return 1

    if state["steps"].get("scan", {}).get("status") != "complete":
        logger.error("Error: 'scan' step must complete before finalize")
        return 1

    repo_path = Path(state["repo_path"])
    db_path = Path(state.get("db_path", ""))
    scan_id = state.get("scan_id")

    if not db_path.exists():
        logger.error(f"Error: repo.db not found: {db_path}")
        return 1
    if not scan_id:
        logger.error("Error: scan_id missing from state — re-run pipeline init")
        return 1

    raw_dir = session_dir / "raw"
    raw_dir.mkdir(exist_ok=True)
    t0 = time.time()
    logger.info("Finalizing pipeline...")

    # 1. Reachability analysis: grype-vulns.json → cve-analyzed.json
    logger.info("  Reachability analysis...")
    grype_vulns = raw_dir / "grype-vulns.json"
    if not grype_vulns.exists():
        logger.error("Error: raw/grype-vulns.json missing — 'scan' step output not found")
        return 1

    sbom_data = _get_sbom_from_db(state)
    sbom_file: Optional[Path] = None
    tmp_sbom: Optional[Path] = None

    if sbom_data:
        fd, tmp_str = tempfile.mkstemp(suffix=".json", prefix="sbom-ra-")
        tmp_sbom = Path(tmp_str)
        sbom_file = tmp_sbom
        try:
            with os.fdopen(fd, "w") as f:
                json.dump(sbom_data, f)
        except Exception as e:
            logger.warning(f"  Could not write temp SBOM: {e}")
            tmp_sbom = None
            sbom_file = None
    else:
        for c in [session_dir / "sbom.json.gz", session_dir / "sbom.json"]:
            if c.exists():
                sbom_file = c
                break

    if not sbom_file:
        logger.error("Error: No SBOM available for reachability analysis")
        return 1

    try:
        from reachable.engine.reachability import ReachabilityAnalyzer
        # Load AI findings produced by the 'ai' step (if it ran) so the
        # analyzer can enrich them with call-graph reachability before correlation.
        _ai_findings_for_analyzer = []
        _ai_raw = raw_dir / "ai-security.json"
        if _ai_raw.exists():
            try:
                with open(_ai_raw) as _af:
                    _ai_data = json.load(_af)
                # Findings are plain dicts from to_dict(); analyzer accepts both dicts and AIFinding objects
                _ai_findings_for_analyzer = _ai_data.get("findings", [])
                logger.info(f"  Loaded {len(_ai_findings_for_analyzer)} AI findings for call-graph enrichment")
            except Exception as _ae:
                logger.warning(f"  Could not load ai-security.json (non-fatal): {_ae}")

        analyzer = ReachabilityAnalyzer(
            app_dir=repo_path,
            libs_dir=session_dir / "libs",
            sbom_file=sbom_file,
            vulns_file=grype_vulns,
            verbose=getattr(args, "verbose", False),
            ai_findings=_ai_findings_for_analyzer,
        )
        ra_results = analyzer.analyze()
        with open(raw_dir / "cve-analyzed.json", "w") as f:
            json.dump(ra_results, f, indent=2, default=str)
        logger.info("  cve-analyzed.json written")
    finally:
        if tmp_sbom:
            try:
                tmp_sbom.unlink()
            except OSError:
                pass

    # 1b. Load call-graph.json written by analyzer (vulns_file.parent = raw/)
    #     so the ingester can use it for CWE entrypoint enrichment.
    call_graph = None
    for cg_name in ["call-graph.json", "call-graph-js.json"]:
        cg_path = raw_dir / cg_name
        if cg_path.exists():
            try:
                with open(cg_path) as _cgf:
                    call_graph = json.load(_cgf)
                logger.info(f"  call-graph loaded ({cg_name}) for CWE enrichment")
                break
            except Exception as _cge:
                logger.warning(f"  call-graph load failed ({cg_name}): {_cge}")

    # 2. Ingest all raw/ files into DB (single write pass)
    logger.info("  Ingesting into database...")
    from reachable.database.ingester import ingest as ingest_to_db
    from reachable.database.storage import RepoDatabase

    db = RepoDatabase(db_path)
    db._current_scan_id = scan_id

    # call_graph already loaded above (from raw/call-graph.json written by analyzer)
    # Pass it to ingester so CWE findings get entrypoint-path enrichment.

    ingest_result = ingest_to_db(
        scan_dir=session_dir,
        db=db,
        scan_id=scan_id,
        call_graph=call_graph,
        skip_iac=getattr(args, "skip_iac", False),
    )
    logger.info(f"  Ingested: {ingest_result.total} findings "
                f"({ingest_result.cve_count} CVE, {ingest_result.cwe_count} CWE, "
                f"{ingest_result.secret_count} secret, {ingest_result.malware_count} malware)")

    # 3. Package health (separate table, not via ingester)
    health_file = raw_dir / "health.json"
    if health_file.exists():
        try:
            from reachable.collectors.health.collector import _PackageHealthReport
            with open(health_file) as f:
                health_raw = json.load(f)
            report = _PackageHealthReport._from_dict(health_raw) if hasattr(_PackageHealthReport, "_from_dict") else None
            if report:
                stored = db.store_package_health(report)
                logger.info(f"  Package health: {stored} advisories stored")
        except Exception as e:
            logger.warning(f"  Package health storage skipped: {e}")

    # 4. Complete scan record
    risk_score, risk_level = _calculate_risk(ingest_result)

    try:
        from reachable.collectors.vulns.purl_resolver import PURLResolver
        sbom_for_purl = _get_sbom_from_db(state)
        if sbom_for_purl:
            fd2, tmp2 = tempfile.mkstemp(suffix=".json", prefix="sbom-purl-")
            tmp2_p = Path(tmp2)
            try:
                with os.fdopen(fd2, "w") as f:
                    json.dump(sbom_for_purl, f)
                unresolved = PURLResolver().persist_unresolved(tmp2_p, db=db)
                if unresolved:
                    logger.info(f"  PURL: {len(unresolved)} unresolved tracked")
            finally:
                try:
                    tmp2_p.unlink()
                except OSError:
                    pass
    except Exception as e:
        logger.debug(f"  PURL resolution skipped: {e}")

    db.complete_scan(
        duration_seconds=time.time() - t0,
        risk_score=risk_score,
        risk_level=risk_level,
    )
    db.cleanup_old_scans()
    db.close()

    # 5. Generate dashboard from DB
    logger.info("  Generating dashboard...")
    from reachable.dashboard_v2.generator import DashboardV2Generator
    generator = DashboardV2Generator()
    dashboard_dir = generator.generate_from_scan_dir(session_dir)
    logger.info(f"  Dashboard: {dashboard_dir}")

    state["status"] = "complete"
    state["completed_at"] = datetime.now().isoformat()
    state["duration_seconds"] = round(time.time() - t0, 2)
    state["risk_score"] = risk_score
    state["risk_level"] = risk_level
    save_pipeline_state(session_dir, state)

    duration = time.time() - t0
    if getattr(args, "json", False):
        logger.info(json.dumps({
            "status": "complete", "duration": round(duration, 2),
            "risk_score": risk_score, "risk_level": risk_level,
            "dashboard": str(dashboard_dir),
            "findings": {"cve": ingest_result.cve_count, "cwe": ingest_result.cwe_count,
                         "secret": ingest_result.secret_count, "malware": ingest_result.malware_count,
                         "total": ingest_result.total},
        }))
    else:
        logger.info(f"Pipeline complete ({duration:.1f}s)")
        logger.info(f"  Risk: {risk_level} (score={risk_score})")
        logger.info(f"  {ingest_result.total} findings total  |  "
                    f"dashboard: {dashboard_dir / 'index.html'}")

    fail_on = getattr(args, "fail_on", "none")
    if fail_on != "none":
        return _check_fail_threshold(ingest_result, fail_on, db_path, scan_id,
                                     raw_dir=raw_dir)
    return 0


# ---------------------------------------------------------------------------
# pipeline status
# ---------------------------------------------------------------------------

def pipeline_status(args) -> int:
    session_dir = _resolve_session_dir(args.session)
    if not session_dir:
        logger.error(f"Error: Session not found: {args.session}")
        return 1
    state = load_pipeline_state(session_dir)
    if not state:
        logger.error("Error: Invalid session")
        return 1
    if getattr(args, "json", False):
        logger.info(json.dumps(state, indent=2))
        return 0
    logger.info(f"Pipeline: {state['session_id']}")
    logger.info(f"Repo:     {state.get('repo_name', '?')}")
    logger.info(f"Status:   {state['status']}")
    logger.info(f"Created:  {state['created_at']}")
    logger.info("Steps:")
    for sn, si in state["steps"].items():
        st = si.get("status", "unknown")
        icon = {"pending": "○", "running": "◉", "complete": "✓", "failed": "✗"}.get(st, "?")
        dur = si.get("duration_seconds", "")
        dur_s = f" ({dur}s)" if dur else ""
        logger.info(f"  {icon} {sn:<12} {st}{dur_s}")
    return 0


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _resolve_session_dir(session: str) -> Optional[Path]:
    if not session:
        return None
    p = Path(session)
    if p.exists() and p.is_dir():
        return p
    scans_dir = Path.home() / ".reachable" / "scans"
    if scans_dir.exists():
        for repo_dir in scans_dir.iterdir():
            if not repo_dir.is_dir():
                continue
            for branch_dir in repo_dir.iterdir():
                if not branch_dir.is_dir():
                    continue
                c = branch_dir / session
                if c.exists():
                    return c
    return None


def _get_git_context(repo_path: Path):
    import subprocess
    branch, commit = "unknown", None
    try:
        r = subprocess.run(["git", "rev-parse", "--abbrev-ref", "HEAD"],
                           cwd=str(repo_path), capture_output=True, text=True, timeout=5)
        if r.returncode == 0:
            branch = r.stdout.strip() or "unknown"
    except Exception:
        pass
    try:
        r = subprocess.run(["git", "rev-parse", "HEAD"],
                           cwd=str(repo_path), capture_output=True, text=True, timeout=5)
        if r.returncode == 0:
            commit = r.stdout.strip() or None
    except Exception:
        pass
    return branch, commit


def _get_sbom_from_db(state: Dict[str, Any]) -> Optional[Dict]:
    db_path_str = state.get("db_path", "")
    commit = state.get("commit", "")
    if not db_path_str or not commit:
        return None
    db_path = Path(db_path_str)
    if not db_path.exists():
        return None
    try:
        from reachable.database.storage import RepoDatabase
        db = RepoDatabase(db_path)
        sbom = db.get_cached_sbom(commit)
        db.close()
        return sbom
    except Exception as e:
        logger.debug(f"SBOM DB cache read failed: {e}")
        return None


def _count_by_severity(matches: list) -> Dict[str, int]:
    counts: Dict[str, int] = {"CRITICAL": 0, "HIGH": 0, "MEDIUM": 0, "LOW": 0, "UNKNOWN": 0}
    for m in matches:
        sev = (m.get("vulnerability", {}).get("severity") or "UNKNOWN").upper()
        counts[sev] = counts.get(sev, 0) + 1
    return counts


def _calculate_risk(ingest_result) -> tuple:
    score = (ingest_result.cve_count * 10 + ingest_result.cwe_count * 3 +
             ingest_result.secret_count * 5 + ingest_result.malware_count * 20)
    if score >= 200: return score, "CRITICAL"
    if score >= 100: return score, "HIGH"
    if score >= 50:  return score, "MEDIUM"
    if score > 0:    return score, "LOW"
    return 0, "NONE"


def _check_fail_threshold(ingest_result, fail_on: str, db_path: Path, scan_id: int,
                          raw_dir: Optional[Path] = None) -> int:
    """Gate CI exit code on finding severity.

    CICD-FIX-01: Use RiskEngine verdicts from cve-analyzed.json as the
    authoritative severity source, not findings.severity in the DB.

    Background
    ----------
    The DB findings table stores severity written by normalize_cves(), which
    uses a simplified 6-branch rule (CVSS severity × reachability only).
    RiskEngine._determine_risk_level() has 12 branches and additionally
    considers KEV, Metasploit modules, Exploit-DB, and EPSS scores.

    Concrete divergence examples
    ----------------------------
    • CVE reachable + in CISA KEV:
        DB severity  = HIGH  (CVSS 7.9 × REACHABLE → HIGH via normalizer)
        RiskEngine   = CRITICAL  (reachable + KEV → CRITICAL, 1-48h SLA)
        --fail-on high would NOT trigger from DB but SHOULD.

    • CVE unreachable + in CISA KEV:
        DB severity  = MEDIUM  (CVSS 7.9 × NOT_REACHABLE → MEDIUM via normalizer)
        RiskEngine   = LOW, MONITOR  (unreachable + KEV → verify manually)
        --fail-on medium WOULD trigger from DB but SHOULD NOT.

    Fix
    ---
    1. Load cve-analyzed.json (written by ReachabilityAnalyzer.analyze() in
       finalize before this function is called).
    2. For each CVE, read verdict["level"]: 1=CRITICAL 2=HIGH 3=MEDIUM 4=LOW 5=INFO.
    3. Count CVEs whose RiskEngine verdict level is at or above the threshold.
    4. Fall back to the old DB query only if cve-analyzed.json is unavailable
       (e.g. reachability step failed), so --fail-on still does something useful.

    Non-CVE findings (secrets, CWE, malware) are unchanged: they have no
    RiskEngine verdict so we continue to count them from the DB as before.
    """
    if fail_on == "any" and ingest_result.total > 0:
        return 1

    # RiskLevel enum values: CRITICAL=1, HIGH=2, MEDIUM=3, LOW=4, INFO=5
    threshold_level = {"critical": 1, "high": 2, "medium": 3}.get(fail_on)
    if threshold_level is None:
        return 0

    # ------------------------------------------------------------------
    # Path 1: RiskEngine verdicts from cve-analyzed.json (preferred)
    # ------------------------------------------------------------------
    if raw_dir is not None:
        cve_analyzed = raw_dir / "cve-analyzed.json"
        if cve_analyzed.exists():
            try:
                with open(cve_analyzed) as f:
                    report = json.load(f)

                cve_count = 0
                for bucket in ("reachable", "unreachable"):
                    for cve_id, cve_data in report.get(bucket, {}).items():
                        verdict = cve_data.get("verdict", {})
                        level = verdict.get("level")
                        # level is an int (RiskLevel.value): 1=CRITICAL … 5=INFO
                        # A CVE breaches the threshold when its level <= threshold_level
                        # (lower int = higher severity)
                        if isinstance(level, int) and level <= threshold_level:
                            cve_count += 1

                # Non-CVE findings: secrets, CWE, malware — count from DB
                non_cve_count = 0
                sevs_str = {1: ("CRITICAL",), 2: ("CRITICAL", "HIGH"),
                            3: ("CRITICAL", "HIGH", "MEDIUM")}[threshold_level]
                try:
                    from reachable.database.storage import RepoDatabase
                    db = RepoDatabase(db_path)
                    db._current_scan_id = scan_id
                    ph = ",".join("?" * len(sevs_str))
                    cur = db.conn.cursor()
                    # Exclude CVE findings — they are gated via RiskEngine above
                    cur.execute(
                        f"SELECT COUNT(*) FROM findings "
                        f"WHERE scan_id=? AND UPPER(severity) IN ({ph}) "
                        f"AND finding_type != 'cve'",
                        (scan_id, *sevs_str),
                    )
                    non_cve_count = cur.fetchone()[0]
                    db.close()
                except Exception:
                    pass  # non-fatal — CVE gate already correct

                total = cve_count + non_cve_count
                logger.info(
                    f"  Threshold check (--fail-on {fail_on}): "
                    f"{cve_count} CVE(s) via RiskEngine + "
                    f"{non_cve_count} non-CVE finding(s) via DB = {total} total"
                )
                return 1 if total > 0 else 0

            except Exception as e:
                logger.warning(
                    f"  cve-analyzed.json verdict read failed ({e}), "
                    f"falling back to DB severity"
                )

    # ------------------------------------------------------------------
    # Path 2: Fallback — DB findings.severity (old behaviour)
    # Reached only if cve-analyzed.json is missing or unreadable.
    # ------------------------------------------------------------------
    logger.warning(
        "  CICD-FIX-01 fallback: using DB findings.severity for threshold check. "
        "RiskEngine enrichments (KEV, Metasploit, EPSS) are NOT reflected."
    )
    sevs = {1: ("CRITICAL",), 2: ("CRITICAL", "HIGH"),
            3: ("CRITICAL", "HIGH", "MEDIUM")}[threshold_level]
    try:
        from reachable.database.storage import RepoDatabase
        db = RepoDatabase(db_path)
        db._current_scan_id = scan_id
        ph = ",".join("?" * len(sevs))
        cur = db.conn.cursor()
        cur.execute(
            f"SELECT COUNT(*) FROM findings WHERE scan_id=? AND UPPER(severity) IN ({ph})",
            (scan_id, *sevs),
        )
        count = cur.fetchone()[0]
        db.close()
        return 1 if count > 0 else 0
    except Exception:
        return 0


# ---------------------------------------------------------------------------
# CLI wiring
# ---------------------------------------------------------------------------

def setup_pipeline_parser(subparsers) -> None:
    pp = subparsers.add_parser("pipeline", help="Distributed CI/CD pipeline commands")
    subs = pp.add_subparsers(dest="pipeline_command")

    ip = subs.add_parser("init", help="Initialize pipeline session")
    ip.add_argument("repo", help="Path to repository")
    ip.add_argument("--json", action="store_true")
    ip.add_argument("--verbose", "-v", action="store_true")

    sp = subs.add_parser("step", help="Run a single pipeline step")
    sp.add_argument("step", choices=list(PIPELINE_STEPS.keys()))
    sp.add_argument("--session", "-s", required=True)
    sp.add_argument("--json", action="store_true")
    sp.add_argument("--verbose", "-v", action="store_true")
    sp.add_argument("--skip-iac", action="store_true")
    sp.add_argument("--no-ai", action="store_true", dest="disable_ai", help="Skip AI/LLM scan")
    sp.add_argument("--no-dlp", action="store_true", dest="disable_dlp", help="Skip DLP/PII scan")

    fp = subs.add_parser("finalize", help="Merge results and generate dashboard")
    fp.add_argument("--session", "-s", required=True)
    fp.add_argument("--fail-on", choices=["critical","high","medium","any","none"], default="none")
    fp.add_argument("--skip-iac", action="store_true")
    fp.add_argument("--json", action="store_true")
    fp.add_argument("--verbose", "-v", action="store_true")

    stp = subs.add_parser("status", help="Show pipeline status")
    stp.add_argument("--session", "-s", required=True)
    stp.add_argument("--json", action="store_true")


def pipeline_command(args) -> int:
    if not hasattr(args, "pipeline_command") or not args.pipeline_command:
        logger.info("Usage: reachctl pipeline <init|step|finalize|status>")
        logger.info("Steps: " + ", ".join(PIPELINE_STEPS.keys()))
        return 1
    dispatch = {"init": pipeline_init, "step": pipeline_step,
                "finalize": pipeline_finalize, "status": pipeline_status}
    fn = dispatch.get(args.pipeline_command)
    if fn:
        return fn(args)
    logger.error(f"Unknown pipeline command: {args.pipeline_command}")
    return 1
