// Fixture: dlp_patch · TypeScript · PII in logging (email)
// pii_type=email  pii_field=user.email  flow_type=logging
import { Logger } from './logger';

const logger = new Logger('auth');

export function processLogin(user: { id: string; email: string; role: string }) {
  // VULNERABLE: CWE-359 · line 9 — raw email in log
  logger.info(`Login attempt: id=${user.id} email=${user.email} role=${user.role}`);
  return { success: true, userId: user.id };
}
