// Fixture: dlp_patch · TypeScript · PII in API response (password hash)
// pii_type=password  pii_field=user.passwordHash  flow_type=transmission
import { Request, Response } from 'express';

export async function getUser(req: Request, res: Response) {
  const user = await db.findUser(req.params.id);
  // VULNERABLE: CWE-359 · line 8 — passwordHash exposed in response
  res.json({
    id: user.id,
    email: user.email,
    passwordHash: user.passwordHash,
    role: user.role,
  });
}
