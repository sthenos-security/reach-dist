// Fixture: code_patch · CWE-89 SQL Injection · TypeScript
// VULNERABLE: template literal in SQL query · line 10
import { Pool } from 'pg';

const pool = new Pool();

export async function getUser(userId: string): Promise<object> {
  // VULNERABLE: CWE-89 · line 10
  const result = await pool.query(`SELECT * FROM users WHERE id = ${userId}`);
  return result.rows[0] || null;
}
