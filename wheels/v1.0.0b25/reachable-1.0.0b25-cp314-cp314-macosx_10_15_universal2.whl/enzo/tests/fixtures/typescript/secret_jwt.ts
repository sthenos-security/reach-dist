// Fixture: secret_rotation · TypeScript
// VULNERABLE: hardcoded JWT secret · line 5
import jwt from 'jsonwebtoken';

// VULNERABLE: CWE-798 · line 5
const JWT_SECRET = "my-super-secret-jwt-key-do-not-share";
const TOKEN_EXPIRY = "24h";

export function signToken(payload: object): string {
  return jwt.sign(payload, JWT_SECRET, { expiresIn: TOKEN_EXPIRY });
}

export function verifyToken(token: string): object {
  return jwt.verify(token, JWT_SECRET) as object;
}
