// Fixture: code_patch · CWE-78 Command Injection · TypeScript
// VULNERABLE: user input in exec call · line 9
import { exec } from 'child_process';
import { promisify } from 'util';

const execAsync = promisify(exec);

export async function runDig(hostname: string): Promise<string> {
  // VULNERABLE: CWE-78 · line 9
  const { stdout } = await execAsync(`dig +short ${hostname}`);
  return stdout;
}
