// Fixture: code_patch · CWE-79 XSS · TypeScript/Express
// VULNERABLE: unsanitized user input in HTML response · line 10
import express, { Request, Response } from 'express';

const app = express();

app.get('/search', (req: Request, res: Response) => {
  const query = req.query.q as string;
  // VULNERABLE: CWE-79 · line 10
  res.send(`<h1>Results for: ${query}</h1>`);
});

export default app;
