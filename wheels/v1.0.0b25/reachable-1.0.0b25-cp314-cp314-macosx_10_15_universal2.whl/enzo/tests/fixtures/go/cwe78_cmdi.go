// Fixture: code_patch · CWE-78 Command Injection · Go
// VULNERABLE: user input passed to shell command · line 12
package scanner

import (
	"os/exec"
)

func RunNmap(target string) (string, error) {
	// VULNERABLE: CWE-78 · line 12
	cmd := exec.Command("sh", "-c", "nmap -sV "+target)
	out, err := cmd.Output()
	return string(out), err
}
