module example.com/app

go 1.21

require (
	github.com/gin-gonic/gin v1.9.0
	golang.org/x/crypto v0.0.0-20220214200702-86341886e292
)
