// Fixture: code_patch · CWE-22 Path Traversal · Go
// VULNERABLE: unsanitized path in file open · line 13
package reports

import (
	"os"
)

const baseDir = "/app/reports"

func ReadReport(filename string) (string, error) {
	// VULNERABLE: CWE-22 · line 13
	data, err := os.ReadFile(baseDir + "/" + filename)
	return string(data), err
}
