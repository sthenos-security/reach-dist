// Fixture: code_patch · CWE-89 SQL Injection · Go
// VULNERABLE: string concat in SQL query · line 14
package db

import "database/sql"

func GetUser(db *sql.DB, username string) (map[string]interface{}, error) {
	// VULNERABLE: CWE-89 · line 14
	query := "SELECT id, username, email FROM users WHERE username = '" + username + "'"
	row := db.QueryRow(query)
	var id int
	var name, email string
	if err := row.Scan(&id, &name, &email); err != nil {
		return nil, err
	}
	return map[string]interface{}{"id": id, "username": name, "email": email}, nil
}
