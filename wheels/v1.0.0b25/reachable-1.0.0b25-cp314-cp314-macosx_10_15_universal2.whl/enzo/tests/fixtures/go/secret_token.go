// Fixture: secret_rotation · Go
// VULNERABLE: hardcoded bearer token · line 8
package api

import "net/http"

// VULNERABLE: CWE-798 · line 8
const bearerToken = "ghp_a3f7c9d2e1b4f8a2c6d9e3b7f1a4c8d2e5f"

func NewClient() *http.Client {
	return &http.Client{}
}

func AuthHeader() string {
	return "Bearer " + bearerToken
}
