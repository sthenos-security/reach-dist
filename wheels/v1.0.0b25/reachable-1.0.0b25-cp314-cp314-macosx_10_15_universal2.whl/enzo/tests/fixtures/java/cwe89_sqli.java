// Fixture: code_patch · CWE-89 SQL Injection · Java
// VULNERABLE: Statement.execute with string concat · line 14
import java.sql.*;

public class UserRepository {
    private final Connection connection;

    public UserRepository(Connection connection) {
        this.connection = connection;
    }

    public ResultSet getUser(String username) throws SQLException {
        Statement stmt = connection.createStatement();
        // VULNERABLE: CWE-89 · line 14
        String query = "SELECT * FROM users WHERE username = '" + username + "'";
        return stmt.executeQuery(query);
    }
}
