// Fixture: code_patch · CWE-326 Weak Cryptography · Java
// VULNERABLE: MD5 for password hashing · line 12
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class PasswordHasher {

    public String hashPassword(String password) throws NoSuchAlgorithmException {
        // VULNERABLE: CWE-326 · line 12
        MessageDigest md = MessageDigest.getInstance("MD5");
        byte[] hash = md.digest(password.getBytes());
        StringBuilder sb = new StringBuilder();
        for (byte b : hash) sb.append(String.format("%02x", b));
        return sb.toString();
    }
}
