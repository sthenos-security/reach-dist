#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.

"""
Scan Context Logger - Provides clear context about what's being scanned
"""

from pathlib import Path
from typing import Optional, List

class ScanContext:
    """Manages and displays scan context for clarity"""
    
    def __init__(self, repo_path: Path, output_dir: Path):
        self.repo_path = repo_path
        self.output_dir = output_dir
        self.repo_name = repo_path.name
        
        # Detect project structure (fast operations only)
        self.is_monorepo = self._detect_monorepo()
        self.detected_languages = self._detect_languages()
        self.project_type = self._detect_project_type()
        
        # Defer slow operations - will be computed on first access
        self._subprojects = None
        self._total_files = None
        self._ecosystem_map = None
    
    @property
    def subprojects(self):
        """Lazy load subprojects detection"""
        if self._subprojects is None:
            self._subprojects = self._detect_subprojects()
        return self._subprojects
    
    @property
    def total_files(self):
        """Lazy load file counts"""
        if self._total_files is None:
            self._total_files = self._count_files()
        return self._total_files
    
    @property
    def ecosystem_map(self):
        """Lazy load ecosystem map"""
        if self._ecosystem_map is None:
            self._ecosystem_map = self._build_ecosystem_map()
        return self._ecosystem_map
    
    def _count_files(self) -> dict:
        """Count files by language"""
        counts = {
            'python': len(list(self.repo_path.rglob('*.py'))),
            'javascript': len(list(self.repo_path.rglob('*.js'))) + len(list(self.repo_path.rglob('*.ts'))),
            'go': len(list(self.repo_path.rglob('*.go'))),
            'rust': len(list(self.repo_path.rglob('*.rs'))),
            'java': len(list(self.repo_path.rglob('*.java'))),
        }
        return {k: v for k, v in counts.items() if v > 0}
    
    def _detect_subprojects(self) -> List[dict]:
        """Detect subprojects in monorepo"""
        subprojects = []
        
        # Look for package.json files (Node.js projects)
        for pkg_json in self.repo_path.rglob('package.json'):
            # Skip node_modules
            if 'node_modules' in str(pkg_json):
                continue
            
            rel_path = pkg_json.parent.relative_to(self.repo_path)
            project_name = str(rel_path) if str(rel_path) != '.' else 'root'
            
            # Try to read package.json for name
            try:
                import json
                with open(pkg_json) as f:
                    data = json.load(f)
                    name = data.get('name', project_name)
            except:
                name = project_name
            
            subprojects.append({
                'name': name,
                'path': str(rel_path),
                'type': 'Node.js',
                'manifest': 'package.json'
            })
        
        # Look for go.mod files (Go projects)
        for go_mod in self.repo_path.rglob('go.mod'):
            rel_path = go_mod.parent.relative_to(self.repo_path)
            project_name = str(rel_path) if str(rel_path) != '.' else 'root'
            
            subprojects.append({
                'name': project_name,
                'path': str(rel_path),
                'type': 'Go',
                'manifest': 'go.mod'
            })
        
        # Look for Python projects (pyproject.toml, requirements.txt)
        python_projects_found = False
        for py_manifest in list(self.repo_path.rglob('pyproject.toml')) + list(self.repo_path.rglob('requirements.txt')):
            if 'venv' in str(py_manifest) or 'site-packages' in str(py_manifest):
                continue
                
            rel_path = py_manifest.parent.relative_to(self.repo_path)
            project_name = str(rel_path) if str(rel_path) != '.' else 'root'
            
            # Skip if already added
            if any(sp['path'] == str(rel_path) for sp in subprojects):
                continue
            
            subprojects.append({
                'name': project_name,
                'path': str(rel_path),
                'type': 'Python',
                'manifest': py_manifest.name
            })
            python_projects_found = True
        
        # If we have Python files but no Python projects, create a standalone entry
        if not python_projects_found:
            py_files = list(self.repo_path.rglob('*.py'))
            py_files = [f for f in py_files if 'venv' not in str(f) and 'site-packages' not in str(f) and '.egg' not in str(f)]
            if py_files:
                subprojects.append({
                    'name': 'Standalone Python Scripts',
                    'path': 'root',
                    'type': 'Python',
                    'manifest': f'{len(py_files)} .py files'
                })
        
        # Look for Cargo.toml (Rust)
        for cargo_toml in self.repo_path.rglob('Cargo.toml'):
            rel_path = cargo_toml.parent.relative_to(self.repo_path)
            project_name = str(rel_path) if str(rel_path) != '.' else 'root'
            
            subprojects.append({
                'name': project_name,
                'path': str(rel_path),
                'type': 'Rust',
                'manifest': 'Cargo.toml'
            })
        
        return subprojects
    
    def _detect_monorepo(self) -> bool:
        """Detect if this is a monorepo"""
        # Check for monorepo indicators
        indicators = [
            'lerna.json',
            'pnpm-workspace.yaml',
            'nx.json',
            'turbo.json',
            'rush.json'
        ]
        
        for indicator in indicators:
            if (self.repo_path / indicator).exists():
                return True
        
        # Check for multiple package.json or go.mod files
        package_jsons = list(self.repo_path.rglob('package.json'))
        go_mods = list(self.repo_path.rglob('go.mod'))
        
        return len(package_jsons) > 1 or len(go_mods) > 1
    
    def _detect_languages(self) -> List[str]:
        """Detect programming languages in repo (excluding vendor directories)"""
        languages = []
        
        # Helper to check if files exist outside vendor directories
        def has_files_outside_vendor(pattern):
            for f in self.repo_path.rglob(pattern):
                # Skip vendor directories
                path_str = str(f)
                if any(skip in path_str for skip in ['node_modules', 'vendor', 'site-packages', '.git', 'venv']):
                    continue
                return True
            return False
        
        # Python
        if has_files_outside_vendor('*.py'):
            languages.append('Python')
        
        # JavaScript/TypeScript  
        if has_files_outside_vendor('*.js') or has_files_outside_vendor('*.ts') or has_files_outside_vendor('*.jsx') or has_files_outside_vendor('*.tsx'):
            languages.append('JavaScript/TypeScript')
        
        # Go
        if has_files_outside_vendor('*.go'):
            languages.append('Go')
        
        # Rust
        if has_files_outside_vendor('*.rs'):
            languages.append('Rust')
        
        # Java
        if has_files_outside_vendor('*.java'):
            languages.append('Java')
        
        # C/C++ - Only if actually in source, not vendored
        if has_files_outside_vendor('*.c') or has_files_outside_vendor('*.cpp') or has_files_outside_vendor('*.cc'):
            languages.append('C/C++')
        
        return languages if languages else ['Unknown']
    
    def _detect_project_type(self) -> str:
        """Detect project type"""
        if (self.repo_path / 'package.json').exists():
            return 'Node.js'
        if (self.repo_path / 'go.mod').exists():
            return 'Go Module'
        if (self.repo_path / 'Cargo.toml').exists():
            return 'Rust Cargo'
        if (self.repo_path / 'pom.xml').exists():
            return 'Java Maven'
        if (self.repo_path / 'requirements.txt').exists() or (self.repo_path / 'pyproject.toml').exists():
            return 'Python'
        if (self.repo_path / 'Gemfile').exists():
            return 'Ruby'
        
        return 'Generic'
    
    def print_scan_header(self):
        """Print detailed scan context header"""
        import sys
        import platform
        from datetime import datetime
        
        # Import version from __init__ (reads from root VERSION file)
        from . import __version__
        
        print()
        print("=" * 70)
        print(f"REACHABLE v{__version__} - Vulnerability Reachability Analysis")
        print("=" * 70)
        print()
        
        # Show timestamp
        scan_time = datetime.now()
        print(f"🕐 Scan Started:    {scan_time.strftime('%Y-%m-%d %H:%M:%S')}")
        
        # Show Python and system info
        py_version = f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}"
        print(f"🐍 Python:          {py_version} ({platform.system()} {platform.machine()})")
        print()
        
        print("📂 SCAN CONTEXT:")
        print(f"   Repository:      {self.repo_path}")
        print(f"   Repo Name:       {self.repo_name}")
        
        # Get git info
        git_info = self._get_git_info()
        if git_info:
            print(f"   Git Branch:      {git_info.get('branch', 'N/A')}")
            print(f"   Git Commit:      {git_info.get('commit', 'N/A')[:12]}...")
            if git_info.get('dirty'):
                print(f"   Git Status:      ⚠️  Uncommitted changes")
        
        print(f"   Project Type:    {self.project_type}")
        print(f"   Languages:       {', '.join(self.detected_languages)}")
        print(f"   Monorepo:        {'Yes' if self.is_monorepo else 'No'}")
        
        # Show file counts
        if self.total_files:
            print()
            print("CODE INVENTORY:")
            total_all = sum(self.total_files.values())
            print(f"   Total Files:     {total_all}")
            for lang, count in sorted(self.total_files.items(), key=lambda x: -x[1]):
                pct = (count / total_all * 100) if total_all > 0 else 0
                print(f"      └─ {lang.capitalize()}: {count} ({pct:.1f}%)")
        
        print()
        print("📁 OUTPUT LOCATION:")
        print(f"   Scan Directory:  {self.output_dir}")
        if '/.reachable/scans/' in str(self.output_dir):
            print(f"   Latest Link:     ~/.reachable/scans/{self.repo_name}/latest/")
        print()
    
    def _get_git_info(self) -> dict:
        """Get git branch and commit info"""
        import subprocess
        
        try:
            # Get current branch
            branch_result = subprocess.run(
                ['git', 'rev-parse', '--abbrev-ref', 'HEAD'],
                cwd=str(self.repo_path),
                capture_output=True,
                text=True,
                timeout=5
            )
            branch = branch_result.stdout.strip() if branch_result.returncode == 0 else None
            
            # Get commit SHA
            commit_result = subprocess.run(
                ['git', 'rev-parse', 'HEAD'],
                cwd=str(self.repo_path),
                capture_output=True,
                text=True,
                timeout=5
            )
            commit = commit_result.stdout.strip() if commit_result.returncode == 0 else None
            
            # Check for uncommitted changes
            status_result = subprocess.run(
                ['git', 'status', '--porcelain'],
                cwd=str(self.repo_path),
                capture_output=True,
                text=True,
                timeout=5
            )
            dirty = bool(status_result.stdout.strip()) if status_result.returncode == 0 else False
            
            if branch or commit:
                return {'branch': branch, 'commit': commit, 'dirty': dirty}
        except:
            pass
        
        return None
    
    def print_scan_plan(self):
        """Print scan plan summary for monorepo"""
        if not self.is_monorepo or not self.subprojects:
            return
        
        print()
        print("=" * 70)
        print("SCAN PLAN - MONOREPO DETECTED")
        print("=" * 70)
        print()
        print(f"Found {len(self.subprojects)} subproject(s) to analyze:")
        print()
        
        # Group by type
        by_type = {}
        for sp in self.subprojects:
            by_type.setdefault(sp['type'], []).append(sp)
        
        for proj_type, projects in sorted(by_type.items()):
            # Make display name consistent with scan context
            display_type = proj_type
            if proj_type == "Node.js":
                display_type = "Node.js (JS/TS)"
            
            print(f"   {display_type} Projects ({len(projects)}):")
            for proj in projects:
                path_display = f"./{proj['path']}" if proj['path'] != 'root' else './root'
                print(f"      • {proj['name']:<30} ({path_display})")
                print(f"        └─ Manifest: {proj['manifest']}")
        
        print()
        print("🔧 ANALYSIS ARCHITECTURE:")
        print("   ✓ Mode: MULTI-LANGUAGE ANALYSIS")
        print("      → Per-language call graphs (Python, JavaScript, Go, Java, Kotlin, Scala, Groovy)")
        print("      → Cross-project import tracking")
        print("      → FFI boundary detection (ctypes, cgo, subprocess)")
        print("      → Note: Full Bazel constraint checking not yet implemented")
        print()
        print("   ✓ SBOM: Unified covering entire monorepo")
        print("   ✓ CVE Detection: Grype scanner (direct + transitive dependencies)")
        print("   ✓ Reachability: From all entrypoints → all code paths")
        print("   ✓ Secrets Detection: TruffleHog + Semgrep (API keys, tokens, credentials)")
        print("   ✓ CWE Analysis: Semgrep (code weaknesses mapped to CWE)")
        print("   ✓ Malware Detection: GuardDog + Malware Sandbox (DevNull)")
        print("      → Static: Typosquatting, backdoors, suspicious patterns")
        print("      → Dynamic: Process spawning, network calls, file system access")
        print("   ✓ Package Health: Maintenance, popularity, outdated analysis")
        print("   ✓ Threat Correlation: Multi-signal risk scoring with amplification")
        # v4.3.1: Removed redundant SLA and Compliance tables
        # These are now shown only in the compliance section of the report
        print()
        print("=" * 70)
        print()
    
    def print_phase_header(self, phase: int, total: int, phase_name: str, tool: str, description: str = ""):
        """Print detailed phase header with context"""
        print(f"[{phase}/{total}] {phase_name}")
        print(f"   🔧 Tool:         {tool}")
        if description:
            print(f"   Action:       {description}")
    
    def print_subphase(self, subphase_name: str, tool: str = "", context: str = ""):
        """Print subphase with tool context"""
        if tool:
            print(f"   [{subphase_name}] - Tool: {tool}")
        else:
            print(f"   [{subphase_name}]")
        
        if context:
            print(f"      Context: {context}")
    
    def _build_ecosystem_map(self) -> dict:
        """
        Build map of packages to ecosystems based on subproject locations
        
        Returns:
            Dict mapping inferred package patterns to ecosystems
        """
        ecosystem_map = {}
        
        for subproject in self.subprojects:
            ecosystem = self._normalize_ecosystem(subproject['type'])
            manifest_path = self.repo_path / subproject['path'] / subproject['manifest']
            
            if not manifest_path.exists():
                continue
            
            # Extract package names from manifests
            if ecosystem == 'npm' and manifest_path.name == 'package.json':
                packages = self._extract_npm_packages(manifest_path)
                for pkg in packages:
                    ecosystem_map[pkg] = 'npm'
            
            elif ecosystem == 'go' and manifest_path.name == 'go.mod':
                packages = self._extract_go_packages(manifest_path)
                for pkg in packages:
                    ecosystem_map[pkg] = 'go'
            
            elif ecosystem == 'python' and manifest_path.name in ('requirements.txt', 'pyproject.toml'):
                packages = self._extract_python_packages(manifest_path)
                for pkg in packages:
                    ecosystem_map[pkg] = 'python'
        
        return ecosystem_map
    
    def _normalize_ecosystem(self, project_type: str) -> str:
        """Normalize project type to ecosystem"""
        if project_type == 'Node.js':
            return 'npm'
        elif project_type == 'Python':
            return 'python'
        elif project_type == 'Go':
            return 'go'
        elif project_type == 'Rust':
            return 'rust'
        elif project_type == 'Java Maven':
            return 'maven'
        else:
            return 'unknown'
    
    def _extract_npm_packages(self, package_json_path: Path) -> List[str]:
        """Extract package names from package.json"""
        try:
            import json
            with open(package_json_path) as f:
                data = json.load(f)
            
            packages = []
            for dep_type in ['dependencies', 'devDependencies', 'peerDependencies']:
                if dep_type in data:
                    packages.extend(data[dep_type].keys())
            
            return packages
        except:
            return []
    
    def _extract_go_packages(self, go_mod_path: Path) -> List[str]:
        """Extract package names from go.mod"""
        try:
            packages = []
            with open(go_mod_path) as f:
                for line in f:
                    line = line.strip()
                    if line.startswith('require'):
                        parts = line.split()
                        if len(parts) >= 2:
                            packages.append(parts[1])
                    elif not line.startswith(')') and not line.startswith('('):
                        parts = line.split()
                        if parts and parts[0] not in ('require', 'module', 'go', 'replace', 'exclude'):
                            packages.append(parts[0])
            
            return packages
        except:
            return []
    
    def _extract_python_packages(self, manifest_path: Path) -> List[str]:
        """Extract package names from requirements.txt or pyproject.toml"""
        try:
            packages = []
            
            if manifest_path.name == 'requirements.txt':
                with open(manifest_path) as f:
                    for line in f:
                        line = line.strip()
                        if line and not line.startswith('#'):
                            pkg = line.split('==')[0].split('>=')[0].split('<=')[0].split('~=')[0].strip()
                            packages.append(pkg)
            
            elif manifest_path.name == 'pyproject.toml':
                with open(manifest_path) as f:
                    in_deps = False
                    for line in f:
                        line = line.strip()
                        if line.startswith('[') and 'dependencies' in line:
                            in_deps = True
                        elif line.startswith('['):
                            in_deps = False
                        elif in_deps and '=' in line:
                            pkg = line.split('=')[0].strip().strip('"').strip("'")
                            packages.append(pkg)
            
            return packages
        except:
            return []
    
    def get_ecosystem_hint(self, package_name: str) -> str:
        """
        Get ecosystem hint for a package name
        
        Returns:
            'npm', 'python', 'go', or 'unknown'
        """
        # Direct match
        if package_name in self.ecosystem_map:
            return self.ecosystem_map[package_name]
        
        # Pattern matching for Go packages
        if package_name.startswith(('github.com/', 'golang.org/', 'gopkg.in/')):
            return 'go'
        
        return 'unknown'

def log_with_context(message: str, indent: int = 0, tool: str = "", context: str = ""):
    """Log message with optional tool and context"""
    indent_str = "   " * indent
    
    parts = [indent_str]
    if tool:
        parts.append(f"[{tool}] ")
    parts.append(message)
    
    print(''.join(parts))
    
    if context:
        print(f"{indent_str}   → {context}")
