#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.

"""
REACHABLE Correlation Metrics & Logging System

Provides comprehensive tracking, logging, and metrics for all correlation
engine features and inputs. Every signal, amplifier, and decision is logged
with full transparency.
"""

from dataclasses import dataclass, field
from typing import Dict, List, Any, Optional
from datetime import datetime
from enum import Enum
import json

class LogLevel(Enum):
    DEBUG = "DEBUG"
    INFO = "INFO"
    WARN = "WARN"
    ERROR = "ERROR"
    SIGNAL = "SIGNAL"
    METRIC = "METRIC"
    FEATURE = "FEATURE"
    AMPLIFIER = "AMPLIFIER"
    DECISION = "DECISION"

@dataclass
class LogEntry:
    timestamp: str
    level: LogLevel
    component: str
    message: str
    entity: str = ""
    signal_type: str = ""
    value: Any = None
    score: float = 0.0
    details: Dict = field(default_factory=dict)
    
    def to_dict(self) -> Dict:
        return {
            'timestamp': self.timestamp,
            'level': self.level.value,
            'component': self.component,
            'message': self.message,
            'entity': self.entity,
            'signal_type': self.signal_type,
            'value': str(self.value) if not isinstance(self.value, (int, float, bool, str, type(None))) else self.value,
            'score': round(self.score, 4) if self.score else 0,
            'details': self.details
        }

@dataclass
class FeatureMetrics:
    feature_name: str
    enabled: bool = True
    items_received: int = 0
    items_processed: int = 0
    items_skipped: int = 0
    items_with_findings: int = 0
    processing_time_ms: float = 0.0
    errors: int = 0
    warnings: int = 0
    signals_generated: int = 0
    signals_amplified: int = 0
    total_score_contribution: float = 0.0
    max_score_contribution: float = 0.0
    
    def to_dict(self) -> Dict:
        return {
            'feature_name': self.feature_name,
            'enabled': self.enabled,
            'counts': {
                'received': self.items_received,
                'processed': self.items_processed,
                'skipped': self.items_skipped,
                'with_findings': self.items_with_findings
            },
            'processing_time_ms': round(self.processing_time_ms, 2),
            'errors': self.errors,
            'warnings': self.warnings,
            'signals': {
                'generated': self.signals_generated,
                'amplified': self.signals_amplified,
                'total_contribution': round(self.total_score_contribution, 2),
                'avg_contribution': round(self.total_score_contribution / self.signals_generated, 2) if self.signals_generated > 0 else 0,
                'max_contribution': round(self.max_score_contribution, 2)
            }
        }

@dataclass
class AmplifierMetrics:
    amplifier_name: str
    multiplier: float
    times_applied: int = 0
    entities_affected: List[str] = field(default_factory=list)
    total_score_boost: float = 0.0
    
    def to_dict(self) -> Dict:
        return {
            'amplifier_name': self.amplifier_name,
            'multiplier': self.multiplier,
            'times_applied': self.times_applied,
            'entities_affected': len(self.entities_affected),
            'entities_list': self.entities_affected[:10],
            'total_score_boost': round(self.total_score_boost, 2),
            'avg_boost_per_entity': round(self.total_score_boost / self.times_applied, 2) if self.times_applied > 0 else 0
        }

class CorrelationMetricsCollector:
    def __init__(self):
        self.start_time = datetime.now()
        self.end_time: Optional[datetime] = None
        
        self.feature_metrics: Dict[str, FeatureMetrics] = {
            'cve': FeatureMetrics('CVE Scanner'),
            'reachability': FeatureMetrics('Reachability Analysis'),
            'kev': FeatureMetrics('CISA KEV Lookup'),
            'epss': FeatureMetrics('EPSS Scoring'),
            'cvss': FeatureMetrics('CVSS Scoring'),
            'exploit_db': FeatureMetrics('Exploit-DB Lookup'),
            'metasploit': FeatureMetrics('Metasploit Lookup'),
            'malware_package': FeatureMetrics('GuardDog Malware'),
            'malware_code': FeatureMetrics('Semgrep Malware'),
            'secrets': FeatureMetrics('Secrets Scanner'),
            'health_maintenance': FeatureMetrics('Maintenance Health'),
            'health_popularity': FeatureMetrics('Popularity Health'),
            'health_outdated': FeatureMetrics('Outdated Health'),
            'phantom_deps': FeatureMetrics('Phantom Dependencies'),
            'shadow_imports': FeatureMetrics('Shadow Imports'),
            'sast': FeatureMetrics('SAST Findings'),
        }
        
        self.amplifier_metrics: Dict[str, AmplifierMetrics] = {
            'reachable': AmplifierMetrics('Reachable Code', 1.0),
            'unreachable': AmplifierMetrics('Unreachable Code', 0.2),
            'multiple_threats': AmplifierMetrics('Multiple Threats', 1.5),
            'exploit_available': AmplifierMetrics('Public Exploit', 2.0),
            'metasploit_available': AmplifierMetrics('Metasploit Module', 2.5),
            'in_kev': AmplifierMetrics('CISA KEV', 3.0),
            'malware_detected': AmplifierMetrics('Malware Detected', 5.0),
        }
        
        self.total_entities = 0
        self.entities_by_type: Dict[str, int] = {'package': 0, 'function': 0, 'file': 0, 'secret': 0}
        self.entities_by_risk: Dict[str, int] = {'CRITICAL': 0, 'HIGH': 0, 'MEDIUM': 0, 'LOW': 0}
        self.attack_paths_found = 0
        self.exploitable_paths = 0
        
        self.score_distribution: Dict[str, int] = {
            '0-10': 0, '10-20': 0, '20-30': 0, '30-40': 0, '40-50': 0,
            '50-60': 0, '60-70': 0, '70-80': 0, '80-90': 0, '90-100': 0
        }
        
        self.logs: List[LogEntry] = []
    
    def log(self, level: LogLevel, component: str, message: str, 
            entity: str = "", signal_type: str = "", value: Any = None,
            score: float = 0.0, details: Dict = None):
        entry = LogEntry(
            timestamp=datetime.now().isoformat(),
            level=level, component=component, message=message,
            entity=entity, signal_type=signal_type, value=value,
            score=score, details=details or {}
        )
        self.logs.append(entry)
    
    def log_feature_input(self, feature: str, count: int):
        if feature in self.feature_metrics:
            self.feature_metrics[feature].items_received = count
            self.log(LogLevel.FEATURE, feature.upper(), f"Received {count} items", details={'count': count})
    
    def log_signal(self, feature: str, entity: str, raw_value: Any, 
                   normalized_score: float, contribution: float, evidence: str):
        if feature in self.feature_metrics:
            fm = self.feature_metrics[feature]
            fm.signals_generated += 1
            fm.total_score_contribution += contribution
            fm.max_score_contribution = max(fm.max_score_contribution, contribution)
            
        self.log(LogLevel.SIGNAL, feature.upper(), f"Signal for {entity}",
                entity=entity, signal_type=feature, value=raw_value,
                score=contribution, details={'normalized': normalized_score, 'evidence': evidence})
    
    def log_amplifier(self, amplifier: str, entity: str, before_score: float, after_score: float):
        if amplifier in self.amplifier_metrics:
            am = self.amplifier_metrics[amplifier]
            am.times_applied += 1
            am.entities_affected.append(entity)
            am.total_score_boost += (after_score - before_score)
        
        self.log(LogLevel.AMPLIFIER, amplifier.upper(), f"Applied to {entity}",
                entity=entity, details={'before': before_score, 'after': after_score})
    
    def log_decision(self, entity: str, entity_type: str, risk_level: str, 
                     final_score: float, reasoning: str, threat_types: List[str]):
        self.total_entities += 1
        self.entities_by_type[entity_type] = self.entities_by_type.get(entity_type, 0) + 1
        self.entities_by_risk[risk_level] = self.entities_by_risk.get(risk_level, 0) + 1
        
        bucket = f"{int(final_score // 10) * 10}-{int(final_score // 10) * 10 + 10}"
        if bucket in self.score_distribution:
            self.score_distribution[bucket] += 1
        
        self.log(LogLevel.DECISION, 'CLASSIFIER', f"{entity} → {risk_level}",
                entity=entity, score=final_score, details={
                    'risk_level': risk_level, 'threat_types': threat_types, 'reasoning': reasoning
                })
    
    def finalize(self):
        self.end_time = datetime.now()
    
    def get_duration_ms(self) -> float:
        end = self.end_time or datetime.now()
        return (end - self.start_time).total_seconds() * 1000
    
    def to_dict(self) -> Dict:
        return {
            'timing': {
                'start_time': self.start_time.isoformat(),
                'end_time': self.end_time.isoformat() if self.end_time else None,
                'duration_ms': round(self.get_duration_ms(), 2)
            },
            'summary': {
                'total_entities': self.total_entities,
                'by_type': self.entities_by_type,
                'by_risk': self.entities_by_risk,
                'attack_paths': self.attack_paths_found,
                'exploitable_paths': self.exploitable_paths
            },
            'score_distribution': self.score_distribution,
            'features': {k: v.to_dict() for k, v in self.feature_metrics.items()},
            'amplifiers': {k: v.to_dict() for k, v in self.amplifier_metrics.items()},
            'log_summary': self._count_logs_by_level()
        }
    
    def _count_logs_by_level(self) -> Dict[str, int]:
        counts = {}
        for log in self.logs:
            level = log.level.value
            counts[level] = counts.get(level, 0) + 1
        return counts
    
    def get_logs(self, level: LogLevel = None, component: str = None, 
                 entity: str = None, limit: int = None) -> List[Dict]:
        filtered = self.logs
        if level:
            filtered = [l for l in filtered if l.level == level]
        if component:
            filtered = [l for l in filtered if component.lower() in l.component.lower()]
        if entity:
            filtered = [l for l in filtered if entity.lower() in l.entity.lower()]
        if limit:
            filtered = filtered[-limit:]
        return [l.to_dict() for l in filtered]

class CorrelationLogger:
    def __init__(self, verbose: bool = False, metrics: CorrelationMetricsCollector = None):
        self.verbose = verbose
        self.metrics = metrics or CorrelationMetricsCollector()
        self._indent = 0
        self._section_has_content = False
        self._current_section = None
    
    def _print(self, msg: str, icon: str = ""):
        if self.verbose:
            indent = "   " * self._indent
            print(f"{indent}{icon} {msg}" if icon else f"{indent}{msg}")
            self._section_has_content = True
    
    def section(self, title: str):
        """Start a new section - only prints header in verbose mode"""
        self._current_section = title
        self._section_has_content = False
        if self.verbose:
            print()
            self._print(f"{'─'*60}")
            self._print(f"📌 {title}")
            self._print(f"{'─'*60}")
    
    def info(self, component: str, message: str, **kwargs):
        self._print(f"[{component}] {message}", "ℹ️")
        self.metrics.log(LogLevel.INFO, component, message, details=kwargs)
    
    def debug(self, component: str, message: str, **kwargs):
        if self.verbose:
            self._print(f"[{component}] {message}", "🔍")
        self.metrics.log(LogLevel.DEBUG, component, message, details=kwargs)
    
    def warn(self, component: str, message: str, **kwargs):
        self._print(f"[{component}] {message}", "⚠️")
        self.metrics.log(LogLevel.WARN, component, message, details=kwargs)
    
    def feature_start(self, feature: str, count: int):
        self._print(f"Processing {feature}: {count} items", "📥")
        self.metrics.log_feature_input(feature, count)
    
    def feature_complete(self, feature: str, processed: int, findings: int):
        if feature in self.metrics.feature_metrics:
            fm = self.metrics.feature_metrics[feature]
            fm.items_processed = processed
            fm.items_with_findings = findings
        self._print(f"{feature}: {processed} processed, {findings} issues", "✅")
    
    def signal(self, feature: str, entity: str, raw_value: Any,
               normalized: float, contribution: float, evidence: str, source: str):
        self._print(f"{entity}: +{contribution:.2f} pts [{feature}]", "📊")
        if self.verbose:
            self._print(f"  Raw={raw_value}, Norm={normalized:.1f}, Src={source}")
            self._print(f"  {evidence[:80]}")
        self.metrics.log_signal(feature, entity, raw_value, normalized, contribution, evidence)
    
    def amplifier(self, amp_name: str, entity: str, before: float, after: float, reason: str):
        boost = after - before
        self._print(f"{entity}: {before:.1f}→{after:.1f} ({amp_name} {'+' if boost >= 0 else ''}{boost:.1f})", "⚡")
        self.metrics.log_amplifier(amp_name, entity, before, after)
    
    def decision(self, entity: str, entity_type: str, risk_level: str, score: float, 
                 reasoning: str, threat_types: List[str]):
        emoji = {'CRITICAL': '🔴', 'HIGH': '🟠', 'MEDIUM': '🟡', 'LOW': '🟢'}.get(risk_level, '⚪')
        self._print(f"{entity}: {risk_level} ({score:.1f}/100)", emoji)
        self.metrics.log_decision(entity, entity_type, risk_level, score, reasoning, threat_types)
    
    def get_metrics(self) -> Dict:
        return self.metrics.to_dict()
    
    def get_logs(self, **filters) -> List[Dict]:
        return self.metrics.get_logs(**filters)

def create_dashboard_data(metrics: CorrelationMetricsCollector) -> Dict:
    data = metrics.to_dict()
    return {
        'correlation_version': '2.0',
        'generated_at': datetime.now().isoformat(),
        'summary': {
            'total_entities': data['summary']['total_entities'],
            'by_risk_level': data['summary']['by_risk'],
            'by_entity_type': data['summary']['by_type'],
            'attack_paths': data['summary']['attack_paths'],
            'exploitable_paths': data['summary']['exploitable_paths']
        },
        'feature_status': [
            {
                'name': fm['feature_name'], 'key': key, 'enabled': fm['enabled'],
                'items': fm['counts']['received'], 'findings': fm['counts']['with_findings'],
                'signals': fm['signals']['generated'], 'contribution': fm['signals']['total_contribution'],
                'status': 'active' if fm['counts']['with_findings'] > 0 else ('enabled' if fm['enabled'] else 'disabled')
            }
            for key, fm in data['features'].items()
        ],
        'amplifier_usage': [
            {
                'name': am['amplifier_name'], 'key': key, 'multiplier': am['multiplier'],
                'times_applied': am['times_applied'], 'entities': am['entities_affected'],
                'total_boost': am['total_score_boost']
            }
            for key, am in data['amplifiers'].items() if am['times_applied'] > 0
        ],
        'score_distribution': data['score_distribution'],
        'log_stats': data['log_summary'],
        'performance': {
            'duration_ms': data['timing']['duration_ms'],
            'start_time': data['timing']['start_time'],
            'end_time': data['timing']['end_time']
        }
    }
