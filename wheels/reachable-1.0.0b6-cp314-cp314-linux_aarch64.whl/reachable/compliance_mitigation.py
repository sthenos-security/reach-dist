# Copyright © 2026 Sthenos Security. All rights reserved.

"""
Compliance Mitigation Rules Catalog

Applies reachability-based mitigation to compliance violations.
Each rule cites specific standard requirements that justify the mitigation.

Rule Categories:
- REACH-001: Unreachable Code Path (code CWEs)
- REACH-002: Test-Only Code (non-production)
- REACH-003: Config Issue (NO MITIGATION)
- REACH-004: Unreachable CVE (reduced risk)
- REACH-005: Secret Unknown Reachability (assume actionable)
- REACH-006: Malware (NO MITIGATION - always critical)
"""

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Any
from enum import Enum

class MitigationStatus(Enum):
    """Mitigation status for a finding"""
    MITIGATED = "mitigated"           # Unreachable - risk accepted
    ACTIONABLE = "actionable"         # Reachable - must fix
    CONFIG_REVIEW = "config_review"   # Config issue - human review needed
    CRITICAL = "critical"             # Malware - immediate action
    RISK_REDUCED = "risk_reduced"     # Unreachable CVE - lower priority

class FindingType(Enum):
    CVE = "cve"
    CWE = "cwe"
    SECRET = "secret"
    MALWARE = "malware"
    CONFIG = "config"

@dataclass
class MitigationRule:
    """A mitigation rule with standard citations"""
    rule_id: str
    name: str
    description: str
    condition: str
    allows_mitigation: bool
    citations: Dict[str, str]
    applies_to_types: List[str]

@dataclass
class ComplianceViolation:
    """A single compliance violation with mitigation status"""
    finding_id: str
    finding_type: str
    framework: str
    control_id: str
    control_name: str
    severity: str
    status: str
    mitigation_rule: Optional[str]
    mitigation_citation: Optional[str]
    file_path: str
    line_number: int = 0
    cwe_id: Optional[str] = None

@dataclass
class ControlSummary:
    """Summary for a single compliance control"""
    control_id: str
    control_name: str
    total: int = 0
    actionable: int = 0
    mitigated: int = 0
    config: int = 0
    findings: List[Dict] = field(default_factory=list)
    status: str = "PASS"

@dataclass
class FrameworkSummary:
    """Summary for an entire compliance framework"""
    framework: str
    total: int = 0
    actionable: int = 0
    mitigated: int = 0
    config: int = 0
    controls: Dict[str, ControlSummary] = field(default_factory=dict)
    status: str = "COMPLIANT"

# ============================================================================
# MITIGATION RULES CATALOG
# ============================================================================

MITIGATION_RULES = {
    "REACH-001": MitigationRule(
        rule_id="REACH-001",
        name="Unreachable Code Vulnerability",
        description="Code CWE exists but no execution path from entry points reaches vulnerable function.",
        condition="is_reachable == false AND cwe_category == 'code_cwe'",
        allows_mitigation=True,
        citations={
            "OWASP": "A03:2021 - Injection flaws require data SENT to interpreter (execution path required)",
            "PCI-DSS": "6.2.4 - Vulnerabilities that POSE A RISK require remediation (no risk if unreachable)",
            "NIST-800-53": "SI-10 - Input validation applies to reachable input handlers only",
            "SOC2": "CC6.1 - Logical access security requires executable code path",
            "HIPAA": "164.312(a)(1) - PHI access requires active code execution path",
            "FEDRAMP": "RA-5 - Risk assessment considers exploitability (unreachable = not exploitable)",
            "CMMC": "SI.L1-3.14.1 - Malicious code protection applies to executable code",
            "NIST-800-171": "3.14.1 - Information flaw correction for exploitable flaws",
        },
        applies_to_types=["cwe"]
    ),
    
    "REACH-002": MitigationRule(
        rule_id="REACH-002",
        name="Test-Only Code",
        description="Finding exists in test files not deployed to production.",
        condition="file_path matches */test/*, *_test.*, *_spec.*, */tests/*",
        allows_mitigation=True,
        citations={
            "PCI-DSS": "Scope limited to systems involved in cardholder data processing - test excluded",
            "NIST-800-53": "CM-4 - Test code changes not deployed to production environment",
            "SOC2": "CC6.7 - Restrict access to production - test environments excluded",
            "FEDRAMP": "Boundary definition explicitly excludes test environments",
            "HIPAA": "Test systems outside PHI processing scope",
        },
        applies_to_types=["cve", "cwe", "secret"]
    ),
    
    "REACH-003": MitigationRule(
        rule_id="REACH-003",
        name="Configuration Issue (NO MITIGATION)",
        description="Config vulnerabilities affect runtime regardless of code reachability. Always actionable.",
        condition="cwe_category == 'config_cwe' OR file_type in [Dockerfile, YAML, Terraform]",
        allows_mitigation=False,
        citations={
            "note": "Configuration issues are ALWAYS actionable - affect deployed environment directly."
        },
        applies_to_types=["config"]
    ),
    
    "REACH-004": MitigationRule(
        rule_id="REACH-004",
        name="Unreachable Dependency Vulnerability",
        description="CVE in dependency but vulnerable function is not called by application code.",
        condition="is_reachable == false AND type == 'cve'",
        allows_mitigation=True,
        citations={
            "OWASP": "A06:2021 - Vulnerable component present but code path not exercised",
            "PCI-DSS": "6.2 - Vulnerability management considers exploitability for prioritization",
            "NIST-800-53": "RA-5 - Vulnerability assessment includes exploitability analysis",
            "SSDF": "RV.2.2 - Analyze vulnerability exploitability before prioritizing remediation",
            "CISA": "VEX allows status='not_affected' with justification='vulnerable_code_not_in_execute_path'",
        },
        applies_to_types=["cve"]
    ),
    
    "REACH-005": MitigationRule(
        rule_id="REACH-005",
        name="Secret Unknown Reachability",
        description="Secret found but loader path unknown. Assume actionable (guilty until proven innocent).",
        condition="type == 'secret' AND reachability == 'unknown'",
        allows_mitigation=False,
        citations={
            "note": "Secrets may be loaded via dynamic methods - assume reachable unless proven otherwise."
        },
        applies_to_types=["secret"]
    ),
    
    "REACH-006": MitigationRule(
        rule_id="REACH-006",
        name="Malware Detection (NO MITIGATION)",
        description="Malicious package detected. Always critical - immediate removal required.",
        condition="type == 'malware'",
        allows_mitigation=False,
        citations={
            "ALL": "Malware must be removed immediately - zero tolerance. Uses install hooks/lazy loading."
        },
        applies_to_types=["malware"]
    ),
}

# ============================================================================
# CWE TO COMPLIANCE CONTROL MAPPING
# ============================================================================

CWE_TO_CONTROLS = {
    # A03:2021 - Injection
    "CWE-079": {
        "OWASP": ["A03:2021"],
        "PCI-DSS": ["6.5.7", "6.2.4"],
        "NIST-800-53": ["SI-10", "SI-11"],
        "SOC2": ["CC6.1"],
        "HIPAA": ["164.312(e)(1)"],
        "FEDRAMP": ["SI-10"],
        "CMMC": ["SI.L1-3.14.2"],
        "NIST-800-171": ["3.13.1"],
    },
    "CWE-089": {
        "OWASP": ["A03:2021"],
        "PCI-DSS": ["6.5.1", "6.2.4"],
        "NIST-800-53": ["SI-10"],
        "SOC2": ["CC6.1"],
        "HIPAA": ["164.312(a)(1)"],
        "FEDRAMP": ["SI-10"],
        "CMMC": ["SI.L1-3.14.2"],
        "NIST-800-171": ["3.14.1"],
    },
    "CWE-078": {
        "OWASP": ["A03:2021"],
        "PCI-DSS": ["6.5.1"],
        "NIST-800-53": ["SI-10", "CM-7"],
        "SOC2": ["CC6.1", "CC6.6"],
        "FEDRAMP": ["SI-10", "CM-7"],
        "CMMC": ["SI.L1-3.14.2"],
    },
    "CWE-094": {
        "OWASP": ["A03:2021"],
        "PCI-DSS": ["6.5.1"],
        "NIST-800-53": ["SI-10"],
        "SOC2": ["CC6.1"],
    },
    # A05:2021 - Security Misconfiguration (CONFIG - NO MITIGATION)
    "CWE-016": {
        "OWASP": ["A05:2021"],
        "PCI-DSS": ["2.2", "6.1"],
        "NIST-800-53": ["CM-6", "CM-7"],
        "SOC2": ["CC6.1"],
        "FEDRAMP": ["CM-6"],
        "CMMC": ["CM.L2-3.4.2"],
        "NIST-800-171": ["3.4.2"],
    },
    "CWE-250": {
        "OWASP": ["A05:2021"],
        "PCI-DSS": ["7.1", "7.2"],
        "NIST-800-53": ["AC-6", "CM-7"],
        "SOC2": ["CC6.3"],
        "HIPAA": ["164.312(a)(1)"],
        "FEDRAMP": ["AC-6"],
        "CMMC": ["AC.L1-3.1.1"],
        "NIST-800-171": ["3.1.5"],
    },
    "CWE-732": {
        "OWASP": ["A05:2021"],
        "PCI-DSS": ["7.1"],
        "NIST-800-53": ["AC-6"],
        "SOC2": ["CC6.3"],
    },
    "CWE-614": {
        "OWASP": ["A05:2021"],
        "PCI-DSS": ["6.5.10"],
        "NIST-800-53": ["SC-23"],
        "SOC2": ["CC6.1"],
    },
    # A02:2021 - Cryptographic Failures
    "CWE-327": {
        "OWASP": ["A02:2021"],
        "PCI-DSS": ["4.1", "4.2"],
        "NIST-800-53": ["SC-13", "SC-12"],
        "SOC2": ["CC6.1", "CC6.7"],
        "HIPAA": ["164.312(e)(2)(ii)"],
        "FEDRAMP": ["SC-13"],
        "CMMC": ["SC.L2-3.13.11"],
        "NIST-800-171": ["3.13.11"],
    },
    "CWE-328": {
        "OWASP": ["A02:2021"],
        "PCI-DSS": ["4.1"],
        "NIST-800-53": ["SC-13"],
    },
    "CWE-330": {
        "OWASP": ["A02:2021"],
        "NIST-800-53": ["SC-13"],
    },
    # A08:2021 - Software and Data Integrity
    "CWE-502": {
        "OWASP": ["A08:2021"],
        "PCI-DSS": ["6.5.1"],
        "NIST-800-53": ["SI-10", "SI-7"],
        "SOC2": ["CC6.1"],
        "FEDRAMP": ["SI-10", "SI-7"],
        "CMMC": ["SI.L1-3.14.1"],
    },
    # A10:2021 - SSRF
    "CWE-918": {
        "OWASP": ["A10:2021"],
        "PCI-DSS": ["6.5.9"],
        "NIST-800-53": ["SC-7", "AC-4"],
        "SOC2": ["CC6.6"],
        "FEDRAMP": ["SC-7"],
        "CMMC": ["SC.L1-3.13.1"],
    },
    # A01:2021 - Broken Access Control
    "CWE-022": {
        "OWASP": ["A01:2021"],
        "PCI-DSS": ["6.5.8"],
        "NIST-800-53": ["AC-3"],
        "SOC2": ["CC6.1"],
    },
    "CWE-352": {
        "OWASP": ["A01:2021"],
        "PCI-DSS": ["6.5.9"],
        "NIST-800-53": ["SC-23"],
        "SOC2": ["CC6.1"],
    },
    "CWE-601": {
        "OWASP": ["A01:2021"],
        "PCI-DSS": ["6.5.10"],
        "NIST-800-53": ["SI-10"],
    },
    # A09:2021 - Logging Failures (CONFIG - NO MITIGATION)
    "CWE-778": {
        "OWASP": ["A09:2021"],
        "PCI-DSS": ["10.1", "10.2"],
        "NIST-800-53": ["AU-2", "AU-3"],
        "SOC2": ["CC7.2"],
        "HIPAA": ["164.312(b)"],
    },
    "CWE-532": {
        "OWASP": ["A09:2021"],
        "PCI-DSS": ["3.4"],
        "NIST-800-53": ["AU-9"],
        "HIPAA": ["164.312(b)"],
    },
    # A07:2021 - Auth Failures (for secrets)
    "CWE-798": {
        "OWASP": ["A07:2021"],
        "PCI-DSS": ["8.3.1", "8.2.1"],
        "NIST-800-53": ["IA-5"],
        "SOC2": ["CC6.1"],
        "HIPAA": ["164.312(d)"],
        "FEDRAMP": ["IA-5"],
        "CMMC": ["IA.L1-3.5.1"],
    },
    # Dangerous function
    "CWE-676": {
        "OWASP": ["A03:2021"],
        "NIST-800-53": ["SI-10"],
        "SOC2": ["CC6.1"],
    },
    # Input validation
    "CWE-020": {
        "OWASP": ["A03:2021"],
        "PCI-DSS": ["6.5.1"],
        "NIST-800-53": ["SI-10"],
        "FEDRAMP": ["SI-10"],
    },
}

# CVE controls (A06:2021 - Vulnerable Components)
CVE_CONTROLS = {
    "OWASP": ["A06:2021"],
    "PCI-DSS": ["6.2", "11.3"],
    "NIST-800-53": ["SI-2", "RA-5"],
    "SOC2": ["CC7.1"],
    "HIPAA": ["164.308(a)(5)(ii)(B)"],
    "FEDRAMP": ["SI-2", "RA-5"],
    "CMMC": ["SI.L1-3.14.1"],
    "NIST-800-171": ["3.14.1"],
}

# Secret controls (A07:2021 - Auth Failures)
SECRET_CONTROLS = {
    "OWASP": ["A07:2021"],
    "PCI-DSS": ["8.3.1", "8.2.1"],
    "NIST-800-53": ["IA-5"],
    "SOC2": ["CC6.1"],
    "HIPAA": ["164.312(d)"],
    "FEDRAMP": ["IA-5"],
    "CMMC": ["IA.L1-3.5.1"],
    "NIST-800-171": ["3.5.1"],
}

# Malware controls (A08:2021 + all frameworks)
MALWARE_CONTROLS = {
    "OWASP": ["A08:2021"],
    "PCI-DSS": ["5.1", "5.2", "5.3"],
    "NIST-800-53": ["SI-3", "SI-7"],
    "SOC2": ["CC6.8"],
    "HIPAA": ["164.308(a)(5)(ii)(B)"],
    "FEDRAMP": ["SI-3"],
    "CMMC": ["SI.L1-3.14.1", "SI.L1-3.14.2"],
    "NIST-800-171": ["3.14.1", "3.14.2"],
}

# Control names for display
CONTROL_NAMES = {
    "A01:2021": "Broken Access Control",
    "A02:2021": "Cryptographic Failures", 
    "A03:2021": "Injection",
    "A05:2021": "Security Misconfiguration",
    "A06:2021": "Vulnerable and Outdated Components",
    "A07:2021": "Identification and Authentication Failures",
    "A08:2021": "Software and Data Integrity Failures",
    "A09:2021": "Security Logging and Monitoring Failures",
    "A10:2021": "Server-Side Request Forgery",
    "6.2": "Vulnerability Management",
    "6.5.1": "Injection Flaws",
    "6.5.7": "Cross-Site Scripting",
    "8.3.1": "Authentication Management",
    "SI-2": "Flaw Remediation",
    "SI-10": "Information Input Validation",
    "IA-5": "Authenticator Management",
    "RA-5": "Vulnerability Assessment",
}

# Config CWEs that cannot be mitigated by reachability
CONFIG_CWES = {"CWE-016", "CWE-250", "CWE-732", "CWE-614", "CWE-778", "CWE-532"}

# ============================================================================
# MITIGATION FUNCTIONS
# ============================================================================

def get_mitigation_for_finding(finding: Dict[str, Any]) -> Dict[str, Any]:
    """
    Determine mitigation status and rule for a finding.
    
    Args:
        finding: Finding dict with type, is_reachable, cwe_category, file, etc.
        
    Returns:
        Dict with mitigation_status, rule_id, rule_name, mitigated, citations, rationale
    """
    finding_type = finding.get('type', finding.get('finding_type', '')).lower()
    is_reachable = finding.get('is_reachable', True)  # Default to reachable (conservative)
    cwe_category = finding.get('cwe_category', '')
    cwe_id = finding.get('cwe_id', '')
    file_path = (finding.get('file', '') or finding.get('file_path', '')).lower()
    reachability = finding.get('reachability', finding.get('cwe_reachability', ''))
    
    is_config = (cwe_category == 'config_cwe' or 
                 reachability == 'config_issue' or 
                 cwe_id in CONFIG_CWES)
    
    is_test = any(x in file_path for x in ['/test/', '/_test', '_test.', '_spec.', '/tests/', '/spec/', '/mock/', '/fake/'])
    
    # REACH-006: Malware - NO MITIGATION EVER
    if finding_type == 'malware':
        rule = MITIGATION_RULES["REACH-006"]
        return {
            "mitigation_status": MitigationStatus.CRITICAL.value,
            "rule_id": "REACH-006",
            "rule_name": rule.name,
            "mitigated": False,
            "citations": rule.citations,
            "rationale": "Malware must be removed immediately - uses install hooks/lazy loading"
        }
    
    # REACH-003: Config issues - NO MITIGATION
    if is_config or finding_type == 'config':
        rule = MITIGATION_RULES["REACH-003"]
        return {
            "mitigation_status": MitigationStatus.CONFIG_REVIEW.value,
            "rule_id": "REACH-003",
            "rule_name": rule.name,
            "mitigated": False,
            "citations": rule.citations,
            "rationale": "Configuration affects runtime regardless of code reachability"
        }
    
    # REACH-002: Test-only code (applies to CVE, CWE, Secret if unreachable)
    if is_test and not is_reachable:
        rule = MITIGATION_RULES["REACH-002"]
        return {
            "mitigation_status": MitigationStatus.MITIGATED.value,
            "rule_id": "REACH-002",
            "rule_name": rule.name,
            "mitigated": True,
            "citations": rule.citations,
            "rationale": "Code exists only in test files, not deployed to production"
        }
    
    # REACH-005: Secret with unknown reachability - assume actionable
    if finding_type == 'secret':
        if reachability == 'unknown' or not is_reachable:
            # Secrets are "guilty until proven innocent"
            rule = MITIGATION_RULES["REACH-005"]
            return {
                "mitigation_status": MitigationStatus.ACTIONABLE.value,
                "rule_id": "REACH-005",
                "rule_name": rule.name,
                "mitigated": False,
                "citations": rule.citations,
                "rationale": "Secrets may use dynamic loading - assume reachable unless proven otherwise"
            }
        else:
            # Reachable secret
            return {
                "mitigation_status": MitigationStatus.ACTIONABLE.value,
                "rule_id": None,
                "rule_name": None,
                "mitigated": False,
                "citations": {},
                "rationale": "Secret is reachable via confirmed loader function"
            }
    
    # REACH-004: Unreachable CVE
    if finding_type == 'cve' and not is_reachable:
        rule = MITIGATION_RULES["REACH-004"]
        return {
            "mitigation_status": MitigationStatus.RISK_REDUCED.value,
            "rule_id": "REACH-004",
            "rule_name": rule.name,
            "mitigated": True,
            "citations": rule.citations,
            "rationale": "Vulnerable function in dependency is not called by application code"
        }
    
    # REACH-001: Unreachable code CWE
    if finding_type in ('cwe', '') and not is_reachable and not is_config:
        rule = MITIGATION_RULES["REACH-001"]
        return {
            "mitigation_status": MitigationStatus.MITIGATED.value,
            "rule_id": "REACH-001",
            "rule_name": rule.name,
            "mitigated": True,
            "citations": rule.citations,
            "rationale": "No execution path from entry points reaches vulnerable function"
        }
    
    # Default: Reachable = Actionable
    return {
        "mitigation_status": MitigationStatus.ACTIONABLE.value,
        "rule_id": None,
        "rule_name": None,
        "mitigated": False,
        "citations": {},
        "rationale": "Reachable code path - vulnerability is exploitable"
    }

def get_controls_for_finding(finding: Dict[str, Any]) -> Dict[str, List[str]]:
    """Get compliance controls that apply to a finding."""
    finding_type = finding.get('type', finding.get('finding_type', '')).lower()
    cwe_id = finding.get('cwe_id', '')
    
    # Use finding's own mapping if available
    if 'compliance_mapping' in finding and finding['compliance_mapping']:
        return finding['compliance_mapping']
    
    # Otherwise use our mapping
    if finding_type == 'malware':
        return MALWARE_CONTROLS
    elif finding_type == 'secret':
        return SECRET_CONTROLS
    elif finding_type == 'cve':
        return CVE_CONTROLS
    elif cwe_id and cwe_id in CWE_TO_CONTROLS:
        return CWE_TO_CONTROLS[cwe_id]
    
    return {}

def calculate_compliance_by_control(findings: List[Dict[str, Any]]) -> Dict[str, FrameworkSummary]:
    """
    Calculate compliance violations grouped by framework and control.
    
    Args:
        findings: List of all findings (CVEs, CWEs, Secrets, Malware)
        
    Returns:
        Dict of framework_name -> FrameworkSummary with per-control breakdown
    """
    frameworks: Dict[str, FrameworkSummary] = {}
    mitigation_stats = {rule_id: 0 for rule_id in MITIGATION_RULES.keys()}
    
    for finding in findings:
        mitigation = get_mitigation_for_finding(finding)
        controls = get_controls_for_finding(finding)
        
        # Track mitigation rule usage
        if mitigation.get('rule_id'):
            mitigation_stats[mitigation['rule_id']] = mitigation_stats.get(mitigation['rule_id'], 0) + 1
        
        # Process each framework this finding affects
        for framework, control_ids in controls.items():
            if framework not in frameworks:
                frameworks[framework] = FrameworkSummary(framework=framework)
            
            fw = frameworks[framework]
            
            # Ensure control_ids is a list
            if isinstance(control_ids, str):
                control_ids = [control_ids]
            
            for control_id in control_ids:
                if control_id not in fw.controls:
                    fw.controls[control_id] = ControlSummary(
                        control_id=control_id,
                        control_name=CONTROL_NAMES.get(control_id, control_id)
                    )
                
                ctrl = fw.controls[control_id]
                ctrl.total += 1
                fw.total += 1
                
                # Categorize by mitigation status
                is_config = mitigation['rule_id'] == 'REACH-003'
                is_mitigated = mitigation['mitigated']
                
                if is_config:
                    ctrl.config += 1
                    fw.config += 1
                    ctrl.status = "FAIL"  # Config issues always fail
                elif is_mitigated:
                    ctrl.mitigated += 1
                    fw.mitigated += 1
                else:
                    ctrl.actionable += 1
                    fw.actionable += 1
                    ctrl.status = "FAIL"
                
                # Track finding
                ctrl.findings.append({
                    "id": finding.get('cve_id') or finding.get('cwe_id') or finding.get('rule_id', 'unknown'),
                    "type": finding.get('type', finding.get('finding_type', 'unknown')),
                    "file": finding.get('file', finding.get('file_path', '')),
                    "severity": finding.get('severity', 'UNKNOWN'),
                    "mitigated": is_mitigated,
                    "mitigation_rule": mitigation.get('rule_id'),
                    "mitigation_rationale": mitigation.get('rationale'),
                })
        
        # Update control status
        for ctrl in fw.controls.values():
            if ctrl.actionable == 0 and ctrl.config == 0:
                ctrl.status = "PASS"
            elif ctrl.actionable > 0:
                ctrl.status = "FAIL"
            else:
                ctrl.status = "CONFIG_REVIEW"
    
    # Calculate framework status
    for fw in frameworks.values():
        actionable_total = fw.actionable + fw.config
        if actionable_total == 0:
            fw.status = "COMPLIANT"
        elif actionable_total <= 5:
            fw.status = "LOW_RISK"
        elif actionable_total <= 20:
            fw.status = "MEDIUM_RISK"
        else:
            fw.status = "HIGH_RISK"
    
    return frameworks, mitigation_stats

def get_compliance_summary(frameworks: Dict[str, FrameworkSummary], 
                           mitigation_stats: Dict[str, int]) -> Dict[str, Any]:
    """Generate summary dict for JSON report."""
    total_violations = sum(fw.total for fw in frameworks.values())
    total_actionable = sum(fw.actionable + fw.config for fw in frameworks.values())
    total_mitigated = sum(fw.mitigated for fw in frameworks.values())
    
    return {
        "summary": {
            "frameworks_assessed": len(frameworks),
            "total_violations": total_violations,
            "total_actionable": total_actionable,
            "total_mitigated": total_mitigated,
            "mitigation_rate_pct": round(total_mitigated / max(1, total_violations) * 100, 1)
        },
        "mitigation_rules_applied": {
            rule_id: {
                "count": count,
                "description": MITIGATION_RULES[rule_id].name
            }
            for rule_id, count in mitigation_stats.items()
            if count > 0
        },
        "by_framework": {
            fw_name: {
                "total": fw.total,
                "actionable": fw.actionable + fw.config,
                "mitigated": fw.mitigated,
                "config_issues": fw.config,
                "status": fw.status,
                "controls": {
                    ctrl_id: {
                        "name": ctrl.control_name,
                        "total": ctrl.total,
                        "actionable": ctrl.actionable + ctrl.config,
                        "mitigated": ctrl.mitigated,
                        "status": ctrl.status
                    }
                    for ctrl_id, ctrl in fw.controls.items()
                }
            }
            for fw_name, fw in frameworks.items()
        }
    }
