#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.

"""
Security Metrics System - Comprehensive Tracking

Tracks ALL security intelligence gathered across:
- CVE Detection (Syft + Grype)
- Malware Detection (GuardDog + Semgrep patterns)
- Secrets Detection (Semgrep + TruffleHog)
- Security Weaknesses (Semgrep SAST)
- Threat Intelligence (KEV, EPSS, Exploit-DB, Metasploit)
- Package Health (maintenance, popularity, age)
- Attack Surface (exposed functions, entry points)
- Correlation Insights (multi-dimensional risk)

Provides metrics for dashboards, reporting, and trend analysis.
"""

from dataclasses import dataclass, field, asdict
from typing import Dict, List, Optional, Set
from enum import Enum
from datetime import datetime
import json

class ThreatSource(Enum):
    """Sources of threat intelligence"""
    GRYPE = "grype"                    # CVE scanner
    SYFT = "syft"                      # SBOM generator
    GUARDDOG = "guarddog"              # Malicious package detection
    SEMGREP_MALWARE = "semgrep_malware"  # Malware patterns
    SEMGREP_SECRETS = "semgrep_secrets"  # Hardcoded secrets
    SEMGREP_SAST = "semgrep_sast"      # Security weaknesses
    TRUFFLEHOG = "trufflehog"          # Secrets scanner
    CISA_KEV = "cisa_kev"              # Known Exploited Vulnerabilities
    EPSS = "epss"                      # Exploit Prediction Scoring
    EXPLOIT_DB = "exploit_db"          # Public exploits
    METASPLOIT = "metasploit"          # Weaponized modules
    GITHUB = "github"                  # Repository metadata
    PYPI = "pypi"                      # Python package index
    NPM = "npm"                        # JavaScript package registry

class MalwareType(Enum):
    """Types of malware detected"""
    SUSPICIOUS_PACKAGE = "suspicious_package"      # GuardDog: package-level suspicion
    MALICIOUS_CODE = "malicious_code"              # Semgrep: code patterns
    EXFILTRATION = "exfiltration"                  # Data theft
    BACKDOOR = "backdoor"                          # Remote access
    TYPOSQUATTING = "typosquatting"                # Name confusion
    HIDDEN_PAYLOAD = "hidden_payload"              # Obfuscated/encrypted code
    HIGH_ENTROPY = "high_entropy"                  # Random strings (potential encryption)
    CREDENTIAL_HARVESTING = "credential_harvesting"  # Steals credentials
    SUPPLY_CHAIN_ATTACK = "supply_chain_attack"    # Fork of legitimate package

class WeaknessType(Enum):
    """Security weaknesses from SAST"""
    PATH_TRAVERSAL = "path_traversal"              # Directory traversal
    COMMAND_INJECTION = "command_injection"        # OS command execution
    SQL_INJECTION = "sql_injection"                # Database injection
    XSS = "xss"                                    # Cross-site scripting
    SSRF = "ssrf"                                  # Server-side request forgery
    DESERIALIZATION = "deserialization"            # Unsafe deserialization
    WEAK_CRYPTO = "weak_crypto"                    # Weak cryptography
    HARDCODED_SECRET = "hardcoded_secret"          # Embedded credentials
    DANGEROUS_FUNCTION = "dangerous_function"      # Unsafe API usage

@dataclass
class CVEMetrics:
    """Metrics for CVE detection"""
    total_cves: int = 0
    critical_cves: int = 0
    high_cves: int = 0
    medium_cves: int = 0
    low_cves: int = 0
    
    # Reachability breakdown
    reachable_cves: int = 0
    unreachable_cves: int = 0
    
    # Threat intelligence enrichment
    kev_cves: int = 0              # CISA Known Exploited
    high_epss_cves: int = 0        # EPSS > 0.5
    exploit_db_cves: int = 0       # Public exploits available
    metasploit_cves: int = 0       # Weaponized modules exist
    
    # Workload reduction
    workload_reduction_pct: float = 0.0
    time_saved_hours: float = 0.0  # 5 min per CVE saved
    
    # By package ecosystem
    python_cves: int = 0
    javascript_cves: int = 0
    go_cves: int = 0
    rust_cves: int = 0
    java_cves: int = 0

@dataclass
class MalwareMetrics:
    """Comprehensive malware detection metrics"""
    # ========================================================================
    # SIGNATURE-BASED DETECTION (SCA Tools)
    # ========================================================================
    # GuardDog detections
    guarddog_suspicious_packages: int = 0
    guarddog_malicious_packages: int = 0
    
    # Semgrep malware patterns
    semgrep_malware_patterns: int = 0
    
    # ========================================================================
    # ENTROPY-BASED DETECTION (Sliding Window)
    # ========================================================================
    # High entropy files detected
    high_entropy_files: int = 0
    critical_entropy_files: int = 0  # Entropy > 7.5
    
    # Entropy details
    total_entropy_windows_scanned: int = 0
    high_entropy_windows: int = 0
    avg_max_entropy: float = 0.0  # Average of max entropy across files
    
    # Files with suspicious entropy ranges
    files_with_encrypted_sections: int = 0
    
    # ========================================================================
    # STATIC ANALYSIS (SAST / Tree-sitter)
    # ========================================================================
    # Unpacker logic detected
    aes_crypto_usage: int = 0
    lzstring_decompression: int = 0
    buffer_manipulation: int = 0
    
    # Dangerous function calls
    eval_usage: int = 0
    function_constructor_usage: int = 0
    exec_usage: int = 0
    
    # Obfuscation indicators
    obfuscated_identifiers: int = 0  # _0x4a2f style
    packed_code_detected: int = 0    # eval(function(p,a,c,k,e,r)
    unicode_escape_sequences: int = 0
    
    # ========================================================================
    # BEHAVIORAL / HEURISTIC INDICATORS
    # ========================================================================
    # Install script risks
    suspicious_install_scripts: int = 0  # preinstall/postinstall
    install_script_network_calls: int = 0
    install_script_downloads: int = 0
    
    # Timing-based evasion
    delayed_execution: int = 0  # setTimeout for days
    time_based_logic: int = 0   # Date.now() checks
    
    # File/process operations
    file_write_operations: int = 0
    process_spawn_operations: int = 0
    child_process_usage: int = 0
    
    # Network operations
    network_requests: int = 0
    suspicious_domains: int = 0  # Known C2, pastebin, etc
    dns_requests: int = 0
    
    # ========================================================================
    # PROVENANCE & SUPPLY CHAIN
    # ========================================================================
    # Missing provenance
    no_npm_signatures: int = 0
    no_npm_attestations: int = 0
    
    # Typosquatting
    typosquatting_detected: int = 0
    similar_to_popular_package: int = 0
    
    # Source integrity
    missing_source_files: int = 0  # Files in tarball but not in repo
    commit_to_publish_gap_large: int = 0  # > 7 days
    
    # Maintainer changes
    new_maintainer_suspicious: int = 0
    maintainer_account_hijacked: int = 0
    
    # ========================================================================
    # DANGEROUS PACKAGE INDICATORS
    # ========================================================================
    # Unmaintained packages with vulns
    unmaintained_with_critical_vulns: int = 0
    unmaintained_with_high_vulns: int = 0
    
    # No activity
    no_commits_1year: int = 0
    no_commits_2years: int = 0
    
    # Deprecated packages
    deprecated_packages: int = 0
    
    # ========================================================================
    # MALWARE CATEGORIES
    # ========================================================================
    # By attack type
    exfiltration: int = 0           # Data theft
    backdoors: int = 0              # Remote access
    droppers: int = 0               # Install other malware
    credential_harvesters: int = 0  # Steal credentials
    cryptominers: int = 0           # Mine cryptocurrency
    ransomware: int = 0             # Encrypt files
    
    # Supply chain specific
    supply_chain_attacks: int = 0
    dependency_confusion: int = 0
    hidden_payloads: int = 0
    
    # ========================================================================
    # SEVERITY BREAKDOWN
    # ========================================================================
    critical_malware: int = 0
    high_malware: int = 0
    medium_malware: int = 0
    low_malware: int = 0
    
    # ========================================================================
    # DETECTION SOURCE ATTRIBUTION
    # ========================================================================
    # Which scanner found it
    detections_by_guarddog: int = 0
    detections_by_semgrep: int = 0
    detections_by_entropy: int = 0
    detections_by_treesitter: int = 0
    detections_by_provenance: int = 0
    detections_by_heuristics: int = 0
    
    # ========================================================================
    # COMPOSITE METRICS
    # ========================================================================
    total_malware_indicators: int = 0
    packages_with_multiple_indicators: int = 0  # 2+ signals
    
    # Risk amplification
    high_confidence_malware: int = 0  # 3+ signals
    
    def calculate_totals(self):
        """Calculate aggregate totals"""
        self.total_malware_indicators = (
            self.guarddog_suspicious_packages +
            self.semgrep_malware_patterns +
            self.high_entropy_files +
            self.eval_usage +
            self.suspicious_install_scripts +
            self.typosquatting_detected +
            self.missing_source_files +
            self.exfiltration +
            self.backdoors +
            self.droppers
        )

@dataclass
class SecretsMetrics:
    """Metrics for secrets detection"""
    total_secrets: int = 0
    
    # Reachability (only Semgrep has reachability awareness)
    reachable_secrets: int = 0
    unreachable_secrets: int = 0
    
    # By secret type
    api_keys: int = 0
    passwords: int = 0
    tokens: int = 0
    certificates: int = 0
    private_keys: int = 0
    connection_strings: int = 0
    
    # By severity
    critical_secrets: int = 0  # Production keys, admin passwords
    high_secrets: int = 0      # API keys, tokens
    medium_secrets: int = 0    # Generic passwords
    low_secrets: int = 0       # Test credentials
    
    # Detection sources
    semgrep_secrets: int = 0
    trufflehog_secrets: int = 0
    
    # Risk indicators
    secrets_in_code: int = 0
    secrets_in_config: int = 0
    secrets_in_comments: int = 0

@dataclass
class WeaknessMetrics:
    """Metrics for security weaknesses (SAST)"""
    total_weaknesses: int = 0
    
    # By weakness type
    path_traversal: int = 0
    command_injection: int = 0
    sql_injection: int = 0
    xss: int = 0
    ssrf: int = 0
    deserialization: int = 0
    weak_crypto: int = 0
    dangerous_functions: int = 0
    
    # By severity
    critical_weaknesses: int = 0
    high_weaknesses: int = 0
    medium_weaknesses: int = 0
    low_weaknesses: int = 0
    
    # Reachability
    reachable_weaknesses: int = 0
    unreachable_weaknesses: int = 0
    
    # CWE mapping
    cwe_mappings: Dict[str, int] = field(default_factory=dict)

@dataclass
class ThreatIntelMetrics:
    """Metrics for threat intelligence enrichment"""
    # CISA KEV
    kev_total: int = 0
    kev_active_exploitation: int = 0
    
    # EPSS (Exploit Prediction)
    epss_high_risk: int = 0      # EPSS > 0.7
    epss_medium_risk: int = 0    # EPSS 0.3-0.7
    epss_low_risk: int = 0       # EPSS < 0.3
    
    # Exploit availability
    exploit_db_available: int = 0
    metasploit_modules: int = 0
    github_exploits: int = 0
    
    # Vendor advisories
    vendor_advisories: int = 0
    
    # Age of vulnerabilities
    zero_day_count: int = 0      # < 30 days old
    recent_count: int = 0        # 30-90 days
    aged_count: int = 0          # > 90 days

@dataclass
class HealthMetrics:
    """Metrics for package health assessment"""
    total_packages: int = 0
    
    # Maintenance status
    actively_maintained: int = 0
    stale_packages: int = 0         # No commits in 6 months
    abandoned_packages: int = 0     # No commits in 2 years
    
    # Popularity indicators
    high_popularity: int = 0        # Top 10% downloads
    medium_popularity: int = 0
    low_popularity: int = 0
    unknown_popularity: int = 0
    
    # Version status
    outdated_major: int = 0         # Major version behind
    outdated_minor: int = 0         # Minor version behind
    up_to_date: int = 0
    
    # Quality indicators
    no_license: int = 0
    deprecated_packages: int = 0
    archived_repos: int = 0
    
    # Risk scores
    critical_health_risk: int = 0   # Multiple red flags
    high_health_risk: int = 0
    medium_health_risk: int = 0
    low_health_risk: int = 0

@dataclass
class AttackSurfaceMetrics:
    """Metrics for attack surface analysis"""
    # Entry points
    total_entry_points: int = 0
    exposed_functions: int = 0
    api_endpoints: int = 0
    cli_commands: int = 0
    
    # Call graph complexity
    total_functions: int = 0
    max_call_depth: int = 0
    avg_call_depth: float = 0.0
    
    # Reachability
    reachable_functions: int = 0
    unreachable_functions: int = 0
    dead_code_pct: float = 0.0
    
    # Dependencies
    total_dependencies: int = 0
    direct_dependencies: int = 0
    transitive_dependencies: int = 0
    dependency_depth: int = 0
    
    # Code metrics
    total_lines_of_code: int = 0
    analyzed_files: int = 0
    languages_detected: List[str] = field(default_factory=list)

@dataclass
class CorrelationMetrics:
    """Metrics for multi-dimensional correlation"""
    # Multi-threat packages
    packages_with_multiple_threats: int = 0
    cve_and_malware: int = 0
    cve_and_secrets: int = 0
    malware_and_secrets: int = 0
    triple_threat: int = 0         # CVE + Malware + Secrets
    
    # Composite risk scores
    critical_composite_risk: int = 0
    high_composite_risk: int = 0
    medium_composite_risk: int = 0
    low_composite_risk: int = 0
    
    # Attack paths
    attack_paths_identified: int = 0
    multi_stage_attacks: int = 0
    exploitable_paths: int = 0
    
    # Risk escalation
    low_to_critical_escalations: int = 0   # Low CVE + High malware = Critical
    risk_amplification_pct: float = 0.0

@dataclass
class ScanCoverageMetrics:
    """Metrics for scan coverage"""
    # Tools executed
    syft_ran: bool = False
    grype_ran: bool = False
    guarddog_ran: bool = False
    semgrep_ran: bool = False
    trufflehog_ran: bool = False
    
    # Coverage percentages
    cve_coverage_pct: float = 0.0        # % of packages scanned for CVEs
    malware_coverage_pct: float = 0.0    # % of packages scanned for malware
    secrets_coverage_pct: float = 0.0    # % of code scanned for secrets
    sast_coverage_pct: float = 0.0       # % of code analyzed for weaknesses
    
    # Scan quality
    full_scan: bool = False              # All tools ran successfully
    partial_scan: bool = False           # Some tools failed
    scan_errors: List[str] = field(default_factory=list)

@dataclass
class ComprehensiveSecurityMetrics:
    """
    Master metrics container for all security intelligence
    
    Aggregates ALL security data collected across:
    - CVE detection and reachability
    - Malware detection (packages and code)
    - Secrets detection
    - Security weaknesses (SAST)
    - Threat intelligence
    - Package health
    - Attack surface
    - Multi-dimensional correlation
    """
    
    # Timestamp
    scan_timestamp: str = field(default_factory=lambda: datetime.utcnow().isoformat())
    scan_duration_seconds: float = 0.0
    
    # Target information
    target_path: str = ""
    target_type: str = ""  # "local", "github", "monorepo"
    
    # Detailed metrics
    cve_metrics: CVEMetrics = field(default_factory=CVEMetrics)
    malware_metrics: MalwareMetrics = field(default_factory=MalwareMetrics)
    secrets_metrics: SecretsMetrics = field(default_factory=SecretsMetrics)
    weakness_metrics: WeaknessMetrics = field(default_factory=WeaknessMetrics)
    threat_intel_metrics: ThreatIntelMetrics = field(default_factory=ThreatIntelMetrics)
    health_metrics: HealthMetrics = field(default_factory=HealthMetrics)
    attack_surface_metrics: AttackSurfaceMetrics = field(default_factory=AttackSurfaceMetrics)
    correlation_metrics: CorrelationMetrics = field(default_factory=CorrelationMetrics)
    coverage_metrics: ScanCoverageMetrics = field(default_factory=ScanCoverageMetrics)
    
    def to_dict(self) -> Dict:
        """Convert to dictionary for JSON serialization"""
        return asdict(self)
    
    def to_json(self, indent: int = 2) -> str:
        """Convert to JSON string"""
        return json.dumps(self.to_dict(), indent=indent)
    
    def get_executive_summary(self) -> Dict:
        """Get high-level executive metrics for dashboards"""
        return {
            "total_issues": (
                self.cve_metrics.total_cves +
                self.malware_metrics.total_malware_indicators +
                self.secrets_metrics.total_secrets +
                self.weakness_metrics.total_weaknesses
            ),
            "critical_issues": (
                self.cve_metrics.critical_cves +
                self.malware_metrics.critical_malware +
                self.secrets_metrics.critical_secrets +
                self.weakness_metrics.critical_weaknesses
            ),
            "reachable_issues": (
                self.cve_metrics.reachable_cves +
                self.secrets_metrics.reachable_secrets +
                self.weakness_metrics.reachable_weaknesses
            ),
            "workload_reduction_pct": self.cve_metrics.workload_reduction_pct,
            "time_saved_hours": self.cve_metrics.time_saved_hours,
            "multi_threat_packages": self.correlation_metrics.packages_with_multiple_threats,
            "attack_paths": self.correlation_metrics.attack_paths_identified
        }
    
    def get_risk_distribution(self) -> Dict:
        """Get risk distribution across all dimensions"""
        return {
            "critical": (
                self.cve_metrics.critical_cves +
                self.malware_metrics.critical_malware +
                self.secrets_metrics.critical_secrets +
                self.weakness_metrics.critical_weaknesses
            ),
            "high": (
                self.cve_metrics.high_cves +
                self.malware_metrics.high_malware +
                self.secrets_metrics.high_secrets +
                self.weakness_metrics.high_weaknesses
            ),
            "medium": (
                self.cve_metrics.medium_cves +
                self.malware_metrics.medium_malware +
                self.secrets_metrics.medium_secrets +
                self.weakness_metrics.medium_weaknesses
            ),
            "low": (
                self.cve_metrics.low_cves +
                self.malware_metrics.low_malware +
                self.secrets_metrics.low_secrets +
                self.weakness_metrics.low_weaknesses
            )
        }

class SecurityMetricsCollector:
    """
    Collects and aggregates security metrics from all scanners
    
    Usage:
        collector = SecurityMetricsCollector()
        collector.add_cve_data(cve_results)
        collector.add_malware_data(guarddog_results, semgrep_malware)
        collector.add_secrets_data(semgrep_secrets, trufflehog_secrets)
        collector.add_weakness_data(semgrep_sast)
        collector.add_threat_intel(kev, epss, exploit_db)
        collector.add_health_data(health_metrics)
        collector.add_correlation_data(correlation_results)
        
        metrics = collector.get_metrics()
    """
    
    def __init__(self):
        self.metrics = ComprehensiveSecurityMetrics()
    
    def add_cve_data(self, cve_data: Dict):
        """Add CVE detection data"""
        # Implementation to parse CVE data and populate metrics
        pass
    
    def add_malware_data(self, guarddog_data: Dict, semgrep_malware: List[Dict]):
        """Add malware detection data from GuardDog and Semgrep"""
        # Implementation to parse malware detections
        pass
    
    def add_secrets_data(self, semgrep_secrets: List[Dict], trufflehog_secrets: List[Dict]):
        """Add secrets detection data"""
        # Implementation to parse secrets
        pass
    
    def add_weakness_data(self, semgrep_sast: List[Dict]):
        """Add SAST weakness data"""
        # Implementation to parse SAST findings
        pass
    
    def add_threat_intel(self, kev: List, epss: Dict, exploit_db: List, metasploit: List):
        """Add threat intelligence enrichment"""
        # Implementation to parse threat intel
        pass
    
    def add_health_data(self, health_metrics: Dict):
        """Add package health metrics"""
        # Implementation to parse health data
        pass
    
    def add_attack_surface_data(self, call_graph: Dict, dependencies: List):
        """Add attack surface metrics"""
        # Implementation to calculate attack surface
        pass
    
    def add_correlation_data(self, correlation_results: Dict):
        """Add correlation engine results"""
        # Implementation to parse correlation insights
        pass
    
    def get_metrics(self) -> ComprehensiveSecurityMetrics:
        """Get complete metrics"""
        return self.metrics

# Example malware test case for lotusbail
LOTUSBAIL_TEST_CASE = {
    "package_name": "lotusbail",
    "description": "Supply chain attack disguised as @whiskeysockets/baileys fork",
    "expected_detections": {
        "malware_type": MalwareType.SUPPLY_CHAIN_ATTACK,
        "patterns_detected": [
            "exfiltration",
            "credential_harvesting",
            "hidden_payload",
            "suspicious_network_operations"
        ],
        "guarddog_score": 0.9,
        "semgrep_patterns": [
            "suspicious-network-request",
            "data-exfiltration",
            "credential-access"
        ],
        "threat_indicators": {
            "typosquatting": False,  # Legitimate fork name
            "downloads": 56000,       # High download count (trusted)
            "functional_code": True,  # Actually provides WhatsApp API
            "hidden_malicious_code": True,  # Concealed data theft
            "supply_chain": True      # Targets dependency chain
        }
    }
}
