#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.

"""
OWASP Classification for SAST Findings

Maps Semgrep/SAST rule IDs to OWASP Top 10 categories with risk weights.
Used by the REACHABLE risk scoring engine.

OWASP Top 10 (2021):
- A01: Broken Access Control
- A02: Cryptographic Failures
- A03: Injection
- A04: Insecure Design
- A05: Security Misconfiguration
- A06: Vulnerable and Outdated Components (covered by CVE scanning)
- A07: Identification and Authentication Failures
- A08: Software and Data Integrity Failures
- A09: Security Logging and Monitoring Failures
- A10: Server-Side Request Forgery (SSRF)
"""

import re
from dataclasses import dataclass
from enum import Enum
from typing import Optional, Tuple

class OWASPCategory(Enum):
    """OWASP Top 10 2021 Categories"""
    A01_BROKEN_ACCESS_CONTROL = "A01"
    A02_CRYPTOGRAPHIC_FAILURES = "A02"
    A03_INJECTION = "A03"
    A04_INSECURE_DESIGN = "A04"
    A05_SECURITY_MISCONFIGURATION = "A05"
    A06_VULNERABLE_COMPONENTS = "A06"  # Covered by CVE scanning
    A07_AUTH_FAILURES = "A07"
    A08_DATA_INTEGRITY_FAILURES = "A08"
    A09_LOGGING_FAILURES = "A09"
    A10_SSRF = "A10"
    
    # Non-OWASP categories
    CONTAINER_SECURITY = "CONTAINER"
    CODE_QUALITY = "QUALITY"
    NOT_SECURITY = "NONE"  # Not a security finding

@dataclass
class SASTClassification:
    """Classification result for a SAST finding"""
    owasp_category: OWASPCategory
    owasp_name: str
    risk_weight_reachable: int
    risk_weight_unreachable: int
    cwe_ids: list  # Related CWE IDs
    description: str

# OWASP Category Definitions with Risk Weights
OWASP_DEFINITIONS = {
    OWASPCategory.A01_BROKEN_ACCESS_CONTROL: SASTClassification(
        owasp_category=OWASPCategory.A01_BROKEN_ACCESS_CONTROL,
        owasp_name="Broken Access Control",
        risk_weight_reachable=150,
        risk_weight_unreachable=38,
        cwe_ids=[22, 23, 35, 59, 200, 201, 219, 264, 275, 276, 284, 285, 352, 359, 377, 402, 425, 441, 497, 538, 540, 548, 552, 566, 601, 639, 651, 668, 706, 862, 863, 913, 922, 1275],
        description="Restrictions on authenticated users not enforced, allowing access to unauthorized functionality or data"
    ),
    OWASPCategory.A02_CRYPTOGRAPHIC_FAILURES: SASTClassification(
        owasp_category=OWASPCategory.A02_CRYPTOGRAPHIC_FAILURES,
        owasp_name="Cryptographic Failures",
        risk_weight_reachable=80,
        risk_weight_unreachable=20,
        cwe_ids=[261, 296, 310, 319, 320, 321, 322, 323, 324, 325, 326, 327, 328, 329, 330, 331, 335, 336, 337, 338, 339, 340, 347, 523, 720, 757, 759, 760, 780, 818, 916],
        description="Failure to protect data in transit and at rest, or weak cryptographic algorithms"
    ),
    OWASPCategory.A03_INJECTION: SASTClassification(
        owasp_category=OWASPCategory.A03_INJECTION,
        owasp_name="Injection",
        risk_weight_reachable=200,
        risk_weight_unreachable=50,
        cwe_ids=[20, 74, 75, 77, 78, 79, 80, 83, 87, 88, 89, 90, 91, 93, 94, 95, 96, 97, 98, 99, 100, 113, 116, 138, 184, 470, 471, 564, 610, 643, 644, 652, 917],
        description="User-supplied data sent to interpreter as part of command or query"
    ),
    OWASPCategory.A04_INSECURE_DESIGN: SASTClassification(
        owasp_category=OWASPCategory.A04_INSECURE_DESIGN,
        owasp_name="Insecure Design",
        risk_weight_reachable=30,
        risk_weight_unreachable=8,
        cwe_ids=[73, 183, 209, 213, 235, 256, 257, 266, 269, 280, 311, 312, 313, 316, 419, 430, 434, 444, 451, 472, 501, 522, 525, 539, 579, 598, 602, 642, 646, 650, 653, 656, 657, 799, 807, 840, 841, 927, 1021, 1173],
        description="Missing or ineffective control design, architectural flaws"
    ),
    OWASPCategory.A05_SECURITY_MISCONFIGURATION: SASTClassification(
        owasp_category=OWASPCategory.A05_SECURITY_MISCONFIGURATION,
        owasp_name="Security Misconfiguration",
        risk_weight_reachable=60,
        risk_weight_unreachable=15,
        cwe_ids=[2, 11, 13, 15, 16, 260, 315, 520, 526, 537, 541, 547, 611, 614, 756, 776, 942, 1004, 1032, 1174],
        description="Missing appropriate security hardening, improper permissions, unnecessary features enabled"
    ),
    OWASPCategory.A07_AUTH_FAILURES: SASTClassification(
        owasp_category=OWASPCategory.A07_AUTH_FAILURES,
        owasp_name="Identification and Authentication Failures",
        risk_weight_reachable=150,
        risk_weight_unreachable=38,
        cwe_ids=[255, 259, 287, 288, 290, 294, 295, 297, 300, 302, 304, 306, 307, 346, 350, 384, 521, 613, 620, 640, 798, 940, 1216],
        description="Identity confirmation, authentication, and session management weaknesses"
    ),
    OWASPCategory.A08_DATA_INTEGRITY_FAILURES: SASTClassification(
        owasp_category=OWASPCategory.A08_DATA_INTEGRITY_FAILURES,
        owasp_name="Software and Data Integrity Failures",
        risk_weight_reachable=60,
        risk_weight_unreachable=15,
        cwe_ids=[345, 353, 426, 494, 502, 565, 784, 829, 830, 913, 915],
        description="Code and infrastructure that does not protect against integrity violations"
    ),
    OWASPCategory.A09_LOGGING_FAILURES: SASTClassification(
        owasp_category=OWASPCategory.A09_LOGGING_FAILURES,
        owasp_name="Security Logging and Monitoring Failures",
        risk_weight_reachable=20,
        risk_weight_unreachable=5,
        cwe_ids=[117, 223, 532, 778],
        description="Insufficient logging, detection, monitoring, and active response"
    ),
    OWASPCategory.A10_SSRF: SASTClassification(
        owasp_category=OWASPCategory.A10_SSRF,
        owasp_name="Server-Side Request Forgery (SSRF)",
        risk_weight_reachable=150,
        risk_weight_unreachable=38,
        cwe_ids=[918],
        description="Fetching remote resource without validating user-supplied URL"
    ),
    OWASPCategory.CONTAINER_SECURITY: SASTClassification(
        owasp_category=OWASPCategory.CONTAINER_SECURITY,
        owasp_name="Container Security",
        risk_weight_reachable=20,
        risk_weight_unreachable=5,
        cwe_ids=[250, 269],  # Execution with unnecessary privileges
        description="Container and Docker security issues (runs as root, privileged mode, etc.)"
    ),
    OWASPCategory.CODE_QUALITY: SASTClassification(
        owasp_category=OWASPCategory.CODE_QUALITY,
        owasp_name="Code Quality",
        risk_weight_reachable=10,
        risk_weight_unreachable=2,
        cwe_ids=[],
        description="General code quality and best practice issues"
    ),
    OWASPCategory.NOT_SECURITY: SASTClassification(
        owasp_category=OWASPCategory.NOT_SECURITY,
        owasp_name="Not Security Related",
        risk_weight_reachable=0,
        risk_weight_unreachable=0,
        cwe_ids=[],
        description="Non-security finding, does not affect risk score"
    ),
}

# Pattern matching for rule classification
# Maps regex patterns to OWASP categories
RULE_PATTERNS = {
    # A03: Injection (CRITICAL - direct code execution)
    OWASPCategory.A03_INJECTION: [
        r'sql[-_]?injection',
        r'sqli',
        r'nosql[-_]?injection',
        r'ldap[-_]?injection',
        r'xpath[-_]?injection',
        r'command[-_]?injection',
        r'os[-_]?command',
        r'code[-_]?injection',
        r'expression[-_]?injection',
        r'template[-_]?injection',
        r'ssti',  # Server-Side Template Injection
        r'xss',
        r'cross[-_]?site[-_]?scripting',
        r'script[-_]?injection',
        r'html[-_]?injection',
        r'xxe',
        r'xml[-_]?external[-_]?entity',
        r'xml[-_]?injection',
        r'header[-_]?injection',
        r'crlf[-_]?injection',
        r'log[-_]?injection',
        r'eval\(',
        r'exec\(',
        r'shell[-_]?exec',
        r'subprocess',
        r'popen',
        r'system\(',
        r'dangerous[-_]?exec',
        r'unsafe[-_]?eval',
        r'untrusted[-_]?input',
    ],
    
    # A01: Broken Access Control
    OWASPCategory.A01_BROKEN_ACCESS_CONTROL: [
        r'path[-_]?traversal',
        r'directory[-_]?traversal',
        r'lfi',  # Local File Inclusion
        r'rfi',  # Remote File Inclusion
        r'file[-_]?inclusion',
        r'idor',
        r'insecure[-_]?direct[-_]?object',
        r'broken[-_]?access',
        r'access[-_]?control',
        r'privilege[-_]?escalation',
        r'privesc',
        r'authorization[-_]?bypass',
        r'auth[-_]?bypass',
        r'permission[-_]?bypass',
        r'open[-_]?redirect',
        r'unvalidated[-_]?redirect',
        r'csrf',
        r'cross[-_]?site[-_]?request[-_]?forgery',
        r'missing[-_]?authorization',
        r'missing[-_]?access[-_]?control',
        r'cors[-_]?misconfiguration',
        r'clickjacking',
        r'frame[-_]?injection',
    ],
    
    # A07: Authentication Failures
    OWASPCategory.A07_AUTH_FAILURES: [
        r'broken[-_]?auth',
        r'authentication[-_]?bypass',
        r'session[-_]?fixation',
        r'session[-_]?hijack',
        r'weak[-_]?password',
        r'hardcoded[-_]?password',
        r'password[-_]?in[-_]?code',
        r'credential[-_]?stuffing',
        r'brute[-_]?force',
        r'missing[-_]?auth',
        r'insecure[-_]?auth',
        r'jwt[-_]?vulnerab',
        r'token[-_]?validation',
        r'missing[-_]?verification',
        r'insecure[-_]?cookie',
        r'cookie[-_]?without[-_]?secure',
        r'cookie[-_]?without[-_]?httponly',
        r'remember[-_]?me[-_]?vulnerab',
    ],
    
    # A10: SSRF
    OWASPCategory.A10_SSRF: [
        r'ssrf',
        r'server[-_]?side[-_]?request[-_]?forgery',
        r'url[-_]?injection',
        r'request[-_]?forgery',
        r'fetch[-_]?injection',
        r'unvalidated[-_]?url',
        r'arbitrary[-_]?url',
    ],
    
    # A02: Cryptographic Failures
    OWASPCategory.A02_CRYPTOGRAPHIC_FAILURES: [
        r'weak[-_]?crypto',
        r'insecure[-_]?crypto',
        r'weak[-_]?hash',
        r'insecure[-_]?hash',
        r'md5',
        r'sha1[^0-9]',
        r'des[^a-z]',
        r'3des',
        r'rc4',
        r'rc2',
        r'blowfish',
        r'ecb[-_]?mode',
        r'weak[-_]?random',
        r'insecure[-_]?random',
        r'predictable[-_]?random',
        r'math\.random',
        r'random\(\)',
        r'weak[-_]?ssl',
        r'insecure[-_]?ssl',
        r'ssl[-_]?verification[-_]?disabled',
        r'certificate[-_]?validation[-_]?disabled',
        r'hardcoded[-_]?key',
        r'hardcoded[-_]?iv',
        r'static[-_]?iv',
        r'weak[-_]?key',
        r'insufficient[-_]?key[-_]?size',
    ],
    
    # A05: Security Misconfiguration
    OWASPCategory.A05_SECURITY_MISCONFIGURATION: [
        r'debug[-_]?mode',
        r'debug[-_]?enabled',
        r'verbose[-_]?error',
        r'stack[-_]?trace[-_]?exposed',
        r'security[-_]?header',
        r'missing[-_]?header',
        r'x[-_]?frame[-_]?options',
        r'content[-_]?security[-_]?policy',
        r'csp[-_]?missing',
        r'hsts[-_]?missing',
        r'x[-_]?content[-_]?type[-_]?options',
        r'default[-_]?credential',
        r'default[-_]?password',
        r'admin[-_]?interface[-_]?exposed',
        r'directory[-_]?listing',
        r'sensitive[-_]?file[-_]?exposed',
        r'backup[-_]?file[-_]?exposed',
        r'git[-_]?exposed',
        r'svn[-_]?exposed',
        r'env[-_]?file[-_]?exposed',
        r'config[-_]?file[-_]?exposed',
        r'phpinfo',
        r'server[-_]?version[-_]?exposed',
    ],
    
    # A08: Data Integrity Failures
    OWASPCategory.A08_DATA_INTEGRITY_FAILURES: [
        r'insecure[-_]?deserialization',
        r'unsafe[-_]?deserialization',
        r'object[-_]?injection',
        r'pickle',
        r'marshal',
        r'yaml\.load',
        r'yaml\.unsafe',
        r'prototype[-_]?pollution',
        r'mass[-_]?assignment',
        r'unsigned[-_]?code',
        r'unverified[-_]?update',
        r'integrity[-_]?check[-_]?missing',
    ],
    
    # A09: Logging Failures
    OWASPCategory.A09_LOGGING_FAILURES: [
        r'log[-_]?forging',
        r'logging[-_]?sensitive[-_]?data',
        r'password[-_]?in[-_]?log',
        r'credentials[-_]?logged',
        r'pii[-_]?logged',
        r'missing[-_]?audit[-_]?log',
        r'audit[-_]?log[-_]?disabled',
    ],
    
    # A04: Insecure Design
    OWASPCategory.A04_INSECURE_DESIGN: [
        r'race[-_]?condition',
        r'toctou',  # Time of check to time of use
        r'time[-_]?of[-_]?check',
        r'missing[-_]?rate[-_]?limit',
        r'denial[-_]?of[-_]?service',
        r'dos[-_]?vulnerab',
        r'regex[-_]?dos',
        r'redos',
        r'resource[-_]?exhaustion',
        r'unbounded[-_]?allocation',
        r'infinite[-_]?loop',
        r'recursion[-_]?limit',
    ],
    
    # Container Security (Non-OWASP)
    OWASPCategory.CONTAINER_SECURITY: [
        r'dockerfile',
        r'docker[-_]?security',
        r'run[-_]?as[-_]?root',
        r'privileged[-_]?container',
        r'privileged[-_]?mode',
        r'cap[-_]?add',
        r'sys[-_]?admin',
        r'net[-_]?admin',
        r'host[-_]?network',
        r'host[-_]?pid',
        r'host[-_]?ipc',
        r'docker\.sock',
        r'seccomp[-_]?disabled',
        r'apparmor[-_]?disabled',
        r'missing[-_]?user',
        r'container.*root',
        r'kubernetes.*security',
        r'k8s.*security',
        r'pod[-_]?security',
    ],
}

def classify_sast_finding(rule_id: str, message: str = "") -> SASTClassification:
    """
    Classify a SAST finding by OWASP category.
    
    Args:
        rule_id: The Semgrep or other SAST tool rule ID
        message: Optional message/description for additional context
        
    Returns:
        SASTClassification with OWASP category and risk weights
    """
    combined = f"{rule_id} {message}".lower()
    
    # Check Container Security FIRST (more specific, before A01)
    for pattern in RULE_PATTERNS[OWASPCategory.CONTAINER_SECURITY]:
        if re.search(pattern, combined, re.IGNORECASE):
            return OWASP_DEFINITIONS[OWASPCategory.CONTAINER_SECURITY]
    
    # Check other categories in priority order
    priority_order = [
        OWASPCategory.A03_INJECTION,  # Most critical
        OWASPCategory.A10_SSRF,
        OWASPCategory.A07_AUTH_FAILURES,
        OWASPCategory.A01_BROKEN_ACCESS_CONTROL,
        OWASPCategory.A02_CRYPTOGRAPHIC_FAILURES,
        OWASPCategory.A08_DATA_INTEGRITY_FAILURES,
        OWASPCategory.A05_SECURITY_MISCONFIGURATION,
        OWASPCategory.A04_INSECURE_DESIGN,
        OWASPCategory.A09_LOGGING_FAILURES,
    ]
    
    for category in priority_order:
        if category not in RULE_PATTERNS:
            continue
        for pattern in RULE_PATTERNS[category]:
            if re.search(pattern, combined, re.IGNORECASE):
                return OWASP_DEFINITIONS[category]
    
    # Check for generic security patterns
    if any(word in combined for word in ['security', 'vulnerab', 'insecure', 'unsafe']):
        return OWASP_DEFINITIONS[OWASPCategory.CODE_QUALITY]
    
    # Default to not security related
    return OWASP_DEFINITIONS[OWASPCategory.NOT_SECURITY]

def get_risk_weight(rule_id: str, message: str = "", is_reachable: bool = True) -> Tuple[int, SASTClassification]:
    """
    Get the risk weight for a SAST finding.
    
    Args:
        rule_id: The SAST rule ID
        message: Optional message for context
        is_reachable: Whether the finding is in reachable code
        
    Returns:
        Tuple of (risk_weight, classification)
    """
    classification = classify_sast_finding(rule_id, message)
    
    if is_reachable:
        return classification.risk_weight_reachable, classification
    else:
        return classification.risk_weight_unreachable, classification

def is_owasp_critical(classification: SASTClassification) -> bool:
    """Check if this is a critical OWASP category (A01, A03, A07, A10)"""
    return classification.owasp_category in [
        OWASPCategory.A01_BROKEN_ACCESS_CONTROL,
        OWASPCategory.A03_INJECTION,
        OWASPCategory.A07_AUTH_FAILURES,
        OWASPCategory.A10_SSRF,
    ]

def is_security_finding(classification: SASTClassification) -> bool:
    """Check if this is actually a security finding that affects risk score"""
    return classification.owasp_category != OWASPCategory.NOT_SECURITY

# Export summary for documentation
def get_owasp_summary() -> dict:
    """Get a summary of all OWASP categories and their weights"""
    return {
        cat.value: {
            "name": defn.owasp_name,
            "reachable_weight": defn.risk_weight_reachable,
            "unreachable_weight": defn.risk_weight_unreachable,
            "description": defn.description,
        }
        for cat, defn in OWASP_DEFINITIONS.items()
    }

if __name__ == "__main__":
    # Test classification
    test_cases = [
        ("generic.secrets.security.detected-aws-access-key", "AWS access key detected"),
        ("python.lang.security.audit.dangerous-subprocess-use", "subprocess.call with shell=True"),
        ("javascript.browser.security.insecure-document-method", "document.write used"),
        ("docker.security.missing-user", "Dockerfile does not use USER directive"),
        ("python.lang.security.audit.hardcoded-sql-expression", "SQL query with string formatting"),
        ("go.lang.security.audit.xss.direct-response-write", "Direct response write"),
        ("javascript.lang.security.audit.path-traversal", "Path traversal vulnerability"),
    ]
    
    print("OWASP SAST Classification Test")
    print("=" * 70)
    
    for rule_id, message in test_cases:
        classification = classify_sast_finding(rule_id, message)
        print(f"\nRule: {rule_id}")
        print(f"  OWASP: {classification.owasp_category.value} - {classification.owasp_name}")
        print(f"  Weight: {classification.risk_weight_reachable} (reachable) / {classification.risk_weight_unreachable} (unreachable)")
        print(f"  Is Critical OWASP: {is_owasp_critical(classification)}")
