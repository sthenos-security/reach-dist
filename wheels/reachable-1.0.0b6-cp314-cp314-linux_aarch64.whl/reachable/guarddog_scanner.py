#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.

"""
GuardDog Malware Detection Integration

Integrates GuardDog to scan Python packages for malicious code patterns.
GuardDog checks for:
- Obfuscated code
- Network connections to suspicious domains
- Code execution patterns
- Credential theft attempts
- And more...

CI/CD Caching:
    Set REACHABLE_CACHE_DIR to a cached path for faster CI builds.
    The guarddog-venv subdirectory will be created there.
    
    GitHub Actions example:
        - uses: actions/cache@v4
          with:
            path: ~/.reachable-cache
            key: reachable-cache-${{ runner.os }}-v1
        - run: reachable scan .
          env:
            REACHABLE_CACHE_DIR: ~/.reachable-cache
    
    GitLab CI example:
        cache:
          paths:
            - .reachable-cache/
        variables:
          REACHABLE_CACHE_DIR: .reachable-cache
"""

import json
import os
import sys
import shutil
import subprocess
import time
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional
from dataclasses import dataclass

# Version marker for cache invalidation
# Bump this when GuardDog dependencies change significantly
# v1.1.0: Fixed parsing for GuardDog 2.x JSON format (int vs list for findings)
GUARDDOG_CACHE_VERSION = "1.1.0"

# Cache refresh interval (seconds) - default 7 days
# Set GUARDDOG_CACHE_TTL=0 to disable TTL-based refresh
GUARDDOG_CACHE_TTL = int(os.environ.get('GUARDDOG_CACHE_TTL', 7 * 24 * 60 * 60))

@dataclass
class MalwareDetection:
    """Malware detection result"""
    package_name: str
    package_version: str
    is_malicious: bool
    risk_level: str  # LOW, MEDIUM, HIGH, CRITICAL
    detections: List[Dict]
    confidence: str  # LOW, MEDIUM, HIGH

class GuardDogScanner:
    """GuardDog integration for malware detection"""
    
    # Enterprise configurable error threshold
    # Set via GUARDDOG_ERROR_LIMIT env var or constructor
    DEFAULT_ERROR_LIMIT = 10
    
    def __init__(self, cache_dir: Optional[Path] = None, error_limit: Optional[int] = None):
        """
        Initialize GuardDog scanner
        
        Args:
            cache_dir: Directory to cache scan results (per-package)
            error_limit: Max errors to show before suppressing (default: 10, enterprise: set higher or -1 for unlimited)
        
        Environment Variables:
            REACHABLE_CACHE_DIR: Base directory for all caches (venv, results)
                                 Useful for CI/CD caching. Default: ~/.reachable-cache
            GUARDDOG_ERROR_LIMIT: Max errors to display
        """
        self.cache_dir = Path(cache_dir) if cache_dir else None
        if self.cache_dir:
            self.cache_dir.mkdir(parents=True, exist_ok=True)
        
        # Cache statistics for performance monitoring
        self.cache_hits = 0
        self.cache_misses = 0
        
        # Error limit: -1 = unlimited, 0 = suppress all, N = show first N
        env_limit = os.environ.get('GUARDDOG_ERROR_LIMIT')
        if error_limit is not None:
            self.error_limit = error_limit
        elif env_limit is not None:
            try:
                self.error_limit = int(env_limit)
            except ValueError:
                self.error_limit = self.DEFAULT_ERROR_LIMIT
        else:
            self.error_limit = self.DEFAULT_ERROR_LIMIT
        
        # GuardDog isolated venv - respect REACHABLE_CACHE_DIR for CI/CD
        cache_base = os.environ.get('REACHABLE_CACHE_DIR')
        if cache_base:
            self.guarddog_venv = Path(cache_base).expanduser() / 'guarddog-venv'
        else:
            self.guarddog_venv = Path.home() / '.reachable-cache' / 'guarddog-venv'
        
        self._available = None  # Will check/setup on first use
    
    def _sanitize_package_name(self, package_name: str) -> str:
        """
        Sanitize package name for use in filenames
        
        Handles scoped packages like @babel/code-frame:
        - Replaces / with -
        - Replaces @ with at-
        - Replaces other unsafe chars
        
        Examples:
            @babel/code-frame → at-babel-code-frame
            ../nexee-api-specs → ..-nexee-api-specs
            actions/checkout → actions-checkout
        """
        sanitized = package_name
        sanitized = sanitized.replace('@', 'at-')
        sanitized = sanitized.replace('/', '-')
        sanitized = sanitized.replace('\\', '-')
        sanitized = sanitized.replace(':', '-')
        sanitized = sanitized.replace(' ', '_')
        return sanitized
    
    def _get_venv_paths(self):
        """Get platform-specific venv paths"""
        import platform
        
        if platform.system() == 'Windows':
            bin_dir = self.guarddog_venv / 'Scripts'
            python_exe = bin_dir / 'python.exe'
            pip_exe = bin_dir / 'pip.exe'
            guarddog_exe = bin_dir / 'guarddog.exe'
        else:
            bin_dir = self.guarddog_venv / 'bin'
            python_exe = bin_dir / 'python3'
            pip_exe = bin_dir / 'pip'
            guarddog_exe = bin_dir / 'guarddog'
        
        return {
            'bin_dir': bin_dir,
            'python': python_exe,
            'pip': pip_exe,
            'guarddog': guarddog_exe
        }
    
    def _setup_guarddog_venv(self) -> bool:
        """
        Create isolated venv for GuardDog on-demand (cross-platform)
        Works on: macOS (Intel/ARM), Linux (x86/ARM), Windows
        Returns True if setup successful
        
        CI/CD Caching:
            The venv is stored in REACHABLE_CACHE_DIR/guarddog-venv
            A version marker file tracks cache validity.
            Cache the entire REACHABLE_CACHE_DIR between CI runs.
        """
        import venv
        import platform
        import shutil
        
        paths = self._get_venv_paths()
        version_marker = self.guarddog_venv / '.cache_version'
        
        # Check if already set up and working
        if paths['guarddog'].exists():
            # Verify cache version and TTL
            cache_valid = False
            cache_expired = False
            
            if version_marker.exists():
                try:
                    cached_version = version_marker.read_text().strip()
                    cache_valid = (cached_version == GUARDDOG_CACHE_VERSION)
                    
                    if not cache_valid:
                        print(f"   ♻️  GuardDog cache outdated (v{cached_version} → v{GUARDDOG_CACHE_VERSION}), rebuilding...")
                    elif GUARDDOG_CACHE_TTL > 0:
                        # Check cache age
                        cache_age = time.time() - version_marker.stat().st_mtime
                        if cache_age > GUARDDOG_CACHE_TTL:
                            cache_expired = True
                            days_old = int(cache_age / 86400)
                            print(f"   ♻️  GuardDog cache expired ({days_old} days old), refreshing...")
                            cache_valid = False
                except Exception:
                    pass
            
            if cache_valid:
                try:
                    result = subprocess.run([str(paths['guarddog']), '--version'],
                                          capture_output=True, timeout=5)
                    if result.returncode == 0:
                        return True
                except (subprocess.SubprocessError, OSError, subprocess.TimeoutExpired):
                    # GuardDog binary exists but failed to run - needs reinstall
                    pass
        
        print("   📦 First-time GuardDog setup (automated)...")
        print(f"      Location: {self.guarddog_venv}")
        cache_dir_env = os.environ.get('REACHABLE_CACHE_DIR')
        if cache_dir_env:
            print(f"      💡 CI Cache: Set (REACHABLE_CACHE_DIR={cache_dir_env})")
        else:
            print("      💡 Tip: Set REACHABLE_CACHE_DIR for CI/CD caching")
        print("      (Happens once per cache, ~1-2 minutes)")
        
        try:
            # Use our complete auto-installer
            from pathlib import Path
            installer_script = Path(__file__).parent.parent / "scripts" / "setup_guarddog.py"
            
            if installer_script.exists():
                print("      Running auto-installer (supports all OSes)...")
                result = subprocess.run([sys.executable, str(installer_script)],
                                       capture_output=True, text=True, timeout=300)
                
                if result.returncode == 0:
                    print("      ✅ GuardDog installed successfully")
                    # Write version marker for cache validation
                    try:
                        version_marker.write_text(GUARDDOG_CACHE_VERSION)
                    except Exception:
                        pass  # Non-fatal
                    return True
                else:
                    print("      ❌ Auto-installer failed:")
                    print(result.stdout)
                    print(result.stderr)
                    return False
            else:
                # Fallback to manual installation if installer missing
                print("      ⚠️  Auto-installer not found, using fallback...")
                return self._fallback_guarddog_install(paths)
            
        except subprocess.TimeoutExpired:
            print("      ❌ Installation timed out (>5 minutes)")
            return False
        except Exception as e:
            print(f"      ❌ Unexpected error: {e}")
            return False
    
    def _fallback_guarddog_install(self, paths):
        """Fallback installation - calls auto-installer script"""
        import platform
        import subprocess
        import venv  # v4.5.4 FIX: was missing, caused 'name venv is not defined' error
        
        print("      Running complete auto-installer...")
        
        # Auto-install system dependencies first
        system = platform.system().lower()
        
        try:
            if system == "darwin":  # macOS
                print("      📦 macOS: Installing libgit2 via Homebrew...")
                # Check if brew exists
                brew_check = subprocess.run(["which", "brew"], capture_output=True)
                if brew_check.returncode != 0:
                    print("      ❌ Homebrew not found. Install from https://brew.sh")
                    return False
                
                # Check if libgit2 already installed
                check_result = subprocess.run(["brew", "list", "libgit2"], 
                                             capture_output=True, timeout=10)
                if check_result.returncode != 0:
                    print("      Installing libgit2...")
                    subprocess.check_call(["brew", "install", "libgit2"], timeout=300)
                    print("      ✅ libgit2 installed")
                else:
                    print("      ✅ libgit2 already installed")
                    
            elif system == "linux":
                # Detect Linux distro
                distro = None
                if os.path.exists('/etc/os-release'):
                    with open('/etc/os-release', 'r') as f:
                        content = f.read().lower()
                        if 'ubuntu' in content or 'debian' in content:
                            distro = 'debian'
                        elif 'rhel' in content or 'fedora' in content or 'centos' in content:
                            distro = 'rhel'
                        elif 'arch' in content:
                            distro = 'arch'
                        elif 'alpine' in content:
                            distro = 'alpine'
                        elif 'suse' in content:
                            distro = 'suse'
                
                print(f"      📦 Linux ({distro}): Installing libgit2...")
                
                if distro == 'debian':
                    subprocess.check_call(["sudo", "apt-get", "update", "-qq"], timeout=60)
                    subprocess.check_call(["sudo", "apt-get", "install", "-y", 
                                          "libgit2-dev", "pkg-config"], timeout=300)
                elif distro == 'rhel':
                    if os.path.exists('/usr/bin/dnf'):
                        subprocess.check_call(["sudo", "dnf", "install", "-y", 
                                              "libgit2-devel", "pkg-config"], timeout=300)
                    elif os.path.exists('/usr/bin/yum'):
                        subprocess.check_call(["sudo", "yum", "install", "-y", 
                                              "libgit2-devel", "pkgconfig"], timeout=300)
                elif distro == 'arch':
                    subprocess.check_call(["sudo", "pacman", "-S", "--noconfirm", 
                                          "libgit2", "pkg-config"], timeout=300)
                elif distro == 'alpine':
                    subprocess.check_call(["sudo", "apk", "add", "libgit2-dev", 
                                          "pkgconf"], timeout=300)
                elif distro == 'suse':
                    subprocess.check_call(["sudo", "zypper", "install", "-y", 
                                          "libgit2-devel", "pkg-config"], timeout=300)
                else:
                    print("      ⚠️  Unknown Linux distro - please install libgit2-dev manually")
                    return False
                    
                print("      ✅ libgit2 installed")
                
        except subprocess.CalledProcessError as e:
            print(f"      ❌ System dependency install failed: {e}")
            return False
        except subprocess.TimeoutExpired:
            print("      ❌ System dependency install timed out")
            return False
        
        # Now create venv and install GuardDog
        print("      Creating virtual environment...")
        try:
            self.guarddog_venv.parent.mkdir(parents=True, exist_ok=True)
            if self.guarddog_venv.exists():
                shutil.rmtree(self.guarddog_venv)
            
            venv.create(self.guarddog_venv, with_pip=True)
            
            # Redefine paths for this venv
            if platform.system() == 'Windows':
                paths = {
                    'python': self.guarddog_venv / 'Scripts' / 'python.exe',
                    'pip': self.guarddog_venv / 'Scripts' / 'pip.exe',
                    'guarddog': self.guarddog_venv / 'Scripts' / 'guarddog.exe'
                }
            else:
                paths = {
                    'python': self.guarddog_venv / 'bin' / 'python',
                    'pip': self.guarddog_venv / 'bin' / 'pip',
                    'guarddog': self.guarddog_venv / 'bin' / 'guarddog'
                }
            
            print("      Upgrading pip...")
            result = subprocess.run(
                [str(paths['python']), '-m', 'pip', 'install', 
                 '--upgrade', 'pip', 'setuptools', 'wheel'],
                capture_output=True, timeout=90, text=True
            )
            
            if result.returncode != 0:
                print(f"      ⚠️  Upgrade warning: {result.stderr[:200]}")
            
            # Platform-specific environment setup
            env = os.environ.copy()
            
            if platform.system() == 'Darwin':
                # macOS: Set flags for libgit2 (homebrew paths)
                # Find homebrew (Intel or Apple Silicon)
                for hb_path in ['/opt/homebrew', '/usr/local']:
                    if Path(hb_path).exists():
                        env['LDFLAGS'] = f"-L{hb_path}/lib"
                        env['CPPFLAGS'] = f"-I{hb_path}/include"
                        env['PKG_CONFIG_PATH'] = f"{hb_path}/lib/pkgconfig"
                        
                        # Apple Silicon specific: Ensure arm64 builds
                        if platform.machine() == 'arm64':
                            env['ARCHFLAGS'] = '-arch arm64'
                        break
            
            # Install guarddog
            print("      Installing guarddog...")
            install_cmd = [str(paths['pip']), 'install', 'guarddog']
            
            # Windows: prefer binary wheels to avoid compilation
            if platform.system() == 'Windows':
                install_cmd.extend(['--only-binary', ':all:'])
            
            result = subprocess.run(install_cmd, capture_output=True, 
                                  timeout=180, env=env, text=True)
            
            if result.returncode != 0:
                print(f"      ❌ GuardDog installation failed")
                print(f"         Error: {result.stderr[:300]}")
                
                # Try to give helpful error message
                if 'libgit2' in result.stderr or 'git2.h' in result.stderr:
                    print("\n      💡 libgit2 is required. Install it:")
                    print("         macOS:   brew install libgit2")
                    print("         Linux:   sudo apt-get install libgit2-dev")
                    print("\n         Then delete venv and retry:")
                    print(f"         rm -rf {self.guarddog_venv}")
                
                return False
            
            # Verify installation
            if paths['guarddog'].exists():
                # Test that it actually works
                test_result = subprocess.run([str(paths['guarddog']), '--version'],
                                           capture_output=True, timeout=5)
                if test_result.returncode == 0:
                    print("      ✅ GuardDog ready")
                    # Write version marker for cache validation
                    try:
                        version_marker = self.guarddog_venv / '.cache_version'
                        version_marker.write_text(GUARDDOG_CACHE_VERSION)
                    except Exception:
                        pass  # Non-fatal
                    return True
                else:
                    print("      ❌ GuardDog installed but not working properly")
                    if test_result.stderr:
                        stderr_lines = test_result.stderr.decode('utf-8', errors='ignore').strip().split('\n')
                        for line in stderr_lines[:5]:  # Show first 5 lines
                            print(f"         {line}")
                    
                    # Check for common issues
                    stderr_str = test_result.stderr.decode('utf-8', errors='ignore') if test_result.stderr else ''
                    
                    if 'libgit2' in stderr_str or 'pygit2' in stderr_str:
                        print("\n      💡 pygit2 dependency issue. Install libgit2:")
                        print("         macOS:   brew install libgit2")
                        print("         Ubuntu:  sudo apt-get install libgit2-dev")
                        print("         Then: pip install pygit2 --break-system-packages")
                    elif 'No module named' in stderr_str:
                        print("\n      💡 Missing Python dependencies")
                        print(f"         Try reinstalling: rm -rf {self.guarddog_venv}")
                    else:
                        print("\n      💡 Try manual installation:")
                        print(f"         rm -rf {self.guarddog_venv}")
                        print("         python3 -m venv ~/.reachable-cache/guarddog-venv")
                        print("         source ~/.reachable-cache/guarddog-venv/bin/activate")
                        print("         pip install guarddog")
                        print("         guarddog --version  # Test it")
                    
                    return False
            else:
                print("      ❌ GuardDog binary not found after install")
                print(f"         Expected at: {paths['guarddog']}")
                print("         Venv may be corrupted. Try:")
                print(f"         rm -rf {self.guarddog_venv}")
                return False
                
        except subprocess.TimeoutExpired:
            print("      ❌ Installation timeout (>180s)")
            print("         Network may be slow. Try manually:")
            print(f"         python3 -m venv {self.guarddog_venv}")
            print(f"         source {self.guarddog_venv}/bin/activate")
            print("         pip install --upgrade pip setuptools wheel")
            print("         pip install guarddog")
            return False
        except Exception as e:
            print(f"      ❌ Setup error: {str(e)[:200]}")
            return False
    
    def _check_guarddog_available(self) -> bool:
        """Check/setup GuardDog on-demand"""
        if self._available is None:
            # First time check - try to setup if needed
            self._available = self._setup_guarddog_venv()
        return self._available
    
    def is_available(self) -> bool:
        """Check if GuardDog is available"""
        return self._check_guarddog_available()
    
    def _detect_ecosystem(self, package_name: str) -> str:
        """
        Auto-detect package ecosystem from name patterns
        
        NPM packages often have:
        - Scoped names (@babel/core)
        - Kebab-case (lodash-es)
        
        PyPI packages often have:
        - Underscores (urllib3)
        - Hyphens (requests-mock)
        
        Args:
            package_name: Package name
            
        Returns:
            'npm' or 'pypi'
        """
        # Scoped packages are always NPM
        if package_name.startswith('@'):
            return 'npm'
        
        # Common NPM-only packages
        npm_packages = {
            'react', 'vue', 'angular', 'next', 'express', 'webpack',
            'lodash', 'axios', 'chalk', 'commander', 'semver', 'debug',
            'typescript', 'eslint', 'prettier', 'jest', 'mocha', 'babel'
        }
        base_name = package_name.split('/')[1] if '/' in package_name else package_name
        base_name = base_name.split('-')[0] if '-' in base_name else base_name
        
        if base_name.lower() in npm_packages:
            return 'npm'
        
        # Common PyPI-only packages
        pypi_packages = {
            'django', 'flask', 'pandas', 'numpy', 'scipy', 'requests',
            'urllib3', 'boto3', 'pytest', 'pillow', 'sqlalchemy'
        }
        base_name = package_name.replace('-', '_').split('_')[0]
        
        if base_name.lower() in pypi_packages:
            return 'pypi'
        
        # Default: check SBOM if available, otherwise assume npm
        # (npm is more common in modern web apps)
        return 'npm'
    
    def scan_local_directory(self, package_dir: Path, ecosystem: str = 'npm') -> Optional[MalwareDetection]:
        """
        Scan a locally cloned package directory with multi-tier detection
        
        DETECTION TIERS:
        1. GuardDog: Metadata + Semgrep patterns
        2. YARA: Byte-level signatures (fast)
        3. Deep Scanner: Entropy + AST (slow, confirms encryption)
        
        This is MORE accurate than remote scanning because:
        1. GuardDog can analyze actual code, not just metadata
        2. YARA finds byte patterns that evade AST
        3. Deep scanner confirms encrypted payloads
        
        Args:
            package_dir: Path to package directory
            ecosystem: 'npm' or 'pypi'
            
        Returns:
            Combined multi-tier detection results
        """
        if not self._available:
            return None
        
        try:
            # TIER 1: GuardDog scan
            paths = self._get_venv_paths()
            guarddog_cmd = str(paths['guarddog'])
            
            result = subprocess.run(
                [guarddog_cmd, ecosystem, 'scan', str(package_dir), '--output-format', 'json'],
                capture_output=True,
                text=True,
                timeout=60
            )
            
            # Parse GuardDog results (supports both old and new 2.x format)
            guarddog_detections = []
            guarddog_is_malicious = False
            guarddog_risk = 'LOW'
            
            if result.stdout and result.stdout.strip():
                try:
                    data = json.loads(result.stdout)
                    
                    # Handle old format with 'issues' key
                    if 'issues' in data and isinstance(data['issues'], list):
                        guarddog_detections = data['issues']
                    else:
                        # New GuardDog 2.x format: package names as top-level keys
                        for pkg_key, rules in data.items():
                            if not isinstance(rules, dict):
                                continue
                            for rule_name, findings in rules.items():
                                # CRITICAL FIX: Skip integers (0 = no findings)
                                if isinstance(findings, int):
                                    continue
                                if not isinstance(findings, list):
                                    continue
                                for finding in findings:
                                    if isinstance(finding, dict):
                                        finding['rule_id'] = rule_name  # Add rule name for risk calc
                                        guarddog_detections.append(finding)
                    
                    guarddog_is_malicious = len(guarddog_detections) > 0
                    guarddog_risk = self._calculate_risk_from_issues(guarddog_detections)
                except (json.JSONDecodeError, ValueError):
                    pass
            
            # TIER 2: YARA byte-level scan (fast, catches obfuscated patterns)
            yara_detections = []
            try:
                from reachable.yara_scanner import YaraScanner
                yara = YaraScanner()
                if yara.is_available():
                    yara_results = yara.scan_directory(package_dir)
                    if yara_results:
                        summary = yara.get_summary(yara_results)
                        
                        # Convert YARA matches to detections
                        for file_path, matches in yara_results.items():
                            for match in matches:
                                yara_detections.append({
                                    'type': 'yara_signature',
                                    'rule': match.rule_name,
                                    'severity': match.severity,
                                    'file': file_path,
                                    'description': match.meta.get('description', '')
                                })
                        
                        # Escalate if YARA found critical patterns
                        if summary['severity']['critical'] > 0:
                            guarddog_risk = 'CRITICAL'
                            guarddog_is_malicious = True
            except ImportError:
                pass  # YARA not available
            
            # TIER 3: Deep scanner (runs on suspicious packages)
            deep_detections = []
            has_obfuscation = any('obfuscation' in str(d).lower() for d in guarddog_detections)
            has_encryption_sig = any('Encryption' in d.get('rule', '') for d in yara_detections)
            has_suspicious_patterns = guarddog_is_malicious or len(yara_detections) > 0
            
            # Run Tier 3 if ANY suspicious indicators (more aggressive)
            if has_suspicious_patterns or has_obfuscation or has_encryption_sig:
                try:
                    from reachable.deep_malware_scanner import analyze_package_directory
                    deep_results = analyze_package_directory(package_dir, verbose=False)
                    
                    # Escalate if deep scanner confirms encryption
                    critical_files = [r for r in deep_results.values() if r.verdict == 'CRITICAL']
                    if critical_files:
                        guarddog_risk = 'CRITICAL'
                        guarddog_is_malicious = True
                        deep_detections = [{
                            'type': 'encrypted_payload_confirmed',
                            'severity': 'CRITICAL',
                            'description': f'Encrypted malware confirmed by deep scan: {len(critical_files)} files',
                            'evidence': {
                                'entropy_spikes': len([r for r in critical_files if r.has_high_entropy]),
                                'unpacker_patterns': len([r for r in critical_files if r.has_unpacker_logic]),
                                'files': [r.file_path for r in critical_files[:3]]  # First 3
                            }
                        }]
                except ImportError:
                    pass  # Deep scanner not available
            
            # Combine all detections
            all_detections = guarddog_detections + yara_detections + deep_detections
            
            package_name = package_dir.name
            
            return MalwareDetection(
                package_name=package_name,
                package_version='local',
                is_malicious=guarddog_is_malicious,
                risk_level=guarddog_risk,
                detections=all_detections,
                confidence='HIGH' if deep_detections else 'MEDIUM'
            )
            
        except Exception as e:
            return None
    
    def _calculate_risk_from_issues(self, issues: List[Dict]) -> str:
        """Calculate risk level from GuardDog issues"""
        if not issues:
            return 'LOW'
        
        # Check for critical patterns
        critical_patterns = ['exec-base64', 'shady-links', 'install-script']
        high_patterns = ['obfuscation', 'serialize-environment']
        
        for issue in issues:
            rule_id = issue.get('rule_id', '').lower()
            if any(p in rule_id for p in critical_patterns):
                return 'CRITICAL'
        
        for issue in issues:
            rule_id = issue.get('rule_id', '').lower()
            if any(p in rule_id for p in high_patterns):
                return 'HIGH'
        
        return 'MEDIUM'
    
    def scan_package(self, package_name: str, package_version: str, ecosystem: str = None) -> Optional[MalwareDetection]:
        """
        Scan a package for malware
        
        Args:
            package_name: Name of the package
            package_version: Version of the package
            ecosystem: 'pypi', 'npm', or None (auto-detect)
            
        Returns:
            MalwareDetection result or None if scan failed
        """
        if not self._available:
            return None
        
        # Auto-detect ecosystem if not specified
        if ecosystem is None:
            ecosystem = self._detect_ecosystem(package_name)
        
        # Check cache
        if self.cache_dir:
            safe_name = self._sanitize_package_name(package_name)
            cache_file = self.cache_dir / f"guarddog_{ecosystem}_{safe_name}_{package_version}.json"
            if cache_file.exists():
                try:
                    with open(cache_file) as f:
                        cached = json.load(f)
                        self.cache_hits += 1  # Track cache hit
                        return MalwareDetection(**cached)
                except:
                    pass
        
        # Cache miss - will scan
        self.cache_misses += 1
        
        try:
            # Use guarddog from isolated venv
            paths = self._get_venv_paths()
            guarddog_cmd = str(paths['guarddog'])
            
            # Run GuardDog scan with ecosystem
            # Format: guarddog {pypi|npm} scan <package>
            package_spec = f"{package_name}@{package_version}" if ecosystem == 'npm' else f"{package_name}=={package_version}"
            
            result = subprocess.run(
                [guarddog_cmd, ecosystem, 'scan', package_spec, '--output-format', 'json'],
                capture_output=True,
                text=True,
                timeout=30
            )
            
            # Parse GuardDog JSON output
            # GuardDog 2.x format:
            # {
            #   "package==version": {
            #     "rule_name": [findings...] or 0 (integer when no findings)
            #   }
            # }
            try:
                guarddog_data = json.loads(result.stdout) if result.stdout.strip() else {}
            except (json.JSONDecodeError, ValueError):
                guarddog_data = {}
            
            # Extract detections from new GuardDog 2.x format
            detections = []
            risk_level = 'LOW'
            
            # Handle both old format (with 'issues' key) and new format (package as key)
            if guarddog_data:
                # Check for old format first
                if 'issues' in guarddog_data and isinstance(guarddog_data['issues'], list):
                    for issue in guarddog_data['issues']:
                        if not isinstance(issue, dict):
                            continue
                        severity = str(issue.get('severity', 'LOW')).upper()
                        detections.append({
                            'rule': issue.get('rule', 'unknown'),
                            'description': issue.get('description', ''),
                            'severity': severity,
                            'location': issue.get('location', ''),
                        })
                else:
                    # New GuardDog 2.x format: package names as top-level keys
                    for pkg_key, rules in guarddog_data.items():
                        # Skip non-dict entries (like 'errors', 'dependency_results')
                        if not isinstance(rules, dict):
                            continue
                        
                        for rule_name, findings in rules.items():
                            # CRITICAL FIX: GuardDog returns 0 (int) when no findings
                            # instead of an empty list. Skip integers.
                            if isinstance(findings, int):
                                continue
                            if not isinstance(findings, list):
                                continue
                            
                            for finding in findings:
                                if not isinstance(finding, dict):
                                    continue
                                severity = str(finding.get('severity', 'WARNING')).upper()
                                # Map GuardDog severities to our levels
                                if severity in ('ERROR', 'CRITICAL'):
                                    severity = 'CRITICAL'
                                elif severity in ('WARNING', 'HIGH'):
                                    severity = 'HIGH'
                                elif severity == 'INFO':
                                    severity = 'LOW'
                                else:
                                    severity = 'MEDIUM'
                                
                                detections.append({
                                    'rule': rule_name,
                                    'description': finding.get('message', finding.get('description', '')),
                                    'severity': severity,
                                    'location': finding.get('location', ''),
                                    'code': finding.get('code', ''),
                                })
            
            # Determine highest risk level from detections
            for det in detections:
                sev = det.get('severity', 'LOW')
                if sev == 'CRITICAL':
                    risk_level = 'CRITICAL'
                    break
                elif sev == 'HIGH' and risk_level not in ('CRITICAL',):
                    risk_level = 'HIGH'
                elif sev == 'MEDIUM' and risk_level not in ('CRITICAL', 'HIGH'):
                    risk_level = 'MEDIUM'
            
            detection = MalwareDetection(
                package_name=package_name,
                package_version=package_version,
                is_malicious=len(detections) > 0,
                risk_level=risk_level,
                detections=detections,
                confidence='HIGH' if len(detections) > 2 else 'MEDIUM'
            )
            
            # Cache result
            if self.cache_dir:
                safe_name = self._sanitize_package_name(package_name)
                cache_file = self.cache_dir / f"guarddog_{ecosystem}_{safe_name}_{package_version}.json"
                with open(cache_file, 'w') as f:
                    json.dump({
                        'package_name': detection.package_name,
                        'package_version': detection.package_version,
                        'is_malicious': detection.is_malicious,
                        'risk_level': detection.risk_level,
                        'detections': detection.detections,
                        'confidence': detection.confidence
                    }, f, indent=2)
            
            return detection
            
        except subprocess.TimeoutExpired:
            print(f"   ⚠️  GuardDog scan timeout for {package_name}")
            return None
        except Exception as e:
            print(f"   ⚠️  GuardDog scan failed for {package_name}: {e}")
            return None
    
    def scan_packages_from_sbom(self, sbom_file: Path) -> Dict[str, MalwareDetection]:
        """
        Scan all packages from SBOM
        
        Args:
            sbom_file: Path to SBOM JSON file (supports .json and .json.gz)
            
        Returns:
            Dict mapping package name → MalwareDetection
        """
        import gzip
        
        if not self._available:
            return {}
        
        results = {}
        
        try:
            # Handle both compressed and uncompressed SBOM files
            sbom_path = Path(sbom_file)
            
            # Try .json.gz first if .json doesn't exist
            if not sbom_path.exists() and sbom_path.with_suffix('.json.gz').exists():
                sbom_path = sbom_path.with_suffix('.json.gz')
            elif not sbom_path.exists() and str(sbom_path).endswith('.json'):
                gz_path = Path(str(sbom_path) + '.gz')
                if gz_path.exists():
                    sbom_path = gz_path
            
            if str(sbom_path).endswith('.gz'):
                with gzip.open(sbom_path, 'rt', encoding='utf-8') as f:
                    sbom = json.load(f)
            else:
                with open(sbom_path) as f:
                    sbom = json.load(f)
            
            packages = sbom.get('artifacts', [])
            total_packages = len(packages)
            
            # Track skipped packages by ecosystem (v2.9.61)
            skipped_by_ecosystem = {}  # ecosystem -> list of package names
            supported_ecosystems = {'npm', 'pypi', 'pip'}
            
            # Pre-filter packages by ecosystem to avoid unnecessary scan attempts
            scannable_packages = []
            for artifact in packages:
                name = artifact.get('name', '')
                version = artifact.get('version', '')
                pkg_type = artifact.get('type', '').lower()
                purl = artifact.get('purl', '')
                
                # Detect ecosystem from SBOM data
                ecosystem = None
                if pkg_type in supported_ecosystems:
                    ecosystem = 'npm' if pkg_type == 'npm' else 'pypi'
                elif 'npm' in purl or pkg_type == 'npm':
                    ecosystem = 'npm'
                elif 'pypi' in purl or pkg_type in ('pip', 'pypi', 'python'):
                    ecosystem = 'pypi'
                elif 'golang' in purl or pkg_type in ('go', 'golang', 'go-module'):
                    ecosystem = 'go'
                elif 'maven' in purl or pkg_type in ('java', 'maven', 'gradle'):
                    ecosystem = 'java'
                elif 'cargo' in purl or pkg_type == 'rust':
                    ecosystem = 'rust'
                else:
                    # Try auto-detection from name
                    ecosystem = self._detect_ecosystem(name)
                
                if ecosystem in supported_ecosystems or ecosystem in ('npm', 'pypi'):
                    scannable_packages.append((name, version, ecosystem if ecosystem != 'pip' else 'pypi'))
                else:
                    # Track skipped package
                    skip_reason = ecosystem or 'unknown'
                    if skip_reason not in skipped_by_ecosystem:
                        skipped_by_ecosystem[skip_reason] = []
                    skipped_by_ecosystem[skip_reason].append(name)
            
            scannable_count = len(scannable_packages)
            skipped_count = total_packages - scannable_count
            
            if packages:
                print(f"   🔍 GuardDog scanning {scannable_count} packages (npm/pip)...")
                if skipped_count > 0:
                    skip_details = ', '.join([f"{eco}: {len(pkgs)}" for eco, pkgs in sorted(skipped_by_ecosystem.items())])
                    print(f"      ⏭️  Skipped {skipped_count} unsupported packages ({skip_details})")
            
            scanned = 0
            errors = 0
            error_types = {}  # Track error categories for enterprise summary
            max_errors_shown = self.error_limit  # Configurable: -1 = unlimited
            
            for name, version, ecosystem in scannable_packages:
                try:
                    detection = self.scan_package(name, version, ecosystem)
                    if detection:
                        results[name] = detection
                        
                        if detection.is_malicious:
                            print(f"   🚨 MALWARE DETECTED: {name} {version} ({detection.risk_level})")
                except Exception as e:
                    errors += 1
                    # Categorize error for enterprise summary
                    error_str = str(e).lower()
                    if 'timeout' in error_str:
                        error_cat = 'timeout'
                    elif 'network' in error_str or 'connection' in error_str or 'socket' in error_str:
                        error_cat = 'network'
                    elif 'not found' in error_str or '404' in error_str or 'no such' in error_str:
                        error_cat = 'not_found'
                    elif 'permission' in error_str or 'access denied' in error_str:
                        error_cat = 'permission'
                    elif 'rate limit' in error_str or '429' in error_str:
                        error_cat = 'rate_limit'
                    else:
                        error_cat = 'other'
                    error_types[error_cat] = error_types.get(error_cat, 0) + 1
                    
                    # Show errors based on configurable limit (-1 = show all)
                    if max_errors_shown == -1 or errors <= max_errors_shown:
                        print(f"   ⚠️  GuardDog scan failed for {name}: {e}")
                    elif max_errors_shown > 0 and errors == max_errors_shown + 1:
                        print(f"   ⚠️  ... suppressing further error messages (will show summary)")
                        print(f"      💡 Set GUARDDOG_ERROR_LIMIT=-1 to see all errors")
                
                scanned += 1
                # Show progress every 100 packages or at end, with cache stats
                if scanned % 100 == 0 or scanned == scannable_count:
                    cache_str = f" [cache: {self.cache_hits} hits]" if self.cache_hits > 0 else ""
                    print(f"      Progress: [{scanned}/{scannable_count}] packages scanned...{cache_str}", end='\r' if scanned < scannable_count else '\n')
            
            clean_count = sum(1 for d in results.values() if not d.is_malicious)
            malicious_count = sum(1 for d in results.values() if d.is_malicious)
            
            if results:
                print(f"   ✓ GuardDog scan complete: {clean_count} clean, {malicious_count} malicious")
                # Show cache statistics for performance monitoring
                if self.cache_hits > 0 or self.cache_misses > 0:
                    total_scans = self.cache_hits + self.cache_misses
                    cache_pct = (self.cache_hits / total_scans * 100) if total_scans > 0 else 0
                    print(f"   💾 Cache: {self.cache_hits} hits, {self.cache_misses} scanned ({cache_pct:.1f}% from cache)")
            
            # Show error summary if many errors occurred (enterprise visibility)
            if max_errors_shown != -1 and errors > max_errors_shown:
                print(f"   ⚠️  Total scan errors: {errors}/{total_packages} packages failed")
                if error_types:
                    error_summary = [f"{cat}: {cnt}" for cat, cnt in sorted(error_types.items(), key=lambda x: -x[1])]
                    print(f"      Error breakdown: {', '.join(error_summary)}")
                    # Provide actionable guidance
                    if error_types.get('rate_limit', 0) > 5:
                        print(f"      💡 Tip: Rate limiting detected - try running with fewer workers or add delays")
                    if error_types.get('network', 0) > 10:
                        print(f"      💡 Tip: Network issues detected - check connectivity and firewall rules")
                    if error_types.get('not_found', 0) > 20:
                        print(f"      💡 Tip: Many packages not found - these may be private/internal packages")
            
            return results
            
        except Exception as e:
            print(f"   ⚠️  GuardDog SBOM scan failed: {e}")
            return {}

if __name__ == '__main__':
    # Test GuardDog scanner
    scanner = GuardDogScanner()
    
    if scanner.is_available():
        print("✓ GuardDog is available")
        
        # Test with a known clean package
        result = scanner.scan_package('requests', '2.31.0')
        if result:
            print(f"\nTest scan result:")
            print(f"  Package: {result.package_name} {result.package_version}")
            print(f"  Malicious: {result.is_malicious}")
            print(f"  Risk: {result.risk_level}")
    else:
        print("❌ GuardDog not available")
        print("   Install with: pip install guarddog")
