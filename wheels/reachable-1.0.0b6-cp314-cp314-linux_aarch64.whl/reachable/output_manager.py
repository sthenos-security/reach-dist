# Copyright © 2026 Sthenos Security. All rights reserved.

"""
Output Directory Manager

Handles organized output structure for parallel scans:
- Global cache (shared across all scans)
- Per-repo, per-branch folders
- Per-session unique directories
- Latest symlink for easy access

Structure:
    ~/.reachable/
    ├── cache/                              # Global shared cache
    │   ├── grype-db/                       # Vulnerability DB
    │   ├── nvd/                            # NVD CVE cache  
    │   └── osv/                            # OSV cache
    │
    ├── scans/
    │   └── {repo}/                         # e.g., owner-reponame
    │       └── {branch}/                   # e.g., main, feature-auth, pr-123
    │           ├── {session}/              # e.g., 20260104-193842-f7e8a2
    │           │   ├── reachable-report.json
    │           │   ├── dashboard.html
    │           │   ├── raw/
    │           │   └── logs/
    │           └── latest -> {session}/
    │
    └── config/
        └── settings.yaml

This allows:
- Multiple repos scanned in parallel
- Same repo, different branches scanned in parallel  
- Full history per branch
- Easy access via 'latest' symlink
"""

import os
import hashlib
import uuid
import subprocess
from pathlib import Path
from datetime import datetime
from typing import Optional, Tuple
import json

def get_reachable_home() -> Path:
    """
    Get REACHABLE home directory.
    
    Priority:
    1. REACHABLE_HOME environment variable
    2. ~/.reachable/
    """
    if 'REACHABLE_HOME' in os.environ:
        home = Path(os.environ['REACHABLE_HOME'])
    else:
        home = Path.home() / '.reachable'
    
    home.mkdir(parents=True, exist_ok=True)
    return home

def get_cache_dir() -> Path:
    """
    Get global cache directory (shared across all scans).
    
    Priority:
    1. REACHABLE_CACHE_DIR environment variable
    2. ~/.reachable/cache/
    """
    if 'REACHABLE_CACHE_DIR' in os.environ:
        cache = Path(os.environ['REACHABLE_CACHE_DIR'])
    else:
        cache = get_reachable_home() / 'cache'
    
    cache.mkdir(parents=True, exist_ok=True)
    return cache

def get_git_branch(repo_path: str) -> str:
    """
    Detect current git branch for a repository.
    
    Returns:
        Branch name (e.g., 'main', 'feature-auth', 'pr-123')
        Falls back to 'default' if not a git repo or detection fails
    """
    try:
        path = Path(repo_path).resolve()
        
        # Try git command
        result = subprocess.run(
            ['git', 'rev-parse', '--abbrev-ref', 'HEAD'],
            cwd=str(path),
            capture_output=True,
            text=True,
            timeout=5
        )
        if result.returncode == 0:
            branch = result.stdout.strip()
            if branch and branch != 'HEAD':
                return _sanitize_branch_name(branch)
        
        # If HEAD (detached), try to get commit short hash
        result = subprocess.run(
            ['git', 'rev-parse', '--short', 'HEAD'],
            cwd=str(path),
            capture_output=True,
            text=True,
            timeout=5
        )
        if result.returncode == 0:
            return f"detached-{result.stdout.strip()}"
            
    except (subprocess.TimeoutExpired, FileNotFoundError, OSError):
        pass
    
    return 'default'

def get_git_info(repo_path: str) -> dict:
    """
    Get git information for a repository.
    
    Returns dict with branch, commit, remote_url, is_dirty
    """
    info = {
        'branch': 'default',
        'commit': None,
        'commit_short': None,
        'remote_url': None,
        'is_dirty': False,
        'is_git_repo': False,
    }
    
    try:
        path = Path(repo_path).resolve()
        
        # Check if git repo
        result = subprocess.run(
            ['git', 'rev-parse', '--git-dir'],
            cwd=str(path),
            capture_output=True,
            timeout=5
        )
        if result.returncode != 0:
            return info
        
        info['is_git_repo'] = True
        
        # Get branch
        result = subprocess.run(
            ['git', 'rev-parse', '--abbrev-ref', 'HEAD'],
            cwd=str(path),
            capture_output=True,
            text=True,
            timeout=5
        )
        if result.returncode == 0:
            branch = result.stdout.strip()
            info['branch'] = _sanitize_branch_name(branch) if branch != 'HEAD' else 'detached'
        
        # Get commit hash
        result = subprocess.run(
            ['git', 'rev-parse', 'HEAD'],
            cwd=str(path),
            capture_output=True,
            text=True,
            timeout=5
        )
        if result.returncode == 0:
            info['commit'] = result.stdout.strip()
            info['commit_short'] = info['commit'][:8]
        
        # Get remote URL
        result = subprocess.run(
            ['git', 'remote', 'get-url', 'origin'],
            cwd=str(path),
            capture_output=True,
            text=True,
            timeout=5
        )
        if result.returncode == 0:
            info['remote_url'] = result.stdout.strip()
        
        # Check if dirty
        result = subprocess.run(
            ['git', 'status', '--porcelain'],
            cwd=str(path),
            capture_output=True,
            text=True,
            timeout=10
        )
        if result.returncode == 0:
            info['is_dirty'] = bool(result.stdout.strip())
            
    except (subprocess.TimeoutExpired, FileNotFoundError, OSError):
        pass
    
    return info

def _sanitize_branch_name(branch: str) -> str:
    """Sanitize branch name for filesystem use."""
    # Replace problematic chars with dash
    safe = ''.join(c if c.isalnum() or c in '-_.' else '-' for c in branch)
    # Collapse multiple dashes
    while '--' in safe:
        safe = safe.replace('--', '-')
    # Trim and limit length
    return safe.strip('-')[:64]

def get_repo_slug(repo_path: str) -> str:
    """
    Generate a unique, human-readable slug for a repository.
    
    Examples:
        /home/user/projects/nexee-dev -> nexee-dev-a1b2c3d4
        github:owner/repo -> owner-repo
        https://github.com/owner/repo -> owner-repo
    """
    # Handle GitHub URLs
    if 'github.com' in repo_path or repo_path.startswith('github:'):
        # Extract owner/repo
        clean = repo_path.replace('github:', '').replace('https://github.com/', '')
        clean = clean.rstrip('/').rstrip('.git')
        parts = clean.split('/')
        if len(parts) >= 2:
            return f"{parts[-2]}-{parts[-1]}"
        return parts[-1]
    
    # For local paths: name + short hash of absolute path for uniqueness
    path = Path(repo_path).resolve()
    name = path.name
    
    # Sanitize name (remove special chars)
    safe_name = ''.join(c if c.isalnum() or c in '-_' else '-' for c in name)
    safe_name = safe_name.strip('-')[:32]  # Limit length
    
    # Add short hash of full path for uniqueness
    path_hash = hashlib.sha256(str(path).encode()).hexdigest()[:8]
    
    return f"{safe_name}-{path_hash}"

def get_session_id() -> str:
    """
    Generate unique session ID for a scan run.
    
    Format: YYYYMMDD-HHMMSS-xxxxxx
    Example: 20260104-193842-f7e8a2
    """
    timestamp = datetime.now().strftime('%Y%m%d-%H%M%S')
    unique = uuid.uuid4().hex[:6]
    return f"{timestamp}-{unique}"

def setup_scan_directory(
    repo_path: str,
    output_override: Optional[Path] = None,
    branch_override: Optional[str] = None
) -> Tuple[Path, str, str, str]:
    """
    Set up output directory for a scan session.
    
    Args:
        repo_path: Path to repository being scanned
        output_override: If provided, use this path directly (legacy mode)
        branch_override: If provided, use this instead of auto-detecting
        
    Returns:
        Tuple of (session_dir, repo_slug, branch, session_id)
    """
    repo_slug = get_repo_slug(repo_path)
    session_id = get_session_id()
    
    # Get branch info
    if branch_override:
        branch = _sanitize_branch_name(branch_override)
    else:
        branch = get_git_branch(repo_path)
    
    if output_override:
        # User explicitly specified output path - respect it
        # But still create organized structure under it
        if output_override.suffix:
            # It's a file path like report.json
            base_dir = output_override.parent
        else:
            # It's a directory
            base_dir = output_override
        
        # Create session subdirectory even with override
        session_dir = base_dir / session_id
        session_dir.mkdir(parents=True, exist_ok=True)
        
        # Create latest symlink
        latest_link = base_dir / 'latest'
        _update_symlink(latest_link, session_id)
        
        return session_dir, repo_slug, branch, session_id
    
    # Default: organize under ~/.reachable/scans/{repo}/{branch}/{session}/
    home = get_reachable_home()
    repo_dir = home / 'scans' / repo_slug
    branch_dir = repo_dir / branch
    session_dir = branch_dir / session_id
    
    session_dir.mkdir(parents=True, exist_ok=True)
    
    # Create subdirectories
    (session_dir / 'raw').mkdir(exist_ok=True)
    (session_dir / 'logs').mkdir(exist_ok=True)
    
    # Update 'latest' symlink at branch level
    latest_link = branch_dir / 'latest'
    _update_symlink(latest_link, session_id)
    
    # Get full git info for metadata
    git_info = get_git_info(repo_path)
    
    # Write session metadata
    metadata = {
        'session_id': session_id,
        'repo_slug': repo_slug,
        'branch': branch,
        'repo_path': str(Path(repo_path).resolve()),
        'started_at': datetime.now().isoformat(),
        'reachable_home': str(home),
        'git': git_info,
    }
    with open(session_dir / '.session.json', 'w') as f:
        json.dump(metadata, f, indent=2)
    
    return session_dir, repo_slug, branch, session_id

def _update_symlink(link_path: Path, target: str):
    """Safely update a symlink."""
    try:
        if link_path.is_symlink():
            link_path.unlink()
        elif link_path.exists():
            # It's a real file/dir, don't overwrite
            return
        link_path.symlink_to(target)
    except (OSError, PermissionError):
        # Symlinks may fail on some systems, ignore
        pass

def get_repo_scans(repo_path: str, branch: Optional[str] = None) -> list:
    """
    List all scan sessions for a repository (optionally filtered by branch).
    
    Returns list of (session_id, session_dir, metadata) tuples,
    sorted by most recent first.
    """
    home = get_reachable_home()
    repo_slug = get_repo_slug(repo_path)
    repo_dir = home / 'scans' / repo_slug
    
    if not repo_dir.exists():
        return []
    
    sessions = []
    
    # If branch specified, look only in that branch folder
    if branch:
        branch_dir = repo_dir / _sanitize_branch_name(branch)
        if branch_dir.exists():
            for session_dir in branch_dir.iterdir():
                if session_dir.is_dir() and session_dir.name != 'latest':
                    metadata = _load_session_metadata(session_dir)
                    sessions.append((session_dir.name, session_dir, metadata))
    else:
        # Look in all branches
        for branch_dir in repo_dir.iterdir():
            if branch_dir.is_dir():
                for session_dir in branch_dir.iterdir():
                    if session_dir.is_dir() and session_dir.name != 'latest':
                        metadata = _load_session_metadata(session_dir)
                        sessions.append((session_dir.name, session_dir, metadata))
    
    # Sort by session_id (which starts with timestamp)
    sessions.sort(key=lambda x: x[0], reverse=True)
    return sessions

def get_repo_branches(repo_path: str) -> list:
    """
    List all branches that have been scanned for a repository.
    
    Returns list of branch names.
    """
    home = get_reachable_home()
    repo_slug = get_repo_slug(repo_path)
    repo_dir = home / 'scans' / repo_slug
    
    if not repo_dir.exists():
        return []
    
    branches = []
    for branch_dir in repo_dir.iterdir():
        if branch_dir.is_dir():
            # Check if it has any sessions (not just 'latest' symlink)
            has_sessions = any(
                d.is_dir() and d.name != 'latest' 
                for d in branch_dir.iterdir()
            )
            if has_sessions:
                branches.append(branch_dir.name)
    
    return sorted(branches)

def _load_session_metadata(session_dir: Path) -> dict:
    """Load session metadata from .session.json."""
    metadata_file = session_dir / '.session.json'
    if metadata_file.exists():
        try:
            with open(metadata_file) as f:
                return json.load(f)
        except:
            pass
    return {}

def get_latest_scan(repo_path: str, branch: Optional[str] = None) -> Optional[Path]:
    """Get the latest scan directory for a repository/branch."""
    home = get_reachable_home()
    repo_slug = get_repo_slug(repo_path)
    
    if branch:
        latest = home / 'scans' / repo_slug / _sanitize_branch_name(branch) / 'latest'
    else:
        # Try to find current branch
        current_branch = get_git_branch(repo_path)
        latest = home / 'scans' / repo_slug / current_branch / 'latest'
    
    if latest.exists():
        return latest.resolve()
    return None

def cleanup_old_scans(repo_path: str, branch: Optional[str] = None, keep: int = 10):
    """
    Remove old scan sessions, keeping the N most recent.
    
    Args:
        repo_path: Repository to clean up
        branch: Branch to clean up (None = all branches)
        keep: Number of recent scans to keep per branch (default: 10)
    """
    home = get_reachable_home()
    repo_slug = get_repo_slug(repo_path)
    repo_dir = home / 'scans' / repo_slug
    
    if not repo_dir.exists():
        return
    
    import shutil
    
    branches_to_clean = []
    if branch:
        branch_dir = repo_dir / _sanitize_branch_name(branch)
        if branch_dir.exists():
            branches_to_clean.append(branch_dir)
    else:
        branches_to_clean = [d for d in repo_dir.iterdir() if d.is_dir()]
    
    for branch_dir in branches_to_clean:
        sessions = []
        for session_dir in branch_dir.iterdir():
            if session_dir.is_dir() and session_dir.name != 'latest':
                sessions.append((session_dir.name, session_dir))
        
        # Sort by timestamp (session_id starts with timestamp)
        sessions.sort(key=lambda x: x[0], reverse=True)
        
        # Remove old sessions
        for session_id, session_dir in sessions[keep:]:
            try:
                shutil.rmtree(session_dir)
            except (OSError, PermissionError):
                pass

class ScanOutputManager:
    """
    Manages output for a single scan session.
    
    Usage:
        mgr = ScanOutputManager(repo_path)
        report_path = mgr.get_report_path()
        dashboard_path = mgr.get_dashboard_path()
        mgr.finalize()
        
    Parallel scans:
        # Terminal 1: main branch
        mgr1 = ScanOutputManager('/path/to/repo')  # auto-detects 'main'
        
        # Terminal 2: feature branch (same repo, different checkout)
        mgr2 = ScanOutputManager('/path/to/repo-feature', branch_override='feature-x')
        
        # Both write to separate directories:
        # ~/.reachable/scans/repo-abc123/main/20260104-.../
        # ~/.reachable/scans/repo-abc123/feature-x/20260104-.../
    """
    
    def __init__(
        self, 
        repo_path: str, 
        output_override: Optional[Path] = None,
        branch_override: Optional[str] = None
    ):
        self.repo_path = repo_path
        self.session_dir, self.repo_slug, self.branch, self.session_id = setup_scan_directory(
            repo_path, output_override, branch_override
        )
        self.raw_dir = self.session_dir / 'raw'
        self.logs_dir = self.session_dir / 'logs'
        
        # Ensure directories exist
        self.raw_dir.mkdir(exist_ok=True)
        self.logs_dir.mkdir(exist_ok=True)
        
        # Store git info
        self._git_info = get_git_info(repo_path)
    
    @property
    def output_dir(self) -> Path:
        """Main output directory for this session."""
        return self.session_dir
    
    @property
    def git_info(self) -> dict:
        """Git information for the scanned repo."""
        return self._git_info
    
    def get_report_path(self, name: str = 'reachable-report.json') -> Path:
        """Get path for main report file."""
        return self.session_dir / name
    
    def get_dashboard_path(self) -> Path:
        """Get path for dashboard HTML."""
        return self.session_dir / 'dashboard.html'
    
    def get_raw_path(self, name: str) -> Path:
        """Get path for raw output file (sbom.json, cves.json, etc.)."""
        return self.raw_dir / name
    
    def get_log_path(self, name: str = 'scan.log') -> Path:
        """Get path for log file."""
        return self.logs_dir / name
    
    def get_cache_path(self, subdir: str) -> Path:
        """Get path in global cache directory."""
        cache = get_cache_dir() / subdir
        cache.mkdir(parents=True, exist_ok=True)
        return cache
    
    def finalize(self, status: str = 'complete', summary: dict = None):
        """
        Finalize the scan session.
        
        Updates session metadata with completion info.
        """
        metadata_file = self.session_dir / '.session.json'
        metadata = {}
        
        if metadata_file.exists():
            try:
                with open(metadata_file) as f:
                    metadata = json.load(f)
            except:
                pass
        
        metadata['completed_at'] = datetime.now().isoformat()
        metadata['status'] = status
        if summary:
            metadata['summary'] = summary
        
        with open(metadata_file, 'w') as f:
            json.dump(metadata, f, indent=2)
    
    def __str__(self) -> str:
        return f"ScanOutput({self.repo_slug}/{self.branch}/{self.session_id})"
    
    def __repr__(self) -> str:
        return f"ScanOutputManager(repo={self.repo_slug}, branch={self.branch}, session={self.session_id})"

class OutputManager:
    """
    Backwards-compatible alias for ScanOutputManager.
    
    This class provides the legacy interface expected by cli.py while
    delegating to the new ScanOutputManager implementation.
    """
    
    def __init__(self, repo_path: Path, custom_output: Optional[Path] = None):
        self._mgr = ScanOutputManager(
            repo_path=str(repo_path),
            output_override=custom_output
        )
        self.repo_path = repo_path
        self.custom_output = custom_output
    
    @property
    def scan_dir(self) -> Path:
        """Main output directory for this scan session."""
        return self._mgr.session_dir
    
    @property
    def timestamp(self) -> str:
        """Session timestamp."""
        return self._mgr.session_id
    
    @property
    def repo_name(self) -> str:
        """Repository name/slug."""
        return self._mgr.repo_slug
    
    @property
    def branch(self) -> str:
        """Git branch."""
        return self._mgr.branch
    
    @property
    def session_id(self) -> str:
        """Session ID."""
        return self._mgr.session_id
    
    @property
    def use_global(self) -> bool:
        """Whether using global ~/.reachable directory (vs custom output)."""
        return self.custom_output is None
    
    @property
    def git_info(self) -> dict:
        """Git information dict."""
        return self._mgr.git_info
    
    @property
    def repo_slug(self) -> str:
        """Repository slug (alias for repo_name)."""
        return self._mgr.repo_slug
    
    @property
    def session_dir(self) -> Path:
        """Session directory (alias for scan_dir)."""
        return self._mgr.session_dir
    
    @property
    def output_dir(self) -> Path:
        """Output directory (alias for scan_dir/session_dir)."""
        return self._mgr.session_dir
    
    @property
    def raw_dir(self) -> Path:
        """Raw output directory for scanner artifacts."""
        raw = self._mgr.session_dir / 'raw'
        raw.mkdir(parents=True, exist_ok=True)
        return raw
    
    @property
    def logs_dir(self) -> Path:
        """Logs directory."""
        logs = self._mgr.session_dir / 'logs'
        logs.mkdir(parents=True, exist_ok=True)
        return logs
    
    def save_scan_plan(self, plan: dict):
        """Save scan plan to session directory."""
        plan_file = self._mgr.session_dir / 'scan-plan.json'
        with open(plan_file, 'w') as f:
            json.dump(plan, f, indent=2)
    
    def create_latest_symlink(self):
        """Create/update latest symlink (already done in ScanOutputManager)."""
        # Already created by ScanOutputManager, but refresh it just in case
        latest = self._mgr.session_dir.parent / 'latest'
        _update_symlink(latest, self._mgr.session_id)
    
    def get_report_path(self, name: str = 'reachable-report.json') -> Path:
        return self._mgr.get_report_path(name)
    
    def get_dashboard_path(self) -> Path:
        return self._mgr.get_dashboard_path()
    
    def get_raw_path(self, name: str) -> Path:
        return self._mgr.get_raw_path(name)
    
    def get_log_path(self, name: str = 'scan.log') -> Path:
        return self._mgr.get_log_path(name)
    
    def finalize(self, status: str = 'complete', summary: dict = None):
        self._mgr.finalize(status, summary)

# Convenience functions for CLI
def print_scan_location(mgr: ScanOutputManager):
    """Print scan output location info."""
    print(f"📁 Output: {mgr.session_dir}")
    print(f"   Repo:    {mgr.repo_slug}")
    print(f"   Branch:  {mgr.branch}")
    print(f"   Session: {mgr.session_id}")
    if mgr.git_info.get('commit_short'):
        print(f"   Commit:  {mgr.git_info['commit_short']}")
    print(f"   Latest:  {mgr.session_dir.parent / 'latest'}")

def list_all_repos() -> list:
    """
    List all repositories that have been scanned.
    
    Returns list of (repo_slug, repo_dir, branches) tuples.
    """
    home = get_reachable_home()
    scans_dir = home / 'scans'
    
    if not scans_dir.exists():
        return []
    
    repos = []
    for repo_dir in scans_dir.iterdir():
        if repo_dir.is_dir():
            branches = [
                d.name for d in repo_dir.iterdir() 
                if d.is_dir() and any(
                    s.is_dir() and s.name != 'latest' 
                    for s in d.iterdir()
                )
            ]
            if branches:
                repos.append((repo_dir.name, repo_dir, sorted(branches)))
    
    return sorted(repos, key=lambda x: x[0])

def print_scan_history(repo_path: Optional[str] = None, branch: Optional[str] = None, limit: int = 10):
    """
    Print scan history for a repo or all repos.
    
    Args:
        repo_path: Repository path (None = all repos)
        branch: Branch filter (None = all branches)
        limit: Max sessions to show per branch
    """
    home = get_reachable_home()
    
    if repo_path:
        repos = [(get_repo_slug(repo_path), home / 'scans' / get_repo_slug(repo_path), None)]
    else:
        repos = list_all_repos()
    
    if not repos:
        print("No scan history found.")
        print(f"Scan directory: {home / 'scans'}")
        return
    
    print(f"📊 REACHABLE Scan History")
    print(f"   Location: {home / 'scans'}")
    print()
    
    for repo_slug, repo_dir, branches in repos:
        if not repo_dir.exists():
            continue
            
        print(f"📁 {repo_slug}/")
        
        # Get branches if not provided
        if branches is None:
            branches = [
                d.name for d in repo_dir.iterdir() 
                if d.is_dir()
            ]
        
        if branch:
            branches = [b for b in branches if b == branch]
        
        for b in sorted(branches):
            branch_dir = repo_dir / b
            if not branch_dir.exists():
                continue
                
            sessions = []
            for session_dir in branch_dir.iterdir():
                if session_dir.is_dir() and session_dir.name != 'latest':
                    metadata = _load_session_metadata(session_dir)
                    sessions.append((session_dir.name, session_dir, metadata))
            
            sessions.sort(key=lambda x: x[0], reverse=True)
            
            print(f"   └── {b}/ ({len(sessions)} scans)")
            
            for session_id, session_dir, metadata in sessions[:limit]:
                status = metadata.get('status', 'unknown')
                status_icon = '✅' if status == 'complete' else '⏳' if status == 'running' else '❓'
                commit = metadata.get('git', {}).get('commit_short', '')
                commit_str = f" @ {commit}" if commit else ""
                
                # Parse timestamp from session_id
                try:
                    ts = session_id.split('-')
                    date_str = f"{ts[0][:4]}-{ts[0][4:6]}-{ts[0][6:8]} {ts[1][:2]}:{ts[1][2:4]}"
                except:
                    date_str = session_id
                
                print(f"       {status_icon} {date_str}{commit_str}")
            
            if len(sessions) > limit:
                print(f"       ... and {len(sessions) - limit} more")
        
        print()

# CLI entry point for history command
def cli_history():
    """CLI command to show scan history."""
    import argparse
    parser = argparse.ArgumentParser(description='Show REACHABLE scan history')
    parser.add_argument('repo', nargs='?', help='Repository path (optional)')
    parser.add_argument('-b', '--branch', help='Filter by branch')
    parser.add_argument('-n', '--limit', type=int, default=5, help='Max sessions per branch')
    parser.add_argument('--home', action='store_true', help='Show REACHABLE_HOME path')
    
    args = parser.parse_args()
    
    if args.home:
        print(get_reachable_home())
        return
    
    print_scan_history(args.repo, args.branch, args.limit)

if __name__ == '__main__':
    cli_history()
