# Copyright © 2026 Sthenos Security. All rights reserved.

"""
REACHABLE Core - Pure Python Implementation
Fallback for environments without Cython compilation.

This module provides the same interface as reachability_core.pyx
but implemented in pure Python for compatibility.
"""

from typing import Dict, Set, List, Tuple, Optional

# Secret detection patterns
SECRET_PATTERNS = [
    'hardcoded', 'secret', 'password', 'api-key', 'api_key', 'apikey',
    'token', 'credential', 'private-key', 'private_key', 'aws-', 'gcp-',
    'azure-', 'slack-', 'github-token', 'jwt', 'bearer', 'generic-',
    'detected-', 'exposed-'
]

def compute_reachability_fast(call_graph: Dict[str, Set[str]], 
                              entry_points: Set[str]) -> Dict:
    """
    Compute reachable functions from entry points using BFS.
    
    Args:
        call_graph: Dict mapping function -> set of called functions
        entry_points: Set of entry point function names
        
    Returns:
        Dict with 'reachable' set and 'unreachable' set
    """
    reachable = set()
    visited = set()
    queue = list(entry_points)
    
    while queue:
        current = queue.pop(0)
        if current in visited:
            continue
        visited.add(current)
        reachable.add(current)
        
        # Get callees for this function
        callees = call_graph.get(current, set())
        for callee in callees:
            if callee not in visited:
                queue.append(callee)
    
    # Compute unreachable as all functions minus reachable
    all_functions = set(call_graph.keys())
    for callees in call_graph.values():
        all_functions.update(callees)
    
    unreachable = all_functions - reachable
    
    return {
        'reachable': reachable,
        'unreachable': unreachable,
        'total': len(all_functions),
        'reachable_count': len(reachable),
        'unreachable_count': len(unreachable)
    }

def traverse_call_graph(call_graph: Dict[str, Set[str]], 
                        start_func: str, 
                        max_depth: int = 10) -> List[List[str]]:
    """
    Traverse call graph from a starting function and return call paths.
    
    Args:
        call_graph: Dict mapping function -> set of called functions
        start_func: Starting function name
        max_depth: Maximum traversal depth
        
    Returns:
        List of call paths (each path is a list of function names)
    """
    paths = []
    stack = [([start_func], 0)]  # (path, depth)
    
    while stack:
        current_path, depth = stack.pop()
        
        if depth >= max_depth:
            paths.append(current_path)
            continue
            
        last_func = current_path[-1]
        callees = call_graph.get(last_func, set())
        
        if not callees:
            paths.append(current_path)
            continue
            
        for callee in callees:
            if callee not in current_path:  # Avoid cycles
                new_path = current_path + [callee]
                stack.append((new_path, depth + 1))
    
    return paths

def calculate_risk_score(severity_breakdown: Dict, 
                        kev_count: int = 0,
                        malware_count: int = 0, 
                        phantom_deps: int = 0,
                        no_fix_count: int = 0) -> Dict:
    """
    Calculate risk score using weighted formula.
    
    Args:
        severity_breakdown: Dict with critical/high/medium/low -> {live, dead}
        kev_count: Number of CISA KEV CVEs
        malware_count: Number of malicious packages
        phantom_deps: Number of phantom dependencies
        no_fix_count: Number of CVEs with no fix
        
    Returns:
        Dict with score, level, components breakdown
    """
    score = 0
    components = {}
    
    # Critical
    crit_live = severity_breakdown.get('critical', {}).get('live', 0)
    crit_dead = severity_breakdown.get('critical', {}).get('dead', 0)
    crit_score = crit_live * 250 + crit_dead * 25
    score += crit_score
    components['critical'] = {'live': crit_live, 'dead': crit_dead, 'score': crit_score}
    
    # High
    high_live = severity_breakdown.get('high', {}).get('live', 0)
    high_dead = severity_breakdown.get('high', {}).get('dead', 0)
    high_score = high_live * 100 + high_dead * 10
    score += high_score
    components['high'] = {'live': high_live, 'dead': high_dead, 'score': high_score}
    
    # Medium
    med_live = severity_breakdown.get('medium', {}).get('live', 0)
    med_dead = severity_breakdown.get('medium', {}).get('dead', 0)
    med_score = med_live * 40 + med_dead * 4
    score += med_score
    components['medium'] = {'live': med_live, 'dead': med_dead, 'score': med_score}
    
    # Low
    low_live = severity_breakdown.get('low', {}).get('live', 0)
    low_dead = severity_breakdown.get('low', {}).get('dead', 0)
    low_score = low_live * 10
    score += low_score
    components['low'] = {'live': low_live, 'dead': low_dead, 'score': low_score}
    
    # Amplifiers
    kev_score = kev_count * 100
    malware_score = malware_count * 500
    phantom_score = phantom_deps * 50
    nofix_score = no_fix_count * 30
    
    score += kev_score + malware_score + phantom_score + nofix_score
    
    components['kev'] = {'count': kev_count, 'score': kev_score}
    components['malware'] = {'count': malware_count, 'score': malware_score}
    components['phantom'] = {'count': phantom_deps, 'score': phantom_score}
    components['no_fix'] = {'count': no_fix_count, 'score': nofix_score}
    
    # Determine risk level
    if score >= 800 or crit_live > 0 or malware_count > 0:
        level = "CRITICAL"
    elif score >= 400 or high_live > 2:
        level = "HIGH"
    elif score >= 150 or high_live > 0:
        level = "MEDIUM"
    else:
        level = "LOW"
    
    return {
        'score': score,
        'max_score': 1000,
        'normalized': min(10.0, score / 100.0),
        'level': level,
        'components': components
    }

def match_secret_patterns(rule_id: str) -> bool:
    """
    Check if a rule ID matches secret detection patterns.
    
    Args:
        rule_id: The rule ID to check
        
    Returns:
        True if matches secret pattern, False for SAST finding
    """
    rule_lower = rule_id.lower()
    
    for pattern in SECRET_PATTERNS:
        if pattern in rule_lower:
            return True
    return False

def classify_findings(findings: List[Dict]) -> Dict:
    """
    Classify security findings into secrets vs SAST.
    
    Args:
        findings: List of finding dicts with rule_id, message, etc.
        
    Returns:
        Dict with 'secrets' and 'sast' lists
    """
    secrets = []
    sast = []
    
    for finding in findings:
        rule_id = finding.get('rule_id', '') or ''
        
        if match_secret_patterns(rule_id):
            finding['is_actual_secret'] = True
            finding['finding_type'] = 'SECRET'
            secrets.append(finding)
        else:
            # Check message for secret indicators
            msg_lower = (finding.get('message', '') or '').lower()
            if any(kw in msg_lower for kw in ['hardcoded password', 'api key', 'credential', 'private key']):
                finding['is_actual_secret'] = True
                finding['finding_type'] = 'SECRET'
                secrets.append(finding)
            else:
                finding['is_actual_secret'] = False
                finding['finding_type'] = 'SAST'
                sast.append(finding)
    
    return {
        'secrets': secrets,
        'sast': sast,
        'secrets_count': len(secrets),
        'sast_count': len(sast)
    }

def compute_workload_reduction(total_cves: int, unreachable_cves: int) -> Dict:
    """
    Compute workload reduction metrics.
    
    Args:
        total_cves: Total number of CVEs found
        unreachable_cves: Number of unreachable CVEs
        
    Returns:
        Dict with reduction metrics
    """
    reduction_pct = 0.0
    hours_per_cve = 10.5  # Industry benchmark
    hourly_rate = 100.0
    
    if total_cves > 0:
        reduction_pct = (unreachable_cves / total_cves) * 100.0
    
    hours_saved = unreachable_cves * hours_per_cve
    cost_savings = hours_saved * hourly_rate
    
    return {
        'reduction_percentage': round(reduction_pct, 1),
        'issues_eliminated': unreachable_cves,
        'hours_saved': round(hours_saved, 1),
        'cost_savings': round(cost_savings, 2),
        'benchmark_source': 'Ponemon Institute'
    }

# =============================================================================
# CISA/NIST SECRET SEVERITY MATRIX (v2.9.37)
# Based on CISA SSVC and NIST SP 800-204D
# =============================================================================

# Scenario constants
SCENARIO_TOXIC_COMBINATION = 'TOXIC_COMBINATION'  # Active + Reachable = CRITICAL
SCENARIO_EXPOSED_ASSET = 'EXPOSED_ASSET'          # Active + Unreachable = HIGH
SCENARIO_DEAD_LINK = 'DEAD_LINK'                  # Inactive + Reachable = MEDIUM
SCENARIO_SECURITY_DEBT = 'SECURITY_DEBT'          # Inactive + Unreachable = LOW

# Action categories
ACTION_ACT = 'ACT'           # Immediate action - active breach
ACTION_ATTEND = 'ATTEND'     # Attack chain risk - rotate priority
ACTION_TRACK = 'TRACK'       # Compliance fix only

def classify_secret_severity(is_active: bool, is_reachable: bool) -> Dict:
    """
    Classify secret severity using CISA/NIST two-dimensional model.
    
    Based on:
    - CISA SSVC (Stakeholder-Specific Vulnerability Categorization)
    - NIST SP 800-204D (2024/2025)
    
    Scenarios:
    - TOXIC_COMBINATION: Active + Reachable = CRITICAL (ACT)
    - EXPOSED_ASSET: Active + Unreachable = HIGH (ATTEND)
    - DEAD_LINK: Inactive + Reachable = MEDIUM (TRACK)
    - SECURITY_DEBT: Inactive + Unreachable = LOW (TRACK)
    
    Args:
        is_active: Whether the secret is valid/active at provider
        is_reachable: Whether secret is in code path (main/prod)
        
    Returns:
        Dict with scenario, severity, action, timeline, and guidance
    """
    if is_active and is_reachable:
        # TOXIC COMBINATION: Active + In-Path = CRITICAL
        return {
            'scenario': SCENARIO_TOXIC_COMBINATION,
            'severity': 'CRITICAL',
            'action': ACTION_ACT,
            'action_label': '🚨 ACT IMMEDIATELY',
            'timeline': '24-48 hours',
            'breach_status': 'ACTIVE - Lock and key both exposed',
            'risk_weight': 100,
            'is_active': is_active,
            'is_reachable': is_reachable,
        }
    elif is_active and not is_reachable:
        # EXPOSED ASSET: Active + Off-Path = HIGH
        return {
            'scenario': SCENARIO_EXPOSED_ASSET,
            'severity': 'HIGH',
            'action': ACTION_ATTEND,
            'action_label': '⚠️ ATTEND',
            'timeline': '7 days (current sprint)',
            'breach_status': 'POTENTIAL - Key valid and discoverable in history',
            'risk_weight': 75,
            'is_active': is_active,
            'is_reachable': is_reachable,
        }
    elif not is_active and is_reachable:
        # DEAD LINK: Inactive + In-Path = MEDIUM
        return {
            'scenario': SCENARIO_DEAD_LINK,
            'severity': 'MEDIUM',
            'action': ACTION_TRACK,
            'action_label': '📋 TRACK',
            'timeline': '30 days (next sprint)',
            'breach_status': 'NONE - Secret revoked at provider',
            'risk_weight': 25,
            'is_active': is_active,
            'is_reachable': is_reachable,
        }
    else:
        # SECURITY DEBT: Inactive + Off-Path = LOW
        return {
            'scenario': SCENARIO_SECURITY_DEBT,
            'severity': 'LOW',
            'action': ACTION_TRACK,
            'action_label': '📝 TRACK',
            'timeline': '90 days (address when convenient)',
            'breach_status': 'NONE - Secret dead AND not in code path',
            'risk_weight': 10,
            'is_active': is_active,
            'is_reachable': is_reachable,
        }

def get_secret_remediation(scenario: str, secret_type: str = 'credential') -> Dict:
    """
    Get remediation steps for a secret based on scenario.
    
    Args:
        scenario: One of TOXIC_COMBINATION, EXPOSED_ASSET, DEAD_LINK, SECURITY_DEBT
        secret_type: Type of secret (e.g., 'AWS key', 'API token')
        
    Returns:
        Dict with action, steps, and compliance notes
    """
    if scenario == SCENARIO_TOXIC_COMBINATION:
        return {
            'scenario': scenario,
            'steps': [
                f"1. REVOKE: Kill this {secret_type} at the provider IMMEDIATELY",
                "2. ROTATE: Generate new credentials into a secrets manager",
                "3. AUDIT: Review provider access logs for unauthorized use",
                "4. SECURE: Ensure new secret has proper access controls"
            ],
            'why': "Federal auditors treat this as an active breach - lock and key both exposed",
            'vex_status': "affected",
            'compliance_refs': ['CISA BOD 19-02', 'NIST SP 800-204D', 'SOC2 CC6.1', 'PCI-DSS 8.3.1'],
        }
    elif scenario == SCENARIO_EXPOSED_ASSET:
        return {
            'scenario': scenario,
            'steps': [
                f"1. ROTATE: Generate new {secret_type} FIRST (makes old key useless)",
                "2. VERIFY: Confirm old secret no longer grants access",
                "3. SCRUB: Remove from git history using BFG (secondary priority)",
                "4. MONITOR: Set alerts for access attempts with old credential"
            ],
            'why': "Live key in git history - attackers find these in seconds via automated scanning",
            'vex_status': "affected",
            'compliance_refs': ['NIST SSDF PW.1.1', 'SOC2 CC6.7', 'CIS Control 16'],
        }
    elif scenario == SCENARIO_DEAD_LINK:
        return {
            'scenario': scenario,
            'steps': [
                "1. VERIFY: Confirm secret is truly revoked at provider",
                "2. DOCUMENT: Log revocation evidence for audit trail",
                "3. REMOVE: Delete hardcoded value from source code",
                "4. REFACTOR: Replace with env var or secrets manager reference"
            ],
            'why': "Secret is dead - fix for audit compliance, not active threat",
            'vex_status': "not_affected",
            'compliance_refs': ['SOC2 CC6.1 (cleanup)', 'FedRAMP AU-6'],
        }
    else:  # SECURITY_DEBT
        return {
            'scenario': scenario,
            'steps': [
                "1. VERIFY: Confirm revocation status at provider",
                "2. DOCUMENT: Record revocation evidence for auditors",
                "3. BACKLOG: Schedule git history cleanup for maintenance",
                "4. SCRUB: Use BFG Repo-Cleaner when convenient"
            ],
            'why': "Dead secret in history only - lowest priority, defer acceptable",
            'vex_status': "not_affected",
            'compliance_refs': ['NIST SP 800-204D (exploitability prioritization)'],
        }

# =============================================================================
# MALWARE SANDBOX SCORING (MALWARE-003) - v2.9.37
# =============================================================================

def calculate_sandbox_risk(sandbox_results: Optional[Dict]) -> Dict:
    """
    Calculate risk contribution from malware sandbox analysis (MALWARE-003).
    
    Sandbox detects behavioral indicators:
    - Honeypot credential access (AWS, SSH, npm, k8s)
    - Network exfiltration attempts
    - Environment variable harvesting
    - Suspicious process spawning
    
    Args:
        sandbox_results: Dict with summary, behavioral_indicators, findings
        
    Returns:
        Dict with risk score contribution and details
    """
    if not sandbox_results:
        return {
            'score': 0,
            'verdict': 'SKIPPED',
            'policy_id': 'MALWARE-003',
            'risk_factors': [],
        }
    
    score = 0
    risk_factors = []
    verdict = 'SKIPPED'
    
    summary = sandbox_results.get('summary', {})
    malicious = summary.get('malicious', 0)
    suspicious = summary.get('suspicious', 0)
    honeypot_accesses = summary.get('honeypot_accesses', 0)
    network_attempts = summary.get('network_attempts', 0)
    
    # Malicious packages: 500 points each
    if malicious > 0:
        score += malicious * 500
        risk_factors.append(f"{malicious} packages with malicious behavior [MALWARE-003]")
        verdict = 'MALICIOUS'
    
    # Suspicious packages: 100 points each
    if suspicious > 0:
        score += suspicious * 100
        risk_factors.append(f"{suspicious} packages with suspicious behavior [MALWARE-003]")
        if verdict != 'MALICIOUS':
            verdict = 'SUSPICIOUS'
    
    # Honeypot access bonus (already counted in malicious, but note it)
    if honeypot_accesses > 0:
        risk_factors.append(f"{honeypot_accesses} honeypot credential accesses detected")
    
    # Network exfil bonus
    if network_attempts > 0:
        risk_factors.append(f"{network_attempts} network exfiltration attempts blocked")
    
    if verdict == 'SKIPPED' and malicious == 0 and suspicious == 0:
        verdict = 'CLEAN'
    
    return {
        'score': score,
        'verdict': verdict,
        'policy_id': 'MALWARE-003',
        'policy_name': 'Behavioral Anomaly Detection',
        'malicious_count': malicious,
        'suspicious_count': suspicious,
        'honeypot_accesses': honeypot_accesses,
        'network_attempts': network_attempts,
        'risk_factors': risk_factors,
    }

# Module version - must match Cython version
__version__ = '2.9.38'
