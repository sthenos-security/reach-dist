# Copyright © 2026 Sthenos Security. All rights reserved.

"""
Core module containing Cython-accelerated components for REACHABLE.

This module provides optimized implementations of:
- Call graph traversal algorithms
- Reachability analysis
- Pattern matching for secrets detection
- Risk score calculations
- CISA/NIST secret severity classification (v2.9.37)
- Malware sandbox scoring (v2.9.37)

Build with: python setup_cython.py build_ext --inplace
"""

__version__ = "2.9.38"

# Try to import Cython-compiled modules, fall back to pure Python
try:
    from .reachability_core import (
        compute_reachability_fast,
        traverse_call_graph,
        calculate_risk_score,
        match_secret_patterns,
        classify_secret_severity,
        calculate_sandbox_risk,
    )
    CYTHON_AVAILABLE = True
except ImportError:
    CYTHON_AVAILABLE = False
    # Pure Python fallbacks will be used
    from .reachability_pure import (
        compute_reachability_fast,
        traverse_call_graph,
        calculate_risk_score,
        match_secret_patterns,
        classify_secret_severity,
        calculate_sandbox_risk,
    )

# Import constants (same in both implementations)
try:
    from .reachability_core import (
        SCENARIO_TOXIC_COMBINATION,
        SCENARIO_EXPOSED_ASSET,
        SCENARIO_DEAD_LINK,
        SCENARIO_SECURITY_DEBT,
        ACTION_ACT,
        ACTION_ATTEND,
        ACTION_TRACK,
    )
except ImportError:
    from .reachability_pure import (
        SCENARIO_TOXIC_COMBINATION,
        SCENARIO_EXPOSED_ASSET,
        SCENARIO_DEAD_LINK,
        SCENARIO_SECURITY_DEBT,
        ACTION_ACT,
        ACTION_ATTEND,
        ACTION_TRACK,
    )

def get_backend():
    """Return which backend is being used."""
    return "cython" if CYTHON_AVAILABLE else "python"

__all__ = [
    # Core algorithms
    'compute_reachability_fast',
    'traverse_call_graph',
    'calculate_risk_score',
    'match_secret_patterns',
    # CISA/NIST secret severity (v2.9.37)
    'classify_secret_severity',
    'SCENARIO_TOXIC_COMBINATION',
    'SCENARIO_EXPOSED_ASSET',
    'SCENARIO_DEAD_LINK',
    'SCENARIO_SECURITY_DEBT',
    'ACTION_ACT',
    'ACTION_ATTEND',
    'ACTION_TRACK',
    # Malware sandbox (v2.9.37)
    'calculate_sandbox_risk',
    # Utilities
    'get_backend',
    'CYTHON_AVAILABLE',
]
