#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.

"""
Kubernetes Security Analyzer

Detects common security misconfigurations in Kubernetes manifests:
- Missing resource limits (CPU/memory)
- Privileged containers
- hostNetwork/hostPID/hostIPC
- Running as root
- Missing security contexts
- Dangerous capabilities

Usage:
    analyzer = K8sSecurityAnalyzer()
    findings = analyzer.analyze_directory('/path/to/k8s/manifests')
"""

import yaml
import json
from pathlib import Path
from typing import Dict, List, Optional, Any
from dataclasses import dataclass, field

@dataclass
class K8sFinding:
    """A Kubernetes security finding"""
    rule_id: str
    severity: str  # CRITICAL, HIGH, MEDIUM, LOW
    title: str
    description: str
    file_path: str
    resource_kind: str
    resource_name: str
    namespace: str
    container_name: Optional[str] = None
    remediation: str = ""
    cwe: Optional[str] = None
    compliance: List[str] = field(default_factory=list)
    
    def to_dict(self) -> Dict:
        return {
            'rule_id': self.rule_id,
            'severity': self.severity,
            'title': self.title,
            'description': self.description,
            'file_path': self.file_path,
            'resource_kind': self.resource_kind,
            'resource_name': self.resource_name,
            'namespace': self.namespace,
            'container_name': self.container_name,
            'remediation': self.remediation,
            'cwe': self.cwe,
            'compliance': self.compliance,
            'type': 'CONFIG',
            'is_reachable': None,  # CONFIG findings have unknown reachability
            'reachability_state': 'unknown',
        }

class K8sSecurityAnalyzer:
    """Analyze Kubernetes manifests for security misconfigurations"""
    
    # Security rules
    RULES = {
        'K8S-001': {
            'title': 'Missing CPU limits',
            'severity': 'MEDIUM',
            'description': 'Container does not specify CPU limits, which can lead to resource exhaustion',
            'remediation': 'Add resources.limits.cpu to container spec',
            'cwe': 'CWE-400',
            'compliance': ['NIST-CM-6', 'CIS-K8S-5.1.1'],
        },
        'K8S-002': {
            'title': 'Missing memory limits',
            'severity': 'MEDIUM',
            'description': 'Container does not specify memory limits, which can lead to OOM kills',
            'remediation': 'Add resources.limits.memory to container spec',
            'cwe': 'CWE-400',
            'compliance': ['NIST-CM-6', 'CIS-K8S-5.1.1'],
        },
        'K8S-003': {
            'title': 'Privileged container',
            'severity': 'CRITICAL',
            'description': 'Container runs in privileged mode, granting full host access',
            'remediation': 'Set securityContext.privileged to false',
            'cwe': 'CWE-250',
            'compliance': ['NIST-AC-6', 'CIS-K8S-5.2.1', 'PCI-DSS-2.2'],
        },
        'K8S-004': {
            'title': 'Running as root',
            'severity': 'HIGH',
            'description': 'Container runs as root user (UID 0)',
            'remediation': 'Set securityContext.runAsNonRoot to true and runAsUser to non-zero',
            'cwe': 'CWE-250',
            'compliance': ['NIST-AC-6', 'CIS-K8S-5.2.6'],
        },
        'K8S-005': {
            'title': 'Host network enabled',
            'severity': 'HIGH',
            'description': 'Pod uses host network namespace, bypassing network isolation',
            'remediation': 'Remove hostNetwork: true unless absolutely required',
            'cwe': 'CWE-284',
            'compliance': ['NIST-SC-7', 'CIS-K8S-5.2.4'],
        },
        'K8S-006': {
            'title': 'Host PID enabled',
            'severity': 'HIGH',
            'description': 'Pod uses host PID namespace, allowing process visibility',
            'remediation': 'Remove hostPID: true unless absolutely required',
            'cwe': 'CWE-284',
            'compliance': ['NIST-SC-7', 'CIS-K8S-5.2.2'],
        },
        'K8S-007': {
            'title': 'Host IPC enabled',
            'severity': 'MEDIUM',
            'description': 'Pod uses host IPC namespace',
            'remediation': 'Remove hostIPC: true unless absolutely required',
            'cwe': 'CWE-284',
            'compliance': ['NIST-SC-7', 'CIS-K8S-5.2.3'],
        },
        'K8S-008': {
            'title': 'Dangerous capability added',
            'severity': 'HIGH',
            'description': 'Container adds dangerous Linux capability',
            'remediation': 'Remove dangerous capabilities from securityContext.capabilities.add',
            'cwe': 'CWE-250',
            'compliance': ['NIST-AC-6', 'CIS-K8S-5.2.8'],
        },
        'K8S-009': {
            'title': 'Capabilities not dropped',
            'severity': 'MEDIUM',
            'description': 'Container does not drop all capabilities',
            'remediation': 'Add securityContext.capabilities.drop: ["ALL"]',
            'cwe': 'CWE-250',
            'compliance': ['NIST-AC-6', 'CIS-K8S-5.2.7'],
        },
        'K8S-010': {
            'title': 'Read-only root filesystem not enabled',
            'severity': 'LOW',
            'description': 'Container root filesystem is writable',
            'remediation': 'Set securityContext.readOnlyRootFilesystem to true',
            'cwe': 'CWE-732',
            'compliance': ['NIST-CM-6', 'CIS-K8S-5.2.4'],
        },
        'K8S-011': {
            'title': 'Privilege escalation allowed',
            'severity': 'HIGH',
            'description': 'Container allows privilege escalation via setuid/setgid',
            'remediation': 'Set securityContext.allowPrivilegeEscalation to false',
            'cwe': 'CWE-269',
            'compliance': ['NIST-AC-6', 'CIS-K8S-5.2.5'],
        },
        'K8S-012': {
            'title': 'Secret mounted as environment variable',
            'severity': 'MEDIUM',
            'description': 'Secrets exposed as environment variables can leak in logs/crashes',
            'remediation': 'Mount secrets as files instead of environment variables',
            'cwe': 'CWE-312',
            'compliance': ['NIST-SC-28'],
        },
        'K8S-013': {
            'title': 'Image uses latest tag',
            'severity': 'MEDIUM',
            'description': 'Container uses :latest tag which is mutable and unpredictable',
            'remediation': 'Use specific image tags or digests',
            'cwe': 'CWE-829',
            'compliance': ['NIST-CM-2'],
        },
        'K8S-014': {
            'title': 'Missing liveness probe',
            'severity': 'LOW',
            'description': 'Container has no liveness probe for health monitoring',
            'remediation': 'Add livenessProbe to container spec',
            'compliance': ['NIST-SI-4'],
        },
        'K8S-015': {
            'title': 'Missing readiness probe',
            'severity': 'LOW',
            'description': 'Container has no readiness probe for traffic routing',
            'remediation': 'Add readinessProbe to container spec',
            'compliance': ['NIST-SI-4'],
        },
    }
    
    # Dangerous capabilities
    DANGEROUS_CAPS = {
        'SYS_ADMIN', 'NET_ADMIN', 'SYS_PTRACE', 'SYS_MODULE',
        'DAC_READ_SEARCH', 'NET_RAW', 'SYS_RAWIO', 'AUDIT_WRITE',
        'MKNOD', 'SETUID', 'SETGID', 'CHOWN', 'SYS_CHROOT',
    }
    
    def __init__(self):
        self.findings: List[K8sFinding] = []
    
    def analyze_directory(self, path: str) -> List[Dict]:
        """Analyze all K8s manifests in a directory"""
        self.findings = []
        root = Path(path)
        
        # Find all YAML files
        yaml_files = list(root.rglob('*.yaml')) + list(root.rglob('*.yml'))
        
        for yaml_file in yaml_files:
            # Skip hidden dirs and common non-k8s files
            if any(p.startswith('.') for p in yaml_file.parts):
                continue
            if 'node_modules' in yaml_file.parts:
                continue
                
            try:
                self._analyze_file(yaml_file)
            except Exception as e:
                # Skip files that aren't valid K8s manifests
                pass
        
        return [f.to_dict() for f in self.findings]
    
    def _analyze_file(self, file_path: Path):
        """Analyze a single YAML file"""
        content = file_path.read_text()
        
        # Handle multi-document YAML
        docs = list(yaml.safe_load_all(content))
        
        for doc in docs:
            if not isinstance(doc, dict):
                continue
            
            # Check if this is a K8s resource
            if 'apiVersion' not in doc or 'kind' not in doc:
                continue
            
            kind = doc.get('kind', '')
            
            # Analyze based on resource type
            if kind in ('Deployment', 'StatefulSet', 'DaemonSet', 'ReplicaSet', 'Job', 'CronJob'):
                self._analyze_workload(doc, str(file_path))
            elif kind == 'Pod':
                self._analyze_pod_spec(
                    doc.get('spec', {}),
                    str(file_path),
                    kind,
                    doc.get('metadata', {}).get('name', 'unnamed'),
                    doc.get('metadata', {}).get('namespace', 'default'),
                )
    
    def _analyze_workload(self, doc: Dict, file_path: str):
        """Analyze a workload resource (Deployment, StatefulSet, etc.)"""
        kind = doc.get('kind', '')
        metadata = doc.get('metadata', {})
        name = metadata.get('name', 'unnamed')
        namespace = metadata.get('namespace', 'default')
        
        # Get pod spec (location varies by kind)
        if kind == 'CronJob':
            pod_spec = doc.get('spec', {}).get('jobTemplate', {}).get('spec', {}).get('template', {}).get('spec', {})
        else:
            pod_spec = doc.get('spec', {}).get('template', {}).get('spec', {})
        
        self._analyze_pod_spec(pod_spec, file_path, kind, name, namespace)
    
    def _analyze_pod_spec(self, pod_spec: Dict, file_path: str, kind: str, name: str, namespace: str):
        """Analyze a pod spec for security issues"""
        
        # Pod-level checks
        if pod_spec.get('hostNetwork'):
            self._add_finding('K8S-005', file_path, kind, name, namespace)
        
        if pod_spec.get('hostPID'):
            self._add_finding('K8S-006', file_path, kind, name, namespace)
        
        if pod_spec.get('hostIPC'):
            self._add_finding('K8S-007', file_path, kind, name, namespace)
        
        # Container-level checks
        containers = pod_spec.get('containers', []) + pod_spec.get('initContainers', [])
        
        for container in containers:
            container_name = container.get('name', 'unnamed')
            self._analyze_container(container, file_path, kind, name, namespace, container_name)
    
    def _analyze_container(self, container: Dict, file_path: str, kind: str, 
                           name: str, namespace: str, container_name: str):
        """Analyze a container spec"""
        
        # Resource limits
        resources = container.get('resources', {})
        limits = resources.get('limits', {})
        
        if 'cpu' not in limits:
            self._add_finding('K8S-001', file_path, kind, name, namespace, container_name)
        
        if 'memory' not in limits:
            self._add_finding('K8S-002', file_path, kind, name, namespace, container_name)
        
        # Security context
        sec_ctx = container.get('securityContext', {})
        
        if sec_ctx.get('privileged'):
            self._add_finding('K8S-003', file_path, kind, name, namespace, container_name)
        
        # Running as root check
        run_as_non_root = sec_ctx.get('runAsNonRoot')
        run_as_user = sec_ctx.get('runAsUser')
        if run_as_non_root is not True and (run_as_user is None or run_as_user == 0):
            self._add_finding('K8S-004', file_path, kind, name, namespace, container_name)
        
        # Capabilities
        caps = sec_ctx.get('capabilities', {})
        added_caps = set(caps.get('add', []))
        dropped_caps = set(caps.get('drop', []))
        
        dangerous_added = added_caps & self.DANGEROUS_CAPS
        if dangerous_added:
            self._add_finding('K8S-008', file_path, kind, name, namespace, container_name,
                             extra=f"Capabilities: {', '.join(dangerous_added)}")
        
        if 'ALL' not in dropped_caps and not dropped_caps:
            self._add_finding('K8S-009', file_path, kind, name, namespace, container_name)
        
        # Read-only root filesystem
        if not sec_ctx.get('readOnlyRootFilesystem'):
            self._add_finding('K8S-010', file_path, kind, name, namespace, container_name)
        
        # Privilege escalation
        if sec_ctx.get('allowPrivilegeEscalation') is not False:
            self._add_finding('K8S-011', file_path, kind, name, namespace, container_name)
        
        # Secrets as env vars
        for env in container.get('env', []):
            if env.get('valueFrom', {}).get('secretKeyRef'):
                self._add_finding('K8S-012', file_path, kind, name, namespace, container_name,
                                 extra=f"Secret: {env.get('name')}")
                break  # Only report once per container
        
        # Image tag
        image = container.get('image', '')
        if ':latest' in image or (':' not in image and '@' not in image):
            self._add_finding('K8S-013', file_path, kind, name, namespace, container_name,
                             extra=f"Image: {image}")
        
        # Probes
        if not container.get('livenessProbe'):
            self._add_finding('K8S-014', file_path, kind, name, namespace, container_name)
        
        if not container.get('readinessProbe'):
            self._add_finding('K8S-015', file_path, kind, name, namespace, container_name)
    
    def _add_finding(self, rule_id: str, file_path: str, kind: str, name: str, 
                     namespace: str, container_name: str = None, extra: str = None):
        """Add a finding"""
        rule = self.RULES[rule_id]
        
        description = rule['description']
        if extra:
            description = f"{description}. {extra}"
        
        self.findings.append(K8sFinding(
            rule_id=rule_id,
            severity=rule['severity'],
            title=rule['title'],
            description=description,
            file_path=file_path,
            resource_kind=kind,
            resource_name=name,
            namespace=namespace,
            container_name=container_name,
            remediation=rule['remediation'],
            cwe=rule.get('cwe'),
            compliance=rule.get('compliance', []),
        ))

def analyze_k8s_manifests(path: str) -> List[Dict]:
    """Convenience function to analyze K8s manifests"""
    analyzer = K8sSecurityAnalyzer()
    return analyzer.analyze_directory(path)

if __name__ == '__main__':
    import sys
    
    if len(sys.argv) < 2:
        print("Usage: python k8s_analyzer.py /path/to/manifests")
        sys.exit(1)
    
    findings = analyze_k8s_manifests(sys.argv[1])
    
    print(f"Found {len(findings)} K8s security issues:")
    for f in findings:
        print(f"  [{f['severity']}] {f['rule_id']}: {f['title']}")
        print(f"    Resource: {f['resource_kind']}/{f['resource_name']}")
        print(f"    File: {f['file_path']}")
        print()
