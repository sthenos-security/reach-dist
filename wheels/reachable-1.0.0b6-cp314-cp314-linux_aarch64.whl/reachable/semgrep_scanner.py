#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.

"""
Semgrep Secrets Detection Integration

Integrates Semgrep to scan for:
- Hardcoded API keys
- AWS credentials
- Database passwords
- Private keys
- OAuth tokens
- Python malware patterns (supply-chain attacks)
"""

import json
import subprocess
from pathlib import Path
from typing import Dict, List, Optional
from dataclasses import dataclass

@dataclass
class SecretDetection:
    """Secret detection result"""
    rule_id: str
    severity: str  # INFO, WARNING, ERROR
    message: str
    file_path: str
    line_number: int
    code_snippet: str
    secret_type: str  # api-key, password, token, etc.
    is_actual_secret: bool = True  # False for SAST findings (shell injection, etc.)

@dataclass
class MalwarePattern:
    """Malware pattern detection result"""
    rule_id: str
    severity: str  # INFO, WARNING, ERROR
    message: str
    file_path: str
    line_number: int
    code_snippet: str
    tier: int  # 1-4 (1 = must-have, 4 = contextual)
    category: str  # import-time-execution, dynamic-execution, etc.
    risk: str  # immediate-compromise, credential-theft, etc.
    confidence: str  # low, medium, high

class SemgrepScanner:
    """Semgrep integration for secrets detection and malware patterns"""
    
    def __init__(self, cache_dir: Optional[Path] = None):
        """
        Initialize Semgrep scanner
        
        Args:
            cache_dir: Directory to cache results
        """
        self.cache_dir = Path(cache_dir) if cache_dir else None
        if self.cache_dir:
            self.cache_dir.mkdir(parents=True, exist_ok=True)
        
        # Find semgrep command (check venv first, then PATH)
        self.semgrep_cmd = self._find_semgrep()
        self._available = self.semgrep_cmd is not None
        
        # Path to custom malware rules
        self.malware_rules_path = Path(__file__).parent / "semgrep-rules-malware.yaml"
    
    def _find_semgrep(self) -> Optional[str]:
        """Find semgrep binary in venv or system PATH"""
        import sys
        import shutil
        
        # Check if running in venv
        if hasattr(sys, 'real_prefix') or (hasattr(sys, 'base_prefix') and sys.base_prefix != sys.prefix):
            # In venv - check venv/bin/semgrep first
            venv_semgrep = Path(sys.prefix) / 'bin' / 'semgrep'
            if venv_semgrep.exists():
                return str(venv_semgrep)
        
        # Check system PATH
        semgrep_path = shutil.which('semgrep')
        return semgrep_path
    
    def _check_semgrep_available(self) -> bool:
        """Check if Semgrep CLI is installed"""
        if not self.semgrep_cmd:
            return False
        
        try:
            result = subprocess.run(
                [self.semgrep_cmd, '--version'],
                capture_output=True,
                text=True,
                timeout=5
            )
            return result.returncode == 0
        except (FileNotFoundError, subprocess.TimeoutExpired):
            return False
    
    def is_available(self) -> bool:
        """Check if Semgrep is available"""
        return self._available
    
    def scan_directory(self, target_dir: Path, rules: str = 'auto') -> List[SecretDetection]:
        """
        Scan directory for secrets
        
        Args:
            target_dir: Directory to scan
            rules: Semgrep rules to use ('auto', 'p/secrets', 'p/security-audit', etc.)
            
        Returns:
            List of SecretDetection findings
        """
        if not self._available:
            return []
        
        if not target_dir.exists():
            return []
        
        try:
            # Build semgrep command
            # semgrep --config auto --json <target>
            cmd = [
                self.semgrep_cmd,
                '--config', rules,
                '--json',
                '--quiet',
                '--no-git-ignore',  # Scan everything including .gitignore files
                # Exclude unsupported languages
                '--exclude', '*.clj',    # Clojure
                '--exclude', '*.cljs',   # ClojureScript
                '--exclude', '*.edn',    # EDN
                '--exclude', '*.rkt',    # Racket
                '--exclude', '*.scm',    # Scheme
                '--exclude', '*.lisp',   # Lisp
                '--exclude', '*.el',     # Emacs Lisp
                '--exclude', '*.ml',     # OCaml (if not using generic rules)
                '--exclude', '*.nim',    # Nim
                '--exclude', '*.zig',    # Zig
                str(target_dir)
            ]
            
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=300
            )
            
            # Check if semgrep failed
            if result.returncode != 0 and result.stderr:
                print(f"   ⚠️  Semgrep stderr: {result.stderr[:200]}")
            
            # Parse Semgrep JSON output
            try:
                semgrep_data = json.loads(result.stdout)
            except json.JSONDecodeError as e:
                print(f"   ⚠️  Semgrep JSON parse error: {e}")
                print(f"   ⚠️  Stdout (first 200 chars): {result.stdout[:200]}")
                return []
            except Exception as e:
                print(f"   ⚠️  Semgrep parse error: {e}")
                return []
            
            # Extract findings
            findings = []
            
            results_list = semgrep_data.get('results', [])
            if not results_list:
                # Check if there's an error message
                errors = semgrep_data.get('errors', [])
                if errors:
                    print(f"   ⚠️  Semgrep reported {len(errors)} error(s)")
                    for error in errors[:3]:
                        # Handle both string errors and dict errors
                        if isinstance(error, dict):
                            error_msg = error.get('short_msg') or error.get('long_msg') or error.get('message', str(error))
                            error_type = error.get('type', 'Error')
                            # Only print non-language errors (we're excluding those files already)
                            if 'UnknownLanguageError' not in error_type:
                                print(f"      • [{error_type}] {error_msg[:150]}")
                        else:
                            print(f"      • {error}")
            
            for finding in results_list:
                # Determine secret type from rule ID
                rule_id = finding.get('check_id', '')
                secret_type = self._classify_secret_type(rule_id)
                
                # Determine if this is an actual secret or a SAST finding
                is_actual_secret = self._is_actual_secret_rule(rule_id)
                
                # Extract code snippet
                code_lines = finding.get('extra', {}).get('lines', '')
                
                detection = SecretDetection(
                    rule_id=rule_id,
                    severity=finding.get('extra', {}).get('severity', 'WARNING').upper(),
                    message=self._enhance_secret_description(
                        finding.get('extra', {}).get('message', ''),
                        secret_type
                    ),
                    file_path=finding.get('path', ''),
                    line_number=finding.get('start', {}).get('line', 0),
                    code_snippet=code_lines.strip() if code_lines else '',
                    secret_type=secret_type,
                    is_actual_secret=is_actual_secret
                )
                
                findings.append(detection)
            
            return findings
            
        except subprocess.TimeoutExpired:
            print(f"   ⚠️  Semgrep scan timeout (>300s)")
            return []
        except FileNotFoundError:
            print(f"   ⚠️  Semgrep command not found - is it installed?")
            return []
        except Exception as e:
            print(f"   ⚠️  Semgrep scan failed: {type(e).__name__}: {e}")
            import traceback
            print(f"   ⚠️  Traceback: {traceback.format_exc()[:300]}")
            return []
    
    def _classify_secret_type(self, rule_id: str) -> str:
        """Classify the type of secret from rule ID"""
        rule_lower = rule_id.lower()
        
        if 'api-key' in rule_lower or 'apikey' in rule_lower:
            return 'api-key'
        elif 'aws' in rule_lower:
            return 'aws-credential'
        elif 'password' in rule_lower or 'passwd' in rule_lower:
            return 'password'
        elif 'token' in rule_lower:
            return 'token'
        elif 'private-key' in rule_lower or 'private_key' in rule_lower:
            return 'private-key'
        elif 'secret' in rule_lower:
            return 'secret'
        elif 'database' in rule_lower or 'db' in rule_lower:
            return 'database-credential'
        elif 'oauth' in rule_lower:
            return 'oauth-token'
        elif 'ssh' in rule_lower:
            return 'ssh-key'
        else:
            return 'unknown'
    
    def _enhance_secret_description(self, original_message: str, secret_type: str) -> str:
        """
        Enhance Semgrep's secret description with industry-standard remediation guidance.
        
        Replaces generic advice like "store in a private file" with proper secrets
        management recommendations per NIST, SOC2, and cloud security best practices.
        """
        # Industry-standard remediation by secret type
        REMEDIATION = {
            'aws-credential': (
                "AWS credential detected. "
                "Use IAM roles for EC2/ECS/Lambda instead of static credentials. "
                "For local development, use aws-vault or environment variables. "
                "For production, use AWS Secrets Manager or SSM Parameter Store."
            ),
            'private-key': (
                "Private key detected. "
                "Store in a secrets manager (HashiCorp Vault, AWS Secrets Manager, Azure Key Vault). "
                "Use certificate managers (ACM, Let's Encrypt) for TLS certs. "
                "Never commit private keys to source control."
            ),
            'ssh-key': (
                "SSH private key detected. "
                "Use ssh-agent or hardware security keys instead of file-based keys. "
                "For CI/CD, use ephemeral credentials or managed identities. "
                "Consider certificate-based SSH authentication."
            ),
            'database-credential': (
                "Database credential detected. "
                "Use IAM database authentication where available. "
                "Store credentials in a secrets manager with automatic rotation. "
                "Use connection poolers with credential injection (PgBouncer, ProxySQL)."
            ),
            'api-key': (
                "API key detected. "
                "Store in environment variables or a secrets manager. "
                "Use short-lived tokens where possible (OAuth2, JWT). "
                "Implement key rotation and scope limitation."
            ),
            'token': (
                "Token detected. "
                "Use a secrets manager (Vault, AWS Secrets Manager) for storage. "
                "Prefer short-lived tokens with automatic refresh. "
                "Implement proper token scoping and rotation."
            ),
            'password': (
                "Password detected. "
                "Never hardcode passwords in source code. "
                "Use a secrets manager with automatic rotation. "
                "Consider passwordless authentication where possible."
            ),
            'oauth-token': (
                "OAuth token detected. "
                "Use OAuth flows that don't require storing tokens in code. "
                "Implement proper token refresh and storage in secure backends. "
                "Consider using managed identity providers."
            ),
        }
        
        # Get enhanced description or use original
        if secret_type in REMEDIATION:
            return REMEDIATION[secret_type]
        
        # Check if original message has bad advice and replace it
        bad_phrases = [
            'store this in a separate, private file',
            'store in a private file',
            'private file',
            'separate file',
        ]
        
        enhanced = original_message
        for phrase in bad_phrases:
            if phrase.lower() in enhanced.lower():
                enhanced = enhanced.replace(
                    phrase,
                    "store in a secrets manager (HashiCorp Vault, AWS Secrets Manager)"
                )
        
        # If still has generic advice, append better guidance
        if 'should not be hardcoded' in enhanced.lower():
            enhanced += " Use a secrets manager or environment variables from secure storage."
        
        return enhanced
    
    def _is_actual_secret_rule(self, rule_id: str) -> bool:
        """
        Determine if a rule detects actual secrets vs SAST findings.
        
        Actual secrets: API keys, passwords, tokens, credentials
        SAST findings: Shell injection, command injection, etc.
        
        Returns:
            True if the rule detects actual hardcoded secrets
            False if the rule detects code quality/security issues (SAST)
        """
        rule_lower = rule_id.lower()
        
        # SAST patterns (not actual secrets)
        SAST_PATTERNS = [
            'injection', 'xss', 'sqli', 'command-injection', 'shell-injection',
            'path-traversal', 'insecure', 'unsafe', 'dangerous', 'document-',
            'eval', 'exec', 'unsafe-', 'unvalidated', 'untrusted', 'taint',
            'csrf', 'cors', 'deserialize', 'yaml-', 'xml-', 'redirect',
            'cookie-', 'header-', 'input-', 'request-', 'response-',
            'open-redirect', 'ssrf', 'lfi', 'rfi', 'file-inclusion'
        ]
        
        # If it matches any SAST pattern, it's not an actual secret
        for pattern in SAST_PATTERNS:
            if pattern in rule_lower:
                return False
        
        # Actual secret patterns
        SECRET_PATTERNS = [
            'api-key', 'apikey', 'api_key', 'password', 'passwd', 'pwd',
            'secret', 'token', 'credential', 'private-key', 'private_key',
            'privatekey', 'aws', 'azure', 'gcp', 'google', 'github',
            'slack', 'stripe', 'twilio', 'sendgrid', 'mailgun', 'oauth',
            'bearer', 'jwt', 'ssh', 'database', 'connection-string',
            'connectionstring', 'db-password', 'db_password', 'mysql',
            'postgres', 'mongodb', 'redis', 'encryption-key', 'signing-key',
            'access-key', 'access_key', 'accesskey'
        ]
        
        # If it matches any secret pattern, it's an actual secret
        for pattern in SECRET_PATTERNS:
            if pattern in rule_lower:
                return True
        
        # Default to True if we can't determine (conservative)
        return True
    
    def scan_with_summary(self, target_dir: Path, rules: str = 'p/secrets', reachable_functions: set = None) -> Dict:
        """
        Scan directory and return summary with reachability context
        
        Args:
            target_dir: Directory to scan
            rules: Semgrep rules to use
            reachable_functions: Set of reachable function names (for prioritization)
            
        Returns:
            Dict with findings and summary statistics (including reachability)
        """
        findings = self.scan_directory(target_dir, rules)
        
        # Group by severity and type
        by_severity = {'ERROR': [], 'WARNING': [], 'INFO': []}
        by_escalated_severity = {'CRITICAL': [], 'VERY_HIGH': [], 'HIGH': [], 'MEDIUM': [], 'LOW': []}
        by_type = {}
        by_reachability = {'reachable': [], 'unreachable': [], 'unknown': []}
        standalone_secrets = []
        
        for finding in findings:
            by_severity[finding.severity].append(finding)
            
            if finding.secret_type not in by_type:
                by_type[finding.secret_type] = []
            by_type[finding.secret_type].append(finding)
            
            # Determine reachability if we have the information
            if reachable_functions is not None:
                is_reachable = self._is_secret_reachable(finding, reachable_functions)
                if is_reachable is None:
                    by_reachability['unknown'].append(finding)
                elif is_reachable:
                    by_reachability['reachable'].append(finding)
                else:
                    by_reachability['unreachable'].append(finding)
                
                # Track escalated severity
                escalated = getattr(finding, '_escalated_severity', None)
                if escalated and escalated in by_escalated_severity:
                    by_escalated_severity[escalated].append(finding)
                
                # Track standalone secrets
                if getattr(finding, '_is_standalone_secret', False):
                    standalone_secrets.append(finding)
            else:
                by_reachability['unknown'].append(finding)
        
        # Calculate priority counts
        reachable_critical = len(by_escalated_severity['CRITICAL'])
        reachable_very_high = len(by_escalated_severity['VERY_HIGH'])
        
        return {
            'total_findings': len(findings),
            'by_severity': {
                'critical': len(by_escalated_severity['CRITICAL']),
                'very_high': len(by_escalated_severity['VERY_HIGH']),
                'error': len(by_severity['ERROR']),
                'warning': len(by_severity['WARNING']),
                'info': len(by_severity['INFO'])
            },
            'by_reachability': {
                'reachable_critical': reachable_critical,
                'reachable_very_high': reachable_very_high,
                'reachable': len(by_reachability['reachable']),
                'unreachable': len(by_reachability['unreachable']),
                'unknown': len(by_reachability['unknown'])
            },
            'standalone_secrets': {
                'total': len(standalone_secrets),
                'critical': len([s for s in standalone_secrets if getattr(s, '_escalated_severity', '') == 'CRITICAL']),
                'very_high': len([s for s in standalone_secrets if getattr(s, '_escalated_severity', '') == 'VERY_HIGH']),
            },
            'by_type': {k: len(v) for k, v in by_type.items()},
            'findings': [
                self._build_finding_dict(f, reachable_functions)
                for f in findings
            ]
        }
    
    def _build_finding_dict(self, f: SecretDetection, reachable_functions: set = None) -> Dict:
        """Build finding dict with escalated severity for standalone secrets"""
        # First call reachability check to populate escalated fields
        if reachable_functions:
            self._is_secret_reachable(f, reachable_functions)
        
        result = {
            'rule_id': f.rule_id,
            'severity': getattr(f, '_escalated_severity', f.severity),  # Use escalated if set
            'original_severity': f.severity,
            'message': f.message,
            'file': f.file_path,
            'line': f.line_number,
            'snippet': f.code_snippet,
            'type': f.secret_type,
            'reachability': self._get_finding_reachability(f, reachable_functions) if reachable_functions else 'unknown',
        }
        
        # Add standalone secret info if present
        if getattr(f, '_is_standalone_secret', False):
            result['is_standalone_secret'] = True
            result['severity_reason'] = getattr(f, '_severity_reason', None)
        
        # Add reachable_via if set
        if hasattr(f, 'reachable_via') and f.reachable_via:
            result['reachable_via'] = f.reachable_via
        
        return result
    
    def _is_secret_reachable(self, finding: SecretDetection, reachable_functions: set) -> Optional[bool]:
        """
        Determine if a secret is in reachable code.
        
        For secrets in code files: Check if containing function is reachable.
        For secrets in standalone files (.pem, .key, etc): Check if any library
        that loads such files is called from reachable code.
        
        Severity escalation for standalone secret files:
        - CRITICAL: Loader function found in reachable code (confirmed exposure)
        - VERY_HIGH: Standalone file but couldn't find loader (assume it's used)
        
        Returns:
            True if reachable, False if unreachable, None if unknown
        """
        if not reachable_functions:
            return None
        
        file_path = Path(finding.file_path)
        
        # Known standalone secret file extensions
        STANDALONE_SECRET_EXTENSIONS = {
            '.pem', '.key', '.crt', '.cer', '.p12', '.pfx', '.jks',  # Certificates/keys
            '.env', '.credentials', '.netrc', '.npmrc', '.pypirc',   # Credential files
        }
        
        # Code file extensions (secrets here use function reachability)
        CODE_EXTENSIONS = {
            '.py', '.go', '.js', '.ts', '.jsx', '.tsx', '.java', '.kt', '.scala',
            '.groovy', '.rb', '.php', '.cs', '.cpp', '.c', '.h', '.rs', '.swift',
            '.m', '.mm', '.sh', '.bash', '.zsh', '.ps1', '.psm1',
        }
        
        file_ext = file_path.suffix.lower()
        file_name = file_path.name.lower()
        
        # Code files are NEVER standalone - they use function reachability
        if file_ext in CODE_EXTENSIONS:
            return self._check_code_function_reachability(finding, reachable_functions)
        
        # Explicit standalone patterns (for non-code files)
        is_explicit_standalone = (
            file_ext in STANDALONE_SECRET_EXTENSIONS or
            file_name in {'credentials', 'config', '.env', '.env.local', '.env.production'} or
            'credential' in file_name or
            '-key.' in file_name or
            '_key.' in file_name or
            'secret' in file_name or
            'password' in file_name
        )
        
        # Non-code file with a secret = treat as standalone
        # If Semgrep found a secret in a non-code file, it's likely a config/data file
        is_non_code_secret = (
            finding.secret_type in {'private-key', 'api-key', 'aws-access-key', 
                                   'aws-secret-key', 'password', 'token', 'secret'}
        )
        
        is_standalone = is_explicit_standalone or is_non_code_secret
        
        if is_standalone:
            # For standalone files, check if secret-loading libraries are reachable
            result = self._check_secret_loader_reachability(finding, reachable_functions)
            
            # Mark as standalone for severity escalation
            finding._is_standalone_secret = True
            
            if result is True:
                # Loader found - CRITICAL severity, confirmed REACHABLE
                finding._escalated_severity = 'CRITICAL'
                finding._severity_reason = 'Loader function reachable'
                return True  # Confirmed reachable
            else:
                # No loaders found - UNKNOWN reachability
                # v4.5.2 FIX: Return None (UNKNOWN) not True
                # Severity still CRITICAL per "assume guilty until proven innocent"
                # but reachability status should be UNKNOWN for accurate reporting
                finding._escalated_severity = 'CRITICAL'
                finding._severity_reason = 'Standalone credential file (unknown reachability - assume exploitable)'
                return None  # UNKNOWN - can't determine reachability
            
            return result
        
        # For secrets embedded in code, check containing function
        result = self._check_code_function_reachability(finding, reachable_functions)
        
        # v4.5.3: ALL reachable secrets are CRITICAL - credentials need immediate rotation
        # Rationale: A reachable secret (API key, DB password, token) can be exploited
        # immediately without needing to find/exploit a CVE. This is worse than most CVEs.
        if result is True:
            finding._escalated_severity = 'CRITICAL'
            finding._severity_reason = 'Reachable secret - immediate credential exposure'
        
        return result
    
    def _check_secret_loader_reachability(self, finding: SecretDetection, 
                                          reachable_functions: set) -> Optional[bool]:
        """
        Check if any library that loads secret files is reachable.
        
        Multi-language support: Python, Go, JavaScript/TypeScript, Java/Kotlin
        
        Strategy:
        1. Identify loader function patterns for this file type
        2. Check if ANY matching pattern exists in reachable_functions
        3. Return True if loader found, False if no loaders, None if can't determine
        """
        file_path = Path(finding.file_path)
        file_ext = file_path.suffix.lower()
        
        # Multi-language secret loader patterns
        # These match function names in our call graph (app.* and lib.*)
        LOADER_PATTERNS = {
            # === CERTIFICATES & PRIVATE KEYS (.pem, .key, .crt, .p12, .pfx) ===
            '.pem': [
                # Go patterns
                'LoadX509KeyPair', 'ParseCertificate', 'ParsePKCS', 'TLSConfig',
                'parsePrivateKey', 'parseCertificate', 'parsePEM', 'parseCert',
                'x509.Parse', 'pem.Decode', 'tls.Load', 'tls.X509',
                # Python patterns
                'load_cert_chain', 'load_pem_private_key', 'load_pem_public_key',
                'SSLContext', 'ssl.create', 'load_certificate', 'load_privatekey',
                'RSAKey.from_private_key', 'Ed25519Key.from_private_key',
                # JavaScript/Node patterns
                'readFileSync', 'createSecureContext', 'tls.create', 'https.create',
                'crypto.create', 'fs.read',
                # Java/Kotlin patterns
                'KeyStore.load', 'SSLContext.init', 'KeyManagerFactory', 
                'TrustManagerFactory', 'PrivateKey', 'X509Certificate',
                'BouncyCastle', 'PEMParser',
            ],
            '.key': [
                'parsePrivateKey', 'parseCert', 'LoadX509', 'TLSConfig',
                'load_cert_chain', 'load_pem_private_key', 'RSAKey',
                'readFileSync', 'createSecureContext', 'fs.read',
                'KeyStore', 'PrivateKey', 'KeyManagerFactory',
            ],
            '.crt': [
                'ParseCertificate', 'parseCert', 'LoadX509', 'x509.Parse',
                'load_verify_locations', 'SSLContext',
                'readFileSync', 'createSecureContext',
                'X509Certificate', 'TrustManagerFactory',
            ],
            '.p12': [
                'ParsePKCS12', 'load_pkcs12', 'load_key_and_certificates',
                'KeyStore.load', 'PKCS12',
            ],
            '.pfx': [
                'ParsePKCS12', 'load_pkcs12', 'KeyStore.load', 'PKCS12',
            ],
            '.jks': [
                'KeyStore.load', 'KeyStore.getInstance',
            ],
            
            # === AWS CREDENTIALS ===
            '.credentials': [
                # Go
                'NewSession', 'NewConfig', 'credentials.NewShared',
                # Python
                'boto3.Session', 'boto3.client', 'botocore.credentials',
                # JavaScript
                'AWS.config', 'SharedIniFileCredentials', 'fromIni',
                # Java
                'AWSCredentialsProvider', 'ProfileCredentialsProvider',
            ],
            
            # === SSH KEYS ===
            '.ssh': [
                # Go
                'ssh.ParsePrivateKey', 'ssh.PublicKey',
                # Python
                'paramiko.RSAKey', 'paramiko.Ed25519Key', 'fabric.Connection',
                # JavaScript
                'ssh2.Client', 'ssh2-sftp',
                # Java
                'JSch', 'ChannelSftp',
            ],
            
            # === ENVIRONMENT FILES ===
            '.env': [
                # Go
                'godotenv.Load', 'os.Getenv', 'viper.',
                # Python
                'load_dotenv', 'dotenv_values', 'os.environ',
                # JavaScript
                'dotenv.config', 'process.env',
                # Java
                'System.getenv', 'Properties.load',
            ],
            
            # === KUBERNETES CONFIGS ===
            '.kubeconfig': [
                # Go
                'clientcmd.', 'rest.InClusterConfig', 'kubernetes.NewForConfig',
                # Python
                'kubernetes.config.load', 'kubernetes.client',
                # JavaScript
                '@kubernetes/client-node', 'KubeConfig',
                # Java
                'io.kubernetes.client',
            ],
            
            # === CONFIG FILES (.yaml, .yml, .json, .ini, .toml, .xml, .conf) ===
            '.yaml': [
                # Go
                'yaml.Unmarshal', 'viper.', 'ioutil.ReadFile', 'os.ReadFile',
                # Python
                'yaml.safe_load', 'yaml.load', 'pyyaml', 'ruamel',
                # JavaScript
                'js-yaml', 'yaml.parse', 'fs.readFile',
                # Java
                'SnakeYAML', 'ObjectMapper', 'YAMLFactory',
            ],
            '.yml': [],  # Same as .yaml, populated below
            '.json': [
                # Go
                'json.Unmarshal', 'ioutil.ReadFile', 'os.ReadFile',
                # Python
                'json.load', 'json.loads',
                # JavaScript
                'JSON.parse', 'parseJson', 'parseJSON', 'ParseJSON',
                'fs.readFile', 'require(',
                # Java
                'ObjectMapper', 'JsonParser', 'Gson',
            ],
            '.ini': [
                # Go
                'ini.Load', 'gopkg.in/ini',
                # Python
                'configparser', 'ConfigParser',
                # Java
                'Properties.load',
            ],
            '.toml': [
                # Go
                'toml.Unmarshal', 'BurntSushi/toml',
                # Python
                'toml.load', 'tomllib',
                # JavaScript
                'toml.parse',
            ],
            '.xml': [
                # Go
                'xml.Unmarshal',
                # Python
                'xml.etree', 'lxml', 'BeautifulSoup',
                # JavaScript
                'xml2js', 'DOMParser',
                # Java
                'DocumentBuilder', 'SAXParser', 'JAXB',
            ],
            '.conf': [
                # Generic config - use file reading patterns
                'ReadFile', 'readFile', 'load', 'parse', 'config',
            ],
        }
        
        # Populate .yml with same patterns as .yaml
        LOADER_PATTERNS['.yml'] = LOADER_PATTERNS['.yaml']
        
        # Secret type to loader patterns (for non-obvious file extensions)
        SECRET_TYPE_PATTERNS = {
            'private-key': LOADER_PATTERNS['.pem'],
            'aws-access-key': LOADER_PATTERNS['.credentials'],
            'aws-secret-key': LOADER_PATTERNS['.credentials'],
            'api-key': [
                # Generic API key loading patterns
                'Getenv', 'getenv', 'environ', 'Environ',
                'process.env', 'System.getenv',
                'Config.', 'config.', 'Settings.', 'settings.',
                'FromEnv', 'fromEnv', 'loadConfig', 'LoadConfig',
                'viper.', 'dotenv', 'ReadFile', 'readFile',
                'JSON.parse', 'json.Unmarshal', 'json.load',
            ],
            'password': [
                # Database/service password patterns
                'Getenv', 'getenv', 'environ', 'Environ',
                'process.env', 'System.getenv',
                'Config.', 'config.', 'database.', 'db.',
                'DataSource', 'ConnectionPool', 'DriverManager',
                'FromEnv', 'loadConfig', 'LoadConfig',
            ],
            'token': [
                'Getenv', 'getenv', 'environ', 'Environ',
                'process.env', 'System.getenv',
                'Bearer', 'Authorization', 'token', 'Token',
                'Config.', 'config.', 'FromEnv',
            ],
            'secret': [
                'Getenv', 'getenv', 'environ', 'Environ',
                'process.env', 'System.getenv',
                'secret', 'Secret', 'Config.', 'config.',
                'FromEnv', 'loadConfig',
            ],
        }
        
        # Get patterns for this file type
        patterns = LOADER_PATTERNS.get(file_ext, [])
        
        # Also check by filename for special cases
        file_name = file_path.name.lower()
        if 'credential' in file_name or 'aws' in file_name:
            patterns.extend(LOADER_PATTERNS.get('.credentials', []))
        if 'kube' in file_name or 'k8s' in file_name:
            patterns.extend(LOADER_PATTERNS.get('.kubeconfig', []))
        if '-key.' in file_name or '_key.' in file_name:
            patterns.extend(LOADER_PATTERNS.get('.pem', []))
        if 'secret' in file_name or 'password' in file_name:
            patterns.extend(SECRET_TYPE_PATTERNS.get('password', []))
        
        # If no patterns from file extension, try secret type
        if not patterns and finding.secret_type:
            patterns = SECRET_TYPE_PATTERNS.get(finding.secret_type, [])
        
        if not patterns:
            # No known loaders for this file type - can't determine
            return None
        
        # Check if any loader pattern matches reachable functions
        matched_loaders = []
        seen_funcs = set()
        
        for func in reachable_functions:
            func_lower = func.lower()
            for pattern in patterns:
                pattern_lower = pattern.lower()
                if pattern_lower in func_lower:
                    # Avoid duplicates - only keep first pattern match per function
                    if func not in seen_funcs:
                        seen_funcs.add(func)
                        matched_loaders.append((func, pattern))
                    break  # Move to next function after first pattern match
        
        if matched_loaders:
            # Sort to prioritize app.* functions over lib.* functions
            matched_loaders.sort(key=lambda x: (0 if x[0].startswith('app.') else 1, x[0]))
            
            # Store loader info on the finding for reporting
            finding.reachable_via = [f"{func} (via {pattern})" for func, pattern in matched_loaders[:5]]
            return True
        
        # No loaders found in reachable code
        return False
    
    def _check_code_function_reachability(self, finding: SecretDetection, 
                                          reachable_functions: set) -> Optional[bool]:
        """
        Check if a secret embedded in code is within a reachable function.
        
        For secrets in source files (not standalone .pem/.key files),
        find the containing function and check if it's reachable.
        """
        try:
            file_path = Path(finding.file_path)
            if not file_path.exists():
                return None
            
            with open(file_path, 'r') as f:
                lines = f.readlines()
            
            # Find the function containing this line
            secret_line = finding.line_number
            current_function = None
            
            # Python: look for 'def '
            # Go: look for 'func '
            # JS/TS: look for 'function ' or arrow functions
            # Java/Kotlin: look for method patterns
            
            for i in range(secret_line - 1, -1, -1):
                line = lines[i].strip()
                
                # Python
                if line.startswith('def '):
                    func_name = line.split('(')[0].replace('def ', '').strip()
                    current_function = func_name
                    break
                # Go
                elif line.startswith('func '):
                    # func (r *Receiver) MethodName(...)
                    # func FunctionName(...)
                    if '(' in line:
                        parts = line.split('(')
                        if len(parts) >= 2:
                            # Handle method receiver
                            if ')' in parts[0]:
                                func_name = parts[1].split(')')[0].strip()
                            else:
                                func_name = parts[0].replace('func ', '').strip()
                            current_function = func_name
                            break
                # JavaScript/TypeScript
                elif 'function ' in line:
                    func_name = line.split('function ')[1].split('(')[0].strip()
                    current_function = func_name
                    break
                # Arrow function assigned to const/let/var
                elif any(kw in line for kw in ['const ', 'let ', 'var ']) and '=>' in line:
                    for kw in ['const ', 'let ', 'var ']:
                        if kw in line:
                            func_name = line.split(kw)[1].split('=')[0].strip()
                            current_function = func_name
                            break
                    if current_function:
                        break
            
            if current_function:
                # Check if this function is reachable
                # Look for app.{filename}.{function} pattern
                module_name = file_path.stem
                full_func_name = f"app.{module_name}.{current_function}"
                
                # Also try variations
                if full_func_name in reachable_functions:
                    return True
                
                # Try just the function name with partial matching
                for func in reachable_functions:
                    if current_function in func:
                        return True
                
                return False
            
            return None
            
        except Exception:
            return None
    
    def _get_finding_reachability(self, finding: SecretDetection, reachable_functions: set) -> str:
        """Get reachability status as string"""
        is_reachable = self._is_secret_reachable(finding, reachable_functions)
        if is_reachable is None:
            return 'unknown'
        return 'reachable' if is_reachable else 'unreachable'
    
    # ========================================================================
    # MALWARE PATTERN DETECTION
    # ========================================================================
    
    def scan_for_malware_patterns(self, target_dir: Path) -> List[MalwarePattern]:
        """
        Scan Python code for malware patterns using custom Semgrep rules
        
        Args:
            target_dir: Directory to scan
            
        Returns:
            List of MalwarePattern findings
        """
        if not self._available:
            return []
        
        if not target_dir.exists():
            return []
        
        if not self.malware_rules_path.exists():
            print(f"   ⚠️  Malware rules not found: {self.malware_rules_path}")
            return []
        
        try:
            # Run Semgrep with custom malware rules
            cmd = [
                self.semgrep_cmd,
                '--config', str(self.malware_rules_path),
                '--json',
                '--quiet',
                '--no-git-ignore',
                str(target_dir)
            ]
            
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=300
            )
            
            # Parse Semgrep JSON output
            try:
                semgrep_data = json.loads(result.stdout)
            except:
                return []
            
            # Extract findings
            patterns = []
            
            for finding in semgrep_data.get('results', []):
                # Extract metadata
                metadata = finding.get('extra', {}).get('metadata', {})
                
                pattern = MalwarePattern(
                    rule_id=finding.get('check_id', ''),
                    severity=finding.get('extra', {}).get('severity', 'INFO').upper(),
                    message=finding.get('extra', {}).get('message', ''),
                    file_path=finding.get('path', ''),
                    line_number=finding.get('start', {}).get('line', 0),
                    code_snippet=finding.get('extra', {}).get('lines', '').strip(),
                    tier=int(metadata.get('tier', 4)),
                    category=metadata.get('category', 'unknown'),
                    risk=metadata.get('risk', 'unknown'),
                    confidence=metadata.get('confidence', 'medium')
                )
                
                patterns.append(pattern)
            
            return patterns
            
        except subprocess.TimeoutExpired:
            print(f"   ⚠️  Semgrep malware scan timeout")
            return []
        except Exception as e:
            print(f"   ⚠️  Semgrep malware scan failed: {e}")
            return []
    
    def scan_malware_with_summary(self, target_dir: Path) -> Dict:
        """
        Scan for malware patterns and return summary with scoring
        
        Returns comprehensive malware assessment based on:
        - Pattern tier (1-4)
        - Severity (ERROR, WARNING, INFO)
        - Signal combination
        """
        patterns = self.scan_for_malware_patterns(target_dir)
        
        if not patterns:
            return {
                'total_patterns': 0,
                'risk_score': 0,
                'verdict': 'CLEAN',
                'patterns': []
            }
        
        # Group by tier and severity
        by_tier = {1: [], 2: [], 3: [], 4: []}
        by_severity = {'ERROR': [], 'WARNING': [], 'INFO': []}
        by_category = {}
        
        for pattern in patterns:
            by_tier[pattern.tier].append(pattern)
            by_severity[pattern.severity].append(pattern)
            
            if pattern.category not in by_category:
                by_category[pattern.category] = []
            by_category[pattern.category].append(pattern)
        
        # Calculate risk score (0-100)
        risk_score = self._calculate_malware_risk_score(patterns)
        
        # Determine verdict
        verdict = self._determine_malware_verdict(risk_score, patterns)
        
        # Check for high-confidence combinations
        combined_signals = self._detect_combined_signals(patterns)
        
        return {
            'total_patterns': len(patterns),
            'risk_score': risk_score,
            'verdict': verdict,  # CLEAN, SUSPICIOUS, LIKELY_MALICIOUS, MALICIOUS
            'by_tier': {
                'tier_1_critical': len(by_tier[1]),
                'tier_2_poisoned': len(by_tier[2]),
                'tier_3_persistence': len(by_tier[3]),
                'tier_4_contextual': len(by_tier[4])
            },
            'by_severity': {
                'error': len(by_severity['ERROR']),
                'warning': len(by_severity['WARNING']),
                'info': len(by_severity['INFO'])
            },
            'by_category': {k: len(v) for k, v in by_category.items()},
            'combined_signals': combined_signals,
            'patterns': [
                {
                    'rule_id': p.rule_id,
                    'severity': p.severity,
                    'message': p.message,
                    'file': p.file_path,
                    'line': p.line_number,
                    'snippet': p.code_snippet,
                    'tier': p.tier,
                    'category': p.category,
                    'risk': p.risk,
                    'confidence': p.confidence
                }
                for p in patterns
            ]
        }
    
    def _calculate_malware_risk_score(self, patterns: List[MalwarePattern]) -> float:
        """
        Calculate risk score (0-100) based on patterns
        
        IMPORTANT: This scoring does NOT consider reachability!
        
        Why: Malware patterns (like import-time network calls or
        exec(base64.decode(...))) execute when the module is imported,
        not when functions are called. Therefore, reachability from
        entrypoints is irrelevant.
        
        Scoring based purely on pattern characteristics:
        - Tier 1 patterns: 30 points each (capped at 90)
        - Tier 2 patterns: 15 points each (capped at 45)
        - Tier 3 patterns: 10 points each (capped at 30)
        - Tier 4 patterns: 5 points each (capped at 15)
        - Combined signals: +20 points
        """
        score = 0
        
        tier_counts = {1: 0, 2: 0, 3: 0, 4: 0}
        for pattern in patterns:
            tier_counts[pattern.tier] += 1
        
        # Tier 1: Critical (import-time execution, dynamic code, etc.)
        score += min(tier_counts[1] * 30, 90)
        
        # Tier 2: Poisoned-library indicators
        score += min(tier_counts[2] * 15, 45)
        
        # Tier 3: Persistence mechanisms
        score += min(tier_counts[3] * 10, 30)
        
        # Tier 4: Contextual
        score += min(tier_counts[4] * 5, 15)
        
        # Bonus for combined signals (exfiltration pattern)
        combined_signals = self._detect_combined_signals(patterns)
        if combined_signals:
            score += 20
        
        return min(score, 100)
    
    def _determine_malware_verdict(self, risk_score: float, patterns: List[MalwarePattern]) -> str:
        """
        Determine overall malware verdict
        
        MALICIOUS: risk >= 70 OR multiple Tier 1 patterns
        LIKELY_MALICIOUS: risk >= 50 OR Tier 1 + Tier 2 patterns
        SUSPICIOUS: risk >= 30 OR multiple Tier 2/3 patterns
        CLEAN: risk < 30 AND only Tier 4 patterns
        """
        tier_1_count = sum(1 for p in patterns if p.tier == 1)
        tier_2_count = sum(1 for p in patterns if p.tier == 2)
        
        if risk_score >= 70 or tier_1_count >= 3:
            return 'MALICIOUS'
        elif risk_score >= 50 or (tier_1_count >= 1 and tier_2_count >= 2):
            return 'LIKELY_MALICIOUS'
        elif risk_score >= 30 or tier_2_count >= 3:
            return 'SUSPICIOUS'
        else:
            return 'CLEAN'
    
    def _detect_combined_signals(self, patterns: List[MalwarePattern]) -> List[str]:
        """
        Detect high-confidence signal combinations
        
        Returns list of detected combined patterns (e.g., "env-harvest + network")
        """
        combinations = []
        
        categories = {p.category for p in patterns}
        
        # Secret harvesting + Network = EXFILTRATION
        if 'secret-harvesting' in categories and 'network-primitives' in categories:
            combinations.append('credential-exfiltration')
        
        # Dynamic execution + Obfuscation = DROPPER
        if 'dynamic-execution' in categories and 'obfuscation' in categories:
            combinations.append('malware-dropper')
        
        # Import-time + Network = AUTO-EXFILTRATION
        if 'import-time-execution' in categories and 'network-primitives' in categories:
            combinations.append('import-time-exfiltration')
        
        # Command execution + Persistence = BACKDOOR
        if 'command-execution' in categories and 'persistence' in categories:
            combinations.append('backdoor-installation')
        
        return combinations

if __name__ == '__main__':
    # Test Semgrep scanner
    scanner = SemgrepScanner()
    
    if scanner.is_available():
        print("✓ Semgrep is available")
        
        # Test with current directory
        test_dir = Path('.')
        print(f"\nScanning {test_dir} for secrets...")
        
        results = scanner.scan_with_summary(test_dir, rules='p/secrets')
        
        print(f"\nResults:")
        print(f"  Total findings: {results['total_findings']}")
        print(f"  Errors: {results['by_severity']['error']}")
        print(f"  Warnings: {results['by_severity']['warning']}")
        print(f"  Info: {results['by_severity']['info']}")
        
        if results['by_type']:
            print(f"\n  By type:")
            for secret_type, count in results['by_type'].items():
                print(f"    {secret_type}: {count}")
    else:
        print("❌ Semgrep not available")
        print("   Install with: pip install semgrep")
