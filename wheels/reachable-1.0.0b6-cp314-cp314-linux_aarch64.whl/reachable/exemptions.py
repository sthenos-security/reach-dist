#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.

"""
REACHABLE Exemption Management System v2.0

Enhanced exemption/whitelisting mechanism supporting multiple identifier types:

IDENTIFIER TYPES:
- CVE-ID:     CVE-2023-1234
- GHSA-ID:    GHSA-xxxx-xxxx-xxxx (GitHub Security Advisory)
- Policy-ID:  ENV-001, MALWARE-001, SEC-001, etc.
- Rule-ID:    semgrep.rule.name, guarddog.rule, etc.
- Package:    package-name or package-name@version
- Secret:     SHA256 hash of secret value
- File:       File path pattern (glob)

EXEMPTION FILE LOCATIONS (searched in order):
1. .reachable/exemptions.yaml (project root)
2. .reachable/exemptions.json (project root)
3. ~/.reachable/exemptions.yaml (user home)
4. ~/.reachable/exemptions.json (user home)
5. REACHABLE_EXEMPTIONS_FILE environment variable

EXEMPTION REASONS:
- false_positive:         Not actually a security issue
- accepted_risk:          Team accepts the risk with justification
- compensating_controls:  Other mitigations in place
- planned_remediation:    Fix scheduled (requires ticket + expires_at)
- not_applicable:         Not applicable to this environment
- vendor_dispute:         Vendor disputes the finding
- wont_fix:              Will not fix (requires strong justification)

AUDIT REQUIREMENTS:
- All exemptions require: created_by, created_at, justification
- accepted_risk requires: approved_by (manager/security team)
- planned_remediation requires: ticket, expires_at
- wont_fix requires: approved_by, review_date

Example .reachable/exemptions.yaml:
```yaml
version: "2.0"
metadata:
  organization: "Example Corp"
  contact: "security@example.com"
  last_review: "2025-01-01"

exemptions:
  # By CVE ID
  - id: "EXM-001"
    type: "cve"
    target: "CVE-2023-44487"
    reason: "compensating_controls"
    justification: "WAF blocks HTTP/2 rapid reset attacks"
    created_by: "security@example.com"
    created_at: "2025-01-01T00:00:00Z"
    expires_at: "2025-06-01T00:00:00Z"

  # By GHSA ID
  - id: "EXM-002"
    type: "ghsa"
    target: "GHSA-jfh8-c2jp-5v3q"
    reason: "not_applicable"
    justification: "We don't use the affected feature"
    created_by: "dev@example.com"
    created_at: "2025-01-01T00:00:00Z"

  # By Policy ID (e.g., suppress all ENV-001 findings)
  - id: "EXM-003"
    type: "policy"
    target: "ENV-001"
    reason: "false_positive"
    justification: "These are example files, not real secrets"
    file_pattern: "examples/**/*"
    created_by: "dev@example.com"
    created_at: "2025-01-01T00:00:00Z"

  # By Semgrep Rule ID
  - id: "EXM-004"
    type: "rule"
    target: "generic.secrets.security.detected-aws-access-key"
    reason: "test_data"
    justification: "Test fixtures with fake AWS keys"
    file_pattern: "tests/**/*"
    created_by: "qa@example.com"
    created_at: "2025-01-01T00:00:00Z"
```
"""

import os
import json
import hashlib
import fnmatch
from pathlib import Path
from typing import Dict, List, Optional, Set, Any, Union
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from enum import Enum
import logging

logger = logging.getLogger(__name__)

# Try to import yaml, fall back to json-only
try:
    import yaml
    YAML_AVAILABLE = True
except ImportError:
    YAML_AVAILABLE = False

# =============================================================================
# ENUMS
# =============================================================================

class ExemptionType(Enum):
    """Types of identifiers that can be exempted"""
    CVE = "cve"              # CVE-2023-1234
    GHSA = "ghsa"            # GHSA-xxxx-xxxx-xxxx
    POLICY = "policy"        # ENV-001, MALWARE-001, SEC-001
    RULE = "rule"            # semgrep.rule.name, guarddog.rule
    PACKAGE = "package"      # package-name or package-name@version
    SECRET = "secret"        # SHA256 hash of secret value
    FILE = "file"            # File path pattern
    FINDING = "finding"      # Specific finding by hash

class ExemptionReason(Enum):
    """Standard exemption reasons with audit requirements"""
    FALSE_POSITIVE = "false_positive"
    ACCEPTED_RISK = "accepted_risk"
    COMPENSATING_CONTROLS = "compensating_controls"
    PLANNED_REMEDIATION = "planned_remediation"
    NOT_APPLICABLE = "not_applicable"
    VENDOR_DISPUTE = "vendor_dispute"
    WONT_FIX = "wont_fix"
    TEST_DATA = "test_data"
    ROTATED = "rotated"
    VENDORED_CODE = "vendored_code"

# Reasons that require additional fields
REASON_REQUIREMENTS = {
    ExemptionReason.ACCEPTED_RISK: ["approved_by"],
    ExemptionReason.PLANNED_REMEDIATION: ["ticket", "expires_at"],
    ExemptionReason.WONT_FIX: ["approved_by", "review_date"],
}

# =============================================================================
# POLICY ID REGISTRY
# =============================================================================

POLICY_REGISTRY = {
    # Secrets Detection (SEC-XXX)
    "SEC-001": {"name": "Hardcoded Secret", "scanner": "semgrep"},
    "SEC-002": {"name": "API Key in Code", "scanner": "semgrep"},
    "SEC-003": {"name": "Private Key File", "scanner": "trufflehog"},
    
    # Environment Secrets (ENV-XXX)
    "ENV-001": {"name": "Environment Secret", "scanner": "env_secrets_scanner"},
    "ENV-002": {"name": "Forbidden File", "scanner": "env_secrets_scanner"},
    "ENV-003": {"name": "Weak Secret", "scanner": "env_secrets_scanner"},
    
    # Code Weakness Enumeration - CWE (non-secret code security findings)
    # Using CWE-XXX format consistent with commercial SAST tools
    "CWE-079": {"name": "Cross-site Scripting (XSS)", "scanner": "semgrep", "severity_base": 6.1, "owasp": "A03:2021"},
    "CWE-089": {"name": "SQL Injection", "scanner": "semgrep", "severity_base": 9.8, "owasp": "A03:2021"},
    "CWE-078": {"name": "OS Command Injection", "scanner": "semgrep", "severity_base": 9.8, "owasp": "A03:2021"},
    "CWE-094": {"name": "Code Injection", "scanner": "semgrep", "severity_base": 9.8, "owasp": "A03:2021"},
    "CWE-022": {"name": "Path Traversal", "scanner": "semgrep", "severity_base": 7.5, "owasp": "A01:2021"},
    "CWE-352": {"name": "Cross-Site Request Forgery", "scanner": "semgrep", "severity_base": 8.8, "owasp": "A01:2021"},
    "CWE-601": {"name": "Open Redirect", "scanner": "semgrep", "severity_base": 6.1, "owasp": "A01:2021"},
    "CWE-327": {"name": "Broken Cryptographic Algorithm", "scanner": "semgrep", "severity_base": 7.5, "owasp": "A02:2021"},
    "CWE-328": {"name": "Weak Hash", "scanner": "semgrep", "severity_base": 7.5, "owasp": "A02:2021"},
    "CWE-330": {"name": "Insufficient Randomness", "scanner": "semgrep", "severity_base": 7.5, "owasp": "A02:2021"},
    "CWE-502": {"name": "Insecure Deserialization", "scanner": "semgrep", "severity_base": 9.8, "owasp": "A08:2021"},
    "CWE-918": {"name": "Server-Side Request Forgery", "scanner": "semgrep", "severity_base": 9.1, "owasp": "A10:2021"},
    "CWE-016": {"name": "Configuration Weakness", "scanner": "semgrep", "severity_base": 5.3, "owasp": "A05:2021"},
    "CWE-250": {"name": "Unnecessary Privileges", "scanner": "semgrep", "severity_base": 7.8, "owasp": "A05:2021"},
    "CWE-732": {"name": "Incorrect Permission Assignment", "scanner": "semgrep", "severity_base": 7.5, "owasp": "A05:2021"},
    "CWE-614": {"name": "Sensitive Cookie Without Secure", "scanner": "semgrep", "severity_base": 5.3, "owasp": "A05:2021"},
    "CWE-778": {"name": "Insufficient Logging", "scanner": "semgrep", "severity_base": 5.3, "owasp": "A09:2021"},
    "CWE-532": {"name": "Sensitive Info in Log", "scanner": "semgrep", "severity_base": 5.5, "owasp": "A09:2021"},
    "CWE-020": {"name": "Improper Input Validation", "scanner": "semgrep", "severity_base": 7.5, "owasp": "A03:2021"},
    "CWE-676": {"name": "Use of Dangerous Function", "scanner": "semgrep", "severity_base": 7.5, "owasp": "A04:2021"},
    
    # Malware Detection (MALWARE-XXX)
    "MALWARE-001": {"name": "Suspicious Package", "scanner": "guarddog"},
    "MALWARE-002": {"name": "Code Pattern Match", "scanner": "malware_sast"},
    "MALWARE-003": {"name": "Behavioral Anomaly", "scanner": "sandbox"},
    
    # Vulnerability Management (CVE-XXX)
    "CVE-001": {"name": "Critical CVE", "scanner": "grype"},
    "CVE-002": {"name": "High CVE", "scanner": "grype"},
    "CVE-003": {"name": "Medium CVE", "scanner": "grype"},
    
    # Supply Chain (SUPPLY-XXX)
    "SUPPLY-001": {"name": "Phantom Dependency", "scanner": "phantom_detector"},
    "SUPPLY-002": {"name": "Typosquat Risk", "scanner": "guarddog"},
    "SUPPLY-003": {"name": "Unmaintained Package", "scanner": "obsolete_detector"},
    
    # Deployment Advisories (DEPLOY-XXX) - not in risk score
    "DEPLOY-TF": {"name": "Terraform Misconfiguration", "scanner": "deployment_advisories"},
    "DEPLOY-K8S": {"name": "Kubernetes Misconfiguration", "scanner": "deployment_advisories"},
    "DEPLOY-CICD": {"name": "CI/CD Misconfiguration", "scanner": "deployment_advisories"},
    "DEPLOY-DOCKER": {"name": "Docker Misconfiguration", "scanner": "deployment_advisories"},
}

# CWE Classification Patterns - maps rule patterns to CWE IDs
CWE_CLASSIFICATION = {
    # Injection (A03:2021)
    "CWE-079": ["xss", "cross-site", "script-injection", "reflected", "stored-xss", "dom-xss"],
    "CWE-089": ["sql", "sqli", "sql-injection", "query-injection"],
    "CWE-078": ["command-injection", "shell-injection", "os-command", "subprocess", "exec(", "system("],
    "CWE-094": ["code-injection", "eval(", "exec(", "compile(", "expression-injection"],
    # Access Control (A01:2021)
    "CWE-022": ["path-traversal", "directory-traversal", "lfi", "rfi", "file-inclusion", "../"],
    "CWE-352": ["csrf", "cross-site-request", "request-forgery"],
    "CWE-601": ["open-redirect", "url-redirect", "redirect-injection"],
    # Crypto (A02:2021)
    "CWE-327": ["weak-crypto", "des", "rc4", "broken-crypto", "insecure-cipher"],
    "CWE-328": ["md5", "sha1", "weak-hash", "broken-hash"],
    "CWE-330": ["random", "insecure-random", "predictable", "math.random", "rand("],
    # Deserialization (A08:2021)
    "CWE-502": ["deserial", "pickle", "yaml.load", "unserialize", "marshal", "objectinputstream"],
    # SSRF (A10:2021)
    "CWE-918": ["ssrf", "server-side-request", "request-forgery", "url-fetch"],
    # Misconfiguration (A05:2021)
    "CWE-016": ["config", "misconfiguration", "debug", "development-mode"],
    "CWE-250": ["missing-user", "root", "privileged", "unnecessary-privilege", "setuid"],
    "CWE-732": ["permission", "chmod", "world-writable", "insecure-permission"],
    "CWE-614": ["secure-cookie", "httponly", "cookie-flag", "session-cookie"],
    # Logging (A09:2021)
    "CWE-778": ["logging", "audit", "missing-log", "insufficient-logging"],
    "CWE-532": ["log-injection", "sensitive-log", "password-log", "credential-log"],
    # Input Validation (A03:2021)
    "CWE-020": ["input-validation", "unvalidated", "untrusted-input", "taint"],
    "CWE-676": ["dangerous-function", "unsafe", "gets(", "strcpy(", "sprintf("],
}

# Compliance Standards Mapping - maps CWE/policy IDs to compliance frameworks
COMPLIANCE_MAPPING = {
    # OWASP Top 10 2021
    "OWASP": {
        "A01:2021": {"name": "Broken Access Control", "policies": ["CWE-022", "CWE-352", "CWE-601"]},
        "A02:2021": {"name": "Cryptographic Failures", "policies": ["CWE-327", "CWE-328", "CWE-330", "SEC-001", "SEC-002"]},
        "A03:2021": {"name": "Injection", "policies": ["CWE-079", "CWE-089", "CWE-078", "CWE-094", "CWE-020"]},
        "A04:2021": {"name": "Insecure Design", "policies": ["CWE-676"]},
        "A05:2021": {"name": "Security Misconfiguration", "policies": ["CWE-016", "CWE-250", "CWE-732", "CWE-614", "DEPLOY-K8S", "DEPLOY-DOCKER"]},
        "A06:2021": {"name": "Vulnerable Components", "policies": ["CVE-001", "CVE-002", "CVE-003", "SUPPLY-003"]},
        "A07:2021": {"name": "Auth Failures", "policies": ["SEC-001", "SEC-002", "SEC-003"]},
        "A08:2021": {"name": "Software Integrity", "policies": ["CWE-502", "MALWARE-001", "MALWARE-002", "SUPPLY-002"]},
        "A09:2021": {"name": "Logging Failures", "policies": ["CWE-778", "CWE-532"]},
        "A10:2021": {"name": "SSRF", "policies": ["CWE-918"]},
    },
    # PCI DSS 4.0
    "PCI-DSS": {
        "6.2.4": {"name": "Software Security", "policies": ["CWE-079", "CWE-089", "CWE-078", "CWE-502", "CWE-676"]},
        "6.3.1": {"name": "Vulnerabilities Identified", "policies": ["CVE-001", "CVE-002", "CVE-003"]},
        "6.3.2": {"name": "Software Inventory", "policies": ["SUPPLY-001", "SUPPLY-003"]},
        "6.5.1": {"name": "Injection Flaws", "policies": ["CWE-079", "CWE-089", "CWE-078", "CWE-094"]},
        "6.5.4": {"name": "Insecure Cryptography", "policies": ["CWE-327", "CWE-328", "CWE-330"]},
        "8.3.1": {"name": "Authentication", "policies": ["SEC-001", "SEC-002", "SEC-003"]},
    },
    # SOC 2
    "SOC2": {
        "CC6.1": {"name": "Logical Access Security", "policies": ["CWE-022", "CWE-352", "SEC-001", "SEC-002"]},
        "CC6.6": {"name": "System Operations", "policies": ["CWE-016", "CWE-250", "DEPLOY-K8S"]},
        "CC7.1": {"name": "System Monitoring", "policies": ["CWE-778", "CWE-532"]},
        "CC8.1": {"name": "Change Management", "policies": ["CVE-001", "CVE-002", "SUPPLY-003"]},
    },
    # NIST 800-53 Rev 5
    "NIST-800-53": {
        "SA-11": {"name": "Developer Security Testing", "policies": ["CWE-079", "CWE-089", "CWE-078", "CWE-327", "CWE-502"]},
        "SI-2": {"name": "Flaw Remediation", "policies": ["CVE-001", "CVE-002", "CVE-003"]},
        "SI-10": {"name": "Input Validation", "policies": ["CWE-079", "CWE-089", "CWE-020"]},
        "SC-13": {"name": "Cryptographic Protection", "policies": ["CWE-327", "CWE-328", "CWE-330"]},
        "CM-6": {"name": "Configuration Settings", "policies": ["CWE-016", "CWE-250", "DEPLOY-K8S", "DEPLOY-DOCKER"]},
        "AC-6": {"name": "Least Privilege", "policies": ["CWE-250", "CWE-732"]},
    },
    # SANS/CWE Top 25
    "CWE-TOP-25": {
        "CWE-787": {"name": "Out-of-bounds Write", "policies": ["CWE-676"]},
        "CWE-79": {"name": "XSS", "policies": ["CWE-079"]},
        "CWE-89": {"name": "SQL Injection", "policies": ["CWE-089"]},
        "CWE-416": {"name": "Use After Free", "policies": ["CWE-676"]},
        "CWE-78": {"name": "OS Command Injection", "policies": ["CWE-078"]},
        "CWE-20": {"name": "Input Validation", "policies": ["CWE-020"]},
        "CWE-125": {"name": "Out-of-bounds Read", "policies": ["CWE-676"]},
        "CWE-22": {"name": "Path Traversal", "policies": ["CWE-022"]},
        "CWE-352": {"name": "CSRF", "policies": ["CWE-352"]},
        "CWE-434": {"name": "Dangerous File Upload", "policies": ["CWE-020"]},
        "CWE-502": {"name": "Deserialization", "policies": ["CWE-502"]},
        "CWE-798": {"name": "Hardcoded Credentials", "policies": ["SEC-001", "SEC-002"]},
        "CWE-918": {"name": "SSRF", "policies": ["CWE-918"]},
        "CWE-862": {"name": "Missing Authorization", "policies": ["CWE-022", "CWE-352"]},
        "CWE-306": {"name": "Missing Authentication", "policies": ["SEC-001"]},
    },
    # HIPAA
    "HIPAA": {
        "164.312(a)(1)": {"name": "Access Control", "policies": ["CWE-022", "CWE-352", "SEC-001"]},
        "164.312(a)(2)(iv)": {"name": "Encryption", "policies": ["CWE-327", "CWE-328"]},
        "164.312(b)": {"name": "Audit Controls", "policies": ["CWE-778", "CWE-532"]},
        "164.312(c)(1)": {"name": "Integrity", "policies": ["CWE-502", "MALWARE-001"]},
        "164.312(e)(1)": {"name": "Transmission Security", "policies": ["CWE-327", "CWE-614"]},
    },
    # FedRAMP (Federal Risk and Authorization Management Program)
    "FEDRAMP": {
        "AC-2": {"name": "Account Management", "policies": ["SEC-001", "SEC-002", "CWE-250"]},
        "AC-6": {"name": "Least Privilege", "policies": ["CWE-250", "CWE-732"]},
        "AU-2": {"name": "Audit Events", "policies": ["CWE-778", "CWE-532"]},
        "CA-8": {"name": "Penetration Testing", "policies": ["CWE-079", "CWE-089", "CWE-078"]},
        "CM-6": {"name": "Configuration Settings", "policies": ["CWE-016", "CWE-614", "DEPLOY-K8S"]},
        "IA-5": {"name": "Authenticator Management", "policies": ["SEC-001", "SEC-002", "SEC-003"]},
        "SC-8": {"name": "Transmission Confidentiality", "policies": ["CWE-327", "CWE-328", "CWE-614"]},
        "SC-13": {"name": "Cryptographic Protection", "policies": ["CWE-327", "CWE-328", "CWE-330"]},
        "SC-28": {"name": "Protection at Rest", "policies": ["CWE-327", "SEC-001"]},
        "SI-2": {"name": "Flaw Remediation", "policies": ["CVE-001", "CVE-002", "CVE-003"]},
        "SI-3": {"name": "Malicious Code Protection", "policies": ["MALWARE-001", "MALWARE-002", "MALWARE-003"]},
        "SI-10": {"name": "Information Input Validation", "policies": ["CWE-079", "CWE-089", "CWE-020"]},
    },
    # CMMC 2.0 (Cybersecurity Maturity Model Certification - DoD)
    "CMMC": {
        "AC.L1-3.1.1": {"name": "Authorized Access Control", "policies": ["CWE-022", "CWE-352", "SEC-001"]},
        "AC.L2-3.1.5": {"name": "Least Privilege", "policies": ["CWE-250", "CWE-732"]},
        "AU.L2-3.3.1": {"name": "System Auditing", "policies": ["CWE-778", "CWE-532"]},
        "CM.L2-3.4.1": {"name": "System Baselining", "policies": ["CWE-016", "DEPLOY-K8S", "DEPLOY-DOCKER"]},
        "IA.L1-3.5.1": {"name": "Identification", "policies": ["SEC-001", "SEC-002"]},
        "SC.L1-3.13.1": {"name": "Boundary Protection", "policies": ["CWE-918", "CWE-601"]},
        "SC.L2-3.13.11": {"name": "CUI Encryption", "policies": ["CWE-327", "CWE-328", "CWE-330"]},
        "SI.L1-3.14.1": {"name": "Flaw Remediation", "policies": ["CVE-001", "CVE-002", "CVE-003"]},
        "SI.L1-3.14.2": {"name": "Malicious Code Protection", "policies": ["MALWARE-001", "MALWARE-002"]},
        "SI.L2-3.14.6": {"name": "Security Alerts", "policies": ["CVE-001", "SUPPLY-001", "SUPPLY-002"]},
    },
    # NIST 800-171 Rev 2 (Protecting CUI in Nonfederal Systems - DoD Contractors)
    "NIST-800-171": {
        "3.1.1": {"name": "Authorized Access", "policies": ["CWE-022", "CWE-352", "SEC-001"]},
        "3.1.5": {"name": "Least Privilege", "policies": ["CWE-250", "CWE-732"]},
        "3.3.1": {"name": "System Auditing", "policies": ["CWE-778", "CWE-532"]},
        "3.4.1": {"name": "System Baselining", "policies": ["CWE-016", "DEPLOY-K8S"]},
        "3.5.1": {"name": "Identification", "policies": ["SEC-001", "SEC-002", "SEC-003"]},
        "3.13.1": {"name": "Boundary Protection", "policies": ["CWE-918", "CWE-601"]},
        "3.13.11": {"name": "CUI Encryption", "policies": ["CWE-327", "CWE-328"]},
        "3.14.1": {"name": "Flaw Remediation", "policies": ["CVE-001", "CVE-002", "CVE-003"]},
        "3.14.2": {"name": "Malicious Code Protection", "policies": ["MALWARE-001", "MALWARE-002"]},
        "3.14.6": {"name": "Security Alerts", "policies": ["CVE-001", "SUPPLY-001"]},
    },
    # DISA STIG (Defense Information Systems Agency - Security Technical Implementation Guides)
    "DISA-STIG": {
        "APP-SEC-1": {"name": "Input Validation", "policies": ["CWE-079", "CWE-089", "CWE-078", "CWE-020"]},
        "APP-SEC-2": {"name": "Output Encoding", "policies": ["CWE-079"]},
        "APP-SEC-3": {"name": "Authentication", "policies": ["SEC-001", "SEC-002", "SEC-003"]},
        "APP-SEC-4": {"name": "Session Management", "policies": ["CWE-614", "CWE-352"]},
        "APP-SEC-5": {"name": "Access Control", "policies": ["CWE-022", "CWE-250", "CWE-732"]},
        "APP-SEC-6": {"name": "Cryptographic Controls", "policies": ["CWE-327", "CWE-328", "CWE-330"]},
        "APP-SEC-7": {"name": "Error Handling", "policies": ["CWE-532", "CWE-778"]},
        "APP-SEC-8": {"name": "Data Protection", "policies": ["SEC-001", "CWE-502"]},
        "APP-SEC-9": {"name": "Communication Security", "policies": ["CWE-327", "CWE-918"]},
        "APP-SEC-10": {"name": "Malicious Code", "policies": ["MALWARE-001", "MALWARE-002", "MALWARE-003"]},
    },
    # FISMA (Federal Information Security Modernization Act)
    "FISMA": {
        "AC": {"name": "Access Control", "policies": ["CWE-022", "CWE-352", "CWE-250", "SEC-001"]},
        "AU": {"name": "Audit and Accountability", "policies": ["CWE-778", "CWE-532"]},
        "CM": {"name": "Configuration Management", "policies": ["CWE-016", "DEPLOY-K8S", "DEPLOY-DOCKER"]},
        "IA": {"name": "Identification and Authentication", "policies": ["SEC-001", "SEC-002", "SEC-003"]},
        "SC": {"name": "System and Communications Protection", "policies": ["CWE-327", "CWE-918", "CWE-614"]},
        "SI": {"name": "System and Information Integrity", "policies": ["CVE-001", "CVE-002", "MALWARE-001", "CWE-020"]},
    },
}

# =============================================================================
# DATA CLASSES
# =============================================================================

@dataclass
class Exemption:
    """Individual exemption rule"""
    id: str                          # Unique ID (e.g., EXM-001)
    type: str                        # From ExemptionType
    target: str                      # The identifier to match
    reason: str                      # From ExemptionReason
    justification: str               # Human-readable explanation
    created_by: str                  # Email or username
    created_at: datetime
    
    # Optional fields
    expires_at: Optional[datetime] = None
    approved_by: Optional[str] = None
    ticket: Optional[str] = None
    review_date: Optional[datetime] = None
    
    # Matching criteria
    file_pattern: Optional[str] = None
    package_version: Optional[str] = None
    severity: Optional[str] = None
    environment: Optional[str] = None  # prod, staging, dev
    
    # Metadata
    tags: List[str] = field(default_factory=list)
    notes: Optional[str] = None
    
    def is_expired(self) -> bool:
        """Check if exemption has expired"""
        if not self.expires_at:
            return False
        # Handle both timezone-aware and naive datetimes
        now = datetime.now()
        expires = self.expires_at
        # If expires_at is timezone-aware, make it naive for comparison
        if expires.tzinfo is not None:
            expires = expires.replace(tzinfo=None)
        return now > expires
    
    def is_valid(self) -> tuple[bool, List[str]]:
        """Validate exemption has required fields"""
        errors = []
        
        # Basic required fields
        if not self.id:
            errors.append("Missing id")
        if not self.type:
            errors.append("Missing type")
        if not self.target:
            errors.append("Missing target")
        if not self.reason:
            errors.append("Missing reason")
        if not self.justification:
            errors.append("Missing justification")
        if not self.created_by:
            errors.append("Missing created_by")
        
        # Reason-specific requirements
        try:
            reason_enum = ExemptionReason(self.reason)
            required = REASON_REQUIREMENTS.get(reason_enum, [])
            for field_name in required:
                if not getattr(self, field_name, None):
                    errors.append(f"Reason '{self.reason}' requires '{field_name}'")
        except ValueError:
            errors.append(f"Invalid reason: {self.reason}")
        
        return len(errors) == 0, errors
    
    def matches(self, 
                finding_type: str, 
                finding_id: str, 
                **kwargs) -> bool:
        """
        Check if exemption matches a finding
        
        Args:
            finding_type: Type of finding (cve, ghsa, policy, rule, package, secret)
            finding_id: The identifier to match
            **kwargs: Additional context (file_path, version, severity, etc.)
        
        Returns:
            True if exemption applies
        """
        # Check expiration
        if self.is_expired():
            return False
        
        # Check type match
        if self.type != finding_type:
            # Special case: CVE exemption also matches GHSA for same vuln
            if not (self.type == 'cve' and finding_type == 'ghsa'):
                return False
        
        # Check target match
        if not self._target_matches(finding_id):
            return False
        
        # Check file pattern
        if self.file_pattern and kwargs.get('file_path'):
            if not fnmatch.fnmatch(kwargs['file_path'], self.file_pattern):
                return False
        
        # Check package version
        if self.package_version and kwargs.get('version'):
            if self.package_version != kwargs['version']:
                return False
        
        # Check severity
        if self.severity and kwargs.get('severity'):
            if self.severity.upper() != kwargs['severity'].upper():
                return False
        
        # Check environment
        if self.environment and kwargs.get('environment'):
            if self.environment != kwargs['environment']:
                return False
        
        return True
    
    def _target_matches(self, finding_id: str) -> bool:
        """Check if target matches the finding ID"""
        # Exact match
        if self.target == finding_id:
            return True
        
        # Case-insensitive match for CVE/GHSA
        if self.type in ('cve', 'ghsa'):
            if self.target.upper() == finding_id.upper():
                return True
        
        # Wildcard match for policy/rule
        if self.type in ('policy', 'rule'):
            if fnmatch.fnmatch(finding_id, self.target):
                return True
        
        # Package with version
        if self.type == 'package' and '@' in self.target:
            pkg_name, _ = self.target.split('@', 1)
            if pkg_name == finding_id:
                return True
        
        return False
    
    def to_dict(self) -> Dict:
        """Convert to dictionary for serialization"""
        result = {
            'id': self.id,
            'type': self.type,
            'target': self.target,
            'reason': self.reason,
            'justification': self.justification,
            'created_by': self.created_by,
            'created_at': self.created_at.isoformat() + 'Z',
        }
        
        if self.expires_at:
            result['expires_at'] = self.expires_at.isoformat() + 'Z'
        if self.approved_by:
            result['approved_by'] = self.approved_by
        if self.ticket:
            result['ticket'] = self.ticket
        if self.review_date:
            result['review_date'] = self.review_date.isoformat() + 'Z'
        if self.file_pattern:
            result['file_pattern'] = self.file_pattern
        if self.package_version:
            result['package_version'] = self.package_version
        if self.severity:
            result['severity'] = self.severity
        if self.environment:
            result['environment'] = self.environment
        if self.tags:
            result['tags'] = self.tags
        if self.notes:
            result['notes'] = self.notes
        
        return result

@dataclass
class ExemptionMatch:
    """Result of an exemption match"""
    exemption: Exemption
    finding_type: str
    finding_id: str
    matched_at: datetime = field(default_factory=datetime.now)
    
    def to_dict(self) -> Dict:
        return {
            'exemption_id': self.exemption.id,
            'reason': self.exemption.reason,
            'justification': self.exemption.justification,
            'created_by': self.exemption.created_by,
            'expires_at': self.exemption.expires_at.isoformat() + 'Z' if self.exemption.expires_at else None,
            'ticket': self.exemption.ticket,
        }

# =============================================================================
# EXEMPTION MANAGER
# =============================================================================

class ExemptionManager:
    """
    Manages exemption rules for REACHABLE
    
    Supports loading from multiple file locations and formats.
    """
    
    # File search order
    DEFAULT_SEARCH_PATHS = [
        ".reachable/exemptions.yaml",
        ".reachable/exemptions.json",
        "exemptions.yaml",
        "exemptions.json",
    ]
    
    def __init__(self, 
                 exemption_file: Optional[Path] = None,
                 project_root: Optional[Path] = None):
        """
        Initialize exemption manager
        
        Args:
            exemption_file: Explicit path to exemptions file
            project_root: Project root for searching default locations
        """
        self.exemptions: List[Exemption] = []
        self.exemption_file: Optional[Path] = None
        self.load_errors: List[str] = []
        
        # Try to load exemptions
        if exemption_file:
            self._load_file(exemption_file)
        elif project_root:
            self._search_and_load(project_root)
        
        # Also check environment variable
        env_file = os.environ.get('REACHABLE_EXEMPTIONS_FILE')
        if env_file and Path(env_file).exists():
            self._load_file(Path(env_file))
        
        # Check user home
        home_file = Path.home() / '.reachable' / 'exemptions.yaml'
        if home_file.exists():
            self._load_file(home_file, merge=True)
    
    def _search_and_load(self, project_root: Path):
        """Search for exemptions file in default locations"""
        for rel_path in self.DEFAULT_SEARCH_PATHS:
            file_path = project_root / rel_path
            if file_path.exists():
                self._load_file(file_path)
                return
    
    def _load_file(self, filepath: Path, merge: bool = False):
        """Load exemptions from file"""
        try:
            if filepath.suffix in ('.yaml', '.yml'):
                if not YAML_AVAILABLE:
                    self.load_errors.append(f"YAML not available, skipping {filepath}")
                    return
                with open(filepath) as f:
                    data = yaml.safe_load(f)
            else:
                with open(filepath) as f:
                    data = json.load(f)
            
            if not merge:
                self.exemptions = []
                self.exemption_file = filepath
            
            self._parse_exemptions(data)
            logger.info(f"Loaded {len(self.exemptions)} exemptions from {filepath}")
            
        except Exception as e:
            self.load_errors.append(f"Error loading {filepath}: {e}")
            logger.warning(f"Failed to load exemptions from {filepath}: {e}")
    
    def _parse_exemptions(self, data: Dict):
        """Parse exemptions from data"""
        for exm_data in data.get('exemptions', []):
            try:
                created_at = self._parse_datetime(exm_data.get('created_at', ''))
                expires_at = self._parse_datetime(exm_data.get('expires_at')) if exm_data.get('expires_at') else None
                review_date = self._parse_datetime(exm_data.get('review_date')) if exm_data.get('review_date') else None
                
                exemption = Exemption(
                    id=exm_data['id'],
                    type=exm_data['type'],
                    target=exm_data['target'],
                    reason=exm_data['reason'],
                    justification=exm_data['justification'],
                    created_by=exm_data['created_by'],
                    created_at=created_at,
                    expires_at=expires_at,
                    approved_by=exm_data.get('approved_by'),
                    ticket=exm_data.get('ticket'),
                    review_date=review_date,
                    file_pattern=exm_data.get('file_pattern'),
                    package_version=exm_data.get('package_version'),
                    severity=exm_data.get('severity'),
                    environment=exm_data.get('environment'),
                    tags=exm_data.get('tags', []),
                    notes=exm_data.get('notes'),
                )
                
                # Validate
                is_valid, errors = exemption.is_valid()
                if not is_valid:
                    self.load_errors.append(f"Invalid exemption {exm_data.get('id')}: {errors}")
                    continue
                
                self.exemptions.append(exemption)
                
            except Exception as e:
                self.load_errors.append(f"Error parsing exemption: {e}")
    
    def _parse_datetime(self, dt_str: str) -> datetime:
        """Parse datetime string"""
        if not dt_str:
            return datetime.now()
        dt_str = dt_str.replace('Z', '+00:00')
        return datetime.fromisoformat(dt_str)
    
    def find_exemption(self, 
                       finding_type: str, 
                       finding_id: str, 
                       **kwargs) -> Optional[ExemptionMatch]:
        """
        Find matching exemption for a finding
        
        Args:
            finding_type: Type (cve, ghsa, policy, rule, package, secret)
            finding_id: Identifier
            **kwargs: Additional context
        
        Returns:
            ExemptionMatch if found, None otherwise
        """
        for exemption in self.exemptions:
            if exemption.matches(finding_type, finding_id, **kwargs):
                return ExemptionMatch(
                    exemption=exemption,
                    finding_type=finding_type,
                    finding_id=finding_id,
                )
        return None
    
    def is_exempted(self, finding_type: str, finding_id: str, **kwargs) -> bool:
        """Check if finding is exempted"""
        return self.find_exemption(finding_type, finding_id, **kwargs) is not None
    
    def get_expired(self) -> List[Exemption]:
        """Get list of expired exemptions"""
        return [e for e in self.exemptions if e.is_expired()]
    
    def get_expiring_soon(self, days: int = 30) -> List[Exemption]:
        """Get exemptions expiring within N days"""
        threshold = datetime.now() + timedelta(days=days)
        result = []
        for e in self.exemptions:
            if e.expires_at and not e.is_expired():
                expires = e.expires_at
                # Handle timezone-aware datetimes
                if expires.tzinfo is not None:
                    expires = expires.replace(tzinfo=None)
                if expires < threshold:
                    result.append(e)
        return result
    
    def get_by_type(self, exemption_type: str) -> List[Exemption]:
        """Get exemptions by type"""
        return [e for e in self.exemptions if e.type == exemption_type]
    
    def get_stats(self) -> Dict:
        """Get exemption statistics"""
        by_type = {}
        by_reason = {}
        
        for e in self.exemptions:
            by_type[e.type] = by_type.get(e.type, 0) + 1
            by_reason[e.reason] = by_reason.get(e.reason, 0) + 1
        
        return {
            'total': len(self.exemptions),
            'active': len([e for e in self.exemptions if not e.is_expired()]),
            'expired': len(self.get_expired()),
            'expiring_soon': len(self.get_expiring_soon()),
            'by_type': by_type,
            'by_reason': by_reason,
            'load_errors': self.load_errors,
        }
    
    def save(self, filepath: Optional[Path] = None):
        """Save exemptions to file"""
        filepath = filepath or self.exemption_file
        if not filepath:
            raise ValueError("No file path specified")
        
        data = {
            'version': '2.0',
            'metadata': {
                'generated_at': datetime.now().isoformat() + 'Z',
                'total_exemptions': len(self.exemptions),
            },
            'exemptions': [e.to_dict() for e in self.exemptions],
        }
        
        filepath.parent.mkdir(parents=True, exist_ok=True)
        
        if filepath.suffix in ('.yaml', '.yml') and YAML_AVAILABLE:
            with open(filepath, 'w') as f:
                yaml.dump(data, f, default_flow_style=False, sort_keys=False)
        else:
            with open(filepath, 'w') as f:
                json.dump(data, f, indent=2)

# =============================================================================
# INTEGRATION FUNCTIONS
# =============================================================================

def apply_exemptions_to_cves(cves: List[Dict], 
                             manager: ExemptionManager) -> Dict:
    """
    Apply exemptions to CVE findings
    
    Supports matching by:
    - CVE-ID (CVE-2023-1234)
    - GHSA-ID (GHSA-xxxx-xxxx-xxxx)
    - Policy ID (CVE-001, CVE-002, CVE-003)
    """
    active = []
    exempted = []
    
    for cve in cves:
        cve_id = cve.get('id', cve.get('cve_id', ''))
        ghsa_id = cve.get('ghsa_id', '')
        severity = cve.get('severity', '')
        package = cve.get('package', '')
        version = cve.get('version', '')
        
        # Determine policy ID based on severity
        policy_id = {
            'CRITICAL': 'CVE-001',
            'HIGH': 'CVE-002',
            'MEDIUM': 'CVE-003',
            'LOW': 'CVE-003',
        }.get(severity.upper(), 'CVE-003')
        
        # Check exemptions in order of specificity
        match = None
        
        # 1. Check by CVE-ID
        if cve_id:
            match = manager.find_exemption('cve', cve_id, severity=severity, package=package, version=version)
        
        # 2. Check by GHSA-ID
        if not match and ghsa_id:
            match = manager.find_exemption('ghsa', ghsa_id, severity=severity, package=package, version=version)
        
        # 3. Check by Policy ID
        if not match:
            match = manager.find_exemption('policy', policy_id, severity=severity, package=package, version=version)
        
        # 4. Check by package
        if not match and package:
            match = manager.find_exemption('package', package, version=version)
        
        if match:
            cve['exempted'] = True
            cve['exemption'] = match.to_dict()
            exempted.append(cve)
        else:
            cve['exempted'] = False
            active.append(cve)
    
    return {
        'active': active,
        'exempted': exempted,
        'total': len(cves),
        'active_count': len(active),
        'exempted_count': len(exempted),
    }

def apply_exemptions_to_secrets(secrets: List[Dict],
                                manager: ExemptionManager) -> Dict:
    """
    Apply exemptions to secret findings
    
    Supports matching by:
    - Secret hash
    - Policy ID (ENV-001, SEC-001, etc.)
    - Rule ID (semgrep rule name)
    - File pattern
    """
    active = []
    exempted = []
    
    for secret in secrets:
        # Get identifiers
        raw_secret = secret.get('raw_secret', secret.get('match', ''))
        secret_hash = hashlib.sha256(raw_secret.encode()).hexdigest()
        file_path = secret.get('path', secret.get('file', ''))
        rule_id = secret.get('rule_id', secret.get('check_id', ''))
        policy_id = secret.get('policy_id', 'ENV-001')
        severity = secret.get('severity', 'HIGH')
        
        match = None
        
        # 1. Check by secret hash (most specific)
        match = manager.find_exemption('secret', secret_hash, file_path=file_path)
        
        # 2. Check by rule ID
        if not match and rule_id:
            match = manager.find_exemption('rule', rule_id, file_path=file_path)
        
        # 3. Check by policy ID
        if not match:
            match = manager.find_exemption('policy', policy_id, file_path=file_path, severity=severity)
        
        # 4. Check by file pattern
        if not match and file_path:
            match = manager.find_exemption('file', file_path)
        
        if match:
            secret['exempted'] = True
            secret['exemption'] = match.to_dict()
            exempted.append(secret)
        else:
            secret['exempted'] = False
            active.append(secret)
    
    return {
        'active': active,
        'exempted': exempted,
        'total': len(secrets),
        'active_count': len(active),
        'exempted_count': len(exempted),
    }

def apply_exemptions_to_findings(findings: List[Dict],
                                 finding_type: str,
                                 manager: ExemptionManager) -> Dict:
    """
    Generic function to apply exemptions to any finding type
    """
    active = []
    exempted = []
    
    for finding in findings:
        finding_id = finding.get('id', finding.get('rule_id', ''))
        file_path = finding.get('file', finding.get('path', ''))
        severity = finding.get('severity', '')
        policy_id = finding.get('policy_id', '')
        
        match = manager.find_exemption(
            finding_type, 
            finding_id,
            file_path=file_path,
            severity=severity,
        )
        
        # Also check policy ID
        if not match and policy_id:
            match = manager.find_exemption('policy', policy_id, file_path=file_path)
        
        if match:
            finding['exempted'] = True
            finding['exemption'] = match.to_dict()
            exempted.append(finding)
        else:
            finding['exempted'] = False
            active.append(finding)
    
    return {
        'active': active,
        'exempted': exempted,
        'total': len(findings),
        'active_count': len(active),
        'exempted_count': len(exempted),
    }

# =============================================================================
# TEMPLATE
# =============================================================================

EXEMPTION_TEMPLATE_YAML = """# REACHABLE Exemption Configuration v2.0
# 
# Place this file at: .reachable/exemptions.yaml
#
# Supported identifier types:
#   - cve:     CVE-2023-1234
#   - ghsa:    GHSA-xxxx-xxxx-xxxx
#   - policy:  ENV-001, MALWARE-001, CVE-001, etc.
#   - rule:    semgrep.rule.name
#   - package: package-name or package-name@version
#   - secret:  SHA256 hash of secret value
#   - file:    File path pattern (glob)
#
# Supported reasons:
#   - false_positive
#   - accepted_risk (requires: approved_by)
#   - compensating_controls
#   - planned_remediation (requires: ticket, expires_at)
#   - not_applicable
#   - vendor_dispute
#   - wont_fix (requires: approved_by, review_date)
#   - test_data
#   - rotated
#   - vendored_code

version: "2.0"

metadata:
  organization: "Your Organization"
  contact: "security@yourorg.com"
  last_review: "2025-01-01"

exemptions:
  # Example: Exempt a specific CVE
  - id: "EXM-001"
    type: "cve"
    target: "CVE-2023-44487"
    reason: "compensating_controls"
    justification: "WAF blocks HTTP/2 rapid reset attacks"
    created_by: "security@example.com"
    created_at: "2025-01-01T00:00:00Z"
    expires_at: "2025-06-01T00:00:00Z"
    ticket: "JIRA-123"

  # Example: Exempt by GHSA ID
  - id: "EXM-002"
    type: "ghsa"
    target: "GHSA-jfh8-c2jp-5v3q"
    reason: "not_applicable"
    justification: "We don't use the affected feature"
    created_by: "dev@example.com"
    created_at: "2025-01-01T00:00:00Z"

  # Example: Exempt all ENV-001 findings in test files
  - id: "EXM-003"
    type: "policy"
    target: "ENV-001"
    reason: "test_data"
    justification: "Test fixtures with intentional secrets"
    file_pattern: "tests/**/*"
    created_by: "qa@example.com"
    created_at: "2025-01-01T00:00:00Z"

  # Example: Exempt a specific Semgrep rule
  - id: "EXM-004"
    type: "rule"
    target: "generic.secrets.security.detected-generic-api-key"
    reason: "false_positive"
    justification: "Pattern matches non-secret configuration values"
    file_pattern: "config/*.yaml"
    created_by: "dev@example.com"
    created_at: "2025-01-01T00:00:00Z"

  # Example: Accept risk for a package
  - id: "EXM-005"
    type: "package"
    target: "lodash@4.17.20"
    reason: "accepted_risk"
    justification: "Upgrade blocked by compatibility issues, patched in Q2"
    approved_by: "ciso@example.com"
    created_by: "security@example.com"
    created_at: "2025-01-01T00:00:00Z"
    expires_at: "2025-04-01T00:00:00Z"
    ticket: "JIRA-456"
"""

EXEMPTION_TEMPLATE_JSON = """{
  "version": "2.0",
  "metadata": {
    "organization": "Your Organization",
    "contact": "security@yourorg.com",
    "last_review": "2025-01-01"
  },
  "exemptions": [
    {
      "id": "EXM-001",
      "type": "cve",
      "target": "CVE-2023-44487",
      "reason": "compensating_controls",
      "justification": "WAF blocks HTTP/2 rapid reset attacks",
      "created_by": "security@example.com",
      "created_at": "2025-01-01T00:00:00Z",
      "expires_at": "2025-06-01T00:00:00Z",
      "ticket": "JIRA-123"
    },
    {
      "id": "EXM-002",
      "type": "ghsa",
      "target": "GHSA-jfh8-c2jp-5v3q",
      "reason": "not_applicable",
      "justification": "We don't use the affected feature",
      "created_by": "dev@example.com",
      "created_at": "2025-01-01T00:00:00Z"
    },
    {
      "id": "EXM-003",
      "type": "policy",
      "target": "ENV-001",
      "reason": "test_data",
      "justification": "Test fixtures with intentional secrets",
      "file_pattern": "tests/**/*",
      "created_by": "qa@example.com",
      "created_at": "2025-01-01T00:00:00Z"
    }
  ]
}
"""

# =============================================================================
# CLI
# =============================================================================

def print_exemption_report(manager: ExemptionManager):
    """Print exemption status report"""
    stats = manager.get_stats()
    
    print("\n" + "=" * 70)
    print("📋 EXEMPTION MANAGEMENT REPORT")
    print("=" * 70)
    
    if manager.exemption_file:
        print(f"\n📁 Loaded from: {manager.exemption_file}")
    
    if manager.load_errors:
        print(f"\n⚠️  Load errors: {len(manager.load_errors)}")
        for err in manager.load_errors[:5]:
            print(f"   • {err}")
    
    print(f"\n📊 Summary:")
    print(f"   Total exemptions:  {stats['total']}")
    print(f"   Active:            {stats['active']}")
    print(f"   Expired:           {stats['expired']}")
    print(f"   Expiring soon:     {stats['expiring_soon']} (within 30 days)")
    
    if stats['by_type']:
        print(f"\n📂 By Type:")
        for t, count in sorted(stats['by_type'].items()):
            print(f"   • {t}: {count}")
    
    if stats['by_reason']:
        print(f"\n📝 By Reason:")
        for r, count in sorted(stats['by_reason'].items()):
            print(f"   • {r}: {count}")
    
    # Show expiring soon
    expiring = manager.get_expiring_soon()
    if expiring:
        print(f"\n⚠️  Expiring Soon:")
        for e in expiring[:5]:
            days_left = (e.expires_at - datetime.now()).days
            print(f"   • {e.id}: {e.target} ({days_left} days left)")
    
    # Show expired
    expired = manager.get_expired()
    if expired:
        print(f"\n❌ Expired ({len(expired)}):")
        for e in expired[:5]:
            print(f"   • {e.id}: {e.target}")
    
    print("\n" + "=" * 70)

if __name__ == '__main__':
    import sys
    
    if len(sys.argv) < 2:
        print("REACHABLE Exemption Management v2.0")
        print()
        print("Usage:")
        print("  python exemptions.py <command> [args]")
        print()
        print("Commands:")
        print("  init <file>       Create template exemptions file (.yaml or .json)")
        print("  validate <file>   Validate exemptions file")
        print("  report <file>     Show exemption status report")
        print("  list <file>       List all exemptions")
        print("  expired <file>    Show expired exemptions")
        print("  policies          Show available policy IDs")
        print()
        print("File locations (searched in order):")
        print("  1. .reachable/exemptions.yaml")
        print("  2. .reachable/exemptions.json")
        print("  3. REACHABLE_EXEMPTIONS_FILE env var")
        print("  4. ~/.reachable/exemptions.yaml")
        print()
        sys.exit(0)
    
    command = sys.argv[1]
    
    if command == 'init':
        if len(sys.argv) < 3:
            print("Usage: python exemptions.py init <file>")
            sys.exit(1)
        
        filepath = Path(sys.argv[2])
        filepath.parent.mkdir(parents=True, exist_ok=True)
        
        if filepath.suffix in ('.yaml', '.yml'):
            filepath.write_text(EXEMPTION_TEMPLATE_YAML)
        else:
            filepath.write_text(EXEMPTION_TEMPLATE_JSON)
        
        print(f"✅ Created template: {filepath}")
    
    elif command == 'validate':
        if len(sys.argv) < 3:
            print("Usage: python exemptions.py validate <file>")
            sys.exit(1)
        
        filepath = Path(sys.argv[2])
        manager = ExemptionManager(exemption_file=filepath)
        
        if manager.load_errors:
            print(f"❌ Validation errors:")
            for err in manager.load_errors:
                print(f"   • {err}")
            sys.exit(1)
        else:
            print(f"✅ Valid exemptions file")
            print(f"   Total: {len(manager.exemptions)}")
            print(f"   Expired: {len(manager.get_expired())}")
    
    elif command == 'report':
        if len(sys.argv) < 3:
            filepath = Path('.reachable/exemptions.yaml')
        else:
            filepath = Path(sys.argv[2])
        
        manager = ExemptionManager(exemption_file=filepath)
        print_exemption_report(manager)
    
    elif command == 'list':
        if len(sys.argv) < 3:
            print("Usage: python exemptions.py list <file>")
            sys.exit(1)
        
        filepath = Path(sys.argv[2])
        manager = ExemptionManager(exemption_file=filepath)
        
        for e in manager.exemptions:
            status = "❌ EXPIRED" if e.is_expired() else "✅ ACTIVE"
            print(f"{status} {e.id}: [{e.type}] {e.target}")
            print(f"   Reason: {e.reason}")
            print(f"   By: {e.created_by}")
            if e.expires_at:
                print(f"   Expires: {e.expires_at.date()}")
            print()
    
    elif command == 'expired':
        if len(sys.argv) < 3:
            print("Usage: python exemptions.py expired <file>")
            sys.exit(1)
        
        filepath = Path(sys.argv[2])
        manager = ExemptionManager(exemption_file=filepath)
        expired = manager.get_expired()
        
        if not expired:
            print("✅ No expired exemptions")
        else:
            print(f"❌ {len(expired)} expired exemptions:")
            for e in expired:
                print(f"   {e.id}: {e.target} (expired {e.expires_at.date()})")
    
    elif command == 'policies':
        print("\n📋 REACHABLE Policy IDs\n")
        print("Use these in exemptions with type: 'policy'\n")
        
        categories = {}
        for policy_id, info in POLICY_REGISTRY.items():
            prefix = policy_id.split('-')[0]
            if prefix not in categories:
                categories[prefix] = []
            categories[prefix].append((policy_id, info))
        
        for cat, policies in sorted(categories.items()):
            print(f"{cat}:")
            for policy_id, info in policies:
                print(f"   {policy_id}: {info['name']} ({info['scanner']})")
            print()
    
    else:
        print(f"Unknown command: {command}")
        sys.exit(1)
