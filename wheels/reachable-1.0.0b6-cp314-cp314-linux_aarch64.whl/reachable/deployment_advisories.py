#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.

"""
REACHABLE Deployment Advisories Scanner (DEPLOY-ADV)

PURPOSE:
Scans for IaC and deployment configuration issues. These findings are
reported for VISIBILITY ONLY and do NOT affect the risk score.

ENFORCEMENT LIFECYCLE:
- CI/CD (Deploy Time): Checkov, tfsec, Trivy, Terrascan
- Admission (K8s Gate): OPA Gatekeeper, Kyverno, Datree  
- Runtime (Production): Falco, Tetragon, KubeArmor, Sysdig

IMPORTANT:
These are deployment-time concerns that should be enforced by admission
controllers or deploy-time tools, not at scan time.

FEATURE FLAG: --enable-config-mgt (disabled by default)
"""

import os
import re
import json
import subprocess
import time
from pathlib import Path
from typing import Dict, List, Optional, Tuple, Set, Any
from dataclasses import dataclass, field
from enum import Enum
import logging

logger = logging.getLogger(__name__)

# =============================================================================
# ENUMS
# =============================================================================

class EnforcementPoint(Enum):
    """Where this finding should be enforced"""
    CI_CD = "ci_cd"
    ADMISSION = "admission"
    RUNTIME = "runtime"
    MULTIPLE = "multiple"

class AdvisoryCategory(Enum):
    TERRAFORM = "terraform"
    KUBERNETES = "kubernetes"
    CICD = "cicd"
    DOCKER = "docker"
    CLOUDFORMATION = "cloudformation"
    HELM = "helm"

class AdvisorySeverity(Enum):
    CRITICAL = "CRITICAL"
    HIGH = "HIGH"
    MEDIUM = "MEDIUM"
    LOW = "LOW"
    INFO = "INFO"

# =============================================================================
# ENFORCEMENT TOOLS DATABASE
# =============================================================================

ENFORCEMENT_TOOLS = {
    "checkov": {
        "name": "Checkov",
        "category": "IaC Scanner",
        "point": EnforcementPoint.CI_CD,
        "description": "Policy-as-code for Terraform, K8s, Docker, CloudFormation",
        "url": "https://www.checkov.io/",
        "install": "pip install checkov",
    },
    "tfsec": {
        "name": "tfsec",
        "category": "Terraform Scanner",
        "point": EnforcementPoint.CI_CD,
        "description": "Terraform static analysis with 100+ built-in rules",
        "url": "https://aquasecurity.github.io/tfsec/",
        "install": "brew install tfsec",
    },
    "terrascan": {
        "name": "Terrascan",
        "category": "IaC Scanner",
        "point": EnforcementPoint.CI_CD,
        "description": "Detect compliance and security violations in IaC",
        "url": "https://runterrascan.io/",
        "install": "brew install terrascan",
    },
    "trivy": {
        "name": "Trivy",
        "category": "Misconfiguration Scanner",
        "point": EnforcementPoint.CI_CD,
        "description": "Scan IaC, Dockerfiles, K8s for misconfigs",
        "url": "https://aquasecurity.github.io/trivy/",
        "install": "brew install trivy",
    },
    "hadolint": {
        "name": "Hadolint",
        "category": "Dockerfile Linter",
        "point": EnforcementPoint.CI_CD,
        "description": "Dockerfile best practice linter",
        "url": "https://github.com/hadolint/hadolint",
        "install": "brew install hadolint",
    },
    "opa_gatekeeper": {
        "name": "OPA Gatekeeper",
        "category": "Admission Controller",
        "point": EnforcementPoint.ADMISSION,
        "description": "Policy controller for Kubernetes using OPA/Rego",
        "url": "https://open-policy-agent.github.io/gatekeeper/",
        "install": "kubectl apply -f https://raw.githubusercontent.com/open-policy-agent/gatekeeper/master/deploy/gatekeeper.yaml",
    },
    "kyverno": {
        "name": "Kyverno",
        "category": "Admission Controller",
        "point": EnforcementPoint.ADMISSION,
        "description": "Kubernetes native policy management (no Rego required)",
        "url": "https://kyverno.io/",
        "install": "kubectl apply -f https://github.com/kyverno/kyverno/releases/latest/download/install.yaml",
    },
    "datree": {
        "name": "Datree",
        "category": "Policy Enforcement",
        "point": EnforcementPoint.MULTIPLE,
        "description": "Prevent K8s misconfigurations from reaching production",
        "url": "https://datree.io/",
        "install": "curl https://get.datree.io | /bin/bash",
    },
    "falco": {
        "name": "Falco",
        "category": "Runtime Security",
        "point": EnforcementPoint.RUNTIME,
        "description": "Cloud-native runtime security (syscall monitoring)",
        "url": "https://falco.org/",
        "install": "helm install falco falcosecurity/falco",
    },
    "tetragon": {
        "name": "Tetragon",
        "category": "Runtime Security",
        "point": EnforcementPoint.RUNTIME,
        "description": "eBPF-based security observability and runtime enforcement",
        "url": "https://tetragon.io/",
        "install": "helm install tetragon cilium/tetragon",
    },
    "kubearmor": {
        "name": "KubeArmor",
        "category": "Runtime Security",
        "point": EnforcementPoint.RUNTIME,
        "description": "Runtime security enforcement using LSM and eBPF",
        "url": "https://kubearmor.io/",
        "install": "helm install kubearmor kubearmor/kubearmor",
    },
    "sysdig": {
        "name": "Sysdig Secure",
        "category": "Runtime Security",
        "point": EnforcementPoint.RUNTIME,
        "description": "Container security with runtime threat detection",
        "url": "https://sysdig.com/",
        "install": "Commercial - see sysdig.com",
    },
}

# Category to enforcement tools mapping
CATEGORY_ENFORCEMENT = {
    AdvisoryCategory.TERRAFORM: {
        EnforcementPoint.CI_CD: ["checkov", "tfsec", "terrascan", "trivy"],
        EnforcementPoint.ADMISSION: [],
        EnforcementPoint.RUNTIME: [],
    },
    AdvisoryCategory.KUBERNETES: {
        EnforcementPoint.CI_CD: ["checkov", "trivy", "datree"],
        EnforcementPoint.ADMISSION: ["opa_gatekeeper", "kyverno", "datree"],
        EnforcementPoint.RUNTIME: ["falco", "tetragon", "kubearmor", "sysdig"],
    },
    AdvisoryCategory.CICD: {
        EnforcementPoint.CI_CD: ["checkov"],
        EnforcementPoint.ADMISSION: [],
        EnforcementPoint.RUNTIME: [],
    },
    AdvisoryCategory.DOCKER: {
        EnforcementPoint.CI_CD: ["trivy", "checkov", "hadolint"],
        EnforcementPoint.ADMISSION: ["opa_gatekeeper", "kyverno"],
        EnforcementPoint.RUNTIME: ["falco", "sysdig"],
    },
    AdvisoryCategory.CLOUDFORMATION: {
        EnforcementPoint.CI_CD: ["checkov", "trivy"],
        EnforcementPoint.ADMISSION: [],
        EnforcementPoint.RUNTIME: [],
    },
    AdvisoryCategory.HELM: {
        EnforcementPoint.CI_CD: ["checkov", "trivy", "datree"],
        EnforcementPoint.ADMISSION: ["opa_gatekeeper", "kyverno"],
        EnforcementPoint.RUNTIME: ["falco", "tetragon"],
    },
}

# =============================================================================
# MISCONFIGURATION RULES
# =============================================================================

TERRAFORM_RULES = [
    # S3 Bucket Issues
    {
        "id": "TF-S3-001",
        "pattern": r'acl\s*=\s*"public-read"',
        "message": "S3 bucket allows public read access",
        "severity": AdvisorySeverity.CRITICAL,
        "checkov_id": "CKV_AWS_19",
    },
    {
        "id": "TF-S3-002",
        "pattern": r'acl\s*=\s*"public-read-write"',
        "message": "S3 bucket allows public read-write access",
        "severity": AdvisorySeverity.CRITICAL,
        "checkov_id": "CKV_AWS_20",
    },
    {
        "id": "TF-S3-003",
        "pattern": r'block_public_acls\s*=\s*false',
        "message": "S3 bucket public ACLs not blocked",
        "severity": AdvisorySeverity.HIGH,
    },
    {
        "id": "TF-S3-004",
        "pattern": r'block_public_policy\s*=\s*false',
        "message": "S3 bucket public policy not blocked",
        "severity": AdvisorySeverity.HIGH,
    },
    # Security Groups
    {
        "id": "TF-SG-001",
        "pattern": r'cidr_blocks\s*=\s*\[\s*"0\.0\.0\.0/0"\s*\]',
        "message": "Security group allows ingress from 0.0.0.0/0",
        "severity": AdvisorySeverity.CRITICAL,
        "checkov_id": "CKV_AWS_24",
    },
    {
        "id": "TF-SG-002",
        "pattern": r'ipv6_cidr_blocks\s*=\s*\[\s*"::/0"\s*\]',
        "message": "Security group allows ingress from ::/0",
        "severity": AdvisorySeverity.CRITICAL,
    },
    {
        "id": "TF-SG-003",
        "pattern": r'from_port\s*=\s*0\s*\n\s*to_port\s*=\s*65535',
        "message": "Security group allows all ports",
        "severity": AdvisorySeverity.CRITICAL,
    },
    # RDS
    {
        "id": "TF-RDS-001",
        "pattern": r'publicly_accessible\s*=\s*true',
        "message": "RDS instance is publicly accessible",
        "severity": AdvisorySeverity.CRITICAL,
        "checkov_id": "CKV_AWS_17",
    },
    {
        "id": "TF-RDS-002",
        "pattern": r'storage_encrypted\s*=\s*false',
        "message": "RDS storage encryption disabled",
        "severity": AdvisorySeverity.HIGH,
        "checkov_id": "CKV_AWS_16",
    },
    {
        "id": "TF-RDS-003",
        "pattern": r'deletion_protection\s*=\s*false',
        "message": "RDS deletion protection disabled",
        "severity": AdvisorySeverity.MEDIUM,
    },
    # IAM
    {
        "id": "TF-IAM-001",
        "pattern": r'"Action"\s*:\s*"\*"',
        "message": "IAM policy allows all actions (*)",
        "severity": AdvisorySeverity.CRITICAL,
        "checkov_id": "CKV_AWS_1",
    },
    {
        "id": "TF-IAM-002",
        "pattern": r'"Resource"\s*:\s*"\*"',
        "message": "IAM policy applies to all resources (*)",
        "severity": AdvisorySeverity.HIGH,
    },
    {
        "id": "TF-IAM-003",
        "pattern": r'arn:aws:iam::aws:policy/AdministratorAccess',
        "message": "IAM role attached AdministratorAccess policy",
        "severity": AdvisorySeverity.HIGH,
    },
    # EC2
    {
        "id": "TF-EC2-001",
        "pattern": r'http_tokens\s*=\s*"optional"',
        "message": "EC2 instance allows IMDSv1 (SSRF risk)",
        "severity": AdvisorySeverity.HIGH,
        "checkov_id": "CKV_AWS_79",
    },
    {
        "id": "TF-EC2-002",
        "pattern": r'associate_public_ip_address\s*=\s*true',
        "message": "EC2 instance has public IP",
        "severity": AdvisorySeverity.MEDIUM,
    },
    # KMS
    {
        "id": "TF-KMS-001",
        "pattern": r'enable_key_rotation\s*=\s*false',
        "message": "KMS key rotation disabled",
        "severity": AdvisorySeverity.MEDIUM,
        "checkov_id": "CKV_AWS_7",
    },
    # ELB
    {
        "id": "TF-ELB-001",
        "pattern": r'ssl_policy\s*=\s*"ELBSecurityPolicy-2016-08"',
        "message": "Load balancer using weak SSL policy",
        "severity": AdvisorySeverity.HIGH,
    },
    {
        "id": "TF-ELB-002",
        "pattern": r'ssl_policy\s*=\s*"ELBSecurityPolicy-TLS-1-0"',
        "message": "Load balancer using TLS 1.0",
        "severity": AdvisorySeverity.CRITICAL,
    },
]

KUBERNETES_RULES = [
    # Pod Security
    {
        "id": "K8S-POD-001",
        "pattern": r'privileged:\s*true',
        "message": "Container running in privileged mode",
        "severity": AdvisorySeverity.CRITICAL,
        "checkov_id": "CKV_K8S_1",
    },
    {
        "id": "K8S-POD-002",
        "pattern": r'hostNetwork:\s*true',
        "message": "Pod using host network namespace",
        "severity": AdvisorySeverity.CRITICAL,
        "checkov_id": "CKV_K8S_19",
    },
    {
        "id": "K8S-POD-003",
        "pattern": r'hostPID:\s*true',
        "message": "Pod using host PID namespace",
        "severity": AdvisorySeverity.CRITICAL,
        "checkov_id": "CKV_K8S_17",
    },
    {
        "id": "K8S-POD-004",
        "pattern": r'hostIPC:\s*true',
        "message": "Pod using host IPC namespace",
        "severity": AdvisorySeverity.CRITICAL,
    },
    {
        "id": "K8S-POD-005",
        "pattern": r'runAsUser:\s*0',
        "message": "Container running as root (UID 0)",
        "severity": AdvisorySeverity.HIGH,
        "checkov_id": "CKV_K8S_6",
    },
    {
        "id": "K8S-POD-006",
        "pattern": r'runAsNonRoot:\s*false',
        "message": "Container allows running as root",
        "severity": AdvisorySeverity.HIGH,
    },
    {
        "id": "K8S-POD-007",
        "pattern": r'readOnlyRootFilesystem:\s*false',
        "message": "Container has writable root filesystem",
        "severity": AdvisorySeverity.MEDIUM,
        "checkov_id": "CKV_K8S_22",
    },
    {
        "id": "K8S-POD-008",
        "pattern": r'allowPrivilegeEscalation:\s*true',
        "message": "Container allows privilege escalation",
        "severity": AdvisorySeverity.HIGH,
        "checkov_id": "CKV_K8S_20",
    },
    # Capabilities
    {
        "id": "K8S-CAP-001",
        "pattern": r'add:\s*\[.*SYS_ADMIN.*\]',
        "message": "Container adding SYS_ADMIN capability",
        "severity": AdvisorySeverity.CRITICAL,
        "checkov_id": "CKV_K8S_25",
    },
    {
        "id": "K8S-CAP-002",
        "pattern": r'add:\s*\[.*NET_ADMIN.*\]',
        "message": "Container adding NET_ADMIN capability",
        "severity": AdvisorySeverity.HIGH,
    },
    {
        "id": "K8S-CAP-003",
        "pattern": r'add:\s*\[.*ALL.*\]',
        "message": "Container adding ALL capabilities",
        "severity": AdvisorySeverity.CRITICAL,
    },
    # RBAC
    {
        "id": "K8S-RBAC-001",
        "pattern": r'kind:\s*ClusterRoleBinding[\s\S]*?cluster-admin',
        "message": "ClusterRoleBinding to cluster-admin",
        "severity": AdvisorySeverity.CRITICAL,
    },
    {
        "id": "K8S-RBAC-002",
        "pattern": r'verbs:\s*\[\s*["\']?\*["\']?\s*\]',
        "message": "RBAC rule allows all verbs (*)",
        "severity": AdvisorySeverity.HIGH,
    },
    {
        "id": "K8S-RBAC-003",
        "pattern": r'resources:\s*\[\s*["\']?\*["\']?\s*\]',
        "message": "RBAC rule applies to all resources (*)",
        "severity": AdvisorySeverity.HIGH,
    },
    # Images
    {
        "id": "K8S-IMG-001",
        "pattern": r'image:\s*[^:]+:latest',
        "message": "Image using :latest tag (unpinned)",
        "severity": AdvisorySeverity.MEDIUM,
        "checkov_id": "CKV_K8S_14",
    },
    {
        "id": "K8S-IMG-002",
        "pattern": r'imagePullPolicy:\s*Never',
        "message": "Image pull policy set to Never",
        "severity": AdvisorySeverity.LOW,
    },
    # Service Account
    {
        "id": "K8S-SA-001",
        "pattern": r'automountServiceAccountToken:\s*true',
        "message": "Service account token auto-mounted",
        "severity": AdvisorySeverity.MEDIUM,
        "checkov_id": "CKV_K8S_21",
    },
]

CICD_RULES = [
    # GitHub Actions
    {
        "id": "GHA-001",
        "pattern": r'on:\s*pull_request_target',
        "message": "pull_request_target can execute untrusted code with secrets",
        "severity": AdvisorySeverity.CRITICAL,
    },
    {
        "id": "GHA-002",
        "pattern": r'pull_request_target[\s\S]*?ref:\s*\$\{\{\s*github\.event\.pull_request\.head',
        "message": "Checking out untrusted PR code with secrets access (pwn request)",
        "severity": AdvisorySeverity.CRITICAL,
    },
    {
        "id": "GHA-003",
        "pattern": r'run:.*\$\{\{\s*github\.event\.(issue|comment|pull_request)\.(body|title)',
        "message": "Script injection via untrusted input in run command",
        "severity": AdvisorySeverity.CRITICAL,
    },
    {
        "id": "GHA-004",
        "pattern": r'run:.*\$\{\{\s*github\.head_ref',
        "message": "Script injection via github.head_ref",
        "severity": AdvisorySeverity.HIGH,
    },
    {
        "id": "GHA-005",
        "pattern": r'permissions:\s*write-all',
        "message": "Workflow uses write-all permissions",
        "severity": AdvisorySeverity.HIGH,
    },
    {
        "id": "GHA-006",
        "pattern": r'uses:\s*[^@]+@(main|master|latest)\s*$',
        "message": "Action not pinned to SHA (supply chain risk)",
        "severity": AdvisorySeverity.MEDIUM,
    },
    {
        "id": "GHA-007",
        "pattern": r'runs-on:\s*self-hosted',
        "message": "Self-hosted runner may execute untrusted code",
        "severity": AdvisorySeverity.MEDIUM,
    },
    # GitLab CI
    {
        "id": "GLB-001",
        "pattern": r'include:\s*-\s*remote:',
        "message": "Including remote CI config (supply chain risk)",
        "severity": AdvisorySeverity.HIGH,
    },
    # Jenkins
    {
        "id": "JNK-001",
        "pattern": r'@Grab',
        "message": "Groovy @Grab may bypass sandbox",
        "severity": AdvisorySeverity.CRITICAL,
    },
    {
        "id": "JNK-002",
        "pattern": r'evaluate\s*\(',
        "message": "Groovy evaluate() may bypass sandbox",
        "severity": AdvisorySeverity.CRITICAL,
    },
    # Generic
    {
        "id": "CICD-001",
        "pattern": r'(password|secret|token|api_key):\s*["\'][^"\']+["\']',
        "message": "Hardcoded secret in CI/CD config",
        "severity": AdvisorySeverity.CRITICAL,
    },
]

DOCKER_RULES = [
    # Dockerfile
    {
        "id": "DOC-001",
        "pattern": r'^FROM\s+\S+:latest',
        "message": "Base image using :latest tag",
        "severity": AdvisorySeverity.MEDIUM,
        "checkov_id": "CKV_DOCKER_7",
    },
    {
        "id": "DOC-002",
        "pattern": r'USER\s+root\s*$',
        "message": "Container explicitly running as root",
        "severity": AdvisorySeverity.HIGH,
        "checkov_id": "CKV_DOCKER_3",
    },
    {
        "id": "DOC-003",
        "pattern": r'^ADD\s+https?://',
        "message": "ADD used with URL (use COPY + curl instead)",
        "severity": AdvisorySeverity.MEDIUM,
        "checkov_id": "CKV_DOCKER_10",
    },
    {
        "id": "DOC-004",
        "pattern": r'curl.*\|\s*(ba)?sh',
        "message": "Piping remote script to shell",
        "severity": AdvisorySeverity.HIGH,
        "checkov_id": "CKV_DOCKER_1",
    },
    {
        "id": "DOC-005",
        "pattern": r'wget.*\|\s*(ba)?sh',
        "message": "Piping remote script to shell",
        "severity": AdvisorySeverity.HIGH,
    },
    {
        "id": "DOC-006",
        "pattern": r'^ENV\s+(PASSWORD|SECRET|KEY|TOKEN|CRED)\s*=',
        "message": "Sensitive value in ENV instruction",
        "severity": AdvisorySeverity.HIGH,
    },
    {
        "id": "DOC-007",
        "pattern": r'EXPOSE\s+(22|23|3389|5900)\s*$',
        "message": "Exposing potentially dangerous port (SSH/Telnet/RDP/VNC)",
        "severity": AdvisorySeverity.MEDIUM,
    },
    {
        "id": "DOC-008",
        "pattern": r'(apt-get|apk|yum)\s+install.*sudo',
        "message": "sudo installed in container",
        "severity": AdvisorySeverity.MEDIUM,
        "checkov_id": "CKV_DOCKER_6",
    },
    # Docker Compose
    {
        "id": "DCP-001",
        "pattern": r'privileged:\s*true',
        "message": "Service running in privileged mode",
        "severity": AdvisorySeverity.CRITICAL,
    },
    {
        "id": "DCP-002",
        "pattern": r'/var/run/docker\.sock',
        "message": "Docker socket mounted (container escape risk)",
        "severity": AdvisorySeverity.CRITICAL,
    },
    {
        "id": "DCP-003",
        "pattern": r'volumes:[\s\S]*?-\s*/:',
        "message": "Root filesystem mounted in container",
        "severity": AdvisorySeverity.CRITICAL,
    },
    {
        "id": "DCP-004",
        "pattern": r'cap_add:[\s\S]*?-\s*(SYS_ADMIN|NET_ADMIN|ALL)',
        "message": "Dangerous capability added to container",
        "severity": AdvisorySeverity.CRITICAL,
    },
    {
        "id": "DCP-005",
        "pattern": r'network_mode:\s*["\']?host["\']?',
        "message": "Container using host network mode",
        "severity": AdvisorySeverity.HIGH,
    },
    {
        "id": "DCP-006",
        "pattern": r'pid:\s*["\']?host["\']?',
        "message": "Container using host PID namespace",
        "severity": AdvisorySeverity.HIGH,
    },
]

# =============================================================================
# DATA CLASSES
# =============================================================================

@dataclass
class DeploymentAdvisory:
    """Advisory finding - NOT included in risk score"""
    file_path: str
    line_number: int
    rule_id: str
    category: AdvisoryCategory
    message: str
    severity: AdvisorySeverity
    enforcement_point: EnforcementPoint = EnforcementPoint.CI_CD
    checkov_id: Optional[str] = None
    
    # Explicitly NOT contributing to risk
    affects_risk_score: bool = False
    
    def to_dict(self) -> Dict:
        tools = CATEGORY_ENFORCEMENT.get(self.category, {})
        enforcement_tools = []
        for point, tool_list in tools.items():
            enforcement_tools.extend(tool_list)
        
        return {
            "file": self.file_path,
            "line": self.line_number,
            "rule_id": self.rule_id,
            "category": self.category.value,
            "message": self.message,
            "severity": self.severity.value,
            "affects_risk_score": self.affects_risk_score,
            "checkov_id": self.checkov_id,
            "enforcement": {
                "recommended_point": self.enforcement_point.value,
                "tools": [ENFORCEMENT_TOOLS[t]["name"] for t in enforcement_tools[:3] if t in ENFORCEMENT_TOOLS],
            },
        }

@dataclass
class DeploymentAdvisoriesResult:
    """Results that are explicitly NOT part of risk calculation"""
    
    advisories: List[DeploymentAdvisory] = field(default_factory=list)
    source: str = "basic"  # "checkov" or "basic"
    scan_time_ms: float = 0.0
    
    # Categorized counts
    by_category: Dict[str, int] = field(default_factory=dict)
    by_severity: Dict[str, int] = field(default_factory=dict)
    by_enforcement_point: Dict[str, int] = field(default_factory=dict)
    
    # Files scanned
    files_scanned: int = 0
    
    # Explicit flag - ALWAYS False
    included_in_risk: bool = False
    
    def to_dict(self) -> Dict:
        return {
            "policy": "DEPLOY-ADV",
            "version": "1.0.0",
            "included_in_risk_score": False,
            "disclaimer": {
                "short": "Not in risk score - enforce at appropriate lifecycle stage",
                "full": (
                    "These findings are infrastructure and deployment configuration issues. "
                    "REACHABLE focuses on application security (CVEs, secrets, malware, reachability). "
                    "Deploy-time issues should be enforced by CI/CD gates (Checkov, tfsec), "
                    "admission controllers (OPA Gatekeeper, Kyverno), and runtime security (Falco, Tetragon)."
                ),
            },
            "source": self.source,
            "scan_time_ms": self.scan_time_ms,
            "files_scanned": self.files_scanned,
            "summary": {
                "total": len(self.advisories),
                "by_category": self.by_category,
                "by_severity": self.by_severity,
                "by_enforcement_point": self.by_enforcement_point,
            },
            "enforcement_lifecycle": self._get_enforcement_lifecycle(),
            "advisories": [a.to_dict() for a in self.advisories],
        }
    
    def _get_enforcement_lifecycle(self) -> Dict:
        return {
            "ci_cd": {
                "stage": "Deploy Time",
                "purpose": "Block misconfigurations before deployment",
                "tools": [
                    {"name": "Checkov", "url": "https://checkov.io", "install": "pip install checkov"},
                    {"name": "tfsec", "url": "https://aquasecurity.github.io/tfsec/", "install": "brew install tfsec"},
                    {"name": "Trivy", "url": "https://aquasecurity.github.io/trivy/", "install": "brew install trivy"},
                ],
                "finding_count": self.by_enforcement_point.get("ci_cd", 0),
            },
            "admission": {
                "stage": "Kubernetes Admission",
                "purpose": "Block/mutate workloads at cluster entry",
                "tools": [
                    {"name": "OPA Gatekeeper", "url": "https://open-policy-agent.github.io/gatekeeper/"},
                    {"name": "Kyverno", "url": "https://kyverno.io/"},
                    {"name": "Datree", "url": "https://datree.io/"},
                ],
                "finding_count": self.by_enforcement_point.get("admission", 0),
            },
            "runtime": {
                "stage": "Production Runtime",
                "purpose": "Detect anomalies and threats in running workloads",
                "tools": [
                    {"name": "Falco", "url": "https://falco.org/"},
                    {"name": "Tetragon", "url": "https://tetragon.io/"},
                    {"name": "KubeArmor", "url": "https://kubearmor.io/"},
                ],
                "finding_count": self.by_enforcement_point.get("runtime", 0),
            },
        }

# =============================================================================
# FILE PATTERNS
# =============================================================================

FILE_PATTERNS = {
    AdvisoryCategory.TERRAFORM: [
        "*.tf", "*.tfvars", "*.tf.json",
    ],
    AdvisoryCategory.KUBERNETES: [
        "*.yaml", "*.yml",  # Will filter by content
    ],
    AdvisoryCategory.CICD: [
        ".github/workflows/*.yml", ".github/workflows/*.yaml",
        ".gitlab-ci.yml", ".gitlab-ci.yaml",
        "Jenkinsfile", "jenkinsfile",
        ".travis.yml", ".travis.yaml",
        "azure-pipelines.yml", "azure-pipelines.yaml",
        "bitbucket-pipelines.yml",
        ".circleci/config.yml",
    ],
    AdvisoryCategory.DOCKER: [
        "Dockerfile", "Dockerfile.*", "*.dockerfile",
        "docker-compose.yml", "docker-compose.yaml",
        "docker-compose.*.yml", "docker-compose.*.yaml",
        "compose.yml", "compose.yaml",
    ],
    AdvisoryCategory.CLOUDFORMATION: [
        "*.template", "*.template.json", "*.template.yaml",
        "cloudformation/*.yml", "cloudformation/*.yaml", "cloudformation/*.json",
    ],
    AdvisoryCategory.HELM: [
        "Chart.yaml", "values.yaml", "values.*.yaml",
        "templates/*.yaml", "templates/*.yml",
    ],
}

# =============================================================================
# SCANNER CLASS
# =============================================================================

class DeploymentAdvisoriesScanner:
    """
    Scans for IaC/deployment misconfigurations.
    
    IMPORTANT: These findings are ADVISORY ONLY and do NOT
    contribute to the REACHABLE risk score.
    
    Feature flag: --enable-config-mgt (disabled by default)
    """
    
    def __init__(self, 
                 use_checkov: bool = False,
                 scan_terraform: bool = True,
                 scan_kubernetes: bool = True,
                 scan_cicd: bool = True,
                 scan_docker: bool = True,
                 max_file_size_kb: int = 1024):
        self.use_checkov = use_checkov
        self.checkov_available = self._check_checkov() if use_checkov else False
        self.scan_terraform = scan_terraform
        self.scan_kubernetes = scan_kubernetes
        self.scan_cicd = scan_cicd
        self.scan_docker = scan_docker
        self.max_file_size = max_file_size_kb * 1024
    
    def _check_checkov(self) -> bool:
        """Check if Checkov is available"""
        try:
            result = subprocess.run(
                ["checkov", "--version"],
                capture_output=True,
                timeout=10,
            )
            return result.returncode == 0
        except Exception:
            return False
    
    def scan(self, target_dir: Path) -> DeploymentAdvisoriesResult:
        """Scan for deployment advisories"""
        start_time = time.time()
        result = DeploymentAdvisoriesResult()
        target_dir = Path(target_dir)
        
        if not target_dir.exists():
            return result
        
        # Find files to scan
        files_by_category = self._find_files(target_dir)
        result.files_scanned = sum(len(files) for files in files_by_category.values())
        
        # Use Checkov if available
        if self.use_checkov and self.checkov_available:
            result.advisories.extend(self._run_checkov(target_dir))
            result.source = "checkov"
        else:
            # Use built-in pattern matching
            result.advisories.extend(self._pattern_scan(files_by_category))
            result.source = "basic"
        
        # Aggregate stats
        for advisory in result.advisories:
            # By category
            cat = advisory.category.value
            result.by_category[cat] = result.by_category.get(cat, 0) + 1
            
            # By severity
            sev = advisory.severity.value
            result.by_severity[sev] = result.by_severity.get(sev, 0) + 1
            
            # By enforcement point - all findings apply to CI/CD at minimum
            result.by_enforcement_point["ci_cd"] = result.by_enforcement_point.get("ci_cd", 0) + 1
            
            # K8s and Docker findings also apply to admission and runtime
            if advisory.category in (AdvisoryCategory.KUBERNETES, AdvisoryCategory.DOCKER):
                result.by_enforcement_point["admission"] = result.by_enforcement_point.get("admission", 0) + 1
                result.by_enforcement_point["runtime"] = result.by_enforcement_point.get("runtime", 0) + 1
        
        result.scan_time_ms = (time.time() - start_time) * 1000
        return result
    
    def _find_files(self, target_dir: Path) -> Dict[AdvisoryCategory, List[Path]]:
        """Find files to scan by category"""
        files = {cat: [] for cat in AdvisoryCategory}
        
        for root, dirs, filenames in os.walk(target_dir):
            # Skip .git directory
            if '.git' in dirs:
                dirs.remove('.git')
            if 'node_modules' in dirs:
                dirs.remove('node_modules')
            if 'vendor' in dirs:
                dirs.remove('vendor')
            
            root_path = Path(root)
            
            for filename in filenames:
                file_path = root_path / filename
                rel_path = str(file_path.relative_to(target_dir))
                
                # Check file size
                try:
                    if file_path.stat().st_size > self.max_file_size:
                        continue
                except OSError:
                    continue
                
                # Categorize file
                category = self._categorize_file(filename, rel_path, file_path)
                if category and self._should_scan_category(category):
                    files[category].append(file_path)
        
        return files
    
    def _categorize_file(self, filename: str, rel_path: str, file_path: Path) -> Optional[AdvisoryCategory]:
        """Determine file category"""
        import fnmatch
        
        # Terraform
        if filename.endswith('.tf') or filename.endswith('.tfvars'):
            return AdvisoryCategory.TERRAFORM
        
        # Docker
        if filename.lower().startswith('dockerfile') or filename.endswith('.dockerfile'):
            return AdvisoryCategory.DOCKER
        if 'docker-compose' in filename.lower() or filename in ('compose.yml', 'compose.yaml'):
            return AdvisoryCategory.DOCKER
        
        # CI/CD
        if '.github/workflows/' in rel_path:
            return AdvisoryCategory.CICD
        if filename in ('.gitlab-ci.yml', '.gitlab-ci.yaml', '.travis.yml', 'Jenkinsfile', 'jenkinsfile'):
            return AdvisoryCategory.CICD
        if 'azure-pipelines' in filename or 'bitbucket-pipelines' in filename:
            return AdvisoryCategory.CICD
        if '.circleci/' in rel_path and filename.endswith('.yml'):
            return AdvisoryCategory.CICD
        
        # Helm
        if filename in ('Chart.yaml', 'values.yaml') or 'values.' in filename:
            if '/templates/' not in rel_path:  # templates/*.yaml are K8s manifests
                return AdvisoryCategory.HELM
        
        # Kubernetes (YAML files with K8s markers)
        if filename.endswith(('.yaml', '.yml')):
            try:
                content = file_path.read_text(errors='ignore')[:2000]
                if any(marker in content for marker in ['apiVersion:', 'kind: Deployment', 'kind: Pod', 'kind: Service', 'kind: ConfigMap', 'kind: Secret', 'kind: Role', 'kind: ClusterRole']):
                    return AdvisoryCategory.KUBERNETES
            except Exception:
                pass
        
        # CloudFormation
        if filename.endswith('.template') or 'cloudformation' in rel_path.lower():
            return AdvisoryCategory.CLOUDFORMATION
        
        return None
    
    def _should_scan_category(self, category: AdvisoryCategory) -> bool:
        """Check if category should be scanned"""
        if category == AdvisoryCategory.TERRAFORM:
            return self.scan_terraform
        if category == AdvisoryCategory.KUBERNETES:
            return self.scan_kubernetes
        if category == AdvisoryCategory.CICD:
            return self.scan_cicd
        if category == AdvisoryCategory.DOCKER:
            return self.scan_docker
        return True
    
    def _pattern_scan(self, files_by_category: Dict[AdvisoryCategory, List[Path]]) -> List[DeploymentAdvisory]:
        """Scan files using pattern matching"""
        advisories = []
        
        # Terraform
        for file_path in files_by_category.get(AdvisoryCategory.TERRAFORM, []):
            advisories.extend(self._scan_file(file_path, AdvisoryCategory.TERRAFORM, TERRAFORM_RULES))
        
        # Kubernetes
        for file_path in files_by_category.get(AdvisoryCategory.KUBERNETES, []):
            advisories.extend(self._scan_file(file_path, AdvisoryCategory.KUBERNETES, KUBERNETES_RULES))
        
        # CI/CD
        for file_path in files_by_category.get(AdvisoryCategory.CICD, []):
            advisories.extend(self._scan_file(file_path, AdvisoryCategory.CICD, CICD_RULES))
        
        # Docker
        for file_path in files_by_category.get(AdvisoryCategory.DOCKER, []):
            advisories.extend(self._scan_file(file_path, AdvisoryCategory.DOCKER, DOCKER_RULES))
        
        # Helm (use K8s rules)
        for file_path in files_by_category.get(AdvisoryCategory.HELM, []):
            advisories.extend(self._scan_file(file_path, AdvisoryCategory.HELM, KUBERNETES_RULES))
        
        return advisories
    
    def _scan_file(self, file_path: Path, category: AdvisoryCategory, rules: List[Dict]) -> List[DeploymentAdvisory]:
        """Scan a single file against rules"""
        advisories = []
        
        try:
            content = file_path.read_text(errors='ignore')
        except Exception:
            return advisories
        
        lines = content.split('\n')
        
        for rule in rules:
            pattern = rule["pattern"]
            try:
                regex = re.compile(pattern, re.MULTILINE | re.IGNORECASE)
            except re.error:
                continue
            
            for match in regex.finditer(content):
                # Find line number
                line_num = content[:match.start()].count('\n') + 1
                
                # Determine enforcement point based on category
                if category in (AdvisoryCategory.KUBERNETES, AdvisoryCategory.DOCKER, AdvisoryCategory.HELM):
                    enforcement = EnforcementPoint.MULTIPLE
                else:
                    enforcement = EnforcementPoint.CI_CD
                
                advisory = DeploymentAdvisory(
                    file_path=str(file_path),
                    line_number=line_num,
                    rule_id=rule["id"],
                    category=category,
                    message=rule["message"],
                    severity=rule["severity"],
                    enforcement_point=enforcement,
                    checkov_id=rule.get("checkov_id"),
                    affects_risk_score=False,
                )
                advisories.append(advisory)
        
        return advisories
    
    def _run_checkov(self, target_dir: Path) -> List[DeploymentAdvisory]:
        """Run Checkov and parse results"""
        advisories = []
        
        try:
            result = subprocess.run(
                [
                    "checkov",
                    "-d", str(target_dir),
                    "-o", "json",
                    "--quiet",
                    "--compact",
                    "--framework", "terraform,kubernetes,dockerfile,github_actions,gitlab_ci,helm",
                ],
                capture_output=True,
                text=True,
                timeout=300,
            )
            
            if result.stdout:
                try:
                    data = json.loads(result.stdout)
                    for check in data.get("results", {}).get("failed_checks", []):
                        category = self._map_checkov_framework(check.get("check_type", ""))
                        if not category:
                            continue
                        
                        advisories.append(DeploymentAdvisory(
                            file_path=check.get("file_path", "unknown"),
                            line_number=check.get("file_line_range", [0])[0],
                            rule_id=check.get("check_id", "unknown"),
                            category=category,
                            message=check.get("check_name", "Unknown check"),
                            severity=self._map_checkov_severity(check.get("severity", "MEDIUM")),
                            checkov_id=check.get("check_id"),
                            affects_risk_score=False,
                        ))
                except json.JSONDecodeError:
                    logger.warning("Failed to parse Checkov output")
        except subprocess.TimeoutExpired:
            logger.warning("Checkov timed out")
        except Exception as e:
            logger.warning(f"Checkov failed: {e}")
        
        return advisories
    
    def _map_checkov_framework(self, framework: str) -> Optional[AdvisoryCategory]:
        """Map Checkov framework to category"""
        mapping = {
            "terraform": AdvisoryCategory.TERRAFORM,
            "kubernetes": AdvisoryCategory.KUBERNETES,
            "dockerfile": AdvisoryCategory.DOCKER,
            "github_actions": AdvisoryCategory.CICD,
            "gitlab_ci": AdvisoryCategory.CICD,
            "helm": AdvisoryCategory.HELM,
            "cloudformation": AdvisoryCategory.CLOUDFORMATION,
        }
        return mapping.get(framework.lower())
    
    def _map_checkov_severity(self, severity: str) -> AdvisorySeverity:
        """Map Checkov severity to our severity"""
        mapping = {
            "CRITICAL": AdvisorySeverity.CRITICAL,
            "HIGH": AdvisorySeverity.HIGH,
            "MEDIUM": AdvisorySeverity.MEDIUM,
            "LOW": AdvisorySeverity.LOW,
            "INFO": AdvisorySeverity.INFO,
        }
        return mapping.get(severity.upper(), AdvisorySeverity.MEDIUM)

# =============================================================================
# CLI OUTPUT
# =============================================================================

def print_advisories(result: DeploymentAdvisoriesResult, verbose: bool = False):
    """Print advisories to console"""
    print("\n" + "═" * 74)
    print("⚠️  DEPLOYMENT ADVISORIES (NOT in risk score)")
    print("═" * 74)
    
    print("""
   ╭───────────────────────────────────────────────────────────────────────╮
   │ These are IaC/deployment configs - enforce at the right stage:       │
   │                                                                       │
   │  🔨 CI/CD           🚧 ADMISSION          👁️ RUNTIME                  │
   │  ──────────────     ──────────────        ───────────────             │
   │  Checkov            OPA Gatekeeper        Falco                       │
   │  tfsec              Kyverno               Tetragon                    │
   │  Trivy              Datree                KubeArmor                   │
   │                                                                       │
   │  Block before       Block at cluster      Detect anomalies            │
   │  deploy             admission             in production               │
   ╰───────────────────────────────────────────────────────────────────────╯
""")
    
    print(f"📁 Files scanned: {result.files_scanned}")
    print(f"⚠️  Total advisories: {len(result.advisories)}")
    print(f"📊 Source: {result.source}")
    
    if result.by_category:
        print(f"\n📂 By Category:")
        for cat, count in sorted(result.by_category.items()):
            enforcement = CATEGORY_ENFORCEMENT.get(AdvisoryCategory(cat), {})
            cicd_tools = enforcement.get(EnforcementPoint.CI_CD, [])[:2]
            admission_tools = enforcement.get(EnforcementPoint.ADMISSION, [])[:2]
            runtime_tools = enforcement.get(EnforcementPoint.RUNTIME, [])[:2]
            
            cicd_str = ", ".join([ENFORCEMENT_TOOLS[t]["name"] for t in cicd_tools]) or "-"
            adm_str = ", ".join([ENFORCEMENT_TOOLS[t]["name"] for t in admission_tools]) or "-"
            run_str = ", ".join([ENFORCEMENT_TOOLS[t]["name"] for t in runtime_tools]) or "-"
            
            print(f"   • {cat}: {count}")
            print(f"     └─ CI/CD: {cicd_str} | Admission: {adm_str} | Runtime: {run_str}")
    
    if result.by_severity:
        print(f"\n📊 By Severity:")
        for sev in ["CRITICAL", "HIGH", "MEDIUM", "LOW", "INFO"]:
            count = result.by_severity.get(sev, 0)
            if count:
                icon = {"CRITICAL": "🔴", "HIGH": "🟠", "MEDIUM": "🟡", "LOW": "🔵", "INFO": "⚪"}.get(sev, "⚪")
                print(f"   {icon} {sev}: {count}")
    
    if verbose and result.advisories:
        print(f"\n📋 Top Issues:")
        for adv in result.advisories[:10]:
            sev_icon = {"CRITICAL": "🔴", "HIGH": "🟠", "MEDIUM": "🟡", "LOW": "🔵", "INFO": "⚪"}.get(adv.severity.value, "⚪")
            print(f"   {sev_icon} {adv.file_path}:{adv.line_number}")
            print(f"      {adv.message}")
            if adv.checkov_id:
                print(f"      Checkov: {adv.checkov_id}")
        
        if len(result.advisories) > 10:
            print(f"\n   ... and {len(result.advisories) - 10} more advisories")
    
    print(f"\n⏱️  Scan time: {result.scan_time_ms:.2f}ms")
    print("═" * 74)

# =============================================================================
# CLI / MAIN
# =============================================================================

if __name__ == '__main__':
    import sys
    
    target = Path(sys.argv[1]) if len(sys.argv) > 1 else Path('.')
    verbose = '-v' in sys.argv or '--verbose' in sys.argv
    use_checkov = '--checkov' in sys.argv
    
    scanner = DeploymentAdvisoriesScanner(use_checkov=use_checkov)
    result = scanner.scan(target)
    print_advisories(result, verbose=verbose)
