#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.

"""
Sandbox Executor - Docker-based Behavioral Testing for Supply Chain Attacks

Executes packages in a sandboxed Docker container with:
- Honeypot credentials (AWS, SSH, npm, etc.)
- Command shims that log all executions
- Network isolation with logging
- Import-time behavior monitoring

Usage:
    executor = SandboxExecutor()
    results = executor.test_packages(packages)
"""

import json
import subprocess
import tempfile
import shutil
from pathlib import Path
from typing import Dict, List, Optional, Any
from dataclasses import dataclass, field
from datetime import datetime
import hashlib
import os

@dataclass
class SandboxEvent:
    """A single event captured in sandbox"""
    timestamp: str
    event_type: str  # "honeypot_access", "network_call", "exec", "file_read", "env_read"
    source: str  # Package/file that triggered it
    target: str  # What was accessed (file path, URL, etc.)
    severity: str  # "critical", "high", "medium", "low"
    details: Dict = field(default_factory=dict)

@dataclass
class SandboxResult:
    """Result of running a package in sandbox"""
    package: str
    version: str
    ecosystem: str  # "npm", "pip", "go"
    verdict: str  # "MALICIOUS", "SUSPICIOUS", "CLEAN", "ERROR"
    events: List[SandboxEvent] = field(default_factory=list)
    duration_ms: int = 0
    error: Optional[str] = None
    
    @property
    def is_malicious(self) -> bool:
        return self.verdict == "MALICIOUS"
    
    @property
    def risk_score(self) -> int:
        """Calculate risk score based on events"""
        score = 0
        for event in self.events:
            if event.event_type == "honeypot_access":
                score += 100  # Critical - credential theft attempt
            elif event.event_type == "network_call":
                if "exfil" in event.target.lower() or "pastebin" in event.target.lower():
                    score += 80
                else:
                    score += 30
            elif event.event_type == "env_read":
                if any(s in event.target.upper() for s in ["AWS", "SECRET", "TOKEN", "KEY", "PASSWORD"]):
                    score += 50
                else:
                    score += 10
            elif event.event_type == "exec":
                if any(s in event.target for s in ["curl", "wget", "nc", "eval", "exec"]):
                    score += 60
                else:
                    score += 20
        return min(score, 100)

class SandboxExecutor:
    """
    Execute packages in Docker sandbox and analyze behavior.
    
    The sandbox:
    1. Plants honeypot credentials (.aws/credentials, .ssh/id_rsa, etc.)
    2. Intercepts commands via shims that log all calls
    3. Monitors network activity
    4. Captures import-time execution behavior
    """
    
    # Use local image - no remote registry
    DOCKER_IMAGE = "reachable/sandbox:latest"
    TIMEOUT_SECONDS = 60
    
    def __init__(self, sandbox_dir: Optional[Path] = None):
        """Initialize sandbox executor"""
        self.sandbox_dir = sandbox_dir or Path(__file__).parent.parent / "sandbox"
        self._docker_available = None
        self._image_built = False
        
    def is_available(self) -> bool:
        """Check if Docker is available"""
        if self._docker_available is None:
            try:
                result = subprocess.run(
                    ["docker", "info"],
                    capture_output=True,
                    timeout=10
                )
                self._docker_available = result.returncode == 0
            except (subprocess.TimeoutExpired, FileNotFoundError):
                self._docker_available = False
        return self._docker_available
    
    def build_image(self) -> bool:
        """Build the sandbox Docker image"""
        if not self.is_available():
            return False
            
        if self._image_built:
            return True
            
        dockerfile = self.sandbox_dir / "Dockerfile"
        if not dockerfile.exists():
            return False
            
        try:
            result = subprocess.run(
                ["docker", "build", "-t", self.DOCKER_IMAGE, "-f", str(dockerfile), str(self.sandbox_dir)],
                capture_output=True,
                timeout=300  # 5 min build timeout
            )
            self._image_built = result.returncode == 0
            return self._image_built
        except (subprocess.TimeoutExpired, Exception):
            return False
    
    def test_package(self, package: str, version: str, ecosystem: str = "npm") -> SandboxResult:
        """
        Test a single package in the sandbox.
        
        Args:
            package: Package name (e.g., "lodash")
            version: Package version (e.g., "4.17.21")
            ecosystem: Package ecosystem ("npm", "pip", "go")
            
        Returns:
            SandboxResult with verdict and captured events
        """
        if not self.is_available():
            return SandboxResult(
                package=package,
                version=version,
                ecosystem=ecosystem,
                verdict="ERROR",
                error="Docker not available"
            )
        
        # Build image if needed (don't try to pull from remote)
        if not self._image_built and not self.build_image():
            # Check if image exists locally (might have been built before)
            try:
                result = subprocess.run(
                    ["docker", "image", "inspect", self.DOCKER_IMAGE],
                    capture_output=True,
                    timeout=10
                )
                if result.returncode == 0:
                    self._image_built = True
            except:
                pass
            
            if not self._image_built:
                return SandboxResult(
                    package=package,
                    version=version,
                    ecosystem=ecosystem,
                    verdict="SKIPPED",
                    error="Sandbox image not available. Build with: cd sandbox && docker build -t reachable/sandbox:latest ."
                )
        
        # Create temp directory for output
        with tempfile.TemporaryDirectory() as tmpdir:
            output_dir = Path(tmpdir)
            events_file = output_dir / "events.jsonl"
            
            # Build install command based on ecosystem
            if ecosystem == "npm":
                install_cmd = f"npm install {package}@{version}"
            elif ecosystem == "pip":
                install_cmd = f"pip install {package}=={version}"
            else:
                install_cmd = f"go get {package}@v{version}"
            
            start_time = datetime.now()
            
            try:
                # Run container with:
                # - Network isolation (--network=none for strict, or custom for logging)
                # - Seccomp profile for syscall filtering
                # - Read-only root filesystem
                # - Honeypots and shims pre-installed in image
                result = subprocess.run(
                    [
                        "docker", "run",
                        "--rm",
                        "--network=none",  # Full network isolation
                        "--read-only",
                        "--tmpfs", "/tmp:rw,size=100m",
                        "--tmpfs", "/work:rw,size=500m",
                        "-v", f"{output_dir}:/var/log/sandbox:rw",
                        "--security-opt", f"seccomp={self.sandbox_dir / 'seccomp.json'}",
                        "--memory=512m",
                        "--cpus=1",
                        "-e", f"PACKAGE={package}",
                        "-e", f"VERSION={version}",
                        "-e", f"ECOSYSTEM={ecosystem}",
                        self.DOCKER_IMAGE,
                        "/bin/bash", "-c", install_cmd
                    ],
                    capture_output=True,
                    timeout=self.TIMEOUT_SECONDS
                )
                
                duration_ms = int((datetime.now() - start_time).total_seconds() * 1000)
                
                # Parse events from honeypot monitor
                events = []
                if events_file.exists():
                    with open(events_file, 'r') as f:
                        for line in f:
                            try:
                                event_data = json.loads(line.strip())
                                events.append(SandboxEvent(
                                    timestamp=event_data.get('timestamp', ''),
                                    event_type=event_data.get('type', 'unknown'),
                                    source=event_data.get('source', ''),
                                    target=event_data.get('target', ''),
                                    severity=event_data.get('severity', 'low'),
                                    details=event_data.get('details', {})
                                ))
                            except json.JSONDecodeError:
                                continue
                
                # Determine verdict based on events
                verdict = self._determine_verdict(events)
                
                return SandboxResult(
                    package=package,
                    version=version,
                    ecosystem=ecosystem,
                    verdict=verdict,
                    events=events,
                    duration_ms=duration_ms
                )
                
            except subprocess.TimeoutExpired:
                return SandboxResult(
                    package=package,
                    version=version,
                    ecosystem=ecosystem,
                    verdict="SUSPICIOUS",
                    error="Execution timed out (possible infinite loop or network wait)"
                )
            except Exception as e:
                return SandboxResult(
                    package=package,
                    version=version,
                    ecosystem=ecosystem,
                    verdict="ERROR",
                    error=str(e)
                )
    
    def _determine_verdict(self, events: List[SandboxEvent]) -> str:
        """Determine verdict based on captured events"""
        has_honeypot_access = any(e.event_type == "honeypot_access" for e in events)
        has_network_exfil = any(
            e.event_type == "network_call" and 
            any(s in e.target.lower() for s in ["pastebin", "requestbin", "webhook", "discord", "telegram"])
            for e in events
        )
        has_env_harvesting = sum(1 for e in events if e.event_type == "env_read") > 10
        has_suspicious_exec = any(
            e.event_type == "exec" and
            any(s in e.target for s in ["curl", "wget", "nc", "eval", "exec", "base64"])
            for e in events
        )
        
        if has_honeypot_access:
            return "MALICIOUS"  # Credential theft attempt
        elif has_network_exfil:
            return "MALICIOUS"  # Data exfiltration attempt
        elif has_env_harvesting and has_suspicious_exec:
            return "MALICIOUS"  # Combined indicators
        elif has_suspicious_exec or has_env_harvesting:
            return "SUSPICIOUS"
        elif len(events) > 0:
            return "SUSPICIOUS"  # Some activity detected
        else:
            return "CLEAN"
    
    def test_packages(self, packages: List[Dict[str, str]]) -> Dict[str, SandboxResult]:
        """
        Test multiple packages in sandbox.
        
        Args:
            packages: List of {"name": "pkg", "version": "1.0", "ecosystem": "npm"}
            
        Returns:
            Dict mapping "pkg@version" to SandboxResult
        """
        results = {}
        
        for pkg in packages:
            name = pkg.get('name', '')
            version = pkg.get('version', '')
            ecosystem = pkg.get('ecosystem', 'npm')
            
            if not name or not version:
                continue
                
            key = f"{name}@{version}"
            results[key] = self.test_package(name, version, ecosystem)
        
        return results
    
    def test_all_suspicious(self, guarddog_detections: Dict[str, Any]) -> Dict[str, SandboxResult]:
        """
        Test all packages flagged as suspicious by GuardDog.
        
        This is the recommended workflow:
        1. GuardDog scans all packages (fast, pattern-based)
        2. Sandbox tests only suspicious ones (slow, behavioral)
        
        Args:
            guarddog_detections: Output from GuardDog scan
            
        Returns:
            Dict of sandbox results for suspicious packages
        """
        packages_to_test = []
        
        for pkg_key, detection in guarddog_detections.items():
            if hasattr(detection, 'is_malicious') and detection.is_malicious:
                packages_to_test.append({
                    'name': detection.package_name,
                    'version': detection.package_version,
                    'ecosystem': 'npm' if '@' in pkg_key else 'pip'  # Heuristic
                })
        
        return self.test_packages(packages_to_test)
    
    def generate_report(self, results: Dict[str, SandboxResult]) -> Dict:
        """Generate a summary report from sandbox results"""
        total = len(results)
        malicious = sum(1 for r in results.values() if r.verdict == "MALICIOUS")
        suspicious = sum(1 for r in results.values() if r.verdict == "SUSPICIOUS")
        clean = sum(1 for r in results.values() if r.verdict == "CLEAN")
        errors = sum(1 for r in results.values() if r.verdict == "ERROR")
        
        # Aggregate events by type
        events_by_type = {}
        for result in results.values():
            for event in result.events:
                events_by_type[event.event_type] = events_by_type.get(event.event_type, 0) + 1
        
        # Honeypots that were deployed
        honeypots_deployed = [
            "~/.aws/credentials",
            "~/.ssh/id_rsa",
            "~/.ssh/id_ed25519",
            "~/.npmrc",
            "~/.docker/config.json",
            "~/.kube/config",
            "~/.netrc",
            "~/.git-credentials",
            "Environment variables (AWS_*, GITHUB_*, API_*)"
        ]
        
        return {
            "policy_id": "MALWARE-003",
            "policy_name": "Behavioral Anomaly Detection",
            "scanner": "DevNull Malware Sandbox",
            "verdict": "MALICIOUS" if malicious > 0 else "SUSPICIOUS" if suspicious > 0 else "CLEAN",
            "reason": f"{malicious} malicious, {suspicious} suspicious out of {total} packages",
            "packages_tested": total,
            "summary": {
                "malicious": malicious,
                "suspicious": suspicious,
                "clean": clean,
                "errors": errors,
                "honeypot_accesses": events_by_type.get("honeypot_access", 0),
                "network_attempts": events_by_type.get("network_call", 0),
                "env_harvesting": events_by_type.get("env_read", 0)
            },
            "honeypots_deployed": honeypots_deployed,
            "events_by_type": events_by_type,
            "behavioral_indicators": {
                "credential_theft": events_by_type.get("honeypot_access", 0) > 0,
                "network_exfiltration": events_by_type.get("network_call", 0) > 0,
                "environment_harvesting": events_by_type.get("env_read", 0) > 0,
                "suspicious_exec": events_by_type.get("exec", 0) > 0
            },
            "findings": [
                {
                    "finding_id": f"MALWARE-003-{r.ecosystem}-{r.package}-{idx}",
                    "policy_id": "MALWARE-003",
                    "package": r.package,
                    "version": r.version,
                    "ecosystem": r.ecosystem,
                    "verdict": r.verdict,
                    "risk_score": r.risk_score,
                    "events_count": len(r.events),
                    "events": [
                        {
                            "type": e.event_type,
                            "target": e.target,
                            "severity": e.severity
                        }
                        for e in r.events
                    ],
                    "error": r.error
                }
                for idx, r in enumerate(results.values())
                if r.verdict in ("MALICIOUS", "SUSPICIOUS") or r.error
            ],
            "_metadata": {
                "generated_at": datetime.utcnow().isoformat() + "Z",
                "sandbox_image": self.DOCKER_IMAGE,
                "timeout_seconds": self.TIMEOUT_SECONDS,
                "isolation": "Docker container with seccomp + network isolation"
            }
        }

# Convenience function for quick testing
def test_package_quick(package: str, version: str, ecosystem: str = "npm") -> SandboxResult:
    """Quick test a single package"""
    executor = SandboxExecutor()
    return executor.test_package(package, version, ecosystem)

if __name__ == "__main__":
    import sys
    
    if len(sys.argv) < 3:
        print("Usage: sandbox_executor.py <package> <version> [ecosystem]")
        print("Example: sandbox_executor.py lodash 4.17.21 npm")
        sys.exit(1)
    
    package = sys.argv[1]
    version = sys.argv[2]
    ecosystem = sys.argv[3] if len(sys.argv) > 3 else "npm"
    
    executor = SandboxExecutor()
    
    if not executor.is_available():
        print("ERROR: Docker not available")
        sys.exit(1)
    
    print(f"Testing {package}@{version} ({ecosystem})...")
    result = executor.test_package(package, version, ecosystem)
    
    print(f"\nVerdict: {result.verdict}")
    print(f"Risk Score: {result.risk_score}")
    print(f"Duration: {result.duration_ms}ms")
    
    if result.events:
        print(f"\nEvents ({len(result.events)}):")
        for event in result.events:
            print(f"  [{event.severity}] {event.event_type}: {event.target}")
    
    if result.error:
        print(f"\nError: {result.error}")
