# Copyright © 2026 Sthenos Security. All rights reserved.

"""
REACHABLE Database Management Module

Provides:
- Database status and statistics
- Auto-trimming at scan completion
- Manual trimming commands
- Dashboard metadata generation
"""

import sqlite3
from pathlib import Path
from datetime import datetime, timedelta
from typing import Dict, Any, List, Optional
import json

# Default retention settings
DEFAULT_MAX_SCANS = 30          # Per branch
DEFAULT_MAX_AGE_DAYS = 45       # Days to keep
DEFAULT_MAX_DB_SIZE_MB = 100    # Warning threshold
WARNING_THRESHOLD_PCT = 80       # Warn at 80% of max

class DatabaseManager:
    """Manages REACHABLE scan databases"""
    
    def __init__(self, reachable_home: Path = None):
        self.reachable_home = reachable_home or Path.home() / '.reachable'
        self.scans_dir = self.reachable_home / 'scans'
    
    def get_all_repo_dbs(self) -> List[Dict[str, Any]]:
        """Get info on all repo databases"""
        dbs = []
        
        if not self.scans_dir.exists():
            return dbs
        
        for repo_dir in self.scans_dir.iterdir():
            if not repo_dir.is_dir():
                continue
            
            db_path = repo_dir / 'repo.db'
            if not db_path.exists():
                continue
            
            try:
                stats = self._get_db_stats(db_path)
                stats['repo_dir'] = str(repo_dir)
                stats['repo_name'] = repo_dir.name.rsplit('-', 1)[0]  # Remove hash suffix
                dbs.append(stats)
            except Exception as e:
                dbs.append({
                    'repo_dir': str(repo_dir),
                    'repo_name': repo_dir.name,
                    'error': str(e)
                })
        
        return dbs
    
    def _get_db_stats(self, db_path: Path) -> Dict[str, Any]:
        """Get statistics for a single database"""
        stats = {
            'db_path': str(db_path),
            'db_size_bytes': db_path.stat().st_size if db_path.exists() else 0,
        }
        stats['db_size_mb'] = round(stats['db_size_bytes'] / (1024 * 1024), 2)
        
        try:
            conn = sqlite3.connect(str(db_path))
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            
            # Scan count
            cursor.execute("SELECT COUNT(*) as cnt FROM scans")
            stats['scan_count'] = cursor.fetchone()['cnt']
            
            # Finding count
            cursor.execute("SELECT COUNT(*) as cnt FROM findings")
            stats['finding_count'] = cursor.fetchone()['cnt']
            
            # First and last scan
            cursor.execute("""
                SELECT MIN(timestamp) as first, MAX(timestamp) as last 
                FROM scans WHERE status = 'complete'
            """)
            row = cursor.fetchone()
            stats['first_scan'] = row['first']
            stats['last_scan'] = row['last']
            
            # Average scan duration
            cursor.execute("""
                SELECT AVG(duration_seconds) as avg_dur 
                FROM scans WHERE status = 'complete'
            """)
            avg = cursor.fetchone()['avg_dur']
            stats['avg_duration_sec'] = round(avg, 1) if avg else 0
            
            # Scans by status
            cursor.execute("""
                SELECT status, COUNT(*) as cnt 
                FROM scans GROUP BY status
            """)
            stats['scans_by_status'] = {row['status']: row['cnt'] for row in cursor.fetchall()}
            
            # Cache sizes
            cursor.execute("SELECT COUNT(*) as cnt FROM sbom_cache")
            stats['sbom_cache_count'] = cursor.fetchone()['cnt']
            
            cursor.execute("SELECT COUNT(*) as cnt FROM call_graph_cache")
            stats['callgraph_cache_count'] = cursor.fetchone()['cnt']
            
            conn.close()
        except Exception as e:
            stats['error'] = str(e)
        
        return stats
    
    def get_global_stats(self) -> Dict[str, Any]:
        """Get aggregate stats across all repo databases"""
        dbs = self.get_all_repo_dbs()
        
        total_size = sum(db.get('db_size_bytes', 0) for db in dbs)
        total_scans = sum(db.get('scan_count', 0) for db in dbs)
        total_findings = sum(db.get('finding_count', 0) for db in dbs)
        
        return {
            'repo_count': len(dbs),
            'total_size_bytes': total_size,
            'total_size_mb': round(total_size / (1024 * 1024), 2),
            'total_scans': total_scans,
            'total_findings': total_findings,
            'repos': dbs,
            'warning': total_size > DEFAULT_MAX_DB_SIZE_MB * 1024 * 1024 * WARNING_THRESHOLD_PCT / 100
        }
    
    def trim_database(self, db_path: Path, 
                      max_scans: int = None,
                      max_age_days: int = None,
                      dry_run: bool = False) -> Dict[str, Any]:
        """
        Trim a single database.
        
        Args:
            db_path: Path to repo.db
            max_scans: Max scans to keep per branch
            max_age_days: Delete scans older than this
            dry_run: If True, report what would be deleted without deleting
        
        Returns:
            Dict with trimming stats
        """
        max_scans = max_scans or DEFAULT_MAX_SCANS
        max_age_days = max_age_days or DEFAULT_MAX_AGE_DAYS
        
        if not db_path.exists():
            return {'error': 'Database not found'}
        
        conn = sqlite3.connect(str(db_path))
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        
        stats = {
            'db_path': str(db_path),
            'size_before_bytes': db_path.stat().st_size,
            'scans_to_delete': 0,
            'findings_to_delete': 0,
            'dry_run': dry_run
        }
        
        try:
            # Get all branches
            cursor.execute("SELECT DISTINCT branch FROM scans")
            branches = [row['branch'] for row in cursor.fetchall()]
            
            scans_to_delete = []
            
            for branch in branches:
                # Find scans to delete by count (keep last N)
                cursor.execute("""
                    SELECT id FROM scans 
                    WHERE branch = ? AND status = 'complete'
                    ORDER BY timestamp DESC
                    LIMIT -1 OFFSET ?
                """, (branch, max_scans))
                scans_to_delete.extend([row['id'] for row in cursor.fetchall()])
                
                # Find scans to delete by age
                cutoff = datetime.now() - timedelta(days=max_age_days)
                cursor.execute("""
                    SELECT id FROM scans 
                    WHERE branch = ? AND timestamp < ?
                """, (branch, cutoff.isoformat()))
                scans_to_delete.extend([row['id'] for row in cursor.fetchall()])
            
            # Dedupe
            scans_to_delete = list(set(scans_to_delete))
            stats['scans_to_delete'] = len(scans_to_delete)
            
            if scans_to_delete:
                # Count findings
                placeholders = ','.join('?' * len(scans_to_delete))
                cursor.execute(f"""
                    SELECT COUNT(*) as cnt FROM findings 
                    WHERE scan_id IN ({placeholders})
                """, scans_to_delete)
                stats['findings_to_delete'] = cursor.fetchone()['cnt']
                
                if not dry_run:
                    # Delete (CASCADE handles related tables)
                    cursor.execute(f"""
                        DELETE FROM scans WHERE id IN ({placeholders})
                    """, scans_to_delete)
                    
                    # Clean orphaned cache entries
                    cursor.execute("""
                        DELETE FROM sbom_cache 
                        WHERE created_at < datetime('now', '-30 days')
                        AND commit_hash NOT IN (SELECT DISTINCT commit_hash FROM scans WHERE commit_hash IS NOT NULL)
                    """)
                    
                    cursor.execute("""
                        DELETE FROM call_graph_cache 
                        WHERE created_at < datetime('now', '-30 days')
                    """)
                    
                    conn.commit()
                    
                    # Vacuum to reclaim space
                    conn.execute("VACUUM")
            
            conn.close()
            
            if not dry_run:
                stats['size_after_bytes'] = db_path.stat().st_size
                stats['space_reclaimed_bytes'] = stats['size_before_bytes'] - stats['size_after_bytes']
                stats['space_reclaimed_mb'] = round(stats['space_reclaimed_bytes'] / (1024 * 1024), 2)
            
        except Exception as e:
            stats['error'] = str(e)
            conn.close()
        
        return stats
    
    def trim_all(self, max_scans: int = None, 
                 max_age_days: int = None,
                 dry_run: bool = False) -> Dict[str, Any]:
        """Trim all repo databases"""
        results = []
        total_reclaimed = 0
        
        for repo_dir in self.scans_dir.iterdir():
            if not repo_dir.is_dir():
                continue
            
            db_path = repo_dir / 'repo.db'
            if db_path.exists():
                result = self.trim_database(db_path, max_scans, max_age_days, dry_run)
                results.append(result)
                total_reclaimed += result.get('space_reclaimed_bytes', 0)
        
        return {
            'repos_trimmed': len(results),
            'total_space_reclaimed_bytes': total_reclaimed,
            'total_space_reclaimed_mb': round(total_reclaimed / (1024 * 1024), 2),
            'results': results
        }
    
    def get_dashboard_metadata(self, db_path: Path) -> Dict[str, Any]:
        """
        Get metadata for dashboard footer.
        
        Returns dict with:
        - scan_number: Current scan #
        - last_scan_time: When last scan completed
        - last_scan_ago: Human readable "2 hours ago"
        - avg_duration: Average scan duration
        - db_size_mb: Database size
        - db_warning: True if approaching limit
        """
        if not db_path.exists():
            return {}
        
        try:
            conn = sqlite3.connect(str(db_path))
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            
            # Current scan number
            cursor.execute("SELECT COUNT(*) as cnt FROM scans WHERE status = 'complete'")
            scan_count = cursor.fetchone()['cnt']
            
            # Last scan time
            cursor.execute("""
                SELECT timestamp, duration_seconds 
                FROM scans WHERE status = 'complete'
                ORDER BY timestamp DESC LIMIT 1
            """)
            row = cursor.fetchone()
            
            last_scan = None
            last_duration = None
            if row:
                last_scan = row['timestamp']
                last_duration = row['duration_seconds']
            
            # Average duration
            cursor.execute("""
                SELECT AVG(duration_seconds) as avg 
                FROM scans WHERE status = 'complete'
            """)
            avg_duration = cursor.fetchone()['avg'] or 0
            
            conn.close()
            
            # Calculate "ago" string
            last_scan_ago = "never"
            if last_scan:
                try:
                    last_dt = datetime.fromisoformat(last_scan.replace('Z', '+00:00'))
                    delta = datetime.now() - last_dt.replace(tzinfo=None)
                    
                    if delta.days > 0:
                        last_scan_ago = f"{delta.days}d ago"
                    elif delta.seconds >= 3600:
                        last_scan_ago = f"{delta.seconds // 3600}h ago"
                    elif delta.seconds >= 60:
                        last_scan_ago = f"{delta.seconds // 60}m ago"
                    else:
                        last_scan_ago = "just now"
                except:
                    pass
            
            # DB size
            db_size = db_path.stat().st_size
            db_size_mb = db_size / (1024 * 1024)
            
            return {
                'scan_number': scan_count,
                'last_scan_time': last_scan,
                'last_scan_ago': last_scan_ago,
                'last_duration_sec': round(last_duration, 1) if last_duration else None,
                'avg_duration_sec': round(avg_duration, 1),
                'db_size_bytes': db_size,
                'db_size_mb': round(db_size_mb, 2),
                'db_warning': db_size_mb > DEFAULT_MAX_DB_SIZE_MB * WARNING_THRESHOLD_PCT / 100,
                'db_limit_mb': DEFAULT_MAX_DB_SIZE_MB
            }
            
        except Exception as e:
            return {'error': str(e)}

def auto_trim_on_scan_complete(db_path: Path, verbose: bool = False) -> Dict[str, Any]:
    """
    Called at end of each scan to auto-trim if needed.
    
    Only trims if DB exceeds thresholds.
    """
    if not db_path.exists():
        return {}
    
    db_size_mb = db_path.stat().st_size / (1024 * 1024)
    
    # Only trim if approaching limit
    if db_size_mb < DEFAULT_MAX_DB_SIZE_MB * WARNING_THRESHOLD_PCT / 100:
        return {'trimmed': False, 'reason': 'below threshold'}
    
    manager = DatabaseManager()
    result = manager.trim_database(
        db_path, 
        max_scans=DEFAULT_MAX_SCANS,
        max_age_days=DEFAULT_MAX_AGE_DAYS,
        dry_run=False
    )
    
    if verbose and result.get('scans_to_delete', 0) > 0:
        print(f"🗑️  Auto-trimmed {result['scans_to_delete']} old scans, "
              f"reclaimed {result.get('space_reclaimed_mb', 0)} MB")
    
    return result

def format_size(size_bytes: int) -> str:
    """Format bytes to human readable"""
    for unit in ['B', 'KB', 'MB', 'GB']:
        if size_bytes < 1024:
            return f"{size_bytes:.1f} {unit}"
        size_bytes /= 1024
    return f"{size_bytes:.1f} TB"

# CLI commands
def db_status(verbose: bool = False):
    """Print database status"""
    manager = DatabaseManager()
    stats = manager.get_global_stats()
    
    print("=" * 60)
    print("REACHABLE DATABASE STATUS")
    print("=" * 60)
    print()
    print(f"Total repos:    {stats['repo_count']}")
    print(f"Total scans:    {stats['total_scans']}")
    print(f"Total findings: {stats['total_findings']}")
    print(f"Total size:     {format_size(stats['total_size_bytes'])}")
    
    if stats['warning']:
        print()
        print(f"⚠️  WARNING: Approaching {DEFAULT_MAX_DB_SIZE_MB} MB limit")
        print(f"   Run: reachctl db --trim")
    
    if verbose and stats['repos']:
        print()
        print("Per-repo breakdown:")
        print("-" * 60)
        for repo in stats['repos']:
            if 'error' in repo:
                print(f"  {repo['repo_name']}: ERROR - {repo['error']}")
            else:
                print(f"  {repo['repo_name']}:")
                print(f"    Scans: {repo['scan_count']}, Findings: {repo['finding_count']}")
                print(f"    Size: {format_size(repo['db_size_bytes'])}")
                print(f"    Last scan: {repo.get('last_scan', 'never')}")

def db_trim(dry_run: bool = False, verbose: bool = False):
    """Trim all databases"""
    manager = DatabaseManager()
    
    if dry_run:
        print("DRY RUN - no changes will be made")
        print()
    
    results = manager.trim_all(dry_run=dry_run)
    
    print("=" * 60)
    print("REACHABLE DATABASE TRIM")
    print("=" * 60)
    print()
    print(f"Repos processed: {results['repos_trimmed']}")
    
    total_scans = sum(r.get('scans_to_delete', 0) for r in results['results'])
    total_findings = sum(r.get('findings_to_delete', 0) for r in results['results'])
    
    print(f"Scans to delete: {total_scans}")
    print(f"Findings to delete: {total_findings}")
    
    if not dry_run:
        print(f"Space reclaimed: {format_size(results['total_space_reclaimed_bytes'])}")
    
    if verbose:
        print()
        for r in results['results']:
            if r.get('scans_to_delete', 0) > 0:
                print(f"  {r['db_path']}: {r['scans_to_delete']} scans")

if __name__ == '__main__':
    db_status(verbose=True)
