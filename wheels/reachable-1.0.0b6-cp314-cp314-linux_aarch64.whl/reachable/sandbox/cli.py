# Copyright © 2026 Sthenos Security. All rights reserved.

"""
REACHABLE Sandbox CLI Commands

Provides the 'reachctl sandbox' command group for testing packages
in isolated containers.
"""

import json
import sys
from pathlib import Path
from typing import Optional

import click

from .runner import SandboxRunner, Verdict, format_sandbox_report

@click.group()
def sandbox():
    """Sandbox package installation testing for supply chain attack detection"""
    pass

@sandbox.command()
@click.argument('package')
@click.option('--ecosystem', '-e', type=click.Choice(['npm', 'pip']), default='npm',
              help='Package ecosystem')
@click.option('--version', '-v', default=None, help='Specific version to test')
@click.option('--timeout', '-t', default=300, type=int, help='Timeout in seconds')
@click.option('--json', 'output_json', is_flag=True, help='Output JSON')
@click.option('--verbose', is_flag=True, help='Verbose output')
def test(package: str, ecosystem: str, version: Optional[str], 
         timeout: int, output_json: bool, verbose: bool):
    """
    Test a package installation in the sandbox.
    
    \b
    Examples:
        reachctl sandbox test lodash
        reachctl sandbox test requests --ecosystem pip
        reachctl sandbox test lodash@4.17.21
    """
    # Parse version from package if specified as package@version
    if '@' in package and not version:
        package, version = package.rsplit('@', 1)
    
    runner = SandboxRunner(timeout=timeout)
    
    # Check Docker availability
    if not runner.is_available():
        click.secho("Error: Docker is not available", fg='red')
        click.echo("Please ensure Docker is installed and running.")
        sys.exit(1)
    
    # Check image availability
    pkg_display = f"{package}@{version}" if version else package
    click.echo(f"🔒 Testing {pkg_display} ({ecosystem})")
    click.echo("")
    
    if not runner.ensure_image():
        click.secho(f"Error: Sandbox image not available: {runner.image}", fg='red')
        click.echo("Build the image with: reachctl sandbox build")
        sys.exit(1)
    
    # Run the test
    click.echo("Installing in sandbox...")
    result = runner.test_package(package, ecosystem, version)
    click.echo("")
    
    # Output results
    if output_json:
        click.echo(json.dumps(result.to_dict(), indent=2))
    else:
        # Verdict with color
        verdict_colors = {
            Verdict.CLEAN: ('✅ CLEAN', 'green'),
            Verdict.INFO: ('ℹ️  INFO', 'cyan'),
            Verdict.WARNING: ('⚠️  WARNING', 'yellow'),
            Verdict.CRITICAL: ('❌ CRITICAL', 'red'),
            Verdict.ERROR: ('⚡ ERROR', 'red'),
        }
        
        icon, color = verdict_colors[result.verdict]
        click.secho(f"Verdict: {icon}", fg=color, bold=True)
        click.echo(f"Duration: {result.duration_ms}ms")
        click.echo(f"Exit code: {result.exit_code}")
        
        if result.error:
            click.secho(f"Error: {result.error}", fg='red')
        
        if result.findings:
            click.echo("")
            click.echo("Findings:")
            for f in result.findings:
                sev_colors = {
                    'CRITICAL': 'red',
                    'HIGH': 'yellow',
                    'MEDIUM': 'yellow',
                    'LOW': 'cyan',
                    'INFO': 'white'
                }
                color = sev_colors.get(f.severity.value, 'white')
                click.secho(f"  [{f.severity.value}] {f.rule}: {f.description}", fg=color)
        
        if verbose and result.events:
            click.echo("")
            click.echo("Events:")
            for e in result.events:
                click.echo(f"  {e.get('event', 'unknown')}: {e.get('binary', '')} {e.get('details', '')}")
    
    # Exit code based on verdict
    if result.verdict == Verdict.CRITICAL:
        sys.exit(2)
    elif result.verdict == Verdict.WARNING:
        sys.exit(1)
    elif result.verdict == Verdict.ERROR:
        sys.exit(3)
    else:
        sys.exit(0)

@sandbox.command()
@click.argument('path', default='.')
@click.option('--ecosystem', '-e', type=click.Choice(['npm', 'pip', 'auto']), default='auto',
              help='Package ecosystem (auto-detect by default)')
@click.option('--timeout', '-t', default=300, type=int, help='Timeout per package')
@click.option('--parallel', '-p', default=4, type=int, help='Parallel tests')
@click.option('--json', 'output_json', is_flag=True, help='Output JSON')
@click.option('--fail-on', type=click.Choice(['critical', 'warning', 'any']), default='critical',
              help='Exit with error on this severity or higher')
def scan(path: str, ecosystem: str, timeout: int, parallel: int, 
         output_json: bool, fail_on: str):
    """
    Scan all dependencies in a project.
    
    \b
    Examples:
        reachctl sandbox scan .
        reachctl sandbox scan ./my-project --ecosystem npm
        reachctl sandbox scan . --fail-on warning
    """
    repo_path = Path(path).resolve()
    
    if not repo_path.exists():
        click.secho(f"Error: Path not found: {path}", fg='red')
        sys.exit(1)
    
    runner = SandboxRunner(timeout=timeout, parallel=parallel)
    
    if not runner.is_available():
        click.secho("Error: Docker is not available", fg='red')
        sys.exit(1)
    
    # Detect ecosystem and parse dependencies
    packages = []
    
    if ecosystem in ('auto', 'npm'):
        pkg_json = repo_path / 'package.json'
        if pkg_json.exists():
            try:
                with open(pkg_json) as f:
                    data = json.load(f)
                deps = data.get('dependencies', {})
                dev_deps = data.get('devDependencies', {})
                for name, version in {**deps, **dev_deps}.items():
                    # Clean version string
                    ver = version.lstrip('^~>=<')
                    packages.append((name, 'npm', ver if ver else None))
            except Exception as e:
                click.secho(f"Warning: Could not parse package.json: {e}", fg='yellow')
    
    if ecosystem in ('auto', 'pip'):
        req_txt = repo_path / 'requirements.txt'
        if req_txt.exists():
            try:
                with open(req_txt) as f:
                    for line in f:
                        line = line.strip()
                        if line and not line.startswith('#'):
                            # Parse package==version or package>=version etc
                            for sep in ['==', '>=', '<=', '~=', '!=']:
                                if sep in line:
                                    name, ver = line.split(sep, 1)
                                    packages.append((name.strip(), 'pip', ver.strip()))
                                    break
                            else:
                                packages.append((line, 'pip', None))
            except Exception as e:
                click.secho(f"Warning: Could not parse requirements.txt: {e}", fg='yellow')
    
    if not packages:
        click.secho("No dependencies found to scan", fg='yellow')
        sys.exit(0)
    
    click.echo(f"🔒 Scanning {len(packages)} packages...")
    click.echo("")
    
    # Run scans with progress
    def progress(current, total, package):
        click.echo(f"  [{current}/{total}] {package}")
    
    results = runner.scan_dependencies(packages, progress_callback=progress)
    
    click.echo("")
    
    # Output
    if output_json:
        output = {
            "packages_tested": len(results),
            "summary": {v.value: sum(1 for r in results if r.verdict == v) for v in Verdict},
            "results": [r.to_dict() for r in results]
        }
        click.echo(json.dumps(output, indent=2))
    else:
        click.echo(format_sandbox_report(results))
    
    # Determine exit code
    has_critical = any(r.verdict == Verdict.CRITICAL for r in results)
    has_warning = any(r.verdict == Verdict.WARNING for r in results)
    
    if fail_on == 'critical' and has_critical:
        sys.exit(2)
    elif fail_on == 'warning' and (has_critical or has_warning):
        sys.exit(1)
    elif fail_on == 'any' and any(r.verdict != Verdict.CLEAN for r in results):
        sys.exit(1)
    else:
        sys.exit(0)

@sandbox.command()
@click.option('--force', is_flag=True, help='Force rebuild even if image exists')
def build(force: bool):
    """
    Build the sandbox Docker image locally.
    """
    import subprocess
    
    # Find sandbox directory
    sandbox_dir = Path(__file__).parent.parent.parent / 'sandbox'
    
    if not sandbox_dir.exists():
        # Try alternate location
        sandbox_dir = Path(__file__).parent.parent.parent.parent / 'sandbox'
    
    if not sandbox_dir.exists():
        click.secho(f"Error: Sandbox directory not found", fg='red')
        click.echo("Expected at: reachable-*/sandbox/")
        sys.exit(1)
    
    dockerfile = sandbox_dir / 'Dockerfile'
    if not dockerfile.exists():
        click.secho(f"Error: Dockerfile not found: {dockerfile}", fg='red')
        sys.exit(1)
    
    click.echo("🔧 Building sandbox image...")
    click.echo(f"   Directory: {sandbox_dir}")
    click.echo("")
    
    cmd = [
        'docker', 'build',
        '-t', 'reachable/sandbox:latest',
        '-f', str(dockerfile),
        str(sandbox_dir)
    ]
    
    try:
        result = subprocess.run(cmd, check=True)
        click.secho("✅ Image built successfully: reachable/sandbox:latest", fg='green')
    except subprocess.CalledProcessError as e:
        click.secho(f"❌ Build failed with exit code {e.returncode}", fg='red')
        sys.exit(1)
    except FileNotFoundError:
        click.secho("Error: Docker not found. Please install Docker.", fg='red')
        sys.exit(1)

@sandbox.command()
def status():
    """
    Check sandbox status and Docker availability.
    """
    click.echo("🔒 REACHABLE Sandbox Status")
    click.echo("=" * 40)
    
    # Check Docker
    try:
        import docker
        client = docker.from_env()
        client.ping()
        click.secho("✅ Docker: Available", fg='green')
        
        # Check for sandbox image
        try:
            img = client.images.get('reachable/sandbox:latest')
            click.secho("✅ Sandbox image: Available", fg='green')
            click.echo(f"   ID: {img.short_id}")
            created = img.attrs.get('Created', 'unknown')
            if isinstance(created, str) and len(created) > 19:
                created = created[:19]
            click.echo(f"   Created: {created}")
        except docker.errors.ImageNotFound:
            click.secho("⚠️  Sandbox image: Not found", fg='yellow')
            click.echo("   Run 'reachctl sandbox build' to build it")
        
    except ImportError:
        click.secho("❌ Docker SDK: Not installed", fg='red')
        click.echo("   Run: pip install docker")
    except Exception as e:
        click.secho(f"❌ Docker: Not available ({e})", fg='red')
