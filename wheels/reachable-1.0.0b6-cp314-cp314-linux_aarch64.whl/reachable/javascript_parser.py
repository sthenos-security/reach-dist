#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.

"""
FIXED JavaScript/TypeScript Call Graph Parser

BUGS FIXED FROM ORIGINAL:
1. Call graph edges were only added for method calls (with `.`) - now adds ALL calls
2. Caller was set to MODULE name not FUNCTION name - now tracks current function context
3. Edges only added if callee already known - now adds all edges, resolves later
4. No tracking of which function uses which import - now properly tracks function_imports

This is the CORE of reachability analysis - without proper call graph, nothing works!
"""

import re
from pathlib import Path
from typing import Dict, Set, List, Tuple, Optional
from collections import defaultdict

class JavaScriptParser:
    """
    Parse JavaScript/TypeScript code to extract call graphs.
    
    FIXED: Actually builds call graph with edges!
    """
    
    def __init__(self):
        self.call_graph: Dict[str, Set[str]] = defaultdict(set)
        self.imports_map: Dict[str, List[str]] = {}
        self.function_imports: Dict[str, Set[str]] = defaultdict(set)  # NEW: track imports per function
        self.all_functions: Set[str] = set()
        self.current_function: Optional[str] = None
        self.current_module: str = ""
        self.module_imports: Set[str] = set()  # imports for current file
        self.function_metadata: Dict[str, dict] = {}  # NEW: func -> {file, line, module}
        self.current_file: str = ""  # NEW: track current file being parsed
    
    def parse_directory(self, directory: Path, prefix: str = "app") -> Tuple[Dict, Dict, Set]:
        """
        Parse all JavaScript/TypeScript files in directory.
        
        Returns:
            Tuple of (call_graph, imports_map, all_functions)
        """
        extensions = ['.js', '.ts', '.jsx', '.tsx', '.mjs', '.cjs']
        all_files = []
        
        for ext in extensions:
            all_files.extend(directory.rglob(f'*{ext}'))
        
        # Exclude node_modules, tests, configs
        all_files = [f for f in all_files if 
                     'node_modules' not in str(f) and
                     '__tests__' not in str(f) and
                     '.test.' not in str(f) and
                     '.spec.' not in str(f) and
                     '.config.' not in str(f) and
                     f.is_file()]
        
        for file_path in all_files:
            self._parse_file(file_path, prefix)
        
        # Resolve cross-module calls (add module prefix to unqualified calls)
        self._resolve_cross_module_calls()
        
        return dict(self.call_graph), self.imports_map, self.all_functions
    
    def get_function_imports(self) -> Dict[str, Set[str]]:
        """Return function→imports mapping for CVE tracking."""
        return dict(self.function_imports)
    
    def get_module_imports(self) -> Dict[str, Set[str]]:
        """Return module→imports mapping for transitive dependency tracking."""
        # Convert imports_map to sets for consistency
        return {mod: set(imports) for mod, imports in self.imports_map.items()}
    
    def _parse_file(self, file_path: Path, prefix: str):
        """Parse a single JavaScript/TypeScript file."""
        try:
            if file_path.is_dir():
                return
            
            # Store current file for metadata
            self.current_file = str(file_path)
            
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                code = f.read()
            
            # Build module name from path
            try:
                rel_path = file_path.relative_to(file_path.parent.parent)
                module_name = str(rel_path).replace('/', '.').replace('\\', '.')
            except:
                module_name = file_path.stem
            
            # Strip extension
            for ext in ['.js', '.ts', '.jsx', '.tsx', '.mjs', '.cjs']:
                if module_name.endswith(ext):
                    module_name = module_name[:-len(ext)]
            
            self.current_module = f"{prefix}.{module_name}"
            self.module_imports = set()
            
            # Step 1: Extract imports (needed for function_imports tracking)
            self._extract_imports(code)
            
            # Step 2: Extract functions and their calls
            self._extract_functions_and_calls(code, file_path)
            
            # Store imports for this module
            if self.module_imports:
                self.imports_map[module_name] = list(self.module_imports)
            
        except Exception as e:
            pass  # Skip unparseable files
    
    def _extract_imports(self, code: str):
        """Extract imported packages from code."""
        # Remove comments to avoid false matches
        code_clean = re.sub(r'//.*$', '', code, flags=re.MULTILINE)
        code_clean = re.sub(r'/\*[\s\S]*?\*/', '', code_clean)
        
        patterns = [
            # require('module') or require("module")
            r'''require\s*\(\s*['"]([^'"]+)['"]\s*\)''',
            # import ... from 'module'
            r'''import\s+.*?\s+from\s+['"]([^'"]+)['"]''',
            # import 'module' (side effect import)
            r'''import\s+['"]([^'"]+)['"]''',
            # dynamic import('module')
            r'''import\s*\(\s*['"]([^'"]+)['"]\s*\)''',
        ]
        
        for pattern in patterns:
            for match in re.finditer(pattern, code_clean):
                module = match.group(1)
                # Skip relative imports
                if module.startswith('.') or module.startswith('/'):
                    continue
                
                # Get package name (handle scoped packages and subpaths)
                if module.startswith('@'):
                    # Scoped: @scope/package or @scope/package/path
                    parts = module.split('/')
                    if len(parts) >= 2:
                        package = '/'.join(parts[:2])
                    else:
                        package = module
                else:
                    # Regular: package or package/path
                    package = module.split('/')[0]
                
                self.module_imports.add(package)
    
    def _extract_functions_and_calls(self, code: str, file_path: Path):
        """Extract function definitions and their internal calls."""
        # Remove comments but keep structure
        code_clean = re.sub(r'//.*$', '', code, flags=re.MULTILINE)
        code_clean = re.sub(r'/\*[\s\S]*?\*/', '', code_clean)
        
        # Find all function definitions with their positions
        functions = self._find_functions(code_clean)
        
        # For each function, extract its body and find calls
        for func_name, start_pos, end_pos in functions:
            qualified_name = f"{self.current_module}.{func_name}"
            self.all_functions.add(qualified_name)
            
            # Store function metadata for reachability tracking
            self.function_metadata[qualified_name] = {
                'file': self.current_file,
                'module': self.current_module,
                'line': None  # Could extract from position if needed
            }
            
            # Extract function body
            body = code_clean[start_pos:end_pos]
            
            # Find all function calls in body
            calls = self._extract_calls(body)
            
            for call in calls:
                # Track the call in call graph
                self.call_graph[qualified_name].add(call)
                
                # Track which imports this function uses
                call_base = call.split('.')[0] if '.' in call else call
                for imp in self.module_imports:
                    # Check if call matches import (e.g., axios.get matches axios)
                    imp_base = imp.split('/')[0].lstrip('@')
                    if call_base.lower() == imp_base.lower() or call_base.lower() == imp.replace('-', '').replace('/', '').lower():
                        self.function_imports[qualified_name].add(imp)
    
    def _find_functions(self, code: str) -> List[Tuple[str, int, int]]:
        """Find all function definitions and their body positions."""
        functions = []
        
        # Patterns that capture function name and opening brace position
        patterns = [
            # function name() {
            (r'function\s+(\w+)\s*\([^)]*\)\s*\{', 1),
            # async function name() {
            (r'async\s+function\s+(\w+)\s*\([^)]*\)\s*\{', 1),
            # const name = function() {
            (r'(?:const|let|var)\s+(\w+)\s*=\s*function\s*\([^)]*\)\s*\{', 1),
            # const name = () => {
            (r'(?:const|let|var)\s+(\w+)\s*=\s*(?:async\s*)?\([^)]*\)\s*=>\s*\{', 1),
            # const name = async () => {
            (r'(?:const|let|var)\s+(\w+)\s*=\s*async\s*\([^)]*\)\s*=>\s*\{', 1),
            # name() { (method in class/object - simplified)
            (r'^\s+(\w+)\s*\([^)]*\)\s*\{', 1),
            # name: function() {
            (r'(\w+)\s*:\s*(?:async\s*)?function\s*\([^)]*\)\s*\{', 1),
        ]
        
        # Keywords to skip
        skip_keywords = {'if', 'for', 'while', 'switch', 'catch', 'with', 'return', 
                         'class', 'new', 'throw', 'typeof', 'instanceof', 'async', 'await',
                         'import', 'export', 'default', 'from', 'get', 'set'}
        
        for pattern, group_idx in patterns:
            for match in re.finditer(pattern, code, re.MULTILINE):
                func_name = match.group(group_idx)
                if func_name in skip_keywords:
                    continue
                
                # Find the opening brace
                brace_pos = match.end() - 1
                if brace_pos < len(code) and code[brace_pos] == '{':
                    # Find matching closing brace
                    end_pos = self._find_matching_brace(code, brace_pos)
                    if end_pos > brace_pos:
                        functions.append((func_name, brace_pos, end_pos))
        
        return functions
    
    def _find_matching_brace(self, code: str, start: int) -> int:
        """Find the position of matching closing brace."""
        depth = 0
        in_string = False
        string_char = None
        
        for i in range(start, min(start + 50000, len(code))):
            char = code[i]
            
            # Handle strings
            if char in '"\'`' and (i == 0 or code[i-1] != '\\'):
                if not in_string:
                    in_string = True
                    string_char = char
                elif char == string_char:
                    in_string = False
                continue
            
            if in_string:
                continue
            
            if char == '{':
                depth += 1
            elif char == '}':
                depth -= 1
                if depth == 0:
                    return i + 1
        
        return start
    
    def _extract_calls(self, body: str) -> Set[str]:
        """Extract function calls from function body."""
        calls = set()
        
        # Pattern for function calls (handles chained calls too)
        # Matches: foo(), bar.baz(), this.method(), await fetch(), new Class()
        call_pattern = r'(?:await\s+)?(?:new\s+)?(\w+(?:\.\w+)*)\s*\('
        
        # Built-ins and keywords to skip
        skip = {
            'if', 'for', 'while', 'switch', 'catch', 'with', 'return',
            'throw', 'typeof', 'instanceof', 'delete', 'void', 'new',
            'console', 'Math', 'JSON', 'Object', 'Array', 'String',
            'Number', 'Boolean', 'Date', 'RegExp', 'Error', 'Promise',
            'Map', 'Set', 'WeakMap', 'WeakSet', 'Symbol', 'Proxy',
            'Reflect', 'Intl', 'parseInt', 'parseFloat', 'isNaN', 'isFinite',
            'encodeURI', 'decodeURI', 'encodeURIComponent', 'decodeURIComponent',
            'setTimeout', 'setInterval', 'clearTimeout', 'clearInterval',
            'require', 'import', 'export', 'module', 'exports',
            'this', 'super', 'self', 'window', 'document', 'global',
            'process', 'Buffer', '__dirname', '__filename',
        }
        
        for match in re.finditer(call_pattern, body):
            call = match.group(1)
            call_base = call.split('.')[0]
            
            if call_base in skip:
                continue
            
            # Qualify local calls with current module
            if '.' not in call:
                call = f"{self.current_module}.{call}"
            
            calls.add(call)
        
        return calls
    
    def _resolve_cross_module_calls(self):
        """Resolve cross-module function calls."""
        # Build a lookup of simple function names to qualified names
        func_lookup: Dict[str, List[str]] = defaultdict(list)
        for func in self.all_functions:
            simple_name = func.split('.')[-1]
            func_lookup[simple_name].append(func)
        
        # Resolve calls in call graph
        resolved_graph = defaultdict(set)
        
        for caller, callees in self.call_graph.items():
            for callee in callees:
                # If callee is already qualified and exists, keep it
                if callee in self.all_functions:
                    resolved_graph[caller].add(callee)
                    continue
                
                # Try to resolve unqualified call
                simple_name = callee.split('.')[-1]
                if simple_name in func_lookup:
                    # Prefer function in same module
                    caller_module = '.'.join(caller.split('.')[:-1])
                    for candidate in func_lookup[simple_name]:
                        candidate_module = '.'.join(candidate.split('.')[:-1])
                        if candidate_module == caller_module:
                            resolved_graph[caller].add(candidate)
                            break
                    else:
                        # Use first match if no same-module match
                        resolved_graph[caller].add(func_lookup[simple_name][0])
                else:
                    # Keep unresolved (might be external library call)
                    resolved_graph[caller].add(callee)
        
        self.call_graph = resolved_graph

def parse_package_json(package_json_path: Path) -> Dict:
    """Parse package.json to extract dependencies."""
    import json
    
    try:
        with open(package_json_path, 'r') as f:
            data = json.load(f)
        
        deps = {}
        if 'dependencies' in data:
            deps.update(data['dependencies'])
        if 'devDependencies' in data:
            deps.update(data['devDependencies'])
        
        return {
            'name': data.get('name', 'unknown'),
            'version': data.get('version', '0.0.0'),
            'dependencies': deps,
            'scripts': data.get('scripts', {}),
            'main': data.get('main', 'index.js')
        }
    except Exception as e:
        return {}

def detect_javascript_project(directory: Path) -> bool:
    """Check if directory is a JavaScript/TypeScript project."""
    indicators = [
        directory / 'package.json',
        directory / 'package-lock.json',
        directory / 'yarn.lock',
        directory / 'tsconfig.json',
    ]
    return any(indicator.exists() for indicator in indicators)

if __name__ == '__main__':
    import sys
    
    # Test with sample code
    test_code = '''
    import axios from 'axios';
    import { useState } from 'react';
    
    function fetchData(url) {
        return axios.get(url);
    }
    
    async function processData(data) {
        const result = transformData(data);
        return result;
    }
    
    function transformData(input) {
        return input.map(x => x * 2);
    }
    
    export async function main() {
        const data = await fetchData('/api/data');
        const processed = await processData(data);
        console.log(processed);
    }
    '''
    
    print("=" * 60)
    print("FIXED JavaScript Parser - Test")
    print("=" * 60)
    
    parser = JavaScriptParser()
    parser.current_module = "app.test"
    parser._extract_imports(test_code)
    
    from pathlib import Path
    parser._extract_functions_and_calls(test_code, Path("test.js"))
    
    print(f"\n📦 Imports found: {parser.module_imports}")
    print(f"\n📋 Functions found ({len(parser.all_functions)}):")
    for func in sorted(parser.all_functions):
        print(f"   • {func}")
    
    print(f"\n🔗 Call graph ({sum(len(v) for v in parser.call_graph.values())} edges):")
    for caller, callees in sorted(parser.call_graph.items()):
        print(f"   {caller} →")
        for callee in sorted(callees):
            print(f"      → {callee}")
    
    print(f"\n📊 Function imports:")
    for func, imports in sorted(parser.function_imports.items()):
        if imports:
            print(f"   {func}: {imports}")
    
    # Verify fix
    edge_count = sum(len(v) for v in parser.call_graph.values())
    print(f"\n{'✅' if edge_count > 0 else '❌'} Edge count: {edge_count}")
    print(f"{'✅' if parser.function_imports else '❌'} Function imports populated: {bool(parser.function_imports)}")
