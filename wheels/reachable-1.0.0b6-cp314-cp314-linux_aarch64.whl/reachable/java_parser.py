#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.

"""
Java/Kotlin/Scala/Groovy Call Graph Parser

Full support for Java ecosystem including:
- Maven (pom.xml) - single and multi-module projects
- Gradle (build.gradle, build.gradle.kts) - Groovy and Kotlin DSL
- Java, Kotlin, Scala, Groovy source files
- Android projects (build.gradle with android plugin)

Call graph extraction for reachability analysis:
- Method calls (static, instance, constructor)
- Class hierarchy (extends, implements)
- Annotation processing (@RestController, @Service, etc.)
- Spring/Jakarta entrypoints detection
- Reflection detection
"""

import re
import os
import xml.etree.ElementTree as ET
from pathlib import Path
from typing import Dict, Set, List, Tuple, Optional, Any
from collections import defaultdict
from dataclasses import dataclass, field
import logging

logger = logging.getLogger(__name__)

# ═══════════════════════════════════════════════════════════════════════════════
# DATA STRUCTURES
# ═══════════════════════════════════════════════════════════════════════════════

@dataclass
class JavaMethod:
    """Represents a Java method with full metadata."""
    name: str
    class_name: str
    package: str
    return_type: str = "void"
    parameters: List[str] = field(default_factory=list)
    modifiers: Set[str] = field(default_factory=set)
    annotations: List[str] = field(default_factory=list)
    file_path: str = ""
    line_number: int = 0
    is_entrypoint: bool = False
    entrypoint_type: Optional[str] = None  # http, cli, event, scheduled, etc.
    
    @property
    def fqn(self) -> str:
        """Fully qualified name."""
        return f"{self.package}.{self.class_name}.{self.name}"
    
    @property
    def signature(self) -> str:
        """Method signature for matching."""
        params = ", ".join(self.parameters)
        return f"{self.name}({params})"

@dataclass
class JavaClass:
    """Represents a Java class with full metadata."""
    name: str
    package: str
    extends: Optional[str] = None
    implements: List[str] = field(default_factory=list)
    annotations: List[str] = field(default_factory=list)
    methods: List[JavaMethod] = field(default_factory=list)
    fields: List[str] = field(default_factory=list)
    imports: List[str] = field(default_factory=list)
    file_path: str = ""
    is_interface: bool = False
    is_abstract: bool = False
    is_enum: bool = False
    
    @property
    def fqn(self) -> str:
        """Fully qualified name."""
        return f"{self.package}.{self.name}"

@dataclass 
class MavenModule:
    """Represents a Maven module."""
    artifact_id: str
    group_id: str
    version: str
    packaging: str = "jar"
    parent: Optional[str] = None
    modules: List[str] = field(default_factory=list)
    dependencies: List[Dict[str, str]] = field(default_factory=list)
    dependency_management: List[Dict[str, str]] = field(default_factory=list)
    properties: Dict[str, str] = field(default_factory=dict)
    build_plugins: List[str] = field(default_factory=list)
    source_directory: str = "src/main/java"
    test_source_directory: str = "src/test/java"
    pom_path: str = ""

@dataclass
class GradleModule:
    """Represents a Gradle module/project."""
    name: str
    group: str = ""
    version: str = ""
    plugins: List[str] = field(default_factory=list)
    dependencies: List[Dict[str, str]] = field(default_factory=list)
    subprojects: List[str] = field(default_factory=list)
    source_sets: Dict[str, List[str]] = field(default_factory=dict)
    build_file: str = ""
    is_android: bool = False
    is_kotlin: bool = False
    is_spring_boot: bool = False

# ═══════════════════════════════════════════════════════════════════════════════
# ENTRYPOINT PATTERNS (Spring, Jakarta, Android, etc.)
# ═══════════════════════════════════════════════════════════════════════════════

# HTTP/REST entrypoints
HTTP_ANNOTATIONS = {
    # Spring MVC/WebFlux
    '@RequestMapping', '@GetMapping', '@PostMapping', '@PutMapping', 
    '@DeleteMapping', '@PatchMapping', '@RestController', '@Controller',
    # Jakarta/JAX-RS
    '@Path', '@GET', '@POST', '@PUT', '@DELETE', '@PATCH', '@HEAD', '@OPTIONS',
    # Micronaut
    '@Get', '@Post', '@Put', '@Delete', '@Patch',
    # Quarkus
    '@Produces', '@Consumes',
    # gRPC
    '@GrpcService',
}

# Class-level entrypoint markers
CONTROLLER_ANNOTATIONS = {
    '@RestController', '@Controller', '@Path', '@Resource',
    '@WebServlet', '@WebService', '@GrpcService',
}

# Event/Message handlers
EVENT_ANNOTATIONS = {
    # Spring
    '@EventListener', '@TransactionalEventListener', '@Async',
    '@KafkaListener', '@RabbitListener', '@JmsListener',
    '@Scheduled', '@Schedules',
    # Jakarta
    '@Observes', '@ObservesAsync',
    # Android
    '@OnClick', '@OnLongClick', '@OnTouch', '@Subscribe',
}

# Lifecycle entrypoints
LIFECYCLE_ANNOTATIONS = {
    '@PostConstruct', '@PreDestroy',
    '@Bean', '@Configuration',
    # Android
    '@Override',  # When in Activity/Fragment context
}

# Main method patterns
MAIN_METHOD_PATTERN = re.compile(
    r'public\s+static\s+void\s+main\s*\(\s*String\s*\[\s*\]\s+\w+\s*\)'
)

# Android lifecycle methods
ANDROID_LIFECYCLE_METHODS = {
    'onCreate', 'onStart', 'onResume', 'onPause', 'onStop', 'onDestroy',
    'onCreateView', 'onViewCreated', 'onActivityCreated',
    'onAttach', 'onDetach', 'onDestroyView',
    'onReceive',  # BroadcastReceiver
    'onStartCommand', 'onBind',  # Service
}

# ═══════════════════════════════════════════════════════════════════════════════
# MAVEN PARSER
# ═══════════════════════════════════════════════════════════════════════════════

class MavenParser:
    """Parse Maven pom.xml files including multi-module projects."""
    
    MAVEN_NS = {'m': 'http://maven.apache.org/POM/4.0.0'}
    
    def __init__(self):
        self.modules: Dict[str, MavenModule] = {}
        self.root_pom: Optional[str] = None
        self.dependency_tree: Dict[str, Set[str]] = defaultdict(set)
        self.effective_pom_cache: Dict[str, Dict] = {}
    
    def parse_project(self, project_dir: Path) -> Dict[str, MavenModule]:
        """
        Parse a Maven project (single or multi-module).
        
        Returns dict of artifact_id -> MavenModule
        """
        # Find root pom.xml
        root_pom = project_dir / 'pom.xml'
        if not root_pom.exists():
            # Check for nested pom
            poms = list(project_dir.rglob('pom.xml'))
            if poms:
                root_pom = min(poms, key=lambda p: len(p.parts))
            else:
                logger.warning(f"No pom.xml found in {project_dir}")
                return {}
        
        self.root_pom = str(root_pom)
        self._parse_pom(root_pom)
        
        return self.modules
    
    def _parse_pom(self, pom_path: Path, parent_props: Dict[str, str] = None) -> Optional[MavenModule]:
        """Parse a single pom.xml file."""
        if not pom_path.exists():
            return None
        
        try:
            tree = ET.parse(pom_path)
            root = tree.getroot()
            
            # Handle namespace
            ns = self.MAVEN_NS if root.tag.startswith('{') else {}
            
            def find(elem, path):
                if ns:
                    return elem.find(f"m:{path}", ns)
                return elem.find(path)
            
            def find_text(elem, path, default=""):
                el = find(elem, path)
                return el.text.strip() if el is not None and el.text else default
            
            # Parse properties first (needed for variable resolution)
            properties = dict(parent_props) if parent_props else {}
            props_elem = find(root, 'properties')
            if props_elem is not None:
                for prop in props_elem:
                    tag = prop.tag.replace(f"{{{self.MAVEN_NS['m']}}}", "") if ns else prop.tag
                    if prop.text:
                        properties[tag] = prop.text.strip()
            
            # Get parent info
            parent_elem = find(root, 'parent')
            parent_group = parent_artifact = parent_version = None
            if parent_elem is not None:
                parent_group = find_text(parent_elem, 'groupId')
                parent_artifact = find_text(parent_elem, 'artifactId')
                parent_version = find_text(parent_elem, 'version')
            
            # Get module info (inherit from parent if not specified)
            group_id = find_text(root, 'groupId') or parent_group or ""
            artifact_id = find_text(root, 'artifactId') or ""
            version = find_text(root, 'version') or parent_version or ""
            packaging = find_text(root, 'packaging', 'jar')
            
            # Resolve property references
            group_id = self._resolve_properties(group_id, properties)
            version = self._resolve_properties(version, properties)
            
            # Store in properties for child resolution
            properties['project.groupId'] = group_id
            properties['project.artifactId'] = artifact_id
            properties['project.version'] = version
            
            module = MavenModule(
                artifact_id=artifact_id,
                group_id=group_id,
                version=version,
                packaging=packaging,
                parent=f"{parent_group}:{parent_artifact}:{parent_version}" if parent_artifact else None,
                properties=properties,
                pom_path=str(pom_path),
            )
            
            # Parse dependencies
            deps_elem = find(root, 'dependencies')
            if deps_elem is not None:
                for dep in deps_elem.findall('m:dependency', ns) if ns else deps_elem.findall('dependency'):
                    dep_info = {
                        'groupId': self._resolve_properties(find_text(dep, 'groupId'), properties),
                        'artifactId': self._resolve_properties(find_text(dep, 'artifactId'), properties),
                        'version': self._resolve_properties(find_text(dep, 'version'), properties),
                        'scope': find_text(dep, 'scope', 'compile'),
                        'optional': find_text(dep, 'optional', 'false') == 'true',
                    }
                    module.dependencies.append(dep_info)
                    
                    # Track dependency graph
                    dep_key = f"{dep_info['groupId']}:{dep_info['artifactId']}"
                    self.dependency_tree[artifact_id].add(dep_key)
            
            # Parse dependency management
            dep_mgmt = find(root, 'dependencyManagement')
            if dep_mgmt is not None:
                deps = find(dep_mgmt, 'dependencies')
                if deps is not None:
                    for dep in deps.findall('m:dependency', ns) if ns else deps.findall('dependency'):
                        dep_info = {
                            'groupId': self._resolve_properties(find_text(dep, 'groupId'), properties),
                            'artifactId': self._resolve_properties(find_text(dep, 'artifactId'), properties),
                            'version': self._resolve_properties(find_text(dep, 'version'), properties),
                            'scope': find_text(dep, 'scope', 'compile'),
                        }
                        module.dependency_management.append(dep_info)
            
            # Parse submodules
            modules_elem = find(root, 'modules')
            if modules_elem is not None:
                for mod in modules_elem.findall('m:module', ns) if ns else modules_elem.findall('module'):
                    if mod.text:
                        submodule_name = mod.text.strip()
                        module.modules.append(submodule_name)
                        
                        # Parse submodule recursively
                        submodule_pom = pom_path.parent / submodule_name / 'pom.xml'
                        if submodule_pom.exists():
                            self._parse_pom(submodule_pom, properties)
            
            # Parse build section for plugins and source directories
            build_elem = find(root, 'build')
            if build_elem is not None:
                src_dir = find_text(build_elem, 'sourceDirectory')
                if src_dir:
                    module.source_directory = self._resolve_properties(src_dir, properties)
                
                test_dir = find_text(build_elem, 'testSourceDirectory')
                if test_dir:
                    module.test_source_directory = self._resolve_properties(test_dir, properties)
                
                plugins_elem = find(build_elem, 'plugins')
                if plugins_elem is not None:
                    for plugin in plugins_elem.findall('m:plugin', ns) if ns else plugins_elem.findall('plugin'):
                        plugin_artifact = find_text(plugin, 'artifactId')
                        if plugin_artifact:
                            module.build_plugins.append(plugin_artifact)
            
            self.modules[artifact_id] = module
            return module
            
        except ET.ParseError as e:
            logger.error(f"Failed to parse {pom_path}: {e}")
            return None
    
    def _resolve_properties(self, value: str, properties: Dict[str, str]) -> str:
        """Resolve ${property} references in value."""
        if not value or '${' not in value:
            return value
        
        result = value
        for key, val in properties.items():
            result = result.replace(f'${{{key}}}', val)
        
        return result
    
    def get_all_dependencies(self) -> Dict[str, List[Dict[str, str]]]:
        """Get all dependencies across all modules."""
        all_deps = {}
        for artifact_id, module in self.modules.items():
            all_deps[artifact_id] = module.dependencies
        return all_deps
    
    def get_source_directories(self) -> Dict[str, Path]:
        """Get source directories for all modules."""
        source_dirs = {}
        for artifact_id, module in self.modules.items():
            pom_dir = Path(module.pom_path).parent
            src_dir = pom_dir / module.source_directory
            if src_dir.exists():
                source_dirs[artifact_id] = src_dir
        return source_dirs

# ═══════════════════════════════════════════════════════════════════════════════
# GRADLE PARSER
# ═══════════════════════════════════════════════════════════════════════════════

class GradleParser:
    """Parse Gradle build files (Groovy and Kotlin DSL)."""
    
    def __init__(self):
        self.modules: Dict[str, GradleModule] = {}
        self.root_project: Optional[str] = None
        self.dependency_tree: Dict[str, Set[str]] = defaultdict(set)
    
    def parse_project(self, project_dir: Path) -> Dict[str, GradleModule]:
        """
        Parse a Gradle project (single or multi-project).
        
        Handles both Groovy DSL (build.gradle) and Kotlin DSL (build.gradle.kts).
        """
        # Find settings file to identify multi-project
        settings_groovy = project_dir / 'settings.gradle'
        settings_kotlin = project_dir / 'settings.gradle.kts'
        
        if settings_groovy.exists():
            self._parse_settings(settings_groovy, is_kotlin=False)
        elif settings_kotlin.exists():
            self._parse_settings(settings_kotlin, is_kotlin=True)
        
        # Parse root build file
        build_groovy = project_dir / 'build.gradle'
        build_kotlin = project_dir / 'build.gradle.kts'
        
        if build_groovy.exists():
            self._parse_build_file(build_groovy, project_dir.name, is_kotlin=False)
        elif build_kotlin.exists():
            self._parse_build_file(build_kotlin, project_dir.name, is_kotlin=True)
        else:
            # Look for buildSrc or nested projects
            for build_file in project_dir.rglob('build.gradle*'):
                if 'build' not in str(build_file.parent) or build_file.parent.name == 'buildSrc':
                    self._parse_build_file(
                        build_file, 
                        build_file.parent.name,
                        is_kotlin=build_file.suffix == '.kts'
                    )
        
        return self.modules
    
    def _parse_settings(self, settings_file: Path, is_kotlin: bool = False):
        """Parse settings.gradle(.kts) to find subprojects."""
        try:
            content = settings_file.read_text(encoding='utf-8', errors='ignore')
            
            # Find root project name
            if is_kotlin:
                match = re.search(r'rootProject\.name\s*=\s*"([^"]+)"', content)
            else:
                match = re.search(r"rootProject\.name\s*=\s*['\"]([^'\"]+)['\"]", content)
            
            if match:
                self.root_project = match.group(1)
            
            # Find included projects
            # include 'module1', 'module2' (Groovy)
            # include("module1", "module2") (Kotlin)
            include_pattern = r"include\s*\(?['\"]([^'\"]+)['\"]" if not is_kotlin else r'include\s*\(\s*"([^"]+)"'
            
            for match in re.finditer(include_pattern, content):
                subproject = match.group(1).replace(':', '/')
                subproject_dir = settings_file.parent / subproject
                
                build_groovy = subproject_dir / 'build.gradle'
                build_kotlin = subproject_dir / 'build.gradle.kts'
                
                if build_groovy.exists():
                    self._parse_build_file(build_groovy, subproject.replace('/', ':'), is_kotlin=False)
                elif build_kotlin.exists():
                    self._parse_build_file(build_kotlin, subproject.replace('/', ':'), is_kotlin=True)
                    
        except Exception as e:
            logger.error(f"Failed to parse settings file {settings_file}: {e}")
    
    def _parse_build_file(self, build_file: Path, module_name: str, is_kotlin: bool = False):
        """Parse a single build.gradle(.kts) file."""
        try:
            content = build_file.read_text(encoding='utf-8', errors='ignore')
            
            module = GradleModule(
                name=module_name,
                build_file=str(build_file),
                is_kotlin=is_kotlin,
            )
            
            # Parse group and version
            if is_kotlin:
                group_match = re.search(r'group\s*=\s*"([^"]+)"', content)
                version_match = re.search(r'version\s*=\s*"([^"]+)"', content)
            else:
                group_match = re.search(r"group\s*=\s*['\"]([^'\"]+)['\"]", content)
                version_match = re.search(r"version\s*=\s*['\"]([^'\"]+)['\"]", content)
            
            if group_match:
                module.group = group_match.group(1)
            if version_match:
                module.version = version_match.group(1)
            
            # Parse plugins
            self._parse_plugins(content, module, is_kotlin)
            
            # Parse dependencies
            self._parse_dependencies(content, module, is_kotlin)
            
            # Parse source sets
            self._parse_source_sets(content, module, build_file.parent, is_kotlin)
            
            self.modules[module_name] = module
            
        except Exception as e:
            logger.error(f"Failed to parse build file {build_file}: {e}")
    
    def _parse_plugins(self, content: str, module: GradleModule, is_kotlin: bool):
        """Parse plugins block."""
        # plugins { } block
        plugins_match = re.search(r'plugins\s*\{([^}]+)\}', content, re.DOTALL)
        if plugins_match:
            plugins_block = plugins_match.group(1)
            
            # id 'plugin-id' or id("plugin-id")
            if is_kotlin:
                pattern = r'id\s*\(\s*"([^"]+)"\s*\)'
            else:
                pattern = r"id\s*['\"]([^'\"]+)['\"]"
            
            for match in re.finditer(pattern, plugins_block):
                plugin_id = match.group(1)
                module.plugins.append(plugin_id)
                
                # Detect special plugins
                if 'android' in plugin_id:
                    module.is_android = True
                if 'kotlin' in plugin_id:
                    module.is_kotlin = True
                if 'spring-boot' in plugin_id or 'org.springframework.boot' in plugin_id:
                    module.is_spring_boot = True
        
        # Legacy apply plugin: syntax
        apply_pattern = r"apply\s+plugin:\s*['\"]([^'\"]+)['\"]"
        for match in re.finditer(apply_pattern, content):
            plugin_id = match.group(1)
            if plugin_id not in module.plugins:
                module.plugins.append(plugin_id)
    
    def _parse_dependencies(self, content: str, module: GradleModule, is_kotlin: bool):
        """Parse dependencies block."""
        deps_match = re.search(r'dependencies\s*\{([^}]+(?:\{[^}]*\}[^}]*)*)\}', content, re.DOTALL)
        if not deps_match:
            return
        
        deps_block = deps_match.group(1)
        
        # Common configurations
        configs = [
            'implementation', 'api', 'compileOnly', 'runtimeOnly',
            'testImplementation', 'testCompileOnly', 'testRuntimeOnly',
            'annotationProcessor', 'kapt', 'ksp',
            'compile', 'testCompile',  # Legacy
        ]
        
        for config in configs:
            # Group:artifact:version format
            if is_kotlin:
                pattern = rf'{config}\s*\(\s*"([^"]+)"\s*\)'
            else:
                pattern = rf"{config}\s*['\"]([^'\"]+)['\"]"
            
            for match in re.finditer(pattern, deps_block):
                dep_string = match.group(1)
                parts = dep_string.split(':')
                
                if len(parts) >= 2:
                    dep_info = {
                        'groupId': parts[0],
                        'artifactId': parts[1],
                        'version': parts[2] if len(parts) > 2 else '',
                        'configuration': config,
                    }
                    module.dependencies.append(dep_info)
                    
                    # Track dependency graph
                    dep_key = f"{parts[0]}:{parts[1]}"
                    self.dependency_tree[module.name].add(dep_key)
            
            # Project dependencies - project(':module')
            if is_kotlin:
                proj_pattern = rf'{config}\s*\(\s*project\s*\(\s*":([^"]+)"\s*\)\s*\)'
            else:
                proj_pattern = rf"{config}\s+project\s*\(\s*['\"]?:?([^'\")\s]+)['\"]?\s*\)"
            
            for match in re.finditer(proj_pattern, deps_block):
                subproject = match.group(1)
                module.subprojects.append(subproject)
                self.dependency_tree[module.name].add(f"project:{subproject}")
    
    def _parse_source_sets(self, content: str, module: GradleModule, project_dir: Path, is_kotlin: bool):
        """Parse source sets to find source directories."""
        # Default source sets
        default_sets = {
            'main': ['src/main/java', 'src/main/kotlin', 'src/main/groovy', 'src/main/scala'],
            'test': ['src/test/java', 'src/test/kotlin', 'src/test/groovy', 'src/test/scala'],
        }
        
        for set_name, dirs in default_sets.items():
            existing_dirs = []
            for dir_path in dirs:
                full_path = project_dir / dir_path
                if full_path.exists():
                    existing_dirs.append(dir_path)
            if existing_dirs:
                module.source_sets[set_name] = existing_dirs
        
        # Android source sets
        if module.is_android:
            android_sets = {
                'main': ['src/main/java', 'src/main/kotlin'],
                'androidTest': ['src/androidTest/java', 'src/androidTest/kotlin'],
                'test': ['src/test/java', 'src/test/kotlin'],
            }
            for set_name, dirs in android_sets.items():
                for dir_path in dirs:
                    full_path = project_dir / dir_path
                    if full_path.exists() and set_name in module.source_sets:
                        if dir_path not in module.source_sets[set_name]:
                            module.source_sets[set_name].append(dir_path)
    
    def get_all_dependencies(self) -> Dict[str, List[Dict[str, str]]]:
        """Get all dependencies across all modules."""
        all_deps = {}
        for name, module in self.modules.items():
            all_deps[name] = module.dependencies
        return all_deps
    
    def get_source_directories(self) -> Dict[str, List[Path]]:
        """Get source directories for all modules."""
        source_dirs = {}
        for name, module in self.modules.items():
            build_dir = Path(module.build_file).parent
            dirs = []
            for set_name, set_dirs in module.source_sets.items():
                if set_name == 'main':  # Only main source sets for now
                    for dir_path in set_dirs:
                        full_path = build_dir / dir_path
                        if full_path.exists():
                            dirs.append(full_path)
            source_dirs[name] = dirs
        return source_dirs

# ═══════════════════════════════════════════════════════════════════════════════
# JAVA SOURCE PARSER
# ═══════════════════════════════════════════════════════════════════════════════

class JavaSourceParser:
    """
    Parse Java/Kotlin/Scala/Groovy source files for call graph extraction.
    
    Uses regex-based parsing for speed (no external dependencies).
    For more accurate parsing, consider integrating:
    - tree-sitter-java
    - javalang (Python AST parser)
    - srcML
    """
    
    def __init__(self):
        self.call_graph: Dict[str, Set[str]] = defaultdict(set)
        self.all_functions: Set[str] = set()
        self.function_imports: Dict[str, Set[str]] = defaultdict(set)
        self.class_hierarchy: Dict[str, JavaClass] = {}
        self.entrypoints: List[JavaMethod] = []
        self.current_file: str = ""
        self.current_class: Optional[str] = None
        self.current_package: str = ""
        self.imports: List[str] = []
        self.function_metadata: Dict[str, Dict] = {}
    
    def parse_directory(self, directory: Path, prefix: str = "app") -> Tuple[Dict, Dict, Set]:
        """
        Parse all Java/Kotlin/Scala/Groovy files in directory.
        
        Returns:
            Tuple of (call_graph, imports_map, all_functions)
        """
        # Supported extensions
        extensions = ['*.java', '*.kt', '*.scala', '*.groovy']
        
        all_files = []
        for ext in extensions:
            all_files.extend(directory.rglob(ext))
        
        # Exclude build artifacts, tests (optionally), generated code
        source_files = [
            f for f in all_files
            if 'build/' not in str(f) and
               '/target/' not in str(f) and
               '/out/' not in str(f) and
               '/generated/' not in str(f) and
               'node_modules' not in str(f) and
               f.is_file()
        ]
        
        for file_path in source_files:
            self._parse_file(file_path, prefix)
        
        # Build class hierarchy relationships
        self._resolve_inheritance()
        
        return dict(self.call_graph), self._build_imports_map(), self.all_functions
    
    def _parse_file(self, file_path: Path, prefix: str):
        """Parse a single source file."""
        try:
            self.current_file = str(file_path)
            content = file_path.read_text(encoding='utf-8', errors='ignore')
            
            ext = file_path.suffix.lower()
            
            if ext == '.java':
                self._parse_java(content, prefix)
            elif ext == '.kt':
                self._parse_kotlin(content, prefix)
            elif ext == '.groovy':
                self._parse_groovy(content, prefix)
            elif ext == '.scala':
                self._parse_scala(content, prefix)
                
        except Exception as e:
            logger.debug(f"Failed to parse {file_path}: {e}")
    
    def _parse_java(self, content: str, prefix: str):
        """Parse Java source file."""
        # Extract package
        pkg_match = re.search(r'package\s+([\w.]+)\s*;', content)
        self.current_package = pkg_match.group(1) if pkg_match else ""
        
        # Extract imports
        self.imports = []
        for match in re.finditer(r'import\s+(?:static\s+)?([\w.*]+)\s*;', content):
            self.imports.append(match.group(1))
        
        # Parse class/interface/enum declarations
        class_pattern = re.compile(
            r'(?:(@\w+(?:\([^)]*\))?)\s*)*'  # Annotations
            r'(?:public|protected|private)?\s*'
            r'(?:abstract\s+)?(?:final\s+)?'
            r'(class|interface|enum)\s+'
            r'(\w+)'  # Class name
            r'(?:<[^>]+>)?'  # Generics
            r'(?:\s+extends\s+([\w.<>,\s]+))?'  # Extends
            r'(?:\s+implements\s+([\w.<>,\s]+))?',  # Implements
            re.MULTILINE
        )
        
        for match in class_pattern.finditer(content):
            annotations = match.group(1) or ""
            class_type = match.group(2)
            class_name = match.group(3)
            extends = match.group(4).strip() if match.group(4) else None
            implements = [i.strip() for i in match.group(5).split(',')] if match.group(5) else []
            
            self.current_class = class_name
            fqn = f"{self.current_package}.{class_name}" if self.current_package else class_name
            
            java_class = JavaClass(
                name=class_name,
                package=self.current_package,
                extends=extends,
                implements=implements,
                annotations=re.findall(r'@(\w+)', annotations),
                imports=list(self.imports),
                file_path=self.current_file,
                is_interface=class_type == 'interface',
                is_abstract='abstract' in content[:match.start()],
                is_enum=class_type == 'enum',
            )
            
            self.class_hierarchy[fqn] = java_class
            
            # Check for controller/service annotations
            is_controller = any(ann in annotations for ann in CONTROLLER_ANNOTATIONS)
            
            # Parse methods within this class
            self._parse_methods(content, class_name, fqn, is_controller, prefix)
    
    def _parse_methods(self, content: str, class_name: str, class_fqn: str, 
                       is_controller: bool, prefix: str):
        """Parse methods from class content."""
        # Method pattern
        method_pattern = re.compile(
            r'(?:(@\w+(?:\([^)]*\))?)\s*)*'  # Annotations  
            r'(?:public|protected|private)?\s*'
            r'(?:static\s+)?(?:final\s+)?(?:synchronized\s+)?'
            r'(?:<[^>]+>\s+)?'  # Generics
            r'([\w<>\[\],\s]+?)\s+'  # Return type
            r'(\w+)\s*'  # Method name
            r'\(([^)]*)\)'  # Parameters
            r'(?:\s+throws\s+[\w,\s]+)?'  # Throws
            r'\s*\{',  # Opening brace
            re.MULTILINE
        )
        
        for match in method_pattern.finditer(content):
            annotations = match.group(1) or ""
            return_type = match.group(2).strip()
            method_name = match.group(3)
            params = match.group(4)
            
            # Skip constructors (method name == class name) for now
            # Actually, we want to track them
            
            # Build function identifier
            func_id = f"{prefix}.{class_fqn}.{method_name}"
            self.all_functions.add(func_id)
            
            # Track function metadata
            self.function_metadata[func_id] = {
                'file': self.current_file,
                'line': content[:match.start()].count('\n') + 1,
                'class': class_name,
                'package': self.current_package,
                'return_type': return_type,
                'annotations': re.findall(r'@(\w+)', annotations),
            }
            
            # Check if this is an entrypoint
            is_entrypoint = False
            entrypoint_type = None
            
            # HTTP endpoints
            if any(ann in annotations for ann in HTTP_ANNOTATIONS) or is_controller:
                is_entrypoint = True
                entrypoint_type = 'http'
            
            # Event listeners
            if any(ann in annotations for ann in EVENT_ANNOTATIONS):
                is_entrypoint = True
                entrypoint_type = 'event'
            
            # Lifecycle hooks
            if any(ann in annotations for ann in LIFECYCLE_ANNOTATIONS):
                is_entrypoint = True
                entrypoint_type = 'lifecycle'
            
            # main() method
            if method_name == 'main' and 'static' in content[match.start()-50:match.start()]:
                is_entrypoint = True
                entrypoint_type = 'main'
            
            # Android lifecycle
            if method_name in ANDROID_LIFECYCLE_METHODS:
                is_entrypoint = True
                entrypoint_type = 'android_lifecycle'
            
            if is_entrypoint:
                java_method = JavaMethod(
                    name=method_name,
                    class_name=class_name,
                    package=self.current_package,
                    return_type=return_type,
                    annotations=re.findall(r'@(\w+)', annotations),
                    file_path=self.current_file,
                    line_number=content[:match.start()].count('\n') + 1,
                    is_entrypoint=True,
                    entrypoint_type=entrypoint_type,
                )
                self.entrypoints.append(java_method)
            
            # Extract method body for call analysis
            method_start = match.end() - 1  # Position of opening brace
            method_body = self._extract_method_body(content, method_start)
            
            # Find method calls in body
            self._extract_calls(method_body, func_id, prefix)
    
    def _extract_method_body(self, content: str, brace_pos: int) -> str:
        """Extract method body by matching braces."""
        depth = 0
        start = brace_pos
        
        for i in range(brace_pos, len(content)):
            if content[i] == '{':
                depth += 1
            elif content[i] == '}':
                depth -= 1
                if depth == 0:
                    return content[start:i+1]
        
        return content[start:]
    
    def _extract_calls(self, method_body: str, caller: str, prefix: str):
        """Extract method calls from method body."""
        # Method call pattern: something.method() or ClassName.method() or method()
        call_pattern = re.compile(
            r'(?:(\w+)\.)?'  # Optional qualifier (instance or class)
            r'(\w+)\s*'  # Method name
            r'\([^)]*\)',  # Arguments
            re.MULTILINE
        )
        
        # Track imports used by this function
        for match in call_pattern.finditer(method_body):
            qualifier = match.group(1)
            method_name = match.group(2)
            
            # Skip common false positives
            if method_name in ('if', 'for', 'while', 'switch', 'catch', 'synchronized', 'new'):
                continue
            
            # Build callee identifier
            if qualifier:
                # Check if qualifier is an imported class
                imported_class = self._resolve_import(qualifier)
                if imported_class:
                    callee = f"{imported_class}.{method_name}"
                    self.function_imports[caller].add(imported_class.rsplit('.', 1)[0])
                else:
                    # Local or this reference
                    callee = f"{prefix}.{self.current_package}.{qualifier}.{method_name}"
            else:
                # Method in same class or static import
                callee = f"{prefix}.{self.current_package}.{self.current_class}.{method_name}"
            
            self.call_graph[caller].add(callee)
    
    def _resolve_import(self, name: str) -> Optional[str]:
        """Resolve a class name to its fully qualified name using imports."""
        for imp in self.imports:
            if imp.endswith(f'.{name}'):
                return imp
            if imp.endswith('.*'):
                # Wildcard import - assume it could be this class
                return imp.replace('*', name)
        
        # Check java.lang (implicitly imported)
        java_lang_classes = {
            'String', 'Integer', 'Long', 'Double', 'Float', 'Boolean',
            'Object', 'Class', 'System', 'Thread', 'Exception', 'Error',
            'StringBuilder', 'StringBuffer', 'Math', 'Runtime',
        }
        if name in java_lang_classes:
            return f"java.lang.{name}"
        
        return None
    
    def _parse_kotlin(self, content: str, prefix: str):
        """Parse Kotlin source file."""
        # Similar to Java but with Kotlin-specific syntax
        pkg_match = re.search(r'package\s+([\w.]+)', content)
        self.current_package = pkg_match.group(1) if pkg_match else ""
        
        # Kotlin imports
        self.imports = []
        for match in re.finditer(r'import\s+([\w.*]+)', content):
            self.imports.append(match.group(1))
        
        # Class pattern for Kotlin
        class_pattern = re.compile(
            r'(?:(@\w+(?:\([^)]*\))?)\s*)*'
            r'(?:open\s+|sealed\s+|data\s+|abstract\s+)?'
            r'(class|interface|object|enum class)\s+'
            r'(\w+)'
            r'(?:<[^>]+>)?'
            r'(?:\s*:\s*([\w.<>,\s]+))?',
            re.MULTILINE
        )
        
        for match in class_pattern.finditer(content):
            annotations = match.group(1) or ""
            class_type = match.group(2)
            class_name = match.group(3)
            super_types = match.group(4)
            
            self.current_class = class_name
            fqn = f"{self.current_package}.{class_name}" if self.current_package else class_name
            
            # In Kotlin, supertype list contains both extends and implements
            extends = None
            implements = []
            if super_types:
                types = [t.strip() for t in super_types.split(',')]
                for t in types:
                    # Remove constructor call and generics
                    base = re.sub(r'\([^)]*\)', '', t)
                    base = re.sub(r'<[^>]+>', '', base).strip()
                    # First one is typically superclass
                    if extends is None and class_type == 'class':
                        extends = base
                    else:
                        implements.append(base)
            
            java_class = JavaClass(
                name=class_name,
                package=self.current_package,
                extends=extends,
                implements=implements,
                annotations=re.findall(r'@(\w+)', annotations),
                imports=list(self.imports),
                file_path=self.current_file,
                is_interface=class_type == 'interface',
            )
            
            self.class_hierarchy[fqn] = java_class
            
            is_controller = any(ann in annotations for ann in CONTROLLER_ANNOTATIONS)
            self._parse_kotlin_functions(content, class_name, fqn, is_controller, prefix)
    
    def _parse_kotlin_functions(self, content: str, class_name: str, class_fqn: str,
                                 is_controller: bool, prefix: str):
        """Parse Kotlin functions."""
        # fun keyword
        fun_pattern = re.compile(
            r'(?:(@\w+(?:\([^)]*\))?)\s*)*'
            r'(?:suspend\s+)?(?:inline\s+)?(?:override\s+)?'
            r'(?:private|protected|internal|public)?\s*'
            r'fun\s+'
            r'(?:<[^>]+>\s+)?'
            r'(\w+)\s*'
            r'\(([^)]*)\)'
            r'(?:\s*:\s*([\w<>.,\s?]+))?',
            re.MULTILINE
        )
        
        for match in fun_pattern.finditer(content):
            annotations = match.group(1) or ""
            func_name = match.group(2)
            params = match.group(3)
            return_type = match.group(4) or "Unit"
            
            func_id = f"{prefix}.{class_fqn}.{func_name}"
            self.all_functions.add(func_id)
            
            # Check entrypoints
            is_entrypoint = False
            entrypoint_type = None
            
            if any(ann in annotations for ann in HTTP_ANNOTATIONS) or is_controller:
                is_entrypoint = True
                entrypoint_type = 'http'
            
            if is_entrypoint:
                java_method = JavaMethod(
                    name=func_name,
                    class_name=class_name,
                    package=self.current_package,
                    return_type=return_type.strip(),
                    annotations=re.findall(r'@(\w+)', annotations),
                    file_path=self.current_file,
                    line_number=content[:match.start()].count('\n') + 1,
                    is_entrypoint=True,
                    entrypoint_type=entrypoint_type,
                )
                self.entrypoints.append(java_method)
    
    def _parse_groovy(self, content: str, prefix: str):
        """Parse Groovy source file."""
        # Groovy is very similar to Java with some differences
        pkg_match = re.search(r'package\s+([\w.]+)', content)
        self.current_package = pkg_match.group(1) if pkg_match else ""
        
        # Groovy-style class (can omit public, etc.)
        class_pattern = re.compile(
            r'(?:(@\w+(?:\([^)]*\))?)\s*)*'
            r'(?:class|interface|trait|enum)\s+'
            r'(\w+)'
            r'(?:\s+extends\s+([\w.]+))?'
            r'(?:\s+implements\s+([\w.,\s]+))?',
            re.MULTILINE
        )
        
        for match in class_pattern.finditer(content):
            annotations = match.group(1) or ""
            class_name = match.group(2)
            extends = match.group(3)
            implements = [i.strip() for i in match.group(4).split(',')] if match.group(4) else []
            
            self.current_class = class_name
            fqn = f"{self.current_package}.{class_name}" if self.current_package else class_name
            
            java_class = JavaClass(
                name=class_name,
                package=self.current_package,
                extends=extends,
                implements=implements,
                annotations=re.findall(r'@(\w+)', annotations),
                file_path=self.current_file,
            )
            
            self.class_hierarchy[fqn] = java_class
            
            is_controller = any(ann in annotations for ann in CONTROLLER_ANNOTATIONS)
            self._parse_groovy_methods(content, class_name, fqn, is_controller, prefix)
    
    def _parse_groovy_methods(self, content: str, class_name: str, class_fqn: str,
                               is_controller: bool, prefix: str):
        """Parse Groovy methods (can have optional types)."""
        # Groovy method: def methodName() or Type methodName()
        method_pattern = re.compile(
            r'(?:(@\w+(?:\([^)]*\))?)\s*)*'
            r'(?:def|[\w<>\[\]]+)\s+'
            r'(\w+)\s*'
            r'\(([^)]*)\)\s*\{',
            re.MULTILINE
        )
        
        for match in method_pattern.finditer(content):
            annotations = match.group(1) or ""
            method_name = match.group(2)
            
            func_id = f"{prefix}.{class_fqn}.{method_name}"
            self.all_functions.add(func_id)
            
            is_entrypoint = False
            entrypoint_type = None
            
            if any(ann in annotations for ann in HTTP_ANNOTATIONS) or is_controller:
                is_entrypoint = True
                entrypoint_type = 'http'
            
            if is_entrypoint:
                self.entrypoints.append(JavaMethod(
                    name=method_name,
                    class_name=class_name,
                    package=self.current_package,
                    annotations=re.findall(r'@(\w+)', annotations),
                    file_path=self.current_file,
                    line_number=content[:match.start()].count('\n') + 1,
                    is_entrypoint=True,
                    entrypoint_type=entrypoint_type,
                ))
    
    def _parse_scala(self, content: str, prefix: str):
        """Parse Scala source file."""
        pkg_match = re.search(r'package\s+([\w.]+)', content)
        self.current_package = pkg_match.group(1) if pkg_match else ""
        
        # Scala class/object/trait
        class_pattern = re.compile(
            r'(?:(@\w+(?:\([^)]*\))?)\s*)*'
            r'(?:sealed\s+|abstract\s+|final\s+|case\s+)?'
            r'(class|object|trait)\s+'
            r'(\w+)'
            r'(?:\[[^\]]+\])?'
            r'(?:\([^)]*\))?'
            r'(?:\s+extends\s+([\w.\[\]]+))?'
            r'(?:\s+with\s+([\w.\[\],\s]+))?',
            re.MULTILINE
        )
        
        for match in class_pattern.finditer(content):
            annotations = match.group(1) or ""
            class_type = match.group(2)
            class_name = match.group(3)
            extends = match.group(4)
            with_traits = [t.strip() for t in match.group(5).split(' with ')] if match.group(5) else []
            
            self.current_class = class_name
            fqn = f"{self.current_package}.{class_name}" if self.current_package else class_name
            
            java_class = JavaClass(
                name=class_name,
                package=self.current_package,
                extends=extends,
                implements=with_traits,
                annotations=re.findall(r'@(\w+)', annotations),
                file_path=self.current_file,
            )
            
            self.class_hierarchy[fqn] = java_class
            
            # Parse Scala def methods
            self._parse_scala_methods(content, class_name, fqn, prefix)
    
    def _parse_scala_methods(self, content: str, class_name: str, class_fqn: str, prefix: str):
        """Parse Scala methods."""
        method_pattern = re.compile(
            r'(?:override\s+)?def\s+'
            r'(\w+)'
            r'(?:\[[^\]]+\])?'
            r'\s*\(([^)]*)\)'
            r'(?:\s*:\s*([\w\[\].,\s]+))?',
            re.MULTILINE
        )
        
        for match in method_pattern.finditer(content):
            method_name = match.group(1)
            
            func_id = f"{prefix}.{class_fqn}.{method_name}"
            self.all_functions.add(func_id)
    
    def _resolve_inheritance(self):
        """Build inheritance relationships for more accurate call resolution."""
        for fqn, java_class in self.class_hierarchy.items():
            if java_class.extends:
                # Try to find parent class
                parent_fqn = self._resolve_class_name(java_class.extends, java_class.imports)
                if parent_fqn and parent_fqn in self.class_hierarchy:
                    # Inherit method calls
                    pass  # Could add virtual dispatch resolution here
    
    def _resolve_class_name(self, name: str, imports: List[str]) -> Optional[str]:
        """Resolve class name to FQN using imports."""
        # Check if already FQN
        if '.' in name:
            return name
        
        # Check imports
        for imp in imports:
            if imp.endswith(f'.{name}'):
                return imp
            if imp.endswith('.*'):
                pkg = imp[:-2]
                potential = f"{pkg}.{name}"
                if potential in self.class_hierarchy:
                    return potential
        
        return None
    
    def _build_imports_map(self) -> Dict[str, List[str]]:
        """Build module -> imports mapping."""
        imports_map = {}
        for fqn, java_class in self.class_hierarchy.items():
            imports_map[fqn] = java_class.imports
        return imports_map
    
    def get_entrypoints(self) -> List[JavaMethod]:
        """Return detected entrypoints."""
        return self.entrypoints
    
    def get_class_hierarchy(self) -> Dict[str, JavaClass]:
        """Return class hierarchy for inheritance analysis."""
        return self.class_hierarchy
    
    def get_function_imports(self) -> Dict[str, Set[str]]:
        """Return function -> imports mapping for CVE tracking."""
        return dict(self.function_imports)

# ═══════════════════════════════════════════════════════════════════════════════
# UNIFIED JAVA ECOSYSTEM ANALYZER
# ═══════════════════════════════════════════════════════════════════════════════

class JavaEcosystemAnalyzer:
    """
    Unified analyzer for Java ecosystem projects.
    
    Automatically detects and handles:
    - Maven projects (pom.xml)
    - Gradle projects (build.gradle, build.gradle.kts)
    - Standalone Java/Kotlin/Scala/Groovy projects
    """
    
    def __init__(self):
        self.maven_parser: Optional[MavenParser] = None
        self.gradle_parser: Optional[GradleParser] = None
        self.source_parser = JavaSourceParser()
        self.project_type: str = "unknown"
        self.modules: Dict[str, Any] = {}
        self.dependencies: Dict[str, List[Dict]] = {}
    
    def analyze(self, project_dir: Path) -> Dict[str, Any]:
        """
        Analyze a Java ecosystem project.
        
        Returns comprehensive analysis including:
        - Project structure (modules, dependencies)
        - Call graph
        - Entrypoints
        - Class hierarchy
        """
        project_dir = Path(project_dir)
        
        # Detect project type
        self.project_type = self._detect_project_type(project_dir)
        
        # Parse build system
        if self.project_type == 'maven':
            self.maven_parser = MavenParser()
            self.modules = self.maven_parser.parse_project(project_dir)
            self.dependencies = self.maven_parser.get_all_dependencies()
            source_dirs = self.maven_parser.get_source_directories()
            
        elif self.project_type == 'gradle':
            self.gradle_parser = GradleParser()
            self.modules = self.gradle_parser.parse_project(project_dir)
            self.dependencies = self.gradle_parser.get_all_dependencies()
            source_dirs = self.gradle_parser.get_source_directories()
            
        else:
            # Standalone project - look for standard directories
            source_dirs = {'main': project_dir}
            std_dirs = ['src/main/java', 'src/main/kotlin', 'src', 'app/src/main/java']
            for std in std_dirs:
                if (project_dir / std).exists():
                    source_dirs = {'main': project_dir / std}
                    break
        
        # Parse source files
        all_call_graphs = {}
        all_functions = set()
        all_imports = {}
        
        if isinstance(source_dirs, dict):
            for module_name, src_dir in source_dirs.items():
                if isinstance(src_dir, list):
                    for d in src_dir:
                        cg, imp, funcs = self.source_parser.parse_directory(d, f"app.{module_name}")
                        all_call_graphs.update(cg)
                        all_functions.update(funcs)
                        all_imports.update(imp)
                else:
                    cg, imp, funcs = self.source_parser.parse_directory(src_dir, f"app.{module_name}")
                    all_call_graphs.update(cg)
                    all_functions.update(funcs)
                    all_imports.update(imp)
        
        return {
            'project_type': self.project_type,
            'modules': {name: self._module_to_dict(mod) for name, mod in self.modules.items()},
            'dependencies': self.dependencies,
            'call_graph': all_call_graphs,
            'all_functions': list(all_functions),
            'function_count': len(all_functions),
            'imports_map': all_imports,
            'entrypoints': [self._method_to_dict(ep) for ep in self.source_parser.get_entrypoints()],
            'entrypoint_count': len(self.source_parser.get_entrypoints()),
            'class_hierarchy': {
                fqn: self._class_to_dict(cls) 
                for fqn, cls in self.source_parser.get_class_hierarchy().items()
            },
            'class_count': len(self.source_parser.get_class_hierarchy()),
            'function_imports': {k: list(v) for k, v in self.source_parser.get_function_imports().items()},
        }
    
    def _detect_project_type(self, project_dir: Path) -> str:
        """Detect project type based on build files."""
        if (project_dir / 'pom.xml').exists():
            return 'maven'
        
        if (project_dir / 'build.gradle').exists() or (project_dir / 'build.gradle.kts').exists():
            return 'gradle'
        
        # Check for nested build files
        if list(project_dir.rglob('pom.xml')):
            return 'maven'
        
        if list(project_dir.rglob('build.gradle*')):
            return 'gradle'
        
        # Check for Java files without build system
        if list(project_dir.rglob('*.java')) or list(project_dir.rglob('*.kt')):
            return 'java_standalone'
        
        return 'unknown'
    
    def _module_to_dict(self, module) -> Dict:
        """Convert module to serializable dict."""
        if isinstance(module, MavenModule):
            return {
                'type': 'maven',
                'groupId': module.group_id,
                'artifactId': module.artifact_id,
                'version': module.version,
                'packaging': module.packaging,
                'parent': module.parent,
                'submodules': module.modules,
                'dependencies_count': len(module.dependencies),
                'pom_path': module.pom_path,
            }
        elif isinstance(module, GradleModule):
            return {
                'type': 'gradle',
                'name': module.name,
                'group': module.group,
                'version': module.version,
                'plugins': module.plugins,
                'is_android': module.is_android,
                'is_kotlin': module.is_kotlin,
                'is_spring_boot': module.is_spring_boot,
                'subprojects': module.subprojects,
                'dependencies_count': len(module.dependencies),
                'build_file': module.build_file,
            }
        return {}
    
    def _method_to_dict(self, method: JavaMethod) -> Dict:
        """Convert JavaMethod to serializable dict."""
        return {
            'name': method.name,
            'class': method.class_name,
            'package': method.package,
            'fqn': method.fqn,
            'return_type': method.return_type,
            'annotations': method.annotations,
            'file': method.file_path,
            'line': method.line_number,
            'entrypoint_type': method.entrypoint_type,
        }
    
    def _class_to_dict(self, cls: JavaClass) -> Dict:
        """Convert JavaClass to serializable dict."""
        return {
            'name': cls.name,
            'package': cls.package,
            'fqn': cls.fqn,
            'extends': cls.extends,
            'implements': cls.implements,
            'annotations': cls.annotations,
            'is_interface': cls.is_interface,
            'is_abstract': cls.is_abstract,
            'file': cls.file_path,
        }
    
    def get_call_graph(self) -> Dict[str, Set[str]]:
        """Get the call graph."""
        return self.source_parser.call_graph
    
    def get_all_functions(self) -> Set[str]:
        """Get all detected functions."""
        return self.source_parser.all_functions
    
    def get_entrypoints(self) -> List[JavaMethod]:
        """Get detected entrypoints."""
        return self.source_parser.entrypoints
    
    def get_dependencies_for_cve_matching(self) -> List[Dict[str, str]]:
        """
        Get flattened dependency list for CVE matching.
        
        Returns list of {groupId, artifactId, version} for Grype/OSV matching.
        """
        all_deps = []
        for module_deps in self.dependencies.values():
            for dep in module_deps:
                # Skip test and optional deps
                if dep.get('scope') in ('test', 'provided') or dep.get('optional'):
                    continue
                all_deps.append({
                    'groupId': dep.get('groupId', ''),
                    'artifactId': dep.get('artifactId', ''),
                    'version': dep.get('version', ''),
                    'ecosystem': 'maven',
                })
        return all_deps

# ═══════════════════════════════════════════════════════════════════════════════
# MODULE EXPORTS
# ═══════════════════════════════════════════════════════════════════════════════

__all__ = [
    'JavaEcosystemAnalyzer',
    'JavaSourceParser', 
    'MavenParser',
    'GradleParser',
    'JavaMethod',
    'JavaClass',
    'MavenModule',
    'GradleModule',
]

if __name__ == '__main__':
    import sys
    import json
    
    if len(sys.argv) < 2:
        print("Usage: python java_parser.py <project_dir>")
        sys.exit(1)
    
    project_dir = Path(sys.argv[1])
    analyzer = JavaEcosystemAnalyzer()
    result = analyzer.analyze(project_dir)
    
    print(json.dumps({
        'project_type': result['project_type'],
        'modules_count': len(result['modules']),
        'function_count': result['function_count'],
        'entrypoint_count': result['entrypoint_count'],
        'class_count': result['class_count'],
        'entrypoints': result['entrypoints'][:10],  # First 10
    }, indent=2))
