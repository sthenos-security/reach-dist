#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.

"""
REACHABLE Audit Logging System

Comprehensive audit logging for security, compliance, and debugging.

Tracks:
- GitHub repository access (MCP vs git clone)
- API usage and rate limits
- File access and modifications
- Suppression changes
- Analysis runs
- User actions

Audit logs are:
- Immutable (append-only)
- Timestamped
- Machine-readable (JSON)
- Includes user context
- Tracks success/failure
- Records timing metrics
"""

import json
import hashlib
import platform
import socket
from pathlib import Path
from typing import Dict, List, Optional, Any
from dataclasses import dataclass, field, asdict
from datetime import datetime
from enum import Enum

class AuditEventType(Enum):
    """Types of auditable events"""
    ANALYSIS_START = "analysis_start"
    ANALYSIS_COMPLETE = "analysis_complete"
    ANALYSIS_FAILED = "analysis_failed"
    
    GITHUB_FETCH_START = "github_fetch_start"
    GITHUB_FETCH_SUCCESS = "github_fetch_success"
    GITHUB_FETCH_FAILED = "github_fetch_failed"
    GITHUB_CACHE_HIT = "github_cache_hit"
    
    SUPPRESSION_ADDED = "suppression_added"
    SUPPRESSION_REMOVED = "suppression_removed"
    SUPPRESSION_EXPIRED = "suppression_expired"
    
    CORRELATION_START = "correlation_start"
    CORRELATION_COMPLETE = "correlation_complete"
    CORRELATION_THREAT_FOUND = "correlation_threat_found"
    
    API_CALL = "api_call"
    API_RATE_LIMIT = "api_rate_limit"
    
    FILE_CREATED = "file_created"
    FILE_MODIFIED = "file_modified"
    FILE_DELETED = "file_deleted"

@dataclass
class AuditEvent:
    """Individual audit event"""
    timestamp: str  # ISO 8601
    event_type: str  # From AuditEventType
    event_id: str  # Unique ID (hash)
    
    # Context
    user: str  # Username or email
    hostname: str  # Machine name
    process_id: int  # PID
    reachable_version: str  # Tool version
    
    # Event data
    action: str  # Human-readable description
    resource: str  # What was accessed/modified
    status: str  # success, failure, warning
    
    # Optional details
    details: Dict[str, Any] = field(default_factory=dict)
    error: Optional[str] = None
    duration_ms: Optional[float] = None
    
    def to_dict(self) -> Dict:
        """Convert to dictionary for JSON serialization"""
        return asdict(self)

class AuditLogger:
    """
    Audit logging system for REACHABLE
    
    Writes append-only audit logs for compliance and debugging.
    """
    
    def __init__(self, log_dir: Optional[Path] = None):
        """
        Initialize audit logger
        
        Args:
            log_dir: Directory for audit logs (default: ~/.reachable-cache/audit-logs)
        """
        if log_dir is None:
            log_dir = Path.home() / ".reachable-cache" / "audit-logs"
        
        self.log_dir = Path(log_dir)
        self.log_dir.mkdir(parents=True, exist_ok=True)
        
        # Current log file (one per day)
        self.current_log_file = self._get_current_log_file()
        
        # Session context
        self.session_id = self._generate_session_id()
        self.user = self._get_current_user()
        self.hostname = socket.gethostname()
        
    def _get_current_log_file(self) -> Path:
        """Get current log file path (one per day)"""
        date_str = datetime.now().strftime("%Y-%m-%d")
        return self.log_dir / f"reachable-audit-{date_str}.jsonl"
    
    def _generate_session_id(self) -> str:
        """Generate unique session ID"""
        import os
        import time
        data = f"{os.getpid()}{time.time()}{socket.gethostname()}"
        return hashlib.sha256(data.encode()).hexdigest()[:16]
    
    def _get_current_user(self) -> str:
        """Get current user"""
        import os
        import getpass
        try:
            return getpass.getuser()
        except:
            return os.getenv('USER', 'unknown')
    
    def _generate_event_id(self, event: AuditEvent) -> str:
        """Generate unique event ID"""
        data = f"{event.timestamp}{event.event_type}{event.user}{event.resource}"
        return hashlib.sha256(data.encode()).hexdigest()[:16]
    
    def log(self, event_type: AuditEventType, action: str, resource: str,
            status: str = "success", details: Optional[Dict] = None,
            error: Optional[str] = None, duration_ms: Optional[float] = None):
        """
        Log an audit event
        
        Args:
            event_type: Type of event
            action: Human-readable description
            resource: What was accessed/modified
            status: success, failure, warning
            details: Additional details
            error: Error message if failed
            duration_ms: Duration in milliseconds
        """
        from reachable.reachable import __version__
        
        event = AuditEvent(
            timestamp=datetime.now().isoformat() + 'Z',
            event_type=event_type.value,
            event_id="",  # Will be set below
            user=self.user,
            hostname=self.hostname,
            process_id=os.getpid(),
            reachable_version=__version__,
            action=action,
            resource=resource,
            status=status,
            details=details or {},
            error=error,
            duration_ms=duration_ms
        )
        
        # Add session ID to details
        event.details['session_id'] = self.session_id
        
        # Generate event ID
        event.event_id = self._generate_event_id(event)
        
        # Write to log file (append-only)
        self._write_event(event)
    
    def _write_event(self, event: AuditEvent):
        """Write event to log file"""
        try:
            with open(self.current_log_file, 'a') as f:
                f.write(json.dumps(event.to_dict()) + '\n')
        except Exception as e:
            # Don't fail the main operation if audit logging fails
            import sys
            print(f"⚠️  Audit log write failed: {e}", file=sys.stderr)
    
    def log_github_fetch(self, mode: str, repo_url: str, success: bool,
                        duration_ms: float, cached: bool = False,
                        error: Optional[str] = None, details: Optional[Dict] = None):
        """
        Log GitHub repository fetch
        
        Args:
            mode: 'mcp' or 'git-clone'
            repo_url: Repository URL
            success: Whether fetch succeeded
            duration_ms: Duration in milliseconds
            cached: Whether result was cached
            error: Error message if failed
            details: Additional details (file count, size, etc.)
        """
        if cached:
            event_type = AuditEventType.GITHUB_CACHE_HIT
            action = f"GitHub repository fetch (cached, {mode} mode)"
            status = "success"
        elif success:
            event_type = AuditEventType.GITHUB_FETCH_SUCCESS
            action = f"GitHub repository fetch ({mode} mode)"
            status = "success"
        else:
            event_type = AuditEventType.GITHUB_FETCH_FAILED
            action = f"GitHub repository fetch failed ({mode} mode)"
            status = "failure"
        
        fetch_details = {
            'mode': mode,
            'repo_url': repo_url,
            'cached': cached,
            **(details or {})
        }
        
        self.log(
            event_type=event_type,
            action=action,
            resource=repo_url,
            status=status,
            details=fetch_details,
            error=error,
            duration_ms=duration_ms
        )
    
    def log_analysis(self, target: str, success: bool, duration_ms: float,
                    cve_count: int = 0, secret_count: int = 0,
                    malware_count: int = 0, malware_metrics: Dict = None,
                    error: Optional[str] = None):
        """
        Log analysis run
        
        Args:
            target: Analysis target (directory or repo)
            success: Whether analysis succeeded
            duration_ms: Duration in milliseconds
            cve_count: Number of CVEs found
            secret_count: Number of secrets found
            malware_count: Number of malware found
            malware_metrics: Detailed malware detection metrics
            error: Error message if failed
        """
        if success:
            event_type = AuditEventType.ANALYSIS_COMPLETE
            action = "Security analysis completed"
            status = "success"
        else:
            event_type = AuditEventType.ANALYSIS_FAILED
            action = "Security analysis failed"
            status = "failure"
        
        details = {
            'target': target,
            'cve_count': cve_count,
            'secret_count': secret_count,
            'malware_count': malware_count,
            'platform': platform.system(),
            'python_version': platform.python_version()
        }
        
        # Add malware detection metrics if available
        if malware_metrics:
            details['malware_detection'] = {
                'total_packages_scanned': malware_metrics.get('summary', {}).get('total_packages_scanned', 0),
                'malicious_found': malware_metrics.get('summary', {}).get('total_malicious_found', 0),
                'tier1_flagged': malware_metrics.get('escalation_funnel', {}).get('tier1_flagged', 0),
                'tier2_escalated': malware_metrics.get('escalation_funnel', {}).get('tier1_to_tier2', 0),
                'tier3_confirmed': malware_metrics.get('escalation_funnel', {}).get('tier3_confirmed', 0),
                'efficiency_gain_percent': malware_metrics.get('efficiency_metrics', {}).get('time_saved_by_escalation', {}).get('efficiency_gain_percent', 0)
            }
        
        self.log(
            event_type=event_type,
            action=action,
            resource=target,
            status=status,
            details=details,
            error=error,
            duration_ms=duration_ms
        )
    
    def log_suppression(self, suppression_id: str, action_type: str,
                       target: str, reason: str, created_by: str):
        """
        Log suppression changes
        
        Args:
            suppression_id: Suppression ID
            action_type: 'added', 'removed', 'expired'
            target: What was suppressed (CVE ID, secret hash, package name)
            reason: Suppression reason
            created_by: Who created/modified suppression
        """
        event_map = {
            'added': AuditEventType.SUPPRESSION_ADDED,
            'removed': AuditEventType.SUPPRESSION_REMOVED,
            'expired': AuditEventType.SUPPRESSION_EXPIRED
        }
        
        event_type = event_map.get(action_type, AuditEventType.SUPPRESSION_ADDED)
        
        details = {
            'suppression_id': suppression_id,
            'target': target,
            'reason': reason,
            'created_by': created_by
        }
        
        self.log(
            event_type=event_type,
            action=f"Suppression {action_type}",
            resource=target,
            status="success",
            details=details
        )
    
    def get_metrics(self, days: int = 7) -> Dict:
        """
        Get usage metrics from audit logs
        
        Args:
            days: Number of days to analyze
        
        Returns:
            Dictionary with metrics
        """
        from datetime import timedelta
        
        cutoff = datetime.now() - timedelta(days=days)
        
        metrics = {
            'github_fetches': {
                'mcp_mode': 0,
                'git_clone_mode': 0,
                'cache_hits': 0,
                'success_rate': 0.0,
                'avg_duration_ms': 0.0
            },
            'analyses': {
                'total': 0,
                'success': 0,
                'failures': 0,
                'avg_duration_ms': 0.0
            },
            'suppressions': {
                'added': 0,
                'removed': 0,
                'expired': 0
            }
        }
        
        github_durations = []
        analysis_durations = []
        github_success = 0
        github_total = 0
        
        # Read recent log files
        for log_file in self.log_dir.glob("reachable-audit-*.jsonl"):
            try:
                with open(log_file) as f:
                    for line in f:
                        try:
                            event = json.loads(line)
                            event_time = datetime.fromisoformat(event['timestamp'].replace('Z', '+00:00'))
                            
                            if event_time < cutoff:
                                continue
                            
                            # GitHub metrics
                            if event['event_type'] in ['github_fetch_success', 'github_fetch_failed', 'github_cache_hit']:
                                github_total += 1
                                mode = event['details'].get('mode', 'unknown')
                                
                                if event['event_type'] == 'github_cache_hit':
                                    metrics['github_fetches']['cache_hits'] += 1
                                    github_success += 1
                                elif event['event_type'] == 'github_fetch_success':
                                    if mode == 'mcp':
                                        metrics['github_fetches']['mcp_mode'] += 1
                                    else:
                                        metrics['github_fetches']['git_clone_mode'] += 1
                                    github_success += 1
                                    if event.get('duration_ms'):
                                        github_durations.append(event['duration_ms'])
                            
                            # Analysis metrics
                            elif event['event_type'] in ['analysis_complete', 'analysis_failed']:
                                metrics['analyses']['total'] += 1
                                if event['event_type'] == 'analysis_complete':
                                    metrics['analyses']['success'] += 1
                                else:
                                    metrics['analyses']['failures'] += 1
                                if event.get('duration_ms'):
                                    analysis_durations.append(event['duration_ms'])
                            
                            # Suppression metrics
                            elif 'suppression' in event['event_type']:
                                if 'added' in event['event_type']:
                                    metrics['suppressions']['added'] += 1
                                elif 'removed' in event['event_type']:
                                    metrics['suppressions']['removed'] += 1
                                elif 'expired' in event['event_type']:
                                    metrics['suppressions']['expired'] += 1
                        
                        except json.JSONDecodeError:
                            continue
            except:
                continue
        
        # Calculate averages
        if github_total > 0:
            metrics['github_fetches']['success_rate'] = round((github_success / github_total) * 100, 1)
        
        if github_durations:
            metrics['github_fetches']['avg_duration_ms'] = round(sum(github_durations) / len(github_durations), 1)
        
        if analysis_durations:
            metrics['analyses']['avg_duration_ms'] = round(sum(analysis_durations) / len(analysis_durations), 1)
        
        return metrics

# Global audit logger instance
_audit_logger: Optional[AuditLogger] = None

def get_audit_logger() -> AuditLogger:
    """Get global audit logger instance"""
    global _audit_logger
    if _audit_logger is None:
        _audit_logger = AuditLogger()
    return _audit_logger

if __name__ == '__main__':
    import sys
    
    if len(sys.argv) < 2:
        print("REACHABLE Audit Log Viewer")
        print()
        print("Usage:")
        print("  python audit_log.py <command>")
        print()
        print("Commands:")
        print("  view [days]     View recent audit events (default: 1 day)")
        print("  metrics [days]  Show usage metrics (default: 7 days)")
        print("  export [days]   Export events to JSON (default: 7 days)")
        sys.exit(1)
    
    command = sys.argv[1]
    days = int(sys.argv[2]) if len(sys.argv) > 2 else (1 if command == 'view' else 7)
    
    logger = get_audit_logger()
    
    if command == 'view':
        from datetime import timedelta
        cutoff = datetime.now() - timedelta(days=days)
        
        print(f"Audit Events (last {days} day{'s' if days > 1 else ''}):")
        print("=" * 70)
        
        for log_file in sorted(logger.log_dir.glob("reachable-audit-*.jsonl")):
            with open(log_file) as f:
                for line in f:
                    try:
                        event = json.loads(line)
                        event_time = datetime.fromisoformat(event['timestamp'].replace('Z', '+00:00'))
                        
                        if event_time < cutoff:
                            continue
                        
                        status_icon = "✅" if event['status'] == 'success' else "❌" if event['status'] == 'failure' else "⚠️"
                        print(f"{status_icon} [{event['timestamp']}] {event['action']}")
                        print(f"   Resource: {event['resource']}")
                        print(f"   User: {event['user']}@{event['hostname']}")
                        if event.get('duration_ms'):
                            print(f"   Duration: {event['duration_ms']:.1f}ms")
                        if event.get('error'):
                            print(f"   Error: {event['error']}")
                        print()
                    except:
                        continue
    
    elif command == 'metrics':
        metrics = logger.get_metrics(days=days)
        
        print(f"Usage Metrics (last {days} days):")
        print("=" * 70)
        print()
        print("📊 GitHub Fetches:")
        print(f"   MCP mode: {metrics['github_fetches']['mcp_mode']}")
        print(f"   Git clone mode: {metrics['github_fetches']['git_clone_mode']}")
        print(f"   Cache hits: {metrics['github_fetches']['cache_hits']}")
        print(f"   Success rate: {metrics['github_fetches']['success_rate']}%")
        print(f"   Avg duration: {metrics['github_fetches']['avg_duration_ms']:.1f}ms")
        print()
        print("🔍 Analyses:")
        print(f"   Total: {metrics['analyses']['total']}")
        print(f"   Success: {metrics['analyses']['success']}")
        print(f"   Failures: {metrics['analyses']['failures']}")
        print(f"   Avg duration: {metrics['analyses']['avg_duration_ms']:.1f}ms")
        print()
        print("🚫 Suppressions:")
        print(f"   Added: {metrics['suppressions']['added']}")
        print(f"   Removed: {metrics['suppressions']['removed']}")
        print(f"   Expired: {metrics['suppressions']['expired']}")
    
    elif command == 'export':
        from datetime import timedelta
        cutoff = datetime.now() - timedelta(days=days)
        
        events = []
        for log_file in sorted(logger.log_dir.glob("reachable-audit-*.jsonl")):
            with open(log_file) as f:
                for line in f:
                    try:
                        event = json.loads(line)
                        event_time = datetime.fromisoformat(event['timestamp'].replace('Z', '+00:00'))
                        if event_time >= cutoff:
                            events.append(event)
                    except:
                        continue
        
        print(json.dumps({'events': events, 'count': len(events)}, indent=2))
