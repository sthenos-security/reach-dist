# Copyright © 2026 Sthenos Security. All rights reserved.

"""
REACHABLE Compliance Framework Mapping

Maps REACHABLE capabilities and scan findings to major compliance frameworks:
- SOC 2 Type II
- SLSA (Supply Chain Levels for Software Artifacts)
- NIST SSDF (Secure Software Development Framework)
- ISO/IEC 27001:2022
- FedRAMP / NIST 800-53
- PCI DSS 4.0
- HIPAA Security Rule
- GDPR (Technical Measures)

This module provides:
1. Framework definitions with control mappings
2. Capability-to-control relationships
3. Finding-to-control mappings
4. Compliance scoring and gap analysis
5. Dashboard-ready compliance reports
"""

from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any, Dict, List, Optional, Set, Tuple
import json

class Framework(Enum):
    """Supported compliance frameworks"""
    SOC2 = "SOC 2 Type II"
    SLSA = "SLSA"
    SSDF = "NIST SSDF"
    ISO27001 = "ISO/IEC 27001:2022"
    FEDRAMP = "FedRAMP / NIST 800-53"
    PCI_DSS = "PCI DSS 4.0"
    STRIDE = "STRIDE Threat Model"

class ThreatCategory(Enum):
    """STRIDE threat categories"""
    SPOOFING = "Spoofing"
    TAMPERING = "Tampering"
    REPUDIATION = "Repudiation"
    INFORMATION_DISCLOSURE = "Information Disclosure"
    DENIAL_OF_SERVICE = "Denial of Service"
    ELEVATION_OF_PRIVILEGE = "Elevation of Privilege"

class ControlStatus(Enum):
    """Status of a compliance control"""
    SATISFIED = "satisfied"      # Control fully addressed
    PARTIAL = "partial"          # Control partially addressed
    NOT_SATISFIED = "not_satisfied"  # Control not addressed
    NOT_APPLICABLE = "n/a"       # Control not applicable to this scan
    REQUIRES_REVIEW = "requires_review"  # Manual review needed

class Severity(Enum):
    """Control importance for compliance"""
    CRITICAL = "critical"
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"

@dataclass
class Control:
    """A single compliance control/requirement"""
    id: str                      # e.g., "CC6.1", "AC-3"
    name: str                    # Human-readable name
    description: str             # Full description
    framework: Framework
    severity: Severity
    category: str               # e.g., "Access Control", "Logging"
    
    # What REACHABLE capabilities address this control
    capabilities: List[str] = field(default_factory=list)
    
    # What findings (if present) indicate control failure
    violation_indicators: List[str] = field(default_factory=list)
    
    # Evidence types that demonstrate compliance
    evidence_types: List[str] = field(default_factory=list)

@dataclass
class ControlResult:
    """Result of evaluating a control against scan findings"""
    control: Control
    status: ControlStatus
    evidence: List[str] = field(default_factory=list)
    gaps: List[str] = field(default_factory=list)
    findings_count: int = 0
    recommendation: Optional[str] = None

@dataclass
class FrameworkReport:
    """Compliance report for a single framework"""
    framework: Framework
    scan_id: str
    timestamp: str
    total_controls: int
    satisfied: int
    partial: int
    not_satisfied: int
    not_applicable: int
    compliance_score: float  # 0.0 - 100.0
    controls: List[ControlResult] = field(default_factory=list)
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "framework": self.framework.value,
            "scan_id": self.scan_id,
            "timestamp": self.timestamp,
            "summary": {
                "total_controls": self.total_controls,
                "satisfied": self.satisfied,
                "partial": self.partial,
                "not_satisfied": self.not_satisfied,
                "not_applicable": self.not_applicable,
                "compliance_score": round(self.compliance_score, 1)
            },
            "controls": [
                {
                    "id": cr.control.id,
                    "name": cr.control.name,
                    "category": cr.control.category,
                    "severity": cr.control.severity.value,
                    "status": cr.status.value,
                    "evidence": cr.evidence,
                    "gaps": cr.gaps,
                    "findings_count": cr.findings_count,
                    "recommendation": cr.recommendation
                }
                for cr in self.controls
            ]
        }

# =============================================================================
# =============================================================================

REACHABLE_CAPABILITIES = {
    # Core scanning capabilities
    "sbom_generation": {
        "name": "SBOM Generation",
        "description": "Generate Software Bill of Materials using Syft",
        "evidence": "SBOM document in CycloneDX/SPDX format"
    },
    "vulnerability_scanning": {
        "name": "Vulnerability Scanning",
        "description": "CVE detection using Grype and multiple databases",
        "evidence": "Vulnerability report with CVE IDs and severity"
    },
    "reachability_analysis": {
        "name": "Reachability Analysis",
        "description": "Determine if vulnerable code is actually executed",
        "evidence": "Reachability score and call graph analysis"
    },
    "malware_detection": {
        "name": "Malware Detection",
        "description": "Static malware scanning with GuardDog and YARA",
        "evidence": "Malware scan results with rule matches"
    },
    "sandbox_behavioral": {
        "name": "Behavioral Sandbox",
        "description": "Install-time behavioral analysis in isolated container",
        "evidence": "Sandbox verdict and capability score"
    },
    "secrets_detection": {
        "name": "Secrets Detection",
        "description": "Detect hardcoded secrets and credentials",
        "evidence": "Secrets scan results with locations"
    },
    "env_config_secrets": {
        "name": "ENV-001 Config Secrets",
        "description": "Detect secrets in .env files, CI/CD configs, K8s manifests (Base64 decoded)",
        "evidence": "ENV-001 findings with decoded secrets and remediation"
    },
    "license_compliance": {
        "name": "License Compliance",
        "description": "Identify and validate open source licenses",
        "evidence": "License inventory and policy violations"
    },
    "provenance_verification": {
        "name": "Provenance Verification",
        "description": "Verify package authenticity and signatures",
        "evidence": "Signature verification results"
    },
    "vex_generation": {
        "name": "VEX Document Generation",
        "description": "Generate Vulnerability Exploitability eXchange documents",
        "evidence": "VEX document with exploitability assessments"
    },
    "audit_logging": {
        "name": "Audit Logging",
        "description": "Immutable audit trail of all scan activities",
        "evidence": "Audit log entries with timestamps"
    },
    "policy_enforcement": {
        "name": "Policy Enforcement",
        "description": "Configurable security policies with automated enforcement",
        "evidence": "Policy evaluation results"
    },
    "ci_cd_integration": {
        "name": "CI/CD Integration",
        "description": "Automated scanning in build pipelines",
        "evidence": "CI/CD scan execution logs"
    },
    "dependency_graph": {
        "name": "Dependency Graph Analysis",
        "description": "Full transitive dependency mapping",
        "evidence": "Dependency tree visualization"
    },
    "epss_scoring": {
        "name": "EPSS Scoring",
        "description": "Exploit Prediction Scoring System integration",
        "evidence": "EPSS probability scores"
    },
    "kev_checking": {
        "name": "KEV Catalog Checking",
        "description": "CISA Known Exploited Vulnerabilities checking",
        "evidence": "KEV match results"
    }
}

# =============================================================================
# SOC 2 TYPE II CONTROLS
# =============================================================================

SOC2_CONTROLS = [
    Control(
        id="CC6.1",
        name="Logical Access Security",
        description="The entity implements logical access security software, infrastructure, and architectures to protect information assets from unauthorized access.",
        framework=Framework.SOC2,
        severity=Severity.CRITICAL,
        category="Logical and Physical Access Controls",
        capabilities=["sandbox_behavioral", "policy_enforcement"],
        violation_indicators=["unauthorized_access", "privilege_escalation"],
        evidence_types=["sandbox_verdict", "policy_results"]
    ),
    Control(
        id="CC6.6",
        name="Boundary Protection",
        description="The entity implements logical access security measures to protect against threats from sources outside its system boundaries.",
        framework=Framework.SOC2,
        severity=Severity.CRITICAL,
        category="Logical and Physical Access Controls",
        capabilities=["sandbox_behavioral", "malware_detection"],
        violation_indicators=["network_exfiltration", "c2_communication"],
        evidence_types=["network_blocked_events", "malware_findings"]
    ),
    Control(
        id="CC6.7",
        name="Transmission Protection",
        description="The entity restricts the transmission, movement, and removal of information to authorized users and processes.",
        framework=Framework.SOC2,
        severity=Severity.HIGH,
        category="Logical and Physical Access Controls",
        capabilities=["secrets_detection", "sandbox_behavioral"],
        violation_indicators=["credential_exfiltration", "data_leakage"],
        evidence_types=["secrets_findings", "honeypot_access_events"]
    ),
    Control(
        id="CC7.1",
        name="Vulnerability Management",
        description="The entity uses detection and monitoring procedures to identify changes to configurations that could create new vulnerabilities.",
        framework=Framework.SOC2,
        severity=Severity.CRITICAL,
        category="System Operations",
        capabilities=["vulnerability_scanning", "reachability_analysis", "epss_scoring"],
        violation_indicators=["critical_cve", "exploitable_vulnerability"],
        evidence_types=["vulnerability_report", "reachability_scores"]
    ),
    Control(
        id="CC7.2",
        name="Anomaly Detection",
        description="The entity monitors system components and the operation of those components for anomalies indicative of malicious acts.",
        framework=Framework.SOC2,
        severity=Severity.HIGH,
        category="System Operations",
        capabilities=["sandbox_behavioral", "malware_detection", "audit_logging"],
        violation_indicators=["suspicious_behavior", "malware_detected"],
        evidence_types=["sandbox_events", "malware_findings", "audit_logs"]
    ),
    Control(
        id="CC7.3",
        name="Security Event Analysis",
        description="The entity evaluates security events to determine whether they could or have resulted in a failure.",
        framework=Framework.SOC2,
        severity=Severity.HIGH,
        category="System Operations",
        capabilities=["audit_logging", "vulnerability_scanning", "kev_checking"],
        violation_indicators=["kev_match", "active_exploitation"],
        evidence_types=["audit_logs", "kev_results", "epss_scores"]
    ),
    Control(
        id="CC7.4",
        name="Incident Response",
        description="The entity responds to identified security incidents by executing a defined incident response program.",
        framework=Framework.SOC2,
        severity=Severity.CRITICAL,
        category="System Operations",
        capabilities=["policy_enforcement", "ci_cd_integration", "vex_generation"],
        violation_indicators=["policy_violation", "critical_finding"],
        evidence_types=["policy_actions", "vex_documents"]
    ),
    Control(
        id="CC8.1",
        name="Change Management",
        description="The entity authorizes, designs, develops, configures, documents, tests, approves, and implements changes to infrastructure and software.",
        framework=Framework.SOC2,
        severity=Severity.HIGH,
        category="Change Management",
        capabilities=["sbom_generation", "dependency_graph", "provenance_verification"],
        violation_indicators=["unauthorized_dependency", "tampered_package"],
        evidence_types=["sbom_diff", "provenance_results"]
    ),
    Control(
        id="CC9.2",
        name="Vendor Risk Management",
        description="The entity assesses and manages risks associated with vendors and business partners.",
        framework=Framework.SOC2,
        severity=Severity.HIGH,
        category="Risk Mitigation",
        capabilities=["sbom_generation", "vulnerability_scanning", "license_compliance"],
        violation_indicators=["high_risk_dependency", "license_violation"],
        evidence_types=["sbom", "vulnerability_report", "license_report"]
    ),
]

# =============================================================================
# SLSA CONTROLS
# =============================================================================

SLSA_CONTROLS = [
    Control(
        id="SLSA-1",
        name="Build Process Documentation",
        description="Documentation of the build process exists.",
        framework=Framework.SLSA,
        severity=Severity.MEDIUM,
        category="Build Integrity",
        capabilities=["sbom_generation", "audit_logging"],
        violation_indicators=[],
        evidence_types=["sbom", "build_logs"]
    ),
    Control(
        id="SLSA-2",
        name="Hosted Build Platform",
        description="Build runs on a hosted platform that generates and signs provenance.",
        framework=Framework.SLSA,
        severity=Severity.HIGH,
        category="Build Integrity",
        capabilities=["ci_cd_integration", "provenance_verification"],
        violation_indicators=["missing_provenance"],
        evidence_types=["ci_logs", "provenance_attestations"]
    ),
    Control(
        id="SLSA-3",
        name="Hardened Build Platform",
        description="Build platform provides strong isolation and tamper resistance.",
        framework=Framework.SLSA,
        severity=Severity.CRITICAL,
        category="Build Integrity",
        capabilities=["sandbox_behavioral", "provenance_verification"],
        violation_indicators=["build_tampering", "isolation_breach"],
        evidence_types=["sandbox_verdict", "isolation_evidence"]
    ),
    Control(
        id="SLSA-Source",
        name="Source Integrity",
        description="Source code integrity is maintained through version control.",
        framework=Framework.SLSA,
        severity=Severity.HIGH,
        category="Source Integrity",
        capabilities=["provenance_verification", "dependency_graph"],
        violation_indicators=["source_tampering"],
        evidence_types=["git_signatures", "commit_verification"]
    ),
    Control(
        id="SLSA-Dependencies",
        name="Dependency Integrity",
        description="Dependencies are verified and their provenance is tracked.",
        framework=Framework.SLSA,
        severity=Severity.CRITICAL,
        category="Dependencies",
        capabilities=["sbom_generation", "provenance_verification", "vulnerability_scanning"],
        violation_indicators=["unverified_dependency", "compromised_package"],
        evidence_types=["sbom", "signature_verification", "vulnerability_report"]
    ),
]

# =============================================================================
# NIST SSDF CONTROLS
# =============================================================================

SSDF_CONTROLS = [
    Control(
        id="PO.1.1",
        name="Security Requirements",
        description="Define security requirements for software development.",
        framework=Framework.SSDF,
        severity=Severity.HIGH,
        category="Prepare the Organization",
        capabilities=["policy_enforcement"],
        violation_indicators=["policy_undefined"],
        evidence_types=["policy_configuration"]
    ),
    Control(
        id="PO.3.1",
        name="Secure Development Environment",
        description="Use a secure development environment.",
        framework=Framework.SSDF,
        severity=Severity.HIGH,
        category="Prepare the Organization",
        capabilities=["sandbox_behavioral", "secrets_detection"],
        violation_indicators=["insecure_configuration"],
        evidence_types=["sandbox_config", "secrets_scan"]
    ),
    Control(
        id="PS.1.1",
        name="Third-Party Component Security",
        description="Acquire and maintain well-secured third-party components.",
        framework=Framework.SSDF,
        severity=Severity.CRITICAL,
        category="Protect the Software",
        capabilities=["vulnerability_scanning", "sbom_generation", "malware_detection"],
        violation_indicators=["vulnerable_dependency", "malicious_package"],
        evidence_types=["vulnerability_report", "sbom", "malware_scan"]
    ),
    Control(
        id="PS.2.1",
        name="Secure Coding Practices",
        description="Follow secure coding practices.",
        framework=Framework.SSDF,
        severity=Severity.HIGH,
        category="Protect the Software",
        capabilities=["secrets_detection", "malware_detection"],
        violation_indicators=["hardcoded_secret", "insecure_pattern"],
        evidence_types=["secrets_findings", "sast_results"]
    ),
    Control(
        id="PW.4.1",
        name="Software Analysis",
        description="Perform software analysis to identify vulnerabilities.",
        framework=Framework.SSDF,
        severity=Severity.CRITICAL,
        category="Produce Well-Secured Software",
        capabilities=["vulnerability_scanning", "reachability_analysis", "malware_detection"],
        violation_indicators=["unanalyzed_code"],
        evidence_types=["vulnerability_report", "reachability_analysis"]
    ),
    Control(
        id="PW.4.4",
        name="Malicious Code Detection",
        description="Verify that no malicious code is present.",
        framework=Framework.SSDF,
        severity=Severity.CRITICAL,
        category="Produce Well-Secured Software",
        capabilities=["malware_detection", "sandbox_behavioral"],
        violation_indicators=["malware_detected", "suspicious_behavior"],
        evidence_types=["malware_findings", "sandbox_verdict"]
    ),
    Control(
        id="PW.6.1",
        name="Reduce Attack Surface",
        description="Configure software to have secure settings by default.",
        framework=Framework.SSDF,
        severity=Severity.HIGH,
        category="Produce Well-Secured Software",
        capabilities=["sandbox_behavioral", "policy_enforcement"],
        violation_indicators=["excessive_permissions"],
        evidence_types=["sandbox_config", "policy_results"]
    ),
    Control(
        id="RV.1.1",
        name="Vulnerability Identification",
        description="Identify vulnerabilities on an ongoing basis.",
        framework=Framework.SSDF,
        severity=Severity.CRITICAL,
        category="Respond to Vulnerabilities",
        capabilities=["vulnerability_scanning", "kev_checking", "epss_scoring"],
        violation_indicators=[],
        evidence_types=["vulnerability_report", "kev_results", "epss_scores"]
    ),
    Control(
        id="RV.1.2",
        name="Vulnerability Assessment",
        description="Assess the severity and exploitability of vulnerabilities.",
        framework=Framework.SSDF,
        severity=Severity.HIGH,
        category="Respond to Vulnerabilities",
        capabilities=["reachability_analysis", "epss_scoring", "kev_checking"],
        violation_indicators=[],
        evidence_types=["reachability_scores", "epss_scores", "kev_matches"]
    ),
    Control(
        id="RV.3.1",
        name="Vulnerability Remediation",
        description="Remediate vulnerabilities.",
        framework=Framework.SSDF,
        severity=Severity.CRITICAL,
        category="Respond to Vulnerabilities",
        capabilities=["vex_generation", "policy_enforcement"],
        violation_indicators=["unpatched_vulnerability"],
        evidence_types=["vex_documents", "remediation_tracking"]
    ),
]

# =============================================================================
# ISO 27001:2022 CONTROLS
# =============================================================================

ISO27001_CONTROLS = [
    Control(
        id="A.5.1",
        name="Policies for Information Security",
        description="Information security policy and topic-specific policies shall be defined and approved.",
        framework=Framework.ISO27001,
        severity=Severity.HIGH,
        category="Organizational Controls",
        capabilities=["policy_enforcement"],
        violation_indicators=["policy_undefined"],
        evidence_types=["policy_configuration", "policy_results"]
    ),
    Control(
        id="A.5.23",
        name="Information Security for Cloud Services",
        description="Processes for acquisition, use, management, and exit from cloud services shall be established.",
        framework=Framework.ISO27001,
        severity=Severity.HIGH,
        category="Organizational Controls",
        capabilities=["sbom_generation", "vulnerability_scanning"],
        violation_indicators=["unmanaged_cloud_dependency"],
        evidence_types=["sbom", "vulnerability_report"]
    ),
    Control(
        id="A.8.8",
        name="Management of Technical Vulnerabilities",
        description="Information about technical vulnerabilities shall be obtained and appropriate measures taken.",
        framework=Framework.ISO27001,
        severity=Severity.CRITICAL,
        category="Technological Controls",
        capabilities=["vulnerability_scanning", "reachability_analysis", "kev_checking"],
        violation_indicators=["unpatched_critical_cve"],
        evidence_types=["vulnerability_report", "reachability_analysis"]
    ),
    Control(
        id="A.8.9",
        name="Configuration Management",
        description="Configurations shall be established, documented, implemented, and reviewed.",
        framework=Framework.ISO27001,
        severity=Severity.HIGH,
        category="Technological Controls",
        capabilities=["sbom_generation", "policy_enforcement"],
        violation_indicators=["configuration_drift"],
        evidence_types=["sbom", "policy_configuration"]
    ),
    Control(
        id="A.8.16",
        name="Monitoring Activities",
        description="Networks, systems, and applications shall be monitored for anomalous behavior.",
        framework=Framework.ISO27001,
        severity=Severity.HIGH,
        category="Technological Controls",
        capabilities=["sandbox_behavioral", "audit_logging", "malware_detection"],
        violation_indicators=["unmonitored_activity"],
        evidence_types=["sandbox_events", "audit_logs"]
    ),
    Control(
        id="A.8.25",
        name="Secure Development Life Cycle",
        description="Rules for the secure development of software shall be established and applied.",
        framework=Framework.ISO27001,
        severity=Severity.CRITICAL,
        category="Technological Controls",
        capabilities=["ci_cd_integration", "policy_enforcement", "vulnerability_scanning"],
        violation_indicators=["sdlc_bypass"],
        evidence_types=["ci_logs", "policy_results"]
    ),
    Control(
        id="A.8.26",
        name="Application Security Requirements",
        description="Information security requirements shall be identified when developing applications.",
        framework=Framework.ISO27001,
        severity=Severity.HIGH,
        category="Technological Controls",
        capabilities=["vulnerability_scanning", "secrets_detection", "malware_detection"],
        violation_indicators=["security_requirement_gap"],
        evidence_types=["vulnerability_report", "secrets_findings"]
    ),
    Control(
        id="A.8.28",
        name="Secure Coding",
        description="Secure coding principles shall be applied to software development.",
        framework=Framework.ISO27001,
        severity=Severity.HIGH,
        category="Technological Controls",
        capabilities=["secrets_detection", "malware_detection"],
        violation_indicators=["insecure_code_pattern"],
        evidence_types=["secrets_findings", "sast_results"]
    ),
    Control(
        id="A.8.31",
        name="Separation of Development and Production",
        description="Development, testing, and production environments shall be separated.",
        framework=Framework.ISO27001,
        severity=Severity.MEDIUM,
        category="Technological Controls",
        capabilities=["sandbox_behavioral"],
        violation_indicators=["environment_leak"],
        evidence_types=["sandbox_isolation_evidence"]
    ),
]

# =============================================================================
# FEDRAMP / NIST 800-53 CONTROLS
# =============================================================================

FEDRAMP_CONTROLS = [
    Control(
        id="AC-3",
        name="Access Enforcement",
        description="The system enforces approved authorizations for logical access to information and system resources.",
        framework=Framework.FEDRAMP,
        severity=Severity.CRITICAL,
        category="Access Control",
        capabilities=["sandbox_behavioral", "policy_enforcement"],
        violation_indicators=["unauthorized_access"],
        evidence_types=["sandbox_verdict", "policy_results"]
    ),
    Control(
        id="AC-6",
        name="Least Privilege",
        description="The system enforces the most restrictive set of rights/privileges.",
        framework=Framework.FEDRAMP,
        severity=Severity.CRITICAL,
        category="Access Control",
        capabilities=["sandbox_behavioral"],
        violation_indicators=["excessive_privileges"],
        evidence_types=["capability_drop_evidence", "seccomp_profile"]
    ),
    Control(
        id="AU-2",
        name="Audit Events",
        description="The organization determines that the system is capable of auditing defined events.",
        framework=Framework.FEDRAMP,
        severity=Severity.HIGH,
        category="Audit and Accountability",
        capabilities=["audit_logging"],
        violation_indicators=["missing_audit_events"],
        evidence_types=["audit_logs"]
    ),
    Control(
        id="AU-6",
        name="Audit Record Review",
        description="The organization reviews and analyzes system audit records for indications of inappropriate or unusual activity.",
        framework=Framework.FEDRAMP,
        severity=Severity.HIGH,
        category="Audit and Accountability",
        capabilities=["audit_logging", "sandbox_behavioral"],
        violation_indicators=["unreviewed_anomaly"],
        evidence_types=["audit_analysis", "behavioral_events"]
    ),
    Control(
        id="CA-7",
        name="Continuous Monitoring",
        description="The organization develops a continuous monitoring strategy and implements a continuous monitoring program.",
        framework=Framework.FEDRAMP,
        severity=Severity.HIGH,
        category="Assessment and Authorization",
        capabilities=["ci_cd_integration", "vulnerability_scanning"],
        violation_indicators=["monitoring_gap"],
        evidence_types=["ci_scan_history", "vulnerability_trends"]
    ),
    Control(
        id="CM-2",
        name="Baseline Configuration",
        description="The organization develops, documents, and maintains a current baseline configuration.",
        framework=Framework.FEDRAMP,
        severity=Severity.HIGH,
        category="Configuration Management",
        capabilities=["sbom_generation", "policy_enforcement"],
        violation_indicators=["baseline_deviation"],
        evidence_types=["sbom", "configuration_baseline"]
    ),
    Control(
        id="CM-6",
        name="Configuration Settings",
        description="The organization establishes and documents configuration settings for IT products.",
        framework=Framework.FEDRAMP,
        severity=Severity.HIGH,
        category="Configuration Management",
        capabilities=["sbom_generation", "sandbox_behavioral"],
        violation_indicators=["insecure_default"],
        evidence_types=["configuration_evidence"]
    ),
    Control(
        id="CM-7",
        name="Least Functionality",
        description="The organization configures the system to provide only essential capabilities.",
        framework=Framework.FEDRAMP,
        severity=Severity.HIGH,
        category="Configuration Management",
        capabilities=["sbom_generation", "dependency_graph"],
        violation_indicators=["unnecessary_functionality"],
        evidence_types=["sbom", "dependency_analysis"]
    ),
    Control(
        id="RA-5",
        name="Vulnerability Monitoring and Scanning",
        description="The organization scans for vulnerabilities in the system and applications.",
        framework=Framework.FEDRAMP,
        severity=Severity.CRITICAL,
        category="Risk Assessment",
        capabilities=["vulnerability_scanning", "reachability_analysis", "kev_checking"],
        violation_indicators=["unscanned_component"],
        evidence_types=["vulnerability_report", "scan_coverage"]
    ),
    Control(
        id="SC-7",
        name="Boundary Protection",
        description="The system monitors and controls communications at external boundaries.",
        framework=Framework.FEDRAMP,
        severity=Severity.CRITICAL,
        category="System and Communications Protection",
        capabilities=["sandbox_behavioral"],
        violation_indicators=["boundary_violation"],
        evidence_types=["network_blocked_events"]
    ),
    Control(
        id="SC-13",
        name="Cryptographic Protection",
        description="The system implements cryptographic mechanisms to prevent unauthorized disclosure.",
        framework=Framework.FEDRAMP,
        severity=Severity.HIGH,
        category="System and Communications Protection",
        capabilities=["secrets_detection", "provenance_verification"],
        violation_indicators=["weak_cryptography"],
        evidence_types=["crypto_analysis"]
    ),
    Control(
        id="SI-2",
        name="Flaw Remediation",
        description="The organization identifies, reports, and corrects system flaws.",
        framework=Framework.FEDRAMP,
        severity=Severity.CRITICAL,
        category="System and Information Integrity",
        capabilities=["vulnerability_scanning", "vex_generation"],
        violation_indicators=["unremediated_flaw"],
        evidence_types=["vulnerability_report", "remediation_tracking"]
    ),
    Control(
        id="SI-3",
        name="Malicious Code Protection",
        description="The organization implements malicious code protection mechanisms.",
        framework=Framework.FEDRAMP,
        severity=Severity.CRITICAL,
        category="System and Information Integrity",
        capabilities=["malware_detection", "sandbox_behavioral"],
        violation_indicators=["malware_detected"],
        evidence_types=["malware_scan", "sandbox_verdict"]
    ),
    Control(
        id="SI-4",
        name="System Monitoring",
        description="The organization monitors the system to detect attacks and indicators of potential attacks.",
        framework=Framework.FEDRAMP,
        severity=Severity.HIGH,
        category="System and Information Integrity",
        capabilities=["sandbox_behavioral", "audit_logging", "kev_checking"],
        violation_indicators=["undetected_attack"],
        evidence_types=["monitoring_logs", "behavioral_events"]
    ),
    Control(
        id="SI-7",
        name="Software and Information Integrity",
        description="The organization employs integrity verification tools to detect unauthorized changes.",
        framework=Framework.FEDRAMP,
        severity=Severity.HIGH,
        category="System and Information Integrity",
        capabilities=["provenance_verification", "sbom_generation"],
        violation_indicators=["integrity_violation"],
        evidence_types=["signature_verification", "sbom_diff"]
    ),
    Control(
        id="SR-3",
        name="Supply Chain Controls",
        description="The organization employs supply chain risk management processes.",
        framework=Framework.FEDRAMP,
        severity=Severity.CRITICAL,
        category="Supply Chain Risk Management",
        capabilities=["sbom_generation", "vulnerability_scanning", "malware_detection", "sandbox_behavioral"],
        violation_indicators=["supply_chain_risk"],
        evidence_types=["sbom", "vulnerability_report", "sandbox_verdict"]
    ),
    Control(
        id="SR-4",
        name="Provenance",
        description="The organization documents, monitors, and maintains valid provenance of systems and components.",
        framework=Framework.FEDRAMP,
        severity=Severity.HIGH,
        category="Supply Chain Risk Management",
        capabilities=["provenance_verification", "sbom_generation"],
        violation_indicators=["unknown_provenance"],
        evidence_types=["provenance_attestation", "sbom"]
    ),
]

# =============================================================================
# PCI DSS 4.0 CONTROLS
# =============================================================================

PCI_DSS_CONTROLS = [
    Control(
        id="6.2.4",
        name="Software Engineering Techniques",
        description="Software engineering techniques or methods are defined and in use to prevent or mitigate common software attacks.",
        framework=Framework.PCI_DSS,
        severity=Severity.CRITICAL,
        category="Develop and Maintain Secure Systems",
        capabilities=["vulnerability_scanning", "secrets_detection", "malware_detection"],
        violation_indicators=["common_vulnerability"],
        evidence_types=["vulnerability_report", "sast_results"]
    ),
    Control(
        id="6.3.1",
        name="Security Vulnerabilities Identification",
        description="Security vulnerabilities are identified and managed.",
        framework=Framework.PCI_DSS,
        severity=Severity.CRITICAL,
        category="Develop and Maintain Secure Systems",
        capabilities=["vulnerability_scanning", "reachability_analysis", "kev_checking"],
        violation_indicators=["unidentified_vulnerability"],
        evidence_types=["vulnerability_report", "kev_results"]
    ),
    Control(
        id="6.3.2",
        name="Software Inventory",
        description="An inventory of bespoke and custom software is maintained to facilitate vulnerability and patch management.",
        framework=Framework.PCI_DSS,
        severity=Severity.HIGH,
        category="Develop and Maintain Secure Systems",
        capabilities=["sbom_generation", "dependency_graph"],
        violation_indicators=["missing_inventory"],
        evidence_types=["sbom"]
    ),
    Control(
        id="6.5.1",
        name="Change Management Processes",
        description="Changes to system components are managed and documented.",
        framework=Framework.PCI_DSS,
        severity=Severity.HIGH,
        category="Develop and Maintain Secure Systems",
        capabilities=["sbom_generation", "audit_logging"],
        violation_indicators=["undocumented_change"],
        evidence_types=["sbom_diff", "audit_logs"]
    ),
    Control(
        id="11.3.1",
        name="Vulnerability Scanning",
        description="Internal vulnerability scans are performed quarterly.",
        framework=Framework.PCI_DSS,
        severity=Severity.CRITICAL,
        category="Test Security Regularly",
        capabilities=["vulnerability_scanning", "ci_cd_integration"],
        violation_indicators=["scan_overdue"],
        evidence_types=["scan_history", "vulnerability_report"]
    ),
]

# =============================================================================
# STRIDE THREAT MODEL CONTROLS
# =============================================================================

STRIDE_CONTROLS = [
    # SPOOFING - Impersonating something or someone
    Control(
        id="S-1",
        name="Package Identity Verification",
        description="Verify that packages are authentic and from legitimate sources.",
        framework=Framework.STRIDE,
        severity=Severity.CRITICAL,
        category="Spoofing",
        capabilities=["provenance_verification", "sbom_generation"],
        violation_indicators=["unsigned_package", "unknown_publisher"],
        evidence_types=["signature_verification", "provenance_attestation"]
    ),
    Control(
        id="S-2",
        name="Typosquatting Detection",
        description="Detect packages with names similar to popular packages.",
        framework=Framework.STRIDE,
        severity=Severity.HIGH,
        category="Spoofing",
        capabilities=["malware_detection", "sandbox_behavioral"],
        violation_indicators=["typosquat_detected"],
        evidence_types=["malware_findings", "name_similarity_score"]
    ),
    Control(
        id="S-3",
        name="Dependency Confusion Prevention",
        description="Prevent private package namespace hijacking.",
        framework=Framework.STRIDE,
        severity=Severity.CRITICAL,
        category="Spoofing",
        capabilities=["sbom_generation", "policy_enforcement"],
        violation_indicators=["namespace_conflict"],
        evidence_types=["sbom", "registry_analysis"]
    ),
    
    # TAMPERING - Modifying data or code
    Control(
        id="T-1",
        name="Code Integrity Verification",
        description="Verify that package code has not been modified.",
        framework=Framework.STRIDE,
        severity=Severity.CRITICAL,
        category="Tampering",
        capabilities=["provenance_verification", "sbom_generation"],
        violation_indicators=["checksum_mismatch", "modified_package"],
        evidence_types=["hash_verification", "sbom_diff"]
    ),
    Control(
        id="T-2",
        name="Build Process Integrity",
        description="Ensure build artifacts match source code.",
        framework=Framework.STRIDE,
        severity=Severity.HIGH,
        category="Tampering",
        capabilities=["provenance_verification"],
        violation_indicators=["build_mismatch"],
        evidence_types=["reproducible_build_check"]
    ),
    Control(
        id="T-3",
        name="Install-Time Modification Detection",
        description="Detect code modifications during package installation.",
        framework=Framework.STRIDE,
        severity=Severity.CRITICAL,
        category="Tampering",
        capabilities=["sandbox_behavioral"],
        violation_indicators=["postinstall_modification"],
        evidence_types=["sandbox_fs_events"]
    ),
    
    # REPUDIATION - Denying actions
    Control(
        id="R-1",
        name="Scan Activity Logging",
        description="Maintain audit trail of all security scans.",
        framework=Framework.STRIDE,
        severity=Severity.MEDIUM,
        category="Repudiation",
        capabilities=["audit_logging"],
        violation_indicators=["missing_audit_trail"],
        evidence_types=["audit_logs"]
    ),
    Control(
        id="R-2",
        name="Finding Attribution",
        description="Track source of each security finding.",
        framework=Framework.STRIDE,
        severity=Severity.MEDIUM,
        category="Repudiation",
        capabilities=["audit_logging", "vex_generation"],
        violation_indicators=["unattributed_finding"],
        evidence_types=["finding_metadata", "vex_document"]
    ),
    Control(
        id="R-3",
        name="Remediation Tracking",
        description="Track vulnerability remediation decisions and actions.",
        framework=Framework.STRIDE,
        severity=Severity.HIGH,
        category="Repudiation",
        capabilities=["vex_generation", "policy_enforcement"],
        violation_indicators=["untracked_remediation"],
        evidence_types=["vex_history", "policy_decisions"]
    ),
    
    # INFORMATION DISCLOSURE - Exposing information
    Control(
        id="I-1",
        name="Secrets Detection",
        description="Detect hardcoded secrets and credentials in code.",
        framework=Framework.STRIDE,
        severity=Severity.CRITICAL,
        category="Information Disclosure",
        capabilities=["secrets_detection"],
        violation_indicators=["hardcoded_secret", "exposed_credential"],
        evidence_types=["secrets_findings"]
    ),
    Control(
        id="I-2",
        name="Credential Exfiltration Prevention",
        description="Prevent packages from stealing credentials during install.",
        framework=Framework.STRIDE,
        severity=Severity.CRITICAL,
        category="Information Disclosure",
        capabilities=["sandbox_behavioral"],
        violation_indicators=["credential_access", "honeypot_triggered"],
        evidence_types=["sandbox_verdict", "honeypot_events"]
    ),
    Control(
        id="I-3",
        name="Token Protection",
        description="Protect CI/CD tokens and API keys from exfiltration.",
        framework=Framework.STRIDE,
        severity=Severity.CRITICAL,
        category="Information Disclosure",
        capabilities=["sandbox_behavioral", "secrets_detection"],
        violation_indicators=["token_access", "env_exfiltration"],
        evidence_types=["env_scrub_events", "sandbox_events"]
    ),
    
    # DENIAL OF SERVICE - Deny or degrade service
    Control(
        id="D-1",
        name="Resource Exhaustion Prevention",
        description="Prevent packages from exhausting system resources.",
        framework=Framework.STRIDE,
        severity=Severity.HIGH,
        category="Denial of Service",
        capabilities=["sandbox_behavioral"],
        violation_indicators=["resource_exhaustion", "fork_bomb"],
        evidence_types=["resource_limits", "sandbox_config"]
    ),
    Control(
        id="D-2",
        name="Dependency Chain Analysis",
        description="Detect dependency chains that could cause build failures.",
        framework=Framework.STRIDE,
        severity=Severity.MEDIUM,
        category="Denial of Service",
        capabilities=["dependency_graph", "vulnerability_scanning"],
        violation_indicators=["circular_dependency", "incompatible_versions"],
        evidence_types=["dependency_analysis"]
    ),
    Control(
        id="D-3",
        name="Build Timeout Protection",
        description="Ensure package installations complete within time limits.",
        framework=Framework.STRIDE,
        severity=Severity.MEDIUM,
        category="Denial of Service",
        capabilities=["sandbox_behavioral"],
        violation_indicators=["installation_timeout"],
        evidence_types=["sandbox_duration"]
    ),
    
    # ELEVATION OF PRIVILEGE - Gain unauthorized access
    Control(
        id="E-1",
        name="Privilege Escalation Prevention",
        description="Prevent packages from gaining elevated privileges.",
        framework=Framework.STRIDE,
        severity=Severity.CRITICAL,
        category="Elevation of Privilege",
        capabilities=["sandbox_behavioral"],
        violation_indicators=["privilege_escalation", "capability_abuse"],
        evidence_types=["capability_drops", "seccomp_violations"]
    ),
    Control(
        id="E-2",
        name="Container Escape Prevention",
        description="Prevent packages from escaping sandbox isolation.",
        framework=Framework.STRIDE,
        severity=Severity.CRITICAL,
        category="Elevation of Privilege",
        capabilities=["sandbox_behavioral"],
        violation_indicators=["container_escape_attempt"],
        evidence_types=["sandbox_isolation_events"]
    ),
    Control(
        id="E-3",
        name="Vulnerable Code Reachability",
        description="Determine if vulnerable code paths are actually executable.",
        framework=Framework.STRIDE,
        severity=Severity.HIGH,
        category="Elevation of Privilege",
        capabilities=["reachability_analysis", "vulnerability_scanning"],
        violation_indicators=["reachable_vulnerability"],
        evidence_types=["reachability_score", "call_graph"]
    ),
    Control(
        id="E-4",
        name="Known Exploit Detection",
        description="Detect vulnerabilities with known exploits in the wild.",
        framework=Framework.STRIDE,
        severity=Severity.CRITICAL,
        category="Elevation of Privilege",
        capabilities=["kev_checking", "epss_scoring"],
        violation_indicators=["kev_match", "high_epss"],
        evidence_types=["kev_results", "epss_scores"]
    ),
]

# =============================================================================
# STRIDE-TO-POLICY MAPPING
# =============================================================================

STRIDE_POLICY_MAP = {
    ThreatCategory.SPOOFING: {
        "description": "Threats involving impersonation of legitimate packages or sources",
        "detection_rules": ["TYPOSQUAT_DETECTED", "UNSIGNED_PACKAGE", "UNKNOWN_PUBLISHER"],
        "capabilities": ["provenance_verification", "malware_detection", "sbom_generation"],
        "sandbox_signals": [],
        "controls": ["S-1", "S-2", "S-3"]
    },
    ThreatCategory.TAMPERING: {
        "description": "Threats involving unauthorized modification of code or data",
        "detection_rules": ["CHECKSUM_MISMATCH", "POSTINSTALL_MODIFICATION"],
        "capabilities": ["provenance_verification", "sandbox_behavioral", "sbom_generation"],
        "sandbox_signals": ["file_write", "executable_creation"],
        "controls": ["T-1", "T-2", "T-3"]
    },
    ThreatCategory.REPUDIATION: {
        "description": "Threats related to inability to trace actions",
        "detection_rules": [],
        "capabilities": ["audit_logging", "vex_generation"],
        "sandbox_signals": ["process_spawn", "script_start", "script_end"],
        "controls": ["R-1", "R-2", "R-3"]
    },
    ThreatCategory.INFORMATION_DISCLOSURE: {
        "description": "Threats involving exposure of sensitive data",
        "detection_rules": ["CREDENTIAL_ACCESS", "ENV_EXFIL_ATTEMPT", "HARDCODED_SECRET"],
        "capabilities": ["secrets_detection", "sandbox_behavioral"],
        "sandbox_signals": ["honeypot_access", "env_scrubbed", "network_blocked"],
        "controls": ["I-1", "I-2", "I-3"]
    },
    ThreatCategory.DENIAL_OF_SERVICE: {
        "description": "Threats that disrupt availability or operations",
        "detection_rules": ["RESOURCE_EXHAUSTION", "FORK_BOMB"],
        "capabilities": ["sandbox_behavioral", "dependency_graph"],
        "sandbox_signals": ["process_spawn"],  # Excessive spawns
        "controls": ["D-1", "D-2", "D-3"]
    },
    ThreatCategory.ELEVATION_OF_PRIVILEGE: {
        "description": "Threats involving unauthorized access escalation",
        "detection_rules": ["NETWORK_DURING_INSTALL", "BLOCKED_TOOL", "SUSPICIOUS_ARGUMENT"],
        "capabilities": ["sandbox_behavioral", "reachability_analysis", "kev_checking"],
        "sandbox_signals": ["network_blocked", "blocked_execution", "suspicious_argument"],
        "controls": ["E-1", "E-2", "E-3", "E-4"]
    },
}

def get_stride_mapping_for_finding(finding_rule: str) -> List[ThreatCategory]:
    """Map a finding rule to STRIDE threat categories"""
    mappings = []
    for category, policy in STRIDE_POLICY_MAP.items():
        if finding_rule in policy["detection_rules"]:
            mappings.append(category)
    return mappings

def get_stride_mapping_for_event(event_type: str) -> List[ThreatCategory]:
    """Map a sandbox event to STRIDE threat categories"""
    mappings = []
    for category, policy in STRIDE_POLICY_MAP.items():
        if event_type in policy["sandbox_signals"]:
            mappings.append(category)
    return mappings

# =============================================================================
# COMPLIANCE EVALUATOR
# =============================================================================

class ComplianceEvaluator:
    """Evaluates scan results against compliance frameworks"""
    
    # Map all controls by framework
    FRAMEWORK_CONTROLS = {
        Framework.SOC2: SOC2_CONTROLS,
        Framework.SLSA: SLSA_CONTROLS,
        Framework.SSDF: SSDF_CONTROLS,
        Framework.ISO27001: ISO27001_CONTROLS,
        Framework.FEDRAMP: FEDRAMP_CONTROLS,
        Framework.PCI_DSS: PCI_DSS_CONTROLS,
        Framework.STRIDE: STRIDE_CONTROLS,
    }
    
    def __init__(self):
        self.capabilities_enabled: Set[str] = set()
        self.findings: Dict[str, List[Dict]] = {}
        self.evidence: Dict[str, List[str]] = {}
    
    def set_scan_results(
        self,
        capabilities_used: List[str],
        vulnerability_findings: List[Dict] = None,
        malware_findings: List[Dict] = None,
        sandbox_findings: List[Dict] = None,
        secrets_findings: List[Dict] = None,
        policy_results: Dict = None,
        sbom_generated: bool = False,
        vex_generated: bool = False,
    ):
        """Load scan results for compliance evaluation"""
        self.capabilities_enabled = set(capabilities_used)
        
        # Store findings by type
        self.findings = {
            "vulnerability": vulnerability_findings or [],
            "malware": malware_findings or [],
            "sandbox": sandbox_findings or [],
            "secrets": secrets_findings or [],
        }
        
        # Generate evidence based on what was run
        self.evidence = {}
        
        if sbom_generated:
            self.evidence["sbom"] = ["SBOM generated in CycloneDX format"]
            
        if vex_generated:
            self.evidence["vex"] = ["VEX document generated"]
            
        if vulnerability_findings:
            self.evidence["vulnerability_report"] = [
                f"Scanned {len(vulnerability_findings)} vulnerabilities"
            ]
            
        if malware_findings is not None:
            self.evidence["malware_scan"] = [
                f"Malware scan completed, {len(malware_findings)} findings"
            ]
            
        if sandbox_findings is not None:
            self.evidence["sandbox_verdict"] = [
                f"Sandbox analysis completed, {len(sandbox_findings)} behavioral findings"
            ]
            
        if policy_results:
            self.evidence["policy_results"] = [
                f"Policy evaluation completed"
            ]
    
    def evaluate_control(self, control: Control) -> ControlResult:
        """Evaluate a single control against scan results"""
        
        # Check if required capabilities were used
        capabilities_present = set(control.capabilities) & self.capabilities_enabled
        capabilities_missing = set(control.capabilities) - self.capabilities_enabled
        
        # Gather evidence
        evidence = []
        for etype in control.evidence_types:
            if etype in self.evidence:
                evidence.extend(self.evidence[etype])
        
        # Check for violations
        violations_found = []
        findings_count = 0
        
        for indicator in control.violation_indicators:
            # Check various finding types for indicators
            for finding_type, findings_list in self.findings.items():
                for finding in findings_list:
                    severity = finding.get("severity", "").lower()
                    rule = finding.get("rule", "").lower()
                    
                    if indicator.lower() in rule or indicator.lower() in severity:
                        violations_found.append(f"{finding_type}: {rule}")
                        findings_count += 1
        
        # Determine status
        if not capabilities_present:
            status = ControlStatus.NOT_APPLICABLE
            recommendation = f"Enable capabilities: {', '.join(control.capabilities)}"
        elif violations_found:
            if control.severity == Severity.CRITICAL:
                status = ControlStatus.NOT_SATISFIED
            else:
                status = ControlStatus.PARTIAL
            recommendation = f"Address {len(violations_found)} findings"
        elif capabilities_missing:
            status = ControlStatus.PARTIAL
            recommendation = f"Also enable: {', '.join(capabilities_missing)}"
        else:
            status = ControlStatus.SATISFIED
            recommendation = None
        
        return ControlResult(
            control=control,
            status=status,
            evidence=evidence,
            gaps=violations_found,
            findings_count=findings_count,
            recommendation=recommendation
        )
    
    def evaluate_framework(self, framework: Framework, scan_id: str = "scan-001") -> FrameworkReport:
        """Evaluate all controls for a framework"""
        
        controls = self.FRAMEWORK_CONTROLS.get(framework, [])
        
        results = [self.evaluate_control(c) for c in controls]
        
        # Count statuses
        satisfied = sum(1 for r in results if r.status == ControlStatus.SATISFIED)
        partial = sum(1 for r in results if r.status == ControlStatus.PARTIAL)
        not_satisfied = sum(1 for r in results if r.status == ControlStatus.NOT_SATISFIED)
        not_applicable = sum(1 for r in results if r.status == ControlStatus.NOT_APPLICABLE)
        
        # Calculate compliance score (exclude N/A from denominator)
        applicable = len(results) - not_applicable
        if applicable > 0:
            # Satisfied = 100%, Partial = 50%, Not Satisfied = 0%
            score = ((satisfied * 100) + (partial * 50)) / applicable
        else:
            score = 0.0
        
        return FrameworkReport(
            framework=framework,
            scan_id=scan_id,
            timestamp=datetime.utcnow().isoformat() + "Z",
            total_controls=len(controls),
            satisfied=satisfied,
            partial=partial,
            not_satisfied=not_satisfied,
            not_applicable=not_applicable,
            compliance_score=score,
            controls=results
        )
    
    def evaluate_all_frameworks(self, scan_id: str = "scan-001") -> Dict[str, FrameworkReport]:
        """Evaluate all supported frameworks"""
        return {
            fw.value: self.evaluate_framework(fw, scan_id)
            for fw in self.FRAMEWORK_CONTROLS.keys()
        }
    
    def get_dashboard_summary(self, scan_id: str = "scan-001") -> Dict[str, Any]:
        """Generate dashboard-ready compliance summary"""
        
        reports = self.evaluate_all_frameworks(scan_id)
        
        return {
            "compliance_summary": {
                "scan_id": scan_id,
                "timestamp": datetime.utcnow().isoformat() + "Z",
                "frameworks": {
                    name: {
                        "score": round(report.compliance_score, 1),
                        "status": self._score_to_status(report.compliance_score),
                        "satisfied": report.satisfied,
                        "partial": report.partial,
                        "not_satisfied": report.not_satisfied,
                        "total_applicable": report.total_controls - report.not_applicable
                    }
                    for name, report in reports.items()
                },
                "overall_score": round(
                    sum(r.compliance_score for r in reports.values()) / len(reports), 1
                ),
                "critical_gaps": self._get_critical_gaps(reports)
            }
        }
    
    def _score_to_status(self, score: float) -> str:
        """Convert score to status label"""
        if score >= 90:
            return "compliant"
        elif score >= 70:
            return "mostly_compliant"
        elif score >= 50:
            return "partial"
        else:
            return "non_compliant"
    
    def _get_critical_gaps(self, reports: Dict[str, FrameworkReport]) -> List[Dict]:
        """Extract critical control gaps across all frameworks"""
        gaps = []
        
        for name, report in reports.items():
            for cr in report.controls:
                if cr.status == ControlStatus.NOT_SATISFIED and cr.control.severity == Severity.CRITICAL:
                    gaps.append({
                        "framework": name,
                        "control_id": cr.control.id,
                        "control_name": cr.control.name,
                        "recommendation": cr.recommendation
                    })
        
        return gaps

# =============================================================================
# CONVENIENCE FUNCTIONS
# =============================================================================

def generate_compliance_report(
    scan_results: Dict[str, Any],
    frameworks: List[Framework] = None
) -> Dict[str, Any]:
    """
    Generate compliance report from REACHABLE scan results.
    
    Args:
        scan_results: Full scan output from reachctl scan
        frameworks: List of frameworks to evaluate (all if None)
        
    Returns:
        Compliance report dictionary
    """
    evaluator = ComplianceEvaluator()
    
    # Extract findings from scan results
    vulnerabilities = scan_results.get("vulnerabilities", {}).get("findings", [])
    malware = scan_results.get("malware", {}).get("findings", [])
    sandbox = scan_results.get("sandbox", {}).get("findings", [])
    secrets = scan_results.get("secrets", {}).get("findings", [])
    
    # Determine capabilities used
    capabilities = []
    if scan_results.get("sbom"):
        capabilities.append("sbom_generation")
    if scan_results.get("vulnerabilities"):
        capabilities.append("vulnerability_scanning")
    if scan_results.get("reachability"):
        capabilities.append("reachability_analysis")
    if scan_results.get("malware"):
        capabilities.append("malware_detection")
    if scan_results.get("sandbox"):
        capabilities.append("sandbox_behavioral")
    if scan_results.get("secrets"):
        capabilities.append("secrets_detection")
    if scan_results.get("vex"):
        capabilities.append("vex_generation")
    
    evaluator.set_scan_results(
        capabilities_used=capabilities,
        vulnerability_findings=vulnerabilities,
        malware_findings=malware,
        sandbox_findings=sandbox,
        secrets_findings=secrets,
        sbom_generated="sbom" in scan_results,
        vex_generated="vex" in scan_results,
    )
    
    scan_id = scan_results.get("scan_metadata", {}).get("scan_id", "unknown")
    
    if frameworks:
        return {
            fw.value: evaluator.evaluate_framework(fw, scan_id).to_dict()
            for fw in frameworks
        }
    else:
        return {
            name: report.to_dict()
            for name, report in evaluator.evaluate_all_frameworks(scan_id).items()
        }

def get_framework_controls(framework: Framework) -> List[Dict]:
    """Get all controls for a framework as dictionaries"""
    controls = ComplianceEvaluator.FRAMEWORK_CONTROLS.get(framework, [])
    return [
        {
            "id": c.id,
            "name": c.name,
            "description": c.description,
            "category": c.category,
            "severity": c.severity.value,
            "capabilities": c.capabilities,
            "evidence_types": c.evidence_types
        }
        for c in controls
    ]

def list_all_frameworks() -> List[Dict]:
    """List all supported compliance frameworks"""
    return [
        {
            "id": fw.name,
            "name": fw.value,
            "control_count": len(ComplianceEvaluator.FRAMEWORK_CONTROLS.get(fw, []))
        }
        for fw in Framework
    ]

# ═══════════════════════════════════════════════════════════════════════════════
# COMPLIANCE AUDIT REPORT GENERATOR
# ═══════════════════════════════════════════════════════════════════════════════

# Official documentation links for each standard
STANDARD_LINKS = {
    "SOC2": {
        "name": "SOC 2 Type II",
        "url": "https://www.aicpa.org/topic/audit-assurance/audit-and-assurance-greater-than-soc-2",
        "description": "AICPA Service Organization Control 2",
        "icon": "🔐"
    },
    "SLSA": {
        "name": "SLSA (Supply Chain Levels)",
        "url": "https://slsa.dev/spec/v1.0/",
        "description": "Supply-chain Levels for Software Artifacts",
        "icon": "🔗"
    },
    "SSDF": {
        "name": "NIST SSDF",
        "url": "https://csrc.nist.gov/publications/detail/sp/800-218/final",
        "description": "NIST SP 800-218 Secure Software Development Framework",
        "icon": "🏛️"
    },
    "ISO27001": {
        "name": "ISO/IEC 27001:2022",
        "url": "https://www.iso.org/standard/27001",
        "description": "Information Security Management Systems",
        "icon": "🌍"
    },
    "FEDRAMP": {
        "name": "FedRAMP / NIST 800-53",
        "url": "https://www.fedramp.gov/",
        "description": "Federal Risk and Authorization Management Program",
        "icon": "🇺🇸"
    },
    "PCI_DSS": {
        "name": "PCI DSS 4.0",
        "url": "https://www.pcisecuritystandards.org/document_library/",
        "description": "Payment Card Industry Data Security Standard",
        "icon": "💳"
    },
    "STRIDE": {
        "name": "STRIDE Threat Model",
        "url": "https://learn.microsoft.com/en-us/azure/security/develop/threat-modeling-tool-threats",
        "description": "Microsoft STRIDE Threat Modeling Framework",
        "icon": "🎯"
    },
    "OWASP": {
        "name": "OWASP Top 10",
        "url": "https://owasp.org/Top10/",
        "description": "Open Web Application Security Project Top 10",
        "icon": "🕷️"
    },
    "HIPAA": {
        "name": "HIPAA Security Rule",
        "url": "https://www.hhs.gov/hipaa/for-professionals/security/index.html",
        "description": "Health Insurance Portability and Accountability Act",
        "icon": "🏥"
    },
    "CMMC": {
        "name": "CMMC 2.0",
        "url": "https://dodcio.defense.gov/CMMC/",
        "description": "Cybersecurity Maturity Model Certification",
        "icon": "🎖️"
    },
    "NIST_CSF": {
        "name": "NIST CSF",
        "url": "https://www.nist.gov/cyberframework",
        "description": "NIST Cybersecurity Framework",
        "icon": "📊"
    },
    "CWE_TOP25": {
        "name": "CWE Top 25",
        "url": "https://cwe.mitre.org/top25/archive/2023/2023_top25_list.html",
        "description": "Common Weakness Enumeration Top 25",
        "icon": "⚠️"
    }
}

def generate_audit_report_html(
    framework_id: str,
    framework_report: Dict,
    scan_metadata: Dict,
    output_dir: str
) -> str:
    """
    Generate an HTML audit report for a specific compliance framework.
    
    Args:
        framework_id: Framework identifier (e.g., "SOC2", "PCI_DSS")
        framework_report: Evaluation results from ComplianceEvaluator
        scan_metadata: Scan metadata (timestamp, repo, etc.)
        output_dir: Directory to write the report
        
    Returns:
        Path to generated HTML file
    """
    from pathlib import Path
    from datetime import datetime
    
    # Get standard info
    std_info = STANDARD_LINKS.get(framework_id, {
        "name": framework_id,
        "url": "#",
        "description": "Compliance Standard",
        "icon": "📋"
    })
    
    summary = framework_report.get("summary", {})
    controls = framework_report.get("controls", [])
    
    # Calculate stats
    total = summary.get("total_controls", len(controls))
    satisfied = summary.get("satisfied", 0)
    partial = summary.get("partial", 0)
    not_satisfied = summary.get("not_satisfied", 0)
    score = summary.get("compliance_score", 0)
    
    # Determine overall status color
    if score >= 80:
        status_color = "#28a745"  # Green
        status_text = "COMPLIANT"
    elif score >= 60:
        status_color = "#ffc107"  # Yellow
        status_text = "PARTIAL"
    else:
        status_color = "#dc3545"  # Red
        status_text = "NON-COMPLIANT"
    
    # Build controls table
    controls_html = ""
    for ctrl in controls:
        status = ctrl.get("status", "unknown")
        if status == "satisfied":
            status_badge = '<span style="background:#28a745;color:white;padding:2px 8px;border-radius:4px;">✓ PASS</span>'
        elif status == "partial":
            status_badge = '<span style="background:#ffc107;color:black;padding:2px 8px;border-radius:4px;">⚠ PARTIAL</span>'
        elif status == "not_satisfied":
            status_badge = '<span style="background:#dc3545;color:white;padding:2px 8px;border-radius:4px;">✗ FAIL</span>'
        else:
            status_badge = '<span style="background:#6c757d;color:white;padding:2px 8px;border-radius:4px;">N/A</span>'
        
        evidence = "<br>".join(ctrl.get("evidence", [])[:3]) or "—"
        gaps = "<br>".join(ctrl.get("gaps", [])[:3]) or "—"
        recommendation = ctrl.get("recommendation") or "—"
        
        controls_html += f"""
        <tr>
            <td><strong>{ctrl.get('id', '')}</strong></td>
            <td>{ctrl.get('name', '')}</td>
            <td>{ctrl.get('category', '')}</td>
            <td>{status_badge}</td>
            <td style="font-size:12px;">{evidence}</td>
            <td style="font-size:12px;color:#dc3545;">{gaps}</td>
            <td style="font-size:12px;">{recommendation}</td>
        </tr>
        """
    
    # Build HTML
    html = f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{std_info['name']} Audit Report - REACHABLE</title>
    <style>
        * {{ box-sizing: border-box; margin: 0; padding: 0; }}
        body {{ font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; background: #f5f5f5; color: #333; line-height: 1.6; }}
        .container {{ max-width: 1200px; margin: 0 auto; padding: 20px; }}
        .header {{ background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%); color: white; padding: 30px; border-radius: 8px; margin-bottom: 20px; }}
        .header h1 {{ font-size: 28px; margin-bottom: 10px; }}
        .header .subtitle {{ opacity: 0.8; font-size: 14px; }}
        .header .icon {{ font-size: 48px; float: right; }}
        .summary-grid {{ display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 20px; margin-bottom: 20px; }}
        .summary-card {{ background: white; padding: 20px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); text-align: center; }}
        .summary-card .value {{ font-size: 36px; font-weight: bold; }}
        .summary-card .label {{ font-size: 12px; color: #666; text-transform: uppercase; }}
        .status-banner {{ background: {status_color}; color: white; padding: 15px 20px; border-radius: 8px; margin-bottom: 20px; display: flex; justify-content: space-between; align-items: center; }}
        .status-banner .status {{ font-size: 24px; font-weight: bold; }}
        .status-banner .score {{ font-size: 18px; }}
        .section {{ background: white; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); margin-bottom: 20px; overflow: hidden; }}
        .section-header {{ background: #f8f9fa; padding: 15px 20px; border-bottom: 1px solid #e9ecef; font-weight: bold; }}
        .section-content {{ padding: 20px; }}
        table {{ width: 100%; border-collapse: collapse; font-size: 14px; }}
        th {{ background: #f8f9fa; text-align: left; padding: 12px; border-bottom: 2px solid #dee2e6; }}
        td {{ padding: 12px; border-bottom: 1px solid #e9ecef; vertical-align: top; }}
        tr:hover {{ background: #f8f9fa; }}
        .links {{ margin-top: 20px; }}
        .links a {{ display: inline-block; margin-right: 15px; color: #0066cc; text-decoration: none; }}
        .links a:hover {{ text-decoration: underline; }}
        .footer {{ text-align: center; padding: 20px; color: #666; font-size: 12px; }}
        @media print {{ body {{ background: white; }} .container {{ max-width: 100%; }} }}
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <span class="icon">{std_info['icon']}</span>
            <h1>{std_info['name']} Compliance Audit Report</h1>
            <div class="subtitle">
                Generated by REACHABLE v2.9.38 | {scan_metadata.get('timestamp', datetime.now().isoformat())}<br>
                Repository: {scan_metadata.get('repo_name', 'Unknown')} | Branch: {scan_metadata.get('git_branch', 'main')}
            </div>
        </div>
        
        <div class="status-banner">
            <span class="status">{status_text}</span>
            <span class="score">Compliance Score: {score:.1f}%</span>
        </div>
        
        <div class="summary-grid">
            <div class="summary-card">
                <div class="value" style="color:#28a745;">{satisfied}</div>
                <div class="label">Controls Satisfied</div>
            </div>
            <div class="summary-card">
                <div class="value" style="color:#ffc107;">{partial}</div>
                <div class="label">Partial Compliance</div>
            </div>
            <div class="summary-card">
                <div class="value" style="color:#dc3545;">{not_satisfied}</div>
                <div class="label">Not Satisfied</div>
            </div>
            <div class="summary-card">
                <div class="value">{total}</div>
                <div class="label">Total Controls</div>
            </div>
        </div>
        
        <div class="section">
            <div class="section-header">📋 Control Assessment Details</div>
            <div class="section-content">
                <table>
                    <thead>
                        <tr>
                            <th>Control ID</th>
                            <th>Control Name</th>
                            <th>Category</th>
                            <th>Status</th>
                            <th>Evidence</th>
                            <th>Gaps</th>
                            <th>Recommendation</th>
                        </tr>
                    </thead>
                    <tbody>
                        {controls_html}
                    </tbody>
                </table>
            </div>
        </div>
        
        <div class="section">
            <div class="section-header">🔗 Reference Links</div>
            <div class="section-content">
                <p><strong>{std_info['name']}</strong>: {std_info['description']}</p>
                <div class="links">
                    <a href="{std_info['url']}" target="_blank">📄 Official Documentation</a>
                    <a href="dashboard.html">🏠 Back to Dashboard</a>
                </div>
            </div>
        </div>
        
        <div class="footer">
            <p>REACHABLE Compliance Audit Report | © 2026 Sthenos Security | Confidential</p>
        </div>
    </div>
</body>
</html>
"""
    
    # Write file
    output_path = Path(output_dir) / f"audit-{framework_id.lower()}.html"
    with open(output_path, 'w') as f:
        f.write(html)
    
    return str(output_path)

def generate_all_audit_reports(
    scan_results: Dict[str, Any],
    output_dir: str
) -> Dict[str, str]:
    """
    Generate audit reports for all compliance frameworks.
    
    Args:
        scan_results: Full scan results from REACHABLE
        output_dir: Directory to write reports
        
    Returns:
        Dict mapping framework_id -> report_path
    """
    from pathlib import Path
    
    # Generate compliance evaluation
    compliance_report = generate_compliance_report(scan_results)
    
    # Extract scan metadata
    scan_metadata = {
        "timestamp": scan_results.get("metadata", {}).get("scan_timestamp", ""),
        "repo_name": scan_results.get("metadata", {}).get("analysis_target", {}).get("repo_name", "Unknown"),
        "git_branch": scan_results.get("metadata", {}).get("analysis_target", {}).get("git_branch", "main"),
        "scan_id": scan_results.get("metadata", {}).get("scan_id", ""),
    }
    
    # Generate individual reports
    reports = {}
    for framework in Framework:
        fw_id = framework.name
        fw_name = framework.value
        
        if fw_name in compliance_report:
            report_path = generate_audit_report_html(
                framework_id=fw_id,
                framework_report=compliance_report[fw_name],
                scan_metadata=scan_metadata,
                output_dir=output_dir
            )
            reports[fw_id] = report_path
    
    # Also save combined JSON
    combined_path = Path(output_dir) / "compliance-report.json"
    with open(combined_path, 'w') as f:
        json.dump(compliance_report, f, indent=2)
    reports["_json"] = str(combined_path)
    
    return reports
