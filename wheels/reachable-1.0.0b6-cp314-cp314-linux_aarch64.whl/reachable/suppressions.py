#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.

"""
REACHABLE Unified Suppression System

Comprehensive whitelist/suppression mechanism for:
- Secrets (from Semgrep and TruffleHog)
- CVEs (vulnerabilities)
- Packages (entire libraries)

Features:
- Unified suppression file format
- Audit trail (who, when, why, expires)
- Risk acceptance tracking
- Integration with REACHABLE report format
- Deduplication of overlapping findings

Suppression Reasons:
- false_positive: Not actually a security issue
- accepted_risk: Team accepts the risk
- compensating_controls: Other mitigations in place
- planned_remediation: Fix scheduled
- not_exploitable: Code path not reachable
- rotated: Secret has been rotated
- inactive: Account/service inactive
- test_data: Test/example data only
- vendored_code: Third-party code, can't fix
- git_history_only: In old commits, not current code

Suppression File Format:
{
  "version": "1.0",
  "suppressions": [
    {
      "id": "SUPP-001",
      "type": "cve|secret|package",
      "target": "CVE-2023-1234 | secret_hash | package_name",
      "reason": "accepted_risk",
      "justification": "Risk is acceptable because...",
      "created_by": "user@example.com",
      "created_at": "2025-12-26T10:00:00Z",
      "expires_at": "2026-12-26T10:00:00Z",
      "ticket": "JIRA-123"
    }
  ]
}
"""

import json
import hashlib
from pathlib import Path
from typing import Dict, List, Optional, Set
from dataclasses import dataclass, field, asdict
from datetime import datetime, timedelta
from enum import Enum

class SuppressionType(Enum):
    """Types of items that can be suppressed"""
    CVE = "cve"
    SECRET = "secret"
    PACKAGE = "package"
    FUNCTION = "function"  # For false positive reachability

class SuppressionReason(Enum):
    """Standard suppression reasons"""
    FALSE_POSITIVE = "false_positive"
    ACCEPTED_RISK = "accepted_risk"
    COMPENSATING_CONTROLS = "compensating_controls"
    PLANNED_REMEDIATION = "planned_remediation"
    NOT_EXPLOITABLE = "not_exploitable"
    ROTATED = "rotated"
    INACTIVE = "inactive"
    TEST_DATA = "test_data"
    VENDORED_CODE = "vendored_code"
    GIT_HISTORY_ONLY = "git_history_only"

@dataclass
class Suppression:
    """Individual suppression rule"""
    id: str  # Unique ID (e.g., SUPP-001)
    type: str  # cve, secret, package, function
    target: str  # CVE-ID, secret hash, package name, function name
    reason: str  # From SuppressionReason enum
    justification: str  # Human-readable explanation
    created_by: str  # Email or username
    created_at: datetime
    expires_at: Optional[datetime] = None
    ticket: Optional[str] = None  # JIRA, GitHub issue, etc.
    
    # Additional matching criteria
    file_pattern: Optional[str] = None  # For secrets in specific files
    package_version: Optional[str] = None  # For specific package versions
    severity: Optional[str] = None  # Suppress only specific severity
    
    def is_expired(self) -> bool:
        """Check if suppression has expired"""
        if not self.expires_at:
            return False
        return datetime.now() > self.expires_at
    
    def matches(self, item_type: str, item_id: str, **kwargs) -> bool:
        """
        Check if suppression matches the item
        
        Args:
            item_type: Type of item (cve, secret, package)
            item_id: Identifier (CVE-ID, secret hash, package name)
            **kwargs: Additional matching criteria
        
        Returns:
            True if suppression applies to this item
        """
        # Check if expired
        if self.is_expired():
            return False
        
        # Check type
        if self.type != item_type:
            return False
        
        # Check target
        if self.target != item_id:
            # For packages, also check if target is package@version
            if item_type == 'package' and '@' in self.target:
                pkg_name, pkg_version = self.target.split('@', 1)
                if pkg_name == item_id:
                    item_version = kwargs.get('version')
                    if item_version == pkg_version:
                        return True
            return False
        
        # Check additional criteria
        if self.file_pattern and kwargs.get('file_path'):
            from fnmatch import fnmatch
            if not fnmatch(kwargs['file_path'], self.file_pattern):
                return False
        
        if self.package_version and kwargs.get('version'):
            if self.package_version != kwargs['version']:
                return False
        
        if self.severity and kwargs.get('severity'):
            if self.severity != kwargs['severity']:
                return False
        
        return True

class SuppressionManager:
    """
    Manages suppression rules for REACHABLE
    
    Handles loading, saving, and matching suppressions.
    Integrates with REACHABLE report format.
    """
    
    def __init__(self, suppression_file: Optional[Path] = None):
        """
        Initialize suppression manager
        
        Args:
            suppression_file: Path to suppressions.json (optional)
        """
        self.suppressions: List[Suppression] = []
        self.suppression_file = suppression_file
        
        if suppression_file and suppression_file.exists():
            self.load_from_file(suppression_file)
    
    def load_from_file(self, filepath: Path):
        """Load suppressions from JSON file"""
        with open(filepath) as f:
            data = json.load(f)
        
        for supp_data in data.get('suppressions', []):
            created_at = datetime.fromisoformat(supp_data['created_at'].replace('Z', '+00:00'))
            expires_at = None
            if supp_data.get('expires_at'):
                expires_at = datetime.fromisoformat(supp_data['expires_at'].replace('Z', '+00:00'))
            
            suppression = Suppression(
                id=supp_data['id'],
                type=supp_data['type'],
                target=supp_data['target'],
                reason=supp_data['reason'],
                justification=supp_data['justification'],
                created_by=supp_data['created_by'],
                created_at=created_at,
                expires_at=expires_at,
                ticket=supp_data.get('ticket'),
                file_pattern=supp_data.get('file_pattern'),
                package_version=supp_data.get('package_version'),
                severity=supp_data.get('severity')
            )
            self.suppressions.append(suppression)
    
    def save_to_file(self, filepath: Path):
        """Save suppressions to JSON file"""
        data = {
            'version': '1.0',
            'schema': 'https://vera-security.org/schemas/suppressions/v1.0',
            'suppressions': []
        }
        
        for supp in self.suppressions:
            supp_dict = {
                'id': supp.id,
                'type': supp.type,
                'target': supp.target,
                'reason': supp.reason,
                'justification': supp.justification,
                'created_by': supp.created_by,
                'created_at': supp.created_at.isoformat() + 'Z',
                'expires_at': supp.expires_at.isoformat() + 'Z' if supp.expires_at else None,
                'ticket': supp.ticket,
                'file_pattern': supp.file_pattern,
                'package_version': supp.package_version,
                'severity': supp.severity
            }
            # Remove None values
            supp_dict = {k: v for k, v in supp_dict.items() if v is not None}
            data['suppressions'].append(supp_dict)
        
        with open(filepath, 'w') as f:
            json.dump(data, f, indent=2)
    
    def add_suppression(self, suppression: Suppression):
        """Add a suppression rule"""
        self.suppressions.append(suppression)
    
    def find_suppression(self, item_type: str, item_id: str, **kwargs) -> Optional[Suppression]:
        """
        Find matching suppression for an item
        
        Args:
            item_type: Type of item (cve, secret, package)
            item_id: Identifier
            **kwargs: Additional matching criteria
        
        Returns:
            Suppression if found, None otherwise
        """
        for suppression in self.suppressions:
            if suppression.matches(item_type, item_id, **kwargs):
                return suppression
        return None
    
    def is_suppressed(self, item_type: str, item_id: str, **kwargs) -> bool:
        """Check if item is suppressed"""
        return self.find_suppression(item_type, item_id, **kwargs) is not None
    
    def get_expired_suppressions(self) -> List[Suppression]:
        """Get list of expired suppressions"""
        return [s for s in self.suppressions if s.is_expired()]
    
    def get_expiring_soon(self, days: int = 30) -> List[Suppression]:
        """Get suppressions expiring within N days"""
        threshold = datetime.now() + timedelta(days=days)
        return [
            s for s in self.suppressions 
            if s.expires_at and s.expires_at <= threshold and not s.is_expired()
        ]
    
    def generate_suppression_report(self) -> Dict:
        """
        Generate suppression summary for REACHABLE report
        
        Returns:
            Dictionary with suppression statistics and details
        """
        total = len(self.suppressions)
        expired = len(self.get_expired_suppressions())
        expiring_soon = len(self.get_expiring_soon(30))
        
        by_type = {}
        by_reason = {}
        
        for supp in self.suppressions:
            if not supp.is_expired():
                by_type[supp.type] = by_type.get(supp.type, 0) + 1
                by_reason[supp.reason] = by_reason.get(supp.reason, 0) + 1
        
        return {
            'total_suppressions': total,
            'active_suppressions': total - expired,
            'expired_suppressions': expired,
            'expiring_soon_30d': expiring_soon,
            'by_type': by_type,
            'by_reason': by_reason,
            'suppressions': [
                {
                    'id': s.id,
                    'type': s.type,
                    'target': s.target,
                    'reason': s.reason,
                    'justification': s.justification,
                    'created_by': s.created_by,
                    'created_at': s.created_at.isoformat() + 'Z',
                    'expires_at': s.expires_at.isoformat() + 'Z' if s.expires_at else None,
                    'is_expired': s.is_expired(),
                    'ticket': s.ticket
                }
                for s in self.suppressions
            ]
        }

def apply_suppressions_to_cves(cves: Dict, suppression_manager: SuppressionManager) -> Dict:
    """
    Apply suppressions to CVE findings
    
    Args:
        cves: Dictionary of CVE findings
        suppression_manager: SuppressionManager instance
    
    Returns:
        Modified CVE dict with suppression info
    """
    suppressed_cves = {}
    active_cves = {}
    
    for cve_id, cve_data in cves.items():
        package = cve_data.get('package', '')
        version = cve_data.get('version', '')
        severity = cve_data.get('severity', '')
        
        # Check for CVE-specific suppression
        cve_suppression = suppression_manager.find_suppression(
            'cve', cve_id,
            package=package,
            version=version,
            severity=severity
        )
        
        # Check for package-level suppression
        pkg_suppression = suppression_manager.find_suppression(
            'package', package,
            version=version
        )
        
        suppression = cve_suppression or pkg_suppression
        
        if suppression:
            cve_data['suppressed'] = True
            cve_data['suppression'] = {
                'id': suppression.id,
                'reason': suppression.reason,
                'justification': suppression.justification,
                'created_by': suppression.created_by,
                'created_at': suppression.created_at.isoformat() + 'Z',
                'expires_at': suppression.expires_at.isoformat() + 'Z' if suppression.expires_at else None,
                'ticket': suppression.ticket
            }
            suppressed_cves[cve_id] = cve_data
        else:
            cve_data['suppressed'] = False
            active_cves[cve_id] = cve_data
    
    return {
        'active': active_cves,
        'suppressed': suppressed_cves
    }

def apply_suppressions_to_secrets(secrets: List[Dict], suppression_manager: SuppressionManager) -> Dict:
    """
    Apply suppressions to secret findings
    
    Args:
        secrets: List of secret findings
        suppression_manager: SuppressionManager instance
    
    Returns:
        Categorized secrets (active vs suppressed)
    """
    active_secrets = []
    suppressed_secrets = []
    
    for secret in secrets:
        # Compute secret hash for matching
        raw_secret = secret.get('raw_secret', secret.get('match', ''))
        secret_hash = hashlib.sha256(raw_secret.encode()).hexdigest()
        
        file_path = secret.get('path', secret.get('file', ''))
        
        # Check suppression
        suppression = suppression_manager.find_suppression(
            'secret', secret_hash,
            file_path=file_path
        )
        
        if suppression:
            secret['suppressed'] = True
            secret['suppression'] = {
                'id': suppression.id,
                'reason': suppression.reason,
                'justification': suppression.justification,
                'created_by': suppression.created_by,
                'ticket': suppression.ticket
            }
            suppressed_secrets.append(secret)
        else:
            secret['suppressed'] = False
            active_secrets.append(secret)
    
    return {
        'active': active_secrets,
        'suppressed': suppressed_secrets
    }

def deduplicate_secrets(semgrep_secrets: List[Dict], 
                       trufflehog_secrets: List[Dict]) -> Dict:
    """
    Deduplicate secrets found by both Semgrep and TruffleHog
    
    Strategy:
    - TruffleHog is primary (better verification)
    - Remove Semgrep findings that overlap with TruffleHog
    - Track deduplication stats
    
    Args:
        semgrep_secrets: Secrets from Semgrep
        trufflehog_secrets: Secrets from TruffleHog
    
    Returns:
        Deduplicated secrets with attribution
    """
    # Build set of TruffleHog locations (file:line)
    trufflehog_locations = set()
    for secret in trufflehog_secrets:
        file_path = secret.get('file', secret.get('path', ''))
        line = secret.get('line', 0)
        trufflehog_locations.add((file_path, line))
    
    # Filter Semgrep secrets
    deduplicated_semgrep = []
    duplicates = 0
    
    for secret in semgrep_secrets:
        file_path = secret.get('path', '')
        line = secret.get('line', 0)
        
        if (file_path, line) in trufflehog_locations:
            duplicates += 1
            continue  # Skip, TruffleHog already found it
        
        secret['source'] = 'semgrep'
        deduplicated_semgrep.append(secret)
    
    # Mark TruffleHog secrets
    for secret in trufflehog_secrets:
        secret['source'] = 'trufflehog'
    
    # Combine
    all_secrets = trufflehog_secrets + deduplicated_semgrep
    
    return {
        'secrets': all_secrets,
        'total': len(all_secrets),
        'from_trufflehog': len(trufflehog_secrets),
        'from_semgrep': len(deduplicated_semgrep),
        'duplicates_removed': duplicates
    }

# Example suppression file template
SUPPRESSION_TEMPLATE = """
{
  "version": "1.0",
  "schema": "https://vera-security.org/schemas/suppressions/v1.0",
  "suppressions": [
    {
      "id": "SUPP-001",
      "type": "cve",
      "target": "CVE-2023-1234",
      "reason": "not_exploitable",
      "justification": "Vulnerable function is not reachable from any entry point",
      "created_by": "security-team@example.com",
      "created_at": "2025-12-26T10:00:00Z",
      "expires_at": "2026-12-26T10:00:00Z",
      "ticket": "JIRA-456"
    },
    {
      "id": "SUPP-002",
      "type": "secret",
      "target": "abc123def456...",
      "reason": "rotated",
      "justification": "Secret was rotated on 2025-12-20, old value is inactive",
      "created_by": "devops@example.com",
      "created_at": "2025-12-26T11:00:00Z",
      "file_pattern": "config/old-*.yaml"
    },
    {
      "id": "SUPP-003",
      "type": "package",
      "target": "urllib3",
      "reason": "compensating_controls",
      "justification": "WAF blocks all exploit attempts, upgrade scheduled Q1 2026",
      "created_by": "security-team@example.com",
      "created_at": "2025-12-26T12:00:00Z",
      "expires_at": "2026-03-31T23:59:59Z",
      "ticket": "JIRA-789",
      "package_version": "1.26.5"
    }
  ]
}
"""

if __name__ == '__main__':
    import sys
    
    if len(sys.argv) < 2:
        print("REACHABLE Suppression System")
        print()
        print("Usage:")
        print("  python suppressions.py <command> [args]")
        print()
        print("Commands:")
        print("  init <file>          Create template suppressions file")
        print("  validate <file>      Validate suppressions file")
        print("  list <file>          List all suppressions")
        print("  expired <file>       Show expired suppressions")
        print()
        sys.exit(1)
    
    command = sys.argv[1]
    
    if command == 'init':
        if len(sys.argv) < 3:
            print("Usage: python suppressions.py init <file>")
            sys.exit(1)
        
        filepath = Path(sys.argv[2])
        filepath.write_text(SUPPRESSION_TEMPLATE)
        print(f"✅ Created template: {filepath}")
    
    elif command == 'validate':
        if len(sys.argv) < 3:
            print("Usage: python suppressions.py validate <file>")
            sys.exit(1)
        
        filepath = Path(sys.argv[2])
        try:
            manager = SuppressionManager(filepath)
            print(f"✅ Valid suppressions file")
            print(f"   Total suppressions: {len(manager.suppressions)}")
            print(f"   Expired: {len(manager.get_expired_suppressions())}")
        except Exception as e:
            print(f"❌ Invalid: {e}")
            sys.exit(1)
    
    elif command == 'list':
        if len(sys.argv) < 3:
            print("Usage: python suppressions.py list <file>")
            sys.exit(1)
        
        filepath = Path(sys.argv[2])
        manager = SuppressionManager(filepath)
        
        print(f"Suppressions in {filepath}:")
        print()
        for supp in manager.suppressions:
            status = "❌ EXPIRED" if supp.is_expired() else "✅ ACTIVE"
            print(f"{status} {supp.id}: {supp.type} {supp.target}")
            print(f"   Reason: {supp.reason}")
            print(f"   By: {supp.created_by}")
            if supp.expires_at:
                print(f"   Expires: {supp.expires_at.isoformat()}")
            print()
    
    elif command == 'expired':
        if len(sys.argv) < 3:
            print("Usage: python suppressions.py expired <file>")
            sys.exit(1)
        
        filepath = Path(sys.argv[2])
        manager = SuppressionManager(filepath)
        expired = manager.get_expired_suppressions()
        
        if not expired:
            print("✅ No expired suppressions")
        else:
            print(f"⚠️  {len(expired)} expired suppressions:")
            for supp in expired:
                print(f"   {supp.id}: {supp.target}")
    
    else:
        print(f"Unknown command: {command}")
        sys.exit(1)
