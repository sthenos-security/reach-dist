#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.

"""
Execution Plan Engine
Defines phase-based execution with clear inputs/outputs.

Structure:
  Phase → Component → Action → Metadata → Output
"""

from dataclasses import dataclass, field
from typing import List, Dict, Optional
from enum import Enum

class ExecutionMode(Enum):
    """How to execute steps within a phase."""
    SERIAL = "serial"      # One after another
    PARALLEL = "parallel"  # All at once

@dataclass
class PhaseStep:
    """
    One step within a phase.
    
    Example:
      Component: SCA Worker
      Action: Scans package-lock.json for CVEs
      Metadata: {"lock_file": "package-lock.json"}
      Output: sca_results.json
    """
    component: str          # Tool/worker name (e.g., "SCA Worker", "Semgrep")
    action: str             # Human-readable description
    metadata: Dict          # Input requirements/configuration
    output: str             # Output file/artifact name
    command: Optional[str] = None  # Actual command to execute
    
    def to_dict(self):
        return {
            "component": self.component,
            "action": self.action,
            "metadata": self.metadata,
            "output": self.output,
            "command": self.command
        }

@dataclass
class ExecutionPhase:
    """
    One phase in the execution pipeline.
    
    Example:
      Phase 1: Parallel Scanning
        - SCA Worker
        - Semgrep SAST
    """
    phase_number: int
    phase_name: str
    description: str
    execution_mode: ExecutionMode
    steps: List[PhaseStep] = field(default_factory=list)
    depends_on: List[str] = field(default_factory=list)  # Previous phase outputs
    
    def to_dict(self):
        return {
            "phase": self.phase_number,
            "name": self.phase_name,
            "description": self.description,
            "execution_mode": self.execution_mode.value,
            "steps": [s.to_dict() for s in self.steps],
            "depends_on": self.depends_on
        }

class ExecutionPlanFactory:
    """
    Factory for creating language-specific execution plans.
    
    Each language gets a custom plan optimized for its characteristics.
    """
    
    @staticmethod
    def create_plan(language: str, project_path: str, project_id: str) -> List[ExecutionPhase]:
        """
        Create execution plan for a language.
        
        Args:
            language: Language type (python, js_ts, go, rust, java)
            project_path: Absolute path to project
            project_id: Unique project identifier
        
        Returns:
            List of execution phases
        """
        if language == "python":
            return ExecutionPlanFactory._python_plan(project_path, project_id)
        elif language == "js_ts":
            return ExecutionPlanFactory._javascript_plan(project_path, project_id)
        elif language == "go":
            return ExecutionPlanFactory._go_plan(project_path, project_id)
        elif language == "rust":
            return ExecutionPlanFactory._rust_plan(project_path, project_id)
        elif language == "java":
            return ExecutionPlanFactory._java_plan(project_path, project_id)
        else:
            return ExecutionPlanFactory._generic_plan(project_path, project_id)
    
    @staticmethod
    def _python_plan(project_path: str, project_id: str) -> List[ExecutionPhase]:
        """
        Python execution plan.
        
        SERIAL dependencies because we need to clone libs before reachability.
        """
        return [
            # Phase 1: SCA (must run first to know which libs to clone)
            ExecutionPhase(
                phase_number=1,
                phase_name="SCA",
                description="Dependency scanning (SBOM + Vulnerabilities)",
                execution_mode=ExecutionMode.SERIAL,
                steps=[
                    PhaseStep(
                        component="Syft",
                        action="Generate SBOM from requirements.txt/pyproject.toml",
                        metadata={
                            "manifest": "requirements.txt",
                            "project_path": project_path
                        },
                        output=f"output/{project_id}/sbom.json",
                        command=f"syft scan dir:{project_path} -o json"
                    ),
                    PhaseStep(
                        component="Grype",
                        action="Scan SBOM for known CVEs",
                        metadata={
                            "sbom_file": f"output/{project_id}/sbom.json"
                        },
                        output=f"output/{project_id}/vulns.json",
                        command=f"grype sbom:output/{project_id}/sbom.json -o json"
                    )
                ],
                depends_on=[]
            ),
            
            # Phase 2: Clone vulnerable libraries (Python-specific)
            ExecutionPhase(
                phase_number=2,
                phase_name="Library Cloning",
                description="Clone source code of vulnerable libraries for reachability analysis",
                execution_mode=ExecutionMode.SERIAL,
                steps=[
                    PhaseStep(
                        component="Library Manager (MCP/Git)",
                        action="Clone vulnerable package source code",
                        metadata={
                            "vulns_file": f"output/{project_id}/vulns.json",
                            "strategy": "MCP first, fallback to git clone"
                        },
                        output=f"output/{project_id}/libs/",
                        command=f"python -m reachable.lib_manager output/{project_id}/vulns.json output/{project_id}/libs/"
                    )
                ],
                depends_on=["output/{project_id}/vulns.json"]
            ),
            
            # Phase 3: Parallel Analysis (can run simultaneously once libs available)
            ExecutionPhase(
                phase_number=3,
                phase_name="Parallel Analysis",
                description="Reachability + SAST + Malware detection in parallel",
                execution_mode=ExecutionMode.PARALLEL,
                steps=[
                    PhaseStep(
                        component="REACHABLE Engine",
                        action="AST-based reachability analysis with library source code",
                        metadata={
                            "sbom": f"output/{project_id}/sbom.json",
                            "vulns": f"output/{project_id}/vulns.json",
                            "libs": f"output/{project_id}/libs/"
                        },
                        output=f"output/{project_id}/reachable-report.json",
                        command=f"python -m reachable scan {project_path} --sbom output/{project_id}/sbom.json --vulns output/{project_id}/vulns.json --libs output/{project_id}/libs/ -o output/{project_id}/reachable-report.json"
                    ),
                    PhaseStep(
                        component="Semgrep (SAST)",
                        action="Scan code for hardcoded secrets",
                        metadata={
                            "rules": "p/secrets",
                            "project_path": project_path
                        },
                        output=f"output/{project_id}/security_findings.json",
                        command=f"semgrep --config p/secrets --json {project_path}"
                    ),
                    PhaseStep(
                        component="GuardDog + Semgrep",
                        action="Scan Python packages for malware patterns",
                        metadata={
                            "requirements": f"{project_path}/requirements.txt"
                        },
                        output=f"output/{project_id}/malware.json",
                        command=f"guarddog scan {project_path}"
                    )
                ],
                depends_on=[f"output/{project_id}/libs/"]
            ),
            
            # Phase 4: Correlation
            ExecutionPhase(
                phase_number=4,
                phase_name="Correlation",
                description="Combine all findings into composite threats",
                execution_mode=ExecutionMode.SERIAL,
                steps=[
                    PhaseStep(
                        component="Correlation Engine",
                        action="Analyze composite threats (CVE + Secret + Malware)",
                        metadata={
                            "reachable_report": f"output/{project_id}/reachable-report.json",
                            "secrets": f"output/{project_id}/security_findings.json",
                            "malware": f"output/{project_id}/malware.json"
                        },
                        output=f"output/{project_id}/final-report.json",
                        command="# Built into REACHABLE report"
                    )
                ],
                depends_on=[
                    f"output/{project_id}/reachable-report.json",
                    f"output/{project_id}/security_findings.json",
                    f"output/{project_id}/malware.json"
                ]
            )
        ]
    
    @staticmethod
    def _javascript_plan(project_path: str, project_id: str) -> List[ExecutionPhase]:
        """
        JavaScript/TypeScript execution plan.
        
        PARALLEL first phase because lock file provides static dependency graph.
        """
        return [
            # Phase 1: Parallel Scanning (SCA + SAST together)
            ExecutionPhase(
                phase_number=1,
                phase_name="Parallel Scanning",
                description="SCA + SAST run simultaneously (no library cloning needed)",
                execution_mode=ExecutionMode.PARALLEL,
                steps=[
                    PhaseStep(
                        component="Syft",
                        action="Generate SBOM from package-lock.json",
                        metadata={
                            "lock_file": "package-lock.json",
                            "project_path": project_path
                        },
                        output=f"output/{project_id}/sbom.json",
                        command=f"syft scan dir:{project_path} -o json"
                    ),
                    PhaseStep(
                        component="Grype",
                        action="Scan package-lock.json for CVEs",
                        metadata={
                            "sbom": f"output/{project_id}/sbom.json"
                        },
                        output=f"output/{project_id}/vulns.json",
                        command=f"grype sbom:output/{project_id}/sbom.json -o json"
                    ),
                    PhaseStep(
                        component="Semgrep (SAST)",
                        action="Scan code for secrets and malware patterns",
                        metadata={
                            "rules": "p/secrets,p/javascript",
                            "project_path": project_path
                        },
                        output=f"output/{project_id}/sast_findings.json",
                        command=f"semgrep --config p/secrets --config p/javascript --json {project_path}"
                    ),
                    PhaseStep(
                        component="npm audit / Socket",
                        action="Scan npm packages for known malware",
                        metadata={
                            "package_json": f"{project_path}/package.json"
                        },
                        output=f"output/{project_id}/malware.json",
                        command=f"cd {project_path} && npm audit --json"
                    )
                ],
                depends_on=[]
            ),
            
            # Phase 2: Reachability Analysis
            ExecutionPhase(
                phase_number=2,
                phase_name="AST Reachability",
                description="Use lock file dependency graph to prove CVE reachability",
                execution_mode=ExecutionMode.SERIAL,
                steps=[
                    PhaseStep(
                        component="REACHABLE Engine",
                        action="AST-based reachability using package-lock.json dependency graph",
                        metadata={
                            "sbom": f"output/{project_id}/sbom.json",
                            "vulns": f"output/{project_id}/vulns.json",
                            "lock_file": f"{project_path}/package-lock.json"
                        },
                        output=f"output/{project_id}/reachable-report.json",
                        command=f"python -m reachable scan {project_path} --sbom output/{project_id}/sbom.json --vulns output/{project_id}/vulns.json -o output/{project_id}/reachable-report.json"
                    )
                ],
                depends_on=[f"output/{project_id}/vulns.json"]
            ),
            
            # Phase 3: Correlation
            ExecutionPhase(
                phase_number=3,
                phase_name="Correlation",
                description="Combine SCA + SAST + Reachability findings",
                execution_mode=ExecutionMode.SERIAL,
                steps=[
                    PhaseStep(
                        component="Correlation Engine",
                        action="Analyze composite threats",
                        metadata={
                            "reachable_report": f"output/{project_id}/reachable-report.json",
                            "sast_findings": f"output/{project_id}/sast_findings.json",
                            "malware": f"output/{project_id}/malware.json"
                        },
                        output=f"output/{project_id}/final-report.json",
                        command="# Built into REACHABLE report"
                    )
                ],
                depends_on=[
                    f"output/{project_id}/reachable-report.json",
                    f"output/{project_id}/sast_findings.json"
                ]
            )
        ]
    
    @staticmethod
    def _go_plan(project_path: str, project_id: str) -> List[ExecutionPhase]:
        """Go execution plan (similar to JavaScript - parallel first)."""
        return [
            ExecutionPhase(
                phase_number=1,
                phase_name="Parallel Scanning",
                description="SCA + SAST (go.sum provides static deps)",
                execution_mode=ExecutionMode.PARALLEL,
                steps=[
                    PhaseStep(
                        component="Syft",
                        action="Generate SBOM from go.mod/go.sum",
                        metadata={"go_mod": f"{project_path}/go.mod"},
                        output=f"output/{project_id}/sbom.json",
                        command=f"syft scan dir:{project_path} -o json"
                    ),
                    PhaseStep(
                        component="Grype",
                        action="Scan go.sum for CVEs",
                        metadata={"sbom": f"output/{project_id}/sbom.json"},
                        output=f"output/{project_id}/vulns.json",
                        command=f"grype sbom:output/{project_id}/sbom.json -o json"
                    ),
                    PhaseStep(
                        component="Semgrep (SAST)",
                        action="Scan Go code for secrets and vulnerabilities",
                        metadata={"rules": "p/secrets,p/golang"},
                        output=f"output/{project_id}/sast_findings.json",
                        command=f"semgrep --config p/secrets --config p/golang --json {project_path}"
                    )
                ],
                depends_on=[]
            ),
            ExecutionPhase(
                phase_number=2,
                phase_name="AST Reachability",
                description="Use go.mod dependency graph",
                execution_mode=ExecutionMode.SERIAL,
                steps=[
                    PhaseStep(
                        component="REACHABLE Engine",
                        action="AST-based reachability with go.sum",
                        metadata={
                            "sbom": f"output/{project_id}/sbom.json",
                            "vulns": f"output/{project_id}/vulns.json",
                            "go_sum": f"{project_path}/go.sum"
                        },
                        output=f"output/{project_id}/reachable-report.json",
                        command=f"python -m reachable scan {project_path} --sbom output/{project_id}/sbom.json --vulns output/{project_id}/vulns.json -o output/{project_id}/reachable-report.json"
                    )
                ],
                depends_on=[f"output/{project_id}/vulns.json"]
            ),
            ExecutionPhase(
                phase_number=3,
                phase_name="Correlation",
                description="Combine findings",
                execution_mode=ExecutionMode.SERIAL,
                steps=[
                    PhaseStep(
                        component="Correlation Engine",
                        action="Analyze composite threats",
                        metadata={
                            "reachable_report": f"output/{project_id}/reachable-report.json",
                            "sast_findings": f"output/{project_id}/sast_findings.json"
                        },
                        output=f"output/{project_id}/final-report.json",
                        command="# Built into REACHABLE report"
                    )
                ],
                depends_on=[f"output/{project_id}/reachable-report.json"]
            )
        ]
    
    @staticmethod
    def _rust_plan(project_path: str, project_id: str) -> List[ExecutionPhase]:
        """Rust execution plan (Cargo.lock provides static deps)."""
        # Similar to Go - parallel first
        return ExecutionPlanFactory._go_plan(project_path, project_id)  # Reuse for now
    
    @staticmethod
    def _java_plan(project_path: str, project_id: str) -> List[ExecutionPhase]:
        """Java execution plan (pom.xml/build.gradle)."""
        # Similar to Go - parallel first
        return ExecutionPlanFactory._go_plan(project_path, project_id)  # Reuse for now
    
    @staticmethod
    def _generic_plan(project_path: str, project_id: str) -> List[ExecutionPhase]:
        """Generic fallback plan."""
        return ExecutionPlanFactory._go_plan(project_path, project_id)

# CLI to visualize execution plan
if __name__ == "__main__":
    import sys
    
    language = sys.argv[1] if len(sys.argv) > 1 else "python"
    
    plan = ExecutionPlanFactory.create_plan(language, "/test/project", "test-project")
    
    print(f"\n{'='*70}")
    print(f"EXECUTION PLAN: {language.upper()}")
    print(f"{'='*70}\n")
    
    for phase in plan:
        print(f"Phase {phase.phase_number}: {phase.phase_name}")
        print(f"  Description: {phase.description}")
        print(f"  Mode: {phase.execution_mode.value.upper()}")
        if phase.depends_on:
            print(f"  Depends on: {', '.join(phase.depends_on)}")
        print(f"\n  Steps:")
        for step in phase.steps:
            print(f"    Component: {step.component}")
            print(f"    Action: {step.action}")
            print(f"    Output: {step.output}")
            print()
        print()
