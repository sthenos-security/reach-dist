#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.

"""
REACHABLE Metadata Manager
Manages metadata directories for CI/CD pipeline integration

Each scan (project + language) gets its own metadata directory:

Structure:
  monorepo-scan-results/
  ├── user-api/                    # Project namespace
  │   ├── python/                  # Language
  │   │   ├── .metadata/           # Metadata for THIS specific scan
  │   │   │   ├── scan-input.json     # Input parameters
  │   │   │   ├── scan-output.json    # Output summary
  │   │   │   ├── lib-cloning.json    # Library cloning metrics
  │   │   │   └── pipeline.json       # For next CI/CD step
  │   │   ├── sbom.json
  │   │   ├── vulns.json
  │   │   └── reachable-report.json
  │   └── js_ts/
  │       ├── .metadata/           # Separate metadata
  │       └── ...

Benefits:
- Each scan is self-contained
- CI/CD can chain steps by reading metadata
- Easy debugging (all scan info in one place)
- Parallel execution safe (no shared state)
"""

import json
import os
from datetime import datetime
from pathlib import Path
from typing import Dict, Optional, Any, List

class MetadataManager:
    """
    Manages metadata for a single scan (project + language).
    
    Handles:
    - Input parameters (what went in)
    - Output results (what came out)
    - Library cloning metrics
    - Pipeline state (for CI/CD chaining)
    """
    
    def __init__(self, scan_dir: Path, project_name: str, language: str):
        """
        Initialize metadata manager for a specific scan.
        
        Args:
            scan_dir: Base directory for this scan (e.g., output/user-api/python)
            project_name: Project name (e.g., "user-api")
            language: Language being scanned (e.g., "python")
        """
        self.scan_dir = Path(scan_dir)
        self.project_name = project_name
        self.language = language
        
        # Create metadata directory
        self.metadata_dir = self.scan_dir / ".metadata"
        self.metadata_dir.mkdir(parents=True, exist_ok=True)
        
        # Metadata files
        self.input_file = self.metadata_dir / "scan-input.json"
        self.output_file = self.metadata_dir / "scan-output.json"
        self.cloning_file = self.metadata_dir / "lib-cloning.json"
        self.pipeline_file = self.metadata_dir / "pipeline.json"
        
        # Output format files (VEX, SPDX, CycloneDX, etc.)
        self.formats_dir = self.metadata_dir / "formats"
        self.formats_dir.mkdir(parents=True, exist_ok=True)
        
        # Initialize scan start time
        self.scan_start = datetime.now().isoformat()
    
    def record_input(self, **kwargs):
        """
        Record input parameters for this scan.
        
        Example:
            record_input(
                app_dir="/services/user-api",
                sbom_path="output/user-api/python/sbom.json",
                vulns_path="output/user-api/python/vulns.json",
                libs_dir="output/user-api/python/libs"
            )
        """
        input_data = {
            "project_name": self.project_name,
            "language": self.language,
            "scan_start": self.scan_start,
            "scan_dir": str(self.scan_dir),
            **kwargs
        }
        
        with open(self.input_file, 'w') as f:
            json.dump(input_data, f, indent=2)
    
    def record_output(self, **kwargs):
        """
        Record output summary for this scan.
        
        Example:
            record_output(
                total_cves=15,
                reachable_cves=12,
                unreachable_cves=3,
                secrets_found=5,
                malware_found=2,
                composite_threats=3
            )
        """
        scan_end = datetime.now().isoformat()
        
        output_data = {
            "project_name": self.project_name,
            "language": self.language,
            "scan_start": self.scan_start,
            "scan_end": scan_end,
            **kwargs
        }
        
        with open(self.output_file, 'w') as f:
            json.dump(output_data, f, indent=2)
    
    def record_cloning_metrics(self, metrics: Dict):
        """
        Record library cloning metrics.
        
        Args:
            metrics: Dictionary with cloning stats
                {
                    'total_attempted': 10,
                    'mcp_success': 7,
                    'mcp_failed': 1,
                    'git_success': 2,
                    'git_failed': 0,
                    'clone_methods': [(pkg, method, success), ...]
                }
        """
        cloning_data = {
            "project_name": self.project_name,
            "language": self.language,
            "timestamp": datetime.now().isoformat(),
            **metrics
        }
        
        with open(self.cloning_file, 'w') as f:
            json.dump(cloning_data, f, indent=2)
    
    def write_pipeline_state(self, **kwargs):
        """
        Write pipeline state for CI/CD chaining.
        
        This allows next step in pipeline to read results from previous step.
        
        Example:
            write_pipeline_state(
                step="reachable-analysis",
                status="success",
                report_path="output/user-api/python/reachable-report.json",
                next_step="correlation",
                pass_to_next={
                    "cve_count": 15,
                    "reachable_count": 12
                }
            )
        """
        pipeline_data = {
            "project_name": self.project_name,
            "language": self.language,
            "timestamp": datetime.now().isoformat(),
            **kwargs
        }
        
        with open(self.pipeline_file, 'w') as f:
            json.dump(pipeline_data, f, indent=2)
    
    def read_pipeline_state(self) -> Optional[Dict]:
        """
        Read pipeline state from previous step.
        
        Returns:
            Dictionary with pipeline state, or None if not exists
        """
        if self.pipeline_file.exists():
            with open(self.pipeline_file, 'r') as f:
                return json.load(f)
        return None
    
    def get_summary(self) -> Dict:
        """
        Get complete metadata summary for this scan.
        
        Returns:
            Dictionary with all metadata
        """
        summary = {
            "project_name": self.project_name,
            "language": self.language,
            "metadata_dir": str(self.metadata_dir),
        }
        
        # Add input if available
        if self.input_file.exists():
            with open(self.input_file, 'r') as f:
                summary["input"] = json.load(f)
        
        # Add output if available
        if self.output_file.exists():
            with open(self.output_file, 'r') as f:
                summary["output"] = json.load(f)
        
        # Add cloning metrics if available
        if self.cloning_file.exists():
            with open(self.cloning_file, 'r') as f:
                summary["cloning"] = json.load(f)
        
        # Add pipeline state if available
        if self.pipeline_file.exists():
            with open(self.pipeline_file, 'r') as f:
                summary["pipeline"] = json.load(f)
        
        return summary
    
    def save_output_format(self, format_name: str, filepath: str):
        """
        Track an output file that was generated by the scanner.
        
        This doesn't recreate the file - it just records where it is
        so the CI/CD pipeline can find it.
        
        Args:
            format_name: Name of the format (e.g., "vex", "reachable-report", "sbom")
            filepath: Path to the actual file
        
        Example:
            # Track REACHABLE report
            manager.save_output_format("reachable-report", "output/reachable-report.json")
            
            # Track VEX document
            manager.save_output_format("vex", "output/reachable-report.vex.json")
            
            # Track SBOM
            manager.save_output_format("sbom", "output/sbom.json")
        """
        # Save reference to the file
        registry_file = self.formats_dir / "output-registry.json"
        
        # Load existing registry
        if registry_file.exists():
            with open(registry_file, 'r') as f:
                registry = json.load(f)
        else:
            registry = {}
        
        # Add this format
        registry[format_name] = {
            "filepath": filepath,
            "tracked_at": datetime.now().isoformat(),
            "exists": Path(filepath).exists()
        }
        
        # Save registry
        with open(registry_file, 'w') as f:
            json.dump(registry, f, indent=2)
    
    def get_output_format(self, format_name: str) -> Optional[str]:
        """
        Get the filepath for a tracked output format.
        
        Args:
            format_name: Name of the format
            
        Returns:
            Filepath if tracked, None otherwise
        """
        registry_file = self.formats_dir / "output-registry.json"
        
        if not registry_file.exists():
            return None
        
        with open(registry_file, 'r') as f:
            registry = json.load(f)
        
        entry = registry.get(format_name)
        if entry:
            return entry.get('filepath')
        return None
    
    def list_output_formats(self) -> List[Dict]:
        """
        List all tracked output formats.
        
        Returns:
            List of format entries with name, filepath, exists status
        """
        registry_file = self.formats_dir / "output-registry.json"
        
        if not registry_file.exists():
            return []
        
        with open(registry_file, 'r') as f:
            registry = json.load(f)
        
        formats = []
        for name, info in registry.items():
            formats.append({
                "name": name,
                "filepath": info.get('filepath'),
                "tracked_at": info.get('tracked_at'),
                "exists": Path(info.get('filepath', '')).exists()
            })
        
        return formats

# Example CI/CD usage pattern
def example_ci_cd_pipeline():
    """
    Example showing how metadata enables CI/CD pipeline chaining.
    
    Step 1: SBOM Generation
    Step 2: Vulnerability Scanning (reads from Step 1)
    Step 3: REACHABLE Analysis (reads from Step 2)
    Step 4: Correlation (reads from Step 3)
    """
    
    # Step 1: SBOM Generation
    metadata1 = MetadataManager(
        scan_dir=Path("output/user-api/python"),
        project_name="user-api",
        language="python"
    )
    
    metadata1.record_input(
        step="sbom-generation",
        app_dir="/services/user-api",
        manifest="requirements.txt"
    )
    
    # ... run syft ...
    
    metadata1.record_output(
        packages_found=25,
        sbom_path="output/user-api/python/sbom.json"
    )
    
    metadata1.write_pipeline_state(
        step="sbom-generation",
        status="success",
        next_step="vulnerability-scanning",
        pass_to_next={
            "sbom_path": "output/user-api/python/sbom.json",
            "packages": 25
        }
    )
    
    # Step 2: Vulnerability Scanning (reads from Step 1)
    metadata2 = MetadataManager(
        scan_dir=Path("output/user-api/python"),
        project_name="user-api",
        language="python"
    )
    
    # Read from previous step
    prev_state = metadata2.read_pipeline_state()
    sbom_path = prev_state["pass_to_next"]["sbom_path"]
    
    metadata2.record_input(
        step="vulnerability-scanning",
        sbom_path=sbom_path
    )
    
    # ... run grype ...
    
    metadata2.record_output(
        vulnerabilities_found=15,
        vulns_path="output/user-api/python/vulns.json"
    )
    
    metadata2.write_pipeline_state(
        step="vulnerability-scanning",
        status="success",
        next_step="reachable-analysis",
        pass_to_next={
            "sbom_path": sbom_path,
            "vulns_path": "output/user-api/python/vulns.json",
            "cve_count": 15
        }
    )
    
    # Step 3: REACHABLE Analysis (reads from Step 2)
    # ... and so on

if __name__ == "__main__":
    # Demo
    metadata = MetadataManager(
        scan_dir=Path("demo-output"),
        project_name="test-project",
        language="python"
    )
    
    metadata.record_input(
        app_dir="/test/app",
        sbom_path="demo-output/sbom.json"
    )
    
    metadata.record_output(
        total_cves=10,
        reachable_cves=7
    )
    
    metadata.record_cloning_metrics({
        'total_attempted': 5,
        'mcp_success': 3,
        'git_success': 2
    })
    
    print(json.dumps(metadata.get_summary(), indent=2))

class ProjectReportAggregator:
    """
    Aggregates language-specific scan results by PROJECT namespace.
    
    This is the key to preventing "Vulnerability Soup":
    - During scan: Each language has separate metadata
    - For reporting: Aggregate by PROJECT (what teams own)
    
    Example:
      Project: user-api
        ├── Python: 12 CVEs, 5 secrets, 2 malware
        ├── React: 13 CVEs, 3 secrets, 1 malware
        └── TOTAL: 25 CVEs, 8 secrets, 3 malware (aggregated)
    """
    
    def __init__(self, project_dir: Path, project_name: str):
        """
        Initialize project-level aggregator.
        
        Args:
            project_dir: Base directory for project (e.g., output/user-api)
            project_name: Project name (e.g., "user-api")
        """
        self.project_dir = Path(project_dir)
        self.project_name = project_name
        self.project_report_path = self.project_dir / "project-report.json"
    
    def discover_languages(self) -> Dict[str, Path]:
        """
        Discover all language scans under this project.
        
        Returns:
            Dictionary mapping language -> metadata directory
        """
        languages = {}
        
        for item in self.project_dir.iterdir():
            if item.is_dir() and not item.name.startswith('.'):
                metadata_dir = item / ".metadata"
                if metadata_dir.exists():
                    languages[item.name] = metadata_dir
        
        return languages
    
    def aggregate_language_results(self) -> Dict:
        """
        Aggregate results from all language scans.
        
        Returns:
            Dictionary with:
            - Per-language results
            - Aggregated project totals
            - Cloning metrics across all languages
        """
        languages = self.discover_languages()
        
        if not languages:
            return {
                "project": self.project_name,
                "error": "No language scans found",
                "languages": []
            }
        
        # Initialize aggregated counters
        project_totals = {
            "total_cves": 0,
            "total_reachable": 0,
            "total_unreachable": 0,
            "total_secrets": 0,
            "total_malware": 0,
            "total_composite_threats": 0,
        }
        
        # Cloning metrics across all languages
        cloning_totals = {
            "total_attempted": 0,
            "mcp_success": 0,
            "mcp_failed": 0,
            "git_success": 0,
            "git_failed": 0,
            "total_failed": 0,
        }
        
        # Per-language results
        language_results = {}
        
        for lang, metadata_dir in languages.items():
            lang_data = {
                "language": lang,
                "metadata_dir": str(metadata_dir),
                "status": "unknown"
            }
            
            # Read output metadata
            output_file = metadata_dir / "scan-output.json"
            if output_file.exists():
                try:
                    with open(output_file, 'r') as f:
                        output = json.load(f)
                    
                    lang_data["output"] = output
                    lang_data["status"] = "success"
                    
                    # Aggregate to project totals
                    project_totals["total_cves"] += output.get("total_cves", 0)
                    project_totals["total_reachable"] += output.get("reachable_cves", 0)
                    project_totals["total_unreachable"] += output.get("unreachable_cves", 0)
                    project_totals["total_secrets"] += output.get("secrets_found", 0)
                    project_totals["total_malware"] += output.get("malware_found", 0)
                    project_totals["total_composite_threats"] += output.get("composite_threats", 0)
                    
                except Exception as e:
                    lang_data["error"] = f"Failed to read output: {e}"
                    lang_data["status"] = "failed"
            
            # Read cloning metrics
            cloning_file = metadata_dir / "lib-cloning.json"
            if cloning_file.exists():
                try:
                    with open(cloning_file, 'r') as f:
                        cloning = json.load(f)
                    
                    lang_data["cloning"] = cloning
                    
                    # Aggregate cloning metrics
                    cloning_totals["total_attempted"] += cloning.get("total_attempted", 0)
                    cloning_totals["mcp_success"] += cloning.get("mcp_success", 0)
                    cloning_totals["mcp_failed"] += cloning.get("mcp_failed", 0)
                    cloning_totals["git_success"] += cloning.get("git_success", 0)
                    cloning_totals["git_failed"] += cloning.get("git_failed", 0)
                    cloning_totals["total_failed"] += cloning.get("total_failed", 0)
                    
                except Exception as e:
                    lang_data["cloning_error"] = f"Failed to read cloning metrics: {e}"
            
            language_results[lang] = lang_data
        
        # Build aggregated report
        report = {
            "project": self.project_name,
            "project_dir": str(self.project_dir),
            "timestamp": datetime.now().isoformat(),
            "languages_detected": list(languages.keys()),
            "language_count": len(languages),
            "is_polyglot": len(languages) > 1,
            
            # Per-language breakdown (prevents Vulnerability Soup)
            "languages": language_results,
            
            # Aggregated project totals (what teams care about)
            "project_totals": project_totals,
            
            # Cloning metrics across all languages
            "cloning_summary": cloning_totals,
        }
        
        return report
    
    def generate_project_report(self, save: bool = True) -> Dict:
        """
        Generate and optionally save project-level report.
        
        Args:
            save: If True, save to project-report.json
        
        Returns:
            Aggregated project report
        """
        report = self.aggregate_language_results()
        
        if save:
            with open(self.project_report_path, 'w') as f:
                json.dump(report, f, indent=2)
            
            report["report_path"] = str(self.project_report_path)
        
        return report
    
    def print_summary(self):
        """Print human-readable project summary."""
        report = self.aggregate_language_results()
        
        print()
        print("=" * 70)
        print(f"PROJECT REPORT: {self.project_name}")
        print("=" * 70)
        print()
        
        if report.get("error"):
            print(f"❌ {report['error']}")
            return
        
        # Project overview
        polyglot = " [POLYGLOT]" if report["is_polyglot"] else ""
        print(f"Languages: {', '.join(report['languages_detected'])}{polyglot}")
        print()
        
        # Per-language breakdown
        print("Per-Language Results:")
        print("-" * 70)
        for lang, data in report["languages"].items():
            status_icon = "✅" if data["status"] == "success" else "❌"
            print(f"{status_icon} {lang.upper()}")
            
            if "output" in data:
                output = data["output"]
                print(f"   CVEs: {output.get('total_cves', 0)} total "
                      f"({output.get('reachable_cves', 0)} reachable, "
                      f"{output.get('unreachable_cves', 0)} unreachable)")
                print(f"   Secrets: {output.get('secrets_found', 0)}")
                print(f"   Malware: {output.get('malware_found', 0)}")
                print(f"   Composite Threats: {output.get('composite_threats', 0)}")
            
            if "cloning" in data:
                cloning = data["cloning"]
                total = cloning.get("total_attempted", 0)
                mcp = cloning.get("mcp_success", 0)
                git = cloning.get("git_success", 0)
                if total > 0:
                    print(f"   Libraries: {total} cloned ({mcp} via MCP, {git} via git)")
            print()
        
        # Aggregated totals
        totals = report["project_totals"]
        print("PROJECT TOTALS (All Languages Combined):")
        print("-" * 70)
        print(f"🔴 Total CVEs: {totals['total_cves']}")
        print(f"   ✅ Reachable: {totals['total_reachable']} (require action)")
        print(f"   ❌ Unreachable: {totals['total_unreachable']} (Risk: LOW)")
        print(f"🔑 Total Secrets: {totals['total_secrets']}")
        print(f"🦠 Total Malware: {totals['total_malware']}")
        print(f"⚡ Composite Threats: {totals['total_composite_threats']}")
        print()
        
        # Cloning summary
        cloning = report["cloning_summary"]
        if cloning["total_attempted"] > 0:
            print("LIBRARY CLONING SUMMARY:")
            print("-" * 70)
            print(f"Total libraries: {cloning['total_attempted']}")
            print(f"  via MCP: {cloning['mcp_success']} ✅, {cloning['mcp_failed']} ❌")
            print(f"  via git: {cloning['git_success']} ✅, {cloning['git_failed']} ❌")
            print(f"  Failed: {cloning['total_failed']}")
            
            # Calculate success rate
            total_success = cloning['mcp_success'] + cloning['git_success']
            total_attempts = cloning['total_attempted']
            success_rate = (total_success / total_attempts * 100) if total_attempts > 0 else 0
            print(f"  Success rate: {success_rate:.1f}%")
            print()
        
        print("=" * 70)
        print()

# Example usage for monorepo
def example_monorepo_reporting():
    """
    Example: Generate reports for multiple projects in a monorepo.
    """
    
    # Project 1: user-api (polyglot: Python + React)
    user_api = ProjectReportAggregator(
        project_dir=Path("output/user-api"),
        project_name="user-api"
    )
    user_api.generate_project_report()
    user_api.print_summary()
    
    # Project 2: payment-service (Go only)
    payment = ProjectReportAggregator(
        project_dir=Path("output/payment-service"),
        project_name="payment-service"
    )
    payment.generate_project_report()
    payment.print_summary()
    
    # Monorepo-level summary would aggregate across all projects
