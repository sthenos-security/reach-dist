#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.

"""
REACHABLE Comprehensive Test Orchestrator
Runs all test cases and demonstrates clear value proposition

Key Features:
1. Source tool tracking (Grype, Syft, Semgrep, GuardDog, etc.)
2. Repo cloning logs (MCP vs git clone)
3. Multiple test cases with aggregate results
4. Clear value demonstration (reachability savings)
5. Test-specific logs and attribution
"""

import json
import subprocess
import sys
from pathlib import Path
from datetime import datetime
from typing import Dict, List, Optional
from dataclasses import dataclass, asdict
import time

@dataclass
class ToolAttribution:
    """Track which tool found which finding"""
    tool_name: str
    tool_version: str
    finding_type: str  # "CVE", "Secret", "Malware", "Health"
    finding_id: str
    timestamp: str

@dataclass
class TestResult:
    """Results for a single test case"""
    test_name: str
    language: str
    repo_path: str
    
    # Cloning info
    clone_method: str  # "MCP", "git", "local", "fallback:MCP->git"
    clone_time_seconds: float
    clone_success: bool
    clone_log: str
    
    # Scanner execution
    scanners_used: List[str]  # ["Syft", "Grype", "Semgrep", "GuardDog"]
    scanner_versions: Dict[str, str]
    
    # Findings with attribution
    total_cves: int
    reachable_cves: int
    unreachable_cves: int
    cve_sources: List[ToolAttribution]  # Which scanner found each CVE
    
    secrets_found: int
    secrets_reachable: int
    secret_sources: List[ToolAttribution]
    
    malware_found: int
    malware_sources: List[ToolAttribution]
    
    # Value demonstration
    traditional_scan_cves: int  # What Grype alone would report
    reachable_only_cves: int  # What REACHABLE reports
    risk_reduction_percent: float
    time_saved_minutes: float  # Estimated triage time saved
    
    # Test status
    passed: bool
    errors: List[str]
    duration_seconds: float

class TestOrchestrator:
    """Orchestrates all test cases with comprehensive tracking"""
    
    def __init__(self, base_dir: Path):
        self.base_dir = base_dir
        self.tests_dir = base_dir / "tests"
        self.output_dir = base_dir / "output" / "orchestrator"
        self.output_dir.mkdir(parents=True, exist_ok=True)
        
        self.results: List[TestResult] = []
        self.start_time = datetime.now()
        
    def run_all_tests(self):
        """Run comprehensive test suite"""
        print("=" * 80)
        print("REACHABLE COMPREHENSIVE TEST SUITE")
        print("Demonstrating Value Through Multiple Test Cases")
        print("=" * 80)
        print()
        
        # Define test battery
        tests = [
            ("Python: Vulnerable App", "python", "tests/vulnerable-app"),
            ("Python: Secure App", "python", "tests/secure-app"),
            ("Python: Secrets Detection", "python", "tests/secrets-test"),
            ("Python: Malware Detection", "python", "tests/malware-test"),
            ("JavaScript: npm Vulnerable", "javascript", "tests/npm-vulnerable-app"),
            ("Go: CVE-2020-9283", "go", "tests/go-vulnerable-app"),
        ]
        
        for i, (name, language, path) in enumerate(tests, 1):
            print(f"\n{'=' * 80}")
            print(f"TEST {i}/{len(tests)}: {name}")
            print(f"Language: {language} | Path: {path}")
            print("=" * 80)
            
            result = self.run_single_test(name, language, path)
            self.results.append(result)
            
            # Show immediate results
            self.print_test_summary(result)
        
        # Aggregate results
        print("\n\n")
        print("=" * 80)
        print("AGGREGATE RESULTS - VALUE PROPOSITION SUMMARY")
        print("=" * 80)
        self.print_aggregate_results()
        
        # Save detailed JSON
        self.save_results()
        
    def run_single_test(self, name: str, language: str, repo_path: str) -> TestResult:
        """Run a single test case with full tracking"""
        test_start = time.time()
        
        repo_full_path = self.base_dir / repo_path
        
        # Initialize result
        result = TestResult(
            test_name=name,
            language=language,
            repo_path=repo_path,
            clone_method="local",
            clone_time_seconds=0,
            clone_success=True,
            clone_log=f"Using local directory: {repo_full_path}",
            scanners_used=[],
            scanner_versions={},
            total_cves=0,
            reachable_cves=0,
            unreachable_cves=0,
            cve_sources=[],
            secrets_found=0,
            secrets_reachable=0,
            secret_sources=[],
            malware_found=0,
            malware_sources=[],
            traditional_scan_cves=0,
            reachable_only_cves=0,
            risk_reduction_percent=0,
            time_saved_minutes=0,
            passed=False,
            errors=[],
            duration_seconds=0
        )
        
        try:
            # Step 1: Check if repo exists or needs cloning
            clone_result = self.handle_repo_access(repo_full_path)
            result.clone_method = clone_result["method"]
            result.clone_time_seconds = clone_result["time"]
            result.clone_success = clone_result["success"]
            result.clone_log = clone_result["log"]
            
            if not result.clone_success:
                result.errors.append(f"Failed to access repo: {clone_result['error']}")
                result.duration_seconds = time.time() - test_start
                return result
            
            # Step 2: Detect and run scanners
            scanner_results = self.run_scanners(repo_full_path, language)
            result.scanners_used = scanner_results["scanners"]
            result.scanner_versions = scanner_results["versions"]
            
            # Step 3: Run REACHABLE analysis
            analysis_results = self.run_reachable_analysis(repo_full_path, scanner_results)
            
            # Step 4: Extract results with attribution
            result.total_cves = analysis_results.get("total_cves", 0)
            result.reachable_cves = analysis_results.get("reachable_cves", 0)
            result.unreachable_cves = result.total_cves - result.reachable_cves
            result.cve_sources = analysis_results.get("cve_sources", [])
            
            result.secrets_found = analysis_results.get("secrets_found", 0)
            result.secrets_reachable = analysis_results.get("secrets_reachable", 0)
            result.secret_sources = analysis_results.get("secret_sources", [])
            
            result.malware_found = analysis_results.get("malware_found", 0)
            result.malware_sources = analysis_results.get("malware_sources", [])
            
            # Step 5: Calculate value metrics
            result.traditional_scan_cves = result.total_cves
            result.reachable_only_cves = result.reachable_cves
            
            if result.total_cves > 0:
                result.risk_reduction_percent = (
                    (result.total_cves - result.reachable_cves) / result.total_cves * 100
                )
            
            # Estimate time saved (5 min per CVE triage)
            result.time_saved_minutes = result.unreachable_cves * 5
            
            result.passed = True
            
        except Exception as e:
            result.errors.append(f"Test failed: {str(e)}")
            import traceback
            result.errors.append(traceback.format_exc())
        
        result.duration_seconds = time.time() - test_start
        return result
    
    def handle_repo_access(self, repo_path: Path) -> Dict:
        """Handle repo cloning with MCP fallback to git"""
        start = time.time()
        
        # Check if local directory exists
        if repo_path.exists():
            return {
                "method": "local",
                "time": time.time() - start,
                "success": True,
                "log": f"✓ Using local directory: {repo_path}"
            }
        
        # Try MCP clone first
        print(f"   [Clone] Attempting MCP clone...")
        mcp_result = self.try_mcp_clone(repo_path)
        
        if mcp_result["success"]:
            return {
                "method": "MCP",
                "time": time.time() - start,
                "success": True,
                "log": mcp_result["log"]
            }
        
        # Fallback to git clone
        print(f"   [Clone] MCP failed, falling back to git clone...")
        git_result = self.try_git_clone(repo_path)
        
        if git_result["success"]:
            return {
                "method": "fallback:MCP->git",
                "time": time.time() - start,
                "success": True,
                "log": f"{mcp_result['log']}\n{git_result['log']}"
            }
        
        return {
            "method": "failed",
            "time": time.time() - start,
            "success": False,
            "log": f"MCP: {mcp_result['error']}\nGit: {git_result['error']}",
            "error": "Both MCP and git clone failed"
        }
    
    def try_mcp_clone(self, repo_path: Path) -> Dict:
        """Try cloning via MCP"""
        try:
            # Placeholder - would use actual MCP implementation
            return {
                "success": False,
                "error": "MCP not available (placeholder)"
            }
        except Exception as e:
            return {
                "success": False,
                "error": str(e)
            }
    
    def try_git_clone(self, repo_path: Path) -> Dict:
        """Try cloning via git"""
        try:
            # Placeholder - would use actual git clone
            return {
                "success": False,
                "error": "Not a git repository (placeholder)"
            }
        except Exception as e:
            return {
                "success": False,
                "error": str(e)
            }
    
    def run_scanners(self, repo_path: Path, language: str) -> Dict:
        """Run appropriate scanners for language"""
        print(f"   [Scanners] Detecting tools for {language}...")
        
        scanners = []
        versions = {}
        
        # Always run SBOM generation
        if self.check_tool("syft"):
            scanners.append("Syft")
            versions["Syft"] = self.get_tool_version("syft")
            print(f"      ✓ Syft {versions['Syft']}")
        
        # Always run CVE scanning
        if self.check_tool("grype"):
            scanners.append("Grype")
            versions["Grype"] = self.get_tool_version("grype")
            print(f"      ✓ Grype {versions['Grype']}")
        
        # Language-specific scanners
        if language == "python":
            if self.check_tool("semgrep"):
                scanners.append("Semgrep")
                versions["Semgrep"] = self.get_tool_version("semgrep")
                print(f"      ✓ Semgrep {versions['Semgrep']}")
            
            if self.check_tool("guarddog"):
                scanners.append("GuardDog")
                versions["GuardDog"] = self.get_tool_version("guarddog")
                print(f"      ✓ GuardDog {versions['GuardDog']}")
        
        elif language == "go":
            if self.check_tool("govulncheck"):
                scanners.append("govulncheck")
                versions["govulncheck"] = self.get_tool_version("govulncheck")
                print(f"      ✓ govulncheck {versions['govulncheck']}")
        
        return {
            "scanners": scanners,
            "versions": versions
        }
    
    def check_tool(self, tool: str) -> bool:
        """Check if tool is available"""
        try:
            subprocess.run([tool, "--version"], capture_output=True, check=True)
            return True
        except:
            return False
    
    def get_tool_version(self, tool: str) -> str:
        """Get tool version"""
        try:
            result = subprocess.run(
                [tool, "--version"],
                capture_output=True,
                text=True
            )
            # Parse version from output
            version = result.stdout.strip().split()[0] if result.stdout else "unknown"
            return version
        except:
            return "unknown"
    
    def run_reachable_analysis(self, repo_path: Path, scanner_results: Dict) -> Dict:
        """Run REACHABLE analysis and extract results with attribution"""
        print(f"   [Analysis] Running REACHABLE analysis...")
        
        # Placeholder - would run actual REACHABLE
        # For now, return mock data
        return {
            "total_cves": 0,
            "reachable_cves": 0,
            "cve_sources": [],
            "secrets_found": 0,
            "secrets_reachable": 0,
            "secret_sources": [],
            "malware_found": 0,
            "malware_sources": []
        }
    
    def print_test_summary(self, result: TestResult):
        """Print immediate test summary"""
        print()
        print("   " + "-" * 76)
        print(f"   TEST RESULT: {'✓ PASSED' if result.passed else '✗ FAILED'}")
        print("   " + "-" * 76)
        
        if result.passed:
            print(f"   Clone Method: {result.clone_method} ({result.clone_time_seconds:.2f}s)")
            print(f"   Scanners: {', '.join(result.scanners_used)}")
            print()
            print(f"   📊 VALUE DEMONSTRATION:")
            print(f"      Traditional Scanner (Grype): {result.traditional_scan_cves} CVEs")
            print(f"      REACHABLE (After Analysis): {result.reachable_only_cves} CVEs")
            print(f"      ✓ Risk Reduction: {result.risk_reduction_percent:.1f}%")
            print(f"      ✓ Time Saved: {result.time_saved_minutes:.0f} minutes")
            print()
            print(f"   Duration: {result.duration_seconds:.1f}s")
        else:
            print(f"   Errors: {len(result.errors)}")
            for error in result.errors:
                print(f"      - {error}")
    
    def print_aggregate_results(self):
        """Print comprehensive aggregate results table"""
        
        # Summary table
        print()
        print("TEST RESULTS SUMMARY")
        print("-" * 80)
        print(f"{'Test Name':<30} {'Lang':<10} {'CVEs':<8} {'Reach':<8} {'Saved%':<10} {'Status'}")
        print("-" * 80)
        
        total_cves = 0
        total_reachable = 0
        total_time_saved = 0
        
        for result in self.results:
            status = "✓ PASS" if result.passed else "✗ FAIL"
            print(
                f"{result.test_name:<30} "
                f"{result.language:<10} "
                f"{result.total_cves:<8} "
                f"{result.reachable_cves:<8} "
                f"{result.risk_reduction_percent:>6.1f}%   "
                f"{status}"
            )
            
            total_cves += result.total_cves
            total_reachable += result.reachable_cves
            total_time_saved += result.time_saved_minutes
        
        print("-" * 80)
        print(f"{'TOTAL':<30} {'':<10} {total_cves:<8} {total_reachable:<8}")
        print()
        
        # Value proposition
        if total_cves > 0:
            overall_reduction = (total_cves - total_reachable) / total_cves * 100
            print("🎯 OVERALL VALUE PROPOSITION")
            print("-" * 80)
            print(f"Total CVEs Found (Traditional): {total_cves}")
            print(f"Actionable CVEs (REACHABLE): {total_reachable}")
            print(f"CVEs Deprioritized: {total_cves - total_reachable}")
            print()
            print(f"✓ Risk Reduction: {overall_reduction:.1f}%")
            print(f"✓ Time Saved: {total_time_saved:.0f} minutes ({total_time_saved/60:.1f} hours)")
            print(f"✓ Focus Improvement: {total_cves}x noise → {total_reachable}x signal")
            print()
        
        # Scanner attribution table
        print()
        print("SCANNER ATTRIBUTION")
        print("-" * 80)
        scanner_usage = {}
        for result in self.results:
            for scanner in result.scanners_used:
                scanner_usage[scanner] = scanner_usage.get(scanner, 0) + 1
        
        for scanner, count in sorted(scanner_usage.items()):
            print(f"   {scanner:<20} Used in {count}/{len(self.results)} tests")
        
        print()
    
    def save_results(self):
        """Save detailed results to JSON"""
        output_file = self.output_dir / f"test-results-{datetime.now().strftime('%Y%m%d-%H%M%S')}.json"
        
        data = {
            "run_timestamp": self.start_time.isoformat(),
            "total_tests": len(self.results),
            "passed": sum(1 for r in self.results if r.passed),
            "failed": sum(1 for r in self.results if not r.passed),
            "results": [asdict(r) for r in self.results]
        }
        
        with open(output_file, 'w') as f:
            json.dump(data, f, indent=2, default=str)
        
        print(f"📄 Detailed results saved to: {output_file}")

def main():
    base_dir = Path(__file__).parent.parent
    orchestrator = TestOrchestrator(base_dir)
    orchestrator.run_all_tests()

if __name__ == "__main__":
    main()
