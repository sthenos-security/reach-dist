// REACHABLE Dashboard v2.9.29 - Complete Capability Matrix
var sampleData = {};

function initDashboard(data) {
    data = data || sampleData;
    var d = transformReport(data);
    
    updateMetadata(d.metadata);
    updateGitInfo(d.metadata);
    renderExecutiveSummary(d);
    renderRiskScore(d);
    updateKPICards(d);
    renderROIPanel(d);
    renderLanguageBreakdown(d);
    renderProjectBreakdown(d);
    renderSeverityChart(d.severity_breakdown);
    renderReductionChart(d);
    renderRemediationGuidance(d);
    renderCVEDetails(d);
    renderSecretsDetails(d);
    renderUpgradeRecommendations(d);
    renderCoverage(d.coverage);
    renderThreatIntel(d.threat_intel);
    renderAttackSurface(d.attack_surface);
    renderSandboxPanel(d.sandbox);
    renderScoringFormulas(d);
    renderCapabilityMatrix(d);
    renderPackageHealth(d.package_health);
    renderPackagesTable(d.top_packages);
    renderIssuesTable(d.issues, d.raw_secrets);
    setupFilters();
}

function transformReport(r) {
    var m = r.metrics || {};
    var cveMetrics = m.cves || {};
    var secScans = m.security_scans || {};
    var secretsMetrics = secScans.secrets || {};
    var malwareMetrics = secScans.malware || {};
    var sandboxMetrics = secScans.sandbox || r.sandbox || {};
    var healthMetrics = m.health_metrics || {};
    var importMetrics = m.import_analysis || {};
    var callGraph = m.call_graph || {};
    
    var reachableCVEs = r.reachable || {};
    var unreachableCVEs = r.unreachable || {};
    if (Object.keys(reachableCVEs).length === 0 && r.cves_by_reachability) {
        reachableCVEs = r.cves_by_reachability.reachable || {};
        unreachableCVEs = r.cves_by_reachability.unreachable || {};
    }
    
    var sevBreak = {critical: {total: 0, live: 0, dead: 0}, high: {total: 0, live: 0, dead: 0}, medium: {total: 0, live: 0, dead: 0}, low: {total: 0, live: 0, dead: 0}};
    var langStats = {Go: {total: 0, live: 0}, JavaScript: {total: 0, live: 0}, Python: {total: 0, live: 0}, Java: {total: 0, live: 0}, Other: {total: 0, live: 0}};
    var projectStats = {};
    var pkgStats = {};
    var cveDetails = [];
    var issues = [];
    
    function detectLang(pkg) {
        if (!pkg) return "Other";
        if (pkg.includes("golang.org") || pkg.includes("github.com/") || pkg.includes("k8s.io") || pkg.includes("gopkg.in")) return "Go";
        if (pkg.startsWith("@") || ["next", "postcss", "braces", "lodash", "express", "axios", "react", "webpack", "babel", "eslint", "typescript", "jest", "mocha"].some(function(n) { return pkg.includes(n); })) return "JavaScript";
        if (["requests", "flask", "django", "numpy", "pandas", "scipy", "pip", "setuptools"].some(function(n) { return pkg.includes(n); })) return "Python";
        if (pkg.includes("springframework") || pkg.includes("maven") || pkg.includes("apache") || pkg.includes("javax")) return "Java";
        return "Other";
    }
    
    function processCV(id, c, isReachable) {
        var sev = (c.severity || "").toLowerCase();
        if (sevBreak[sev]) { sevBreak[sev].total++; if (isReachable) sevBreak[sev].live++; else sevBreak[sev].dead++; }
        
        var pkg = c.package || "unknown";
        var ver = c.version || "";
        var key = pkg + "@" + ver;
        var lang = detectLang(pkg);
        
        langStats[lang].total++;
        if (isReachable) langStats[lang].live++;
        
        var funcs = c.affected_functions || c.unreachable_functions || [];
        // Filter out internal placeholder functions
        funcs = funcs.filter(function(f) { return !f.startsWith('__') || !f.endsWith('__'); });
        funcs.slice(0, 5).forEach(function(f) {
            var proj = (f.split(".")[1] || f.split(".")[0] || "unknown");
            if (!projectStats[proj]) projectStats[proj] = {total: 0, live: 0, critical: 0, high: 0};
            projectStats[proj].total++;
            if (isReachable) projectStats[proj].live++;
            if (sev === "critical") projectStats[proj].critical++;
            if (sev === "high") projectStats[proj].high++;
        });
        
        if (!pkgStats[key]) pkgStats[key] = {name: pkg, version: ver, cves_total: 0, cves_reachable: 0, severity_max: "low", fixable: true, fix_versions: [], language: lang};
        pkgStats[key].cves_total++;
        if (isReachable) pkgStats[key].cves_reachable++;
        if (c.fix_versions && c.fix_versions.length > 0) pkgStats[key].fix_versions = c.fix_versions;
        if (c.is_fixable === false || c.fix_state === "not-fixed") pkgStats[key].fixable = false;
        if (sev === "critical") pkgStats[key].severity_max = "critical";
        else if (sev === "high" && pkgStats[key].severity_max !== "critical") pkgStats[key].severity_max = "high";
        else if (sev === "medium" && pkgStats[key].severity_max === "low") pkgStats[key].severity_max = "medium";
        
        issues.push({
            id: c.cve || id, 
            severity: sev, 
            type: "cve", 
            package: pkg + " " + ver, 
            status: isReachable ? "live" : "dead", 
            description: c.description || "", 
            fix_versions: c.fix_versions || [],
            remediation: c.remediation || null,
            call_path: isReachable ? (c.reachable_functions || c.affected_functions || c.call_paths || []).slice(0, 5) : null
        });
        
        if (sev === "critical" || sev === "high") {
            // Extract GHSA and CVE IDs for dual display
            var primaryId = c.cve || id;
            var relatedIds = c.related_cves || [];
            var ghsaId = null;
            var cveId = null;
            
            if (primaryId.startsWith('GHSA-')) {
                ghsaId = primaryId;
                cveId = relatedIds.find(function(rid) { return rid.startsWith('CVE-'); }) || null;
                if (!cveId && c.exploitability && c.exploitability.id_mapping) {
                    cveId = c.exploitability.id_mapping.mapped_cve || null;
                }
            } else if (primaryId.startsWith('CVE-')) {
                cveId = primaryId;
                ghsaId = relatedIds.find(function(rid) { return rid.startsWith('GHSA-'); }) || null;
            }
            
            cveDetails.push({
                id: primaryId,
                cve_id: cveId,
                ghsa_id: ghsaId,
                severity: sev, 
                package: pkg, 
                version: ver, 
                description: c.description || "", 
                fix_versions: c.fix_versions || [], 
                cvss: c.cvss_score, 
                status: isReachable ? "live" : "dead", 
                kev: c.exploitability && c.exploitability.kev && c.exploitability.kev.in_catalog,
                remediation: c.remediation || null,
                reachable_functions: c.reachable_functions || c.affected_functions || c.call_paths || [],
                call_paths: c.call_paths || []
            });
        }
    }
    
    Object.keys(reachableCVEs).forEach(function(id) { processCV(id, reachableCVEs[id], true); });
    Object.keys(unreachableCVEs).forEach(function(id) { processCV(id, unreachableCVEs[id], false); });
    
    var bySev = cveMetrics.by_severity || {};
    if (sevBreak.critical.total === 0 && bySev.critical) { sevBreak.critical.total = bySev.critical; sevBreak.critical.dead = bySev.critical; }
    if (sevBreak.high.total === 0 && bySev.high) { sevBreak.high.total = bySev.high; sevBreak.high.dead = bySev.high; }
    if (sevBreak.medium.total === 0 && bySev.medium) { sevBreak.medium.total = bySev.medium; sevBreak.medium.dead = bySev.medium; }
    if (sevBreak.low.total === 0 && bySev.low) { sevBreak.low.total = bySev.low; sevBreak.low.dead = bySev.low; }
    
    var detailedFindings = r.detailed_findings || {};
    var secretsList = (detailedFindings.secrets || {}).findings || [];
    
    // Secret detection patterns - actual hardcoded credentials
    var SECRET_PATTERNS = ['hardcoded', 'secret', 'password', 'api-key', 'api_key', 'apikey', 'token', 'credential', 'private-key', 'private_key', 'aws-', 'gcp-', 'azure-', 'slack-', 'github-token', 'jwt', 'bearer', 'generic-', 'detected-', 'exposed-'];
    
    var secretIdx = 0;
    var sastIdx = 0;
    
    secretsList.forEach(function(s, idx) {
        var ruleId = s.rule_id || s.check_id || '';
        var ruleLower = ruleId.toLowerCase();
        var msgLower = (s.message || '').toLowerCase();
        
        // Classify: actual secret vs SAST finding
        var isActualSecret = SECRET_PATTERNS.some(function(pat) { return ruleLower.includes(pat); });
        if (!isActualSecret) {
            isActualSecret = ['hardcoded password', 'hardcoded secret', 'api key', 'credential', 'token detected', 'private key', 'exposed secret'].some(function(w) { return msgLower.includes(w); });
        }
        
        // Also check if it's explicitly marked as actual secret from backend
        if (s.is_actual_secret === true) {
            isActualSecret = true;
        }
        if (s.finding_type === 'CWE' || s.cwe_id) {
            isActualSecret = false;  // CWE findings are NOT secrets
        }
        
        s.is_actual_secret = isActualSecret;
        s.finding_type = isActualSecret ? 'SECRET' : 'SAST';
        
        // Generate appropriate ID
        var issueId;
        var issueType;
        if (isActualSecret) {
            secretIdx++;
            issueId = "SECRET-" + secretIdx;
            issueType = 'secret';
        } else {
            sastIdx++;
            issueId = "SAST-" + sastIdx;
            issueType = 'sast';
        }
        
        // SEVERITY LOGIC per design doc:
        // For SECRETS:
        //   - CRITICAL: Reachable + loader found (confirmed used)
        //   - CRITICAL + TRIAGE: Reachable + no loader (assume used, verify)
        //   - HIGH: Unreachable (lower priority but still needs attention)
        // For SAST (CWE):
        //   - Use original severity from scanner
        var severity;
        var needsTriage = s.needs_human_triage || false;
        var hasLoader = s.reachability_evidence && !s.reachability_evidence.includes('No loader');
        
        if (isActualSecret) {
            // Secrets severity based on reachability and loader
            if (s.is_reachable) {
                severity = 'critical';
                if (!hasLoader) {
                    needsTriage = true;  // No loader found - needs verification
                }
            } else {
                severity = 'high';  // Unreachable secrets are HIGH, not CRITICAL
            }
        } else {
            // SAST/CWE findings - use original severity mapping
            var sevMap = {"ERROR": "high", "WARNING": "medium", "INFO": "low"};
            severity = sevMap[s.severity] || "medium";
        }
        
        // Extract filename and full path
        var fullPath = s.file || '';
        var fileName = fullPath ? fullPath.split("/").pop() : '';
        var lineNum = s.line || (s.start ? s.start.line : '');
        
        // Build reachability info - include function name if available
        var reachabilityInfo = {
            is_reachable: s.is_reachable || false,
            function_name: s.reachable_function || s.function_name || s.in_function || null,
            call_path: s.call_path || s.reachable_via || null,
            has_loader: hasLoader,
            needs_triage: needsTriage,
            triage_reason: s.triage_reason || null
        };
        
        issues.push({
            id: issueId, 
            severity: severity, 
            type: issueType, 
            file_name: fileName,
            file_path: fullPath,
            line: lineNum,
            reachability: reachabilityInfo,
            description: s.message || s.rule_id || "",
            rule_id: ruleId,
            remediation: s.remediation,
            is_actual_secret: isActualSecret,
            needs_triage: needsTriage
        });
    });
    
    var topPkgs = Object.values(pkgStats).sort(function(a, b) {
        if (a.cves_reachable !== b.cves_reachable) return b.cves_reachable - a.cves_reachable;
        var so = {critical: 4, high: 3, medium: 2, low: 1};
        return (so[b.severity_max] || 0) - (so[a.severity_max] || 0);
    }).slice(0, 25);
    
    var cvesTotal = cveMetrics.total_found || Object.keys(reachableCVEs).length + Object.keys(unreachableCVEs).length;
    var cvesReachable = cveMetrics.reachable || Object.keys(reachableCVEs).length;
    var cvesUnreachable = cveMetrics.unreachable || Object.keys(unreachableCVEs).length;
    var secretsTotal = secretsMetrics.total_detected || secretsList.length;
    var malwareTotal = malwareMetrics.malicious_packages || 0;
    var noFix = (cveMetrics.fix_status || {}).no_fix || 0;
    var phantomDeps = importMetrics.phantom_dependencies || 0;
    
    // Sandbox/Behavioral analysis metrics
    var sandboxFindings = sandboxMetrics.findings || [];
    var sandboxVerdict = sandboxMetrics.verdict || "NOT_RUN";
    var sandboxCritical = sandboxFindings.filter(function(f) { return f.severity === "CRITICAL"; }).length;
    var sandboxHigh = sandboxFindings.filter(function(f) { return f.severity === "HIGH"; }).length;
    var sandboxCapabilityScore = sandboxMetrics.capability_score !== undefined ? sandboxMetrics.capability_score : 1.0;
    var sandboxPackagesTested = sandboxMetrics.packages_tested || 0;
    
    // Add sandbox findings to issues list
    sandboxFindings.forEach(function(f) {
        issues.push({
            id: f.rule || "SANDBOX",
            type: "sandbox",
            severity: (f.severity || "HIGH").toLowerCase(),
            package: sandboxMetrics.package || "install-time",
            description: f.description || f.rule,
            reachable: true,
            evidence: f.evidence || {}
        });
    });
    
    // Calculate risk score
    var riskScore = 0;
    riskScore += sevBreak.critical.live * 250;
    riskScore += sevBreak.critical.dead * 25;
    riskScore += sevBreak.high.live * 100;
    riskScore += sevBreak.high.dead * 10;
    riskScore += sevBreak.medium.live * 40;
    riskScore += sevBreak.medium.dead * 4;
    riskScore += sevBreak.low.live * 10;
    riskScore += malwareTotal * 500;
    riskScore += phantomDeps * 50;
    riskScore += noFix * 30;
    
    // Sandbox behavioral risk - CRITICAL findings are severe
    riskScore += sandboxCritical * 600;  // Network/credential access during install
    riskScore += sandboxHigh * 200;      // Suspicious behavior
    
    // If sandbox verdict is CRITICAL, ensure risk level reflects it
    var sandboxIsCritical = sandboxVerdict === "CRITICAL" || sandboxCritical > 0;
    
    var riskLevel = "LOW";
    if (riskScore >= 800 || sevBreak.critical.live > 0 || malwareTotal > 0 || sandboxIsCritical) riskLevel = "CRITICAL";
    else if (riskScore >= 400 || sevBreak.high.live > 2 || sandboxHigh > 0) riskLevel = "HIGH";
    else if (riskScore >= 150 || sevBreak.high.live > 0) riskLevel = "MEDIUM";
    
    var exploitability = "NONE";
    if (sevBreak.critical.live > 0 || sevBreak.high.live > 0) exploitability = "HIGH";
    else if (sevBreak.medium.live > 0) exploitability = "MEDIUM";
    else if (cvesReachable > 0) exploitability = "LOW";
    
    var reductionPct = cvesTotal > 0 ? Math.round((cvesUnreachable / cvesTotal) * 100) : 0;
    
    var meta = r.metadata || {};
    var target = meta.analysis_target || {};
    var appDir = target.app_directory || "";
    
    return {
        metadata: {scan_id: (meta.generated_at || "").substring(0, 19), timestamp: meta.generated_at, repository: appDir.split("/").pop() || "Unknown", git: target.git},
        findings: {cves_total: cvesTotal, cves_reachable: cvesReachable, cves_eliminated: cvesUnreachable, cves_no_fix: noFix, secrets_total: secretsTotal, secrets_live: secretsMetrics.reachable_critical || 0, malware_total: malwareTotal, phantom_deps: phantomDeps, sandbox_critical: sandboxCritical, sandbox_high: sandboxHigh, sandbox_total: sandboxFindings.length},
        risk_assessment: {level: riskLevel, score: riskScore, max_score: 1000, exploitability: exploitability},
        workload_reduction: {reduction_percentage: reductionPct, issues_eliminated: cvesUnreachable},
        severity_breakdown: sevBreak,
        language_stats: langStats,
        project_stats: projectStats,
        coverage: {sbom: 100, cve_scanning: cvesTotal > 0 ? 100 : 0, reachability: (callGraph.total_functions || 0) > 0 ? 100 : 80, secrets: secretsTotal >= 0 ? 100 : 0, malware: (malwareMetrics.packages_scanned || 0) > 0 ? 100 : 0, health: (healthMetrics.packages_analyzed || 0) > 0 ? 100 : 0, threat_intel: 100, sandbox: sandboxPackagesTested > 0 ? 100 : 0},
        threat_intel: {kev_hits: ((cveMetrics.with_exploits || {}).in_kev_catalog) || 0, exploit_db: ((cveMetrics.with_exploits || {}).public_exploits) || 0, metasploit: ((cveMetrics.with_exploits || {}).metasploit_modules) || 0},
        attack_surface: {phantom_dependencies: phantomDeps, shadow_imports: importMetrics.shadow_imports || 0, dead_dependencies: importMetrics.dead_dependencies || 0},
        package_health: {total_analyzed: healthMetrics.packages_analyzed || (m.libraries || {}).total_packages || 0, critical: healthMetrics.critical_health || 0, risky: healthMetrics.risky_health || 0, unmaintained: healthMetrics.unmaintained || 0},
        sandbox: {verdict: sandboxVerdict, capability_score: sandboxCapabilityScore, findings_count: sandboxFindings.length, critical: sandboxCritical, high: sandboxHigh, packages_tested: sandboxPackagesTested, findings: sandboxFindings},
        top_packages: topPkgs,
        issues: issues,
        raw_secrets: secretsList,
        cve_details: cveDetails.sort(function(a, b) { return a.severity === "critical" ? -1 : 1; })
    };
}

function updateMetadata(m) {
    m = m || {};
    var el = function(id, v) { var e = document.getElementById(id); if (e) e.textContent = v || "-"; };
    el("scanId", m.scan_id);
    el("scanTime", m.timestamp ? new Date(m.timestamp).toLocaleString() : "-");
    el("repository", m.repository);
}

function updateGitInfo(m) {
    var git = (m || {}).git;
    var row = document.getElementById("gitInfoRow");
    if (!git || (!git.branch && !git.commit_short)) { if (row) row.style.display = "none"; return; }
    if (row) row.style.display = "block";
    var el = function(id, v) { var e = document.getElementById(id); if (e) e.textContent = v || "-"; };
    el("gitBranch", git.branch);
    el("gitCommit", git.commit_short);
}

function renderExecutiveSummary(d) {
    var c = document.getElementById("executiveSummary");
    if (!c) return;
    var f = d.findings;
    var r = d.risk_assessment;
    var live = f.cves_reachable + f.secrets_live + f.malware_total;
    var safe = f.cves_eliminated;
    
    var summaryText = "";
    if (r.level === "CRITICAL") {
        summaryText = "<div style='background:#fef2f2;border-left:4px solid #dc2626;padding:15px;border-radius:8px;margin-bottom:15px;'><strong style='color:#dc2626;'>⚠️ CRITICAL RISK DETECTED</strong><p style='margin:10px 0 0 0;'>Your application has " + live + " exploitable vulnerabilities in reachable code paths. Immediate remediation is required.</p></div>";
    } else if (r.level === "HIGH") {
        summaryText = "<div style='background:#fff7ed;border-left:4px solid #f97316;padding:15px;border-radius:8px;margin-bottom:15px;'><strong style='color:#f97316;'>⚠️ HIGH RISK</strong><p style='margin:10px 0 0 0;'>Your application has " + live + " exploitable vulnerabilities. Prioritize remediation of critical and high severity issues.</p></div>";
    } else if (r.level === "MEDIUM") {
        summaryText = "<div style='background:#fefce8;border-left:4px solid #eab308;padding:15px;border-radius:8px;margin-bottom:15px;'><strong style='color:#ca8a04;'>⚡ MEDIUM RISK</strong><p style='margin:10px 0 0 0;'>Your application has " + live + " vulnerabilities in reachable code. Review and address based on priority.</p></div>";
    } else {
        summaryText = "<div style='background:#f0fdf4;border-left:4px solid #22c55e;padding:15px;border-radius:8px;margin-bottom:15px;'><strong style='color:#16a34a;'>✅ LOW RISK</strong><p style='margin:10px 0 0 0;'>Your application is in good security posture. " + safe + " CVEs are in unreachable code and can be safely deprioritized.</p></div>";
    }
    
    summaryText += "<div style='display:grid;grid-template-columns:repeat(4,1fr);gap:15px;text-align:center;'>";
    summaryText += "<div style='padding:15px;background:#f8fafc;border-radius:8px;'><div style='font-size:24px;font-weight:bold;'>" + f.cves_total + "</div><div style='font-size:12px;color:#64748b;'>Total CVEs</div></div>";
    summaryText += "<div style='padding:15px;background:" + (live > 0 ? "#fef2f2" : "#f0fdf4") + ";border-radius:8px;'><div style='font-size:24px;font-weight:bold;color:" + (live > 0 ? "#dc2626" : "#16a34a") + ";'>" + live + "</div><div style='font-size:12px;color:#64748b;'>Exploitable</div></div>";
    summaryText += "<div style='padding:15px;background:#f0fdf4;border-radius:8px;'><div style='font-size:24px;font-weight:bold;color:#16a34a;'>" + safe + "</div><div style='font-size:12px;color:#64748b;'>Safe (Unreachable)</div></div>";
    summaryText += "<div style='padding:15px;background:#f3e8ff;border-radius:8px;'><div style='font-size:24px;font-weight:bold;color:#7c3aed;'>" + d.workload_reduction.reduction_percentage + "%</div><div style='font-size:12px;color:#64748b;'>Work Reduced</div></div>";
    summaryText += "</div>";
    
    c.innerHTML = summaryText;
}

// Admin mode state - default to false (user view)
var isAdminMode = false;

function toggleAdminMode() {
    isAdminMode = !isAdminMode;
    var btn = document.getElementById('adminToggleBtn');
    if (btn) {
        btn.textContent = isAdminMode ? 'Switch to User View' : 'Switch to Admin View';
        btn.style.background = isAdminMode ? '#6366f1' : '#374151';
    }
    // Re-render all affected panels
    if (window.currentDashboardData) {
        renderRiskScore(window.currentDashboardData);
        renderScoringFormulas(window.currentDashboardData);
        renderSecretsDetails(window.currentDashboardData);
        renderCVEDetails(window.currentDashboardData);
    }
}

function renderRiskScore(d) {
    window.currentDashboardData = d;
    var c = document.getElementById("riskScoreContainer");
    if (!c) return;
    var r = d.risk_assessment || {};
    var riskLevel = r.level || "LOW";
    var riskScore = r.score || 0;
    
    // Get SLA based on risk level
    var slaText = {'CRITICAL': '24-48h', 'HIGH': '14 days', 'MEDIUM': '30 days', 'LOW': '90 days'}[riskLevel] || 'No SLA';
    
    // Risk level colors
    var levelConfig = {
        'CRITICAL': { color: '#dc2626', bg: 'linear-gradient(135deg, #dc2626 0%, #991b1b 100%)' },
        'HIGH': { color: '#f97316', bg: 'linear-gradient(135deg, #f97316 0%, #c2410c 100%)' },
        'MEDIUM': { color: '#eab308', bg: 'linear-gradient(135deg, #eab308 0%, #a16207 100%)' },
        'LOW': { color: '#22c55e', bg: 'linear-gradient(135deg, #22c55e 0%, #15803d 100%)' }
    };
    var config = levelConfig[riskLevel] || levelConfig['LOW'];
    
    // Threat intel
    var kevCount = r.kev_count || (d.threat_intel || {}).kev_hits || 0;
    var exploitCount = r.exploit_count || (d.threat_intel || {}).exploit_db || 0;
    var highEpss = r.high_epss || 0;
    
    // USER VIEW - Clean risk LEVEL display (no numeric score)
    var userView = '<div style="display:flex;gap:20px;align-items:stretch;">' +
        '<div style="background:' + config.bg + ';color:white;padding:30px 40px;border-radius:16px;text-align:center;min-width:200px;box-shadow:0 4px 20px rgba(0,0,0,0.3);">' +
        '<div style="font-size:42px;font-weight:800;letter-spacing:2px;">' + riskLevel + '</div>' +
        '<div style="font-size:13px;opacity:0.9;margin-top:10px;border-top:1px solid rgba(255,255,255,0.2);padding-top:10px;">SLA: ' + slaText + '</div>' +
        '<div style="font-size:11px;opacity:0.7;margin-top:12px;display:flex;align-items:center;justify-content:center;gap:6px;">' +
        '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>' +
        'Correlated Risk Score</div>' +
        '<div style="font-size:10px;opacity:0.5;">Based on reachable findings only</div>' +
        '</div>' +
        '<div style="flex:1;padding:20px;background:#1e293b;border-radius:12px;">' +
        '<div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:15px;">' +
        '<div style="background:#0f172a;padding:12px;border-radius:8px;border:1px solid #334155;">' +
        '<div style="font-size:10px;color:#64748b;text-transform:uppercase;">CISA KEV</div>' +
        '<div style="font-size:18px;font-weight:bold;color:' + (kevCount > 0 ? '#f97316' : '#22c55e') + ';">' + kevCount + ' <span style="font-size:11px;opacity:0.7;">actively exploited</span></div></div>' +
        '<div style="background:#0f172a;padding:12px;border-radius:8px;border:1px solid #334155;">' +
        '<div style="font-size:10px;color:#64748b;text-transform:uppercase;">EPSS >50%</div>' +
        '<div style="font-size:18px;font-weight:bold;color:' + (highEpss > 0 ? '#f97316' : '#22c55e') + ';">' + highEpss + ' <span style="font-size:11px;opacity:0.7;">high probability</span></div></div>' +
        '<div style="background:#0f172a;padding:12px;border-radius:8px;border:1px solid #334155;">' +
        '<div style="font-size:10px;color:#64748b;text-transform:uppercase;">Public Exploits</div>' +
        '<div style="font-size:18px;font-weight:bold;color:' + (exploitCount > 0 ? '#f97316' : '#22c55e') + ';">' + exploitCount + ' <span style="font-size:11px;opacity:0.7;">available</span></div></div>' +
        '<div style="background:#0f172a;padding:12px;border-radius:8px;border:1px solid #334155;">' +
        '<div style="font-size:10px;color:#64748b;text-transform:uppercase;">Amplifier</div>' +
        '<div style="font-size:18px;font-weight:bold;color:#6366f1;">' + (r.amplifier || 1.0).toFixed(1) + 'x</div></div></div>' +
        '<div style="background:#0f172a;border-radius:8px;padding:12px;border:1px solid #334155;">' +
        '<div style="font-size:11px;color:#64748b;"><span style="color:#f59e0b;">💡</span> This score reflects only <strong style="color:#f59e0b;">reachable vulnerabilities</strong> — issues in code paths that can actually be executed at runtime.</div></div>' +
        '<div style="margin-top:15px;"><div style="font-size:10px;color:#64748b;margin-bottom:6px;text-transform:uppercase;">Remediation SLA by Risk Level</div>' +
        '<div style="display:flex;gap:4px;">' +
        '<div style="flex:1;background:#dc2626;color:white;padding:8px;border-radius:6px;text-align:center;font-size:10px;' + (riskLevel === 'CRITICAL' ? 'box-shadow:0 0 10px #dc2626;' : 'opacity:0.4;') + '"><strong>CRITICAL</strong><br>24-48h</div>' +
        '<div style="flex:1;background:#f97316;color:white;padding:8px;border-radius:6px;text-align:center;font-size:10px;' + (riskLevel === 'HIGH' ? 'box-shadow:0 0 10px #f97316;' : 'opacity:0.4;') + '"><strong>HIGH</strong><br>14 days</div>' +
        '<div style="flex:1;background:#eab308;color:white;padding:8px;border-radius:6px;text-align:center;font-size:10px;' + (riskLevel === 'MEDIUM' ? 'box-shadow:0 0 10px #eab308;' : 'opacity:0.4;') + '"><strong>MEDIUM</strong><br>30 days</div>' +
        '<div style="flex:1;background:#22c55e;color:white;padding:8px;border-radius:6px;text-align:center;font-size:10px;' + (riskLevel === 'LOW' ? 'box-shadow:0 0 10px #22c55e;' : 'opacity:0.4;') + '"><strong>LOW</strong><br>90 days</div>' +
        '<div style="flex:1;background:#374151;color:white;padding:8px;border-radius:6px;text-align:center;font-size:10px;opacity:0.4;"><strong>MINIMAL</strong><br>No SLA</div>' +
        '</div></div></div></div>';
    
    // Calculate scores for admin view
    var s = d.severity_breakdown || {critical:{live:0,dead:0},high:{live:0,dead:0},medium:{live:0,dead:0},low:{live:0,dead:0}};
    var critScore = (s.critical ? s.critical.live : 0) * 250;
    var highScore = (s.high ? s.high.live : 0) * 100;
    var medScore = (s.medium ? s.medium.live : 0) * 40;
    var lowScore = (s.low ? s.low.live : 0) * 10;
    var unreachScore = ((s.critical ? s.critical.dead : 0) * 25) + ((s.high ? s.high.dead : 0) * 10) + ((s.medium ? s.medium.dead : 0) * 4);
    
    // ADMIN VIEW - Numeric score with breakdown
    var adminView = '<div style="display:flex;gap:20px;align-items:stretch;">' +
        '<div style="background:' + config.bg + ';color:white;padding:25px 35px;border-radius:16px;text-align:center;min-width:180px;box-shadow:0 4px 20px rgba(0,0,0,0.3);">' +
        '<div style="font-size:56px;font-weight:800;">' + riskScore + '</div>' +
        '<div style="font-size:18px;font-weight:600;margin-top:4px;letter-spacing:1px;">' + riskLevel + '</div>' +
        '<div style="font-size:12px;opacity:0.8;margin-top:8px;border-top:1px solid rgba(255,255,255,0.2);padding-top:8px;">SLA: ' + slaText + '</div>' +
        '<div style="font-size:11px;opacity:0.6;margin-top:12px;">Correlated Risk Score</div></div>' +
        '<div style="flex:1;padding:15px;background:#1e293b;border-radius:12px;">' +
        '<div style="font-size:13px;color:#94a3b8;margin-bottom:10px;font-weight:600;">Risk Score Breakdown (0-1000)</div>' +
        '<table style="width:100%;font-size:12px;color:#cbd5e1;">' +
        '<tr><td style="padding:4px 0;">Reachable CRITICAL CVEs</td><td style="text-align:right;">' + (s.critical ? s.critical.live : 0) + ' × 250</td><td style="text-align:right;font-weight:bold;color:#dc2626;">= ' + critScore + '</td></tr>' +
        '<tr><td style="padding:4px 0;">Reachable HIGH CVEs</td><td style="text-align:right;">' + (s.high ? s.high.live : 0) + ' × 100</td><td style="text-align:right;font-weight:bold;color:#f97316;">= ' + highScore + '</td></tr>' +
        '<tr><td style="padding:4px 0;">Reachable MEDIUM CVEs</td><td style="text-align:right;">' + (s.medium ? s.medium.live : 0) + ' × 40</td><td style="text-align:right;font-weight:bold;color:#eab308;">= ' + medScore + '</td></tr>' +
        '<tr><td style="padding:4px 0;">Reachable LOW CVEs</td><td style="text-align:right;">' + (s.low ? s.low.live : 0) + ' × 10</td><td style="text-align:right;font-weight:bold;color:#22c55e;">= ' + lowScore + '</td></tr>' +
        (kevCount > 0 ? '<tr style="color:#dc2626;"><td style="padding:4px 0;">CISA KEV Amplifier</td><td style="text-align:right;">' + kevCount + ' × 100</td><td style="text-align:right;font-weight:bold;">= ' + (kevCount*100) + '</td></tr>' : '') +
        '<tr style="color:#64748b;"><td style="padding:4px 0;">Unreachable (10% weight)</td><td></td><td style="text-align:right;">= ' + unreachScore + '</td></tr>' +
        '<tr style="border-top:2px solid #475569;"><td style="padding:8px 0;"><strong>TOTAL</strong></td><td></td><td style="text-align:right;font-weight:bold;font-size:14px;color:#6366f1;">' + riskScore + ' / 1000</td></tr>' +
        '</table>' +
        '<div style="margin-top:12px;display:flex;gap:4px;">' +
        '<div style="flex:1;background:#dc2626;color:white;padding:6px;border-radius:4px;text-align:center;font-size:9px;' + (riskLevel === 'CRITICAL' ? 'box-shadow:0 0 6px #dc2626;' : 'opacity:0.4;') + '">CRITICAL<br>24-48h</div>' +
        '<div style="flex:1;background:#f97316;color:white;padding:6px;border-radius:4px;text-align:center;font-size:9px;' + (riskLevel === 'HIGH' ? 'box-shadow:0 0 6px #f97316;' : 'opacity:0.4;') + '">HIGH<br>14d</div>' +
        '<div style="flex:1;background:#eab308;color:white;padding:6px;border-radius:4px;text-align:center;font-size:9px;' + (riskLevel === 'MEDIUM' ? 'box-shadow:0 0 6px #eab308;' : 'opacity:0.4;') + '">MEDIUM<br>30d</div>' +
        '<div style="flex:1;background:#22c55e;color:white;padding:6px;border-radius:4px;text-align:center;font-size:9px;' + (riskLevel === 'LOW' ? 'box-shadow:0 0 6px #22c55e;' : 'opacity:0.4;') + '">LOW<br>90d</div>' +
        '</div></div></div>';
    
    c.innerHTML = isAdminMode ? adminView : userView;
}

function updateKPICards(d) {
    var f = d.findings;
    var el = function(id, v) { var e = document.getElementById(id); if (e) e.textContent = v; };
    el("totalIssues", f.cves_total + f.secrets_total + f.malware_total + f.sandbox_total);
    el("liveIssues", f.cves_reachable + f.secrets_live + f.malware_total + f.sandbox_critical + f.sandbox_high);
    el("noFixIssues", f.cves_no_fix);
    el("eliminatedIssues", f.cves_eliminated);
    el("reductionPct", d.workload_reduction.reduction_percentage + "%");
}

function renderLanguageBreakdown(d) {
    var c = document.getElementById("languageBreakdown");
    if (!c) return;
    var ls = d.language_stats;
    var html = "<table style='width:100%;font-size:14px;'><tr style='background:#f8fafc;'><th style='padding:8px;text-align:left;'>Language</th><th style='padding:8px;text-align:right;'>CVEs</th><th style='padding:8px;text-align:right;'>Exploitable</th></tr>";
    Object.keys(ls).forEach(function(lang) {
        if (ls[lang].total > 0) {
            html += "<tr><td style='padding:8px;'>" + lang + "</td><td style='padding:8px;text-align:right;'>" + ls[lang].total + "</td><td style='padding:8px;text-align:right;color:" + (ls[lang].live > 0 ? "#dc2626" : "#16a34a") + ";'>" + ls[lang].live + "</td></tr>";
        }
    });
    html += "</table>";
    c.innerHTML = html;
}

function renderProjectBreakdown(d) {
    var c = document.getElementById("projectBreakdown");
    if (!c) return;
    var ps = d.project_stats;
    var projects = Object.keys(ps).sort(function(a, b) { return ps[b].live - ps[a].live; }).slice(0, 10);
    
    if (projects.length === 0) {
        c.innerHTML = "<p style='color:#888;'>No project data available</p>";
        return;
    }
    
    var html = "<table style='width:100%;font-size:14px;'><tr style='background:#f8fafc;'><th style='padding:8px;text-align:left;'>Project</th><th style='padding:8px;text-align:right;'>CVEs</th><th style='padding:8px;text-align:right;'>Critical</th><th style='padding:8px;text-align:right;'>High</th></tr>";
    projects.forEach(function(proj) {
        var p = ps[proj];
        html += "<tr><td style='padding:8px;'>" + proj + "</td><td style='padding:8px;text-align:right;'>" + p.total + "</td><td style='padding:8px;text-align:right;color:#dc2626;'>" + p.critical + "</td><td style='padding:8px;text-align:right;color:#f97316;'>" + p.high + "</td></tr>";
    });
    html += "</table>";
    c.innerHTML = html;
}

function renderSeverityChart(s) {
    var c = document.getElementById("severityChart");
    if (!c || typeof Plotly === "undefined") return;
    Plotly.newPlot(c, [
        {x: [s.critical.live, s.high.live, s.medium.live, s.low.live], y: ["Critical", "High", "Medium", "Low"], name: "Exploitable", type: "bar", orientation: "h", marker: {color: "#dc2626"}},
        {x: [s.critical.dead, s.high.dead, s.medium.dead, s.low.dead], y: ["Critical", "High", "Medium", "Low"], name: "Safe (Unreachable)", type: "bar", orientation: "h", marker: {color: "#22c55e"}}
    ], {barmode: "stack", height: 280, margin: {l: 70, r: 20, t: 10, b: 40}, legend: {orientation: "h", y: -0.15}}, {responsive: true});
}

function renderReductionChart(d) {
    var c = document.getElementById("reductionChart");
    if (!c || typeof Plotly === "undefined") return;
    var live = d.findings.cves_reachable;
    var safe = d.findings.cves_eliminated;
    if (live + safe === 0) { c.innerHTML = "<p style='text-align:center;color:#888;padding:40px;'>No CVE data</p>"; return; }
    Plotly.newPlot(c, [{values: [live, safe], labels: ["Exploitable", "Safe"], type: "pie", hole: 0.5, marker: {colors: ["#dc2626", "#22c55e"]}}], {height: 280, margin: {l: 20, r: 20, t: 10, b: 20}, annotations: [{text: d.workload_reduction.reduction_percentage + "%<br>Safe", showarrow: false, font: {size: 16}}]}, {responsive: true});
}

function renderRemediationGuidance(d) {
    var c = document.getElementById("remediationGuidance");
    if (!c) return;
    var s = d.severity_breakdown;
    var html = "<div style='display:grid;grid-template-columns:repeat(2,1fr);gap:20px;'>";
    
    if (s.critical.live > 0) {
        html += "<div style='background:#fef2f2;padding:15px;border-radius:8px;border-left:4px solid #dc2626;'><h4 style='color:#dc2626;margin:0 0 10px 0;'>🚨 CRITICAL (" + s.critical.live + " exploitable)</h4><p style='margin:0;font-size:13px;'>These CVEs are in code paths that can be reached by attackers. <strong>Immediate patching required.</strong></p><ul style='margin:10px 0 0 0;padding-left:20px;font-size:13px;'><li>Update affected packages to fixed versions</li><li>If no fix available, implement WAF rules or code-level mitigations</li><li>Consider removing unused functionality</li></ul></div>";
    }
    
    if (s.high.live > 0) {
        html += "<div style='background:#fff7ed;padding:15px;border-radius:8px;border-left:4px solid #f97316;'><h4 style='color:#ea580c;margin:0 0 10px 0;'>⚠️ HIGH (" + s.high.live + " exploitable)</h4><p style='margin:0;font-size:13px;'>High severity vulnerabilities in reachable code. <strong>Patch within 7 days.</strong></p><ul style='margin:10px 0 0 0;padding-left:20px;font-size:13px;'><li>Prioritize packages with known exploits (check CISA KEV)</li><li>Review affected code paths for additional hardening</li></ul></div>";
    }
    
    if (s.critical.dead + s.high.dead > 0) {
        html += "<div style='background:#f0fdf4;padding:15px;border-radius:8px;border-left:4px solid #22c55e;'><h4 style='color:#16a34a;margin:0 0 10px 0;'>✅ SAFE TO DEPRIORITIZE (" + (s.critical.dead + s.high.dead) + " unreachable)</h4><p style='margin:0;font-size:13px;'>These CVEs exist in code that cannot be reached from application entry points.</p><ul style='margin:10px 0 0 0;padding-left:20px;font-size:13px;'><li>Schedule for next maintenance window</li><li>Still recommended to update for defense-in-depth</li></ul></div>";
    }
    
    if (d.findings.phantom_deps > 0) {
        html += "<div style='background:#fef9c3;padding:15px;border-radius:8px;border-left:4px solid #ca8a04;'><h4 style='color:#ca8a04;margin:0 0 10px 0;'>👻 PHANTOM DEPENDENCIES (" + d.findings.phantom_deps + ")</h4><p style='margin:0;font-size:13px;'>Packages imported in code but not in manifest. These are <strong>invisible to vulnerability scanners.</strong></p><ul style='margin:10px 0 0 0;padding-left:20px;font-size:13px;'><li>Add missing packages to requirements.txt/package.json</li><li>Run scanner again after fixing manifests</li></ul></div>";
    }
    
    html += "</div>";
    c.innerHTML = html || "<p style='color:#16a34a;'>✅ No immediate remediation required. Your application is in good security posture.</p>";
}

function renderCVEDetails(d) {
    var c = document.getElementById("cveDetailsContainer");
    if (!c) return;
    var cves = d.cve_details.slice(0, 20);
    
    if (cves.length === 0) {
        c.innerHTML = "<p style='color:#888;'>No critical or high severity CVEs found.</p>";
        return;
    }
    
    var html = "";
    cves.forEach(function(cve) {
        var statusColor = cve.status === "live" ? "#dc2626" : "#22c55e";
        var statusText = cve.status === "live" ? "🔴 EXPLOITABLE" : "✅ SAFE (Unreachable)";
        var sevColor = cve.severity === "critical" ? "#dc2626" : "#f97316";
        
        html += "<div style='background:white;border:1px solid #e2e8f0;border-left:4px solid " + sevColor + ";padding:15px;margin-bottom:15px;border-radius:8px;'>";
        
        // Header
        html += "<div style='display:flex;justify-content:space-between;align-items:center;'>";
        html += "<div><strong style='font-size:16px;'>" + cve.id + "</strong> <span style='background:" + sevColor + ";color:white;padding:2px 8px;border-radius:4px;font-size:11px;margin-left:8px;'>" + cve.severity.toUpperCase() + "</span></div>";
        html += "<div style='color:" + statusColor + ";font-weight:600;'>" + statusText + "</div></div>";
        
        // CVE/GHSA ID Links - show both when available
        var idLinks = [];
        if (cve.cve_id) {
            idLinks.push("<a href='https://nvd.nist.gov/vuln/detail/" + cve.cve_id + "' target='_blank' style='color:#3b82f6;text-decoration:none;font-size:12px;'>📋 " + cve.cve_id + " (NVD)</a>");
        }
        if (cve.ghsa_id) {
            idLinks.push("<a href='https://github.com/advisories/" + cve.ghsa_id + "' target='_blank' style='color:#3b82f6;text-decoration:none;font-size:12px;'>🔒 " + cve.ghsa_id + " (GitHub)</a>");
        }
        if (idLinks.length === 0 && cve.id) {
            if (cve.id.startsWith('CVE-')) {
                idLinks.push("<a href='https://nvd.nist.gov/vuln/detail/" + cve.id + "' target='_blank' style='color:#3b82f6;text-decoration:none;font-size:12px;'>📋 " + cve.id + " (NVD)</a>");
            } else if (cve.id.startsWith('GHSA-')) {
                idLinks.push("<a href='https://github.com/advisories/" + cve.id + "' target='_blank' style='color:#3b82f6;text-decoration:none;font-size:12px;'>🔒 " + cve.id + " (GitHub)</a>");
            }
        }
        if (idLinks.length > 0) {
            html += "<div style='margin:6px 0;'>" + idLinks.join(" &nbsp;|&nbsp; ") + "</div>";
        }
        
        // Package info
        html += "<div style='margin:10px 0;font-size:14px;color:#475569;'><strong>" + cve.package + "</strong> v" + cve.version + (cve.cvss ? " | CVSS: " + cve.cvss : "") + (cve.kev ? " | <span style='color:#dc2626;'>⚠️ CISA KEV</span>" : "") + "</div>";
        
        // Description
        html += "<p style='margin:10px 0;font-size:13px;color:#64748b;'>" + (cve.description || "No description available").substring(0, 200) + "...</p>";
        
        // CALL PATH (if reachable)
        var callPath = cve.reachable_functions || cve.call_paths || [];
        if (cve.status === "live" && callPath.length > 0) {
            html += "<div style='background:#fef2f2;padding:12px;border-radius:6px;margin:10px 0;'>";
            html += "<strong style='color:#dc2626;font-size:12px;'>🔗 Reachability Path (Code that calls this vulnerable package):</strong>";
            html += "<div style='font-family:monospace;font-size:11px;margin-top:8px;color:#475569;background:#fff;padding:8px;border-radius:4px;max-height:100px;overflow-y:auto;'>";
            callPath.slice(0, 5).forEach(function(fn) {
                html += "<div style='padding:2px 0;'>→ " + fn + "</div>";
            });
            if (callPath.length > 5) {
                html += "<div style='color:#888;font-style:italic;'>... and " + (callPath.length - 5) + " more functions</div>";
            }
            html += "</div></div>";
        }
        
        // REMEDIATION GUIDANCE
        if (cve.remediation && cve.remediation.steps && cve.remediation.steps.length > 0) {
            html += "<div style='background:#f0fdf4;padding:12px;border-radius:6px;margin:10px 0;border:1px solid #bbf7d0;'>";
            html += "<strong style='color:#16a34a;font-size:12px;'>📋 Remediation Steps (from Grype):</strong>";
            html += "<ol style='margin:8px 0 0 20px;padding:0;font-size:12px;color:#475569;'>";
            cve.remediation.steps.forEach(function(step) {
                html += "<li style='margin:4px 0;'>" + step + "</li>";
            });
            html += "</ol>";
            if (cve.remediation.estimated_effort) {
                html += "<div style='margin-top:8px;font-size:11px;color:#64748b;'>⏱️ Estimated effort: <strong>" + cve.remediation.estimated_effort + "</strong></div>";
            }
            // Add reference links
            if (cve.remediation.references && cve.remediation.references.length > 0) {
                html += "<div style='margin-top:8px;font-size:11px;'>";
                html += "<strong>🔗 References:</strong> ";
                cve.remediation.references.forEach(function(ref, idx) {
                    if (idx > 0) html += " | ";
                    html += "<a href='" + ref + "' target='_blank' style='color:#3b82f6;text-decoration:underline;'>" + (ref.includes('nvd.nist') ? 'NVD' : (ref.includes('github.com/advisories') ? 'GHSA' : 'Link')) + "</a>";
                });
                html += "</div>";
            }
            html += "</div>";
        } else if (cve.fix_versions && cve.fix_versions.length > 0) {
            // Fallback: show simple fix version
            html += "<div style='background:#f0fdf4;padding:12px;border-radius:6px;margin:10px 0;'>";
            html += "<strong style='color:#16a34a;'>✅ Fix Available:</strong> Upgrade to <code style='background:#dcfce7;padding:2px 6px;border-radius:4px;'>" + cve.fix_versions.join(" or ") + "</code>";
            // Add CVE link even for simple case
            var cveLink = cve.id.startsWith('CVE-') ? 'https://nvd.nist.gov/vuln/detail/' + cve.id : (cve.id.startsWith('GHSA-') ? 'https://github.com/advisories/' + cve.id : null);
            if (cveLink) {
                html += " <a href='" + cveLink + "' target='_blank' style='color:#3b82f6;font-size:11px;'>[View Advisory]</a>";
            }
            html += "</div>";
        } else {
            html += "<div style='background:#fef9c3;padding:12px;border-radius:6px;margin:10px 0;'>";
            html += "<strong style='color:#ca8a04;'>⚠️ No Fix Available:</strong> Implement compensating controls or consider removing dependency if unused.";
            // Add CVE link for investigation
            var cveLink = cve.id.startsWith('CVE-') ? 'https://nvd.nist.gov/vuln/detail/' + cve.id : (cve.id.startsWith('GHSA-') ? 'https://github.com/advisories/' + cve.id : null);
            if (cveLink) {
                html += " <a href='" + cveLink + "' target='_blank' style='color:#3b82f6;font-size:11px;'>[Research Options]</a>";
            }
            html += "</div>";
        }
        
        html += "</div>";
    });
    
    c.innerHTML = html;
}

function renderUpgradeRecommendations(d) {
    var c = document.getElementById("upgradeRecommendations");
    if (!c) return;
    
    var pkgsNeedingUpgrade = d.top_packages.filter(function(p) { return p.fix_versions && p.fix_versions.length > 0; }).slice(0, 15);
    
    if (pkgsNeedingUpgrade.length === 0) {
        c.innerHTML = "<p style='color:#888;'>No package upgrades recommended at this time.</p>";
        return;
    }
    
    var html = "<table style='width:100%;border-collapse:collapse;'><thead><tr style='background:#f8fafc;'><th style='padding:12px;text-align:left;border-bottom:2px solid #e2e8f0;'>Package</th><th style='padding:12px;text-align:left;border-bottom:2px solid #e2e8f0;'>Current</th><th style='padding:12px;text-align:left;border-bottom:2px solid #e2e8f0;'>Recommended</th><th style='padding:12px;text-align:center;border-bottom:2px solid #e2e8f0;'>CVEs Fixed</th><th style='padding:12px;text-align:left;border-bottom:2px solid #e2e8f0;'>Language</th></tr></thead><tbody>";
    
    pkgsNeedingUpgrade.forEach(function(p) {
        html += "<tr><td style='padding:12px;border-bottom:1px solid #e2e8f0;'><strong>" + p.name + "</strong></td>";
        html += "<td style='padding:12px;border-bottom:1px solid #e2e8f0;color:#dc2626;'>" + p.version + "</td>";
        html += "<td style='padding:12px;border-bottom:1px solid #e2e8f0;color:#16a34a;font-weight:600;'>" + (p.fix_versions[0] || "Latest") + "</td>";
        html += "<td style='padding:12px;border-bottom:1px solid #e2e8f0;text-align:center;'>" + p.cves_total + "</td>";
        html += "<td style='padding:12px;border-bottom:1px solid #e2e8f0;'>" + p.language + "</td></tr>";
    });
    
    html += "</tbody></table>";
    c.innerHTML = html;
}

function renderCoverage(cov) {
    var c = document.getElementById("coverageContainer");
    if (!c) return;
    var items = [
        {name: "SBOM Generation", value: cov.sbom},
        {name: "CVE Scanning", value: cov.cve_scanning},
        {name: "Reachability Analysis", value: cov.reachability},
        {name: "Secrets Detection", value: cov.secrets},
        {name: "Malware Detection", value: cov.malware},
        {name: "Behavioral Sandbox", value: cov.sandbox || 0},
        {name: "Health Analysis", value: cov.health},
        {name: "Threat Intelligence", value: cov.threat_intel}
    ];
    var html = "";
    items.forEach(function(item) {
        html += "<div style='margin-bottom:12px;'><div style='display:flex;justify-content:space-between;margin-bottom:4px;font-size:14px;'><span>" + item.name + "</span><span>" + item.value + "%</span></div><div style='height:8px;background:#e2e8f0;border-radius:4px;overflow:hidden;'><div style='height:100%;width:" + item.value + "%;background:linear-gradient(90deg,#6366f1,#8b5cf6);border-radius:4px;'></div></div></div>";
    });
    c.innerHTML = html;
}

function renderThreatIntel(t) {
    var c = document.getElementById("threatIntelMetrics");
    if (!c) return;
    c.innerHTML = "<div style='display:grid;grid-template-columns:repeat(3,1fr);gap:15px;text-align:center;'>" +
        "<div style='background:#fef2f2;padding:15px;border-radius:8px;'><div style='font-size:28px;font-weight:bold;color:#dc2626;'>" + (t.kev_hits || 0) + "</div><div style='font-size:12px;'>CISA KEV</div><div style='font-size:10px;color:#888;'>Actively Exploited</div></div>" +
        "<div style='background:#fef9c3;padding:15px;border-radius:8px;'><div style='font-size:28px;font-weight:bold;color:#ca8a04;'>" + (t.exploit_db || 0) + "</div><div style='font-size:12px;'>Exploit-DB</div><div style='font-size:10px;color:#888;'>Public Exploits</div></div>" +
        "<div style='background:#f3e8ff;padding:15px;border-radius:8px;'><div style='font-size:28px;font-weight:bold;color:#7c3aed;'>" + (t.metasploit || 0) + "</div><div style='font-size:12px;'>Metasploit</div><div style='font-size:10px;color:#888;'>Framework Modules</div></div></div>";
}

function renderAttackSurface(s) {
    var c = document.getElementById("attackSurfaceMetrics");
    if (!c) return;
    c.innerHTML = "<div style='display:grid;grid-template-columns:repeat(3,1fr);gap:15px;text-align:center;'>" +
        "<div style='background:" + (s.phantom_dependencies > 0 ? "#fef2f2" : "#f0fdf4") + ";padding:15px;border-radius:8px;'><div style='font-size:28px;font-weight:bold;color:" + (s.phantom_dependencies > 0 ? "#dc2626" : "#16a34a") + ";'>" + (s.phantom_dependencies || 0) + "</div><div style='font-size:12px;'>Phantom Deps</div><div style='font-size:10px;color:#888;'>Hidden from SCA</div></div>" +
        "<div style='background:#fef9c3;padding:15px;border-radius:8px;'><div style='font-size:28px;font-weight:bold;color:#ca8a04;'>" + (s.shadow_imports || 0) + "</div><div style='font-size:12px;'>Shadow Imports</div></div>" +
        "<div style='background:#f0fdf4;padding:15px;border-radius:8px;'><div style='font-size:28px;font-weight:bold;color:#16a34a;'>" + (s.dead_dependencies || 0) + "</div><div style='font-size:12px;'>Dead Deps</div></div></div>";
}

function renderSandboxPanel(sandbox) {
    var c = document.getElementById("sandboxMetrics");
    if (!c) {
        // Try to find or create a container
        var parent = document.getElementById("attackSurfaceMetrics");
        if (parent && parent.parentNode) {
            var newSection = document.createElement("div");
            newSection.id = "sandboxSection";
            newSection.innerHTML = '<h3 style="margin:20px 0 10px 0;font-size:16px;font-weight:600;">🔒 Behavioral Sandbox Analysis</h3><div id="sandboxMetrics"></div>';
            parent.parentNode.insertBefore(newSection, parent.parentNode.querySelector("h3:last-of-type") || null);
            c = document.getElementById("sandboxMetrics");
        }
        if (!c) return;
    }
    
    sandbox = sandbox || {};
    var verdict = sandbox.verdict || "NOT_RUN";
    var capScore = sandbox.capability_score !== undefined ? sandbox.capability_score : 1.0;
    var findings = sandbox.findings_count || 0;
    var critical = sandbox.critical || 0;
    var high = sandbox.high || 0;
    var pkgsTested = sandbox.packages_tested || 0;
    
    // Determine colors based on verdict
    var verdictColor, verdictBg, verdictIcon;
    switch(verdict) {
        case "CRITICAL":
            verdictColor = "#dc2626"; verdictBg = "#fef2f2"; verdictIcon = "🚨"; break;
        case "WARNING":
            verdictColor = "#ca8a04"; verdictBg = "#fef9c3"; verdictIcon = "⚠️"; break;
        case "CLEAN":
            verdictColor = "#16a34a"; verdictBg = "#f0fdf4"; verdictIcon = "✅"; break;
        case "NOT_RUN":
        default:
            verdictColor = "#6b7280"; verdictBg = "#f3f4f6"; verdictIcon = "⏸️"; break;
    }
    
    var capScoreColor = capScore >= 0.8 ? "#16a34a" : (capScore >= 0.5 ? "#ca8a04" : "#dc2626");
    
    c.innerHTML = "<div style='display:grid;grid-template-columns:repeat(4,1fr);gap:15px;text-align:center;'>" +
        "<div style='background:" + verdictBg + ";padding:15px;border-radius:8px;'><div style='font-size:24px;'>" + verdictIcon + "</div><div style='font-size:18px;font-weight:bold;color:" + verdictColor + ";'>" + verdict + "</div><div style='font-size:12px;'>Verdict</div></div>" +
        "<div style='background:#f3f4f6;padding:15px;border-radius:8px;'><div style='font-size:28px;font-weight:bold;color:" + capScoreColor + ";'>" + (capScore * 100).toFixed(0) + "%</div><div style='font-size:12px;'>Capability Score</div><div style='font-size:10px;color:#888;'>Install safety</div></div>" +
        "<div style='background:" + (critical > 0 ? "#fef2f2" : "#f3f4f6") + ";padding:15px;border-radius:8px;'><div style='font-size:28px;font-weight:bold;color:" + (critical > 0 ? "#dc2626" : "#6b7280") + ";'>" + critical + "</div><div style='font-size:12px;'>Critical Findings</div><div style='font-size:10px;color:#888;'>Network/Creds</div></div>" +
        "<div style='background:" + (high > 0 ? "#fef9c3" : "#f3f4f6") + ";padding:15px;border-radius:8px;'><div style='font-size:28px;font-weight:bold;color:" + (high > 0 ? "#ca8a04" : "#6b7280") + ";'>" + high + "</div><div style='font-size:12px;'>High Findings</div><div style='font-size:10px;color:#888;'>Suspicious</div></div>" +
        "</div>";
    
    // Add findings details if any
    if (findings > 0 && sandbox.findings && sandbox.findings.length > 0) {
        var findingsHtml = "<div style='margin-top:15px;'><strong>Behavioral Findings:</strong><ul style='margin:10px 0;padding-left:20px;'>";
        sandbox.findings.slice(0, 5).forEach(function(f) {
            var sevColor = f.severity === "CRITICAL" ? "#dc2626" : (f.severity === "HIGH" ? "#ca8a04" : "#6b7280");
            findingsHtml += "<li style='margin:5px 0;'><span style='color:" + sevColor + ";font-weight:bold;'>[" + f.severity + "]</span> " + f.rule + ": " + (f.description || "") + "</li>";
        });
        if (sandbox.findings.length > 5) {
            findingsHtml += "<li style='color:#888;'>... and " + (sandbox.findings.length - 5) + " more</li>";
        }
        findingsHtml += "</ul></div>";
        c.innerHTML += findingsHtml;
    }
}

function renderScoringFormulas(d) {
    var c = document.getElementById("scoringFormulas");
    if (!c) return;
    
    // Hide scoring formulas in user mode
    if (!isAdminMode) {
        c.innerHTML = '<div style="padding:20px;text-align:center;color:#64748b;"><p>Switch to Admin View to see detailed scoring formulas</p></div>';
        return;
    }
    
    var metrics = d.totals || {};
    var summary = d.summary || {};
    var risk = summary.overall_risk || {};
    
    // ═══════════════════════════════════════════════════════════════════════
    // READ FROM calculation_detail - the single source of truth
    // ═══════════════════════════════════════════════════════════════════════
    var calc_detail = risk.calculation_detail || {};
    var amplification = risk.amplification || {};
    var step_by_step = calc_detail.step_by_step || [];
    var base_total = calc_detail.base_total || amplification.base_score || 0;
    var amplifier = calc_detail.amplifier_applied || amplification.amplifier || 1.0;
    var amplifier_factors = calc_detail.amplifier_factors || amplification.amplifier_factors || [];
    var amplified_total = calc_detail.amplified_total || amplification.amplified_score || 0;
    var final_score = calc_detail.final_score || risk.risk_score || 0;
    var was_capped = calc_detail.was_capped || false;
    var risk_level = risk.risk_level || 'N/A';
    
    var html = '';
    
    // Risk Score Formula
    html += '<div style="margin-bottom:20px;">';
    html += '<h4 style="color:#6366f1; margin-bottom:10px;">🎯 Overall Risk Score (0-1000)</h4>';
    html += '<div style="background:#f8fafc; padding:15px; border-radius:8px; font-family:monospace; font-size:12px;">';
    html += '<div style="margin-bottom:10px;"><strong>Formula:</strong> BASE_SCORE × AMPLIFIER (capped at 1000)</div>';
    
    // Step-by-step breakdown from JSON
    html += '<table style="width:100%; border-collapse:collapse;">';
    
    var currentCategory = '';
    var categoryColors = {
        'CVE-001': '#dc2626',
        'THREAT-001': '#6366f1',
        'THREAT-002': '#6366f1',
        'CWE-001': '#8b5cf6',
        'SECRET-001': '#f59e0b',
        'MAL-001': '#dc2626',
        'MAL-002': '#dc2626',
        'MAL-003': '#dc2626',
        'SUPPLY-001': '#059669',
        'SUPPLY-002': '#059669',
        'SUPPLY-003': '#059669',
        'SUPPLY-004': '#059669',
        'CORR-001': '#3b82f6'
    };
    
    var categoryNames = {
        'CVE-001': 'CVE Severity (Reachable Only)',
        'THREAT-001': 'Threat Intelligence (Additive)',
        'THREAT-002': 'Threat Intelligence (Additive)',
        'CWE-001': 'CWE/SAST Findings',
        'SECRET-001': 'Secrets Detection',
        'MAL-001': 'Malware Detection',
        'MAL-002': 'Malware Detection',
        'MAL-003': 'Malware Detection',
        'SUPPLY-001': 'Supply Chain Analysis',
        'SUPPLY-002': 'Supply Chain Analysis',
        'SUPPLY-003': 'Supply Chain Analysis',
        'SUPPLY-004': 'Supply Chain Analysis',
        'CORR-001': 'Correlation Engine'
    };
    
    var printedCategories = {};
    
    for (var i = 0; i < step_by_step.length; i++) {
        var step = step_by_step[i];
        var policy = step.policy || '';
        var factor = step.factor || '';
        var count = step.count || 0;
        var pts = step.points_each;
        var subtotal = step.subtotal;
        var capped = step.capped || false;
        var triage = step.requires_triage || false;
        
        // Skip zero entries
        if (subtotal === 0 && count === 0) continue;
        
        // Print category header if new
        var catName = categoryNames[policy];
        if (catName && !printedCategories[catName]) {
            var bg = policy.startsWith('MAL') ? '#fef2f2' : '#f1f5f9';
            html += '<tr style="background:' + bg + ';"><td colspan="3" style="padding:6px;font-weight:bold;">' + catName + '</td></tr>';
            printedCategories[catName] = true;
        }
        
        // Format the row
        var color = categoryColors[policy] || '#6366f1';
        var subtotalStr = (subtotal === 'INSTANT MAX' || (typeof pts === 'string' && pts.includes('1000'))) 
            ? '<span style="color:#dc2626;font-weight:bold;">= 1000 (MAX)</span>' 
            : '= ' + subtotal;
        var ptsStr = (typeof pts === 'number') ? count + ' × ' + pts : (count + ' ' + (pts || ''));
        var triageFlag = triage ? ' <span style="color:#f59e0b;">⚠</span>' : '';
        
        html += '<tr style="border-bottom:1px solid #e2e8f0;">';
        html += '<td style="padding:4px;">' + factor + triageFlag + '</td>';
        html += '<td style="padding:4px;text-align:right;">' + ptsStr + '</td>';
        html += '<td style="padding:4px;text-align:right;color:' + color + ';">' + subtotalStr + '</td>';
        html += '</tr>';
    }
    
    // Base total
    html += '<tr style="background:#e5e7eb;"><td colspan="2" style="padding:6px;font-weight:bold;">BASE TOTAL</td><td style="padding:6px;text-align:right;font-weight:bold;">' + base_total + '</td></tr>';
    html += '</table>';
    
    // Amplifiers section
    html += '<div style="margin-top:15px; padding:10px; background:#eff6ff; border-radius:6px;">';
    html += '<strong style="color:#1e40af;">⚡ Threat Intelligence Amplifiers:</strong>';
    if (amplifier_factors && amplifier_factors.length > 0) {
        html += '<ul style="margin:8px 0 0 20px; padding:0;">';
        for (var j = 0; j < amplifier_factors.length; j++) {
            html += '<li style="color:#1e40af;">' + amplifier_factors[j] + '</li>';
        }
        html += '</ul>';
        html += '<div style="margin-top:8px; font-weight:bold; color:#1e40af;">Combined Amplifier: ' + amplifier.toFixed(2) + '× (max 3.0×)</div>';
    } else {
        html += '<div style="margin-top:4px; color:#6b7280;">No amplifiers triggered (1.0×)</div>';
    }
    html += '</div>';
    
    // Final calculation
    html += '<div style="margin-top:15px; padding:12px; background:#dcfce7; border-radius:6px; text-align:center;">';
    html += '<strong style="font-size:14px;">FINAL SCORE: </strong>';
    html += '<span style="font-size:18px; font-weight:bold;">' + base_total + ' × ' + amplifier.toFixed(2) + ' = ' + amplified_total + '</span>';
    if (was_capped) {
        html += ' → <span style="color:#dc2626; font-weight:bold;">CAPPED AT 1000</span>';
    }
    html += '<br/><span style="font-size:24px; font-weight:bold; color:' + getRiskColor(risk_level) + ';">' + final_score + '/1000 (' + risk_level + ')</span>';
    html += '</div>';
    
    html += '</div></div>';
    
    // Category 7: Correlation
    html += '<tr style="background:#f1f5f9;"><td colspan="3" style="padding:6px;font-weight:bold;">Correlation Engine</td></tr>';
    html += '<tr style="border-bottom:1px solid #e2e8f0;"><td style="padding:4px;">Composite threats (attack chains)</td><td style="padding:4px;text-align:right;">min(' + composite_threats + ' × 10, 100)</td><td style="padding:4px;text-align:right;color:#6366f1;">= ' + composite_pts + '</td></tr>';
    
    // Total
    html += '<tr style="background:#e0e7ff;"><td style="padding:8px;"><strong>TOTAL (capped at 1000)</strong></td><td style="padding:8px;"></td><td style="padding:8px;text-align:right;"><strong style="color:#4f46e5;font-size:14px;">' + risk_score + ' / 1000</strong></td></tr>';
    html += '</table>';
    html += '<div style="margin-top:12px;"><strong>Risk Level:</strong> <span style="padding:4px 12px; border-radius:4px; background:' + getRiskColor(risk_level) + '; color:white; font-weight:bold;">' + risk_level + '</span></div>';
    html += '</div></div>';
    
    // CVE Verdict Formula
    html += '<div style="margin-bottom:20px;">';
    html += '<h4 style="color:#6366f1; margin-bottom:10px;">⚖️ CVE Verdict Algorithm</h4>';
    html += '<div style="background:#f8fafc; padding:15px; border-radius:8px; font-size:12px;">';
    html += '<table style="width:100%; border-collapse:collapse;">';
    html += '<tr style="background:#fef2f2;border-bottom:1px solid #fecaca;"><td style="padding:8px;"><strong>🔴 FIX_IMMEDIATELY</strong></td><td style="padding:8px;">Reachable + (CRITICAL or KEV or EPSS>50%)</td></tr>';
    html += '<tr style="background:#fff7ed;border-bottom:1px solid #fed7aa;"><td style="padding:8px;"><strong>🟠 FIX_SOON</strong></td><td style="padding:8px;">Reachable + (HIGH or public exploit)</td></tr>';
    html += '<tr style="background:#fefce8;border-bottom:1px solid #fef08a;"><td style="padding:8px;"><strong>🟡 MONITOR</strong></td><td style="padding:8px;">Reachable + MEDIUM, or Unreachable + CRITICAL</td></tr>';
    html += '<tr style="background:#f0fdf4;"><td style="padding:8px;"><strong>🟢 DEPRIORITIZE</strong></td><td style="padding:8px;">Unreachable + (HIGH/MEDIUM/LOW)</td></tr>';
    html += '</table></div></div>';
    
    // Workload Reduction Formula
    var total_cves = cves_reachable + cves_unreachable;
    var reduction_pct = total_cves > 0 ? Math.round((cves_unreachable / total_cves) * 100) : 0;
    var hours_saved = cves_unreachable * 10.5;
    var cost_saved = hours_saved * 100;
    
    html += '<div style="margin-bottom:20px;">';
    html += '<h4 style="color:#6366f1; margin-bottom:10px;">💰 Workload Reduction & ROI</h4>';
    html += '<div style="background:#f8fafc; padding:15px; border-radius:8px; font-size:12px;">';
    html += '<table style="width:100%; border-collapse:collapse;">';
    html += '<tr style="border-bottom:1px solid #e2e8f0;"><td style="padding:6px;"><strong>Reduction %</strong></td><td style="padding:6px;">(Unreachable CVEs / Total CVEs) × 100</td><td style="padding:6px;text-align:right;">(' + cves_unreachable + ' / ' + total_cves + ') × 100 = <strong>' + reduction_pct + '%</strong></td></tr>';
    html += '<tr style="border-bottom:1px solid #e2e8f0;"><td style="padding:6px;"><strong>Hours Saved</strong></td><td style="padding:6px;">Unreachable CVEs × 10.5 hours/CVE</td><td style="padding:6px;text-align:right;">' + cves_unreachable + ' × 10.5 = <strong>' + hours_saved.toFixed(1) + ' hours</strong></td></tr>';
    html += '<tr style="background:#dcfce7;"><td style="padding:6px;"><strong>Cost Savings</strong></td><td style="padding:6px;">Hours Saved × $100/hour</td><td style="padding:6px;text-align:right;">' + hours_saved.toFixed(1) + ' × $100 = <strong>$' + cost_saved.toLocaleString() + '</strong></td></tr>';
    html += '</table>';
    html += '<div style="margin-top:10px; font-size:11px; color:#64748b;">📊 Industry benchmark: 10.5 hours average remediation time per CVE (Ponemon Institute)</div>';
    html += '</div></div>';
    
    // Secret Severity Formula
    html += '<div>';
    html += '<h4 style="color:#6366f1; margin-bottom:10px;">🔐 Secret Severity Classification</h4>';
    html += '<div style="background:#f8fafc; padding:15px; border-radius:8px; font-size:12px;">';
    html += '<table style="width:100%; border-collapse:collapse;">';
    html += '<tr style="background:#fef2f2;border-bottom:1px solid #e2e8f0;"><td style="padding:6px;"><strong>CRITICAL</strong></td><td style="padding:6px;">AWS keys, GCP credentials, private keys, database passwords</td></tr>';
    html += '<tr style="background:#fff7ed;border-bottom:1px solid #e2e8f0;"><td style="padding:6px;"><strong>HIGH</strong></td><td style="padding:6px;">API tokens, OAuth secrets, JWT secrets</td></tr>';
    html += '<tr style="background:#fefce8;border-bottom:1px solid #e2e8f0;"><td style="padding:6px;"><strong>MEDIUM</strong></td><td style="padding:6px;">Generic passwords, internal tokens</td></tr>';
    html += '<tr style="background:#f0fdf4;"><td style="padding:6px;"><strong>LOW</strong></td><td style="padding:6px;">Test credentials, example keys</td></tr>';
    html += '</table></div></div>';
    
    c.innerHTML = html;
}

function getRiskColor(level) {
    var colors = {
        'CRITICAL': '#dc2626',
        'HIGH': '#f97316', 
        'MEDIUM': '#eab308',
        'LOW': '#22c55e',
        'MINIMAL': '#16a34a'
    };
    return colors[level] || '#64748b';
}

function renderCapabilityMatrix(d) {
    var c = document.getElementById("capabilityMatrix");
    if (!c) return;
    
    // Extract data from dashboard
    var metrics = d.totals || {};
    var summary = d.summary || {};
    var findings = d.findings || {};
    var threatIntel = summary.by_exploit_intelligence || {};
    var attackSurface = findings.attack_surface || {};
    var verdicts = summary.by_verdict || {};
    
    // Calculate derived metrics
    var cves_total = metrics.cves_total || 0;
    var cves_reachable = metrics.cves_reachable || 0;
    var cves_unreachable = metrics.cves_unreachable || 0;
    var secrets_total = metrics.secrets_total || 0;
    var secrets_reachable = metrics.secrets_reachable || 0;
    var malware_found = metrics.malware_packages || 0;
    var packages_total = metrics.total_packages || 0;
    var health_analyzed = metrics.health_packages_analyzed || 0;
    var health_critical = metrics.health_critical || 0;
    var health_risky = metrics.health_risky || 0;
    var reduction_pct = cves_total > 0 ? Math.round((cves_unreachable / cves_total) * 100) : 0;
    
    // Build HTML table
    var html = '<table style="width:100%; font-size:12px; border-collapse:collapse;">';
    html += '<thead><tr style="background:#f1f5f9;"><th style="padding:8px;text-align:left;">ID</th><th style="padding:8px;text-align:left;">Capability</th><th style="padding:8px;text-align:center;">Status</th><th style="padding:8px;text-align:left;">Metrics</th></tr></thead>';
    html += '<tbody>';
    
    // SBOM
    html += capRow("SBOM-001", "Package Discovery", true, packages_total + " packages");
    html += capRow("SBOM-002", "Language Detection", true, (d.languages ? d.languages.length : "N/A") + " languages");
    
    // VULN
    html += capRow("VULN-001", "CVE Scanning", true, cves_total + " CVEs found");
    html += capRow("VULN-003", "Severity Breakdown", true, "Crit:" + (metrics.cves_critical || 0) + " High:" + (metrics.cves_high || 0));
    
    // SEC
    html += capRow("SEC-001", "Secret Scanning", true, secrets_total + " secrets");
    html += capRow("SEC-004", "Secret Verification", d.trufflehog_executed, d.trufflehog_executed ? "TruffleHog" : "Not executed");
    html += capRow("SEC-007", "Secret Reachability", true, secrets_reachable + " reachable");
    
    // SAST
    var sast = d.sast_findings || {};
    var sast_total = (sast.sql_injection || 0) + (sast.xss || 0) + (sast.command_injection || 0);
    html += capRow("SAST-001", "SQL Injection", true, (sast.sql_injection || 0) + " findings");
    html += capRow("SAST-003", "XSS Detection", true, (sast.xss || 0) + " findings");
    
    // MAL
    html += capRow("MAL-001", "Package Malware Scan", true, (metrics.malware_packages_scanned || packages_total) + " scanned, " + malware_found + " found");
    html += capRow("MAL-004", "Code Pattern Analysis", true, (metrics.semgrep_patterns || 0) + " patterns");
    
    // SANDBOX - Behavioral Analysis
    var sandbox = d.sandbox || {};
    var sandboxVerdict = sandbox.verdict || "NOT_RUN";
    var sandboxEnabled = sandboxVerdict !== "NOT_RUN";
    html += capRow("SANDBOX-001", "Behavioral Sandbox", sandboxEnabled, sandboxEnabled ? sandbox.packages_tested + " packages tested" : "Not enabled");
    html += capRow("SANDBOX-002", "Install-Time Analysis", sandboxEnabled, sandboxEnabled ? "Verdict: " + sandboxVerdict : "N/A");
    html += capRow("SANDBOX-003", "Network Detection", sandboxEnabled, sandboxEnabled ? (sandbox.findings || []).filter(function(f) { return f.rule === "NETWORK_DURING_INSTALL"; }).length + " blocked" : "N/A");
    html += capRow("SANDBOX-004", "Credential Access", sandboxEnabled, sandboxEnabled ? (sandbox.findings || []).filter(function(f) { return f.rule === "CREDENTIAL_ACCESS"; }).length + " detected" : "N/A");
    html += capRow("SANDBOX-005", "Capability Score", sandboxEnabled, sandboxEnabled ? (sandbox.capability_score * 100).toFixed(0) + "%" : "N/A");
    
    // REACH
    html += capRow("REACH-001", "Call Graph", true, (metrics.functions_total || 0) + " functions");
    html += capRow("REACH-004", "CVE Reachability", true, cves_reachable + " reachable, " + cves_unreachable + " unreachable");
    
    // THREAT
    html += capRow("THREAT-001", "CISA KEV", true, (threatIntel.in_kev_catalog || 0) + " in catalog");
    html += capRow("THREAT-002", "EPSS Scores", true, (threatIntel.high_epss || 0) + " high risk");
    html += capRow("THREAT-003", "Exploit-DB", true, (threatIntel.public_exploits || 0) + " public exploits");
    html += capRow("THREAT-004", "Metasploit", true, (threatIntel.metasploit_modules || 0) + " modules");
    
    // ATK
    html += capRow("ATK-001", "Phantom Dependencies", true, (attackSurface.phantom_dependencies || {}).count || 0);
    html += capRow("ATK-002", "Shadow Imports", true, (attackSurface.shadow_imports || {}).count || 0);
    html += capRow("ATK-003", "Dead Dependencies", true, (attackSurface.dead_dependencies || {}).count || 0);
    
    // SUPPLY
    var supply = d.supply_chain || {};
    html += capRow("SUPPLY-001", "Provenance Check", true, (supply.provenance_checked || 0) + " checked");
    
    // HLTH
    html += capRow("HLTH-001", "Maintenance Status", true, health_analyzed + " analyzed");
    html += capRow("HLTH-007", "Health Scores", true, "Crit:" + health_critical + " Risky:" + health_risky);
    
    // VRD
    html += capRow("VRD-001", "CVE Verdicts", true, "FIX_NOW:" + (verdicts.FIX_IMMEDIATELY || 0) + " FIX_SOON:" + (verdicts.FIX_SOON || 0));
    html += capRow("VRD-005", "Workload Reduction", true, reduction_pct + "% reduction (" + cves_unreachable + " eliminated)");
    
    // CORR
    html += capRow("CORR-001", "Multi-Signal Fusion", true, cves_total + " CVEs + " + secrets_total + " secrets correlated");
    
    // RISK
    var risk = summary.overall_risk || {};
    html += capRow("RISK-001", "Risk Score", true, (risk.risk_score || 0) + "/1000");
    html += capRow("RISK-002", "Risk Level", true, risk.risk_level || "N/A");
    
    // RPT
    html += capRow("RPT-001", "JSON Report", true, "reachable-report.json");
    html += capRow("RPT-002", "Dashboard", true, "dashboard.html");
    
    html += '</tbody></table>';
    html += '<p style="margin-top:10px;font-size:11px;color:#64748b;">✓ = Executed | ○ = Not executed | Total: 78 capabilities across 14 domains</p>';
    
    c.innerHTML = html;
}

function capRow(id, name, executed, metric) {
    var status = executed ? '<span style="color:#16a34a;">✓</span>' : '<span style="color:#9ca3af;">○</span>';
    var bg = executed ? '' : 'background:#f9fafb;';
    return '<tr style="border-bottom:1px solid #e2e8f0;' + bg + '"><td style="padding:6px 8px;font-family:monospace;font-size:11px;color:#6366f1;">' + id + '</td><td style="padding:6px 8px;">' + name + '</td><td style="padding:6px 8px;text-align:center;">' + status + '</td><td style="padding:6px 8px;color:#64748b;">' + metric + '</td></tr>';
}

function renderPackageHealth(h) {
    var c = document.getElementById("packageHealthChart");
    if (!c) return;
    var total = h.total_analyzed || 0;
    if (total === 0) { c.innerHTML = "<p style='color:#888;text-align:center;'>No package health data</p>"; return; }
    var healthy = Math.max(0, total - (h.critical || 0) - (h.risky || 0));
    if (typeof Plotly !== "undefined") {
        Plotly.newPlot(c, [{values: [h.critical || 0, h.risky || 0, healthy], labels: ["Critical", "Risky", "Healthy"], type: "pie", marker: {colors: ["#dc2626", "#f97316", "#22c55e"]}}], {height: 220, margin: {l: 10, r: 10, t: 10, b: 10}}, {responsive: true});
    } else {
        c.innerHTML = "<div style='text-align:center;'><span style='color:#dc2626;'>Critical: " + (h.critical || 0) + "</span> | <span style='color:#f97316;'>Risky: " + (h.risky || 0) + "</span> | <span style='color:#22c55e;'>Healthy: " + healthy + "</span></div>";
    }
}

function renderPackagesTable(pkgs) {
    var tb = document.getElementById("packagesTableBody");
    if (!tb) return;
    if (!pkgs || pkgs.length === 0) { tb.innerHTML = "<tr><td colspan='6' style='text-align:center;color:#888;'>No vulnerable packages</td></tr>"; return; }
    var html = "";
    pkgs.forEach(function(p) {
        var sevColor = {critical: "#dc2626", high: "#f97316", medium: "#eab308", low: "#22c55e"}[p.severity_max] || "#64748b";
        html += "<tr><td style='padding:12px;'><strong>" + p.name + "</strong><br><span style='color:#888;font-size:12px;'>" + p.version + "</span></td>";
        html += "<td style='padding:12px;'>" + p.cves_total + "</td>";
        html += "<td style='padding:12px;color:" + (p.cves_reachable > 0 ? "#dc2626" : "#16a34a") + ";font-weight:600;'>" + p.cves_reachable + "</td>";
        html += "<td style='padding:12px;'><span style='background:" + sevColor + ";color:white;padding:2px 8px;border-radius:4px;font-size:11px;'>" + p.severity_max.toUpperCase() + "</span></td>";
        html += "<td style='padding:12px;'>" + (p.fixable ? "✅ Yes" : "⚠️ No") + "</td>";
        html += "<td style='padding:12px;'><span style='background:" + (p.cves_reachable > 0 ? "#fef2f2" : "#f0fdf4") + ";color:" + (p.cves_reachable > 0 ? "#dc2626" : "#16a34a") + ";padding:4px 8px;border-radius:4px;font-size:11px;font-weight:600;'>" + (p.cves_reachable > 0 ? "HIGH" : "LOW") + "</span></td></tr>";
    });
    tb.innerHTML = html;
}

function renderIssuesTable(issues, rawSecrets) {
    var tb = document.getElementById("issuesTableBody");
    if (!tb) return;
    if (!issues || issues.length === 0) { tb.innerHTML = "<tr><td colspan='8' style='text-align:center;color:#888;'>No issues found</td></tr>"; return; }
    
    var html = "";
    issues.slice(0, 200).forEach(function(i) {
        var sevColor = {critical: "#dc2626", high: "#f97316", medium: "#eab308", low: "#22c55e"}[i.severity] || "#64748b";
        
        // Determine type label and emoji
        var typeLabel = "🛡️ CVE";
        var typeClass = "cve";
        if (i.type === "secret") { typeLabel = "🔐 Secret"; typeClass = "secret"; }
        else if (i.type === "sast") { typeLabel = "🔍 SAST"; typeClass = "sast"; }
        else if (i.type === "malware") { typeLabel = "🦠 Malware"; typeClass = "malware"; }
        else if (i.type === "sandbox") { typeLabel = "🔒 Sandbox"; typeClass = "sandbox"; }
        
        // Determine reachability status
        var isReachable = false;
        var reachabilityText = "";
        var reachabilityColor = "#16a34a";
        var needsTriageFlag = i.needs_triage || (i.reachability && i.reachability.needs_triage);
        
        if (i.type === "sandbox") {
            // Sandbox findings are always "active" - they happened during install
            isReachable = true;
            reachabilityColor = "#dc2626";
            reachabilityText = "🚨 INSTALL-TIME";
        } else if (i.type === "cve") {
            isReachable = i.status === "live";
            if (isReachable) {
                reachabilityColor = "#dc2626";
                var funcHint = "";
                if (i.call_path && i.call_path.length > 0) {
                    funcHint = i.call_path[0];
                }
                reachabilityText = "🔴 REACHABLE" + (funcHint ? "<br><span style='font-size:10px;color:#666;'>via " + funcHint + "</span>" : "");
            } else {
                reachabilityText = "✅ Unreachable";
            }
        } else if (i.type === "secret") {
            // Secrets - show loader status
            isReachable = i.reachability && i.reachability.is_reachable;
            var hasLoader = i.reachability && i.reachability.has_loader;
            if (isReachable) {
                reachabilityColor = "#dc2626";
                if (hasLoader) {
                    reachabilityText = "🔴 REACHABLE<br><span style='font-size:10px;color:#16a34a;'>✓ Loader confirmed</span>";
                } else {
                    reachabilityText = "🔴 REACHABLE<br><span style='font-size:10px;color:#f59e0b;'>⚠ No loader found</span>";
                }
            } else {
                reachabilityText = "✅ Unreachable";
            }
        } else if (i.reachability) {
            isReachable = i.reachability.is_reachable;
            if (isReachable) {
                reachabilityColor = "#dc2626";
                var funcName = i.reachability.function_name || "";
                reachabilityText = "🔴 REACHABLE";
                if (funcName) {
                    reachabilityText += "<br><span style='font-size:10px;color:#666;'>in " + funcName + "()</span>";
                }
            } else {
                reachabilityText = "✅ Unreachable";
            }
        } else {
            // Fallback for legacy data
            isReachable = i.status === "live";
            reachabilityText = isReachable ? "🔴 REACHABLE" : "✅ Unreachable";
            if (isReachable) reachabilityColor = "#dc2626";
        }
        
        // Add triage flag to reachability display
        if (needsTriageFlag) {
            reachabilityText += "<br><span style='font-size:10px;color:#f59e0b;background:#fef3c7;padding:1px 4px;border-radius:2px;'>⚠ Triage needed</span>";
        }
        
        html += "<tr class='issue-row' data-severity='" + i.severity + "' data-status='" + (isReachable ? "live" : "dead") + "' data-type='" + i.type + "'>";
        
        // Column 1: Issue ID
        html += "<td style='padding:10px;'><code style='font-size:11px;'>" + i.id + "</code></td>";
        
        // Column 2: Severity
        html += "<td style='padding:10px;'><span style='background:" + sevColor + ";color:white;padding:2px 8px;border-radius:4px;font-size:11px;'>" + (i.severity || "").toUpperCase() + "</span></td>";
        
        // Column 3: Type
        html += "<td style='padding:10px;'>" + typeLabel + "</td>";
        
        // Column 4 & 5: File and Full Path (for secrets/SAST) or Package (for CVEs)
        if (i.type === "secret" || i.type === "sast") {
            var fileName = i.file_name || (i.package || '');
            var filePath = i.file_path || i.file || '';
            var lineDisplay = i.line ? ":" + i.line : "";
            html += "<td style='padding:10px;font-size:12px;font-family:monospace;'>" + fileName + lineDisplay + "</td>";
            html += "<td style='padding:10px;font-size:10px;color:#64748b;max-width:200px;overflow:hidden;text-overflow:ellipsis;' title='" + filePath + "'>" + filePath + "</td>";
        } else {
            // CVE - package info
            html += "<td style='padding:10px;'>" + i.package + "</td>";
            html += "<td style='padding:10px;font-size:10px;color:#64748b;'>-</td>";
        }
        
        // Column 6: Reachability Status with details
        html += "<td style='padding:10px;color:" + reachabilityColor + ";font-size:12px;'>" + reachabilityText + "</td>";
        
        // Column 7: Action - different for each type
        var actionHtml = "";
        if (i.type === "cve") {
            if (i.fix_versions && i.fix_versions.length > 0) {
                actionHtml = "<span style='color:#16a34a;'>⬆️ Upgrade to " + i.fix_versions[0] + "</span>";
            } else {
                actionHtml = "<span style='color:#f59e0b;'>⚠️ No fix - mitigate</span>";
            }
        } else if (i.type === "secret") {
            // Real secrets need: revoke, rotate, use secret manager
            if (isReachable) {
                if (needsTriageFlag) {
                    // Needs triage - no loader found
                    actionHtml = "<div style='font-size:11px;'>";
                    actionHtml += "<div style='color:#f59e0b;font-weight:600;'>⚠️ TRIAGE REQUIRED:</div>";
                    actionHtml += "<div>1. Verify if secret is actually used</div>";
                    actionHtml += "<div>2. Check for dynamic loading</div>";
                    actionHtml += "<div>3. If used: revoke & rotate</div>";
                    actionHtml += "</div>";
                } else {
                    // Confirmed loader - immediate action
                    actionHtml = "<div style='font-size:11px;'>";
                    actionHtml += "<div style='color:#dc2626;font-weight:600;'>🚨 IMMEDIATE:</div>";
                    actionHtml += "<div>1. 🔄 Revoke credential</div>";
                    actionHtml += "<div>2. 🔑 Rotate secret</div>";
                    actionHtml += "<div>3. 🔐 Use secret manager</div>";
                    actionHtml += "</div>";
                }
            } else {
                actionHtml = "<div style='font-size:11px;'>";
                actionHtml += "<div style='color:#64748b;'>Lower priority:</div>";
                actionHtml += "<div>1. 🔄 Revoke if active</div>";
                actionHtml += "<div>2. 🗑️ Remove from codebase</div>";
                actionHtml += "</div>";
            }
        } else if (i.type === "sast") {
            // SAST findings need code fixes
            actionHtml = "<span style='color:#3b82f6;'>🔧 Fix code pattern</span>";
        } else {
            actionHtml = "-";
        }
        html += "<td style='padding:10px;font-size:12px;'>" + actionHtml + "</td>";
        
        // Column 8: Description (truncated)
        var desc = i.description || '';
        var descDisplay = desc.length > 50 ? desc.substring(0, 50) + '...' : desc;
        html += "<td style='padding:10px;font-size:11px;color:#64748b;max-width:200px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;' title='" + desc.replace(/'/g, "&#39;") + "'>" + descDisplay + "</td>";
        
        html += "</tr>";
    });
    tb.innerHTML = html;
}

// ROI Panel - Engineering Savings
function renderROIPanel(d) {
    var c = document.getElementById("roiPanel");
    if (!c) return;
    
    var f = d.findings;
    var wr = d.workload_reduction;
    var eliminated = f.cves_eliminated || 0;
    var reductionPct = wr.reduction_percentage || 0;
    
    // Industry benchmarks
    var hoursPerCVE = 10.5;
    var hourlyRate = 100;
    var hoursSaved = eliminated * hoursPerCVE;
    var costSavings = hoursSaved * hourlyRate;
    
    var html = '<div style="display:grid;grid-template-columns:repeat(4,1fr);gap:20px;padding:20px 0;">';
    html += '<div style="text-align:center;"><div style="font-size:36px;font-weight:bold;">' + eliminated + '</div><div style="font-size:14px;opacity:0.9;">CVEs Eliminated</div><div style="font-size:11px;opacity:0.7;">Unreachable code</div></div>';
    html += '<div style="text-align:center;"><div style="font-size:36px;font-weight:bold;">' + reductionPct + '%</div><div style="font-size:14px;opacity:0.9;">Workload Reduction</div><div style="font-size:11px;opacity:0.7;">vs traditional SCA</div></div>';
    html += '<div style="text-align:center;"><div style="font-size:36px;font-weight:bold;">' + hoursSaved.toLocaleString() + '</div><div style="font-size:14px;opacity:0.9;">Hours Saved</div><div style="font-size:11px;opacity:0.7;">' + hoursPerCVE + 'h/CVE benchmark</div></div>';
    html += '<div style="text-align:center;"><div style="font-size:36px;font-weight:bold;">$' + costSavings.toLocaleString() + '</div><div style="font-size:14px;opacity:0.9;">Engineering Savings</div><div style="font-size:11px;opacity:0.7;">@ $' + hourlyRate + '/hr</div></div>';
    html += '</div>';
    
    html += '<div style="background:rgba(255,255,255,0.1);padding:12px;border-radius:8px;margin-top:10px;font-size:13px;">';
    html += '<strong>Calculation:</strong> ' + eliminated + ' unreachable CVEs × ' + hoursPerCVE + ' hrs/CVE × $' + hourlyRate + '/hr = <strong>$' + costSavings.toLocaleString() + '</strong>';
    html += '<div style="margin-top:5px;opacity:0.8;">Based on industry benchmarks (Ponemon Institute)</div></div>';
    
    c.innerHTML = html;
}

// Secrets Details Panel
function renderSecretsDetails(d) {
    var c = document.getElementById("secretsDetailsContainer");
    if (!c) return;
    
    var secrets = d.raw_secrets || [];
    if (secrets.length === 0) {
        c.innerHTML = '<p style="color:#16a34a;">✅ No security findings detected</p>';
        return;
    }
    
    // Classify
    var actualSecrets = secrets.filter(function(s) { return s.is_actual_secret === true; });
    var sastFindings = secrets.filter(function(s) { return s.is_actual_secret !== true; });
    var reachableSecrets = actualSecrets.filter(function(s) { return s.is_reachable; });
    
    var html = '';
    
    // Summary stats
    html += '<div style="display:grid;grid-template-columns:repeat(4,1fr);gap:15px;margin-bottom:20px;">';
    html += '<div style="background:#fef2f2;padding:15px;border-radius:8px;text-align:center;"><div style="font-size:24px;font-weight:bold;color:#dc2626;">' + actualSecrets.length + '</div><div style="font-size:12px;color:#64748b;">Actual Secrets</div></div>';
    html += '<div style="background:#fef9c3;padding:15px;border-radius:8px;text-align:center;"><div style="font-size:24px;font-weight:bold;color:#ca8a04;">' + sastFindings.length + '</div><div style="font-size:12px;color:#64748b;">SAST Findings</div></div>';
    html += '<div style="background:#fef2f2;padding:15px;border-radius:8px;text-align:center;"><div style="font-size:24px;font-weight:bold;color:#dc2626;">' + reachableSecrets.length + '</div><div style="font-size:12px;color:#64748b;">🔴 Reachable</div></div>';
    html += '<div style="background:#f0fdf4;padding:15px;border-radius:8px;text-align:center;"><div style="font-size:24px;font-weight:bold;color:#16a34a;">' + (actualSecrets.length - reachableSecrets.length) + '</div><div style="font-size:12px;color:#64748b;">✅ Unreachable</div></div>';
    html += '</div>';
    
    // Reachable Secrets (priority)
    if (reachableSecrets.length > 0) {
        html += '<h3 style="color:#dc2626;margin:20px 0 10px 0;">🚨 Reachable Secrets (Immediate Action)</h3>';
        reachableSecrets.slice(0, 5).forEach(function(s, idx) {
            html += renderSecretCard(s, idx + 1, true);
        });
        if (reachableSecrets.length > 5) {
            html += '<p style="color:#64748b;font-style:italic;">... and ' + (reachableSecrets.length - 5) + ' more reachable secrets</p>';
        }
    }
    
    // SAST summary
    if (sastFindings.length > 0) {
        html += '<h3 style="color:#ca8a04;margin:20px 0 10px 0;">⚠️ SAST Findings (Not Secrets - Code Issues)</h3>';
        html += '<p style="color:#64748b;margin-bottom:10px;font-size:13px;">These are security misconfigurations detected by static analysis, not actual hardcoded credentials.</p>';
        
        // Group by rule
        var byRule = {};
        sastFindings.forEach(function(s) {
            var rule = s.rule_id || 'unknown';
            if (!byRule[rule]) byRule[rule] = { count: 0, severity: s.severity };
            byRule[rule].count++;
        });
        
        html += '<table style="width:100%;border-collapse:collapse;"><thead><tr style="background:#f8fafc;"><th style="padding:10px;text-align:left;border-bottom:2px solid #e2e8f0;font-size:12px;">Rule</th><th style="padding:10px;text-align:center;border-bottom:2px solid #e2e8f0;font-size:12px;">Count</th><th style="padding:10px;text-align:left;border-bottom:2px solid #e2e8f0;font-size:12px;">Severity</th></tr></thead><tbody>';
        
        var rules = Object.keys(byRule).slice(0, 10);
        rules.forEach(function(rule) {
            var item = byRule[rule];
            var sev = item.severity || 'WARNING';
            var sevColor = sev === 'ERROR' ? '#dc2626' : sev === 'WARNING' ? '#f59e0b' : '#64748b';
            html += '<tr><td style="padding:10px;border-bottom:1px solid #e2e8f0;font-family:monospace;font-size:11px;">' + rule + '</td>';
            html += '<td style="padding:10px;border-bottom:1px solid #e2e8f0;text-align:center;">' + item.count + '</td>';
            html += '<td style="padding:10px;border-bottom:1px solid #e2e8f0;"><span style="background:' + sevColor + ';color:white;padding:2px 8px;border-radius:4px;font-size:11px;">' + sev + '</span></td></tr>';
        });
        
        if (Object.keys(byRule).length > 10) {
            html += '<tr><td colspan="3" style="padding:10px;color:#64748b;font-style:italic;">... and ' + (Object.keys(byRule).length - 10) + ' more rules</td></tr>';
        }
        html += '</tbody></table>';
    }
    
    c.innerHTML = html;
}

function renderSecretCard(s, num, isReachable) {
    var sevColor = s.severity === 'ERROR' ? '#dc2626' : s.severity === 'WARNING' ? '#f59e0b' : '#64748b';
    var statusColor = isReachable ? '#dc2626' : '#16a34a';
    var statusText = isReachable ? '🔴 REACHABLE' : '✅ Unreachable';
    
    var html = '<div style="background:white;border:1px solid #e2e8f0;border-left:4px solid ' + sevColor + ';padding:15px;margin-bottom:10px;border-radius:8px;">';
    html += '<div style="display:flex;justify-content:space-between;align-items:center;"><div><strong>#' + num + '</strong> <span style="background:' + sevColor + ';color:white;padding:2px 8px;border-radius:4px;font-size:11px;margin-left:8px;">' + (s.severity || 'WARNING') + '</span></div><div style="color:' + statusColor + ';font-weight:600;">' + statusText + '</div></div>';
    
    var filePath = s.file || 'unknown';
    var line = s.line || '?';
    html += '<div style="margin:10px 0;font-family:monospace;font-size:12px;color:#475569;"><strong>📁 ' + filePath + ':' + line + '</strong></div>';
    html += '<div style="font-size:11px;color:#64748b;margin-bottom:8px;">Rule: <code style="background:#f1f5f9;padding:2px 6px;border-radius:4px;">' + (s.rule_id || 'unknown') + '</code></div>';
    
    if (s.message) {
        var msgDisplay = s.message.length > 200 ? s.message.substring(0, 200) + '...' : s.message;
        html += '<p style="margin:10px 0;font-size:12px;color:#64748b;background:#f8fafc;padding:10px;border-radius:6px;">📝 ' + msgDisplay + '</p>';
    }
    
    if (isReachable) {
        html += '<div style="background:#fef2f2;padding:10px;border-radius:6px;margin-top:10px;"><strong style="color:#dc2626;font-size:12px;">📋 Remediation:</strong><ul style="margin:8px 0 0 20px;color:#475569;font-size:12px;"><li>REVOKE: Invalidate this credential immediately</li><li>ROTATE: Generate new credentials</li><li>SECURE: Move to secrets manager</li></ul></div>';
    }
    
    html += '</div>';
    return html;
}

function setupFilters() {
    var apply = function() {
        var sev = (document.getElementById("severityFilter") || {}).value || "all";
        var stat = (document.getElementById("statusFilter") || {}).value || "all";
        var typ = (document.getElementById("typeFilter") || {}).value || "all";
        document.querySelectorAll(".issue-row").forEach(function(r) {
            var typeMatch = typ === "all" || r.dataset.type === typ;
            // Also match 'secret' filter to 'sast' type for backward compat
            if (typ === "secret" && r.dataset.type === "sast") typeMatch = true;
            r.style.display = ((sev === "all" || r.dataset.severity === sev) && (stat === "all" || r.dataset.status === stat) && typeMatch) ? "" : "none";
        });
    };
    ["severityFilter", "statusFilter", "typeFilter"].forEach(function(id) { var e = document.getElementById(id); if (e) e.onchange = apply; });
}

document.addEventListener("DOMContentLoaded", function() { initDashboard(sampleData); });
