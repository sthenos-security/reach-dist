#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.

"""
REACHABLE Dashboard Generator
Creates standalone HTML dashboards from scan results
"""

import json
from pathlib import Path
from datetime import datetime
from typing import Dict, Any

class DashboardGenerator:
    """Generate standalone HTML dashboard from REACHABLE scan data"""
    
    def __init__(self, template_dir: Path = None):
        """Initialize generator with template directory"""
        if template_dir is None:
            template_dir = Path(__file__).parent
        
        self.template_dir = Path(template_dir)
        self.template_html = self.template_dir / "template.html"
        self.template_css = self.template_dir / "styles.css"
        self.template_js = self.template_dir / "dashboard.js"
    
    def generate(self, scan_data: Dict[str, Any], output_path: Path) -> None:
        """
        Generate standalone HTML dashboard
        
        Args:
            scan_data: REACHABLE scan results dictionary
            output_path: Where to save the HTML file
        """
        # Read template files
        html_content = self._read_template(self.template_html)
        css_content = self._read_template(self.template_css)
        js_content = self._read_template(self.template_js)
        
        # Embed data into JavaScript
        js_with_data = self._embed_data(js_content, scan_data)
        
        # Create standalone HTML
        standalone_html = self._create_standalone(html_content, css_content, js_with_data)
        
        # Write output
        output_path = Path(output_path)
        output_path.parent.mkdir(parents=True, exist_ok=True)
        output_path.write_text(standalone_html, encoding='utf-8')
        
        # Note: Dashboard link is printed by cli.py to avoid duplication
    
    def _read_template(self, template_path: Path) -> str:
        """Read template file"""
        if not template_path.exists():
            raise FileNotFoundError(f"Template not found: {template_path}")
        return template_path.read_text(encoding='utf-8')
    
    def _embed_data(self, js_content: str, scan_data: Dict[str, Any]) -> str:
        """Embed scan data into JavaScript with proper escaping"""
        import re
        
        # Convert scan data to JSON with proper escaping
        # ensure_ascii=True converts all non-ASCII to \uXXXX escapes
        # json.dumps handles all escaping correctly for JSON
        data_json = json.dumps(scan_data, indent=2, default=str, ensure_ascii=True)
        
        # Additional safety: escape any </script> tags in the data to prevent XSS
        data_json = data_json.replace('</script>', '<\\/script>')
        data_json = data_json.replace('</Script>', '<\\/Script>')
        data_json = data_json.replace('</SCRIPT>', '<\\/SCRIPT>')
        
        # Find and replace the entire sampleData object
        # Support both var and const declarations
        replacement = f'var sampleData = {data_json};'
        
        # Try simple replacement first (for empty object)
        if 'var sampleData = {};' in js_content:
            return js_content.replace('var sampleData = {};', replacement)
        if 'const sampleData = {};' in js_content:
            return js_content.replace('const sampleData = {};', replacement.replace('var ', 'const '))
        
        # Otherwise use regex for non-empty sample data
        pattern = r'(var|const)\s+sampleData\s*=\s*\{[^;]*?\};'
        js_with_data = re.sub(pattern, replacement, js_content, count=1, flags=re.DOTALL)
        
        # If regex didn't work, prepend data and override
        if js_with_data == js_content or 'sampleData = {' not in js_with_data:
            # Inject at the beginning
            data_block = f'var sampleData = {data_json};\n'
            # Find where to inject (after initial comments)
            lines = js_content.split('\n')
            inject_at = 0
            for i, line in enumerate(lines):
                if line.strip() and not line.strip().startswith('//'):
                    inject_at = i
                    break
            lines.insert(inject_at, data_block)
            js_with_data = '\n'.join(lines)
        
        return js_with_data
    
    def _create_standalone(self, html: str, css: str, js: str) -> str:
        """Create standalone HTML with embedded CSS and JS"""
        # Embed CSS
        html = html.replace(
            '<link rel="stylesheet" href="styles.css">',
            f'<style>\n{css}\n</style>'
        )
        
        # Embed JS (keep Plotly CDN link)
        html = html.replace(
            '<script src="dashboard.js"></script>',
            f'<script>\n{js}\n</script>'
        )
        
        return html
    
    @staticmethod
    def from_json(json_path: Path, output_path: Path) -> None:
        """
        Generate dashboard from JSON file
        
        Args:
            json_path: Path to scan results JSON
            output_path: Where to save HTML dashboard
        """
        with open(json_path, 'r') as f:
            scan_data = json.load(f)
        
        generator = DashboardGenerator()
        generator.generate(scan_data, output_path)

def create_sample_data() -> Dict[str, Any]:
    """Create sample scan data for testing"""
    return {
        "metadata": {
            "scan_id": f"scan_{datetime.now().strftime('%Y%m%d_%H%M%S')}",
            "timestamp": datetime.now().isoformat(),
            "repository": "example-app"
        },
        "findings": {
            "cves_total": 127,
            "cves_reachable": 43,
            "cves_eliminated": 84,
            "secrets_total": 20,
            "secrets_live": 8,
            "secrets_dead": 12,
            "malware_total": 7
        },
        "workload_reduction": {
            "reduction_percentage": 62,
            "issues_eliminated": 96,
            "time_saved_hours": 120
        },
        "severity_breakdown": {
            "critical": {"total": 15, "live": 8, "dead": 7},
            "high": {"total": 28, "live": 12, "dead": 16},
            "medium": {"total": 5, "live": 2, "dead": 3},
            "low": {"total": 2, "live": 1, "dead": 1}
        },
        "coverage": {
            "cve_analysis": 80,
            "malware_scan": 100,
            "secrets_scan": 80
        },
        "top_packages": [
            {
                "name": "numpy",
                "version": "1.21.0",
                "cves_total": 12,
                "cves_reachable": 8,
                "secrets": 3,
                "malware": 0,
                "priority": "high"
            },
            {
                "name": "requests",
                "version": "2.25.0",
                "cves_total": 8,
                "cves_reachable": 3,
                "secrets": 0,
                "malware": 0,
                "priority": "medium"
            },
            {
                "name": "malicious-logger",
                "version": "1.0.0",
                "cves_total": 0,
                "cves_reachable": 0,
                "secrets": 0,
                "malware": 1,
                "priority": "critical"
            },
            {
                "name": "flask",
                "version": "1.0.2",
                "cves_total": 5,
                "cves_reachable": 2,
                "secrets": 1,
                "malware": 0,
                "priority": "medium"
            }
        ],
        "correlation_events": [
            {
                "package": "numpy",
                "version": "1.21.0",
                "cve_count": 8,
                "secret_count": 3,
                "malware_count": 0,
                "risk_level": "high"
            },
            {
                "package": "flask",
                "version": "1.0.2",
                "cve_count": 2,
                "secret_count": 1,
                "malware_count": 0,
                "risk_level": "medium"
            },
            {
                "package": "malicious-logger",
                "version": "1.0.0",
                "cve_count": 0,
                "secret_count": 0,
                "malware_count": 1,
                "risk_level": "critical"
            }
        ],
        "issues": [
            {
                "id": "CVE-2021-44228",
                "severity": "critical",
                "type": "cve",
                "package": "log4j 2.14.0",
                "status": "live",
                "age_days": 45
            },
            {
                "id": "CVE-2022-1234",
                "severity": "high",
                "type": "cve",
                "package": "flask 1.0.2",
                "status": "dead",
                "age_days": 12
            },
            {
                "id": "SECRET-API-KEY",
                "severity": "high",
                "type": "secret",
                "package": "config.py",
                "status": "live",
                "age_days": 2
            },
            {
                "id": "MALWARE-TYPOSQUAT",
                "severity": "critical",
                "type": "malware",
                "package": "malicious-logger",
                "status": "live",
                "age_days": 1
            },
            {
                "id": "CVE-2023-5678",
                "severity": "medium",
                "type": "cve",
                "package": "requests 2.25.0",
                "status": "dead",
                "age_days": 8
            },
            {
                "id": "CVE-2023-1111",
                "severity": "high",
                "type": "cve",
                "package": "numpy 1.21.0",
                "status": "live",
                "age_days": 30
            },
            {
                "id": "SECRET-DB-PASS",
                "severity": "critical",
                "type": "secret",
                "package": "database.py",
                "status": "live",
                "age_days": 5
            },
            {
                "id": "CVE-2022-9999",
                "severity": "low",
                "type": "cve",
                "package": "old-lib 0.1.0",
                "status": "dead",
                "age_days": 60
            }
        ]
    }

def main():
    """CLI entry point"""
    import argparse
    
    parser = argparse.ArgumentParser(
        description='Generate REACHABLE security dashboard'
    )
    parser.add_argument(
        '--input',
        type=Path,
        help='Path to scan results JSON (uses sample data if not provided)'
    )
    parser.add_argument(
        '--output',
        type=Path,
        default=Path('dashboard.html'),
        help='Output HTML file (default: dashboard.html)'
    )
    parser.add_argument(
        '--sample',
        action='store_true',
        help='Generate dashboard with sample data'
    )
    
    args = parser.parse_args()
    
    # Generate dashboard
    generator = DashboardGenerator()
    
    if args.sample or args.input is None:
        print("📝 Using sample data...")
        scan_data = create_sample_data()
        generator.generate(scan_data, args.output)
    else:
        print(f"📂 Loading data from {args.input}...")
        DashboardGenerator.from_json(args.input, args.output)

if __name__ == '__main__':
    main()
