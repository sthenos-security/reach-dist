# Copyright © 2026 Sthenos Security. All rights reserved.

"""
REACHABLE Dashboard Module

Generate professional HTML security dashboards from scan results.
"""

from .generator import DashboardGenerator, create_sample_data

__all__ = ['DashboardGenerator', 'create_sample_data']
__version__ = '2.2.0'
