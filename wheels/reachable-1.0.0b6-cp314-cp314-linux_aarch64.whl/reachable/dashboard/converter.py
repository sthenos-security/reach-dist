#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.

"""
REACHABLE Dashboard Data Converter v4.3.3
Supports both database-first (preferred) and JSON-based flows

Architecture:
    v4.3.3+ (Preferred): SQLite DB → Dashboard
    Legacy/Fallback:     JSON Report → Dashboard

Usage:
    # From database (preferred)
    from reachable.dashboard.converter import DashboardDataLoader
    loader = DashboardDataLoader.from_scan_dir('/path/to/scan')
    dashboard_data = loader.load()
    
    # From JSON (legacy)
    loader = DashboardDataLoader.from_json('/path/to/report.json.gz')
    dashboard_data = loader.load()
"""

import gzip
import json
import sqlite3
from pathlib import Path
from typing import Dict, Any, List, Optional
from datetime import datetime

class DashboardDataLoader:
    """
    Load dashboard data from either SQLite database or JSON report
    
    Automatically detects and uses the best available source:
    1. reachable.db (v4.3.3+ database-first architecture)
    2. reachable-report.json.gz (compressed JSON)
    3. reachable-report.json (uncompressed JSON)
    """
    
    def __init__(self, source_type: str, source_path: Path):
        self.source_type = source_type  # 'database' or 'json'
        self.source_path = Path(source_path)
        self._data = None
    
    @classmethod
    def from_scan_dir(cls, scan_dir: Path) -> 'DashboardDataLoader':
        """
        Auto-detect best source from scan directory
        
        Preference order:
        1. reachable.db (database-first, v4.3.3+)
        2. reachable-report.json.gz
        3. reachable-report.json
        """
        scan_dir = Path(scan_dir)
        
        # Check for database first (preferred)
        db_path = scan_dir / 'reachable.db'
        if db_path.exists():
            return cls('database', db_path)
        
        # Fall back to compressed JSON
        json_gz = scan_dir / 'reachable-report.json.gz'
        if json_gz.exists():
            return cls('json', json_gz)
        
        # Fall back to uncompressed JSON
        json_file = scan_dir / 'reachable-report.json'
        if json_file.exists():
            return cls('json', json_file)
        
        raise FileNotFoundError(
            f"No data source found in {scan_dir}. "
            "Expected: reachable.db, reachable-report.json.gz, or reachable-report.json"
        )
    
    @classmethod
    def from_database(cls, db_path: Path) -> 'DashboardDataLoader':
        """Create loader from database file"""
        return cls('database', db_path)
    
    @classmethod
    def from_json(cls, json_path: Path) -> 'DashboardDataLoader':
        """Create loader from JSON file"""
        return cls('json', json_path)
    
    def load(self) -> Dict[str, Any]:
        """Load and transform data to dashboard format"""
        if self.source_type == 'database':
            return self._load_from_database()
        else:
            return self._load_from_json()
    
    def _load_from_database(self) -> Dict[str, Any]:
        """
        Load dashboard data directly from SQLite database
        
        This is the v4.3.3+ preferred flow:
        - Queries are optimized for dashboard needs
        - No intermediate JSON serialization
        - Direct access to indexed data
        """
        conn = sqlite3.connect(str(self.source_path))
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        
        try:
            # Load findings
            reachable_cves = {}
            unreachable_cves = {}
            secrets_findings = []
            cwe_findings = []
            
            # Get CVE findings
            cursor.execute("""
                SELECT * FROM findings WHERE finding_type = 'cve'
            """)
            for row in cursor.fetchall():
                cve_data = dict(row)
                cve_id = cve_data.get('cve_id') or cve_data.get('finding_id')
                
                if cve_data.get('is_reachable'):
                    reachable_cves[cve_id] = self._format_cve(cve_data)
                else:
                    unreachable_cves[cve_id] = self._format_cve(cve_data)
            
            # Get secret findings
            cursor.execute("""
                SELECT * FROM findings WHERE finding_type = 'secret'
            """)
            for row in cursor.fetchall():
                secrets_findings.append(self._format_secret(dict(row)))
            
            # Get CWE/SAST findings
            cursor.execute("""
                SELECT * FROM findings WHERE finding_type = 'cwe'
            """)
            for row in cursor.fetchall():
                cwe_findings.append(self._format_cwe(dict(row)))
            
            # Get metrics
            cursor.execute("""
                SELECT metric_type, metric_name, metric_value 
                FROM metrics
            """)
            metrics = {}
            for row in cursor.fetchall():
                mtype = row['metric_type']
                if mtype not in metrics:
                    metrics[mtype] = {}
                metrics[mtype][row['metric_name']] = row['metric_value']
            
            # Get large objects (sandbox results, etc.)
            sandbox = {}
            cursor.execute("""
                SELECT object_type, data, compression FROM large_objects
                WHERE object_type = 'sandbox'
            """)
            row = cursor.fetchone()
            if row:
                data = row['data']
                if row['compression'] == 'gzip':
                    data = gzip.decompress(data).decode()
                else:
                    data = data.decode() if isinstance(data, bytes) else data
                sandbox = json.loads(data)
            
            # Get scan summary
            cursor.execute("SELECT * FROM scan_summary LIMIT 1")
            summary_row = cursor.fetchone()
            scan_summary = dict(summary_row) if summary_row else {}
            
            # Build dashboard data structure
            totals = self._calculate_totals(
                reachable_cves, unreachable_cves, 
                secrets_findings, cwe_findings, metrics
            )
            
            return {
                'metadata': {
                    'generated_at': scan_summary.get('scan_date', datetime.now().isoformat()),
                    'source': 'database',
                    'version': scan_summary.get('version', '4.3.3'),
                },
                'reachable': reachable_cves,
                'unreachable': unreachable_cves,
                'detailed_findings': {
                    'secrets': {'findings': secrets_findings + cwe_findings},
                },
                'metrics': self._build_metrics_from_db(metrics, totals),
                'sandbox': sandbox,
                'summary': {'totals': totals},
                'reachable_version': scan_summary.get('version', '4.3.3'),
            }
            
        finally:
            conn.close()
    
    def _load_from_json(self) -> Dict[str, Any]:
        """
        Load dashboard data from JSON report (legacy/fallback)
        """
        if str(self.source_path).endswith('.gz'):
            with gzip.open(self.source_path, 'rt', encoding='utf-8') as f:
                report = json.load(f)
        else:
            with open(self.source_path, 'r', encoding='utf-8') as f:
                report = json.load(f)
        
        # JSON report is already in dashboard-compatible format
        # Just add source metadata
        if 'metadata' not in report:
            report['metadata'] = {}
        report['metadata']['source'] = 'json'
        
        return report
    
    def _format_cve(self, row: Dict) -> Dict[str, Any]:
        """Format database row to CVE structure"""
        return {
            'cve': row.get('cve_id') or row.get('finding_id'),
            'severity': row.get('severity', 'UNKNOWN'),
            'package': row.get('package_name', ''),
            'version': row.get('package_version', ''),
            'description': row.get('description', ''),
            'cvss_score': row.get('cvss_score'),
            'is_reachable': row.get('is_reachable', False),
            'reachability_confidence': row.get('reachability_confidence', 'UNKNOWN'),
        }
    
    def _format_secret(self, row: Dict) -> Dict[str, Any]:
        """Format database row to secret structure"""
        return {
            'rule_id': row.get('finding_id', ''),
            'severity': row.get('severity', 'HIGH'),
            'message': row.get('description', ''),
            'file': row.get('file_path', ''),
            'line': row.get('line_number'),
            'is_reachable': row.get('is_reachable', False),
            'secret_type': row.get('secret_type', ''),
            'is_actual_secret': True,
            'finding_type': 'SECRET',
        }
    
    def _format_cwe(self, row: Dict) -> Dict[str, Any]:
        """Format database row to CWE/SAST structure"""
        return {
            'rule_id': row.get('finding_id', ''),
            'severity': row.get('severity', 'MEDIUM'),
            'message': row.get('description', ''),
            'file': row.get('file_path', ''),
            'line': row.get('line_number'),
            'cwe_id': row.get('cwe_id', ''),
            'is_reachable': row.get('is_reachable', False),
            'is_actual_secret': False,
            'finding_type': 'CWE',
        }
    
    def _calculate_totals(self, reachable, unreachable, secrets, cwes, metrics) -> Dict[str, Any]:
        """Calculate summary totals from findings"""
        cves_total = len(reachable) + len(unreachable)
        
        # Count by severity
        sev_counts = {'critical': 0, 'high': 0, 'medium': 0, 'low': 0}
        sev_reachable = {'critical': 0, 'high': 0, 'medium': 0, 'low': 0}
        
        for cve in reachable.values():
            sev = cve.get('severity', '').lower()
            if sev in sev_counts:
                sev_counts[sev] += 1
                sev_reachable[sev] += 1
        
        for cve in unreachable.values():
            sev = cve.get('severity', '').lower()
            if sev in sev_counts:
                sev_counts[sev] += 1
        
        secrets_reachable = sum(1 for s in secrets if s.get('is_reachable'))
        cwe_reachable = sum(1 for c in cwes if c.get('is_reachable'))
        
        return {
            'cves_total': cves_total,
            'cves_reachable': len(reachable),
            'cves_unreachable': len(unreachable),
            'cves_critical': sev_counts['critical'],
            'cves_high': sev_counts['high'],
            'cves_medium': sev_counts['medium'],
            'cves_low': sev_counts['low'],
            'cves_critical_reachable': sev_reachable['critical'],
            'cves_high_reachable': sev_reachable['high'],
            'secrets_total': len(secrets),
            'secrets_reachable': secrets_reachable,
            'cwe_total': len(cwes),
            'cwe_reachable': cwe_reachable,
            'risk_reduction_pct': round((len(unreachable) / cves_total * 100) if cves_total > 0 else 0, 1),
        }
    
    def _build_metrics_from_db(self, db_metrics: Dict, totals: Dict) -> Dict[str, Any]:
        """Build metrics structure from database metrics"""
        return {
            'cves': {
                'total_found': totals.get('cves_total', 0),
                'reachable': totals.get('cves_reachable', 0),
                'unreachable': totals.get('cves_unreachable', 0),
                'by_severity': {
                    'critical': totals.get('cves_critical', 0),
                    'high': totals.get('cves_high', 0),
                    'medium': totals.get('cves_medium', 0),
                    'low': totals.get('cves_low', 0),
                },
            },
            'security_scans': {
                'secrets': {
                    'total_detected': totals.get('secrets_total', 0),
                    'reachable': totals.get('secrets_reachable', 0),
                },
            },
            'call_graph': db_metrics.get('call_graph', {}),
            'libraries': db_metrics.get('libraries', {}),
        }

def generate_dashboard(
    source: Path,
    output_path: Path,
    template_dir: Path = None
) -> Path:
    """
    Generate dashboard HTML from scan directory, database, or JSON
    
    Auto-detects the best available source:
    1. Database (if scan_dir contains reachable.db)
    2. Compressed JSON (reachable-report.json.gz)
    3. Uncompressed JSON (reachable-report.json)
    
    Args:
        source: Path to scan directory, database, or JSON file
        output_path: Where to save dashboard HTML
        template_dir: Optional custom template directory
        
    Returns:
        Path to generated dashboard
    """
    from .generator import DashboardGenerator
    
    source = Path(source)
    
    # Determine source type
    if source.is_dir():
        loader = DashboardDataLoader.from_scan_dir(source)
    elif source.suffix == '.db':
        loader = DashboardDataLoader.from_database(source)
    else:
        loader = DashboardDataLoader.from_json(source)
    
    # Load data
    dashboard_data = loader.load()
    
    # Generate dashboard
    generator = DashboardGenerator(template_dir)
    generator.generate(dashboard_data, output_path)
    
    return output_path

# Legacy compatibility
ReportToDashboardConverter = DashboardDataLoader

def main():
    """CLI entry point"""
    import argparse
    
    parser = argparse.ArgumentParser(
        description='Generate REACHABLE dashboard from scan results'
    )
    parser.add_argument(
        'source',
        type=Path,
        help='Scan directory, database file (.db), or JSON report (.json/.json.gz)'
    )
    parser.add_argument(
        '-o', '--output',
        type=Path,
        default=Path('dashboard.html'),
        help='Output HTML file (default: dashboard.html)'
    )
    
    args = parser.parse_args()
    
    output = generate_dashboard(args.source, args.output)
    print(f"✅ Dashboard generated: {output}")
    print(f"   Open in browser: file://{output.absolute()}")

if __name__ == '__main__':
    main()
