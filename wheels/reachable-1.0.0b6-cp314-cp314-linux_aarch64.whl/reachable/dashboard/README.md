# REACHABLE Dashboard

Professional HTML dashboards for security scan results.

## Features

- **Executive KPI Cards** - Total issues, live issues, eliminated issues, workload reduction
- **Severity Charts** - Visual breakdown of critical/high/medium/low issues
- **Coverage Metrics** - Track CVE, malware, and secrets scanning coverage
- **Correlation Insights** - Identify packages with multiple issue types
- **Interactive Filtering** - Filter issues by severity, status, and type
- **Standalone HTML** - Single file, works offline, no server required

## Quick Start

### Generate Dashboard with Sample Data

```bash
python generator.py --sample --output dashboard.html
```

### Generate from Scan Results

```bash
# From JSON file
python generator.py --input scan-results.json --output dashboard.html

# Open in browser
open dashboard.html  # macOS
xdg-open dashboard.html  # Linux
start dashboard.html  # Windows
```

## Usage

```python
from reachable.dashboard.generator import DashboardGenerator

# Load your scan data
scan_data = {
    "metadata": {
        "scan_id": "abc123",
        "timestamp": "2025-12-27T10:30:00Z",
        "repository": "myapp"
    },
    "findings": {
        "cves_total": 127,
        "cves_reachable": 43,
        "cves_eliminated": 84,
        "secrets_total": 20,
        "secrets_live": 8,
        "secrets_dead": 12,
        "malware_total": 7
    },
    "workload_reduction": {
        "reduction_percentage": 62,
        "issues_eliminated": 96,
        "time_saved_hours": 120
    },
    # ... more data
}

# Generate dashboard
generator = DashboardGenerator()
generator.generate(scan_data, "dashboard.html")
```

## Dashboard Sections

### 1. KPI Cards
- **Total Issues** - All CVEs + Secrets + Malware found
- **Live Issues** - Issues requiring action (reachable or in live code)
- **Issues Eliminated** - Problems in dead code (safe to ignore)
- **Workload Reduction** - Percentage of security work saved

### 2. Severity Charts
- Horizontal bar chart showing live vs dead code issues
- Grouped bar chart showing workload reduction impact
- Color-coded by severity (Critical=Red, High=Orange, Medium=Yellow, Low=Gray)

### 3. Coverage Widget
- CVE Reachability Analysis coverage
- Malware Detection coverage  
- Secrets Detection coverage

### 4. Correlation Insights ⭐
**Unique to REACHABLE** - Shows packages with multiple issue types:
- Packages with CVEs + Secrets + Malware
- Risk-based prioritization
- Immediate action recommendations

### 5. Top Packages Table
- Packages requiring attention
- CVE counts (total vs reachable)
- Secrets and malware detections
- Priority levels

### 6. Detailed Issues Table
- All issues with filtering
- Filter by severity, status, type
- Age tracking
- Interactive sorting

## Data Schema

See the `create_sample_data()` function in `generator.py` for the complete schema.

Key fields:
```json
{
  "metadata": {...},
  "findings": {...},
  "workload_reduction": {...},
  "severity_breakdown": {...},
  "coverage": {...},
  "top_packages": [...],
  "correlation_events": [...],
  "issues": [...]
}
```

## Integration with REACHABLE

The dashboard generator will be integrated into `reachctl`:

```bash
# Future integration (v2.2.0)
reachctl scan ./myapp --output-format dashboard
reachctl dashboard generate scan-results.json
reachctl dashboard view dashboard.html
```

## File Structure

```
reachable/dashboard/
├── generator.py      # Dashboard generator
├── template.html     # HTML template
├── styles.css        # Professional styling
├── dashboard.js      # Interactive functionality
└── README.md         # This file
```

## Customization

### Custom Styling

Edit `styles.css` to customize colors, fonts, layout:

```css
:root {
    --critical: #d93636;
    --high: #ff8c42;
    --medium: #ffd93d;
    --low: #95afc0;
    /* ... */
}
```

### Custom Charts

Edit `dashboard.js` to modify Plotly chart configurations.

## Requirements

- Python 3.7+
- No Python dependencies (uses only stdlib)
- Browser with JavaScript enabled for viewing

The generated HTML uses:
- Plotly.js (via CDN) for charts
- Vanilla JavaScript (no frameworks)
- Modern CSS (Grid, Flexbox)

## Browser Support

- Chrome/Edge 90+
- Firefox 88+
- Safari 14+

## Performance

- Dashboard loads instantly (single HTML file)
- Handles 1000+ issues smoothly
- Offline capable
- ~500KB file size (including embedded data)

## Future Enhancements

- [ ] PDF export
- [ ] Historical trend charts
- [ ] Comparison between scans
- [ ] Customizable KPI thresholds
- [ ] Email report generation
- [ ] CI/CD integration badges

## License

Part of the REACHABLE project.
