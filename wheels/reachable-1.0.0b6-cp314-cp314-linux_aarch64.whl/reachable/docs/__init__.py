# Copyright © 2026 Sthenos Security. All rights reserved.

"""REACHABLE Documentation"""

from pathlib import Path

DOCS_DIR = Path(__file__).parent

def get_doc_path(name: str) -> Path:
    """Get path to a documentation file"""
    return DOCS_DIR / name

def get_quick_start() -> str:
    """Get quick start guide content"""
    return (DOCS_DIR / "QUICK_START.md").read_text()

def get_install_guide() -> str:
    """Get installation guide content"""
    return (DOCS_DIR / "INSTALL.md").read_text()

def get_user_guide() -> str:
    """Get full user guide content"""
    return (DOCS_DIR / "USER_GUIDE.md").read_text()
