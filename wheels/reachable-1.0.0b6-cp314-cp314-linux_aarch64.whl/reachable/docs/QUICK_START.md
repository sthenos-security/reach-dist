# REACHABLE Quick Start

## 1. Install

```bash
pip install reachable-4.5.7-py3-none-any.whl
```

## 2. Install Dependencies

**macOS:**
```bash
brew install syft grype
```

**Linux:**
```bash
curl -sSfL https://raw.githubusercontent.com/anchore/syft/main/install.sh | sh -s -- -b /usr/local/bin
curl -sSfL https://raw.githubusercontent.com/anchore/grype/main/install.sh | sh -s -- -b /usr/local/bin
```

## 3. Run a Scan

```bash
reachctl scan /path/to/your/project
```

## 4. View Results

```bash
# macOS
open ~/.reachable/scans/your-project/latest/dashboard/index.html

# Linux
xdg-open ~/.reachable/scans/your-project/latest/dashboard/index.html
```

## Common Commands

| Command | Description |
|---------|-------------|
| `reachctl scan <path>` | Scan a repository |
| `reachctl scan <path> --debug` | Scan with full debug output |
| `reachctl version` | Show version |
| `reachctl selftest` | Verify installation |
| `reachctl docs` | View quick start guide |
| `reachctl docs guide` | View full user guide |
| `reachctl docs --online` | Open docs in browser |

## Logs

```bash
cat ~/.reachable/scans/<project>/latest/scan.log
```

## Support

- Email: support@reachable.dev
- Docs: https://docs.reachable.dev

---

For full documentation, see [USER_GUIDE.md](USER_GUIDE.md)
