#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.

"""
Import Statement Scanner - Phantom Dependency Detection

Scans actual import statements in code to find discrepancies with requirements.txt:

1. PHANTOM DEPENDENCIES: Imported but not in requirements.txt
   - Risk: SCA tools won't scan them for CVEs
   - "Works on my machine" but not in production

2. SHADOW IMPORTS: Importing transitive dependencies directly
   - Risk: If parent removed, app breaks in production
   - Should be explicitly declared

3. DEAD DEPENDENCIES: In requirements.txt but never imported
   - Risk: Alert fatigue from CVEs in unused code
   - Unnecessary attack surface

This is the "dual-check" approach used by professional AppSec teams.
"""

import ast
import re
from pathlib import Path
from typing import Set, Dict, List, Tuple, Optional
from dataclasses import dataclass
from collections import defaultdict

@dataclass
class ImportAnalysis:
    """Results of import vs. manifest analysis"""
    
    # What's actually imported in code
    imports_found: Set[str]
    imports_by_file: Dict[str, Set[str]]
    
    # What's declared in manifest
    manifest_packages: Set[str]
    
    # Discrepancies (THE SECURITY GAPS)
    phantom_dependencies: Set[str]  # Imported but NOT in manifest
    shadow_imports: Set[str]  # Transitive deps imported directly
    dead_dependencies: Set[str]  # In manifest but NEVER imported
    
    # Risk assessment
    phantom_risk: str  # CRITICAL, HIGH, MEDIUM, LOW
    shadow_risk: str
    dead_risk: str
    
    # Details
    phantom_details: List[Dict]
    shadow_details: List[Dict]
    dead_details: List[Dict]

class ImportScanner:
    """Scans Python code for import statements"""
    
    def __init__(self, app_dir: Path):
        self.app_dir = Path(app_dir)
        self.imports_by_file = defaultdict(set)
        self.all_imports = set()
    
    def scan_directory(self) -> Dict[str, Set[str]]:
        """
        Scan all Python files for import statements
        
        Returns:
            Dict mapping file path to set of imported packages
        """
        python_files = list(self.app_dir.rglob('*.py'))
        
        for py_file in python_files:
            # Skip virtual environments
            if 'venv' in str(py_file) or 'site-packages' in str(py_file):
                continue
            
            imports = self._extract_imports(py_file)
            if imports:
                rel_path = str(py_file.relative_to(self.app_dir))
                self.imports_by_file[rel_path] = imports
                self.all_imports.update(imports)
        
        return dict(self.imports_by_file)
    
    def _extract_imports(self, filepath: Path) -> Set[str]:
        """
        Extract all import statements from a Python file
        
        Handles:
        - import package
        - import package.submodule
        - from package import something
        - from package.submodule import something
        """
        imports = set()
        
        try:
            with open(filepath, 'r', encoding='utf-8') as f:
                source = f.read()
            
            tree = ast.parse(source, filename=str(filepath))
            
            for node in ast.walk(tree):
                if isinstance(node, ast.Import):
                    # import package, import package.submodule
                    for alias in node.names:
                        package = self._get_top_level_package(alias.name)
                        if package:
                            imports.add(package)
                
                elif isinstance(node, ast.ImportFrom):
                    # from package import something
                    if node.module:
                        package = self._get_top_level_package(node.module)
                        if package:
                            imports.add(package)
        
        except (SyntaxError, UnicodeDecodeError):
            # Skip files with syntax errors or encoding issues
            pass
        
        return imports
    
    def _get_top_level_package(self, module_name: str) -> Optional[str]:
        """
        Extract top-level package from module name
        
        Examples:
            requests.auth → requests
            urllib.parse → urllib
            os → os
        """
        if not module_name:
            return None
        
        # Skip built-in/standard library modules
        if self._is_stdlib(module_name):
            return None
        
        # Get first component
        return module_name.split('.')[0]
    
    def _is_stdlib(self, module_name: str) -> bool:
        """Check if module is part of Python standard library"""
        # Common stdlib modules
        stdlib = {
            'os', 'sys', 'json', 're', 'datetime', 'time', 'math',
            'random', 'collections', 'itertools', 'functools',
            'pathlib', 'typing', 'dataclasses', 'abc', 'enum',
            'io', 'csv', 'xml', 'html', 'urllib', 'http', 'email',
            'logging', 'unittest', 'asyncio', 'threading', 'multiprocessing',
            'subprocess', 'argparse', 'configparser', 'pickle', 'shelve',
            'sqlite3', 'hashlib', 'hmac', 'secrets', 'base64', 'binascii',
            'struct', 'array', 'queue', 'heapq', 'bisect', 'copy',
            'pprint', 'reprlib', 'textwrap', 'string', 'difflib',
            'warnings', 'contextlib', 'weakref', 'gc', 'inspect',
            'importlib', '__future__'
        }
        
        top_level = module_name.split('.')[0]
        return top_level in stdlib

class ManifestParser:
    """Parses requirements.txt or pyproject.toml"""
    
    def __init__(self, project_dir: Path):
        self.project_dir = Path(project_dir)
    
    def parse(self) -> Set[str]:
        """
        Parse manifest file to get declared dependencies
        
        Returns:
            Set of package names declared in manifest
        """
        # Try requirements.txt first
        requirements_txt = self.project_dir / 'requirements.txt'
        if requirements_txt.exists():
            return self._parse_requirements_txt(requirements_txt)
        
        # Try pyproject.toml
        pyproject = self.project_dir / 'pyproject.toml'
        if pyproject.exists():
            return self._parse_pyproject_toml(pyproject)
        
        return set()
    
    def _parse_requirements_txt(self, filepath: Path) -> Set[str]:
        """Parse requirements.txt"""
        packages = set()
        
        with open(filepath, 'r') as f:
            for line in f:
                line = line.strip()
                
                # Skip comments and empty lines
                if not line or line.startswith('#'):
                    continue
                
                # Handle different formats:
                # package==1.0.0
                # package>=1.0.0
                # package~=1.0.0
                # package
                match = re.match(r'^([a-zA-Z0-9_-]+)', line)
                if match:
                    package = match.group(1).lower().replace('-', '_')
                    packages.add(package)
        
        return packages
    
    def _parse_pyproject_toml(self, filepath: Path) -> Set[str]:
        """Parse pyproject.toml (basic support)"""
        packages = set()
        
        try:
            import tomli
        except ImportError:
            try:
                import tomllib as tomli
            except ImportError:
                # Can't parse toml without library
                return packages
        
        with open(filepath, 'rb') as f:
            data = tomli.load(f)
        
        # Poetry dependencies
        if 'tool' in data and 'poetry' in data['tool']:
            deps = data['tool']['poetry'].get('dependencies', {})
            for package in deps.keys():
                if package != 'python':
                    packages.add(package.lower().replace('-', '_'))
        
        # PEP 621 dependencies
        if 'project' in data:
            deps = data['project'].get('dependencies', [])
            for dep in deps:
                match = re.match(r'^([a-zA-Z0-9_-]+)', dep)
                if match:
                    package = match.group(1).lower().replace('-', '_')
                    packages.add(package)
        
        return packages

class PhantomDependencyDetector:
    """Detects phantom dependencies and other import/manifest discrepancies"""
    
    def __init__(self, app_dir: Path, sbom_file: Optional[Path] = None):
        self.app_dir = Path(app_dir)
        self.sbom_file = sbom_file
    
    def analyze(self) -> ImportAnalysis:
        """
        Perform comprehensive import vs. manifest analysis
        
        Returns:
            ImportAnalysis with all discrepancies identified
        """
        # Scan actual imports
        scanner = ImportScanner(self.app_dir)
        imports_by_file = scanner.scan_directory()
        imports_found = scanner.all_imports
        
        # Parse manifest
        parser = ManifestParser(self.app_dir)
        manifest_packages = parser.parse()
        
        # Normalize package names (handle common variations)
        manifest_normalized = self._normalize_package_names(manifest_packages)
        imports_normalized = self._normalize_package_names(imports_found)
        
        # Find discrepancies
        phantom = imports_normalized - manifest_normalized
        dead = manifest_normalized - imports_normalized
        
        # Identify shadow imports (requires SBOM for transitive deps)
        shadow = self._identify_shadow_imports(phantom, manifest_normalized)
        
        # Remove shadow imports from phantoms (they're a different category)
        true_phantoms = phantom - shadow
        
        # Assess risk levels
        phantom_risk = self._assess_phantom_risk(true_phantoms)
        shadow_risk = self._assess_shadow_risk(shadow)
        dead_risk = self._assess_dead_risk(dead)
        
        # Build detailed reports
        phantom_details = self._build_phantom_details(true_phantoms, imports_by_file)
        shadow_details = self._build_shadow_details(shadow, imports_by_file)
        dead_details = self._build_dead_details(dead)
        
        return ImportAnalysis(
            imports_found=imports_found,
            imports_by_file=imports_by_file,
            manifest_packages=manifest_packages,
            phantom_dependencies=true_phantoms,
            shadow_imports=shadow,
            dead_dependencies=dead,
            phantom_risk=phantom_risk,
            shadow_risk=shadow_risk,
            dead_risk=dead_risk,
            phantom_details=phantom_details,
            shadow_details=shadow_details,
            dead_details=dead_details
        )
    
    def _normalize_package_names(self, packages: Set[str]) -> Set[str]:
        """Normalize package names for comparison"""
        normalized = set()
        for pkg in packages:
            # Convert to lowercase, replace hyphens with underscores
            norm = pkg.lower().replace('-', '_')
            normalized.add(norm)
        return normalized
    
    def _identify_shadow_imports(
        self, 
        phantom_deps: Set[str],
        manifest_packages: Set[str]
    ) -> Set[str]:
        """
        Identify shadow imports (transitive deps imported directly)
        
        Requires SBOM to know full dependency tree
        """
        if not self.sbom_file or not Path(self.sbom_file).exists():
            return set()
        
        try:
            import json
            with open(self.sbom_file, 'r') as f:
                sbom = json.load(f)
            
            # Get all packages in SBOM (includes transitives)
            all_sbom_packages = set()
            for artifact in sbom.get('artifacts', []):
                pkg_name = artifact.get('name', '').lower().replace('-', '_')
                if pkg_name:
                    all_sbom_packages.add(pkg_name)
            
            # Shadow imports are:
            # - In phantom_deps (not in manifest)
            # - BUT in SBOM (installed as transitive)
            shadow = phantom_deps & all_sbom_packages
            
            return shadow
        
        except Exception:
            return set()
    
    def _assess_phantom_risk(self, phantoms: Set[str]) -> str:
        """Assess risk level of phantom dependencies"""
        count = len(phantoms)
        if count == 0:
            return "NONE"
        elif count >= 5:
            return "CRITICAL"
        elif count >= 3:
            return "HIGH"
        elif count >= 1:
            return "MEDIUM"
        else:
            return "LOW"
    
    def _assess_shadow_risk(self, shadow: Set[str]) -> str:
        """Assess risk level of shadow imports"""
        count = len(shadow)
        if count == 0:
            return "NONE"
        elif count >= 5:
            return "HIGH"
        elif count >= 2:
            return "MEDIUM"
        else:
            return "LOW"
    
    def _assess_dead_risk(self, dead: Set[str]) -> str:
        """Assess risk level of dead dependencies"""
        count = len(dead)
        if count == 0:
            return "NONE"
        elif count >= 10:
            return "MEDIUM"
        else:
            return "LOW"
    
    def _build_phantom_details(
        self,
        phantoms: Set[str],
        imports_by_file: Dict[str, Set[str]]
    ) -> List[Dict]:
        """Build detailed report for phantom dependencies"""
        details = []
        
        for pkg in phantoms:
            # Find which files import this package
            files = [
                filepath for filepath, imports in imports_by_file.items()
                if pkg in {i.lower().replace('-', '_') for i in imports}
            ]
            
            details.append({
                'package': pkg,
                'risk': 'CRITICAL',
                'reason': 'Imported in code but NOT in requirements.txt',
                'impact': 'SCA tools will not scan for CVEs in this package',
                'files': files,
                'recommendation': f'Add {pkg} to requirements.txt'
            })
        
        return details
    
    def _build_shadow_details(
        self,
        shadow: Set[str],
        imports_by_file: Dict[str, Set[str]]
    ) -> List[Dict]:
        """Build detailed report for shadow imports"""
        details = []
        
        for pkg in shadow:
            files = [
                filepath for filepath, imports in imports_by_file.items()
                if pkg in {i.lower().replace('-', '_') for i in imports}
            ]
            
            details.append({
                'package': pkg,
                'risk': 'HIGH',
                'reason': 'Importing transitive dependency directly',
                'impact': 'Will break if parent dependency removed',
                'files': files,
                'recommendation': f'Add {pkg} explicitly to requirements.txt'
            })
        
        return details
    
    def _build_dead_details(self, dead: Set[str]) -> List[Dict]:
        """Build detailed report for dead dependencies"""
        details = []
        
        for pkg in dead:
            details.append({
                'package': pkg,
                'risk': 'LOW',
                'reason': 'In requirements.txt but NEVER imported',
                'impact': 'Unnecessary CVE alerts (alert fatigue)',
                'recommendation': f'Remove {pkg} from requirements.txt (if truly unused)'
            })
        
        return details

def analyze_import_manifest_discrepancies(
    app_dir: str,
    sbom_file: Optional[str] = None
) -> ImportAnalysis:
    """
    Main entry point for import/manifest analysis
    
    Args:
        app_dir: Application directory to scan
        sbom_file: Optional SBOM file for transitive dependency detection
    
    Returns:
        ImportAnalysis with all discrepancies
    """
    detector = PhantomDependencyDetector(
        app_dir=Path(app_dir),
        sbom_file=Path(sbom_file) if sbom_file else None
    )
    
    return detector.analyze()

if __name__ == '__main__':
    import sys
    
    if len(sys.argv) < 2:
        print("Usage: python import_scanner.py <app_directory> [sbom.json]")
        sys.exit(1)
    
    app_dir = sys.argv[1]
    sbom_file = sys.argv[2] if len(sys.argv) > 2 else None
    
    print("=" * 70)
    print("IMPORT vs. MANIFEST ANALYSIS")
    print("=" * 70)
    print()
    
    analysis = analyze_import_manifest_discrepancies(app_dir, sbom_file)
    
    print(f"📦 Packages in manifest: {len(analysis.manifest_packages)}")
    print(f"📥 Packages imported in code: {len(analysis.imports_found)}")
    print()
    
    # PHANTOM DEPENDENCIES (CRITICAL)
    if analysis.phantom_dependencies:
        print(f"🚨 PHANTOM DEPENDENCIES ({analysis.phantom_risk}): {len(analysis.phantom_dependencies)}")
        print("   → These are imported but NOT in requirements.txt")
        print("   → SCA tools WILL NOT scan them for CVEs!")
        print()
        for detail in analysis.phantom_details:
            print(f"   💀 {detail['package']}")
            print(f"      Impact: {detail['impact']}")
            print(f"      Files: {', '.join(detail['files'][:3])}")
            print(f"      Fix: {detail['recommendation']}")
            print()
    
    # SHADOW IMPORTS (HIGH)
    if analysis.shadow_imports:
        print(f"⚠️  SHADOW IMPORTS ({analysis.shadow_risk}): {len(analysis.shadow_imports)}")
        print("   → Importing transitive dependencies directly")
        print("   → Will break if parent dependency removed!")
        print()
        for detail in analysis.shadow_details:
            print(f"   🎭 {detail['package']}")
            print(f"      Impact: {detail['impact']}")
            print(f"      Fix: {detail['recommendation']}")
            print()
    
    # DEAD DEPENDENCIES (LOW)
    if analysis.dead_dependencies:
        print(f"📦 DEAD DEPENDENCIES ({analysis.dead_risk}): {len(analysis.dead_dependencies)}")
        print("   → In requirements.txt but NEVER imported")
        print("   → Causes alert fatigue from unused CVEs")
        print()
        for detail in analysis.dead_details[:5]:
            print(f"   ⚪ {detail['package']}")
        if len(analysis.dead_dependencies) > 5:
            print(f"   ... and {len(analysis.dead_dependencies) - 5} more")
        print()
    
    # Summary
    print("=" * 70)
    print("SUMMARY")
    print("=" * 70)
    print()
    print(f"✅ Clean imports (in both manifest and code): {len(analysis.manifest_packages & analysis.imports_found)}")
    print(f"🚨 CRITICAL: {len(analysis.phantom_dependencies)} phantom dependencies")
    print(f"⚠️  HIGH: {len(analysis.shadow_imports)} shadow imports")
    print(f"ℹ️  INFO: {len(analysis.dead_dependencies)} dead dependencies")
    print()
    
    if analysis.phantom_dependencies or analysis.shadow_imports:
        print("⚠️  ACTION REQUIRED:")
        print("   1. Add all phantom dependencies to requirements.txt")
        print("   2. Explicitly declare shadow imports")
        print("   3. Re-run SCA scan to check for CVEs in phantom deps")
