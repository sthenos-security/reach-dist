# Auto-generated at build time - DO NOT EDIT
__version__ = "1.0.0b11.dev0+nogit.root"
