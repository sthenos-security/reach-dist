# Copyright © 2026 Sthenos Security. All rights reserved.

"""
REACHABLE - Vulnerability Exploitability & Reachability Assessment
"""

import subprocess
from pathlib import Path


def _get_version() -> str:
    """Read version — single source of truth is VERSION file (or wheel metadata when installed)"""
    # Priority 1: importlib.metadata (installed wheel — wheel was built from VERSION)
    try:
        from importlib.metadata import version

        v = version("reachable")
        if v and v != "0.0.0":
            return v
    except Exception:
        pass

    # Priority 2: VERSION file (dev/editable mode)
    for candidate in [
        Path(__file__).parent / "VERSION",  # inside package (if copied by setup)
        Path(__file__).parent.parent / "VERSION",  # repo root
    ]:
        if candidate.exists():
            return candidate.read_text(encoding="utf-8").strip()

    return "0.0.0"


def _get_git_info() -> dict:
    """
    Get git commit info: sha, date, branch.
    Returns dict with keys: sha, date, branch (any may be None)
    """
    info = {"sha": None, "date": None, "branch": None}

    # Check for GIT_INFO file (baked into wheel by CI/CD)
    git_info_file = Path(__file__).parent / "GIT_INFO"
    if git_info_file.exists():
        for line in git_info_file.read_text().strip().split("\n"):
            if "=" in line:
                k, v = line.split("=", 1)
                info[k.strip().lower()] = v.strip()
        return info

    # Dev mode - get from git
    repo_root = Path(__file__).parent.parent
    try:
        # Short SHA
        result = subprocess.run(
            ["git", "rev-parse", "--short", "HEAD"], capture_output=True, text=True, cwd=repo_root, timeout=5
        )
        if result.returncode == 0:
            info["sha"] = result.stdout.strip()

        # Commit date
        result = subprocess.run(
            ["git", "log", "-1", "--format=%cd", "--date=short"],
            capture_output=True,
            text=True,
            cwd=repo_root,
            timeout=5,
        )
        if result.returncode == 0:
            info["date"] = result.stdout.strip()

        # Branch
        result = subprocess.run(
            ["git", "rev-parse", "--abbrev-ref", "HEAD"],
            capture_output=True,
            text=True,
            cwd=repo_root,
            timeout=5,
        )
        if result.returncode == 0:
            info["branch"] = result.stdout.strip()
    except Exception:
        pass

    return info


def _get_build_date() -> str:
    """Get CI/CD build date if available (wheel only)"""
    build_date_file = Path(__file__).parent / "BUILD_DATE"
    if build_date_file.exists():
        return build_date_file.read_text().strip()
    return None


__version__ = _get_version()
__build_date__ = _get_build_date()

# Lazily populated — avoids 3x subprocess.run() git calls at every import
_git_info_cache = None

def _lazy_git_info() -> dict:
    global _git_info_cache
    if _git_info_cache is None:
        _git_info_cache = _get_git_info()
    return _git_info_cache

# Keep __git_info__ as a property-like accessor; callers that do
# `from reachable import __git_info__` get the lazy value on first use.
class _LazyGitInfo:
    def __repr__(self): return repr(_lazy_git_info())
    def __getattr__(self, k): return _lazy_git_info().get(k)
    def get(self, k, d=None): return _lazy_git_info().get(k, d)
    def __getitem__(self, k): return _lazy_git_info()[k]
    def __iter__(self): return iter(_lazy_git_info())
    def items(self): return _lazy_git_info().items()

__git_info__ = _LazyGitInfo()
__all__ = ["__version__", "__git_info__", "__build_date__"]
