#!/usr/bin/env python3
# Copyright (c) 2026 Sthenos Security. All rights reserved.

"""
IAC/Config Normalizer

Reads: raw/iac.json  (output of pipeline _step_iac — K8s + Docker Compose scanners)
Produces: findings (type=config)
"""

import hashlib
import logging
from pathlib import Path
from typing import Any, Dict, List

from reachable.database.normalizers.compliance_tags import get_compliance_mapping

logger = logging.getLogger(__name__)

_REACHABILITY = "NOT_APPLICABLE"


def normalize_iac(
    raw_files: Dict[str, Any],
    scan_dir: Path = None,
    call_graph: Dict = None,
    skip_iac: bool = False,
) -> Dict[str, List[Dict]]:
    """
    Normalize IAC/config findings into DB-ready config findings.

    Returns:
        {"config": [<finding dicts>]}
    """
    if skip_iac:
        return {"config": []}

    iac_data = raw_files.get("iac.json")
    if not iac_data or not isinstance(iac_data, dict):
        return {"config": []}

    raw_findings = iac_data.get("findings", [])
    if not raw_findings:
        return {"config": []}

    findings = []
    for raw in raw_findings:
        try:
            f = _normalize_one(raw)
            if f:
                findings.append(f)
        except Exception as e:
            logger.warning(f"IAC normalizer: skipped finding: {e}")
            continue

    logger.info(f"IAC: {len(findings)} config findings normalized")
    return {"config": findings}


def _normalize_one(raw: Dict) -> Dict:
    rule_id     = raw.get("rule_id", "")
    severity    = (raw.get("severity") or "MEDIUM").upper()
    title       = raw.get("title") or rule_id or "IAC misconfiguration"
    description = raw.get("description") or title
    file_path   = raw.get("file_path") or raw.get("file") or ""
    line        = int(raw.get("line_number") or raw.get("line") or 0)
    remediation = raw.get("remediation") or ""
    resource_kind = raw.get("resource_kind") or ""
    resource_name = raw.get("resource_name") or ""
    namespace     = raw.get("namespace") or ""

    if rule_id.startswith("K8S"):
        scanner = "k8s_scanner"
    elif rule_id.startswith("DC") or rule_id.startswith("DOCKER"):
        scanner = "docker_compose"
    else:
        scanner = "iac_scanner"

    # Include resource identity so findings with line=0 don't collide
    finding_id = hashlib.md5(
        f"iac:{rule_id}:{file_path}:{line}:{resource_kind}:{resource_name}:{namespace}".encode()
    ).hexdigest()[:16]

    context_parts = [p for p in (resource_kind, resource_name, f"ns:{namespace}" if namespace else "") if p]
    context_str = " / ".join(context_parts)
    full_description = f"[{context_str}] {description}" if context_str else description
    if remediation:
        full_description += f"\nRemediation: {remediation}"

    if severity not in ("CRITICAL", "HIGH", "MEDIUM", "LOW"):
        severity = "MEDIUM"

    return {
        "id":                      finding_id,
        "finding_type":            "config",
        "severity":                severity,
        "risk_level":              severity,
        "title":                   title[:500],
        "description":             full_description[:1000],
        "rule_id":                 rule_id,
        "package":                 "",
        "package_name":            "",
        "file":                    file_path,
        "file_path":               file_path,
        "line":                    line,
        "line_number":             line,
        "scanner":                 scanner,
        "resource_kind":           resource_kind,
        "resource_name":           resource_name,
        "namespace":               namespace,
        "remediation":             remediation[:500],
        "app_reachability":        _REACHABILITY,
        "reachability_state":      "not_applicable",
        "reachability_confidence": "N/A",
        "call_paths_v2":           [],
        "compliance_mapping":      get_compliance_mapping("config", {}),
    }
