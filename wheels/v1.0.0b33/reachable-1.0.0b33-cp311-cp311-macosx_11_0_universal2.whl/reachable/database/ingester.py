#!/usr/bin/env python3
# Copyright (c) 2026 Sthenos Security. All rights reserved.

"""
REACHABLE v5.1.3 - Ingester Module

Single code path: raw scanner files -> normalize -> DB.

Design principles (db_source_of_truth_design.md):
  1. Collectors NEVER write to DB
  2. Ingester is ONLY code path that writes findings to DB
  3. All downstream consumers read from DB only

Usage:
    from reachable.database.ingester import ingest
    result = ingest(scan_dir, db, scan_id)

    # Re-ingestion (after normalizer fix):
    from reachable.database.ingester import reingest
    result = reingest(scan_dir, db_path, scan_id=47)
"""

import gzip
import json
import logging
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional

from reachable.database.normalizers.ai import normalize_ai

# Normalizers - each handles one raw file type
from reachable.database.normalizers.cve import normalize_cves
from reachable.database.normalizers.dlp import normalize_dlp
from reachable.database.normalizers.iac import normalize_iac
from reachable.database.normalizers.malware import normalize_malware
from reachable.database.normalizers.sandbox import normalize_sandbox
from reachable.database.normalizers.semgrep import (
    enrich_cwe_with_containing_function,
    enrich_secret_reachability,
    normalize_semgrep,
)
from reachable.database.storage import RepoDatabase

logger = logging.getLogger(__name__)


@dataclass
class IngestResult:
    """Result of ingestion - counts per finding type."""

    scan_id: int = 0
    cve_count: int = 0
    cwe_count: int = 0
    config_count: int = 0
    secret_count: int = 0
    malware_count: int = 0
    suspicious_count: int = 0
    ai_count: int = 0
    dlp_count: int = 0
    errors: List[str] = field(default_factory=list)
    duration_seconds: float = 0.0

    @property
    def total(self) -> int:
        return (
            self.cve_count
            + self.cwe_count
            + self.config_count
            + self.secret_count
            + self.malware_count
            + self.suspicious_count
            + self.ai_count
            + self.dlp_count
        )

    @property
    def ok(self) -> bool:
        return len(self.errors) == 0

    def to_dict(self) -> Dict[str, Any]:
        return {
            "scan_id": self.scan_id,
            "total": self.total,
            "by_type": {
                "cve": self.cve_count,
                "cwe": self.cwe_count,
                "config": self.config_count,
                "secret": self.secret_count,
                "malware": self.malware_count,
                "suspicious": self.suspicious_count,
                "ai": self.ai_count,
                "dlp": self.dlp_count,
            },
            "errors": self.errors,
            "duration_seconds": self.duration_seconds,
        }


# ==========================================================================
# RAW FILE REGISTRY
# ==========================================================================
# Maps raw file names to normalizer functions.
# Order matters: CVEs first (most critical), then CWE/secrets, then security.

RAW_FILE_REGISTRY = [
    {
        "files": ["cve-analyzed.json", "reachable-report.json.gz", "reachable-report.json"],
        "normalizer": normalize_cves,
        "types": ["cve"],
        "description": "CVE vulnerabilities with reachability from analysis",
    },
    {
        "files": ["security-findings.json"],
        "normalizer": normalize_semgrep,
        "types": ["cwe", "secret", "config"],
        "description": "CWE/secret/config findings from Semgrep",
    },
    {
        "files": ["malware.json", "static-malware-extracted.json"],
        "normalizer": normalize_malware,
        "types": ["malware", "suspicious"],
        "description": "Static malware from GuardDog + YARA",
        "audit_label": "malware_sast",  # BUG-A1: separate audit row from sandbox
    },
    {
        "files": ["ai-security.json"],
        "normalizer": normalize_ai,
        "types": ["ai"],
        "description": "AI/LLM security (OWASP LLM Top 10)",
    },
    {
        "files": ["dlp-security.json"],
        "normalizer": normalize_dlp,
        "types": ["dlp"],
        "description": "DLP/PII data exposure",
    },
    {
        "files": ["sandbox.json", "sandbox-extracted.json"],
        "normalizer": normalize_sandbox,
        "types": ["malware", "suspicious"],
        "description": "Dynamic sandbox analysis",
        "audit_label": "malware_sandbox",  # BUG-A1: separate audit row from SAST
    },
    {
        "files": ["iac.json"],
        "normalizer": normalize_iac,
        "types": ["config"],
        "description": "IAC/config findings from K8s/Docker scanners",
    },
]


def _load_raw_file(filepath: Path) -> Optional[Dict]:
    """Load a raw JSON file (handles .gz compression)."""
    if not filepath.exists():
        return None
    try:
        if str(filepath).endswith(".gz"):
            with gzip.open(filepath, "rt") as f:
                return json.load(f)
        else:
            with open(filepath) as f:
                return json.load(f)
    except (json.JSONDecodeError, OSError) as e:
        logger.error(f"Failed to load {filepath}: {e}")
        return None


def _find_raw_files(scan_dir: Path, entry: Dict) -> Dict[str, Any]:
    """Find raw files for a registry entry. Returns {filename: data}."""
    raw_dir = scan_dir / "raw"
    found = {}

    for filename in entry["files"]:
        if entry.get("search_parent"):
            filepath = scan_dir / filename
        else:
            filepath = raw_dir / filename

        # Also check .gz extension
        if not filepath.exists():
            filepath_gz = filepath.with_suffix(filepath.suffix + ".gz")
            if filepath_gz.exists():
                filepath = filepath_gz

        if filepath.exists():
            data = _load_raw_file(filepath)
            if data is not None:
                found[filename] = data

    return found


def ingest(
    scan_dir: Path,
    db: RepoDatabase,
    scan_id: Optional[int] = None,
    call_graph: Optional[Dict] = None,
    skip_iac: bool = False,
) -> IngestResult:
    """
    Ingest raw scanner files into the database.

    This is the ONLY code path that writes findings to the DB.

    Args:
        scan_dir: Scan output directory (contains raw/*.json files)
        db: RepoDatabase instance (scan already started)
        scan_id: Override db._current_scan_id (for re-ingestion)
        call_graph: Optional pre-loaded call graph for reachability hints
        skip_iac: If True, drop all config/IaC findings (--skip-iac flag)

    Returns:
        IngestResult with counts and errors
    """
    start_time = time.time()
    result = IngestResult()

    if scan_id is not None:
        db._current_scan_id = scan_id
    result.scan_id = db._current_scan_id or 0

    if not result.scan_id:
        result.errors.append("No scan_id - call db.start_scan() first")
        return result

    scan_dir = Path(scan_dir)
    if not scan_dir.exists():
        result.errors.append(f"Scan directory not found: {scan_dir}")
        return result

    logger.info(f"Ingesting scan {result.scan_id} from {scan_dir}")

    # Process each raw file type
    for entry in RAW_FILE_REGISTRY:
        raw_files = _find_raw_files(scan_dir, entry)

        if not raw_files:
            logger.debug(f"No files found for {entry['description']}")
            continue

        try:
            normalizer = entry["normalizer"]
            description = entry["description"]
            audit_label = entry.get("audit_label")  # BUG-A1: per-scanner audit row label

            logger.info(f"  Normalizing: {description} ({len(raw_files)} files)")

            # Call normalizer - returns {finding_type: [findings]}
            # v5.1.3: Pass skip_iac to semgrep normalizer
            kwargs = dict(scan_dir=scan_dir, call_graph=call_graph)
            if normalizer in (normalize_semgrep, normalize_iac):
                kwargs["skip_iac"] = skip_iac
            normalized = normalizer(raw_files, **kwargs)

            # T-CG8/9: Post-normalization enrichment for semgrep findings
            if normalizer == normalize_semgrep:
                try:
                    _repo_path = None
                    _sess_path = scan_dir / ".session.json"
                    if _sess_path.exists():
                        import json as _j

                        _repo_path = _j.loads(_sess_path.read_text()).get("repo_path")
                    if _repo_path:
                        # T-CG9: Secret Level 1 — confirm file is actually read at runtime
                        if normalized.get("secret"):
                            normalized["secret"] = enrich_secret_reachability(normalized["secret"], _repo_path)
                        # T-CG8: CWE — attach containing function + entrypoint BFS path
                        if normalized.get("cwe"):
                            normalized["cwe"] = enrich_cwe_with_containing_function(
                                normalized["cwe"], call_graph or {}, _repo_path
                            )
                except Exception as _enrich_ex:
                    logger.warning(f"CG8/9 enrichment failed (non-fatal): {_enrich_ex}")

            # Store each finding type
            for finding_type, findings in normalized.items():
                if not findings:
                    continue

                if finding_type == "ai":
                    stored = db.store_ai_findings(findings)
                    result.ai_count += stored
                elif finding_type == "dlp":
                    stored = db.store_dlp_findings(findings)
                    result.dlp_count += stored
                else:
                    # FIX: CVE findings from normalize_cves() never went through
                    # threat intel enrichment (enrich_findings is only called in
                    # the legacy store_cves() path which the ingester doesn't use).
                    # Enrich here before storing so go_vuln_id/epss/kev are populated.
                    if finding_type == "cve":
                        try:
                            from reachable.enrichment.threat_intel import enrich_findings

                            for _f in findings:
                                _f.setdefault("finding_type", "cve")
                            findings = enrich_findings(findings)
                            _go_ids = [f.get("go_vuln_id") for f in findings if f.get("go_vuln_id")]
                            logger.info(f" Enrichment: {len(findings)} CVEs, {len(_go_ids)} GO-aliases")
                        except Exception as _enrich_err:
                            logger.warning(f"Threat intel enrichment failed (non-fatal): {_enrich_err}")
                    stored = db.store_findings(findings, finding_type, audit_type=audit_label)

                    if finding_type == "cve":
                        result.cve_count += stored
                    elif finding_type == "cwe":
                        result.cwe_count += stored
                    elif finding_type == "config":
                        result.config_count += stored
                    elif finding_type == "secret":
                        result.secret_count += stored
                    elif finding_type == "malware":
                        result.malware_count += stored
                    elif finding_type == "suspicious":
                        result.suspicious_count += stored

                logger.info(f"    Stored {stored} {finding_type} findings")

        except Exception as e:
            error_msg = f"Error normalizing {entry['description']}: {e}"
            logger.error(error_msg)
            result.errors.append(error_msg)
            continue

    # --- Sub-module ownership enrichment for transitive CVE findings ---
    # In monorepos, the engine only knows the repo root. Walk go.mod files to
    # build a map of {dep_module -> owning_sub_module} so dependency_chain
    # shows the correct intermediate module (e.g. saml-bridge → crewjam/saml).
    try:
        session_path = scan_dir / ".session.json"
        if session_path.exists():
            import json as _json2
            import re as _re2

            _sess2 = _json2.loads(session_path.read_text())
            _project_root = _sess2.get("repo_path")
            if _project_root:
                import os as _os2
                from pathlib import Path as _Path2

                _root = _Path2(_project_root)
                _EXCL = {"vendor", "node_modules", ".git", "__pycache__", "dist", "build"}
                # Map: canonical_dep_module -> owning_sub_module_name
                _dep_to_owner: dict = {}
                for _dirpath, _dirnames, _fnames in _os2.walk(_root):
                    _dirnames[:] = [d for d in _dirnames if d not in _EXCL and not d.startswith(".")]
                    if "go.mod" not in _fnames:
                        continue
                    _gmod = _Path2(_dirpath) / "go.mod"
                    if _Path2(_dirpath) == _root:
                        continue  # skip root — that IS "your project"
                    try:
                        _text = _gmod.read_text(errors="ignore")
                        # Get the module name for this sub-module
                        _mod_match = _re2.search(r"^module\s+(\S+)", _text, _re2.MULTILINE)
                        if not _mod_match:
                            continue
                        _owner_module = _mod_match.group(1)
                        # Use relative filesystem path (e.g. "api/auth/saml-bridge") —
                        # more informative than just the module name tail.
                        _owner_short = str(_Path2(_dirpath).relative_to(_root))
                        # Extract all require'd deps (versioned) from this go.mod
                        for _req in _re2.finditer(r"^\s+(\S+)\s+v[\d]", _text, _re2.MULTILINE):
                            _dep = _req.group(1)
                            # Only map if not already claimed by a more specific owner
                            if _dep not in _dep_to_owner:
                                _dep_to_owner[_dep] = (_owner_short, _owner_module)
                        # Also parse 'replace' directives — local path replacements
                        # have no version in require (e.g. github.com/crewjam/saml => ./third_party/...)
                        # so they never appear in the versioned require scan above.
                        for _rep in _re2.finditer(r"^\s+(\S+)(?:\s+v\S+)?\s*=>\s*(\S+)", _text, _re2.MULTILINE):
                            _dep = _rep.group(1)
                            if _dep not in _dep_to_owner:
                                _dep_to_owner[_dep] = (_owner_short, _owner_module)
                    except Exception as _gmod_err:
                        logger.debug(f"  go.mod parse skipped ({_gmod.name}): {_gmod_err}")
                        continue

                # Now post-process transitive CVE findings in the DB
                if _dep_to_owner and db.conn:
                    _cur2 = db.conn.cursor()
                    _cur2.execute(
                        "SELECT finding_id, via_package, dependency_chain FROM findings "
                        "WHERE scan_id=? AND is_transitive=1 AND finding_type='cve'",
                        (result.scan_id,),
                    )
                    _rows = _cur2.fetchall()
                    _updated = 0
                    for _fid, _via, _chain_json in _rows:
                        if not _via:
                            continue
                        # Try to match via_package to a dep in _dep_to_owner.
                        # via_package may be "crewjam/saml" (owner/repo) while the
                        # canonical module key is "github.com/crewjam/saml".
                        # Match strategies (in order of specificity):
                        #   1. Exact canonical match: "github.com/crewjam/saml" == dep
                        #   2. Suffix match:          dep ends with "/crewjam/saml"
                        #   3. Dash-to-slash variant: "crewjam-saml" -> "crewjam/saml"
                        #   4. Tail-only match (last resort): dep last segment == via last segment
                        _via_norm = _via.replace("/", "-")  # crewjam/saml  -> crewjam-saml
                        _via_slash = _via.replace("-", "/")  # crewjam-saml  -> crewjam/saml
                        _via_tail = _via.split("/")[-1]  # crewjam/saml  -> saml
                        _owner = None
                        for _dep, (_oshort, _ofull) in _dep_to_owner.items():
                            _dep_tail = _dep.split("/")[-1]
                            if (
                                _dep == _via  # exact match
                                or _dep.endswith("/" + _via)  # github.com/owner/repo ends with /via
                                or _dep == _via_slash  # crewjam-saml -> crewjam/saml
                                or _dep.endswith("/" + _via_slash)
                                or _dep_tail == _via_norm  # saml == crewjam-saml? (loose)
                                or _dep_tail == _via_tail
                            ):  # saml == saml (last resort)
                                _owner = _oshort
                                break
                        if not _owner:
                            continue
                        # Build 4-hop chain: your project → owning_sub → via_pkg → vuln_pkg
                        try:
                            _chain = _json2.loads(_chain_json) if _chain_json else []
                        except Exception as _chain_err:
                            logger.debug(f"  dependency_chain JSON parse failed (finding {_fid}): {_chain_err}")
                            _chain = []
                        if len(_chain) >= 1 and _owner not in _chain:
                            _vuln_pkg = _chain[-1] if _chain else ""
                            # chain from cve.py is already [via, vuln_pkg] (no 'app' prefix)
                            # template prepends 'your project', so final display is:
                            # your project → api/auth/saml-bridge → crewjam/saml → golang.org/x/crypto
                            _new_chain = [_owner, _via, _vuln_pkg] if _vuln_pkg else _chain
                            _cur2.execute(
                                "UPDATE findings SET dependency_chain=? WHERE finding_id=? AND scan_id=?",
                                (_json2.dumps(_new_chain), _fid, result.scan_id),
                            )
                            _updated += 1
                    if _updated:
                        db.conn.commit()
                        logger.info(f"  Sub-module enrichment: {_updated} dependency chains updated")
    except Exception as _sub_err:
        logger.warning(f"Sub-module enrichment failed (non-fatal): {_sub_err}")

    result.duration_seconds = time.time() - start_time

    logger.info(
        f"Ingestion complete: {result.total} findings "
        f"({result.cve_count} CVE, {result.cwe_count} CWE, "
        f"{result.secret_count} secret, {result.config_count} config, "
        f"{result.malware_count} malware, {result.suspicious_count} suspicious, "
        f"{result.ai_count} AI, {result.dlp_count} DLP) "
        f"in {result.duration_seconds:.2f}s"
    )

    if result.errors:
        logger.warning(f"Ingestion completed with {len(result.errors)} errors")

    return result


def reingest(scan_dir: Path, db_path: Path, scan_id: int) -> IngestResult:
    """
    Re-ingest a previous scan from raw files (e.g., after normalizer fix).

    Deletes existing findings for the scan_id and re-ingests from raw files.
    Does NOT re-run collectors (Grype, Semgrep, etc.).
    """
    db = RepoDatabase(db_path)

    logger.info(f"Re-ingesting scan {scan_id} from {scan_dir}")
    logger.info("Deleting existing findings...")
    db.conn.execute("DELETE FROM findings WHERE scan_id = ?", (scan_id,))
    db.conn.execute("DELETE FROM ai_findings WHERE scan_id = ?", (scan_id,))
    db.conn.execute("DELETE FROM dlp_findings WHERE scan_id = ?", (scan_id,))
    db.conn.commit()

    db._current_scan_id = scan_id
    result = ingest(scan_dir, db, scan_id=scan_id)

    db.close()
    return result
