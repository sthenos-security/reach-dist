#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.

"""
REACHABLE Logger Module - Backward Compatibility Layer

This module provides backward compatibility for existing code that imports
from reachable.logger. New code should import from reachable.core.logger.

Usage (existing - still works):
    from reachable.logger import logger
    from reachable.logger import get_logger, setup_logger

    logger.info("Starting scan...")
    setup_logger(debug=True)

Usage (new - preferred):
    from reachable.core.logger import get_logger, configure, OutputMode

    configure(mode=OutputMode.CI, timestamps=False)
    logger = get_logger()
    logger.info("Starting scan...")

Migration:
    Old: setup_logger(debug=True)
    New: configure(debug=True)

    Old: setup_logger(debug=False, quiet=True)
    New: configure(quiet=True)
"""

import logging
import sys
from typing import Optional

# Try to import from core, fall back to inline implementation
try:
    from .core.logger import OutputMode as OutputMode
    from .core.logger import ReachableLogger as ReachableLogger
    from .core.logger import configure as _core_configure
    from .core.logger import get_logger as _core_get_logger  # noqa: F401 — re-exports for backward compat

    _USE_CORE = True
except ImportError:
    _USE_CORE = False


# =========================================================================
# Backward Compatibility - Global State
# =========================================================================

_logger: Optional[logging.Logger] = None
_debug_mode: bool = False


def setup_logger(debug: bool = False, quiet: bool = False) -> logging.Logger:
    """
    Configure the global logger.

    DEPRECATED: Use reachable.core.logger.configure() instead.

    Args:
        debug: Enable debug-level logging
        quiet: Suppress info-level messages

    Returns:
        Configured logger instance
    """
    global _logger, _debug_mode

    _debug_mode = debug

    # If core logger is available, delegate entirely to it.
    # Do NOT add any handler here — core.logger.configure() owns the handler.
    # Adding one here causes doubled console output (two handlers on same logger).
    if _USE_CORE:
        _core_configure(
            debug=debug,
            quiet=quiet,
            timestamps=debug,  # Timestamps only in debug mode (original behavior)
        )
        _logger = _core_get_logger()._py_logger
        return _logger

    # Fallback: original implementation (only if core.logger unavailable)
    if _logger is None:
        _logger = logging.getLogger("reachable")

    # Clear existing handlers
    _logger.handlers.clear()

    # Set level
    if debug:
        _logger.setLevel(logging.DEBUG)
    elif quiet:
        _logger.setLevel(logging.WARNING)
    else:
        _logger.setLevel(logging.INFO)

    # Create console handler.
    # Normal: WARNING+ only (INFO goes through the logger directly to stdout).
    # Debug: show all submodule output on stderr for troubleshooting.
    handler = logging.StreamHandler(sys.stderr)
    if debug:
        handler.setLevel(logging.DEBUG)
    else:
        handler.setLevel(logging.WARNING)
    handler.setFormatter(logging.Formatter("%(message)s"))
    _logger.addHandler(handler)

    # Don't propagate to root logger
    _logger.propagate = False

    return _logger


def get_logger(name: Optional[str] = None) -> logging.Logger:
    """
    Get a logger instance.

    Args:
        name: Logger name (typically __name__ of the calling module)

    Returns:
        Logger instance (never None)

    Example:
        logger = get_logger(__name__)
        logger.info("Starting process")
    """
    global _logger

    # Ensure global logger is initialized
    if _logger is None:
        setup_logger()

    # Safety check - fallback to standard logging if still None
    if _logger is None:
        _logger = logging.getLogger("reachable")
        _logger.setLevel(logging.INFO)
        if not _logger.handlers:
            handler = logging.StreamHandler(sys.stderr)
            handler.setLevel(logging.WARNING)
            handler.setFormatter(logging.Formatter("%(message)s"))
            _logger.addHandler(handler)

    # Return module-specific logger if name provided
    if name and name != "reachable":
        # Create child logger
        child_logger = logging.getLogger(f"reachable.{name}")
        child_logger.setLevel(_logger.level)
        return child_logger

    return _logger


# Default logger instance for simple imports
logger = get_logger()


def is_debug() -> bool:
    """Check if debug mode is enabled"""
    return _debug_mode


def set_debug(enabled: bool) -> None:
    """Enable or disable debug mode"""
    global _debug_mode
    _debug_mode = enabled
    if _logger:
        _logger.setLevel(logging.DEBUG if enabled else logging.INFO)


def log_step(step: str, message: str) -> None:
    """Log a scan step with consistent formatting"""
    logger.info(f" {step}: {message}")


def log_error(context: str, error: Exception) -> None:
    """Log an error with context"""
    logger.error(f" {context}: {type(error).__name__}: {error}")


def log_warning(message: str) -> None:
    """Log a warning with emoji"""
    logger.warning(f" {message}")


def log_success(message: str) -> None:
    """Log a success message with emoji"""
    logger.info(f" {message}")


__all__ = [
    "logger",
    "get_logger",
    "setup_logger",
    "is_debug",
    "set_debug",
    "log_step",
    "log_error",
    "log_warning",
    "log_success",
]
