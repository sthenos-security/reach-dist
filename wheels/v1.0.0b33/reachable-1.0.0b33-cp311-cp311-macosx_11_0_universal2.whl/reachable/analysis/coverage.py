#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.

"""
REACHABLE v1.0.0b15 - Scan Coverage Gap Reporter

What every scanner tells you: what it found.
What REACHABLE uniquely tells you: what it did NOT test — and why.

Coverage gap dimensions:
  1. Manifest coverage    — manifest files found vs manifests consumed by Syft/Grype
  2. Language coverage    — languages detected by file extension vs scanners that ran
  3. File coverage        — source files in repo vs files touched by callgraph analysis
  4. Package coverage     — packages in SBOM vs packages with reachability data
  5. Reachability gaps    — CVEs found with no callgraph → "vulnerable but unknown reachability"
  6. Excluded paths       — intentionally skipped dirs (vendor/, tests, generated) with file count
  7. Sub-module gaps      — nested go.mod / package.json files not scanned as roots

Output:
  coverage_report dict (stored in DB + .metadata/08-coverage.json)

  {
    "coverage_score": 0.73,           # 0.0–1.0 overall coverage estimate
    "manifests": {
      "found": [...],                 # All manifests discovered in repo
      "scanned": [...],               # Manifests Syft/Grype consumed
      "skipped": [...],               # Found but not consumed (with reason)
    },
    "languages": {
      "detected": {"go": 47, "python": 12, "js": 3},     # by file count
      "analyzed": {"go": True, "python": False},          # scanner ran?
      "gaps": [{"language": "python", "files": 12, "reason": "no Python scanner in plan"}],
    },
    "packages": {
      "total_in_sbom": 88,
      "with_reachability": 23,
      "without_reachability": 65,
      "reachability_coverage_pct": 26,
    },
    "reachability_blind_spots": [
      {"package": "golang.org/x/net", "cve_count": 3, "reason": "no callgraph for Go stdlib deps"},
    ],
    "excluded_paths": [
      {"path": "vendor/", "reason": "vendor dir", "file_count": 312, "size_kb": 4200},
      {"path": "mock_client.go", "reason": "mock file pattern", "file_count": 1},
    ],
    "sub_modules": [
      {"path": "services/auth/go.mod", "module": "github.com/acme/auth", "scanned": False},
    ],
    "recommendations": [
      "Add Python scanner to analyze 12 .py files in scripts/",
      "3 sub-modules in services/ were not scanned — run reachctl scan on each",
    ],
  }
"""

import json
import logging
import os
import re
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Tuple

logger = logging.getLogger(__name__)

# Lazy scan_log helper — same pattern as correlation/engine.py (LOG-01 fix)
try:
    from reachable.core.logger import get_logger as _get_scan_log

    _scan_log_ok = True
except Exception:
    _scan_log_ok = False


def _slog(msg: str, level: str = "INFO") -> None:
    if _scan_log_ok:
        try:
            _get_scan_log()._write(msg, level=level)
            return
        except Exception:
            pass
    logger.info(msg)


# ---------------------------------------------------------------------------
# Constants — manifest file patterns per ecosystem
# ---------------------------------------------------------------------------

MANIFEST_PATTERNS: Dict[str, List[str]] = {
    "go": ["go.mod"],
    "python": [
        "requirements.txt",
        "requirements*.txt",
        "pyproject.toml",
        "setup.py",
        "setup.cfg",
        "Pipfile",
        "Pipfile.lock",
    ],
    "javascript": ["package.json", "package-lock.json", "yarn.lock", "pnpm-lock.yaml"],
    "java": ["pom.xml", "build.gradle", "build.gradle.kts", "*.gradle"],
    "rust": ["Cargo.toml", "Cargo.lock"],
    "ruby": ["Gemfile", "Gemfile.lock"],
    "dotnet": ["*.csproj", "*.fsproj", "*.vbproj", "packages.config", "paket.dependencies"],
    "php": ["composer.json", "composer.lock"],
}

# Source file extensions per language (for language detection)
SOURCE_EXTENSIONS: Dict[str, List[str]] = {
    "go": [".go"],
    "python": [".py"],
    "javascript": [".js", ".jsx", ".ts", ".tsx", ".mjs", ".cjs"],
    "java": [".java", ".kt", ".scala"],
    "rust": [".rs"],
    "ruby": [".rb"],
    "dotnet": [".cs", ".fs", ".vb"],
    "php": [".php"],
}

# Directories always excluded from analysis (and why)
EXCLUDED_DIR_PATTERNS: Dict[str, str] = {
    "vendor": "Go vendor directory — dependencies, not source",
    "node_modules": "npm package directory — use SBOM instead",
    ".git": "Git internal directory",
    "__pycache__": "Python bytecode cache",
    ".pytest_cache": "pytest cache",
    "dist": "Build output",
    "build": "Build output",
    "target": "Java/Rust build output",
    ".gradle": "Gradle cache",
    "coverage": "Test coverage output",
    "htmlcov": "Python coverage HTML",
    ".tox": "tox virtualenv",
    "venv": "Python virtualenv",
    ".venv": "Python virtualenv",
    "env": "Python virtualenv",
}

# File patterns excluded from callgraph analysis (and why)
EXCLUDED_FILE_PATTERNS: Dict[str, str] = {
    r"_test\.go$": "Go test file",
    r"\.pb\.go$": "Protobuf generated file",
    r"mock_.*\.go$": "Mock file",
    r".*_mock\.go$": "Mock file",
    r".*_gen\.go$": "Generated file",
    r"\.min\.js$": "Minified JavaScript",
    r"\.d\.ts$": "TypeScript declaration file",
    r"test_.*\.py$": "Python test file",
    r".*_test\.py$": "Python test file",
    r"conftest\.py$": "pytest config file",
}


# ---------------------------------------------------------------------------
# Data classes
# ---------------------------------------------------------------------------


@dataclass
class ManifestGap:
    path: str
    ecosystem: str
    reason: str  # why it was skipped
    is_sub_module: bool = False
    module_name: str = ""


@dataclass
class LanguageGap:
    language: str
    file_count: int
    example_files: List[str]
    reason: str


@dataclass
class ReachabilityBlindSpot:
    package: str
    version: str
    cve_ids: List[str]
    severity: str
    reason: str  # why reachability is unknown


@dataclass
class ExcludedPath:
    path: str  # relative to project root
    reason: str
    file_count: int
    size_kb: int
    source: str = "built-in"  # "built-in" | "user-config"
    exclude_file: str = ""  # absolute path to the exclude file that caused this, empty for built-in


@dataclass
class CoverageReport:
    project_path: str
    scan_id: str
    generated_at: str

    # Overall score
    coverage_score: float  # 0.0–1.0

    # Dimension breakdowns
    manifests_found: List[str]
    manifests_scanned: List[str]
    manifests_skipped: List[ManifestGap]

    language_detected: Dict[str, int]  # {lang: file_count}
    language_analyzed: Dict[str, bool]
    language_gaps: List[LanguageGap]

    # File-level counts
    files_total: int  # source files found (after dir exclusions)
    files_analyzed: int  # source files actually passed to callgraph
    files_excluded_patterns: int  # skipped by pattern (tests, generated, mocks)
    files_excluded_dirs: int  # in excluded dirs (vendor, node_modules, etc.)

    packages_total: int
    packages_with_reachability: int

    # Phase 5: Private registry coverage dimension
    registry_coverage: Dict[
        str, Any
    ]  # {total, canonical, hash_match, alias, internal, unresolved, coverage_pct, unresolved_packages: [...]}

    # Files the SAST scanner (semgrep) could not parse due to encoding/binary/corruption.
    # Each entry: {"path": str, "reason": str, "error_type": str, "scan": str}
    # These are a coverage gap: REACHABLE could not check them for secrets/CWE/malware.
    # Roadmap: sanitize-and-reparse in advanced mode.
    sast_skipped_files: List[Dict]

    reachability_blind_spots: List[ReachabilityBlindSpot]
    excluded_paths: List[ExcludedPath]
    sub_modules: List[ManifestGap]
    manifests_excluded: List[Any]  # List[ExcludedManifest] — manifests found in excluded dirs
    recommendations: List[str]

    def _build_exclude_config(self) -> Dict[str, Any]:
        """
        Build the exclude_config section for the coverage report.
        Shows paths to both exclude files, whether they exist, and
        summary counts of built-in vs user-configured exclusions.
        """
        root = Path(self.project_path)
        file_paths = _get_exclude_file_paths(root)

        built_in_count = sum(1 for e in self.excluded_paths if e.source == "built-in")
        user_count = sum(1 for e in self.excluded_paths if e.source == "user-config")
        total_files_excluded = sum(e.file_count for e in self.excluded_paths)
        total_size_kb = sum(e.size_kb for e in self.excluded_paths)

        return {
            "semgrep_exclude_file": file_paths["semgrep"],
            "guarddog_exclude_file": file_paths["guarddog"],
            "semgrep_exclude_file_exists": Path(file_paths["semgrep"]).exists(),
            "guarddog_exclude_file_exists": Path(file_paths["guarddog"]).exists(),
            "dirs_excluded_builtin": built_in_count,
            "dirs_excluded_user_config": user_count,
            "dirs_excluded_total": built_in_count + user_count,
            "files_excluded_total": total_files_excluded,
            "size_excluded_kb": total_size_kb,
            "builtin_patterns": sorted(EXCLUDED_DIR_PATTERNS.keys()),
        }

    def to_dict(self) -> Dict[str, Any]:
        reachability_pct = (
            round(100 * self.packages_with_reachability / self.packages_total) if self.packages_total > 0 else 0
        )
        return {
            "coverage_score": round(self.coverage_score, 3),
            "generated_at": self.generated_at,
            "manifests": {
                "found": self.manifests_found,
                "scanned": self.manifests_scanned,
                "skipped": [
                    {"path": g.path, "ecosystem": g.ecosystem, "reason": g.reason} for g in self.manifests_skipped
                ],
                "excluded": [
                    {
                        "path": e.path,
                        "ecosystem": e.ecosystem,
                        "excluded_dir": e.excluded_dir,
                        "reason": e.reason,
                        "module_name": e.module_name,
                    }
                    for e in self.manifests_excluded
                ],
            },
            "languages": {
                "detected": self.language_detected,
                "analyzed": self.language_analyzed,
                "gaps": [
                    {
                        "language": g.language,
                        "file_count": g.file_count,
                        "example_files": g.example_files[:5],
                        "reason": g.reason,
                    }
                    for g in self.language_gaps
                ],
            },
            "files": {
                "total_found": self.files_total + self.files_excluded_patterns,
                "analyzed": self.files_analyzed,
                "skipped_patterns": self.files_excluded_patterns,
                "skipped_dirs": self.files_excluded_dirs,
                "total_skipped": self.files_excluded_patterns + self.files_excluded_dirs,
                # SAST parse failures — encoding errors, binary files, corrupted source
                "sast_unparseable": len(self.sast_skipped_files),
                "sast_skipped_files": self.sast_skipped_files,
            },
            "packages": {
                "total_in_sbom": self.packages_total,
                "with_reachability": self.packages_with_reachability,
                "without_reachability": self.packages_total - self.packages_with_reachability,
                "reachability_coverage_pct": reachability_pct,
            },
            "registry_coverage": self.registry_coverage,
            "reachability_blind_spots": [
                {
                    "package": b.package,
                    "version": b.version,
                    "cve_count": len(b.cve_ids),
                    "cve_ids": b.cve_ids,
                    "severity": b.severity,
                    "reason": b.reason,
                }
                for b in self.reachability_blind_spots
            ],
            "excluded_paths": [
                {
                    "path": e.path,
                    "reason": e.reason,
                    "file_count": e.file_count,
                    "size_kb": e.size_kb,
                    "source": e.source,
                    "exclude_file": e.exclude_file,
                }
                for e in self.excluded_paths
            ],
            "exclude_config": self._build_exclude_config(),
            "sub_modules": [
                {"path": s.path, "ecosystem": s.ecosystem, "module_name": s.module_name, "scanned": False}
                for s in self.sub_modules
            ],
            "recommendations": self.recommendations,
        }


# ---------------------------------------------------------------------------
# Filesystem walkers
# ---------------------------------------------------------------------------


def _match_manifest(fname: str) -> Optional[str]:
    """Return ecosystem name if fname matches a manifest pattern, else None."""
    for ecosystem, patterns in MANIFEST_PATTERNS.items():
        for pat in patterns:
            if pat.startswith("*"):
                if fname.endswith(pat[1:]):
                    return ecosystem
            else:
                if fname == pat:
                    return ecosystem
    return None


def _walk_manifests(root: Path) -> List[Tuple[Path, str]]:
    """
    Walk project tree and return all discovered manifest files with ecosystem.
    Skips excluded dirs (vendor, node_modules, .git, etc.) AND per-repo
    user-configured excludes (semgrep-exclude.txt + guarddog-exclude.txt).

    Merging both here ensures that user-excluded dirs (e.g. guinea_pigs/)
    are never added to all_manifests and therefore never land in
    manifests.skipped — they go exclusively to manifests.excluded via
    _walk_excluded_manifests().
    """
    results = []
    per_repo = _read_per_repo_excludes(root)
    exclude_dirs = set(EXCLUDED_DIR_PATTERNS.keys()) | set(per_repo.keys())

    for dirpath, dirnames, filenames in os.walk(root):
        # Prune excluded dirs in-place so os.walk skips them
        dirnames[:] = [d for d in dirnames if d not in exclude_dirs and not d.startswith(".")]

        for fname in filenames:
            eco = _match_manifest(fname)
            if eco:
                results.append((Path(dirpath) / fname, eco))

    return results


@dataclass
class ExcludedManifest:
    """A manifest found inside an excluded directory."""

    path: str  # relative to project root
    ecosystem: str
    excluded_dir: str  # the excluded directory name that caused exclusion
    reason: str  # human-readable reason from EXCLUDED_DIR_PATTERNS
    module_name: str = ""  # extracted name (from package.json, go.mod, etc.)


def _repo_slug(root: Path) -> str:
    """Stable slug for ~/.reachable/scans/{slug}/ — mirrors SemgrepScanner._repo_slug."""
    import hashlib

    path = root.resolve()
    safe_name = "".join(c if c.isalnum() or c in "-_" else "-" for c in path.name).strip("-")[:32]
    path_hash = hashlib.sha256(str(path).encode()).hexdigest()[:8]
    return f"{safe_name}-{path_hash}"


def _read_per_repo_excludes(root: Path) -> Dict[str, str]:
    """
    Read per-repo exclude files and return a dict of {dir_name: reason}.

    Reads both:
      ~/.reachable/scans/<slug>/semgrep-exclude.txt  (Semgrep/DLP/CWE)
      ~/.reachable/scans/<slug>/guarddog-exclude.txt  (GuardDog malware)

    Entries present in either file are merged.  Both files use the same
    format: one bare directory name per line, # comments ignored.

    Returns an empty dict if neither file exists.
    """
    slug = _repo_slug(root)
    scans_dir = Path.home() / ".reachable" / "scans" / slug

    exclude_files = {
        "semgrep-exclude.txt": "excluded by user config (semgrep-exclude.txt)",
        "guarddog-exclude.txt": "excluded by user config (guarddog-exclude.txt)",
    }

    result: Dict[str, str] = {}
    for fname, reason in exclude_files.items():
        fpath = scans_dir / fname
        if not fpath.exists():
            continue
        for line in fpath.read_text(encoding="utf-8").splitlines():
            entry = line.strip()
            if entry and not entry.startswith("#"):
                # Only bare directory names are meaningful (no path separators)
                if "/" not in entry and "\\" not in entry:
                    # semgrep-exclude.txt wins if already set
                    if entry not in result:
                        result[entry] = reason
    return result


def _get_exclude_file_paths(root: Path) -> Dict[str, str]:
    """
    Return absolute paths to both per-repo exclude files for this root.
    Values are the absolute path as a string (whether or not the file exists).
    """
    slug = _repo_slug(root)
    scans_dir = Path.home() / ".reachable" / "scans" / slug
    return {
        "semgrep": str(scans_dir / "semgrep-exclude.txt"),
        "guarddog": str(scans_dir / "guarddog-exclude.txt"),
    }


def _walk_excluded_manifests(root: Path) -> List[ExcludedManifest]:
    """
    Discover manifests inside excluded directories so they appear in the
    coverage report as 'Excluded by config' rather than silently hidden.

    Merges built-in EXCLUDED_DIR_PATTERNS with the per-repo
    semgrep-exclude.txt and guarddog-exclude.txt so user-added
    exclusions from either file also surface here.

    We still don't scan these — but we record that we found them and why
    they were excluded.
    """
    results = []
    # Merge built-in + per-repo excludes; per-repo reason overwrites built-in
    # if the same dir appears in both (shouldn't happen, but be safe).
    per_repo = _read_per_repo_excludes(root)
    all_excluded: Dict[str, str] = {**EXCLUDED_DIR_PATTERNS, **per_repo}
    exclude_dirs = set(all_excluded.keys())
    # Infrastructure dirs that never contain meaningful manifests
    # (node_modules could have thousands of package.json — skip it)
    _INFRA_DIRS = {
        ".git",
        "__pycache__",
        ".pytest_cache",
        ".gradle",
        "htmlcov",
        ".tox",
        "coverage",
        "node_modules",
        "venv",
        ".venv",
        "env",
        "dist",
        "build",
        "target",
    }

    for dirpath, dirnames, filenames in os.walk(root):
        # Prune ALL excluded dirs from traversal (we walk them separately below)
        pruned = [d for d in dirnames if d not in exclude_dirs and not d.startswith(".")]
        found_excluded = [d for d in dirnames if d in exclude_dirs and d not in _INFRA_DIRS]
        dirnames[:] = pruned
        for dirname in found_excluded:
            # This is a meaningful excluded dir — walk it for manifests
            excluded_root = Path(dirpath) / dirname
            reason = EXCLUDED_DIR_PATTERNS[dirname]
            for sub_dirpath, sub_dirnames, sub_filenames in os.walk(excluded_root):
                # Skip infra dirs inside excluded dirs (e.g. node_modules inside guinea_pigs)
                sub_dirnames[:] = [d for d in sub_dirnames if d not in _INFRA_DIRS and not d.startswith(".")]
                for fname in sub_filenames:
                    eco = _match_manifest(fname)
                    if not eco:
                        continue
                    fpath = Path(sub_dirpath) / fname
                    rel = str(fpath.relative_to(root))

                    # Extract module name for context
                    module_name = ""
                    if fname == "package.json":
                        try:
                            pkg = json.loads(fpath.read_text())
                            module_name = pkg.get("name", "")
                        except Exception:
                            pass
                    elif fname == "go.mod":
                        try:
                            content = fpath.read_text(errors="ignore")
                            m = re.search(r"^module\s+(\S+)", content, re.MULTILINE)
                            if m:
                                module_name = m.group(1)
                        except OSError:
                            pass

                    results.append(
                        ExcludedManifest(
                            path=rel,
                            ecosystem=eco,
                            excluded_dir=dirname,
                            reason=f"excluded by config — {reason}",
                            module_name=module_name,
                        )
                    )

    return results


def _walk_source_files(root: Path) -> Tuple[Dict[str, List[Path]], int]:
    """
    Walk project tree and return (source files grouped by language, pattern-excluded count).
    Skips excluded dirs. Also counts files that match EXCLUDED_FILE_PATTERNS
    (test files, generated files, mocks) so the dashboard can report them.
    """
    results: Dict[str, List[Path]] = {lang: [] for lang in SOURCE_EXTENSIONS}
    ext_to_lang = {}
    for lang, exts in SOURCE_EXTENSIONS.items():
        for ext in exts:
            ext_to_lang[ext] = lang

    per_repo = _read_per_repo_excludes(root)
    exclude_dirs = set(EXCLUDED_DIR_PATTERNS.keys()) | set(per_repo.keys())
    excluded_by_pattern = 0
    compiled_patterns = [(re.compile(pat), reason) for pat, reason in EXCLUDED_FILE_PATTERNS.items()]

    for dirpath, dirnames, filenames in os.walk(root):
        dirnames[:] = [d for d in dirnames if d not in exclude_dirs and not d.startswith(".")]

        for fname in filenames:
            ext = Path(fname).suffix
            lang = ext_to_lang.get(ext)
            if not lang:
                continue
            # Check if excluded by pattern
            if any(p.search(fname) for p, _ in compiled_patterns):
                excluded_by_pattern += 1
                continue
            results[lang].append(Path(dirpath) / fname)

    return results, excluded_by_pattern


def _count_excluded_paths(root: Path) -> List[ExcludedPath]:
    """
    Find and count files/sizes in excluded directories.

    Merges built-in EXCLUDED_DIR_PATTERNS with per-repo exclude files
    (semgrep-exclude.txt + guarddog-exclude.txt) so user-configured
    exclusions are reflected in the coverage report alongside built-ins.
    Each ExcludedPath is tagged with source ("built-in" | "user-config")
    and the path to the exclude file that caused it.
    """
    # Build merged exclusion map: {dirname: (reason, source, exclude_file)}
    per_repo = _read_per_repo_excludes(root)
    exclude_file_paths = _get_exclude_file_paths(root)

    merged: Dict[str, tuple] = {}
    for dirname, reason in EXCLUDED_DIR_PATTERNS.items():
        merged[dirname] = (reason, "built-in", "")
    for dirname, reason in per_repo.items():
        if dirname not in merged:  # user-added (not already in built-ins)
            # Determine which file it came from
            fpath = ""
            if "guarddog" in reason:
                fpath = exclude_file_paths["guarddog"]
            else:
                fpath = exclude_file_paths["semgrep"]
            merged[dirname] = (reason, "user-config", fpath)

    excluded = []
    for dirpath, dirnames, filenames in os.walk(root):
        for dirname in list(dirnames):
            if dirname in merged:
                full_path = Path(dirpath) / dirname
                rel_path = str(full_path.relative_to(root))
                reason, source, exc_file = merged[dirname]

                # Count files and total size
                file_count = 0
                total_bytes = 0
                try:
                    for dp, _, fns in os.walk(full_path):
                        file_count += len(fns)
                        for fn in fns:
                            try:
                                total_bytes += (Path(dp) / fn).stat().st_size
                            except OSError:
                                pass
                except OSError:
                    pass

                excluded.append(
                    ExcludedPath(
                        path=rel_path,
                        reason=reason,
                        file_count=file_count,
                        size_kb=total_bytes // 1024,
                        source=source,
                        exclude_file=exc_file,
                    )
                )
                dirnames.remove(dirname)  # don't recurse into it

    return excluded


def _find_sub_modules(root: Path, primary_manifest: Optional[str] = None) -> List[ManifestGap]:
    """
    Find nested module roots (go.mod, package.json) that aren't the root manifest.
    These represent separate sub-projects that weren't scanned as their own target.

    Excludes third_party/, vendor/, and similar local-dependency directories that
    are managed as go.mod 'replace' directives — they are dependencies, not
    independent projects.
    """
    sub_modules = []
    root_str = str(root)
    # Add local-dependency / vendoring dirs that are NOT real sub-projects
    exclude_dirs = set(EXCLUDED_DIR_PATTERNS.keys()) | {
        "third_party",
        "thirdparty",
        "third-party",
        "external",
        "ext",
        "deps",
        "dependencies",
    }
    sub_module_markers = {
        "go.mod": "go",
        "package.json": "javascript",
        "pyproject.toml": "python",
        "Cargo.toml": "rust",
        "pom.xml": "java",
    }

    for dirpath, dirnames, filenames in os.walk(root):
        dirnames[:] = [d for d in dirnames if d not in exclude_dirs and not d.startswith(".")]

        for fname in filenames:
            if fname not in sub_module_markers:
                continue
            fpath = Path(dirpath) / fname
            rel_path = str(fpath.relative_to(root))

            # Skip root-level manifest
            if str(dirpath) == root_str:
                continue

            ecosystem = sub_module_markers[fname]
            module_name = ""

            # Extract module name from go.mod
            if fname == "go.mod":
                try:
                    content = fpath.read_text(errors="ignore")
                    m = re.search(r"^module\s+(\S+)", content, re.MULTILINE)
                    if m:
                        module_name = m.group(1)
                except OSError:
                    pass
            # Extract name from package.json
            elif fname == "package.json":
                try:
                    pkg = json.loads(fpath.read_text())
                    module_name = pkg.get("name", "")
                except Exception:
                    pass

            # Skip stub go.mod files that exist only for local replace directives
            # (no 'require' block = dependency shim, not a real sub-project)
            if fname == "go.mod" and module_name:
                try:
                    content = fpath.read_text(errors="ignore")
                    has_require = bool(re.search(r"^require\s", content, re.MULTILINE))
                    if not has_require:
                        continue
                except OSError:
                    pass

            sub_modules.append(
                ManifestGap(
                    path=rel_path,
                    ecosystem=ecosystem,
                    reason="nested module root — not scanned as independent target",
                    is_sub_module=True,
                    module_name=module_name,
                )
            )

    return sub_modules


# ---------------------------------------------------------------------------
# Reachability gap analysis
# ---------------------------------------------------------------------------


def _compute_reachability_gaps(
    findings: List[Dict[str, Any]],
    callgraph_packages: Optional[Set[str]],
) -> Tuple[int, int, List[ReachabilityBlindSpot]]:
    """
    Returns (total_cve_packages, reachable_packages, blind_spots).

    A "blind spot" is a package with one or more CVEs but no callgraph data,
    so we can't determine reachability. This is distinct from NOT_REACHABLE
    (which means we analyzed it and it's not called).
    """
    cve_findings = [f for f in findings if (f.get("finding_type") or f.get("type") or "").upper() == "CVE"]

    if not cve_findings:
        return 0, 0, []

    # Group by package
    pkg_cves: Dict[str, List[Dict]] = {}
    for f in cve_findings:
        pkg = (f.get("package_name") or f.get("package") or "unknown").split(" ")[0]
        if pkg not in pkg_cves:
            pkg_cves[pkg] = []
        pkg_cves[pkg].append(f)

    blind_spots = []
    packages_with_reach = 0

    for pkg, cves in pkg_cves.items():
        # A package has callgraph coverage when the engine produced a definitive
        # answer (REACHABLE or NOT_REACHABLE) for at least one of its CVEs.
        # UNKNOWN means the engine had no call graph — that IS a blind spot.
        reachability_states = {(c.get("app_reachability") or c.get("reachability") or "UNKNOWN").upper() for c in cves}
        has_reachability_data = bool(reachability_states & {"REACHABLE", "NOT_REACHABLE"})

        # Also honour an explicit set passed in by the ingester (belt-and-suspenders)
        if not has_reachability_data and callgraph_packages is not None:
            has_reachability_data = pkg in callgraph_packages

        if has_reachability_data:
            packages_with_reach += 1
        else:
            # All CVEs are UNKNOWN → blind spot
            sev_rank = {"CRITICAL": 4, "HIGH": 3, "MEDIUM": 2, "LOW": 1}
            top_sev = max(
                (c.get("severity", "UNKNOWN") for c in cves),
                key=lambda s: sev_rank.get(s.upper(), 0),
                default="UNKNOWN",
            )
            cve_ids = [c.get("id") or c.get("finding_id") or "" for c in cves]

            blind_spots.append(
                ReachabilityBlindSpot(
                    package=pkg,
                    version=cves[0].get("installed_version") or cves[0].get("version") or "",
                    cve_ids=[c for c in cve_ids if c],
                    severity=top_sev,
                    reason="reachability UNKNOWN — no call graph data for this package",
                )
            )

    return len(pkg_cves), packages_with_reach, blind_spots


# ---------------------------------------------------------------------------
# Coverage score calculation
# ---------------------------------------------------------------------------


def _compute_coverage_score(
    manifests_found: int,
    manifests_scanned: int,
    languages_detected: int,
    languages_analyzed: int,
    packages_total: int,
    packages_with_reachability: int,
    blind_spots_count: int,
) -> float:
    """
    Weighted coverage score 0.0–1.0.

    Weights:
      Manifest coverage      30% — did we consume all package info?
      Language coverage      30% — did we run all needed scanners?
      Reachability coverage  40% — can we answer "is it reachable?" for CVEs?
    """
    manifest_score = (manifests_scanned / manifests_found) if manifests_found > 0 else 1.0
    language_score = (languages_analyzed / languages_detected) if languages_detected > 0 else 1.0
    reach_score = (packages_with_reachability / packages_total) if packages_total > 0 else 1.0
    # Penalize blind spots: each blind spot reduces reach_score slightly
    if blind_spots_count > 0 and packages_total > 0:
        reach_score = max(0.0, reach_score - (blind_spots_count * 0.05))

    score = (manifest_score * 0.30) + (language_score * 0.30) + (reach_score * 0.40)
    return min(1.0, max(0.0, score))


# ---------------------------------------------------------------------------
# Recommendations generator
# ---------------------------------------------------------------------------


def _generate_recommendations(
    language_gaps: List[LanguageGap],
    manifests_skipped: List[ManifestGap],
    sub_modules: List[ManifestGap],
    blind_spots: List[ReachabilityBlindSpot],
    excluded_paths: List[ExcludedPath],
) -> List[str]:
    """Generate actionable, prioritized recommendations."""
    recs = []

    # Language gaps first — high impact
    for gap in language_gaps:
        examples = ", ".join(gap.example_files[:2])
        recs.append(
            f"Add {gap.language} scanner to analyze {gap.file_count} source files (e.g. {examples}) — {gap.reason}"
        )

    # Sub-modules — high impact, often missed
    if sub_modules:
        paths = ", ".join(s.path for s in sub_modules[:3])
        suffix = f" and {len(sub_modules) - 3} more" if len(sub_modules) > 3 else ""
        recs.append(
            f"Run independent scan on {len(sub_modules)} sub-module(s): "
            f"{paths}{suffix} — each is a separate dependency graph"
        )

    # Reachability blind spots — medium impact
    critical_blind = [b for b in blind_spots if b.severity.upper() in ("CRITICAL", "HIGH")]
    if critical_blind:
        pkgs = ", ".join(b.package.split("/")[-1] for b in critical_blind[:3])
        recs.append(
            f"{len(critical_blind)} HIGH/CRITICAL package(s) with CVEs have no reachability data "
            f"({pkgs}) — they are conservatively flagged as potentially reachable"
        )

    # Skipped manifests
    for gap in manifests_skipped:
        recs.append(f"Manifest {gap.path} ({gap.ecosystem}) was found but not scanned: {gap.reason}")

    # Excluded paths with source files
    for ep in excluded_paths:
        if ep.file_count > 50:
            recs.append(f"{ep.path} excluded ({ep.file_count} files, {ep.size_kb}KB): {ep.reason}")

    return recs


# ---------------------------------------------------------------------------
# Main entry point
# ---------------------------------------------------------------------------


class CoverageAnalyzer:
    """
    Computes the coverage gap report for a completed scan.

    Inputs (all optional — degrade gracefully):
      - project_path: filesystem root of the scanned project
      - sbom_data:    Syft SBOM JSON (from 01-sbom.json)
      - vulns_data:   Grype JSON (from vulns.json)
      - findings:     Enriched findings list from DB (for reachability gap analysis)
      - callgraph_packages: Set of packages the callgraph engine analyzed
      - scanned_manifests:  Explicit list of manifests Syft consumed
      - analyzed_languages: Explicit list of languages scanners ran for
    """

    def __init__(
        self,
        project_path: str,
        scan_id: str,
        sbom_data: Optional[Dict] = None,
        vulns_data: Optional[Dict] = None,
        findings: Optional[List[Dict]] = None,
        callgraph_packages: Optional[Set[str]] = None,
        scanned_manifests: Optional[List[str]] = None,
        analyzed_languages: Optional[List[str]] = None,
        sast_skipped_files: Optional[List[Dict]] = None,
    ):
        self.root = Path(project_path)
        self.scan_id = scan_id
        self.sbom_data = sbom_data or {}
        self.vulns_data = vulns_data or {}
        self.findings = findings or []
        self.callgraph_packages = callgraph_packages
        self.scanned_manifests = scanned_manifests or []
        self.analyzed_languages = analyzed_languages or []
        # Files semgrep could not parse (encoding errors, binary, corrupted)
        self.sast_skipped_files: List[Dict] = sast_skipped_files or []

    def analyze(self) -> CoverageReport:
        """Run all coverage gap analyses and return combined report."""
        # --- 1. Manifests ---
        all_manifests = _walk_manifests(self.root)
        manifests_found = [str(p.relative_to(self.root)) for p, _ in all_manifests]

        # What did Syft consume? Extract from SBOM or use explicit list
        scanned_set = self._resolve_scanned_manifests(all_manifests)

        manifests_skipped: List[ManifestGap] = []
        for fpath, ecosystem in all_manifests:
            rel = str(fpath.relative_to(self.root))
            if rel not in scanned_set:
                # Determine why it was skipped
                reason = self._classify_skip_reason(fpath, ecosystem)
                manifests_skipped.append(ManifestGap(path=rel, ecosystem=ecosystem, reason=reason))

        # --- 2. Source file language detection ---
        source_files, files_excluded_by_pattern = _walk_source_files(self.root)
        language_detected = {lang: len(files) for lang, files in source_files.items() if files}
        files_total = sum(len(f) for f in source_files.values())

        # Normalize analyzed_languages to lowercase coverage keys.
        # ScanContext emits display names like 'Python', 'JavaScript/TypeScript', 'Go';
        # SOURCE_EXTENSIONS uses lowercase keys like 'python', 'javascript', 'go'.
        # Without normalization every language shows as a Gap even when fully analyzed.
        _LANG_ALIASES: Dict[str, str] = {
            "python": "python",
            "javascript": "javascript",
            "javascript/typescript": "javascript",
            "typescript": "javascript",
            "js": "javascript",
            "ts": "javascript",
            "go": "go",
            "golang": "go",
            "java": "java",
            "kotlin": "java",
            "scala": "java",
            "rust": "rust",
            "ruby": "ruby",
            "dotnet": "dotnet",
            "c#": "dotnet",
            "php": "php",
        }
        analyzed_set: Set[str] = set()
        for lang in self.analyzed_languages:
            normalized = _LANG_ALIASES.get(lang.lower().strip())
            if normalized:
                analyzed_set.add(normalized)
            else:
                # Best-effort: lowercase prefix match
                key = lang.lower().split("/")[0].split(" ")[0]
                analyzed_set.add(key)

        if not analyzed_set:
            # Infer from scanned manifests + SBOM ecosystem names
            for _, eco in all_manifests:
                if eco in scanned_set or any(eco in s for s in scanned_set):
                    normalized = _LANG_ALIASES.get(eco.lower(), eco.lower())
                    analyzed_set.add(normalized)

        language_analyzed = {lang: (lang in analyzed_set) for lang in language_detected}

        language_gaps: List[LanguageGap] = []
        for lang, count in language_detected.items():
            if not language_analyzed.get(lang, False):
                example_files = [str(f.relative_to(self.root)) for f in source_files[lang][:5]]
                language_gaps.append(
                    LanguageGap(
                        language=lang,
                        file_count=count,
                        example_files=example_files,
                        reason=f"no {lang} scanner configured in this scan plan",
                    )
                )

        # --- 3. Package coverage ---
        packages_total, packages_with_reach, blind_spots = _compute_reachability_gaps(
            self.findings, self.callgraph_packages
        )

        # --- 4. Excluded paths ---
        excluded_paths = _count_excluded_paths(self.root)

        # --- 4b. Excluded manifests ---
        # Manifests found inside excluded directories (guinea_pigs/, vendor/, etc.)
        # are NOT scanned but ARE recorded so the coverage report shows
        # "we found this, we excluded it by config, here's why"
        excluded_manifests = _walk_excluded_manifests(self.root)

        # --- 5. Sub-modules ---
        # Filter out sub-modules whose manifest is already covered by scanned_set
        # (e.g. webapp/package.json is covered when webapp/package-lock.json is scanned)
        sub_modules = [sm for sm in _find_sub_modules(self.root) if sm.path not in scanned_set]

        # --- 6. Recommendations ---
        recommendations = _generate_recommendations(
            language_gaps=language_gaps,
            manifests_skipped=manifests_skipped,
            sub_modules=sub_modules,
            blind_spots=blind_spots,
            excluded_paths=excluded_paths,
        )

        # --- 7. Score ---
        score = _compute_coverage_score(
            manifests_found=len(manifests_found),
            manifests_scanned=len(scanned_set),
            languages_detected=len(language_detected),
            languages_analyzed=sum(1 for v in language_analyzed.values() if v),
            packages_total=packages_total,
            packages_with_reachability=packages_with_reach,
            blind_spots_count=len(blind_spots),
        )

        files_excluded_dirs = sum(ep.file_count for ep in excluded_paths)

        # Extract registry coverage from SBOM metadata if available (Phase 5: PURLResolver)
        registry_coverage = self.sbom_data.get("_reachable_registry_coverage", {})

        return CoverageReport(
            project_path=str(self.root),
            scan_id=self.scan_id,
            generated_at=datetime.now(timezone.utc).isoformat(),
            coverage_score=score,
            manifests_found=manifests_found,
            manifests_scanned=sorted(scanned_set),
            manifests_skipped=manifests_skipped,
            language_detected=language_detected,
            language_analyzed=language_analyzed,
            language_gaps=language_gaps,
            files_total=files_total,
            # files_analyzed = source files in analyzed languages only.
            # Previously hardcoded to files_total which falsely showed 100% always.
            files_analyzed=sum(
                len(source_files[lang]) for lang in language_detected if language_analyzed.get(lang, False)
            ),
            files_excluded_patterns=files_excluded_by_pattern,
            files_excluded_dirs=files_excluded_dirs,
            packages_total=packages_total,
            packages_with_reachability=packages_with_reach,
            registry_coverage=registry_coverage,
            reachability_blind_spots=blind_spots,
            excluded_paths=excluded_paths,
            sub_modules=sub_modules,
            manifests_excluded=excluded_manifests,
            sast_skipped_files=self.sast_skipped_files,
            recommendations=recommendations,
        )

    def _resolve_scanned_manifests(self, all_manifests: List[Tuple[Path, str]]) -> Set[str]:
        """
        Determine which manifests were actually consumed.

        Priority:
          1. Explicit list passed in (from execution engine logging)
          2. SBOM metadata (Syft records source locations)
          3. Heuristic: if only one manifest of a type exists, assume it was scanned
        """
        if self.scanned_manifests:
            return set(self.scanned_manifests)

        # Try to extract from SBOM source metadata
        scanned = set()
        if self.sbom_data:
            # Syft SPDX or CycloneDX source section
            # source = self.sbom_data.get('source', {})  # noqa: F841 - reserved for future use
            # Syft JSON format: source.target.userInput or source.target.imageID
            for artifact in self.sbom_data.get("artifacts", []):
                for loc in artifact.get("locations", []):
                    real_path = loc.get("realPath") or loc.get("path", "")
                    if real_path:
                        for fpath, eco in all_manifests:
                            if real_path.endswith(str(fpath.name)):
                                scanned.add(str(fpath.relative_to(self.root)))

        # Heuristic: if only one root-level manifest of its type → assume scanned
        if not scanned:
            manifest_by_eco: Dict[str, List[Tuple[Path, str]]] = {}
            for fpath, eco in all_manifests:
                manifest_by_eco.setdefault(eco, []).append((fpath, eco))

            for eco, manifests in manifest_by_eco.items():
                root_manifests = [(fp, e) for fp, e in manifests if fp.parent == self.root]
                if len(root_manifests) == 1:
                    scanned.add(str(root_manifests[0][0].relative_to(self.root)))
                elif len(root_manifests) > 1:
                    # Multiple at root — assume the canonical one was scanned
                    for fp, _ in root_manifests:
                        if fp.name in (
                            "go.mod",
                            "package-lock.json",
                            "requirements.txt",
                            "Cargo.lock",
                            "pom.xml",
                        ):
                            scanned.add(str(fp.relative_to(self.root)))

        # --- Companion logic: lock file scanned → manifest is covered ---
        # When package-lock.json is scanned, package.json in the same dir is
        # fully covered (lock file is a superset). Same for yarn.lock, etc.
        _LOCK_TO_MANIFEST = {
            "package-lock.json": "package.json",
            "yarn.lock": "package.json",
            "pnpm-lock.yaml": "package.json",
            "Cargo.lock": "Cargo.toml",
            "Pipfile.lock": "Pipfile",
            "Gemfile.lock": "Gemfile",
        }
        companions_to_add: Set[str] = set()
        for scanned_rel in list(scanned):
            scanned_path = Path(scanned_rel)
            companion_manifest = _LOCK_TO_MANIFEST.get(scanned_path.name)
            if companion_manifest:
                companion_rel = str(scanned_path.parent / companion_manifest)
                # Only add if the companion actually exists in the discovered manifests
                if companion_rel in {str(fp.relative_to(self.root)) for fp, _ in all_manifests}:
                    companions_to_add.add(companion_rel)
        scanned |= companions_to_add

        return scanned

    def _classify_skip_reason(self, manifest_path: Path, ecosystem: str) -> str:
        """Classify why a manifest wasn't scanned."""
        rel = str(manifest_path.relative_to(self.root))

        # Is it a lock file vs the manifest?
        lock_files = {
            "go.sum",
            "package-lock.json",
            "yarn.lock",
            "Cargo.lock",
            "Pipfile.lock",
            "pnpm-lock.yaml",
            "Gemfile.lock",
        }
        if manifest_path.name in lock_files:
            return "lock file — Grype uses the primary manifest, not the lock file directly"

        # Is it a sub-module?
        if manifest_path.parent != self.root:
            return f"nested module at {rel} — not scanned as independent target"

        # Is it a dev/test manifest?
        if "test" in rel.lower() or "dev" in rel.lower() or "example" in rel.lower():
            return "test/dev manifest — not included in production scan scope"

        return f"not consumed by scanner (check scan configuration for {ecosystem})"


# ---------------------------------------------------------------------------
# Pipeline integration — write to message bus
# ---------------------------------------------------------------------------


def run_coverage_analysis(
    project_path: str,
    scan_id: str,
    metadata_dir: Optional[str] = None,
    **kwargs,
) -> Dict[str, Any]:
    """
    Run coverage analysis and write result to pipeline message bus.

    Args:
        project_path:  filesystem root of scanned project
        scan_id:       scan identifier
        metadata_dir:  .metadata/ dir for pipeline message bus output
        **kwargs:      passed to CoverageAnalyzer (sbom_data, findings, etc.)

    Returns:
        coverage report dict
    """
    analyzer = CoverageAnalyzer(project_path=project_path, scan_id=scan_id, **kwargs)
    report = analyzer.analyze()
    report_dict = report.to_dict()

    # Write to pipeline message bus
    if metadata_dir:
        out_path = Path(metadata_dir) / "08-coverage.json"
        try:
            out_path.parent.mkdir(parents=True, exist_ok=True)
            out_path.write_text(json.dumps(report_dict, indent=2))
        except OSError as e:
            _slog(f" Could not write coverage report: {e}", level="WARNING")

    return report_dict


# ---------------------------------------------------------------------------
# DB storage integration
# ---------------------------------------------------------------------------


def store_coverage_report(db_conn, scan_id: str, report: Dict[str, Any]) -> None:
    """
    Store coverage report in the scan_coverage table.
    Creates table if it doesn't exist.
    Raises on failure so the caller can surface the error.
    """
    db_conn.execute("""
        CREATE TABLE IF NOT EXISTS scan_coverage (
            scan_id         TEXT PRIMARY KEY,
            coverage_score  REAL,
            report_json     TEXT,
            generated_at    TEXT
        )
    """)
    db_conn.execute(
        """
        INSERT OR REPLACE INTO scan_coverage
            (scan_id, coverage_score, report_json, generated_at)
        VALUES (?, ?, ?, ?)
    """,
        (
            str(scan_id),
            report.get("coverage_score"),
            json.dumps(report),
            report.get("generated_at"),
        ),
    )
    db_conn.commit()
