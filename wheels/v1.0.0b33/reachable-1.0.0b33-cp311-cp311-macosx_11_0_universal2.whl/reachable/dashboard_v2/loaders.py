#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.

"""
Data loaders for dashboard generation.
Handles loading from SQLite database and JSON files.
"""

import gzip
import json
import logging
import re
import sqlite3
from pathlib import Path
from typing import Any, Dict, List, Optional

from .metrics import calculate_metrics_from_summary, calculate_risk_level, format_summary
from .utils import get_version

logger = logging.getLogger(__name__)


def _row_get(row, key, default=None, transform=None):
    """Safely get a value from a sqlite3.Row — returns default if column missing."""
    try:
        val = row[key]
        if val is None:
            return default
        return transform(val) if transform else val
    except (IndexError, KeyError):
        return default


# b15: Extract context tags from finding titles for context-aware remediation
# Format: "Secret detected: ... [weak_default_fallback: desc]" -> tag='weak_default_fallback'
_FINDING_TAG_RE = re.compile(r"\s*\[(\w+):\s*[^\]]*\]\s*$")

# b15: Context-aware secret remediation labels (12-Context Classification Table)
_SECRET_FIX_LABELS = {
    "weak_default_fallback": ("⚠️ REMOVE FALLBACK", "#fef3c7", "#92400e"),
    "test_data": ("✅ VERIFY TEST DATA", "#d1fae5", "#065f46"),
    "test_data_email": ("✅ VERIFY TEST DATA", "#d1fae5", "#065f46"),
    "valid_externalized": ("✔️ EXTERNALIZED", "#d1fae5", "#065f46"),
}

# b15: Context-aware secret remediation guidance (action, review_guidance)
_SECRET_REMEDIATION = {
    "weak_default_fallback": (
        "Remove the hardcoded fallback value. Use a secrets manager or .env file instead.",
        "Verify fallback value is not used in production. Remove default if possible.",
    ),
    "test_data": (
        "Verify this is test-only data not used in production environments.",
        "Confirm credential is test-only and cannot access production resources.",
    ),
    "test_data_email": (
        "Verify this is a test email not used for production notifications.",
        "Confirm email is test-only and does not receive sensitive data.",
    ),
    "valid_externalized": (
        "Secret is properly externalized via environment variable. No action required.",
        "Properly externalized. No rotation needed.",
    ),
}


def load_from_database(db_path: Path) -> Dict[str, Any]:
    """Load dashboard data directly from SQLite database"""
    conn = sqlite3.connect(str(db_path))
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA busy_timeout=30000")  # P2.60a: concurrency hardening
    cursor = conn.cursor()

    try:
        # Get scan metadata FIRST — we need branch to scope the scan_id query.
        # BRANCH-SCOPE FIX: repo.db is shared across branches; _get_latest_scan_id
        # must be called with the branch to avoid returning wrong-branch scan data.
        metadata = _get_scan_metadata(cursor)

        # v4.5.37: Get the latest completed scan_id to filter all queries
        # This fixes the bug where metrics accumulated across all scans
        latest_scan_id = _get_latest_scan_id(cursor, branch=metadata.get("branch"))

        # v5.1.5: Enrich metadata with repo_root from scan-plan.json if missing
        # _get_scan_metadata may fail to find repo_path when scans table lacks
        # the column, causing broken VCS links in the dashboard
        if not metadata.get("repo_root"):
            _enrich_metadata_from_scan_plan(metadata, db_path)

        # Get issues summary (was 'findings') - filtered by scan_id
        issues_summary = _get_issues_summary(cursor, latest_scan_id)

        # Get all security issues for table - filtered by scan_id
        issues = _get_all_issues(cursor, latest_scan_id)

        # v5.1.3: IaC severity now handled by normalizer (semgrep.py _iac_severity)
        # DB is source of truth — no display-time reclassification needed

        # v4.5.28: Build OWASP Top 10 web summary from CWE findings
        owasp_web = _build_owasp_web_from_issues(issues)

        # v4.5.28: Load AI security findings from ai_findings table
        # v4.5.37: Filter by latest_scan_id to prevent accumulation
        ai_security = load_ai_security_from_db(cursor, latest_scan_id)

        # v4.5.40: Load DLP/PII findings from dlp_findings table
        dlp_security = load_dlp_findings_from_db(cursor, latest_scan_id)

        # P2.21: Calculate metrics AFTER loading DLP to include DLP total AND reachable
        dlp_total = dlp_security.get("total", 0) if dlp_security else 0
        dlp_reachable = dlp_security.get("reachable", 0) if dlp_security else 0

        # v4.5.10: Read risk_level from scans table (stored at scan time)
        risk_level = _get_stored_risk_level(cursor)

        # v4.5.40: Export dlp_findings as array for template compatibility
        # P2.21: Limit to prevent browser crash with massive DLP datasets
        dlp_findings = dlp_security.get("findings", []) if dlp_security else []

        # P2.21: Show ALL DLP findings in dashboard

        # P2.21 FIX: Add simplified DLP findings to issues array for Action Required panel
        # Keep full dlp_findings for detailed DLP panel, but add to issues for breakdown
        dlp_issues = _convert_dlp_to_issues(dlp_findings)
        issues.extend(dlp_issues)

        # P2.50 FIX: Add AI findings to issues array (like DLP)
        # This ensures funnel and issues[] have matching counts
        ai_findings_list = ai_security.get("findings", []) if ai_security else []
        ai_issues = _convert_ai_to_issues(ai_findings_list)
        issues.extend(ai_issues)

        # P2.21 FIX: Calculate metrics AFTER all issues are added (including DLP and AI)
        # Pass full issues list for proper severity breakdown calculation
        ai_total = ai_security.get("total", 0) if ai_security else 0
        ai_reachable = ai_security.get("reachable", 0) if ai_security else 0
        metrics = calculate_metrics_from_summary(
            issues_summary,
            dlp_total,
            dlp_reachable,
            issues=issues,
            ai_total=ai_total,
            ai_reachable=ai_reachable,
        )

        # Use stored risk_level from scans table (set by complete_scan() after all findings
        # are ingested — it is always current). Fall back to recalculation only when absent.
        if not risk_level:
            risk_level = calculate_risk_level(issues_summary, metrics, issues)

        # P2.21 FIX: Load scan history for trends chart visualization
        # repo.db is at repo root: ~/.reachable/scans/<repo-hash>/repo.db
        # We need to pass repo root (db_path.parent), not scan_dir
        repo_root = Path(db_path).parent
        scan_history = get_scan_history(repo_root, days=30)

        # P2.50 CRITICAL FIX: Database is the SINGLE SOURCE OF TRUTH
        # All dashboard values must come from database - NO JS recalculation
        # Build funnel, trends, and other pre-computed sections here

        # P2.50: Build FUNNEL section from database counts
        # This is the source of truth for the Analysis Funnel panel
        funnel = _build_funnel_from_db(cursor, latest_scan_id, dlp_security, ai_security)

        # P2.50: Build TRENDS section from scan_history
        # Transform scan_history into the format dashboard expects
        trends = _build_trends_from_history(scan_history)

        # P2.50: Build repo_metadata for Scan Context panel
        repo_metadata = get_repo_metadata(Path(db_path).parent)

        # v5.0.1: Malware metrics computed directly from DB (source of truth)
        malware_metrics = _get_malware_metrics_from_db(cursor, latest_scan_id)
        metrics.update(malware_metrics)

        # P2.60: Build engineering panel (pre-computed category breakdowns)
        # DB = single source of truth — JS must NOT recalculate these
        engineering = _build_engineering_panel(issues)

        # P2.60: Build exec summary (pre-computed severity breakdowns)
        exec_summary = _build_exec_summary(issues, risk_level, funnel)

        # --- Coverage report ---
        coverage_report = None
        try:
            cov_cur = conn.execute(
                "SELECT report_json FROM scan_coverage WHERE scan_id = ? ORDER BY rowid DESC LIMIT 1",
                (latest_scan_id,),
            )
            cov_row = cov_cur.fetchone()
            if cov_row and cov_row[0]:
                import json as _cjson

                coverage_report = _cjson.loads(cov_row[0])
        except Exception:
            pass  # table may not exist yet — degrade gracefully

        # BUG #2 FIX: Build OWASP LLM Top 10 from ai_security.by_owasp data.
        # owasp_top10 was incorrectly aliased to owasp_web (OWASP Web Top 10).
        owasp_llm = _build_owasp_llm_from_ai_security(ai_security)

        # P2-FIX: Read sandbox_packages_tested from raw/sandbox.json
        # The engine hardcodes packages_tested=0 because sandbox runs AFTER analysis.
        # The actual value is in the raw file written by cli/scan.py.
        sandbox_metrics = {"packages_tested": 0, "malicious": 0, "suspicious": 0, "clean": 0}
        try:
            _scan_dir_row = cursor.execute(
                "SELECT scan_dir FROM scans WHERE id = ?", (latest_scan_id,)
            ).fetchone()
            if _scan_dir_row and _scan_dir_row["scan_dir"]:
                import json as _sbox_json
                _sbox_path = Path(_scan_dir_row["scan_dir"]) / "raw" / "sandbox.json"
                if _sbox_path.exists():
                    _sbox_data = _sbox_json.loads(_sbox_path.read_text())
                    sandbox_metrics["packages_tested"] = _sbox_data.get("packages_tested", 0)
                    _sbox_summary = _sbox_data.get("summary", {})
                    sandbox_metrics["malicious"] = _sbox_summary.get("malicious", 0)
                    sandbox_metrics["suspicious"] = _sbox_summary.get("suspicious", 0)
                    sandbox_metrics["clean"] = _sbox_summary.get("clean", 0)
                    sandbox_metrics["verdict"] = _sbox_data.get("verdict", "SKIPPED")
        except Exception as _sbox_err:
            logger.debug(f"P2-FIX: sandbox metrics read failed (non-fatal): {_sbox_err}")
        metrics["sandbox_packages_tested"] = sandbox_metrics["packages_tested"]

        return {
            "version": get_version(),
            "scan": metadata,
            "risk_level": risk_level,
            "metrics": metrics,
            "summary": format_summary(issues_summary, dlp_total),
            "issues": issues,
            # OWASP data - provide both key names for compatibility
            "owasp_web": owasp_web,
            "owasp_top10": owasp_llm,  # BUG #2 FIX: LLM Top 10 (LLM01-10), not Web Top 10
            # AI Security — ai_findings[] is the canonical array for the AI tab;
            # ai_security{} carries the full stats dict (by_owasp, by_severity, etc.)
            "ai_security": ai_security,
            "ai_findings": ai_findings_list,  # BUG-A FIX: was missing, AI tab showed 0
            # DLP data - provide both key names for compatibility
            "dlp_findings": dlp_findings,
            "dlp_summary": dlp_security,
            "dlp_security": dlp_security,  # P2.50: Alias for dashboard compatibility
            # P2.50 CRITICAL: Pre-computed sections (DB = truth, no JS recalc)
            "funnel": funnel,
            "trends": trends,
            "scan_history": scan_history,
            "repo_metadata": repo_metadata,
            "clone_metrics": None,  # Loaded separately via get_clone_metrics()
            # P2.60: Pre-computed panel data (eliminates 14 JS recomputation violations)
            "engineering": engineering,
            "exec_summary": exec_summary,
            "coverage_report": coverage_report,
            # T7: Package health advisories (advisory-only, not in risk score)
            "package_health": _load_package_health(cursor, latest_scan_id),
            # P2-FIX: Sandbox summary from raw/sandbox.json (packages_tested, verdict, etc.)
            "sandbox_metrics": sandbox_metrics,
        }

    finally:
        conn.close()


def load_from_json(json_path: Path) -> Dict[str, Any]:
    """Load report from JSON file (gzipped or plain)"""
    try:
        if str(json_path).endswith(".gz"):
            with gzip.open(json_path, "rt", encoding="utf-8") as f:
                return json.load(f)
        else:
            with open(json_path, encoding="utf-8") as f:
                return json.load(f)
    except FileNotFoundError:
        raise
    except (json.JSONDecodeError, ValueError) as e:
        raise ValueError(f"Invalid JSON in {json_path}: {e}") from e
    except OSError as e:
        raise OSError(f"Cannot read {json_path}: {e}") from e


def load_dlp_findings_from_db(cursor, scan_id: Optional[int] = None) -> Optional[Dict[str, Any]]:
    """
    Load DLP/PII findings from dlp_findings table in repo.db

    v4.5.40: Added for DLP dashboard panel support
    """
    try:
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='dlp_findings'")
        if not cursor.fetchone():
            return None

        # Filter by scan_id if provided
        if scan_id:
            cursor.execute(
                """
                SELECT
                    rule_id, finding_type, pii_type, pii_sample, pii_count,
                    sink_type, sink_function, severity,
                    base_risk_score, adjusted_risk_score,
                    file_class, file_class_modifier,
                    is_reachable, reachability_confidence,
                    sanitizer_present, sanitizer_type, sanitizer_effectiveness,
                    regulations, file_path, line_start, line_end,
                    message, remediation, detection_source, confidence,
                    call_paths_v2
                FROM dlp_findings
                WHERE scan_id = ?
                ORDER BY adjusted_risk_score DESC
            """,
                (scan_id,),
            )
        else:
            cursor.execute("""
                SELECT
                    rule_id, finding_type, pii_type, pii_sample, pii_count,
                    sink_type, sink_function, severity,
                    base_risk_score, adjusted_risk_score,
                    file_class, file_class_modifier,
                    is_reachable, reachability_confidence,
                    sanitizer_present, sanitizer_type, sanitizer_effectiveness,
                    regulations, file_path, line_start, line_end,
                    message, remediation, detection_source, confidence,
                    call_paths_v2
                FROM dlp_findings
                ORDER BY adjusted_risk_score DESC
            """)

        findings = []
        by_pii_type = {}
        by_sink_type = {}
        by_severity = {"CRITICAL": 0, "HIGH": 0, "MEDIUM": 0, "LOW": 0, "WARNING": 0}
        reachable_count = 0
        sanitized_count = 0

        for row in cursor.fetchall():
            pii_type = row[2] or "UNKNOWN"
            sink_type = row[5] or "UNKNOWN"
            severity = (row[7] or "MEDIUM").upper()
            is_reach = row[12]
            is_sanitized = row[14]

            # Aggregate stats
            by_pii_type[pii_type] = by_pii_type.get(pii_type, 0) + 1
            by_sink_type[sink_type] = by_sink_type.get(sink_type, 0) + 1
            if severity in by_severity:
                by_severity[severity] += 1
            if is_reach == 1:
                reachable_count += 1
            if is_sanitized == 1:
                sanitized_count += 1

            # Parse regulations from JSON
            regulations = []
            try:
                if row[17]:
                    regulations = json.loads(row[17])
            except Exception:
                pass

            # P2.20: Compute SLA and fix tag for DLP findings
            is_reach_bool = None if row[12] is None else bool(row[12])  # L5 FIX: remove duplicate, preserve tri-state

            sla_display, sla_class = _compute_sla_display(
                is_reachable=is_reach_bool,
                severity=severity,
                fix_status=None,  # DLP findings don't have fix_status
                finding_type="DLP",
            )

            fix_tag_display = _compute_fix_tag_display(
                finding_type="DLP",
                fix_status=None,
                fix_version=None,
                context_tag=None,  # b15: DLP has no context tags
            )

            # P2.21: Add missing fields for security issues table compatibility
            file_path = row[18] or ""
            line_start = row[19] or 1
            message = row[21] or f"{pii_type} detected"

            # Build location string (file:line format)
            location = file_path
            if line_start:
                location = f"{file_path}:{line_start}"

            # P2.60 FIX: Map DB reachability directly — no hardcoded overrides
            if is_reach_bool:
                reachability_state = "reachable"
            elif row[12] is None:
                reachability_state = "unknown"
            else:
                reachability_state = "not_reachable"

            findings.append(
                {
                    # DLP-specific fields (original)
                    "rule_id": row[0],
                    "finding_type": row[1],
                    "pii_type": pii_type,
                    "pii_sample": row[3],
                    "pii_count": row[4] or 1,
                    "sink_type": sink_type,
                    "sink_function": row[6],
                    "severity": severity,
                    "base_risk_score": row[8],
                    "adjusted_risk_score": row[9],
                    "file_class": row[10],
                    "file_class_modifier": row[11],
                    "is_reachable": is_reach_bool,
                    "reachability_confidence": row[13],
                    "call_paths_v2": json.loads(row[25]) if row[25] else [],
                    "sanitizer_present": bool(row[14]),
                    "sanitizer_type": row[15],
                    "sanitizer_effectiveness": row[16],
                    "regulations": regulations,
                    "file_path": file_path,
                    "line_start": line_start,
                    "line_end": row[20],
                    "message": message,
                    "remediation": row[22],
                    "detection_source": row[23],
                    "confidence": row[24],
                    # P2.20: Pre-computed display fields
                    "sla_display": sla_display,
                    "sla_class": sla_class,
                    "fix_tag_display": fix_tag_display,
                    # P2.21: Security issues table compatibility fields
                    "id": row[0],  # Use rule_id as ID
                    "type": "DLP",
                    "title": message,  # Use message as title
                    "description": message,  # Full description
                    "location": location,  # file:line format
                    "line": line_start,  # Single line number for table
                    "reachability_state": reachability_state,  # State string
                    "compliance_mapping": {  # NEW-1 FIX: DLP compliance tags
                        "OWASP": ["A02"],
                        "NIST": ["AC-4", "SC-7", "SI-10"],
                        "SOC2": ["CC6.1", "CC6.7", "P5.2"],
                        "PCI-DSS": ["3.3", "6.2.4"],
                        "GDPR": ["Art.25", "Art.32"],
                    },
                    "scanner": "reachable-dlp",  # NEW-6 FIX
                    "cwe_id": "",  # Empty for DLP
                    "package": "",  # Empty for DLP
                    "fix_available": False,  # DLP doesn't have fixes
                    "fix_status": None,  # DLP doesn't have fix status
                    "fix_version": None,  # DLP doesn't have fix versions
                }
            )

        if not findings:
            return None

        # P2.42: Separate discovery findings (PII exists) from data
        # loss (PII flows to sink)
        # Discovery = PII detected in source code, no external flow
        # Data Loss = PII flows to external sink (API, log, storage, etc.)
        discovery_findings = [f for f in findings if not f.get("sink_type") or f.get("sink_type") == "UNKNOWN"]
        data_loss_findings = [f for f in findings if f.get("sink_type") and f.get("sink_type") != "UNKNOWN"]

        unknown_count = sum(1 for f in findings if f.get("reachability_state") == "unknown")
        return {
            "total": len(findings),
            "reachable": reachable_count,
            "unknown": unknown_count,  # L4 FIX: expose unknown count for funnel builder
            "sanitized": sanitized_count,
            "by_pii_type": by_pii_type,
            "by_sink_type": by_sink_type,
            "by_severity": by_severity,
            "findings": findings,
            # P2.42: Separate discovery from data loss
            "discovery_count": len(discovery_findings),
            "data_loss_count": len(data_loss_findings),
            "discovery_findings": discovery_findings,
            "data_loss_findings": data_loss_findings,
        }

    except Exception as _dlp_load_err:
        logger.warning(f"load_dlp_findings_from_db failed: {_dlp_load_err}", exc_info=True)
        return None


def _convert_dlp_to_issues(dlp_findings: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """
    Convert DLP findings to simplified issue format for Action Required panel.

    P2.21 FIX: DLP findings were in separate dlp_findings array and not counted
    in Action Required breakdown. This converts them to match the issues schema
    so they appear in severity breakdowns alongside CVE/SECRET/CONFIG/CWE.

    The full detailed dlp_findings array is kept separate for the DLP panel.
    """
    simplified_issues = []

    for dlp in dlp_findings:
        # Build location string
        file_path = dlp.get("file_path", "")
        line_start = dlp.get("line_start")
        location = f"{file_path}:{line_start}" if line_start else file_path

        # P2.60 FIX: Map DB reachability directly — no hardcoded overrides
        is_reachable = dlp.get("is_reachable")
        if is_reachable is True or is_reachable == 1:
            reachability_state = "reachable"
        elif is_reachable is None:
            reachability_state = "unknown"
        else:
            reachability_state = "not_reachable"

        # Create simplified issue matching the standard issue schema
        simplified_issues.append(
            {
                "id": dlp.get("rule_id", ""),
                "type": "DLP",
                "severity": dlp.get("severity", "MEDIUM"),
                "raw_severity": dlp.get("severity", "MEDIUM"),
                "is_reachable": None if is_reachable is None else bool(is_reachable),  # L1 FIX: preserve tri-state
                "reachability_state": reachability_state,
                "title": dlp.get("message", f"{dlp.get('pii_type', 'PII')} detected"),
                "description": dlp.get("message", ""),
                "file_path": file_path,
                "location": location,
                "line": line_start or 1,
                "package": "",  # DLP doesn't have packages
                "cwe_id": "",  # DLP doesn't map to CWE
                "fix_available": False,  # DLP has sanitization guidance, not fixes
                "fix_status": None,
                "compliance_mapping": {  # NEW-1 FIX: DLP compliance tags
                    "OWASP": ["A02"],
                    "NIST": ["AC-4", "SC-7", "SI-10"],
                    "SOC2": ["CC6.1", "CC6.7", "P5.2"],
                    "PCI-DSS": ["3.3", "6.2.4"],
                    "GDPR": ["Art.25", "Art.32"],
                },
                # Keep minimal DLP-specific context
                "scanner": dlp.get("scanner", "reachable-dlp"),
                "pii_type": dlp.get("pii_type", "UNKNOWN"),
                "sink_type": dlp.get("sink_type", "UNKNOWN"),
                "sanitizer_present": dlp.get("sanitizer_present", False),
                # P2.21 FIX: Include pre-computed display fields for SLA
                "sla_display": dlp.get("sla_display", ""),
                "sla_class": dlp.get("sla_class", ""),
                "fix_tag_display": dlp.get("fix_tag_display", ""),
            }
        )

    return simplified_issues


def _convert_ai_to_issues(ai_findings: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """
    Convert AI findings to simplified issue format for issues array.

    P2.50 FIX: AI findings were in separate ai_security.findings array and not
    counted in issues[]. This converts them to match the issues schema so
    funnel and issues[] have matching counts.
    """
    simplified_issues = []

    for ai in ai_findings:
        # Determine reachability state
        # BUG-A2 FIX: default was False, which collapsed None (unknown) into not_reachable.
        # Use None as sentinel so tri-state (True / False / None) is preserved.
        is_reachable = ai.get("is_reachable", None)
        # BUG-A2 FIX: NONE-category reachability comes from DB, not hardcoded.
        # The banner already excludes NONE from its reachable count (reachable_actionable).
        # Forcing not_reachable here was wrong — trust DB value.
        if is_reachable is True:
            reachability_state = "reachable"
        elif is_reachable is False:
            reachability_state = "not_reachable"
        else:
            reachability_state = "unknown"

        # Build location string
        file_path = ai.get("file_path", "")
        line_start = ai.get("line_start")
        location = f"{file_path}:{line_start}" if line_start else file_path

        simplified_issues.append(
            {
                "id": ai.get("rule_id", "") or ai.get("policy_id", ""),
                "type": "AI",
                "severity": ai.get("severity", "MEDIUM"),
                # BUG-A2 FIX: preserve tri-state — bool(None) == False would lose "unknown"
                "is_reachable": None if is_reachable is None else bool(is_reachable),
                "reachability_state": reachability_state,
                "title": ai.get("owasp_name", "") or ai.get("message", "AI Security Finding"),
                "description": ai.get("message", ""),
                "file_path": file_path,
                "location": location,
                "line": line_start or 1,
                "package": "",
                "cwe_id": "",
                "owasp_llm": ai.get("owasp_llm", ""),
                "llm_category": ai.get("owasp_llm", ""),  # NOTE B FIX: alias for JS compatibility
                "owasp_category": ai.get("owasp_llm", ""),  # NOTE B FIX: alias for JS compatibility
                "call_paths_v2": ai.get("call_paths_v2", []),
                "compliance_mapping": ai.get("compliance_mapping", {}),
                "fix_available": False,
                "fix_status": None,
                # Pre-computed display fields
                "sla_display": ai.get("sla_display", ""),
                "sla_class": ai.get("sla_class", ""),
                "fix_tag_display": ai.get("fix_tag_display", ""),
            }
        )

    return simplified_issues


def load_ai_security_from_db(cursor, scan_id: Optional[int] = None) -> Optional[Dict[str, Any]]:
    """
    Load AI security findings from ai_findings table in repo.db

    v4.5.28: Added for OWASP LLM Top 10 dashboard support
    v4.5.37: Added scan_id filter to prevent accumulation across scans
    """
    try:
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='ai_findings'")
        if not cursor.fetchone():
            return None

        # v4.5.37: Filter by scan_id if provided
        # v4.5.38: Removed cwe_id from SELECT - AI findings don't have CWE mappings
        if scan_id:
            cursor.execute(
                """
                SELECT
                    rule_id, policy_id, owasp_category, owasp_name, severity,
                    base_risk_score, adjusted_risk_score, is_reachable,
                    guards, guard_risk_reduction,
                    file_path, line_start, line_end, message,
                    framework, provider, detection_source, call_paths_v2
                FROM ai_findings
                WHERE scan_id = ?
                ORDER BY adjusted_risk_score DESC
            """,
                (scan_id,),
            )
        else:
            cursor.execute("""
                SELECT
                    rule_id, policy_id, owasp_category, owasp_name, severity,
                    base_risk_score, adjusted_risk_score, is_reachable,
                    guards, guard_risk_reduction,
                    file_path, line_start, line_end, message,
                    framework, provider, detection_source, call_paths_v2
                FROM ai_findings
                ORDER BY adjusted_risk_score DESC
            """)

        findings = []
        by_owasp = {}  # Total counts
        by_owasp_breakdown = {}  # {cat: {reachable:N, unreachable:N, unknown:N}}
        by_severity = {"CRITICAL": 0, "HIGH": 0, "MEDIUM": 0, "LOW": 0}

        # BUG 36 FIX: Normalize legacy non-OWASP categories → real LLM categories at read time.
        # MCP/MCP_SECURITY = Excessive Agency = LLM06 (per AI-SECURITY-DETECTION-SPEC.md)
        # CONTROLS = missing guardrails = LLM06. PRIMITIVE = informational = NONE.
        _OWASP_CAT_REMAP = {
            "MCP": "LLM06",
            "MCP_SECURITY": "LLM06",
            "CONTROLS": "LLM06",
            "MODEL_CONTROLS": "LLM06",
            "PRIMITIVE": "NONE",
            "AI_PRIMITIVE": "NONE",
        }

        for row in cursor.fetchall():
            raw_cat = (row[2] or "NONE").upper()
            owasp_cat = _OWASP_CAT_REMAP.get(raw_cat, raw_cat)
            raw_severity = (row[4] or "WARNING").upper()
            # P2.45 FIX: Normalize AI severity to standard levels BEFORE aggregation
            severity_map = {
                "CRITICAL": "CRITICAL",
                "HIGH": "HIGH",
                "ERROR": "HIGH",
                "MEDIUM": "MEDIUM",
                "WARNING": "MEDIUM",
                "LOW": "LOW",
                "INFO": "LOW",
            }
            severity = severity_map.get(raw_severity, "MEDIUM")
            is_reach = row[7]

            by_owasp[owasp_cat] = by_owasp.get(owasp_cat, 0) + 1
            if owasp_cat not in by_owasp_breakdown:
                by_owasp_breakdown[owasp_cat] = {"reachable": 0, "unreachable": 0, "unknown": 0}
            # SQLite stores booleans as 0/1 integers, use == not is
            if is_reach == 1:
                by_owasp_breakdown[owasp_cat]["reachable"] += 1
            elif is_reach == 0:
                by_owasp_breakdown[owasp_cat]["unreachable"] += 1
            else:
                by_owasp_breakdown[owasp_cat]["unknown"] += 1
            if severity in by_severity:
                by_severity[severity] += 1

            # Parse guards from JSON
            guards = []
            try:
                if row[8]:
                    guards = json.loads(row[8])
            except Exception:
                pass

            # Build compliance mapping for AI findings
            # v4.5.38: AI findings use OWASP LLM Top 10, not CWE
            ai_compliance = {}
            if owasp_cat == "NONE":
                # NEW-2 FIX: NONE-cat (PRIMITIVE/informational) gets base AI compliance
                ai_compliance["NIST"] = ["CA-7", "RA-5"]
                ai_compliance["SOC2"] = ["CC7.1"]
            if owasp_cat and owasp_cat != "NONE":
                ai_compliance["OWASP_LLM"] = [owasp_cat]
                # Map OWASP LLM to compliance frameworks
                # LLM01 (Prompt Injection), LLM05 (Improper Output), LLM06 (Excessive Agency) are critical security issues
                if owasp_cat in ["LLM01", "LLM05", "LLM06"]:
                    ai_compliance["NIST"] = ["AC-4", "SC-7", "SI-10"]
                    ai_compliance["FedRAMP"] = ["AC-4", "SC-7", "SI-10"]
                    ai_compliance["CMMC"] = ["AC.L2-3.1.3", "SC.L2-3.13.1"]
                # LLM02 (Sensitive Info Disclosure), LLM07 (System Prompt Leakage)
                elif owasp_cat in ["LLM02", "LLM07"]:
                    ai_compliance["NIST"] = ["AC-3", "SC-8", "SC-28"]
                    ai_compliance["FedRAMP"] = ["AC-3", "SC-8", "SC-28"]
                    ai_compliance["CMMC"] = ["AC.L2-3.1.1", "SC.L2-3.13.8"]
                # LLM03 (Supply Chain), LLM04 (Data Poisoning)
                elif owasp_cat in ["LLM03", "LLM04"]:
                    ai_compliance["NIST"] = ["SA-12", "SR-3", "SR-4"]
                    ai_compliance["FedRAMP"] = ["SA-12", "SR-3", "SR-4"]
                    ai_compliance["CMMC"] = ["SR.L2-3.17.1", "SR.L2-3.17.2"]

            # P2.20: Compute SLA and fix tag for AI findings
            # BUG-A2 FIX: bool(None) == False, which misclassifies unknown as not_reachable.
            # Use explicit == 1 so only confirmed-reachable findings get the short SLA.
            is_reach_bool = (row[7] == 1)  # True only when SQLite stores 1, not for NULL

            sla_display, sla_class = _compute_sla_display(
                is_reachable=is_reach_bool,
                severity=severity,
                fix_status=None,  # AI findings don't have fix_status
                finding_type="AI",
            )

            fix_tag_display = _compute_fix_tag_display(
                finding_type="AI",
                fix_status=None,
                fix_version=None,
                context_tag=None,  # b15: AI has no context tags
            )

            # v4.5.38: Removed row indices - cwe_id removed from SELECT
            # New indices: message=14, framework=15, provider=16, detection_source=17
            findings.append(
                {
                    "rule_id": row[0],
                    "policy_id": row[1],
                    "owasp_llm": owasp_cat,
                    "llm_category": owasp_cat,
                    "owasp_category": owasp_cat,  # NOTE B FIX: DB column name alias for JS compatibility
                    "owasp_name": row[3],
                    "severity": severity,
                    "base_risk_score": row[5],
                    "adjusted_risk_score": row[6],
                    "is_reachable": None if row[7] is None else bool(row[7]),  # L2 FIX: preserve tri-state
                    "call_paths_v2": json.loads(row[17]) if row[17] else [],
                    "guards": guards,
                    "guard_risk_reduction": row[9],
                    "file_path": row[10],
                    "line_start": row[11],
                    "line_end": row[12],
                    "message": row[13],
                    "framework": row[14],
                    "provider": row[15],
                    "detection_source": row[16],
                    "compliance_mapping": ai_compliance,
                    # P2.20: Pre-computed display fields
                    "sla_display": sla_display,
                    "sla_class": sla_class,
                    "fix_tag_display": fix_tag_display,
                }
            )

        if not findings:
            return None

        # v4.5.31: Compute reachable count for AI findings
        reachable_count = sum(1 for f in findings if f.get("is_reachable"))
        unknown_count = sum(1 for f in findings if f.get("is_reachable") is None)

        # BUG-CTR-01 FIX: total_actionable excludes NONE (PRIMITIVE/informational)
        # so the banner count matches what the pipeline stages actually show.
        none_count = by_owasp.get("NONE", 0)

        # BUG-AI-BANNER FIX: reachable/unknown must also exclude NONE for
        # the AI Attack Surface banner.  Previously reachable=12 included
        # 9 NONE-category findings while totalAI subtracted all 16 NONE,
        # producing the impossible display "12 reachable / 5 total".
        none_breakdown = by_owasp_breakdown.get("NONE", {"reachable": 0, "unreachable": 0, "unknown": 0})
        reachable_actionable = reachable_count - none_breakdown.get("reachable", 0)
        unknown_actionable = unknown_count - none_breakdown.get("unknown", 0)

        return {
            "total": len(findings),
            "total_actionable": len(findings) - none_count,
            "reachable": reachable_actionable,  # BUG-AI-BANNER FIX: excludes NONE
            "reachable_all": reachable_count,  # includes NONE (for funnel)
            "unknown": unknown_actionable,  # BUG-AI-BANNER FIX: excludes NONE
            "unknown_all": unknown_count,  # includes NONE (for funnel)
            "by_owasp": by_owasp,
            "by_owasp_breakdown": by_owasp_breakdown,
            "by_severity": by_severity,
            "findings": findings,
        }

    except Exception as _ai_load_err:
        import logging as _logging

        _logging.getLogger(__name__).warning(f"load_ai_security_from_db failed: {_ai_load_err}", exc_info=True)
        return None


def get_repo_metadata(scan_dir: Path) -> Dict[str, Any]:
    """
    Get repo-level metadata from repo.db: scan count, first scan date, db size
    """
    try:
        repo_root = scan_dir.parent.parent
        repo_db = repo_root / "repo.db"

        if not repo_db.exists():
            branch_dir = scan_dir.parent
            scan_dirs = sorted(
                [d for d in branch_dir.iterdir() if d.is_dir() and d.name[0].isdigit() and len(d.name) >= 15]
            )
            return {
                "scan_number": len(scan_dirs),
                "first_scan": scan_dirs[0].name[:8] if scan_dirs else "",
                "db_size_display": "N/A",
            }

        conn = sqlite3.connect(str(repo_db))
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA busy_timeout=30000")  # P2.60a: concurrency hardening
        cursor = conn.cursor()

        cursor.execute("SELECT COUNT(*) as cnt FROM scans WHERE status = 'complete'")
        scan_count = cursor.fetchone()["cnt"]

        cursor.execute("""
            SELECT MIN(timestamp) as first_scan
            FROM scans WHERE status = 'complete'
        """)
        row = cursor.fetchone()
        first_scan = row["first_scan"] if row else None

        first_scan_display = ""
        if first_scan:
            try:
                from datetime import datetime

                dt = datetime.fromisoformat(first_scan.replace("Z", "+00:00"))
                first_scan_display = dt.strftime("%Y-%m-%d")
            except Exception:
                first_scan_display = first_scan[:10] if len(first_scan) >= 10 else first_scan

        conn.close()

        db_size_bytes = repo_db.stat().st_size
        db_size_mb = round(db_size_bytes / (1024 * 1024), 2)

        return {
            "scan_number": scan_count,
            "first_scan": first_scan_display,
            "db_size_mb": db_size_mb,
            "db_size_display": f"{db_size_mb} MB" if db_size_mb >= 1 else f"{round(db_size_bytes / 1024, 1)} KB",
        }

    except Exception as e:
        return {"error": str(e)}


def get_scan_history(repo_root: Path, days: int = 30) -> List[Dict[str, Any]]:
    """Get scan history for trends visualization

    P2.50 FIX: Now takes repo_root directly (where repo.db lives)
    instead of scan_dir.
    """
    try:
        # P2.50: repo_root is now passed directly, repo.db is here
        repo_db = repo_root / "repo.db"

        if not repo_db.exists():
            return []

        conn = sqlite3.connect(str(repo_db))
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA busy_timeout=30000")  # P2.60a: concurrency hardening
        cursor = conn.cursor()

        cursor.execute("PRAGMA table_info(scans)")
        columns = [col[1] for col in cursor.fetchall()]
        has_config = "config_count" in columns
        has_unknown = "unknown_count" in columns

        if has_config and has_unknown:
            cursor.execute(
                """
                SELECT
                    id, timestamp, branch, total_findings, reachable_findings,
                    critical_count, high_count, medium_count, low_count,
                    risk_level, config_count, unknown_count
                FROM scans
                WHERE status = 'complete'
                AND timestamp >= datetime('now', '-' || ? || ' days')
                ORDER BY timestamp ASC
            """,
                (days,),
            )
        elif has_config:
            cursor.execute(
                """
                SELECT
                    id, timestamp, branch, total_findings, reachable_findings,
                    critical_count, high_count, medium_count, low_count,
                    risk_level, config_count
                FROM scans
                WHERE status = 'complete'
                AND timestamp >= datetime('now', '-' || ? || ' days')
                ORDER BY timestamp ASC
            """,
                (days,),
            )
        else:
            cursor.execute(
                """
                SELECT
                    id, timestamp, branch, total_findings, reachable_findings,
                    critical_count, high_count, medium_count, low_count,
                    risk_level
                FROM scans
                WHERE status = 'complete'
                AND timestamp >= datetime('now', '-' || ? || ' days')
                ORDER BY timestamp ASC
            """,
                (days,),
            )

        history = []
        for row in cursor.fetchall():
            try:
                config = row["config_count"] or 0
            except (IndexError, KeyError):
                config = 0
            try:
                unknown = row["unknown_count"] or 0
            except (IndexError, KeyError):
                unknown = 0

            # v5.1.3: Query findings + ai_findings + dlp_findings tables
            # for accurate trends that include ALL signal types.
            scan_id = row["id"]

            try:
                # P2.55 FIX: Exclude CONFIG from severity counts too
                # Previously CONFIG findings were subtracted from total but
                # still counted in critical/high/medium/low, causing
                # hover box totals to not match the trend line values.
                # P2.55 FIX: Normalize severity in SQL — ERROR→CRITICAL, WARNING→MEDIUM
                # Semgrep stores CWE severity as 'ERROR' (their highest level) but
                # REACHABLE normalizes to 'CRITICAL'. Without this, CWE findings
                # with ERROR severity fall through all CASE branches uncounted,
                # causing hover totals to not add up to the trend line value.
                cursor.execute(
                    """
                    SELECT
                        COUNT(*) as total,
                        SUM(CASE WHEN app_reachability = 'REACHABLE' AND LOWER(finding_type) != 'config' THEN 1 ELSE 0 END) as reachable,
                        SUM(CASE WHEN UPPER(severity) IN ('CRITICAL', 'ERROR') AND LOWER(finding_type) != 'config' THEN 1 ELSE 0 END) as critical,
                        SUM(CASE WHEN UPPER(severity) = 'HIGH' AND LOWER(finding_type) != 'config' THEN 1 ELSE 0 END) as high,
                        SUM(CASE WHEN UPPER(severity) IN ('MEDIUM', 'WARNING') AND LOWER(finding_type) != 'config' THEN 1 ELSE 0 END) as medium,
                        SUM(CASE WHEN UPPER(severity) IN ('LOW', 'INFO') AND LOWER(finding_type) != 'config' THEN 1 ELSE 0 END) as low,
                        SUM(CASE WHEN LOWER(finding_type) = 'config' THEN 1 ELSE 0 END) as config_findings,
                        SUM(CASE WHEN UPPER(severity) IN ('CRITICAL','ERROR') AND app_reachability IN ('REACHABLE','UNKNOWN') AND LOWER(finding_type) != 'config' THEN 1 ELSE 0 END) as act_critical,
                        SUM(CASE WHEN UPPER(severity) = 'HIGH' AND app_reachability IN ('REACHABLE','UNKNOWN') AND LOWER(finding_type) != 'config' THEN 1 ELSE 0 END) as act_high,
                        SUM(CASE WHEN UPPER(severity) IN ('MEDIUM','WARNING') AND app_reachability IN ('REACHABLE','UNKNOWN') AND LOWER(finding_type) != 'config' THEN 1 ELSE 0 END) as act_medium,
                        SUM(CASE WHEN UPPER(severity) IN ('LOW','INFO') AND app_reachability IN ('REACHABLE','UNKNOWN') AND LOWER(finding_type) != 'config' THEN 1 ELSE 0 END) as act_low
                    FROM findings WHERE scan_id = ?
                """,
                    (scan_id,),
                )
                f_row = cursor.fetchone()
                findings_total = f_row["total"] or 0
                findings_reachable = f_row["reachable"] or 0
                findings_critical = f_row["critical"] or 0
                findings_high = f_row["high"] or 0
                findings_medium = f_row["medium"] or 0
                findings_low = f_row["low"] or 0
                findings_config = f_row["config_findings"] or 0
                act_critical = f_row["act_critical"] or 0
                act_high = f_row["act_high"] or 0
                act_medium = f_row["act_medium"] or 0
                act_low = f_row["act_low"] or 0

                # P2.56: Per-signal-type reachable counts for trends breakdown
                cursor.execute(
                    """
                    SELECT
                        UPPER(finding_type) as ftype,
                        COUNT(*) as total,
                        SUM(CASE WHEN app_reachability = 'REACHABLE' THEN 1 ELSE 0 END) as reachable
                    FROM findings
                    WHERE scan_id = ? AND LOWER(finding_type) != 'config'
                    GROUP BY UPPER(finding_type)
                """,
                    (scan_id,),
                )
                signal_counts = {}
                for sig_row in cursor.fetchall():
                    ftype = sig_row["ftype"] or "OTHER"
                    signal_counts[ftype] = {
                        "total": sig_row["total"] or 0,
                        "reachable": sig_row["reachable"] or 0,
                    }

                # v5.1.3 FIX D1: Include AI and DLP in trends
                # Previously excluded — caused trends to undercount by ~160 findings
                try:
                    cursor.execute(
                        """
                        SELECT
                            COUNT(*) as total,
                            SUM(CASE WHEN is_reachable = 1 THEN 1 ELSE 0 END) as reachable,
                            SUM(CASE WHEN UPPER(severity) IN ('CRITICAL', 'ERROR') THEN 1 ELSE 0 END) as critical,
                            SUM(CASE WHEN UPPER(severity) = 'HIGH' THEN 1 ELSE 0 END) as high,
                            SUM(CASE WHEN UPPER(severity) IN ('MEDIUM', 'WARNING') THEN 1 ELSE 0 END) as medium,
                            SUM(CASE WHEN UPPER(severity) IN ('LOW', 'INFO') THEN 1 ELSE 0 END) as low
                        FROM ai_findings WHERE scan_id = ?
                    """,
                        (scan_id,),
                    )
                    ai_row = cursor.fetchone()
                    ai_total = ai_row["total"] or 0
                    if ai_total > 0:
                        ai_reachable = ai_row["reachable"] or 0
                        findings_total += ai_total
                        findings_reachable += ai_reachable
                        findings_critical += ai_row["critical"] or 0
                        findings_high += ai_row["high"] or 0
                        findings_medium += ai_row["medium"] or 0
                        findings_low += ai_row["low"] or 0
                        act_critical += ai_row["critical"] or 0
                        act_high += ai_row["high"] or 0
                        act_medium += ai_row["medium"] or 0
                        act_low += ai_row["low"] or 0
                        signal_counts["AI"] = {"total": ai_total, "reachable": ai_reachable}
                except sqlite3.OperationalError:
                    pass  # Table may not exist in older DBs

                try:
                    cursor.execute(
                        """
                        SELECT
                            COUNT(*) as total,
                            SUM(CASE WHEN is_reachable = 1 THEN 1 ELSE 0 END) as reachable,
                            SUM(CASE WHEN UPPER(severity) IN ('CRITICAL', 'ERROR') THEN 1 ELSE 0 END) as critical,
                            SUM(CASE WHEN UPPER(severity) = 'HIGH' THEN 1 ELSE 0 END) as high,
                            SUM(CASE WHEN UPPER(severity) IN ('MEDIUM', 'WARNING') THEN 1 ELSE 0 END) as medium,
                            SUM(CASE WHEN UPPER(severity) IN ('LOW', 'INFO') THEN 1 ELSE 0 END) as low
                        FROM dlp_findings WHERE scan_id = ?
                    """,
                        (scan_id,),
                    )
                    dlp_row = cursor.fetchone()
                    dlp_total = dlp_row["total"] or 0
                    if dlp_total > 0:
                        dlp_reachable = dlp_row["reachable"] or 0
                        findings_total += dlp_total
                        findings_reachable += dlp_reachable
                        findings_critical += dlp_row["critical"] or 0
                        findings_high += dlp_row["high"] or 0
                        findings_medium += dlp_row["medium"] or 0
                        findings_low += dlp_row["low"] or 0
                        act_critical += dlp_row["critical"] or 0
                        act_high += dlp_row["high"] or 0
                        act_medium += dlp_row["medium"] or 0
                        act_low += dlp_row["low"] or 0
                        signal_counts["DLP"] = {"total": dlp_total, "reachable": dlp_reachable}
                except sqlite3.OperationalError:
                    pass  # Table may not exist in older DBs

            except Exception:
                # Fallback to scans table if findings query fails
                findings_total = row["total_findings"] or 0
                findings_reachable = row["reachable_findings"] or 0
                findings_critical = row["critical_count"] or 0
                findings_high = row["high_count"] or 0
                findings_medium = row["medium_count"] or 0
                findings_low = row["low_count"] or 0
                findings_config = config
                act_critical = act_high = act_medium = act_low = 0
                signal_counts = {}

            history.append(
                {
                    "scan_id": scan_id,
                    "timestamp": row["timestamp"],
                    "branch": row["branch"],
                    "total_issues": findings_total - findings_config,
                    "reachable_issues": findings_reachable,
                    "critical": findings_critical,
                    "high": findings_high,
                    "medium": findings_medium,
                    "low": findings_low,
                    "risk_level": row["risk_level"] or "UNKNOWN",
                    "unknown_reachability": unknown,
                    "config_count": findings_config,
                    "actionable_critical": act_critical,
                    "actionable_high": act_high,
                    "actionable_medium": act_medium,
                    "actionable_low": act_low,
                    "signals": signal_counts,
                }
            )

        conn.close()
        return history

    except Exception as _hist_err:
        logger.warning(f"get_scan_history failed: {_hist_err}", exc_info=True)
        return []


# --- Private helpers for database loading ---


def _get_latest_scan_id(cursor, branch: str = None) -> Optional[int]:
    """
    Get the latest completed scan_id from the database, scoped to branch.

    v4.5.37: Added to fix accumulation bug - all queries should filter by this scan_id
    BRANCH-SCOPE FIX: repo.db is shared across branches; without branch filter
    this returns the latest scan from ANY branch, showing wrong-branch data.
    """
    try:
        if branch:
            cursor.execute(
                "SELECT id FROM scans WHERE status = 'complete' AND branch = ? ORDER BY id DESC LIMIT 1",
                (branch,)
            )
        else:
            cursor.execute("SELECT id FROM scans WHERE status = 'complete' ORDER BY id DESC LIMIT 1")
        row = cursor.fetchone()
        if row:
            return row["id"] if isinstance(row, dict) or hasattr(row, "keys") else row[0]
    except Exception:
        pass
    return None


def _get_stored_risk_level(cursor) -> Optional[str]:
    """Read risk_level from scans table — only from completed scans."""
    try:
        cursor.execute("SELECT risk_level FROM scans WHERE status = 'complete' ORDER BY id DESC LIMIT 1")
        row = cursor.fetchone()
        if row and row["risk_level"]:
            return row["risk_level"]
    except Exception:
        pass
    return None


def _try_github_url(repo_path_str: str) -> str:
    """Try to extract GitHub/GitLab/Bitbucket URL from git remote."""
    if not repo_path_str:
        return ""
    try:
        import subprocess

        result = subprocess.run(
            ["git", "-C", repo_path_str, "remote", "get-url", "origin"],
            capture_output=True,
            text=True,
            timeout=5,
        )
        url = result.stdout.strip()
        if url:
            if url.startswith("git@"):
                url = url.replace(":", "/").replace("git@", "https://")
            url = url.removesuffix(".git")
            if "github.com" in url or "gitlab.com" in url or "bitbucket.org" in url:
                return url
    except Exception:
        pass
    return ""


def _enrich_metadata_from_scan_plan(metadata: Dict[str, Any], db_path: Path) -> None:
    """
    v5.1.5: Enrich scan metadata with repo_root/github_url from scan-plan.json.

    When the scans table lacks repo_path (common in older DBs), the dashboard
    has no repo_root or github_url, causing VCS links to break. This fallback
    searches for scan-plan.json which always has repo_path.
    """
    repo_root_dir = Path(db_path).parent  # e.g. ~/.reachable/scans/repo-hash/

    # Find the latest scan directory containing scan-plan.json
    scan_plan = None
    try:
        for branch_dir in sorted(repo_root_dir.iterdir(), reverse=True):
            if not branch_dir.is_dir() or branch_dir.name == "__pycache__":
                continue
            for scan_dir in sorted(branch_dir.iterdir(), reverse=True):
                if not scan_dir.is_dir():
                    continue
                candidate = scan_dir / "scan-plan.json"
                if candidate.exists():
                    with open(candidate) as f:
                        scan_plan = json.load(f)
                    break
            if scan_plan:
                break
    except Exception:
        return

    if not scan_plan:
        return

    repo_path = scan_plan.get("repo_path", "")
    if not repo_path:
        return

    metadata["repo_root"] = repo_path
    if not metadata.get("repository") or metadata["repository"] == "unknown":
        metadata["repository"] = Path(repo_path).name
        metadata["display"] = Path(repo_path).name
    if not metadata.get("github_url"):
        metadata["github_url"] = _try_github_url(repo_path)
    # Also set branch from scan-plan if missing
    if not metadata.get("branch") or metadata["branch"] == "main":
        metadata["branch"] = scan_plan.get("branch", metadata.get("branch", "main"))


def _get_scan_metadata(cursor) -> Dict[str, Any]:
    """Extract scan metadata from database"""

    # v5.1.4: Also extract github_url from git remote config
    # Consolidated: delegates to module-level _try_github_url (identical logic)
    _try_github_url_inner = _try_github_url

    try:
        cursor.execute("SELECT * FROM scan_summary LIMIT 1")
        row = cursor.fetchone()
        if row:
            repo_path = row["repo_path"] if row["repo_path"] else ""
            if repo_path:
                return {
                    "repository": repo_path.split("/")[-1],
                    "branch": "main",
                    "commit": "",
                    "display": repo_path.split("/")[-1],
                    "repo_root": repo_path,
                    "github_url": _try_github_url(repo_path),
                }
    except Exception:
        pass

    try:
        # v5.1.6 FIX: Use actual column names (scan_dir, commit_hash) not repo_path/commit_sha
        cursor.execute("""
            SELECT scan_dir, branch, commit_hash, commit_short
            FROM scans
            ORDER BY id DESC LIMIT 1
        """)
        row = cursor.fetchone()
        if row:
            scan_dir_val = row["scan_dir"] if "scan_dir" in row.keys() else ""
            # Derive repo_path from scan-plan.json in scan_dir
            repo_path = ""
            if scan_dir_val:
                try:
                    plan_path = Path(scan_dir_val) / "scan-plan.json"
                    if plan_path.exists():
                        with open(plan_path) as _f:
                            _plan = json.load(_f)
                            repo_path = _plan.get("repo_path", "") or _plan.get("app_dir", "")
                except Exception:
                    pass
            if repo_path:
                return {
                    "repository": Path(repo_path).name,
                    "branch": row["branch"] if "branch" in row.keys() else "main",
                    "commit": (row["commit_short"] or "")[:8] if "commit_short" in row.keys() else "",
                    "display": Path(repo_path).name,
                    "repo_root": repo_path,
                    "github_url": _try_github_url(repo_path),
                }
    except Exception:
        pass

    # v4.5.33: Fallback to scan-plan.json for repo name (fixed exception handling)
    scan_dir = None
    try:
        cursor.execute("SELECT scan_dir FROM scans ORDER BY id DESC LIMIT 1")
        scan_row = cursor.fetchone()
        if scan_row and "scan_dir" in scan_row.keys():
            scan_dir = scan_row["scan_dir"]
    except Exception:
        pass

    if scan_dir:
        try:
            scan_plan_path = Path(scan_dir) / "scan-plan.json"
            if scan_plan_path.exists():
                with open(scan_plan_path) as f:
                    plan = json.load(f)
                    repo_path = plan.get("repo_path", "") or plan.get("app_dir", "")
                    if repo_path:
                        return {
                            "repository": Path(repo_path).name,
                            "branch": plan.get("branch", "main"),
                            "commit": "",
                            "display": Path(repo_path).name,
                            "repo_root": str(repo_path),
                            "github_url": _try_github_url(str(repo_path)),
                        }
        except Exception:
            pass

    # v4.5.34: Final fallback - extract repo name from scan_dir path structure
    # scan_dir format: ~/.reachable/scans/<repo-name-hash>/<branch>/<timestamp>/
    if scan_dir:
        try:
            path_parts = Path(scan_dir).parts
            # Find the 'scans' directory and get the next part (repo folder)
            for i, part in enumerate(path_parts):
                if part == "scans" and i + 1 < len(path_parts):
                    repo_folder = path_parts[i + 1]
                    # repo_folder is like "my-repo-abc123" - strip hash suffix
                    # Hash is typically 8 hex chars at the end
                    if len(repo_folder) > 9 and repo_folder[-8:].replace("-", "").isalnum():
                        repo_name = repo_folder[:-9] if repo_folder[-9] == "-" else repo_folder
                    else:
                        repo_name = repo_folder
                    if repo_name:
                        # v5.1.5 FIX: Try to recover repo_root from scan-plan.json
                        # Without repo_root, VCS links for relative paths are broken
                        fallback_repo_root = ""
                        try:
                            plan_path = Path(scan_dir) / "scan-plan.json"
                            if plan_path.exists():
                                with open(plan_path) as _f:
                                    _plan = json.load(_f)
                                    fallback_repo_root = _plan.get("repo_path", "") or _plan.get("app_dir", "")
                        except Exception:
                            pass
                        return {
                            "repository": repo_name,
                            "branch": path_parts[i + 2] if i + 2 < len(path_parts) else "main",
                            "commit": "",
                            "display": repo_name,
                            "repo_root": fallback_repo_root,
                            "github_url": _try_github_url(fallback_repo_root) if fallback_repo_root else "",
                        }
        except Exception:
            pass

    return {
        "repository": "unknown",
        "branch": "main",
        "commit": "",
        "display": "unknown",
        "repo_root": "",
        "github_url": "",
    }


def _get_issues_summary(cursor, scan_id: Optional[int] = None) -> Dict[str, int]:
    """
    Get aggregated findings counts from database.

    v4.5.37: Added scan_id filter to prevent accumulation across scans
    """
    summary = {
        "cves_total": 0,
        "cves_reachable": 0,
        "cves_critical": 0,
        "cves_high": 0,
        "cves_medium": 0,
        "cves_low": 0,
        "secrets_total": 0,
        "secrets_reachable": 0,
        "secrets_unknown": 0,  # P2.21: Track unknown secrets separately
        "cwe_total": 0,
        "cwe_reachable": 0,
        "config_total": 0,
        "config_unknown": 0,
        "malware_total": 0,
        "packages_scanned": 0,  # AU-M4: distinct packages with findings for this scan
    }

    try:
        # v4.5.37: Filter by scan_id to get only current scan findings
        if scan_id:
            cursor.execute(
                """
                SELECT
                    finding_type,
                    severity,
                    app_reachability,
                    COUNT(*) as count
                FROM findings
                WHERE scan_id = ?
                GROUP BY finding_type, severity, app_reachability
            """,
                (scan_id,),
            )
        else:
            cursor.execute("""
                SELECT
                    finding_type,
                    severity,
                    app_reachability,
                    COUNT(*) as count
                FROM findings
                GROUP BY finding_type, severity, app_reachability
            """)
    except Exception as _sum_err:
        logger.warning(f"_get_issues_summary query failed: {_sum_err}", exc_info=True)
        return summary

    for row in cursor.fetchall():
        ftype = (row["finding_type"] or "").lower()
        sev = (row["severity"] or "").upper()
        reachability = (row["app_reachability"] or "").upper()
        count = row["count"]

        # FIX: Proper reachability mapping
        # REACHABLE → reachable
        # NOT_REACHABLE → not reachable
        # UNKNOWN → depends on type (secrets=reachable, config=unknown)
        is_reachable = reachability == "REACHABLE"
        is_unknown = reachability == "UNKNOWN"

        if ftype == "cve":
            summary["cves_total"] += count
            if is_reachable:
                summary["cves_reachable"] += count
            if sev == "CRITICAL":
                summary["cves_critical"] += count
            elif sev == "HIGH":
                summary["cves_high"] += count
            elif sev == "MEDIUM":
                summary["cves_medium"] += count
            elif sev == "LOW":
                summary["cves_low"] += count

        elif ftype == "secret":
            summary["secrets_total"] += count
            # P2.21 FIX: Only REACHABLE secrets count as reachable, not UNKNOWN
            if is_reachable:
                summary["secrets_reachable"] += count
            # Add secrets_unknown metric
            if is_unknown:
                if "secrets_unknown" not in summary:
                    summary["secrets_unknown"] = 0
                summary["secrets_unknown"] += count

        elif ftype == "cwe":
            summary["cwe_total"] += count
            if is_reachable:
                summary["cwe_reachable"] += count

        elif ftype == "config":
            summary["config_total"] += count
            # P2.60 FIX: Use actual DB reachability from correlation engine — NOT hardcoded
            if is_reachable:
                summary["config_reachable"] = summary.get("config_reachable", 0) + count
            elif is_unknown:
                summary["config_unknown"] += count

        elif ftype == "malware":
            summary["malware_total"] += count
            # P2.60 FIX: Track malware reachability — static malware may NOT be reachable
            if is_reachable:
                summary["malware_reachable"] = summary.get("malware_reachable", 0) + count
            if is_unknown:
                summary["malware_unknown"] = summary.get("malware_unknown", 0) + count

        elif ftype == "suspicious":
            summary["suspicious_total"] = summary.get("suspicious_total", 0) + count
            if is_reachable:
                summary["suspicious_reachable"] = summary.get("suspicious_reachable", 0) + count
            if is_unknown:
                summary["suspicious_unknown"] = summary.get("suspicious_unknown", 0) + count

    # AU-M4: Count distinct packages with CVE findings as packages_scanned proxy
    # (sbom_cache.package_count is per-commit and not easily joined here;
    #  distinct CVE package_name is the best available scan-scoped count)
    try:
        if scan_id:
            pkg_row = cursor.execute(
                "SELECT COUNT(DISTINCT package_name) FROM findings "
                "WHERE scan_id = ? AND finding_type = 'cve' AND package_name != ''",
                (scan_id,),
            ).fetchone()
        else:
            pkg_row = cursor.execute(
                "SELECT COUNT(DISTINCT package_name) FROM findings WHERE finding_type = 'cve' AND package_name != ''"
            ).fetchone()
        summary["packages_scanned"] = pkg_row[0] if pkg_row else 0
    except Exception:
        pass  # Non-critical: metric stays 0

    # BUG #1 FIX: Count CVEs with no fix available.
    # DB stores fix_status='no_fix' (and variants) for unfixable CVEs.
    # Previously this field was never computed — metrics.py returned 0 via .get('cves_no_fix', 0).
    try:
        no_fix_statuses = "('no_fix', 'not-fixed', 'wont_fix', 'not_fixed')"
        if scan_id:
            nf_row = cursor.execute(
                f"SELECT COUNT(*) FROM findings "
                f"WHERE scan_id = ? AND LOWER(finding_type) = 'cve' "
                f"AND LOWER(COALESCE(fix_status,'')) IN {no_fix_statuses}",
                (scan_id,),
            ).fetchone()
        else:
            nf_row = cursor.execute(
                f"SELECT COUNT(*) FROM findings "
                f"WHERE LOWER(finding_type) = 'cve' "
                f"AND LOWER(COALESCE(fix_status,'')) IN {no_fix_statuses}"
            ).fetchone()
        summary["cves_no_fix"] = nf_row[0] if nf_row else 0
    except Exception:
        summary["cves_no_fix"] = 0  # Non-critical: degrade gracefully

    return summary


def _get_all_issues(cursor, scan_id: Optional[int] = None) -> List[Dict[str, Any]]:
    """
    Get all findings for the issues table.

    v4.5.37: Added scan_id filter to prevent accumulation across scans
    v4.5.41: Added fix_status, fix_version for CVE fix availability display
    T-CG28: Build SELECT dynamically — substitute NULL AS col for missing columns
            so sparse test schemas (and older production DBs) don't raise OperationalError.
    """
    findings = []

    try:
        # Detect which columns actually exist in this DB's findings table.
        # Older DBs and test fixtures may be missing recently-added columns.
        cursor.execute("PRAGMA table_info(findings)")
        existing_cols = {row[1] for row in cursor.fetchall()}

        # All columns we want to SELECT, in order.  Missing ones become NULL.
        wanted = [
            "id",
            "finding_type",
            "finding_id",
            "display_id",
            "ghsa_id",
            "id_note",
            "severity",
            "title",
            "description",
            "file_path",
            "line_number",
            "package_name",
            "package_version",
            "app_reachability",
            "app_reachability_confidence",
            "cwe_id",
            "fix_status",
            "fix_version",
            "scanner",
            "evidence_static",
            "evidence_dynamic",
            "is_transitive",
            "via_package",
            "dependency_chain",
            "dependency_depth",
            "fix_version_raw",
            "cvss_score",
            "epss_score",
            "epss_percentile",
            "is_kev",
            "go_vuln_id",
            "fix_commit_url",
            "call_paths_v2",
            "containing_function",
            "reachability_reason",
            "raw_data",
            "type_detail",
        ]
        col_exprs = [col if col in existing_cols else f"NULL AS {col}" for col in wanted]
        select_clause = ",\n                    ".join(col_exprs)

        # v4.5.37: Filter by scan_id to get only current scan findings
        if scan_id:
            cursor.execute(
                f"""
                SELECT
                    {select_clause}
                FROM findings
                WHERE scan_id = ?
                ORDER BY
                    CASE severity
                        WHEN 'CRITICAL' THEN 1
                        WHEN 'HIGH' THEN 2
                        WHEN 'MEDIUM' THEN 3
                        WHEN 'LOW' THEN 4
                        ELSE 5
                    END,
                    CASE app_reachability
                        WHEN 'REACHABLE' THEN 1
                        WHEN 'UNKNOWN' THEN 2
                        ELSE 3
                    END
            """,
                (scan_id,),
            )
        else:
            cursor.execute(f"""
                SELECT
                    {select_clause}
                FROM findings
                ORDER BY
                    CASE severity
                        WHEN 'CRITICAL' THEN 1
                        WHEN 'HIGH' THEN 2
                        WHEN 'MEDIUM' THEN 3
                        WHEN 'LOW' THEN 4
                        ELSE 5
                    END,
                    CASE app_reachability
                        WHEN 'REACHABLE' THEN 1
                        WHEN 'UNKNOWN' THEN 2
                        ELSE 3
                    END
            """)
    except Exception as _issues_err:
        logger.warning(f"_get_all_issues query failed: {_issues_err}", exc_info=True)
        return findings

    for row in cursor.fetchall():
        ftype = (row["finding_type"] or "").upper()
        reachability = (row["app_reachability"] or "").upper()

        # P2.60 FIX: Map DB reachability directly — NO per-type overrides.
        # The correlation engine sets app_reachability; loaders.py must trust it.
        # UNKNOWN means the engine couldn't determine reachability; it does NOT
        # mean "not reachable". All types get the same mapping.
        if reachability == "REACHABLE":
            is_reachable = True
            reachability_state = "reachable"
        elif reachability == "NOT_REACHABLE":
            is_reachable = False
            reachability_state = "not_reachable"
        elif reachability == "NOT_APPLICABLE":
            is_reachable = None
            reachability_state = "not_applicable"
        elif reachability == "UNKNOWN":
            is_reachable = None
            # CONFIG is infrastructure — reachability concept does not apply.
            # Treat any CONFIG with UNKNOWN state as not_applicable (handles
            # scans run before NOT_APPLICABLE was added to the normalizer).
            ftype = (row["finding_type"] or "").upper()
            reachability_state = "not_applicable" if ftype in ("CONFIG", "IAC") else "unknown"
        else:
            is_reachable = None
            reachability_state = "unknown"

        # v4.5.31: Normalize CWE ID (CWE-016 -> CWE-16)
        raw_cwe = row["cwe_id"] or ""
        cwe_id = _normalize_cwe_id(raw_cwe) if raw_cwe else ""

        # v4.5.32: Build compliance mapping for finding
        # COMP-01 FIX: All finding types now get compliance tags
        compliance_mapping = {}
        if cwe_id:
            compliance_mapping["CWE"] = [cwe_id]
            owasp_cat = _CWE_TO_OWASP.get(cwe_id)
            if owasp_cat:
                compliance_mapping["OWASP"] = [owasp_cat]
        if ftype == "CVE":
            compliance_mapping["OWASP"] = ["A06"]
            compliance_mapping.setdefault("NIST", ["RA-5", "SI-2"])
            compliance_mapping.setdefault("SOC2", ["CC7.1", "CC7.3"])
            compliance_mapping.setdefault("PCI-DSS", ["6.3.1", "6.3.2"])
        elif ftype == "SECRET":
            compliance_mapping["OWASP"] = ["A02", "A07"]
            compliance_mapping["NIST"] = ["IA-5", "SC-13"]
            compliance_mapping["SOC2"] = ["CC6.7", "CC6.1"]
            compliance_mapping["PCI-DSS"] = ["6.2.4", "8.3.1"]
            compliance_mapping["CWE"] = compliance_mapping.get("CWE", ["CWE-798"])
        elif ftype in ("MALWARE", "SUSPICIOUS"):
            compliance_mapping["OWASP"] = ["A08"]
            compliance_mapping["NIST"] = ["SI-3", "SR-3", "SR-4"]
            compliance_mapping["SOC2"] = ["CC6.6", "CC7.2", "CC7.4"]
            compliance_mapping["PCI-DSS"] = ["6.2.4"]
        elif ftype in ("CONFIG", "IAC"):
            compliance_mapping["OWASP"] = ["A05"]
            compliance_mapping["NIST"] = ["CM-6", "CM-7"]
            compliance_mapping["SOC2"] = ["CC8.1"]
            compliance_mapping["PCI-DSS"] = ["6.5.1"]

        # v4.5.35: Fix duplicate CWE-CWE prefix
        raw_id = row["finding_id"] or f"{ftype}-{row['id']}"
        clean_id = raw_id.replace("CWE-CWE-", "CWE-") if raw_id else raw_id

        # P2.55 FIX: Use display_id for dashboard (includes CVE alias for GHSA findings)
        # e.g. "GHSA-xqr8-7jwr-rhp7 (CVE: CVE-2023-37920)" instead of just "GHSA-xqr8-7jwr-rhp7"
        display_id = row["display_id"] or clean_id

        # v4.5.41: Include fix_status and fix_version for CVE fix availability
        fix_status = row["fix_status"] or None
        fix_version = row["fix_version"] or None

        # P2.55 FIX: Normalize severity for dashboard display
        # DB stores raw scanner values (ERROR, WARNING) but dashboard expects
        # standard levels (CRITICAL, HIGH, MEDIUM, LOW)
        raw_sev = (row["severity"] or "UNKNOWN").upper()
        if raw_sev == "ERROR":
            normalized_sev = "CRITICAL"
        elif raw_sev == "WARNING":
            normalized_sev = "MEDIUM"
        else:
            normalized_sev = raw_sev

        # P2.20: Compute display fields at load time (lightweight JS)
        sla_display, sla_class = _compute_sla_display(
            is_reachable=is_reachable, severity=normalized_sev, fix_status=fix_status, finding_type=ftype
        )

        # b15: Extract context tag from title for context-aware remediation
        raw_title = row["title"] or row["finding_id"] or ""
        raw_desc = row["description"] or ""
        context_tag = None
        clean_title = raw_title
        clean_desc = raw_desc
        # CWE display rule: show human-readable name as title, not raw semgrep rule message
        if ftype == "CWE" and cwe_id:
            clean_title = _CWE_NAMES.get(cwe_id, raw_title)
        if ftype == "SECRET":
            match = _FINDING_TAG_RE.search(raw_title)
            if match:
                context_tag = match.group(1)
                clean_title = _FINDING_TAG_RE.sub("", raw_title).strip()
                clean_desc = _FINDING_TAG_RE.sub("", raw_desc).strip()

        fix_tag_display = _compute_fix_tag_display(
            finding_type=ftype,
            fix_status=fix_status,
            fix_version=fix_version,
            context_tag=context_tag,
            package_name=row["package_name"] or "",  # v1.0.0b15: prepend package to upgrade label
        )

        # v5.0.1: Parse evidence fields for malware detail display
        # JS expects: evidence.static.indicators[] and evidence.dynamic.behaviors[]
        evidence = {}
        if row["evidence_static"]:
            try:
                parsed = json.loads(row["evidence_static"])
                # Handle double-encoded JSON (json.dumps was called twice)
                if isinstance(parsed, str):
                    parsed = json.loads(parsed)
                # Transform flat evidence dict → {indicators: [...], scanner: ...}
                if isinstance(parsed, dict) and "indicators" not in parsed:
                    indicators = []
                    for k, v in parsed.items():
                        if k not in ("file", "sha256", "scanner") and v:
                            indicators.append({"type": k, "detail": str(v)})
                    evidence["static"] = {
                        "scanner": row["scanner"] or "static",
                        "indicators": indicators,
                        "file": parsed.get("file", ""),
                    }
                else:
                    evidence["static"] = parsed
                    evidence["static"]["scanner"] = row["scanner"] or "static"
            except Exception:
                evidence["static"] = {
                    "raw": str(row["evidence_static"])[:500],
                    "scanner": row["scanner"] or "static",
                    "indicators": [],
                }
        if row["evidence_dynamic"]:
            try:
                parsed = json.loads(row["evidence_dynamic"])
                if isinstance(parsed, str):
                    parsed = json.loads(parsed)
                if isinstance(parsed, dict) and "behaviors" not in parsed:
                    behaviors = []
                    for k, v in parsed.items():
                        if k not in ("file", "sha256", "scanner") and v:
                            behaviors.append({"type": k, "detail": str(v)})
                    evidence["dynamic"] = {
                        "scanner": "sandbox",
                        "behaviors": behaviors,
                    }
                else:
                    evidence["dynamic"] = parsed
                    evidence["dynamic"]["scanner"] = "sandbox"
            except Exception:
                evidence["dynamic"] = {
                    "raw": str(row["evidence_dynamic"])[:500],
                    "scanner": "sandbox",
                    "behaviors": [],
                }

        findings.append(
            {
                "id": display_id,
                "type": ftype,
                "severity": normalized_sev,
                "scanner": row["scanner"] or None,
                "is_reachable": is_reachable,
                "reachability_state": reachability_state,
                "title": clean_title,
                "description": clean_desc,
                "package": f"{row['package_name'] or ''} {row['package_version'] or ''}".strip(),
                "file_path": row["file_path"] or "",
                # P2.20: Dashboard expects 'location' field - map from file_path or package_name
                "location": row["file_path"] or row["package_name"] or "unknown",
                "line": row["line_number"],
                "cwe_id": cwe_id,
                "compliance_mapping": compliance_mapping,
                # v4.5.41: Fix availability for CVEs
                "fix_status": fix_status,
                "fix_version": fix_version,
                "fix_available": fix_status == "fix_available",
                # b15: Context-aware remediation for secrets
                "remediation": (
                    {
                        "action": _SECRET_REMEDIATION[context_tag][0],
                        "review_guidance": _SECRET_REMEDIATION[context_tag][1],
                    }
                    if ftype == "SECRET" and context_tag and context_tag in _SECRET_REMEDIATION
                    else ({"fixed_in": fix_version} if fix_version else None)
                ),
                # P2.20: Pre-computed display fields (source of truth)
                "sla_display": sla_display,
                "sla_class": sla_class,
                "fix_tag_display": fix_tag_display,
                # v5.0.1: Evidence for malware/suspicious detail panel
                "evidence": evidence if evidence else None,
                "finding_id": row["finding_id"] or "",
                # v1.0.0b15: Transitive dependency fields
                "is_transitive": bool(row["is_transitive"]) if row["is_transitive"] is not None else False,
                "via_package": row["via_package"] or "",
                "dependency_chain": json.loads(row["dependency_chain"]) if row["dependency_chain"] else [],
                "dependency_depth": row["dependency_depth"] or 0,
                # v1.0.0b15: Threat intel enrichment
                "fix_version_raw": row["fix_version_raw"] or None,
                "cvss_score": row["cvss_score"] if row["cvss_score"] is not None else None,  # BUG #4 FIX
                "epss_score": row["epss_score"],  # float or None
                "epss_percentile": row["epss_percentile"],  # int or None
                "is_kev": bool(row["is_kev"]) if row["is_kev"] is not None else None,
                "go_vuln_id": row["go_vuln_id"] or None,
                "fix_commit_url": row["fix_commit_url"] or None,
                # OSV enrichment fields — stored in raw_data JSON (not separate columns)
                # Extract here so dashboard JS can render them without reading raw_data
                **_extract_osv_fields(row["raw_data"] if "raw_data" in row.keys() else None),
                # T-CG10: typed PathNode list + enrichment metadata
                "call_paths_v2": _row_get(row, "call_paths_v2", [], lambda x: json.loads(x) if x else []),
                "containing_function": _row_get(row, "containing_function", None),
                "reachability_reason": _row_get(row, "reachability_reason", None),
                # malware_class: derived from type_detail (malware:confirmed|suspicious|supply_chain)
                "malware_class": _extract_malware_class(_row_get(row, "type_detail", "")) if ftype == "MALWARE" else None,
            }
        )

    return findings


def _extract_malware_class(type_detail: str) -> str:
    """Extract malware_class from type_detail column (e.g. 'malware:supply_chain' -> 'supply_chain')."""
    if type_detail and ":" in type_detail:
        cls = type_detail.split(":", 1)[1]
        # Recognised classes — pass through as-is
        if cls in ("confirmed", "suspicious", "supply_chain", "code_pattern"):
            return cls
        return cls  # forward-compatible: pass through unknown sub-classes
    # Legacy rows without sub-class: could be guarddog/yara (confirmed) or semgrep (unknown).
    # Use 'suspicious' as safe fallback — avoids inflating 'confirmed' count.
    return "suspicious"


def _normalize_cwe_id(cwe_id: str) -> str:
    """
    Normalize CWE ID: CWE-016 -> CWE-16, 094 -> CWE-94

    v4.5.31: Added for consistent CWE ID handling
    """
    if not cwe_id:
        return ""
    cwe_id = cwe_id.upper().strip()
    # Reject sentinel/fallback values — not real CWEs
    if cwe_id.startswith("RULE:") or cwe_id == "CWE-UNKNOWN":
        return ""
    if cwe_id.startswith("CWE-"):
        # Remove leading zeros: CWE-016 -> CWE-16
        num_part = cwe_id[4:].lstrip("0") or "0"
        return f"CWE-{num_part}"
    elif cwe_id.isdigit():
        # Just a number: 094 -> CWE-94
        return f"CWE-{cwe_id.lstrip('0') or '0'}"
    return cwe_id


# CWE ID → human-readable policy name (dashboard title display)
_CWE_NAMES = {
    "CWE-20":  "Improper Input Validation",
    "CWE-22":  "Path Traversal",
    "CWE-78":  "OS Command Injection",
    "CWE-79":  "Cross-Site Scripting (XSS)",
    "CWE-89":  "SQL Injection",
    "CWE-94":  "Code Injection",
    "CWE-95":  "Eval Injection",
    "CWE-134": "Format String Vulnerability",
    "CWE-215": "Information Insertion into Debugging Code",
    "CWE-295": "Improper Certificate Validation",
    "CWE-319": "Cleartext Transmission of Sensitive Information",
    "CWE-327": "Weak Cryptographic Algorithm",
    "CWE-352": "Cross-Site Request Forgery (CSRF)",
    "CWE-377": "Insecure Temporary File",
    "CWE-502": "Deserialization of Untrusted Data",
    "CWE-601": "Open Redirect",
    "CWE-605": "Multiple Binds to Same Port",
    "CWE-614": "Insecure Cookie (missing Secure flag)",
    "CWE-732": "Incorrect Permission Assignment",
    "CWE-798": "Hardcoded Credentials",
    "CWE-918": "Server-Side Request Forgery (SSRF)",
}


# CWE to OWASP Top 10 2021 mapping
_CWE_TO_OWASP = {
    # A01: Broken Access Control
    "CWE-22": "A01",
    "CWE-23": "A01",
    "CWE-35": "A01",
    "CWE-59": "A01",
    "CWE-200": "A01",
    "CWE-284": "A01",
    "CWE-285": "A01",
    "CWE-352": "A01",
    "CWE-639": "A01",
    "CWE-862": "A01",
    "CWE-863": "A01",
    # A02: Cryptographic Failures
    "CWE-259": "A02",
    "CWE-327": "A02",
    "CWE-328": "A02",
    "CWE-330": "A02",
    "CWE-326": "A02",
    "CWE-319": "A02",
    "CWE-321": "A02",
    # A03: Injection
    "CWE-20": "A03",
    "CWE-74": "A03",
    "CWE-77": "A03",
    "CWE-78": "A03",
    "CWE-79": "A03",
    "CWE-89": "A03",
    "CWE-94": "A03",
    "CWE-917": "A03",
    # A04: Insecure Design
    "CWE-209": "A04",
    "CWE-256": "A04",
    "CWE-501": "A04",
    "CWE-522": "A04",
    # A05: Security Misconfiguration
    "CWE-16": "A05",
    "CWE-611": "A05",
    "CWE-614": "A05",
    # A06: Vulnerable Components (CVEs)
    "CWE-937": "A06",
    "CWE-1035": "A06",
    "CWE-1104": "A06",
    # A07: Auth Failures
    "CWE-287": "A07",
    "CWE-384": "A07",
    "CWE-613": "A07",
    "CWE-798": "A07",
    # A08: Data Integrity Failures
    "CWE-345": "A08",
    "CWE-502": "A08",
    "CWE-829": "A08",
    # A09: Logging Failures
    "CWE-117": "A09",
    "CWE-223": "A09",
    "CWE-532": "A09",
    "CWE-778": "A09",
    # A10: SSRF
    "CWE-918": "A10",
}


def _build_owasp_web_from_issues(issues: List[Dict[str, Any]]) -> Dict[str, Any]:
    """
    Build OWASP Top 10 (2021) Web summary from CWE findings.

    v4.5.28: Added for OWASP dashboard panel
    v4.5.29: Fixed CWE normalization (CWE-016 -> CWE-16)
    v4.5.32: Added by_category_breakdown for reachable/unreachable/unknown per category
    v4.5.36: Fixed severity mapping (ERROR→HIGH, WARNING→MEDIUM)
    """
    by_category = {f"A{i:02d}": 0 for i in range(1, 11)}
    by_category_breakdown = {f"A{i:02d}": {"reachable": 0, "unreachable": 0, "unknown": 0} for i in range(1, 11)}
    by_severity = {"CRITICAL": 0, "HIGH": 0, "MEDIUM": 0, "LOW": 0}
    total = 0
    reachable = 0

    # v4.5.36: Map non-standard severity to standard levels
    severity_map = {
        "CRITICAL": "CRITICAL",
        "HIGH": "HIGH",
        "ERROR": "HIGH",
        "MEDIUM": "MEDIUM",
        "WARNING": "MEDIUM",
        "LOW": "LOW",
        "INFO": "LOW",
    }

    for issue in issues:
        cwe_id = issue.get("cwe_id", "") or ""
        ftype = issue.get("type", "").upper()
        is_reach = issue.get("is_reachable")

        # Map CWE to OWASP category
        owasp_cat = None
        if cwe_id:
            # Normalize CWE ID: CWE-016 -> CWE-16, 094 -> CWE-94
            cwe_id = cwe_id.upper().strip()
            if cwe_id.startswith("CWE-"):
                # Remove leading zeros: CWE-016 -> CWE-16
                num_part = cwe_id[4:].lstrip("0") or "0"
                cwe_id = f"CWE-{num_part}"
            elif cwe_id.isdigit():
                # Just a number: 094 -> CWE-94
                cwe_id = f"CWE-{cwe_id.lstrip('0') or '0'}"
            owasp_cat = _CWE_TO_OWASP.get(cwe_id)

        # CVEs map to A06 (Vulnerable Components)
        if ftype == "CVE":
            owasp_cat = "A06"

        if owasp_cat:
            by_category[owasp_cat] += 1
            # Track breakdown
            if is_reach is True:
                by_category_breakdown[owasp_cat]["reachable"] += 1
            elif is_reach is False:
                by_category_breakdown[owasp_cat]["unreachable"] += 1
            else:
                by_category_breakdown[owasp_cat]["unknown"] += 1
            total += 1
            # v4.5.36: Map severity to standard levels
            raw_sev = (issue.get("severity") or "MEDIUM").upper()
            sev = severity_map.get(raw_sev, "MEDIUM")
            by_severity[sev] += 1
            if is_reach:
                reachable += 1

    return {
        "total": total,
        "reachable": reachable,
        "by_category": by_category,
        "by_category_breakdown": by_category_breakdown,
        "by_severity": by_severity,
    }


def _build_owasp_llm_from_ai_security(ai_security):
    """
    BUG #2 FIX: Build OWASP LLM Top 10 summary from ai_security data.

    ai_security.by_owasp  → {LLM01: N, LLM06: N, NONE: N, ...}
    ai_security.by_owasp_breakdown → per-category reachability breakdown.

    Returns structure matching dashboard LLM Top 10 panel expectations,
    or None if there are no AI findings.
    """
    if not ai_security:
        return None

    by_owasp = ai_security.get("by_owasp", {}) or {}
    by_owasp_breakdown = ai_security.get("by_owasp_breakdown", {}) or {}
    by_severity = ai_security.get("by_severity", {}) or {}
    total = ai_security.get("total", 0) or 0
    reachable = ai_security.get("reachable", 0) or 0

    llm_cats = [f"LLM{i:02d}" for i in range(1, 11)]
    by_category = {cat: 0 for cat in llm_cats}
    by_category_breakdown = {cat: {"reachable": 0, "unreachable": 0, "unknown": 0} for cat in llm_cats}

    for cat, count in by_owasp.items():
        if cat in by_category:
            by_category[cat] = count
        # NONE / unknown categories dropped from LLM panel

    for cat, breakdown in by_owasp_breakdown.items():
        if cat in by_category_breakdown:
            by_category_breakdown[cat] = breakdown

    return {
        "total": total,
        "reachable": reachable,
        "by_category": by_category,
        "by_category_breakdown": by_category_breakdown,
        "by_severity": by_severity,
    }


def get_clone_metrics(scan_dir: Path) -> Optional[Dict[str, Any]]:
    """
    Load library clone metrics from scan directory.

    Returns dict with clone success/failure statistics or None if not found.
    """
    # Try to find lib-cloning-metrics.json in scan directory or raw/ subdirectory
    candidates = [
        scan_dir / "lib-cloning-metrics.json",
        scan_dir / "raw" / "lib-cloning-metrics.json",
    ]

    for metrics_file in candidates:
        if metrics_file.exists():
            try:
                with open(metrics_file) as f:
                    return json.load(f)
            except Exception:
                pass

    return None


def _compute_sla_display(
    is_reachable: Optional[bool], severity: str, fix_status: Optional[str], finding_type: str
) -> tuple[str, str]:
    """
    Compute SLA display and CSS class for a finding.

    P2.20: Business logic for SLA moved to Python (database population)
    JavaScript just displays what's here (lightweight).

    Returns:
        (display_text, css_class)
    """
    # P2.21: Fix tri-state reachability - None (UNKNOWN) must show ASSESS
    # Not reachable (False) → no SLA
    if is_reachable is False:
        return "-", ""
    # Unknown reachability (None) → show ASSESS
    if is_reachable is None:
        return "ASSESS", "sla-unknown"

    # Normalize severity
    sev = (severity or "UNKNOWN").upper()

    # CVEs: check fix status
    if finding_type == "CVE":
        if fix_status == "fix_available":
            # Fixable CVE → show timeline based on severity
            if sev == "CRITICAL":
                return "24 hours", "sla-critical"
            elif sev == "HIGH":
                return "7 days", "sla-high"
            elif sev == "MEDIUM":
                return "30 days", "sla-medium"
            elif sev == "LOW":
                return "90 days", "sla-low"
            elif sev == "UNKNOWN":
                return "ASSESS", "sla-unknown"
            else:
                return "ASSESS", "sla-unknown"
        else:
            # Unfixable CVE (not-fixed, wont_fix, unknown, NULL)
            return "NO FIX", "sla-none"

    # All other types (SECRET, CWE, MALWARE, CONFIG, etc) → always show SLA when reachable
    else:
        if sev == "CRITICAL":
            return "24 hours", "sla-critical"
        elif sev == "HIGH":
            return "7 days", "sla-high"
        elif sev == "MEDIUM":
            return "30 days", "sla-medium"
        elif sev == "LOW":
            return "90 days", "sla-low"
        elif sev == "UNKNOWN":
            return "ASSESS", "sla-unknown"
        else:
            return "ASSESS", "sla-unknown"


def _compute_fix_tag_display(
    finding_type: str,
    fix_status: Optional[str],
    fix_version: Optional[str],
    context_tag: Optional[str] = None,  # b15: context-aware secret labels
    package_name: Optional[str] = None,  # v1.0.0b15: prepend package for clarity
) -> str:
    """
    Compute fix tag HTML for a finding.

    P2.20: Business logic for fix tags moved to Python (database population)
    JavaScript just displays what's here (lightweight).

    Returns:
        HTML string for fix tag
    """
    ftype = finding_type.upper()

    if ftype == "CVE":
        if fix_status == "fix_available":
            if fix_version:
                pkg = package_name.strip() if package_name else ""
                upgrade_label = f"Upgrade {pkg} to {fix_version}" if pkg else f"Upgrade to {fix_version}"
                return f'<span class="fix-tag fix-available" title="{upgrade_label}">✅ {upgrade_label}</span>'
            else:
                return '<span class="fix-tag fix-available">✅ FIX</span>'
        elif fix_status == "wont_fix":
            return '<span class="fix-tag fix-wontfix">🚫 WONT FIX</span>'
        elif fix_status in ("not-fixed", "no_fix"):
            return '<span class="fix-tag fix-none">⚠️ NO FIX</span>'
        elif fix_status == "wont-fix":
            return '<span class="fix-tag fix-wontfix">🚫 WONT FIX</span>'
        else:
            # genuinely unknown fix state
            return '<span class="fix-tag fix-unknown">❓ UNKNOWN</span>'

    elif ftype == "SECRET":
        # b15: Context-aware secret remediation labels
        if context_tag and context_tag in _SECRET_FIX_LABELS:
            label, bg, fg = _SECRET_FIX_LABELS[context_tag]
            return f'<span class="fix-tag" style="background:{bg};color:{fg};">{label}</span>'
        else:
            # Default: real secrets need rotation
            return '<span class="fix-tag" style="background:#fef3c7;color:#92400e;">🔑 ROTATE</span>'

    elif ftype in ("MALWARE", "SUSPICIOUS"):
        return '<span class="fix-tag" style="background:#fee2e2;color:#991b1b;">🗑️ REMOVE</span>'

    elif ftype == "AI":
        return '<span class="fix-tag" style="background:#ede9fe;color:#5b21b6;">🛡️ MITIGATE</span>'

    elif ftype == "DLP":
        return '<span class="fix-tag" style="background:#fce7f3;color:#9d174d;">🔒 SANITIZE</span>'

    elif ftype == "CWE":
        return '<span class="fix-tag" style="background:#dbeafe;color:#1e40af;">🔧 CODE FIX</span>'

    elif ftype in ("CONFIG", "IAC"):
        return '<span class="fix-tag" style="background:#e0e7ff;color:#3730a3;">⚙️ CONFIG</span>'

    else:
        return "-"


def _get_malware_metrics_from_db(cursor, scan_id=None) -> Dict[str, Any]:
    """
    v5.0.2: Compute malware 4-counter directly from DB.

    Returns dict with malware_static_confirmed, malware_static_suspicious,
    malware_dynamic_confirmed, malware_dynamic_suspicious (distinct package counts).
    """
    static_confirmed = set()
    static_suspicious = set()
    dynamic_confirmed = set()
    dynamic_suspicious = set()

    try:
        scan_filter = "WHERE scan_id = ?" if scan_id else ""
        scan_params = (scan_id,) if scan_id else ()

        cursor.execute(
            f"""
            SELECT
                finding_type,
                scanner,
                severity,
                app_reachability,
                COALESCE(NULLIF(package_name, ''), file_path, 'unknown') as pkg_key
            FROM findings
            {scan_filter + " AND" if scan_filter else "WHERE"} finding_type IN ('malware', 'suspicious')
        """,
            scan_params,
        )

        for row in cursor.fetchall():
            ftype = (row["finding_type"] or "").lower()
            scanner = (row["scanner"] or "").lower()
            sev = (row["severity"] or "").upper()
            pkg = row["pkg_key"] or "unknown"
            reach = (row["app_reachability"] or "").upper()

            if scanner == "sandbox":
                # BUG-A5 FIX: sandbox confirmed = REACHABLE findings only
                if reach == "REACHABLE" and (sev == "CRITICAL" or ftype == "malware"):
                    dynamic_confirmed.add(pkg)
                elif sev == "CRITICAL" or ftype == "malware":
                    pass  # not reachable — don't count as confirmed
                else:
                    dynamic_suspicious.add(pkg)
            else:
                # BUG-A5 FIX: static confirmed = REACHABLE malware only
                if ftype == "malware" and reach == "REACHABLE":
                    static_confirmed.add(pkg)
                elif ftype == "malware":
                    static_suspicious.add(pkg)  # detected but not reachable → suspicious
                else:
                    static_suspicious.add(pkg)

        # Confirmed trumps suspicious for same package
        dynamic_suspicious -= dynamic_confirmed
        static_suspicious -= static_confirmed
    except Exception as _mal_err:
        logger.warning(f"_get_malware_metrics_from_db failed: {_mal_err}", exc_info=True)

    # v5.0.2: Union totals for headline numbers (avoids double-counting
    # packages detected by both static AND dynamic scanners)
    all_confirmed = static_confirmed | dynamic_confirmed
    all_suspicious = static_suspicious | dynamic_suspicious
    # Confirmed trumps suspicious across scanner types too
    all_suspicious -= all_confirmed

    return {
        "malware_static_confirmed": len(static_confirmed),
        "malware_static_suspicious": len(static_suspicious),
        "malware_dynamic_confirmed": len(dynamic_confirmed),
        "malware_dynamic_suspicious": len(dynamic_suspicious),
        # Union totals for headline display (no double-counting).
        # BUG-A5: malware_confirmed is also set here so metrics.update() overwrites
        # the stale issues-list-derived value from calculate_metrics_from_summary().
        # Single source of truth = DB query above.
        "malware_confirmed": len(all_confirmed),
        "malware_confirmed_total": len(all_confirmed),
        "malware_suspicious_total": len(all_suspicious),
    }


def _build_funnel_from_db(
    cursor,
    scan_id: Optional[int],
    dlp_security: Optional[Dict[str, Any]],
    ai_security: Optional[Dict[str, Any]],
) -> Dict[str, Any]:
    """
    Build the Analysis Funnel data directly from database.

    P2.50 CRITICAL: This is the SINGLE SOURCE OF TRUTH for funnel metrics.
    Dashboard JS must NOT recalculate these values.

    P2.60 NOTE (P1 #5-6 — WORKING AS DESIGNED):
    The funnel uses ALL signal types including CONFIG, DLP, AI, MALWARE, SUSPICIOUS.
    This is intentional: the funnel shows the complete analysis pipeline from
    raw signals → reachable signals, so ALL signal types must be included.

    v5.1.3: The TRENDS chart now includes findings + ai_findings + dlp_findings
    tables for complete coverage. CONFIG is excluded from trend raw totals.

    Summary: funnel_base = all signals, trends_base = all tables (no CONFIG).

    Returns:
        {
            'raw_total': int,
            'reachable_total': int,
            'noise_reduction_pct': float,
            'raw_signals': {'CVE': N, 'MALWARE': N, 'SUSPICIOUS': N, 'SECRET': N, 'CWE': N, 'CONFIG': N, 'AI': N, 'DLP': N},
            'reachable_signals': {'CVE': N, 'MALWARE': N, 'SUSPICIOUS': N, 'SECRET': N, 'CWE': N, 'CONFIG': N, 'AI': N, 'DLP': N},
            'unknown_signals': {'CVE': N, 'MALWARE': N, 'SUSPICIOUS': N, 'SECRET': N, 'CWE': N, 'CONFIG': N, 'AI': N, 'DLP': N},
            'unreachable_signals': {'CVE': N, 'MALWARE': N, 'SUSPICIOUS': N, 'SECRET': N, 'CWE': N, 'CONFIG': N, 'AI': N, 'DLP': N},
        }
    """
    # Initialize signal counts (v4.6.10: added MALWARE, SUSPICIOUS)
    raw_signals = {
        "CVE": 0,
        "SECRET": 0,
        "CWE": 0,
        "CONFIG": 0,
        "AI": 0,
        "DLP": 0,
        "MALWARE": 0,
        "SUSPICIOUS": 0,
    }
    reachable_signals = {
        "CVE": 0,
        "SECRET": 0,
        "CWE": 0,
        "CONFIG": 0,
        "AI": 0,
        "DLP": 0,
        "MALWARE": 0,
        "SUSPICIOUS": 0,
    }
    unknown_signals = {
        "CVE": 0,
        "SECRET": 0,
        "CWE": 0,
        "CONFIG": 0,
        "AI": 0,
        "DLP": 0,
        "MALWARE": 0,
        "SUSPICIOUS": 0,
    }
    unreachable_signals = {
        "CVE": 0,
        "SECRET": 0,
        "CWE": 0,
        "CONFIG": 0,
        "AI": 0,
        "DLP": 0,
        "MALWARE": 0,
        "SUSPICIOUS": 0,
    }

    try:
        # Non-malware signals: count individual findings (CVE, SECRET, CWE, CONFIG)
        scan_filter = "WHERE scan_id = ?" if scan_id else ""
        scan_params = (scan_id,) if scan_id else ()

        cursor.execute(
            f"""
            SELECT
                finding_type,
                app_reachability,
                COUNT(*) as count
            FROM findings
            {scan_filter + " AND" if scan_filter else "WHERE"} finding_type NOT IN ('malware', 'suspicious')
            GROUP BY finding_type, app_reachability
        """,
            scan_params,
        )

        for row in cursor.fetchall():
            ftype = (row["finding_type"] or "").upper()
            reachability = (row["app_reachability"] or "").upper()
            count = row["count"] or 0

            if ftype not in raw_signals:
                continue

            raw_signals[ftype] += count

            if reachability == "REACHABLE":
                reachable_signals[ftype] += count
            elif reachability == "NOT_REACHABLE":
                unreachable_signals[ftype] += count
            elif reachability == "UNKNOWN":
                unknown_signals[ftype] += count

        # Malware/suspicious: count INDIVIDUAL FINDINGS (same as all other types).
        # This ensures funnel raw_total matches len(issues[]).
        # Package-level dedup is done separately for engineering panel / malware metrics.
        cursor.execute(
            f"""
            SELECT
                finding_type,
                app_reachability,
                COUNT(*) as count
            FROM findings
            {scan_filter + " AND" if scan_filter else "WHERE"} finding_type IN ('malware', 'suspicious')
            GROUP BY finding_type, app_reachability
        """,
            scan_params,
        )

        for row in cursor.fetchall():
            ftype = (row["finding_type"] or "").upper()
            reachability = (row["app_reachability"] or "").upper()
            count = row["count"] or 0

            if ftype not in raw_signals:
                continue

            raw_signals[ftype] += count

            if reachability == "REACHABLE":
                reachable_signals[ftype] += count
            elif reachability == "NOT_REACHABLE":
                unreachable_signals[ftype] += count
            elif reachability == "UNKNOWN":
                unknown_signals[ftype] += count
    except Exception as _funnel_err:
        logger.warning(f"_build_funnel_from_db query failed: {_funnel_err}", exc_info=True)

    # Add AI findings from ai_security dict
    # BUG-AI-BANNER FIX: Use reachable_all for funnel (includes NONE for consistent totals).
    # The AI banner uses ai_security.reachable (excludes NONE) separately.
    if ai_security:
        ai_total = ai_security.get("total", 0) or 0
        ai_reachable = ai_security.get("reachable_all", 0) or ai_security.get("reachable", 0) or 0
        ai_unknown = ai_security.get("unknown_all", 0) or ai_security.get("unknown", 0) or 0
        raw_signals["AI"] = ai_total
        reachable_signals["AI"] = ai_reachable
        unknown_signals["AI"] = ai_unknown
        unreachable_signals["AI"] = max(0, ai_total - ai_reachable - ai_unknown)

    # Add DLP findings from dlp_security dict
    # L4 FIX: subtract unknown from unreachable — NULL reachability is unknown, not unreachable
    if dlp_security:
        dlp_total = dlp_security.get("total", 0) or 0
        dlp_reachable = dlp_security.get("reachable", 0) or 0
        dlp_unknown = dlp_security.get("unknown", 0) or 0
        raw_signals["DLP"] = dlp_total
        reachable_signals["DLP"] = dlp_reachable
        unknown_signals["DLP"] = dlp_unknown
        unreachable_signals["DLP"] = max(0, dlp_total - dlp_reachable - dlp_unknown)

    # Calculate totals (exclude CONFIG - not part of risk calculation, matches Signal Quality table)
    raw_total = sum(v for k, v in raw_signals.items() if k.upper() != "CONFIG")
    reachable_total = sum(v for k, v in reachable_signals.items() if k.upper() != "CONFIG")
    unknown_total = sum(v for k, v in unknown_signals.items() if k.upper() != "CONFIG")
    unreachable_total = sum(v for k, v in unreachable_signals.items() if k.upper() != "CONFIG")

    # Calculate noise reduction percentage (unreachable / total)
    if raw_total > 0:
        noise_reduction_pct = round((unreachable_total / raw_total) * 100, 1)
    else:
        noise_reduction_pct = 0.0

    return {
        "raw_total": raw_total,
        "reachable_total": reachable_total,
        "unknown_total": unknown_total,  # P2.50: Add for consistency
        "unreachable_total": unreachable_total,  # P2.50: Add for consistency
        "noise_reduction_pct": noise_reduction_pct,
        "raw_signals": raw_signals,
        "reachable_signals": reachable_signals,
        "unknown_signals": unknown_signals,
        "unreachable_signals": unreachable_signals,
        "config_excluded": True,  # P2.50: Flag that CONFIG is excluded from totals
    }


def _build_trends_from_history(scan_history: List[Dict[str, Any]]) -> Dict[str, Any]:
    """
    Transform scan_history into the trends format expected by dashboard.

    P2.50 CRITICAL: This is the SINGLE SOURCE OF TRUTH for trends data.
    Dashboard JS must NOT recalculate these values.

    v5.1.3: Now includes ALL signal types (CVE, CWE, SECRET, MALWARE,
    AI, DLP) from findings + ai_findings + dlp_findings tables.
    CONFIG is excluded from raw totals but included in signal breakdown.

    Returns:
        {
            'data_points': [
                {
                    'timestamp': str,
                    'raw': int,
                    'reachable': int,
                    'critical': int,
                    'high': int,
                    'medium': int,
                    'low': int
                },
                ...
            ],
            'latest': {...}  # Most recent data point
        }
    """
    data_points = []

    # P2.56: Collect all signal types seen across all scans
    all_signal_types = set()
    for entry in scan_history:
        all_signal_types.update(entry.get("signals", {}).keys())

    for entry in scan_history:
        signals = entry.get("signals", {})

        # P2.56: Per-signal reachable counts (e.g. signal_CVE_reachable, signal_SECRET_reachable)
        signal_data = {}
        for stype in all_signal_types:
            sig = signals.get(stype, {})
            signal_data[f"signal_{stype}_total"] = sig.get("total", 0)
            signal_data[f"signal_{stype}_reachable"] = sig.get("reachable", 0)

        dp = {
            "timestamp": entry.get("timestamp", ""),
            "scan_id": entry.get("scan_id"),
            "branch": entry.get("branch", "main"),
            "raw": entry.get("total_issues", 0),
            "reachable": entry.get("reachable_issues", 0),
            "unknown_reachability": entry.get("unknown_reachability", 0),
            # actionable = reachable + unknown_reachability (pre-summed for JS convenience)
            "actionable": entry.get("reachable_issues", 0) + entry.get("unknown_reachability", 0),
            # severity counts — actionable only (reachable + unknown per severity)
            "actionable_critical": entry.get("actionable_critical", 0),
            "actionable_high": entry.get("actionable_high", 0),
            "actionable_medium": entry.get("actionable_medium", 0),
            "actionable_low": entry.get("actionable_low", 0),
            # total severity (kept for reference, not used in chart)
            "critical": entry.get("critical", 0),
            "high": entry.get("high", 0),
            "medium": entry.get("medium", 0),
            "low": entry.get("low", 0),
            "risk_level": entry.get("risk_level", "UNKNOWN"),
        }
        dp.update(signal_data)
        data_points.append(dp)

    # Get latest data point
    latest = (
        data_points[-1]
        if data_points
        else {
            "timestamp": "",
            "raw": 0,
            "reachable": 0,
            "unknown_reachability": 0,
            "actionable": 0,
            "actionable_critical": 0,
            "actionable_high": 0,
            "actionable_medium": 0,
            "actionable_low": 0,
            "critical": 0,
            "high": 0,
            "medium": 0,
            "low": 0,
        }
    )

    return {
        "data_points": data_points,
        "latest": latest,
        "count": len(data_points),
    }


def _build_engineering_panel(issues: List[Dict[str, Any]]) -> Dict[str, Any]:
    """
    P2.60: Pre-compute ALL engineering panel category breakdowns.

    This is the SINGLE SOURCE OF TRUTH for the engineering panel.
    Dashboard JS must NOT recalculate these values — it just reads d.engineering.*

    Eliminates JS recomputation violations #5-#9, #10-#11 from the audit.
    """

    # Helper: get reachability state (mirrors JS getReachabilityState)
    def _reach_state(f):
        (f.get("type") or "").upper()
        rs = f.get("reachability_state", "")
        if rs:
            return rs
        ir = f.get("is_reachable")
        if ir is True:
            return "reachable"
        if ir is False:
            return "not_reachable"
        return "unknown"

    # Helper: normalize severity (mirrors loaders already-normalized, but safety net)
    def _norm_sev(sev):
        s = (sev or "MEDIUM").upper()
        if s == "ERROR":
            return "CRITICAL"
        if s == "WARNING":
            return "MEDIUM"
        return s

    # Helper: keyword match for categorization
    def _match_keywords(f, keywords, fields=("description", "id", "finding_id")):
        for field in fields:
            val = (f.get(field) or "").lower()
            if any(kw in val for kw in keywords):
                return True
        return False

    # Helper: distinct packages from findings
    def _distinct_pkgs(findings):
        return len(
            set(
                f.get("package") or f.get("file_path") or "unknown"
                for f in findings
                if (f.get("package") or f.get("file_path"))
            )
        )

    # === CVE breakdown ===
    all_cves = [f for f in issues if (f.get("type") or "").upper() == "CVE"]
    cves_reachable = [f for f in all_cves if _reach_state(f) == "reachable"]
    cves_unknown = [f for f in all_cves if _reach_state(f) == "unknown"]
    actionable_cves = cves_reachable + cves_unknown

    # Vulnerable packages (distinct)
    vuln_packages = set()
    reach_vuln_packages = set()
    for f in all_cves:
        pkg = (f.get("package") or "").strip()
        if pkg:
            vuln_packages.add(pkg)
            if _reach_state(f) == "reachable":
                reach_vuln_packages.add(pkg)

    # Direct vs transitive
    direct_cves = len([f for f in all_cves if not f.get("is_transitive")])
    transitive_cves = len([f for f in all_cves if f.get("is_transitive")])

    cve_data = {
        "total": len(all_cves),  # all CVEs (incl not_reachable — CVE count is a hygiene metric)
        "actionable": len(actionable_cves),
        "reachable": len(cves_reachable),
        "unknown": len(cves_unknown),
        "critical": len([f for f in all_cves if _norm_sev(f.get("severity")) == "CRITICAL"]),
        "high": len([f for f in all_cves if _norm_sev(f.get("severity")) == "HIGH"]),
        "medium": len([f for f in all_cves if _norm_sev(f.get("severity")) == "MEDIUM"]),
        "low": len([f for f in all_cves if _norm_sev(f.get("severity")) == "LOW"]),
        "fixable": len([f for f in all_cves if f.get("fix_available") or f.get("fix_status") == "fix_available"]),
        "not_fixable": len(
            [f for f in all_cves if not (f.get("fix_available") or f.get("fix_status") == "fix_available")]
        ),
        "direct": direct_cves,
        "transitive": transitive_cves,
        "vulnerable_packages": len(vuln_packages),
        "reachable_vuln_packages": len(reach_vuln_packages),
    }

    # === SECRET breakdown ===
    all_secrets = [f for f in issues if (f.get("type") or "").upper() == "SECRET"]
    secrets_reachable = len([f for f in all_secrets if _reach_state(f) == "reachable"])
    secrets_unknown = len([f for f in all_secrets if _reach_state(f) == "unknown"])
    actionable_secrets = [f for f in all_secrets if _reach_state(f) in ("reachable", "unknown")]

    # L3 FIX: use actionable_secrets consistently for all subcounts so categories sum to total
    secret_data = {
        "total": len(actionable_secrets),
        "reachable": secrets_reachable,
        "unknown": secrets_unknown,
        "critical": len([f for f in actionable_secrets if _norm_sev(f.get("severity")) == "CRITICAL"]),
        "high": len([f for f in actionable_secrets if _norm_sev(f.get("severity")) == "HIGH"]),
        "medium": len([f for f in actionable_secrets if _norm_sev(f.get("severity")) == "MEDIUM"]),
        "aws": len([f for f in actionable_secrets if _match_keywords(f, ["aws"])]),
        "api": len([f for f in actionable_secrets if _match_keywords(f, ["api", "api key"])]),
        "private": len([f for f in actionable_secrets if _match_keywords(f, ["private", "private key"])]),
        "tokens": len([f for f in actionable_secrets if _match_keywords(f, ["token"])]),
        "passwords": len([f for f in actionable_secrets if _match_keywords(f, ["password"])]),
    }
    secret_data["other"] = max(
        0,
        len(actionable_secrets)
        - secret_data["aws"]
        - secret_data["api"]
        - secret_data["private"]
        - secret_data["tokens"]
        - secret_data["passwords"],
    )

    # === CWE breakdown ===
    all_cwes = [f for f in issues if (f.get("type") or "").upper() == "CWE"]
    cwes_reachable = [f for f in all_cwes if _reach_state(f) == "reachable"]
    cwes_unknown = [f for f in all_cwes if _reach_state(f) == "unknown"]
    actionable_cwes = cwes_reachable + cwes_unknown

    # CWE policy categories (keyword matching)
    cwe_injection = len(
        [
            f
            for f in actionable_cwes
            if _match_keywords(
                f,
                [
                    "injection",
                    "sql",
                    "sqli",
                    "command-injection",
                    "code-injection",
                    "os-command",
                    "eval(",
                    "exec(",
                ],
                ("description", "id", "finding_id"),
            )
        ]
    )
    cwe_xss = len(
        [
            f
            for f in actionable_cwes
            if _match_keywords(
                f,
                ["xss", "cross-site", "script", "reflected", "stored-xss", "dom-xss"],
                ("description", "id", "finding_id"),
            )
        ]
    )
    cwe_path_traversal = len(
        [
            f
            for f in actionable_cwes
            if _match_keywords(
                f,
                ["path-traversal", "directory-traversal", "lfi", "rfi", "../", "file-inclusion"],
                ("description", "id", "finding_id"),
            )
        ]
    )
    cwe_crypto = len(
        [
            f
            for f in actionable_cwes
            if _match_keywords(
                f,
                ["crypto", "cipher", "hash", "md5", "sha1", "weak-hash", "hardcoded-secret", "random"],
                ("description", "id", "finding_id"),
            )
        ]
    )
    cwe_auth = len(
        [
            f
            for f in actionable_cwes
            if _match_keywords(
                f,
                ["auth", "session", "jwt", "token", "password", "credential", "login", "permission"],
                ("description", "id", "finding_id"),
            )
        ]
    )
    cwe_ssrf = len(
        [
            f
            for f in actionable_cwes
            if _match_keywords(
                f,
                ["ssrf", "redirect", "open-redirect", "url", "request-forgery"],
                ("description", "id", "finding_id"),
            )
        ]
    )
    categorized = cwe_injection + cwe_xss + cwe_path_traversal + cwe_crypto + cwe_auth + cwe_ssrf

    cwe_data = {
        "total": len(actionable_cwes),
        "reachable": len(cwes_reachable),
        "unknown": len(cwes_unknown),
        "critical": len([f for f in actionable_cwes if _norm_sev(f.get("severity")) == "CRITICAL"]),
        "high": len([f for f in actionable_cwes if _norm_sev(f.get("severity")) == "HIGH"]),
        "medium": len([f for f in actionable_cwes if _norm_sev(f.get("severity")) == "MEDIUM"]),
        "low": len([f for f in actionable_cwes if _norm_sev(f.get("severity")) == "LOW"]),
        "injection": cwe_injection,
        "xss": cwe_xss,
        "path_traversal": cwe_path_traversal,
        "crypto": cwe_crypto,
        "auth": cwe_auth,
        "ssrf": cwe_ssrf,
        "other": max(0, len(actionable_cwes) - categorized),
    }

    # === MALWARE breakdown ===
    all_malware = [f for f in issues if (f.get("type") or "").upper() in ("MALWARE", "SUSPICIOUS")]
    static_malware = [f for f in all_malware if (f.get("scanner") or "") != "sandbox"]
    dynamic_malware = [f for f in all_malware if (f.get("scanner") or "") == "sandbox"]

    # Static subcategories
    mal_backdoor = len(
        [f for f in static_malware if _match_keywords(f, ["backdoor", "reverse shell", "remote access"])]
    )
    mal_crypto = len([f for f in static_malware if _match_keywords(f, ["crypto", "miner", "mining", "coinhive"])])
    mal_exfil = len([f for f in static_malware if _match_keywords(f, ["exfil", "data theft", "stealer", "send data"])])
    mal_typosquat = len([f for f in static_malware if _match_keywords(f, ["typosquat", "typo-squat", "similar name"])])
    mal_obfuscation = len(
        [
            f
            for f in static_malware
            if _match_keywords(f, ["obfuscat", "base64", "encoded", "hidden code", "steganograph"])
        ]
    )
    mal_cmd_inject = len(
        [
            f
            for f in static_malware
            if _match_keywords(f, ["cmd", "command", "shell", "exec", "os.system", "subprocess"])
        ]
    )
    static_categorized = mal_backdoor + mal_crypto + mal_exfil + mal_typosquat + mal_obfuscation + mal_cmd_inject

    # Dynamic subcategories (distinct packages)
    def _dyn_pkgs(findings, keywords):
        matched = [f for f in findings if _match_keywords(f, keywords, ("title", "description"))]
        return _distinct_pkgs(matched)

    dyn_c2 = _dyn_pkgs(dynamic_malware, ["network", "outbound", "dns", "c2", "beacon", "connect"])
    dyn_exfil = _dyn_pkgs(dynamic_malware, ["exfil", "upload", "send data", "post request"])
    dyn_creds = _dyn_pkgs(dynamic_malware, ["credential", ".npmrc", ".pypirc", ".netrc", ".ssh", ".aws", "honeypot"])
    dyn_shell = _dyn_pkgs(dynamic_malware, ["reverse shell", "shell", "bash -i", "nc -e"])
    dyn_mining = _dyn_pkgs(dynamic_malware, ["mining", "miner", "crypto", "pool"])
    dyn_confirmed = _distinct_pkgs([f for f in dynamic_malware if (f.get("type") or "").upper() == "MALWARE"])
    dyn_suspicious = _distinct_pkgs([f for f in dynamic_malware if (f.get("type") or "").upper() == "SUSPICIOUS"])

    malware_data = {
        "total_packages": _distinct_pkgs(all_malware),
        # confirmed = sandbox-verified (malware_class='confirmed')
        # code_pattern = semgrep static heuristic — NOT confirmed malicious packages
        "confirmed_packages": _distinct_pkgs([f for f in all_malware if f.get("malware_class") == "confirmed"]),
        "suspicious_packages": _distinct_pkgs(
            [f for f in all_malware if f.get("malware_class") in ("suspicious", "supply_chain")]
        ),
        "code_pattern_packages": _distinct_pkgs([f for f in all_malware if f.get("malware_class") == "code_pattern"]),
        "critical": _distinct_pkgs([f for f in all_malware if _norm_sev(f.get("severity")) == "CRITICAL"]),
        "high": _distinct_pkgs([f for f in all_malware if _norm_sev(f.get("severity")) == "HIGH"]),
        "medium": _distinct_pkgs([f for f in all_malware if _norm_sev(f.get("severity")) == "MEDIUM"]),
        "static_total": _distinct_pkgs(static_malware),
        "dynamic_total": _distinct_pkgs(dynamic_malware),
        "static": {
            "backdoor": mal_backdoor,
            "crypto": mal_crypto,
            "exfil": mal_exfil,
            "typosquat": mal_typosquat,
            "obfuscation": mal_obfuscation,
            "cmd_inject": mal_cmd_inject,
            "other": max(0, len(static_malware) - static_categorized),
        },
        "dynamic": {
            "confirmed": dyn_confirmed,
            "suspicious": dyn_suspicious,
            "c2": dyn_c2,
            "exfil": dyn_exfil,
            "creds": dyn_creds,
            "shell": dyn_shell,
            "mining": dyn_mining,
        },
    }

    # === CONFIG breakdown ===
    all_configs = [f for f in issues if (f.get("type") or "").upper() == "CONFIG"]
    config_k8s = len(
        [
            f
            for f in all_configs
            if _match_keywords(f, ["kubernetes", "k8s", "resource limit"], ("file_path", "description"))
        ]
    )
    config_docker = len(
        [f for f in all_configs if _match_keywords(f, ["dockerfile", "docker"], ("file_path", "description"))]
    )
    config_ports = len([f for f in all_configs if _match_keywords(f, ["port", "expose"], ("description",))])

    config_data = {
        "total": len(all_configs),
        "k8s": config_k8s,
        "docker": config_docker,
        "ports": config_ports,
        "other": max(0, len(all_configs) - config_k8s - config_docker - config_ports),
    }

    return {
        "cve": cve_data,
        "secret": secret_data,
        "cwe": cwe_data,
        "malware": malware_data,
        "config": config_data,
    }


def _extract_osv_fields(raw_data_json: Optional[str]) -> dict:
    """
    Extract OSV-enrichment fields from a finding's raw_data JSON blob.

    These fields are written by threat_intel.py / cve.py normalizer into
    the finding dict (and therefore into raw_data), but are NOT separate
    DB columns.  We extract them here so that dashboard JS can render them
    in the CVE detail panel without reading raw_data itself.

    Returns a dict with keys:
        osv_aliases     list[str]   cross-IDs (CVE, GHSA, GO-, PYSEC)
        osv_summary     str|None    one-liner from OSV database
        osv_cwes        list[str]   CWE IDs from affected[].database_specific
        osv_withdrawn   str|None    ISO date if advisory was retracted
        fix_refs        list[str]   patch URLs from OSV references
    """
    empty = {
        "osv_aliases": [],
        "osv_summary": None,
        "osv_cwes": [],
        "osv_withdrawn": None,
        "fix_refs": [],
    }
    if not raw_data_json:
        return empty
    try:
        import json as _j
        raw = _j.loads(raw_data_json) if isinstance(raw_data_json, str) else raw_data_json
        if not isinstance(raw, dict):
            return empty
        return {
            "osv_aliases":   list(raw.get("osv_aliases") or []),
            "osv_summary":   raw.get("osv_summary") or None,
            "osv_cwes":      list(raw.get("osv_cwes") or []),
            "osv_withdrawn": raw.get("osv_withdrawn") or None,
            "fix_refs":      list(raw.get("fix_refs") or []),
        }
    except Exception:
        return empty


def _load_package_health(cursor, scan_id) -> Optional[Dict[str, Any]]:
    """
    T7: Load package health advisories from DB for Supply Chain dashboard tab.

    Returns dict with 'summary' and 'advisories' keys, matching the shape
    that supply_chain.js renderSupplyChain() expects in dashboardData.package_health.
    """
    try:
        cursor.execute(
            """
            SELECT package_name, package_version, ecosystem, purl,
                   status, severity, signals, title, detail,
                   last_publish_date, latest_version, deprecated_msg,
                   maintainer_count, has_repository,
                   is_deprecated, is_private,
                   COALESCE(is_direct, 0) AS is_direct
            FROM package_health
            WHERE scan_id = ? AND status != 'healthy'
            ORDER BY
                CASE status
                    WHEN 'confused' THEN 1
                    WHEN 'abandoned' THEN 2
                    WHEN 'deprecated' THEN 3
                    WHEN 'stale' THEN 4
                    WHEN 'info' THEN 5
                    ELSE 6
                END
            """,
            (scan_id,),
        )
        rows = cursor.fetchall()
    except Exception as e:
        if "no such table" in str(e).lower():
            return None  # table not yet created — expected on first scan
        import traceback
        logger.warning(f" _load_package_health SQL error: {e}")
        logger.warning(traceback.format_exc())
        return None

    if not rows:
        # Table exists but all packages are healthy — return empty advisory dict.
        # Do NOT return None here: None causes supply_chain.js to show
        # "registry connectivity" error instead of the all-healthy success state.
        return {
            "summary": {
                "total_advisories": 0,
                "confused": 0, "abandoned": 0, "deprecated": 0,
                "stale": 0, "info": 0,
            },
            "advisories": [],
        }

    # Build per-package risk counts from findings (CVE/CWE/secret) for inline display.
    # Key: lowercase package_name. Counts only non-info findings.
    _risk_counts: dict = {}
    try:
        cursor.execute(
            """
            SELECT lower(package_name) AS pkg,
                   finding_type,
                   COUNT(*) AS n
            FROM findings
            WHERE scan_id = ?
              AND finding_type IN ('cve', 'cwe', 'secret')
              AND package_name IS NOT NULL AND package_name != ''
            GROUP BY lower(package_name), finding_type
            """,
            (scan_id,),
        )
        for _r in cursor.fetchall():
            _pkg = _r[0] or ""
            _risk_counts.setdefault(_pkg, {"cve": 0, "cwe": 0, "secret": 0})
            _risk_counts[_pkg][_r[1]] = _r[2]
    except Exception:
        pass  # non-fatal — risk counts are display-only

    def _effective_status(adv):
        """Mirror supply_chain.js effectiveStatus() — must stay in sync."""
        sig_types = {s.get("signal_type", "") if isinstance(s, dict) else str(s)
                     for s in adv.get("signals", [])}
        st = adv.get("status", "info")
        if st == "maintenance_complete":
            return "deprecated"
        if st == "info":
            if "stale" in sig_types:
                return "stale"
            if "deprecated" in sig_types:
                return "deprecated"
            if "abandoned" in sig_types:
                return "abandoned"
        return st

    advisories = []
    counts = {"confused": 0, "abandoned": 0, "deprecated": 0, "stale": 0, "info": 0}
    for row in rows:
        d = dict(row)
        # Parse signals JSON
        try:
            import json as _hj
            d["signals"] = _hj.loads(d.get("signals", "[]"))
        except Exception:
            d["signals"] = []
        # Rename for JS compatibility
        d["package"] = d.pop("package_name", "")
        d["version"] = d.pop("package_version", "")
        # Compute days since publish
        d["days_since_publish"] = None
        if d.get("last_publish_date"):
            try:
                from datetime import datetime, timezone
                pub = datetime.fromisoformat(d["last_publish_date"].replace("Z", "+00:00"))
                d["days_since_publish"] = (datetime.now(timezone.utc) - pub).days
            except (ValueError, TypeError):
                pass
        d["is_direct"] = bool(d.get("is_direct", 0))
        # Merge per-package risk counts (CVE/CWE/secret)
        d["risk_counts"] = _risk_counts.get((d["package"] or "").lower(),
                                            {"cve": 0, "cwe": 0, "secret": 0})
        advisories.append(d)
        # Count using effectiveStatus so Python summary matches JS stat cards
        eff = _effective_status(d)
        if eff in counts:
            counts[eff] += 1
        else:
            counts["info"] += 1

    return {
        "summary": {
            "total_advisories": len(advisories),
            "confused": counts["confused"],
            "abandoned": counts["abandoned"],
            "deprecated": counts["deprecated"],
            "stale": counts["stale"],
            "info": counts["info"],
        },
        "advisories": advisories,
        "malicious_packages": _get_malicious_package_names(cursor, scan_id),
    }


def _get_malicious_package_names(cursor, scan_id: int) -> list:
    """Return distinct package names that have malware/suspicious findings in this scan."""
    try:
        cursor.execute(
            """
            SELECT DISTINCT package_name
            FROM findings
            WHERE scan_id = ?
              AND finding_type IN ('malware', 'suspicious')
              AND package_name IS NOT NULL
              AND package_name != ''
            """,
            (scan_id,),
        )
        return [r[0] for r in cursor.fetchall()]
    except Exception:
        return []


def _build_exec_summary(
    issues: List[Dict[str, Any]], risk_level: Optional[str], funnel: Dict[str, Any]
) -> Dict[str, Any]:
    """
    P2.60: Pre-compute executive summary severity breakdowns.

    This is the SINGLE SOURCE OF TRUTH for the exec summary panel.
    Dashboard JS must NOT recalculate these values — it just reads d.exec_summary.*

    Eliminates JS recomputation violations #1-#3 from the audit.
    """

    # Helper: get reachability state
    def _reach_state(f):  # noqa: F811
        rs = f.get("reachability_state", "")
        if rs:
            return rs
        ir = f.get("is_reachable")
        if ir is True:
            return "reachable"
        if ir is False:
            return "not_reachable"
        return "unknown"

    # Helper: normalize severity
    def _norm_sev(sev):  # noqa: F811
        s = (sev or "MEDIUM").upper()
        if s == "ERROR":
            return "CRITICAL"
        if s == "WARNING":
            return "MEDIUM"
        return s

    # Helper: distinct malware packages for severity tier
    def _mal_pkgs_for_sev(sev_target, actionable_malware):
        return len(
            set(
                f.get("package") or f.get("finding_id") or ""
                for f in actionable_malware
                if _norm_sev(f.get("severity")) == sev_target
            )
            - {""}
        )

    # Actionable = reachable OR unknown (excludes not_reachable AND not_applicable/CONFIG)
    actionable = [f for f in issues if _reach_state(f) in ("reachable", "unknown")]

    # Signal types for breakdown
    SIGNAL_TYPES = ["CVE", "SECRET", "CWE", "MALWARE", "AI", "CONFIG", "DLP"]

    # MALWARE+SUSPICIOUS combined for exec summary (deduped by package)
    actionable_malware = [f for f in actionable if (f.get("type") or "").upper() in ("MALWARE", "SUSPICIOUS")]

    def _count_by_type_sev(sev_target):
        """Count actionable findings by type for a given severity."""
        result = {}
        for stype in SIGNAL_TYPES:
            if stype == "MALWARE":
                # Malware uses distinct package counts
                result[stype.lower()] = _mal_pkgs_for_sev(sev_target, actionable_malware)
            else:
                type_key = stype.upper()
                result[stype.lower()] = len(
                    [
                        f
                        for f in actionable
                        if (f.get("type") or "").upper() == type_key and _norm_sev(f.get("severity")) == sev_target
                    ]
                )
        return result

    critical_by_type = _count_by_type_sev("CRITICAL")
    high_by_type = _count_by_type_sev("HIGH")

    # Totals (malware deduped)
    critical_total = sum(critical_by_type.values())
    high_total = sum(high_by_type.values())

    # Unknown reachability breakdown by type
    unknown_issues = [f for f in issues if _reach_state(f) == "unknown"]
    unknown_by_type = {}
    for stype in SIGNAL_TYPES:
        if stype == "MALWARE":
            unknown_by_type[stype.lower()] = len(
                [f for f in unknown_issues if (f.get("type") or "").upper() in ("MALWARE", "SUSPICIOUS")]
            )
        else:
            unknown_by_type[stype.lower()] = len([f for f in unknown_issues if (f.get("type") or "").upper() == stype])
    unknown_total = sum(unknown_by_type.values())

    # Risk posture (override risk_level based on actionable issues)
    if critical_total > 0:
        posture = "critical"
    elif high_total > 0:
        posture = "high"
    elif any(_norm_sev(f.get("severity")) == "MEDIUM" for f in actionable):
        posture = "medium"
    else:
        posture = "low"

    # Malware alert info
    confirmed_malware = [f for f in issues if (f.get("type") or "").upper() == "MALWARE"]
    malware_packages = list(set(f.get("package") or "" for f in confirmed_malware if f.get("package")))

    return {
        "posture": posture,
        "critical_total": critical_total,
        "high_total": high_total,
        "critical_by_type": critical_by_type,
        "high_by_type": high_by_type,
        "unknown_total": unknown_total,
        "unknown_by_type": unknown_by_type,
        "actionable_count": len(actionable),
        "malware_packages": malware_packages,
        "malware_package_count": len(malware_packages),
    }


# Alias for backward compatibility / selftest checks
load_scan_results = load_from_database
