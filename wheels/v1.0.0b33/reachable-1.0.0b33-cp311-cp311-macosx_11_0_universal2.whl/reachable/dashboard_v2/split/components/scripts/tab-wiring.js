/* === Tabs wiring — clean v2 === */
(function(){
  function rawActivateTab(name){
    // Strip 'tab-' prefix if present
    name = name.replace(/^tab-/, '');
    document.querySelectorAll('.tab').forEach(t => t.classList.toggle('active', t.dataset.tab === name));
    document.querySelectorAll('.tab-page').forEach(p => p.classList.toggle('active', p.id === `tab-${name}`));
    // Supply chain tab: render on first switch (container was hidden at page load)
    if (name === 'supply-chain' && typeof renderSupplyChain === 'function') {
      renderSupplyChain('supplyChainContent');
    }
  }

  // Tab click handler — use rawActivateTab directly, never go through window.activateTab
  // This avoids the activateTab wrapper chain calling resetFindingsFilters on gotoFindings nav
  document.addEventListener('click', (e) => {
    const btn = e.target && e.target.closest ? e.target.closest('.tab') : null;
    if (!btn) return;
    rawActivateTab(btn.dataset.tab);
    // If user manually clicks Findings tab (not via gotoFindings), reset filters
    if (btn.dataset.tab === 'security-issues' && !window._inGotoFindings) {
      if (typeof window.resetFindingsFilters === 'function') window.resetFindingsFilters();
    }
  });

  // Expose for gotoFindings and owasp-cards.js
  window.activateTab = rawActivateTab;
  window._rawActivateTab = rawActivateTab;

  // Set default tab on load
  const firstActive = document.querySelector('.tab.active');
  if (firstActive) {
    rawActivateTab(firstActive.dataset.tab);
  } else {
    rawActivateTab('risk-posture');
  }
})();
