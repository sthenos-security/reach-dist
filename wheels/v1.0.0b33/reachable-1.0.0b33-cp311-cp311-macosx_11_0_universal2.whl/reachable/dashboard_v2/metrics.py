#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.

"""
Metrics calculation and risk level determination.
"""

from typing import Any, Dict, List


def calculate_metrics_from_summary(
    summary: Dict[str, int],
    dlp_total: int = 0,
    dlp_reachable: int = 0,
    issues: List[Dict[str, Any]] = None,
    ai_total: int = 0,
    ai_reachable: int = 0,
) -> Dict[str, Any]:
    """Calculate dashboard metrics from summary (v5.1.3: all signal types including AI + DLP)

    P2.21 FIX: Added issues parameter to calculate severity breakdowns for Action Required panel.
    v5.1.3 FIX D5: Added ai_total/ai_reachable for correct raw_total.
    """
    # P2.21 FIX: Calculate severity breakdowns from issues list
    actionable_critical = 0
    actionable_high = 0
    actionable_medium = 0
    actionable_low = 0

    # Count by type and severity for reachable/unknown issues
    by_type_reachable = {"CVE": 0, "SECRET": 0, "CWE": 0, "CONFIG": 0, "DLP": 0, "AI": 0, "MALWARE": 0}
    by_type_unknown = {"CVE": 0, "SECRET": 0, "CWE": 0, "CONFIG": 0, "DLP": 0, "AI": 0, "MALWARE": 0}

    if issues:
        for issue in issues:
            reachability = issue.get("reachability_state", "")
            is_reachable = issue.get("is_reachable")
            sev = (issue.get("severity") or "MEDIUM").upper()
            itype = (issue.get("type") or "UNKNOWN").upper()

            # BUG-METRICS-01 FIX: Skip not_applicable and not_reachable before
            # checking is_reachable fallback.  Previously, not_applicable issues
            # with is_reachable=None fell into the unknown bucket, inflating
            # actionable_total by 15 (CONFIG=13 + SECRET=2).
            if reachability in ("not_applicable", "not_reachable"):
                continue

            # Count actionable (reachable OR unknown)
            if reachability == "reachable" or is_reachable is True:
                if sev == "CRITICAL":
                    actionable_critical += 1
                elif sev == "HIGH":
                    actionable_high += 1
                elif sev == "MEDIUM":
                    actionable_medium += 1
                elif sev == "LOW":
                    actionable_low += 1

                if itype in by_type_reachable:
                    by_type_reachable[itype] += 1

            elif reachability == "unknown" or is_reachable is None:
                # Unknown also needs attention (ASSESS)
                if sev == "CRITICAL":
                    actionable_critical += 1
                elif sev == "HIGH":
                    actionable_high += 1
                elif sev == "MEDIUM":
                    actionable_medium += 1
                elif sev == "LOW":
                    actionable_low += 1

                if itype in by_type_unknown:
                    by_type_unknown[itype] += 1

    actionable_total = actionable_critical + actionable_high + actionable_medium + actionable_low

    # v5.3.0: 3-class malware model (confirmed / suspicious / supply_chain)
    # Driven by malware_class field set by malware.py normalizer.
    # Count unique packages per class.
    _confirmed_pkgs = set()
    _suspicious_pkgs = set()
    _supply_chain_pkgs = set()
    if issues:
        for issue in issues:
            itype = (issue.get("type") or "").upper()
            if itype not in ("MALWARE", "SUSPICIOUS"):
                continue
            # v5.0.2: Defensive — handle NULL package_name (YARA file-level findings)
            pkg_raw = (issue.get("package", "") or "").strip()
            pkg = pkg_raw.split()[0] if pkg_raw else ""
            if not pkg:
                fp = issue.get("file_path", "") or issue.get("file", "") or ""
                pkg = fp.rsplit("/", 2)[-2] if "/" in fp else fp or "unknown"
            mc = (issue.get("malware_class") or "").lower()
            if mc == "supply_chain":
                _supply_chain_pkgs.add(pkg)
            elif mc == "suspicious":
                _suspicious_pkgs.add(pkg)
            else:
                # confirmed (default) or sandbox dynamic
                _confirmed_pkgs.add(pkg)
    # A package confirmed elsewhere is not also suspicious
    _suspicious_pkgs -= _confirmed_pkgs
    _supply_chain_pkgs -= _confirmed_pkgs

    return {
        "cves_total": summary["cves_total"],
        "cves_reachable": summary["cves_reachable"],
        "cves_critical": summary["cves_critical"],
        "cves_high": summary["cves_high"],
        "cves_no_fix": summary.get("cves_no_fix", 0),
        # P2.21 FIX: security_findings_total should NOT include CONFIG or DLP
        # CONFIG is infrastructure/IaC (separate signal)
        # DLP is data loss prevention (separate signal)
        # Security findings = CVE + SECRET + CWE only
        "security_findings_total": (summary["cves_total"] + summary["secrets_total"] + summary["cwe_total"]),
        "security_findings_reachable": (
            summary["cves_reachable"] + summary["secrets_reachable"] + summary["cwe_reachable"]
        ),
        "security_findings_critical": actionable_critical,  # CRITICAL severity actionable findings
        "secrets_total": summary["secrets_total"],
        "secrets_reachable": summary["secrets_reachable"],
        "cwe_total": summary["cwe_total"],
        "cwe_reachable": summary["cwe_reachable"],
        "config_total": summary.get("config_total", 0),
        # P2.60 FIX: Use actual DB reachability from correlation engine
        "config_reachable": summary.get("config_reachable", 0),
        "config_unknown": summary.get("config_unknown", 0),
        "sast_findings": summary["cwe_total"],
        "malware_total": summary["malware_total"],
        # P2.60 FIX: Static malware is NOT always reachable — depends on import analysis
        "malware_reachable": summary.get("malware_reachable", 0),
        "malware_unknown": summary.get("malware_unknown", 0),
        # v5.3.0: 3-class malware model (confirmed / suspicious / supply_chain)
        "malware_confirmed": len(_confirmed_pkgs),
        "malware_suspicious": len(_suspicious_pkgs),
        "malware_supply_chain": len(_supply_chain_pkgs),
        # Legacy keys for backward compat
        "malware_confirmed_total": len(_confirmed_pkgs) + len(_supply_chain_pkgs),
        "malware_suspicious_total": len(_suspicious_pkgs),
        "suspicious_total": summary.get("suspicious_total", 0),
        "suspicious_reachable": summary.get("suspicious_reachable", 0),
        # v4.4.4: Threat Intel (KEV/EPSS)
        "threatintel_total": summary.get("threatintel_total", 0),
        "threatintel_reachable": summary.get("threatintel_reachable", summary.get("threatintel_total", 0)),
        # v4.4.4: Phantom Libraries
        "phantom_total": summary.get("phantom_total", 0),
        "phantom_reachable": summary.get("phantom_reachable", summary.get("phantom_total", 0)),
        "packages_scanned": summary.get("packages_scanned", 0),
        "sandbox_packages_tested": 0,
        "raw_total": (
            summary["cves_total"]
            + summary["secrets_total"]
            + summary["cwe_total"]
            + summary["malware_total"]
            + summary.get("suspicious_total", 0)
            + summary.get("config_total", 0)
            + summary.get("threatintel_total", 0)
            + summary.get("phantom_total", 0)
            + ai_total
            + dlp_total
        ),  # v5.1.3 FIX D5: include AI
        # DLP metrics
        "dlp_total": dlp_total,
        "dlp_reachable": dlp_reachable,
        # Unknown reachability
        "secrets_unknown": summary.get("secrets_unknown", 0),
        "cwe_unknown": summary.get("cwe_unknown", 0),
        # P2.21 FIX: ACTIONABLE counts with severity breakdown
        "actionable_total": actionable_total,
        "actionable_critical": actionable_critical,
        "actionable_high": actionable_high,
        "actionable_medium": actionable_medium,
        "actionable_low": actionable_low,
        # P2.21 FIX: By-type breakdown for reachable/unknown
        "actionable_by_type_reachable": by_type_reachable,
        "actionable_by_type_unknown": by_type_unknown,
        # Legacy actionable counts (kept for backward compat — not used by current dashboard)
        # These are approximations; actionable_critical/high/medium/low are authoritative
        "actionable_immediate": actionable_critical,
        "actionable_fix": summary["cves_reachable"] + summary["cwe_reachable"],
        "actionable_review": summary.get("secrets_unknown", 0) + dlp_reachable + ai_reachable,
    }


def calculate_risk_level(summary: Dict[str, int], metrics: Dict[str, Any], issues: List[Dict[str, Any]] = None) -> str:
    """
    Calculate overall risk level based on reachable issues.

    Priority (highest severity reachable issue determines posture):
    1. Any malware → CRITICAL
    2. Any CRITICAL severity reachable → CRITICAL
    3. Any KEV or high EPSS reachable → CRITICAL (actively exploited)
    4. Any HIGH severity reachable → HIGH
    5. Any MEDIUM severity reachable → MEDIUM
    6. Otherwise → LOW
    """
    # Malware is always critical
    if summary.get("malware_total", 0) > 0 or summary.get("suspicious_total", 0) > 0:
        return "CRITICAL"

    # Check for actively exploited vulnerabilities (KEV/EPSS amplifiers)
    if metrics.get("kev_total", 0) > 0 or metrics.get("epss_high", 0) > 0:
        return "CRITICAL"

    # Count reachable issues by severity
    issues_list = issues or []
    reachable_critical = 0
    reachable_high = 0
    reachable_medium = 0

    for issue in issues_list:
        if issue.get("reachability_state") == "reachable" or issue.get("is_reachable"):
            sev = (issue.get("severity") or "MEDIUM").upper()
            if sev == "CRITICAL":
                reachable_critical += 1
            elif sev == "HIGH":
                reachable_high += 1
            elif sev == "MEDIUM":
                reachable_medium += 1

    # Determine posture based on highest reachable severity
    if reachable_critical > 0:
        return "CRITICAL"
    if reachable_high > 0:
        return "HIGH"
    if reachable_medium > 0:
        return "MEDIUM"

    return "LOW"


def format_summary(summary: Dict[str, int], dlp_total: int = 0) -> Dict[str, str]:
    """Format summary for display (v4.4.0 + DLP)"""
    return {
        "cves": f"{summary['cves_total']} total, {summary['cves_reachable']} reachable",
        "cves_no_fix": f"{summary.get('cves_no_fix', 0)} without fix",
        "security_findings": f"{summary['cves_total'] + summary['secrets_total'] + summary['cwe_total'] + summary.get('config_total', 0) + dlp_total} total",
        "secrets": f"{summary['secrets_total']} secrets",
        "config": f"{summary.get('config_total', 0)} config issues",
        "cwe": f"{summary['cwe_total']} code weaknesses (CWE)",
        "malware": f"{summary['malware_total']} malicious packages",
        "suspicious": f"{summary.get('suspicious_total', 0)} suspicious packages",
    }
