#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.

"""
Grype Vulnerability Database Management

Manages the local cache of grype's vulnerability database to speed up scans.
The DB is refreshed automatically if older than 24 hours.

Cache location: ~/.reachable/cache/grype-db/
Timestamp file: ~/.reachable/cache/grype-db/.last_update

Usage:
    from reachable.collectors.vulns.grype import VulnDBManager

    mgr = VulnDBManager()
    mgr.ensure_fresh()  # Auto-refresh if > 24h old
    env = mgr.get_grype_env()  # Get env vars for grype subprocess
"""

import glob
import logging
import os
import shutil
import subprocess
import tempfile
from datetime import datetime, timedelta
from pathlib import Path
from typing import Optional

# Initialize module-level logger
logger = logging.getLogger(__name__)

def _is_network_reachable(host: str = "toolbox.anchore.io", port: int = 443, timeout: float = 3.0) -> bool:
    """Fast connectivity probe — returns False immediately if air-gapped.

    Probes the Grype DB update host (toolbox.anchore.io:443) with a 3-second
    timeout. This avoids hanging for the full 5-minute grype db update timeout
    in air-gapped environments.
    """
    import socket
    try:
        socket.setdefaulttimeout(timeout)
        with socket.create_connection((host, port), timeout=timeout):
            return True
    except OSError:
        return False


# Constants
GRYPE_DB_CACHE_DIR = Path.home() / ".reachable" / "cache" / "grype-db"
GRYPE_DB_TIMESTAMP_FILE = GRYPE_DB_CACHE_DIR / ".last_update"


def _grype_db_max_age_hours() -> int:
    """Grype DB max age — reads config at call time."""
    from reachable.core.config import get_grype_db_max_age_hours
    return get_grype_db_max_age_hours()


GRYPE_DB_MAX_AGE_HOURS: int  # resolved at call time via _grype_db_max_age_hours()

# Tool locations
TOOLS_BIN = Path.home() / ".reachable" / "tools" / "bin"


def _parse_grype_version(version_output: str) -> Optional[tuple]:
    """
    Parse Grype version from `grype version` output.

    Handles formats:
        Application:          grype
        Version:              0.87.0
    Or simpler: "grype 0.87.0"
    """
    import re
    # Match version patterns like 0.87.0, 0.104.1, 1.0.0
    m = re.search(r"(\d+)\.(\d+)\.(\d+)", version_output)
    if m:
        return (int(m.group(1)), int(m.group(2)), int(m.group(3)))
    return None


class VulnDBManager:
    """Manages grype vulnerability database caching and updates."""

    def __init__(self, cache_dir: Optional[Path] = None, max_age_hours: int = None):
        """
        Initialize VulnDB manager.

        Args:
            cache_dir: Override cache directory (default: ~/.reachable/cache/grype-db/)
            max_age_hours: Maximum age before auto-refresh (default: 24)
        """
        self.cache_dir = cache_dir or GRYPE_DB_CACHE_DIR
        self.timestamp_file = self.cache_dir / ".last_update"
        self.max_age_hours = max_age_hours if max_age_hours is not None else _grype_db_max_age_hours()
        self._grype_path: Optional[Path] = None

    @property
    def grype_path(self) -> Path:
        """Get path to grype binary, preferring local tools/bin."""
        if self._grype_path is None:
            # Check local tools first
            local_grype = TOOLS_BIN / "grype"
            if local_grype.exists():
                self._grype_path = local_grype
            else:
                # Fall back to system PATH
                import shutil

                system_grype = shutil.which("grype")
                if system_grype:
                    self._grype_path = Path(system_grype)
                else:
                    raise FileNotFoundError(
                        "grype not found. Install with:\n"
                        "  brew install grype  # macOS\n"
                        "  Or run the REACHABLE installer"
                    )
        return self._grype_path

    def get_grype_version(self) -> Optional[tuple]:
        """
        Get installed Grype version as a tuple (major, minor, patch).

        Returns:
            (major, minor, patch) tuple or None if version cannot be determined
        """
        try:
            from reachable.core.config import get_timeout as _cfg_timeout
            result = subprocess.run(
                [str(self.grype_path), "version"],
                capture_output=True,
                text=True,
                timeout=_cfg_timeout("grype_version_check_seconds"),
            )
            if result.returncode == 0:
                return _parse_grype_version(result.stdout)
        except Exception:
            pass
        return None

    def get_grype_version_string(self) -> str:
        """Get installed Grype version as a display string."""
        v = self.get_grype_version()
        if v is None:
            return "unknown"
        return f"{v[0]}.{v[1]}.{v[2]}"

    def check_grype_version(self) -> dict:
        """
        Check if installed Grype meets minimum version requirements.

        Uses GRYPE_MIN_VERSION from preflight.py as the authoritative source.

        Returns:
            dict with 'ok', 'installed', 'minimum', 'supports_v6_db', 'message'
        """
        try:
            from reachable.integrations.preflight import GRYPE_MIN_VERSION
        except ImportError:
            GRYPE_MIN_VERSION = (0, 88, 0)

        min_str = ".".join(str(x) for x in GRYPE_MIN_VERSION)
        v = self.get_grype_version()
        if v is None:
            return {
                "ok": False,
                "installed": "unknown",
                "minimum": min_str,
                "supports_v6_db": False,
                "message": "Could not determine Grype version",
            }

        installed_str = f"{v[0]}.{v[1]}.{v[2]}"
        meets_min = v >= GRYPE_MIN_VERSION
        supports_v6 = v >= (0, 88, 0)

        if meets_min:
            msg = f"Grype {installed_str} OK"
            if supports_v6:
                msg += " (DB v6)"
        else:
            msg = (
                f"Grype {installed_str} is below minimum {min_str}. "
                f"Run: reachctl doctor --fix"
            )

        return {
            "ok": meets_min,
            "installed": installed_str,
            "minimum": min_str,
            "supports_v6_db": supports_v6,
            "message": msg,
        }

    def get_db_age(self) -> Optional[timedelta]:
        """
        Get age of the cached vulnerability database.

        Returns:
            timedelta since last update, or None if no cache exists
        """
        if not self.timestamp_file.exists():
            return None

        try:
            timestamp_str = self.timestamp_file.read_text().strip()
            last_update = datetime.fromisoformat(timestamp_str)
            return datetime.now() - last_update
        except (ValueError, OSError):
            return None

    def get_db_age_hours(self) -> Optional[float]:
        """Get age in hours, or None if no cache."""
        age = self.get_db_age()
        if age is None:
            return None
        return age.total_seconds() / 3600

    def is_stale(self) -> bool:
        """Check if DB needs refresh (> max_age_hours old or doesn't exist)."""
        age_hours = self.get_db_age_hours()
        if age_hours is None:
            return True  # No cache exists
        return age_hours > self.max_age_hours

    def get_status(self) -> dict:
        """
        Get detailed status of the vulnerability database.

        Returns:
            dict with status info
        """
        age_hours = self.get_db_age_hours()
        db_exists = self.cache_dir.exists() and any(self.cache_dir.glob("*"))

        # Calculate size
        db_size = 0
        if db_exists:
            for f in self.cache_dir.rglob("*"):
                if f.is_file():
                    db_size += f.stat().st_size

        # Get last update time
        last_update = None
        if self.timestamp_file.exists():
            try:
                last_update = self.timestamp_file.read_text().strip()
            except OSError:
                pass

        return {
            "exists": db_exists,
            "location": str(self.cache_dir),
            "size_mb": db_size / (1024 * 1024),
            "age_hours": age_hours,
            "last_update": last_update,
            "is_stale": self.is_stale(),
            "max_age_hours": self.max_age_hours,
            "grype_path": str(self.grype_path) if self._grype_path else None,
            "grype_version": self.get_grype_version_string(),
            "version_check": self.check_grype_version(),
        }

    def update(self, force: bool = False, verbose: bool = True) -> bool:
        """
        Update the vulnerability database.

        Args:
            force: Update even if not stale
            verbose: Print progress messages

        Returns:
            True if update succeeded
        """
        if not force and not self.is_stale():
            if verbose:
                age = self.get_db_age_hours()
                logger.info(f" Vulnerability DB is fresh ({age:.1f}h old, max {self.max_age_hours}h)")
            return True

        # Ensure cache directory exists
        self.cache_dir.mkdir(parents=True, exist_ok=True)

        if verbose:
            if self.is_stale():
                age = self.get_db_age_hours()
                if age is None:
                    logger.info("    Downloading vulnerability database (first time)...")
                else:
                    logger.info(f" Refreshing vulnerability database ({age:.1f}h old > {self.max_age_hours}h limit)...")
            else:
                logger.info("    Force-refreshing vulnerability database...")

        # Per-invocation scratch isolated by PID — concurrent scans of
        # different repos never touch each other's active download.
        invocation_tmp = self.cache_dir / ".tmp" / f"update-{os.getpid()}"
        invocation_tmp.mkdir(parents=True, exist_ok=True)

        try:
            from reachable.core.config import get_timeout as _cfg_timeout
            env = self.get_grype_env()
            env["TMPDIR"] = str(invocation_tmp)  # pin to this invocation only
            result = subprocess.run(
                [str(self.grype_path), "db", "update"],
                env=env,
                capture_output=True,
                text=True,
                timeout=_cfg_timeout("grype_db_update_seconds"),
            )

            if result.returncode != 0:
                if verbose:
                    logger.info(f" DB update failed: {result.stderr[:200]}")
                return False

            # Update timestamp
            self._update_timestamp()

            # Clean orphaned schema dirs (e.g. 5/ left after v5→v6 upgrade)
            self._cleanup_old_schema_dirs()

            if verbose:
                size_mb = self.get_status()["size_mb"]
                logger.info(f" Vulnerability DB updated ({size_mb:.1f} MB)")

            return True

        except subprocess.TimeoutExpired:
            if verbose:
                logger.info("    DB update timed out (5 min)")
            return False
        except FileNotFoundError:
            if verbose:
                logger.info("    grype not found")
            return False
        except Exception as e:
            if verbose:
                logger.info(f" DB update error: {e}")
            return False
        finally:
            # Clean only THIS invocation's scratch — never a sibling's
            # active download (each invocation gets a unique PID dir).
            shutil.rmtree(invocation_tmp, ignore_errors=True)
            logger.debug("Cleaned grype update scratch: %s", invocation_tmp)
            # Sweep the system /tmp for orphans left by pre-fix runs.
            self._cleanup_legacy_system_tmp()

    def cleanup_scan_scratch(self, scan_dir: Path) -> None:
        """
        Remove the per-repo grype scratch dir after a scan completes or fails.

        Call this from the scan executor's finally block:
            db_mgr.cleanup_scan_scratch(self.output_dir)

        Args:
            scan_dir: The repo scan directory passed to get_grype_env().
        """
        scratch = scan_dir / ".grype-tmp"
        if scratch.exists():
            shutil.rmtree(scratch, ignore_errors=True)
            logger.debug("Cleaned per-repo grype scratch: %s", scratch)

    def _cleanup_legacy_system_tmp(self) -> None:
        """
        Remove orphaned grype-scratch* dirs from the system temp dir.

        These were left by pre-fix runs where TMPDIR was not redirected.
        Safe to call unconditionally — skips entries that don't exist.
        """
        system_tmp = tempfile.gettempdir()
        for d in glob.glob(os.path.join(system_tmp, "grype-scratch*")):
            shutil.rmtree(d, ignore_errors=True)
            logger.debug("Cleaned legacy system-tmp grype scratch: %s", d)

    def ensure_fresh(self, verbose: bool = False) -> bool:
        """
        Ensure DB is fresh, updating if necessary.

        This is the main method to call before running grype scans.
        It will automatically refresh if the DB is older than max_age_hours.
        Also checks Grype version meets minimum requirements.

        Args:
            verbose: Print progress messages

        Returns:
            True if DB is ready (fresh or successfully updated)
        """
        # v1.0.0b16: Version check — warn if below minimum
        try:
            vc = self.check_grype_version()
            if not vc["ok"]:
                logger.warning(f"\u26a0\ufe0f  {vc['message']}")
            elif verbose and vc["supports_v6_db"]:
                logger.info(f" {vc['message']}")
        except Exception:
            pass  # Don't block scan on version check failure

        if not self.is_stale():
            return True

        # Air-gapped fast-fail: probe network before attempting a 5-min download.
        # If unreachable and we have a cached DB (even stale), use it and warn.
        # If unreachable and NO cached DB, fail immediately with a clear message.
        if not _is_network_reachable():
            db_exists = self.cache_dir.exists() and any(self.cache_dir.glob("*"))
            if db_exists:
                age = self.get_db_age_hours()
                age_str = f"{age:.0f}h old" if age is not None else "unknown age"
                logger.warning(
                    f"⚠️  No network access — using cached Grype DB ({age_str}). "
                    "CVE coverage may be incomplete."
                )
                return True
            else:
                logger.error(
                    "❌ No network access and no cached Grype DB found. "
                    "Run `reachctl vulndb --update` on a connected machine first, "
                    "or set GRYPE_DB_CACHE_DIR to a pre-populated directory."
                )
                return False

        return self.update(verbose=verbose)

    def clear(self, verbose: bool = True) -> bool:
        """
        Clear the vulnerability database cache.

        Args:
            verbose: Print progress messages

        Returns:
            True if cleared successfully
        """
        import shutil

        if not self.cache_dir.exists():
            if verbose:
                logger.info("    Vulnerability DB already empty")
            return True

        try:
            # Get size before clearing
            size_mb = self.get_status()["size_mb"]

            shutil.rmtree(self.cache_dir)

            if verbose:
                logger.info(f" Cleared vulnerability DB ({size_mb:.1f} MB freed)")

            return True

        except Exception as e:
            if verbose:
                logger.info(f" Failed to clear DB: {e}")
            return False

    def get_grype_env(self, scan_dir: Optional[Path] = None) -> dict:
        """
        Get environment variables for running grype with cached DB.

        Sets GRYPE_DB_CACHE_DIR so grype uses the shared vulnerability DB
        (~/.reachable/cache/grype-db/) across all repos.

        Overrides TMPDIR to a per-repo scratch directory so that grype's
        download scratch files (grype-scratch*) are isolated per scan and
        never collide between concurrent repo scans:

            scan_dir provided  ->  <scan_dir>/.grype-tmp/
            no scan_dir        ->  ~/.reachable/cache/grype-db/.tmp/  (CLI/tests)

        The per-repo scratch is cleaned up by cleanup_scan_scratch() at the
        end of each scan (success or failure).

        Args:
            scan_dir: Per-repo scan dir (e.g. ~/.reachable/scans/<repo-id>/).
                      Pass self.output_dir from execution.py.

        Returns:
            dict of environment variables to pass to subprocess
        """
        env = os.environ.copy()
        env["GRYPE_DB_CACHE_DIR"] = str(self.cache_dir)

        # Per-repo scratch when scan_dir provided; shared fallback for CLI.
        tmp = (scan_dir / ".grype-tmp") if scan_dir else (self.cache_dir / ".tmp")
        tmp.mkdir(parents=True, exist_ok=True)
        env["TMPDIR"] = str(tmp)

        return env

    def _update_timestamp(self):
        """Update the last_update timestamp file."""
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        self.timestamp_file.write_text(datetime.now().isoformat())

    def _cleanup_old_schema_dirs(self) -> None:
        """Remove orphaned DB schema version directories.

        Grype creates numbered subdirs (5/, 6/) for each DB schema version.
        After an upgrade only the latest one is used; older ones are dead weight.
        Keep only the highest-numbered schema dir.
        """
        if not self.cache_dir.exists():
            return
        schema_dirs = sorted(
            [d for d in self.cache_dir.iterdir() if d.is_dir() and d.name.isdigit()],
            key=lambda d: int(d.name),
        )
        if len(schema_dirs) <= 1:
            return
        for old in schema_dirs[:-1]:
            try:
                shutil.rmtree(old)
                logger.info(f"  Removed orphaned DB schema dir: {old.name}/")
            except Exception as e:
                logger.debug(f"  Could not remove {old}: {e}")


def get_tool_path(tool: str) -> Path:
    """
    Get path to a tool binary, preferring local tools/bin.

    Args:
        tool: Tool name ('syft', 'grype', etc.)

    Returns:
        Path to tool binary

    Raises:
        FileNotFoundError if tool not found
    """
    # Check local tools first
    local_tool = TOOLS_BIN / tool
    if local_tool.exists():
        return local_tool

    # Fall back to system PATH
    import shutil

    system_tool = shutil.which(tool)
    if system_tool:
        return Path(system_tool)

    raise FileNotFoundError(f"{tool} not found in {TOOLS_BIN} or system PATH")


def get_syft_path() -> Path:
    """Get path to syft binary."""
    return get_tool_path("syft")


def get_grype_path() -> Path:
    """Get path to grype binary."""
    return get_tool_path("grype")


# Module-level convenience functions
_manager: Optional[VulnDBManager] = None


def get_manager() -> VulnDBManager:
    """Get or create the singleton VulnDBManager."""
    global _manager
    if _manager is None:
        _manager = VulnDBManager()
    return _manager


def ensure_fresh_db(verbose: bool = False) -> bool:
    """Ensure vulnerability DB is fresh (< 24h old)."""
    return get_manager().ensure_fresh(verbose=verbose)


def get_grype_env(scan_dir: Optional[Path] = None) -> dict:
    """
    Get environment variables for running grype.

    Args:
        scan_dir: Per-repo scan directory (e.g. ~/.reachable/scans/<repo-id>/).
                  Pass self.output_dir from execution.py to isolate each
                  repo's grype scratch under <scan_dir>/.grype-tmp/.
    """
    return get_manager().get_grype_env(scan_dir=scan_dir)


def get_db_status() -> dict:
    """Get vulnerability DB status."""
    return get_manager().get_status()


def check_grype_version() -> dict:
    """Check Grype version meets minimum requirements."""
    return get_manager().check_grype_version()


def get_grype_version_string() -> str:
    """Get installed Grype version as display string."""
    return get_manager().get_grype_version_string()
