#!/usr/bin/env python3
# Copyright 2026 Sthenos Security. All rights reserved.

"""
Package Health Analyzer

Takes PackageMetadata and computes health signals.
Pure logic - no I/O, no network, fully testable.
"""

import logging
from dataclasses import dataclass, field
from typing import Dict, List, Optional

from .registry import PackageMetadata

logger = logging.getLogger(__name__)

ABANDONED_DAYS = 730
STALE_DAYS = 365

# Polyfill/shim keywords for maintenance_complete detection (PKG-07)
_POLYFILL_KEYWORDS = (
    "polyfill", "shim", "ponyfill", "browser compat", "compatibility",
    "es5", "es6 compat", "ponyfill", "browser support", "legacy support",
    "backport",
)
_POLYFILL_MIN_WEEKLY_DOWNLOADS = 1_000_000

STATUS_PRIORITY = {
    "healthy": 0,
    "maintenance_complete": 1,   # intentionally frozen, not a risk (PKG-07)
    "info": 1,
    "deprecated": 2,
    "abandoned": 3,
    "abandoned_risky": 4,
    "confused": 4,
}


@dataclass
class HealthSignal:
    """A single health signal for a package."""

    signal_type: str
    confidence: str
    detail: str

    def to_dict(self) -> Dict:
        return {
            "signal_type": self.signal_type,
            "confidence": self.confidence,
            "detail": self.detail,
        }


@dataclass
class PackageHealthResult:
    """Health assessment for a single package."""

    name: str
    version: str
    ecosystem: str
    status: str = "healthy"
    signals: List[HealthSignal] = field(default_factory=list)
    metadata: Optional[PackageMetadata] = None
    is_direct: bool = False  # True if listed in a manifest (not only in a lock file)

    def to_dict(self) -> Dict:
        return {
            "name": self.name,
            "version": self.version,
            "ecosystem": self.ecosystem,
            "status": self.status,
            "signals": [s.to_dict() for s in self.signals],
            "metadata": self.metadata.to_dict() if self.metadata else None,
            "is_direct": self.is_direct,
        }


def _resolve_status(signals: List[HealthSignal]) -> str:
    """Determine overall status from signals. Highest priority wins."""
    if not signals:
        return "healthy"

    signal_to_status = {
        "abandoned": "abandoned",
        "abandoned_risky": "abandoned",
        "major_version_lag": "info",         # PKG-03: lag alone is not abandonment
        "deprecated": "deprecated",
        "override_deprecated": "deprecated", # PKG-10
        "override_abandoned": "abandoned",   # PKG-10
        "yanked": "deprecated",
        "stale": "info",
        "single_maintainer": "info",
        "no_repository": "info",
        "maintenance_complete": "maintenance_complete",  # PKG-07
        "confused": "confused",
        "fetch_error": "info",
    }

    best_status = "healthy"
    best_priority = -1

    for sig in signals:
        mapped = signal_to_status.get(sig.signal_type, "info")
        prio = STATUS_PRIORITY.get(mapped, 0)
        if prio > best_priority:
            best_priority = prio
            best_status = mapped

    return best_status


def _abandonment_risk_score(meta) -> int:
    """Multi-factor abandonment risk score (0-100). Higher = more risky.

    Formula:
      abandoned_score = years_since_release   (0-40)
                      + bus_factor            (0-25)
                      + dependency_count_inv  (-30 to +20)  weekly downloads proxy
                      + repo_activity         (0-10)  repo presence
                      + maintainer_activity   (0-5)   version frequency over lifetime

    High score requires multiple bad signals together — a very popular but old
    package (util-deprecate, core-util-is) gets a large negative from
    dependency_count_inv and scores too low to reach abandoned_risky (threshold: 60).

    Score bands:
      >= 60 → abandoned_risky  (red)
      >= 35 → abandoned        (orange)
      <  35 → stale            (shown as info)
    """
    score = 0
    days = meta.days_since_last_publish or 0

    # years_since_release (0-40)
    if days > 3650:    score += 40   # 10+ years
    elif days > 1825:  score += 25   # 5+ years
    elif days > 1095:  score += 20   # 3+ years (PKG-02/03/04: new band)
    elif days > 730:   score += 10   # 2+ years

    # bus_factor — single maintainer is high risk (0-25)
    count = meta.maintainer_count or 1
    if count == 1:    score += 25
    elif count <= 2:  score += 10

    # dependency_count_inv — weekly downloads proxy for ecosystem adoption (-25 to +20)
    # npm bulk downloads API or pypistats populates meta.weekly_downloads.
    # High download count = ecosystem depends on this = likely not truly abandoned.
    # PKG-02/04 FIX: the 1M-10M band previously subtracted -15, which caused packages
    # like jszip (~5M/week) and SheetJS sub-packages to score below the abandoned
    # threshold despite being genuinely inactive. Changed to neutral (0).
    # Very-high-usage polyfills (50M+/week) are caught by maintenance_complete (PKG-07).
    weekly = meta.weekly_downloads or 0
    if weekly == 0:            score += 20   # no data or zero
    elif weekly < 1_000:       score += 15
    elif weekly < 10_000:      score += 10
    elif weekly < 100_000:     score += 3
    elif weekly < 1_000_000:   score += 0    # popular: neutral
    elif weekly < 10_000_000:  score += 0    # PKG-02/04 FIX: was -15, now neutral
    elif weekly < 50_000_000:  score -= 15   # very popular
    else:                      score -= 25   # util-deprecate tier (50M+/week)

    # repo_activity — missing repo is a bad signal (0-10)
    if not meta.repository_url:
        score += 10

    # maintainer_activity — version publish frequency over package lifetime (0-5)
    # A package with 50 versions over 10 years is maintained; one with 2 versions
    # in the same window is not. Computed as versions/year.
    if meta.total_versions and days and days > 0:
        years = days / 365.25
        versions_per_year = meta.total_versions / max(years, 1.0)
        if versions_per_year < 0.2:   score += 5   # < 1 release per 5 years
        elif versions_per_year < 0.5: score += 2   # < 1 release per 2 years
        # >= 0.5/year: 0 pts (active cadence)

    return max(0, min(score, 100))


def analyze_public_package(meta: PackageMetadata) -> PackageHealthResult:
    """Analyze a public package for health signals."""
    result = PackageHealthResult(
        name=meta.name, version=meta.version, ecosystem=meta.ecosystem, metadata=meta
    )

    if not meta.fetched:
        result.signals.append(HealthSignal(
            signal_type="fetch_error",
            confidence="low",
            detail=f"Could not fetch metadata: {meta.error or 'unknown'}",
        ))
        result.status = _resolve_status(result.signals)
        return result

    if meta.deprecated:
        result.signals.append(HealthSignal(
            signal_type="deprecated",
            confidence="high",
            detail=f"Registry deprecated: {meta.deprecated}",
        ))

    if meta.yanked:
        result.signals.append(HealthSignal(
            signal_type="yanked",
            confidence="high",
            detail=f"Version {meta.version} has been yanked from the registry.",
        ))

    days = meta.days_since_last_publish
    if days is not None:
        if days >= ABANDONED_DAYS:
            risk_score = _abandonment_risk_score(meta)
            if risk_score >= 60:
                result.signals.append(HealthSignal(
                    signal_type="abandoned_risky",
                    confidence="high",
                    detail=(
                        f"Last published {days // 365}+ years ago. "
                        f"Abandonment risk score: {risk_score}/100. "
                        f"Low download activity, limited maintainership, or missing repository signals."
                    ),
                ))
            elif risk_score >= 35:
                result.signals.append(HealthSignal(
                    signal_type="abandoned",
                    confidence="medium",
                    detail=(
                        f"Last published {days // 365}+ years ago. "
                        f"Abandonment risk score: {risk_score}/100. "
                        f"Package may be in maintenance-complete state."
                    ),
                ))
            else:
                result.signals.append(HealthSignal(
                    signal_type="stale",
                    confidence="low",
                    detail=(
                        f"Last published {days // 365}+ years ago but shows stability signals "
                        f"(score {risk_score}/100 — high downloads or active ecosystem presence)."
                    ),
                ))
        elif days >= STALE_DAYS:
            result.signals.append(HealthSignal(
                signal_type="stale",
                confidence="medium",
                detail=f"Last published {days} days ago. Maintenance may be inactive.",
            ))

    # Major-version lag (PKG-03) — installed major is behind latest major AND
    # the installed version branch has not been updated in > 2 years.
    if meta.latest_version and days is not None and days >= 730:
        try:
            installed_major = int((meta.version or "0").split(".")[0].lstrip("v"))
            latest_major    = int((meta.latest_version or "0").split(".")[0].lstrip("v"))
            if latest_major > installed_major:
                result.signals.append(HealthSignal(
                    signal_type="major_version_lag",
                    confidence="medium",
                    detail=(
                        f"Installed major version v{installed_major} is EOL — "
                        f"latest is v{latest_major}. "
                        f"The v{installed_major} branch has not been updated in "
                        f"{days // 365}+ years."
                    ),
                ))
        except (ValueError, IndexError):
            pass

    if meta.maintainer_count == 1:
        result.signals.append(HealthSignal(
            signal_type="single_maintainer",
            confidence="low",
            detail=f"Single maintainer: {meta.maintainers[0] if meta.maintainers else 'unknown'}",
        ))

    if not meta.repository_url:
        result.signals.append(HealthSignal(
            signal_type="no_repository",
            confidence="low",
            detail="No source repository URL in registry metadata.",
        ))

    # Maintenance-complete reclassification (PKG-07)
    # A package that scores as abandoned but has very high download counts and a
    # polyfill/shim description is not a supply chain risk — it is intentionally
    # frozen. Reclassify to maintenance_complete so it doesn't pollute the
    # abandoned count.
    result.status = _resolve_status(result.signals)
    if result.status == "abandoned":
        desc_lower = (meta.description or "").lower()
        has_polyfill_keywords = any(kw in desc_lower for kw in _POLYFILL_KEYWORDS)
        has_high_downloads = (meta.weekly_downloads or 0) >= 100_000
        if has_polyfill_keywords or has_high_downloads:
            # Replace the stale/abandoned signal with maintenance_complete
            result.signals = [
                s for s in result.signals
                if s.signal_type not in ("abandoned", "abandoned_risky", "stale")
            ]
            result.signals.append(HealthSignal(
                signal_type="maintenance_complete",
                confidence="medium",
                detail=(
                    f"Package is intentionally frozen (polyfill/shim). "
                    f"Last published {(days or 0) // 365}+ years ago but has "
                    f"{meta.weekly_downloads:,} weekly downloads and serves a "
                    f"compatibility/shim purpose. Not an active supply chain risk."
                ),
            ))
            result.status = "maintenance_complete"
    return result


def analyze_private_package(
    name: str,
    version: str,
    ecosystem: str,
    exists_on_public: bool,
) -> Optional[PackageHealthResult]:
    """Analyze a private package for dependency confusion."""
    if not exists_on_public:
        return None

    result = PackageHealthResult(name=name, version=version, ecosystem=ecosystem)
    result.signals.append(HealthSignal(
        signal_type="confused",
        confidence="high",
        detail=(
            f"Private package '{name}' also exists on the public {ecosystem} registry. "
            "This creates a dependency confusion attack vector \u2014 an adversary could "
            "publish a higher version on the public registry."
        ),
    ))
    result.status = "confused"
    return result
