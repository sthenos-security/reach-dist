#!/usr/bin/env python3
# Copyright 2026 Sthenos Security. All rights reserved.

"""
Registry API Clients — stdlib only, no third-party dependencies.

Fetches package metadata from public registries:
  - npm:  registry.npmjs.org
  - PyPI: pypi.org/pypi

Uses urllib.request (stdlib) instead of requests.

Abandonment scoring uses multi-factor formula:
  abandoned_score = years_since_release + bus_factor + maintainer_activity
                  + dependency_count + repo_activity

Download counts fetched via bulk npm endpoint (128 names/request)
and pypistats per-package endpoint. All responses cached 24h to disk.
"""

import hashlib
import json
import logging
import socket
import sys
import threading
import time
import urllib.error
import urllib.parse
import urllib.request

# Python 3.14.3+ fires HTTPResponse.__del__ → flush() on GC even after close().
# This produces noisy "Exception ignored" stderr that scares customers.
# Suppress only the specific ValueError from http.client finalizer.
_orig_unraisablehook = sys.unraisablehook


def _quiet_http_finalizer(unraisable):
    if isinstance(unraisable.exc_value, ValueError) and "closed file" in str(unraisable.exc_value):
        return
    _orig_unraisablehook(unraisable)


sys.unraisablehook = _quiet_http_finalizer

from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, List, Optional

logger = logging.getLogger(__name__)

_NPM_BASE       = "https://registry.npmjs.org"
_NPM_STATS_BASE = "https://api.npmjs.org"
_PYPI_BASE      = "https://pypi.org/pypi"
_PYPISTATS_BASE = "https://pypistats.org/api"

# ---------------------------------------------------------------------------
# Disk cache — 24h TTL, keyed by URL hash
# ---------------------------------------------------------------------------
_CACHE_DIR = Path.home() / ".reachable" / "cache" / "registry"
_CACHE_TTL  = 86_400  # 24 hours


def _cache_path(url: str) -> Path:
    key = hashlib.sha256(url.encode()).hexdigest()
    return _CACHE_DIR / key[:2] / key


def _cache_get(url: str) -> Optional[bytes]:
    p = _cache_path(url)
    try:
        if p.exists() and (time.time() - p.stat().st_mtime) < _CACHE_TTL:
            return p.read_bytes()
    except Exception:
        pass
    return None


def _cache_set(url: str, body: bytes) -> None:
    p = _cache_path(url)
    try:
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_bytes(body)
    except Exception:
        pass


# ---------------------------------------------------------------------------
# API call telemetry — reset per pipeline step via reset_api_stats()
# ---------------------------------------------------------------------------
_api_stats: Dict[str, int] = {}
_api_stats_lock = threading.Lock()


def reset_api_stats() -> None:
    """Reset counters at the start of each health step."""
    with _api_stats_lock:
        _api_stats.clear()


def get_api_stats() -> Dict[str, int]:
    """Return a copy of current counters."""
    with _api_stats_lock:
        return dict(_api_stats)


def _record(endpoint: str) -> None:
    with _api_stats_lock:
        _api_stats[endpoint] = _api_stats.get(endpoint, 0) + 1


_HEADERS = {
    "User-Agent": "reachable-security/1.0 (package-health-scanner)",
    "Accept": "application/json",
}

_MAX_RESPONSE_BYTES = 10 * 1024 * 1024  # 10 MB cap


# HTTP status codes that warrant a retry (transient server/network errors).
# 404 is NOT here — it is definitive (package does not exist on that registry).
_TRANSIENT_CODES = frozenset({429, 500, 502, 503, 504})
# Max retry attempts and base back-off in seconds (0.5 → 1.0 → 2.0)
_HTTP_MAX_RETRIES = 3
_HTTP_BACKOFF_BASE = 0.5


def _http_get(url: str, timeout: float = 8.0, use_cache: bool = True):
    """GET url → (status: int, body: bytes). Checks disk cache first.

    Retries up to _HTTP_MAX_RETRIES times on transient HTTP codes (429, 5xx)
    and network timeouts, using exponential back-off (0.5 s → 1.0 s → 2.0 s).
    Permanent errors (e.g. 404) are raised immediately without retrying.
    """
    host = url.split("/")[2] if url.startswith("http") else url

    if use_cache:
        cached = _cache_get(url)
        if cached is not None:
            return 200, cached

    _record(host)
    req = urllib.request.Request(url, headers=_HEADERS)
    last_exc: Exception = RuntimeError("unreachable")
    for attempt in range(_HTTP_MAX_RETRIES):
        try:
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                body = resp.read(_MAX_RESPONSE_BYTES)
                truncated = len(body) == _MAX_RESPONSE_BYTES
                # Only drain if truncated — full reads leave no residual data.
                # Draining a fully-read response hits a closed socket on 3.14.3+
                # and triggers GC finalizer "I/O operation on closed file" noise.
                if truncated:
                    try:
                        while resp.read(65536):
                            pass
                    except Exception:
                        pass
                if use_cache and not truncated:
                    # Don't cache truncated responses — partial JSON is
                    # corrupt and would serve bad data on the next request.
                    _cache_set(url, body)
                return resp.status, body
        except urllib.error.HTTPError as exc:
            if exc.code in _TRANSIENT_CODES and attempt < _HTTP_MAX_RETRIES - 1:
                logger.debug("_http_get: HTTP %d for %s, retry %d/%d",
                             exc.code, url, attempt + 1, _HTTP_MAX_RETRIES - 1)
                time.sleep(_HTTP_BACKOFF_BASE * (2 ** attempt))
                last_exc = exc
                continue
            raise  # 404, 401, 403 and other definitive codes — do not retry
        except (socket.timeout, urllib.error.URLError) as exc:
            if attempt < _HTTP_MAX_RETRIES - 1:
                logger.debug("_http_get: network error for %s, retry %d/%d: %s",
                             url, attempt + 1, _HTTP_MAX_RETRIES - 1, exc)
                time.sleep(_HTTP_BACKOFF_BASE * (2 ** attempt))
                last_exc = exc
                continue
            raise
    raise last_exc  # exhausted retries


def _http_head(url: str, timeout: float = 5.0) -> int:
    """HEAD url → HTTP status code, 0 on error."""
    host = url.split("/")[2] if url.startswith("http") else url
    _record(host)
    req = urllib.request.Request(url, headers=_HEADERS, method="HEAD")
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return resp.status
    except urllib.error.HTTPError as exc:
        return exc.code
    except Exception:
        return 0


# ---------------------------------------------------------------------------
# PackageMetadata
# ---------------------------------------------------------------------------

@dataclass
class PackageMetadata:
    """Normalised metadata from any registry."""
    name: str
    version: str
    ecosystem: str

    latest_version: Optional[str] = None
    latest_publish_iso: Optional[str] = None
    version_publish_iso: Optional[str] = None
    days_since_last_publish: Optional[int] = None
    deprecated: Optional[str] = None
    yanked: bool = False

    maintainer_count: int = 0
    maintainers: List[str] = field(default_factory=list)

    repository_url: Optional[str] = None
    homepage_url: Optional[str] = None
    total_versions: int = 0

    # Popularity / activity signals for abandonment scoring
    weekly_downloads: int = 0   # npm bulk downloads API or pypistats

    # Human-readable description — used for polyfill/shim detection (PKG-07)
    description: Optional[str] = None

    fetched: bool = False
    error: Optional[str] = None

    def to_dict(self) -> Dict:
        return {
            "name": self.name, "version": self.version, "ecosystem": self.ecosystem,
            "latest_version": self.latest_version,
            "latest_publish_iso": self.latest_publish_iso,
            "version_publish_iso": self.version_publish_iso,
            "days_since_last_publish": self.days_since_last_publish,
            "deprecated": self.deprecated, "yanked": self.yanked,
            "maintainer_count": self.maintainer_count, "maintainers": self.maintainers,
            "repository_url": self.repository_url, "homepage_url": self.homepage_url,
            "total_versions": self.total_versions,
            "weekly_downloads": self.weekly_downloads,
            "description": self.description,
            "fetched": self.fetched, "error": self.error,
        }


# ---------------------------------------------------------------------------
# Date helpers
# ---------------------------------------------------------------------------

def _parse_iso_date(iso_str: Optional[str]) -> Optional[datetime]:
    if not iso_str:
        return None
    try:
        cleaned = iso_str.replace("Z", "+00:00")
        if "+" not in cleaned and "T" in cleaned:
            cleaned += "+00:00"
        return datetime.fromisoformat(cleaned)
    except (ValueError, TypeError):
        return None


def _days_since(iso_str: Optional[str]) -> Optional[int]:
    dt = _parse_iso_date(iso_str)
    if dt is None:
        return None
    return (datetime.now(timezone.utc) - dt).days


# ---------------------------------------------------------------------------
# npm registry fetch
# ---------------------------------------------------------------------------

def fetch_npm(name: str, version: str, timeout: float = 8.0) -> PackageMetadata:
    """Fetch npm packument from registry.npmjs.org. weekly_downloads backfilled later."""
    meta = PackageMetadata(name=name, version=version, ecosystem="npm")
    try:
        url = f"{_NPM_BASE}/{urllib.parse.quote(name, safe='@')}"
        try:
            status, body = _http_get(url, timeout=timeout)
        except urllib.error.HTTPError as exc:
            if exc.code == 404:
                meta.error = "not_found"
                return meta
            raise
        data = json.loads(body)
        time_map = data.get("time", {})
        if isinstance(time_map, str):
            time_map = {"modified": time_map}

        dist_tags = data.get("dist-tags", {})
        meta.latest_version = dist_tags.get("latest")

        if meta.latest_version and meta.latest_version in time_map:
            meta.latest_publish_iso = time_map[meta.latest_version]
        elif "modified" in time_map:
            meta.latest_publish_iso = time_map["modified"]

        if version in time_map:
            meta.version_publish_iso = time_map[version]

        meta.days_since_last_publish = _days_since(meta.latest_publish_iso)

        raw_maintainers = data.get("maintainers", [])
        if raw_maintainers:
            meta.maintainers = [
                m.get("name", str(m)) if isinstance(m, dict) else str(m)
                for m in raw_maintainers
            ]
            meta.maintainer_count = len(meta.maintainers)

        versions = data.get("versions", {})
        meta.total_versions = len(versions) if isinstance(versions, dict) else 0

        ver_data = versions.get(version, {}) if isinstance(versions, dict) else {}
        dep_msg = ver_data.get("deprecated")
        if dep_msg:
            meta.deprecated = str(dep_msg)
        elif data.get("deprecated"):
            meta.deprecated = str(data["deprecated"])

        repo = data.get("repository")
        if isinstance(repo, dict):
            meta.repository_url = repo.get("url", "")
        elif isinstance(repo, str):
            meta.repository_url = repo

        meta.homepage_url = data.get("homepage")
        meta.description = data.get("description") or ""
        meta.fetched = True

    except socket.timeout:
        meta.error = "timeout"
    except urllib.error.URLError as exc:
        if "timed out" in str(exc).lower() or isinstance(getattr(exc, "reason", None), socket.timeout):
            meta.error = "timeout"
        else:
            meta.error = f"network_error: {exc}"
    except Exception as exc:
        meta.error = f"parse_error: {exc}"

    return meta


# ---------------------------------------------------------------------------
# npm bulk download counts — api.npmjs.org/downloads/point/last-week/{csv}
# Up to 128 package names per request.
# ---------------------------------------------------------------------------

_NPM_BULK_LIMIT = 128


def fetch_npm_download_counts_bulk(names: List[str], timeout: float = 10.0) -> Dict[str, int]:
    """Fetch last-week download counts for a list of npm package names.

    Uses the bulk endpoint: api.npmjs.org/downloads/point/last-week/a,b,c,...
    Batches into chunks of 128 (registry limit). Returns {name: count}.
    Scoped packages (@org/name) are NOT supported by the bulk endpoint —
    they are fetched individually. Results are cached 24h.
    """
    counts: Dict[str, int] = {}
    # Bulk endpoint does not support scoped packages — separate them
    unscoped = [n for n in names if not n.startswith("@")]
    scoped   = [n for n in names if n.startswith("@")]

    # Bulk fetch for unscoped
    for i in range(0, len(unscoped), _NPM_BULK_LIMIT):
        batch = unscoped[i:i + _NPM_BULK_LIMIT]
        csv = ",".join(urllib.parse.quote(n, safe="") for n in batch)
        url = f"{_NPM_STATS_BASE}/downloads/point/last-week/{csv}"
        try:
            _, body = _http_get(url, timeout=timeout, use_cache=True)
            data = json.loads(body)
            # Bulk response: {pkg_name: {downloads: N, ...}, ...}
            for name, info in data.items():
                if isinstance(info, dict):
                    counts[name] = int(info.get("downloads", 0) or 0)
        except Exception as exc:
            logger.debug(f"npm bulk download fetch failed for batch starting {batch[0]}: {exc}")

    # Per-package fetch for scoped (no bulk support)
    for name in scoped:
        encoded = urllib.parse.quote(name, safe="@")
        url = f"{_NPM_STATS_BASE}/downloads/point/last-week/{encoded}"
        try:
            _, body = _http_get(url, timeout=timeout, use_cache=True)
            data = json.loads(body)
            counts[name] = int(data.get("downloads", 0) or 0)
        except Exception as exc:
            logger.debug(f"npm download fetch failed for {name}: {exc}")

    return counts


# ---------------------------------------------------------------------------
# PyPI registry fetch
# ---------------------------------------------------------------------------

def fetch_pypi(name: str, version: str, timeout: float = 8.0) -> PackageMetadata:
    """Fetch PyPI package metadata from pypi.org + weekly downloads from pypistats."""
    meta = PackageMetadata(name=name, version=version, ecosystem="pypi")
    try:
        url = f"{_PYPI_BASE}/{urllib.parse.quote(name)}/json"
        try:
            status, body = _http_get(url, timeout=timeout)
        except urllib.error.HTTPError as exc:
            if exc.code == 404:
                meta.error = "not_found"
                return meta
            raise
        data = json.loads(body)
        info = data.get("info", {})
        meta.latest_version = info.get("version")
        meta.homepage_url = info.get("home_page")
        meta.repository_url = info.get("project_url") or info.get("home_page")
        meta.description = info.get("summary") or ""

        project_urls = info.get("project_urls") or {}
        for key in ("Source", "Repository", "Source Code", "GitHub", "Code"):
            if key in project_urls:
                meta.repository_url = project_urls[key]
                break

        author = info.get("author") or info.get("maintainer")
        if author:
            meta.maintainers = [author]
            meta.maintainer_count = 1

        releases = data.get("releases", {})
        meta.total_versions = len(releases)

        if meta.latest_version and meta.latest_version in releases:
            files = releases[meta.latest_version]
            if files:
                upload_time = files[0].get("upload_time_iso_8601") or files[0].get("upload_time")
                if upload_time:
                    meta.latest_publish_iso = upload_time

        if version in releases:
            files = releases[version]
            if files:
                upload_time = files[0].get("upload_time_iso_8601") or files[0].get("upload_time")
                if upload_time:
                    meta.version_publish_iso = upload_time
                meta.yanked = bool(files[0].get("yanked", False))

        meta.days_since_last_publish = _days_since(meta.latest_publish_iso)

        classifiers = info.get("classifiers", [])
        for c in classifiers:
            if "Inactive" in c or "Deprecated" in c:
                meta.deprecated = c
                break

        meta.fetched = True

    except socket.timeout:
        meta.error = "timeout"
    except urllib.error.URLError as exc:
        if "timed out" in str(exc).lower() or isinstance(getattr(exc, "reason", None), socket.timeout):
            meta.error = "timeout"
        else:
            meta.error = f"network_error: {exc}"
    except Exception as exc:
        meta.error = f"parse_error: {exc}"

    # Fetch weekly downloads from pypistats (separate endpoint, also cached)
    if meta.fetched:
        try:
            stats_url = f"{_PYPISTATS_BASE}/packages/{urllib.parse.quote(name)}/recent"
            _, stats_body = _http_get(stats_url, timeout=6.0, use_cache=True)
            stats_data = json.loads(stats_body)
            # Response: {"data": {"last_week": N, "last_month": N, ...}}
            meta.weekly_downloads = int(
                (stats_data.get("data") or {}).get("last_week", 0) or 0
            )
        except Exception as exc:
            logger.debug(f"pypistats fetch failed for {name}: {exc}")

    return meta


# ---------------------------------------------------------------------------
# Dispatch
# ---------------------------------------------------------------------------

_FETCHERS = {
    "npm": fetch_npm, "javascript": fetch_npm,
    "pypi": fetch_pypi, "python": fetch_pypi,
}


def fetch_metadata(name: str, version: str, ecosystem: str, timeout: float = 8.0) -> PackageMetadata:
    """Dispatch to the correct registry fetcher by ecosystem."""
    eco_key = ecosystem.lower().strip()
    fetcher = _FETCHERS.get(eco_key)
    if not fetcher:
        return PackageMetadata(name=name, version=version, ecosystem=eco_key,
                               error=f"unsupported_ecosystem: {eco_key}")
    return fetcher(name, version, timeout=timeout)


def check_public_exists(name: str, ecosystem: str, timeout: float = 5.0) -> bool:
    """HEAD check: does this package name exist on the public registry?"""
    eco = ecosystem.lower().strip()
    try:
        if eco in ("npm", "javascript"):
            return _http_head(f"{_NPM_BASE}/{urllib.parse.quote(name, safe='@')}", timeout) == 200
        elif eco in ("pypi", "python"):
            return _http_head(f"{_PYPI_BASE}/{urllib.parse.quote(name)}/json", timeout) == 200
    except Exception as e:
        logger.debug(f"check_public_exists failed for {name} ({eco}): {e}")
    return False
