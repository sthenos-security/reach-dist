#!/usr/bin/env python3
# Copyright 2026 Sthenos Security. All rights reserved.

"""
Package Health Collector

Orchestrates the full package health pipeline:
  1. Parse SBOM for unique packages
  2. Classify public vs private (via purl_resolution_map)
  3. Fetch metadata for public packages
  4. Run confusion check for private packages
  5. Analyze all, return results
"""

import gzip
import json
import logging
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Tuple

from .analyzer import (
    PackageHealthResult,
    analyze_private_package,
    analyze_public_package,
)
from .overrides import apply_override, get_override
from .registry import (
    check_public_exists,
    fetch_metadata,
    fetch_npm_download_counts_bulk,
    get_api_stats,
    reset_api_stats,
)

logger = logging.getLogger(__name__)

MAX_HEALTH_CHECK_SECONDS = 30.0
_SUPPORTED_ECOSYSTEMS = {"npm", "javascript", "pypi", "python"}


def _collect_manifest_direct_names(repo_path: str) -> Set[str]:
    """
    Strategy 0: parse the repo's own manifests to get the set of direct dep names.
    Independent of Syft version. Used as the highest-priority signal.

    Reads: package.json (npm), requirements.txt, setup.cfg, pyproject.toml (pip),
           go.mod (go), Cargo.toml (rust), pom.xml (maven — first-level only).
    Returns lowercase package names so callers can do case-insensitive lookup.
    """
    import re
    direct: Set[str] = set()
    if not repo_path:
        return direct

    root = Path(repo_path)

    # ── npm / yarn / pnpm ─────────────────────────────────────────────────────
    pkg_json = root / "package.json"
    if pkg_json.exists():
        try:
            import json as _j
            data = _j.loads(pkg_json.read_text(encoding="utf-8", errors="replace"))
            for section in ("dependencies", "devDependencies", "peerDependencies", "optionalDependencies"):
                for name in (data.get(section) or {}).keys():
                    direct.add(name.lower())
        except Exception:
            pass

    # ── Python requirements.txt ────────────────────────────────────────────────
    for req_file in ("requirements.txt", "requirements-dev.txt", "requirements_dev.txt"):
        req = root / req_file
        if req.exists():
            try:
                for line in req.read_text(encoding="utf-8", errors="replace").splitlines():
                    line = line.strip()
                    if line and not line.startswith("#") and not line.startswith("-"):
                        # strip version specifiers: requests>=2.0 → requests
                        name = re.split(r"[>=<!;\s\[]", line)[0].strip().lower()
                        if name:
                            direct.add(name)
            except Exception:
                pass

    # ── pyproject.toml ─────────────────────────────────────────────────────────
    pyproject = root / "pyproject.toml"
    if pyproject.exists():
        try:
            text = pyproject.read_text(encoding="utf-8", errors="replace")
            # Grab [project].dependencies list (PEP 621) and [tool.poetry.dependencies]
            for line in text.splitlines():
                line = line.strip().strip('"').strip("'")
                if line and not line.startswith("#") and not line.startswith("[") and not line.startswith("{"):
                    name = re.split(r"[>=<!;\s\[]", line)[0].strip().lower()
                    if name and re.match(r"^[a-z0-9]", name):
                        direct.add(name)
        except Exception:
            pass

    # ── go.mod ─────────────────────────────────────────────────────────────────
    gomod = root / "go.mod"
    if gomod.exists():
        try:
            in_require = False
            for line in gomod.read_text(encoding="utf-8", errors="replace").splitlines():
                stripped = line.strip()
                if stripped.startswith("require ("):
                    in_require = True
                    continue
                if in_require and stripped == ")":
                    in_require = False
                    continue
                if in_require or stripped.startswith("require "):
                    parts = stripped.replace("require ", "").split()
                    if parts:
                        direct.add(parts[0].lower())
        except Exception:
            pass

    return direct


_MANIFEST_PATTERNS = (
    "package.json",
    "requirements.txt", "setup.py", "setup.cfg", "pyproject.toml", "Pipfile",
    "go.mod",
    "Gemfile",
    "Cargo.toml",
    "pom.xml", "build.gradle", "build.gradle.kts",
    "composer.json",
)
_LOCK_PATTERNS = (
    "package-lock.json", "yarn.lock", "pnpm-lock.yaml",
    "Pipfile.lock", "poetry.lock", "requirements.lock",
    "go.sum", "Gemfile.lock", "Cargo.lock",
    "composer.lock",
)


def _is_manifest_path(p: str) -> bool:
    import os
    base = os.path.basename(p)
    if any(base == lk or base.endswith(lk) for lk in _LOCK_PATTERNS):
        return False
    return any(base == m or base.endswith(m) for m in _MANIFEST_PATTERNS)


def parse_sbom_packages_from_dict(data: dict, repo_path: str = None) -> List[Dict[str, str]]:
    """Extract unique (name, version, ecosystem) tuples from a pre-loaded Syft SBOM dict.

    Use when SBOM is already in memory (from DB cache or in-process scan).
    Identical output to parse_sbom_packages() — no file I/O.
    """
    artifacts = data.get("artifacts", [])
    seen: Set[str] = set()
    packages: List[Dict[str, str]] = []

    # Strategy 0: parse repo manifests directly (independent of Syft version).
    # Highest priority — overrides everything when available.
    _manifest_direct_names = _collect_manifest_direct_names(repo_path) if repo_path else set()

    # Strategy 2 pre-pass: build set of artifact IDs that are DIRECT deps.
    # Syft emits a top-level "artifactRelationships" array (Syft JSON format) where
    # type="dependency-of" means the child is a direct dependency of the root target.
    # The root target is the artifact with type="directory" (the scanned repo itself).
    # We collect all child IDs whose parent is the root → those are direct deps.
    _direct_ids: Set[str] = set()
    _relationships = data.get("artifactRelationships", [])
    if _relationships:
        # Find root artifact ID(s) — type "directory" or matching source metadata
        _source_name = (data.get("source") or {}).get("name", "")
        _root_ids: Set[str] = set()
        for _art in artifacts:
            if _art.get("type", "").lower() in ("directory", "file"):
                _root_ids.add(_art.get("id", ""))
        # Also treat the source target itself as root
        _source_id = (data.get("source") or {}).get("id", "")
        if _source_id:
            _root_ids.add(_source_id)
        # Collect direct children of root
        for _rel in _relationships:
            if _rel.get("type", "").lower() in ("dependency-of", "contains") and _rel.get("parent") in _root_ids:
                _direct_ids.add(_rel.get("child", ""))
        # Build artifact id → artifact map for later lookup
    # C1 FIX: _art_by_id was built but never used — removed dead dict comprehension
    for art in artifacts:
        name = art.get("name", "")
        version = art.get("version", "")
        language = (art.get("language") or art.get("type") or "").lower()

        if not name or not version:
            continue
        if language not in _SUPPORTED_ECOSYSTEMS:
            continue

        key = f"{language}:{name}@{version}"
        if key in seen:
            continue
        seen.add(key)

        locations = art.get("locations", [])
        loc_paths = [loc.get("path", "") for loc in locations if loc.get("path")]

        # Direct dep detection — three strategies in priority order:
        #
        # 1. Syft npm metadata.relationship = "direct" | "indirect"
        #    Most reliable for npm/yarn/pnpm — Syft reads package-lock.json
        #    dependency tree and records the relationship explicitly.
        #    ALL npm artifacts have locations = [package-lock.json] regardless
        #    of whether they are direct or transitive, so location-file heuristics
        #    fail for npm.
        #
        # 2. Syft artifactRelationships top-level array (SPDX-style)
        #    Some Syft versions emit this instead of artifact.metadata.relationship.
        #
        # 3. Location-file heuristic (Python, Go, Java, Ruby, Rust)
        #    For ecosystems where Syft DOES list manifests separately from lock
        #    files in locations[].path (e.g. requirements.txt vs Pipfile.lock).

        # Strategy 1: metadata.relationship (npm/yarn — Syft reads package-lock.json tree)
        # Most reliable signal — Syft explicitly recorded the relationship.
        if meta_rel := (art.get("metadata") or {}).get("relationship", ""):
            is_direct = meta_rel.lower() == "direct"
        elif _direct_ids:
            # Strategy 2: artifactRelationships pre-pass (SPDX-style Syft output)
            art_id = art.get("id", "")
            is_direct = art_id in _direct_ids
        elif _manifest_direct_names:
            # Strategy 0: repo manifest parse (fallback — Syft-version-independent)
            # Used only when Syft provides no relationship data at all.
            is_direct = name.lower() in _manifest_direct_names
        else:
            # Strategy 3: location-file heuristic (last resort)
            is_direct = any(_is_manifest_path(p) for p in loc_paths)

        packages.append({
            "name": name,
            "version": version,
            "ecosystem": language,
            "purl": art.get("purl", ""),
            "locations": loc_paths,
            "is_direct": is_direct,
        })

    return packages


def classify_packages(
    packages: List[Dict[str, str]],
    purl_resolution_map: Optional[Dict[str, str]] = None,
) -> Tuple[List[Dict[str, str]], List[Dict[str, str]]]:
    """Split packages into public and private based on PURL resolution.

    Logic:
        - If no purl_resolution_map: all packages are public (common case).
        - If purl_resolution_map exists:
            - Package PURL in map -> was private, now resolved -> treat as public
            - Package PURL NOT in map -> already public -> treat as public
            - Package with NO purl -> private (internal, no upstream)
    """
    if not purl_resolution_map:
        return packages, []

    public = []
    private = []
    resolved_purls = set(purl_resolution_map.keys())

    for pkg in packages:
        purl = pkg.get("purl", "")
        if not purl:
            private.append(pkg)
        elif purl in resolved_purls:
            public.append(pkg)
        else:
            public.append(pkg)

    return public, private


def run_package_health(
    sbom_path: Path = None,
    purl_resolution_map: Optional[Dict[str, str]] = None,
    timeout_budget: float = MAX_HEALTH_CHECK_SECONDS,
    sbom_data: dict = None,
    repo_path: str = None,
) -> List[PackageHealthResult]:
    """Run the full package health pipeline.

    Args:
        sbom_path: Path to SBOM file (file-based path)
        sbom_data: Pre-loaded SBOM dict (from DB cache). If provided, sbom_path ignored.
        repo_path: Repo root path for strategy-0 manifest parsing (direct dep detection).

    Returns:
        List of PackageHealthResult (only non-healthy packages).
    """
    start = time.monotonic()

    if sbom_data is not None:
        packages = parse_sbom_packages_from_dict(sbom_data, repo_path=repo_path)
    else:
        packages = parse_sbom_packages(sbom_path, repo_path=repo_path)
    logger.info(f"  Package health: {len(packages)} packages from SBOM")
    reset_api_stats()

    if not packages:
        return []

    public_pkgs, private_pkgs = classify_packages(packages, purl_resolution_map)
    if private_pkgs:
        logger.info(
            f"  Package health: {len(public_pkgs)} public, {len(private_pkgs)} private"
        )

    results: List[PackageHealthResult] = []
    _deadline = start + timeout_budget
    _MAX_WORKERS = 16

    def _fetch_public(pkg):
        remaining = _deadline - time.monotonic()
        if remaining < 0.5:
            return None
        meta = fetch_metadata(
            pkg["name"], pkg["version"], pkg["ecosystem"],
            timeout=min(5.0, remaining)
        )
        health = analyze_public_package(meta)
        health.is_direct = pkg.get("is_direct", False)
        # PKG-10: apply manual overrides after automated analysis
        override = get_override(meta.name, meta.ecosystem)
        if override:
            apply_override(health, override)
        return health

    if public_pkgs:
        workers = min(_MAX_WORKERS, len(public_pkgs))
        remaining_budget = max(1.0, _deadline - time.monotonic())
        with ThreadPoolExecutor(max_workers=workers) as executor:
            futures = {executor.submit(_fetch_public, pkg): pkg for pkg in public_pkgs}
            try:
                for future in as_completed(futures, timeout=remaining_budget):
                    try:
                        health = future.result()
                        if health is not None and health.status != "healthy":
                            results.append(health)
                    except Exception as exc:
                        pkg = futures[future]
                        logger.debug(f"  health fetch failed for {pkg['name']}: {exc}")
            except TimeoutError:
                elapsed = time.monotonic() - start
                logger.warning(
                    f"  Package health: timeout budget exceeded ({elapsed:.1f}s), "
                    f"{len(results)} results collected so far"
                )

    if private_pkgs:
        def _check_private(pkg):
            remaining = _deadline - time.monotonic()
            if remaining < 0.5:
                return None
            exists = check_public_exists(pkg["name"], pkg["ecosystem"], timeout=3.0)
            health = analyze_private_package(
                pkg["name"], pkg["version"], pkg["ecosystem"], exists
            )
            if health is not None:
                health.is_direct = pkg.get("is_direct", False)
            return health

        priv_workers = min(_MAX_WORKERS, len(private_pkgs))
        remaining_budget = max(1.0, _deadline - time.monotonic())
        with ThreadPoolExecutor(max_workers=priv_workers) as executor:
            futures = {executor.submit(_check_private, pkg): pkg for pkg in private_pkgs}
            try:
                for future in as_completed(futures, timeout=remaining_budget):
                    try:
                        health = future.result()
                        if health is not None:
                            results.append(health)
                    except Exception as exc:
                        logger.debug(f"  private health check failed: {exc}")
            except TimeoutError:
                logger.warning("  Package health: timeout budget exceeded for confusion checks")

    # --- Backfill npm weekly_downloads via bulk endpoint -------------------
    # The packument thread pool above already fetched metadata for all packages.
    # Now do 1-3 bulk calls to api.npmjs.org to populate weekly_downloads on
    # every npm PackageHealthResult.metadata object.
    # PyPI downloads were already fetched per-package inside fetch_pypi().
    npm_results = [
        r for r in results
        if r.metadata and r.metadata.ecosystem in ("npm", "javascript")
    ]
    if npm_results:
        npm_names = list({r.metadata.name for r in npm_results})
        try:
            dl_counts = fetch_npm_download_counts_bulk(npm_names)
            for r in npm_results:
                r.metadata.weekly_downloads = dl_counts.get(r.metadata.name, 0)
        except Exception as exc:
            logger.warning(f"  npm bulk download fetch failed: {exc}")

    # Re-analyze npm results now that weekly_downloads is populated.
    # Only re-run packages flagged as abandoned/abandoned_risky — status may
    # change (e.g. util-deprecate drops from abandoned_risky to stale/abandoned).
    from .analyzer import analyze_public_package as _analyze
    re_analyzed = []
    for r in results:
        if r.metadata and r.metadata.ecosystem in ("npm", "javascript") \
                and r.status == "abandoned" \
                and r.metadata.weekly_downloads > 0:  # C2 FIX: 'abandoned_risky' status never occurs (_resolve_status maps it to 'abandoned')
            refreshed = _analyze(r.metadata)
            refreshed.is_direct = r.is_direct
            re_analyzed.append(refreshed)
        else:
            re_analyzed.append(r)
    # Keep only non-healthy after re-analysis
    results = [r for r in re_analyzed if r.status != "healthy"]

    status_order = {"confused": 0, "abandoned": 1, "deprecated": 2, "info": 3, "healthy": 4}
    results.sort(key=lambda r: status_order.get(r.status, 99))

    elapsed = time.monotonic() - start
    stats = get_api_stats()
    total_calls = sum(stats.values())
    stats_str = "  ".join(f"{host}: {n}" for host, n in sorted(stats.items()))
    logger.info(
        f"  Package health: {len(results)} advisories "
        f"({sum(1 for r in results if r.status == 'confused')} confused, "
        f"{sum(1 for r in results if r.status == 'abandoned')} abandoned, "
        f"{sum(1 for r in results if r.status == 'deprecated')} deprecated) "
        f"in {elapsed:.1f}s"
    )
    logger.info(f"  API calls: {total_calls} total — {stats_str if stats_str else 'none'}")

    return results


class PackageHealthCollector:
    """Class-based wrapper for scan.py integration.

    scan.py does:
        collector = PackageHealthCollector(sbom_path=..., purl_resolution_map=...)
        report = collector.collect()
        db.store_package_health(report)

    The returned report object has an `advisories` attribute (list of dicts)
    that store_package_health() reads via getattr(report, 'advisories', []).
    """

    def __init__(self, sbom_path: Path = None, purl_resolution_map=None, timeout_budget=MAX_HEALTH_CHECK_SECONDS, sbom_data: dict = None, repo_path: str = None):
        """
        Args:
            sbom_path:  Path to sbom.json or sbom.json.gz (file-based path, backward compat)
            sbom_data:  Pre-loaded SBOM dict (from DB cache). If provided, sbom_path is ignored.
            purl_resolution_map: Optional mapping of purls to resolution hints
            timeout_budget: Max seconds for health checks
            repo_path: Repo root for strategy-0 direct dep detection (Syft-version-independent)
        """
        self._sbom_data = sbom_data  # pre-loaded dict takes priority
        self.sbom_path = Path(sbom_path) if sbom_path else None
        self.purl_resolution_map = purl_resolution_map or {}
        self.timeout_budget = timeout_budget
        self.repo_path = str(repo_path) if repo_path else None

    def collect(self):
        """Run pipeline and return a report object consumable by store_package_health."""
        results = run_package_health(
            sbom_path=self.sbom_path,
            purl_resolution_map=self.purl_resolution_map,
            timeout_budget=self.timeout_budget,
            sbom_data=self._sbom_data,
            repo_path=self.repo_path,
        )
        return _PackageHealthReport(results)


class _PackageHealthReport:
    """Lightweight report object with .advisories for DB storage."""

    def __init__(self, results: List[PackageHealthResult]):
        self.results = results
        self.advisories = self._to_advisory_dicts(results)

    @staticmethod
    def _to_advisory_dicts(results: List[PackageHealthResult]) -> List[Dict[str, Any]]:
        rows = []
        for r in results:
            signals = []
            for s in r.signals:
                try:
                    signals.append(s.to_dict())
                except Exception as e:
                    logger.warning(f"  Health: signal serialization failed for {r.name}: {e}")
            severity_map = {"confused": "CRITICAL", "abandoned": "HIGH", "deprecated": "MEDIUM", "maintenance_complete": "INFO"}
            sev = severity_map.get(r.status, "INFO")
            title = f"{r.name}@{r.version}: {r.status}"
            detail_parts = [s.get("detail", "") for s in signals if s.get("detail")]
            detail = "; ".join(detail_parts) if detail_parts else ""

            rows.append({
                "package_name": r.name,
                "version": r.version,
                "ecosystem": r.ecosystem,
                "purl": getattr(r, 'purl', '') or '',
                "status": r.status,
                "severity": sev,
                "signals": signals,
                "title": title,
                "detail": detail,
                "last_publish_date": r.metadata.latest_publish_iso if r.metadata else None,
                "latest_version": r.metadata.latest_version if r.metadata else None,
                "deprecated_msg": str(r.metadata.deprecated) if (r.metadata and r.metadata.deprecated) else None,
                "maintainer_count": r.metadata.maintainer_count if r.metadata else 0,
                "has_repository": bool(r.metadata.repository_url) if r.metadata else True,
                "is_deprecated": bool(r.metadata.deprecated) if r.metadata else False,
                "is_private": False,
                "is_direct": getattr(r, "is_direct", False),  # BUG FIX: was dropped here
            })
        return rows

    def to_dict(self) -> "Dict[str, Any]":
        """Serialize for results dict and dashboard data.json."""
        from .normalizer import normalize_for_dashboard
        return normalize_for_dashboard(self.results)

    def get(self, key, default=None):
        """Dict-like access for backward compat."""
        return getattr(self, key, default)

def parse_sbom_packages(sbom_path: Path, repo_path: str = None) -> List[Dict[str, str]]:
    """Extract unique (name, version, ecosystem) tuples from Syft SBOM file.

    Loads the file then delegates to parse_sbom_packages_from_dict().
    Kept for backward compatibility with monolithic scan path.
    """
    sbom_path = Path(sbom_path)
    try:
        if str(sbom_path).endswith(".gz"):
            with gzip.open(sbom_path, "rt", encoding="utf-8") as f:
                data = json.load(f)
        else:
            with open(sbom_path, "r", encoding="utf-8") as f:
                data = json.load(f)
    except FileNotFoundError:
        logger.error(f"  SBOM file not found: {sbom_path}")
        return []
    except PermissionError:
        logger.error(f"  SBOM file not readable (permission denied): {sbom_path}")
        return []
    except (json.JSONDecodeError, ValueError) as e:
        logger.error(f"  SBOM file is not valid JSON: {sbom_path}: {e}")
        return []
    except OSError as e:
        logger.error(f"  SBOM file read error: {sbom_path}: {e}")
        return []
    return parse_sbom_packages_from_dict(data, repo_path=repo_path)


