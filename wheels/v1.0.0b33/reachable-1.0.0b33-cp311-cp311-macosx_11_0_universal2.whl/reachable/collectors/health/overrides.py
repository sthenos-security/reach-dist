#!/usr/bin/env python3
# Copyright 2026 Sthenos Security. All rights reserved.

"""
Package Health Overrides (PKG-10)

Manually curated list of packages that cannot be correctly classified by
automated registry signals alone — typically packages that have migrated
off a public registry, been silently abandoned with no deprecation notice,
or whose npm page still exists but will never receive security patches.

Each entry forces a specific status regardless of registry scoring. The
override is applied *after* analyze_public_package() so it wins over all
automated signals.

Adding an entry:
    {
        "name":       "exact-npm-name",         # case-sensitive
        "ecosystem":  "npm",                    # or "pypi"
        "status":     "deprecated",             # or "abandoned"
        "severity":   "MEDIUM",                 # or "HIGH", "CRITICAL"
        "reason":     "Human-readable reason",
        "alternative": "Migration path or replacement",
        "cves":       ["CVE-2023-30533"],       # optional — known unpatched CVEs
        "added":      "2026-03-09",
    }
"""

from typing import Dict, List, Optional, Tuple

# ---------------------------------------------------------------------------
# Override table — edit this list to add / remove entries
# ---------------------------------------------------------------------------

_OVERRIDES: List[Dict] = [
    # PKG-01 — xlsx@0.18.5: SheetJS migrated from npm to private CDN after v0.18.5.
    # The npm package will never receive security patches. Two unpatched CVEs exist.
    {
        "name":        "xlsx",
        "ecosystem":   "npm",
        "status":      "deprecated",
        "severity":    "HIGH",
        "reason":      (
            "SheetJS migrated from npm to private CDN (cdn.sheetjs.com) after v0.18.5. "
            "The npm package will never receive security patches. "
            "CVE-2023-30533 (Prototype Pollution, CVSS 7.8) and "
            "CVE-2024-22363 (ReDoS, CVSS 7.5) are unpatched on npm."
        ),
        "alternative": "Migrate to cdn.sheetjs.com or replace with exceljs",
        "cves":        ["CVE-2023-30533", "CVE-2024-22363"],
        "added":       "2026-03-09",
    },
]

# ---------------------------------------------------------------------------
# Lookup index — built once at import time
# ---------------------------------------------------------------------------

_INDEX: Dict[Tuple[str, str], Dict] = {
    (entry["name"], entry["ecosystem"]): entry
    for entry in _OVERRIDES
}


def get_override(name: str, ecosystem: str) -> Optional[Dict]:
    """Return the override entry for (name, ecosystem) or None."""
    # Normalize ecosystem alias
    eco = ecosystem.lower()
    if eco == "javascript":
        eco = "npm"
    elif eco == "python":
        eco = "pypi"
    return _INDEX.get((name, eco))


def apply_override(result, override: Dict) -> None:
    """Mutate a PackageHealthResult in-place to reflect the override.

    Prepends an override signal and forces status/severity. The existing
    signals from registry analysis are preserved for audit purposes.
    """
    from .analyzer import HealthSignal

    cve_note = ""
    if override.get("cves"):
        cve_note = " Unpatched CVEs: " + ", ".join(override["cves"]) + "."

    signal = HealthSignal(
        signal_type="override_deprecated" if override["status"] == "deprecated" else "override_abandoned",
        confidence="high",
        detail=override["reason"] + cve_note + (
            f" Alternative: {override['alternative']}" if override.get("alternative") else ""
        ),
    )
    # Prepend so it shows first in the signals list
    result.signals.insert(0, signal)
    result.status = override["status"]
