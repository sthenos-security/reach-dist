"""
REACHABLE Parallel Execution — DAG Orchestrator

Runs pipeline steps as subprocesses in dependency order.
Steps with no unmet dependencies are launched immediately;
steps that have dependencies wait until all deps complete.

The DAG is read directly from pipeline.STEP_DEPENDENCIES.
Tool concurrency is injected via env vars derived by tuner.py.
"""

from __future__ import annotations

import logging
import os
import subprocess
import sys
import time
from concurrent.futures import Future, ThreadPoolExecutor, as_completed
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Optional

from reachable.cli.pipeline import PIPELINE_STEPS, STEP_DEPENDENCIES
from reachable.parallel.tuner import TuningConfig, derive_tuning

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Step result
# ---------------------------------------------------------------------------

@dataclass
class StepResult:
    name: str
    exit_code: int
    wall_seconds: float
    started_at: float
    error: Optional[str] = None

    @property
    def ok(self) -> bool:
        return self.exit_code == 0

    def summary(self) -> str:
        status = "✔" if self.ok else "✘"
        return f"  {status} {self.name:<10} {self.wall_seconds:6.1f}s"


@dataclass
class PipelineResult:
    steps: List[StepResult] = field(default_factory=list)
    total_wall_seconds: float = 0.0
    sequential_estimate_seconds: float = 0.0

    def print_summary(self) -> None:
        W = 44  # box width
        bar_max = 6   # max bar chars

        # Sort by wall time descending — longest (critical path) first
        sorted_steps = sorted(self.steps, key=lambda s: s.wall_seconds, reverse=True)
        max_t = sorted_steps[0].wall_seconds if sorted_steps else 1.0

        print()
        print("━" * W)
        print("  Parallel Pipeline")
        print("━" * W)
        for r in sorted_steps:
            icon = "✔" if r.ok else "✘"
            bar_len = max(1, round(r.wall_seconds / max_t * bar_max))
            bar = "." * bar_len + " " * (bar_max - bar_len)
            # critical path marker on the longest step
            marker = " ◀" if r is sorted_steps[0] else ""
            print(f"  {icon} {r.name:<10} {r.wall_seconds:5.1f}s  {bar}{marker}")
        print(f"  {'─' * (W - 2)}")
        print(f"  {'Wall time':<18} {self.total_wall_seconds:5.1f}s")
        if self.sequential_estimate_seconds > 0:
            saved = self.sequential_estimate_seconds - self.total_wall_seconds
            pct = saved / self.sequential_estimate_seconds * 100 if self.sequential_estimate_seconds else 0
            print(f"  {'Sequential est.':<18} {self.sequential_estimate_seconds:5.1f}s")
            print(f"  {'Saved':<18} {saved:5.1f}s  ({pct:.0f}%)")
        print("━" * W)
        failures = [r for r in self.steps if not r.ok]
        if failures:
            print(f"  ✘ Failed: {', '.join(r.name for r in failures)}")

    @property
    def all_ok(self) -> bool:
        return all(r.ok for r in self.steps)

    @property
    def failed_steps(self) -> List[str]:
        return [r.name for r in self.steps if not r.ok]


# ---------------------------------------------------------------------------
# Orchestrator
# ---------------------------------------------------------------------------

class PipelineOrchestrator:
    """
    Runs pipeline steps in parallel, respecting STEP_DEPENDENCIES.

    Each step is launched as a subprocess: `reachctl pipeline step <name> --session <dir>`
    Tool concurrency env vars are injected per subprocess.
    """

    def __init__(
        self,
        session_dir: Path,
        tuning: Optional[TuningConfig] = None,
        steps: Optional[List[str]] = None,
        reachctl_bin: Optional[str] = None,
        stream_output: bool = True,
    ):
        self.session_dir = session_dir
        self.tuning = tuning or derive_tuning()
        self.steps = steps or list(PIPELINE_STEPS.keys())
        self.stream_output = stream_output

        # Find reachctl binary
        if reachctl_bin:
            self.reachctl = reachctl_bin
        else:
            # Same Python env as the current process
            bin_dir = Path(sys.executable).parent
            candidate = bin_dir / "reachctl"
            self.reachctl = str(candidate) if candidate.exists() else "reachctl"

        # Build base env for subprocesses (inherit current env + tuning overrides)
        self._base_env = {**os.environ, **self.tuning.to_env()}

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def run(self) -> PipelineResult:
        """Execute the pipeline. Returns timing results for all steps."""
        t0 = time.monotonic()

        print()
        print(f"▶ Parallel pipeline — session: {self.session_dir}")
        print(f"  Max concurrent steps : {self.tuning.parallel_steps}")
        print(f"  semgrep_jobs         : {self.tuning.semgrep_jobs}")
        print(f"  gomaxprocs           : {self.tuning.gomaxprocs}")
        print(f"  trufflehog_concurr.  : {self.tuning.trufflehog_concurrency}")
        print(f"  joern_heap           : {self.tuning.joern_heap}")
        print()

        results: Dict[str, StepResult] = {}
        completed: set[str] = set()
        running: Dict[str, Future] = {}

        # Filter to requested steps only
        steps_to_run = [s for s in self.steps if s in PIPELINE_STEPS]
        # Build filtered dependency map
        deps = {s: [d for d in STEP_DEPENDENCIES.get(s, []) if d in steps_to_run]
                for s in steps_to_run}

        with ThreadPoolExecutor(max_workers=self.tuning.parallel_steps) as pool:
            while len(completed) < len(steps_to_run):
                # Launch all steps whose deps are satisfied and aren't running
                for step in steps_to_run:
                    if step in completed or step in running:
                        continue
                    step_deps = deps.get(step, [])
                    if all(d in completed for d in step_deps):
                        # Check no dep failed
                        failed_deps = [d for d in step_deps if not results[d].ok]
                        if failed_deps:
                            logger.warning(
                                f"Skipping {step} — dependency failed: {failed_deps}"
                            )
                            results[step] = StepResult(
                                name=step, exit_code=1,
                                wall_seconds=0.0, started_at=time.monotonic(),
                                error=f"dependency failed: {failed_deps}",
                            )
                            completed.add(step)
                            continue
                        print(f"  → launching: {step}")
                        fut = pool.submit(self._run_step, step)
                        running[step] = fut

                # Wait for at least one to finish
                if running:
                    done_futs = {f: n for n, f in running.items()}
                    try:
                        for fut in as_completed(done_futs.keys(), timeout=0.05):
                            step_name = done_futs[fut]
                            try:
                                result = fut.result()
                            except Exception as e:
                                result = StepResult(
                                    name=step_name, exit_code=1,
                                    wall_seconds=0.0, started_at=time.monotonic(),
                                    error=str(e),
                                )
                            results[step_name] = result
                            completed.add(step_name)
                            del running[step_name]
                            status = "✔" if result.ok else "✘"
                            print(f"  {status} {step_name:<10} finished in {result.wall_seconds:.1f}s")
                            break  # re-evaluate DAG after each completion
                    except TimeoutError:
                        pass  # no step finished in this 50ms window — loop and check again
                else:
                    time.sleep(0.1)

        total = time.monotonic() - t0
        sequential_est = sum(r.wall_seconds for r in results.values())

        pipeline_result = PipelineResult(
            steps=list(results.values()),
            total_wall_seconds=total,
            sequential_estimate_seconds=sequential_est,
        )
        return pipeline_result

    # ------------------------------------------------------------------
    # Internal
    # ------------------------------------------------------------------

    def _run_step(self, step: str) -> StepResult:
        t0 = time.monotonic()
        cmd = [
            self.reachctl, "pipeline", "step", step,
            "--session", str(self.session_dir),
        ]

        try:
            if self.stream_output:
                # Stream output prefixed with step name; tee to log queue if active
                from reachable.core.log_queue import make_stdout_reader
                proc = subprocess.Popen(
                    cmd,
                    env=self._base_env,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.STDOUT,
                    text=True, bufsize=1,
                )
                reader = make_stdout_reader(proc.stdout, step_name=step)
                reader.start()
                reader.join()
                # stdout EOF means process is done; wait() with short timeout to reap
                try:
                    proc.wait(timeout=2.0)
                except subprocess.TimeoutExpired:
                    proc.kill()
                    proc.wait()
                exit_code = proc.returncode
            else:
                result = subprocess.run(
                    cmd,
                    env=self._base_env,
                    capture_output=True,
                    text=True,
                )
                exit_code = result.returncode
                if exit_code != 0:
                    logger.error(f"Step {step} failed:\n{result.stderr}")

        except Exception as e:
            return StepResult(
                name=step, exit_code=1,
                wall_seconds=time.monotonic() - t0,
                started_at=t0,
                error=str(e),
            )

        return StepResult(
            name=step,
            exit_code=exit_code,
            wall_seconds=time.monotonic() - t0,
            started_at=t0,
        )


# ---------------------------------------------------------------------------
# Convenience entry points
# ---------------------------------------------------------------------------

def run_serial_pipeline(
    session_dir: Path,
    steps: Optional[List[str]] = None,
    tuning: Optional["TuningConfig"] = None,
    debug: bool = False,
    log_handle=None,  # ignored — kept for call-site compat during transition
) -> int:
    """
    Run the full pipeline sequentially in topological order.
    Uses identical subprocess calls as the parallel orchestrator — same code
    path, same raw output format — just one step at a time for easy debugging.
    Called by serial scan mode (--mode serial or REACH_PARALLEL=0).
    """
    import sys

    if tuning is None:
        tuning = derive_tuning()

    steps_to_run = steps or list(PIPELINE_STEPS.keys())
    deps = STEP_DEPENDENCIES

    # Topological sort (Kahn's algorithm)
    from collections import deque
    in_degree = {s: 0 for s in steps_to_run}
    adjacency: Dict[str, List[str]] = {s: [] for s in steps_to_run}
    for step in steps_to_run:
        for dep in deps.get(step, []):
            if dep in in_degree:
                in_degree[step] += 1
                adjacency[dep].append(step)
    queue = deque(s for s in steps_to_run if in_degree[s] == 0)
    ordered: List[str] = []
    while queue:
        s = queue.popleft()
        ordered.append(s)
        for nxt in adjacency[s]:
            in_degree[nxt] -= 1
            if in_degree[nxt] == 0:
                queue.append(nxt)

    # Find reachctl binary
    bin_dir = Path(sys.executable).parent
    candidate = bin_dir / "reachctl"
    reachctl = str(candidate) if candidate.exists() else "reachctl"
    env = {**os.environ, **tuning.to_env()}
    if debug:
        env["REACHABLE_DEBUG"] = "1"

    from reachable.core.log_queue import _active_queue, make_stdout_reader
    log_path = session_dir / "scan.log"

    print()
    print(f"▶ Serial pipeline — session: {session_dir}")
    print(f"  Steps: {' → '.join(ordered)}")
    if _active_queue is not None:
        print(f"  Log:   {log_path}")
    print()

    step_results: List[StepResult] = []
    t_total = time.monotonic()
    for step in ordered:
        t0 = time.monotonic()
        cmd = [reachctl, "pipeline", "step", step, "--session", str(session_dir)]
        if debug:
            cmd.append("--debug")
        print(f"  → {step}")
        proc = subprocess.Popen(
            cmd, env=env,
            stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
            text=True, bufsize=1,
        )

        reader = make_stdout_reader(proc.stdout, step_name=step, debug=debug)
        reader.start()
        reader.join()

        try:
            proc.wait(timeout=2.0)
        except subprocess.TimeoutExpired:
            proc.kill()
            proc.wait()
        elapsed = time.monotonic() - t0
        step_results.append(StepResult(name=step, exit_code=proc.returncode, wall_seconds=elapsed, started_at=t0))
        if proc.returncode != 0:
            print(f"  Step '{step}' failed (exit {proc.returncode}) — aborting serial pipeline")
            return 1

    total = time.monotonic() - t_total

    # Reuse parallel summary rendering — same format, DRY
    pipeline_result = PipelineResult(
        steps=step_results,
        total_wall_seconds=total,
        sequential_estimate_seconds=0.0,  # serial: no parallelism savings to show
    )
    pipeline_result.print_summary()
    print(f"  Log:   {log_path}")
    print("━" * 44)
    return 0


def run_parallel_pipeline(
    session_dir: Path,
    steps: Optional[List[str]] = None,
    tuning: Optional["TuningConfig"] = None,
) -> int:
    """
    Run the full pipeline in parallel. Returns exit code (0 = all ok).
    Called by `reachctl pipeline run --session <dir>`.
    Pass tuning to suppress duplicate hardware print when called from scan_concurrent.
    """
    if tuning is None:
        tuning = derive_tuning()
        hw = tuning.hw
        print(f"  CPU: {hw.ncpu} cores ({hw.cpu_vendor}, {hw.arch}), RAM: {hw.mem_gb:.1f}GB")
        print("  Auto-tuning:")
        print(tuning.summary())

    orch = PipelineOrchestrator(
        session_dir=session_dir,
        tuning=tuning,
        steps=steps,
    )

    result = orch.run()
    result.print_summary()

    return 0 if result.all_ok else 1
