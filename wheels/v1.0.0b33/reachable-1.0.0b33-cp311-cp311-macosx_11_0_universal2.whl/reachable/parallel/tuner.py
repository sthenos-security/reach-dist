"""
REACHABLE Parallel Execution — Hardware Tuner

Detects hardware capabilities and derives sensible defaults for parallel
execution. All values are overridable via env vars. Designed to be called
once at scan start; results cached for the lifetime of the process.
"""

from __future__ import annotations

import logging
import os
import platform
import subprocess
from dataclasses import dataclass, field
from functools import lru_cache
from typing import Optional

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Hardware profile
# ---------------------------------------------------------------------------

@dataclass
class HardwareProfile:
    ncpu: int
    mem_gb: float
    arch: str                     # arm64, x86_64
    os_name: str                  # Darwin, Linux
    cpu_vendor: str               # apple, intel, amd, graviton, unknown
    perf_cores: Optional[int]     # Apple Silicon P-cores (None on other platforms)
    eff_cores: Optional[int]      # Apple Silicon E-cores (None on other platforms)

    @property
    def effective_compute_cores(self) -> int:
        """Cores that should be used for CPU-heavy work."""
        if self.perf_cores:
            return self.perf_cores  # prefer P-cores on Apple Silicon
        return self.ncpu


@lru_cache(maxsize=1)
def detect_hardware() -> HardwareProfile:
    ncpu = os.cpu_count() or 1
    os_name = platform.system()   # Darwin, Linux
    arch = platform.machine()     # arm64, x86_64, aarch64

    # Normalize arch
    if arch in ("aarch64", "arm64"):
        arch = "arm64"

    # Memory
    try:
        import psutil
        mem_gb = psutil.virtual_memory().total / 1e9
    except Exception:
        mem_gb = _fallback_mem_gb(os_name)

    # CPU vendor + Apple Silicon P/E core split
    cpu_vendor, perf_cores, eff_cores = _detect_cpu_details(os_name, arch, ncpu)

    profile = HardwareProfile(
        ncpu=ncpu,
        mem_gb=mem_gb,
        arch=arch,
        os_name=os_name,
        cpu_vendor=cpu_vendor,
        perf_cores=perf_cores,
        eff_cores=eff_cores,
    )
    logger.debug(
        f"HW: {ncpu} CPU ({cpu_vendor}, arch={arch}), "
        f"mem={mem_gb:.1f}GB, P-cores={perf_cores}, E-cores={eff_cores}"
    )
    return profile


def _detect_cpu_details(
    os_name: str, arch: str, ncpu: int
) -> tuple[str, Optional[int], Optional[int]]:
    """Return (vendor, perf_cores, eff_cores)."""

    if os_name == "Darwin" and arch == "arm64":
        # Apple Silicon — query sysctl for P/E split
        try:
            p = int(_sysctl("hw.perflevel0.logicalcpu") or "0")
            e = int(_sysctl("hw.perflevel1.logicalcpu") or "0")
            if p > 0:
                return "apple", p, e or None
        except Exception:
            pass
        return "apple", None, None

    if os_name == "Linux":
        try:
            cpuinfo = open("/proc/cpuinfo").read().lower()
            if "graviton" in cpuinfo or (arch == "arm64" and "amazon" in cpuinfo):
                return "graviton", None, None
            if "amd" in cpuinfo or "authentikamd" in cpuinfo:
                return "amd", None, None
            if "intel" in cpuinfo or "genuineintel" in cpuinfo:
                return "intel", None, None
        except Exception:
            pass

    if arch == "arm64":
        return "arm", None, None

    return "unknown", None, None


def _sysctl(key: str) -> Optional[str]:
    try:
        result = subprocess.run(
            ["sysctl", "-n", key],
            capture_output=True, text=True, timeout=2
        )
        return result.stdout.strip() or None
    except Exception:
        return None


def _fallback_mem_gb(os_name: str) -> float:
    """Best-effort memory detection without psutil."""
    try:
        if os_name == "Linux":
            for line in open("/proc/meminfo"):
                if line.startswith("MemTotal:"):
                    kb = int(line.split()[1])
                    return kb / 1e6
        if os_name == "Darwin":
            out = _sysctl("hw.memsize")
            if out:
                return int(out) / 1e9
    except Exception:
        pass
    return 4.0  # safe fallback


# ---------------------------------------------------------------------------
# Tuning config
# ---------------------------------------------------------------------------

@dataclass
class TuningConfig:
    """Derived parallelism settings for a scan run."""

    # Step orchestration
    parallel_steps: int        # max concurrent step subprocesses

    # Per-tool knobs — passed as env vars to step subprocesses
    semgrep_jobs: int          # semgrep --jobs
    trufflehog_concurrency: int
    gomaxprocs: int            # GOMAXPROCS for syft, grype
    joern_heap: str            # JVM -Xmx (e.g. "2g")

    # Source info for logging
    hw: HardwareProfile = field(repr=False)
    overridden: list[str] = field(default_factory=list)

    def to_env(self) -> dict[str, str]:
        """Return dict suitable for subprocess env injection."""
        return {
            "REACH_PARALLEL_MAX_STEPS":      str(self.parallel_steps),
            "REACH_SEMGREP_JOBS":            str(self.semgrep_jobs),
            "REACH_TRUFFLEHOG_CONCURRENCY":  str(self.trufflehog_concurrency),
            "REACH_GOMAXPROCS":              str(self.gomaxprocs),
            "REACH_JOERN_HEAP":              self.joern_heap,
            "GOMAXPROCS":                    str(self.gomaxprocs),
        }

    def summary(self) -> str:
        lines = [
            f"  parallel_steps={self.parallel_steps}",
            f"  semgrep_jobs={self.semgrep_jobs}",
            f"  trufflehog_concurrency={self.trufflehog_concurrency}",
            f"  gomaxprocs={self.gomaxprocs}",
            f"  joern_heap={self.joern_heap}",
        ]
        if self.overridden:
            lines.append(f"  overridden via env: {', '.join(self.overridden)}")
        return "\n".join(lines)


def derive_tuning(hw: Optional[HardwareProfile] = None) -> TuningConfig:
    """
    Derive parallelism settings from hardware, then apply env var overrides.

    Override any value by setting the corresponding REACH_* env var.
    """
    if hw is None:
        hw = detect_hardware()

    N = hw.ncpu               # total logical cores — used for step-level parallelism
    C = hw.effective_compute_cores  # P-cores only (Apple) or N — used for per-tool limits
    mem = hw.mem_gb
    overridden: list[str] = []

    # ── Memory guard ───────────────────────────────────────────────────
    if mem < 2.0:
        # Constrained: sequential only
        auto_steps = 1
        auto_semgrep = 1
        auto_trufflehog = 2
        auto_gomaxprocs = 1
    elif mem < 4.0:
        auto_steps = min(2, N // 2)
        auto_semgrep = min(2, max(1, C // 2))
        auto_trufflehog = min(4, N // 2)
        auto_gomaxprocs = max(1, C // 2)
    else:
        # Step-level parallelism: use total cores — I/O-bound steps run fine on E-cores.
        # Cap at 4: beyond that steps fight for semgrep/joern CPU budget.
        auto_steps = min(4, max(1, N // 2))

        # Per-tool budgets — NOT divided by parallel_steps because tools
        # like semgrep only run in 1-2 steps simultaneously (secrets, iac).
        # Give each tool half the compute cores; the Go scheduler + OS handle
        # the rest. This avoids under-provisioning on Apple Silicon.

        # semgrep: 2 steps can run it concurrently (secrets + iac).
        # Give each half the P-cores, min 2.
        auto_semgrep = min(4, max(2, C // 2))

        # trufflehog: Go goroutines, give it all compute cores (tolerant)
        auto_trufflehog = min(8, max(4, C))

        # gomaxprocs: syft + grype run in scan step — half compute cores
        auto_gomaxprocs = max(2, C // 2)

    # joern heap: 25% of total RAM, min 512MB, max 4GB
    joern_mb = int(min(4096, max(512, mem * 0.25 * 1024)))
    auto_joern = f"{joern_mb // 1024}g" if joern_mb >= 1024 else f"{joern_mb}m"

    # ── Env var overrides ──────────────────────────────────────────────
    def _env_int(key: str, auto: int) -> int:
        val = os.environ.get(key)
        if val is not None:
            overridden.append(key)
            return max(1, int(val))
        return auto

    def _env_str(key: str, auto: str) -> str:
        val = os.environ.get(key)
        if val is not None:
            overridden.append(key)
            return val
        return auto

    return TuningConfig(
        hw=hw,
        parallel_steps=_env_int("REACH_PARALLEL_MAX_STEPS", auto_steps),
        semgrep_jobs=_env_int("REACH_SEMGREP_JOBS", auto_semgrep),
        trufflehog_concurrency=_env_int("REACH_TRUFFLEHOG_CONCURRENCY", auto_trufflehog),
        gomaxprocs=_env_int("REACH_GOMAXPROCS", auto_gomaxprocs),
        joern_heap=_env_str("REACH_JOERN_HEAP", auto_joern),
        overridden=overridden,
    )
