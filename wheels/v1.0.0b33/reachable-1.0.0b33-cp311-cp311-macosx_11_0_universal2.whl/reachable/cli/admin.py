#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.
"""CLI admin commands: cache, doctor, db, test, version."""

import logging
import os
import shutil
import subprocess
import sys
from pathlib import Path

# Cross-module imports
from reachable.cli.utils import format_size

logger = logging.getLogger(__name__)


def admin_cache(args):
    """Cache management commands (v4.5.40)"""
    import shutil

    # Default to --status if no option specified
    options = ["status", "clear", "clear_libs", "clear_vuln", "clear_epss", "clear_semgrep", "clear_db", "warm"]
    if not any([getattr(args, opt, False) for opt in options]):
        args.status = True

    cache_base = Path.home() / ".reachable"
    cache_dir = cache_base / "cache"  # v4.5.40: Consolidated cache location
    reachable_pkg = Path(__file__).parent.parent  # The reachable package directory
    pycache_dirs = list(reachable_pkg.rglob("__pycache__"))  # computed once, used by --status and --clear

    # Cache directories
    cache_dirs = {
        "libs": cache_dir / "libs",  # v4.5.40: Now under cache/
        "guarddog": cache_dir / "guarddog",  # GuardDog malware scan results
        "guarddog_venv": cache_dir / "guarddog-venv",  # GuardDog venv
        "vuln_db": cache_dir / "grype-db",  # Grype vulnerability DB
        "scans": cache_base / "scans",
    }

    # Exploitability cache files (not directories)
    cache_files = {
        "epss": cache_dir / "epss_cache.json",
        "kev": cache_dir / "kev_cache.json",
        "exploit_db": cache_dir / "exploitdb_cve_map.json",
        "metasploit": cache_dir / "metasploit_cve_map.json",
        "ghsa": cache_dir / "ghsa_cve_map.json",
        "health_metrics": cache_dir / "health-metrics",
    }

    if args.status:
        logger.info("REACHABLE CACHE STATUS")
        logger.info(f"Cache location: {cache_base}")
        total_size = 0

        # Show cache directories
        for name, path in cache_dirs.items():
            if not path.exists():
                logger.info(f" {name:15} {'(empty)':>10}")
                continue
            if name == "scans":
                # v4.5.41 FIX: scans dir can be huge — count top-level repo dirs only, no deep rglob
                try:
                    scan_dirs = [d for d in path.iterdir() if d.is_dir()]
                    scan_count = len(scan_dirs)
                    logger.info(f" {name:15} {'(see below)':>10} ({scan_count} repos)")
                except Exception:
                    logger.info(f" {name:15} {'(error)':>10}")
            else:
                try:
                    size = sum(f.stat().st_size for f in path.rglob("*") if f.is_file())
                    total_size += size
                    file_count = sum(1 for _ in path.rglob("*") if _.is_file())
                    logger.info(f" {name:15} {format_size(size):>10} ({file_count} files)")
                except Exception:
                    logger.info(f" {name:15} {'(error)':>10}")

        # Show exploitability cache files
        logger.info("")  # Separator
        logger.info("  Threat Intelligence:")
        for name, path in cache_files.items():
            if path.exists():
                if path.is_file():
                    size = path.stat().st_size
                    total_size += size
                    logger.info(f" {name:13} {format_size(size):>10}")
                else:  # Directory (health_metrics)
                    size = sum(f.stat().st_size for f in path.rglob("*") if f.is_file())
                    total_size += size
                    file_count = sum(1 for _ in path.rglob("*") if _.is_file())
                    logger.info(f" {name:13} {format_size(size):>10} ({file_count} files)")
            else:
                logger.info(f" {name:13} {'(empty)':>10}")

        # Show bytecode cache size
        bytecode_size = 0
        bytecode_files = 0
        for pycache in pycache_dirs:
            if pycache.exists():
                bytecode_size += sum(f.stat().st_size for f in pycache.rglob("*.pyc") if f.is_file())
                bytecode_files += sum(1 for f in pycache.rglob("*.pyc") if f.is_file())
        if bytecode_size > 0:
            total_size += bytecode_size
            logger.info(f" {'bytecode':15} {format_size(bytecode_size):>10} ({bytecode_files} .pyc files)")
        else:
            logger.info(f" {'bytecode':15} {'(empty)':>10}")

        # Show Semgrep SHA caches per repo
        scans_root = cache_base / "scans"
        semgrep_caches = []
        semgrep_total = 0
        if scans_root.exists():
            for repo_dir in sorted(scans_root.iterdir()):
                if not repo_dir.is_dir():
                    continue
                cf = repo_dir / "semgrep-cache.json"
                if cf.exists():
                    size = cf.stat().st_size
                    semgrep_total += size
                    semgrep_caches.append((repo_dir.name, size))
        if semgrep_caches:
            logger.info("  Semgrep Result Caches:")
            for repo_name, size in semgrep_caches:
                logger.info(f" {repo_name[:30]:30} {format_size(size):>10}")
            total_size += semgrep_total
        logger.info(f" {'TOTAL':15} {format_size(total_size):>10}")
        return

    # Clear DB-level caches (sbom_cache, call_graph_cache, sandbox_cache)
    if getattr(args, "clear_db", False):
        from reachable.database.storage import RepoDatabase

        scans_root = cache_base / "scans"
        if not scans_root.exists():
            logger.info("No scan databases found")
            return

        repo_dbs = sorted(scans_root.glob("*/repo.db"))
        if not repo_dbs:
            logger.info("No scan databases found")
            return

        if not args.force:
            logger.info(f"This will clear DB caches (SBOM, call graph, sandbox) for {len(repo_dbs)} repo(s)")
            confirm = input("Continue? [y/N] ").strip().lower()
            if confirm != "y":
                logger.info("Cancelled.")
                return

        total_sbom = total_cg = total_sb = 0
        for db_path in repo_dbs:
            repo_name = db_path.parent.name
            try:
                db = RepoDatabase(db_path)
                n_sbom = db.purge_sbom_cache(max_age_hours=0)
                n_cg = db.purge_call_graph_cache(max_age_hours=0)
                # sandbox uses strict < so bypass with direct DELETE
                cur = db.conn.execute("DELETE FROM sandbox_cache")
                db.conn.commit()
                n_sb = cur.rowcount
                total_sbom += n_sbom
                total_cg += n_cg
                total_sb += n_sb
                logger.info(
                    f" {repo_name}: sbom={n_sbom} call_graph={n_cg} sandbox={n_sb}"
                )
            except Exception as e:
                logger.info(f" {repo_name}: ERROR - {e}")

        logger.info(
            f"DB cache cleared: {total_sbom} SBOM, {total_cg} call graph, {total_sb} sandbox entries"
        )
        return

    # Warm caches
    if args.warm:
        admin_cache_warm()
        return

    # Determine what to clear
    dir_targets = []  # Directories to clear
    file_targets = []  # Files to clear (exploitability caches)
    clear_bytecode = False

    clear_semgrep_all = False
    if args.clear:
        dir_targets = ["libs", "vuln_db"]
        file_targets = ["epss", "kev", "exploit_db", "metasploit", "ghsa"]  # Threat intel files
        clear_bytecode = True  # v4.5.3: Also clear bytecode cache
        clear_semgrep_all = True  # Also clear all Semgrep SHA caches
    elif getattr(args, "clear_libs", False):
        dir_targets = ["libs"]
    elif getattr(args, "clear_vuln", False):
        dir_targets = ["vuln_db"]
    elif getattr(args, "clear_epss", False):
        file_targets = ["epss", "kev", "exploit_db", "metasploit", "ghsa"]  # All threat intel
    elif getattr(args, "clear_semgrep", False):
        # Clear Semgrep SHA result caches
        scans_root = cache_base / "scans"
        repo_filter = getattr(args, "repo", None)
        if not scans_root.exists():
            logger.info("No Semgrep caches found")
            return

        # Find matching repos
        targets = []
        for repo_dir in sorted(scans_root.iterdir()):
            cf = repo_dir / "semgrep-cache.json"
            if cf.exists():
                if repo_filter is None or repo_filter.lower() in repo_dir.name.lower():
                    targets.append((repo_dir.name, cf))

        if not targets:
            if repo_filter:
                logger.info(f"No Semgrep caches matching '{repo_filter}'")
            else:
                logger.info("No Semgrep caches found")
            return

        # Confirm unless --force
        if not args.force:
            logger.info(f"This will clear Semgrep caches for {len(targets)} repo(s):")
            for name, cf in targets:
                size = cf.stat().st_size
                logger.info(f" - {name}: {format_size(size)}")
            confirm = input("Continue? [y/N] ").strip().lower()
            if confirm != "y":
                logger.info("Cancelled.")
                return

        removed = 0
        for name, cf in targets:
            try:
                cf.unlink()
                removed += 1
                logger.info(f"Cleared Semgrep cache: {name}")
            except Exception as e:
                logger.info(f"Failed to clear {name}: {e}")
        logger.info(f"Cleared {removed} Semgrep cache(s)")
        return

    if not dir_targets and not file_targets:
        logger.info("No cache target specified")
        return

    # Confirm unless --force
    if not args.force:
        logger.info("This will clear the following caches:")
        for name in dir_targets:
            path = cache_dirs.get(name)
            if path and path.exists():
                size = sum(f.stat().st_size for f in path.rglob("*") if f.is_file())
                logger.info(f" - {name}: {format_size(size)}")
        for name in file_targets:
            path = cache_files.get(name)
            if path and path.exists():
                size = (
                    path.stat().st_size
                    if path.is_file()
                    else sum(f.stat().st_size for f in path.rglob("*") if f.is_file())
                )
                logger.info(f" - {name}: {format_size(size)}")
        confirm = input("Continue? [y/N] ").strip().lower()
        if confirm != "y":
            logger.info("Cancelled.")
            return

    # Clear directory caches
    for name in dir_targets:
        path = cache_dirs.get(name)
        if path and path.exists():
            try:
                shutil.rmtree(path)
                logger.info(f"Cleared {name}: {path}")
            except Exception as e:
                logger.info(f"Failed to clear {name}: {e}")
        else:
            logger.info(f"{name}: already empty")

    # Clear file caches (exploitability/threat intel)
    for name in file_targets:
        path = cache_files.get(name)
        if path and path.exists():
            try:
                if path.is_file():
                    path.unlink()
                else:
                    shutil.rmtree(path)
                logger.info(f"Cleared {name}: {path}")
            except Exception as e:
                logger.info(f"Failed to clear {name}: {e}")
        else:
            logger.info(f"{name}: already empty")

    # v4.5.3: Clear bytecode cache to avoid stale .pyc issues
    if clear_bytecode:
        bytecode_cleared = 0
        for pycache in pycache_dirs:
            if pycache.exists():
                try:
                    shutil.rmtree(pycache)
                    bytecode_cleared += 1
                except Exception as e:
                    logger.info(f"Failed to clear {pycache}: {e}")
        if bytecode_cleared > 0:
            logger.info(f"Cleared bytecode: {bytecode_cleared} __pycache__ directories")
        else:
            logger.info("bytecode: already empty")

    # Clear Semgrep SHA caches when --clear (all)
    if clear_semgrep_all:
        scans_root = cache_base / "scans"
        semgrep_cleared = 0
        if scans_root.exists():
            for repo_dir in scans_root.iterdir():
                cf = repo_dir / "semgrep-cache.json"
                if cf.exists():
                    try:
                        cf.unlink()
                        semgrep_cleared += 1
                    except Exception as e:
                        logger.info(f"Failed to clear semgrep cache {repo_dir.name}: {e}")
        if semgrep_cleared > 0:
            logger.info(f"Cleared semgrep: {semgrep_cleared} repo cache(s)")
        else:
            logger.info("semgrep: already empty")

    logger.info("Cache cleared successfully")


def admin_cache_warm():
    """Pre-warm caches by creating tool venvs and downloading data"""
    logger.info("REACHABLE CACHE WARM-UP")
    # Show CI/CD cache tip
    cache_dir = os.environ.get("REACHABLE_CACHE_DIR")
    if cache_dir:
        logger.info(f" REACHABLE_CACHE_DIR set: {cache_dir}")
    else:
        cache_dir = Path.home() / ".reachable-cache"
        logger.info(" Tip: Set REACHABLE_CACHE_DIR for CI/CD caching")
        logger.info(" export REACHABLE_CACHE_DIR=/path/to/ci-cache")
    # 1. GuardDog venv
    logger.info(" 1/3: GuardDog venv...")
    try:
        from reachable.collectors.malware.guarddog import GuardDogScanner

        scanner = GuardDogScanner()
        if scanner.is_available():
            logger.info("    GuardDog venv ready")
        else:
            logger.info("    GuardDog setup failed")
    except Exception as e:
        logger.info(f" GuardDog check failed: {e}")

    # 2. Semgrep (uses system install, but check availability)
    logger.info(" 2/3: Semgrep...")
    try:
        import subprocess

        result = subprocess.run(["semgrep", "--version"], capture_output=True, timeout=5)
        if result.returncode == 0:
            version = result.stdout.decode().strip()
            logger.info(f" Semgrep available: {version}")
        else:
            logger.info("     Semgrep not installed (pip install semgrep)")
    except FileNotFoundError:
        logger.info("     Semgrep not installed (pip install semgrep)")
    except Exception as e:
        logger.info(f" Semgrep check failed: {e}")

    # 3. Grype/Syft (external tools)
    logger.info(" 3/3: Grype & Syft...")

    # Grype: version check with minimum version enforcement
    try:
        from reachable.collectors.vulns.grype import VulnDBManager

        mgr = VulnDBManager()
        vc = mgr.check_grype_version()
        if vc["ok"]:
            logger.info(f" {vc['message']}")
        else:
            logger.warning(f"\u26a0\ufe0f  {vc['message']}")
        # Show DB status
        status = mgr.get_status()
        if status["exists"]:
            logger.info(
                f" Grype DB: {status['size_mb']:.1f} MB, "
                f"{'fresh' if not status['is_stale'] else 'stale'} "
                f"({status['age_hours']:.1f}h old)"
            )
        else:
            logger.info(" Grype DB: not downloaded yet")
    except FileNotFoundError:
        logger.info(" grype not installed")
    except Exception as e:
        logger.info(f" grype check failed: {e}")

    # Syft
    try:
        import subprocess

        result = subprocess.run(["syft", "version"], capture_output=True, timeout=5)
        if result.returncode == 0:
            logger.info(" syft available")
        else:
            logger.info(" syft not working properly")
    except FileNotFoundError:
        logger.info(" syft not installed")
    except Exception as e:
        logger.info(f" syft check failed: {e}")
    # CI/CD cache instructions
    cache_base = Path(cache_dir) if cache_dir else Path.home() / ".reachable-cache"
    logger.info(" CI/CD Cache Configuration:")
    logger.info("   GitHub Actions:")
    logger.info("   ```yaml")
    logger.info("   - uses: actions/cache@v3")
    logger.info("     with:")
    logger.info("       path: ~/.reachable-cache")
    logger.info("       key: reachable-cache-${{ runner.os }}-v1")
    logger.info("   ```")
    logger.info("   GitLab CI:")
    logger.info("   ```yaml")
    logger.info("   cache:")
    logger.info("     paths:")
    logger.info("       - ~/.reachable-cache/")
    logger.info("     key: reachable-${CI_COMMIT_REF_SLUG}")
    logger.info("   ```")
    logger.info(f" Cache location: {cache_base}")
    if cache_base.exists():
        size = sum(f.stat().st_size for f in cache_base.rglob("*") if f.is_file())
        logger.info(f" Current size: {format_size(size)}")


def admin_db(args):
    """Manage scan databases and storage (v4.5.40)

    Commands:
        --status      Show database status (default): sizes, WAL, bloat ratio
        --compact     Compact databases: checkpoint WAL + VACUUM INTO if needed
        --checkpoint  Checkpoint WAL only (fast, no vacuum)
        --check       Check database integrity
        --repair      Attempt to repair corrupted database
        --trim        Trim old scans (30 days / 20 per branch)
        --optimize    [DEPRECATED] Use --compact instead

    Options:
        --repo NAME   Target specific repository (fuzzy match)
        --force       Force vacuum even if low bloat
        --dry-run     Preview without making changes
        --verbose     Show detailed information
    """
    from reachable.database.compaction import (
        DatabaseCompactor,
        check_all_databases,
        compact_all_databases,
        format_size,
        get_all_database_stats,
    )
    from reachable.storage.cleanup import trim_storage

    reachable_home = Path.home() / ".reachable"
    scans_dir = reachable_home / "scans"

    verbose = getattr(args, "verbose", False)
    dry_run = getattr(args, "dry_run", False)
    force = getattr(args, "force", False)
    repo_filter = getattr(args, "repo", None)

    # Default to --status if no option specified
    options = ["status", "compact", "checkpoint", "check", "repair", "trim", "optimize"]
    if not any([getattr(args, opt, False) for opt in options]):
        args.status = True

    # Helper to filter repos
    def get_target_repos():
        if not scans_dir.exists():
            return []
        repos = list(scans_dir.glob("*/repo.db"))
        if repo_filter:
            repos = [r for r in repos if repo_filter.lower() in r.parent.name.lower()]
        return sorted(repos)

    # =========================================================================
    # --status: Show database statistics
    # =========================================================================
    if getattr(args, "status", False):
        logger.info("REACHABLE DATABASE STATUS")
        stats = get_all_database_stats(reachable_home)

        if not stats["databases"]:
            logger.info("No databases found.")
            return

        logger.info(f"Total DB size: {stats['total_db_size_human']}")
        logger.info(f"Total WAL size: {stats['total_wal_size_human']}")
        logger.info(f"Total: {stats['total_size_human']}")
        # Filter if requested
        databases = stats["databases"]
        if repo_filter:
            databases = [d for d in databases if repo_filter.lower() in d["repo"].lower()]

        logger.info(f"{'Repository':<40} {'DB':>10} {'WAL':>10} {'Bloat':>8} {'Status':<12}")
        logger.info("-" * 84)

        for db in databases:
            # Determine status
            status_parts = []
            if db.get("needs_checkpoint"):
                status_parts.append("wal!")
            if db.get("needs_vacuum"):
                status_parts.append("bloat!")
            status = ", ".join(status_parts) if status_parts else "healthy"

            indicator = " " if status_parts else "   "
            repo_name = db["repo"][:38]

            logger.info(
                f"{indicator}{repo_name:<37} {db['db_size_human']:>10} {db['wal_size_human']:>10} {db['bloat_percent']:>8} {status:<12}"
            )

        # Show scan counts if verbose
        if verbose:
            logger.info("Scan details:")
            logger.info("-" * 60)

            import sqlite3

            for db in databases:
                repo_db = scans_dir / db["repo"] / "repo.db"
                try:
                    conn = sqlite3.connect(str(repo_db))
                    cursor = conn.cursor()
                    cursor.execute("SELECT COUNT(*) FROM scans WHERE status = 'complete'")
                    scan_count = cursor.fetchone()[0]
                    cursor.execute("SELECT MAX(timestamp) FROM scans")
                    last_scan = cursor.fetchone()[0] or "never"
                    conn.close()

                    logger.info(
                        f" {db['repo']}: {scan_count} scans, last: {last_scan[:16] if last_scan != 'never' else 'never'}"
                    )
                except Exception as e:
                    logger.info(f" {db['repo']}: ERROR - {e}")
        # Show recommendations
        needs_attention = [d for d in databases if d.get("needs_checkpoint") or d.get("needs_vacuum")]
        if needs_attention:
            logger.info(f" {len(needs_attention)} database(s) need attention. Run: reachctl db --compact")

    # =========================================================================
    # --compact: Checkpoint WAL + VACUUM INTO if needed
    # =========================================================================
    elif getattr(args, "compact", False):
        target_repos = get_target_repos()

        if not target_repos:
            logger.info("No databases found.")
            return

        if repo_filter:
            # Compact specific repo(s)
            logger.info(f"{'[DRY RUN] ' if dry_run else ''}Compacting {len(target_repos)} database(s)...")
            for repo_db in target_repos:
                repo_name = repo_db.parent.name
                compactor = DatabaseCompactor(repo_db)
                stats = compactor.get_stats()
                logger.info(f" {repo_name}:")
                logger.info(
                    f" DB: {stats['db_size_human']}, WAL: {stats['wal_size_human']}, Bloat: {stats['bloat_percent']}"
                )

                if dry_run:
                    if stats["needs_checkpoint"] or stats["needs_vacuum"] or force:
                        logger.info(" → Would compact")
                    else:
                        logger.info(" → Would skip (healthy)")
                else:
                    result = compactor.compact(force=force)
                    if result["error"]:
                        logger.info(f" → Error: {result['error']}")
                    else:
                        actions = []
                        if result["checkpointed"]:
                            actions.append("checkpointed")
                        if result["vacuumed"]:
                            actions.append(f"vacuumed ({format_size(result['bytes_freed'])} freed)")
                        elif result["method"] and "skipped" in result["method"]:
                            actions.append(result["method"])
                        logger.info(f" → {', '.join(actions) or 'no action needed'}")
        else:
            # Compact all
            compact_all_databases(reachable_home=reachable_home, force=force, dry_run=dry_run, verbose=True)

    # =========================================================================
    # --checkpoint: Just checkpoint WAL (fast)
    # =========================================================================
    elif getattr(args, "checkpoint", False):
        target_repos = get_target_repos()

        if not target_repos:
            logger.info("No databases found.")
            return
        logger.info(f"{'[DRY RUN] ' if dry_run else ''}Checkpointing WAL...")
        total_wal = 0
        for repo_db in target_repos:
            repo_name = repo_db.parent.name
            compactor = DatabaseCompactor(repo_db)
            stats = compactor.get_stats()

            if stats["wal_size"] == 0:
                if verbose:
                    logger.info(f" {repo_name}: no WAL")
                continue

            total_wal += stats["wal_size"]

            if dry_run:
                logger.info(f" {repo_name}: would checkpoint {stats['wal_size_human']}")
            else:
                try:
                    pages, remaining, blocked = compactor.checkpoint("TRUNCATE")
                    status = "blocked" if blocked else f"done ({pages} pages)"
                    logger.info(f" {repo_name}: {status}")
                except Exception as e:
                    logger.info(f" {repo_name}: ERROR - {e}")
        logger.info(f"Total WAL {'to checkpoint' if dry_run else 'checkpointed'}: {format_size(total_wal)}")

    # =========================================================================
    # --check: Integrity check
    # =========================================================================
    elif getattr(args, "check", False):
        if repo_filter:
            target_repos = get_target_repos()
            if not target_repos:
                logger.info(f"No database found matching '{repo_filter}'")
                return
            logger.info("Database Integrity Check")
            for repo_db in target_repos:
                repo_name = repo_db.parent.name
                compactor = DatabaseCompactor(repo_db)
                is_ok, message = compactor.integrity_check()

                if is_ok:
                    logger.info(f" {repo_name}: OK")
                else:
                    logger.info(f" {repo_name}: {message}")
        else:
            check_all_databases(reachable_home, verbose=True)

    # =========================================================================
    # --repair: Attempt to repair corrupted database
    # =========================================================================
    elif getattr(args, "repair", False):
        target_repos = get_target_repos()

        if not target_repos:
            if repo_filter:
                logger.info(f"No database found matching '{repo_filter}'")
            else:
                logger.info("No databases found. Use --repo to specify which to repair.")
            return

        if len(target_repos) > 1 and not repo_filter:
            logger.info("Multiple databases found. Use --repo to specify which to repair:")
            for repo_db in target_repos:
                logger.info(f" {repo_db.parent.name}")
            return

        repo_db = target_repos[0]
        repo_name = repo_db.parent.name
        logger.info(f"Repairing {repo_name}...")
        if dry_run:
            logger.info("[DRY RUN] Would attempt repair")
            return

        compactor = DatabaseCompactor(repo_db)

        # Check current state
        is_ok, message = compactor.integrity_check()
        if is_ok:
            logger.info(" Database is healthy, no repair needed.")
            return

        logger.info(f" Current state: {message}")
        logger.info(" Attempting repair...")

        success, repair_message = compactor.repair()

        if success:
            logger.info(f" {repair_message}")
        else:
            logger.info(f" {repair_message}")

    # =========================================================================
    # --trim: Trim old scans
    # =========================================================================
    elif getattr(args, "trim", False):
        result = trim_storage(
            reachable_home=reachable_home, retention_days=30, min_scans_keep=5, dry_run=dry_run, verbose=True
        )

        # Also compact after trim
        if not dry_run and result.get("scans_deleted", 0) > 0:
            logger.info("Compacting databases after trim...")
            compact_all_databases(reachable_home=reachable_home, verbose=verbose)

    # =========================================================================
    # --optimize: [DEPRECATED] Use --compact
    # =========================================================================
    elif getattr(args, "optimize", False):
        logger.info("  --optimize is deprecated. Use --compact instead.")
        # Run compact for backwards compatibility
        compact_all_databases(reachable_home=reachable_home, force=force, dry_run=dry_run, verbose=True)


def admin_doctor(args=None):
    """Check system health and dependencies, auto-fix missing tools by default.

    Uses the centralized preflight_check() function.
    """
    from reachable.integrations.preflight import preflight_check

    # Auto-fix by default (use --no-fix to just check)
    fix_mode = not getattr(args, "no_fix", False) if args else True
    # --full: install optional tools (TruffleHog, Joern) without prompting
    full_mode = getattr(args, "full", False) if args else False
    logger.info("REACHABLE SYSTEM CHECK")

    # ── Step 1: System Resources ──────────────────────────────
    logger.info("[1/4] System Resources")
    from reachable.core.sysinfo import detect_resources, format_ollama_status, format_resources

    sysres = detect_resources()
    for line in format_resources(sysres, indent="   ").split("\n"):
        logger.info(line)
    logger.info(format_ollama_status(sysres, indent="   "))

    # ── Step 2: Tools ─────────────────────────────────────────
    logger.info("[2/4] Required Tools")
    # Always run full checks in doctor — this verifies current tool versions,
    # fixes anything missing, and writes a fresh cache for subsequent scans.
    result = preflight_check(fix=fix_mode, quiet=False, verbose=True)
    if not result.ok:
        logger.info(f" {len(result.issues)} issue(s) found:")
        for issue in result.issues:
            logger.info(f" - {issue}")
        sys.exit(1)
    elif result.has_warnings:
        logger.info(" All required tools present (with warnings)")
    else:
        logger.info(" All tools ready")

    # Explicitly report sandbox readiness (colima + docker SDK)
    import platform as _pf
    if _pf.system() == "Darwin":
        _colima = shutil.which("colima")
        if _colima:
            try:
                _cs = subprocess.run(["colima", "status"], capture_output=True, text=True, timeout=5)
                _running = "is running" in _cs.stdout or "is running" in _cs.stderr
            except Exception:
                _running = False
            _colima_str = "running" if _running else "installed (not running)"

            # Check docker SDK in venv
            from reachable.integrations.preflight import VENV_BIN
            _vpy = VENV_BIN / "python3"
            if not _vpy.exists():
                _vpy = VENV_BIN / "python"
            _sdk_ok = False
            try:
                _r = subprocess.run(
                    [str(_vpy), "-c", "import docker; docker.DockerClient"],
                    capture_output=True, timeout=10,
                )
                _sdk_ok = _r.returncode == 0
            except Exception:
                pass

            if _sdk_ok:
                logger.info(f"   Sandbox: colima {_colima_str}, docker SDK ready")
            else:
                logger.info(f"   Sandbox: colima {_colima_str}, docker SDK missing (run: reachctl doctor)")
        else:
            logger.info("   Sandbox: colima not installed (run: reachctl doctor to install)")

    # ── Step 3: Git client ───────────────────────────────────────
    logger.info("[3/4] Git")
    git_path = shutil.which("git")
    if git_path:
        try:
            result = subprocess.run(["git", "--version"], capture_output=True, text=True, timeout=5)
            ver = result.stdout.strip() if result.returncode == 0 else "unknown"
            logger.info(f"   ✓ {ver}")
        except Exception:
            logger.info(f"   ✓ git found at {git_path}")
    else:
        logger.info("   ✗ git not found")
        logger.info("     Install: brew install git  (macOS) | sudo apt install git  (Debian/Ubuntu)")
    logger.info("   Credentials: reachctl auth status")

    # ── Step 4: Optional enhancements ──────────────────────────
    logger.info("[4/5] Optional Enhancements")
    import platform as _platform
    import re as _re

    _is_mac = _platform.system() == "Darwin"

    # ── TruffleHog ─────────────────────────────────────────────
    trufflehog_path = shutil.which("trufflehog")
    if trufflehog_path:
        try:
            th_out = subprocess.run([trufflehog_path, "--version"], capture_output=True, text=True, timeout=10)
            th_ver = ""
            if th_out.returncode == 0:
                m = _re.search(r"(\d+\.\d+\.?\d*)", th_out.stdout.strip() or th_out.stderr.strip())
                th_ver = m.group(1) if m else ""
        except Exception:
            th_ver = ""
        ver_str = f" {th_ver}" if th_ver else ""
        logger.info(f"   trufflehog{ver_str} — active secret verification available")
    else:
        logger.info("   trufflehog — not installed (validates credentials against live APIs)")
        if fix_mode:
            try:
                answer = "y" if full_mode else input("     Install TruffleHog now? [y/N] ").strip().lower()
            except EOFError:
                answer = "n"
            if answer == "y":
                if _is_mac:
                    cmd = ["brew", "install", "trufflehog"]
                else:
                    cmd = [
                        "sh",
                        "-c",
                        "curl -sSfL https://raw.githubusercontent.com/trufflesecurity/trufflehog/main/scripts/install.sh | sh -s -- -b /usr/local/bin",
                    ]
                logger.info("     Installing TruffleHog...")
                r = subprocess.run(cmd, timeout=180)
                if r.returncode == 0:
                    logger.info("     TruffleHog installed")
                else:
                    logger.info("     TruffleHog installation failed — install manually:")
                    if _is_mac:
                        logger.info("       brew install trufflehog")
                    else:
                        logger.info("       https://github.com/trufflesecurity/trufflehog/releases")
            else:
                if _is_mac:
                    logger.info("     Install later: brew install trufflehog")
                else:
                    logger.info("     Install later: https://github.com/trufflesecurity/trufflehog/releases")
        else:
            if _is_mac:
                logger.info("     Install: brew install trufflehog")
            else:
                logger.info("     Install: https://github.com/trufflesecurity/trufflehog/releases")

    # ── Joern ──────────────────────────────────────────────────
    # Detect Java version
    _java_bin = shutil.which("java")
    _java_ver = None
    if _java_bin:
        try:
            _jv = subprocess.run([_java_bin, "-version"], capture_output=True, text=True, timeout=5)
            _jout = _jv.stderr + _jv.stdout
            m = _re.search(r'version "(\d+)', _jout)
            if m:
                _java_ver = int(m.group(1))
        except Exception:
            pass

    _tools_bin = Path.home() / ".reachable" / "tools" / "bin"
    joern_path = shutil.which("joern") or (str(_tools_bin / "joern") if (_tools_bin / "joern").exists() else None)
    if joern_path:
        try:
            from reachable.collectors.callgraph.js_collector import _get_joern_version

            j_ver_tuple = _get_joern_version(Path(joern_path))
            j_ver = ".".join(str(v) for v in j_ver_tuple) if j_ver_tuple else ""
        except Exception:
            j_ver = ""
        ver_str = f" {j_ver}" if j_ver else ""
        java_str = f" (Java {_java_ver})" if _java_ver else " (Java not detected)"
        if _java_ver and _java_ver < 17:
            logger.info(f"   joern{ver_str} — WARNING: Java {_java_ver} detected, Joern requires Java 17+")
            logger.info(
                "     Upgrade: brew install openjdk@17" if _is_mac else "     Upgrade: sudo apt install openjdk-17-jdk"
            )
        else:
            logger.info(f"   joern{ver_str}{java_str}")
    else:
        java_status = f"Java {_java_ver}" if _java_ver else "Java not found"
        java_ok = _java_ver is not None and _java_ver >= 17
        logger.info(f"   joern — not installed | {java_status}{'  ✔' if java_ok else ' (17+ required)'}")
        logger.info("     Without Joern: ts-morph import tracing runs as fallback (file-level only)")
        if fix_mode:
            has_java = java_ok
            if not has_java:
                logger.info("     Joern requires Java 17+ — not detected on this system")
                if _is_mac:
                    logger.info("     Install Java first: brew install openjdk@17")
                else:
                    logger.info("     Install Java first: sudo apt install openjdk-17-jdk  (Debian/Ubuntu)")
                    logger.info("                         sudo dnf install java-17-openjdk  (RHEL/Fedora)")
            else:
                try:
                    answer = (
                        "y"
                        if full_mode
                        else input("     Install Joern now? (~300MB, requires Java 17+) [y/N] ").strip().lower()
                    )
                except EOFError:
                    answer = "n"
                if answer == "y":
                    if _is_mac:
                        logger.info("     Installing Joern via Homebrew...")
                        r = subprocess.run(["brew", "install", "joern"], timeout=600)
                        if r.returncode == 0:
                            logger.info("     Joern installed")
                        else:
                            logger.info("     Homebrew install failed — trying managed install...")
                            from reachable.collectors.callgraph.js_collector import install_joern

                            if install_joern(verbose=True):
                                logger.info("     Joern installed")
                            else:
                                logger.info("     Joern installation failed")
                                logger.info("     Manual: brew install joern")
                    else:
                        logger.info("     Installing Joern (Linux)...")
                        r = subprocess.run(
                            [
                                "sh",
                                "-c",
                                "curl -sSfL https://github.com/joernio/joern/releases/latest/download/joern-install.sh | sudo bash",
                            ],
                            timeout=600,
                        )
                        if r.returncode == 0:
                            logger.info("     Joern installed")
                        else:
                            logger.info("     Joern installation failed")
                            logger.info("     Manual: https://docs.joern.io/installation")
                else:
                    if _is_mac:
                        logger.info("     Install later: brew install joern")
                    else:
                        logger.info("     Install later: https://docs.joern.io/installation")
        else:
            if _is_mac:
                logger.info("     Install: brew install joern  (requires Java 17+)")
            else:
                logger.info("     Install: https://docs.joern.io/installation  (requires Java 17+)")

    # ── Ollama (for enzo AI remediation) ─────────────────────────
    def _ollama_start_hint():
        """Platform-specific Ollama start instructions."""
        if _is_mac:
            logger.info("     Start as service: brew services start ollama")
            logger.info("       (auto-starts on boot, restarts on crash)")
        else:
            logger.info("     Start as service: sudo systemctl start ollama")
            logger.info("       Enable on boot: sudo systemctl enable ollama")

    if sysres.ollama_installed:
        if sysres.ollama_running:
            model_count = len(sysres.ollama_models)
            models_str = f" ({model_count} model{'s' if model_count != 1 else ''})"
            logger.info(f"   ollama — running{models_str}")
            if sysres.ollama_models:
                for m in sysres.ollama_models[:5]:
                    logger.info(f"     {m}")
        else:
            logger.info("   ollama — installed (not running)")
            if fix_mode:
                try:
                    answer = "y" if full_mode else input("     Start Ollama now? [y/N] ").strip().lower()
                except EOFError:
                    answer = "n"
                if answer == "y":
                    try:
                        subprocess.Popen(
                            ["ollama", "serve"],
                            stdout=subprocess.DEVNULL,
                            stderr=subprocess.DEVNULL,
                            start_new_session=True,
                        )
                        logger.info("     \u2713 Ollama started (background)")
                        logger.info("     For persistent service:")
                        _ollama_start_hint()
                        logger.info("     Run: reachctl enzo setup")
                    except Exception as e:
                        logger.info(f"     Failed to start: {e}")
                        _ollama_start_hint()
                else:
                    _ollama_start_hint()
            else:
                _ollama_start_hint()
    else:
        logger.info("   ollama — not installed (local AI remediation engine)")
        if fix_mode:
            _has_brew = shutil.which("brew") is not None
            if _is_mac and _has_brew:
                try:
                    answer = (
                        "y" if full_mode else input("     Install Ollama now? (via Homebrew) [y/N] ").strip().lower()
                    )
                except EOFError:
                    answer = "n"
                if answer == "y":
                    logger.info("     Installing Ollama via Homebrew (this may take a minute)...")
                    env = os.environ.copy()
                    env["HOMEBREW_NO_AUTO_UPDATE"] = "1"
                    r = subprocess.run(
                        ["brew", "install", "ollama"],
                        env=env,
                        timeout=300,
                    )
                    if r.returncode == 0:
                        logger.info("     \u2713 Ollama installed")
                        try:
                            subprocess.Popen(
                                ["ollama", "serve"],
                                stdout=subprocess.DEVNULL,
                                stderr=subprocess.DEVNULL,
                                start_new_session=True,
                            )
                            logger.info("     \u2713 Ollama started (background)")
                        except Exception:
                            pass
                        logger.info("     For persistent service: brew services start ollama")
                        logger.info("     Then: reachctl enzo setup")
                    else:
                        logger.info("     Homebrew install failed")
                        logger.info("     Install manually: https://ollama.com/download")
                else:
                    logger.info("     Install later: brew install ollama")
            else:
                if _is_mac:
                    logger.info("     Install: https://ollama.com/download")
                else:
                    logger.info("     Install: curl -fsSL https://ollama.com/install.sh | sh")
                    logger.info("       (installs as systemd service, starts automatically)")
                logger.info("     Then: reachctl enzo setup")

    # ── Credential check — presence + live API validation ────────────
    logger.info("[5/5] Credentials")
    try:
        from reachable.core.credentials import (
            test_anthropic_api,
            test_github_api,
            test_github_mcp,
            test_groq_api,
            test_ssh_github,
        )

        _issues = []

        # GitHub
        _gh = test_github_api()
        _ssh_ok = False
        if _gh["ok"]:
            _u = f"@{_gh['user']} " if _gh.get("user") else ""
            logger.info(f"   {'GitHub Token':<22} \u2713 {_u}valid ({_gh['source']})")
        elif _gh["error"] == "no-token":
            _ssh_ok = test_ssh_github()
            if _ssh_ok:
                logger.info(f"   {'GitHub Token':<22} \u25cb SSH works, no API token")
            else:
                logger.info(f"   {'GitHub Token':<22} \u2717 not configured")
                _issues.append("GitHub Token not configured")
        elif _gh["error"] == "invalid-or-expired":
            logger.info(f"   {'GitHub Token':<22} \u2717 INVALID or EXPIRED")
            _issues.append("GitHub Token expired")
        else:
            logger.info(f"   {'GitHub Token':<22} \u2717 {_gh['error']}")

        # GitHub MCP (optional)
        _mcp = test_github_mcp()
        if _mcp["ok"]:
            logger.info(f"   {'GitHub MCP Token':<22} \u2713 valid ({_mcp['source']})")
        elif _mcp["error"] == "invalid-or-expired":
            logger.info(f"   {'GitHub MCP Token':<22} \u2717 INVALID or EXPIRED")
            _issues.append("GitHub MCP Token expired")

        # Anthropic (optional)
        _ant = test_anthropic_api()
        if _ant["ok"]:
            logger.info(f"   {'Anthropic API Key':<22} \u2713 valid ({_ant['source']})")
        elif _ant["error"] == "no-key":
            logger.info(f"   {'Anthropic API Key':<22} \u2014 not configured (optional)")
        elif _ant["error"] == "invalid-or-expired":
            logger.info(f"   {'Anthropic API Key':<22} \u2717 INVALID or EXPIRED")
            _issues.append("Anthropic API Key expired")
        else:
            logger.info(f"   {'Anthropic API Key':<22} \u2717 {_ant['error']}")

        # Groq (optional)
        _groq = test_groq_api()
        if _groq["ok"]:
            logger.info(f"   {'Groq API Key':<22} \u2713 valid ({_groq['source']})")
        elif _groq["error"] == "no-key":
            logger.info(f"   {'Groq API Key':<22} \u2014 not configured (optional)")
        elif _groq["error"] == "invalid-or-expired":
            logger.info(f"   {'Groq API Key':<22} \u2717 INVALID or EXPIRED")
            _issues.append("Groq API Key expired")
        else:
            logger.info(f"   {'Groq API Key':<22} \u2717 {_groq['error']}")

        # Summary
        if _issues:
            logger.info("")
            for _i in _issues:
                logger.info(f"   \u26a0 {_i}")
            logger.info("   \u2192 Fix: reachctl auth login")
        elif not _gh["ok"] and not _ssh_ok:
            logger.info("   \u2192 reachctl auth login  (to add GitHub token)")

    except Exception as _ce:
        logger.debug("Credential check failed: %s", _ce)
        logger.info("   (credential check unavailable)")

    # ── Enzo build tools ──────────────────────────────────────────────────────────
    try:
        from enzo.setup import check_build_tools
        _tools = check_build_tools()
        _missing = [t for t in _tools if not t[1]]
        if _missing:
            logger.info("[6/6] Enzo build tools")
            for _binary, _installed, _brew_f, _apt_pkg, _desc in _tools:
                _s = "✓" if _installed else "✗"
                logger.info(f"   {_binary:<12}      {_s}  {_desc}")
            logger.info(f"   {len(_missing)} missing — run: reachctl enzo doctor --fix")
        else:
            logger.info("[6/6] Enzo build tools  ✓ all present")
    except ImportError:
        pass  # enzo not installed, skip silently

    logger.info(" Doctor complete")
