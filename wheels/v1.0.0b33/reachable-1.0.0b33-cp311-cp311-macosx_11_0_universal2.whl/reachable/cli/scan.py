#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.
"""CLI scan operations: reachability analysis, database storage."""

import json
import os
import sys
from datetime import datetime
from pathlib import Path
from typing import List, Optional

from reachable import __version__

# Cross-module imports
from reachable.cli.utils import run_command
from reachable.core.logger import OutputMode, get_logger

# Central logger — all output goes through here, never through stdlib logging
_log = get_logger()


def generate_sbom(repo_path: Path, output_dir: Path, verbose: bool = False) -> Path:
    """Generate SBOM using Syft (reuses existing logic)"""
    from reachable.collectors.vulns.grype import get_syft_path

    if verbose:
        _log.debug("[1/5] Generating SBOM...")
    sbom_file = output_dir / "sbom.json"

    # Use local syft from ~/.reachable/tools/bin/ if available
    syft_path = get_syft_path()

    result = run_command(
        [str(syft_path), "scan", f"dir:{repo_path}", "-o", "json", "-q"], "SBOM generation", capture=True
    )

    try:
        from reachable.core.compression import save_json

        sbom_data = json.loads(result)
        actual_file = save_json(sbom_data, sbom_file, compress=True)
        if verbose:
            _log.debug(f" SBOM saved to {actual_file.name} (compressed)")
        return actual_file
    except ImportError:
        # Fallback to uncompressed
        sbom_file.write_text(result)
        if verbose:
            _log.debug(f" SBOM saved to {sbom_file}")
        return sbom_file


def enrich_sbom_purls(sbom_file: Path, verbose: bool = False) -> tuple:
    """Enrich SBOM with canonical PURLs for private registry packages.

    Runs PURLResolver between Syft and Grype to rewrite private-registry
    PURLs (renamed mirrors, scoped wrappers) to their canonical upstream
    identities using hash-based verification.

    Returns:
        (enriched_sbom_path, resolution_map, coverage_stats)
        - enriched_sbom_path: Path to enriched SBOM (or original if no changes)
        - resolution_map: dict mapping (ecosystem, private_name) → canonical info
        - coverage_stats: dict with resolution counts
    """
    try:
        from reachable.collectors.vulns.purl_resolver import PURLResolver
    except ImportError:
        if verbose:
            _log.debug("  PURLResolver not available, skipping SBOM enrichment")
        return sbom_file, {}, {}

    resolver = PURLResolver()
    try:
        enriched_path = resolver.enrich_sbom(sbom_file)
        resolution_map = resolver.get_resolution_map(enriched_path)

        # Read coverage stats from the enriched SBOM
        coverage = {}
        if enriched_path != sbom_file:
            import json as _json

            data = _json.loads(enriched_path.read_text())
            coverage = data.get("_reachable_registry_coverage", {})

        if verbose:
            resolved = len(resolution_map)
            if resolved > 0:
                _log.debug(f"  PURL enrichment: {resolved} private package(s) resolved to canonical upstream")
                for (eco, orig_name), info in resolution_map.items():
                    _log.debug(f"    {orig_name} → {info['canonical_name']} ({info['method']})")
            else:
                total = coverage.get("total_packages", 0)
                _log.debug(f"  PURL enrichment: {total} packages all canonical, no rewrites needed")

        return enriched_path, resolution_map, coverage

    except Exception as e:
        if verbose:
            _log.debug(f"  PURLResolver failed: {e} — using original SBOM")
        return sbom_file, {}, {}


def scan_vulnerabilities(sbom_file: Path, output_dir: Path, verbose: bool = False) -> Path:
    """Scan for vulnerabilities using Grype with cached DB.

    Uses local grype from ~/.reachable/tools/bin/ and cached vulnerability
    database from ~/.reachable/cache/grype-db/. Auto-refreshes DB if > 24h old.
    """
    from reachable.collectors.vulns.grype import VulnDBManager, get_grype_path

    if verbose:
        _log.debug("[2/5] Scanning for vulnerabilities...")
    vulns_file = output_dir / "vulns.json"

    # Ensure vulnerability DB is fresh (auto-refresh if > 24h old)
    db_mgr = VulnDBManager()
    db_mgr.ensure_fresh(verbose=verbose)

    # Use local grype from ~/.reachable/tools/bin/ if available
    grype_path = get_grype_path()

    actual_sbom_file = sbom_file
    temp_sbom = None

    if str(sbom_file).endswith(".gz"):
        import gzip

        # Decompress to temp file for Grype
        temp_sbom = output_dir / "sbom_temp.json"
        with gzip.open(sbom_file, "rt") as f_in:
            temp_sbom.write_text(f_in.read())
        actual_sbom_file = temp_sbom

    try:
        # Run grype with cached DB location
        result = run_command(
            [str(grype_path), f"sbom:{actual_sbom_file}", "-o", "json", "-q"],
            "vulnerability scanning",
            capture=True,
            env=db_mgr.get_grype_env(),
        )

        vulns_file.write_text(result)

        # Count vulnerabilities
        vulns_data = json.loads(result)
        vuln_count = len(vulns_data.get("matches", []))

        if verbose:
            _log.debug(f" Found {vuln_count} vulnerabilities (Syft SBOM + Grype scanner)")
            _log.debug(f" Results saved to {vulns_file}")

        return vulns_file
    finally:
        # Clean up temp file
        if temp_sbom and temp_sbom.exists():
            temp_sbom.unlink()


def clone_vulnerable_libs(
    vulns_file: Path, libs_dir: Path, scan_ctx=None, purl_resolutions: dict = None, verbose: bool = False
) -> tuple:
    """Clone vulnerable libraries using smart lib manager.

    Args:
        purl_resolutions: Optional dict from PURLResolver mapping
            (ecosystem, private_name) → {canonical_name, canonical_version, ...}
            Used to fetch canonical upstream source for resolved private packages.
    """
    if verbose:
        _log.debug("[3/5] Cloning vulnerable library source code...")

    from reachable.integrations.lib_manager import LibraryManager

    with open(vulns_file) as f:
        vulns_data = json.load(f)

    # Pass scan context and PURL resolutions to library manager
    manager = LibraryManager(libs_dir, scan_context=scan_ctx, purl_resolutions=purl_resolutions or {})
    cloned_paths = manager.clone_vulnerable_libraries(vulns_data)

    # Capture library manager metrics (includes obsolete packages)
    lib_metrics = manager.metrics

    # IMPORTANT: Return libs_dir even if nothing was freshly cloned
    # (libraries may already exist from previous runs)
    if libs_dir.exists() and any(libs_dir.iterdir()):
        return libs_dir, lib_metrics
    elif cloned_paths:
        return libs_dir, lib_metrics
    else:
        if verbose:
            _log.debug("     No vulnerable libraries found or cloning failed")
        return None, lib_metrics


def run_reachability_analysis(
    repo_path: Path,
    sbom_file: Path,
    vulns_file: Path,
    libs_dir: Optional[Path],
    output_dir: Path,
    enable_dynamic_malware: bool = True,
    debug: bool = False,
    progress_callback=None,
    ai_findings: List = None,  # v4.5.18: AI/LLM security findings
    ai_scan_time: float = 0.0,  # v4.5.39: AI scan timing for step breakdown
    dlp_scan_time: float = 0.0,  # v4.5.50: DLP scan timing for step breakdown
    sandbox_cache_ttl: int = 24,  # v4.6.10: Sandbox cache TTL in hours (0 = disable)
    force_rebuild: bool = False,  # v4.6.10: Force skip all caches including sandbox
    ci_mode: bool = False,        # v5.1.4: passed through to ScanConfig (CI detection)
    fail_on: str = "none",        # v5.1.4: passed through to ScanConfig (fail_on escalation)
):
    """Run reachability analysis (reuses existing reachable.py)

    Args:
        ai_findings: AI/LLM security findings (OWASP LLM Top 10)
        ai_scan_time: Time spent on AI scanning (for step breakdown)
        dlp_scan_time: Time spent on DLP scanning (for step breakdown)

    Note: OWASP Top 10 (Web) data is derived from CWE findings automatically.
    """
    # Import existing analyzer
    from reachable.engine.reachability import ReachabilityAnalyzer

    # Create and run analyzer
    analyzer = ReachabilityAnalyzer(
        app_dir=repo_path,
        libs_dir=libs_dir,
        sbom_file=sbom_file,
        vulns_file=vulns_file,
        verbose=False,  # Correlation engine verbose output disabled
        progress_callback=progress_callback,
        ai_findings=ai_findings,  # v4.5.18: AI/LLM security findings
        ai_scan_time=ai_scan_time,  # v4.5.39: AI scan timing
        dlp_scan_time=dlp_scan_time,  # v4.5.50: DLP scan timing
    )

    results = analyzer.analyze()

    # T-AI1: AI reachability integration bridge
    # integrate_ai_reachability enriches AI findings with call graph data.
    # reachable_functions extracted from call_graph for function-level lookup.
    if ai_findings and "call_graph" in results:
        try:
            from reachable.ai.ai_reachability_integration import integrate_ai_reachability
            _cg = results["call_graph"]
            reachable_functions = set(_cg.get("reachable_functions", []))
            enriched, _ai_summary = integrate_ai_reachability(
                findings=ai_findings,
                call_graph=_cg.get("adjacency", {}),
                reachable_functions=reachable_functions,
                entrypoints=set(_cg.get("entrypoints", [])),
                repo_path=repo_path,
            )
            results["_ai_enrichment_summary"] = _ai_summary
        except Exception as e:
            _log.warning(f"AI reachability integration failed: {e}")

    # Run dynamic malware sandbox analysis if enabled
    # Note: Static malware analysis (GuardDog) always runs as part of reachability analysis
    sandbox_results = None
    if sandbox_results:
        results["dynamic_malware"] = sandbox_results
        # Also add to security_scans for dashboard compatibility
        if "security_scans" not in results:
            results["security_scans"] = {}
        results["security_scans"]["dynamic_malware"] = sandbox_results

    # Save results
    _log.debug("[5/5] Saving results...")

    # Helper to add timestamp to any dict
    def add_timestamp(data: dict) -> dict:
        """Add scan timestamp to JSON output"""
        data["_metadata"] = {
            "generated_at": datetime.now().isoformat() + "Z",
            "reachable_version": results.get("reachable_version", __version__),
            "schema": "REACHABLE",
        }
        return data

    # v5.1.3: reachable-report.json REMOVED — DB is single source of truth
    # Dashboard reads from repo.db; raw files kept for audit/debug.
    # Use 'reachctl export' to generate JSON/CSV from DB on demand.
    _log.debug(" Core files: sbom.json, vulns.json (created earlier)")

    # raw/ directory needed for scan-manifest.json and ingester source files
    raw_dir = output_dir / "raw"
    raw_dir.mkdir(exist_ok=True)

    # Generate scan manifest for CI/CD coordination
    scan_id = results.get("metadata", {}).get(
        "scan_id", results.get("metadata", {}).get("scan_timing", {}).get("start_timestamp", "unknown")
    )
    git_info = results.get("metadata", {}).get("git_info")
    scan_manifest = {
        "schema_version": "3.0",
        "scan_id": scan_id,
        "generated_at": results.get("metadata", {}).get("generated_at", ""),
        "generator_version": results.get("reachable_version", "unknown"),
        "target": {
            "path": str(results.get("metadata", {}).get("analysis_target", {}).get("app_directory", "")),
            "git_commit": git_info.get("commit_sha") if git_info else None,
            "git_branch": git_info.get("branch") if git_info else None,
        },
        "components": {},
        "outputs": {
            "dashboard": "dashboard/index.html",
            "dashboard_data": "dashboard/data.json",
            "database": "repo.db",
        },
    }

    # 2. Save detailed data files to raw/ subfolder
    _log.debug(" Saving detailed data files to raw/...")

    # CVEs - detailed findings with remediation
    if "reachable" in results or "unreachable" in results:
        # v5.1.3: Write CVE data to raw/ for ingester (replaces reachable-report.json)
        cve_raw_file = raw_dir / "cve-analyzed.json"
        cve_raw_data = {
            "reachable": results.get("reachable", {}),
            "unreachable": results.get("unreachable", {}),
        }
        with open(cve_raw_file, "w") as f:
            json.dump(cve_raw_data, f, indent=2)
        total_cves = len(cve_raw_data["reachable"]) + len(cve_raw_data["unreachable"])
        _log.debug(f" raw/cve-analyzed.json ({total_cves} CVEs)")
        scan_manifest["components"]["cves"] = {"status": "complete", "file": "raw/cve-analyzed.json"}

    # Secrets - with locations and reachability
    if "security_scans" in results and "secrets" in results["security_scans"]:
        secrets_data = results["security_scans"]["secrets"]
        if secrets_data:
            secrets_data = add_timestamp(secrets_data if isinstance(secrets_data, dict) else {"findings": secrets_data})
            security_file = raw_dir / "security-findings.json"
            with open(security_file, "w") as f:
                json.dump(secrets_data, f, indent=2)
            total_secrets = secrets_data.get("total_findings", 0)
            _log.debug(f" raw/security-findings.json ({total_secrets} secrets)")
            scan_manifest["components"]["secrets"] = {
                "status": "complete",
                "file": "raw/security-findings.json",
            }

    # Malware - tier 1/2/3 detections
    if "malware_detection" in results and results["malware_detection"]:
        malware_data = add_timestamp(results["malware_detection"])
        malware_file = raw_dir / "malware.json"
        with open(malware_file, "w") as f:
            json.dump(malware_data, f, indent=2)
        malicious = malware_data.get("malicious_packages", 0)
        if isinstance(malicious, list):
            malicious = len(malicious)
        _log.debug(f" raw/malware.json ({malicious} malicious packages)")
        scan_manifest["components"]["malware"] = {"status": "complete", "file": "raw/malware.json"}

    # Sandbox - behavioral analysis findings
    sandbox_data = None
    if "dynamic_malware" in results and results["dynamic_malware"]:
        sandbox_data = results["dynamic_malware"]
    elif "security_scans" in results and "dynamic_malware" in results["security_scans"]:
        sandbox_data = results["security_scans"]["dynamic_malware"]
    # Legacy key fallback
    elif "sandbox" in results and results["sandbox"]:
        sandbox_data = results["sandbox"]
    elif "security_scans" in results and "sandbox" in results["security_scans"]:
        sandbox_data = results["security_scans"]["sandbox"]

    if sandbox_data:
        sandbox_data = add_timestamp(sandbox_data if isinstance(sandbox_data, dict) else {"findings": sandbox_data})
        sandbox_file = raw_dir / "sandbox.json"
        with open(sandbox_file, "w") as f:
            json.dump(sandbox_data, f, indent=2)
        verdict = sandbox_data.get("verdict", "N/A")
        findings = sandbox_data.get("findings", [])
        if not isinstance(findings, list):
            findings = []
        findings_count = len(findings)
        critical_count = sum(1 for f in findings if isinstance(f, dict) and f.get("severity") == "CRITICAL")
        _log.debug(f" raw/sandbox.json (verdict: {verdict}, {findings_count} issues, {critical_count} critical)")
        scan_manifest["components"]["sandbox"] = {"status": "complete", "file": "raw/sandbox.json"}

    # Package Health - unmaintained/risky packages
    if "tool_execution_log" in results and "package_health_analyzer" in results["tool_execution_log"]:
        health_log = results["tool_execution_log"]["package_health_analyzer"]
        if health_log.get("executed"):
            health_data = add_timestamp(
                {
                    "summary": {
                        "total_packages": health_log["metrics"]["packages_analyzed"],
                        "health_distribution": health_log["metrics"]["health_distribution"],
                        "unmaintained": health_log["metrics"]["health_distribution"].get("CRITICAL", 0),
                        "risky": health_log["metrics"]["health_distribution"].get("MEDIUM", 0),
                    },
                    "findings": results.get("findings", {}).get("package_health_issues", []),
                }
            )
            health_file = raw_dir / "health.json"
            with open(health_file, "w") as f:
                json.dump(health_data, f, indent=2)
            _log.debug(f" raw/health.json ({health_data['summary']['total_packages']} packages)")
            scan_manifest["components"]["health"] = {"status": "complete", "file": "raw/health.json"}

    # Correlation - threat correlations (large file, use compression)
    if "correlation" in results and results["correlation"]:
        correlation_data = add_timestamp(results["correlation"])
        correlation_file = raw_dir / "correlation.json"
        try:
            from reachable.core.compression import save_json as save_json_compressed

            actual_file = save_json_compressed(correlation_data, correlation_file, compress=True)
            total_threats = correlation_data.get("summary", {}).get("total_composite_threats", 0)
            _log.debug(f" raw/{actual_file.name} ({total_threats} composite threats)")
            scan_manifest["components"]["correlation"] = {
                "status": "complete",
                "file": f"raw/{actual_file.name}",
            }
        except ImportError:
            with open(correlation_file, "w") as f:
                json.dump(correlation_data, f, indent=2)
            total_threats = correlation_data.get("summary", {}).get("total_composite_threats", 0)
            _log.debug(f" raw/correlation.json ({total_threats} composite threats)")
            scan_manifest["components"]["correlation"] = {
                "status": "complete",
                "file": "raw/correlation.json",
            }

    # Attack Surface - phantom deps, shadow imports
    if "findings" in results and "attack_surface" in results["findings"]:
        attack_surface_data = add_timestamp(results["findings"]["attack_surface"])
        attack_surface_file = raw_dir / "attack_surface.json"
        with open(attack_surface_file, "w") as f:
            json.dump(attack_surface_data, f, indent=2)
        phantom = attack_surface_data.get("phantom_dependencies", {}).get("count", 0)
        _log.debug(f" raw/attack_surface.json ({phantom} phantom dependencies)")
        scan_manifest["components"]["attack_surface"] = {
            "status": "complete",
            "file": "raw/attack_surface.json",
        }

    # Call graphs (keep in output_dir for easy access, also copy to raw/)
    if "call_graph_exports" in results:
        for format_name, content in results["call_graph_exports"].items():
            graph_file = output_dir / f"call-graph.{format_name}"
            with open(graph_file, "w") as f:
                f.write(content)
            # Also save to raw/
            raw_graph_file = raw_dir / f"call-graph.{format_name}"
            with open(raw_graph_file, "w") as f:
                f.write(content)
        _log.debug(" call-graph.json (+ raw/)")
        scan_manifest["components"]["call_graph"] = {"status": "complete", "file": "raw/call-graph.json"}

    # Save scan manifest
    manifest_file = raw_dir / "scan-manifest.json"
    with open(manifest_file, "w") as f:
        json.dump(scan_manifest, f, indent=2)
    _log.debug(" raw/scan-manifest.json (CI/CD coordination)")

    # Populate database with all findings (after raw files exist)
    # v4.5.8: Store to repo.db (per-repo database with history)
    # v4.5.10: Extract and pass risk data to DB storage
    overall_risk = results.get("summary", {}).get("overall_risk", {})
    db_risk_score = overall_risk.get("risk_score", 0)
    db_risk_level = overall_risk.get("risk_level", None)

    # v4.6.10: Convert sandbox findings to DB format for malware storage
    sandbox_findings_for_db = []
    sandbox_data_for_db = results.get("dynamic_malware") or results.get("security_scans", {}).get("dynamic_malware", {})
    if sandbox_data_for_db and sandbox_data_for_db.get("findings"):
        import hashlib

        for f in sandbox_data_for_db["findings"]:
            sev = f.get("severity", "MEDIUM")
            if sev not in ("CRITICAL", "HIGH", "MEDIUM", "LOW", "INFO"):
                sev = "MEDIUM"
            pkg = f.get("package", "unknown")
            rule = f.get("rule", "sandbox_finding")
            desc = f.get("description", "")
            evidence = f.get("evidence", "")
            # Generate stable finding_id from rule + package + description
            fid = hashlib.sha256(f"{rule}:{pkg}:{desc}".encode()).hexdigest()[:16]
            # v4.6.10: CRITICAL=malware (confirmed), else=suspicious (review)
            db_type = "malware" if sev == "CRITICAL" else "suspicious"
            sandbox_findings_for_db.append(
                {
                    "id": f"SANDBOX-{fid}",
                    "finding_type": db_type,
                    "severity": sev,
                    "risk_level": sev,  # Runtime-observed = severity is risk
                    "title": desc[:500] if desc else f"Sandbox: {rule}",
                    "description": f"Rule: {rule}. Evidence: {evidence}"[:1000],
                    "package": pkg,
                    "scanner": "sandbox",
                    "app_reachability": "REACHABLE",  # Observed at runtime
                    "reachability_confidence": "HIGH",
                    "phase": f.get("phase", "install"),
                    "local_package": f.get("local_package", False),
                }
            )

    # v5.0.1: Extract static malware findings (Semgrep + YARA) from analysis results
    static_malware_for_db = results.get("static_malware_findings", [])

    # P2.60 FIX (P0 #1): Fallback — if static_malware_findings not populated by engine,
    # extract from malware_detection results (GuardDog/YARA raw output)
    # This ensures YARA file-level findings and GuardDog package findings reach the DB
    if not static_malware_for_db:
        import hashlib as _hashlib

        malware_raw = results.get("malware_detection", {})
        if malware_raw:
            # Extract package-level findings (GuardDog format: packages dict)
            packages = malware_raw.get("packages", malware_raw.get("malicious_packages", {}))
            if isinstance(packages, dict):
                for pkg_name, pkg_data in packages.items():
                    if not isinstance(pkg_data, dict):
                        continue
                    for finding in pkg_data.get("findings", []):
                        sev = (finding.get("severity") or "HIGH").upper()
                        rule = finding.get("rule", finding.get("code", "guarddog_finding"))
                        msg = finding.get("message", finding.get("description", f"Malware pattern: {rule}"))
                        fid = _hashlib.sha256(f"{rule}:{pkg_name}:{msg}".encode()).hexdigest()[:16]
                        db_type = "malware" if sev in ("CRITICAL", "HIGH") else "suspicious"
                        # P2.60 FIX: Static malware reachability depends on context:
                        # - Install hooks (setup.py, postinstall) → REACHABLE (execute at install time)
                        # - Import-time code (__init__.py) → depends on import analysis
                        # - Function-level code → depends on call graph
                        # Default to UNKNOWN; reachability engine determines actual state
                        fpath_lower = (finding.get("file", finding.get("file_path", "")) or "").lower()
                        is_install_hook = any(
                            h in fpath_lower
                            for h in (
                                "setup.py",
                                "setup.cfg",
                                "postinstall",
                                "preinstall",
                                "install.js",
                                ".github/workflows",
                                "Makefile",
                            )
                        )
                        static_malware_for_db.append(
                            {
                                "id": f"STATIC-{fid}",
                                "finding_type": db_type,
                                "severity": sev,
                                "risk_level": sev,
                                "title": msg[:500],
                                "description": f"Rule: {rule}. Package: {pkg_name}"[:1000],
                                "package": pkg_name,
                                "version": pkg_data.get("version", ""),
                                "scanner": finding.get("scanner", "guarddog"),
                                "file": finding.get("file", finding.get("file_path", "")),
                                "line": finding.get("line", finding.get("line_number", 0)),
                                "app_reachability": "REACHABLE" if is_install_hook else "UNKNOWN",
                                "reachability_confidence": "HIGH" if is_install_hook else "LOW",
                            }
                        )
            # Extract file-level findings (YARA format: file_findings list)
            file_findings = malware_raw.get("file_findings", malware_raw.get("yara_findings", []))
            if isinstance(file_findings, list):
                for finding in file_findings:
                    if not isinstance(finding, dict):
                        continue
                    sev = (finding.get("severity") or "HIGH").upper()
                    rule = finding.get("rule", finding.get("signature", "yara_finding"))
                    fpath = finding.get("file", finding.get("file_path", finding.get("filepath", "")))
                    msg = finding.get("description", finding.get("message", f"YARA match: {rule}"))
                    fid = _hashlib.sha256(f"{rule}:{fpath}:{msg}".encode()).hexdigest()[:16]
                    db_type = "malware" if sev in ("CRITICAL", "HIGH") else "suspicious"
                    # Derive package from file path (parent directory)
                    pkg = ""
                    if fpath and "/" in fpath:
                        pkg = fpath.rsplit("/", 2)[-2] if fpath.count("/") >= 2 else fpath.rsplit("/", 1)[0]
                    # P2.60 FIX: YARA file-level reachability — same logic as GuardDog
                    fpath_lower = (fpath or "").lower()
                    is_install_hook = any(
                        h in fpath_lower
                        for h in (
                            "setup.py",
                            "setup.cfg",
                            "postinstall",
                            "preinstall",
                            "install.js",
                            ".github/workflows",
                            "Makefile",
                        )
                    )
                    static_malware_for_db.append(
                        {
                            "id": f"YARA-{fid}",
                            "finding_type": db_type,
                            "severity": sev,
                            "risk_level": sev,
                            "title": msg[:500],
                            "description": f"Rule: {rule}. File: {fpath}"[:1000],
                            "package": pkg,
                            "scanner": "yara",
                            "file": fpath,
                            "line": finding.get("line", 0),
                            "app_reachability": "REACHABLE" if is_install_hook else "UNKNOWN",
                            "reachability_confidence": "HIGH" if is_install_hook else "LOW",
                        }
                    )
            if static_malware_for_db:
                _log.debug(
                    f" P2.60 FIX: Extracted {len(static_malware_for_db)} static malware findings from malware_detection for DB"
                )

    # v5.1.3: DB setup (ingester call moved here after all raw files written)
    from reachable import __version__ as _ver
    from reachable.database.storage import RepoDatabase, get_repo_db_path

    repo_db_path = get_repo_db_path(repo_path)
    db = RepoDatabase(repo_db_path)

    # Get branch/commit from provenance
    _branch = "unknown"
    _commit = None
    _prov_file = output_dir / "provenance.json"
    if _prov_file.exists():
        with open(_prov_file) as _pf:
            _prov = json.load(_pf)
            _sp = _prov.get("source_provenance", {})
            _branch = _sp.get("branch") or "unknown"
            _commit = _sp.get("commit_sha")

    scan_id = db.start_scan(branch=_branch, commit_hash=_commit, scan_dir=str(output_dir), version=_ver)

    # Persist ScanConfig — single source of truth consumed by all downstream steps.
    try:
        from reachable.core.scan_config import ScanConfig as _SC
        _sc_args = type("_A", (), {
            "ci": ci_mode,
            "debug": debug,
            "quiet": ci_mode,
            "log_format": "text",
            "fail_on": fail_on,
            "skip_iac": False,
            "no_dynamic_malware": not enable_dynamic_malware,
            "sandbox_cache_ttl": sandbox_cache_ttl,
            "force_rebuild": force_rebuild,
        })()
        _sc = _SC.init(
            repo_path=repo_path,
            args=_sc_args,
            session_dir=output_dir,
            scan_id=scan_id,
            db_path=repo_db_path,
            branch=_branch,
            commit=_commit,
            version=_ver,
        )
        _sc.save()
    except Exception as e:
        _log.warning(f"ScanConfig save failed (non-fatal): {e}")

    # v5.1.3: Write in-memory findings to raw/ so ingester can read them
    _raw_dir = output_dir / "raw"
    if sandbox_findings_for_db:
        with open(_raw_dir / "sandbox-extracted.json", "w") as _f:
            json.dump({"findings": sandbox_findings_for_db}, _f)
    if static_malware_for_db:
        with open(_raw_dir / "static-malware-extracted.json", "w") as _f:
            json.dump({"findings": static_malware_for_db}, _f)

    db.close()

    results["_repo_db_path"] = str(repo_db_path)
    results["_scan_id"] = scan_id
    results["_output_dir"] = str(output_dir)
    results["_db_risk_score"] = db_risk_score
    results["_db_risk_level"] = db_risk_level

    # v4.6.8: Auto-maintenance after scan (checkpoint, vacuum, prune)
    try:
        from reachable.core.config import is_auto_maintenance_enabled, load_config
        from reachable.maintenance.auto import run_auto_maintenance

        if is_auto_maintenance_enabled():
            repo_db = get_repo_db_path(repo_path)
            if repo_db and repo_db.exists():
                config = load_config()
                auto_results = run_auto_maintenance(repo_db, config)

                if debug and auto_results.get("checkpointed"):
                    _log.debug(" Auto-maintenance: database checkpointed")
                if debug and auto_results.get("vacuumed"):
                    _log.debug(" Auto-maintenance: database vacuumed")
                if auto_results.get("pruned", 0) > 0 and debug:
                    _log.debug(f" Auto-maintenance: {auto_results['pruned']} old scans removed")
    except Exception as e:
        if debug:
            _log.debug(f"Auto-maintenance warning: {e}")

    return results


def _generate_dashboard(results: dict, output_dir: Path, skip: bool = False) -> None:
    """Generate Dashboard v2 (funnel visualization with Executive + Engineering views)"""
    if skip:
        _log.info(" Dashboard skipped (--no-dashboard)")
        return

    try:
        from reachable.dashboard_v2.generator import DashboardV2Generator

        generator = DashboardV2Generator()
        generator.generate_from_report(results, output_dir)
    except Exception as e:
        import traceback

        _log.info(f" Dashboard generation failed: {e}")
        _log.info(traceback.format_exc())


def print_summary(results: dict):
    """Print summary (reuses existing format)"""
    _log.debug("ANALYSIS COMPLETE")
    summary = results.get("summary", {})
    totals = summary.get("totals", {})
    _log.debug(" CVE Summary:")
    total_cves = totals.get("cves_total", summary.get("total_cves", 0))
    _log.debug(f" Total CVEs found: {total_cves}")

    # Severity breakdown
    critical = totals.get("cves_critical", 0)
    high = totals.get("cves_high", 0)
    medium = totals.get("cves_medium", 0)
    low = totals.get("cves_low", 0)

    if critical + high + medium + low > 0:
        _log.debug(" Severity Breakdown:")
        if critical > 0:
            _log.debug(f" Critical: {critical}")
        if high > 0:
            _log.debug(f" High: {high}")
        if medium > 0:
            _log.debug(f" Medium: {medium}")
        if low > 0:
            _log.debug(f" Low: {low}")
    reachable = totals.get("cves_reachable", summary.get("reachable_cves", 0))
    unreachable = totals.get("cves_unreachable", summary.get("unreachable_cves", 0))
    _log.debug(f" REACHABLE: {reachable} (require immediate attention)")
    _log.debug(f" UNREACHABLE: {unreachable} (Risk: LOW)")
    _log.debug(f" Risk Reduction: {summary.get('risk_reduction_pct', 0):.1f}%")
    _log.debug(" Code Coverage:")
    _log.debug(f" Functions analyzed: {summary.get('total_functions', 0)}")
    reachable_count = summary.get("reachable_functions", 0)
    total_funcs = summary.get("total_functions", 1)
    pct = (reachable_count / total_funcs * 100) if total_funcs > 0 else 0
    _log.debug(f" Reachable from entrypoints: {reachable_count} ({pct:.1f}%)")


def _get_repo_stats(repo_path: Path) -> dict:
    """
    Get repository scan statistics from repo.db.

    Returns:
        dict with branch, scan_count, first_scan_date
    """
    from reachable.database.storage import get_repo_db_path

    stats = {
        "branch": "unknown",
        "scan_count": 0,
        "first_scan_date": None,
    }

    # Get current git branch — read .git directly, no subprocess
    try:
        from reachable.cli.pipeline import _get_git_context
        _branch, _ = _get_git_context(repo_path)
        stats["branch"] = _branch
    except Exception as e:
        _log.debug(f"Could not read git branch for repo stats: {e}")

    # Get scan history from repo.db
    try:
        import sqlite3

        repo_db_path = get_repo_db_path(repo_path)
        if repo_db_path.exists():
            conn = sqlite3.connect(str(repo_db_path))
            cursor = conn.cursor()

            # Get total scan count for this repo
            cursor.execute("SELECT COUNT(*) FROM scans WHERE status = 'complete'")
            stats["scan_count"] = cursor.fetchone()[0]

            # Get first scan date
            cursor.execute("SELECT MIN(timestamp) FROM scans")
            first = cursor.fetchone()[0]
            if first:
                stats["first_scan_date"] = first[:10]  # YYYY-MM-DD

            conn.close()
    except Exception as e:
        _log.debug(f"Could not read scan history from repo.db: {e}")

    return stats


# scan_repo() removed — dead code. Preserved in git history.


def scan_serial(args):
    """
    Serial scan mode — drives pipeline init → run (sequential) → finalize.
    Uses identical pipeline step code as concurrent mode; steps run one at a
    time in dependency order. Produces identical output — easier to debug.
    """
    from pathlib import Path

    from reachable.cli.pipeline import pipeline_finalize, pipeline_init
    from reachable.parallel.orchestrator import run_serial_pipeline
    from reachable.parallel.tuner import derive_tuning, detect_hardware

    # Historical naming inconsistency: verbose=debug_mode (verbose: bool was the old CLI API
    # before --debug was added; scan_serial/scan_concurrent use debug_mode throughout).
    debug_mode = getattr(args, 'debug', False)
    quiet_mode = getattr(args, 'quiet', False)
    ci_mode = getattr(args, 'ci', False)
    log_format = getattr(args, 'log_format', 'text')
    no_timestamps = getattr(args, "no_timestamps", False)

    if log_format == "jsonl":
        output_mode = OutputMode.JSON
    elif ci_mode:
        output_mode = OutputMode.CI
    else:
        output_mode = OutputMode.HUMAN

    # verbose=debug_mode — historical naming alias: verbose: bool was the old scan_repo API
    _log.configure(
        quiet=quiet_mode,
        mode=output_mode,
        timestamps=not no_timestamps,
        debug=debug_mode,
    )

    repo_path = Path(args.repo).resolve()
    if not repo_path.exists() or not repo_path.is_dir():
        print(f"Error: Repository path not found: {repo_path}", file=sys.stderr)
        sys.exit(1)

    from reachable.integrations.preflight import preflight_check
    preflight = preflight_check(fix=False, quiet=False, skip_vulndb=True)
    if not preflight.ok:
        print("Cannot start scan - missing dependencies:", file=sys.stderr)
        for issue in preflight.issues:
            print(f"  - {issue}", file=sys.stderr)
        print("Run 'reachctl doctor' to resolve.", file=sys.stderr)
        sys.exit(1)

    hw = detect_hardware()
    tuning = derive_tuning(hw)
    print("\n▶ REACHABLE — Serial Mode")
    print(f"  CPU: {hw.ncpu} cores ({hw.cpu_vendor}, {hw.arch}), RAM: {hw.mem_gb:.1f}GB")

    import io
    import json
    from contextlib import redirect_stdout
    init_args = type('A', (), {
        'repo':               str(repo_path),
        'json':               True,
        'verbose':            debug_mode,
        # pass-through flags so ScanConfig.init sees the full user intent
        'ci':                 ci_mode,
        'fail_on':            getattr(args, 'fail_on', 'none'),
        'quiet':              quiet_mode,
        'log_format':         getattr(args, 'log_format', 'text'),
        'debug':              debug_mode,
        'skip_iac':           getattr(args, 'skip_iac', False),
        'no_dynamic_malware': getattr(args, 'no_dynamic_malware', False),
        'sandbox_cache_ttl':  getattr(args, 'sandbox_cache_ttl', 24),
        'force_rebuild':      getattr(args, 'force_rebuild', False),
    })()
    buf = io.StringIO()
    with redirect_stdout(buf):
        rc = pipeline_init(init_args)
    if rc != 0:
        print("Pipeline init failed", file=sys.stderr)
        sys.exit(rc)
    try:
        init_data = json.loads(buf.getvalue().strip())
        session_dir = Path(init_data['session_dir'])
    except Exception as e:
        print(f"Failed to parse pipeline init output: {e}", file=sys.stderr)
        sys.exit(1)

    steps = None
    if getattr(args, 'disable_ai', False) or getattr(args, 'disable_dlp', False):
        from reachable.cli.pipeline import PIPELINE_STEPS
        steps = [s for s in PIPELINE_STEPS.keys()
                 if not (s == 'ai' and getattr(args, 'disable_ai', False))
                 and not (s == 'dlp' and getattr(args, 'disable_dlp', False))]

    debug = debug_mode

    log_path = session_dir / "scan.log"
    from reachable.core.log_queue import start_log_queue, stop_log_queue
    log_handle = start_log_queue(log_path=log_path, debug=debug)

    rc = run_serial_pipeline(session_dir, steps=steps, tuning=tuning, debug=debug)
    if rc != 0:
        stop_log_queue(log_handle)
        print("\nSerial pipeline failed — check output above", file=sys.stderr)
        sys.exit(rc)

    print("\n▶ Finalizing (reachability + dashboard)...")
    finalize_args = type('A', (), {
        'session': str(session_dir),
        'fail_on': getattr(args, 'fail_on', 'none'),
        'skip_iac': getattr(args, 'skip_iac', False),
        'json': False,
        'verbose': debug,
    })()
    rc = pipeline_finalize(finalize_args)
    stop_log_queue(log_handle)
    sys.exit(rc)


def scan_concurrent(args):
    """
    Concurrent scan mode — drives pipeline init → run (parallel) → finalize.
    """
    from pathlib import Path

    from reachable.cli.pipeline import pipeline_finalize, pipeline_init
    from reachable.parallel.orchestrator import run_parallel_pipeline
    from reachable.parallel.tuner import derive_tuning, detect_hardware

    # --debug is not supported in concurrent mode (serial only)
    if getattr(args, 'debug', False):
        print("  [warn] --debug is not supported in concurrent mode — ignored (use --mode serial for debug output)", file=sys.stderr)
        args.debug = False

    ci_mode    = getattr(args, 'ci', False) or os.environ.get('CI', '').lower() in ('true', '1', 'yes')
    quiet_mode = getattr(args, 'quiet', False)
    log_format = getattr(args, 'log_format', 'text')

    from reachable.core.logger import OutputMode
    if log_format == 'jsonl':
        output_mode = OutputMode.JSON
    elif ci_mode:
        output_mode = OutputMode.CI
    else:
        output_mode = OutputMode.HUMAN

    _log.configure(quiet=quiet_mode, mode=output_mode, timestamps=False, debug=False)

    repo_path = Path(args.repo).resolve()
    if not repo_path.exists() or not repo_path.is_dir():
        print(f"Error: Repository path not found: {repo_path}", file=sys.stderr)
        sys.exit(1)

    from reachable.integrations.preflight import preflight_check
    preflight = preflight_check(fix=False, quiet=False, skip_vulndb=True)
    if not preflight.ok:
        print("Cannot start scan - missing dependencies:", file=sys.stderr)
        for issue in preflight.issues:
            print(f"  - {issue}", file=sys.stderr)
        print("Run 'reachctl doctor' to resolve.", file=sys.stderr)
        sys.exit(1)

    hw = detect_hardware()
    tuning = derive_tuning(hw)
    print("\n▶ REACHABLE — Concurrent Mode")
    print(f"  CPU: {hw.ncpu} cores ({hw.cpu_vendor}, {hw.arch}), RAM: {hw.mem_gb:.1f}GB")
    if hw.perf_cores:
        print(f"  P-cores: {hw.perf_cores}  E-cores: {hw.eff_cores}")
    print(tuning.summary())

    import io
    import json
    from contextlib import redirect_stdout

    init_args = type('A', (), {
        'repo':               str(repo_path),
        'json':               True,
        'verbose':            False,
        # pass-through flags so ScanConfig.init sees the full user intent
        'ci':                 ci_mode,
        'fail_on':            getattr(args, 'fail_on', 'none'),
        'quiet':              quiet_mode,
        'log_format':         log_format,
        'debug':              False,
        'skip_iac':           getattr(args, 'skip_iac', False),
        'no_dynamic_malware': getattr(args, 'no_dynamic_malware', False),
        'sandbox_cache_ttl':  getattr(args, 'sandbox_cache_ttl', 24),
        'force_rebuild':      getattr(args, 'force_rebuild', False),
    })()
    buf = io.StringIO()
    with redirect_stdout(buf):
        rc = pipeline_init(init_args)
    if rc != 0:
        print("Pipeline init failed", file=sys.stderr)
        sys.exit(rc)

    try:
        init_data = json.loads(buf.getvalue().strip())
        session_dir = Path(init_data['session_dir'])
    except Exception as e:
        print(f"Failed to parse pipeline init output: {e}", file=sys.stderr)
        print(f"Output was: {buf.getvalue()!r}", file=sys.stderr)
        sys.exit(1)

    steps = None
    if getattr(args, 'disable_ai', False) or getattr(args, 'disable_dlp', False):
        from reachable.cli.pipeline import PIPELINE_STEPS
        steps = [s for s in PIPELINE_STEPS.keys()
                 if not (s == 'ai' and getattr(args, 'disable_ai', False))
                 and not (s == 'dlp' and getattr(args, 'disable_dlp', False))]

    debug = getattr(args, 'debug', False)
    log_path = session_dir / "scan.log"
    from reachable.core.log_queue import start_log_queue as _start_lq
    from reachable.core.log_queue import stop_log_queue as _stop_lq
    log_handle = _start_lq(log_path=log_path, debug=debug)

    rc = run_parallel_pipeline(session_dir, steps=steps, tuning=tuning)
    if rc != 0:
        _stop_lq(log_handle)
        print("\nParallel pipeline failed — check output above", file=sys.stderr)
        sys.exit(rc)

    print("\n▶ Finalizing (reachability + dashboard)...")
    finalize_args = type('A', (), {
        'session': str(session_dir),
        'fail_on': getattr(args, 'fail_on', 'none'),
        'skip_iac': getattr(args, 'skip_iac', False),
        'json': False,
        'verbose': False,
        'skip_timing': False,
    })()
    rc = pipeline_finalize(finalize_args)
    _stop_lq(log_handle)
    sys.exit(rc)


# v5.1.3: REMOVED - _calculate_risk_level, _extract_call_path, store_scan_to_database
# Replaced by reachable.database.ingester + normalizers.
# Risk calculation: normalizers/cve.py
# Call path extraction: normalizers/cve.py
# CWE/secret classification: normalizers/semgrep.py
# DB writes: ingester.ingest()
