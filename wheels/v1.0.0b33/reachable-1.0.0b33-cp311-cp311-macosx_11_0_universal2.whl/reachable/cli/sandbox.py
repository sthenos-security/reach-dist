#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.
"""CLI sandbox operations: dynamic malware sandbox, Colima/Docker management."""

import json
import os
import platform
import shutil
import subprocess
import sys
from pathlib import Path
from typing import Optional

from reachable.core.logger import get_logger

logger = get_logger()


def _get_colima_info() -> dict:
    """
    Get structured info from `colima status --json`.
    Returns dict with keys: status, arch, cpus, memory, disk, runtime, socket_path.
    Returns {} if colima not installed or not running.
    """
    try:
        result = subprocess.run(
            ["colima", "status", "--json"],
            capture_output=True, text=True, timeout=10,
        )
        if result.returncode == 0 and result.stdout.strip():
            import json as _json
            return _json.loads(result.stdout)
    except Exception:
        pass
    return {}


def _check_colima_status() -> str:
    """
    Check Colima installation and running status.

    Returns:
        'running'       - Colima VM up and socket accessible
        'not_ready'     - Colima VM up but socket not yet accessible
        'stopped'       - Colima installed but VM not running
        'not_installed' - Colima not installed
    """
    try:
        if not shutil.which("colima"):
            return "not_installed"

        result = subprocess.run(["colima", "status"], capture_output=True, text=True, timeout=10)
        output = (result.stdout + result.stderr).lower()

        if result.returncode != 0:
            if "not running" in output or "not exist" in output:
                return "stopped"
            return "stopped"

        # Colima VM is up — verify Docker socket is accessible (single check, no retry).
        # Retry belongs in _start_colima only.
        if _get_docker_client():
            return "running"
        return "not_ready"

    except FileNotFoundError:
        return "not_installed"
    except subprocess.TimeoutExpired:
        return "stopped"
    except Exception:
        return "not_installed"


def _start_colima() -> bool:
    """
    Start Colima VM with appropriate resources for sandbox.

    Returns:
        True if Colima started successfully, False otherwise
    """
    try:
        logger.info("         (this may take 2-3 minutes on first run)")
        result = subprocess.run(
            ["colima", "start", "--cpu", "2", "--memory", "4", "--disk", "10"],
            capture_output=True,
            text=True,
            timeout=300,  # 5 min timeout
        )
        if result.returncode == 0:
            # Wait for Docker daemon to become responsive inside the VM
            import time

            for attempt in range(12):  # Up to 30 seconds
                time.sleep(2.5)
                client = _get_docker_client()
                if client:
                    return True
                if attempt == 0:
                    logger.info("         Waiting for Colima Docker engine...")
            logger.info("         Colima Docker engine did not respond after 30s")
            return False
        else:
            logger.info("         Colima start returned error")
            return False
    except subprocess.TimeoutExpired:
        logger.info("         Timeout waiting for Colima to start")
        return False
    except Exception as e:
        logger.info(f" Error: {e}")
        return False


# Global to store last docker connection error for diagnostics
_last_docker_error = None


def _get_docker_client():
    """
    Get Docker client, trying Docker context endpoint first (supports Colima).

    The Docker CLI uses 'contexts' to determine which daemon to connect to.
    This function queries the current context to get the endpoint, ensuring
    compatibility with Colima and other Docker context-based setups.

    Returns:
        docker.DockerClient or None
    """
    global _last_docker_error

    try:
        import docker
        if not hasattr(docker, 'DockerClient'):
            _last_docker_error = "wrong 'docker' package installed — run: pip install docker --break-system-packages"
            return None
    except ImportError:
        _last_docker_error = "docker SDK not installed — run: pip install docker --break-system-packages"
        return None

    # macOS: Colima socket only — never fall through to Docker Desktop.
    if platform.system() == "Darwin":
        colima_sockets = [
            Path.home() / ".colima" / "default" / "docker.sock",
            Path.home() / ".colima" / "docker.sock",
        ]
        for colima_socket in colima_sockets:
            if colima_socket.exists():
                try:
                    client = docker.DockerClient(base_url=f"unix://{colima_socket}")
                    client.ping()
                    _last_docker_error = None
                    return client
                except Exception as e:
                    _last_docker_error = f"Colima socket {colima_socket}: {e}"
        if not _last_docker_error:
            _last_docker_error = "Colima socket not found — is Colima running? (colima start)"
        return None

    # Linux: standard Docker socket
    try:
        client = docker.DockerClient(base_url="unix:///var/run/docker.sock")
        client.ping()
        _last_docker_error = None
        return client
    except Exception as e:
        _last_docker_error = f"/var/run/docker.sock: {e}"
        return None


def _ensure_sandbox_image() -> bool:
    """
    Ensure the sandbox Docker image is available.
    Uses Dockerfile hash to detect if rebuild is needed (cache invalidation).

    Returns:
        True if image is available, False otherwise
    """
    import hashlib

    try:
        import docker  # noqa: F401
    except ImportError:
        logger.info("         Docker SDK not installed (pip install docker)")
        return False

    client = _get_docker_client()
    if not client:
        # Connection failed - Colima may have stopped between checks
        logger.info("           Colima connection failed")
        return False

    image_name = "reachable/sandbox:latest"

    # Find sandbox directory (build context with Dockerfile)
    # __file__ = reachable/cli/sandbox.py
    # Dockerfile is at reach-core/sandbox/Dockerfile (repo root level)
    sandbox_dir = Path(__file__).parent.parent.parent / "sandbox"
    dockerfile = sandbox_dir / "Dockerfile"

    if not dockerfile.exists():
        # Fallback: check relative to reachable/ package
        sandbox_dir = Path(__file__).parent.parent / "sandbox"
        dockerfile = sandbox_dir / "Dockerfile"

    if not dockerfile.exists():
        logger.info(f"         Dockerfile not found (searched {Path(__file__).parent.parent.parent / 'sandbox'})")
        return False

    # Compute hash of Dockerfile + key sandbox files (so shim/entrypoint changes trigger rebuild)
    hasher = hashlib.sha256()
    hasher.update(dockerfile.read_bytes())
    for extra in ["scripts/entrypoint.sh", "runner.py"]:
        extra_path = sandbox_dir / extra
        if extra_path.exists():
            hasher.update(extra_path.read_bytes())
    # Include shim source directory hash
    shims_dir = sandbox_dir / "shims"
    if shims_dir.exists():
        for go_file in sorted(shims_dir.rglob("*.go")):
            hasher.update(go_file.read_bytes())
    current_hash = hasher.hexdigest()[:12]  # Short hash for label

    # Check if image exists with matching hash
    try:
        image = client.images.get(image_name)
        cached_hash = image.labels.get("reachable.sandbox.hash", "")

        if cached_hash == current_hash:
            logger.info("       Sandbox image ready (cached)")
            return True
        else:
            logger.info(" Sandbox image outdated (rebuilding...)")
    except docker.errors.ImageNotFound:
        logger.info("       Building sandbox image (first time only)...")

    # Build image with hash label
    try:
        logger.info(f" Building from {sandbox_dir}")
        image, build_logs = client.images.build(
            path=str(sandbox_dir),
            tag=image_name,
            labels={"reachable.sandbox.hash": current_hash},
            rm=True,
            quiet=False,
        )
        logger.info("       Sandbox image built")
        return True
    except Exception as e:
        logger.info(f" Build failed: {e}")
        return False


def _run_colima_sandbox(
    sbom_file: Path, output_dir: Path, repo_dir: Optional[Path] = None, cache_ttl_hours: int = 24
) -> Optional[dict]:
    """
    Internal: Run Docker-based sandbox when Colima is available.

    Colima provides a proper VM isolation layer, making it safe to run
    potentially malicious code (unlike Docker Desktop on macOS).
    """
    # Delegate to the existing sandbox analysis logic
    return run_sandbox_analysis(sbom_file, output_dir, repo_dir=repo_dir, cache_ttl_hours=cache_ttl_hours)


def _local_package_content_hash(pkg) -> str:
    """
    Compute a stable content hash of a local package's install hook files.
    Used as both package_version and pkg_hash in sandbox_cache.
    Cache busts automatically when hook file content changes.
    """
    import hashlib
    h = hashlib.sha256()
    for hook_name in pkg.hooks:
        if hook_name == "setup.py":
            hook_file = pkg.path / "setup.py"
        elif hook_name in ("preinstall", "install", "postinstall"):
            hook_file = pkg.path / "package.json"
        else:
            hook_file = pkg.path / hook_name
        try:
            if hook_file.exists():
                h.update(hook_file.read_bytes())
        except OSError:
            pass
    # Include path so same-named packages in different dirs get different hashes
    h.update(str(pkg.path).encode())
    return h.hexdigest()[:16]


def run_sandbox_analysis(
    sbom_file: Path, output_dir: Path, repo_dir: Optional[Path] = None, cache_ttl_hours: int = 24
) -> Optional[dict]:
    """
    Run behavioral sandbox analysis on dependencies (internal implementation).

    Uses hybrid testing: batch first, then individual tests if issues found.

    Args:
        sbom_file: Path to SBOM JSON file
        output_dir: Output directory for results

    Returns:
        Sandbox results dict or None if sandbox unavailable
    """
    logger.info("       Checking sandbox prerequisites...")

    # Check 1: Docker Python SDK
    docker_sdk_installed = False
    try:
        import docker  # noqa: F401

        docker_sdk_installed = True
        logger.info("    Docker SDK: installed")
    except ImportError:
        logger.info("    Docker SDK: not installed")
        logger.info("    Installing docker Python SDK...")
        import subprocess

        try:
            subprocess.check_call(
                [sys.executable, "-m", "pip", "install", "docker", "-q"],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                timeout=120,  # 2 min for pip install
            )
            docker_sdk_installed = True
            logger.info("    Docker SDK: installed successfully")
        except Exception as e:
            logger.info(f" Docker SDK: installation failed - {e}")
            logger.info("    Run manually: pip install docker")
            return {
                "verdict": "NOT_RUN",
                "reason": "Could not install docker Python SDK",
                "packages_tested": 0,
                "findings": [],
                "prerequisites": {"docker_sdk": False, "docker_daemon": False},
            }

    # Check 2: Docker daemon running (use _get_docker_client which knows about Colima)
    docker_daemon_running = False
    daemon_error = None
    client = _get_docker_client()
    if client:
        try:
            docker_daemon_running = True
            docker_version = client.version().get("Version", "unknown")
            logger.info(f" Docker daemon: running (v{docker_version})")
        except Exception as e:
            daemon_error = str(e)
            logger.info(f" Docker daemon: error getting version - {e}")
    else:
        daemon_error = _last_docker_error or "Could not connect to Docker"
        logger.info("    Docker daemon: not running")
        logger.info("    Start Docker Desktop or run: sudo systemctl start docker")

    if not docker_daemon_running:
        return {
            "verdict": "NOT_RUN",
            "reason": daemon_error or "Docker daemon not available",
            "packages_tested": 0,
            "findings": [],
            "prerequisites": {
                "docker_sdk": docker_sdk_installed,
                "docker_daemon": False,
                "error": daemon_error,
            },
        }

    # Both prerequisites met
    try:
        from reachable.metrics.comprehensive import SandboxMetrics

        from ..sandbox.runner import SandboxRunner, Verdict
    except ImportError as e:
        logger.info(f" Sandbox module not available: {e}")
        return None

    # Create runner (Docker is confirmed available, pass the Colima-aware client)
    runner = SandboxRunner(timeout=300, parallel=4, docker_client=client)

    # Parse SBOM to get packages (handles both compressed and uncompressed)
    try:
        try:
            from reachable.core.compression import load_json

            sbom = load_json(sbom_file)
        except ImportError:
            with open(sbom_file) as f:
                sbom = json.load(f)
    except Exception as e:
        logger.info(f" Could not read SBOM: {e}")
        return None

    # Extract packages from SBOM (Syft format uses 'artifacts', CycloneDX uses 'components')
    packages = []

    # Try Syft format first (artifacts), then CycloneDX (components)
    components = sbom.get("artifacts", []) or sbom.get("components", [])

    if not components:
        logger.info("     No packages found in SBOM")
        return {"verdict": "CLEAN", "reason": "No packages in SBOM", "packages_tested": 0, "findings": []}

    npm_count = 0
    pip_count = 0
    skipped_count = 0
    skipped_by_type = {}  # Track why packages were skipped

    for comp in components:
        name = comp.get("name", "")
        version = comp.get("version")

        # Syft format uses 'type', CycloneDX uses 'purl'
        pkg_type = comp.get("type", "").lower()
        purl = comp.get("purl", "")

        # Determine ecosystem
        ecosystem = None
        if pkg_type in ("npm", "node"):
            ecosystem = "npm"
            npm_count += 1
        elif pkg_type in ("pip", "pypi", "python"):
            ecosystem = "pip"
            pip_count += 1
        elif "pkg:pypi" in purl:
            ecosystem = "pip"
            pip_count += 1
        elif "pkg:npm" in purl:
            ecosystem = "npm"
            npm_count += 1
        elif pkg_type in ("go-module", "go", "golang") or "pkg:golang" in purl:
            skipped_count += 1
            skipped_by_type["Go"] = skipped_by_type.get("Go", 0) + 1
            continue  # Skip Go packages (different install mechanism)
        elif pkg_type in ("maven", "gradle", "java") or "pkg:maven" in purl:
            skipped_count += 1
            skipped_by_type["Java/Maven"] = skipped_by_type.get("Java/Maven", 0) + 1
            continue  # Skip Java packages
        elif pkg_type in ("cargo", "rust") or "pkg:cargo" in purl:
            skipped_count += 1
            skipped_by_type["Rust"] = skipped_by_type.get("Rust", 0) + 1
            continue  # Skip Rust packages
        elif pkg_type in ("gem", "ruby") or "pkg:gem" in purl:
            skipped_count += 1
            skipped_by_type["Ruby"] = skipped_by_type.get("Ruby", 0) + 1
            continue  # Skip Ruby packages
        else:
            skipped_count += 1
            skipped_by_type["Other"] = skipped_by_type.get("Other", 0) + 1
            continue  # Skip unknown ecosystems

        if name and ecosystem:
            # v4.6.10: Extract package hash from SBOM for cache integrity
            pkg_hash = ""
            for h in comp.get("hashes", []):
                if h.get("alg", "").upper() in ("SHA-256", "SHA256"):
                    pkg_hash = h.get("content", "")
                    break
            if not pkg_hash:
                # Fallback: use purl as pseudo-hash (unique per registry entry)
                pkg_hash = purl if purl else ""
            packages.append((name, ecosystem, version, pkg_hash))

    if not packages:
        reason = "No pip/npm packages found in SBOM to sandbox test"
        if skipped_count > 0:
            reason += f" ({skipped_count} Go/Java/other packages skipped)"
        logger.info(f" {reason}")
        return {
            "verdict": "CLEAN",
            "reason": reason,
            "packages_tested": 0,
            "findings": [],
            "stats": {
                "npm_packages": npm_count,
                "pip_packages": pip_count,
                "skipped_packages": skipped_count,
                "sbom_total": len(components),
            },
        }

    # Show breakdown before testing
    logger.info(f" Sandbox will test {len(packages)} packages:")
    logger.info(f" • npm: {npm_count}")
    logger.info(f" • pip: {pip_count}")
    if skipped_count > 0:
        skipped_detail = ", ".join(f"{k}: {v}" for k, v in sorted(skipped_by_type.items(), key=lambda x: -x[1]))
        logger.info(f" • skipped: {skipped_count} ({skipped_detail})")
        logger.info(" Why skipped:")
        logger.info(" • Go modules: No install-time hooks (uses go.mod declarative imports)")
        logger.info(" • Java/Maven: Build-time dependencies (Gradle/Maven manages lifecycle)")
        logger.info(" • Other: Ecosystem not yet supported for behavioral testing")
        logger.info(" Tip: These packages are still scanned by GuardDog static analysis")
    logger.info(" Running behavioral sandbox analysis...")
    logger.info(" Strategy: Batch test all → individual tests if suspicious")

    # v4.6.10: Check sandbox cache — skip packages already tested within TTL
    cached_findings = []
    cached_malicious = []
    cached_suspicious = []
    cached_clean_count = 0
    uncached_packages = []

    if cache_ttl_hours > 0:
        try:
            from reachable.database.storage import get_sandbox_cache_db

            # GLOBAL sandbox cache — shared across all repos on this machine.
            # Packages tested in one repo are never re-tested in another.
            db = get_sandbox_cache_db()

            for pkg_tuple in packages:
                name, ecosystem, version, pkg_hash = pkg_tuple
                cached = db.get_sandbox_cache(
                    name, version, ecosystem, max_age_hours=cache_ttl_hours, pkg_hash=pkg_hash
                )
                if cached:
                    if cached["malicious"]:
                        cached_malicious.append(name)
                        cached_findings.extend(cached["findings"])
                    elif cached["suspicious"]:
                        cached_suspicious.append(name)
                        cached_findings.extend(cached["findings"])
                    else:
                        cached_clean_count += 1
                else:
                    uncached_packages.append(pkg_tuple)

            total_cached = len(cached_malicious) + len(cached_suspicious) + cached_clean_count
            if total_cached > 0:
                logger.info(f" Sandbox cache: {total_cached} packages cached ({cache_ttl_hours}h TTL)")
                if cached_malicious:
                    logger.info(f" ☢️ Cached malware: {', '.join(cached_malicious)}")
                if cached_suspicious:
                    logger.info(f" ⚠️ Cached suspicious: {', '.join(cached_suspicious)}")
                logger.info(f" ✅ Cached clean: {cached_clean_count}")
                if uncached_packages:
                    logger.info(f" 🔄 Need testing: {len(uncached_packages)} packages")
                else:
                    logger.info(" All packages cached — skipping sandbox")
        except Exception:
            uncached_packages = packages  # Cache unavailable, test all
    else:
        logger.info(" Sandbox cache: disabled (TTL=0 or --force)")
        uncached_packages = packages

    # If all SBOM packages cached, still need to run local package testing.
    # Local packages (install hooks) are never in the SBOM cache — skip only
    # the Docker runner, not the local package detection step.
    if not uncached_packages and (cached_malicious or cached_suspicious or cached_clean_count > 0):
        overall_verdict = "CRITICAL" if cached_malicious else ("SUSPICIOUS" if cached_suspicious else "CLEAN")
        sandbox_data = {
            "verdict": overall_verdict,
            "packages_tested": len(packages),
            "duration_ms": 0,
            "strategy": "cached",
            "summary": {
                "malicious": len(cached_malicious),
                "suspicious": len(cached_suspicious),
                "clean": cached_clean_count,
                "verdict_explanation": f"All {len(packages)} packages served from sandbox cache ({cache_ttl_hours}h TTL)",
            },
            "findings": cached_findings,
            "malicious_packages": cached_malicious,
            "suspicious_packages": cached_suspicious,
            "metrics": {"packages_tested": len(packages), "cache_hits": len(packages)},
            "batch": {"verdict": overall_verdict, "duration_ms": 0, "findings_count": len(cached_findings)},
            "individual_tests": 0,
            "cache": {"hits": len(packages), "misses": 0, "ttl_hours": cache_ttl_hours},
        }

        # Local packages: check cache by content hash, only re-test if changed.
        if repo_dir:
            try:
                from ..sandbox.runner import (
                    SandboxRunner,
                    Verdict,
                    detect_local_packages_with_hooks,
                    test_local_packages,
                )

                _local_runner = SandboxRunner(timeout=300, parallel=4, docker_client=_get_docker_client())
                local_packages = detect_local_packages_with_hooks(str(repo_dir))
                if local_packages:
                    logger.info(f" Local packages with install hooks: {len(local_packages)}")

                    # --- Cache check for local packages ---
                    _local_cached = []   # (LocalPackageInfo, cached_result)
                    _local_uncached = [] # (LocalPackageInfo, content_hash)
                    if cache_ttl_hours > 0:
                        try:
                            from reachable.database.storage import get_sandbox_cache_db
                            _db_l = get_sandbox_cache_db()
                            for _lp in local_packages:
                                _lp_hash = _local_package_content_hash(_lp)
                                _lp_cached = _db_l.get_sandbox_cache(
                                    _lp.name, _lp_hash, "local", max_age_hours=cache_ttl_hours, pkg_hash=_lp_hash
                                )
                                if _lp_cached:
                                    _local_cached.append((_lp, _lp_cached))
                                else:
                                    _local_uncached.append((_lp, _lp_hash))
                        except Exception:
                            _local_uncached = [(_lp, _local_package_content_hash(_lp)) for _lp in local_packages]
                    else:
                        _local_uncached = [(_lp, _local_package_content_hash(_lp)) for _lp in local_packages]

                    _local_cache_hits = len(_local_cached)
                    if _local_cache_hits:
                        logger.info(f" Local package cache: {_local_cache_hits} hit(s)")
                    if _local_uncached:
                        logger.info(f" Local packages to test: {len(_local_uncached)}")

                    # Replay cached local results into sandbox_data
                    for _lp, _lp_c in _local_cached:
                        for _f in _lp_c.get("findings", []):
                            _f["local_package"] = True
                            sandbox_data["findings"].append(_f)
                        if _lp_c.get("malicious"):
                            sandbox_data["malicious_packages"] = list(
                                set(sandbox_data.get("malicious_packages", []) + [_lp.name])
                            )
                            sandbox_data["verdict"] = "CRITICAL"
                        sandbox_data["summary"]["malicious"] += (1 if _lp_c.get("malicious") else 0)
                        sandbox_data["summary"]["suspicious"] += (1 if _lp_c.get("suspicious") else 0)
                        sandbox_data["packages_tested"] += 1

                    # Test uncached local packages
                    local_results = []
                    if _local_uncached:
                        _pkgs_to_test = [_lp for _lp, _ in _local_uncached]
                        local_results = test_local_packages(
                            str(repo_dir), runner=_local_runner, timeout=300, packages=_pkgs_to_test
                        )

                        # Write results to global cache
                        try:
                            from reachable.database.storage import get_sandbox_cache_db
                            _db_lw = get_sandbox_cache_db()
                        except Exception:
                            _db_lw = None

                        _hash_map = {_lp.name: _h for _lp, _h in _local_uncached}
                        local_malicious = []
                        for lr in local_results:
                            if lr.verdict == Verdict.CRITICAL:
                                local_malicious.append(lr.package)
                            _lf_list = []
                            for f in lr.findings:
                                _lf = {
                                    "rule": f.rule,
                                    "severity": f.severity.value if hasattr(f.severity, "value") else str(f.severity),
                                    "description": f.description,
                                    "phase": f.phase,
                                    "evidence": f.evidence,
                                    "package": lr.package,
                                    "local_package": True,
                                }
                                _lf_list.append(_lf)
                                sandbox_data["findings"].append(_lf)
                            # Cache this result
                            if _db_lw and cache_ttl_hours > 0:
                                _lp_h = _hash_map.get(lr.package, "")
                                try:
                                    _db_lw.cache_sandbox_result(
                                        package_name=lr.package,
                                        version=_lp_h,
                                        ecosystem="local",
                                        verdict=lr.verdict.value,
                                        findings=_lf_list,
                                        malicious=(lr.verdict == Verdict.CRITICAL),
                                        suspicious=(lr.verdict.value == "SUSPICIOUS"),
                                        pkg_hash=_lp_h,
                                    )
                                except Exception:
                                    pass

                        local_suspicious = [lr.package for lr in local_results if lr.verdict.value == "SUSPICIOUS"]
                        if local_malicious:
                            sandbox_data["malicious_packages"] = list(
                                set(sandbox_data.get("malicious_packages", []) + local_malicious)
                            )
                            sandbox_data["verdict"] = "CRITICAL"
                        sandbox_data["summary"]["malicious"] += len(local_malicious)
                        sandbox_data["summary"]["suspicious"] += len(local_suspicious)
                        sandbox_data["packages_tested"] += len(local_results)

                    _cached_local_results = [
                        type("_CR", (), {"package": _lp.name, "verdict": type("V", (), {"value": _c["verdict"]})()
                                          , "findings": [], "duration_ms": 0, "capability_score": 1.0})()
                        for _lp, _c in _local_cached
                    ]
                    sandbox_data["local_packages"] = {
                        "tested": len(local_packages),
                        "cache_hits": _local_cache_hits,
                        "packages": [
                            {
                                "name": lr.package,
                                "verdict": lr.verdict.value,
                                "findings_count": len(lr.findings),
                                "duration_ms": lr.duration_ms,
                                "capability_score": lr.capability_score,
                                "cached": False,
                            }
                            for lr in local_results
                        ] + [
                            {
                                "name": _lp.name,
                                "verdict": _c["verdict"],
                                "findings_count": len(_c.get("findings", [])),
                                "duration_ms": 0,
                                "capability_score": 1.0,
                                "cached": True,
                            }
                            for _lp, _c in _local_cached
                        ],
                    }
                    _all_local_malicious = len([lr for lr in local_results if lr.verdict == Verdict.CRITICAL]) + sum(1 for _, _c in _local_cached if _c.get("malicious"))
                    _all_local_suspicious = len([lr for lr in local_results if lr.verdict.value == "SUSPICIOUS"]) + sum(1 for _, _c in _local_cached if _c.get("suspicious"))
                    logger.info(
                        f" Local package sandbox: {len(local_packages)} total "
                        f"({_local_cache_hits} cached, {len(_local_uncached)} tested), "
                        f"{_all_local_malicious} malicious, {_all_local_suspicious} suspicious"
                    )
            except Exception as _e:
                logger.info(f" Local package testing error: {_e}")

        return sandbox_data

    # Test only uncached packages — strip hash for runner (expects 3-tuples)
    packages_to_test = uncached_packages if uncached_packages else packages
    runner_packages = [(n, e, v) for n, e, v, _h in packages_to_test]

    # Use hybrid testing for efficiency
    def progress_callback(phase, current, total, pkg):
        if phase == "batch":
            if current == 0:
                logger.info(" Phase 1: Batch testing all packages...")
            else:
                logger.info(" Phase 1: Complete")
        elif phase == "individual":
            logger.info(f" Phase 2: Testing {pkg} ({current}/{total})...")

    try:
        result = runner.test_hybrid(runner_packages, progress_callback=progress_callback)

        # Convert to metrics for structured data
        metrics = SandboxMetrics.from_hybrid_result(result)

        # Count malicious/suspicious for risk score integration
        malicious_count = len(result.malicious_packages) if result.malicious_packages else 0
        suspicious_count = (
            len(result.batch_result.suspicious_packages) if result.batch_result.suspicious_packages else 0
        )

        # Binary model: CRITICAL = malware, CLEAN = nothing
        if result.verdict.value == "CRITICAL" and malicious_count == 0:
            malicious_count = 1  # At least one if CRITICAL verdict

        # Build result dict for JSON/dashboard
        sandbox_data = {
            "verdict": result.verdict.value,
            "capability_score": metrics.min_capability_score,
            "packages_tested": metrics.packages_tested,
            "duration_ms": result.duration_ms,
            "strategy": "hybrid",
            # Summary for risk score integration (matches sandbox_executor format)
            "summary": {
                "malicious": malicious_count,
                "suspicious": suspicious_count,
                "clean": metrics.packages_tested - malicious_count - suspicious_count,
                "verdict_explanation": {
                    "CLEAN": "No malicious behavior detected",
                    "SUSPICIOUS": "Suspicious behavior detected - review recommended",
                    "CRITICAL": "Malicious behavior confirmed - remove immediately",
                    "ERROR": "Sandbox execution failed",
                }.get(result.verdict.value, "Unknown verdict"),
            },
            "findings": [
                {
                    "rule": f.rule,
                    "severity": f.severity.value if hasattr(f.severity, "value") else str(f.severity),
                    "description": f.description,
                    "phase": f.phase,
                    "evidence": f.evidence,
                }
                for f in result.batch_result.findings
            ],
            "malicious_packages": result.malicious_packages,
            "suspicious_packages": result.batch_result.suspicious_packages,
            "metrics": metrics.to_dict(),
            "batch": {
                "verdict": result.batch_result.verdict.value,
                "duration_ms": result.batch_result.duration_ms,
                "findings_count": len(result.batch_result.findings),
            },
            "individual_tests": len(result.individual_results),
        }

        # Add individual findings
        for r in result.individual_results:
            for f in r.findings:
                sandbox_data["findings"].append(
                    {
                        "rule": f.rule,
                        "severity": f.severity.value if hasattr(f.severity, "value") else str(f.severity),
                        "description": f.description,
                        "phase": f.phase,
                        "evidence": f.evidence,
                        "package": r.package,
                    }
                )

        # Print summary with explanation
        # Log SBOM batch result (intermediate, not final verdict)
        logger.info(f" SBOM packages: {result.verdict.value} ({metrics.packages_tested} tested)")
        logger.info(f" Duration: {result.duration_ms}ms")

        # =================================================================
        # LOCAL PACKAGE TESTING
        # Detect and test local packages with install hooks (postinstall etc.)
        # These are NOT caught by GuardDog (which only checks registry pkgs)
        # Example: shai-hulud simulation in reach-testbed
        # =================================================================
        if repo_dir:
            try:
                from ..sandbox.runner import detect_local_packages_with_hooks, test_local_packages

                local_packages = detect_local_packages_with_hooks(str(repo_dir))
                if local_packages:
                    logger.info(f" Local packages with install hooks: {len(local_packages)}")

                    # --- Cache check for local packages (content-hash keyed) ---
                    _local_cached_b = []   # (LocalPackageInfo, cached_result)
                    _local_uncached_b = [] # (LocalPackageInfo, content_hash)
                    if cache_ttl_hours > 0:
                        try:
                            from reachable.database.storage import get_sandbox_cache_db
                            _db_b = get_sandbox_cache_db()
                            for _lp in local_packages:
                                _lp_hash = _local_package_content_hash(_lp)
                                _lp_c = _db_b.get_sandbox_cache(
                                    _lp.name, _lp_hash, "local", max_age_hours=cache_ttl_hours, pkg_hash=_lp_hash
                                )
                                if _lp_c:
                                    _local_cached_b.append((_lp, _lp_c))
                                else:
                                    _local_uncached_b.append((_lp, _lp_hash))
                        except Exception:
                            _local_uncached_b = [(_lp, _local_package_content_hash(_lp)) for _lp in local_packages]
                    else:
                        _local_uncached_b = [(_lp, _local_package_content_hash(_lp)) for _lp in local_packages]

                    _local_hits_b = len(_local_cached_b)
                    if _local_hits_b:
                        logger.info(f" Local package cache: {_local_hits_b} hit(s)")
                    if _local_uncached_b:
                        logger.info(f" Local packages to test: {len(_local_uncached_b)}")

                    # Replay cached results
                    for _lp, _lp_c in _local_cached_b:
                        for _f in _lp_c.get("findings", []):
                            _f["local_package"] = True
                            sandbox_data["findings"].append(_f)
                        if _lp_c.get("malicious"):
                            sandbox_data["malicious_packages"] = list(
                                set((sandbox_data.get("malicious_packages") or []) + [_lp.name])
                            )
                            sandbox_data["verdict"] = "CRITICAL"
                        sandbox_data["summary"]["malicious"] = sandbox_data["summary"].get("malicious", 0) + (1 if _lp_c.get("malicious") else 0)
                        sandbox_data["summary"]["suspicious"] = sandbox_data["summary"].get("suspicious", 0) + (1 if _lp_c.get("suspicious") else 0)
                        sandbox_data["packages_tested"] = sandbox_data.get("packages_tested", 0) + 1

                    # Test uncached local packages
                    local_results = []
                    if _local_uncached_b:
                        local_results = test_local_packages(
                            str(repo_dir), runner=runner, timeout=300,
                            packages=[_lp for _lp, _ in _local_uncached_b]
                        )

                        # Cache results to global cache
                        try:
                            from reachable.database.storage import get_sandbox_cache_db
                            _db_bw = get_sandbox_cache_db()
                        except Exception:
                            _db_bw = None

                        _hash_map_b = {_lp.name: _h for _lp, _h in _local_uncached_b}
                        local_findings = []
                        local_malicious = []
                        for lr in local_results:
                            if lr.verdict == Verdict.CRITICAL:
                                local_malicious.append(lr.package)
                            _lf_list = []
                            for f in lr.findings:
                                _lf = {
                                    "rule": f.rule,
                                    "severity": f.severity.value if hasattr(f.severity, "value") else str(f.severity),
                                    "description": f.description,
                                    "phase": f.phase,
                                    "evidence": f.evidence,
                                    "package": lr.package,
                                    "local_package": True,
                                }
                                _lf_list.append(_lf)
                                local_findings.append(_lf)
                            if _db_bw and cache_ttl_hours > 0:
                                _lp_h = _hash_map_b.get(lr.package, "")
                                try:
                                    _db_bw.cache_sandbox_result(
                                        package_name=lr.package,
                                        version=_lp_h,
                                        ecosystem="local",
                                        verdict=lr.verdict.value,
                                        findings=_lf_list,
                                        malicious=(lr.verdict == Verdict.CRITICAL),
                                        suspicious=(lr.verdict.value == "SUSPICIOUS"),
                                        pkg_hash=_lp_h,
                                    )
                                except Exception:
                                    pass

                        sandbox_data["findings"].extend(local_findings)
                        local_suspicious = [lr.package for lr in local_results if lr.verdict.value == "SUSPICIOUS"]
                        if local_malicious:
                            sandbox_data["malicious_packages"] = list(
                                set((sandbox_data.get("malicious_packages") or []) + local_malicious)
                            )
                            sandbox_data["verdict"] = "CRITICAL"
                        sandbox_data["summary"]["malicious"] = sandbox_data["summary"].get("malicious", 0) + len(local_malicious)
                        sandbox_data["summary"]["suspicious"] = sandbox_data["summary"].get("suspicious", 0) + len(local_suspicious)
                        sandbox_data["packages_tested"] = sandbox_data.get("packages_tested", 0) + len(local_results)

                    sandbox_data["local_packages"] = {
                        "tested": len(local_packages),
                        "cache_hits": _local_hits_b,
                        "packages": [
                            {
                                "name": lr.package,
                                "verdict": lr.verdict.value,
                                "findings_count": len(lr.findings),
                                "duration_ms": lr.duration_ms,
                                "capability_score": lr.capability_score,
                                "cached": False,
                            }
                            for lr in local_results
                        ] + [
                            {
                                "name": _lp.name,
                                "verdict": _lp_c["verdict"],
                                "findings_count": len(_lp_c.get("findings", [])),
                                "duration_ms": 0,
                                "capability_score": 1.0,
                                "cached": True,
                            }
                            for _lp, _lp_c in _local_cached_b
                        ],
                    }
                    _all_b_mal = len([lr for lr in local_results if lr.verdict == Verdict.CRITICAL]) + sum(1 for _, _c in _local_cached_b if _c.get("malicious"))
                    _all_b_sus = len([lr for lr in local_results if lr.verdict.value == "SUSPICIOUS"]) + sum(1 for _, _c in _local_cached_b if _c.get("suspicious"))
                    logger.info(
                        f" Local package sandbox complete: {len(local_packages)} total "
                        f"({_local_hits_b} cached, {len(_local_uncached_b)} tested), "
                        f"{_all_b_mal} malicious, {_all_b_sus} suspicious"
                    )

            except Exception as e:
                logger.info(f" Local package testing error: {e}")

        # =================================================================
        # FINAL VERDICT (after ALL testing — SBOM + local packages)
        # =================================================================
        final_verdict = sandbox_data["verdict"]
        final_malicious = sandbox_data.get("malicious_packages") or []
        final_suspicious = sandbox_data.get("suspicious_packages") or []
        final_malicious_count = sandbox_data["summary"].get("malicious", 0)
        final_suspicious_count = sandbox_data["summary"].get("suspicious", 0)

        verdict_icon = {"CLEAN": "", "SUSPICIOUS": "⚠️", "CRITICAL": "", "ERROR": ""}.get(final_verdict, "")

        verdict_explanation = {
            "CLEAN": "No malicious install-time behavior",
            "SUSPICIOUS": f"Suspicious behavior detected ({final_suspicious_count} packages) - review recommended",
            "CRITICAL": f"MALWARE CONFIRMED ({final_malicious_count} packages) - remove immediately",
            "ERROR": "Sandbox execution failed",
        }.get(final_verdict, "")

        logger.info(f" {verdict_icon} Sandbox verdict: {final_verdict}")
        if verdict_explanation:
            logger.info(f" → {verdict_explanation}")
        if final_malicious:
            logger.info(f" Malicious packages: {', '.join(final_malicious)}")
        if final_suspicious:
            logger.info(f" Suspicious packages: {', '.join(final_suspicious[:5])}")
            if len(final_suspicious) > 5:
                logger.info(f" ... and {len(final_suspicious) - 5} more")

        # v4.6.10: Write sandbox results to GLOBAL cache for each tested package
        if cache_ttl_hours > 0:
            try:
                from reachable.database.storage import get_sandbox_cache_db

                # GLOBAL sandbox cache — shared across all repos on this machine.
                db = get_sandbox_cache_db()

                malicious_set = set(result.malicious_packages or [])
                suspicious_set = set(result.batch_result.suspicious_packages or [])

                # Build per-package findings map from individual results
                pkg_findings = {}
                for r in result.individual_results:
                    pkg_findings[r.package] = [
                        {
                            "rule": f.rule,
                            "severity": f.severity.value if hasattr(f.severity, "value") else str(f.severity),
                            "description": f.description,
                            "phase": f.phase,
                            "evidence": f.evidence,
                        }
                        for f in r.findings
                    ]

                cached_count = 0
                for name, ecosystem, version, *rest in packages_to_test:
                    # pkg_hash write gap fix: pass content hash for integrity check on read.
                    # packages_to_test tuples are (name, ecosystem, version, pkg_hash).
                    _pkg_hash = rest[0] if rest else ""
                    pkg_verdict = (
                        "CRITICAL" if name in malicious_set else ("SUSPICIOUS" if name in suspicious_set else "CLEAN")
                    )
                    findings = pkg_findings.get(name, [])
                    db.cache_sandbox_result(
                        package_name=name,
                        version=version or "unknown",
                        ecosystem=ecosystem,
                        verdict=pkg_verdict,
                        findings=findings,
                        malicious=(name in malicious_set),
                        suspicious=(name in suspicious_set),
                        pkg_hash=_pkg_hash,
                    )
                    cached_count += 1

                logger.info(f" Sandbox cache: stored {cached_count} results ({cache_ttl_hours}h TTL)")

                # Purge stale entries (>7 days)
                purged = db.purge_sandbox_cache(max_age_hours=168)
                if purged:
                    logger.info(f" Sandbox cache: purged {purged} stale entries")
            except Exception as e:
                logger.info(f" Sandbox cache write error: {e}")
        else:
            logger.debug(" Sandbox cache disabled (TTL=0), skipping cache write")

        # Merge cached results into sandbox_data if partial cache hit
        if cached_findings:
            sandbox_data["findings"].extend(cached_findings)
            sandbox_data["malicious_packages"] = list(
                set((sandbox_data.get("malicious_packages") or []) + cached_malicious)
            )
            sandbox_data["suspicious_packages"] = list(
                set((sandbox_data.get("suspicious_packages") or []) + cached_suspicious)
            )
            sandbox_data["summary"]["malicious"] += len(cached_malicious)
            sandbox_data["summary"]["suspicious"] += len(cached_suspicious)
            sandbox_data["summary"]["clean"] += cached_clean_count
            sandbox_data["packages_tested"] += len(cached_malicious) + len(cached_suspicious) + cached_clean_count
            sandbox_data["cache"] = {
                "hits": len(cached_malicious) + len(cached_suspicious) + cached_clean_count,
                "misses": len(packages_to_test),
                "ttl_hours": cache_ttl_hours,
            }
            # Re-evaluate overall verdict with merged results
            if cached_malicious and sandbox_data["verdict"] != "CRITICAL":
                sandbox_data["verdict"] = "CRITICAL"

        # BUG-A7: Sync metrics.packages_tested with the top-level total.
        # metrics.to_dict() only counts the SBOM batch (176); local packages
        # are added to sandbox_data["packages_tested"] afterward (+14 = 190).
        # Without this patch, metrics.execution.packages_tested diverges from
        # the top-level count, producing confusing dual values in sandbox.json.
        _total_tested = sandbox_data.get("packages_tested", 0)
        if sandbox_data.get("metrics"):
            sandbox_data["metrics"]["packages_tested"] = _total_tested
        # Recompute summary.clean to account for local malicious packages.
        # They are added to summary.malicious but clean was never decremented.
        _mal = sandbox_data["summary"].get("malicious", 0)
        _sus = sandbox_data["summary"].get("suspicious", 0)
        sandbox_data["summary"]["clean"] = max(0, _total_tested - _mal - _sus)

        return sandbox_data

    except Exception as e:
        logger.info(f" Sandbox error: {e}")
        import traceback

        logger.debug(f" Sandbox traceback: {traceback.format_exc()}")
        return {"verdict": "ERROR", "reason": str(e), "packages_tested": len(packages), "findings": []}


def sandbox_command(args):
    """
    Manage dynamic malware sandbox.

    Platform-specific:
    - macOS: Colima (brew install/uninstall)
    - Linux: Firecracker (not yet implemented)
    """

    system = platform.system().lower()
    logger.info("REACHABLE DYNAMIC MALWARE SANDBOX")
    logger.info(f"Platform: {platform.system()} ({platform.machine()})")
    # Default to --status if no option specified
    if getattr(args, "init", False):
        _sandbox_init(system)
    elif getattr(args, "remove", False):
        _sandbox_remove(system)
    else:
        # Default behavior: show status
        _sandbox_status(system)


def _sandbox_status(system: str):
    """Check sandbox installation status"""

    if system == "darwin":
        logger.info("Checking Colima status...")
        colima_status = _check_colima_status()
        colima_info = _get_colima_info()

        def _show_vm_info():
            if not colima_info:
                return
            cpus = colima_info.get("cpu") or colima_info.get("cpus", "?")
            mem  = colima_info.get("memory", "?")
            disk = colima_info.get("disk", "?")
            arch = colima_info.get("arch", "?")
            rt   = colima_info.get("runtime", "docker")
            sock = colima_info.get("socket_path") or colima_info.get("address", "")
            logger.info(f"  VM:                        cpu={cpus}  mem={mem}  disk={disk}  arch={arch}  runtime={rt}")
            if sock:
                logger.info(f"  Socket:                    {sock}")

        if colima_status == "not_installed":
            logger.info("  Colima:                    NOT INSTALLED")
            logger.info("  Dynamic malware sandbox is NOT available.")
            logger.info("  Run: reachctl sandbox --init")
            sys.exit(1)
        elif colima_status == "not_ready":
            logger.info("  Colima:                    NOT READY (socket not accessible)")
            _show_vm_info()
            sock = Path.home() / ".colima" / "default" / "docker.sock"
            logger.info(f"  Socket exists:             {sock.exists()}  ({sock})")
            if _last_docker_error:
                logger.info(f"  Last connect error:        {_last_docker_error}")
            logger.info("  Try: colima restart  (then wait ~15s before re-checking)")
            sys.exit(1)
        elif colima_status == "stopped":
            logger.info("  Colima:                    INSTALLED but stopped")
            logger.info("  Sandbox installed but not running.")
            logger.info("  It will auto-start during scans, or run: colima start")
        else:
            # colima_status == 'running'
            logger.info("  Colima:                    RUNNING")
            _show_vm_info()
            image_status = _check_sandbox_image_status()
            logger.info(f"  Sandbox Image:              {image_status.strip()}")
            logger.info("  Dynamic malware sandbox is READY.")

    elif system == "linux":
        logger.info("  Firecracker:     NOT YET IMPLEMENTED")
        logger.info("  Linux sandbox (Firecracker) planned for v4.7.x")
        logger.info("  Static malware analysis (GuardDog) is always available.")

    else:
        logger.info(f" Platform {system} not supported for dynamic sandbox.")
        logger.info("  Static malware analysis (GuardDog) is always available.")
        sys.exit(1)


def _sandbox_init(system: str):
    """Install sandbox components"""

    if system == "darwin":
        logger.info("Installing Colima for macOS...")
        # Check if already installed
        colima_status = _check_colima_status()
        if colima_status != "not_installed":
            logger.info("   Colima is already installed")

            # Ensure Python Docker SDK is installed
            try:
                import docker  # noqa: F401

                docker.DockerClient  # Verify it's the real SDK
            except (ImportError, AttributeError):
                logger.info("   Installing Python Docker SDK...")
                try:
                    result = subprocess.run(
                        [sys.executable, "-m", "pip", "install", "docker", "-q"],
                        timeout=120,
                        capture_output=True,
                    )
                    if result.returncode == 0:
                        logger.info("   Python Docker SDK installed")
                    else:
                        logger.info("    Run manually: pip install docker")
                except Exception as e:
                    logger.info(f" Could not install Python Docker SDK: {e}")
                    logger.info("     Run manually: pip install docker")
            if colima_status == "stopped":
                logger.info("   Starting Colima...")
                if _start_colima():
                    logger.info("   Colima started")
                else:
                    logger.info("   Failed to start Colima")
                    sys.exit(1)
            elif colima_status == "not_ready":
                logger.info("    Colima not responding, restarting...")
                try:
                    subprocess.run(["colima", "stop"], timeout=60, capture_output=True)
                except Exception:
                    pass
                if _start_colima():
                    logger.info("   Colima restarted")
                else:
                    logger.info("   Failed to restart Colima")
                    logger.info("  Try manually: colima delete -f && colima start")
                    sys.exit(1)
            if _ensure_sandbox_image():
                logger.info("  Sandbox is ready!")
            else:
                logger.info("    Sandbox image not ready - will build on first scan")
            return

        # Check for brew
        if not shutil.which("brew"):
            logger.info("   Homebrew not found")
            logger.info("  Please install Homebrew first:")
            logger.info(
                '    /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"'
            )
            logger.info("  Or install Colima manually:")
            logger.info("    https://github.com/abiosoft/colima/releases")
            sys.exit(1)

        # Install colima and docker CLI via brew
        logger.info("   Installing colima and docker via Homebrew...")
        logger.info("     (this may take a few minutes)")
        try:
            result = subprocess.run(
                ["brew", "install", "colima", "docker"],
                timeout=600,  # 10 minute timeout
                capture_output=True,  # Suppress brew output
            )
            if result.returncode != 0:
                logger.info("   Installation failed")
                sys.exit(1)
        except subprocess.TimeoutExpired:
            logger.info("   Installation timed out")
            sys.exit(1)
        except Exception as e:
            logger.info(f" Installation error: {e}")
            sys.exit(1)
        logger.info("   Colima and Docker CLI installed")

        # Install Python Docker SDK
        logger.info("   Installing Python Docker SDK...")
        try:
            result = subprocess.run(
                [sys.executable, "-m", "pip", "install", "docker", "-q"], timeout=120, capture_output=True
            )
            if result.returncode == 0:
                logger.info("   Python Docker SDK installed")
            else:
                logger.info("    Python Docker SDK install failed (may already be installed)")
        except Exception as e:
            logger.info(f" Could not install Python Docker SDK: {e}")
            logger.info("     Run manually: pip install docker")

        # Start Colima
        logger.info("   Starting Colima VM...")
        logger.info("     (first start downloads VM image, may take 2-3 minutes)")
        if _start_colima():
            logger.info("   Colima started")
        else:
            logger.info("   Failed to start Colima")
            logger.info("  Try manually: colima start --cpu 2 --memory 4")
            sys.exit(1)

        # Build sandbox image
        _ensure_sandbox_image()
        logger.info(" SANDBOX INSTALLATION COMPLETE")
        logger.info("Dynamic malware detection is now enabled.")
        logger.info("Run 'reachctl scan /path/to/repo' to use it.")

    elif system == "linux":
        logger.info("    Linux sandbox (Firecracker) not yet implemented")
        logger.info("  Planned for v4.7.x")
        logger.info("  Static malware analysis (GuardDog) is always available.")
        sys.exit(0)

    else:
        logger.info(f" Platform {system} not supported")
        sys.exit(1)


def _sandbox_remove(system: str):
    """Remove sandbox components"""

    if system == "darwin":
        logger.info("Removing Colima sandbox...")
        # Check if installed
        colima_status = _check_colima_status()
        if colima_status == "not_installed":
            logger.info("    Colima is not installed")
            return

        # Stop Colima if running
        if colima_status == "running":
            logger.info("   Stopping Colima...")
            try:
                subprocess.run(["colima", "stop"], timeout=60, capture_output=True)
                logger.info("   Colima stopped")
            except Exception as e:
                logger.info(f" Failed to stop Colima: {e}")

        # Delete Colima VM
        logger.info("    Deleting Colima VM...")
        try:
            subprocess.run(["colima", "delete", "-f"], timeout=60, capture_output=True)
            logger.info("   Colima VM deleted")
        except Exception as e:
            logger.info(f" Failed to delete VM: {e}")

        # Check for brew
        if not shutil.which("brew"):
            logger.info("    Homebrew not found - cannot uninstall packages")
            logger.info("  Colima VM deleted, but binaries remain.")
            logger.info("  Remove manually if needed.")
            return

        # Uninstall via brew
        logger.info("   Uninstalling colima via Homebrew...")
        try:
            result = subprocess.run(["brew", "uninstall", "colima"], timeout=120, capture_output=True, text=True)
            if result.returncode == 0:
                logger.info("   Colima uninstalled")
            else:
                logger.info(f" Uninstall warning: {result.stderr[:100]}")
        except Exception as e:
            logger.info(f" Uninstall error: {e}")

        # Ask about docker CLI
        logger.info("    Docker CLI was NOT removed (may be used by other tools)")
        logger.info("  To remove: brew uninstall docker")
        logger.info(" SANDBOX REMOVED")
        logger.info("Dynamic malware detection is now disabled.")
        logger.info("Static malware analysis (GuardDog) still works.")

    elif system == "linux":
        logger.info("    Linux sandbox (Firecracker) not yet implemented")
        logger.info("  Nothing to remove.")

    else:
        logger.info(f" Platform {system} has no sandbox to remove")


def _check_docker_cli_status() -> str:
    """Check if docker CLI is installed and whether its active socket is Colima-owned."""
    if not shutil.which("docker"):
        return " not installed"
    version_str = ""
    try:
        result = subprocess.run(["docker", "--version"], capture_output=True, text=True, timeout=5)
        if result.returncode == 0:
            version_str = f"v{result.stdout.strip().split()[2].rstrip(',')}"
    except Exception:
        pass

    # Detect if active socket is Colima-owned
    socket_owner = _detect_docker_socket_owner()
    if socket_owner:
        label = f" installed ({version_str}, socket: {socket_owner})"
    elif version_str:
        label = f" installed ({version_str})"
    else:
        label = " installed"
    return label


def _detect_docker_socket_owner() -> str:
    """
    Detect who owns the active Docker socket.

    Returns a short label like 'Colima', 'Docker Desktop', or '' if unknown.
    Detection strategy:
      1. If ~/.colima/default/docker.sock exists and is a socket → 'Colima'
      2. If DOCKER_HOST points to a colima path → 'Colima'
      3. If /var/run/docker.sock exists and Docker Desktop LaunchAgent is present → 'Docker Desktop'
    """
    # Check Colima socket paths directly — most reliable
    colima_sockets = [
        Path.home() / ".colima" / "default" / "docker.sock",
        Path.home() / ".colima" / "docker.sock",
    ]
    for sock in colima_sockets:
        if sock.exists():
            import stat
            try:
                if stat.S_ISSOCK(sock.stat().st_mode):
                    return "Colima"
            except OSError:
                pass

    # Check DOCKER_HOST env var
    docker_host = os.environ.get("DOCKER_HOST", "")
    if "colima" in docker_host.lower():
        return "Colima"

    # Check if docker context points to colima
    try:
        result = subprocess.run(
            ["docker", "context", "inspect", "--format", "{{.Name}} {{.Endpoints.docker.Host}}"],
            capture_output=True, text=True, timeout=5,
        )
        if result.returncode == 0 and "colima" in result.stdout.lower():
            return "Colima"
    except Exception:
        pass

    # Docker Desktop check (macOS LaunchAgent)
    if platform.system() == "Darwin":
        dd_agent = Path.home() / "Library" / "LaunchAgents" / "com.docker.helper.plist"
        if dd_agent.exists():
            return "Docker Desktop"

    return ""


def _check_sandbox_image_status() -> str:
    """Check if sandbox Docker image exists and is up-to-date"""
    import hashlib

    global _last_docker_error

    try:
        import docker  # noqa: F401
    except ImportError:
        return " unknown (docker SDK not installed - pip install docker)"

    client = _get_docker_client()
    if not client:
        # Show the actual error from _get_docker_client
        if _last_docker_error:
            return f" unknown ({_last_docker_error})"
        else:
            return " unknown (Docker connection failed)"

    # Compute current hash
    # __file__ = reachable/cli/sandbox.py → Dockerfile at reach-core/sandbox/
    sandbox_dir = Path(__file__).parent.parent.parent / "sandbox"
    dockerfile = sandbox_dir / "Dockerfile"
    if not dockerfile.exists():
        sandbox_dir = Path(__file__).parent.parent / "sandbox"
        dockerfile = sandbox_dir / "Dockerfile"

    if dockerfile.exists():
        hasher = hashlib.sha256()
        hasher.update(dockerfile.read_bytes())
        for extra in ["scripts/entrypoint.sh", "runner.py"]:
            extra_path = sandbox_dir / extra
            if extra_path.exists():
                hasher.update(extra_path.read_bytes())
        shims_dir = sandbox_dir / "shims"
        if shims_dir.exists():
            for go_file in sorted(shims_dir.rglob("*.go")):
                hasher.update(go_file.read_bytes())
        current_hash = hasher.hexdigest()[:12]
    else:
        current_hash = None

    # Check image
    try:
        image = client.images.get("reachable/sandbox:latest")
        cached_hash = image.labels.get("reachable.sandbox.hash", "")

        if current_hash and cached_hash == current_hash:
            return f" ready (cached, hash: {cached_hash})"
        elif cached_hash:
            return "  outdated (will rebuild on next scan)"
        else:
            return " ready (no hash - legacy build)"
    except docker.errors.ImageNotFound:
        return "  not built (will build on first scan)"
    except Exception as e:
        return f" unknown ({e})"


# =============================================================================
# v4.5.51: Bug Fixes - Call Path and Risk Level Population
# =============================================================================
