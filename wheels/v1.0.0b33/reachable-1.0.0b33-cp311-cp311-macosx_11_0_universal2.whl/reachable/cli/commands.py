#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.
"""CLI commands: selftest, primer, dashboard, config, cleanup, system, vulndb, version."""

import json
import logging
import subprocess
import sys
from pathlib import Path
from typing import Optional

from reachable import __version__

# Cross-module imports

logger = logging.getLogger(__name__)


def selftest(args=None):
    """Verify REACHABLE installation and optionally run dev test suites.

    Usage:
        reachctl selftest                Quick sanity check (default, works from wheel)
        reachctl selftest --unit         Unit tests (source checkout only)
        reachctl selftest --integration  Integration tests (source checkout + testbed)
        reachctl selftest --full         ALL tests: unit + integration
        reachctl selftest --full -c      All tests with coverage report
    """
    from reachable.testing.selftest import SelfTest

    run_full        = getattr(args, "full", False) if args else False
    run_unit        = getattr(args, "unit", False) if args else False
    run_integration = getattr(args, "integration", False) if args else False
    coverage        = getattr(args, "coverage", False) if args else False
    quiet           = getattr(args, "quiet", False) if args else False
    run_extended    = run_full or run_unit or run_integration

    # Extended modes: delegate to TestRunner in tests/run_tests.py (source checkout required)
    if run_extended:
        tests_dir = Path(__file__).parent.parent.parent / "tests"
        run_tests_path = tests_dir / "run_tests.py"
        if not run_tests_path.exists():
            logger.info("❌ Extended flags (--full/--unit/--integration) require a source checkout of reach-core.")
            logger.info("   For installed wheels, use: reachctl selftest")
            sys.exit(1)

        import importlib.util
        import shutil as _shutil
        for _pc in tests_dir.rglob("__pycache__"):
            try:
                _shutil.rmtree(str(_pc))
            except OSError:
                pass
        spec = importlib.util.spec_from_file_location("run_tests", run_tests_path)
        mod  = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)
        runner = mod.TestRunner(verbose=not quiet)

        if run_integration:
            sys.exit(runner.run_integration_tests())
        elif run_unit:
            sys.exit(runner.run_unit_tests(coverage=coverage))
        else:
            sys.exit(runner.run_all_tests(coverage=coverage))

    # Default: quick selftest — always from reachable.testing.selftest (ships in wheel)
    test = SelfTest(verbose=not quiet)
    sys.exit(test.run())




def _page(text: str) -> None:
    """Pipe *text* through $PAGER (like man).  Falls back to direct print."""
    import os
    import shutil
    import subprocess

    if not sys.stdout.isatty():
        print(text)
        return

    pager = os.environ.get("PAGER") or shutil.which("less") or shutil.which("more")
    if not pager:
        print(text)
        return

    pager_cmd = [pager]
    # less -R preserves ANSI colour; -S chops long lines; -X avoids clearing
    if "less" in os.path.basename(pager):
        pager_cmd = [pager, "-RXS"]

    try:
        proc = subprocess.Popen(pager_cmd, stdin=subprocess.PIPE, encoding="utf-8")
        proc.communicate(input=text)
    except (BrokenPipeError, KeyboardInterrupt):
        pass
    except Exception:
        print(text)


def show_primer(args):
    """Show quick-start guide (paged, like man)."""
    from reachable import __version__

    text = f"""REACHABLE(1)                  Security Scanner                  REACHABLE(1)

NAME
  reachctl {__version__} — reachability-aware application security scanner

OVERVIEW
  REACHABLE scans your code and its dependencies to find security risks that
  are actually exploitable — not just theoretical.  It traces execution paths
  from your application through library code to determine which CVEs, secrets,
  CWEs, malware, AI/LLM risks, PII/DLP issues, and misconfigurations can
  really be reached at runtime.

  The result: dramatically less noise, so you fix what matters.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
GETTING STARTED
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

  1. INSTALL & VERIFY

     reachctl doctor               Check all dependencies are present
     reachctl selftest             Quick sanity check (ships in wheel)
     reachctl version              Show installed version and tool paths

  2. AUTHENTICATE (optional, one-time)

     If your git already clones from GitHub (SSH keys, credential helper,
     gh auth login), basic scanning works out of the box.  For full
     enrichment and API-based cloning, store tokens securely:

     reachctl auth login            Prompts for tokens, stores in keychain

  3. YOUR FIRST SCAN

     reachctl scan /path/to/repo

     That's it.  REACHABLE will:
       - Generate an SBOM (Syft)
       - Scan for CVEs (Grype), secrets, CWEs, malware (Semgrep/GuardDog)
       - Clone vulnerable library source and build call graphs
       - Classify every finding as REACHABLE, UNREACHABLE, or UNVERIFIED
       - Generate an interactive HTML dashboard

  4. VIEW RESULTS

     reachctl dashboard --open     Open dashboard in browser
     reachctl export --format csv  Export findings as CSV

  5. PATH SETUP (one-time)

     Add to ~/.zshrc or ~/.bashrc:
       export PATH="$HOME/.reachable/venv/bin:$PATH"

  6. STORAGE

     All data lives under ~/.reachable/ — scans, caches, databases, logs.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
ADVANCED CONFIGURATION
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

  SCAN FLAGS

     --ci                          CI mode: quiet + structured exit codes
     --quiet, -q                   Suppress progress, show results only
     --debug, -d                   Verbose output for troubleshooting
                                   Also enables timestamps in output
     --log-format jsonl            Machine-readable JSONL output (for Splunk,
                                   Datadog, ELK, or any log aggregator)
     --no-timestamps               No-op: timestamps are off by default.
                                   Kept for backward compatibility.
     --fail-on <level>             Exit non-zero if findings >= level
                                   (critical | high | medium | any | none)
     --sarif FILE                  Write SARIF 2.1.0 for GitHub/GitLab/Azure
     --no-ai                       Skip AI/LLM security analysis
     --no-dlp                      Skip DLP/PII analysis
     --no-dashboard                Skip dashboard generation (faster CI)
     --skip-iac                    Skip IaC scanning (Docker, K8s, Terraform)
     --no-sandbox                  Skip dynamic malware sandbox
     --no-health                   Skip package health checks
     --force-rebuild               Ignore all caches, fresh scan
     --radr                        Compile RADR manifest after scan

     See: reachctl scan --help

  CI/CD INTEGRATION

     Basic:
       reachctl scan . --ci --fail-on high

     With SARIF upload (GitHub Actions):
       reachctl scan . --ci --fail-on high --sarif results.sarif

     Machine-readable logs:
       reachctl scan . --ci --log-format jsonl

     Distributed pipeline (parallel steps on different runners):
       reachctl pipeline init /path/to/repo
       reachctl pipeline step scan    --session $ID          # sequential — SBOM + CVE
       reachctl pipeline step secrets --session $ID  &       # parallel
       reachctl pipeline step malware --session $ID  &       # parallel (needs scan)
       reachctl pipeline step health  --session $ID  &       # parallel (needs scan)
       reachctl pipeline step iac     --session $ID  &       # parallel
       reachctl pipeline step ai      --session $ID  &       # parallel
       reachctl pipeline step dlp     --session $ID  &       # parallel
       wait
       reachctl pipeline finalize     --session $ID --fail-on high

     See: reachctl pipeline --help

  AUTHENTICATION

     Desktop (credentials stored in system keychain):
       reachctl auth login          Prompts for all tokens, stores securely
       reachctl auth status         Show what's configured (masked)
       reachctl auth set <n>     Rotate a single token
       reachctl auth remove <n>  Remove a single token
       reachctl auth logout         Remove all stored credentials

     CI/CD (set as pipeline secrets — injected as env vars at runtime):
       GITHUB_TOKEN                 Tarball API + GHSA enrichment (recommended)
       MCP_GITHUB_TOKEN             MCP-based cloning (optional, different scopes)
       ANTHROPIC_API_KEY            Enzo cloud remediation (optional)

     Resolution order (first found wins):
       1. Environment variable       CI/CD, always takes priority
       2. System keychain            macOS Keychain / Linux encrypted file
       3. Not configured             auth status shows the gap

     GitHub PAT (classic, scope: repo read):
       Enables the tarball API — single-request archive downloads that are
       ~5x faster than git clone for fetching vulnerable library source.
       Also enables GHSA vulnerability enrichment (advisory details, affected
       versions, CWE mappings).  Without a PAT, REACHABLE falls back to git
       clone via SSH or credential helper — still works, just slower.
       Create at: github.com/settings/tokens

     GitHub MCP token (fine-grained, scopes: contents:read, metadata:read):
       Different token with different permissions.  Only needed if you use
       MCP-based workflows.  NOT interchangeable with the GitHub PAT.
       Create at: github.com/settings/personal-access-tokens/new

     Anthropic API key:
       Used by enzo for cloud-assisted fix strategies.  Sends only metadata
       to Claude (no source code).  Typical cost: ~$0.01-0.05 per finding.
       Create at: console.anthropic.com/settings/keys

     Verify: reachctl auth status

  OPTIONAL TOOLS

     TruffleHog — live secret verification
       Validates leaked credentials against real APIs (ACTIVE vs inactive).
       macOS:  brew install trufflehog
       Linux:  github.com/trufflesecurity/trufflehog/releases

     Joern — full JS/TS call graph
       Function-level reachability for JavaScript/TypeScript projects.
       Without it, REACHABLE uses file-level import tracing (ts-morph).
       Requires Java 17+.
       macOS:  brew install openjdk@17 && brew install joern
       Linux:  docs.joern.io/installation

     Check: reachctl doctor               (auto-detects and offers to install both)
            reachctl doctor --network-config  Show network timeout configuration

  DYNAMIC MALWARE SANDBOX (macOS)

     Runs suspicious packages in an isolated VM to detect install-time
     malware (credential theft, network exfiltration).  Static analysis
     (GuardDog) always runs — sandbox adds dynamic behavioural detection.

     reachctl sandbox --init       Install (Colima + Docker)
     reachctl sandbox --status     Check status
     reachctl sandbox --remove     Uninstall

     Cache TTL: --sandbox-cache-ttl <hours>   (default: 24)
     Env var:   REACHABLE_SANDBOX_CACHE_TTL=<hours>
     Linux:     Firecracker sandbox planned for a future release.

  AI-POWERED REMEDIATION (enzo)

     enzo auto-fixes your code vulnerabilities.  Point it at a scanned repo
     and it patches findings, validates each fix in an isolated worktree,
     and commits to per-finding branches.  You get a diff to review and a
     single batch branch to merge — or cherry-pick individual fixes.

     Fix branches are created in the TARGET repo (the one being fixed),
     not in reach-core.

     WORKFLOW

       # 1. Scan your repo (produces findings in repo.db)
       reachctl scan ~/src/myapp

       # 2. See what enzo can fix
       reachctl enzo scan ~/src/myapp

       # 3. Preview patches without changing anything
       reachctl enzo run ~/src/myapp --dry-run --mode cloud --provider groq

       # 4. Fix everything (Groq cloud — fast, cheap)
       reachctl enzo run ~/src/myapp --mode cloud --provider groq --debug

       # 5. Review and merge
       cd ~/src/myapp
       git diff main..reachable/batch/2026-03-12     # review all fixes
       git merge reachable/batch/2026-03-12          # merge the batch
       # or cherry-pick:
       git merge reachable/fix/07d2d96af949          # one finding

       # 6. Verify fixes hold (optional)
       reachctl enzo pentest ~/src/myapp

     COMMANDS

       enzo setup                     Pull local Ollama model (one-time)
       enzo doctor                    Check health: model, API keys, build tools
       enzo doctor --fix              Same + install missing tools via brew/apt
       enzo scan [path]               List fixable findings from last scan
       enzo fix [path] --finding-id X Fix one finding by ID
       enzo run [path]                Fix all fixable findings
       enzo pentest [path]            Verify fixes with exploit payloads
       enzo status [path]             Show remediation history
       enzo metrics [path]            Pipeline performance stats
       enzo benchmark                 Run quality benchmark suite
       enzo report [path]             Generate risk or compliance report
       enzo ingest --tool X --file Y  Import findings from external tools
       enzo gap-analysis [path]       Compare external vs reachable findings
       enzo knowledge                 Show global knowledge DB stats

     RUN FLAGS

       --mode local                   Ollama on your machine (default, private)
       --mode cloud                   Cloud API generates patches
       --mode fallback                Ollama first, cloud if local fails
       --provider groq                Groq cloud (fast, cheap)
       --provider claude              Claude API (highest quality)
       --dry-run                      Generate patches, don't apply or commit
       --severity HIGH                Minimum severity (default: HIGH)
       --reachable-only               Only REACHABLE findings
       --max-retries N                Max attempts per finding (default: 3)
       --fail-fast                    Stop on first failure
       --force                        Re-run all, ignore prior successes
       --no-consolidate               Skip merging into batch branch
       --scan-id N                    Use a specific scan (default: latest)
       --debug, -d                    Verbose output

     SCAN FLAGS

       --severity HIGH                Minimum severity threshold
       --reachable-only               Only REACHABLE findings
       --fix-type <type>              Filter: code_patch, dependency_upgrade,
                                      config_change, secret_rotation, dlp_patch

     FIX FLAGS

       --finding-id X                 Finding ID (from enzo scan output)
       --dry-run                      Preview without applying
       --mode / --provider            Same as run
       --debug, -d                    Verbose output

     REPORT FLAGS

       --framework soc2|pci|nist|...  GRC compliance evidence report
       --executive                    200-word executive summary
       --finding ID                   Deep-dive on one finding
       --accepted-risks               Interactive risk acceptance workflow
       --output markdown|pdf          Output format (default: markdown)
       --org "Company Name"           Organisation name for report header

     MODES

       local      Code never leaves your machine. Needs Ollama.
       cloud      Fastest. Source sent to API. Prompts for consent on first run.
       fallback   Tries local first, escalates to cloud if local fails.

     SETUP

       Groq (recommended for speed):
         export GROQ_API_KEY=gsk_...          # console.groq.com/keys
         reachctl enzo run ~/src/app --mode cloud --provider groq

       Claude (highest quality):
         export ANTHROPIC_API_KEY=sk-ant-...  # console.anthropic.com
         reachctl enzo run ~/src/app --mode cloud --provider claude

       Local (private, no API key):
         brew install ollama && brew services start ollama
         reachctl enzo setup                  # pulls the model (~20GB)
         reachctl enzo run ~/src/app

     RESUME

       enzo remembers what it already fixed.  If you stop and restart,
       it picks up where it left off — already-succeeded findings are
       skipped instantly.  Use --force to re-run everything.

     See: reachctl enzo --help, reachctl enzo run --help

  PRIVATE REGISTRIES

     If your project pulls from Artifactory, Nexus, GitHub Packages, etc:

     reachctl registries init      Auto-detect from env and config files
     reachctl registries test      Test connectivity
     reachctl registries show      Show current configuration

     Alias mapping (private to canonical package names):
       reachctl registries alias add <private> <canonical>
       Example: ...alias add "pkg:pypi/acme-crypto@" "pkg:pypi/cryptography@"

     See: reachctl registries --help, reachctl aliases --help

  ENVIRONMENT VARIABLES

     REACHABLE_HOME                Override ~/.reachable base directory
     REACHABLE_SEMGREP_JOBS=N      Override Semgrep parallelism
                                   (default: floor(ncpu * 0.85))
     REACHABLE_TRACE_SEMGREP=1     Per-rule timing (shows 5 slowest rules)
     REACHABLE_CACHE_TTL_HOURS=N   Semgrep cache lifetime (default: 24)
                                   Set to 0 for fresh scan every time
     REACHABLE_SANDBOX_CACHE_TTL=N Sandbox result cache hours (default: 24)
     REACHABLE_DEBUG=1             Enable debug mode without --debug flag
     REACHABLE_EXEMPTIONS_FILE     Path to custom exemptions file

     Network timeouts (seconds):
       REACHABLE_NET_CONNECT_TIMEOUT  REACHABLE_NET_READ_TIMEOUT
       REACHABLE_NET_TOTAL_TIMEOUT    REACHABLE_NET_API_CONNECT
       REACHABLE_NET_DOWNLOAD_READ    REACHABLE_NET_ENRICHMENT_READ

  CONFIGURATION

     reachctl config status        Show current config
     reachctl config get <key>     Get a value
     reachctl config set <key> <v> Set a value
     reachctl config enable        Enable auto-maintenance
     reachctl config disable       Disable auto-maintenance
     reachctl config reset         Reset to defaults

     Config file: ~/.reachable/config.json
     Auto-maintenance: WAL checkpointing, VACUUM, scan pruning.

  SCAN CACHES

     reachctl cache                Show cache status and sizes
     reachctl cache --clear        Clear all filesystem caches
     reachctl cache --clear-db     Clear DB-level caches (SBOM, call graph, sandbox)
     reachctl cache --clear-semgrep            Clear Semgrep result caches
     reachctl cache --clear-semgrep -r <repo>  Clear one repo only
     reachctl cache --clear-libs               Clear cloned library source
     reachctl cache --warm         Pre-warm caches for faster scans

     Per-repo exclude lists (auto-seeded on first scan, edit freely):
       ~/.reachable/scans/<repo>/semgrep-exclude.txt   ← Semgrep / DLP / CWE
       ~/.reachable/scans/<repo>/guarddog-exclude.txt  ← GuardDog malware

     Both files accept one directory name per line.  Directories listed in
     either file are fully excluded from the corresponding scanner.  Common
     uses: test fixtures (e.g. guinea_pigs/), vendor snapshots, generated
     code, or any directory inflating your finding counts.
     Changes take effect on the next scan — no restart needed.

     REACHABLE also maintains built-in default exclusions (node_modules/,
     vendor/, .git/, etc.) defined in analysis/coverage.py.  These apply
     to the dependency walker and show up in the Coverage tab under
     "Excluded Directories" with source "built-in".  User-configured
     excludes show up with source "your config" and the path to the file.

     The Coverage tab → "Exclude Configuration" panel shows both files,
     whether they exist, how many directories each layer excludes, and the
     manifests found inside excluded dirs so you can audit what was skipped.

     Find large dirs to exclude: reachctl top10size .

  DATABASE MANAGEMENT

     reachctl db --status          Database sizes, WAL, bloat
     reachctl db --compact         Compact databases (VACUUM)
     reachctl db --repair          Check and repair integrity
     reachctl cleanup              Emergency: compact + prune old scans

  EXPORT & AUDIT

     KEY DISTINCTION: --repo vs --repo-uri
       --repo /path/to/repo          Finds the database for that repo under
                                     ~/.reachable/scans/{{slug}}/repo.db
                                     Default: "." (current directory)
       --repo-uri https://github.com/org/repo
                                     SARIF metadata only — the GitHub/GitLab
                                     URL embedded in the SARIF report so Code
                                     Scanning links back to your repo.
                                     Does NOT affect which database is read.
                                     Auto-detected from GITHUB_REPOSITORY /
                                     CI_PROJECT_URL when running in CI.

     FORMATS
       reachctl export --repo ~/src/myapp --format summary
                                     Human-readable summary (quickest)
       reachctl export --repo ~/src/myapp --format csv --output findings.csv
                                     Flat CSV for spreadsheets / ticketing
       reachctl export --repo ~/src/myapp --format json
                                     Full v2 JSON payload (same as server API)
       reachctl export --repo ~/src/myapp --format sarif --output results.sarif
                                     SARIF 2.1.0 for GitHub Code Scanning
       reachctl export --repo ~/src/myapp --format sarif \
           --repo-uri https://github.com/org/myapp \
           --output results.sarif    SARIF with explicit repo URL metadata
       reachctl export --repo ~/src/myapp --scan-id 47 --format summary
                                     Specific scan by DB integer ID (latest if omitted)

     WHAT IS A SCAN SESSION ID?
       Every scan creates a session directory named:  YYYYMMDD-HHMMSS-<commit>
       Example:  20260312-044116-b5d36a
                 ^^^^^^^^  ^^^^^^  ^^^^^^
                 date      time    short commit hash

       You can see it in the scan log footer and in the dashboard URL:
         ~/.reachable/scans/<repo-hash>/main/20260312-044116-b5d36a/

       To export a specific session by its timestamp ID:
         reachctl export --repo ~/src/myapp --scan-id 20260312-044116-b5d36a

       To export the latest scan (most common):
         reachctl export --repo ~/src/myapp > ~/export.json

     GITHUB ACTIONS — upload SARIF to Code Scanning
       reachctl export --repo $GITHUB_WORKSPACE \
           --format sarif --output results.sarif
       # then: github/codeql-action/upload-sarif@v3 → sarif_file: results.sarif
       # Findings appear under Security → Code scanning alerts

     WORKFLOW GENERATION
       reachctl export --format github-action \
           --output .github/workflows/reachable.yml
       reachctl export --format github-action --fail-on high --branch main \
           --output .github/workflows/reachable.yml

     OTHER
       reachctl audit --scan-path <dir>  Validate raw → DB → dashboard pipeline
       reachctl manifest compile         Compile RADR agent-ready manifest

  TESTING

     reachctl selftest                Quick check (ships in wheel): imports, tools on PATH, DB
     reachctl selftest --unit         Unit tests (dev, requires pytest + source checkout)
     reachctl selftest --integration  Integration tests (requires pytest + reach-testbed)
     reachctl selftest --full -c      All tests with coverage report

  ALL COMMANDS

     Scan & Analyze:   scan, dashboard, export, audit, manifest
     System Health:     doctor, selftest, version, top10size
     Data Management:   db, cache, cleanup, vulndb, system
     Configuration:     config, auth, registries, aliases, license
     CI/CD:            pipeline
     AI Remediation:   enzo (scan, fix, run, pentest, setup, doctor, status,
                             metrics, benchmark, report, ingest, gap-analysis,
                             knowledge)
     Reference:        primer

     See: reachctl --help, reachctl <command> --help

SUPPORT
  For technical assistance, contact info@sthenosec.com

© 2026 Sthenos Security. All rights reserved.
"""
    _page(text)


def open_dashboard(args):
    """Generate or access scan dashboard"""
    import webbrowser
    from pathlib import Path

    # Get REACHABLE home directory
    reachable_home = Path.home() / ".reachable" / "scans"

    # List mode
    if getattr(args, "list", False):
        if not reachable_home.exists():
            logger.info("No scans found.")
            return
        logger.info("Available dashboards:")
        logger.info("")
        found = False
        for scan_dir in sorted(reachable_home.iterdir()):
            if not scan_dir.is_dir():
                continue
            dir_name = scan_dir.name
            repo_name = dir_name.rsplit("-", 1)[0] if "-" in dir_name else dir_name

            # Check old structure: {repo}/latest/
            direct_latest = scan_dir / "latest"
            if direct_latest.exists() and direct_latest.is_symlink():
                dashboard = direct_latest / "dashboard" / "index.html"
                if dashboard.exists():
                    found = True
                    target = direct_latest.readlink()
                    logger.info(f"  {repo_name}")
                    logger.info(f"    scan: {target}")
                    logger.info(f"    reachctl dashboard --repo {repo_name} --open")
                    logger.info("")
                    continue

            # Check new structure: {repo}/{branch}/latest/
            branches_found = []
            for subdir in sorted(scan_dir.iterdir()):
                if not subdir.is_dir() or subdir.name.startswith("."):
                    continue
                branch_latest = subdir / "latest"
                if branch_latest.exists() and branch_latest.is_symlink():
                    dashboard = branch_latest / "dashboard" / "index.html"
                    if dashboard.exists():
                        target = branch_latest.readlink()
                        branches_found.append((subdir.name, target))

            if branches_found:
                found = True
                logger.info(f"  {repo_name}")
                for branch, target in branches_found:
                    logger.info(f"    [{branch}] {target}")
                logger.info(f"    reachctl dashboard --repo {repo_name} --open")
                logger.info("")

        if not found:
            logger.info("  (none)")
        return

    # Helper: find latest scan dir, accounting for branch subdirectories
    def find_latest_in_repo(repo_dir: Path) -> Optional[Path]:
        """Find latest scan in repo dir, checking for branch subdirectories.

        Structure can be either:
          - {repo}/latest/  (old structure)
          - {repo}/{branch}/latest/  (new structure with branches)
        """
        # Check old structure first
        direct_latest = repo_dir / "latest"
        if direct_latest.exists() and (direct_latest / "dashboard" / "index.html").exists():
            return direct_latest  # Return symlink path, not resolved target

        # Check for branch subdirectories (new structure)
        latest_scan = None
        latest_mtime = 0

        for subdir in repo_dir.iterdir():
            if not subdir.is_dir():
                continue
            # Skip non-branch directories
            if subdir.name.startswith("."):
                continue

            branch_latest = subdir / "latest"
            if branch_latest.exists():
                dashboard = branch_latest / "dashboard" / "index.html"
                if dashboard.exists():
                    mtime = branch_latest.stat().st_mtime
                    if mtime > latest_mtime:
                        latest_mtime = mtime
                        latest_scan = branch_latest  # Return symlink path, not resolved target

        return latest_scan

    # Helper: fuzzy match repo name against scan directories
    def find_scan_dir(search_term: str) -> Optional[Path]:
        """Find scan directory by fuzzy matching repo name or path"""
        if not reachable_home.exists():
            return None

        search_lower = search_term.lower()
        matches = []

        for sd in reachable_home.iterdir():
            if not sd.is_dir():
                continue

            dir_name = sd.name.lower()
            # Extract repo name (remove hash suffix like -abc123)
            repo_name = dir_name.rsplit("-", 1)[0] if "-" in dir_name else dir_name

            # Exact match
            if repo_name == search_lower or dir_name == search_lower:
                latest = find_latest_in_repo(sd)
                if latest:
                    return latest

            # Partial match (search term contained in repo name)
            if search_lower in repo_name or search_lower in dir_name:
                latest = find_latest_in_repo(sd)
                if latest:
                    matches.append((sd, latest))

        # Return best match (most recent if multiple)
        if matches:
            # Sort by modification time, newest first
            matches.sort(key=lambda x: x[0].stat().st_mtime, reverse=True)
            return matches[0][1]

        return None

    # Determine scan directory
    repo = getattr(args, "repo", None)
    scan_dir = None

    if repo:
        repo_input = repo
        repo_path = Path(repo).resolve()

        # Check if it's a direct path to a scan output directory
        if repo_path.exists() and repo_path.is_dir():
            # Check if it looks like a scan output dir (has reachable-report.json)
            if (repo_path / "reachable-report.json").exists() or (repo_path / "reachable-report.json.gz").exists():
                scan_dir = repo_path
            else:
                # It's a repo path, look for scans by repo name
                scan_dir = find_scan_dir(repo_path.name)
        else:
            # It's a repo name, search in scans with fuzzy matching
            scan_dir = find_scan_dir(repo)

        if not scan_dir:
            logger.info(f"No scan found for: {repo_input}")
            logger.info("Available repos:")
            if reachable_home.exists():
                for sd in sorted(reachable_home.iterdir()):
                    if not sd.is_dir():
                        continue
                    latest = find_latest_in_repo(sd)
                    if latest:
                        dir_name = sd.name
                        repo_name = dir_name.rsplit("-", 1)[0] if "-" in dir_name else dir_name
                        logger.info(f"  {repo_name}")
            logger.info("Usage: reachctl dashboard --repo <n> --open")
            sys.exit(1)
    else:
        # Find most recent scan with a dashboard across all repos
        if reachable_home.exists():
            # Collect all valid dashboards with their mtimes
            valid_scans = []
            for repo_dir in reachable_home.iterdir():
                if not repo_dir.is_dir():
                    continue
                latest = find_latest_in_repo(repo_dir)
                if latest:
                    valid_scans.append((latest, latest.stat().st_mtime))

            if valid_scans:
                # Sort by mtime, newest first
                valid_scans.sort(key=lambda x: x[1], reverse=True)
                scan_dir = valid_scans[0][0]

    if not scan_dir:
        logger.info("No scan found. Run a scan first:")
        logger.info("  reachctl scan /path/to/repo")
        sys.exit(1)

    # Generate mode - regenerate dashboard from scan results
    if getattr(args, "generate", False):
        # Find report file
        report_file = scan_dir / "reachable-report.json"
        if not report_file.exists():
            report_file = scan_dir / "reachable-report.json.gz"

        if not report_file.exists():
            logger.info(f"Report not found in: {scan_dir}")
            sys.exit(1)

        # Load report
        try:
            if str(report_file).endswith(".gz"):
                import gzip

                with gzip.open(report_file, "rt") as f:
                    results = json.load(f)
            else:
                with open(report_file) as f:
                    results = json.load(f)
        except Exception as e:
            logger.info(f"Failed to load report: {e}")
            sys.exit(1)

        # Determine output directory
        output_dir = Path(args.output).resolve() if args.output else scan_dir

        # Generate dashboard
        try:
            from reachable.dashboard_v2.generator import DashboardV2Generator

            generator = DashboardV2Generator()
            dashboard_dir = generator.generate_from_report(results, output_dir)
            dashboard_path = dashboard_dir / "index.html"

            logger.info(f"Dashboard generated: {dashboard_path}")

            # Output path if requested
            if getattr(args, "path", False):
                logger.info(dashboard_path.absolute())

            # Open if requested
            if getattr(args, "open", False):
                url = f"file://{dashboard_path.absolute()}"
                webbrowser.open(url)

        except ImportError as e:
            logger.info(f"Dashboard generator not available: {e}")
            sys.exit(1)
        except Exception as e:
            logger.info(f"Dashboard generation failed: {e}")
            sys.exit(1)

        return

    # Default: find existing dashboard
    dashboard = scan_dir / "dashboard" / "index.html"

    if not dashboard.exists():
        logger.info(f"Dashboard not found: {dashboard}")
        logger.info("Generate with: reachctl dashboard --generate")
        sys.exit(1)

    # Path-only mode (for CI/CD)
    if getattr(args, "path", False):
        logger.info(dashboard.absolute())
        return

    # Open mode
    if getattr(args, "open", False):
        url = f"file://{dashboard.absolute()}"
        logger.info(f"Opening: {url}")
        webbrowser.open(url)
        return

    # Default: print path info (CI/CD friendly)
    logger.info(f"Dashboard: {dashboard.absolute()}")
    logger.info(f"URL: file://{dashboard.absolute()}")
    logger.info("Options:")
    logger.info("  --path       Print path only (for CI/CD artifacts)")
    logger.info("  --open       Open in browser")
    logger.info("  --generate   Regenerate from scan results")


def config_command(args):
    """
    Manage REACHABLE configuration.

    Commands:
        status  - Show current configuration
        get     - Get specific value
        set     - Set specific value
        enable  - Enable auto-maintenance
        disable - Disable auto-maintenance
        reset   - Reset to defaults
    """
    import sys

    from reachable.core.config import (
        DEFAULT_CONFIG,
        get_config_value,
        load_config,
        save_config,
        set_config_value,
    )

    action = getattr(args, "config_action", "status")

    if action == "status":
        config = load_config()
        auto = config.get("auto_maintenance", {})
        logger.info("REACHABLE Configuration")
        enabled = auto.get("enabled", True)
        status_icon = "" if enabled else ""
        logger.info(f"Auto-Maintenance: {status_icon} {'ENABLED' if enabled else 'DISABLED'}")
        if enabled:
            logger.info("Settings:")
            logger.info(f" Max scans per branch: {auto.get('max_scans_per_branch', 50)}")
            logger.info(f" Max scan age (days): {auto.get('max_age_days', 30)}")
            logger.info(f" Vacuum threshold: {auto.get('vacuum_threshold_pct', 30)}%")
            logger.info(f" WAL checkpoint: {'Yes' if auto.get('wal_checkpoint', True) else 'No'}")
            logger.info("What happens automatically:")
            logger.info("  • Database checkpoint after every scan")
            logger.info("  • Vacuum when bloat exceeds threshold")
            logger.info("  • Remove scans older than max age")
            logger.info("  • Keep only max scans per branch")
        else:
            logger.info("  Auto-maintenance is DISABLED")
            logger.info("   Run 'reachctl config enable' to turn it back on")
    elif action == "get":
        key = getattr(args, "key", None)
        if not key:
            logger.info("Error: Must specify key")
            logger.info("Usage: reachctl config get <key>")
            sys.exit(1)

        # Map friendly names to config paths
        key_map = {
            "max-scans": "auto_maintenance.max_scans_per_branch",
            "max-age": "auto_maintenance.max_age_days",
            "vacuum-threshold": "auto_maintenance.vacuum_threshold_pct",
            "enabled": "auto_maintenance.enabled",
        }

        config_key = key_map.get(key, f"auto_maintenance.{key}")
        value = get_config_value(config_key)

        if value is None:
            logger.info(f"Error: Unknown key '{key}'")
            sys.exit(1)

        logger.info(f"{key}: {value}")

    elif action == "set":
        key = getattr(args, "key", None)
        value_str = getattr(args, "value", None)

        if not key or value_str is None:
            logger.info("Error: Must specify key and value")
            logger.info("Usage: reachctl config set <key> <value>")
            sys.exit(1)

        # Map friendly names and parse values
        key_map = {
            "max-scans": ("auto_maintenance.max_scans_per_branch", int),
            "max-age": ("auto_maintenance.max_age_days", int),
            "vacuum-threshold": ("auto_maintenance.vacuum_threshold_pct", int),
        }

        if key not in key_map:
            logger.info(f"Error: Unknown key '{key}'")
            logger.info("Valid keys: max-scans, max-age, vacuum-threshold")
            sys.exit(1)

        config_key, value_type = key_map[key]

        try:
            value = value_type(value_str)
        except ValueError:
            logger.info(f"Error: Invalid value for {key}: {value_str}")
            sys.exit(1)

        # Validation
        if key == "max-scans" and value < 1:
            logger.info("Error: max-scans must be at least 1")
            sys.exit(1)
        if key == "max-age" and value < 1:
            logger.info("Error: max-age must be at least 1 day")
            sys.exit(1)
        if key == "vacuum-threshold" and not (1 <= value <= 100):
            logger.info("Error: vacuum-threshold must be 1-100%")
            sys.exit(1)

        set_config_value(config_key, value)
        logger.info(f" Set {key} = {value}")

    elif action == "enable":
        set_config_value("auto_maintenance.enabled", True)
        logger.info(" Auto-maintenance ENABLED")

    elif action == "disable":
        set_config_value("auto_maintenance.enabled", False)
        logger.info("  Auto-maintenance DISABLED")
        logger.info("   Databases and storage will not be maintained automatically")

    elif action == "reset":
        save_config(dict(DEFAULT_CONFIG))
        logger.info(" Configuration reset to defaults")

    else:
        logger.info(f"Error: Unknown action '{action}'")
        sys.exit(1)


def cleanup_command(args):
    """
    Emergency cleanup: compact databases and prune old scans.

    Usage:
        reachctl cleanup                    # Run cleanup
        reachctl cleanup --dry-run          # Preview only
        reachctl cleanup --force            # Force vacuum even if low bloat
    """
    import sys
    import time

    from reachable.maintenance.auto import run_cleanup

    dry_run = getattr(args, "dry_run", False)
    force = getattr(args, "force", False)
    if dry_run:
        logger.info("CLEANUP PREVIEW (DRY RUN)")
    else:
        logger.info("RUNNING CLEANUP")
    logger.info("This will:")
    logger.info("  • Checkpoint all database WAL files")
    logger.info("  • Vacuum databases to reclaim space")
    logger.info("  • Remove old scans based on retention policy")
    if not dry_run:
        logger.info("Starting in 3 seconds... (Ctrl+C to cancel)")
        try:
            time.sleep(3)
        except KeyboardInterrupt:
            logger.info("Cancelled")
            sys.exit(0)

    results = run_cleanup(force=force, dry_run=dry_run, verbose=True)
    logger.info("CLEANUP RESULTS")
    if results.get("error"):
        logger.info(f" Error: {results['error']}")
        sys.exit(1)

    logger.info(f"Repositories processed: {results['repos_processed']}")
    logger.info(f"Databases checkpointed: {results['total_checkpointed']}")
    logger.info(f"Databases vacuumed: {results['total_vacuumed']}")
    logger.info(f"Scans pruned: {results['total_pruned']}")

    if not dry_run and results["space_reclaimed_mb"] > 0:
        logger.info(f"Space reclaimed: {results['space_reclaimed_mb']:.1f} MB")

    if results["errors"]:
        logger.info("Errors:")
        for err in results["errors"]:
            logger.info(f" • {err}")
    if dry_run:
        logger.info("This was a dry run. Run without --dry-run to apply changes.")


def system_command(args):
    """
    System information and storage management.

    Actions:
        info  - Show system overview (storage, sandboxes, DB status)
        df    - Detailed disk usage breakdown
        prune - Clean up old scans and compress older dashboards
    """
    from reachable.storage.utils import print_system_info, prune_storage

    action = getattr(args, "action", "info")
    verbose = getattr(args, "verbose", False)
    json_output = getattr(args, "json", False)

    if action == "info":
        print_system_info(verbose=verbose, json_output=json_output)

    elif action == "df":
        import shutil

        reachable_home = Path.home() / ".reachable"
        if not reachable_home.exists():
            logger.info("~/.reachable does not exist yet")
            return
        # shutil.disk_usage() — Python stdlib, POSIX, works on macOS and Linux, instant
        # Reports the filesystem that ~/.reachable lives on
        usage = shutil.disk_usage(str(reachable_home))

        def _fmt(b):
            for unit in ("B", "KB", "MB", "GB", "TB"):
                if b < 1024 or unit == "TB":
                    return f"{b:.1f} {unit}"
                b /= 1024

        pct = usage.used / usage.total * 100 if usage.total else 0
        logger.info("Filesystem containing ~/.reachable:")
        logger.info(f"  Total:     {_fmt(usage.total)}")
        logger.info(f"  Used:      {_fmt(usage.used)} ({pct:.1f}%)")
        logger.info(f"  Available: {_fmt(usage.free)}")
        if pct > 90:
            logger.info(f"  WARNING: disk is {pct:.0f}% full")
        # Per-component sizes
        # du -sh is portable on macOS and Linux but slow on large dirs
        # Skip venv/, guarddog-venv/, cache/libs/ — they can be huge
        logger.info("")
        logger.info("COMPONENT SIZES (~/.reachable)  [this may take a moment]")

        def _du(path):
            """du -sh — portable on macOS and Linux."""
            try:
                r = subprocess.run(["du", "-sh", str(path)], capture_output=True, text=True, timeout=60)
                if r.returncode == 0 and r.stdout:
                    return r.stdout.split()[0]
            except Exception:
                pass
            return "?"

        # Small/bounded dirs — fast
        for name in ["logs", "sandbox", "tools", "scans"]:
            path = reachable_home / name
            if path.exists():
                logger.info(f"  {name:22} {_du(path)}")

        # cache/ subdirs individually — skip libs/ (cloned repo source, can be huge)
        cache_dir = reachable_home / "cache"
        if cache_dir.exists():
            for subdir in sorted(cache_dir.iterdir()):
                if subdir.is_dir() and subdir.name not in ("libs",):
                    logger.info(f"  cache/{subdir.name:16} {_du(subdir)}")
            libs_dir = cache_dir / "libs"
            if libs_dir.exists():
                try:
                    pkg_count = sum(1 for eco in libs_dir.iterdir() if eco.is_dir() for _ in eco.iterdir())
                    logger.info(
                        f"  cache/libs             ({pkg_count} cached pkgs — 'reachctl cache --status' for size)"
                    )
                except Exception:
                    pass

        # Venvs — large but static; skip by default, show note
        for name in ["venv", "guarddog-venv"]:
            path = reachable_home / name
            if path.exists():
                logger.info(f"  {name:22} (tooling venv — run 'du -sh {path}' to measure)")
    elif action == "prune":
        # Clean up old data
        dry_run = getattr(args, "dry_run", False)
        max_age = getattr(args, "max_age", 21)
        max_scans = getattr(args, "max_scans", 20)
        logger.info("REACHABLE STORAGE PRUNE")
        if dry_run:
            logger.info("  DRY RUN - No changes will be made\n")

        logger.info("Settings:")
        logger.info(f" Max scan age: {max_age} days")
        logger.info(f" Max scans per branch: {max_scans}")
        logger.info(" Compress after: 14 days")
        result = prune_storage(
            max_age_days=max_age,
            max_scans_per_branch=max_scans,
            compress_after_days=14,
            dry_run=dry_run,
            verbose=verbose,
        )
        logger.info("-" * 50)
        logger.info("RESULTS")
        logger.info("-" * 50)
        logger.info(f" Scans deleted: {result['scans_deleted']}")
        logger.info(f" Directories deleted: {result['dirs_deleted']}")
        logger.info(f" Directories compressed: {result['dirs_compressed']}")
        logger.info(f" Space freed: {result['bytes_freed_human']}")

        if result.get("errors"):
            logger.info("  Errors:")
            for err in result["errors"]:
                logger.info(f" • {err}")

        if dry_run:
            logger.info(" Run without --dry-run to apply changes")
        else:
            logger.info(" Cleanup complete")


def vulndb_command(args):
    """
    Manage grype vulnerability database.

    The vulnerability DB is cached locally at ~/.reachable/cache/grype-db/
    and auto-refreshed if older than 24 hours during scans.
    """
    from reachable.collectors.vulns.grype import VulnDBManager

    logger.info("REACHABLE VULNERABILITY DATABASE")
    mgr = VulnDBManager()

    if getattr(args, "update", False):
        # Force update
        logger.info("Updating vulnerability database...")
        if mgr.update(force=True, verbose=True):
            logger.info(" Vulnerability database updated successfully.")
        else:
            logger.info(" Failed to update vulnerability database.")
            sys.exit(1)

    elif getattr(args, "reset", False):
        # Clear and rebuild
        logger.info("Resetting vulnerability database...")
        if mgr.clear(verbose=True):
            logger.info("Downloading fresh database...")
            if mgr.update(force=True, verbose=True):
                logger.info(" Vulnerability database reset successfully.")
            else:
                logger.info(" Failed to download new database.")
                sys.exit(1)
        else:
            logger.info(" Failed to clear database.")
            sys.exit(1)

    else:
        # Default: show status
        status = mgr.get_status()

        logger.info(f"Location: {status['location']}")
        if status["exists"]:
            logger.info(" Status: Available")
            logger.info(f" Size: {status['size_mb']:.1f} MB")

            if status["age_hours"] is not None:
                age_hours = status["age_hours"]
                if age_hours < 1:
                    age_str = f"{int(age_hours * 60)} minutes"
                elif age_hours < 24:
                    age_str = f"{age_hours:.1f} hours"
                else:
                    age_str = f"{age_hours / 24:.1f} days"
                logger.info(f" Age: {age_str}")
                logger.info(f" Last Update: {status['last_update']}")

                if status["is_stale"]:
                    logger.info(f" Database is stale (> {status['max_age_hours']}h old)")
                    logger.info(" Will auto-refresh on next scan, or run:")
                    logger.info(" reachctl vulndb --update")
                else:
                    logger.info(f" Database is fresh (auto-refresh at {status['max_age_hours']}h)")
            else:
                logger.info(" Age: Unknown (no timestamp)")
        else:
            logger.info(" Status: Not initialized")
            logger.info("  The database will be downloaded automatically on first scan.")
            logger.info("  Or run: reachctl vulndb --update")
        logger.info("Commands:")
        logger.info("  reachctl vulndb --status  Show this status")
        logger.info("  reachctl vulndb --update  Force refresh now")
        logger.info("  reachctl vulndb --reset   Delete and rebuild from scratch")


def print_version(args=None):
    """Print version information with tool locations.

    Uses print() not logger.info() — this is user-facing output that must
    work even when logging is not yet configured (e.g. reachctl entry point).
    """
    import platform

    from reachable import __build_date__, __git_info__

    # Version line
    print(f"REACHABLE {__version__}")
    print("")

    # Python info
    print(f"Python: {platform.python_version()}")
    print(f"Platform: {platform.system().lower()}")
    print("")

    # Commit info
    git = __git_info__
    if git.get("sha"):
        commit_line = f"Commit: {git['sha']}"
        if git.get("date"):
            commit_line += f" ({git['date']})"
        if git.get("branch"):
            commit_line += f" [{git['branch']}]"
        print(str(commit_line))

    # Build date (only for wheel installs from CI/CD)
    if __build_date__:
        print(f"Build: {__build_date__}")

    print("")
    print("© 2026 Sthenos Security. All rights reserved.")


def top10size_command(args):
    """Show top-level directory file counts for scan performance diagnostics."""
    from pathlib import Path

    target = Path(getattr(args, "path", ".")).resolve()
    top_n = getattr(args, "top", 10)
    show_all = getattr(args, "all", False)

    if not target.is_dir():
        logger.info(f"Error: not a directory: {target}")
        sys.exit(1)
    logger.info(f"Scanning: {target}\n")

    dir_counts = []
    root_files = 0

    for entry in sorted(target.iterdir()):
        if entry.name.startswith("."):
            continue  # skip hidden
        if entry.is_file():
            root_files += 1
            continue
        if entry.is_dir():
            count = 0
            try:
                for _ in entry.rglob("*"):
                    count += 1
            except (PermissionError, OSError):
                pass
            dir_counts.append((entry.name, count))

    dir_counts.sort(key=lambda x: x[1], reverse=True)
    total = sum(c for _, c in dir_counts) + root_files

    # Print table
    display = dir_counts if show_all else dir_counts[:top_n]
    name_width = max((len(d[0]) for d in display), default=20)
    name_width = max(name_width, 20)

    logger.info(f"{'Directory':<{name_width}} {'Files':>10} {'%':>6}")
    logger.info("-" * (name_width + 20))

    for name, count in display:
        pct = (count / total * 100) if total else 0
        bar = "█" * int(pct / 2.5)
        logger.info(f"{name:<{name_width}} {count:>10,} {pct:>5.1f}% {bar}")

    if root_files:
        pct = (root_files / total * 100) if total else 0
        logger.info(f"{'(root files)':<{name_width}} {root_files:>10,} {pct:>5.1f}%")

    if not show_all and len(dir_counts) > top_n:
        rest = sum(c for _, c in dir_counts[top_n:])
        pct = (rest / total * 100) if total else 0
        logger.info(f"{'... ({} more)'.format(len(dir_counts) - top_n):<{name_width}} {rest:>10,} {pct:>5.1f}%")

    logger.info("-" * (name_width + 20))
    logger.info(f"{'TOTAL':<{name_width}} {total:>10,}")

    # Advice
    if dir_counts:
        top_name = dir_counts[0][0]
        top_pct = (dir_counts[0][1] / total * 100) if total else 0
        if top_pct > 50 and top_name in ("node_modules", "venv", ".venv", "vendor", "__pycache__", ".git"):
            # Find the per-repo exclude file — only if a scan exists
            from reachable.collectors.secrets.semgrep import SemgrepScanner

            slug = SemgrepScanner._repo_slug(target)
            scan_dir = Path.home() / ".reachable" / "scans" / slug
            logger.info(f" {top_name}/ is {top_pct:.0f}% of all files.")
            if scan_dir.exists():
                exclude_file = scan_dir / "semgrep-exclude.txt"
                logger.info(" Add it to your exclude list to speed up scans:")
                logger.info(f" echo '{top_name}' >> {exclude_file}")
            else:
                logger.info(f" Run a scan on this repo first, then exclude {top_name}/:")
                logger.info(f"   reachctl scan {target}")
                logger.info(f"   echo '{top_name}' >> ~/.reachable/scans/{slug}/semgrep-exclude.txt")


def audit_command(args):
    """
    Comprehensive data quality audit across entire pipeline.
    Validates: Raw JSON → Database → Dashboard
    Checks ALL finding types, states, severities, and reduction metrics.
    """
    from pathlib import Path

    from reachable.governance.audit import ComprehensiveAuditor, find_latest_scan

    # Get scan path
    scan_path = Path(args.scan_path) if args.scan_path else None

    if not scan_path:
        scan_path = find_latest_scan()
        if not scan_path:
            logger.info("Error: No scans found. Run a scan first or specify --scan-path")
            return 1

    if not scan_path.exists():
        logger.info(f"Error: Scan directory not found: {scan_path}")
        return 1

    # Run comprehensive audit
    auditor = ComprehensiveAuditor(scan_path)

    raw = auditor.audit_raw()
    db = auditor.audit_database()
    dash = auditor.audit_dashboard()

    issues = auditor.compare_stages(raw, db, dash)

    passed = auditor.print_report(raw, db, dash, issues)

    return 0 if passed else 1
