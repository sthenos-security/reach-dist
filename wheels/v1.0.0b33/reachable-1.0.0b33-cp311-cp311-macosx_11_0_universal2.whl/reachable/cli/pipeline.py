#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.

"""
Pipeline CLI - Distributed CI/CD Execution Support

Five steps (consolidated from seven):

  scan     Syft + Grype combined. Syft writes temp file → Grype reads it → temp deleted.
           SBOM dict cached in repo.db. Output: raw/grype-vulns.json
  secrets  Semgrep secrets + CWE merged → raw/security-findings.json
  malware  GuardDog. SBOM from db.get_cached_sbom(). Output: raw/malware.json
  iac      K8s + Docker Compose scanners. Output: raw/iac.json
  health   Registry health. SBOM from db.get_cached_sbom(). Output: raw/health.json

finalize   RA(grype-vulns.json) → cve-analyzed.json
           ingest(session_dir, db)
           store_package_health()
           complete_scan()
           generate_from_scan_dir()  ← DB → dashboard

Design axioms
─────────────
1. repo.db is the single source of truth.
2. ingester.py is the ONLY code path that writes findings to DB.
3. raw/ files exist solely to feed the ingester.
4. Syft and Grype share a temp file deleted after Grype reads it.
5. finalize reads DB to generate dashboard — never raw JSON.
"""

import hashlib
import json
import os
import tempfile
import threading
import time
from contextlib import contextmanager
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional

from reachable.core.logger import get_logger

# _log: used by step functions (run as subprocesses — stdout captured by make_stdout_reader → queue)
_log = get_logger()


@contextmanager
def _heartbeat(label: str, interval: int = 15):
    """Print a dot every `interval` seconds so long-running steps don't look hung."""
    stop = threading.Event()
    t0 = time.monotonic()

    def _beat():
        while not stop.wait(interval):
            elapsed = int(time.monotonic() - t0)
            _log.info(f"  {label} still running... ({elapsed}s)")

    t = threading.Thread(target=_beat, daemon=True)
    t.start()
    try:
        yield
    finally:
        stop.set()
        t.join(timeout=2)

# _flog: used by pipeline_finalize (runs in-process in the parent) — goes through the log queue

# ---------------------------------------------------------------------------
# Content-hash cache helpers  (drift detection for IAC + malware SAST)
# ---------------------------------------------------------------------------

_HASH_SKIP_DIRS = {
    ".git", ".hg", ".svn", "node_modules", "vendor", "third_party",
    ".venv", "venv", "env", "build", "dist", "target",
    "__pycache__", ".tox", ".nox",
}


def _content_hash(root: Path, suffixes: tuple) -> str:
    """
    SHA-256 of all files under *root* whose suffix is in *suffixes*.
    Files are sorted for determinism. Returns a 16-char hex prefix.
    """
    h = hashlib.sha256()
    for dirpath, dirnames, filenames in os.walk(str(root)):
        dirnames[:] = sorted(
            d for d in dirnames
            if d not in _HASH_SKIP_DIRS and not d.startswith(".")
        )
        for fname in sorted(filenames):
            if any(fname.endswith(s) for s in suffixes):
                fpath = Path(dirpath) / fname
                try:
                    h.update(str(fpath.relative_to(root)).encode())
                    h.update(fpath.read_bytes())
                except OSError:
                    pass
    return h.hexdigest()[:16]


def _load_cache(cache_file: Path) -> dict:
    try:
        return json.loads(cache_file.read_text())
    except Exception:
        return {}


def _save_cache(cache_file: Path, data: dict) -> None:
    tmp = cache_file.with_suffix(".tmp")
    try:
        tmp.write_text(json.dumps(data, indent=2))
        tmp.replace(cache_file)
    except OSError:
        try:
            tmp.unlink(missing_ok=True)
        except OSError:
            pass


# ---------------------------------------------------------------------------
# Step registry
# ---------------------------------------------------------------------------

PIPELINE_STEPS = {
    "scan":    "Generate SBOM (Syft) + scan vulnerabilities (Grype) — combined step",
    "clone":   "Clone vulnerable library source (MCP → npm-pack → git) for reachability",
    "secrets": "Scan secrets + CWE with Semgrep — combined, merged output",
    "malware": "Scan for malware with GuardDog (SBOM from DB cache)",
    "iac":     "Scan Infrastructure as Code (Kubernetes, Docker Compose)",
    "health":  "Analyze package health via registry APIs (SBOM from DB cache)",
    "ai":      "Scan for AI/LLM security issues (OWASP LLM Top 10)",
    "dlp":     "Scan for DLP/PII data exposure (taint analysis)",
}

PARALLEL_STEPS: List[str] = ["clone", "secrets", "malware", "iac", "health", "ai", "dlp"]

STEP_DEPENDENCIES: Dict[str, List[str]] = {
    "scan":    [],
    "clone":   ["scan"],
    "secrets": [],
    "malware": ["scan"],
    "iac":     [],
    "health":  ["scan"],
    "ai":      [],
    "dlp":     [],
}

# ---------------------------------------------------------------------------
# State management — sidecar architecture (zero write contention)
# ---------------------------------------------------------------------------

def get_pipeline_state_path(session_dir: Path) -> Path:
    return session_dir / ".pipeline-state.json"


def _get_step_state_path(session_dir: Path, step_name: str) -> Path:
    return session_dir / f".step-{step_name}.json"


def _write_json_atomic(path: Path, data: Dict[str, Any]) -> None:
    """Atomic write via temp-file + os.replace(). Readers never see partial files."""
    data["updated_at"] = datetime.now().isoformat()
    payload = json.dumps(data, indent=2)
    fd, tmp = tempfile.mkstemp(dir=path.parent, prefix=path.name + ".tmp-")
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            f.write(payload)
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp, path)
    except Exception:
        try:
            os.unlink(tmp)
        except OSError:
            pass
        raise


def _read_json_safe(path: Path) -> Dict[str, Any]:
    try:
        text = path.read_text(encoding="utf-8").strip()
        return json.loads(text) if text else {}
    except (OSError, json.JSONDecodeError):
        return {}


def load_pipeline_state(session_dir: Path) -> Dict[str, Any]:
    """Merge init state + per-step sidecars into unified dict."""
    init_state = _read_json_safe(get_pipeline_state_path(session_dir))
    if not init_state:
        return {}
    steps = init_state.get("steps", {})
    for step_name in list(steps.keys()):
        sidecar = _get_step_state_path(session_dir, step_name)
        if sidecar.exists():
            step_data = _read_json_safe(sidecar)
            if step_data:
                steps[step_name] = step_data
    init_state["steps"] = steps
    return init_state


def save_pipeline_state(session_dir: Path, state: Dict[str, Any]) -> None:
    _write_json_atomic(get_pipeline_state_path(session_dir), state)


def save_step_state(session_dir: Path, step_name: str, step_data: Dict[str, Any]) -> None:
    _write_json_atomic(_get_step_state_path(session_dir, step_name), step_data)


# ---------------------------------------------------------------------------
# pipeline init
# ---------------------------------------------------------------------------

def pipeline_init(args) -> int:
    """Initialize a pipeline session: create session dir, start DB scan record."""
    from reachable import __version__
    from reachable.database.storage import RepoDatabase, get_repo_db_path
    from reachable.output.manager import OutputManager

    repo_path = Path(args.repo).resolve()
    if not repo_path.exists():
        _log.info(f"Error: Repository not found: {repo_path}")
        return 1

    output_mgr = OutputManager(repo_path)
    session_dir = output_mgr.scan_dir
    session_id = output_mgr.timestamp

    branch, commit = _get_git_context(repo_path)

    db_path = get_repo_db_path(repo_path)
    db = RepoDatabase(db_path)
    scan_id = db.start_scan(
        branch=branch,
        commit_hash=commit,
        scan_dir=str(session_dir),
        version=__version__,
    )
    db.close()

    state = {
        "session_id": session_id,
        "repo_path": str(repo_path),
        "repo_name": output_mgr.repo_name,
        "session_dir": str(session_dir),
        "db_path": str(db_path),
        "scan_id": scan_id,
        "branch": branch,
        "commit": commit,
        "created_at": datetime.now().isoformat(),
        "version": __version__,
        "status": "initialized",
        "steps": {step: {"status": "pending"} for step in PIPELINE_STEPS},
    }
    save_pipeline_state(session_dir, state)

    # Persist ScanConfig — single source of truth for all steps + finalize
    try:
        from reachable.core.scan_config import ScanConfig
        cfg = ScanConfig.init(
            repo_path=repo_path,
            args=args,
            session_dir=session_dir,
            scan_id=scan_id,
            db_path=db_path,
            branch=branch,
            commit=commit,
            version=__version__,
        )
        cfg.save()
    except Exception as _cfg_err:
        _log.info(f"  ScanConfig save failed (non-fatal): {_cfg_err}")

    try:
        from reachable.core.context import ScanContext
        scan_ctx = ScanContext(repo_path, session_dir)
        output_mgr.save_scan_plan({
            "timestamp": session_id,
            "repo_path": str(repo_path),
            "repo_name": output_mgr.repo_name,
            "project_type": scan_ctx.project_type,
            "languages": scan_ctx.detected_languages,
            "pipeline_mode": True,
        })
    except Exception:
        pass

    if getattr(args, "json", False):
        print(json.dumps({
            "session_id": session_id,
            "session_dir": str(session_dir),
            "db_path": str(db_path),
            "scan_id": scan_id,
            "repo_name": output_mgr.repo_name,
            "branch": branch,
            "commit": commit,
        }))
    else:
        print(f"Session: {session_id}")
        print(f"Directory: {session_dir}")
        print(f"DB: {db_path}  scan_id={scan_id}")

    return 0


# ---------------------------------------------------------------------------
# pipeline step
# ---------------------------------------------------------------------------

def pipeline_step(args) -> int:
    _debug = getattr(args, 'debug', False)
    step_name = args.step
    if step_name not in PIPELINE_STEPS:
        _log.info(f"Error: Unknown step '{step_name}'. Available: {', '.join(PIPELINE_STEPS)}")
        return 1

    session_dir = _resolve_session_dir(args.session)
    if not session_dir:
        _log.info(f"Error: Session not found: {args.session}")
        return 1

    state = load_pipeline_state(session_dir)
    if not state:
        _log.info("Error: Invalid session (no state file)")
        return 1

    repo_path = Path(state["repo_path"])

    for dep in STEP_DEPENDENCIES.get(step_name, []):
        dep_status = state["steps"].get(dep, {}).get("status")
        if dep_status != "complete":
            _log.info(f"Error: '{step_name}' requires '{dep}' to complete first (status: {dep_status})")
            return 1

    started_at = datetime.now().isoformat()
    save_step_state(session_dir, step_name, {
        "status": "running",
        "started_at": started_at,
        "runner": os.environ.get("GITHUB_RUN_ID", os.environ.get("CI_JOB_ID", "local")),
    })

    t0 = time.time()
    try:
        result = _run_step(step_name, repo_path, session_dir, state, args)
        duration = time.time() - t0
        save_step_state(session_dir, step_name, {
            "status": "complete",
            "started_at": started_at,
            "completed_at": datetime.now().isoformat(),
            "duration_seconds": round(duration, 2),
            "result": result,
        })
        if getattr(args, "json", False):
            _log.info(json.dumps({"step": step_name, "status": "complete",
                                    "duration": round(duration, 2), "result": result}))
        else:
            _log.info(f"Step '{step_name}' complete ({duration:.1f}s)")
        return 0
    except Exception as e:
        duration = time.time() - t0
        save_step_state(session_dir, step_name, {
            "status": "failed",
            "started_at": started_at,
            "failed_at": datetime.now().isoformat(),
            "duration_seconds": round(duration, 2),
            "error": str(e),
        })
        _log.info(f"Step '{step_name}' failed: {e}")
        if getattr(args, "debug", False):
            import traceback
            _log.info(traceback.format_exc())
        return 1


def _run_step(step_name, repo_path, session_dir, state, args):
    if step_name == "scan":
        return _step_scan(repo_path, session_dir, state, args)
    elif step_name == "secrets":
        return _step_secrets(repo_path, session_dir, args)
    elif step_name == "malware":
        return _step_malware(repo_path, session_dir, state, args)
    elif step_name == "iac":
        return _step_iac(repo_path, session_dir, args)
    elif step_name == "health":
        return _step_health(repo_path, session_dir, state, args)
    elif step_name == "ai":
        return _step_ai(repo_path, session_dir, args)
    elif step_name == "dlp":
        return _step_dlp(repo_path, session_dir, args)
    elif step_name == "clone":
        return _step_clone(repo_path, session_dir, state, args)
    else:
        raise ValueError(f"Unknown step: {step_name}")


# ---------------------------------------------------------------------------
# Step implementations
# ---------------------------------------------------------------------------

def _step_scan(repo_path: Path, session_dir: Path, state: Dict[str, Any], args) -> Dict[str, Any]:
    """Syft (SBOM) + Grype (vulns) in one step. Temp SBOM file deleted after Grype reads it."""
    import subprocess

    from reachable.collectors.vulns.grype import VulnDBManager, get_grype_path, get_syft_path

    raw_dir = session_dir / "raw"
    raw_dir.mkdir(exist_ok=True)

    syft_path = get_syft_path()
    grype_path = get_grype_path()

    # Syft → temp file
    _log.info("Syft: generating SBOM...")
    fd, sbom_tmp_str = tempfile.mkstemp(suffix=".json", prefix="sbom-")
    sbom_tmp = Path(sbom_tmp_str)
    os.close(fd)
    try:
        from reachable.core.config import get_timeout as _cfg_timeout
        syft_r = subprocess.run(
            [str(syft_path), "scan", f"dir:{repo_path}", "-o", "json", "-q"],
            capture_output=True, text=True, encoding="utf-8", errors="replace",
            timeout=_cfg_timeout("syft_seconds"),
        )
        if syft_r.returncode != 0:
            raise RuntimeError(f"Syft failed: {syft_r.stderr[:500]}")
        try:
            sbom_data = json.loads(syft_r.stdout)
        except json.JSONDecodeError as e:
            raise RuntimeError(f"Syft output is not valid JSON: {e}") from e
        sbom_tmp.write_text(syft_r.stdout, encoding="utf-8")
        artifacts = sbom_data.get("artifacts", [])
        _log.info(f"Syft: {len(artifacts)} packages")

        # PURL enrichment — rewrites private-registry PURLs to canonical upstream
        # identities so Grype matches CVEs against the correct upstream package.
        purl_resolution_map = {}
        _enriched_sbom_tmp = None
        try:
            from reachable.collectors.vulns.purl_resolver import PURLResolver
            _resolver = PURLResolver()
            _enriched_path = _resolver.enrich_sbom(sbom_tmp)
            purl_resolution_map = _resolver.get_resolution_map(_enriched_path)
            if _enriched_path != sbom_tmp:
                _enriched_sbom_tmp = _enriched_path
                sbom_data = json.loads(_enriched_path.read_text(encoding="utf-8"))
            if purl_resolution_map:
                _log.info(f"  PURL: {len(purl_resolution_map)} private package(s) resolved")
            else:
                _purl_total = sbom_data.get("_reachable_registry_coverage", {}).get("total_packages", len(artifacts))
                _log.info(f"  PURL: {_purl_total} packages all canonical")
        except Exception as _purl_err:
            _log.info(f"  PURL enrichment skipped: {_purl_err}")

        # Grype reads the enriched SBOM (or original if enrichment did not change it)
        _grype_sbom_input = _enriched_sbom_tmp or sbom_tmp
        _log.info("Grype: scanning vulnerabilities...")
        db_mgr = VulnDBManager()
        db_mgr.ensure_fresh(verbose=False)
        grype_r = subprocess.run(
            [str(grype_path), f"sbom:{_grype_sbom_input}", "-o", "json", "-q"],
            capture_output=True, text=True, encoding="utf-8", errors="replace",
            env=db_mgr.get_grype_env(), timeout=_cfg_timeout("grype_scan_seconds"),
        )
        if grype_r.returncode != 0:
            raise RuntimeError(f"Grype failed: {grype_r.stderr[:500]}")
        try:
            vulns_data = json.loads(grype_r.stdout)
        except json.JSONDecodeError as e:
            raise RuntimeError(f"Grype output is not valid JSON: {e}") from e
        matches = vulns_data.get("matches", [])
        _log.info(f"Grype: {len(matches)} CVEs")

        # Write grype raw output for ReachabilityAnalyzer in finalize
        (raw_dir / "grype-vulns.json").write_text(grype_r.stdout, encoding="utf-8")

    finally:
        try:
            sbom_tmp.unlink()
        except OSError:
            pass
        if _enriched_sbom_tmp is not None:
            try:
                _enriched_sbom_tmp.unlink(missing_ok=True)
            except OSError:
                pass

    # Cache SBOM in DB for malware + health steps
    db_path = Path(state.get("db_path", ""))
    commit = state.get("commit") or ""
    if db_path.exists() and commit:
        try:
            from reachable.database.storage import RepoDatabase
            db = RepoDatabase(db_path)
            db.cache_sbom(commit, sbom_data)
            db.close()
            _log.info(f"SBOM cached in DB (commit {commit[:8]})")
        except Exception as e:
            _log.info(f"SBOM DB cache failed (malware/health will error): {e}")

    # Serialize purl_resolution_map for state storage.
    # Keys are (ecosystem, name) tuples — stored as "ecosystem:name" strings.
    _purl_serialized = {f"{k[0]}:{k[1]}": v for k, v in purl_resolution_map.items()}

    return {
        "file": "raw/grype-vulns.json",
        "packages": len(artifacts),
        "total_cves": len(matches),
        "by_severity": _count_by_severity(matches),
        "purl_resolutions": _purl_serialized,
    }


def _step_secrets(repo_path: Path, session_dir: Path, args) -> Dict[str, Any]:
    """Semgrep secrets scan + CWE scan — merged into one security-findings.json."""
    from reachable.collectors.secrets.semgrep import SemgrepScanner

    raw_dir = session_dir / "raw"
    raw_dir.mkdir(exist_ok=True)
    scanner = SemgrepScanner(repo_path)

    _log.info("  Semgrep: secrets scan...")
    secrets_r = scanner.scan_secrets()
    _log.info("  Semgrep: CWE scan...")
    cwe_r = scanner.scan_cwe()

    merged_findings = secrets_r.get("findings", []) + cwe_r.get("findings", [])
    merged = {
        "findings": merged_findings,
        "secrets_count": len(secrets_r.get("findings", [])),
        "cwe_count": len(cwe_r.get("findings", [])),
        "total": len(merged_findings),
    }
    with open(raw_dir / "security-findings.json", "w", encoding="utf-8") as f:
        json.dump(merged, f, indent=2)

    _log.info(f"  Semgrep: {merged['secrets_count']} secrets, {merged['cwe_count']} CWE")

    # Collect files semgrep could not parse (encoding errors, binary, corrupted).
    # Write to raw/sast-skipped.json so finalize can route them to the coverage gap.
    skipped = scanner.get_skipped_files()
    if skipped:
        _merge_sast_skipped(raw_dir, skipped)
        _log.info(f"  Semgrep: {len(skipped)} file(s) could not be parsed — added to coverage gap")

    return {"file": "raw/security-findings.json",
            "secrets": merged["secrets_count"],
            "cwe": merged["cwe_count"],
            "total": merged["total"],
            "sast_skipped": len(skipped)}


def _step_malware(repo_path: Path, session_dir: Path, state: Dict[str, Any], args) -> Dict[str, Any]:
    """GuardDog (registry packages) + Semgrep malware SAST (source code)."""
    from reachable.collectors.malware.guarddog import GuardDogScanner

    raw_dir = session_dir / "raw"
    raw_dir.mkdir(exist_ok=True)

    sbom_data = _get_sbom_from_db(state)
    if not sbom_data:
        raise RuntimeError("SBOM not in DB cache — 'scan' step must complete first")

    # --- Tier 1: GuardDog — registry package inspection ---
    _log.info("  GuardDog: scanning packages...")
    guarddog_cache = Path.home() / ".reachable" / "cache" / "guarddog-results"
    scanner = GuardDogScanner(cache_dir=guarddog_cache)
    results = scanner.scan_from_sbom(sbom_data)

    with open(raw_dir / "malware.json", "w", encoding="utf-8") as f:
        json.dump(results, f, indent=2)

    scanned   = results.get("packages_scanned", 0)
    malicious = results.get("malicious_count", 0)
    hits      = int(getattr(scanner, "cache_hits",   None) or 0)
    misses    = int(getattr(scanner, "cache_misses", None) or 0)
    total     = hits + misses
    hit_pct   = f"{hits/total*100:.0f}%" if total else "n/a"
    _log.info(
        f"  GuardDog: {scanned} scanned, {malicious} malicious "
        f"| network calls: {misses}  cache hits: {hits} ({hit_pct})"
    )

    # --- Tier 2: Semgrep malware SAST — source code patterns ---
    # Catches supply-chain attacks (setup.py hooks, postinstall, obfuscation,
    # C2 beacons, credential harvesters) that GuardDog misses for local packages.
    # SHA-based drift detection: skip rescan if source files unchanged.
    sast_count = 0
    try:
        from reachable.collectors.secrets.semgrep import SemgrepScanner

        repo_cache_dir = session_dir.parent.parent
        sast_cache_file = repo_cache_dir / "malware-sast-cache.json"
        sast_hash = _content_hash(repo_path, (".py", ".js", ".ts", ".jsx", ".tsx", ".mjs", ".cjs"))
        sast_cached = _load_cache(sast_cache_file)

        # Cache validity: require ok=True (guards against crash-produced empty results),
        # matching content_hash (source unchanged), matching rules_hash (malware.yaml unchanged),
        # and matching semgrep_version (scanner upgraded).
        sast_scanner = SemgrepScanner(repo_path)
        import subprocess as _sp
        _semgrep_ver = ""
        try:
            _sv = _sp.run([sast_scanner._find_semgrep() or "semgrep", "--version"], capture_output=True, text=True, timeout=5)
            _semgrep_ver = _sv.stdout.strip().split()[-1] if _sv.returncode == 0 else ""
        except Exception:
            pass
        _rules_hash = _content_hash(sast_scanner.malware_rules_path.parent, (".yaml",))[:16]

        _cache_ok = (
            sast_cached.get("ok") is True
            and sast_cached.get("content_hash") == sast_hash
            and sast_cached.get("rules_hash") == _rules_hash
            and sast_cached.get("semgrep_version", "") == _semgrep_ver
            and sast_cached.get("findings") is not None
        )

        if _cache_ok:
            _log.info(f"  Semgrep malware SAST: cache hit (hash={sast_hash[:8]}, rules={_rules_hash[:8]}, semgrep={_semgrep_ver}) — {len(sast_cached['findings'])} patterns")
            cached_findings = sast_cached["findings"]
            if cached_findings:
                with open(raw_dir / "static-malware-extracted.json", "w", encoding="utf-8") as f:
                    json.dump({"findings": cached_findings}, f, indent=2)
            sast_count = len(cached_findings)
        else:
            if not sast_cached.get("ok"):
                reason = "no prior cache" if not sast_cached else "prior scan not marked ok (possible crash or incomplete run)"
            elif sast_cached.get("content_hash") != sast_hash:
                reason = f"source drift ({sast_cached.get('content_hash','?')[:8]} → {sast_hash[:8]})"
            elif sast_cached.get("rules_hash") != _rules_hash:
                reason = f"rules changed ({sast_cached.get('rules_hash','?')[:8]} → {_rules_hash[:8]})"
            elif sast_cached.get("semgrep_version", "") != _semgrep_ver:
                reason = f"semgrep upgraded ({sast_cached.get('semgrep_version','?')} → {_semgrep_ver})"
            else:
                reason = "cache miss"
            _log.info(f"  Semgrep malware SAST: {reason} — rescanning")

            _log.info("  Semgrep: malware SAST scan (full repo)...")
            # Scope: full repo. See comment block below.
            # Scan the full repo — malware.yaml targets supply-chain injection patterns
            # (setup.py hooks, postinstall scripts, obfuscated loaders, credential harvesters)
            # that are specific enough not to FP on normal application code.
            # This correctly covers both standard package dirs (node_modules, site-packages)
            # AND local custom packages (malware-test-packages, static-malware-tests, etc.)
            # that never appear in any registry and therefore have no standard dir name.
            patterns = list(sast_scanner.scan_for_malware_patterns(repo_path))
            if patterns:
                # Convert MalwarePattern objects → pre-normalized finding dicts
                # (format expected by normalize_malware Priority 1 path)
                INSTALL_HOOK_FILES = (
                    "setup.py", "setup.cfg", "pyproject.toml",
                    "install.js", "postinstall", "preinstall",
                    ".github/workflows", "Makefile", "__init__.py",
                )
                import hashlib as _hashlib
                sast_findings = []
                for p in patterns:
                    fp = p.file_path or ""
                    is_hook = any(pat in fp.lower() for pat in INSTALL_HOOK_FILES)
                    reach_state = "reachable" if is_hook else "unknown"
                    _fid = _hashlib.md5(f"semgrep-malware:{p.rule_id}:{fp}:{p.line_number}".encode()).hexdigest()[:16]
                    sast_findings.append({
                        "id": _fid,
                        "finding_type": "malware",
                        "severity": p.severity if p.severity in ("CRITICAL", "HIGH", "MEDIUM", "LOW") else "MEDIUM",
                        "title": f"[Semgrep] {p.rule_id}: {p.message}"[:500],
                        "description": p.message[:1000],
                        "rule": p.rule_id,
                        "package": "",
                        "file": fp,
                        "file_path": fp,
                        "line": p.line_number,
                        "line_number": p.line_number,
                        "scanner": "semgrep",
                        "reachability_state": reach_state,
                        "app_reachability": reach_state.upper(),
                        "category": p.category,
                        "tier": p.tier,
                        "confidence": p.confidence,
                    })
                with open(raw_dir / "static-malware-extracted.json", "w", encoding="utf-8") as f:
                    json.dump({"findings": sast_findings}, f, indent=2)
                sast_count = len(sast_findings)
                _log.info(f"  Semgrep malware SAST: {sast_count} patterns found")
                _save_cache(sast_cache_file, {
                    "ok":             True,
                    "content_hash":   sast_hash,
                    "rules_hash":     _rules_hash,
                    "semgrep_version": _semgrep_ver,
                    "findings":       sast_findings,
                    "findings_count": len(sast_findings),
                    "generated_at":   datetime.utcnow().isoformat(),
                })
            else:
                # Never cache zero results — may indicate crash/timeout, not a clean repo.
                _log.info("  WARNING: Semgrep malware SAST: 0 patterns — skipping cache (will rescan next run)")
                if sast_cache_file.exists():
                    sast_cache_file.unlink()

        # Collect files semgrep could not parse during malware scan and merge
        # into raw/sast-skipped.json (same file written by _step_secrets).
        mal_skipped = sast_scanner.get_skipped_files()
        if mal_skipped:
            _merge_sast_skipped(raw_dir, mal_skipped)
            _log.info(f"  Semgrep malware: {len(mal_skipped)} file(s) skipped (coverage gap)")

    except Exception as e:
        _log.info(f"  Semgrep malware SAST skipped: {e}")

    return {
        "file": "raw/malware.json",
        "packages_scanned": scanned,
        "malicious": malicious,
        "sast_patterns": sast_count,
    }


def _step_iac(repo_path: Path, session_dir: Path, args) -> Dict[str, Any]:
    """K8s + Docker Compose security scan — with SHA-based drift detection."""
    import dataclasses

    from reachable.iac.docker_compose import DockerComposeScanner
    from reachable.iac.k8s_scanner import K8sSecurityScanner

    raw_dir = session_dir / "raw"
    raw_dir.mkdir(exist_ok=True)

    # Per-repo cache: ~/.reachable/scans/{repo-slug}/iac-cache.json
    repo_cache_dir = session_dir.parent.parent
    iac_cache_file = repo_cache_dir / "iac-cache.json"

    # Hash all YAML/compose source files to detect drift
    current_hash = _content_hash(repo_path, (".yaml", ".yml"))
    cached = _load_cache(iac_cache_file)

    if cached.get("content_hash") == current_hash and cached.get("findings") is not None:
        _log.info(f"  IAC: no file changes detected (hash={current_hash[:8]}) — using cached results")
        results = {
            "findings":       cached["findings"],
            "total_findings": cached["total_findings"],
            "by_type":        cached["by_type"],
            "content_hash":   current_hash,
            "cache_hit":      True,
        }
        with open(raw_dir / "iac.json", "w", encoding="utf-8") as f:
            json.dump(results, f, indent=2)
        _log.info(f"  IAC: {results['total_findings']} findings (from cache)")
        return {"file": "raw/iac.json", "total": results["total_findings"], "by_type": results["by_type"]}

    if cached.get("content_hash") and cached["content_hash"] != current_hash:
        _log.info(f"  IAC: file drift detected ({cached['content_hash'][:8]} → {current_hash[:8]}) — rescanning")
    else:
        _log.info(f"  IAC: no prior cache (hash={current_hash[:8]}) — scanning")

    results = {"findings": [], "total_findings": 0, "by_type": {}}

    _log.info("  K8s scanner...")
    k8s = K8sSecurityScanner()
    k8s_f = k8s.scan_directory(repo_path)
    k8s_dicts = [dataclasses.asdict(f) if dataclasses.is_dataclass(f) else f for f in k8s_f]
    results["findings"].extend(k8s_dicts)
    results["by_type"]["kubernetes"] = len(k8s_f)

    _log.info("  Docker Compose scanner...")
    dc = DockerComposeScanner()
    dc_f = dc.scan_directory(repo_path)
    dc_dicts = [dataclasses.asdict(f) if dataclasses.is_dataclass(f) else f for f in dc_f]
    results["findings"].extend(dc_dicts)
    results["by_type"]["docker"] = len(dc_f)

    results["total_findings"] = len(results["findings"])
    results["content_hash"] = current_hash
    results["cache_hit"] = False

    with open(raw_dir / "iac.json", "w", encoding="utf-8") as f:
        json.dump(results, f, indent=2)

    # Update per-repo cache
    _save_cache(iac_cache_file, {
        "content_hash":   current_hash,
        "findings":       results["findings"],
        "total_findings": results["total_findings"],
        "by_type":        results["by_type"],
        "generated_at":   datetime.utcnow().isoformat(),
    })

    _log.info(f"  IAC: {results['total_findings']} findings")
    return {"file": "raw/iac.json", "total": results["total_findings"], "by_type": results["by_type"]}


def _step_health(repo_path: Path, session_dir: Path, state: Dict[str, Any], args) -> Dict[str, Any]:
    """Package health via registry APIs. Reads SBOM from DB — no file I/O."""
    from reachable.collectors.health.collector import PackageHealthCollector

    raw_dir = session_dir / "raw"
    raw_dir.mkdir(exist_ok=True)

    sbom_data = _get_sbom_from_db(state)
    if not sbom_data:
        raise RuntimeError("SBOM not in DB cache — 'scan' step must complete first")

    # Restore purl_resolution_map from scan step result
    purl_resolution_map = {}
    try:
        _scan_result = state.get("steps", {}).get("scan", {}).get("result", {})
        _purl_raw = _scan_result.get("purl_resolutions", {})
        purl_resolution_map = {tuple(k.split(":", 1)): v for k, v in _purl_raw.items()}
    except Exception:
        pass

    _log.info("  Package health checks...")
    collector = PackageHealthCollector(
        sbom_data=sbom_data,
        purl_resolution_map=purl_resolution_map,
        repo_path=str(repo_path),
    )
    report = collector.collect()

    # Write in the same format as scan.py so pipeline_finalize has one canonical format.
    report_dict = report.to_dict()
    advisories = report.advisories if isinstance(report.advisories, list) else []
    with open(raw_dir / "health.json", "w", encoding="utf-8") as f:
        json.dump({"advisories": advisories, "summary": {"total_advisories": len(advisories)}}, f, indent=2, default=str)

    total = report_dict.get("total_packages", len(advisories))
    _log.info(f"  Health: {total} package(s) analyzed")
    return {"file": "raw/health.json", "packages_analyzed": total}


def _step_ai(repo_path: Path, session_dir: Path, args) -> Dict[str, Any]:
    """AI/LLM security scan (OWASP LLM Top 10 + MITRE ATLAS). No dependencies."""
    from reachable.ai import AIScanConfig, AISecurityScanner

    raw_dir = session_dir / "raw"
    raw_dir.mkdir(exist_ok=True)

    _log.info("  AI/LLM security scan...")
    scanner = AISecurityScanner(config=AIScanConfig.full())
    findings_list = list(scanner.scan(repo_path))

    by_owasp: Dict[str, int] = {}
    by_severity: Dict[str, int] = {"ERROR": 0, "WARNING": 0, "INFO": 0}
    for f in findings_list:
        cat = f.owasp_category or "OTHER"
        by_owasp[cat] = by_owasp.get(cat, 0) + 1
        by_severity[f.severity] = by_severity.get(f.severity, 0) + 1

    results = {
        "total": len(findings_list),
        "by_owasp": by_owasp,
        "by_severity": by_severity,
        "findings": [f.to_dict() for f in findings_list],
    }
    with open(raw_dir / "ai-security.json", "w", encoding="utf-8") as f:
        json.dump(results, f, indent=2, default=str)

    _log.info(f"  AI: {len(findings_list)} findings ({by_owasp})")
    return {"file": "raw/ai-security.json", "total": len(findings_list), "by_owasp": by_owasp}


def _step_dlp(repo_path: Path, session_dir: Path, args) -> Dict[str, Any]:
    """DLP/PII taint analysis. No dependencies."""
    from reachable.dlp import DLPScanConfig, DLPScanner

    raw_dir = session_dir / "raw"
    raw_dir.mkdir(exist_ok=True)

    _log.info("  DLP/PII taint scan...")
    scanner = DLPScanner(config=DLPScanConfig.full())
    scanner.scan(repo_path)
    stats = scanner.statistics

    results = {
        "total": stats.get("total_findings", 0),
        "discovery_findings": stats.get("discovery_findings", 0),
        "taint_findings": stats.get("taint_findings", 0),
        "ai_findings": stats.get("ai_findings", 0),
        "by_pii_type": stats.get("by_pii_type", {}),
        "by_severity": stats.get("by_severity", {}),
        "by_sink_type": stats.get("by_sink_type", {}),
        "findings": [f.to_dict() for f in scanner.findings],
    }
    with open(raw_dir / "dlp-security.json", "w", encoding="utf-8") as f:
        json.dump(results, f, indent=2, default=str)

    total = stats.get("total_findings", 0)
    _log.info(f"  DLP: {total} findings")
    return {"file": "raw/dlp-security.json", "total": total}


def _step_clone(repo_path: Path, session_dir: Path, state: Dict[str, Any], args) -> Dict[str, Any]:
    """Clone vulnerable library source code (MCP → npm-pack → git) for reachability analysis.
    Depends on: scan (needs grype-vulns.json).
    """
    from reachable.integrations.lib_manager import LibraryManager

    raw_dir = session_dir / "raw"
    vulns_file = raw_dir / "grype-vulns.json"
    if not vulns_file.exists():
        raise FileNotFoundError("grype-vulns.json not found — scan step must complete first")

    with open(vulns_file, encoding="utf-8") as f:
        vulns_data = json.load(f)

    libs_dir = session_dir / "libs"
    libs_dir.mkdir(exist_ok=True)

    # Build ScanContext for language-aware clone decisions (same as scan_repo path)
    scan_ctx = None
    try:
        from reachable.core.context import ScanContext
        scan_ctx = ScanContext(repo_path, session_dir)
    except Exception:
        pass

    # Restore purl_resolution_map from scan step result
    purl_resolutions = {}
    try:
        _scan_result = state.get("steps", {}).get("scan", {}).get("result", {})
        _purl_raw = _scan_result.get("purl_resolutions", {})
        purl_resolutions = {tuple(k.split(":", 1)): v for k, v in _purl_raw.items()}
    except Exception:
        pass

    _log.info("  Cloning vulnerable library source (MCP/npm-pack/git)...")
    manager = LibraryManager(libs_dir, scan_context=scan_ctx, purl_resolutions=purl_resolutions)
    with _heartbeat("Clone"):
        cloned_paths = manager.clone_vulnerable_libraries(vulns_data)

    metrics = manager.metrics
    n_cloned    = len(cloned_paths)
    attempted   = metrics.get("total_attempted", n_cloned)
    cache_ok    = metrics.get("cache_hits", 0)
    cache_miss  = metrics.get("cache_misses", 0)
    mcp_ok      = metrics.get("mcp_success", 0)
    mcp_fail    = metrics.get("mcp_failed", 0)
    npm_ok      = metrics.get("npm_pack_success", 0)
    npm_fail    = metrics.get("npm_pack_failed", 0)
    git_ok      = metrics.get("git_success", 0)
    git_fail    = metrics.get("git_failed", 0)
    failed      = metrics.get("total_failed", 0)
    obsolete    = metrics.get("obsolete_packages", [])
    clone_detail = metrics.get("clone_methods", [])  # [(pkg, method, success)]

    # Coverage gaps: packages we attempted but could not clone source for
    # These become call-graph blind spots — reachability analysis is degraded for them
    gaps = [pkg for pkg, method, success in clone_detail if not success]

    _log.info(
        f"  Clone: {n_cloned}/{attempted} libraries "
        f"(cache:{cache_ok} MCP:{mcp_ok} npm:{npm_ok} git:{git_ok} failed:{failed})"
    )
    if gaps:
        _log.info(f"  Coverage gaps (no source): {len(gaps)} packages — {gaps}")
    if obsolete:
        _log.info(f"  Obsolete (version missing): {len(obsolete)} — {[p if isinstance(p, str) else p.get('package','?') for p in obsolete]}")

    # Write raw/lib-cloning-metrics.json so dashboard loader and coverage tab can read it
    clone_metrics_data = {
        "attempted": attempted,
        "cloned": n_cloned,
        "cache_hits": cache_ok,
        "cache_misses": cache_miss,
        "mcp_success": mcp_ok,
        "mcp_failed": mcp_fail,
        "npm_pack_success": npm_ok,
        "npm_pack_failed": npm_fail,
        "git_success": git_ok,
        "git_failed": git_fail,
        "total_failed": failed,
        "coverage_gaps": gaps,
        "obsolete_packages": [
            p if isinstance(p, str) else p.get("package", str(p))
            for p in obsolete
        ],
    }
    raw_dir = session_dir / "raw"
    raw_dir.mkdir(exist_ok=True)
    try:
        with open(raw_dir / "lib-cloning-metrics.json", "w") as _f:
            json.dump(clone_metrics_data, _f, indent=2)
    except Exception as _e:
        _log.info(f"  lib-cloning-metrics.json write failed (non-fatal): {_e}")

    return {
        "libs_dir": str(libs_dir),
        "cloned": n_cloned,
        "mcp_success": mcp_ok,
        "npm_pack_success": npm_ok,
        "git_success": git_ok,
        "failed": failed,
        "coverage_gaps": gaps,
    }


# ---------------------------------------------------------------------------
# pipeline finalize
# ---------------------------------------------------------------------------

def pipeline_finalize(args) -> int:
    """Run reachability analysis, ingest raw/ files into DB, generate dashboard."""
    _debug = getattr(args, 'debug', False)
    session_dir = _resolve_session_dir(args.session)
    if not session_dir:
        _log.info(f"Error: Session not found: {args.session}")
        return 1

    state = load_pipeline_state(session_dir)
    if not state:
        _log.info("Error: Invalid session")
        return 1

    if state["steps"].get("scan", {}).get("status") != "complete":
        _log.info("Error: 'scan' step must complete before finalize")
        return 1

    repo_path = Path(state["repo_path"])
    db_path = Path(state.get("db_path", ""))
    scan_id = state.get("scan_id")

    if not db_path.exists():
        _log.info(f"Error: repo.db not found: {db_path}")
        return 1
    if not scan_id:
        _log.info("Error: scan_id missing from state — re-run pipeline init")
        return 1

    raw_dir = session_dir / "raw"
    raw_dir.mkdir(exist_ok=True)
    t0 = time.time()
    _log.info("  Finalizing pipeline...")

    # 0. JS callgraph (T-CG15) — must run before RA so analyzer picks up
    #    call-graph-js.json for npm CVE reachability (mirrors scan_repo path)
    if any((repo_path / f).exists() for f in ("package.json", "package-lock.json")):
        try:
            from reachable.collectors.callgraph.js_collector import JSCallGraphCollector
            _js_col = JSCallGraphCollector()
            if _js_col.is_available():
                _js_cg = _js_col.collect(
                    src_dir=repo_path,
                    output_dir=raw_dir,
                    commit_sha=state.get("commit") or "",
                )
                if _js_cg:
                    _log.info(f"  JS callgraph: {_js_col.tier} → {_js_cg.name}")
        except Exception as _js_err:
            if _debug:
                _log.info(f"  JS callgraph skipped: {_js_err}")

    # 1. Reachability analysis: grype-vulns.json → cve-analyzed.json
    _log.info("  Reachability analysis (call graph + CVE matching)...")
    grype_vulns = raw_dir / "grype-vulns.json"
    if not grype_vulns.exists():
        _log.info("Error: raw/grype-vulns.json missing — 'scan' step output not found")
        return 1

    sbom_data = _get_sbom_from_db(state)
    sbom_file: Optional[Path] = None
    tmp_sbom: Optional[Path] = None

    if sbom_data:
        fd, tmp_str = tempfile.mkstemp(suffix=".json", prefix="sbom-ra-")
        tmp_sbom = Path(tmp_str)
        sbom_file = tmp_sbom
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as f:
                json.dump(sbom_data, f)
        except Exception as e:
            _log.info(f"  Could not write temp SBOM: {e}")
            tmp_sbom = None
            sbom_file = None
    else:
        for c in [session_dir / "sbom.json.gz", session_dir / "sbom.json"]:
            if c.exists():
                sbom_file = c
                break

    if not sbom_file:
        _log.info("Error: No SBOM available for reachability analysis")
        return 1

    try:
        from reachable.engine.reachability import ReachabilityAnalyzer
        # Load AI findings produced by the 'ai' step (if it ran) so the
        # analyzer can enrich them with call-graph reachability before correlation.
        _ai_findings_for_analyzer = []
        _ai_raw = raw_dir / "ai-security.json"
        if _ai_raw.exists():
            try:
                with open(_ai_raw, encoding="utf-8") as _af:
                    _ai_data = json.load(_af)
                # Findings are plain dicts from to_dict(); analyzer accepts both dicts and AIFinding objects
                _ai_findings_for_analyzer = _ai_data.get("findings", [])
                _log.info(f"  Loaded {len(_ai_findings_for_analyzer)} AI findings for call-graph enrichment")
            except Exception as _ae:
                _log.info(f"  Could not load ai-security.json (non-fatal): {_ae}")

        # Load runtime fields (health advisories + sast-skipped) via ScanConfig.
        # Falls back to direct file read if .scan-config.json is absent (old sessions).
        _preloaded_health = None
        try:
            from reachable.core.scan_config import ScanConfig as _SC
            _cfg = _SC.load_or_none(session_dir)
            if _cfg is not None:
                _cfg.reload_runtime()
                _preloaded_health = _cfg.preloaded_health or None
                if _preloaded_health:
                    _log.info(f"  Loaded {len(_preloaded_health)} health advisories (ScanConfig)")
            else:
                raise FileNotFoundError("no .scan-config.json")
        except Exception:
            # Fallback for sessions created before ScanConfig existed
            _health_raw = raw_dir / "health.json"
            if _health_raw.exists():
                try:
                    _preloaded_health = json.loads(
                        _health_raw.read_text(encoding="utf-8")
                    ).get("advisories", [])
                    _log.info(f"  Loaded {len(_preloaded_health)} health advisories (fallback)")
                except Exception:
                    pass

        analyzer = ReachabilityAnalyzer(
            app_dir=repo_path,
            libs_dir=session_dir / "libs",
            sbom_file=sbom_file,
            vulns_file=grype_vulns,
            verbose=getattr(args, "debug", False),
            ai_findings=_ai_findings_for_analyzer,
            skip_malware=True,
            preloaded_health=_preloaded_health,
        )
        _ra_t0 = time.time()
        with _heartbeat("Reachability analysis"):
            ra_results = analyzer.analyze()
        _ra_elapsed = time.time() - _ra_t0
        _log.info(f"  Call graph done ({_ra_elapsed:.1f}s)")
        with open(raw_dir / "cve-analyzed.json", "w", encoding="utf-8") as f:
            json.dump(ra_results, f, indent=2, default=str)
        _log.info("  cve-analyzed.json written")

        # 1b. AI reachability enrichment — enrich AI findings with call-graph data
        #     then overwrite ai-security.json so ingester gets enriched versions
        if _ai_findings_for_analyzer:
            try:
                from reachable.ai.ai_reachability_integration import integrate_ai_reachability
                _cg_data = ra_results.get("call_graph", {})
                _rf = set(_cg_data.get("reachable_functions", []))
                _adj = _cg_data.get("adjacency", {})
                _eps = set(_cg_data.get("entrypoints", []))
                if _rf:
                    _enriched_ai, _ai_sum = integrate_ai_reachability(
                        findings=_ai_findings_for_analyzer,
                        call_graph=_adj,
                        reachable_functions=_rf,
                        entrypoints=_eps,
                        repo_path=repo_path,
                    )
                    # Overwrite ai-security.json with enriched findings so ingester reads them
                    _ai_out_data = {"total": len(_enriched_ai), "findings": [
                        f.to_dict() if hasattr(f, "to_dict") else f for f in _enriched_ai
                    ]}
                    with open(raw_dir / "ai-security.json", "w", encoding="utf-8") as _af:
                        json.dump(_ai_out_data, _af, indent=2, default=str)
                    if _debug:
                        _log.info(f"  AI enrichment: {_ai_sum.get('reachable_findings', 0)} reachable, "
                                    f"{_ai_sum.get('guarded_findings', 0)} guarded")
            except Exception as _ai_enr_err:
                if _debug:
                    _log.info(f"  AI enrichment skipped: {_ai_enr_err}")

        # 1c. Dynamic malware sandbox — runs after RA, writes raw/sandbox.json
        #     for ingester (mirrors scan_repo path, same TTL logic)
        _sandbox_results = None
        try:
            from reachable.cli.sandbox import run_sandbox_analysis as run_dynamic_malware_sandbox
            from reachable.core.config import get_sandbox_ttl_hours as _get_ttl
            _sbom_for_sandbox = sbom_file  # still in scope (temp file not yet unlinked)
            with _heartbeat("Sandbox"):
                _sandbox_results = run_dynamic_malware_sandbox(
                    _sbom_for_sandbox,
                    raw_dir,
                    repo_dir=repo_path,
                    cache_ttl_hours=_get_ttl(),
                )
            if _sandbox_results:
                _sb_verdict = _sandbox_results.get("verdict", "N/A")
                _sb_findings = len(_sandbox_results.get("findings", []))
                _log.info(f"  Sandbox: verdict={_sb_verdict}, {_sb_findings} finding(s)")
                # Write to disk so ingester can pick it up
                _sandbox_out = raw_dir / "sandbox.json"
                with open(_sandbox_out, "w", encoding="utf-8") as _sf:
                    json.dump(_sandbox_results, _sf, indent=2)
        except Exception as _sb_err:
            if _debug:
                _log.info(f"  Sandbox skipped: {_sb_err}")

    finally:
        if tmp_sbom:
            try:
                tmp_sbom.unlink()
            except OSError:
                pass

    # 1b. Load call-graph.json written by analyzer (vulns_file.parent = raw/)
    #     so the ingester can use it for CWE entrypoint enrichment.
    call_graph = None
    for cg_name in ["call-graph.json", "call-graph-js.json"]:
        cg_path = raw_dir / cg_name
        if cg_path.exists():
            try:
                with open(cg_path, encoding="utf-8") as _cgf:
                    call_graph = json.load(_cgf)
                _log.info(f"  call-graph loaded ({cg_name}) for CWE enrichment")
                break
            except Exception as _cge:
                _log.info(f"  call-graph load failed ({cg_name}): {_cge}")

    # 2. Ingest all raw/ files into DB (single write pass)
    _log.info("  Ingesting into database...")
    from reachable.database.ingester import ingest as ingest_to_db
    from reachable.database.storage import RepoDatabase

    db = RepoDatabase(db_path)
    db._current_scan_id = scan_id

    # call_graph already loaded above (from raw/call-graph.json written by analyzer)
    # Pass it to ingester so CWE findings get entrypoint-path enrichment.

    ingest_result = ingest_to_db(
        scan_dir=session_dir,
        db=db,
        scan_id=scan_id,
        call_graph=call_graph,
        skip_iac=getattr(args, "skip_iac", False),
    )
    _breakdown = []
    if ingest_result.cve_count:      _breakdown.append(f"{ingest_result.cve_count} CVE")
    if ingest_result.cwe_count:      _breakdown.append(f"{ingest_result.cwe_count} CWE")
    if ingest_result.secret_count:   _breakdown.append(f"{ingest_result.secret_count} secret")
    if ingest_result.malware_count:  _breakdown.append(f"{ingest_result.malware_count} malware")
    if ingest_result.suspicious_count: _breakdown.append(f"{ingest_result.suspicious_count} suspicious")
    if ingest_result.ai_count:       _breakdown.append(f"{ingest_result.ai_count} AI")
    if ingest_result.dlp_count:      _breakdown.append(f"{ingest_result.dlp_count} DLP")
    if ingest_result.config_count:   _breakdown.append(f"{ingest_result.config_count} config")
    _log.info(f"  Ingested: {ingest_result.total} findings ({', '.join(_breakdown)})")

    # 3. Package health (separate table, not via ingester)
    # health.json may be written by _step_health (concurrent: raw list)
    # or by scan.py/run_reachability_analysis (serial: dict with 'advisories' key).
    # Handle both formats.  Any failure here is an error — raise loudly.
    health_file = raw_dir / "health.json"
    if health_file.exists():
        import types as _types
        try:
            with open(health_file, encoding="utf-8") as _hf:
                raw = json.load(_hf)
        except (OSError, json.JSONDecodeError) as e:
            raise RuntimeError(f"health.json unreadable: {e}") from e
        advisories = raw["advisories"]
        if not isinstance(advisories, list):
            raise RuntimeError(f"health.json advisories is not a list: {type(advisories)}")
        if advisories:
            proxy = _types.SimpleNamespace(advisories=advisories)
            stored = db.store_package_health(proxy)
            _log.info(f"  Package health: {stored} advisories stored")
        else:
            _log.info("  Package health: 0 advisories")
    else:
        _log.info("  Package health: health.json not found — step may not have run")

    # 4. Complete scan record
    _calc_risk_score, _calc_risk_level = _calculate_risk(ingest_result)

    try:
        from reachable.collectors.vulns.purl_resolver import PURLResolver
        sbom_for_purl = _get_sbom_from_db(state)
        if sbom_for_purl:
            fd2, tmp2 = tempfile.mkstemp(suffix=".json", prefix="sbom-purl-")
            tmp2_p = Path(tmp2)
            try:
                with os.fdopen(fd2, "w") as f:
                    json.dump(sbom_for_purl, f)
                unresolved = PURLResolver().persist_unresolved(tmp2_p, db=db)
                if unresolved:
                    _log.info(f"  PURL: {len(unresolved)} unresolved tracked")
            finally:
                try:
                    tmp2_p.unlink()
                except OSError:
                    pass
    except Exception as e:
        _log.info(f"  PURL resolution skipped: {e}")

    db.complete_scan(
        duration_seconds=time.time() - t0,
        risk_score=_calc_risk_score,
        risk_level=_calc_risk_level,
    )
    # Read back the risk level complete_scan() actually stored (includes AI/DLP enrichments)
    try:
        _row = db.conn.execute(
            "SELECT risk_score, risk_level FROM scans WHERE id = ?",
            (scan_id,)
        ).fetchone()
        _rs = _row[0] if _row else None
        _rl = _row[1] if _row else None
        risk_score = int(_rs) if isinstance(_rs, (int, float)) else _calc_risk_score
        risk_level = str(_rl) if isinstance(_rl, str) else _calc_risk_level
    except Exception:
        risk_score, risk_level = _calc_risk_score, _calc_risk_level
    db.cleanup_old_scans()

    # 4b. Coverage gap analysis — runs after DB is written, before dashboard
    try:
        from reachable.analysis.coverage import run_coverage_analysis, store_coverage_report

        # Gather callgraph packages from cve-analyzed.json
        _cg_pkgs = None
        _cva_path = raw_dir / "cve-analyzed.json"
        if _cva_path.exists():
            try:
                with open(_cva_path, encoding="utf-8") as _cvf:
                    _cva = json.load(_cvf)
                _cg_pkgs = set()
                for _section in ("reachable", "unreachable"):
                    for _cve_data in _cva.get(_section, {}).values():
                        _pkg = (_cve_data.get("package") or _cve_data.get("package_name") or "").split(" ")[0]
                        if _pkg:
                            _cg_pkgs.add(_pkg)
            except Exception:
                pass

        # Load SBOM from DB (already cached)
        _sbom_data = _get_sbom_from_db(state) or {}

        # Load findings from DB for reachability gap analysis
        import sqlite3 as _csql
        _cconn = _csql.connect(str(db_path))
        _cconn.row_factory = _csql.Row
        _ccur = _cconn.cursor()
        _ccur.execute(
            "SELECT finding_type, id, package_name, package_version, severity, app_reachability "
            "FROM findings WHERE scan_id = ?",
            (scan_id,),
        )
        _db_findings = [
            {"finding_type": r["finding_type"], "id": r["id"],
             "package_name": r["package_name"] or "", "version": r["package_version"] or "",
             "severity": r["severity"] or "UNKNOWN", "app_reachability": r["app_reachability"] or "UNKNOWN"}
            for r in _ccur.fetchall()
        ]
        _cconn.close()

        # Scanned manifests — walk full repo tree (same as scan.py Fix #2)
        _manifest_names = {
            "go.mod", "package.json", "package-lock.json", "requirements.txt",
            "pyproject.toml", "setup.py", "Pipfile", "Cargo.toml", "pom.xml",
            "build.gradle", "build.gradle.kts", "Gemfile", "composer.json",
            "Package.swift", "Cargo.lock",
        }
        _MANIFEST_SKIP = {
            ".git", ".hg", ".svn", "node_modules", "vendor", "third_party",
            "third-party", ".venv", "venv", "env", "build", "dist", "target",
            "__pycache__", ".tox", ".nox", "site-packages", "dist-packages",
        }
        _scanned_manifests = []
        import os as _os_mfst
        for _dirpath, _dirnames, _fnames in _os_mfst.walk(str(repo_path)):
            _dirnames[:] = [
                d for d in _dirnames
                if d not in _MANIFEST_SKIP and not d.startswith(".")
            ]
            for _fname in _fnames:
                if _fname in _manifest_names:
                    _rel = _os_mfst.path.relpath(
                        _os_mfst.path.join(_dirpath, _fname), str(repo_path)
                    )
                    _scanned_manifests.append(_rel)

        # If the secrets step ran, Semgrep p/default covered all detected
        # languages — tell the coverage analyzer so it doesn't report gaps.
        _secrets_done = state.get("steps", {}).get("secrets", {}).get("status") == "complete"
        _ALL_SEMGREP_LANGS = ["python", "javascript", "go", "java", "rust", "ruby", "dotnet", "php"]
        _analyzed_langs = _ALL_SEMGREP_LANGS if _secrets_done else []

        # Load SAST-skipped files via ScanConfig (already reloaded above).
        # Falls back to direct file read for old sessions without .scan-config.json.
        _sast_skipped: List[Dict] = []
        try:
            from reachable.core.scan_config import ScanConfig as _SC2
            _cfg2 = _SC2.load_or_none(session_dir)
            if _cfg2 is not None:
                _cfg2.reload_runtime()
                _sast_skipped = _cfg2.sast_skipped or []
                if _sast_skipped:
                    _log.info(f"  Coverage: {len(_sast_skipped)} SAST-skipped file(s) (ScanConfig)")
            else:
                raise FileNotFoundError("no .scan-config.json")
        except Exception:
            _sast_skipped_path = raw_dir / "sast-skipped.json"
            if _sast_skipped_path.exists():
                try:
                    _sast_skipped = json.loads(
                        _sast_skipped_path.read_text(encoding="utf-8")
                    ).get("skipped", [])
                    if _sast_skipped:
                        _log.info(f"  Coverage: {len(_sast_skipped)} SAST-skipped file(s) (fallback)")
                except (OSError, json.JSONDecodeError) as _sse:
                    _log.info(f"  sast-skipped.json unreadable (non-fatal): {_sse}")

        coverage_report = run_coverage_analysis(
            project_path=str(repo_path),
            scan_id=str(scan_id),
            metadata_dir=str(session_dir / ".metadata"),
            sbom_data=_sbom_data,
            findings=_db_findings,
            callgraph_packages=_cg_pkgs,
            scanned_manifests=_scanned_manifests,
            analyzed_languages=_analyzed_langs,
            sast_skipped_files=_sast_skipped,
        )

        store_coverage_report(db.conn, str(scan_id), coverage_report)

        _score_pct = round(coverage_report.get("coverage_score", 0) * 100)
        _gap_count = (
            len(coverage_report.get("languages", {}).get("gaps", []))
            + len(coverage_report.get("reachability_blind_spots", []))
            + len(coverage_report.get("sub_modules", []))
        )
        _log.info(f"  Coverage: {_score_pct}% | {_gap_count} gap(s) | "
                             f"{len(coverage_report.get('recommendations', []))} recommendations")
    except ImportError as _cov_imp:
        _log.info(f"  Coverage module unavailable: {_cov_imp}")
    except Exception as _cov_err:
        import traceback
        _log.info(f"  Coverage analysis failed: {_cov_err}")
        _log.info(traceback.format_exc())

    db.close()

    # 5. Generate dashboard from DB
    _log.info("  Generating dashboard...")
    from reachable.dashboard_v2.generator import DashboardV2Generator
    generator = DashboardV2Generator()
    dashboard_dir = generator.generate_from_scan_dir(session_dir)
    state["status"] = "complete"
    state["completed_at"] = datetime.now().isoformat()
    state["duration_seconds"] = round(time.time() - t0, 2)
    state["risk_score"] = risk_score
    state["risk_level"] = risk_level
    state["dashboard"] = str(dashboard_dir)
    save_pipeline_state(session_dir, state)

    duration = time.time() - t0
    if getattr(args, "json", False):
        _log.info(json.dumps({
            "status": "complete", "duration": round(duration, 2),
            "risk_score": risk_score, "risk_level": risk_level,
            "dashboard": str(dashboard_dir),
            "findings": {"cve": ingest_result.cve_count, "cwe": ingest_result.cwe_count,
                         "secret": ingest_result.secret_count, "malware": ingest_result.malware_count,
                         "total": ingest_result.total},
        }))
    else:
        # ── Per-signal actionable + noise from DB ───────────────────────
        _sig_label = {"CVE": "CVE", "CWE": "CWE", "SECRET": "Secrets",
                      "MALWARE": "Malware", "AI": "AI", "DLP": "DLP", "CONFIG": "Config"}
        _actionable: dict = {}
        _noise: dict = {}
        _total_by_sig: dict = {}   # initialised before try so UnboundLocalError can't fire
        try:
            import sqlite3 as _psql
            _pc = _psql.connect(str(db_path))
            _pc.row_factory = _psql.Row
            _rows = _pc.execute(
                "SELECT finding_type, app_reachability, COUNT(*) as n "
                "FROM findings WHERE scan_id=? "
                "GROUP BY finding_type, app_reachability",
                (scan_id,)
            ).fetchall()
            for _r in _rows:
                _ft = (_r["finding_type"] or "").upper()
                _st = (_r["app_reachability"] or "").upper()
                _n  = _r["n"]
                _total_by_sig[_ft] = _total_by_sig.get(_ft, 0) + _n
                if _st in ("REACHABLE", "UNKNOWN"):
                    _actionable[_ft] = _actionable.get(_ft, 0) + _n
                elif _st in ("NOT_APPLICABLE", "NOT_REACHABLE"):
                    _noise[_ft] = _noise.get(_ft, 0) + _n
            # AI and DLP live in separate tables with is_reachable bool
            for _tbl, _key in (("ai_findings", "AI"), ("dlp_findings", "DLP")):
                try:
                    _xrows = _pc.execute(
                        f"SELECT is_reachable, COUNT(*) as n FROM {_tbl} WHERE scan_id=? GROUP BY is_reachable",
                        (scan_id,)
                    ).fetchall()
                    for _xr in _xrows:
                        _n = _xr["n"]
                        _total_by_sig[_key] = _total_by_sig.get(_key, 0) + _n
                        if _xr["is_reachable"]:
                            _actionable[_key] = _actionable.get(_key, 0) + _n
                        else:
                            _noise[_key] = _noise.get(_key, 0) + _n
                except Exception:
                    pass
            _pc.close()
        except Exception:
            pass

        # Compute sandbox dynamic counts here (in scope) and pass in
        _sb_dyn_confirmed  = 0
        _sb_dyn_suspicious = 0
        if _sandbox_results:
            _sb_s = _sandbox_results.get("summary", {})
            _sb_dyn_confirmed  = len(_sandbox_results.get("malicious_packages", [])) or _sb_s.get("malicious", 0)
            _sb_dyn_suspicious = len(_sandbox_results.get("suspicious_packages", [])) or _sb_s.get("suspicious", 0)

        _print_pipeline_scan_complete(
            db_path=db_path,
            scan_id=scan_id,
            state=state,
            session_dir=session_dir,
            dashboard_dir=dashboard_dir,
            repo_path=repo_path,
            risk_score=risk_score,
            risk_level=risk_level,
            pipeline_start=t0,
            debug=_debug,
            skip_timing=getattr(args, 'skip_timing', False),
            sandbox_dynamic_confirmed=_sb_dyn_confirmed,
            sandbox_dynamic_suspicious=_sb_dyn_suspicious,
        )

    # Prefer ScanConfig.fail_on (has CI auto-escalation) over raw args
    try:
        from reachable.core.scan_config import ScanConfig as _SC3
        _cfg3 = _SC3.load_or_none(session_dir)
        fail_on = _cfg3.fail_on if _cfg3 is not None else getattr(args, "fail_on", "none")
    except Exception:
        fail_on = getattr(args, "fail_on", "none")
    if fail_on != "none":
        return _check_fail_threshold(ingest_result, fail_on, db_path, scan_id,
                                     raw_dir=raw_dir)
    return 0


# ---------------------------------------------------------------------------
# pipeline status
# ---------------------------------------------------------------------------

def pipeline_status(args) -> int:
    session_dir = _resolve_session_dir(args.session)
    if not session_dir:
        _log.info(f"Error: Session not found: {args.session}")
        return 1
    state = load_pipeline_state(session_dir)
    if not state:
        _log.info("Error: Invalid session")
        return 1
    if getattr(args, "json", False):
        _log.info(json.dumps(state, indent=2))
        return 0
    _log.info(f"Pipeline: {state['session_id']}")
    _log.info(f"Repo:     {state.get('repo_name', '?')}")
    _log.info(f"Status:   {state['status']}")
    _log.info(f"Created:  {state['created_at']}")
    _log.info("Steps:")
    for sn, si in state["steps"].items():
        st = si.get("status", "unknown")
        icon = {"pending": "○", "running": "◉", "complete": "✓", "failed": "✗"}.get(st, "?")
        dur = si.get("duration_seconds", "")
        dur_s = f" ({dur}s)" if dur else ""
        _log.info(f"  {icon} {sn:<12} {st}{dur_s}")
    return 0


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _resolve_session_dir(session: str) -> Optional[Path]:
    if not session:
        return None
    p = Path(session)
    if p.exists() and p.is_dir():
        return p
    scans_dir = Path.home() / ".reachable" / "scans"
    if scans_dir.exists():
        for repo_dir in scans_dir.iterdir():
            if not repo_dir.is_dir():
                continue
            for branch_dir in repo_dir.iterdir():
                if not branch_dir.is_dir():
                    continue
                c = branch_dir / session
                if c.exists():
                    return c
    return None


def _get_git_context(repo_path: Path):
    """Read branch and commit directly from .git — no subprocess."""
    branch, commit = "unknown", None
    git_dir = repo_path / ".git"
    if not git_dir.is_dir():
        return branch, commit
    try:
        head = (git_dir / "HEAD").read_text(encoding="utf-8").strip()
        if head.startswith("ref: refs/heads/"):
            branch = head[len("ref: refs/heads/"):]
            ref_file = git_dir / "refs" / "heads" / branch
            if ref_file.exists():
                commit = ref_file.read_text(encoding="utf-8").strip() or None
            else:
                # Packed refs — scan packed-refs
                packed = git_dir / "packed-refs"
                if packed.exists():
                    prefix = f"refs/heads/{branch}"
                    for line in packed.read_text(encoding="utf-8").splitlines():
                        if line.endswith(prefix) and not line.startswith("^"):
                            commit = line.split()[0]
                            break
        else:
            # Detached HEAD — value is the commit hash itself
            commit = head if len(head) == 40 else None
    except Exception:
        pass
    return branch, commit


def _get_sbom_from_db(state: Dict[str, Any]) -> Optional[Dict]:
    db_path_str = state.get("db_path", "")
    commit = state.get("commit", "")
    if not db_path_str or not commit:
        return None
    db_path = Path(db_path_str)
    if not db_path.exists():
        return None
    try:
        from reachable.database.storage import RepoDatabase
        db = RepoDatabase(db_path)
        sbom = db.get_cached_sbom(commit)
        db.close()
        return sbom
    except Exception as e:
        _log.info(f"SBOM DB cache read failed: {e}")
        return None


def _count_by_severity(matches: list) -> Dict[str, int]:
    counts: Dict[str, int] = {"CRITICAL": 0, "HIGH": 0, "MEDIUM": 0, "LOW": 0, "UNKNOWN": 0}
    for m in matches:
        sev = (m.get("vulnerability", {}).get("severity") or "UNKNOWN").upper()
        counts[sev] = counts.get(sev, 0) + 1
    return counts


def _merge_sast_skipped(raw_dir: Path, new_entries: List[Dict]) -> None:
    """Merge new sast-skipped entries into raw/sast-skipped.json.

    Multiple pipeline steps (secrets, malware) may encounter unparseable
    files independently.  This helper merges them into a single deduplicated
    list keyed on file path so finalize has one place to read from.

    File format: {"skipped": [{"path": ..., "reason": ..., "scan": ...}, ...]}
    """
    skipped_path = raw_dir / "sast-skipped.json"
    existing: List[Dict] = []
    if skipped_path.exists():
        try:
            data = json.loads(skipped_path.read_text(encoding="utf-8"))
            existing = data.get("skipped", [])
        except (OSError, json.JSONDecodeError):
            existing = []

    # Deduplicate by path — first entry for a given path wins
    seen = {e["path"] for e in existing}
    for entry in new_entries:
        if entry.get("path") and entry["path"] not in seen:
            seen.add(entry["path"])
            existing.append(entry)

    try:
        skipped_path.write_text(
            json.dumps({"skipped": existing}, indent=2),
            encoding="utf-8",
        )
    except OSError as e:
        _log.info(f"  sast-skipped.json write failed (non-fatal): {e}")


def _find_package_dirs(repo_path: Path, names: set, max_depth: int = 4) -> list:
    """Return all subdirs of repo_path whose name is in *names*, up to max_depth levels deep.

    Covers the common layouts:
      ./node_modules/          (depth 1)
      ./packages/              (depth 1)
      ./venv/lib/python3.x/site-packages/  (depth 3-4)
    """
    found = []
    def _walk(path: Path, depth: int) -> None:
        if depth > max_depth:
            return
        try:
            for child in path.iterdir():
                if child.is_dir():
                    if child.name in names:
                        found.append(child)
                    else:
                        _walk(child, depth + 1)
        except PermissionError:
            pass
    _walk(repo_path, 1)
    return found


def _calculate_risk(ingest_result) -> tuple:
    score = (ingest_result.cve_count * 10 + ingest_result.cwe_count * 3 +
             ingest_result.secret_count * 5 + ingest_result.malware_count * 20)
    if score >= 200: return score, "CRITICAL"
    if score >= 100: return score, "HIGH"
    if score >= 50:  return score, "MEDIUM"
    if score > 0:    return score, "LOW"
    return 0, "NONE"


def _check_fail_threshold(ingest_result, fail_on: str, db_path: Path, scan_id: int,
                          raw_dir: Optional[Path] = None) -> int:
    """Gate CI exit code on finding severity.

    CICD-FIX-01: Use RiskEngine verdicts from cve-analyzed.json as the
    authoritative severity source, not findings.severity in the DB.

    Background
    ----------
    The DB findings table stores severity written by normalize_cves(), which
    uses a simplified 6-branch rule (CVSS severity × reachability only).
    RiskEngine._determine_risk_level() has 12 branches and additionally
    considers KEV, Metasploit modules, Exploit-DB, and EPSS scores.

    Concrete divergence examples
    ----------------------------
    • CVE reachable + in CISA KEV:
        DB severity  = HIGH  (CVSS 7.9 × REACHABLE → HIGH via normalizer)
        RiskEngine   = CRITICAL  (reachable + KEV → CRITICAL, 1-48h SLA)
        --fail-on high would NOT trigger from DB but SHOULD.

    • CVE unreachable + in CISA KEV:
        DB severity  = MEDIUM  (CVSS 7.9 × NOT_REACHABLE → MEDIUM via normalizer)
        RiskEngine   = LOW, MONITOR  (unreachable + KEV → verify manually)
        --fail-on medium WOULD trigger from DB but SHOULD NOT.

    Fix
    ---
    1. Load cve-analyzed.json (written by ReachabilityAnalyzer.analyze() in
       finalize before this function is called).
    2. For each CVE, read verdict["level"]: 1=CRITICAL 2=HIGH 3=MEDIUM 4=LOW 5=INFO.
    3. Count CVEs whose RiskEngine verdict level is at or above the threshold.
    4. Fall back to the old DB query only if cve-analyzed.json is unavailable
       (e.g. reachability step failed), so --fail-on still does something useful.

    Non-CVE findings (secrets, CWE, malware) are unchanged: they have no
    RiskEngine verdict so we continue to count them from the DB as before.
    """
    if fail_on == "any" and ingest_result.total > 0:
        return 1

    # RiskLevel enum values: CRITICAL=1, HIGH=2, MEDIUM=3, LOW=4, INFO=5
    threshold_level = {"critical": 1, "high": 2, "medium": 3}.get(fail_on)
    if threshold_level is None:
        return 0

    # ------------------------------------------------------------------
    # Path 1: RiskEngine verdicts from cve-analyzed.json (preferred)
    # ------------------------------------------------------------------
    if raw_dir is not None:
        cve_analyzed = raw_dir / "cve-analyzed.json"
        if cve_analyzed.exists():
            try:
                with open(cve_analyzed, encoding="utf-8") as f:
                    report = json.load(f)

                cve_count = 0
                for bucket in ("reachable", "unreachable"):
                    for cve_id, cve_data in report.get(bucket, {}).items():
                        verdict = cve_data.get("verdict", {})
                        level = verdict.get("level")
                        # level is an int (RiskLevel.value): 1=CRITICAL … 5=INFO
                        # A CVE breaches the threshold when its level <= threshold_level
                        # (lower int = higher severity)
                        if isinstance(level, int) and level <= threshold_level:
                            cve_count += 1

                # Non-CVE findings: secrets, CWE, malware — count from DB
                non_cve_count = 0
                sevs_str = {1: ("CRITICAL",), 2: ("CRITICAL", "HIGH"),
                            3: ("CRITICAL", "HIGH", "MEDIUM")}[threshold_level]
                try:
                    from reachable.database.storage import RepoDatabase
                    db = RepoDatabase(db_path)
                    db._current_scan_id = scan_id
                    ph = ",".join("?" * len(sevs_str))
                    cur = db.conn.cursor()
                    # Exclude CVE findings — they are gated via RiskEngine above
                    cur.execute(
                        f"SELECT COUNT(*) FROM findings "
                        f"WHERE scan_id=? AND UPPER(severity) IN ({ph}) "
                        f"AND finding_type != 'cve'",
                        (scan_id, *sevs_str),
                    )
                    non_cve_count = cur.fetchone()[0]
                    db.close()
                except Exception:
                    pass  # non-fatal — CVE gate already correct

                total = cve_count + non_cve_count
                _log.info(
                    f"  Threshold check (--fail-on {fail_on}): "
                    f"{cve_count} CVE(s) via RiskEngine + "
                    f"{non_cve_count} non-CVE finding(s) via DB = {total} total"
                )
                return 1 if total > 0 else 0

            except Exception as e:
                _log.info(
                    f"  cve-analyzed.json verdict read failed ({e}), "
                    f"falling back to DB severity"
                )

    # ------------------------------------------------------------------
    # Path 2: Fallback — DB findings.severity (old behaviour)
    # Reached only if cve-analyzed.json is missing or unreadable.
    # ------------------------------------------------------------------
    _log.info(
        "  CICD-FIX-01 fallback: using DB findings.severity for threshold check. "
        "RiskEngine enrichments (KEV, Metasploit, EPSS) are NOT reflected."
    )
    sevs = {1: ("CRITICAL",), 2: ("CRITICAL", "HIGH"),
            3: ("CRITICAL", "HIGH", "MEDIUM")}[threshold_level]
    try:
        from reachable.database.storage import RepoDatabase
        db = RepoDatabase(db_path)
        db._current_scan_id = scan_id
        ph = ",".join("?" * len(sevs))
        cur = db.conn.cursor()
        cur.execute(
            f"SELECT COUNT(*) FROM findings WHERE scan_id=? AND UPPER(severity) IN ({ph})",
            (scan_id, *sevs),
        )
        count = cur.fetchone()[0]
        db.close()
        return 1 if count > 0 else 0
    except Exception:
        return 0


# ---------------------------------------------------------------------------
# Full scan summary for pipeline mode
# Replicates the scan_repo() summary: TIMING + SCAN COMPLETE table + risk
# ---------------------------------------------------------------------------

def _print_pipeline_scan_complete(
    db_path: Path,
    scan_id,
    state: dict,
    session_dir: Path,
    dashboard_dir: Path,
    repo_path: Path,
    risk_score: int,
    risk_level: str,
    pipeline_start: float,
    debug: bool = False,
    skip_timing: bool = False,
    sandbox_dynamic_confirmed: int = 0,
    sandbox_dynamic_suspicious: int = 0,
) -> None:
    """Print the full REACHABLE scan summary (timing + signal table + severity + risk).
    Matches the output produced by scan_repo() in scan.py.
    """

    from reachable.core.logger import OutputMode, get_logger
    scan_log = get_logger()

    # Minimally configure so print methods have a sane state
    scan_log._mode = OutputMode.HUMAN
    scan_log._timestamps = False
    scan_log._debug = debug
    scan_log._quiet = False

    # Reconstruct phase timings from pipeline step durations
    # Map: pipeline step → (phase_num, display_name)
    _step_phase_map = {
        "scan":    (1, "SBOM + Vuln Scan",   "Syft + Grype"),
        "clone":   (3, "Library Cloning",    "MCP/Git"),
        "dlp":     (5, "DLP/PII Analysis",   "DLP"),
    }
    # Parallel steps (secrets/malware/iac/health/ai) collapse into phase 4
    _parallel_steps = {"secrets", "malware", "iac", "health", "ai"}
    _parallel_total = 0.0
    scan_log._phase_timings = {}
    step_states = state.get("steps", {})
    for _sname, _pinfo in _step_phase_map.items():
        _pnum, _pname, _pscanner = _pinfo
        _sdur = step_states.get(_sname, {}).get("duration_seconds", 0.0) or 0.0
        scan_log._phase_timings[_pnum] = {
            "name": _pname, "scanner": _pscanner,
            "start": 0.0, "end": _sdur, "elapsed": _sdur,
        }
    for _sname in _parallel_steps:
        _sdur = step_states.get(_sname, {}).get("duration_seconds", 0.0) or 0.0
        _parallel_total = max(_parallel_total, _sdur)  # wall time is max (parallel)
    if _parallel_total > 0:
        scan_log._phase_timings[4] = {
            "name": "Security Analysis", "scanner": "Multi-Signal",
            "start": 0.0, "end": _parallel_total, "elapsed": _parallel_total,
        }

    # Set scan_start_time so total time calculation works
    # Use pipeline creation time if available, else pipeline_start
    _created_at_str = state.get("created_at", "")
    try:
        from datetime import datetime as _dt
        _created = _dt.fromisoformat(_created_at_str).timestamp()
        scan_log._scan_start_time = _created
    except Exception:
        scan_log._scan_start_time = pipeline_start

    # ── DB query — identical to scan_repo() block ───────────────────────────────────
    _db_counts: dict = {}
    _db_all_sev: dict = {}
    _db_reach_sev: dict = {}
    _db_unkn_sev: dict = {}
    _sev_levels = ("CRITICAL", "HIGH", "MEDIUM", "LOW")

    def _norm_sev(s):
        s = (s or "MEDIUM").upper()
        if s == "ERROR":   return "CRITICAL"
        if s == "WARNING": return "MEDIUM"
        if s == "INFO":    return "LOW"
        return s if s in _sev_levels else "MEDIUM"

    try:
        import sqlite3 as _sql
        _conn = _sql.connect(str(db_path))
        _conn.row_factory = _sql.Row
        _cur = _conn.cursor()
        _cur.execute(
            "SELECT finding_type, app_reachability, severity, COUNT(*) as cnt "
            "FROM findings WHERE scan_id=? GROUP BY finding_type, app_reachability, severity",
            (scan_id,),
        )
        for row in _cur.fetchall():
            ft   = row["finding_type"].lower()
            reach = (row["app_reachability"] or "UNKNOWN").upper()
            sev  = _norm_sev(row["severity"])
            cnt  = row["cnt"]
            if ft not in _db_counts:
                _db_counts[ft] = {"total": 0, "reachable": 0, "unreachable": 0, "unknown": 0}
            _db_counts[ft]["total"] += cnt
            if reach == "REACHABLE":      _db_counts[ft]["reachable"] += cnt
            elif reach == "NOT_REACHABLE": _db_counts[ft]["unreachable"] += cnt
            else:                          _db_counts[ft]["unknown"] += cnt
            _db_all_sev.setdefault(ft, {})
            _db_all_sev[ft][sev] = _db_all_sev[ft].get(sev, 0) + cnt
            if reach == "REACHABLE":
                _db_reach_sev.setdefault(ft, {})
                _db_reach_sev[ft][sev] = _db_reach_sev[ft].get(sev, 0) + cnt
            elif reach not in ("NOT_REACHABLE", "NOT_APPLICABLE"):
                _db_unkn_sev.setdefault(ft, {})
                _db_unkn_sev[ft][sev] = _db_unkn_sev[ft].get(sev, 0) + cnt
        for _tbl, _key in (("ai_findings", "ai"), ("dlp_findings", "dlp")):
            try:
                _cur.execute(
                    f"SELECT is_reachable, severity, COUNT(*) as cnt "
                    f"FROM {_tbl} WHERE scan_id=? GROUP BY is_reachable, severity",
                    (scan_id,),
                )
                _db_counts.setdefault(_key, {"total": 0, "reachable": 0, "unreachable": 0, "unknown": 0})
                for row in _cur.fetchall():
                    sev = _norm_sev(row["severity"])
                    cnt = row["cnt"]
                    _db_counts[_key]["total"] += cnt
                    if row["is_reachable"]:
                        _db_counts[_key]["reachable"] += cnt
                    else:
                        _db_counts[_key]["unreachable"] += cnt
                    _db_all_sev.setdefault(_key, {})
                    _db_all_sev[_key][sev] = _db_all_sev[_key].get(sev, 0) + cnt
                    if row["is_reachable"]:
                        _db_reach_sev.setdefault(_key, {})
                        _db_reach_sev[_key][sev] = _db_reach_sev[_key].get(sev, 0) + cnt
                    else:
                        _db_unkn_sev.setdefault(_key, {})
                        _db_unkn_sev[_key][sev] = _db_unkn_sev[_key].get(sev, 0) + cnt
            except _sql.OperationalError:
                pass
        _conn.close()
    except Exception as _dbe:
        if debug:
            _log.info(f"  Summary DB query failed: {_dbe}")

    def _gc(sig):
        return _db_counts.get(sig, {"total": 0, "reachable": 0, "unreachable": 0, "unknown": 0})
    def _gs(sig, level):
        return _db_all_sev.get(sig, {}).get(level, 0)

    cve = _gc("cve")
    secret = _gc("secret")
    cwe = _gc("cwe")
    config = _gc("config")
    malware = _gc("malware")
    suspicious = _gc("suspicious")
    ai_s = _gc("ai")
    dlp_s = _gc("dlp")

    malware_total     = malware["total"] + suspicious["total"]
    malware_confirmed = malware["total"]
    malware_suspic    = suspicious["total"]
    malware_reachable = malware["reachable"] + suspicious["reachable"]
    _merged_mal_sev = dict(_db_all_sev.get("malware", {}))
    for _l, _c in _db_all_sev.get("suspicious", {}).items():
        _merged_mal_sev[_l] = _merged_mal_sev.get(_l, 0) + _c

    # Dynamic sandbox counts — passed in from pipeline_finalize (in scope there)
    _sandbox_dynamic_confirmed  = sandbox_dynamic_confirmed
    _sandbox_dynamic_suspicious = sandbox_dynamic_suspicious

    _reach_sev_out: dict = {}
    _unkn_sev_out: dict = {}
    _sig_map = {"cve": "cves", "secret": "secrets", "cwe": "cwe",
                "malware": "malware", "config": "config",
                "ai": "ai", "dlp": "dlp", "suspicious": "malware"}
    for _db_t, _cli_n in _sig_map.items():
        for _sev_d, _out_d in ((_db_reach_sev, _reach_sev_out), (_db_unkn_sev, _unkn_sev_out)):
            for _l, _c in _sev_d.get(_db_t, {}).items():
                _out_d.setdefault(_cli_n, {})
                _out_d[_cli_n][_l] = _out_d[_cli_n].get(_l, 0) + _c

    # Load ai_security.guarded from raw file (not in DB directly)
    _ai_guarded = 0
    try:
        _ai_raw_path = session_dir / "raw" / "ai-security.json"
        if _ai_raw_path.exists():
            import json as _j
            _ai_raw = _j.loads(_ai_raw_path.read_text())
            _ai_guarded = sum(1 for _f in _ai_raw.get("findings", [])
                             if _f.get("guards") or _f.get("is_guarded"))
    except Exception:
        pass

    # Load transitive CVE counts from cve-analyzed.json
    _cves_transitive = 0
    _cves_transitive_via: dict = {}
    try:
        _cva_path = session_dir / "raw" / "cve-analyzed.json"
        if _cva_path.exists():
            import json as _j2
            _cva = _j2.loads(_cva_path.read_text())
            _totals_cva = _cva.get("summary", {}).get("totals", {})
            _cves_transitive = _totals_cva.get("cves_transitive", 0)
            _cves_transitive_via = _totals_cva.get("cves_transitive_via", {})
    except Exception:
        pass

    # DLP scan time from step state
    _dlp_scan_time = step_states.get("dlp", {}).get("duration_seconds", 0.0) or 0.0
    scan_log._dlp_scan_time = _dlp_scan_time
    # AI scan time from step state
    _ai_scan_time = step_states.get("ai", {}).get("duration_seconds", 0.0) or 0.0
    scan_log._ai_scan_time = _ai_scan_time

    scan_log.set_counts(
        risk_level=risk_level,
        cves_total=cve["total"],      cves_reachable=cve["reachable"],   cves_unknown=cve["unknown"],
        cves_critical=_gs("cve","CRITICAL"), cves_high=_gs("cve","HIGH"),
        cves_medium=_gs("cve","MEDIUM"),     cves_low=_gs("cve","LOW"),
        cves_transitive=_cves_transitive,    cves_transitive_via=_cves_transitive_via,
        malware_static=malware_total,         malware_static_confirmed=malware_confirmed,
        malware_static_suspicious=malware_suspic, malware_reachable=malware_reachable,
        malware_count=malware_total,
        malware_critical=_merged_mal_sev.get("CRITICAL",0), malware_high=_merged_mal_sev.get("HIGH",0),
        malware_medium=_merged_mal_sev.get("MEDIUM",0),     malware_low=_merged_mal_sev.get("LOW",0),
        malware_dynamic=_sandbox_dynamic_confirmed, malware_dynamic_suspicious=_sandbox_dynamic_suspicious,
        secrets_total=secret["total"],   secrets_reachable=secret["reachable"], secrets_unknown=secret["unknown"],
        secrets_critical=_gs("secret","CRITICAL"), secrets_high=_gs("secret","HIGH"),
        secrets_medium=_gs("secret","MEDIUM"),      secrets_low=_gs("secret","LOW"),
        cwe_total=cwe["total"],   cwe_reachable=cwe["reachable"], cwe_unknown=cwe["unknown"],
        cwe_critical=_gs("cwe","CRITICAL"), cwe_high=_gs("cwe","HIGH"),
        cwe_medium=_gs("cwe","MEDIUM"),     cwe_low=_gs("cwe","LOW"),
        config_total=config["total"],
        config_critical=_gs("config","CRITICAL"), config_high=_gs("config","HIGH"),
        config_medium=_gs("config","MEDIUM"),      config_low=_gs("config","LOW"),
        ai_total=ai_s["total"],   ai_reachable=ai_s["reachable"], ai_guarded=_ai_guarded,
        ai_critical=_gs("ai","CRITICAL"), ai_high=_gs("ai","HIGH"),
        ai_medium=_gs("ai","MEDIUM"),     ai_low=_gs("ai","LOW"),
        dlp_total=dlp_s["total"],  dlp_reachable=dlp_s["reachable"], dlp_sanitized=0,
        dlp_critical=_gs("dlp","CRITICAL"), dlp_high=_gs("dlp","HIGH"),
        dlp_medium=_gs("dlp","MEDIUM"),     dlp_low=_gs("dlp","LOW"),
        reachable_severity=_reach_sev_out,
        unknown_severity=_unkn_sev_out,
    )

    scan_log.print_results_summary()
    scan_log.scan_complete(risk_score, risk_level, session_dir)


# ---------------------------------------------------------------------------
# CLI wiring
# ---------------------------------------------------------------------------

def setup_pipeline_parser(subparsers) -> None:
    pp = subparsers.add_parser("pipeline", help="Distributed CI/CD pipeline commands")
    subs = pp.add_subparsers(dest="pipeline_command")

    ip = subs.add_parser("init", help="Initialize pipeline session")
    ip.add_argument("repo", help="Path to repository")
    ip.add_argument("--json", action="store_true")
    ip.add_argument("--debug", action="store_true")

    sp = subs.add_parser("step", help="Run a single pipeline step")
    sp.add_argument("step", choices=list(PIPELINE_STEPS.keys()))
    sp.add_argument("--session", "-s", required=True)
    sp.add_argument("--json", action="store_true")
    sp.add_argument("--debug", action="store_true")
    sp.add_argument("--skip-iac", action="store_true")
    sp.add_argument("--no-ai", action="store_true", dest="disable_ai", help="Skip AI/LLM scan")
    sp.add_argument("--no-dlp", action="store_true", dest="disable_dlp", help="Skip DLP/PII scan")

    fp = subs.add_parser("finalize", help="Merge results and generate dashboard")
    fp.add_argument("--session", "-s", required=True)
    fp.add_argument("--fail-on", choices=["critical","high","medium","any","none"], default="none")
    fp.add_argument("--skip-iac", action="store_true")
    fp.add_argument("--json", action="store_true")
    fp.add_argument("--debug", action="store_true")

    stp = subs.add_parser("status", help="Show pipeline status")
    stp.add_argument("--session", "-s", required=True)
    stp.add_argument("--json", action="store_true")

    # ── Parallel orchestration ─────────────────────────────────────────
    rp = subs.add_parser("run", help="Run all steps in parallel (auto-tuned)")
    rp.add_argument("--session", "-s", required=True)
    rp.add_argument("--steps", nargs="+", choices=list(PIPELINE_STEPS.keys()),
                    help="Run specific steps only (default: all)")
    rp.add_argument("--fail-on", choices=["critical","high","medium","any","none"],
                    default="none")
    rp.add_argument("--json", action="store_true")

    tp = subs.add_parser("tune", help="Show auto-tuning config for this machine")
    tp.add_argument("--json", action="store_true")


def pipeline_command(args) -> int:
    if not hasattr(args, "pipeline_command") or not args.pipeline_command:
        _log.info("Usage: reachctl pipeline <init|step|finalize|run|status|tune>")
        _log.info("Steps: " + ", ".join(PIPELINE_STEPS.keys()))
        return 1
    dispatch = {"init": pipeline_init, "step": pipeline_step,
                "finalize": pipeline_finalize, "status": pipeline_status,
                "run": pipeline_run, "tune": pipeline_tune}
    fn = dispatch.get(args.pipeline_command)
    if fn:
        return fn(args)
    _log.info(f"Unknown pipeline command: {args.pipeline_command}")
    return 1


def pipeline_run(args) -> int:
    """Run all pipeline steps in parallel using the DAG orchestrator."""
    from reachable.parallel.orchestrator import run_parallel_pipeline
    session_dir = Path(args.session)
    if not session_dir.exists():
        _log.info(f"Session not found: {session_dir}")
        return 1
    steps = getattr(args, "steps", None)
    # tuning=None → orchestrator prints its own hardware summary (standalone use)
    return run_parallel_pipeline(session_dir, steps=steps, tuning=None)


def pipeline_tune(args) -> int:
    """Print auto-tuning config for this machine and exit."""
    import json as _json

    from reachable.parallel.tuner import derive_tuning, detect_hardware
    hw = detect_hardware()
    cfg = derive_tuning(hw)
    if getattr(args, "json", False):
        data = {
            "hw": {
                "ncpu": hw.ncpu, "mem_gb": round(hw.mem_gb, 1),
                "arch": hw.arch, "os": hw.os_name,
                "cpu_vendor": hw.cpu_vendor,
                "perf_cores": hw.perf_cores, "eff_cores": hw.eff_cores,
            },
            "tuning": {
                "parallel_steps": cfg.parallel_steps,
                "semgrep_jobs": cfg.semgrep_jobs,
                "trufflehog_concurrency": cfg.trufflehog_concurrency,
                "gomaxprocs": cfg.gomaxprocs,
                "joern_heap": cfg.joern_heap,
            },
            "overridden": cfg.overridden,
        }
        print(_json.dumps(data, indent=2))
    else:
        print(f"\n  Hardware: {hw.ncpu} cores ({hw.cpu_vendor}, {hw.arch}), "
              f"{hw.mem_gb:.1f}GB RAM")
        if hw.perf_cores:
            print(f"  P-cores: {hw.perf_cores}  E-cores: {hw.eff_cores}")
        print("\n  Auto-tuning config:")
        print(cfg.summary())
        print()
    return 0
