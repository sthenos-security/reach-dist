#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.
"""CLI utilities: logging, output capture, command execution."""

import json
import logging
import shutil
import subprocess
import sys
from pathlib import Path
from typing import Optional

logger = logging.getLogger(__name__)


class TeeOutput:
    """Tee stdout to both console and a log file, with optional console suppression.

    IMPORTANT: If log_path is the same file that ReachableLogger writes to,
    open in append mode to avoid truncating the logger's header content.
    """

    def __init__(self, log_path: Path, console_enabled: bool = True):
        self.terminal = sys.stdout
        # Append mode — scan_log already opened this file and wrote the header.
        # Opening with 'w' would truncate it, causing null-byte corruption.
        self.log_file = open(log_path, "a", encoding="utf-8")
        self.log_path = log_path
        self.console_enabled = console_enabled

    def write(self, message):
        if self.console_enabled:
            self.terminal.write(message)
        self.log_file.write(message)
        self.log_file.flush()

    def flush(self):
        if self.console_enabled:
            self.terminal.flush()
        self.log_file.flush()

    def enable_console(self):
        """Re-enable console output"""
        self.console_enabled = True

    def disable_console(self):
        """Suppress console output (still logs to file)"""
        self.console_enabled = False

    def close(self):
        self.log_file.close()

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()


def _extract_vulnerability_ids(vuln_data):
    """Extract both CVE and GHSA IDs from Grype vulnerability data."""
    cve_id = None
    ghsa_id = None

    # Primary ID
    primary_id = vuln_data.get("id", "")
    if primary_id.startswith("CVE-"):
        cve_id = primary_id
    elif primary_id.startswith("GHSA-"):
        ghsa_id = primary_id

    # Check relatedVulnerabilities (array of objects with 'id' field)
    for rel in vuln_data.get("relatedVulnerabilities", []):
        if isinstance(rel, dict):
            rel_id = rel.get("id", "")
            if rel_id.startswith("CVE-") and not cve_id:
                cve_id = rel_id
            elif rel_id.startswith("GHSA-") and not ghsa_id:
                ghsa_id = rel_id

    return cve_id, ghsa_id


def setup_logger(debug: bool = False, no_timestamps: bool = False, command_type: str = None):
    """
    Configure logging for reachctl.

    Args:
        debug: If True, include timestamps and set level to DEBUG.
        no_timestamps: If True, use minimal format (message only, no INFO prefix).
        command_type: Command being run. Non-scan commands always use clean format.
    """
    root = logging.getLogger()
    root.handlers.clear()
    root.setLevel(logging.DEBUG)

    if command_type and command_type not in ("scan", "pipeline"):
        # Non-scan: plain StreamHandler on root, message-only, no file, no timestamps.
        # ReachableLogger._write() also writes to stdout; stdlib logger.info() calls
        # (e.g. admin.py) go here too.
        h = logging.StreamHandler(sys.stdout)
        h.setLevel(logging.DEBUG if debug else logging.INFO)
        h.setFormatter(logging.Formatter("%(message)s"))
        root.addHandler(h)
        # ReachableLogger uses logging.getLogger("reachable") internally for file routing
        # via _log_via_stdlib(). Keep propagate=False so those calls don't double-print
        # through root's StreamHandler above.
        # admin.py uses logging.getLogger("reachable.cli.admin") — attach a StreamHandler
        # directly to that logger so its output still reaches stdout.
        logging.getLogger("reachable").propagate = False
        logging.getLogger("reachable").setLevel(logging.DEBUG)
        _admin_logger = logging.getLogger("reachable.cli.admin")
        _admin_logger.propagate = False
        _admin_logger.setLevel(logging.DEBUG if debug else logging.INFO)
        if not any(isinstance(h, logging.StreamHandler) for h in _admin_logger.handlers):
            _ah = logging.StreamHandler(sys.stdout)
            _ah.setLevel(logging.DEBUG if debug else logging.INFO)
            _ah.setFormatter(logging.Formatter("%(message)s"))
            _admin_logger.addHandler(_ah)
    else:
        # Scan / pipeline step: NullHandler for now.
        # scan: start_log_queue() will attach QueueHandler later.
        # pipeline step: runs as subprocess with stdout piped — _write() prints
        #   directly; a StreamHandler here would double-write every line.
        root.addHandler(logging.NullHandler())

    # Suppress noisy third-party loggers
    logging.getLogger("urllib3").setLevel(logging.WARNING)
    logging.getLogger("requests").setLevel(logging.WARNING)
    logging.getLogger("git").setLevel(logging.WARNING)
    logging.getLogger("docker").setLevel(logging.WARNING)
    logging.getLogger("docker.utils.config").setLevel(logging.WARNING)
    logging.getLogger("docker.auth").setLevel(logging.WARNING)


def _format_vulnerability_display_id(cve_id, ghsa_id, primary_id):
    """Format display ID showing both IDs."""
    if cve_id and ghsa_id:
        if primary_id and primary_id.startswith("GHSA-"):
            return f"{ghsa_id} (CVE: {cve_id})"
        return f"{cve_id} (GHSA: {ghsa_id})"
    elif ghsa_id:
        return f"{ghsa_id} ( No CVE assigned)"
    elif cve_id:
        return cve_id
    return "UNKNOWN"


def _check_venv_activation():
    """Check if running in activated venv and warn if not."""
    import sys
    from pathlib import Path

    # Check if we're in a venv
    in_venv = hasattr(sys, "real_prefix") or (  # virtualenv
        hasattr(sys, "base_prefix") and sys.base_prefix != sys.prefix
    )  # venv

    if in_venv:
        return  # All good

    # Not in venv - check if running from source (./reachctl)
    cli_path = Path(__file__).resolve()
    project_root = cli_path.parent.parent
    venv_dir = project_root / "venv"

    # Only warn if venv exists but isn't activated
    if venv_dir.exists():
        logger.info("\033[93m  WARNING: Virtual environment not activated\033[0m")
        logger.info("Some tools (semgrep, guarddog) may not be available.")
        logger.info("To activate:")
        logger.info(f" source {venv_dir}/bin/activate")
        logger.info("Or run setup first:")
        logger.info("  ./setup.sh && source venv/bin/activate")
        logger.info("-" * 60)


def run_command(cmd: list, description: str, capture=False, check=True, env=None) -> Optional[str]:
    """Run a shell command with error handling.

    Args:
        cmd: Command and arguments
        description: Human-readable description for error messages
        capture: If True, return stdout
        check: If True, exit on non-zero return code
        env: Optional environment variables dict
    """
    try:
        if capture:
            result = subprocess.run(cmd, check=check, capture_output=True, text=True, env=env)
            return result.stdout
        else:
            result = subprocess.run(cmd, check=check, capture_output=True, text=True, env=env)
            return None
    except subprocess.CalledProcessError as e:
        if check:
            logger.info(f" Error during {description}")
            if e.stderr:
                logger.info(f" {e.stderr}")
            sys.exit(1)
        return None
    except FileNotFoundError:
        logger.info(f" Command not found: {cmd[0]}")
        logger.info(f" Please ensure {cmd[0]} is installed")
        sys.exit(1)


def check_github_connectivity(verbose: bool = False):
    """Check git client, GitHub token validity (all tokens), and SSH access."""
    import os

    if verbose:
        logger.info("[AUTH] Checking Git & GitHub Connectivity...")

    has_auth = False
    git_ok = False

    # Check git client exists
    git_path = shutil.which("git")
    if git_path:
        git_ok = True
        if verbose:
            try:
                result = subprocess.run(["git", "--version"], capture_output=True, text=True, timeout=5)
                ver = result.stdout.strip() if result.returncode == 0 else "unknown"
                logger.info(f" git client: {ver}")
            except Exception:
                logger.info(f" git client: found at {git_path}")
    else:
        if verbose:
            logger.info("    git client: NOT FOUND")
            logger.info("      Without git, REACHABLE cannot clone library source for reachability analysis.")
            logger.info("      Install: brew install git  (macOS) | sudo apt install git  (Debian/Ubuntu)")

    # Check ALL GitHub tokens (priority order: MCP first, then standard)
    token_vars = ["MCP_GITHUB_TOKEN", "GITHUB_TOKEN", "GH_TOKEN"]
    any_token_found = False

    for var in token_vars:
        val = os.getenv(var)
        if not val:
            continue

        any_token_found = True

        # Validate token against GitHub API
        # Fine-grained tokens (github_pat_) use Bearer auth
        # Classic tokens (ghp_) use token auth
        token_valid = False
        token_user = None
        token_scopes = None
        http_error_code = None
        auth_scheme = "Bearer" if val.startswith("github_pat_") else "token"
        try:
            import urllib.error
            import urllib.request

            # First: try /user (gives username + scopes for classic tokens)
            req = urllib.request.Request(
                "https://api.github.com/user",
                headers={
                    "Authorization": f"{auth_scheme} {val}",
                    "Accept": "application/vnd.github.v3+json",
                    "User-Agent": "reachable-preflight",
                },
            )
            with urllib.request.urlopen(req, timeout=5) as resp:
                if resp.status == 200:
                    token_valid = True
                    data = json.loads(resp.read())
                    token_user = data.get("login", "")
                    token_scopes = resp.headers.get("X-OAuth-Scopes", "")
        except urllib.error.HTTPError as e:
            http_error_code = e.code
            # /user returned 401/403 — try /rate_limit as fallback
            # (works with any valid token, no scopes needed)
            if http_error_code in (401, 403):
                try:
                    req2 = urllib.request.Request(
                        "https://api.github.com/rate_limit",
                        headers={
                            "Authorization": f"{auth_scheme} {val}",
                            "User-Agent": "reachable-preflight",
                        },
                    )
                    with urllib.request.urlopen(req2, timeout=5) as resp2:
                        if resp2.status == 200:
                            token_valid = True
                            http_error_code = None
                except Exception:
                    pass
        except Exception:
            pass

        if token_valid:
            has_auth = True
            if verbose:
                if token_user:
                    scope_info = f", scopes: {token_scopes}" if token_scopes else ""
                    logger.info(f" {var}: valid (user: {token_user}{scope_info})")
                    if token_scopes and "repo" not in token_scopes:
                        logger.info(f" {var} missing 'repo' scope — private repos won't be accessible")
                        logger.info(" Update at: https://github.com/settings/tokens")
                else:
                    logger.info(f" {var}: valid (fine-grained token)")
        elif http_error_code == 401:
            if verbose:
                logger.info(f" {var}: INVALID or EXPIRED (HTTP 401)")
                logger.info(" Regenerate at: https://github.com/settings/tokens")
        elif http_error_code == 403:
            # Fine-grained tokens or tokens without read:user scope
            # return 403 on /user but may still work for git cloning
            has_auth = True
            if verbose:
                logger.info(f" {var}: set (cannot verify user — fine-grained token or limited scope)")
                logger.info(" Token may still work for git cloning")
        else:
            # Network error, timeout, etc. — assume token might work
            has_auth = True
            if verbose:
                logger.info(f" {var}: set but could not validate (network error)")
                logger.info(" Token may still work for git cloning")

    if not any_token_found:
        # Check credential store (macOS Keychain / Linux encrypted file)
        try:
            from reachable.core.credentials import get_credential, get_credential_source

            for cred_name in ("github-token", "github-mcp-token"):
                val = get_credential(cred_name)
                if val:
                    any_token_found = True
                    has_auth = True
                    source = get_credential_source(cred_name)
                    if verbose:
                        masked = val[:4] + "…" + val[-4:] if len(val) > 8 else "***"
                        logger.info(f" {cred_name}: {masked} ({source})")
                    break
        except Exception:
            pass

    if not any_token_found and verbose:
        logger.info(f" No GitHub token (checked: {', '.join(token_vars)}, credential store)")

    # Check SSH access
    ssh_ok = False
    ssh_user = ""
    try:
        result = subprocess.run(["ssh", "-T", "git@github.com"], capture_output=True, text=True, timeout=5)
        # SSH to GitHub always returns exit code 1, but with specific message
        if "successfully authenticated" in result.stderr.lower():
            ssh_ok = True
            if "Hi " in result.stderr:
                ssh_user = result.stderr.split("Hi ")[1].split("!")[0]
            if verbose:
                logger.info(f" SSH: authenticated{f' (user: {ssh_user})' if ssh_user else ''}")
            has_auth = True
        else:
            if verbose:
                logger.info("     SSH: not configured")
    except (subprocess.TimeoutExpired, FileNotFoundError):
        if verbose:
            logger.info("     SSH: check skipped (not available)")

    # Check git credential helper (osxkeychain, manager, gh, etc.)
    cred_helper = ""
    try:
        result = subprocess.run(
            ["git", "config", "--global", "credential.helper"],
            capture_output=True,
            text=True,
            timeout=3,
        )
        if result.returncode == 0 and result.stdout.strip():
            cred_helper = result.stdout.strip()
            has_auth = True
            if verbose:
                logger.info(f" Git credential helper: {cred_helper}")
    except (subprocess.TimeoutExpired, FileNotFoundError):
        pass

    # Summary
    if verbose:
        if not git_ok:
            logger.info("    CRITICAL: No git client — scanner will be severely limited")
        elif has_auth:
            auth_methods = []
            if any_token_found:
                auth_methods.append("token")
            if ssh_ok:
                auth_methods.append("SSH")
            if cred_helper:
                auth_methods.append(f"credential helper ({cred_helper})")
            logger.info(f"    GitHub: authenticated via {', '.join(auth_methods)}")
            if not any_token_found and (ssh_ok or cred_helper):
                logger.info("    Note: git clone works, but a token enables faster API-based")
                logger.info("          cloning and GHSA vulnerability enrichment")
                logger.info("          Optional: reachctl auth set github-token")
        else:
            logger.info("     No GitHub authentication — only public repositories accessible")
            logger.info("    Desktop:  reachctl auth login")
            logger.info("    CI/CD:    set GITHUB_TOKEN as pipeline secret")

    return has_auth


def detect_github_auth() -> dict:
    """Lightweight GitHub auth detection for auth login flow.

    Returns dict with:
        working: bool       — can we clone repos right now?
        methods: list[str]  — what's working (e.g. ["env:GITHUB_TOKEN", "SSH (user)"])
        tokens: dict        — env var tokens found {var: masked_value}
        ssh: bool           — SSH to github.com works
        credential_helper: str — git credential helper name or ""
        keychain: dict      — {cred_name: masked} from credential store
    """
    import os

    result = {
        "working": False,
        "methods": [],
        "tokens": {},
        "ssh": False,
        "credential_helper": "",
        "keychain": {},
    }

    # 1. Environment variable tokens
    for var in ["GITHUB_TOKEN", "GH_TOKEN"]:
        val = os.getenv(var)
        if val:
            masked = val[:4] + "…" + val[-4:] if len(val) > 8 else "***"
            result["tokens"][var] = masked
            result["methods"].append(f"env:{var}")
            result["working"] = True

    # 2. Credential store
    try:
        from reachable.core.credentials import get_credential, mask_value

        for cred_name in ("github-token",):
            val = get_credential(cred_name)
            if val and cred_name not in result["tokens"]:
                result["keychain"][cred_name] = mask_value(val)
                result["methods"].append("credential store")
                result["working"] = True
    except Exception:
        pass

    # 3. SSH
    try:
        r = subprocess.run(
            ["ssh", "-T", "git@github.com"],
            capture_output=True,
            text=True,
            timeout=5,
        )
        if "successfully authenticated" in r.stderr.lower():
            user = ""
            if "Hi " in r.stderr:
                user = r.stderr.split("Hi ")[1].split("!")[0]
            result["ssh"] = True
            label = f"SSH ({user})" if user else "SSH"
            result["methods"].append(label)
            result["working"] = True
    except (subprocess.TimeoutExpired, FileNotFoundError):
        pass

    # 4. Git credential helper
    try:
        r = subprocess.run(
            ["git", "config", "--global", "credential.helper"],
            capture_output=True,
            text=True,
            timeout=3,
        )
        if r.returncode == 0 and r.stdout.strip():
            helper = r.stdout.strip()
            result["credential_helper"] = helper
            result["methods"].append(f"credential helper ({helper})")
            result["working"] = True
    except (subprocess.TimeoutExpired, FileNotFoundError):
        pass

    return result


def _is_dev_build() -> bool:
    """Check if this is a development build (not customer distribution)"""
    import os
    from pathlib import Path

    # Check for .dev marker file (present in dev, removed in customer builds)
    dev_marker = Path(__file__).parent / ".dev"
    if dev_marker.exists():
        return True

    # Check for compiled Cython modules (customer builds have these)
    core_dir = Path(__file__).parent / "core"
    if core_dir.exists():
        compiled = list(core_dir.glob("*.so")) + list(core_dir.glob("*.pyd"))
        if compiled:
            return False  # Customer build has compiled modules

    # Check environment variable override
    if os.environ.get("REACHABLE_DEV_MODE") == "1":
        return True

    return True  # Default: dev build


def format_size(size_bytes: int) -> str:
    """Format bytes as human-readable size"""
    for unit in ["B", "KB", "MB", "GB"]:
        if size_bytes < 1024:
            return f"{size_bytes:.1f} {unit}"
        size_bytes /= 1024
    return f"{size_bytes:.1f} TB"
