#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.

"""
REACHABLE v1.0.0b15 - Threat Intelligence Enrichment

Single-pass batch enrichment of CVE/GHSA findings with three external sources:

  1. OSV (osv.dev)      — authoritative fix semver, GO- alias IDs, fix commit URL
  2. EPSS (first.org)   — exploit probability score + percentile
  3. KEV (cisa.gov)     — Known Exploited Vulnerabilities catalog

Design principles:
  - ONE batch call per source per scan (not per finding)
  - Hard timeouts per source — scan never hangs on enrichment failure
  - Filesystem cache with TTL — warm cache = zero network calls
  - Graceful fallback — partial enrichment is better than none
  - Go-aware fix normalization — pseudo-versions → clean semver

Cache layout:
  ~/.reachable/cache/osv/{ID}.json     TTL 30 days
  ~/.reachable/cache/epss/{DATE}.json  TTL 24 hours  (date-keyed, all IDs fetched that day)
  ~/.reachable/cache/kev/catalog.json  TTL 24 hours  (full CISA catalog)

Enriched fields added to each finding dict:
  epss_score       float   0.0–1.0  (None if unavailable)
  epss_percentile  int     0–100    (None if unavailable)
  is_kev           bool    True if in CISA KEV catalog (None if catalog unavailable)
  go_vuln_id       str     GO-XXXX-XXXX alias (None if OSV has no record for this vuln)
  fix_commit_url   str     https://go.googlesource.com/…/+/{commit} (None if unavailable)
  fix_version      str     clean semver if Grype gave pseudo-version, else unchanged
  fix_version_raw  str     original Grype fix version (always preserved)

Risk level adjustment (applied after enrichment):
  KEV = True                            → floor at HIGH
  EPSS ≥ 0.5  AND reachable            → bump one level
  EPSS ≥ 0.9  (regardless reachability) → bump one level

Bug fixes in this version:
  - FIX 1: OSV lookup now tries GHSA fallback when CVE-id lookup misses.
    Go vulns are indexed in OSV under GHSA/GO- IDs, not CVE IDs. The previous
    code looked up osv_data[cve_id] which always returned {} even though
    osv_data[ghsa_id] had the full record with GO- aliases.
  - FIX 2: GO- alias extraction no longer gated on is_go.
    Previously `if osv_rec and is_go:` meant go_vuln_id was never set unless
    the package name contained 'golang.org' etc. The GO- alias is a property
    of the OSV record, not of the package name pattern.
"""

import json
import logging
import re
import time
import urllib.error
import urllib.request
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

logger = logging.getLogger(__name__)

from .osv_package_groups import (
    OsvRecord,
    best_cvss_score,
    database_cwes,
    extract_fix_commit,
    extract_fix_versions,
    parse_osv_record,
)

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

OSV_BATCH_URL = "https://api.osv.dev/v1/querybatch"
EPSS_BATCH_URL = "https://api.first.org/data/v1/epss"
KEV_URL = "https://www.cisa.gov/sites/default/files/feeds/known_exploited_vulnerabilities.json"

OSV_TIMEOUT_S = 20  # batch of ~100 IDs (Go vuln DB can be slow)
EPSS_TIMEOUT_S = 6  # batch query
KEV_TIMEOUT_S = 6  # full catalog (~200 KB)

OSV_TTL_DAYS = 30  # vuln advisories are stable
EPSS_TTL_HOURS = 24  # EPSS updates daily
KEV_TTL_HOURS = 24  # CISA updates ~weekly but cache daily to catch hot additions

# Go pseudo-version pattern: v?0.0.0-YYYYMMDDHHMMSS-COMMITHASH12
_PSEUDO_RE = re.compile(r"^v?0\.0\.0-\d{14}-[0-9a-f]{12}$", re.IGNORECASE)

# OSV ecosystem names (must match OSV's canonical values exactly)
_ECOSYSTEM_MAP = {
    "go": "Go",
    "npm": "npm",
    "python": "PyPI",
    "pypi": "PyPI",
    "rust": "crates.io",
    "java": "Maven",
    "ruby": "RubyGems",
}


def _osv_ecosystem(artifact_type: str, package_name: str) -> str:
    """
    Map Grype artifact type / package name → OSV ecosystem string.
    OSV ecosystem names are case-sensitive.
    """
    t = (artifact_type or "").lower()
    if t in ("npm", "yarn"):
        return "npm"
    if t in ("python", "wheel", "egg", "pypi"):
        return "PyPI"
    if t in ("go-module", "go-binary", "go"):
        return "Go"
    if t in ("cargo", "rust-crate"):
        return "crates.io"
    if t == "java-archive":
        return "Maven"
    # Fallback: infer from package name
    pkg = (package_name or "").lower()
    if (
        pkg.startswith("github.com/")
        or pkg.startswith("golang.org/")
        or pkg.startswith("gopkg.in/")
        or pkg.startswith("k8s.io/")
        or pkg.startswith("go.uber.org/")
        or pkg.startswith("google.golang.org/")
    ):
        return "Go"
    if pkg.startswith("@"):
        return "npm"
    return ""


# Map golang.org/x/* sub-path → googlesource repo name
_GOLANG_X_REPOS = {
    "crypto": "crypto",
    "net": "net",
    "text": "text",
    "sys": "sys",
    "oauth2": "oauth2",
    "sync": "sync",
    "tools": "tools",
    "image": "image",
    "term": "term",
    "xerrors": "xerrors",
    "mod": "mod",
    "lint": "lint",
    "exp": "exp",
    "time": "time",
}

_SEVERITY_RANK = {"CRITICAL": 4, "HIGH": 3, "MEDIUM": 2, "LOW": 1, "INFO": 0}
_RANK_SEVERITY = {v: k for k, v in _SEVERITY_RANK.items()}


# ---------------------------------------------------------------------------
# Cache helpers
# ---------------------------------------------------------------------------


def _cache_root() -> Path:
    return Path.home() / ".reachable" / "cache"


def _osv_cache_path(vuln_id: str) -> Path:
    safe = vuln_id.replace("/", "_")
    return _cache_root() / "osv" / f"{safe}.json"


def _osv_pkg_cache_path(pkg: str, ecosystem: str, version: str) -> Path:
    safe = f"{ecosystem}__{pkg}__{version}".replace("/", "_").replace(":", "_")
    return _cache_root() / "osv" / f"{safe}.json"


def _epss_cache_path() -> Path:
    date_str = datetime.now(timezone.utc).strftime("%Y-%m-%d")
    return _cache_root() / "epss" / f"{date_str}.json"


def _kev_cache_path() -> Path:
    return _cache_root() / "kev" / "catalog.json"


def _is_fresh(path: Path, ttl_hours: float) -> bool:
    if not path.exists():
        return False
    age = datetime.now().timestamp() - path.stat().st_mtime
    return age < ttl_hours * 3600


def _read_json(path: Path) -> Optional[Any]:
    try:
        return json.loads(path.read_text())
    except Exception:
        return None


def _write_json(path: Path, data: Any) -> None:
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        tmp = path.with_suffix(".tmp")
        tmp.write_text(json.dumps(data, separators=(",", ":")), encoding="utf-8")
        tmp.replace(path)  # atomic on POSIX
    except (TypeError, ValueError) as e:
        logger.debug(f"_write_json: serialization failed for {path}: {e}")
    except OSError as e:
        logger.debug(f"_write_json: write failed for {path}: {e}")


def _http_get(url: str, timeout: int) -> Optional[bytes]:
    """Simple GET with timeout. Returns raw bytes or None on any error."""
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "reachable-scanner/1.0"})
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return resp.read()
    except Exception as exc:
        logger.debug(f"HTTP GET failed {url}: {exc}")
        return None


def _http_post_json(url: str, payload: dict, timeout: int) -> Optional[dict]:
    """POST JSON with timeout. Returns parsed response or None on any error."""
    try:
        body = json.dumps(payload).encode()
        req = urllib.request.Request(
            url,
            data=body,
            headers={"Content-Type": "application/json", "User-Agent": "reachable-scanner/1.0"},
            method="POST",
        )
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return json.loads(resp.read())
    except Exception as exc:
        logger.debug(f"HTTP POST failed {url}: {exc}")
        return None


# ---------------------------------------------------------------------------
# Go-specific helpers
# ---------------------------------------------------------------------------


def _is_pseudo_version(v: str) -> bool:
    return bool(_PSEUDO_RE.match((v or "").strip()))


def _googlesource_url(package: str, commit: str) -> Optional[str]:
    """
    Build a googlesource link for a golang.org/x/* package + commit hash.
    e.g. golang.org/x/crypto + abc123... → https://go.googlesource.com/crypto/+/abc123...
    """
    if not commit or not package:
        return None
    pkg = package.split(" ")[0].rstrip("/")
    if pkg.startswith("golang.org/x/"):
        sub = pkg[len("golang.org/x/") :].split("/")[0]
        repo = _GOLANG_X_REPOS.get(sub)
        if repo:
            return f"https://go.googlesource.com/{repo}/+/{commit}"
    return None


def _extract_osv_go_info(osv_record: dict, package: str) -> Tuple[Optional[str], Optional[str], Optional[str]]:
    """
    From an OSV record extract:
      - clean semver fix version (from SEMVER range)
      - fix commit hash (from GIT range)
      - GO- alias ID

    Returns (semver_fix, commit_hash, go_id)
    """
    semver_fix = None
    commit_hash = None
    go_id = None

    # GO- alias — check aliases array
    for alias in osv_record.get("aliases", []):
        if alias.startswith("GO-"):
            go_id = alias
            break

    # Also check if the primary ID is GO-
    if not go_id and osv_record.get("id", "").startswith("GO-"):
        go_id = osv_record["id"]

    pkg_lower = (package or "").lower().split(" ")[0]

    for affected in osv_record.get("affected", []):
        aff_pkg = affected.get("package", {}).get("name", "").lower()
        # Match on package name (exact or prefix for sub-paths)
        if (
            pkg_lower
            and aff_pkg
            and not (aff_pkg == pkg_lower or pkg_lower.startswith(aff_pkg) or aff_pkg.startswith(pkg_lower))
        ):
            continue

        for rng in affected.get("ranges", []):
            rtype = rng.get("type", "")
            for event in rng.get("events", []):
                fixed = event.get("fixed")
                if not fixed:
                    continue
                if rtype == "SEMVER" and not semver_fix:
                    # Prefix with 'v' if missing
                    semver_fix = fixed if fixed.startswith("v") else f"v{fixed}"
                elif rtype == "GIT" and not commit_hash:
                    commit_hash = fixed

    return semver_fix, commit_hash, go_id


# ---------------------------------------------------------------------------
# OSV client
# ---------------------------------------------------------------------------


def _osv_pkg_key(pkg: str, ecosystem: str, version: str) -> str:
    """Stable string key for a (pkg, ecosystem, version) triple."""
    return f"{ecosystem}/{pkg}@{version}"


class OSVClient:
    """
    Batch-fetch OSV records using /v1/querybatch (package + ecosystem + version).

    API format:
      POST /v1/querybatch
      {"queries": [{"package": {"name": "...", "ecosystem": "..."}, "version": "..."},
                   {"id": "CVE-xxx"},  ← fallback when ecosystem unknown
                   ...]}

    Response:
      {"results": [{"vulns": [{"id": "GHSA-...", ...}]}, ...]}
      Positional — results[i] corresponds to queries[i].

    Returns a dict keyed by pkg_key = "{ecosystem}/{pkg}@{version}" mapping to
    list of vuln IDs found.  Callers that don't know the ecosystem should look up
    by building the same key.  For findings with no detectable ecosystem the key
    is instead the vuln ID (CVE-xxx / GHSA-xxx) used in the fallback query.

    Also caches per-package so repeat scans skip the network.
    """

    def fetch(self, findings: List[Dict[str, Any]]) -> Dict[str, "OsvRecord"]:
        """
        Returns {pkg_key: OsvRecord} for every finding OSV matched.

        OSV querybatch returns a list of vuln stubs {id, ...} per package@version.
        We then batch-fetch full records (GET /v1/vulns/{id}) so callers get
        the complete OSV schema: affected[], aliases, severity, references, etc.

        Cache layout (unchanged):
          pkg-level:  ~/.reachable/cache/osv/{eco}_{pkg}@{ver}.json
                      contains list of vuln IDs  (TTL: OSV_TTL_DAYS)
          record-level: ~/.reachable/cache/osv/{vuln_id}.json
                      contains full OSV record   (TTL: OSV_TTL_DAYS)

        Backward-compatible: callers that only need vuln IDs can do
          [r.id for r in result.values()]
        """
        result: Dict[str, "OsvRecord"] = {}
        # misses: (pkg_key, pkg, ecosystem, version)
        misses: List[tuple] = []

        for f in findings:
            pkg = (f.get("package_name") or f.get("package") or "").strip()
            version = (f.get("version") or f.get("package_version") or "").strip()
            art_type = f.get("artifact_type") or f.get("type") or ""
            ecosystem = _osv_ecosystem(art_type, pkg)

            if not pkg or not version or not ecosystem:
                continue

            pkg_key = _osv_pkg_key(pkg, ecosystem, version)
            if pkg_key in result:
                continue  # same pkg@ver seen twice

            # Check pkg-level cache (list of vuln IDs)
            cache_path = _osv_pkg_cache_path(pkg, ecosystem, version)
            if _is_fresh(cache_path, OSV_TTL_DAYS * 24):
                cached_ids = _read_json(cache_path)
                if isinstance(cached_ids, list):
                    # Load full records from per-record cache
                    records = _load_full_records(cached_ids)
                    result[pkg_key] = _merge_records(records, pkg, ecosystem, version)
                    continue

            misses.append((pkg_key, pkg, ecosystem, version))

        if not misses:
            logger.debug(f"OSV: all {len(findings)} findings from cache ({len(result)} hits)")
            return result

        logger.info(f" OSV: querying {len(misses)} packages (cache miss), {len(result)} cached")
        t0 = time.time()

        payload = {
            "queries": [{"package": {"name": pkg, "ecosystem": eco}, "version": ver}
                        for (_, pkg, eco, ver) in misses]
        }
        resp = _http_post_json(OSV_BATCH_URL, payload, OSV_TIMEOUT_S)
        elapsed = time.time() - t0

        if resp is None:
            logger.warning(
                f" OSV: querybatch failed after {elapsed:.1f}s — enrichment fields will be empty this scan"
            )
            return result

        # querybatch returns stubs: {id, modified, ...} — not full records.
        # We need to GET full records to get affected[], severity, aliases etc.
        all_stub_ids: List[str] = []
        pkg_to_ids: Dict[str, List[str]] = {}
        for (pkg_key, pkg, eco, ver), res_item in zip(misses, resp.get("results", [])):
            stubs = (res_item or {}).get("vulns", [])
            ids = [v["id"] for v in stubs if v.get("id")]
            _write_json(_osv_pkg_cache_path(pkg, eco, ver), ids)
            pkg_to_ids[pkg_key] = ids
            all_stub_ids.extend(ids)

        # Fetch full records (deduplicated) — cache saves repeat scans
        unique_ids = list(dict.fromkeys(all_stub_ids))  # preserve order, dedup
        full_records = _fetch_full_records(unique_ids)

        fetched = 0
        for (pkg_key, pkg, eco, ver) in misses:
            ids = pkg_to_ids.get(pkg_key, [])
            recs = [full_records[oid] for oid in ids if oid in full_records]
            result[pkg_key] = _merge_records(recs, pkg, eco, ver)
            if ids:
                fetched += 1

        logger.info(f" OSV: {fetched}/{len(misses)} packages had vulns, "
                    f"{len(full_records)} full records in {elapsed:.1f}s")
        return result


# ---------------------------------------------------------------------------
# OSV full-record helpers
# ---------------------------------------------------------------------------


def _load_full_records(vuln_ids: List[str]) -> List["OsvRecord"]:
    """Load OsvRecord objects from per-record cache (no network)."""
    out = []
    for oid in vuln_ids:
        path = _osv_cache_path(oid)
        if path.exists():
            raw = _read_json(path)
            if raw:
                out.append(parse_osv_record(raw))
    return out


def _fetch_full_records(vuln_ids: List[str]) -> Dict[str, "OsvRecord"]:
    """
    Fetch full OSV records for a list of vuln IDs.
    Checks per-record cache first; fetches missing ones via GET /v1/vulns/{id}.
    Returns {vuln_id: OsvRecord}.
    """
    result: Dict[str, "OsvRecord"] = {}
    to_fetch: List[str] = []

    for oid in vuln_ids:
        cache_path = _osv_cache_path(oid)
        if _is_fresh(cache_path, OSV_TTL_DAYS * 24):
            raw = _read_json(cache_path)
            if raw:
                result[oid] = parse_osv_record(raw)
                continue
        to_fetch.append(oid)

    if not to_fetch:
        return result

    logger.debug(f" OSV full records: fetching {len(to_fetch)} (cache miss)")
    for oid in to_fetch:
        raw_bytes = _http_get(f"https://api.osv.dev/v1/vulns/{oid}", OSV_TIMEOUT_S)
        if not raw_bytes:
            continue
        try:
            raw = json.loads(raw_bytes)
            _write_json(_osv_cache_path(oid), raw)
            result[oid] = parse_osv_record(raw)
        except Exception as exc:
            logger.debug(f" OSV parse error for {oid}: {exc}")

    return result


def _merge_records(records: List["OsvRecord"], pkg: str, ecosystem: str, version: str) -> "OsvRecord":
    """
    Merge multiple OsvRecord objects for the same package@version into one.

    When querybatch returns multiple vulns for a package we merge them into
    a synthetic container record so callers only deal with one object.
    The merged record carries:
      - all aliases across all constituent records
      - all affected[] groups
      - worst-case severity (highest CVSS score wins)
      - combined references and fix_refs
    """
    if not records:
        # Empty sentinel — zero fields means "no OSV data"
        return OsvRecord(id="")

    if len(records) == 1:
        return records[0]

    # Use the record with the highest CVSS as the base.
    # Tiebreak: prefer records that have any severity entry (V3 > V2 > none).
    _TYPE_PREF = {"CVSS_V3": 3, "CVSS_V4": 2, "CVSS_V2": 1}

    def _score(r: "OsvRecord") -> tuple:
        s, _ = best_cvss_score(r)
        numeric = s or 0.0
        type_pref = max((_TYPE_PREF.get(sv.get("type", ""), 0) for sv in r.severity), default=0)
        return (numeric, type_pref)

    records_sorted = sorted(records, key=_score, reverse=True)
    base = OsvRecord(
        id        = records_sorted[0].id,
        aliases   = [],
        related   = [],
        summary   = records_sorted[0].summary or "",
        details   = records_sorted[0].details or "",
        severity  = records_sorted[0].severity or [],
        published = records_sorted[0].published,
        modified  = records_sorted[0].modified,
        withdrawn = next((r.withdrawn for r in records_sorted if r.withdrawn), None),
        references = [],
        credits    = [],
        affected   = [],
    )
    seen_ids: set = set()
    seen_refs: set = set()
    for rec in records_sorted:
        for aid in rec.all_ids():
            if aid and aid not in seen_ids:
                if aid != base.id:
                    base.aliases.append(aid)
                seen_ids.add(aid)
        for ref in rec.references:
            url = ref.get("url", "")
            if url and url not in seen_refs:
                base.references.append(ref)
                seen_refs.add(url)
        base.affected.extend(rec.affected)
        if not base.related:
            base.related = rec.related

    return base


# ---------------------------------------------------------------------------
# EPSS client
# ---------------------------------------------------------------------------


class EPSSClient:
    """
    Batch-fetch EPSS scores from FIRST.

    EPSS API accepts comma-separated CVE IDs as query param:
      GET https://api.first.org/data/v1/epss?cve=CVE-A,CVE-B,...

    Cache: one JSON file per day keyed by CVE ID.
    On error: returns empty dict (graceful fallback).
    """

    def fetch(self, cve_ids: List[str]) -> Dict[str, Tuple[float, int]]:
        """
        Returns {cve_id: (epss_score, percentile)} for known CVEs.
        Non-CVE IDs (GHSA-*) are skipped — EPSS only covers CVEs.
        """
        real_cves = [c for c in cve_ids if c.startswith("CVE-")]
        if not real_cves:
            return {}

        cache_path = _epss_cache_path()
        day_cache: Dict[str, Any] = {}

        if _is_fresh(cache_path, EPSS_TTL_HOURS):
            day_cache = _read_json(cache_path) or {}

        result: Dict[str, Tuple[float, int]] = {}
        misses: List[str] = []

        for cve in real_cves:
            if cve in day_cache:
                entry = day_cache[cve]
                result[cve] = (entry["epss"], entry["percentile"])
            else:
                misses.append(cve)

        if not misses:
            logger.debug(f"EPSS: all {len(real_cves)} CVEs from cache")
            return result

        logger.info(f" EPSS: fetching {len(misses)} CVEs (cache miss), {len(result)} cached")
        t0 = time.time()

        # EPSS supports up to 2000 CVEs per request
        CHUNK = 2000
        for i in range(0, len(misses), CHUNK):
            chunk = misses[i : i + CHUNK]
            url = f"{EPSS_BATCH_URL}?cve={','.join(chunk)}&limit={len(chunk)}"
            raw = _http_get(url, EPSS_TIMEOUT_S)
            if raw is None:
                logger.warning(f" EPSS: fetch failed after {time.time() - t0:.1f}s — EPSS scores unavailable")
                break

            try:
                data = json.loads(raw)
            except Exception:
                logger.warning(" EPSS: invalid JSON response")
                break

            for item in data.get("data", []):
                cve = item.get("cve", "")
                try:
                    score = float(item.get("epss", 0))
                    pct = round(float(item.get("percentile", 0)) * 100)
                except (ValueError, TypeError):
                    score, pct = 0.0, 0
                result[cve] = (score, pct)
                day_cache[cve] = {"epss": score, "percentile": pct}

        elapsed = time.time() - t0
        logger.info(f" EPSS: {len(result)} scores in {elapsed:.1f}s")
        _write_json(cache_path, day_cache)
        return result


# ---------------------------------------------------------------------------
# KEV client
# ---------------------------------------------------------------------------


class KEVClient:
    """
    Download and cache the CISA Known Exploited Vulnerabilities catalog.

    The catalog is a single ~200 KB JSON file. We cache it for 24h.
    Lookup is a simple set membership check on CVE IDs.
    On error: returns None (caller treats as "unknown", not "not in KEV").
    """

    def __init__(self):
        self._kev_set: Optional[set] = None

    def load(self) -> Optional[set]:
        """Returns set of CVE IDs in KEV catalog, or None on failure."""
        if self._kev_set is not None:
            return self._kev_set

        cache_path = _kev_cache_path()

        if _is_fresh(cache_path, KEV_TTL_HOURS):
            cached = _read_json(cache_path)
            if cached and isinstance(cached, list):
                self._kev_set = set(cached)
                logger.debug(f"KEV: {len(self._kev_set)} entries from cache")
                return self._kev_set

        logger.info(" KEV: downloading CISA catalog")
        t0 = time.time()
        raw = _http_get(KEV_URL, KEV_TIMEOUT_S)
        elapsed = time.time() - t0

        if raw is None:
            logger.warning(f" KEV: download failed after {elapsed:.1f}s — KEV status will be unknown")
            return None

        try:
            catalog = json.loads(raw)
            vulns = catalog.get("vulnerabilities", [])
            cve_ids = [v["cveID"] for v in vulns if v.get("cveID")]
            self._kev_set = set(cve_ids)
            _write_json(cache_path, cve_ids)
            logger.info(f" KEV: {len(self._kev_set)} entries loaded in {elapsed:.1f}s")
            return self._kev_set
        except Exception as exc:
            logger.warning(f" KEV: parse error — {exc}")
            return None

    def is_kev(self, cve_id: str) -> Optional[bool]:
        """
        Returns True/False/None.
        None means catalog unavailable — distinguish from False (confirmed not in KEV).
        """
        kev_set = self.load()
        if kev_set is None:
            return None
        return cve_id in kev_set


# ---------------------------------------------------------------------------
# Risk level derivation
# ---------------------------------------------------------------------------


def _derive_risk_level(
    base_severity: str,
    is_reachable: Optional[bool],
    epss_score: Optional[float],
    is_kev: Optional[bool],
) -> str:
    """
    Derive final risk_level incorporating threat intel signals.

    Rules (applied in order, highest-wins):
      1. KEV = True                         → floor at HIGH
      2. EPSS ≥ 0.9                         → bump one level (any reachability)
      3. EPSS ≥ 0.5 AND reachable           → bump one level
      4. Base severity (from CVSS)          → baseline

    Returns: 'CRITICAL' | 'HIGH' | 'MEDIUM' | 'LOW' | 'INFO'
    """
    rank = _SEVERITY_RANK.get((base_severity or "").upper(), 1)

    # Rule 3: high EPSS + reachable → bump
    if epss_score and epss_score >= 0.5 and is_reachable:
        rank = min(rank + 1, 4)

    # Rule 2: very high EPSS → bump regardless
    if epss_score and epss_score >= 0.9:
        rank = min(rank + 1, 4)

    # Rule 1: KEV floors at HIGH
    if is_kev:
        rank = max(rank, _SEVERITY_RANK["HIGH"])

    return _RANK_SEVERITY.get(rank, "MEDIUM")


# ---------------------------------------------------------------------------
# Main enrichment entry point
# ---------------------------------------------------------------------------


class ThreatIntelEnricher:
    """
    Orchestrates OSV + EPSS + KEV enrichment for a batch of findings.

    Usage:
        enricher = ThreatIntelEnricher()
        findings = enricher.enrich(findings)

    Each finding dict gains:
        epss_score, epss_percentile, is_kev,
        go_vuln_id, fix_commit_url,
        fix_version (normalized if pseudo-version),
        fix_version_raw (original Grype value, always preserved),
        risk_level (recalculated with threat intel)
    """

    def __init__(self):
        self.osv = OSVClient()
        self.epss = EPSSClient()
        self.kev = KEVClient()

    def enrich(self, findings: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """
        Enrich all findings in a single pass.
        Non-CVE findings pass through unchanged.
        On any per-source failure the others still apply.
        """
        cve_findings = [f for f in findings if (f.get("finding_type") or f.get("type") or "").upper() == "CVE"]

        if not cve_findings:
            return findings

        t_total = time.time()
        logger.info(f" Threat intel enrichment: {len(cve_findings)} CVE findings")

        # _vuln_id: prefer cve_id over ghsa_id for EPSS/KEV lookup (they only index CVEs).
        # For OSV we query BOTH so we get records regardless of which ID is primary.
        def _vuln_id(f: dict) -> str:
            return f.get("cve_id") or f.get("ghsa_id") or f.get("vuln_id") or f.get("finding_id") or ""

        all_ids = list({_vuln_id(f) for f in cve_findings if _vuln_id(f)})
        cve_ids_only = [i for i in all_ids if i.startswith("CVE-")]

        # --- Fetch OSV / EPSS / KEV concurrently ---
        import threading

        osv_data: Dict[str, "OsvRecord"] = {}  # pkg_key -> OsvRecord
        epss_data: Dict[str, Tuple[float, int]] = {}
        kev_set: Optional[set] = None

        def _fetch_osv():
            nonlocal osv_data
            try:
                osv_data = self.osv.fetch(cve_findings)
            except Exception as e:
                logger.warning(f" OSV enrichment error: {e}")

        def _fetch_epss():
            nonlocal epss_data
            try:
                epss_data = self.epss.fetch(cve_ids_only)
            except Exception as e:
                logger.warning(f" EPSS enrichment error: {e}")

        def _fetch_kev():
            nonlocal kev_set
            try:
                kev_set = self.kev.load()
            except Exception as e:
                logger.warning(f" KEV enrichment error: {e}")

        threads = [
            threading.Thread(target=_fetch_osv, daemon=True),
            threading.Thread(target=_fetch_epss, daemon=True),
            threading.Thread(target=_fetch_kev, daemon=True),
        ]
        for t in threads:
            t.start()
        for t in threads:
            t.join(timeout=25)  # hard wall — must exceed OSV_TIMEOUT_S (15s) + margin

        logger.info(
            f" Threat intel fetched in {time.time() - t_total:.1f}s "
            f"(OSV:{len(osv_data)} EPSS:{len(epss_data)} KEV:{'ok' if kev_set else 'n/a'})"
        )

        # --- Merge enrichment into each finding ---
        enriched = []
        for f in findings:
            ftype = (f.get("finding_type") or f.get("type") or "").upper()
            if ftype != "CVE":
                enriched.append(f)
                continue

            f = dict(f)  # shallow copy — don't mutate caller's list
            vid = _vuln_id(f)
            pkg = (f.get("package_name") or f.get("package") or "").split(" ")[0].rstrip("/")
            # is_go controls: (a) pseudo-version replacement, (b) googlesource commit URL
            is_go = any(x in pkg for x in ["golang.org", "k8s.io", "gopkg.in", "go.uber.org", "github.com/"])

            # ----------------------------------------------------------------
            # OSV — OsvRecord for this finding's package@version
            # Keyed by _osv_pkg_key(pkg, ecosystem, version).
            # ----------------------------------------------------------------
            _art_type = f.get("artifact_type") or f.get("type") or ""
            _eco_for_key = _osv_ecosystem(_art_type, pkg)
            _ver_for_key = (f.get("version") or f.get("package_version") or "").strip()
            _osv_key = _osv_pkg_key(pkg, _eco_for_key, _ver_for_key) if _eco_for_key else ""
            osv_rec: OsvRecord = osv_data.get(_osv_key) if _osv_key else None  # type: ignore[assignment]
            has_osv = osv_rec is not None and osv_rec.id != ""

            if "fix_version_raw" not in f:
                f["fix_version_raw"] = f.get("fix_version")

            go_id = None
            commit_url = None

            if has_osv:
                logger.debug(f" OSV hit {vid} ({pkg}@{_ver_for_key}): {osv_rec.id} aliases={osv_rec.aliases[:3]}")

                # GO- alias — first GO- in all_ids()
                go_ids = osv_rec.go_ids()
                if go_ids:
                    go_id = go_ids[0]

                # Pseudo-version resolution for Go packages
                raw_fix = f.get("fix_version") or ""
                if is_go and _is_pseudo_version(raw_fix):
                    semver_fixes = extract_fix_versions(osv_rec, pkg, _eco_for_key or "Go")
                    if semver_fixes:
                        f["fix_version"] = semver_fixes[0]
                        logger.debug(f" {vid}: pseudo {raw_fix} → {semver_fixes[0]} (OSV package group)")
                    commit = extract_fix_commit(osv_rec, pkg, _eco_for_key or "Go")
                    if commit:
                        commit_url = _googlesource_url(pkg, commit)

                # OSV-derived CVSS score (augments Grype-supplied score if better)
                osv_cvss, osv_vector = best_cvss_score(osv_rec)
                if osv_cvss and not f.get("cvss_score"):
                    f["cvss_score"] = osv_cvss

                # Withdrawn flag — retracted vulns should be noted
                if osv_rec.is_withdrawn():
                    f["osv_withdrawn"] = osv_rec.withdrawn

                # Full alias list (CVE ↔ GHSA ↔ GO- ↔ PYSEC-) for cross-linking
                f["osv_aliases"] = osv_rec.aliases

                # One-liner summary from OSV (often clearer than NVD description)
                if osv_rec.summary and not f.get("osv_summary"):
                    f["osv_summary"] = osv_rec.summary

                # CWEs extracted from affected[].database_specific.cwes
                osv_cwes: list = []
                for g in osv_rec.affected:
                    for cid in database_cwes(g):
                        if cid not in osv_cwes:
                            osv_cwes.append(cid)
                if osv_cwes:
                    f["osv_cwes"] = osv_cwes

                # Fix references (patch URLs from OSV)
                fix_refs = osv_rec.fix_references()
                if fix_refs and not f.get("fix_commit_url"):
                    f.setdefault("fix_refs", fix_refs)

            else:
                _ver = f.get("version") or f.get("package_version") or ""
                logger.debug(f" OSV miss: {vid} pkg={pkg}@{_ver}")
                f.setdefault("osv_aliases", [])
                f.setdefault("osv_summary", None)

            f["go_vuln_id"] = go_id
            f["fix_commit_url"] = commit_url

            # ----------------------------------------------------------------
            # EPSS — try vid first, then CVE alias from OSV record
            # ----------------------------------------------------------------
            epss_entry = epss_data.get(vid)
            if epss_entry is None and has_osv:
                for cve_alias in osv_rec.cve_ids():
                    if cve_alias in epss_data:
                        epss_entry = epss_data[cve_alias]
                        break
            if epss_entry:
                f["epss_score"] = epss_entry[0]
                f["epss_percentile"] = epss_entry[1]
            else:
                f.setdefault("epss_score", None)
                f.setdefault("epss_percentile", None)

            # ----------------------------------------------------------------
            # KEV — need a CVE ID; derive from OSV aliases if vid is a GHSA
            # ----------------------------------------------------------------
            cve_id_for_kev = vid if vid.startswith("CVE-") else None
            if cve_id_for_kev is None and has_osv:
                cve_aliases = osv_rec.cve_ids()
                if cve_aliases:
                    cve_id_for_kev = cve_aliases[0]
            if cve_id_for_kev and kev_set is not None:
                f["is_kev"] = cve_id_for_kev in kev_set
            else:
                f.setdefault("is_kev", None)  # None = catalog unavailable, not False

            # ----------------------------------------------------------------
            # Risk level recalculation
            # ----------------------------------------------------------------
            base_sev = f.get("severity", "MEDIUM")
            is_reachable = f.get("is_reachable") or f.get("app_reachability") == "REACHABLE"
            f["risk_level"] = _derive_risk_level(
                base_severity=base_sev,
                is_reachable=is_reachable,
                epss_score=f.get("epss_score"),
                is_kev=f.get("is_kev"),
            )

            enriched.append(f)

        kev_count = sum(1 for f in enriched if f.get("is_kev") is True)
        epss_hi = sum(1 for f in enriched if (f.get("epss_score") or 0) >= 0.5)
        go_vulns = sum(1 for f in enriched if f.get("go_vuln_id"))
        pseudo_fix = sum(1 for f in enriched if _is_pseudo_version(f.get("fix_version_raw") or ""))
        resolved = sum(
            1
            for f in enriched
            if _is_pseudo_version(f.get("fix_version_raw") or "") and not _is_pseudo_version(f.get("fix_version") or "")
        )

        logger.info(
            f" Enrichment summary: "
            f"{kev_count} KEV | {epss_hi} EPSS≥0.5 | "
            f"{go_vulns} GO-aliases | "
            f"{resolved}/{pseudo_fix} pseudo-versions resolved"
        )
        return enriched


# ---------------------------------------------------------------------------
# Module-level convenience
# ---------------------------------------------------------------------------

_enricher_instance: Optional[ThreatIntelEnricher] = None


def get_enricher() -> ThreatIntelEnricher:
    global _enricher_instance
    if _enricher_instance is None:
        _enricher_instance = ThreatIntelEnricher()
    return _enricher_instance


def enrich_findings(findings: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """Module-level convenience wrapper."""
    return get_enricher().enrich(findings)
