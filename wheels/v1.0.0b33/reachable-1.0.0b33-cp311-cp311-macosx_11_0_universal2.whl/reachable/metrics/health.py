#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.

"""
Package Health Metrics Collector

Collects health/quality metrics for packages to identify leading indicators of risk:
- Maintenance: Is the package actively maintained?
- Popularity: Is it widely used and community-vetted?
- Outdated: How many versions behind is the installed version?
- Security Posture: OpenSSF Scorecard (if available)

These metrics help identify risks BEFORE they become CVEs.
"""

import json
import re
from dataclasses import asdict, dataclass
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Dict, List, Optional

from reachable.core.logger import logger

try:
    import requests
except ImportError:
    requests = None


@dataclass
class HealthMetrics:
    """Health metrics for a package"""

    package_name: str
    package_version: str
    ecosystem: str  # "pypi", "npm", "go"

    # Maintenance metrics
    last_commit_date: Optional[str] = None
    commits_last_year: Optional[int] = None
    days_since_last_commit: Optional[int] = None
    is_maintained: Optional[bool] = None
    maintenance_risk: str = "UNKNOWN"  # LOW, MEDIUM, HIGH, CRITICAL
    maintenance_score: float = 0.0  # 0-100

    # Popularity metrics
    downloads_last_month: Optional[int] = None
    github_stars: Optional[int] = None
    dependents_count: Optional[int] = None
    is_popular: Optional[bool] = None
    popularity_risk: str = "UNKNOWN"  # LOW, MEDIUM, HIGH, CRITICAL
    popularity_score: float = 0.0  # 0-100

    # Freshness metrics
    latest_version: Optional[str] = None
    versions_behind: Optional[int] = None
    is_outdated: Optional[bool] = None
    outdated_risk: str = "UNKNOWN"  # LOW, MEDIUM, HIGH, CRITICAL
    outdated_score: float = 0.0  # 0-100

    # Obsolescence metrics (NEW)
    publish_date: Optional[str] = None  # When this version was published
    version_age_days: Optional[int] = None  # Days since this version was published
    version_age_years: Optional[float] = None  # Years since publish (for display)
    is_deprecated: bool = False  # Whether package is deprecated
    deprecation_message: Optional[str] = None  # Deprecation message if any
    is_obsolete: bool = False  # True if version is very old (>3 years)
    obsolescence_risk: str = "UNKNOWN"  # LOW, MEDIUM, HIGH, CRITICAL
    latest_publish_date: Optional[str] = None  # When latest version was published

    # Security posture (OpenSSF Scorecard)
    security_scorecard: Optional[float] = None  # 0-10

    # Composite health
    health_penalty: float = 0.0  # Combined penalty (0-100)
    overall_health: str = "UNKNOWN"  # HEALTHY, CAUTION, RISKY, CRITICAL

    # Metadata
    data_sources: List[str] = None
    collection_date: str = None
    errors: List[str] = None

    def __post_init__(self):
        if self.data_sources is None:
            self.data_sources = []
        if self.errors is None:
            self.errors = []
        if self.collection_date is None:
            self.collection_date = datetime.now(timezone.utc).isoformat()


class PackageHealthCollector:
    """Collects health metrics for packages"""

    def __init__(self, cache_dir: Path = None):
        self.cache_dir = cache_dir or Path.home() / ".reachable" / "cache" / "health-metrics"
        self.cache_dir.mkdir(parents=True, exist_ok=True)

        # API rate limiting
        self.github_token = None  # Set from env: GITHUB_TOKEN
        self._load_github_token()

    def _load_github_token(self):
        """Load GitHub token from environment"""
        import os

        self.github_token = os.environ.get("GITHUB_TOKEN")

    def collect_metrics(self, package_name: str, package_version: str, ecosystem: str = "pypi") -> HealthMetrics:
        """
        Collect all health metrics for a package

        Args:
            package_name: Package name (e.g., "requests")
            package_version: Installed version (e.g., "2.28.0")
            ecosystem: Package ecosystem ("pypi", "npm", "go")

        Returns:
            HealthMetrics object with all available metrics
        """
        metrics = HealthMetrics(package_name=package_name, package_version=package_version, ecosystem=ecosystem)

        # Collect from different sources
        if ecosystem == "pypi":
            self._collect_pypi_metrics(metrics)
        elif ecosystem == "npm":
            self._collect_npm_metrics(metrics)
        elif ecosystem == "go":
            self._collect_go_metrics(metrics)

        # Collect GitHub metrics if repo found
        # Note: collect_health_metrics_for_sbom() calls _collect_github_metrics_batch()
        # after the parallel pass for efficiency. This per-package call is the
        # fallback used when collect_metrics() is called directly (not via SBOM).
        self._collect_github_metrics(metrics)

        # Calculate risk scores
        self._calculate_risk_scores(metrics)

        return metrics

    def _collect_pypi_metrics(self, metrics: HealthMetrics):
        """Collect metrics from PyPI including obsolescence detection"""
        try:
            # Get package info from PyPI
            url = f"https://pypi.org/pypi/{metrics.package_name}/json"
            response = requests.get(url, timeout=10)
            response.raise_for_status()

            data = response.json()
            metrics.data_sources.append("pypi")

            # Latest version
            metrics.latest_version = data["info"]["version"]

            # Calculate versions behind
            metrics.versions_behind = self._calculate_versions_behind(metrics.package_version, metrics.latest_version)

            # Get publish date for this version
            releases = data.get("releases", {})
            version = metrics.package_version
            if version in releases and releases[version]:
                # Get the first release file's upload time
                release_info = releases[version][0]
                upload_time = release_info.get("upload_time_iso_8601") or release_info.get("upload_time")
                if upload_time:
                    metrics.publish_date = upload_time
                    try:
                        if "T" in upload_time:
                            publish_dt = datetime.fromisoformat(upload_time.replace("Z", "+00:00"))
                        else:
                            publish_dt = datetime.strptime(upload_time, "%Y-%m-%dT%H:%M:%S")
                        now = datetime.utcnow()
                        if publish_dt.tzinfo:
                            now = datetime.now(publish_dt.tzinfo)
                        age_days = (now - publish_dt).days
                        metrics.version_age_days = age_days
                        metrics.version_age_years = round(age_days / 365.25, 1)

                        # Flag as obsolete if > 3 years old
                        if age_days > 3 * 365:
                            metrics.is_obsolete = True
                            metrics.obsolescence_risk = "HIGH" if age_days > 5 * 365 else "MEDIUM"
                    except Exception:
                        pass

            # Get latest version publish date
            if metrics.latest_version in releases and releases[metrics.latest_version]:
                latest_info = releases[metrics.latest_version][0]
                metrics.latest_publish_date = latest_info.get("upload_time_iso_8601") or latest_info.get("upload_time")

            # Check for deprecation/yanked status in classifiers
            classifiers = data["info"].get("classifiers", [])
            for classifier in classifiers:
                if "Development Status :: 7 - Inactive" in classifier:
                    metrics.is_deprecated = True
                    metrics.deprecation_message = "Package marked as Inactive"
                    metrics.obsolescence_risk = "HIGH"
                elif "Development Status :: 1 - Planning" in classifier:
                    metrics.obsolescence_risk = "MEDIUM"

            # Get GitHub URL from project URLs
            project_urls = data["info"].get("project_urls", {})
            github_url = None
            for key, url in project_urls.items():
                if "github.com" in url.lower():
                    github_url = url
                    break

            if not github_url:
                github_url = data["info"].get("home_page")
                if github_url and "github.com" not in github_url.lower():
                    github_url = None

            metrics.github_url = github_url

        except Exception as e:
            metrics.errors.append(f"PyPI error: {str(e)}")

    def _collect_npm_metrics(self, metrics: HealthMetrics):
        """Collect metrics from npm including obsolescence detection"""
        try:
            url = f"https://registry.npmjs.org/{metrics.package_name}"
            response = requests.get(url, timeout=10)
            response.raise_for_status()

            data = response.json()
            metrics.data_sources.append("npm")

            # Latest version
            metrics.latest_version = data.get("dist-tags", {}).get("latest")

            # Get publish dates for versions
            time_data = data.get("time", {})
            version = metrics.package_version

            # Get publish date for this specific version
            if version in time_data:
                metrics.publish_date = time_data[version]
                try:
                    publish_dt = datetime.fromisoformat(metrics.publish_date.replace("Z", "+00:00"))
                    now = datetime.now(publish_dt.tzinfo)
                    age_days = (now - publish_dt).days
                    metrics.version_age_days = age_days
                    metrics.version_age_years = round(age_days / 365.25, 1)

                    # Flag as obsolete if > 3 years old
                    if age_days > 3 * 365:
                        metrics.is_obsolete = True
                        metrics.obsolescence_risk = "HIGH" if age_days > 5 * 365 else "MEDIUM"
                except Exception:
                    pass

            # Get latest version publish date
            if metrics.latest_version and metrics.latest_version in time_data:
                metrics.latest_publish_date = time_data[metrics.latest_version]

            # Check for deprecation
            versions_data = data.get("versions", {})
            if version in versions_data:
                version_info = versions_data[version]
                if version_info.get("deprecated"):
                    metrics.is_deprecated = True
                    metrics.deprecation_message = version_info.get("deprecated", "Deprecated")
                    metrics.obsolescence_risk = "CRITICAL"

            # Check if entire package is deprecated
            if data.get("deprecated"):
                metrics.is_deprecated = True
                metrics.deprecation_message = data.get("deprecated", "Package deprecated")
                metrics.obsolescence_risk = "CRITICAL"

            # Downloads (need separate API call)
            downloads_url = f"https://api.npmjs.org/downloads/point/last-month/{metrics.package_name}"
            dl_response = requests.get(downloads_url, timeout=10)
            if dl_response.status_code == 200:
                dl_data = dl_response.json()
                metrics.downloads_last_month = dl_data.get("downloads", 0)

            # GitHub URL
            repo = data.get("repository", {})
            if isinstance(repo, dict):
                github_url = repo.get("url", "")
                if github_url:
                    # Clean npm URLs like "git+https://github.com/..."
                    github_url = re.sub(r"^git\+", "", github_url)
                    github_url = re.sub(r"\.git$", "", github_url)
                    metrics.github_url = github_url

        except Exception as e:
            metrics.errors.append(f"npm error: {str(e)}")

    def _collect_go_metrics(self, metrics: HealthMetrics):
        """Collect metrics from Go module proxy"""
        try:
            # Go modules use proxy.golang.org
            # Most Go packages are on GitHub
            if metrics.package_name.startswith("github.com/"):
                parts = metrics.package_name.split("/")
                if len(parts) >= 3:
                    metrics.github_url = f"https://github.com/{parts[1]}/{parts[2]}"

        except Exception as e:
            metrics.errors.append(f"Go error: {str(e)}")

    def _collect_github_metrics(self, metrics: HealthMetrics):
        """Collect metrics from GitHub"""
        if not hasattr(metrics, "github_url") or not metrics.github_url:
            return

        try:
            # Parse GitHub URL
            match = re.search(r"github\.com/([^/]+)/([^/]+)", metrics.github_url)
            if not match:
                return

            owner, repo = match.groups()
            repo = repo.rstrip(".git")

            # GitHub API
            api_url = f"https://api.github.com/repos/{owner}/{repo}"
            headers = {}
            if self.github_token:
                headers["Authorization"] = f"token {self.github_token}"

            response = requests.get(api_url, headers=headers, timeout=10)
            response.raise_for_status()

            data = response.json()
            metrics.data_sources.append("github")

            # Popularity metrics
            metrics.github_stars = data.get("stargazers_count", 0)

            # Last commit date
            commits_url = f"{api_url}/commits"
            commits_response = requests.get(commits_url, headers=headers, timeout=10, params={"per_page": 1})
            if commits_response.status_code == 200:
                commits = commits_response.json()
                if commits:
                    last_commit = commits[0]["commit"]["committer"]["date"]
                    metrics.last_commit_date = last_commit

                    # Calculate days since last commit
                    last_commit_dt = datetime.fromisoformat(last_commit.replace("Z", "+00:00"))
                    now = datetime.now(last_commit_dt.tzinfo)
                    metrics.days_since_last_commit = (now - last_commit_dt).days

            # Commits in last year
            one_year_ago = (datetime.utcnow() - timedelta(days=365)).isoformat() + "Z"
            commits_year_url = f"{api_url}/commits"
            params = {"since": one_year_ago, "per_page": 100}
            commits_year_response = requests.get(commits_year_url, headers=headers, timeout=10, params=params)
            if commits_year_response.status_code == 200:
                # Note: This only gets first 100, real count may be higher
                metrics.commits_last_year = len(commits_year_response.json())

        except Exception as e:
            metrics.errors.append(f"GitHub error: {str(e)}")

    def _collect_github_metrics_batch(self, metrics_list: list) -> None:
        """
        Batch GitHub metrics collection using GraphQL aliased queries.

        Replaces up to 3 REST calls per package with one GraphQL POST per 50
        packages. Falls back silently to per-package REST if token is missing
        or GraphQL fails.

        Mutates each HealthMetrics object in-place (same as _collect_github_metrics).
        Only processes packages that have a github_url attribute set.
        """
        if not self.github_token:
            # GraphQL requires auth — fall back to per-package REST
            for m in metrics_list:
                self._collect_github_metrics(m)
            return

        import json as _json
        import urllib.error
        import urllib.request
        from datetime import datetime as _dt
        from datetime import timedelta as _td
        from datetime import timezone as _tz

        GRAPHQL_URL = "https://api.github.com/graphql"
        CHUNK_SIZE = 50
        ONE_YEAR_AGO = (_dt.now(_tz.utc) - _td(days=365)).strftime("%Y-%m-%dT%H:%M:%SZ")

        # Only process packages that have a GitHub URL
        github_packages = []
        for m in metrics_list:
            if not hasattr(m, "github_url") or not m.github_url:
                continue
            match = re.search(r"github\.com/([^/]+)/([^/]+)", m.github_url)
            if not match:
                continue
            owner, repo = match.groups()
            repo = repo.rstrip(".git")
            github_packages.append((m, owner, repo))

        if not github_packages:
            return

        def _build_query(chunk):
            """Build aliased GraphQL query for up to 50 packages."""
            since = ONE_YEAR_AGO
            aliases = []
            for idx, (_, owner, repo) in enumerate(chunk):
                # Escape owner/repo for GraphQL string safety
                owner_s = owner.replace('"', '')
                repo_s = repo.replace('"', '')
                aliases.append(f'''
  pkg_{idx}: repository(owner: "{owner_s}", name: "{repo_s}") {{
    stargazerCount
    isArchived
    defaultBranchRef {{
      target {{
        ... on Commit {{
          history(first: 1) {{
            nodes {{ committedDate }}
          }}
        }}
      }}
    }}
    recentCommits: defaultBranchRef {{
      target {{
        ... on Commit {{
          history(since: "{since}", first: 0) {{
            totalCount
          }}
        }}
      }}
    }}
  }}''')
            return "query GetPackageHealth {" + "".join(aliases) + "}"

        def _post_graphql(query: str) -> dict:
            body = _json.dumps({"query": query}).encode()
            req = urllib.request.Request(
                GRAPHQL_URL,
                data=body,
                headers={
                    "Content-Type": "application/json",
                    "Authorization": f"Bearer {self.github_token}",
                    "User-Agent": "reachable-security/1.0",
                },
                method="POST",
            )
            with urllib.request.urlopen(req, timeout=15) as resp:
                return _json.loads(resp.read())

        # Process in chunks of CHUNK_SIZE
        for chunk_start in range(0, len(github_packages), CHUNK_SIZE):
            chunk = github_packages[chunk_start:chunk_start + CHUNK_SIZE]
            try:
                query = _build_query(chunk)
                response = _post_graphql(query)
                data = response.get("data") or {}

                for idx, (metrics, owner, repo) in enumerate(chunk):
                    alias = f"pkg_{idx}"
                    repo_data = data.get(alias)
                    if not repo_data:
                        continue

                    metrics.data_sources.append("github_graphql")
                    metrics.github_stars = repo_data.get("stargazerCount", 0)

                    # Last commit date from defaultBranchRef
                    try:
                        history_nodes = (
                            repo_data
                            .get("defaultBranchRef", {})
                            .get("target", {})
                            .get("history", {})
                            .get("nodes", [])
                        )
                        if history_nodes:
                            committed = history_nodes[0].get("committedDate", "")
                            if committed:
                                metrics.last_commit_date = committed
                                dt = _dt.fromisoformat(committed.replace("Z", "+00:00"))
                                metrics.days_since_last_commit = (_dt.now(dt.tzinfo) - dt).days
                    except Exception:
                        pass

                    # Commits last year — totalCount from recentCommits alias
                    try:
                        total_count = (
                            repo_data
                            .get("recentCommits", {})
                            .get("target", {})
                            .get("history", {})
                            .get("totalCount", None)
                        )
                        if total_count is not None:
                            metrics.commits_last_year = total_count
                    except Exception:
                        pass

            except Exception as e:
                # Chunk failed — fall back to per-package REST for this chunk
                logger.info(f" GraphQL batch failed (chunk {chunk_start}), falling back to REST: {e}")
                for metrics, owner, repo in chunk:
                    self._collect_github_metrics(metrics)

    def _calculate_versions_behind(self, current: str, latest: str) -> int:
        """Calculate how many versions behind current is from latest"""
        try:
            # Simple version comparison (works for semver)
            current_parts = [int(x) for x in current.split(".") if x.isdigit()]
            latest_parts = [int(x) for x in latest.split(".") if x.isdigit()]

            # Pad to same length
            max_len = max(len(current_parts), len(latest_parts))
            current_parts += [0] * (max_len - len(current_parts))
            latest_parts += [0] * (max_len - len(latest_parts))

            # Calculate difference
            if latest_parts[0] > current_parts[0]:
                # Major versions behind
                return latest_parts[0] - current_parts[0]
            elif latest_parts[1] > current_parts[1]:
                # Minor versions behind
                return latest_parts[1] - current_parts[1]
            elif latest_parts[2] > current_parts[2]:
                # Patch versions behind
                return 0  # Patches don't count as "versions behind"
            else:
                return 0

        except Exception:
            return None

    def _calculate_risk_scores(self, metrics: HealthMetrics):
        """Calculate risk scores from collected metrics

        v4.4.6 FIX: Don't mark packages as CRITICAL based on weak signals alone.
        - downloads_last_month = 0 often means "no data" (scoped/private packages)
        - Require at least 2 strong signals OR 1 definitive signal (deprecated/unmaintained)
        - If insufficient data, overall_health stays UNKNOWN
        """

        # Track number of valid signals for confidence scoring
        valid_signals = 0
        has_definitive_signal = False  # True if we have unmaintained or deprecated

        # ========== MAINTENANCE RISK ==========
        if metrics.days_since_last_commit is not None:
            days = metrics.days_since_last_commit
            valid_signals += 1

            if days < 90:
                # Active (< 3 months)
                metrics.maintenance_risk = "LOW"
                metrics.maintenance_score = 10
                metrics.is_maintained = True
            elif days < 180:
                # Moderately active (3-6 months)
                metrics.maintenance_risk = "LOW"
                metrics.maintenance_score = 20
                metrics.is_maintained = True
            elif days < 365:
                # Slow (6-12 months)
                metrics.maintenance_risk = "MEDIUM"
                metrics.maintenance_score = 40
                metrics.is_maintained = True
            elif days < 730:
                # Stale (1-2 years)
                metrics.maintenance_risk = "HIGH"
                metrics.maintenance_score = 70
                metrics.is_maintained = False
            else:
                # Dead (2+ years) - DEFINITIVE signal
                metrics.maintenance_risk = "CRITICAL"
                metrics.maintenance_score = 100
                metrics.is_maintained = False
                has_definitive_signal = True

        # ========== POPULARITY RISK ==========
        popularity_indicators = 0
        popularity_sum = 0

        # GitHub stars is a reliable signal
        if metrics.github_stars is not None:
            popularity_indicators += 1
            valid_signals += 1
            if metrics.github_stars > 10000:
                popularity_sum += 0  # Very popular
            elif metrics.github_stars > 1000:
                popularity_sum += 20
            elif metrics.github_stars > 100:
                popularity_sum += 40
            elif metrics.github_stars > 10:
                popularity_sum += 60
            else:
                popularity_sum += 80  # Low stars (not as bad as 0 downloads)

        # v4.4.6 FIX: downloads_last_month = 0 is NOT a valid signal
        # Many scoped packages (@scope/pkg) and private packages show 0 downloads
        # Only count downloads if > 0 (we actually have data)
        if metrics.downloads_last_month is not None and metrics.downloads_last_month > 0:
            popularity_indicators += 1
            valid_signals += 1
            if metrics.downloads_last_month > 1000000:
                popularity_sum += 0  # Very popular
            elif metrics.downloads_last_month > 100000:
                popularity_sum += 20
            elif metrics.downloads_last_month > 10000:
                popularity_sum += 40
            elif metrics.downloads_last_month > 1000:
                popularity_sum += 60
            else:
                popularity_sum += 80  # Low but positive downloads

        if popularity_indicators > 0:
            metrics.popularity_score = popularity_sum / popularity_indicators

            if metrics.popularity_score < 25:
                metrics.popularity_risk = "LOW"
                metrics.is_popular = True
            elif metrics.popularity_score < 50:
                metrics.popularity_risk = "MEDIUM"
                metrics.is_popular = True
            elif metrics.popularity_score < 75:
                metrics.popularity_risk = "HIGH"
                metrics.is_popular = False
            else:
                # v4.4.6: Only mark CRITICAL if we have strong evidence
                metrics.popularity_risk = "HIGH"  # Changed from CRITICAL
                metrics.is_popular = False

        # ========== OUTDATED RISK ==========
        if metrics.versions_behind is not None:
            versions = metrics.versions_behind
            valid_signals += 1

            if versions == 0:
                metrics.outdated_risk = "LOW"
                metrics.outdated_score = 0
                metrics.is_outdated = False
            elif versions == 1:
                metrics.outdated_risk = "LOW"
                metrics.outdated_score = 20
                metrics.is_outdated = False
            elif versions == 2:
                metrics.outdated_risk = "MEDIUM"
                metrics.outdated_score = 40
                metrics.is_outdated = True
            elif versions <= 5:
                metrics.outdated_risk = "HIGH"
                metrics.outdated_score = 70
                metrics.is_outdated = True
            else:
                metrics.outdated_risk = "CRITICAL"
                metrics.outdated_score = 100
                metrics.is_outdated = True

        # ========== OBSOLESCENCE RISK ==========
        # Based on version age, deprecation status
        obsolescence_score = 0

        if metrics.is_deprecated:
            # Deprecated packages are DEFINITIVE signal for critical risk
            metrics.obsolescence_risk = "CRITICAL"
            obsolescence_score = 100
            has_definitive_signal = True
            valid_signals += 1
        elif metrics.version_age_days is not None:
            valid_signals += 1
            age_days = metrics.version_age_days

            if age_days < 365:
                # Less than 1 year old - fresh
                metrics.obsolescence_risk = "LOW"
                obsolescence_score = 0
            elif age_days < 2 * 365:
                # 1-2 years old - getting stale
                metrics.obsolescence_risk = "LOW"
                obsolescence_score = 20
            elif age_days < 3 * 365:
                # 2-3 years old - old
                metrics.obsolescence_risk = "MEDIUM"
                obsolescence_score = 40
                metrics.is_obsolete = True
            elif age_days < 5 * 365:
                # 3-5 years old - very old
                metrics.obsolescence_risk = "HIGH"
                obsolescence_score = 70
                metrics.is_obsolete = True
            else:
                # 5+ years old - ancient (DEFINITIVE signal)
                metrics.obsolescence_risk = "CRITICAL"
                obsolescence_score = 100
                metrics.is_obsolete = True
                has_definitive_signal = True

        # ========== COMPOSITE HEALTH PENALTY ==========
        penalties = []
        weights = []

        if metrics.maintenance_score > 0:
            penalties.append(metrics.maintenance_score)
            weights.append(0.35)  # 35% weight
        if metrics.popularity_score > 0:
            penalties.append(metrics.popularity_score)
            weights.append(0.20)  # 20% weight
        if metrics.outdated_score > 0:
            penalties.append(metrics.outdated_score)
            weights.append(0.20)  # 20% weight
        if obsolescence_score > 0:
            penalties.append(obsolescence_score)
            weights.append(0.25)  # 25% weight - obsolescence is important

        # v4.4.6 FIX: Require sufficient signals before assigning health grade
        # - 0 signals: UNKNOWN (no data)
        # - 1 weak signal: UNKNOWN (insufficient confidence)
        # - 1 definitive signal (deprecated/unmaintained): use calculated grade
        # - 2+ signals: use calculated grade

        if not penalties:
            # No data at all - stay UNKNOWN
            metrics.overall_health = "UNKNOWN"
            return

        if len(penalties) == 1 and not has_definitive_signal:
            # Only 1 weak signal - not enough confidence
            # Exception: if it's a very low penalty (HEALTHY signal), we can trust it
            if penalties[0] <= 25:
                metrics.health_penalty = penalties[0]
                metrics.overall_health = "HEALTHY"
            else:
                # Single weak signal suggesting problems - stay UNKNOWN
                metrics.overall_health = "UNKNOWN"
            return

        # Calculate weighted health penalty
        weighted_sum = sum(p * w for p, w in zip(penalties, weights))
        weight_sum = sum(weights)
        metrics.health_penalty = weighted_sum / weight_sum if weight_sum > 0 else 0

        # Boost penalty for deprecated or very obsolete packages
        if metrics.is_deprecated or (metrics.version_age_days and metrics.version_age_days > 5 * 365):
            metrics.health_penalty = min(100, metrics.health_penalty * 1.5)

        # Overall health grade
        if metrics.health_penalty < 25:
            metrics.overall_health = "HEALTHY"
        elif metrics.health_penalty < 50:
            metrics.overall_health = "RISKY"  # Renamed from CAUTION for clarity
        elif metrics.health_penalty < 75:
            metrics.overall_health = "RISKY"
        else:
            metrics.overall_health = "CRITICAL"


def collect_health_metrics_for_sbom(
    sbom_file: str, max_workers: int = 10, use_cache: bool = True, cache_ttl_days: int = 7
) -> Dict[str, HealthMetrics]:
    """
    Collect health metrics for all packages in an SBOM (PARALLELIZED)

    Args:
        sbom_file: Path to SBOM JSON file (supports .json and .json.gz)
        max_workers: Number of parallel workers (default: 10)
        use_cache: Use cached results if available (default: True)
        cache_ttl_days: Cache expiration in days (default: 7)
                       SECURITY: Set lower for critical production systems
                       Recommended: 1-7 days for active monitoring

    Returns:
        Dict mapping package@version to HealthMetrics

    Performance:
        - Serial: ~850 packages in 10+ minutes
        - Parallel (10 workers): ~850 packages in 1-2 minutes
        - With cache: ~850 packages in 5-10 seconds

    Security:
        Cache expires after cache_ttl_days to detect:
        - Abandoned packages (maintenance status changes)
        - Compromised packages (popularity drops)
        - New vulnerabilities (GitHub activity)
        - Supply chain attacks (download count anomalies)
    """
    import concurrent.futures
    import gzip
    import hashlib
    from pathlib import Path

    # v4.4.5: Use compression module to handle all formats (gzip, zstd, lz4)
    sbom_path = Path(sbom_file) if isinstance(sbom_file, str) else sbom_file

    # v4.4.5: Robust file loading with multiple fallbacks
    sbom = None

    # Approach 1: Try the compression module (handles all formats automatically)
    try:
        from reachable.core.compression import load_json as load_json_compressed

        sbom = load_json_compressed(sbom_path)
    except Exception:
        pass  # Fall through to manual handling

    # Approach 2: Manual gzip handling (most common compressed format)
    if sbom is None and (str(sbom_path).endswith(".gz") or str(sbom_path).endswith(".json.gz")):
        try:
            with gzip.open(sbom_path, "rt", encoding="utf-8") as f:
                sbom = json.load(f)
        except Exception:
            pass  # Fall through to next approach

    # Approach 3: Try zstd if available
    if sbom is None and str(sbom_path).endswith(".zst"):
        try:
            import zstandard as zstd

            with open(sbom_path, "rb") as f:
                dctx = zstd.ZstdDecompressor()
                data = dctx.decompress(f.read())
                sbom = json.loads(data.decode("utf-8"))
        except Exception:
            pass  # Fall through to next approach

    # Approach 4: Try raw binary read and detect format from magic bytes
    if sbom is None:
        try:
            with open(sbom_path, "rb") as f:
                data = f.read()

            # Check for gzip magic bytes (1f 8b)
            if len(data) >= 2 and data[:2] == b"\x1f\x8b":
                sbom = json.loads(gzip.decompress(data).decode("utf-8"))
            # Check for zstd magic bytes (28 b5 2f fd)
            elif len(data) >= 4 and data[:4] == b"\x28\xb5\x2f\xfd":
                import zstandard as zstd

                dctx = zstd.ZstdDecompressor()
                sbom = json.loads(dctx.decompress(data).decode("utf-8"))
            else:
                # Assume uncompressed JSON
                sbom = json.loads(data.decode("utf-8"))
        except Exception:
            pass

    # Approach 5: Plain text JSON (fallback)
    if sbom is None:
        try:
            with open(sbom_path, encoding="utf-8") as f:
                sbom = json.load(f)
        except Exception as e:
            raise RuntimeError(f"Failed to load SBOM from {sbom_path}: {e}")

    if sbom is None:
        raise RuntimeError(f"Failed to load SBOM from {sbom_path}: unknown format")

    artifacts = sbom.get("artifacts", [])
    total = len(artifacts)

    # Setup cache directory
    cache_dir = Path.home() / ".reachable" / "cache" / "health-metrics"
    cache_dir.mkdir(parents=True, exist_ok=True)

    logger.info(f"Collecting health metrics for {total} packages...")
    if use_cache:
        logger.info(f" Using cache: {cache_dir}")
    logger.info(f" Parallel workers: {max_workers}")

    # Per-language breakdown
    lang_counts = {"npm": 0, "pypi": 0, "go": 0, "other": 0}
    for artifact in artifacts:
        pkg_type = artifact.get("type", "").lower()
        if "npm" in pkg_type or "javascript" in pkg_type:
            lang_counts["npm"] += 1
        elif "python" in pkg_type:
            lang_counts["pypi"] += 1
        elif "go" in pkg_type:
            lang_counts["go"] += 1
        else:
            lang_counts["other"] += 1

    lang_parts = []
    if lang_counts["npm"] > 0:
        lang_parts.append(f"JavaScript: {lang_counts['npm']}")
    if lang_counts["go"] > 0:
        lang_parts.append(f"Go: {lang_counts['go']}")
    if lang_counts["pypi"] > 0:
        lang_parts.append(f"Python: {lang_counts['pypi']}")
    if lang_counts["other"] > 0:
        lang_parts.append(f"Other: {lang_counts['other']}")

    if lang_parts:
        logger.info(f" By Language: {', '.join(lang_parts)}")
    collector = PackageHealthCollector()
    results = {}

    # Prepare work items
    work_items = []
    for artifact in artifacts:
        pkg_name = artifact.get("name")
        pkg_version = artifact.get("version")

        if not pkg_name or not pkg_version:
            continue

        # Determine ecosystem
        pkg_type = artifact.get("type", "").lower()
        if "python" in pkg_type:
            ecosystem = "pypi"
        elif "npm" in pkg_type or "javascript" in pkg_type:
            ecosystem = "npm"
        elif "go" in pkg_type:
            ecosystem = "go"
        else:
            ecosystem = "pypi"  # Default

        work_items.append((pkg_name, pkg_version, ecosystem))

    def process_package(item):
        """Process a single package (called in parallel)"""
        pkg_name, pkg_version, ecosystem = item
        key = f"{pkg_name}@{pkg_version}"

        # Check cache with expiration (7 days for security)
        if use_cache:
            cache_key = hashlib.md5(f"{pkg_name}@{pkg_version}@{ecosystem}".encode()).hexdigest()
            cache_file = cache_dir / f"{cache_key}.json"

            if cache_file.exists():
                try:
                    # Check cache age - use consistent timestamp handling
                    file_mtime = cache_file.stat().st_mtime
                    current_time = datetime.now().timestamp()
                    cache_age_days = (current_time - file_mtime) / (60 * 60 * 24)

                    # SECURITY: Expire cache after cache_ttl_days
                    # Why: Package status can change (abandoned, compromised, etc.)
                    if cache_age_days < cache_ttl_days:
                        with open(cache_file) as f:
                            cached_data = json.load(f)
                        # Reconstruct HealthMetrics from dict - only use valid fields
                        from dataclasses import fields as dc_fields

                        valid_fields = {f.name for f in dc_fields(HealthMetrics)}
                        filtered_data = {k: v for k, v in cached_data.items() if k in valid_fields}
                        metrics = HealthMetrics(**filtered_data)
                        return (key, metrics, True)  # True = from cache
                    else:
                        # Cache expired - delete and re-fetch
                        cache_file.unlink()
                except Exception:
                    pass  # Cache corrupted or expired, re-fetch

        # Fetch fresh data
        try:
            metrics = collector.collect_metrics(pkg_name, pkg_version, ecosystem)

            # Save to cache
            if use_cache:
                cache_key = hashlib.md5(f"{pkg_name}@{pkg_version}@{ecosystem}".encode()).hexdigest()
                cache_file = cache_dir / f"{cache_key}.json"
                try:
                    # Convert to dict for JSON serialization - use dataclasses.asdict
                    from dataclasses import fields

                    metrics_dict = {}
                    for field in fields(metrics):
                        value = getattr(metrics, field.name)
                        # Skip non-serializable values
                        if value is not None:
                            metrics_dict[field.name] = value

                    with open(cache_file, "w") as f:
                        json.dump(metrics_dict, f)
                except Exception:
                    pass  # Cache write failed, continue

            return (key, metrics, False)  # False = fresh fetch
        except Exception:
            # Return error metrics
            metrics = HealthMetrics(package_name=pkg_name, package_version=pkg_version, ecosystem=ecosystem)
            return (key, metrics, False)

    # Process in parallel with progress tracking
    completed = 0
    cached_count = 0

    with concurrent.futures.ThreadPoolExecutor(max_workers=max_workers) as executor:
        # Submit all work
        future_to_item = {executor.submit(process_package, item): item for item in work_items}

        # Process results as they complete
        for future in concurrent.futures.as_completed(future_to_item):
            item = future_to_item[future]
            pkg_name, pkg_version, ecosystem = item

            try:
                key, metrics, from_cache = future.result()
                results[key] = metrics
                completed += 1

                if from_cache:
                    cached_count += 1

                # Progress indicator (every 50 packages)
                if completed % 50 == 0 or completed == total:
                    cache_pct = (cached_count / completed * 100) if completed > 0 else 0
                    logger.info(f"[{completed}/{total}] {cache_pct:.0f}% from cache")

            except Exception:
                completed += 1

    # GitHub batch pass: replace per-package REST calls with one GraphQL
    # POST per 50 packages. Only runs on fresh (non-cached) results.
    # Falls back to per-package REST automatically if token missing or error.
    fresh_metrics = [m for m in results.values() if "github" not in m.data_sources and "github_graphql" not in m.data_sources]
    if fresh_metrics:
        logger.info(f" Running GitHub GraphQL batch for {len(fresh_metrics)} fresh packages...")
        collector._collect_github_metrics_batch(fresh_metrics)
        # Re-run risk scores for packages that got GitHub data
        for m in fresh_metrics:
            if "github_graphql" in m.data_sources:
                collector._calculate_risk_scores(m)

    logger.info(f" Collected metrics for {len(results)} packages")
    logger.info(f" Cached: {cached_count} ({cached_count / total * 100:.0f}%)")
    logger.info(f" Fresh: {total - cached_count}")
    if use_cache:
        logger.info(f" Cache TTL: {cache_ttl_days} days (security: auto-expires stale data)")
    return results


if __name__ == "__main__":
    import sys

    if len(sys.argv) < 2:
        logger.info("Usage: python health_metrics.py <sbom.json>")
        sys.exit(1)

    sbom_file = sys.argv[1]
    results = collect_health_metrics_for_sbom(sbom_file)

    # Summary statistics
    logger.info("HEALTH METRICS SUMMARY")
    total = len(results)
    critical = sum(1 for m in results.values() if m.overall_health == "CRITICAL")
    risky = sum(1 for m in results.values() if m.overall_health == "RISKY")
    caution = sum(1 for m in results.values() if m.overall_health == "CAUTION")
    healthy = sum(1 for m in results.values() if m.overall_health == "HEALTHY")

    logger.info(f"Total packages analyzed: {total}")
    logger.info(f" CRITICAL: {critical} ({critical / total * 100:.1f}%)")
    logger.info(f" RISKY: {risky} ({risky / total * 100:.1f}%)")
    logger.info(f" CAUTION: {caution} ({caution / total * 100:.1f}%)")
    logger.info(f" HEALTHY: {healthy} ({healthy / total * 100:.1f}%)")
    # Show critical packages
    if critical > 0:
        logger.info(" CRITICAL HEALTH ISSUES:")
        for key, metrics in results.items():
            if metrics.overall_health == "CRITICAL":
                logger.info(f" {metrics.package_name} {metrics.package_version}")
                if metrics.maintenance_risk == "CRITICAL":
                    logger.info(f" • Unmaintained ({metrics.days_since_last_commit} days since last commit)")
                if metrics.popularity_risk == "CRITICAL":
                    logger.info(f" • Unpopular ({metrics.github_stars} stars)")
                if metrics.outdated_risk == "CRITICAL":
                    logger.info(f" • Outdated ({metrics.versions_behind} versions behind)")
        logger.info("")

    # Save to file
    output_file = "health-metrics.json"
    with open(output_file, "w") as f:
        json.dump({k: asdict(v) for k, v in results.items()}, f, indent=2)

    logger.info(f" Detailed metrics saved to: {output_file}")
