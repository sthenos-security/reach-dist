# Copyright © 2026 Sthenos Security. All rights reserved.
"""
Option A — Socket-based log streaming for serial pipeline.

The parent process (run_serial_pipeline) starts a LogSocketReceiver before
spawning any step subprocess.  Each subprocess, when REACHABLE_LOG_PORT is
set in its environment, attaches a SocketHandler to the 'reachable' Python
logger.  The receiver captures all LogRecord objects emitted by any
reachable.* submodule and:

  1. Formats and prints them to stdout in real time (~200 ms latency max)
  2. Writes them to session_dir/scan.log via a 64 KB buffered writer
     (reduces syscalls ~100x compared to line-by-line flushing)

Design constraints
──────────────────
• Pure stdlib: socket, socketserver, logging.handlers, pickle, io, threading
• Daemon thread — scan always completes even if the receiver crashes
• Graceful shutdown: stop_event + explicit flush/close in server_close()
• Never raises — every error path is silently swallowed
• Zero impact when REACHABLE_LOG_PORT is absent from the environment
• Only activated in serial mode; parallel mode uses [step] stdout prefixes

Receiver lifecycle (run_serial_pipeline)
─────────────────────────────────────────
  handle = start_log_receiver(session_dir / "scan.log", debug=debug)
  env["REACHABLE_LOG_PORT"] = str(handle.port)
  # ... spawn step subprocesses …
  stop_log_receiver(handle)      # flushes + closes log file

Subprocess hook (pipeline_step)
────────────────────────────────
  _attach_socket_log_handler(debug=debug)   # no-op if LOG_PORT not set
"""

from __future__ import annotations

import io
import logging
import pickle
import socketserver
import struct
import threading
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

_logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# ANSI colour palette (matches the existing _log output style)
# ---------------------------------------------------------------------------

_RESET  = "\x1b[0m"
_GREY   = "\x1b[90m"
_CYAN   = "\x1b[36m"
_YELLOW = "\x1b[33m"
_RED    = "\x1b[31m"

_LEVEL_COLOUR: dict[str, str] = {
    "DEBUG":    _GREY,
    "INFO":     _CYAN,
    "WARNING":  _YELLOW,
    "ERROR":    _RED,
    "CRITICAL": _RED,
}


def _fmt_console(record: logging.LogRecord) -> str:
    """Format a LogRecord for stdout (with ANSI colour)."""
    import datetime
    ts    = datetime.datetime.fromtimestamp(record.created).strftime("%Y-%m-%dT%H:%M:%S")
    level = record.levelname
    colour = _LEVEL_COLOUR.get(level, "")
    return f"{ts} {colour}[{level}]{_RESET} {record.name}: {record.getMessage()}"


def _fmt_file(record: logging.LogRecord) -> str:
    """Format a LogRecord for the log file (no ANSI, newline-terminated)."""
    import datetime
    ts    = datetime.datetime.fromtimestamp(record.created).strftime("%Y-%m-%dT%H:%M:%S")
    level = record.levelname
    return f"{ts} [{level}] {record.name}: {record.getMessage()}\n"


# ---------------------------------------------------------------------------
# Per-connection stream handler
# ---------------------------------------------------------------------------

class _LogStreamHandler(socketserver.StreamRequestHandler):
    """
    Handles one connected SocketHandler client (one step subprocess).

    Python's logging.handlers.SocketHandler sends records as:
      [4-byte big-endian length][pickle of LogRecord.__dict__]
    """

    def handle(self) -> None:
        receiver: LogSocketReceiver = self.server  # type: ignore[assignment]
        while not receiver.stop_event.is_set():
            try:
                header = self._recv_exact(4)
                if header is None:
                    break
                slen = struct.unpack(">L", header)[0]
                if slen > 4 * 1024 * 1024:  # 4 MB sanity cap
                    break
                data = self._recv_exact(slen)
                if data is None:
                    break
                record_dict = pickle.loads(data)  # noqa: S301 — localhost only
                record = logging.makeLogRecord(record_dict)
                receiver._emit(record)
            except Exception:
                break  # client disconnected or malformed data — stop quietly

    def _recv_exact(self, n: int) -> Optional[bytes]:
        """Read exactly n bytes, returning None on EOF or error."""
        buf = b""
        while len(buf) < n:
            try:
                chunk = self.connection.recv(n - len(buf))
            except OSError:
                return None
            if not chunk:
                return None
            buf += chunk
        return buf


# ---------------------------------------------------------------------------
# TCP receiver server
# ---------------------------------------------------------------------------

class LogSocketReceiver(socketserver.ThreadingTCPServer):
    """
    Binds to 127.0.0.1 on OS-assigned port (port=0).
    Receives LogRecord objects and writes to stdout + buffered scan.log.
    """

    allow_reuse_address = True
    daemon_threads = True  # handler threads don't block interpreter exit

    def __init__(self, log_path: Optional[Path], debug: bool) -> None:
        super().__init__(("127.0.0.1", 0), _LogStreamHandler)
        self.port: int = self.server_address[1]  # OS-assigned port
        self.stop_event = threading.Event()
        self._debug = debug
        self._lock = threading.Lock()

        # Buffered file writer — 64 KB buffer reduces disk I/O by ~100x
        self._raw_fh: Optional[io.RawIOBase] = None
        self._buf_fh: Optional[io.BufferedWriter] = None
        if log_path:
            try:
                log_path.parent.mkdir(parents=True, exist_ok=True)
                self._raw_fh = open(log_path, "ab", buffering=0)  # raw unbuffered bytes
                self._buf_fh = io.BufferedWriter(self._raw_fh, buffer_size=65_536)
            except Exception as exc:
                _logger.debug("log_socket: cannot open log file %s: %s", log_path, exc)

        self._record_count = 0
        self._last_flush   = time.monotonic()

    # ------------------------------------------------------------------
    # Emit (called from _LogStreamHandler.handle in a handler thread)
    # ------------------------------------------------------------------

    def _emit(self, record: logging.LogRecord) -> None:
        """Format and write one received record to stdout + log file."""
        # Respect debug flag — suppress DEBUG records unless --debug is active
        if record.levelno < logging.INFO and not self._debug:
            return

        try:
            console_line = _fmt_console(record)
            with self._lock:
                print(console_line, flush=True)

                if self._buf_fh:
                    self._buf_fh.write(_fmt_file(record).encode("utf-8", errors="replace"))
                    self._record_count += 1
                    now = time.monotonic()
                    # Flush every 50 records or every 2 seconds — whichever comes first
                    if self._record_count >= 50 or (now - self._last_flush) >= 2.0:
                        self._buf_fh.flush()
                        self._record_count = 0
                        self._last_flush   = now
        except Exception:
            pass  # never let an emit error crash a step

    # ------------------------------------------------------------------
    # Cleanup
    # ------------------------------------------------------------------

    def flush_and_close(self) -> None:
        """Final flush + close of the buffered log file.  Safe to call twice."""
        try:
            if self._buf_fh:
                self._buf_fh.flush()
                self._buf_fh.close()
                self._buf_fh = None
            if self._raw_fh:
                self._raw_fh.close()
                self._raw_fh = None
        except Exception:
            pass

    def server_close(self) -> None:  # override
        self.stop_event.set()
        self.flush_and_close()
        super().server_close()


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

@dataclass
class ReceiverHandle:
    """Returned by start_log_receiver.  Pass handle.port to subprocesses."""
    receiver: LogSocketReceiver
    thread: threading.Thread
    port: int  # 0 → receiver failed to start (scan continues without logging)


def start_log_receiver(log_path: Optional[Path], debug: bool) -> ReceiverHandle:
    """
    Bind the TCP receiver and start its serve_forever loop in a daemon thread.

    Args:
        log_path: Path to write scan.log.  None → stdout only.
        debug:    True → forward DEBUG records; False → INFO and above only.

    Returns:
        ReceiverHandle with .port set to the bound port (0 on failure).
    """
    try:
        receiver = LogSocketReceiver(log_path=log_path, debug=debug)
        thread = threading.Thread(
            target=receiver.serve_forever,
            name="reach-log-receiver",
            daemon=True,
        )
        thread.start()
        # Give the server loop a moment to enter select() before the first
        # subprocess is spawned — prevents the very first SocketHandler
        # connection from hitting a "connection refused".
        time.sleep(0.05)
        return ReceiverHandle(receiver=receiver, thread=thread, port=receiver.port)

    except Exception as exc:
        _logger.debug("log_socket: failed to start receiver: %s", exc)
        # Dummy handle — scan proceeds normally, just without socket log streaming
        dummy_thread = threading.Thread(daemon=True)

        class _Dummy:
            def shutdown(self) -> None: pass
            def server_close(self) -> None: pass

        return ReceiverHandle(receiver=_Dummy(), thread=dummy_thread, port=0)  # type: ignore[arg-type]


def stop_log_receiver(handle: ReceiverHandle) -> None:
    """
    Gracefully shut down the receiver after all pipeline steps complete.
    Flushes and closes the log file before returning.
    """
    if handle.port == 0:
        return  # dummy handle — nothing to do
    try:
        handle.receiver.shutdown()    # signals serve_forever to exit
        handle.receiver.server_close()  # flush + close log file
        handle.thread.join(timeout=2.0)
    except Exception:
        pass


def attach_socket_log_handler(debug: bool) -> None:
    """
    Called inside each step subprocess (pipeline_step) AFTER _log.configure().

    Reads REACHABLE_LOG_PORT from the environment.  If set, attaches a
    SocketHandler to the 'reachable' Python logger so that all reachable.*
    submodule loggers forward their records to the parent receiver.

    No-op when REACHABLE_LOG_PORT is absent (normal / CI / parallel mode).
    Never raises.
    """
    import logging.handlers
    import os

    port_str = os.environ.get("REACHABLE_LOG_PORT")
    if not port_str:
        return

    try:
        port = int(port_str)
        if port <= 0:
            return

        # Idempotency guard — if a SocketHandler is already attached (e.g.
        # attach called twice via an import side-effect), do not add a second
        # one.  Two SocketHandlers on the same logger would cause every record
        # to be sent twice and written twice to scan.log.
        py_logger = logging.getLogger("reachable")
        for _existing in py_logger.handlers:
            if isinstance(_existing, logging.handlers.SocketHandler):
                return

        handler = logging.handlers.SocketHandler("127.0.0.1", port)
        handler.setLevel(logging.DEBUG if debug else logging.INFO)
        py_logger.addHandler(handler)

    except Exception as exc:
        # Log to stderr only (don't use _log — it may not be configured yet)
        import sys
        print(f"[reach-log-socket] attach failed: {exc}", file=sys.stderr, flush=True)
