#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.

"""
Centralized configuration for REACHABLE.

Single source of truth for all tuneable settings: cache TTLs, scanner
timeouts, maintenance policies, and storage parameters.

Priority (highest → lowest):
  1. Environment variable  (always wins — CI/CD escape hatch)
  2. ~/.reachable/config.json  (user / operator preference)
  3. Compiled-in DEFAULT_CONFIG  (safe production defaults)

Environment variables and their config.json equivalents:

  REACHABLE_CACHE_TTL_HOURS      cache.semgrep_ttl_hours
  GUARDDOG_CACHE_TTL             cache.guarddog_ttl_seconds  (seconds)
  REACHABLE_SEMGREP_JOBS         scanners.semgrep_jobs
  REACHABLE_TRACE_SEMGREP        scanners.semgrep_trace
  GUARDDOG_ERROR_LIMIT           scanners.guarddog_error_limit
  REACHABLE_CACHE_DIR            paths.cache_dir_override

Scanner-specific FP suppression is configured via per-repo exclude files
under ~/.reachable/scans/{slug}/ (managed by REACHABLE, not by config.json):
  guarddog-exclude.txt  — seeded from GuardDogScanner.DEFAULT_EXCLUDE_PATHS
  semgrep-exclude.txt   — seeded from SemgrepScanner.EXCLUDE_DIRS
Edit those files freely to tune per-repo behaviour.
"""

import copy
import json
import os
from pathlib import Path
from typing import Any, Dict, Optional

# Config file path (can be patched in tests)
CONFIG_PATH = Path.home() / ".reachable" / "config.json"


# ---------------------------------------------------------------------------
# Default configuration — every tuneable lives here
# ---------------------------------------------------------------------------
DEFAULT_CONFIG: Dict[str, Any] = {
    "version": "2.0",

    # ── Cache TTLs ──────────────────────────────────────────────────────────
    # How long scan results/DBs are considered fresh before a live re-run.
    # All values in hours unless noted.  0 = disable cache entirely.
    "cache": {
        # Semgrep rules cache (secrets + CWE scans).
        # Env override: REACHABLE_CACHE_TTL_HOURS
        "semgrep_ttl_hours": 24,

        # GuardDog per-package result cache (in seconds — GuardDog native unit).
        # Default: 7 days.  Env override: GUARDDOG_CACHE_TTL
        "guarddog_ttl_seconds": 7 * 24 * 60 * 60,

        # Grype vulnerability DB maximum age before auto-refresh.
        "grype_db_max_age_hours": 24,

        # Dynamic malware sandbox result cache.
        "sandbox_ttl_hours": 24,
    },

    # ── Timeouts ─────────────────────────────────────────────────────────────
    # All values in seconds.
    "timeouts": {
        # Syft SBOM generation per repo.
        "syft_seconds": 600,

        # Grype vulnerability scan per repo.
        "grype_scan_seconds": 300,

        # Grype vulnerability DB download/update.
        "grype_db_update_seconds": 300,

        # Quick grype version probe.
        "grype_version_check_seconds": 10,

        # Semgrep: floor timeout applied to any repo (< 50 source files).
        "semgrep_min_seconds": 120,

        # Semgrep: ceiling — no scan ever runs longer than this.
        "semgrep_max_seconds": 900,

        # Semgrep: additional seconds per source file above the 50-file floor.
        "semgrep_per_file_seconds": 3,

        # Semgrep: floor applies below this file count; linear scaling above.
        "semgrep_per_file_threshold": 50,

        # GuardDog: per-package remote scan.
        "guarddog_package_seconds": 30,

        # GuardDog: local directory scan.
        "guarddog_local_seconds": 60,

        # SQLite WAL busy-wait before giving up.
        "db_busy_timeout_ms": 5000,
    },

    # ── Scanner parameters ───────────────────────────────────────────────────
    "scanners": {
        # Semgrep parallel jobs.  null = auto (cpu_count × 0.85).
        # Env override: REACHABLE_SEMGREP_JOBS
        "semgrep_jobs": None,

        # Enable semgrep --time rule-level timing output (debug aid).
        # Env override: REACHABLE_TRACE_SEMGREP=1
        "semgrep_trace": False,

        # Max GuardDog per-scan error messages before suppression.
        # -1 = unlimited.  Env override: GUARDDOG_ERROR_LIMIT
        "guarddog_error_limit": 10,
    },

    # ── Path overrides ───────────────────────────────────────────────────────
    "paths": {
        # Override the entire cache root (useful for CI layer caching).
        # null = ~/.reachable/cache.  Env override: REACHABLE_CACHE_DIR
        "cache_dir_override": None,
    },

    # ── Auto-maintenance ─────────────────────────────────────────────────────
    "auto_maintenance": {
        "enabled": True,
        "wal_checkpoint": True,
        "vacuum_enabled": True,
        "vacuum_threshold_pct": 30,
        "prune_enabled": True,
        "max_scans_per_branch": 50,
        "max_age_days": 30,
    },

    # ── User preferences (reserved for future use) ───────────────────────────
    "user_preferences": {},
}


def get_config_path() -> Path:
    """Get path to config file"""
    return CONFIG_PATH


# ---------------------------------------------------------------------------
# Core load / save
# ---------------------------------------------------------------------------

def load_config() -> Dict[str, Any]:
    """
    Load configuration from ~/.reachable/config.json.

    Returns default config if file doesn't exist or is invalid.
    """
    config_path = get_config_path()

    if not config_path.exists():
        # Create default config file
        default = copy.deepcopy(DEFAULT_CONFIG)
        save_config(default)
        return default

    try:
        with open(config_path) as f:
            user_config = json.load(f)

        # Merge with defaults (in case new settings were added)
        config = copy.deepcopy(DEFAULT_CONFIG)
        _deep_merge(config, user_config)

        return config
    except Exception:
        # If config is corrupted, return defaults
        return copy.deepcopy(DEFAULT_CONFIG)


def save_config(config: Dict[str, Any]) -> bool:
    """
    Save configuration to ~/.reachable/config.json

    Returns:
        True if successful, False otherwise
    """
    config_path = get_config_path()

    try:
        # Ensure directory exists
        config_path.parent.mkdir(parents=True, exist_ok=True)

        # Write with pretty formatting
        with open(config_path, "w") as f:
            json.dump(config, f, indent=2)

        return True
    except Exception:
        return False


def get_config_value(key_path: str) -> Any:
    """
    Get a config value using dot notation.

    Examples:
        get_config_value('auto_maintenance.enabled') → True
        get_config_value('auto_maintenance.prune_max_scans') → 50

    Args:
        key_path: Dot-separated path to config value

    Returns:
        Config value or None if not found
    """
    config = load_config()

    keys = key_path.split(".")
    value = config

    for key in keys:
        if isinstance(value, dict) and key in value:
            value = value[key]
        else:
            return None

    return value


def set_config_value(key_path: str, value: Any) -> bool:
    """
    Set a config value using dot notation.

    Examples:
        set_config_value('auto_maintenance.enabled', True)
        set_config_value('auto_maintenance.prune_max_scans', 100)

    Args:
        key_path: Dot-separated path to config value
        value: New value

    Returns:
        True if successful, False otherwise
    """
    config = load_config()

    keys = key_path.split(".")

    # Navigate to parent dict
    current = config
    for key in keys[:-1]:
        if key not in current or not isinstance(current[key], dict):
            current[key] = {}
        current = current[key]

    # Set the value
    current[keys[-1]] = value

    return save_config(config)


def reset_config() -> bool:
    """
    Reset configuration to defaults.

    Returns:
        True if successful, False otherwise
    """
    return save_config(copy.deepcopy(DEFAULT_CONFIG))


def get_auto_maintenance_config() -> Dict[str, Any]:
    """
    Get auto-maintenance configuration section.

    Returns:
        Auto-maintenance config dict
    """
    config = load_config()
    return config.get("auto_maintenance", copy.deepcopy(DEFAULT_CONFIG["auto_maintenance"]))


def is_auto_maintenance_enabled() -> bool:
    """Check if auto-maintenance is enabled"""
    return get_config_value("auto_maintenance.enabled") is True


def should_checkpoint() -> bool:
    """Check if WAL checkpoint should run"""
    checkpoint_policy = get_config_value("auto_maintenance.wal_checkpoint")
    return checkpoint_policy is True


def should_vacuum() -> bool:
    """Check if vacuum is enabled"""
    return get_config_value("auto_maintenance.vacuum_enabled") is True


def get_vacuum_threshold() -> int:
    """Get vacuum bloat threshold percentage"""
    threshold = get_config_value("auto_maintenance.vacuum_threshold_pct")
    return threshold if threshold is not None else 30


def should_prune() -> bool:
    """Check if pruning is enabled"""
    return get_config_value("auto_maintenance.prune_enabled") is True


def get_prune_max_scans() -> int:
    """Get max scans per branch for pruning"""
    max_scans = get_config_value("auto_maintenance.max_scans_per_branch")
    return max_scans if max_scans is not None else 50


def get_prune_max_age_days() -> int:
    """Get max scan age in days for pruning"""
    max_age = get_config_value("auto_maintenance.max_age_days")
    return max_age if max_age is not None else 30


def _deep_merge(base: Dict, update: Dict) -> None:
    """
    Deep merge update dict into base dict (in-place).

    Used to merge user config with defaults, preserving new default settings.
    """
    for key, value in update.items():
        if key in base and isinstance(base[key], dict) and isinstance(value, dict):
            _deep_merge(base[key], value)
        else:
            base[key] = value


def validate_config_value(key_path: str, value: Any) -> tuple[bool, Optional[str]]:
    """
    Validate a config value before setting.

    Args:
        key_path: Dot-separated path to config value
        value: Value to validate

    Returns:
        (is_valid, error_message)
    """
    # Validate auto_maintenance settings
    if key_path == "auto_maintenance.enabled":
        if not isinstance(value, bool):
            return False, "Value must be true or false"

    elif key_path == "auto_maintenance.wal_checkpoint":
        if value not in ["always", "never", "auto"]:
            return False, "Value must be 'always', 'never', or 'auto'"

    elif key_path == "auto_maintenance.vacuum_enabled":
        if not isinstance(value, bool):
            return False, "Value must be true or false"

    elif key_path == "auto_maintenance.vacuum_threshold_pct":
        if not isinstance(value, int) or value < 0 or value > 100:
            return False, "Value must be an integer between 0 and 100"

    elif key_path == "auto_maintenance.prune_enabled":
        if not isinstance(value, bool):
            return False, "Value must be true or false"

    elif key_path == "auto_maintenance.prune_max_scans":
        if not isinstance(value, int) or value < 1:
            return False, "Value must be a positive integer"

    elif key_path == "auto_maintenance.prune_max_age_days":
        if not isinstance(value, int) or value < 1:
            return False, "Value must be a positive integer"

    else:
        # Unknown setting - allow it (for future extensibility)
        pass

    return True, None


# Convenience function for getting all config as formatted string
# ---------------------------------------------------------------------------
# Typed accessors — env var → config.json → default
# ---------------------------------------------------------------------------

def get_semgrep_ttl_hours() -> int:
    """Semgrep results cache TTL in hours.  REACHABLE_CACHE_TTL_HOURS wins."""
    env = os.environ.get("REACHABLE_CACHE_TTL_HOURS", "").strip()
    if env:
        try:
            return int(env)
        except ValueError:
            pass
    v = get_config_value("cache.semgrep_ttl_hours")
    return int(v) if v is not None else DEFAULT_CONFIG["cache"]["semgrep_ttl_hours"]


def get_guarddog_ttl_seconds() -> int:
    """GuardDog cache TTL in seconds.  GUARDDOG_CACHE_TTL wins."""
    env = os.environ.get("GUARDDOG_CACHE_TTL", "").strip()
    if env:
        try:
            return int(env)
        except ValueError:
            pass
    v = get_config_value("cache.guarddog_ttl_seconds")
    return int(v) if v is not None else DEFAULT_CONFIG["cache"]["guarddog_ttl_seconds"]


def get_grype_db_max_age_hours() -> int:
    """Grype vulnerability DB maximum age in hours before auto-refresh."""
    v = get_config_value("cache.grype_db_max_age_hours")
    return int(v) if v is not None else DEFAULT_CONFIG["cache"]["grype_db_max_age_hours"]


def get_sandbox_ttl_hours() -> int:
    """Dynamic malware sandbox cache TTL in hours."""
    v = get_config_value("cache.sandbox_ttl_hours")
    return int(v) if v is not None else DEFAULT_CONFIG["cache"]["sandbox_ttl_hours"]


def get_timeout(key: str) -> int:
    """
    Return a timeout value in seconds by key.

    Keys (all in DEFAULT_CONFIG["timeouts"]):
      syft_seconds, grype_scan_seconds, grype_db_update_seconds,
      grype_version_check_seconds, semgrep_min_seconds,
      semgrep_max_seconds, semgrep_per_file_seconds,
      semgrep_per_file_threshold, guarddog_package_seconds,
      guarddog_local_seconds, db_busy_timeout_ms
    """
    v = get_config_value(f"timeouts.{key}")
    if v is not None:
        return int(v)
    return int(DEFAULT_CONFIG["timeouts"].get(key, 60))


def get_semgrep_jobs() -> Optional[int]:
    """Semgrep -j value.  None = auto.  REACHABLE_SEMGREP_JOBS wins."""
    env = os.environ.get("REACHABLE_SEMGREP_JOBS", "").strip()
    if env:
        try:
            v = int(env)
            if v > 0:
                return v
        except ValueError:
            pass
    v = get_config_value("scanners.semgrep_jobs")
    if v is not None:
        try:
            return int(v) if int(v) > 0 else None
        except (TypeError, ValueError):
            pass
    return None  # auto


def get_semgrep_trace() -> bool:
    """Whether semgrep --time output is enabled.  REACHABLE_TRACE_SEMGREP=1 wins."""
    if os.environ.get("REACHABLE_TRACE_SEMGREP") == "1":
        return True
    v = get_config_value("scanners.semgrep_trace")
    return bool(v) if v is not None else DEFAULT_CONFIG["scanners"]["semgrep_trace"]


def get_guarddog_error_limit() -> int:
    """Max GuardDog error messages before suppression.  GUARDDOG_ERROR_LIMIT wins."""
    env = os.environ.get("GUARDDOG_ERROR_LIMIT", "").strip()
    if env:
        try:
            return int(env)
        except ValueError:
            pass
    v = get_config_value("scanners.guarddog_error_limit")
    return int(v) if v is not None else DEFAULT_CONFIG["scanners"]["guarddog_error_limit"]


def get_cache_dir_override() -> Optional[Path]:
    """Base cache directory override.  REACHABLE_CACHE_DIR wins."""
    env = os.environ.get("REACHABLE_CACHE_DIR", "").strip()
    if env:
        return Path(env).expanduser()
    v = get_config_value("paths.cache_dir_override")
    if v:
        return Path(str(v)).expanduser()
    return None


# ---------------------------------------------------------------------------
# Display helper
# ---------------------------------------------------------------------------

def format_config_display(config: Optional[Dict] = None) -> str:
    """
    Format config as human-readable display.

    Args:
        config: Config dict (loads if not provided)

    Returns:
        Formatted string
    """
    if config is None:
        config = load_config()

    auto_maint = config.get("auto_maintenance", {})

    lines = []
    lines.append("CONFIGURATION")
    lines.append("=" * 60)
    lines.append("")
    lines.append("Cache TTLs:")
    lines.append(f"  Semgrep TTL:         {get_semgrep_ttl_hours()}h")
    lines.append(f"  GuardDog TTL:        {get_guarddog_ttl_seconds() // 3600}h ({get_guarddog_ttl_seconds()}s)")
    lines.append(f"  Grype DB max age:    {get_grype_db_max_age_hours()}h")
    lines.append(f"  Sandbox TTL:         {get_sandbox_ttl_hours()}h")
    lines.append("")
    lines.append("Timeouts (seconds):")
    lines.append(f"  Syft:                {get_timeout('syft_seconds')}")
    lines.append(f"  Grype scan:          {get_timeout('grype_scan_seconds')}")
    lines.append(f"  Grype DB update:     {get_timeout('grype_db_update_seconds')}")
    lines.append(f"  Semgrep min/max:     {get_timeout('semgrep_min_seconds')}/{get_timeout('semgrep_max_seconds')}")
    lines.append(f"  GuardDog pkg:        {get_timeout('guarddog_package_seconds')}")
    lines.append(f"  GuardDog local:      {get_timeout('guarddog_local_seconds')}")
    lines.append(f"  DB busy timeout:     {get_timeout('db_busy_timeout_ms')}ms")
    lines.append("")
    lines.append("Scanners:")
    lines.append(f"  Semgrep jobs:        {get_semgrep_jobs() or 'auto'}")
    lines.append(f"  Semgrep trace:       {get_semgrep_trace()}")
    lines.append(f"  GuardDog err limit:  {get_guarddog_error_limit()}")
    lines.append("")
    lines.append("Paths:")
    override = get_cache_dir_override()
    lines.append(f"  Cache dir override:  {override or '(default ~/.reachable/cache)'}")
    lines.append("")
    lines.append("Auto-Maintenance:")
    lines.append(f"  Enabled:             {auto_maint.get('enabled', False)}")
    lines.append(f"  WAL Checkpoint:      {auto_maint.get('wal_checkpoint', True)}")
    lines.append(f"  Vacuum Enabled:      {auto_maint.get('vacuum_enabled', True)}")
    lines.append(f"  Vacuum Threshold:    {auto_maint.get('vacuum_threshold_pct', 30)}%")
    lines.append(f"  Pruning Enabled:     {auto_maint.get('prune_enabled', True)}")
    lines.append(f"  Max Scans/Branch:    {auto_maint.get('max_scans_per_branch', 50)}")
    lines.append(f"  Max Scan Age:        {auto_maint.get('max_age_days', 30)} days")
    lines.append("")
    lines.append(f"Config file: {get_config_path()}")

    return "\n".join(lines)
