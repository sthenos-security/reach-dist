# Copyright © 2026 Sthenos Security. All rights reserved.

"""
REACHABLE Unified Logger

Consolidates Python logging and stdout/stderr into a single system with:
- Timestamp toggle (on/off)
- Output modes: human (pretty), ci (minimal timestamps), json (structured)
- Per-scan log file support
- Structured scan progress (replaces scan_logger.py)

Usage:
    from reachable.core.logger import get_logger, OutputMode

    # Initialize at CLI entry
    logger = get_logger()
    logger.configure(
        mode=OutputMode.HUMAN,      # or CI, JSON
        timestamps=True,             # True/False
        debug=False,                 # --debug flag
        quiet=False,                 # -q flag
        log_file=Path("scan.log")   # Per-scan file
    )

    # Regular logging
    logger.info("Starting scan...")
    logger.debug("Detailed info")
    logger.warning("Something odd")
    logger.error("Failed!")

    # Structured scan output (replaces ScanLogger)
    logger.scan_start(repo="myrepo", version="5.2.0")
    logger.phase_start(1, "SBOM Analysis", scanner="syft")
    logger.phase_end(1, "423 packages")
    logger.scan_complete(risk_score=340, risk_level="MEDIUM")
"""

import json
import logging
import logging.handlers
import re
import sys
import time
from contextlib import contextmanager
from datetime import datetime
from enum import Enum
from pathlib import Path
from typing import Any, Dict, Optional

# Pre-compiled regex for stripping ANSI escape sequences from log file output
_ANSI_RE = re.compile(r"\x1b\[[0-9;]*m")



class _AnsiStrippingFormatter(logging.Formatter):
    """Formatter that strips ANSI escape codes (for log file output)."""

    def format(self, record):
        result = super().format(record)
        return _ANSI_RE.sub("", result)


class OutputMode(Enum):
    """Output format modes."""

    HUMAN = "human"  # Pretty output with emojis, progress bars
    CI = "ci"  # Clean output for CI/CD logs (no emojis, optional timestamps)
    JSON = "json"  # Structured JSON lines for machine parsing


class ReachableLogger:
    """
    Unified logger for REACHABLE.

    Singleton pattern - use get_logger() to access.
    """

    _instance: Optional["ReachableLogger"] = None

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance._initialized = False
        return cls._instance

    def __init__(self):
        if self._initialized:
            return

        self._initialized = True
        self._configured = False

        # Configuration
        self._mode: OutputMode = OutputMode.HUMAN
        self._timestamps: bool = False

        self._debug: bool = False
        self._quiet: bool = False

        # Output streams — use sys.stdout/stderr (not sys.__stdout__) so that
        # Python-level redirections (contextlib.redirect_stdout, pytest capsys,
        # concurrent mode suppression) work correctly.
        self._stdout = sys.stdout
        self._stderr = sys.stderr

        # Python logging integration
        self._py_logger = logging.getLogger("reachable")
        self._py_logger.setLevel(logging.WARNING)  # BUG 55 FIX: was DEBUG — caused --debug always-on behaviour
        self._py_logger.handlers.clear()
        self._py_logger.propagate = False

        # Scan state (for structured output)
        self._scan_start_time: Optional[float] = None
        self._phase_timings: Dict[int, Dict[str, Any]] = {}
        self._pending_line: bool = False

        # Results state (ported from ScanLogger)
        self._counts: Dict[str, Any] = {}
        self._dlp_scan_time: float = 0.0
        self._ai_scan_time: float = 0.0
        self._sub_phase_timings: Dict[str, float] = {}
        self._scanners: list = []
        self._policies: Dict[str, Dict[str, int]] = {
            "secrets": {},
            "cwe": {},
            "malware": {},
            "config": {},
        }
        self._compliance: Dict[str, int] = {}

        # No direct file handle — file output goes via stdlib → root → QueueHandler → scan.log.

    # =========================================================================
    # Configuration
    # =========================================================================

    def configure(
        self,
        mode: OutputMode = OutputMode.HUMAN,
        timestamps: bool = True,
        debug: bool = False,
        quiet: bool = False,
        log_file: Optional[Path] = None,  # kept for API compat, ignored — queue owns the file
    ):
        """
        Configure the logger.

        Console output: _write() → stdout.
        File output: _log_via_stdlib() → logging.getLogger("reachable") → root
                     → QueueHandler (set by start_log_queue) → FileHandler → scan.log.
        When no queue is active, root has NullHandler so file calls are no-ops.
        """
        self._mode = mode
        self._timestamps = timestamps
        self._debug = debug
        self._quiet = quiet

        # reachable logger: no handlers here, propagate to root.
        # start_log_queue() attaches QueueHandler to root — that's the file path.
        self._py_logger.handlers.clear()
        self._py_logger.propagate = True
        self._py_logger.setLevel(logging.DEBUG)  # let the FileHandler filter by level

        # Root: NullHandler when no queue active (non-scan commands, pre-scan).
        # start_log_queue() replaces this with QueueHandler.
        # If log_file is given (unit tests, non-scan commands), attach a direct FileHandler.
        root = logging.getLogger()

        # Always flush+close+remove any FileHandler we previously attached.
        # This must happen unconditionally — skipping it when a QueueHandler
        # is present was causing FileHandler accumulation across tests (FD leak).
        old_fh = getattr(self, "_file_handler", None)
        if old_fh is not None:
            try:
                old_fh.flush()
                old_fh.close()
                root.removeHandler(old_fh)
            except Exception:
                pass
            self._file_handler = None
        # Also sweep any stale FileHandlers left by previous instances
        # (e.g. when tests reset the singleton via _instance = None).
        for _h in list(root.handlers):
            if isinstance(_h, logging.FileHandler):
                try:
                    _h.flush()
                    _h.close()
                except Exception:
                    pass
                root.removeHandler(_h)

        has_queue = any(isinstance(h, logging.handlers.QueueHandler) for h in root.handlers)
        if not has_queue:
            if not root.handlers:
                root.addHandler(logging.NullHandler())
            root.setLevel(logging.DEBUG)

        if log_file is not None:
            log_file = Path(log_file)
            log_file.parent.mkdir(parents=True, exist_ok=True)
            fh = logging.FileHandler(str(log_file), mode="a", encoding="utf-8")
            fh.setLevel(logging.DEBUG)
            fh.setFormatter(_AnsiStrippingFormatter("%(message)s"))
            root.addHandler(fh)
            self._file_handler = fh
        else:
            self._file_handler = None

        self._configured = True

    @property
    def is_configured(self) -> bool:
        """True if configure() has been called at least once."""
        return self._configured

    def set_timestamps(self, enabled: bool):
        """Enable or disable timestamps."""
        self._timestamps = enabled

    def set_mode(self, mode: OutputMode):
        """Set output mode."""
        self._mode = mode

    # =========================================================================
    # Core Output
    # =========================================================================

    def _format_timestamp(self) -> str:
        """Format current timestamp."""
        if not self._timestamps:
            return ""
        return datetime.now().strftime("%Y-%m-%dT%H:%M:%S ")

    def _write_event(self, event: dict, level: str = "INFO"):
        """
        Write a structured event (JSON mode) or formatted string (other modes).
        """
        if self._mode == OutputMode.JSON:
            envelope = {"level": level}
            if self._timestamps:
                envelope["ts"] = datetime.now().isoformat()
            envelope.update(event)
            output = json.dumps(envelope, default=str)
            self._stdout.write(output + "\n")
            self._stdout.flush()
            self._log_via_stdlib(output, level)
        else:
            self._write(str(event), level=level)

    def _write(self, message: str, newline: bool = True, level: str = "INFO"):
        """
        Write to stdout (console) and route to file via stdlib → queue.
        """
        if self._quiet and level == "INFO" and self._mode != OutputMode.JSON:
            # Quiet mode: suppress console, still send to file via queue.
            self._log_via_stdlib(message, level)
            return

        if self._pending_line and newline:
            self._stdout.write("\r" + " " * 80 + "\r")
            self._stdout.flush()
            self._pending_line = False

        if self._mode == OutputMode.JSON:
            envelope = {"level": level, "msg": message}
            if self._timestamps:
                envelope["ts"] = datetime.now().isoformat()
            output = json.dumps(envelope, default=str)
        else:
            ts = self._format_timestamp()
            output = f"{ts}{message}"

        end = "\n" if newline else ""
        self._stdout.write(output + end)
        self._stdout.flush()

        # File path: stdlib → root → QueueHandler → FileHandler → scan.log
        self._log_via_stdlib(message, level)

        self._pending_line = not newline

    def _write_stderr(self, message: str, level: str = "ERROR"):
        """Write to stderr and route to file via stdlib → queue."""
        ts = self._format_timestamp()

        if self._mode == OutputMode.JSON:
            envelope = {"level": level, "msg": message}
            if self._timestamps:
                envelope["ts"] = datetime.now().isoformat()
            output = json.dumps(envelope, default=str)
        else:
            output = f"{ts}{message}"

        self._stderr.write(output + "\n")
        self._stderr.flush()
        self._log_via_stdlib(message, level)

    def _log_via_stdlib(self, message: str, level: str = "INFO") -> None:
        """Route message to file via stdlib → root → QueueHandler → FileHandler.

        Console output is handled separately by _write() → stdout.
        When no queue is active (non-scan commands), root has NullHandler → no-op.
        """
        clean = _ANSI_RE.sub("", message)
        lvl = getattr(logging, level.upper() if level.upper() != "WARN" else "WARNING", logging.INFO)
        logging.getLogger("reachable").log(lvl, clean)

    def _write_log_only(self, message: str, level: str = "DEBUG"):
        """Write only to log file / queue (no console output)."""
        self._log_via_stdlib(message, level)

    # =========================================================================
    # Standard Logging Methods
    # =========================================================================

    def debug(self, message: str):
        """Log debug message (console if --debug; file always via queue)."""
        if self._debug:
            self._write(f"[DEBUG] {message}", level="DEBUG")
        else:
            self._log_via_stdlib(message, "DEBUG")  # file-only, no console

    def info(self, message: str):
        """Log info message."""
        self._write(message, level="INFO")

    def warning(self, message: str):
        """Log warning message."""
        prefix = "  " if self._mode == OutputMode.HUMAN else ""
        self._write(f"{prefix}{message}", level="WARN")

    def error(self, message: str):
        """Log error message."""
        prefix = " " if self._mode == OutputMode.HUMAN else "[ERROR] "
        self._write_stderr(f"{prefix}{message}", level="ERROR")

    def success(self, message: str):
        """Log success message."""
        prefix = " " if self._mode == OutputMode.HUMAN else ""
        self._write(f"{prefix}{message}", level="INFO")

    # =========================================================================
    # Structured Scan Output (replaces ScanLogger)
    # =========================================================================

    def scan_start(
        self,
        repo: str,
        path: Path,
        version: str,
        branch: str = None,
        scan_number: int = None,
        license_info: dict = None,
        repo_stats: dict = None,
        scan_context=None,
    ):
        """
        Log scan start with header.

        Args:
            repo: Repository name
            path: Repository path
            version: REACHABLE version
            branch: Git branch (optional)
            scan_number: Scan count for this repo (optional)
            license_info: Dict with days_remaining, install_time, etc.
            repo_stats: Dict with branch, scan_count, first_scan_date
            scan_context: ScanContext object for language/build system info
        """
        self._scan_start_time = time.time()
        self._phase_timings.clear()
        self._counts.clear()
        self._dlp_scan_time = 0.0
        self._ai_scan_time = 0.0
        self._sub_phase_timings.clear()
        self._scanners.clear()
        for k in self._policies:
            self._policies[k] = {}
        self._compliance.clear()

        if self._mode == OutputMode.JSON:
            self._write_event(
                {"event": "scan_start", "version": version, "repo": repo, "path": str(path)},
                level="INFO",
            )
            return

        # Banner
        w = 40
        title = f"  REACHABLE v{version}"
        copy_line = "  © 2026 Sthenos Security"
        self._write(f"╭{'─' * w}╮")
        self._write(f"│{title:<{w}}│")
        self._write(f"│{copy_line:<{w}}│")
        self._write(f"╰{'─' * w}╯")

        # License info
        if license_info:
            days = license_info.get("days_remaining", 0)
            if days > 7:
                self._write(f" License: {days} days remaining")
            elif days > 0:
                self._write(f" License: {days} days remaining (expiring soon!)")
            else:
                self._write(" License: EXPIRED")

        self._write(f" Target: {repo}" + (" [DEBUG]" if self._debug else ""))
        self._write(f" Path: {path}")

        # Repo stats
        if repo_stats:
            rb = repo_stats.get("branch", branch or "unknown")
            scan_count = repo_stats.get("scan_count", 0)
            first_scan = repo_stats.get("first_scan_date")
            today = datetime.now().strftime("%Y-%m-%d")
            self._write(f" Today: {today}")
            self._write(f" Branch: {rb}")
            if first_scan:
                self._write(f" First scan: {first_scan}")
            self._write(f" Scan #: {scan_count + 1} (this repo)")
        elif branch:
            self._write(f" Branch: {branch}")
            if scan_number:
                self._write(f" Scan #: {scan_number}")

        # Analysis scope (languages + build systems)
        if scan_context:
            self._print_analysis_scope(scan_context)

        if not scan_context:
            self._write("")

    def phase_start(self, phase_num: int, name: str, scanner: str = None, total_phases: int = 5):
        """
        Log phase start.

        Args:
            phase_num: Phase number (1-based)
            name: Phase name
            scanner: Scanner name (optional)
            total_phases: Total number of phases
        """
        self._phase_timings[phase_num] = {"name": name, "scanner": scanner, "start": time.time(), "end": None}

        scanner_str = f" ({scanner})" if scanner else ""

        if self._mode == OutputMode.JSON:
            self._write_event(
                {"event": "phase_start", "phase": phase_num, "name": name, "scanner": scanner},
                level="INFO",
            )
        elif self._mode == OutputMode.HUMAN:
            self._write(f"[{phase_num}/{total_phases}] {name}{scanner_str}...", newline=False)
        else:
            # CI mode
            self._write(f"[{phase_num}/{total_phases}] {name}{scanner_str}...")

    def phase_end(self, phase_num: int, result: str = None):
        """
        Log phase completion.

        Args:
            phase_num: Phase number
            result: Result summary (optional)
        """
        if phase_num not in self._phase_timings:
            return

        phase = self._phase_timings[phase_num]
        phase["end"] = time.time()
        elapsed = phase["end"] - phase["start"]
        phase["elapsed"] = elapsed

        if self._mode == OutputMode.JSON:
            self._write_event(
                {
                    "event": "phase_end",
                    "phase": phase_num,
                    "elapsed_sec": round(elapsed, 2),
                    "result": result,
                },
                level="INFO",
            )
        elif self._mode == OutputMode.HUMAN:
            result_str = f" → {result}" if result else ""
            self._write(f" ({elapsed:.1f}s){result_str}")
        else:
            # CI mode
            result_str = f" - {result}" if result else ""
            self._write(f" Completed in {elapsed:.1f}s{result_str}")

    def phase_error(self, phase_num: int, error: str):
        """Log phase error."""
        if self._mode == OutputMode.HUMAN:
            self._write(f" {error}")
        else:
            self._write(f" ERROR: {error}")

    def scan_complete(
        self,
        risk_score: int,
        risk_level: str,
        output_dir: Path,
        findings_count: int = 0,
        open_dashboard: bool = False,
        repo_path: Optional[Path] = None,
    ):
        """
        Log scan completion.

        Args:
            risk_score: Risk score (0-1000)
            risk_level: Risk level string
            output_dir: Output directory path
            findings_count: Total findings count
            open_dashboard: Auto-open dashboard in browser after scan
            repo_path: Repo path, used to build reachctl hint
        """
        total_time = time.time() - self._scan_start_time if self._scan_start_time else 0
        # Stash for print_results_summary header
        self._counts["risk_level"] = risk_level

        if self._mode == OutputMode.JSON:
            self._write_event(
                {
                    "event": "scan_complete",
                    "risk_score": risk_score,
                    "risk_level": risk_level,
                    "total_time_sec": round(total_time, 2),
                    "findings": findings_count,
                    "output_dir": str(output_dir),
                },
                level="INFO",
            )
        else:
            _saved_quiet = self._quiet
            self._quiet = False
            try:
                dashboard_path = output_dir / "dashboard" / "index.html"
                repo_db = output_dir.parent.parent / "repo.db"
                self._write("\u2501" * 68)
                self._write(f"  Dashboard  file://{dashboard_path.absolute()}")
                if self._debug:
                    self._write(f"  Database   {repo_db}")
                    self._write(f"  Log        {output_dir}/scan.log")
                self._write("\u2501" * 68)

                if open_dashboard and dashboard_path.exists():
                    import webbrowser
                    webbrowser.open(f"file://{dashboard_path.absolute()}")
            finally:
                self._quiet = _saved_quiet

    def print_debug_report(self):
        """Print debug report — only in debug mode, writes to log file only."""
        if not self._debug:
            return

        self._write_log_only("")
        self._write_log_only("DEBUG: EXECUTION DETAILS")

        # Scanner execution
        if self._scanners:
            self._write_log_only("")
            self._write_log_only("SCANNER EXECUTION")
            self._write_log_only("─" * 60)
            self._write_log_only(f"  {'Scanner':<16} {'Status':<8} {'Time':>8}   {'Result':<20}")
            self._write_log_only("─" * 60)
            for s in self._scanners:
                icon = "OK" if s["status"] == "success" else "ERR" if s["status"] == "error" else "SKIP"
                self._write_log_only(f"  {s['name']:<16} {icon:<8} {s['duration']:>7.1f}s   {s['result'][:20]:<20}")
            self._write_log_only("─" * 60)

        # Policy coverage
        has_policies = any(len(p) > 0 for p in self._policies.values())
        if has_policies:
            self._write_log_only("")
            self._write_log_only("POLICY COVERAGE")
            self._write_log_only("─" * 60)
            for category, policies in self._policies.items():
                if not policies:
                    continue
                total = sum(policies.values())
                self._write_log_only(f"  {category.upper()} ({total} findings)")
                sorted_p = sorted(policies.items(), key=lambda x: x[1], reverse=True)
                for policy_id, count in sorted_p[:5]:
                    display_id = policy_id.split(".")[-1] if "." in policy_id else policy_id
                    self._write_log_only(f"    {display_id[:35]:<35} {count:>4}")
                if len(sorted_p) > 5:
                    other = sum(c for _, c in sorted_p[5:])
                    self._write_log_only(f"    {'(other)':<35} {other:>4}")
                self._write_log_only("")

        # Compliance mapping
        if self._compliance:
            self._write_log_only("COMPLIANCE MAPPED")
            self._write_log_only("─" * 60)
            for framework, count in sorted(self._compliance.items()):
                self._write_log_only(f"  {framework:<30} {count:>4} controls")
            self._write_log_only("")

    # =========================================================================
    # Analysis Scope (language/build system detection)
    # =========================================================================

    def _print_analysis_scope(self, scan_context):
        """Print language and build system analysis scope."""
        self._write(" ANALYSIS SCOPE")
        self._write("─" * 40)

        SUPPORTED_LANGS = {"python", "javascript", "go", "java"}
        PARTIAL_LANGS = {"rust", "ruby"}

        detected = scan_context.detected_languages
        file_counts = scan_context.total_files if hasattr(scan_context, "total_files") else {}

        supported, partial, unsupported = [], [], []
        for lang in detected:
            if lang in SUPPORTED_LANGS:
                supported.append(lang)
            elif lang in PARTIAL_LANGS:
                partial.append(lang)
            elif lang not in ("unknown",):
                unsupported.append(lang)

        if supported:
            self._write(f" Languages: {', '.join(supported)}")
        if partial:
            self._write(f" Partial: {', '.join(partial)} (CVE only, no reachability)")
        if unsupported:
            self._write(f" Skipped: {', '.join(unsupported)} (not yet supported)")

        if file_counts:
            total = sum(file_counts.values())
            if total > 0:
                self._write(f" Files: {total} total")

        self._print_build_systems(scan_context)
        self._write("─" * 40)

    def _print_build_systems(self, scan_context):
        """Detect and print build systems."""
        repo_path = scan_context.repo_path

        SUPPORTED_BUILD = {
            "pip/poetry": ("requirements.txt", "pyproject.toml", "Pipfile"),
            "npm/yarn/pnpm": ("package.json",),
            "go.mod": ("go.mod",),
            "Maven": ("pom.xml",),
            "Gradle": ("build.gradle", "build.gradle.kts"),
        }
        PARTIAL_BUILD = {
            "Cargo": ("Cargo.toml",),
            "Bundler": ("Gemfile",),
        }
        UNSUPPORTED_BUILD = {
            "Bazel": ("WORKSPACE", "WORKSPACE.bazel"),
            "Buck2": ("BUCK", ".buckconfig"),
            "CMake": ("CMakeLists.txt",),
            "NuGet": ("*.csproj", "packages.config"),
            "Composer": ("composer.json",),
        }

        def _detect(build_map):
            found = []
            for name, files in build_map.items():
                for f in files:
                    if list(repo_path.rglob(f)):
                        found.append(name)
                        break
            return found

        detected_supported = _detect(SUPPORTED_BUILD)
        detected_partial = _detect(PARTIAL_BUILD)
        detected_unsupported = _detect(UNSUPPORTED_BUILD)

        if detected_supported:
            self._write(f" Build: {', '.join(detected_supported)}")
        if detected_partial:
            self._write(f" Partial: {', '.join(detected_partial)} (CVE only)")
        if detected_unsupported:
            self._write(f" Skipped: {', '.join(detected_unsupported)} (not yet supported)")

    # =========================================================================
    # Scanner & Policy Tracking
    # =========================================================================

    def track_scanner(self, name: str, status: str = "success", duration: float = 0, result: str = ""):
        """Track scanner execution."""
        self._scanners.append({"name": name, "status": status, "duration": duration, "result": result})
        self._write_log_only(f"  Scanner: {name} - {status} ({duration:.1f}s) - {result}")

    def track_policy(self, category: str, policy_id: str, count: int):
        """Track policy findings."""
        if category not in self._policies:
            self._policies[category] = {}
        self._policies[category][policy_id] = count

    def track_compliance(self, framework: str, count: int):
        """Track compliance mapping."""
        self._compliance[framework] = count

    def set_counts(self, **kwargs):
        """Set result counts for summary display."""
        self._counts.update(kwargs)

    def set_dlp_timing(self, dlp_scan_time: float):
        """Set DLP scan timing for timing summary."""
        self._dlp_scan_time = dlp_scan_time

    def set_ai_timing(self, ai_scan_time: float):
        """Set AI scan timing for timing summary."""
        self._ai_scan_time = ai_scan_time

    def track_sub_phase(self, name: str, elapsed: float):
        """Track sub-phase timing within a main phase."""
        self._sub_phase_timings[name] = elapsed

    # =========================================================================
    # Timing Summary
    # =========================================================================

    def print_timing_summary(self):
        """Print timing breakdown with phase information."""
        if not self._phase_timings:
            return

        # JSON mode: emit structured timing event
        if self._mode == OutputMode.JSON:
            phases = []
            for pn in sorted(self._phase_timings.keys()):
                p = self._phase_timings[pn]
                phases.append(
                    {
                        "phase": pn,
                        "name": p["name"],
                        "scanner": p.get("scanner"),
                        "elapsed_sec": round(p.get("elapsed", 0) or 0, 2),
                    }
                )
            total = sum(p.get("elapsed", 0) or 0 for p in self._phase_timings.values())
            event = {"event": "timing", "phases": phases, "total_sec": round(total, 2)}
            if self._dlp_scan_time > 0:
                event["dlp_sec"] = round(self._dlp_scan_time, 2)
            if self._ai_scan_time > 0:
                event["ai_sec"] = round(self._ai_scan_time, 2)
            if self._sub_phase_timings:
                event["sub_phases"] = {k: round(v, 2) for k, v in self._sub_phase_timings.items() if v > 0.1}
            self._write_event(event, level="INFO")
            return

        # Results always shown, even in quiet/CI mode
        _saved_quiet = self._quiet
        self._quiet = False

        self._write(" TIMING")
        self._write("─" * 60)

        total = sum(p.get("elapsed", 0) or 0 for p in self._phase_timings.values())
        if self._dlp_scan_time > 0:
            total += self._dlp_scan_time
        if self._ai_scan_time > 0:
            total += self._ai_scan_time

        for phase_num in sorted(self._phase_timings.keys()):
            phase = self._phase_timings[phase_num]
            elapsed = phase.get("elapsed", 0) or 0
            name = phase["name"][:28]
            bar_len = int((elapsed / total * 20) if total > 0 else 0)
            bar = "█" * bar_len + "░" * (20 - bar_len)
            marker = " " if elapsed > 30 else ""
            self._write(f" {phase_num}. {name:<28} {elapsed:>6.1f}s {bar}{marker}")

        # Sub-phase breakdown
        if self._sub_phase_timings:
            self._write("")
            self._write("     Sub-phase breakdown:")
            for name, elapsed in sorted(self._sub_phase_timings.items(), key=lambda x: -x[1]):
                if elapsed > 0.1:
                    sub_bar_len = int((elapsed / total * 20) if total > 0 else 0)
                    sub_bar = "█" * sub_bar_len + "░" * (20 - sub_bar_len)
                    self._write(f" {name:<24} {elapsed:>6.1f}s {sub_bar}")

        # DLP timing
        if self._dlp_scan_time > 0:
            dlp_bar_len = int((self._dlp_scan_time / total * 20) if total > 0 else 0)
            dlp_bar = "█" * dlp_bar_len + "░" * (20 - dlp_bar_len)
            pn = max(self._phase_timings.keys()) + 1 if self._phase_timings else 5
            self._write(f" {pn}. {'DLP/PII Analysis':<28} {self._dlp_scan_time:>6.1f}s {dlp_bar}")

        # AI timing
        if self._ai_scan_time > 0:
            ai_bar_len = int((self._ai_scan_time / total * 20) if total > 0 else 0)
            ai_bar = "█" * ai_bar_len + "░" * (20 - ai_bar_len)
            pn = max(self._phase_timings.keys()) + 2 if self._phase_timings else 6
            self._write(f" {pn}. {'AI Security Analysis':<28} {self._ai_scan_time:>6.1f}s {ai_bar}")

        self._write("─" * 60)
        self._write(f" {'TOTAL':<28} {total:>6.1f}s")

        self._quiet = _saved_quiet

    # =========================================================================
    # Results Summary
    # =========================================================================

    def print_results_summary(self):
        """Print unified scan results summary — single professional block."""
        c = self._counts
        total_time = time.time() - self._scan_start_time if self._scan_start_time else 0

        cves_total = c.get("cves_total", 0)
        cves_reachable = c.get("cves_reachable", 0)
        cves_unknown = c.get("cves_unknown", 0)
        cves_transitive = c.get("cves_transitive", 0)
        cves_transitive_via = c.get("cves_transitive_via", {})

        malware_static = c.get("malware_static", 0) or c.get("malware_count", 0) or 0
        malware_static_confirmed = c.get("malware_static_confirmed", 0)
        malware_static_suspicious = c.get("malware_static_suspicious", 0)
        malware_dynamic = c.get("malware_dynamic", 0) or c.get("sandbox_malicious", 0) or 0
        malware_dynamic_suspicious = c.get("malware_dynamic_suspicious", 0)
        malware_reachable = c.get("malware_reachable", 0)

        secrets_total = c.get("secrets_total", 0)
        secrets_reachable = c.get("secrets_reachable", 0)
        secrets_unknown = c.get("secrets_unknown", 0)

        cwe_total = c.get("cwe_total", 0)
        cwe_reachable = c.get("cwe_reachable", 0)
        cwe_unknown = c.get("cwe_unknown", 0)

        config_total = c.get("config_total", 0)
        ai_total = c.get("ai_total", 0)
        ai_reachable = c.get("ai_reachable", 0)
        ai_guarded = c.get("ai_guarded", 0)
        dlp_total = c.get("dlp_total", 0)
        dlp_reachable = c.get("dlp_reachable", 0)
        dlp_sanitized = c.get("dlp_sanitized", 0)

        # Dynamic malware totals
        dyn_total = malware_dynamic + malware_dynamic_suspicious
        malware_all = malware_static + dyn_total
        # sandbox findings are already in malware_reachable from DB — don't add dyn_total again
        malware_all_reachable = malware_reachable

        # Grand totals (config excluded from risk)
        total_all = cves_total + malware_all + secrets_total + cwe_total + ai_total + dlp_total
        total_reachable = (
            cves_reachable + malware_all_reachable + secrets_reachable + cwe_reachable + ai_reachable + dlp_reachable
        )
        total_unknown = cves_unknown + secrets_unknown + cwe_unknown
        total_unreachable = total_all - total_reachable - total_unknown
        total_filtered_pct = round((total_unreachable / total_all) * 100, 1) if total_all > 0 else 0

        # JSON mode: emit structured results event
        if self._mode == OutputMode.JSON:
            self._write_event(
                {
                    "event": "results_summary",
                    "total_time_sec": round(total_time, 2),
                    "cves": {
                        "total": cves_total,
                        "reachable": cves_reachable,
                        "unknown": cves_unknown,
                        "transitive": cves_transitive,
                    },
                    "secrets": {
                        "total": secrets_total,
                        "reachable": secrets_reachable,
                        "unknown": secrets_unknown,
                    },
                    "malware": {
                        "static": malware_static,
                        "dynamic": malware_dynamic,
                        "reachable": malware_reachable,
                    },
                    "cwe": {"total": cwe_total, "reachable": cwe_reachable, "unknown": cwe_unknown},
                    "config": config_total,
                    "ai": {"total": ai_total, "reachable": ai_reachable, "guarded": ai_guarded},
                    "dlp": {"total": dlp_total, "reachable": dlp_reachable, "sanitized": dlp_sanitized},
                    "totals": {
                        "all": total_all,
                        "reachable": total_reachable,
                        "unknown": total_unknown,
                        "unreachable": total_unreachable,
                        "filtered_pct": total_filtered_pct,
                    },
                },
                level="INFO",
            )
            return

        # Results always shown, even in quiet/CI mode
        _saved_quiet = self._quiet
        self._quiet = False

        dash = "\u2500"
        em = "\u2014"
        tee = "\u251c\u2500"  # ├─
        pipe = "\u2502 "      # │
        ell = "\u2514\u2500"  # └─
        W = 68

        # ── Severity data (for branch sub-lines) ────────────────────────────
        reach_sev = c.get("reachable_severity", {})
        unkn_sev = c.get("unknown_severity", {})
        config_sev = {"critical": c.get("config_critical", 0), "high": c.get("config_high", 0),
                      "medium": c.get("config_medium", 0), "low": c.get("config_low", 0)}

        def _sev_line(sev_dict_by_signal, signals=None):
            """Build '3 critical · 5 high · 12 medium · 2 low' from per-signal severity dicts."""
            if signals is None:
                signals = list(sev_dict_by_signal.keys())
            totals = {}
            for sig in signals:
                for lvl, cnt in sev_dict_by_signal.get(sig, {}).items():
                    totals[lvl] = totals.get(lvl, 0) + cnt
            parts = []
            for lvl in ("CRITICAL", "HIGH", "MEDIUM", "LOW"):
                n = totals.get(lvl, 0)
                if n:
                    parts.append(f"{n} {lvl.lower()}")
            return " \u00b7 ".join(parts) if parts else ""

        def _config_sev_line():
            parts = []
            for lvl in ("critical", "high", "medium", "low"):
                n = config_sev.get(lvl, 0)
                if n:
                    parts.append(f"{n} {lvl}")
            return " \u00b7 ".join(parts) if parts else ""

        # ── Signal table (debug only — goes to log file) ─────────────────────
        if self._debug:
            TW = 21
            self._write_log_only(f" {'Signal':<{TW}}{'Total':>5}  {'Reach':>5}  {'Unkn':>4}  {'Unreach':>7}  {'Filtered':>8}")
            self._write_log_only(" " + dash * 66)

            def _drow(name, total, reachable, unknown=0, suffix=""):
                unreachable = total - reachable - unknown
                filt = f"{round((unreachable / total) * 100, 1)}%" if total > 0 else em
                self._write_log_only(f" {name:<{TW}}{total:>5}  {reachable:>5}  {unknown:>4}  {unreachable:>7}  {filt:>8}{suffix}")

            def _drow_dash(name, total, reachable=None, suffix=""):
                r = f"{reachable:>5}" if reachable is not None else f"{'':>4}{em}"
                self._write_log_only(f" {name:<{TW}}{total:>5}  {r}  {'':>3}{em}  {'':>6}{em}  {'':>7}{em}{suffix}")

            if cves_transitive > 0:
                via_parts = [f"{pkg}\u00d7{cnt}" for pkg, cnt in list(cves_transitive_via.items())[:3]]
                _trans = f"  ({cves_transitive} transitive via: {', '.join(via_parts)})"
            else:
                _trans = ""
            _drow("CVE Vulnerabilities", cves_total, cves_reachable, cves_unknown, suffix=_trans)
            _drow_dash("Malware (Static)", malware_static, malware_reachable,
                       suffix=f"  ({malware_static_confirmed} confirmed, {malware_static_suspicious} review)" if malware_static else "")
            _drow_dash("Malware (Dynamic)", dyn_total)
            _drow("Exposed Secrets", secrets_total, secrets_reachable, secrets_unknown)
            _drow("Code Weaknesses", cwe_total, cwe_reachable, cwe_unknown)
            self._write_log_only(f" {'Config Issues':<{TW}}{config_total:>5}  {'':>4}{em}  {config_total:>4}  {'':>6}{em}  {'     N/A':>8}")
            if ai_total > 0:
                ai_unreachable = ai_total - ai_reachable
                ai_filt = f"{round((ai_unreachable / ai_total) * 100, 1)}%"
                self._write_log_only(f" {'AI Security':<{TW}}{ai_total:>5}  {ai_reachable:>5}  {'':>3}{em}  {ai_unreachable:>7}  {ai_filt:>8}")
            if dlp_total > 0:
                dlp_unreachable = dlp_total - dlp_reachable
                dlp_filt = f"{round((dlp_unreachable / dlp_total) * 100, 1)}%"
                self._write_log_only(f" {'DLP/PII':<{TW}}{dlp_total:>5}  {dlp_reachable:>5}  {'':>3}{em}  {dlp_unreachable:>7}  {dlp_filt:>8}")
            self._write_log_only(" " + dash * 66)
            self._write_log_only(f" {'TOTAL':<{TW}}{total_all:>5}  {total_reachable:>5}  {total_unknown:>4}  {total_unreachable:>7}  {total_filtered_pct:>7}%")

        # ── Header ──────────────────────────────────────────────────────────
        risk_level = c.get("risk_level", "").upper()
        header_right = f"  {risk_level}" if risk_level else ""
        header = f" SCAN COMPLETE  {total_time:.1f}s"
        self._write("\u2501" * W)
        self._write(f"{header}{header_right:>{W - len(header)}}")
        self._write("\u2501" * W)

        # ── Action Required ──────────────────────────────────────────────────
        actionable_unknown = total_unknown + config_total
        actionable = total_reachable + actionable_unknown

        reachable_parts = []
        if cves_reachable > 0:
            reachable_parts.append(f"{cves_reachable} CVE")
        if malware_all_reachable > 0:
            reachable_parts.append(f"{malware_all_reachable} malware")
        if secrets_reachable > 0:
            reachable_parts.append(f"{secrets_reachable} secret")
        if cwe_reachable > 0:
            reachable_parts.append(f"{cwe_reachable} CWE")
        if ai_reachable > 0:
            reachable_parts.append(f"{ai_reachable} AI")
        if dlp_reachable > 0:
            reachable_parts.append(f"{dlp_reachable} DLP")

        unverified_parts = []
        if cves_unknown > 0:
            unverified_parts.append(f"{cves_unknown} CVE")
        if secrets_unknown > 0:
            unverified_parts.append(f"{secrets_unknown} secret")
        if cwe_unknown > 0:
            unverified_parts.append(f"{cwe_unknown} CWE")

        has_filtered = total_unreachable > 0
        has_config = config_total > 0
        NW = 11

        lines_after_reachable = bool(unverified_parts) + has_config + has_filtered
        lines_after_unverified = has_config + has_filtered
        lines_after_config = has_filtered
        _sep = " \u00b7 "

        self._write("")
        self._write(f"  ACTION REQUIRED   {actionable}")

        if reachable_parts:
            conn = tee if lines_after_reachable else ell
            cont = pipe if lines_after_reachable else "  "
            self._write(f"  {conn} {'Exploitable':<{NW}}({total_reachable})   {_sep.join(reachable_parts)}")
            sev = _sev_line(reach_sev)
            if sev:
                self._write(f"  {cont}              {sev}")

        if unverified_parts:
            conn = tee if lines_after_unverified else ell
            cont = pipe if lines_after_unverified else "  "
            self._write(f"  {conn} {'Unverified':<{NW}}({total_unknown})   {_sep.join(unverified_parts)}")
            # Only show severity for the signals that are IN total_unknown (cve/secret/cwe)
            # malware unknown is intentionally excluded — it's not in the Unverified bucket
            sev = _sev_line(unkn_sev, signals=["cves", "secrets", "cwe"])
            if sev:
                self._write(f"  {cont}              {sev}")

        if has_config:
            conn = tee if lines_after_config else ell
            cont = pipe if lines_after_config else "  "
            self._write(f"  {conn} {'Config':<{NW}}({config_total})   N/A for reachability")
            sev = _config_sev_line()
            if sev:
                self._write(f"  {cont}              {sev}")

        if has_filtered:
            self._write(f"  {ell} {'Filtered':<{NW}}({total_unreachable})   {total_filtered_pct}% noise reduction")

        self._write("")

        # ── Debug-only: verbose per-signal breakdowns ────────────────────────
        if self._debug:
            self._print_severity_detail_to_log()

        self._quiet = _saved_quiet

    def _print_severity_table(self):
        """Print 4-column severity table: All | Exploitable | Unverified | Actionable."""
        c = self._counts
        reach_sev = c.get("reachable_severity", {})
        unkn_sev = c.get("unknown_severity", {})

        rows = []
        for level in ("critical", "high", "medium", "low"):
            total = 0
            for signal in (
                "cves",
                "secrets",
                "cwe",
                "malware",
                "ai",
                "dlp",
            ):  # config excluded — NOT_APPLICABLE
                total += c.get(f"{signal}_{level}", 0)
            exploitable = 0
            for signal in ("cves", "secrets", "cwe", "malware", "ai", "dlp"):
                exploitable += reach_sev.get(signal, {}).get(level.upper(), 0)
            unverified = 0
            for signal in ("cves", "secrets", "cwe", "malware", "ai", "dlp"):
                unverified += unkn_sev.get(signal, {}).get(level.upper(), 0)
            actionable = exploitable + unverified
            if total > 0 or exploitable > 0:
                rows.append((level.capitalize(), total, exploitable, unverified, actionable))

        if not rows:
            return

        self._write("")
        self._write(f" {'Severity':<12}{'All':>5}  {'Exploitable':>11}  {'Unverified':>10}  {'Actionable':>10}")
        self._write(" " + "\u2500" * 54)
        for label, total, exploitable, unverified, actionable in rows:
            self._write(f" {label:<12}{total:>5}  {exploitable:>11}  {unverified:>10}  {actionable:>10}")

    def _print_severity_detail_to_log(self):
        """Write verbose per-signal severity breakdown to log file (debug only)."""
        c = self._counts

        self._write_log_only("")
        self._write_log_only("SEVERITY DETAIL (all signals):")
        for level in ("critical", "high", "medium", "low"):
            total = 0
            parts = []
            for signal in ("cves", "secrets", "cwe", "malware", "config", "ai", "dlp"):
                v = c.get(f"{signal}_{level}", 0)
                if v > 0:
                    total += v
                    label = signal.upper() if signal in ("ai", "dlp", "cwe") else signal.capitalize()
                    parts.append(f"{v} {label}")
            if total > 0:
                self._write_log_only(f"  {level.capitalize()} ({total}): {', '.join(parts)}")

        reach_sev = c.get("reachable_severity", {})
        if not reach_sev:
            return
        label_map = {
            "cves": "CVE",
            "secrets": "Secrets",
            "cwe": "CWE",
            "malware": "Malware",
            "config": "Config",
            "ai": "AI",
            "dlp": "DLP",
        }
        self._write_log_only("")
        self._write_log_only("SEVERITY DETAIL (exploitable only):")
        for level in ("CRITICAL", "HIGH", "MEDIUM", "LOW"):
            total = 0
            parts = []
            for signal in ("cves", "secrets", "cwe", "malware", "config", "ai", "dlp"):
                v = reach_sev.get(signal, {}).get(level, 0)
                if v > 0:
                    total += v
                    parts.append(f"{v} {label_map[signal]}")
            if total > 0:
                self._write_log_only(f"  {level.capitalize()} ({total}): {', '.join(parts)}")

        unkn_sev = c.get("unknown_severity", {})
        if unkn_sev:
            self._write_log_only("")
            self._write_log_only("SEVERITY DETAIL (unverified only):")
            for level in ("CRITICAL", "HIGH", "MEDIUM", "LOW"):
                total = 0
                parts = []
                for signal in ("cves", "secrets", "cwe", "malware", "config", "ai", "dlp"):
                    v = unkn_sev.get(signal, {}).get(level, 0)
                    if v > 0:
                        total += v
                        parts.append(f"{v} {label_map[signal]}")
                if total > 0:
                    self._write_log_only(f"  {level.capitalize()} ({total}): {', '.join(parts)}")

    def results_summary(
        self,
        cves: Dict[str, int],
        secrets: Dict[str, int],
        malware: Dict[str, int],
        cwe: Dict[str, int],
        config: int = 0,
        ai: Dict[str, int] = None,
        dlp: Dict[str, int] = None,
    ):
        """
        Print results summary table.

        Args:
            cves: Dict with total, reachable, unknown keys
            secrets: Dict with total, reachable, unknown keys
            malware: Dict with total, reachable keys
            cwe: Dict with total, reachable, unknown keys
            config: Config issues count
            ai: Dict with total, reachable keys (optional)
            dlp: Dict with total, reachable keys (optional)
        """
        if self._mode == OutputMode.JSON:
            self._write_event(
                {
                    "event": "results_summary",
                    "cves": cves,
                    "secrets": secrets,
                    "malware": malware,
                    "cwe": cwe,
                    "config": config,
                    "ai": ai,
                    "dlp": dlp,
                },
                level="INFO",
            )
            return

        self._write("")
        self._write(" RESULTS")
        self._write("─" * 68)

        if self._mode == OutputMode.HUMAN:
            self._write(f" {'Signal':<18} {'Total':>6} {'Reach':>6} {'Unkn':>6} {'Unreach':>7}")
            self._write("  " + "─" * 50)

            def print_row(name: str, total: int, reachable: int, unknown: int = 0):
                unreachable = total - reachable - unknown
                self._write(f" {name:<18} {total:>6} {reachable:>6} {unknown:>6} {unreachable:>7}")

            print_row("CVE Vulnerabilities", cves.get("total", 0), cves.get("reachable", 0), cves.get("unknown", 0))
            print_row(
                "Exposed Secrets",
                secrets.get("total", 0),
                secrets.get("reachable", 0),
                secrets.get("unknown", 0),
            )
            print_row("Malware", malware.get("total", 0), malware.get("reachable", 0))
            print_row("Code Weaknesses", cwe.get("total", 0), cwe.get("reachable", 0), cwe.get("unknown", 0))

            if ai:
                print_row("AI Security", ai.get("total", 0), ai.get("reachable", 0))
            if dlp:
                print_row("DLP/PII", dlp.get("total", 0), dlp.get("reachable", 0))

            self._write("─" * 68)
        else:
            # CI mode: compact
            self._write(f" CVEs: {cves.get('total', 0)} ({cves.get('reachable', 0)} reachable)")
            self._write(f" Secrets: {secrets.get('total', 0)} ({secrets.get('reachable', 0)} reachable)")
            self._write(f" Malware: {malware.get('total', 0)}")
            self._write(f" CWE: {cwe.get('total', 0)} ({cwe.get('reachable', 0)} reachable)")

    # =========================================================================
    # Context Managers
    # =========================================================================

    @contextmanager
    def collector_context(self, name: str):
        """
        Context manager for collector logging.

        Usage:
            with logger.collector_context("guarddog"):
                # collector code
                logger.debug("Scanning packages...")
        """
        start = time.time()
        self.debug(f"Starting collector: {name}")
        try:
            yield
        finally:
            elapsed = time.time() - start
            self.debug(f"Collector {name} completed in {elapsed:.1f}s")

    def close(self):
        """Close direct FileHandler if one was attached (unit tests / log_file= path)."""
        fh = getattr(self, "_file_handler", None)
        if fh is not None:
            try:
                fh.flush()
                fh.close()
                logging.getLogger().removeHandler(fh)
            except Exception:
                pass
            self._file_handler = None


# =========================================================================
# Module-level API
# =========================================================================

_logger: Optional[ReachableLogger] = None


def get_logger() -> ReachableLogger:
    """Get the global logger instance."""
    global _logger
    if _logger is None:
        _logger = ReachableLogger()
    return _logger


def configure(
    mode: OutputMode = OutputMode.HUMAN,
    timestamps: bool = True,   # ON by default; disable with --no-timestamps
    debug: bool = False,
    quiet: bool = False,
    log_file: Optional[Path] = None,
):
    """Configure the global logger."""
    logger = get_logger()
    logger.configure(mode=mode, timestamps=timestamps, debug=debug, quiet=quiet, log_file=log_file)
    return logger


# Convenience aliases
def info(msg: str):
    get_logger().info(msg)


def debug(msg: str):
    get_logger().debug(msg)


def warning(msg: str):
    get_logger().warning(msg)


def error(msg: str):
    get_logger().error(msg)


def success(msg: str):
    get_logger().success(msg)


# Module-level logger instance — import as `from reachable.core.logger import logger`
# This is the global singleton; equivalent to calling get_logger() at import time.
logger: ReachableLogger = get_logger()

__all__ = [
    "ReachableLogger",
    "OutputMode",
    "get_logger",
    "configure",
    "logger",
    "info",
    "debug",
    "warning",
    "error",
    "success",
]
