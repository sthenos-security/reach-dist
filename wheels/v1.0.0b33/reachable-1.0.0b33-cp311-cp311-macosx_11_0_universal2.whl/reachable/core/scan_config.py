#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.

"""
ScanConfig — single source of truth for all scan-session settings and paths.

Replaces 21 per-caller divergences between serial (scan.py) and concurrent
(pipeline.py) modes.  Initialised once at scan start, persisted to
session_dir/.scan-config.json, read by any step or finalize without
re-deriving anything.

Usage (init — once, at scan start):
    from reachable.core.scan_config import ScanConfig
    cfg = ScanConfig.init(repo_path=..., args=..., session_dir=...,
                          scan_id=..., db_path=..., branch=...,
                          commit=..., version=...)
    cfg.save()

Usage (load — any step, finalize, or tool):
    cfg = ScanConfig.load(session_dir)
    raw  = cfg.raw_dir          # Path
    db   = cfg.db_path          # Path
    sid  = cfg.scan_id          # int
    skip = cfg.skip_malware     # bool
    ci   = cfg.ci_mode          # bool

Runtime reload (after parallel steps complete, before finalize):
    cfg.reload_runtime()        # pulls preloaded_health + sast_skipped from raw/
"""

from __future__ import annotations

import json
import os
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional

# ---------------------------------------------------------------------------
# Canonical raw file names — one place, no string literals scattered around
# ---------------------------------------------------------------------------

GRYPE_VULNS_FILE        = "grype-vulns.json"
SECURITY_FINDINGS_FILE  = "security-findings.json"
CVE_ANALYZED_FILE       = "cve-analyzed.json"
CALL_GRAPH_FILE         = "call-graph.json"
CALL_GRAPH_JS_FILE      = "call-graph-js.json"
MALWARE_FILE            = "malware.json"
STATIC_MALWARE_FILE     = "static-malware-extracted.json"
HEALTH_FILE             = "health.json"
AI_FILE                 = "ai-security.json"
DLP_FILE                = "dlp-security.json"
IAC_FILE                = "iac.json"
SAST_SKIPPED_FILE       = "sast-skipped.json"
SBOM_FILE               = "sbom.json"
CALLABLE_FUNCTIONS_FILE = "callable-functions.json"
INTERNAL_EP_FILE        = "internal-entrypoints.json"


@dataclass
class ScanConfig:
    """
    All settings and derived paths for one scan session.

    Fields are plain Python types so the object is JSON-round-trippable.
    Path fields are stored as strings internally and re-hydrated on load.
    """

    # ── identity ──────────────────────────────────────────────────────────
    repo_path:   str    # absolute path to repository root
    session_dir: str    # absolute path to session directory
    scan_id:     int
    branch:      str
    commit:      Optional[str]
    version:     str

    # ── derived paths (canonical — no per-caller reconstruction) ─────────
    raw_dir:  str   # session_dir/raw/
    libs_dir: str   # session_dir/libs/
    db_path:  str   # ~/.reachable/scans/<repo>/repo.db

    # ── CI / output ───────────────────────────────────────────────────────
    ci_mode:    bool = False
    debug:      bool = False
    quiet:      bool = False
    log_format: str  = "text"    # "text" | "json"
    fail_on:    str  = "none"    # "none" | "critical" | "high" | "medium" | "any"

    # ── feature flags ─────────────────────────────────────────────────────
    skip_malware:      bool = False
    skip_secrets:      bool = False
    skip_cwe:          bool = False
    skip_iac:          bool = False
    enable_sandbox:    bool = False
    sandbox_cache_ttl: int  = 24
    force_rebuild:     bool = False

    # ── tool timeouts (seconds) ───────────────────────────────────────────
    syft_timeout:    int = 600
    grype_timeout:   int = 300
    semgrep_timeout: int = 300

    # ── semgrep rules — single source of truth ────────────────────────────
    # 'auto' works without Semgrep cloud auth (offline, CI, airgapped).
    # Override via --semgrep-rules flag or REACHABLE_SEMGREP_RULES env var.
    semgrep_rules: str = "auto"

    # ── git / CI context ──────────────────────────────────────────────────
    git_sha:      Optional[str] = None
    git_branch:   Optional[str] = None
    git_repo_url: Optional[str] = None
    ci_run_id:    Optional[str] = None

    # ── runtime fields (populated after steps complete) ───────────────────
    preloaded_health: List[Dict] = field(default_factory=list)
    sast_skipped:     List[Dict] = field(default_factory=list)

    # ─────────────────────────────────────────────────────────────────────
    # Path properties — typed access, no string building at call sites
    # ─────────────────────────────────────────────────────────────────────

    @property
    def repo(self) -> Path:
        return Path(self.repo_path)

    @property
    def session(self) -> Path:
        return Path(self.session_dir)

    @property
    def raw(self) -> Path:
        return Path(self.raw_dir)

    @property
    def libs(self) -> Path:
        return Path(self.libs_dir)

    @property
    def db(self) -> Path:
        return Path(self.db_path)

    # -- raw file paths (property = raw_dir / canonical_name) -------------

    @property
    def grype_vulns(self) -> Path:
        return self.raw / GRYPE_VULNS_FILE

    @property
    def security_findings(self) -> Path:
        return self.raw / SECURITY_FINDINGS_FILE

    @property
    def cve_analyzed(self) -> Path:
        return self.raw / CVE_ANALYZED_FILE

    @property
    def call_graph(self) -> Path:
        return self.raw / CALL_GRAPH_FILE

    @property
    def call_graph_js(self) -> Path:
        return self.raw / CALL_GRAPH_JS_FILE

    @property
    def malware(self) -> Path:
        return self.raw / MALWARE_FILE

    @property
    def static_malware(self) -> Path:
        return self.raw / STATIC_MALWARE_FILE

    @property
    def health(self) -> Path:
        return self.raw / HEALTH_FILE

    @property
    def ai_security(self) -> Path:
        return self.raw / AI_FILE

    @property
    def dlp_security(self) -> Path:
        return self.raw / DLP_FILE

    @property
    def iac(self) -> Path:
        return self.raw / IAC_FILE

    @property
    def sast_skipped_path(self) -> Path:
        return self.raw / SAST_SKIPPED_FILE

    @property
    def sbom(self) -> Path:
        return self.raw / SBOM_FILE

    @property
    def callable_functions(self) -> Path:
        return self.raw / CALLABLE_FUNCTIONS_FILE

    @property
    def internal_entrypoints(self) -> Path:
        return self.raw / INTERNAL_EP_FILE

    # -- config file path --------------------------------------------------

    @property
    def config_path(self) -> Path:
        return self.session / ".scan-config.json"

    # ─────────────────────────────────────────────────────────────────────
    # Factory
    # ─────────────────────────────────────────────────────────────────────

    @classmethod
    def init(
        cls,
        repo_path: Path,
        args: Any,
        session_dir: Path,
        scan_id: int,
        db_path: Path,
        branch: str,
        commit: Optional[str],
        version: str,
    ) -> "ScanConfig":
        """
        Construct from CLI args + resolved values.  Call exactly once at scan
        start (pipeline_init or reachctl scan entry point).

        All CI detection, fail_on escalation, git context, and env-var reads
        happen here — never repeated in individual steps.
        """
        # ── CI detection — one place only ─────────────────────────────────
        ci_mode: bool = bool(
            getattr(args, "ci", False)
            or os.environ.get("CI", "").lower() in ("true", "1", "yes")
        )

        # ── fail_on — auto-escalate in CI if not explicitly set ──────────
        fail_on: str = getattr(args, "fail_on", "none") or "none"
        if ci_mode and fail_on == "none":
            fail_on = "critical"

        # ── git / CI env vars — one place only ───────────────────────────
        git_sha: Optional[str] = (
            commit
            or os.environ.get("GITHUB_SHA")
            or os.environ.get("CI_COMMIT_SHA")
            or os.environ.get("BUILD_SOURCEVERSION")
        ) or None

        git_branch: Optional[str] = (
            branch
            or os.environ.get("GITHUB_REF_NAME")
            or os.environ.get("CI_COMMIT_REF_NAME")
            or os.environ.get("BUILD_SOURCEBRANCHNAME")
        ) or None

        _gh_repo = os.environ.get("GITHUB_REPOSITORY")
        git_repo_url: Optional[str] = (
            (os.environ.get("GITHUB_SERVER_URL", "https://github.com") + "/" + _gh_repo)
            if _gh_repo
            else (
                os.environ.get("CI_PROJECT_URL")
                or os.environ.get("BUILD_REPOSITORY_URI")
            )
        ) or None

        ci_run_id: Optional[str] = (
            os.environ.get("GITHUB_RUN_ID")
            or os.environ.get("CI_JOB_ID")
        ) or None

        return cls(
            repo_path    = str(repo_path.resolve()),
            session_dir  = str(session_dir.resolve()),
            scan_id      = scan_id,
            branch       = git_branch or branch or "unknown",
            commit       = git_sha or commit,
            version      = version,
            raw_dir      = str(session_dir.resolve() / "raw"),
            libs_dir     = str(session_dir.resolve() / "libs"),
            db_path      = str(db_path.resolve()),
            ci_mode      = ci_mode,
            debug        = bool(getattr(args, "debug", False)),
            quiet        = bool(getattr(args, "quiet", False)),
            log_format   = str(getattr(args, "log_format", "text") or "text"),
            fail_on      = fail_on,
            skip_iac     = bool(getattr(args, "skip_iac", False)),
            enable_sandbox     = not bool(getattr(args, "no_dynamic_malware", False)),
            sandbox_cache_ttl  = int(getattr(args, "sandbox_cache_ttl", 24) or 24),
            force_rebuild      = bool(getattr(args, "force_rebuild", False)),
            semgrep_rules      = (
                getattr(args, "semgrep_rules", None)
                or os.environ.get("REACHABLE_SEMGREP_RULES", "")
                or "auto"
            ),
            git_sha      = git_sha,
            git_branch   = git_branch,
            git_repo_url = git_repo_url,
            ci_run_id    = ci_run_id,
        )

    # ─────────────────────────────────────────────────────────────────────
    # Persistence
    # ─────────────────────────────────────────────────────────────────────

    def save(self) -> None:
        """Write to session_dir/.scan-config.json (atomic)."""
        import tempfile

        self.raw.mkdir(parents=True, exist_ok=True)
        data = asdict(self)
        payload = json.dumps(data, indent=2)
        parent = self.config_path.parent
        fd, tmp = tempfile.mkstemp(dir=parent, prefix=".scan-config.tmp-")
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as f:
                f.write(payload)
                f.flush()
                os.fsync(f.fileno())
            os.replace(tmp, self.config_path)
        except Exception:
            try:
                os.unlink(tmp)
            except OSError:
                pass
            raise

    @classmethod
    def load(cls, session_dir: Path) -> "ScanConfig":
        """Load from session_dir/.scan-config.json."""
        path = Path(session_dir) / ".scan-config.json"
        if not path.exists():
            raise FileNotFoundError(f"ScanConfig not found: {path}")
        data: Dict = json.loads(path.read_text(encoding="utf-8"))
        return cls(**data)

    @classmethod
    def load_or_none(cls, session_dir: Path) -> Optional["ScanConfig"]:
        """Load without raising — returns None if not found or corrupted."""
        try:
            return cls.load(session_dir)
        except (FileNotFoundError, json.JSONDecodeError, TypeError):
            return None

    def update(self, **kwargs: Any) -> None:
        """Update fields in-place and re-save atomically."""
        for k, v in kwargs.items():
            if not hasattr(self, k):
                raise AttributeError(f"ScanConfig has no field '{k}'")
            object.__setattr__(self, k, v)
        self.save()

    # ─────────────────────────────────────────────────────────────────────
    # Runtime reload (call in pipeline_finalize after steps complete)
    # ─────────────────────────────────────────────────────────────────────

    def reload_runtime(self) -> None:
        """
        Re-read runtime fields from raw/ files that steps have written.

        Call this once in pipeline_finalize (or serial scan after all steps)
        before passing preloaded_health / sast_skipped to the analyzer and
        coverage module.
        """
        # preloaded_health — from raw/health.json
        h = self.health
        if h.exists():
            try:
                raw = json.loads(h.read_text(encoding="utf-8"))
                self.preloaded_health = raw.get("advisories", [])
            except (OSError, json.JSONDecodeError):
                pass

        # sast_skipped — from raw/sast-skipped.json
        s = self.sast_skipped_path
        if s.exists():
            try:
                raw = json.loads(s.read_text(encoding="utf-8"))
                self.sast_skipped = raw.get("skipped", [])
            except (OSError, json.JSONDecodeError):
                pass

    # ─────────────────────────────────────────────────────────────────────
    # Helpers
    # ─────────────────────────────────────────────────────────────────────

    def ensure_dirs(self) -> None:
        """Create raw/ and libs/ directories if they don't exist."""
        self.raw.mkdir(parents=True, exist_ok=True)
        self.libs.mkdir(parents=True, exist_ok=True)

    def as_dict(self) -> Dict:
        """Return serialisable dict (same as what save() writes)."""
        return asdict(self)

    def __repr__(self) -> str:
        return (
            f"ScanConfig(scan_id={self.scan_id}, branch={self.branch!r}, "
            f"ci_mode={self.ci_mode}, fail_on={self.fail_on!r}, "
            f"raw={self.raw_dir!r})"
        )
