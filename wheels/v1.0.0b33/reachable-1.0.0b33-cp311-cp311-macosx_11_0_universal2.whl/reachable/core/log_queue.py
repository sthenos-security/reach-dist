# Copyright © 2026 Sthenos Security. All rights reserved.
"""
Queue-based log aggregator for serial and concurrent pipeline modes.

Architecture
────────────
Parent process owns one queue.Queue and one QueueListener (single FileHandler).
Each step runs as subprocess.Popen with stdout=PIPE.  A reader thread per
subprocess forwards every stdout line to the queue via a named logger
("step.<name>").  In-process loggers (reachable.*) attach a QueueHandler so
their records also flow through the same queue.

                Parent process
                ┌──────────────────────────────────┐
                │  queue.Queue                     │
                │       ▲            ▲             │
                │  reader thread  QueueHandler     │
                │  (per proc)    (reachable.*)     │
                │       │                          │
                │  QueueListener                   │
                │       │                          │
                │  FileHandler → scan.log          │
                └──────────────────────────────────┘

Design
──────
• Pure stdlib: queue, logging, logging.handlers, threading
• One file writer — no locking, no corruption, no duplicates
• Works identically for serial (one subprocess at a time) and concurrent
  (multiple subprocesses via ThreadPoolExecutor)
• Zero impact when not started (start_log_queue not called)
• Graceful shutdown: stop_log_queue() drains queue + closes file
"""

from __future__ import annotations

import logging
import logging.handlers
import queue
import threading
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Optional

_LOGGER = logging.getLogger(__name__)

# Module-level queue handle — set by start_log_queue, cleared by stop_log_queue.
# Checked by attach_queue_handler so in-process loggers can self-wire.
_active_queue: Optional[queue.Queue] = None
_active_queue_lock = threading.Lock()


# ---------------------------------------------------------------------------
# Public handle
# ---------------------------------------------------------------------------

@dataclass
class QueueHandle:
    """Returned by start_log_queue.  Pass to stop_log_queue when done."""
    log_queue: queue.Queue
    listener: logging.handlers.QueueListener
    log_path: Optional[Path]
    _counting_handler: object = None  # _CountingFileHandler, stored for byte report


# ---------------------------------------------------------------------------
# Formatters
# ---------------------------------------------------------------------------

def _make_formatter() -> logging.Formatter:
    return logging.Formatter(
        "%(asctime)s [%(levelname)s] %(name)s: %(message)s",
        datefmt="%Y-%m-%dT%H:%M:%S",
    )


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def start_log_queue(log_path: Optional[Path], debug: bool) -> Optional[QueueHandle]:
    """
    Create the central log queue and start the QueueListener.

    Configure logging ONCE here — attach QueueHandler to the root logger at
    DEBUG level so every logger.info/debug() call anywhere in the process
    flows through the queue.  The FileHandler filters at INFO or DEBUG
    depending on the debug flag.  Nobody else should call logging.basicConfig
    or touch handler lists after this point.

    Args:
        log_path: Path to write scan.log.  None → no file output.
        debug:    True → capture DEBUG+; False → INFO+ only in file.

    Returns:
        QueueHandle, or None if setup fails (scan continues without logging).
    """
    global _active_queue

    try:
        log_queue: queue.Queue = queue.Queue(-1)  # unbounded

        handlers = []

        if log_path:
            log_path.parent.mkdir(parents=True, exist_ok=True)
            fh = logging.FileHandler(str(log_path), mode="a", encoding="utf-8")
            # Filter here — one place, not on every logger
            fh.setLevel(logging.DEBUG if debug else logging.INFO)
            fh.setFormatter(_make_formatter())
            handlers.append(fh)

        if not handlers:
            return None

        # Counting wrapper — prints bytes_written at stop_log_queue so we can
        # verify data actually flows through the queue.
        class _CountingFileHandler(logging.FileHandler):
            def __init__(self, *a, **kw):
                super().__init__(*a, **kw)
                self.bytes_written = 0
            def emit(self, record):
                super().emit(record)
                try:
                    msg = self.format(record)
                    self.bytes_written += len((msg + "\n").encode("utf-8"))
                except Exception:
                    pass

        counting_fh = _CountingFileHandler(str(log_path), mode="a", encoding="utf-8")
        counting_fh.setLevel(logging.DEBUG if debug else logging.INFO)
        counting_fh.setFormatter(_make_formatter())
        handlers = [counting_fh]  # replace the plain fh built above

        listener = logging.handlers.QueueListener(
            log_queue,
            *handlers,
            respect_handler_level=True,
        )
        listener.start()

        # Attach QueueHandler to root logger — one call, covers everything.
        # Set root to DEBUG so no records are filtered before reaching the queue.
        # The FileHandler above does the actual level filtering.
        root = logging.getLogger()
        root.handlers = [logging.handlers.QueueHandler(log_queue)]
        root.setLevel(logging.DEBUG)

        # reachable logger: propagate to root so its records reach the queue
        reachable = logging.getLogger("reachable")
        reachable.propagate = True
        reachable.handlers = []
        reachable.setLevel(logging.DEBUG)

        with _active_queue_lock:
            _active_queue = log_queue

        return QueueHandle(log_queue=log_queue, listener=listener, log_path=log_path, _counting_handler=counting_fh)

    except Exception as exc:
        _LOGGER.debug("log_queue: failed to start: %s", exc)
        return None


def stop_log_queue(handle: Optional[QueueHandle]) -> None:
    """
    Drain the queue, stop the listener, and close the log file.
    Safe to call with None (no-op).
    """
    global _active_queue

    if handle is None:
        return

    try:
        handle.listener.stop()   # drains queue then stops listener thread
    except Exception:
        pass

    # Report bytes written — debug/log only, never to console.
    if handle._counting_handler is not None:
        b = getattr(handle._counting_handler, 'bytes_written', 0)
        path = handle.log_path or ''
        _LOGGER.debug("[log_queue] bytes written to %s: %s", path, f"{b:,}")

    with _active_queue_lock:
        _active_queue = None


def attach_queue_handler(logger_name: str = "reachable", debug: bool = False) -> bool:
    """
    Attach a QueueHandler to the named logger so in-process records flow
    into the central queue.  Idempotent — safe to call multiple times.

    Returns True if a handler was attached, False if queue not active.
    """
    with _active_queue_lock:
        q = _active_queue

    if q is None:
        return False

    py_logger = logging.getLogger(logger_name)

    # Idempotency guard
    for h in py_logger.handlers:
        if isinstance(h, logging.handlers.QueueHandler):
            return True

    qh = logging.handlers.QueueHandler(q)
    qh.setLevel(logging.DEBUG if debug else logging.INFO)
    py_logger.addHandler(qh)
    return True


def make_stdout_reader(
    proc_stdout,
    step_name: str,
    debug: bool = False,
    print_console: bool = True,
) -> threading.Thread:
    """
    Return a daemon thread that reads lines from proc.stdout and:
      1. Prints each line to console (tee), prefixed with [step_name]
      2. Pushes each line into the active queue via logging.getLogger("step.<step_name>")

    Uses _active_queue directly — no queue parameter needed.
    If no queue is active, console-only output.

    The caller is responsible for starting the thread and joining it before
    calling proc.wait().
    """
    step_logger = logging.getLogger(f"step.{step_name}")
    step_logger.setLevel(logging.DEBUG if debug else logging.INFO)
    step_logger.handlers = []
    step_logger.propagate = False

    with _active_queue_lock:
        q = _active_queue
    if q is not None:
        qh = logging.handlers.QueueHandler(q)
        qh.setLevel(logging.DEBUG if debug else logging.INFO)
        step_logger.addHandler(qh)

    def _read():
        try:
            for raw_line in proc_stdout:
                line = raw_line.rstrip("\n")
                if not line:
                    continue
                if print_console:
                    if debug:
                        ts = datetime.now().strftime("%Y-%m-%dT%H:%M:%S")
                        print(f"{ts} [{step_name}] {line}", flush=True)
                    else:
                        print(f"  [{step_name}] {line}", flush=True)
                step_logger.info(line)
        except Exception:
            pass

    t = threading.Thread(target=_read, name=f"reader-{step_name}", daemon=True)
    return t
