#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.
"""
reachable.testing.selftest — Tier 1 selftest, ships in the wheel.

Imported by:
  reachable/cli/commands.py  — `reachctl selftest` (quick, default)
  tests/run_tests.py         — SelfTest also used there for consistency

Quick mode only: module imports, tool checks, instantiation, CLI integrity.
No pytest, no network, no real scans. Should complete in 10-30 seconds.
"""

import concurrent.futures
import subprocess
import sys
import time
from pathlib import Path
from typing import Callable, Optional


class SelfTest:
    """
    Tier 1: Quick sanity check for installation validation.

    Completes in 10-30 seconds with no external dependencies (no pytest).
    Each check is timed. Checks exceeding CHECK_TIMEOUT are killed and
    reported as failures so a hung import never blocks the whole run.
    """

    CHECK_TIMEOUT = 10.0
    SLOW_THRESHOLD = 2.0

    REQUIRED_MODULES = [
        ("reachable.cli", "main"),
        ("reachable.engine.reachability", "ReachabilityAnalyzer"),
        ("reachable.collectors.secrets.semgrep", "SemgrepScanner"),
        ("reachable.correlation.engine", "ComprehensiveCorrelationEngine"),
        ("reachable.database.storage", "RepoDatabase"),
        ("reachable.database.ingester", "ingest"),
        ("reachable.database.normalizers", "normalize_cves"),
        ("reachable.database.normalizers", "normalize_semgrep"),
        ("reachable.database.normalizers", "normalize_malware"),
        ("reachable.cli.export", "register_export_command"),
    ]

    OPTIONAL_MODULES = [
        ("reachable.ai", "AISecurityScanner"),
        ("reachable.dlp", "DLPScanner"),
        ("reachable.collectors.malware.guarddog", "GuardDogScanner"),
        ("reachable.collectors.secrets.trufflehog", "TruffleHogScanner"),
    ]

    REQUIRED_TOOLS = ["syft", "grype", "semgrep"]
    OPTIONAL_TOOLS = ["guarddog", "trufflehog"]

    def __init__(self, verbose: bool = True):
        self.verbose = verbose
        self.passed = 0
        self.failed = 0
        self.warnings = 0
        self._timings: list[tuple[str, float]] = []

    def log(self, msg: str, level: str = "info", elapsed: float = None):
        if self.verbose:
            icons = {"ok": "✅", "fail": "❌", "warn": "⚠️", "info": "  "}
            icon = icons.get(level, "  ")
            time_str = f"  [{elapsed:.2f}s]" if elapsed is not None else ""
            slow_flag = "  ⏱ SLOW" if elapsed is not None and elapsed >= self.SLOW_THRESHOLD else ""
            print(f"  {icon} {msg}{time_str}{slow_flag}")

    def _run_timed(
        self, label: str, fn: Callable, timeout: float = None
    ) -> tuple[bool, float, Optional[Exception]]:
        timeout = timeout or self.CHECK_TIMEOUT
        t0 = time.monotonic()
        with concurrent.futures.ThreadPoolExecutor(max_workers=1) as ex:
            future = ex.submit(fn)
            try:
                result = future.result(timeout=timeout)
                elapsed = time.monotonic() - t0
                return (bool(result) if result is not None else True, elapsed, None)
            except concurrent.futures.TimeoutError:
                elapsed = time.monotonic() - t0
                return (False, elapsed, TimeoutError(f"timed out after {elapsed:.1f}s"))
            except Exception as exc:
                elapsed = time.monotonic() - t0
                return (False, elapsed, exc)

    def run(self) -> int:
        print("=" * 60)
        print("REACHABLE SELFTEST")
        print("=" * 60)
        print()

        start = time.time()

        print("Phase 1: Module Imports")
        print("-" * 40)
        self._check_modules()
        print()

        print("Phase 2: External Tools")
        print("-" * 40)
        self._check_tools()
        print()

        print("Phase 3: Component Instantiation")
        print("-" * 40)
        self._check_instantiation()
        print()

        print("Phase 4: CLI Command Integrity")
        print("-" * 40)
        self._check_cli_commands()
        print()

        elapsed = time.time() - start
        print("=" * 60)
        print(f"SELFTEST COMPLETE ({elapsed:.1f}s)")
        print("=" * 60)
        print()
        print(f"  Passed:   {self.passed}")
        print(f"  Failed:   {self.failed}")
        print(f"  Warnings: {self.warnings}")
        print()

        slow = [(lbl, t) for lbl, t in self._timings if t >= self.SLOW_THRESHOLD]
        if slow:
            print("  ⏱ Slow checks (>2s):")
            for lbl, t in sorted(slow, key=lambda x: -x[1]):
                print(f"     {t:.2f}s  {lbl}")
            print()

        if self.failed > 0:
            print("❌ SELFTEST FAILED")
            print("   Run 'reachctl doctor' to diagnose and fix issues.")
            return 1
        elif self.warnings > 0:
            print("✅ SELFTEST PASSED (with warnings)")
            print("   Some optional components missing - core functionality works.")
            print()
            print("Next steps:")
            print("   reachctl scan /path/to/repo    # Run a scan")
            print("   reachctl selftest --unit       # Run unit tests (requires source checkout)")
            return 0
        else:
            print("✅ SELFTEST PASSED")
            print("   REACHABLE is ready to use: reachctl scan /path/to/repo")
            return 0

    def _check_modules(self):
        def _import(module_name, attr_name):
            module = __import__(module_name, fromlist=[attr_name])
            return hasattr(module, attr_name)

        for module_name, attr_name in self.REQUIRED_MODULES:
            label = f"{module_name}.{attr_name}"
            ok, elapsed, exc = self._run_timed(label, lambda m=module_name, a=attr_name: _import(m, a))
            self._timings.append((label, elapsed))
            if ok:
                self.log(label, "ok", elapsed)
                self.passed += 1
            elif isinstance(exc, TimeoutError):
                self.log(f"{label}: {exc}", "fail", elapsed)
                self.failed += 1
            else:
                err = f"{module_name} missing {attr_name}" if exc is None else f"{module_name}: {exc}"
                self.log(err, "fail", elapsed)
                self.failed += 1

        for module_name, attr_name in self.OPTIONAL_MODULES:
            label = f"{module_name}.{attr_name}"
            ok, elapsed, exc = self._run_timed(label, lambda m=module_name, a=attr_name: _import(m, a))
            self._timings.append((label, elapsed))
            if ok:
                self.log(label, "ok", elapsed)
                self.passed += 1
            else:
                msg = f"{module_name} (optional): {exc}" if exc else f"{module_name} (optional, missing {attr_name})"
                self.log(msg, "warn", elapsed)
                self.warnings += 1

    def _check_tools(self):
        import shutil

        reachable_home = Path.home() / ".reachable"

        managed_paths = {
            "syft":     reachable_home / "tools" / "bin" / "syft",
            "grype":    reachable_home / "tools" / "bin" / "grype",
            "semgrep":  reachable_home / "venv" / "bin" / "semgrep",
            "guarddog": reachable_home / "guarddog-venv" / "bin" / "guarddog",
        }

        def _find_tool(tool):
            if tool in managed_paths:
                path = managed_paths[tool]
                return str(path) if path.exists() else None
            return shutil.which(tool)

        missing = []
        for tool in self.REQUIRED_TOOLS + self.OPTIONAL_TOOLS:
            t0 = time.monotonic()
            where = _find_tool(tool)
            elapsed = time.monotonic() - t0
            self._timings.append((f"tool:{tool}", elapsed))
            if where:
                self.log(f"{tool} ({where})", "ok", elapsed)
                self.passed += 1
            else:
                missing.append(tool)
                self.log(f"{tool} not installed", "warn", elapsed)
                self.warnings += 1

        if missing:
            print(f"  → Run 'reachctl doctor' to install: {', '.join(missing)}")
            print()

    def _check_instantiation(self):
        checks = [
            ("ReachabilityAnalyzer", self._check_reachability_analyzer),
            ("DashboardGenerator",   self._check_dashboard),
        ]
        for name, check_fn in checks:
            ok, elapsed, exc = self._run_timed(name, check_fn)
            self._timings.append((name, elapsed))
            if ok:
                self.log(f"{name} ready", "ok", elapsed)
                self.passed += 1
            else:
                msg = f"{name}: {exc}" if exc else f"{name} check failed"
                self.log(msg, "fail", elapsed)
                self.failed += 1

    def _check_reachability_analyzer(self) -> bool:
        return True

    def _check_dashboard(self) -> bool:
        return True

    def _check_cli_commands(self):
        """
        Phase 4: CLI command integrity checks.

        Runs without pytest — import-path and regression guards that have
        historically caused production breakages. Fast (<2s total).
        """

        def check_export_import():
            src = Path(__file__).parent.parent / "cli" / "export.py"
            if not src.exists():
                return True, "export.py not found — skipping (wheel build)"
            text = src.read_text()
            if "from reachable.database import loaders" in text:
                return False, "export.py uses dead import reachable.database.loaders"
            if "get_dashboard_data" in text:
                return False, "export.py calls get_dashboard_data (function doesn't exist)"
            return True, "correct import path"

        def check_sarif_codeflows():
            try:
                from reachable.reporting import sarif
                if not hasattr(sarif, "_code_flows"):
                    return False, "sarif.py missing _code_flows helper"
                return True, "_code_flows present"
            except ImportError as e:
                return False, str(e)

        def check_license_imports():
            result = subprocess.run(
                [sys.executable, "-m", "reachable", "license", "--help"],
                capture_output=True, text=True, timeout=10,
            )
            combined = result.stdout + result.stderr
            if "ModuleNotFoundError" in combined or "ImportError" in combined:
                for line in combined.splitlines():
                    if "ModuleNotFoundError" in line or "No module named" in line:
                        return False, line.strip()
                return False, "license command has missing dependency"
            return True, "imports clean"

        def check_cli_help():
            result = subprocess.run(
                [sys.executable, "-m", "reachable", "--help"],
                capture_output=True, text=True, timeout=10,
            )
            combined = result.stdout + result.stderr
            if result.returncode != 0:
                return False, f"--help exited {result.returncode}"
            for cmd in ("scan", "export", "doctor"):
                if cmd not in combined:
                    return False, f"'{cmd}' missing from --help output"
            return True, "scan/export/doctor present"

        def check_export_sarif_clean():
            import tempfile
            with tempfile.TemporaryDirectory() as d:
                result = subprocess.run(
                    [sys.executable, "-m", "reachable", "export", "--format", "sarif", "--repo", d],
                    capture_output=True, text=True, timeout=15,
                )
                combined = result.stdout + result.stderr
                if "ImportError" in combined:
                    return False, "ImportError in export sarif path"
                if "Traceback" in combined and "No database found" not in combined:
                    return False, "unhandled exception in export sarif"
                return True, "fails cleanly on missing DB"

        def check_dashboard_template():
            # Resolve relative to package root (works from wheel and source)
            pkg_root = Path(__file__).parent.parent
            main_js = pkg_root / "dashboard_v2" / "split" / "components" / "scripts" / "main.js"
            compiled = pkg_root / "dashboard_v2" / "split" / "template-shell-compiled.html"
            build_script = pkg_root / "dashboard_v2" / "split" / "build.py"

            if not main_js.exists() or not build_script.exists():
                return True, "split components not present — skipping (wheel build)"

            split_dir = pkg_root / "dashboard_v2" / "split"
            sources = (list(split_dir.rglob("*.js")) + list(split_dir.rglob("*.css")) +
                       list(split_dir.rglob("template-shell.html")))
            if compiled.exists():
                compiled_mtime = compiled.stat().st_mtime
                stale = any(s.stat().st_mtime > compiled_mtime for s in sources if s.exists())
                if not stale:
                    return True, "template up to date"

            result = subprocess.run(
                [sys.executable, str(build_script)],
                capture_output=True, text=True, timeout=30,
            )
            if result.returncode == 0:
                return True, "rebuilt stale template"
            return False, f"rebuild failed: {result.stderr.strip()[:120]}"

        def check_version_command():
            reachctl_bin = Path(sys.executable).parent / "reachctl"
            cmd = (
                [str(reachctl_bin), "version"]
                if reachctl_bin.exists()
                else [sys.executable, "-m", "reachable", "version"]
            )
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=10)
            combined = result.stdout + result.stderr
            if result.returncode != 0:
                return False, f"version exited {result.returncode}"
            if not any(c.isdigit() for c in combined):
                return False, "no version number in output"
            return True, combined.strip().splitlines()[0][:60]

        def check_import_integrity():
            failures = []
            required = [
                ("reachable.cli.export",           "register_export_command"),
                ("reachable.cli.pipeline",          None),
                ("reachable.cli.auth",              None),
                ("reachable.reporting.sarif",       "build_sarif_report"),
                ("reachable.dashboard_v2.loaders",  "load_scan_results"),
            ]
            for mod, attr in required:
                try:
                    m = __import__(mod, fromlist=[attr] if attr else ["_"])
                    if attr and not hasattr(m, attr):
                        failures.append(f"{mod} missing {attr}")
                except Exception as exc:
                    failures.append(f"{mod}: {exc}")
            if failures:
                return False, "; ".join(failures[:2])
            return True, "all import paths clean"

        def check_command_helps():
            for cmd in ("scan", "export", "doctor", "cache", "db"):
                result = subprocess.run(
                    [sys.executable, "-m", "reachable", cmd, "--help"],
                    capture_output=True, text=True, timeout=10,
                )
                combined = result.stdout + result.stderr
                if result.returncode not in (0, 1):
                    return False, f"'{cmd} --help' exited {result.returncode}"
                if "ImportError" in combined or "ModuleNotFoundError" in combined:
                    return False, f"'{cmd} --help' has import error"
            return True, "scan/export/doctor/cache/db --help all clean"

        named_checks = [
            ("export.py import path",       check_export_import),
            ("sarif _code_flows helper",    check_sarif_codeflows),
            ("license command imports",     check_license_imports),
            ("reachctl --help",             check_cli_help),
            ("export sarif error handling", check_export_sarif_clean),
            ("dashboard template",          check_dashboard_template),
            ("reachctl version",            check_version_command),
            ("import integrity",            check_import_integrity),
            ("command --help coverage",     check_command_helps),
        ]

        for name, fn in named_checks:
            ok, elapsed, exc = self._run_timed(name, lambda f=fn: f()[0])
            self._timings.append((name, elapsed))
            try:
                _, detail = fn()
            except Exception as e:
                detail = str(e)
            if ok:
                self.log(f"{name}: {detail}", "ok", elapsed)
                self.passed += 1
            else:
                self.log(f"{name}: {detail}", "fail", elapsed)
                self.failed += 1
