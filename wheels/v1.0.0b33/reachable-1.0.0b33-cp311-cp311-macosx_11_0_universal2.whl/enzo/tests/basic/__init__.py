# enzo basic selftest package — ships in the wheel
# Inline checks live in enzo/cli.py (_cmd_selftest).
# This package exists so setuptools recognises the directory cleanly.
