#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.
"""
Enzo CLI — standalone and reachctl-integrated.

Standalone:   python -m enzo run /path/to/repo
Integrated:   reachctl enzo run /path/to/repo
"""

from __future__ import annotations

import argparse
import json
import logging
import sys
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from enzo.config import EnzoConfig

logger = logging.getLogger("enzo")


def _clean_api_error(msg: str) -> str:
    """
    Strip raw JSON from API error messages, leaving just the human text.

    e.g. 'HTTP 400: {"type":"error","error":{"message":"Your credit balance..."}}'
         → 'HTTP 400: Your credit balance is too low to access the Anthropic API.'
    """
    if not msg:
        return msg
    brace = msg.find("{")
    if brace != -1:
        try:
            obj = json.loads(msg[brace:])
            api_msg = (
                obj.get("error", {}).get("message")
                or obj.get("message")
            )
            if api_msg:
                prefix = msg[:brace].rstrip(": ")
                return f"{prefix}: {api_msg}" if prefix else api_msg
        except (json.JSONDecodeError, AttributeError):
            pass
    return msg


def _add_common_args(parser):
    parser.add_argument("repo", metavar="PATH", nargs="?", default=".",
                        help="Repository root (default: current directory)")
    parser.add_argument("--scan-id", type=int, default=None,
                        help="Scan number from repo.db (e.g. 13). Default: latest")
    parser.add_argument("--severity", default="HIGH", help="Minimum severity (default: HIGH)")
    parser.add_argument("--reachable-only", action="store_true", help="Only REACHABLE findings")


def _build_subparsers(sub):
    """Define all enzo subcommands."""

    # ── setup ──────────────────────────────────────────────────────────
    p = sub.add_parser("setup", help="Detect resources, select model, pull, configure",
        epilog="Examples:\n"
               "  reachctl enzo setup              Auto-detect and install best model\n"
               "  reachctl enzo setup --list       Show which models fit your machine\n"
               "  reachctl enzo setup --check      Verify current setup is healthy\n",
        formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--list", action="store_true", dest="list_tiers", help="Show all model tiers vs system resources")
    p.add_argument("--check", action="store_true", help="Health check current setup")
    p.add_argument("--model", default=None, help="Explicit model tag (e.g. qwen2.5-coder:14b)")
    p.add_argument("--gpu", action="store_true", help="Prefer GPU-optimized tiers")
    p.add_argument("--repo", default=None, help="Also save config to repo .reachable.yml")
    p.add_argument("--endpoint", default="http://localhost:11434", help="Ollama endpoint")
    p.set_defaults(func=_cmd_setup)

    # ── doctor ────────────────────────────────────────────────────────────
    p = sub.add_parser("doctor",
        help="Check enzo health: model, API keys, build tools",
        epilog="Examples:\n"
               "  reachctl enzo doctor           Status check\n"
               "  reachctl enzo doctor --fix     Interactively install missing build tools\n",
        formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--fix", action="store_true",
                   help="Interactively install missing build tools (brew/apt)")
    p.add_argument("--endpoint", default="http://localhost:11434",
                   help="Ollama endpoint (default: http://localhost:11434)")
    p.set_defaults(func=_cmd_doctor)

    # ── scan ──────────────────────────────────────────────────────────
    p = sub.add_parser("scan",
        help="Show fixable findings from the last scan (does NOT rescan)",
        description="Read the latest scan results and show which findings enzo can fix.\n"
                    "Requires a prior 'reachctl scan' — this command reads, not rescans.",
        epilog="Examples:\n"
               "  reachctl enzo scan                         Show fixable findings (current dir)\n"
               "  reachctl enzo scan ~/src/myrepo             Show fixable findings for myrepo\n"
               "  reachctl enzo scan --reachable-only         Only findings reachable in code\n"
               "  reachctl enzo scan --fix-type code_patch    Only code-level fixes\n"
               "\n"
               "Fix types: code_patch, dependency_upgrade, config_change, secret_rotation, dlp_patch\n",
        formatter_class=argparse.RawDescriptionHelpFormatter)
    _add_common_args(p)
    p.add_argument("--fix-type", default=None,
                   help="Filter: code_patch, dependency_upgrade, config_change, secret_rotation, dlp_patch")
    p.set_defaults(func=_cmd_scan)

    # ── fix ───────────────────────────────────────────────────────────
    p = sub.add_parser("fix",
        help="Fix one specific finding by ID",
        epilog="Examples:\n"
               "  reachctl enzo fix ~/src/myrepo --finding-id 07d2d96af949 --dry-run\n"
               "  reachctl enzo fix ~/src/myrepo --finding-id 07d2d96af949 --mode cloud --provider groq\n"
               "  reachctl enzo fix ~/src/myrepo --finding-id 07d2d96af949 --mode cloud --provider claude\n"
               "\n"
               "Get finding IDs from: reachctl enzo scan\n",
        formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("repo", metavar="PATH", nargs="?", default=".",
                   help="Repository root (default: current directory)")
    p.add_argument("--scan-id", type=int, default=None,
                   help="Scan number from repo.db (e.g. 13). Default: latest")
    p.add_argument("--finding-id", required=True, help="Finding ID (from 'enzo scan' output)")
    p.add_argument("--dry-run", action="store_true", help="Generate patch but don't apply")
    p.add_argument("--model", default=None, help="Override local model (e.g. qwen2.5-coder:14b)")
    p.add_argument(
        "--mode", default="local",
        choices=["local", "cloud", "fallback"],
        help="local=Ollama (default), cloud=Claude/Groq API, fallback=Ollama then cloud",
    )
    p.add_argument(
        "--provider", default=None, choices=["claude", "groq"],
        help="Cloud provider (--mode cloud/fallback): claude (default) or groq",
    )
    p.add_argument("--debug", "-d", action="store_true", help="Verbose debug output")
    p.set_defaults(func=_cmd_fix)

    # ── run ───────────────────────────────────────────────────────────
    p = sub.add_parser("run",
        help="Fix all findings: scan → fix → validate → commit",
        description="Full auto-remediation pipeline. For each fixable finding:\n"
                    "generate patch → validate (build + test) → commit if clean.",
        epilog="Modes:\n"
               "Fix types handled:\n"
               "  code_patch         AI patches for CWE vulnerabilities (SQL injection, XSS, …)\n"
               "  dependency_upgrade Bump packages to fix CVEs (version algebra, conflict resolution)\n"
               "  secret_rotation    Replace hardcoded secrets with env-var references\n"
               "  config_change      Fix insecure configurations\n"
               "  dlp_patch          Mask/redact PII/sensitive data in logging, storage, transmission\n"
               "\n"
               "Modes:\n"
               "  --mode local                       Ollama only, code stays on machine (default)\n"
               "  --mode cloud --provider groq       Groq Cloud (fast, cheap)\n"
               "  --mode cloud --provider claude     Claude API — highest quality\n"
               "  --mode fallback --provider groq    Ollama first, Groq if all candidates fail\n"
               "  --mode fallback --provider claude  Ollama first, Claude if all candidates fail\n"
               "\n"
               "Examples:\n"
               "  reachctl enzo run ~/src/myrepo --debug\n"
               "  reachctl enzo run ~/src/myrepo --mode cloud --provider groq --debug\n"
               "  reachctl enzo run ~/src/myrepo --mode cloud --provider claude\n"
               "  reachctl enzo run ~/src/myrepo --mode fallback --provider groq --debug\n"
               "  reachctl enzo run ~/src/myrepo --dry-run --mode cloud --provider groq\n"
               "\n"
               "Typical workflow:\n"
               "  1. reachctl scan ~/src/myrepo                               Security scan\n"
               "  2. reachctl enzo scan ~/src/myrepo                          Review fixable findings\n"
               "  3. reachctl enzo run ~/src/myrepo --dry-run                 Preview (local)\n"
               "  4. reachctl enzo run ~/src/myrepo --mode cloud --provider groq  Apply and commit\n",
        formatter_class=argparse.RawDescriptionHelpFormatter)
    _add_common_args(p)
    p.add_argument("--dry-run", action="store_true", help="Generate patches but don't apply or commit")
    p.add_argument("--mode", default="local",
                   choices=["local", "cloud", "fallback", "both"],
                   help="local=Ollama (default), cloud=Claude/Groq API, fallback=Ollama then cloud on failure")
    p.add_argument("--max-retries", type=int, default=None, help="Max fix attempts per finding (default: 3)")
    p.add_argument("--provider", default=None, choices=["claude", "groq"],
                   help="Cloud provider for cloud/fallback modes: claude (default) or groq")
    p.add_argument("--no-consolidate", action="store_false", dest="consolidate",
                   default=True,
                   help="Skip merging fix branches into a batch branch")
    p.add_argument("--fail-fast", action="store_true", dest="fail_fast",
                   help="Stop after the first failed finding (default: continue to next finding)")
    p.add_argument("--force", action="store_true",
                   help="Re-remediate all findings, ignoring prior successes in enzo.db")
    p.add_argument("--debug", "-d", action="store_true", help="Verbose debug output")
    p.set_defaults(func=_cmd_run)

    # ── status ────────────────────────────────────────────────────────
    p = sub.add_parser("status",
        help="Show remediation history for a repo",
        epilog="Examples:\n"
               "  reachctl enzo status                 History for current dir\n"
               "  reachctl enzo status ~/src/myrepo    History for a repo\n",
        formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("repo", metavar="PATH", nargs="?", default=".",
                    help="Repository root (default: current directory)")
    p.set_defaults(func=_cmd_status)

    # ── pentest ───────────────────────────────────────────────────────
    p = sub.add_parser("pentest",
        help="Verify fixes with exploit payloads (before/after)",
        description="Run CWE-specific exploit payloads against findings to verify\n"
                    "that patches actually block the attack. Also checks CVE upgrades,\n"
                    "secret removal, and malware pattern cleanup.",
        epilog="Examples:\n"
               "  reachctl enzo pentest ~/src/myrepo                     Test all fixable\n"
               "  reachctl enzo pentest ~/src/myrepo --finding-id 07d2   Test one finding\n"
               "  reachctl enzo pentest ~/src/myrepo --type cwe          Only CWE findings\n"
               "\n"
               "Verdicts:\n"
               "  CONFIRMED    Exploit blocked after patch\n"
               "  FAILED       Exploit still works after patch\n"
               "  INCONCLUSIVE Cannot determine (missing info)\n"
               "  SKIPPED      No test available for this finding type\n",
        formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("repo", metavar="PATH", nargs="?", default=".",
                   help="Repository root (default: current directory)")
    p.add_argument("--scan-id", type=int, default=None,
                   help="Database scan ID (default: latest scan)")
    p.add_argument("--finding-id", default=None,
                   help="Test one specific finding")
    p.add_argument("--type", dest="signal_type", default=None,
                   choices=["cwe", "cve", "secret", "malware"],
                   help="Filter by signal type")
    p.add_argument("--reachable-only", action="store_true",
                   help="Only test reachable findings")
    p.set_defaults(func=_cmd_pentest)

    # ── metrics ───────────────────────────────────────────────────────
    p = sub.add_parser("metrics",
        help="Show pipeline performance metrics from enzo.db",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="Examples:\n"
               "  reachctl enzo metrics ~/src/repo --since 30d\n"
               "  reachctl enzo metrics ~/src/repo --since 2026-01-01 --json\n")
    p.add_argument("repo", metavar="PATH", nargs="?", default=".",
                   help="Repository root")
    p.add_argument("--since", default="30d",
                   help="Period: Nd (days) or YYYY-MM-DD (default: 30d)")
    p.add_argument("--json", action="store_true", dest="json_output",
                   help="Output as JSON")
    p.set_defaults(func=_cmd_metrics)

    # ── benchmark ─────────────────────────────────────────────────────
    p = sub.add_parser("benchmark",
        help="Run fixture suite to measure fix quality across languages and CWEs",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="Examples:\n"
               "  reachctl enzo benchmark\n"
               "  reachctl enzo benchmark --model groq/llama-3.3-70b-versatile\n"
               "  reachctl enzo benchmark --deterministic-only\n"
               "  reachctl enzo benchmark --compare bm_20260303_184211\n")
    p.add_argument("repo", metavar="PATH", nargs="?", default=".",
                   help="Repository root (for enzo.db path)")
    p.add_argument("--model", default=None,
                   help="Model to benchmark (e.g. groq/llama-3.3-70b-versatile)")
    p.add_argument("--provider", default="groq", choices=["groq", "claude", "local"],
                   help="Provider for AI fixtures (default: groq)")
    p.add_argument("--deterministic-only", action="store_true",
                   help="Only run deterministic fixtures (no API key needed)")
    p.add_argument("--compare", default=None, metavar="RUN_ID",
                   help="Compare against a previous benchmark run_id")
    p.add_argument("--debug", "-d", action="store_true")
    p.set_defaults(func=_cmd_benchmark)

    # ── report ────────────────────────────────────────────────────────
    p = sub.add_parser("report",
        help="Generate AI risk report or GRC compliance evidence report",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="Report types:\n"
               "  (default)              Full risk report with finding analysis\n"
               "  --executive            200-word executive summary\n"
               "  --framework soc2       GRC compliance evidence (SOC2)\n"
               "  --framework pci        PCI-DSS 4.0 evidence\n"
               "  --framework nist       NIST 800-53 evidence\n"
               "  --framework owasp_asvs OWASP ASVS 4.0 evidence\n"
               "  --finding <id>         Deep-dive on one finding\n"
               "  --accepted-risks       Interactive accepted risk workflow\n"
               "\nExamples:\n"
               "  reachctl enzo report ~/src/repo\n"
               "  reachctl enzo report ~/src/repo --framework soc2\n"
               "  reachctl enzo report ~/src/repo --framework pci --output pdf\n"
               "  reachctl enzo report ~/src/repo --executive\n"
               "  reachctl enzo report ~/src/repo --finding 07d2d96af949\n"
               "  reachctl enzo report ~/src/repo --accepted-risks\n"
               "  reachctl enzo report ~/src/repo --model ollama/deepseek-r1:7b\n")
    p.add_argument("repo", metavar="PATH", nargs="?", default=".",
                   help="Repository root")
    p.add_argument("--framework", default=None,
                   metavar="FRAMEWORK",
                   help="GRC framework: soc2 | pci | nist | owasp_asvs | iso27001 | hipaa")
    p.add_argument("--executive", action="store_true",
                   help="200-word executive summary only")
    p.add_argument("--finding", default=None, metavar="ID",
                   help="Deep-dive analysis of one finding by ID")
    p.add_argument("--accepted-risks", action="store_true", dest="accepted_risks",
                   help="Interactive accepted risk documentation workflow")
    p.add_argument("--org", default="Organisation", metavar="NAME",
                   help="Organisation name for report header")
    p.add_argument("--model", default=None,
                   help="Model: ollama/<name> or groq/<name> (default: auto-detect Ollama)")
    p.add_argument("--output", default="markdown", choices=["markdown", "pdf"],
                   help="Output format (default: markdown)")
    p.add_argument("--output-path", default=None, metavar="PATH",
                   help="Write report to this path (default: .reachable/reports/)")
    p.add_argument("--scan-id", type=int, default=None,
                   help="Specific scan ID (default: latest)")
    p.add_argument("--period-start", default=None, metavar="YYYY-MM-DD")
    p.add_argument("--period-end",   default=None, metavar="YYYY-MM-DD")
    p.add_argument("--debug", "-d", action="store_true")
    p.set_defaults(func=_cmd_report)


    # ── ingest ────────────────────────────────────────────────────────────────
    p = sub.add_parser("ingest",
        help="Import findings from a third-party security tool",
        description="Normalise external tool output into enzo's canonical finding format.\n"
                    "Ingested files are saved to .reachable/ingest/ for gap analysis.",
        epilog="Supported tools:\n"
               "  dependabot    GitHub Security Alerts API JSON\n"
               "  codeql        SARIF 2.1.0 (also accepts semgrep, bandit SARIF)\n"
               "  trivy         SARIF or native JSON (--fmt json for richer CVE data)\n"
               "  osv           OSV-Scanner JSON (google/osv-scanner --format json)\n"
               "\n"
               "Examples:\n"
               "  reachctl enzo ingest --tool dependabot --file github-alerts.json\n"
               "  reachctl enzo ingest --tool codeql     --file codeql.sarif\n"
               "  reachctl enzo ingest --tool trivy      --file trivy.sarif\n"
               "  reachctl enzo ingest --tool trivy      --file trivy.json --fmt json\n"
               "  reachctl enzo ingest --tool osv        --file osv-results.json\n"
               "\n"
               "After ingestion, run: reachctl enzo gap-analysis\n",
        formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("repo", metavar="PATH", nargs="?", default=".",
                   help="Repository root (default: current directory)")
    p.add_argument("--tool", required=True,
                   choices=["dependabot", "codeql", "semgrep", "bandit", "trivy", "osv"],
                   help="Source tool")
    p.add_argument("--file", required=True, metavar="PATH",
                   help="Tool output file to ingest")
    p.add_argument("--fmt", default=None, choices=["sarif", "json"],
                   help="Force format (trivy: sarif or json; auto-detected by default)")
    p.set_defaults(func=_cmd_ingest)

    # ── gap-analysis ──────────────────────────────────────────────────────────
    p = sub.add_parser("gap-analysis",
        help="Compare ingested tool findings against reachable scan (two-bucket report)",
        description="Matches findings from ingested external tools against reachable's\n"
                    "repo.db. Produces an ACTIONABLE bucket (REACHABLE + UNKNOWN) and a\n"
                    "RAW bucket (full picture including UNREACHABLE noise).\n"
                    "\n"
                    "ACTIONABLE sections:\n"
                    "  Auto-fixed by Enzo       External open; Enzo patched it\n"
                    "  Confirmed Open           REACHABLE — call graph confirms exec path\n"
                    "  UNKNOWN — human review   Could not establish reachability; keep severity\n"
                    "  Severity disagreements   Both found it, different ratings\n"
                    "  External-only            External found; reachable missed (scanner gap)\n"
                    "  Reachable-only           Reachable found; external missed (false negative)\n"
                    "\n"
                    "RAW additionally shows:\n"
                    "  Noise (UNREACHABLE)      External flagged; call graph disproves reach\n",
        epilog="Examples:\n"
               "  reachctl enzo gap-analysis                   Report for current dir\n"
               "  reachctl enzo gap-analysis --since 7d        Enzo fixes in last 7 days\n"
               "  reachctl enzo gap-analysis --output gap.md   Write to file\n"
               "\n"
               "Requires prior ingestion: reachctl enzo ingest --tool <n> --file <path>\n",
        formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("repo", metavar="PATH", nargs="?", default=".",
                   help="Repository root (default: current directory)")
    p.add_argument("--scan-id", type=int, default=None,
                   help="Scan ID (default: latest)")
    p.add_argument("--since", default=None, metavar="Nd",
                   help="Only include enzo fixes from last N days (e.g. 7d)")
    p.add_argument("--output", default=None, metavar="PATH",
                   help="Write markdown report to file (default: print to stdout)")
    p.set_defaults(func=_cmd_gap_analysis)

    # ── knowledge ─────────────────────────────────────────────────────
    p = sub.add_parser("knowledge", help="Show global knowledge DB stats")
    p.set_defaults(func=_cmd_knowledge)

    # ── selftest ───────────────────────────────────────────────────────
    p = sub.add_parser("selftest",
        help="Verify enzo installation and optionally run dev test suites",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="Examples:\n"
               "  reachctl enzo selftest                 Quick sanity check (works from wheel)\n"
               "  reachctl enzo selftest --unit          Full unit suite (source checkout only)\n"
               "  reachctl enzo selftest --unit -v       Verbose output\n")
    p.add_argument("--unit", action="store_true",
                   help="Run full unit test suite (requires source checkout)")
    p.add_argument("-v", "--verbose", action="store_true",
                   help="Verbose output")
    p.set_defaults(func=_cmd_selftest)


def _resolve_repo(args) -> str:
    """Resolve repo path to absolute. Defaults to cwd."""
    repo = str(Path(args.repo).resolve())
    args.repo = repo
    return repo


def _load_config(args) -> "EnzoConfig":
    from .config import EnzoConfig
    _resolve_repo(args)
    overrides = {}
    if hasattr(args, "model") and args.model:
        overrides["local_model"] = args.model
    if hasattr(args, "mode") and args.mode:
        overrides["mode"] = args.mode
    if hasattr(args, "provider") and args.provider:
        overrides["provider"] = args.provider
    if hasattr(args, "max_retries") and args.max_retries is not None:
        overrides["max_retries"] = args.max_retries
    if hasattr(args, "severity") and args.severity:
        overrides["severity_threshold"] = args.severity
    if hasattr(args, "reachable_only") and args.reachable_only:
        overrides["reachable_only"] = True
    if hasattr(args, "force") and args.force:
        overrides["force"] = True
    return EnzoConfig.load(args.repo, overrides)


# ═══════════════════════════════════════════════════════════════════════════
#  Cloud consent
# ═══════════════════════════════════════════════════════════════════════════

def _check_cloud_consent(config) -> bool:
    """
    In 'cloud' mode, source code is sent to the Anthropic API.
    Require explicit one-time consent, stored in ~/.reachable/config.json.
    """
    # Check API key for cloud and both modes
    if config.mode == "cloud" and not config.cloud_api_key:
        print("\n  ✗ --mode cloud/both requires an Anthropic API key.")
    if (
        config.mode == "cloud"
        and getattr(config, "provider", "claude") == "groq"
        and not getattr(config, "groq_api_key", "")
    ):
        print("\n  ✗ --mode groq requires GROQ_API_KEY. Get one at https://console.groq.com/keys")
        print("    export GROQ_API_KEY=gsk_...")
        print("    Set: export ANTHROPIC_API_KEY=sk-ant-...")
        print("    Or:  reachctl auth login\n")
        return False

    if config.mode != "cloud":
        return True  # local and both modes don't send source code

    if config.cloud_code_consent:
        return True

    # Check global config
    try:
        from reachable.core.config import load_config, save_config
        global_cfg = load_config()
        if global_cfg.get("enzo", {}).get("cloud_code_consent"):
            config.cloud_code_consent = True
            return True
    except Exception as exc:
        logger.debug("Could not load global config for cloud consent: %s", exc)

    # Prompt for consent
    print()
    print("  ┌" + "─" * 58 + "┐")
    print("  │  ⚠  CLOUD MODE — source code will be sent to the API   │")
    print("  ├" + "─" * 58 + "┤")
    print("  │  --mode cloud sends file contents to Anthropic's Claude │")
    print("  │  API so it can generate security patches.               │")
    print("  │                                                         │")
    print("  │  • Code is processed but NOT stored or used for         │")
    print("  │    model training (see anthropic.com/policies)          │")
    print("  │  • Use --mode local or --mode both to keep code local   │")
    print("  └" + "─" * 58 + "┘")
    print()

    try:
        answer = input("  Accept and continue? [y/N] ").strip().lower()
    except (EOFError, KeyboardInterrupt):
        print()
        return False

    if answer not in ("y", "yes"):
        print("  Cancelled. Use --mode local or --mode both instead.")
        return False

    # Store consent
    config.cloud_code_consent = True
    try:
        from reachable.core.config import load_config, save_config
        global_cfg = load_config()
        if "enzo" not in global_cfg:
            global_cfg["enzo"] = {}
        global_cfg["enzo"]["cloud_code_consent"] = True
        save_config(global_cfg)
        print("  ✓ Saved to ~/.reachable/config.json (won't ask again)")
    except Exception:
        print("  ✓ Accepted (could not save preference, will ask next time)")

    print()
    return True


# ═══════════════════════════════════════════════════════════════════════════
#  Command implementations
# ═══════════════════════════════════════════════════════════════════════════

def _cmd_setup(args):
    from .setup import run_setup
    run_setup(
        model_override=args.model,
        prefer_gpu=args.gpu,
        list_only=args.list_tiers,
        check_only=args.check,
        repo_path=args.repo,
        endpoint=args.endpoint,
        interactive=True,
    )


def _cmd_doctor(args):
    from .setup import run_doctor
    run_doctor(
        fix_mode=getattr(args, "fix", False),
        endpoint=getattr(args, "endpoint", "http://localhost:11434"),
    )


def _cmd_scan(args):
    from .classifier import classify_batch, filter_fixable, prioritize
    from .query import RepoReader, get_repo_db_path

    config = _load_config(args)
    db_path = get_repo_db_path(args.repo)

    if not db_path.exists():
        print(f"No scan data found for: {args.repo}")
        print(f"  Expected: {db_path}")
        print(f"  Run first: reachctl scan {args.repo}")
        return

    reader = RepoReader(db_path)

    scan_id = args.scan_id or reader.get_latest_scan_id()
    if not scan_id:
        print("No completed scans found.")
        return

    scan_info = reader.get_scan_info(scan_id)

    findings = reader.get_findings(scan_id=scan_id, reachable_only=config.reachable_only)
    classify_batch(findings)
    fixable = filter_fixable(findings, [args.fix_type] if args.fix_type else config.fix_types)
    fixable = [f for f in fixable if config.severity_meets_threshold(f.severity)]
    fixable = prioritize(fixable)

    # ── Header ────────────────────────────────────────────────────
    repo_name = Path(args.repo).name
    branch = scan_info.get("branch", "?") if scan_info else "?"
    ts = scan_info.get("timestamp", "") if scan_info else ""
    version = scan_info.get("version", "") if scan_info else ""

    print(f"\n{'═' * 64}")
    print(f"  ENZO TRIAGE — {repo_name}")
    print(f"{'═' * 64}")
    print(f"  Scan #{scan_id}  branch: {branch}  {ts}")
    if version:
        print(f"  REACHABLE {version}")
    print(f"  Total: {len(findings)} findings, {len(fixable)} fixable")
    print(f"{'─' * 64}")

    if not fixable:
        print("\n  No fixable findings matching criteria.\n")
        reader.close()
        return

    # ── Group by fix type ─────────────────────────────────────────
    from collections import defaultdict
    groups = defaultdict(list)
    for f in fixable:
        groups[f.fix_type.value].append(f)

    # Section labels
    section_labels = {
        "code_patch": "CODE PATCHES",
        "dependency_upgrade": "DEPENDENCY UPGRADES",
        "config_change": "CONFIGURATION",
        "secret_rotation": "SECRETS",
        "dlp_patch": "DLP / PII REMEDIATION",
    }

    for fix_type, group in groups.items():
        label = section_labels.get(fix_type, fix_type.upper())
        print(f"\n  {label} ({len(group)})")
        print(f"  {'─' * 60}")

        for f in group:
            reach = "🟢" if f.app_reachability == "REACHABLE" else "⚪"

            # ID line: severity + reachability + finding ID
            sev = f.severity
            ids = []
            if f.cwe_id:
                ids.append(f.cwe_id)
            if f.cve_id:
                ids.append(f.cve_id)
            elif f.raw_data and isinstance(f.raw_data, dict) and f.raw_data.get("ghsa_id"):
                ids.append(f.raw_data["ghsa_id"])
            if f.secret_type:
                ids.append(f"secret:{f.secret_type}")
            id_str = " ".join(ids) if ids else f.finding_type

            print(f"\n  {reach} {sev:<9s} {id_str}  [{f.finding_id[:12]}]")

            # Description (truncated)
            desc = f.title or f.description or ""
            if len(desc) > 90:
                desc = desc[:87] + "..."
            if desc:
                print(f"    {desc}")

            # Location
            if f.file_path:
                loc = f.file_path
                if f.line_number:
                    loc += f":{f.line_number}"
                print(f"    File: {loc}")

            # Package
            if f.package_name:
                pkg = f.package_name
                if f.package_version:
                    pkg += f"@{f.package_version}"
                if f.fix_version:
                    pkg += f" → {f.fix_version}"
                print(f"    Pkg:  {pkg}")

            # Scanner
            if f.scanner:
                print(f"    Via:  {f.scanner}")

    # ── Summary ───────────────────────────────────────────────────
    reach_count = sum(1 for f in fixable if f.app_reachability == "REACHABLE")
    crit = sum(1 for f in fixable if f.severity == "CRITICAL")
    high = sum(1 for f in fixable if f.severity == "HIGH")

    print(f"\n{'─' * 64}")
    print(f"  Summary: {len(fixable)} fixable — "
          f"{crit} critical, {high} high — "
          f"{reach_count} reachable 🟢")
    print(f"\n  Next: reachctl enzo run {args.repo} --dry-run")
    print(f"{'═' * 64}\n")

    reader.close()


def _cmd_fix(args):
    if getattr(args, "debug", False):
        logging.getLogger("enzo").setLevel(logging.DEBUG)
        if not logging.getLogger("enzo").handlers:
            _h = logging.StreamHandler()
            _h.setFormatter(logging.Formatter("%(name)s %(levelname)s %(message)s"))
            logging.getLogger("enzo").addHandler(_h)
        logging.getLogger("enzo").propagate = False

    config = _load_config(args)

    if not _check_cloud_consent(config):
        return

    from .pipeline import EnzoPipeline

    pipeline = EnzoPipeline(config, args.repo)
    try:
        outcome = pipeline.fix_finding(
            args.finding_id, scan_id=args.scan_id, dry_run=args.dry_run,
        )
        _print_outcome(outcome, args.dry_run)
    finally:
        pipeline.close()


def _cmd_run(args):
    # Wire --debug independently of reachctl log setup.
    # Forces DEBUG level on the enzo logger tree regardless of outer config.
    if getattr(args, "debug", False):
        logging.getLogger("enzo").setLevel(logging.DEBUG)
        if not logging.getLogger("enzo").handlers:
            _h = logging.StreamHandler()
            _h.setFormatter(logging.Formatter("%(name)s %(levelname)s %(message)s"))
            logging.getLogger("enzo").addHandler(_h)
        logging.getLogger("enzo").propagate = False

    config = _load_config(args)

    if not _check_cloud_consent(config):
        return

    _provider = getattr(config, "provider", "claude")
    _groq_model = getattr(config, "groq_model", "groq")
    mode_desc = {
        ("local",    "claude"): "local (Ollama)",
        ("local",    "groq"):   "local (Ollama)",
        ("cloud",    "groq"):   f"cloud (Groq — {_groq_model})",
        ("cloud",    "claude"): "cloud (Claude API)",
        ("fallback", "groq"):   f"fallback (Ollama → Groq {_groq_model} if local fails)",
        ("fallback", "claude"): "fallback (Ollama → Claude if local fails)",
    }
    _mode_label = mode_desc.get(
        (config.mode, _provider), config.mode
    )
    print(f"\nEnzo mode: {_mode_label}")

    from .pipeline import EnzoPipeline

    pipeline = EnzoPipeline(config, args.repo)
    try:
        result = pipeline.run(
            scan_id=args.scan_id,
            dry_run=args.dry_run,
            fail_fast=args.fail_fast,
            consolidate_branch=getattr(args, "consolidate", True),
        )
    finally:
        pipeline.close()

    print(f"\n{'─' * 60}")
    print("ENZO PIPELINE RESULTS")
    print(f"{'─' * 60}")
    print(f"  Total findings:    {result.total_findings}")
    print(f"  Fixable:           {result.fixable_findings}")
    print(f"  Attempted:         {result.attempted}")
    print(f"  ✓ Succeeded:       {result.succeeded}")
    print(f"  ✗ Failed:          {result.failed}")
    print(f"  ⚠ Manual:          {result.manual}")
    if result.aborted:
        _abort_reason = _clean_api_error(result.abort_reason) or "fatal error"
        print(f"  ⛔ Aborted:        {result.aborted}  ← pipeline stopped ({_abort_reason})")

    # When the pipeline aborted (fatal error or --fail-fast), only show
    # the finding that actually failed — not the wall of skipped ones.
    pipeline_stopped = getattr(args, "fail_fast", False) or bool(result.abort_reason)
    for o in result.outcomes:
        is_skipped = (
            o.status.value == "aborted"
            and o.error
            and ("Skipped" in o.error or "aborted by earlier" in o.error)
        )
        if is_skipped and pipeline_stopped:
            continue
        status = {"success": "✓", "failed": "✗", "manual": "⚠"}.get(o.status.value, "?")
        print(f"  {status} {o.finding_id[:12]} ({o.fix_type}) — {o.status.value}")
        if o.status.value == "success" and o.branch and o.branch != "(detached)":
            print(f"      branch: {o.branch}")
        if o.error:
            print(f"    Error: {_clean_api_error(o.error)[:120]}")

    # ── NEXT STEPS — consolidation-aware ────────────────────────────────────
    succeeded_outcomes = [o for o in result.outcomes if o.status.value == "success" and o.branch]
    if succeeded_outcomes:
        print(f"\n  {'─' * 58}")

        # Show verify stats if verification ran
        if result.verified or result.verify_failed:
            total_v = result.verified + result.verify_failed
            print(f"  VERIFICATION  ({result.verified}/{total_v} confirmed)")
            if result.verify_failed:
                print(f"  ⚠  {result.verify_failed} fix(es) could not be verified — review manually")
            else:
                print("  ✓  All targeted checks passed")
            print(f"  {'─' * 58}")

        print("  NEXT STEPS")
        print(f"  {'─' * 58}")

        if result.batch_branch:
            # Consolidated branch exists — primary workflow
            bb = result.batch_branch
            print(f"  Consolidated branch: {bb}")
            if result.consolidation_conflicts:
                print(f"  ⚠  {len(result.consolidation_conflicts)} branch(es) had merge conflicts — apply manually:")
                for b in result.consolidation_conflicts:
                    print(f"       {b}")
            print()
            print("  Review everything at once:")
            print(f"    git diff main..{bb}")
            print(f"    git merge {bb}")
            print()
            print("  Or cherry-pick individual fixes:")
            for o in succeeded_outcomes[:3]:
                b = o.branch
                if b and b != "(detached)":
                    print(f"    git merge {b}")
            if len(succeeded_outcomes) > 3:
                print(f"    ... ({len(succeeded_outcomes) - 3} more)")
        else:
            # No consolidation — show individual branches
            print("  Review and merge each fix branch:")
            print()
            for o in succeeded_outcomes:
                b = o.branch
                if b and b != "(detached)":
                    print(f"    git diff main..{b}")
                    print(f"    git merge {b}")
                    print()

        print(f"  {'─' * 58}")


def _cmd_pentest(args):
    from .classifier import classify_batch, filter_fixable, prioritize
    from .pentest.runner import PentestReport, PentestRunner
    from .query import RepoReader, get_repo_db_path

    repo = str(Path(args.repo).resolve())
    db_path = get_repo_db_path(repo)

    if not db_path.exists():
        print(f"No scan data found for: {repo}")
        print(f"  Run first: reachctl scan {repo}")
        return

    reader = RepoReader(db_path)
    scan_id = args.scan_id or reader.get_latest_scan_id()
    if not scan_id:
        print("No completed scans found.")
        return

    # Get findings
    reachable_only = getattr(args, "reachable_only", False)
    findings = reader.get_findings(scan_id=scan_id, reachable_only=reachable_only)
    classify_batch(findings)

    # Filter
    if args.finding_id:
        findings = [f for f in findings if f.finding_id.startswith(args.finding_id)]
        if not findings:
            print(f"Finding not found: {args.finding_id}")
            reader.close()
            return
    else:
        findings = filter_fixable(findings)
        findings = prioritize(findings)

    if args.signal_type:
        findings = [f for f in findings if f.finding_type == args.signal_type]

    if not findings:
        print("No findings to test.")
        reader.close()
        return

    # Run pentest
    repo_name = Path(repo).name
    runner = PentestRunner(repo, db_path)
    report = PentestReport(repo_path=repo)

    print(f"\n{'═' * 64}")
    print(f"  ENZO PENTEST — {repo_name}")
    print(f"{'═' * 64}")
    print(f"  Testing {len(findings)} findings...")
    print(f"{'─' * 64}")

    for f in findings:
        result = runner.run_finding(f)
        result.finding_id = f.finding_id
        report.results.append(result)

        # Print each result
        icon = result.icon
        cwe_str = f" {result.cwe_id}" if result.cwe_id else ""
        type_label = result.signal_type.upper()

        print(f"\n  {icon} [{result.verdict:13s}] {type_label}{cwe_str}  [{f.finding_id[:12]}]")

        if result.file_path:
            print(f"    File: {result.file_path}")

        if result.before_details:
            print(f"    Before: {result.before_details[:80]}")

        if result.after_details:
            for line in result.after_details.split("\n")[:4]:
                print(f"    After:  {line.strip()}")

        if result.error:
            print(f"    Error:  {result.error[:80]}")

    # Summary
    print(f"\n{'─' * 64}")
    print(f"  RESULTS: {report.total} tested")
    print(f"    ✓ Confirmed: {report.confirmed}")
    print(f"    ✗ Failed:    {report.failed}")

    skipped = sum(1 for r in report.results if r.verdict == "SKIPPED")
    errors = sum(1 for r in report.results if r.verdict == "ERROR")
    inconclusive = sum(1 for r in report.results if r.verdict == "INCONCLUSIVE")

    if skipped:
        print(f"    ⊘ Skipped:   {skipped}")
    if inconclusive:
        print(f"    ? Unclear:   {inconclusive}")
    if errors:
        print(f"    ! Errors:    {errors}")

    print(f"{'═' * 64}\n")

    reader.close()


def _cmd_status(args):
    from .db import EnzoRepoDB
    from .query import get_repo_db_path

    _resolve_repo(args)
    db_path = get_repo_db_path(args.repo)

    if not db_path.exists():
        print(f"No scan data found for: {args.repo}")
        print(f"  Run first: reachctl scan {args.repo}")
        return

    enzo_db = EnzoRepoDB(db_path)
    summary = enzo_db.get_summary()

    print(f"\nEnzo status for {args.repo}")
    print(f"  Total attempts: {summary.get('total', 0)}")
    print(f"  Succeeded:      {summary.get('succeeded', 0)}")
    print(f"  Failed:         {summary.get('failed', 0)}")
    print(f"  Manual:         {summary.get('manual', 0)}")
    print(f"  Pending:        {summary.get('pending', 0)}")
    enzo_db.close()


def _cmd_metrics(args):
    import dataclasses as _dc
    import json as _json

    from .metrics import MetricsCollector, format_metrics, parse_since
    from .query import get_repo_db_path

    repo = str(Path(args.repo).resolve())
    enzo_db_path = str(get_repo_db_path(repo)).replace("repo.db", "enzo.db")
    if not Path(enzo_db_path).exists():
        print(f"No enzo.db found for: {repo}")
        print(f"  Run first: reachctl enzo run {repo}")
        return

    since_days = parse_since(getattr(args, "since", "30d"))
    collector = MetricsCollector(enzo_db_path, repo_path=repo)
    metrics = collector.collect_days(since_days)

    if getattr(args, "json_output", False):
        print(_json.dumps(_dc.asdict(metrics), indent=2, default=str))
        return

    print(format_metrics(metrics, repo_name=metrics.repo_name))


def _cmd_benchmark(args):
    from .benchmark import BenchmarkRunner
    from .query import get_repo_db_path

    if getattr(args, "debug", False):
        import logging
        logging.basicConfig(level=logging.DEBUG)

    repo = str(Path(args.repo).resolve())
    enzo_db_path = str(get_repo_db_path(repo)).replace("repo.db", "enzo.db")
    # Create enzo.db dir if needed
    Path(enzo_db_path).parent.mkdir(parents=True, exist_ok=True)

    model_arg = getattr(args, "model", None) or ""
    provider = getattr(args, "provider", "groq")
    det_only = getattr(args, "deterministic_only", False)

    # Resolve model name
    model = model_arg
    if not model and not det_only:
        api_key = __import__("os").environ.get("GROQ_API_KEY", "")
        if not api_key:
            print("  ⚠  GROQ_API_KEY not set — running deterministic fixtures only.")
            print("     Set GROQ_API_KEY or use --deterministic-only to suppress this.")
            det_only = True

    api_key = __import__("os").environ.get("GROQ_API_KEY", "")

    print(f"\n  {'━'*61}")
    print(f"  ENZO BENCHMARK  {model or 'deterministic-only'}")
    print(f"  {'━'*61}")

    runner = BenchmarkRunner(
        model=model.replace("groq/", "") if model.startswith("groq/") else model,
        provider=provider,
        db_path=enzo_db_path,
        api_key=api_key,
        only_deterministic=det_only,
    )

    compare_id = getattr(args, "compare", None)
    if compare_id:
        _benchmark_compare(enzo_db_path, compare_id, runner)
        return

    runner.run()


def _benchmark_compare(db_path: str, run_id: str, runner):
    import sqlite3
    con = sqlite3.connect(db_path)
    con.row_factory = sqlite3.Row
    prev = con.execute(
        "SELECT * FROM benchmark_runs WHERE run_id = ?", (run_id,)
    ).fetchone()
    if not prev:
        print(f"  Run ID not found: {run_id}")
        print("  Available runs:")
        for r in con.execute("SELECT run_id, timestamp, model FROM benchmark_runs ORDER BY timestamp DESC LIMIT 10").fetchall():
            print(f"    {r['run_id']}  {r['timestamp'][:19]}  {r['model']}")
        con.close()
        return
    con.close()

    print(f"\n  Running current benchmark for comparison with {run_id}...")
    runner.run()
    print(f"\n  vs {run_id}: model={prev['model']}  pass={prev['pass_count']}/{prev['fixture_count']}")


def _cmd_report(args):
    import logging
    if getattr(args, "debug", False):
        logging.basicConfig(level=logging.DEBUG)

    from .query import get_repo_db_path
    from .reporter.report import (
        ReportConfig,
        generate_deep_dive,
        generate_executive_summary,
        generate_grc_report,
        generate_risk_report,
        run_accepted_risk_workflow,
    )

    repo = str(Path(args.repo).resolve())
    repo_db_path = str(get_repo_db_path(repo))
    enzo_db_path = repo_db_path.replace("repo.db", "enzo.db")

    if not Path(repo_db_path).exists():
        print(f"No scan data found for: {repo}")
        print(f"  Run first: reachctl scan {repo}")
        return

    cfg = ReportConfig(
        repo_path=repo,
        enzo_db_path=enzo_db_path,
        repo_db_path=repo_db_path,
        org_name=getattr(args, "org", "Organisation"),
        model=getattr(args, "model", None) or "",
        scan_id=getattr(args, "scan_id", None),
        framework=getattr(args, "framework", None) or "",
        output_format=getattr(args, "output", "markdown"),
        output_path=getattr(args, "output_path", None),
        period_start=getattr(args, "period_start", None),
        period_end=getattr(args, "period_end", None),
    )

    # Accepted risks workflow
    if getattr(args, "accepted_risks", False):
        run_accepted_risk_workflow(cfg)
        return

    # Deep-dive
    if getattr(args, "finding", None):
        print(f"  Generating deep-dive: {args.finding}...")
        result = generate_deep_dive(cfg, args.finding)

    # Executive summary
    elif getattr(args, "executive", False):
        print("  Generating executive summary...")
        result = generate_executive_summary(cfg)

    # GRC compliance report
    elif cfg.framework:
        fw_name = cfg.framework_name
        print(f"  Generating {fw_name} compliance report...")
        result = generate_grc_report(cfg)

    # Full risk report
    else:
        print(f"  Generating risk report for {cfg.app_name}...")
        result = generate_risk_report(cfg)

    if result.success:
        print(f"\n  ✓ Report written: {result.report_path}")
        print(f"    DB hash:  SHA256:{result.db_hash[:32]}...")
        print(f"    Words:    {result.word_count}")
        print(f"    Manifest: {repo}/.reachable/report-manifests.jsonl")
    else:
        print(f"\n  ✗ Report failed: {result.error}")


def _cmd_selftest(args):
    """Quick sanity check (default) or full unit suite (--unit).

    Quick mode runs entirely inline — no test files needed, works from a wheel.
    --unit mode discovers enzo/tests/unit/ and requires a source checkout.
    """
    import os
    import sqlite3
    import sys
    import tempfile
    from pathlib import Path

    verbose = getattr(args, "verbose", False)
    run_unit = getattr(args, "unit", False)

    W = 55

    # ── Extended: run unit test suite from source ─────────────────────
    if run_unit:
        tests_dir = Path(__file__).parent / "tests" / "extended" / "unit"
        if not tests_dir.exists():
            print("❌  Unit tests not found — requires source checkout of reach-core.")
            print(f"   Expected: {tests_dir}")
            sys.exit(1)
        import unittest
        loader = unittest.TestLoader()
        suite = loader.discover(str(tests_dir), pattern="test_*.py")
        runner = unittest.TextTestRunner(verbosity=2 if verbose else 1)
        result = runner.run(suite)
        sys.exit(0 if result.wasSuccessful() else 1)

    # ── Quick mode: inline checks, no test files required ────────────
    passed = 0
    failed = []

    def check(label, fn):
        nonlocal passed
        try:
            fn()
            if verbose:
                print(f"  ✓  {label}")
            passed += 1
        except Exception as e:
            failed.append((label, str(e)))
            print(f"  ✗  {label}: {e}")

    print(f"\n  {'━'*W}")
    print("  ENZO SELFTEST")
    print(f"  {'━'*W}")

    # ── Imports ───────────────────────────────────────────────────────
    check("import enzo.models",
          lambda: __import__("enzo.models"))
    check("import enzo.pipeline",
          lambda: __import__("enzo.pipeline"))
    check("import enzo.gap",
          lambda: __import__("enzo.gap"))
    check("import enzo.metrics",
          lambda: __import__("enzo.metrics"))
    check("import enzo.benchmark",
          lambda: __import__("enzo.benchmark"))
    check("import enzo.reporter.report",
          lambda: __import__("enzo.reporter.report"))
    check("import enzo.reporter.frameworks",
          lambda: __import__("enzo.reporter.frameworks"))
    check("import enzo.patcher.deterministic",
          lambda: __import__("enzo.patcher.deterministic"))
    check("import enzo.patcher.cve_resolver",
          lambda: __import__("enzo.patcher.cve_resolver"))
    check("import enzo.ingest.models",
          lambda: __import__("enzo.ingest.models"))
    check("import enzo.knowledge",
          lambda: __import__("enzo.knowledge"))

    # ── Version ───────────────────────────────────────────────────────
    def _check_version():
        import enzo
        assert hasattr(enzo, "__version__"), "missing __version__"
        v = enzo.__version__
        assert v and v[0].isdigit(), f"unexpected version: {v!r}"
    check("__version__ set", _check_version)

    # ── Deterministic patcher: secret rotation ────────────────────────
    def _check_det_secret():
        from enzo.patcher.deterministic import try_deterministic
        content = 'API_KEY = "sk-prod-abc123"\n'
        r = try_deterministic(
            fix_type="secret_rotation",
            file_path="config.py",
            file_content=content,
            line_number=1,
            finding_metadata={"secret_type": "api_key",
                              "secret_value": "sk-prod-abc123"},
        )
        assert r.success, f"secret_rotation failed: {r.error}"
        assert "sk-prod-abc123" not in r.patched_content, "secret not removed"
    check("deterministic patcher: secret_rotation", _check_det_secret)

    # ── Deterministic patcher: dependency upgrade ────────────────────
    def _check_det_dep():
        from enzo.patcher.deterministic import try_deterministic
        r = try_deterministic(
            fix_type="dependency_upgrade",
            file_path="requirements.txt",
            file_content="requests==2.28.0\n",
            line_number=1,
            finding_metadata={"package_name": "requests",
                              "current_version": "2.28.0",
                              "fix_version": "2.32.3"},
        )
        assert r.success, f"dependency_upgrade failed: {r.error}"
        assert "2.32.3" in r.patched_content
    check("deterministic patcher: dependency_upgrade", _check_det_dep)

    # ── Hallucination detector ────────────────────────────────────────
    def _check_hallucination():
        from enzo.patcher.engine import _validate_code_output
        ok, _ = _validate_code_output("def foo():\n    return 42\n",
                                      "def foo():\n    return 42\n", "python")
        assert ok, "valid python rejected"
        bad, reason = _validate_code_output(
            "Step 1: find the injection point\nStep 2: apply the fix",
            "def foo(): pass", "python",
        )
        assert not bad, f"prose accepted as code: {reason}"
    check("hallucination detector", _check_hallucination)

    # ── Gap analyser ─────────────────────────────────────────────────
    def _check_gap():
        from enzo.gap import REACHABLE, UNKNOWN, UNREACHABLE, _normalise_cwe, _severity_note
        assert _normalise_cwe("CWE-89") == "CWE-89"
        assert _normalise_cwe("89") == "CWE-89"
        assert _severity_note("CRITICAL", "CRITICAL", REACHABLE) != ""
        assert REACHABLE != UNREACHABLE
        assert UNKNOWN != REACHABLE
    check("gap analyser: normalise_cwe / severity_note / constants", _check_gap)

    # ── Metrics: collect from empty db ────────────────────────────────
    def _check_metrics():
        from enzo.metrics import MetricsSummary, collect
        fd, path = tempfile.mkstemp(suffix=".db")
        os.close(fd)
        try:
            con = sqlite3.connect(path)
            con.executescript("""
                CREATE TABLE IF NOT EXISTS remediation_attempts (
                    id INTEGER PRIMARY KEY, scan_id INTEGER DEFAULT 1,
                    finding_id TEXT, fix_type TEXT, status TEXT,
                    attempt_number INTEGER DEFAULT 1, attestation TEXT, created_at TEXT
                );
                CREATE TABLE IF NOT EXISTS benchmark_results (
                    id INTEGER PRIMARY KEY, run_id TEXT, fixture_id TEXT,
                    language TEXT, fix_type TEXT, success INTEGER
                );
            """)
            con.commit()
            con.close()
            m = collect(path, since_days=30)
            assert isinstance(m, MetricsSummary)
            assert m.attempted == 0
            assert m.fix_rate == 0.0
        finally:
            os.unlink(path)
    check("metrics: collect() on empty db", _check_metrics)

    # ── Metrics: format_metrics doesn't crash ─────────────────────────
    def _check_format_metrics():
        from enzo.metrics import MetricsSummary, format_metrics
        m = MetricsSummary(attempted=5, succeeded=4, failed=1,
                           runs=2, period_days=30, period_label="last 30 days",
                           ai_count=3, deterministic_count=1)
        out = format_metrics(m, repo_name="selftest-repo")
        assert "ENZO METRICS" in out
        assert "80.0%" in out
    check("metrics: format_metrics()", _check_format_metrics)

    # ── Benchmark schema ──────────────────────────────────────────────
    def _check_benchmark_schema():
        from enzo.benchmark import FIXTURES, BenchmarkRunner
        fd, path = tempfile.mkstemp(suffix=".db")
        os.close(fd)
        try:
            BenchmarkRunner("n/a", "groq", path)
            con = sqlite3.connect(path)
            tables = {r[0] for r in con.execute(
                "SELECT name FROM sqlite_master WHERE type='table'"
            ).fetchall()}
            con.close()
            assert "benchmark_runs" in tables
            assert "benchmark_results" in tables
            det = [f for f in FIXTURES if f.patcher == "deterministic"]
            assert len(det) >= 9, f"expected ≥9 deterministic fixtures, got {len(det)}"
        finally:
            os.unlink(path)
    check("benchmark: schema + fixture list", _check_benchmark_schema)

    # ── Reporter: frameworks ─────────────────────────────────────────
    def _check_frameworks():
        from enzo.reporter.frameworks import get_controls, resolve_framework
        fw = resolve_framework("soc2")
        assert "soc2" in fw.lower()
        controls = get_controls("soc2", "CWE-89")
        assert isinstance(controls, list)
    check("reporter: frameworks resolve + get_controls", _check_frameworks)

    # ── Reporter: ReportConfig ────────────────────────────────────────
    def _check_report_config():
        from enzo.reporter.report import ReportConfig
        cfg = ReportConfig(repo_path="/tmp/myapp",
                           enzo_db_path="/tmp/e.db",
                           repo_db_path="/tmp/r.db",
                           framework="soc2")
        assert cfg.app_name == "myapp"
        assert "SOC" in cfg.framework_name
    check("reporter: ReportConfig properties", _check_report_config)

    # ── CVE resolver ─────────────────────────────────────────────────
    def _check_cve_resolver():
        from enzo.patcher.cve_resolver import _greatest_lower_bound
        result = _greatest_lower_bound(["2.0", "3.0"], {">=": "2.0"}, "1.5")
        assert result is not None
    check("cve_resolver: _greatest_lower_bound", _check_cve_resolver)

    # ── Ingest: normaliser round-trip ────────────────────────────────
    def _check_ingest():
        from enzo.ingest.models import ExternalFinding
        f = ExternalFinding(
            tool="trivy", tool_finding_id="CVE-2023-1234",
            finding_type="cve", severity="CRITICAL",
            file_path="go.sum", line_number=0,
        )
        assert f.tool == "trivy"
        assert f.severity == "CRITICAL"
    check("ingest: ExternalFinding model", _check_ingest)

    # ── Summary ───────────────────────────────────────────────────────
    total = passed + len(failed)
    print(f"\n  {'━'*W}")
    if not failed:
        print(f"  ✓  All {total} checks passed")
    else:
        print(f"  {passed}/{total} checks passed  ·  {len(failed)} failed")
        for label, err in failed:
            print(f"     ✗ {label}: {err}")
    print(f"  {'━'*W}")

    if not verbose and not failed:
        print("  Tip: reachctl enzo selftest --unit   (full suite, source only)")
    print()
    sys.exit(0 if not failed else 1)


def _cmd_knowledge(args):
    from .knowledge import EnzoKnowledgeDB

    kb = EnzoKnowledgeDB()
    stats = kb.get_stats()

    print("\nEnzo Global Knowledge DB")
    print(f"  Path:             {stats['db_path']}")
    print(f"  Fix patterns:     {stats['fix_patterns']['local']} local, {stats['fix_patterns']['community']} community")
    print(f"  Upgrade intel:    {stats['upgrade_intel']}")
    print(f"  Build errors:     {stats['build_errors']}")
    print(f"  Model perf:       {stats['model_performance']}")
    print(f"  Strategy cache:   {stats['strategy_cache']}")
    if stats["best_pattern"]:
        bp = stats["best_pattern"]
        total = bp["success_count"] + bp["failure_count"]
        print(f"  Top pattern:      {bp['strategy']} ({bp['success_count']}/{total})")
    kb.close()


def _cmd_ingest(args):
    from .ingest import load_tool

    repo = str(Path(args.repo).resolve())

    kwargs = {}
    if getattr(args, "fmt", None):
        kwargs["fmt"] = args.fmt

    print(f"  Ingesting {args.tool} findings from {args.file}...")

    try:
        findings = load_tool(args.tool, args.file, **kwargs)
    except Exception as e:
        print(f"  ✗ Failed to load {args.file}: {e}")
        return

    if not findings:
        print("  No actionable findings found.")
        return

    # Save to .reachable/ingest/
    import datetime
    ingest_dir = Path(repo) / ".reachable" / "ingest"
    ingest_dir.mkdir(parents=True, exist_ok=True)

    ts = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    ext = Path(args.file).suffix or ".json"
    out_path = ingest_dir / f"{args.tool}-{ts}{ext}"
    # Copy raw file
    import shutil
    shutil.copy2(args.file, out_path)

    # Severity breakdown
    from collections import Counter
    sev_counts = Counter(f.severity for f in findings)

    print(f"  ✓ {len(findings)} findings loaded from {args.tool}")
    print("    Severity: " + "  ".join(f"{k}:{v}" for k,v in sorted(sev_counts.items())))
    print(f"    Saved:    {out_path}")
    print(f"\n  Next: reachctl enzo gap-analysis {args.repo}")


def _cmd_gap_analysis(args):

    from .gap import GapAnalyser
    from .ingest import load_tool
    from .query import get_repo_db_path

    repo = str(Path(args.repo).resolve())
    db_path = get_repo_db_path(repo)

    if not db_path.exists():
        print(f"No scan data for: {repo}")
        print(f"  Run first: reachctl scan {repo}")
        return

    # Load all ingested files from .reachable/ingest/
    ingest_dir = Path(repo) / ".reachable" / "ingest"
    tool_map = {
        "dependabot": "dependabot",
        "codeql":     "codeql",
        "semgrep":    "semgrep",
        "trivy":      "trivy",
        "osv":        "osv",
    }

    analyser = GapAnalyser(db_path=str(db_path))
    try:
        analyser.load_reachable_findings()
    except Exception as e:
        print(f"  ✗ Could not read repo.db: {e}")
        return

    ingest_count = 0
    if ingest_dir.exists():
        for fpath in sorted(ingest_dir.iterdir()):
            stem = fpath.stem  # e.g. "trivy-20260304_120000"
            for tool_key in tool_map:
                if stem.startswith(tool_key):
                    try:
                        findings = load_tool(tool_key, str(fpath))
                        analyser.add_external(findings)
                        ingest_count += len(findings)
                    except Exception as e:
                        print(f"  ⚠ Could not load {fpath.name}: {e}")
                    break

    if ingest_count == 0:
        print("  No ingested tool findings found.")
        print(f"  Run first: reachctl enzo ingest --tool <name> --file <path>  [{repo}]")
        return

    # Load enzo fix history
    try:
        import sqlite3 as _sql
        enzo_db = str(db_path).replace("repo.db", "enzo.db")
        if Path(enzo_db).exists():
            con = _sql.connect(enzo_db)
            rows = con.execute(
                "SELECT finding_id FROM remediation_attempts WHERE status='success'"
            ).fetchall()
            analyser.set_enzo_fixed([r[0] for r in rows])
            con.close()
    except Exception:
        pass

    report = analyser.analyse()
    md = report.to_markdown()

    output_path = getattr(args, "output", None)
    if output_path:
        Path(output_path).write_text(md)
        print(f"  ✓ Gap analysis written to {output_path}")
    else:
        print(md)


def _print_outcome(outcome, dry_run):
    status = {"success": "✓", "failed": "✗", "manual": "⚠"}.get(outcome.status.value, "?")
    mode = " (dry run)" if dry_run else ""
    print(f"\n{status} {outcome.finding_id[:12]} — {outcome.status.value}{mode}")
    if outcome.patch and outcome.patch.diff and dry_run:
        print(f"\nGenerated diff ({len(outcome.patch.diff)} bytes):")
        print(outcome.patch.diff[:2000])
    if outcome.error:
        print(f"  Error: {outcome.error}")
    if outcome.branch:
        print(f"  Branch: {outcome.branch}")
    if outcome.attestation:
        print(f"  Attestation: {json.dumps(outcome.attestation, indent=2)[:500]}")


# ═══════════════════════════════════════════════════════════════════════════
#  Integration hook for reachctl
# ═══════════════════════════════════════════════════════════════════════════

def register_enzo_subcommand(subparsers):
    """
    Call from cli/main.py to wire Enzo into reachctl:

        from enzo.cli import register_enzo_subcommand
        register_enzo_subcommand(subparsers)
    """
    p = subparsers.add_parser("enzo", help="AI-powered remediation engine")
    enzo_sub = p.add_subparsers(dest="enzo_command", metavar="COMMAND")
    _build_subparsers(enzo_sub)
    p.set_defaults(func=lambda args: p.print_help())


# ═══════════════════════════════════════════════════════════════════════════
#  Standalone entry
# ═══════════════════════════════════════════════════════════════════════════

def main():
    parser = argparse.ArgumentParser(
        prog="enzo",
        description="Enzo — AI Remediation Engine for REACHABLE",
    )
    parser.add_argument("-v", "--verbose", action="store_true")
    sub = parser.add_subparsers(dest="command", metavar="COMMAND")
    _build_subparsers(sub)

    args = parser.parse_args()
    if getattr(args, "verbose", False) or getattr(args, "debug", False):
        logging.basicConfig(level=logging.DEBUG, format="%(name)s %(levelname)s %(message)s")
    else:
        logging.basicConfig(level=logging.INFO, format="%(message)s")

    if not args.command:
        parser.print_help()
        sys.exit(1)

    args.func(args)
