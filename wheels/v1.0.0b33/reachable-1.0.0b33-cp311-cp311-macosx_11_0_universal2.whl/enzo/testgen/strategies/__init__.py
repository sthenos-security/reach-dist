#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.
"""
Strategy registry — maps CWE IDs to test generation strategies.

Each strategy knows:
  - What mock to inject (DB cursor, subprocess, HTTP client, filesystem)
  - What assertions prove the fix is effective
  - How to generate the complete test file content

Usage:
    strategy = get_strategy("CWE-089")
    test_path, content = strategy.generate_test(func_info, finding_id, repo_path)
"""
from __future__ import annotations

from typing import Dict, Optional

from .base import Strategy
from .injection import CmdInjectionStrategy, CodeInjectionStrategy
from .sqli import SQLiStrategy
from .traversal import PathTraversalStrategy
from .web import OpenRedirectStrategy, SSRFStrategy, XSSStrategy

# Registry: normalized CWE → strategy instance
_REGISTRY: Dict[str, Strategy] = {
    "CWE-022": PathTraversalStrategy(),
    "CWE-078": CmdInjectionStrategy(),
    "CWE-079": XSSStrategy(),
    "CWE-089": SQLiStrategy(),
    "CWE-094": CodeInjectionStrategy(),
    "CWE-601": OpenRedirectStrategy(),
    "CWE-918": SSRFStrategy(),
}


def get_strategy(cwe_id: str) -> Optional[Strategy]:
    """
    Return the strategy for a CWE ID, or None if not supported.
    Normalizes CWE-022, CWE-22 → CWE-022.
    """
    if not cwe_id:
        return None
    normalized = cwe_id.upper().strip()
    if normalized.startswith("CWE-"):
        num = normalized[4:].lstrip("0") or "0"
        normalized = f"CWE-{num.zfill(3)}"
    return _REGISTRY.get(normalized)


def list_supported() -> list:
    return sorted(_REGISTRY.keys())
