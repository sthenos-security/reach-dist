# Copyright © 2026 Sthenos Security. All rights reserved.
"""
Enzo TestGen — exploit proof via generated tests.

Entry points:
    prove_fix(finding, repo_path)           → post-patch only (validator use)
    prove_finding(finding, repo_path, diff) → full before/after proof (CLI use)
"""
from .engine import TestGenResult, prove_finding, prove_fix

__all__ = ["TestGenResult", "prove_fix", "prove_finding"]
