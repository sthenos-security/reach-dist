#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.
"""
Enzo setup — detect resources, select model, pull via Ollama, configure.

Usage:
    reachctl enzo setup                 # auto-detect + recommend + pull
    reachctl enzo setup --list          # show model tiers vs system resources
    reachctl enzo setup --model X       # explicit model choice
    reachctl enzo setup --check         # verify current setup health
    reachctl enzo setup --gpu           # prefer GPU-optimized tiers
"""

from __future__ import annotations

import json
import logging
import os
import platform
import shutil
import sys
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Tuple

logger = logging.getLogger(__name__)

try:
    import urllib.error
    import urllib.request
except ImportError:
    pass

try:
    import yaml as _yaml  # type: ignore
    _HAS_YAML = True
except ImportError:
    _HAS_YAML = False


# ═══════════════════════════════════════════════════════════════════════════
#  Credential helpers
# ═══════════════════════════════════════════════════════════════════════════

def _get_anthropic_key() -> str:
    """
    Return the Anthropic API key, checking (in order):
      1. ANTHROPIC_API_KEY environment variable
      2. macOS Keychain / Linux encrypted credential store
         via reachable.core.credentials (same source as reachctl doctor)

    Returns empty string if not found.
    """
    key = os.environ.get("ANTHROPIC_API_KEY", "")
    if key:
        return key
    try:
        from reachable.core.credentials import get_credential
        key = get_credential("anthropic-api-key") or ""
    except Exception:
        pass
    return key


# ═══════════════════════════════════════════════════════════════════════════
#  Paths
# ═══════════════════════════════════════════════════════════════════════════

# Store Ollama models inside .reachable so all tooling is self-contained.

# ═══════════════════════════════════════════════════════════════════════════
#  Model Registry
# ═══════════════════════════════════════════════════════════════════════════

# ═══════════════════════════════════════════════════════════════════════════
#  Groq Cloud
# ═══════════════════════════════════════════════════════════════════════════

GROQ_ENDPOINT = "https://api.groq.com/openai"
GROQ_RECOMMENDED_MODEL = "qwen-2.5-coder-32b"
GROQ_FALLBACK_MODEL    = "llama-3.3-70b-versatile"


def _get_groq_key() -> str:
    """Return Groq API key from env or keychain."""
    key = os.environ.get("GROQ_API_KEY", "")
    if key:
        return key
    try:
        from reachable.core.credentials import get_credential
        return get_credential("groq-api-key") or ""
    except Exception:
        return ""


def check_groq() -> tuple:
    """Return (configured: bool, key_source: str)."""
    key = _get_groq_key()
    if not key:
        return False, ""
    source = "env" if os.environ.get("GROQ_API_KEY") else "keychain"
    return True, source


def verify_groq_key(key: str) -> tuple:
    """
    Verify a Groq API key is valid by hitting /openai/v1/models.
    Returns (valid: bool, error: str).
    """
    try:
        req = urllib.request.Request(
            f"{GROQ_ENDPOINT}/v1/models",
            headers={"Authorization": f"Bearer {key}"},
        )
        with urllib.request.urlopen(req, timeout=10) as resp:
            data = json.loads(resp.read())
            models = [m["id"] for m in data.get("data", [])]
            return True, f"{len(models)} models available"
    except urllib.error.HTTPError as exc:
        if exc.code == 401:
            return False, "Invalid API key (HTTP 401)"
        return False, f"HTTP {exc.code}"
    except Exception as exc:
        return False, str(exc)


def store_groq_key(key: str) -> tuple:
    """
    Store a Groq API key in the system keychain.
    Returns (success: bool, message: str).
    """
    try:
        from reachable.core.credentials import set_credential
        set_credential("groq-api-key", key)
        return True, "Stored in keychain"
    except ImportError:
        return False, "Keychain unavailable — set GROQ_API_KEY env var instead"
    except Exception as exc:
        return False, str(exc)


@dataclass
class ModelTier:
    """A model tier with resource requirements and capabilities."""
    name: str                       # human-readable tier name
    ollama_tag: str                 # tag for `ollama pull`
    disk_gb: float                  # approximate download size
    ram_gb: float                   # minimum RAM for inference
    quality: str                    # flagship | standard | compact | minimal
    description: str
    best_for: List[str]             # fix types this excels at
    languages: List[str] = field(default_factory=lambda: ["python", "javascript", "go", "java"])
    gpu_recommended: bool = False
    code_patch_capable: bool = True  # can handle CWE/SAST code fixes

    @property
    def ram_bytes(self) -> int:
        return int(self.ram_gb * 1024**3)

    @property
    def disk_bytes(self) -> int:
        return int(self.disk_gb * 1024**3)


# Ordered by quality descending — selection logic walks top-down
MODEL_TIERS: List[ModelTier] = [
    ModelTier(
        name="Flagship",
        ollama_tag="qwen2.5-coder:32b",
        disk_gb=18.0, ram_gb=24.0,
        quality="flagship",
        description="Best open-source code model. Handles complex CWE patches, "
                    "multi-file changes, nuanced security fixes.",
        best_for=["dependency_upgrade", "code_patch", "config_change", "secret_rotation"],
        gpu_recommended=True,
    ),
    ModelTier(
        name="Standard",
        ollama_tag="qwen2.5-coder:14b",
        disk_gb=8.5, ram_gb=12.0,
        quality="standard",
        description="Good balance of quality and resource usage. Handles most "
                    "remediation tasks well including code patches.",
        best_for=["dependency_upgrade", "code_patch", "config_change", "secret_rotation"],
    ),
    ModelTier(
        name="Compact",
        ollama_tag="qwen2.5-coder:7b",
        disk_gb=4.5, ram_gb=8.0,
        quality="compact",
        description="Fits on most developer laptops. Good for dependency upgrades "
                    "and config fixes. Adequate for simpler code patches.",
        best_for=["dependency_upgrade", "config_change", "secret_rotation", "code_patch"],
    ),
    ModelTier(
        name="Minimal",
        ollama_tag="qwen2.5-coder:1.5b",
        disk_gb=1.0, ram_gb=4.0,
        quality="minimal",
        description="Ultra-light. Best for dependency upgrades only — version bumps "
                    "are mostly deterministic and don't need a large model.",
        best_for=["dependency_upgrade", "config_change"],
        code_patch_capable=False,
    ),
]

# Lookup by tag
_TIER_BY_TAG = {t.ollama_tag: t for t in MODEL_TIERS}


# ═══════════════════════════════════════════════════════════════════════════
#  System Resource Detection  (delegated to reachable.core.sysinfo)
# ═══════════════════════════════════════════════════════════════════════════

from reachable.core.sysinfo import (  # noqa: E402
    SystemResources,
    _check_ollama_status,
    detect_resources,
    format_ollama_status,
    format_resources,
)


def _check_ollama_installed() -> bool:
    """Check if ollama binary is on PATH."""
    return shutil.which("ollama") is not None


def ensure_ollama_running(endpoint: str = "http://localhost:11434") -> tuple:
    """
    Check Ollama is installed and running. Auto-starts if possible.
    Returns (ok: bool, message: str).
    """
    if not _check_ollama_installed():
        _is_mac = platform.system() == "Darwin"
        if _is_mac:
            return False, (
                "Ollama is not installed. Install it:\n"
                "  brew install ollama\n"
                f"Expected at: {endpoint}"
            )
        else:
            return False, (
                "Ollama is not installed. Install it:\n"
                "  curl -fsSL https://ollama.com/install.sh | sh\n"
                f"Expected at: {endpoint}"
            )

    running, _ = _check_ollama_status(endpoint)
    if running:
        return True, "Ollama is running"

    # Try to start it automatically
    print("Ollama is installed but not running. Starting...")
    try:
        import subprocess
        subprocess.Popen(
            ["ollama", "serve"],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            start_new_session=True,
        )
        for _ in range(20):
            time.sleep(0.5)
            running, _ = _check_ollama_status(endpoint)
            if running:
                print("✓ Ollama started")
                _is_mac = platform.system() == "Darwin"
                if _is_mac:
                    print("  For persistent service: brew services start ollama")
                else:
                    print("  For persistent service: sudo systemctl enable --now ollama")
                return True, "Ollama started"
    except Exception as exc:
        logger.debug("Could not auto-start Ollama: %s", exc)

    _is_mac = platform.system() == "Darwin"
    if _is_mac:
        return False, (
            "Ollama could not be started. Try:\n"
            "  brew services start ollama\n"
            f"Expected at: {endpoint}"
        )
    else:
        return False, (
            "Ollama could not be started. Try:\n"
            "  sudo systemctl start ollama\n"
            f"Expected at: {endpoint}"
        )


# ═══════════════════════════════════════════════════════════════════════════
#  Model Selection
# ═══════════════════════════════════════════════════════════════════════════

@dataclass
class ModelRecommendation:
    """Result of model selection."""
    tier: ModelTier
    fits: bool                      # True if system has enough resources
    reason: str                     # why this was selected / why it doesn't fit
    already_pulled: bool = False    # already available in Ollama
    ram_headroom_gb: float = 0.0    # available_ram - required
    disk_headroom_gb: float = 0.0   # disk_free - download_size


def select_model(
    resources: SystemResources,
    prefer_gpu: bool = False,
    max_ram_fraction: float = 0.75,  # don't recommend if model needs >75% of total RAM
    endpoint: str = "http://localhost:11434",
) -> ModelRecommendation:
    """
    Select the best model tier that fits the system.

    Walks tiers from best to worst, returns first that fits.
    """
    # Apple Silicon: Ollama uses Metal over unified memory (= total RAM).
    # Other systems: cap at available * 0.85 to avoid OOM from memory pressure.
    if getattr(resources, "metal_available", False) and getattr(resources, "gpu_vram_gb", 0) > 0:
        usable_ram = resources.gpu_vram_gb * max_ram_fraction
    else:
        usable_ram = min(
            resources.total_ram_gb * max_ram_fraction,
            resources.available_ram_gb * 0.85,
        )
    for tier in MODEL_TIERS:
        ram_ok = tier.ram_gb <= usable_ram
        disk_ok = tier.disk_gb <= resources.disk_free_gb
        already = tier.ollama_tag in resources.ollama_models

        if ram_ok and (disk_ok or already):
            reason = f"{tier.name} tier fits: {tier.ram_gb}GB RAM needed, "
            reason += f"{resources.total_ram_gb}GB total ({resources.available_ram_gb}GB free). "
            if already:
                reason += "Already pulled."
            else:
                reason += f"{tier.disk_gb}GB download, {resources.disk_free_gb}GB free disk."
            return ModelRecommendation(
                tier=tier, fits=True, reason=reason,
                already_pulled=already,
                ram_headroom_gb=round(usable_ram - tier.ram_gb, 1),
                disk_headroom_gb=round(resources.disk_free_gb - tier.disk_gb, 1),
            )

    # Nothing fits — recommend minimal with a warning
    minimal = MODEL_TIERS[-1]
    return ModelRecommendation(
        tier=minimal, fits=False,
        reason=f"System resources very limited ({resources.total_ram_gb}GB RAM, "
               f"{resources.disk_free_gb}GB disk). Even {minimal.name} tier "
               f"({minimal.ram_gb}GB RAM, {minimal.disk_gb}GB disk) may struggle. "
               f"Consider using cloud-only mode.",
    )


def get_all_recommendations(
    resources: SystemResources,
    endpoint: str = "http://localhost:11434",
) -> List[ModelRecommendation]:
    """Evaluate all tiers against system resources (for --list)."""
    if getattr(resources, "metal_available", False) and getattr(resources, "gpu_vram_gb", 0) > 0:
        usable_ram = resources.gpu_vram_gb * 0.75
    else:
        usable_ram = min(resources.total_ram_gb * 0.75, resources.available_ram_gb * 0.85)
    results = []
    for tier in MODEL_TIERS:
        ram_ok = tier.ram_gb <= usable_ram
        disk_ok = tier.disk_gb <= resources.disk_free_gb
        already = tier.ollama_tag in resources.ollama_models
        fits = ram_ok and (disk_ok or already)

        if not ram_ok:
            reason = (
                f"Needs {tier.ram_gb:.0f}GB RAM, "
                f"only {usable_ram:.0f}GB available "
                f"({resources.available_ram_gb:.0f}GB free)"
            )
        elif not disk_ok and not already:
            reason = f"Needs {tier.disk_gb}GB disk, only {resources.disk_free_gb}GB free"
        elif already:
            reason = "Already pulled ✓"
        else:
            reason = "Fits ✓"

        results.append(ModelRecommendation(
            tier=tier, fits=fits, reason=reason,
            already_pulled=already,
            ram_headroom_gb=round(usable_ram - tier.ram_gb, 1),
            disk_headroom_gb=round(resources.disk_free_gb - tier.disk_gb, 1),
        ))
    return results





class OllamaModelManager:
    """
    Manage Ollama models through the REST API.

    Uses the same API endpoints as the Ollama CLI:
      /api/tags    — list downloaded models
      /api/pull    — download a model (streaming progress)
      /api/show    — model details (parameters, quantization, etc.)
      /api/ps      — models currently loaded in memory
      /api/delete  — remove a model

    Models stay in ~/.ollama/models (default Ollama location).
    No env var manipulation or filesystem hacks.
    """

    def __init__(self, endpoint: str = "http://localhost:11434"):
        self.endpoint = endpoint.rstrip("/")

    # ── Query ─────────────────────────────────────────────────────────

    def list_models(self) -> List[Dict]:
        """Return all locally downloaded models with size/digest/details."""
        try:
            req = urllib.request.Request(f"{self.endpoint}/api/tags")
            with urllib.request.urlopen(req, timeout=10) as resp:
                return json.loads(resp.read()).get("models", [])
        except Exception as exc:
            logger.debug("list_models failed: %s", exc)
            return []

    def has_model(self, tag: str) -> bool:
        """True if the model is already downloaded locally."""
        # Normalise — "qwen2.5-coder:14b" and "qwen2.5-coder" should both match
        tag_base = tag.split(":")[0]
        for m in self.list_models():
            name = m.get("name", "")
            if name == tag or name.startswith(tag_base + ":"):
                return True
        return False

    def running_models(self) -> List[Dict]:
        """Return models currently loaded in GPU/CPU memory."""
        try:
            req = urllib.request.Request(f"{self.endpoint}/api/ps")
            with urllib.request.urlopen(req, timeout=10) as resp:
                return json.loads(resp.read()).get("models", [])
        except Exception as exc:
            logger.debug("running_models failed: %s", exc)
            return []

    def model_info(self, tag: str) -> Dict:
        """
        Return detailed info for a model: architecture, parameters,
        quantization, context length, etc.
        """
        payload = json.dumps({"name": tag}).encode()
        try:
            req = urllib.request.Request(
                f"{self.endpoint}/api/show", data=payload,
                headers={"Content-Type": "application/json"}, method="POST",
            )
            with urllib.request.urlopen(req, timeout=10) as resp:
                return json.loads(resp.read())
        except Exception as exc:
            logger.debug("model_info failed: %s", exc)
            return {}

    def total_disk_gb(self) -> float:
        """Total disk used by all downloaded models in GB."""
        return sum(m.get("size", 0) for m in self.list_models()) / 1e9

    # ── Lifecycle ─────────────────────────────────────────────────────

    def pull(
        self,
        tag: str,
        progress_callback: Optional[Callable[[str, float], None]] = None,
    ) -> Tuple[bool, str]:
        """
        Download a model from the Ollama registry with streaming progress.

        Args:
            tag: Model tag e.g. "qwen2.5-coder:14b"
            progress_callback: Called with (status_msg, pct_complete 0-100)

        Returns: (success, message)
        """
        payload = json.dumps({"name": tag, "stream": True}).encode()
        try:
            req = urllib.request.Request(
                f"{self.endpoint}/api/pull", data=payload,
                headers={"Content-Type": "application/json"}, method="POST",
            )
            with urllib.request.urlopen(req, timeout=3600) as resp:
                buf = b""
                last_pct = -1
                for chunk in iter(lambda: resp.read(4096), b""):
                    buf += chunk
                    while b"\n" in buf:
                        line, buf = buf.split(b"\n", 1)
                        if not line.strip():
                            continue
                        try:
                            data = json.loads(line)
                        except json.JSONDecodeError:
                            continue
                        if data.get("error"):
                            return False, data["error"]
                        status = data.get("status", "")
                        total = data.get("total", 0)
                        completed = data.get("completed", 0)
                        pct = (completed / total * 100) if total > 0 else 0
                        if progress_callback and int(pct) != last_pct:
                            progress_callback(status, pct)
                            last_pct = int(pct)
            return True, f"Pulled {tag}"
        except urllib.error.URLError as exc:
            return False, f"Pull failed: {exc.reason}"
        except Exception as exc:
            return False, f"Pull failed: {exc}"

    def delete(self, tag: str) -> Tuple[bool, str]:
        """Remove a model from local storage."""
        payload = json.dumps({"name": tag}).encode()
        try:
            req = urllib.request.Request(
                f"{self.endpoint}/api/delete", data=payload,
                headers={"Content-Type": "application/json"}, method="DELETE",
            )
            urllib.request.urlopen(req, timeout=30)
            return True, f"Deleted {tag}"
        except Exception as exc:
            return False, f"Delete failed: {exc}"

    def unload(self, tag: str) -> bool:
        """Unload a model from memory (keep_alive=0 trick)."""
        payload = json.dumps({"model": tag, "prompt": "", "keep_alive": 0}).encode()
        try:
            req = urllib.request.Request(
                f"{self.endpoint}/api/generate", data=payload,
                headers={"Content-Type": "application/json"}, method="POST",
            )
            urllib.request.urlopen(req, timeout=30)
            return True
        except Exception:
            return False


def pull_model(
    tag: str,
    endpoint: str = "http://localhost:11434",
    progress_callback: Optional[Callable[[str, float], None]] = None,
) -> Tuple[bool, str]:
    """
    Pull a model via Ollama API (streaming progress).

    Args:
        tag: Model tag (e.g. "qwen2.5-coder:14b")
        endpoint: Ollama API URL
        progress_callback: Called with (status_msg, percent_complete)

    Returns: (success, message)
    """
    url = f"{endpoint}/api/pull"
    payload = json.dumps({"name": tag, "stream": True}).encode("utf-8")

    try:
        req = urllib.request.Request(
            url, data=payload,
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        with urllib.request.urlopen(req, timeout=3600) as resp:
            buffer = b""
            last_pct = -1
            for chunk in iter(lambda: resp.read(4096), b""):
                buffer += chunk
                while b"\n" in buffer:
                    line, buffer = buffer.split(b"\n", 1)
                    if not line.strip():
                        continue
                    try:
                        data = json.loads(line)
                    except json.JSONDecodeError:
                        continue

                    status = data.get("status", "")
                    total = data.get("total", 0)
                    completed = data.get("completed", 0)
                    pct = (completed / total * 100) if total > 0 else 0

                    if progress_callback and int(pct) != last_pct:
                        progress_callback(status, pct)
                        last_pct = int(pct)

                    if data.get("error"):
                        return False, data["error"]

        return True, f"Successfully pulled {tag}"

    except urllib.error.URLError as exc:
        return False, f"Pull failed: {exc.reason}"
    except Exception as exc:
        return False, f"Pull failed: {exc}"


def verify_model(
    tag: str,
    endpoint: str = "http://localhost:11434",
) -> Tuple[bool, str, float]:
    """
    Quick inference test to verify model loads and responds.

    Returns: (success, response_text, latency_ms)
    """
    url = f"{endpoint}/api/generate"
    payload = json.dumps({
        "model": tag,
        "prompt": "Respond with exactly: ENZO_OK",
        "stream": False,
        "options": {"temperature": 0, "num_predict": 20},
    }).encode("utf-8")

    start = time.time()
    try:
        req = urllib.request.Request(
            url, data=payload,
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        with urllib.request.urlopen(req, timeout=120) as resp:
            data = json.loads(resp.read())
            text = data.get("response", "").strip()
            latency = (time.time() - start) * 1000
            if "ENZO_OK" in text or "OK" in text.upper():
                return True, text, latency
            else:
                # Model responded but not as expected — still working
                return True, text, latency
    except Exception as exc:
        latency = (time.time() - start) * 1000
        return False, str(exc), latency


# ═══════════════════════════════════════════════════════════════════════════
#  Config Persistence
# ═══════════════════════════════════════════════════════════════════════════

_GLOBAL_CONFIG_PATH = Path.home() / ".reachable" / "enzo" / "config.yml"


def save_global_config(model_tag: str, endpoint: str = "http://localhost:11434"):
    """Save model selection to global config (~/.reachable/enzo/config.yml)."""
    _GLOBAL_CONFIG_PATH.parent.mkdir(parents=True, exist_ok=True)
    config = {}
    if _GLOBAL_CONFIG_PATH.exists() and _HAS_YAML:
        try:
            with open(_GLOBAL_CONFIG_PATH) as f:
                config = _yaml.safe_load(f) or {}
        except Exception:
            config = {}

    config["local_model"] = model_tag
    config["local_endpoint"] = endpoint
    config["configured_at"] = time.strftime("%Y-%m-%dT%H:%M:%S")

    if _HAS_YAML:
        with open(_GLOBAL_CONFIG_PATH, "w") as f:
            _yaml.dump(config, f, default_flow_style=False)
    else:
        with open(_GLOBAL_CONFIG_PATH, "w") as f:
            json.dump(config, f, indent=2)

    return _GLOBAL_CONFIG_PATH


def save_repo_config(repo_path: str, model_tag: str, endpoint: str = "http://localhost:11434"):
    """Save model selection to repo .reachable.yml enzo section."""
    yml_path = Path(repo_path) / ".reachable.yml"
    config = {}
    if yml_path.exists() and _HAS_YAML:
        try:
            with open(yml_path) as f:
                config = _yaml.safe_load(f) or {}
        except Exception:
            config = {}

    if "enzo" not in config:
        config["enzo"] = {}
    config["enzo"]["local_model"] = model_tag
    config["enzo"]["local_endpoint"] = endpoint

    if _HAS_YAML:
        with open(yml_path, "w") as f:
            _yaml.dump(config, f, default_flow_style=False)
    return yml_path


def load_global_config() -> Dict[str, Any]:
    """Load global config, returns {} if not found."""
    if not _GLOBAL_CONFIG_PATH.exists():
        return {}
    try:
        if _HAS_YAML:
            with open(_GLOBAL_CONFIG_PATH) as f:
                return _yaml.safe_load(f) or {}
        else:
            with open(_GLOBAL_CONFIG_PATH) as f:
                return json.load(f)
    except Exception:
        return {}


# ═══════════════════════════════════════════════════════════════════════════
#  Health Check
# ═══════════════════════════════════════════════════════════════════════════

@dataclass
class HealthReport:
    """Result of setup health check."""
    ollama_installed: bool = False
    ollama_running: bool = False
    model_configured: bool = False
    model_tag: str = ""
    model_pulled: bool = False
    model_responsive: bool = False
    inference_latency_ms: float = 0.0
    cloud_configured: bool = False
    groq_configured: bool = False
    groq_key_source: str = ""
    issues: List[str] = field(default_factory=list)

    @property
    def healthy(self) -> bool:
        return self.ollama_running and self.model_pulled and self.model_responsive


def check_health(endpoint: str = "http://localhost:11434") -> HealthReport:
    """Full health check of Enzo setup."""
    report = HealthReport()

    # Ollama
    report.ollama_installed = _check_ollama_installed()
    if not report.ollama_installed:
        report.issues.append("Ollama not installed")
        return report

    report.ollama_running, models = _check_ollama_status(endpoint)
    if not report.ollama_running:
        report.issues.append("Ollama not running")
        return report

    # Config
    config = load_global_config()
    report.model_tag = config.get("local_model", "")
    report.model_configured = bool(report.model_tag)
    if not report.model_configured:
        report.issues.append("No model configured (run: enzo setup)")
        return report

    # Model pulled
    report.model_pulled = report.model_tag in models
    if not report.model_pulled:
        report.issues.append(f"Model {report.model_tag} not pulled")
        return report

    # Inference test
    ok, text, latency = verify_model(report.model_tag, endpoint)
    report.model_responsive = ok
    report.inference_latency_ms = latency
    if not ok:
        report.issues.append(f"Model not responding: {text}")

    # Cloud (Anthropic)
    report.cloud_configured = bool(_get_anthropic_key())

    # Groq
    report.groq_configured, report.groq_key_source = check_groq()

    return report


# ═══════════════════════════════════════════════════════════════════════════
#  CLI-facing setup flow
# ═══════════════════════════════════════════════════════════════════════════

def run_setup(
    model_override: Optional[str] = None,
    prefer_gpu: bool = False,
    list_only: bool = False,
    check_only: bool = False,
    repo_path: Optional[str] = None,
    endpoint: str = "http://localhost:11434",
    interactive: bool = True,
) -> Dict[str, Any]:
    """
    Main setup entry point.

    Returns dict with results for programmatic use.
    """
    result: Dict[str, Any] = {"success": False}

    # ── Check mode ────────────────────────────────────────────────────
    if check_only:
        report = check_health(endpoint)
        result["health"] = report
        result["success"] = report.healthy
        _print_health(report)
        return result

    # ── Detect resources ──────────────────────────────────────────────
    print("Detecting system resources...")
    resources = detect_resources(endpoint)
    _print_resources(resources)
    result["resources"] = resources

    # ── List mode ─────────────────────────────────────────────────────
    if list_only:
        recs = get_all_recommendations(resources)
        _print_tier_list(recs)
        result["recommendations"] = recs
        result["success"] = True
        return result

    # ── Ensure Ollama ─────────────────────────────────────────────────
    ok, msg = ensure_ollama_running(endpoint)
    if not ok:
        print(f"\n{msg}")
        result["error"] = msg
        return result

    # ── Select model ──────────────────────────────────────────────────
    if model_override:
        tier = _TIER_BY_TAG.get(model_override)
        if tier:
            rec = ModelRecommendation(
                tier=tier, fits=True, reason="Explicitly selected",
                already_pulled=OllamaModelManager(endpoint).has_model(model_override),
            )
        else:
            # Custom model not in registry — create ad-hoc tier
            rec = ModelRecommendation(
                tier=ModelTier(
                    name="Custom", ollama_tag=model_override,
                    disk_gb=0, ram_gb=0, quality="custom",
                    description="User-specified model",
                    best_for=["dependency_upgrade", "code_patch", "config_change", "secret_rotation"],
                ),
                fits=True, reason="User-specified model",
                already_pulled=OllamaModelManager(endpoint).has_model(model_override),
            )
    else:
        rec = select_model(resources, prefer_gpu=prefer_gpu)

    tag = rec.tier.ollama_tag
    print(f"\nSelected: {rec.tier.name} — {tag}")
    print(f"  {rec.reason}")

    if not rec.fits:
        print("\n⚠ WARNING: This model may not fit your system resources.")
        if interactive:
            confirm = input("Continue anyway? [y/N] ").strip().lower()
            if confirm != "y":
                result["error"] = "Aborted by user"
                return result

    result["selected_model"] = tag
    result["tier"] = rec.tier.name

    # ── Pull model ────────────────────────────────────────────────────
    if rec.already_pulled:
        print(f"\n✓ {tag} already pulled")
    else:
        # Warn if disk headroom is tight after download
        if rec.disk_headroom_gb < 2.0 and not rec.already_pulled:
            print(f"\n  ⚠ Low disk: {resources.disk_free_gb:.1f}GB free, "
                  f"{rec.tier.disk_gb}GB needed for download")
            print("  Models are stored in ~/.ollama/models by default.")
            if interactive:
                    confirm = input("\n  Continue with internal disk? [y/N] ").strip().lower()
                    if confirm != "y":
                        result["error"] = "Aborted — set OLLAMA_MODELS and retry"
                        return result

        print(f"\nPulling {tag} (~{rec.tier.disk_gb}GB)...")

        def _progress(status: str, pct: float):
            bar_len = 30
            filled = int(bar_len * pct / 100)
            bar = "█" * filled + "░" * (bar_len - filled)
            sys.stdout.write(f"\r  {bar} {pct:5.1f}%  {status[:40]:<40}")
            sys.stdout.flush()

        ok, msg = OllamaModelManager(endpoint).pull(tag, progress_callback=_progress)
        print()  # newline after progress bar
        if not ok:
            print(f"\n✗ Pull failed: {msg}")
            result["error"] = msg
            return result
        print(f"✓ Pulled {tag}")

    # ── Verify ────────────────────────────────────────────────────────
    print("\nVerifying model loads correctly...")
    ok, text, latency = verify_model(tag, endpoint)
    if ok:
        print(f"✓ Model responsive ({latency:.0f}ms first-token latency)")
    else:
        print(f"⚠ Verification inconclusive: {text[:100]}")
        print("  Model may still work — first load can be slow.")

    result["verified"] = ok
    result["latency_ms"] = latency

    # ── Persist config ────────────────────────────────────────────────
    global_path = save_global_config(tag, endpoint)
    print(f"\n✓ Saved to {global_path}")

    if repo_path:
        repo_yml = save_repo_config(repo_path, tag, endpoint)
        print(f"✓ Saved to {repo_yml}")

    # ── Summary ───────────────────────────────────────────────────────
    print(f"\n{'─' * 50}")
    print("Enzo is ready.")
    print(f"  Model:    {tag}")
    print(f"  Endpoint: {endpoint}")
    if not rec.tier.code_patch_capable:
        print(f"  Note:     {rec.tier.name} tier is best for dependency upgrades.")
        print("            For code patches (CWE), consider upgrading or enabling cloud mode.")
    _api_key = _get_anthropic_key()
    if _api_key:
        _key_source = "env" if os.environ.get("ANTHROPIC_API_KEY") else "keychain"
        print(f"  Anthropic: ✓ API key ({_key_source}) — --mode cloud/both available")
    else:
        print("  Anthropic: — not configured (set ANTHROPIC_API_KEY or store in keychain)")
    _groq_key = _get_groq_key()
    if _groq_key:
        _groq_src = "env" if os.environ.get("GROQ_API_KEY") else "keychain"
        print(f"  Groq:      ✓ API key ({_groq_src}) — --mode cloud --provider groq available")
    else:
        print("  Groq:      — not configured (set GROQ_API_KEY or: reachctl auth login)")
    print(f"{'─' * 50}")

    result["success"] = True
    return result


# ═══════════════════════════════════════════════════════════════════════════
#  Print helpers
# ═══════════════════════════════════════════════════════════════════════════

def _print_resources(res: SystemResources):
    print()
    print(format_resources(res))
    print(format_ollama_status(res))
    if res.ollama_models:
        print(f"  Models:  {', '.join(res.ollama_models[:5])}")


def _print_tier_list(recs: List[ModelRecommendation]):
    print(f"\n{'─' * 70}")
    print(f"{'Tier':<12} {'Model':<25} {'RAM':<8} {'Disk':<8} {'Status'}")
    print(f"{'─' * 70}")
    for r in recs:
        tag = r.tier.ollama_tag
        fits = "✓" if r.fits else "✗"
        status = r.reason
        if r.already_pulled:
            fits = "●"
        print(f"{fits} {r.tier.name:<10} {tag:<25} {r.tier.ram_gb:>5.0f}GB  {r.tier.disk_gb:>5.1f}GB  {status}")
    print(f"{'─' * 70}")
    print("  ● = already pulled   ✓ = fits system   ✗ = insufficient resources")


# ═══════════════════════════════════════════════════════════════════════════
#  Build Tool Check
# ═══════════════════════════════════════════════════════════════════════════

# (binary, brew_formula, apt_pkg, description)
_ENZO_BUILD_TOOLS = [
    ("mvn",      "maven",       "maven",        "Java/Maven"),
    ("gradle",   "gradle",      "gradle",        "Java/Gradle"),
    ("go",       "go",          "golang-go",     "Go"),
    ("cargo",    "rust",        "cargo",         "Rust"),
    ("node",     "node",        "nodejs",        "Node.js"),
    ("bundle",   "ruby",        "ruby-bundler",  "Ruby/Bundler"),
    ("composer", "composer",    "composer",      "PHP/Composer"),
]


def check_build_tools() -> list:
    """
    Return list of (binary, installed: bool, brew_formula, apt_pkg, description)
    for all enzo build validation tools.
    """
    results = []
    for binary, brew_f, apt_pkg, desc in _ENZO_BUILD_TOOLS:
        installed = shutil.which(binary) is not None
        results.append((binary, installed, brew_f, apt_pkg, desc))
    return results


def install_build_tool(binary: str, interactive: bool = True) -> tuple:
    """
    Install a missing build tool via brew (macOS) or apt-get (Linux).
    Returns (success: bool, message: str).
    """
    entry = next((e for e in _ENZO_BUILD_TOOLS if e[0] == binary), None)
    if not entry:
        return False, f"No install recipe for {binary}"

    _, brew_f, apt_pkg, desc = entry
    _is_mac = platform.system() == "Darwin"

    if _is_mac and shutil.which("brew"):
        pm, pkg = "brew", brew_f
        cmd = ["brew", "install", pkg]
    elif shutil.which("apt-get") and apt_pkg:
        pm, pkg = "apt-get", apt_pkg
        cmd = ["apt-get", "install", "-y", "-q", pkg]
    else:
        hint = f"brew install {brew_f}" if _is_mac else f"apt-get install {apt_pkg}"
        return False, f"No supported package manager found. Install manually: {hint}"

    if interactive:
        try:
            ans = input(f"  Install {binary} via {pm} {pkg}? [y/N] ").strip().lower()
        except EOFError:
            ans = "n"
        if ans != "y":
            return False, "skipped"

    print(f"  Installing {binary} via {pm}...")
    try:
        import subprocess as _sp
        env = os.environ.copy()
        if pm == "brew":
            env["HOMEBREW_NO_AUTO_UPDATE"] = "1"
        r = _sp.run(cmd, capture_output=True, text=True, timeout=300, env=env)
        if r.returncode == 0 and shutil.which(binary):
            return True, f"Installed {binary} via {pm}"
        return False, r.stderr.strip()[:200] or "Install failed"
    except Exception as exc:
        return False, str(exc)


def run_doctor(
    fix_mode: bool = False,
    endpoint: str = "http://localhost:11434",
) -> None:
    """
    `reachctl enzo doctor` — health check covering:
      1. Model (configured, pulled, responsive)
      2. API keys (Anthropic, Groq)
      3. Build tools (mvn, go, gradle, cargo, …)
    """
    _is_mac = platform.system() == "Darwin"
    print("Enzo Doctor")
    print(f"{'─' * 50}")

    # ── 1. Model ──────────────────────────────────────────────────────
    print("[1/3] Model")
    report = check_health(endpoint)
    if not report.ollama_installed:
        print("   ollama              ✗ not installed")
        if _is_mac:
            print("     Install: brew install ollama")
        else:
            print("     Install: curl -fsSL https://ollama.com/install.sh | sh")
    elif not report.ollama_running:
        print("   ollama              ✗ installed but not running")
        if _is_mac:
            print("     Start: brew services start ollama")
        else:
            print("     Start: sudo systemctl start ollama")
    else:
        print("   ollama              ✓ running")

    if report.model_tag:
        if report.model_pulled and report.model_responsive:
            print(f"   model               ✓ {report.model_tag} ({report.inference_latency_ms:.0f}ms)")
        elif report.model_pulled:
            print(f"   model               ⚠ {report.model_tag} (not responding)")
        else:
            print(f"   model               ✗ {report.model_tag} (not pulled)")
            print("     Pull: reachctl enzo setup")
    else:
        print("   model               — not configured")
        print("     Run: reachctl enzo setup")

    # ── 2. API Keys ───────────────────────────────────────────────────
    print("[2/3] API Keys")
    ant_key = _get_anthropic_key()
    if ant_key:
        src = "env" if os.environ.get("ANTHROPIC_API_KEY") else "keychain"
        print(f"   Anthropic           ✓ configured ({src}) — --mode cloud --provider claude")
    else:
        print("   Anthropic           — not configured (optional)")
        print("     Set: export ANTHROPIC_API_KEY=sk-ant-...  or  reachctl auth login")

    groq_key = _get_groq_key()
    if groq_key:
        src = "env" if os.environ.get("GROQ_API_KEY") else "keychain"
        print(f"   Groq                ✓ configured ({src}) — --mode cloud --provider groq")
    else:
        print("   Groq                — not configured (optional)")
        print("     Set: export GROQ_API_KEY=gsk_...  or  reachctl auth login")

    # ── 3. Build Tools ────────────────────────────────────────────────
    print("[3/3] Build validation tools")
    tools = check_build_tools()
    missing = []
    for binary, installed, brew_f, apt_pkg, desc in tools:
        status = "✓" if installed else "✗"
        print(f"   {binary:<12}      {status}  {desc}")
        if not installed:
            missing.append((binary, brew_f, apt_pkg, desc))

    if missing:
        print()
        print(f"  {len(missing)} tool(s) missing — enzo will skip build validation for those ecosystems.")
        if fix_mode:
            for binary, brew_f, apt_pkg, desc in missing:
                ok, msg = install_build_tool(binary, interactive=True)
                if ok:
                    print(f"  ✓ {binary} installed")
                elif msg != "skipped":
                    print(f"  ✗ {binary}: {msg}")
        else:
            if _is_mac:
                pkgs = " ".join(e[1] for e in missing)
                print("  Fix: reachctl enzo doctor --fix")
                print(f"   or: brew install {pkgs}")
            else:
                pkgs = " ".join(e[2] for e in missing if e[2])
                print("  Fix: reachctl enzo doctor --fix")
                print(f"   or: apt-get install {pkgs}")
    else:
        print()
        print("  All build tools present ✓")

    print(f"{'─' * 50}")


def _print_health(report: HealthReport):
    print("\nEnzo Health Check")
    print(f"  Ollama installed:  {'✓' if report.ollama_installed else '✗'}")
    print(f"  Ollama running:    {'✓' if report.ollama_running else '✗'}")
    print(f"  Model configured:  {'✓' if report.model_configured else '✗'} {report.model_tag}")
    print(f"  Model pulled:      {'✓' if report.model_pulled else '✗'}")
    print(f"  Model responsive:  {'✓' if report.model_responsive else '✗'} ({report.inference_latency_ms:.0f}ms)")
    _cloud_src = "env" if os.environ.get("ANTHROPIC_API_KEY") else "keychain"
    _cloud_key_status = (
        f"✓ ({_cloud_src})"
        if report.cloud_configured
        else "— (set ANTHROPIC_API_KEY or store in keychain)"
    )
    print(f"  Anthropic API key: {_cloud_key_status}")
    _groq_src = "env" if os.environ.get("GROQ_API_KEY") else "keychain"
    _groq_key_status = f"✓ ({_groq_src})" if report.groq_configured else "— (set GROQ_API_KEY or store in keychain)"
    print(f"  Groq API key:      {_groq_key_status}")
    if report.issues:
        print("\n  Issues:")
        for issue in report.issues:
            print(f"    • {issue}")
    else:
        print("\n  Status: All systems go ✓")
