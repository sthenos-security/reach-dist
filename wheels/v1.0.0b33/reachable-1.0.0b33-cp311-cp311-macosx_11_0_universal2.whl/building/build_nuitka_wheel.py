#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.
"""
build_nuitka_wheel.py — Selective Nuitka-compiled wheel builder for CI

Strategy:
  1. Build standard wheel (preserves all metadata, deps, data files)
  2. Unpack it
  3. Compile only the PROTECTED subpackages with Nuitka → one .so per subpackage
  4. Remove .py source files from protected subpackages only
  5. Leave CLI, dashboard, licensing, standards etc. as plain Python
  6. Fix WHEEL tag (pure → platform-specific) and regenerate RECORD
  7. Repack as platform-specific wheel

Protected modules (IP core — compiled to .so, .py stripped):
  reachable/correlation/           — multi-signal correlation engine
  reachable/engine/                — pipeline execution + reachability analysis
  reachable/collectors/callgraph/  — call graph collection
  reachable/collectors/malware/    — malware detection engine + YARA
  reachable/sandbox/               — malware behavioral sandbox
  reachable/licensing/             — license enforcement + trial timebomb
  reachable/dlp/                   — DLP/PII taint analysis
  reachable/ai/                    — AI/LLM security detection
  enzo/                            — AI remediation engine (entire package)

Not protected (stays as plain Python):
  reachable/cli/                   — public interface
  reachable/dashboard_v2/          — HTML/JS rendering
  reachable/licensing/             — must be auditable
  reachable/compliance/            — standards mapping (public data)
  reachable/storage/               — DB schema
  reachable/conf/                  — config
  reachable/iac/                   — wraps open tools

Usage:
    python building/build_nuitka_wheel.py [--output-dir dist/]

Requirements:
    pip install nuitka ordered-set build wheel setuptools
    apt install patchelf   (Linux only — Nuitka needs it to fix library rpaths)

Local test (no release):
    source build-venv/bin/activate
    pip install nuitka ordered-set build wheel setuptools
    python building/build_nuitka_wheel.py --output-dir /tmp/nuitka-test/
    # Inspect the result:
    python -c "
    import zipfile, glob
    whl = glob.glob('/tmp/nuitka-test/*.whl')[0]
    with zipfile.ZipFile(whl) as z:
        names = z.namelist()
        so = [n for n in names if n.endswith('.so') or n.endswith('.pyd')]
        print(f'.so files ({len(so)}):')
        for f in so: print(f'  {f}')
    "
"""

import base64
import hashlib
import platform
import shutil
import subprocess
import sys
import tempfile
import time
import zipfile
from pathlib import Path

PROJECT_ROOT = Path(__file__).parent.parent

# ─────────────────────────────────────────────────────────────────────
# Protected subpackages — compiled to .so, .py stripped
# Each entry: (dotted_import_path, path_relative_to_project_root)
# ─────────────────────────────────────────────────────────────────────
PROTECTED_PACKAGES = [
    ('reachable.correlation',          'reachable/correlation'),
    ('reachable.engine',               'reachable/engine'),
    ('reachable.collectors.callgraph', 'reachable/collectors/callgraph'),
    ('reachable.collectors.malware',   'reachable/collectors/malware'),
    ('reachable.sandbox',              'reachable/sandbox'),
    ('reachable.licensing',            'reachable/licensing'),
    ('reachable.dlp',                  'reachable/dlp'),
    ('reachable.ai',                   'reachable/ai'),
    ('enzo',                           'enzo'),
]

_PROTECTED_PREFIXES = frozenset(rel for _, rel in PROTECTED_PACKAGES)


# ─────────────────────────────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────────────────────────────

def get_version() -> str:
    return (PROJECT_ROOT / 'VERSION').read_text().strip()


def get_python_tag() -> str:
    v = sys.version_info
    return f'cp{v.major}{v.minor}'


def get_platform_tag() -> str:
    system = platform.system().lower()
    machine = platform.machine().lower()
    if system == 'darwin':
        return 'macosx_15_0_arm64' if machine in ('arm64', 'aarch64') else 'macosx_13_0_x86_64'
    if system == 'linux':
        return 'linux_aarch64' if machine in ('arm64', 'aarch64') else 'linux_x86_64'
    raise RuntimeError(f'Unsupported platform: {system} {machine}')


def sha256_record(path: Path) -> str:
    digest = hashlib.sha256(path.read_bytes()).digest()
    return 'sha256=' + base64.urlsafe_b64encode(digest).rstrip(b'=').decode()


def is_protected(rel_path: str) -> bool:
    """Return True if rel_path (relative to wheel root) is inside a protected package."""
    for prefix in _PROTECTED_PREFIXES:
        if rel_path == prefix or rel_path.startswith(prefix + '/'):
            return True
    return False


# ─────────────────────────────────────────────────────────────────────
# Step 1: Build standard wheel
# ─────────────────────────────────────────────────────────────────────

def build_standard_wheel(std_dist: Path) -> Path:
    print('▶ Building standard wheel (metadata + data files)...')
    std_dist.mkdir(parents=True, exist_ok=True)
    result = subprocess.run(
        [sys.executable, '-m', 'build', '--wheel', '--outdir', str(std_dist)],
        cwd=PROJECT_ROOT,
    )
    if result.returncode != 0:
        raise RuntimeError('Standard wheel build failed')
    wheels = list(std_dist.glob('*.whl'))
    if not wheels:
        raise RuntimeError(f'No wheel found in {std_dist}')
    print(f'  Base wheel: {wheels[0].name}')
    return wheels[0]


# ─────────────────────────────────────────────────────────────────────
# Step 2: Compile protected subpackages with Nuitka
# ─────────────────────────────────────────────────────────────────────

def compile_subpackage(import_path: str, source_dir: Path, nuitka_out: Path) -> Path:
    """Compile a single subpackage directory to a .so file."""
    pkg_out = nuitka_out / import_path.replace('.', '_')
    pkg_out.mkdir(parents=True, exist_ok=True)

    module_name = import_path.split('.')[-1]

    cmd = [
        sys.executable, '-m', 'nuitka',
        '--mode=module',
        str(source_dir),
        f'--include-package={import_path}',
        f'--follow-import-to={import_path}',
        '--no-pyi-file',
        f'--output-dir={pkg_out}',
        '--remove-output',
        '--assume-yes-for-downloads',  # suppress ccache/dependency download prompts
        '--quiet',
    ]

    if platform.system().lower() == 'linux' and not shutil.which('patchelf'):
        print('  WARNING: patchelf not found — install with: apt install patchelf')

    t0 = time.time()
    # Stream output directly — Nuitka compilation takes minutes, capture_output hides progress
    result = subprocess.run(cmd, cwd=PROJECT_ROOT)
    elapsed = time.time() - t0
    if result.returncode != 0:
        raise RuntimeError(f'Nuitka compilation failed for {import_path} (see output above)')

    # Find the .so — Nuitka names it after the last module component
    so_files = (
        list(pkg_out.glob(f'{module_name}.cpython-*.so')) +
        list(pkg_out.glob(f'{module_name}.cpython-*.pyd')) +
        list(pkg_out.glob('*.so')) +
        list(pkg_out.glob('*.pyd'))
    )
    if not so_files:
        raise RuntimeError(f'Nuitka produced no .so in {pkg_out} for {import_path}')

    so = so_files[0]
    print(f'  ✓ {import_path:<45} → {so.name} ({so.stat().st_size // 1024} KB, {elapsed:.0f}s)')
    return so


def compile_all_protected(nuitka_out: Path) -> dict:
    """Compile all protected packages. Returns {import_path: so_path}."""
    print('▶ Compiling protected modules with Nuitka...')
    results = {}
    failed = []
    for import_path, rel_source in PROTECTED_PACKAGES:
        source_dir = PROJECT_ROOT / rel_source
        if not source_dir.exists():
            print(f'  SKIP {import_path} — not found: {rel_source}')
            continue
        try:
            print(f'  Compiling {import_path}...')
            sys.stdout.flush()
            so = compile_subpackage(import_path, source_dir, nuitka_out)
            results[import_path] = so
        except RuntimeError as e:
            print(f'  ✗ {import_path}: {e}')
            failed.append(import_path)

    if failed:
        raise RuntimeError(f'Nuitka compilation failed for: {", ".join(failed)}')

    print(f'  Compiled {len(results)}/{len(PROTECTED_PACKAGES)} packages')
    return results


# ─────────────────────────────────────────────────────────────────────
# Step 3-7: Repack wheel
# ─────────────────────────────────────────────────────────────────────

def repack_wheel(std_wheel: Path, compiled: dict, output_dir: Path) -> Path:
    print('▶ Repacking wheel with compiled .so files...')

    py_tag = get_python_tag()
    plat_tag = get_platform_tag()
    version = get_version()
    new_name = f'reachable-{version}-{py_tag}-{py_tag}-{plat_tag}.whl'
    wheel_path = output_dir / new_name

    unpack_dir = Path(tempfile.mkdtemp(prefix='reachable_wheel_'))
    try:
        with zipfile.ZipFile(std_wheel) as zf:
            zf.extractall(unpack_dir)

        # Strip .py source from protected packages only
        removed = 0
        for py_file in sorted(unpack_dir.rglob('*.py')):
            rel = str(py_file.relative_to(unpack_dir))
            if is_protected(rel):
                py_file.unlink()
                removed += 1

        # Strip __pycache__ from protected packages
        for pycache in sorted(unpack_dir.rglob('__pycache__')):
            rel_parent = str(pycache.parent.relative_to(unpack_dir))
            if is_protected(rel_parent):
                shutil.rmtree(pycache, ignore_errors=True)

        print(f'  Stripped {removed} .py source files from protected modules')

        # Place .so files at correct location in wheel
        for import_path, so_path in compiled.items():
            parts = import_path.split('.')
            if len(parts) == 1:
                dest = unpack_dir / so_path.name
            else:
                parent_dir = unpack_dir.joinpath(*parts[:-1])
                parent_dir.mkdir(parents=True, exist_ok=True)
                dest = parent_dir / so_path.name
            shutil.copy2(so_path, dest)
            print(f'  + {dest.relative_to(unpack_dir)}')

        # Fix WHEEL metadata: pure-python → platform-specific
        dist_info_dirs = list(unpack_dir.glob('reachable-*.dist-info'))
        if not dist_info_dirs:
            raise RuntimeError('No dist-info found in unpacked wheel')
        dist_info = dist_info_dirs[0]

        wheel_meta = dist_info / 'WHEEL'
        new_lines = []
        for line in wheel_meta.read_text().splitlines():
            if line.startswith('Tag:'):
                new_lines.append(f'Tag: {py_tag}-{py_tag}-{plat_tag}')
            elif line.startswith('Root-Is-Purelib:'):
                new_lines.append('Root-Is-Purelib: false')
            else:
                new_lines.append(line)
        wheel_meta.write_text('\n'.join(new_lines) + '\n')

        # Regenerate RECORD
        record_path = dist_info / 'RECORD'
        dist_info_name = dist_info.name
        records = []
        for f in sorted(unpack_dir.rglob('*')):
            if not f.is_file():
                continue
            rel = str(f.relative_to(unpack_dir))
            if rel == f'{dist_info_name}/RECORD':
                continue
            records.append(f'{rel},{sha256_record(f)},{f.stat().st_size}')
        records.append(f'{dist_info_name}/RECORD,,')
        record_path.write_text('\n'.join(records) + '\n')

        # Repack
        output_dir.mkdir(parents=True, exist_ok=True)
        with zipfile.ZipFile(wheel_path, 'w', compression=zipfile.ZIP_DEFLATED) as zf:
            for f in sorted(unpack_dir.rglob('*')):
                if f.is_file():
                    zf.write(f, f.relative_to(unpack_dir))

        size_mb = wheel_path.stat().st_size / 1024 / 1024
        print(f'  Built: {new_name} ({size_mb:.1f} MB)')
        return wheel_path

    finally:
        shutil.rmtree(unpack_dir, ignore_errors=True)


# ─────────────────────────────────────────────────────────────────────
# Verification
# ─────────────────────────────────────────────────────────────────────

def verify_wheel(wheel_path: Path, compiled: dict):
    """Sanity-check the output wheel."""
    print('▶ Verifying wheel...')
    with zipfile.ZipFile(wheel_path) as zf:
        names = zf.namelist()

    so_files = [n for n in names if n.endswith('.so') or n.endswith('.pyd')]
    py_in_protected = [n for n in names if n.endswith('.py') and is_protected(n)]

    for import_path in compiled:
        module_name = import_path.split('.')[-1]
        found = any(module_name in s for s in so_files)
        status = '✓' if found else '✗'
        print(f'  {status} {import_path} — .so {"present" if found else "MISSING"}')

    if py_in_protected:
        print(f'  ✗ {len(py_in_protected)} .py files still in protected packages:')
        for f in py_in_protected[:5]:
            print(f'      {f}')
        raise RuntimeError('Protected .py source files were not stripped')

    total_py = len([n for n in names if n.endswith('.py')])
    print('  ✓ No .py source in protected packages')
    print(f'  ✓ {len(so_files)} .so files, {total_py} .py files remaining (unprotected only)')


# ─────────────────────────────────────────────────────────────────────
# Main
# ─────────────────────────────────────────────────────────────────────

def main():
    import argparse
    parser = argparse.ArgumentParser(description='Build Nuitka-compiled REACHABLE wheel')
    parser.add_argument('--output-dir', '-o', default='dist', help='Output directory (default: dist/)')
    args = parser.parse_args()

    output_dir = Path(args.output_dir)
    std_dist = Path(tempfile.mkdtemp(prefix='reachable_std_'))
    nuitka_out = Path(tempfile.mkdtemp(prefix='reachable_nuitka_'))

    try:
        print(f'\n🔒 REACHABLE {get_version()} — Nuitka selective compilation')
        print(f'   Platform : {get_platform_tag()}')
        print(f'   Python   : {get_python_tag()}')
        print(f'   Protecting {len(PROTECTED_PACKAGES)} subpackages\n')

        std_wheel = build_standard_wheel(std_dist)
        compiled = compile_all_protected(nuitka_out)
        wheel_path = repack_wheel(std_wheel, compiled, output_dir)
        verify_wheel(wheel_path, compiled)

        print(f'\n✅ Wheel: {wheel_path}')
        return 0

    except Exception as e:
        print(f'\n❌ Build failed: {e}', file=sys.stderr)
        import traceback
        traceback.print_exc()
        return 1

    finally:
        shutil.rmtree(std_dist, ignore_errors=True)
        shutil.rmtree(nuitka_out, ignore_errors=True)


if __name__ == '__main__':
    sys.exit(main())
