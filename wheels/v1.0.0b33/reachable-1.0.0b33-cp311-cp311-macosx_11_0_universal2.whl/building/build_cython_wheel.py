#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.
"""
build_cython_wheel.py — Selective Cython-compiled wheel builder for CI

Strategy:
  1. Build standard wheel (preserves all metadata, deps, data files)
  2. Unpack it
  3. Compile protected .py files → .so via Cython + setuptools build_ext
  4. Strip .py source from protected packages, drop .so files in-place
  5. Fix WHEEL tag (pure → platform-specific), regenerate RECORD
  6. Repack as platform-specific wheel

Protected modules (IP core — compiled to .so, .py stripped):
  reachable/correlation/           — multi-signal correlation engine
  reachable/engine/                — pipeline execution + reachability analysis
  reachable/collectors/callgraph/  — call graph collection
  reachable/collectors/malware/    — malware detection engine + YARA
  reachable/sandbox/               — malware behavioral sandbox
  reachable/licensing/             — license enforcement + trial timebomb
  reachable/dlp/                   — DLP/PII taint analysis
  reachable/ai/                    — AI/LLM security detection
  enzo/                            — AI remediation engine (entire package)

Not protected (stays as plain Python):
  reachable/cli/                   — public interface
  reachable/dashboard_v2/          — HTML/JS rendering
  reachable/compliance/            — standards mapping (public data)
  reachable/database/              — DB schema
  reachable/conf/                  — config
  reachable/iac/                   — wraps open tools

Note: __init__.py files are never compiled — Python needs them for package
discovery regardless of whether the package is otherwise compiled.

Usage:
    python building/build_cython_wheel.py [--output-dir dist/]

Requirements:
    pip install cython build wheel setuptools

Build time vs Nuitka:
    Nuitka: 30-60+ min per job (whole-program C compilation + optimization)
    Cython: 2-5 min per job (per-file C transpilation, standard gcc compile)
"""

import base64
import hashlib
import json
import os
import platform
import shutil
import subprocess
import sys
import tempfile
import time
import zipfile
from pathlib import Path

PROJECT_ROOT = Path(__file__).parent.parent

PROTECTED_PACKAGES = [
    ('reachable.correlation',          'reachable/correlation'),
    ('reachable.engine',               'reachable/engine'),
    ('reachable.collectors.callgraph', 'reachable/collectors/callgraph'),
    ('reachable.collectors.malware',   'reachable/collectors/malware'),
    ('reachable.sandbox',              'reachable/sandbox'),
    ('reachable.licensing',            'reachable/licensing'),
    ('reachable.dlp',                  'reachable/dlp'),
    ('reachable.ai',                   'reachable/ai'),
    ('enzo',                           'enzo'),
]

_PROTECTED_PREFIXES = frozenset(rel for _, rel in PROTECTED_PACKAGES)


# ─────────────────────────────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────────────────────────────

def get_version() -> str:
    return (PROJECT_ROOT / 'VERSION').read_text().strip()


def get_python_tag() -> str:
    v = sys.version_info
    return f'cp{v.major}{v.minor}'


def get_platform_tag(universal2: bool = False) -> str:
    system = platform.system().lower()
    machine = platform.machine().lower()
    if system == 'darwin':
        if universal2:
            return 'macosx_11_0_universal2'
        return 'macosx_15_0_arm64' if machine in ('arm64', 'aarch64') else 'macosx_13_0_x86_64'
    if system == 'linux':
        return 'linux_aarch64' if machine in ('arm64', 'aarch64') else 'linux_x86_64'
    raise RuntimeError(f'Unsupported platform: {system} {machine}')


def sha256_record(path: Path) -> str:
    digest = hashlib.sha256(path.read_bytes()).digest()
    return 'sha256=' + base64.urlsafe_b64encode(digest).rstrip(b'=').decode()


def is_protected(rel_path: str) -> bool:
    for prefix in _PROTECTED_PREFIXES:
        if rel_path == prefix or rel_path.startswith(prefix + '/'):
            return True
    return False


# ─────────────────────────────────────────────────────────────────────
# Step 1: Build standard wheel
# ─────────────────────────────────────────────────────────────────────

def build_standard_wheel(std_dist: Path) -> Path:
    print('▶ Building standard wheel (metadata + data files)...')
    std_dist.mkdir(parents=True, exist_ok=True)
    result = subprocess.run(
        [sys.executable, '-m', 'build', '--wheel', '--outdir', str(std_dist)],
        cwd=PROJECT_ROOT,
    )
    if result.returncode != 0:
        raise RuntimeError('Standard wheel build failed')
    wheels = list(std_dist.glob('*.whl'))
    if not wheels:
        raise RuntimeError(f'No wheel found in {std_dist}')
    print(f'  Base wheel: {wheels[0].name}')
    return wheels[0]


# ─────────────────────────────────────────────────────────────────────
# Step 2a: Cython transpilation (.py → .c)  — run ONCE in CI
# Step 2b: gcc compile (.c → .so)           — run per platform/py/arch
#
# The .c files Cython produces are Python-version-independent: they
# reference the CPython C-API but adapt to the target ABI at gcc compile
# time via the Python headers.  So we can transpile once, cache the .c
# files keyed on source hash, and let every matrix job skip straight to
# gcc (build_ext) without needing Cython at all.
#
# Cache directory layout (relative to PROJECT_ROOT):
#   cython_c_cache/<rel/path/to/module.c>
# ─────────────────────────────────────────────────────────────────────

# Default cache location — outside the repo, persistent across builds.
# Override with --cache-dir or REACHABLE_CYTHON_CACHE env var.
DEFAULT_CACHE_DIR = Path.home() / '.reachable-build-cache' / 'cython_c'

# ── Legacy in-repo cache dir (no longer used — remove if present) ──
CYTHON_CACHE_DIR = PROJECT_ROOT / 'cython_c_cache'  # kept for cleanup only


# ─────────────────────────────────────────────────────────────────────
# C-file cache  —  transpile once, reuse on every platform/arch/py
# ─────────────────────────────────────────────────────────────────────

MANIFEST_NAME = 'manifest.json'


def _file_sha256(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        for chunk in iter(lambda: f.read(65536), b''):
            h.update(chunk)
    return h.hexdigest()


def _source_cache_key(modules: list[tuple[str, Path]]) -> str:
    """
    SHA256 over sorted (rel_path, file_sha256) pairs.
    Changes to ANY protected source file produce a new key → auto-invalidation.
    """
    h = hashlib.sha256()
    for _, py_path in sorted(modules, key=lambda x: str(x[1])):
        rel = str(py_path.relative_to(PROJECT_ROOT))
        src_hash = _file_sha256(py_path)
        h.update(f'{rel}:{src_hash}\n'.encode())
    return h.hexdigest()


def get_cache_dir(override: str = None) -> Path:
    if override:
        return Path(override)
    env = os.environ.get('REACHABLE_CYTHON_CACHE')
    if env:
        return Path(env)
    return DEFAULT_CACHE_DIR


def cache_status(cache_dir: Path) -> dict:
    """
    Return status dict:
      valid      bool
      reason     str   (empty if valid)
      cache_key  str
      file_count int
      total_mb   float
      age_hours  float
      files      list
    """
    manifest_path = cache_dir / MANIFEST_NAME
    if not cache_dir.exists() or not manifest_path.exists():
        return {'valid': False, 'reason': 'cache missing', 'cache_key': '', 'file_count': 0, 'total_mb': 0.0, 'age_hours': 0.0, 'files': []}

    try:
        manifest = json.loads(manifest_path.read_text())
    except Exception as e:
        return {'valid': False, 'reason': f'manifest unreadable: {e}', 'cache_key': '', 'file_count': 0, 'total_mb': 0.0, 'age_hours': 0.0, 'files': []}

    expected_count = manifest.get('file_count', 0)
    expected_size  = manifest.get('total_size_bytes', 0)
    files_meta     = manifest.get('files', [])
    created_at     = manifest.get('created_at', 0)
    cache_key      = manifest.get('cache_key', '')
    age_hours      = (time.time() - created_at) / 3600 if created_at else 0.0

    # Check file count
    actual_c_files = list(cache_dir.rglob('*.c'))
    if len(actual_c_files) != expected_count:
        return {'valid': False,
                'reason': f'file count mismatch: expected {expected_count}, found {len(actual_c_files)}',
                'cache_key': cache_key, 'file_count': expected_count,
                'total_mb': expected_size / 1024 / 1024, 'age_hours': age_hours, 'files': files_meta}

    # Check total size
    actual_size = sum(f.stat().st_size for f in actual_c_files)
    if actual_size != expected_size:
        return {'valid': False,
                'reason': f'size mismatch: expected {expected_size}B, found {actual_size}B',
                'cache_key': cache_key, 'file_count': expected_count,
                'total_mb': expected_size / 1024 / 1024, 'age_hours': age_hours, 'files': files_meta}

    # Per-file checksum
    for entry in files_meta:
        rel = entry.get('c_rel', '')
        expected_hash = entry.get('c_hash', '')
        c_path = cache_dir / rel
        if not c_path.exists():
            return {'valid': False, 'reason': f'missing cached file: {rel}',
                    'cache_key': cache_key, 'file_count': expected_count,
                    'total_mb': expected_size / 1024 / 1024, 'age_hours': age_hours, 'files': files_meta}
        actual_hash = _file_sha256(c_path)
        if actual_hash != expected_hash:
            return {'valid': False, 'reason': f'checksum mismatch: {rel}',
                    'cache_key': cache_key, 'file_count': expected_count,
                    'total_mb': expected_size / 1024 / 1024, 'age_hours': age_hours, 'files': files_meta}

    return {'valid': True, 'reason': '',
            'cache_key': cache_key, 'file_count': expected_count,
            'total_mb': expected_size / 1024 / 1024, 'age_hours': age_hours, 'files': files_meta}


def print_cache_status(cache_dir: Path):
    print(f'  Cache dir : {cache_dir}')
    status = cache_status(cache_dir)
    if not status['valid']:
        print(f'  Status    : ✗ INVALID — {status["reason"]}')
        return
    print('  Status    : ✓ VALID')
    print(f'  Key       : {status["cache_key"][:16]}...')
    print(f'  Files     : {status["file_count"]} .c files')
    print(f'  Size      : {status["total_mb"]:.1f} MB')
    print(f'  Age       : {status["age_hours"]:.1f} hours')


def clear_cache(cache_dir: Path):
    if cache_dir.exists():
        shutil.rmtree(cache_dir)
        print(f'  ✓ Cache cleared: {cache_dir}')
    else:
        print(f'  Cache does not exist: {cache_dir}')


def write_cache(cache_dir: Path, c_files: list[tuple[str, Path]], cache_key: str, src_modules: list[tuple[str, Path]]):
    """
    Copy all generated .c files into cache_dir, write manifest.
    c_files: list of (rel_to_project_root, abs_c_path)
    """
    cache_dir.mkdir(parents=True, exist_ok=True)

    files_meta = []
    total_size = 0

    for rel_c, abs_c in c_files:
        dest = cache_dir / rel_c
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(abs_c, dest)
        c_hash = _file_sha256(dest)
        c_size = dest.stat().st_size
        total_size += c_size
        # Find matching source
        src_hash = ''
        for mod_name, py_path in src_modules:
            if py_path.with_suffix('.c').relative_to(PROJECT_ROOT) == Path(rel_c):
                src_hash = _file_sha256(py_path)
                break
        files_meta.append({'c_rel': rel_c, 'c_hash': c_hash, 'c_size': c_size, 'src_hash': src_hash})

    manifest = {
        'cache_key':        cache_key,
        'created_at':       time.time(),
        'created_at_iso':   time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
        'file_count':       len(files_meta),
        'total_size_bytes': total_size,
        'files':            files_meta,
    }
    (cache_dir / MANIFEST_NAME).write_text(json.dumps(manifest, indent=2))
    print(f'  Cached {len(files_meta)} .c files → {cache_dir}  ({total_size / 1024 / 1024:.1f} MB)')


def restore_from_cache(cache_dir: Path) -> list[tuple[str, Path]]:
    """
    Copy .c files from cache into the source tree next to their .py files.
    Returns list of (rel_c_path, abs_c_path) placed in source tree.
    """
    manifest_path = cache_dir / MANIFEST_NAME
    manifest = json.loads(manifest_path.read_text())
    restored = []
    for entry in manifest['files']:
        rel = entry['c_rel']
        src = cache_dir / rel
        dst = PROJECT_ROOT / rel
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, dst)
        restored.append((rel, dst))
    print(f'  Restored {len(restored)} .c files from cache')
    return restored


def collect_protected_py_files() -> list[tuple[str, Path]]:
    """
    Returns list of (dotted_module_name, abs_py_path) for all non-__init__
    .py files in protected packages.
    """
    # Files that should not be Cython-compiled (dead code tombstones, stubs, etc.)
    SKIP_FILES = frozenset([
        'reachable/engine/loaders.py',  # dead code — raises ImportError at module level
        'enzo/cli.py',                  # CLI entry point — stays as plain .py
        'enzo/setup.py',                # setup/config utility — stays as plain .py
        'enzo/__main__.py',             # module runner — stays as plain .py
    ])

    # Directories to skip entirely (tests, fixtures — not shipped or not compiled)
    SKIP_DIRS = (
        'enzo/tests/',
        'enzo/docs/',
    )

    modules = []
    for _, rel_source in PROTECTED_PACKAGES:
        source_dir = PROJECT_ROOT / rel_source
        if not source_dir.exists():
            print(f'  SKIP {rel_source} — directory not found')
            continue
        for py_file in sorted(source_dir.rglob('*.py')):
            if py_file.name == '__init__.py':
                continue  # keep __init__.py as plain Python
            rel = py_file.relative_to(PROJECT_ROOT)
            rel_str = str(rel).replace('\\', '/')
            if rel_str in SKIP_FILES:
                print(f'  SKIP {rel_str} — excluded from Cython compilation')
                continue
            if any(rel_str.startswith(d) for d in SKIP_DIRS):
                continue
            module_name = str(rel.with_suffix('')).replace('/', '.').replace('\\', '.')
            modules.append((module_name, py_file))
    return modules


def transpile_with_cython(modules: list[tuple[str, Path]]) -> list[tuple[str, Path]]:
    """
    Run Cython transpilation ONLY: .py → .c next to each source file.
    Does NOT compile to .so.  Returns list of (rel_c_path, abs_c_path).
    Fast — no gcc, no platform dependency.
    """
    print(f'▶ Transpiling {len(modules)} modules with Cython (.py → .c)...')
    t0 = time.time()

    ext_entries = '\n'.join(
        f'    Extension("{m}", ["{str(p.relative_to(PROJECT_ROOT)).replace(chr(92), "/")}"]),'  # noqa: E501
        for m, p in modules
    )
    setup_src = (
        'from setuptools import Extension, setup\n'
        'from Cython.Build import cythonize\n'
        '\n'
        'extensions = [\n' + ext_entries + '\n]\n\n'
        'if __name__ == "__main__":\n'
        '    setup(ext_modules=cythonize(extensions,\n'
        '        compiler_directives={"language_level": "3", "always_allow_keywords": True},\n'
        '        nthreads=4, quiet=True))\n'
    )
    setup_py = PROJECT_ROOT / '_cython_transpile_setup.py'
    setup_py.write_text(setup_src)
    try:
        result = subprocess.run(
            [sys.executable, str(setup_py), 'build_ext', '--inplace'],
            cwd=PROJECT_ROOT,
        )
        if result.returncode != 0:
            raise RuntimeError('Cython transpilation failed')
    finally:
        setup_py.unlink(missing_ok=True)
        # Clean stale .so / build dir (we only want .c at this stage)
        build_dir = PROJECT_ROOT / 'build'
        if build_dir.exists():
            shutil.rmtree(build_dir)
        for _, py_path in modules:
            for so in py_path.parent.glob(py_path.stem + '.*.so'):
                so.unlink(missing_ok=True)

    c_files = []
    for _, py_path in modules:
        c_path = py_path.with_suffix('.c')
        if c_path.exists():
            c_files.append((str(c_path.relative_to(PROJECT_ROOT)), c_path))

    elapsed = time.time() - t0
    print(f'  Transpilation done in {elapsed:.0f}s — {len(c_files)} .c files generated')
    return c_files


def compile_with_cython(modules: list[tuple[str, Path]], build_lib: Path,
                        skip_transpile: bool = False, universal2: bool = False) -> dict[str, Path]:
    """
    Compile protected modules to .so via a temporary setup.py.

    skip_transpile=False (default): full path — Cython transpiles .py→.c then gcc compiles.
    skip_transpile=True:  fast path — .c files already restored from cache; only gcc runs.
                          Does NOT need Cython installed.  ~3-5x faster.
    universal2=True:      macOS only — compile fat binary (ARM64 + x86_64) via
                          ARCHFLAGS + extra_compile_args/extra_link_args.
    Returns {rel_path_in_wheel: so_path}
    """
    if universal2 and platform.system().lower() != 'darwin':
        raise RuntimeError('--universal2 is only supported on macOS')

    if universal2:
        # Tell distutils/setuptools to build a fat binary.
        # ARCHFLAGS is the canonical way — picked up by clang automatically.
        os.environ['ARCHFLAGS'] = '-arch x86_64 -arch arm64'
        # _PYTHON_HOST_PLATFORM makes the wheel tag universal2 in the build step.
        os.environ['_PYTHON_HOST_PLATFORM'] = 'macosx-11.0-universal2'
        print('  Universal2: ARCHFLAGS=-arch x86_64 -arch arm64')

    if skip_transpile:
        print(f'▶ Compiling {len(modules)} modules from cached .c files (skipping Cython)...')
        # Pass .c source directly to Extension — no cythonize() call needed.
        ext_entries = '\n'.join(
            f'    Extension("{module_name}", ["{str(py_file.with_suffix(".c").relative_to(PROJECT_ROOT)).replace(chr(92), "/")}"]),'  # noqa: E501
            for module_name, py_file in modules
            if py_file.with_suffix('.c').exists()  # skip if .c missing (shouldn't happen)
        )
        setup_src = (
            'from setuptools import Extension, setup\n'
            '\n'
            'extensions = [\n'
            + ext_entries + '\n'
            ']\n'
            '\n'
            'if __name__ == "__main__":\n'
            '    setup(ext_modules=extensions)\n'
        )
    else:
        print(f'▶ Compiling {len(modules)} protected modules with Cython...')
        # Full path: cythonize transpiles .py → .c, then gcc compiles.
        ext_entries = '\n'.join(
            f'    Extension("{module_name}", ["{str(py_file.relative_to(PROJECT_ROOT)).replace(chr(92), "/")}"]),'  # noqa: E501
            for module_name, py_file in modules
        )
        setup_src = (
            'from setuptools import Extension, setup\n'
            'from Cython.Build import cythonize\n'
            '\n'
            'extensions = [\n'
            + ext_entries + '\n'
            ']\n'
            '\n'
            'if __name__ == "__main__":\n'
            '    setup(\n'
            '        ext_modules=cythonize(\n'
            '            extensions,\n'
            "            compiler_directives={'language_level': '3', 'always_allow_keywords': True},\n"
            '            nthreads=4,\n'
            '            quiet=True,\n'
            '        )\n'
            '    )\n'
        )

    t0 = time.time()
    setup_py = PROJECT_ROOT / '_cython_build_setup.py'
    setup_py.write_text(setup_src)
    build_lib.mkdir(parents=True, exist_ok=True)

    n_jobs = os.cpu_count() or 2

    try:
        # Use -j2 for universal2 (cross-compiling x86_64+arm64 — more jobs can cause linker races)
        # Use all cores otherwise.
        parallel = 2 if universal2 else n_jobs
        result = subprocess.run(
            [
                sys.executable, str(setup_py),
                'build_ext',
                f'--build-lib={build_lib}',
                '--inplace',
                f'--parallel={parallel}',
            ],
            cwd=PROJECT_ROOT,
        )
        if result.returncode != 0:
            raise RuntimeError('Cython build_ext failed — see output above')
    finally:
        setup_py.unlink(missing_ok=True)
        # Clean up .c files only if WE generated them (not from cache)
        if not skip_transpile:
            for _, py_file in modules:
                c_file = py_file.with_suffix('.c')
                if c_file.exists():
                    c_file.unlink()
        build_dir = PROJECT_ROOT / 'build'
        if build_dir.exists():
            shutil.rmtree(build_dir)

    elapsed = time.time() - t0
    print(f'  Cython compilation done in {elapsed:.0f}s')

    # Collect .so files from build_lib
    so_map: dict[str, Path] = {}
    for so_file in build_lib.rglob('*.so'):
        rel = str(so_file.relative_to(build_lib)).replace('\\', '/')
        so_map[rel] = so_file

    # Also collect any .so built inplace (--inplace puts them next to source)
    for _, rel_source in PROTECTED_PACKAGES:
        source_dir = PROJECT_ROOT / rel_source
        if not source_dir.exists():
            continue
        for so_file in source_dir.rglob('*.so'):
            rel_to_root = str(so_file.relative_to(PROJECT_ROOT)).replace('\\', '/')
            if rel_to_root not in so_map:
                so_map[rel_to_root] = so_file

    print(f'  Collected {len(so_map)} .so files')
    for rel in sorted(so_map):
        size_kb = so_map[rel].stat().st_size // 1024
        print(f'  + {rel} ({size_kb} KB)')

    if not so_map:
        raise RuntimeError('Cython produced no .so files')

    return so_map


# ─────────────────────────────────────────────────────────────────────
# Step 3: Repack wheel
# ─────────────────────────────────────────────────────────────────────

def repack_wheel(std_wheel: Path, so_map: dict[str, Path], output_dir: Path, universal2: bool = False) -> Path:
    print('▶ Repacking wheel with compiled .so files...')

    py_tag = get_python_tag()
    plat_tag = get_platform_tag(universal2=universal2)
    version = get_version()
    new_name = f'reachable-{version}-{py_tag}-{py_tag}-{plat_tag}.whl'
    wheel_path = output_dir / new_name

    unpack_dir = Path(tempfile.mkdtemp(prefix='reachable_wheel_'))
    try:
        with zipfile.ZipFile(std_wheel) as zf:
            zf.extractall(unpack_dir)

        # Files kept as plain .py in the wheel (not compiled, not stripped)
        KEEP_AS_PY = frozenset([
            'enzo/cli.py',
            'enzo/setup.py',
            'enzo/__main__.py',
        ])

        # Strip .py source from protected packages (except __init__.py and KEEP_AS_PY)
        removed = 0
        for py_file in sorted(unpack_dir.rglob('*.py')):
            rel = str(py_file.relative_to(unpack_dir)).replace('\\', '/')
            if py_file.name == '__init__.py':
                continue
            if rel in KEEP_AS_PY:
                continue
            if is_protected(rel):
                py_file.unlink()
                removed += 1

        # Strip __pycache__ from protected packages
        for pycache in sorted(unpack_dir.rglob('__pycache__')):
            rel_parent = str(pycache.parent.relative_to(unpack_dir))
            if is_protected(rel_parent):
                shutil.rmtree(pycache, ignore_errors=True)

        print(f'  Stripped {removed} .py source files from protected modules')

        # Place .so files at correct location in wheel
        placed = 0
        for so_rel, so_path in so_map.items():
            dest = unpack_dir / so_rel
            dest.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(so_path, dest)
            placed += 1

        print(f'  Placed {placed} .so files into wheel')

        # Fix WHEEL metadata
        dist_info_dirs = list(unpack_dir.glob('reachable-*.dist-info'))
        if not dist_info_dirs:
            raise RuntimeError('No dist-info found in unpacked wheel')
        dist_info = dist_info_dirs[0]

        wheel_meta = dist_info / 'WHEEL'
        new_lines = []
        for line in wheel_meta.read_text().splitlines():
            if line.startswith('Tag:'):
                new_lines.append(f'Tag: {py_tag}-{py_tag}-{plat_tag}')
            elif line.startswith('Root-Is-Purelib:'):
                new_lines.append('Root-Is-Purelib: false')
            else:
                new_lines.append(line)
        wheel_meta.write_text('\n'.join(new_lines) + '\n')

        # Regenerate RECORD
        record_path = dist_info / 'RECORD'
        dist_info_name = dist_info.name
        records = []
        for f in sorted(unpack_dir.rglob('*')):
            if not f.is_file():
                continue
            rel = str(f.relative_to(unpack_dir))
            if rel == f'{dist_info_name}/RECORD':
                continue
            records.append(f'{rel},{sha256_record(f)},{f.stat().st_size}')
        records.append(f'{dist_info_name}/RECORD,,')
        record_path.write_text('\n'.join(records) + '\n')

        # Repack
        output_dir.mkdir(parents=True, exist_ok=True)
        with zipfile.ZipFile(wheel_path, 'w', compression=zipfile.ZIP_DEFLATED) as zf:
            for f in sorted(unpack_dir.rglob('*')):
                if f.is_file():
                    zf.write(f, f.relative_to(unpack_dir))

        size_mb = wheel_path.stat().st_size / 1024 / 1024
        print(f'  Built: {new_name} ({size_mb:.1f} MB)')
        return wheel_path

    finally:
        shutil.rmtree(unpack_dir, ignore_errors=True)


# ─────────────────────────────────────────────────────────────────────
# Verification
# ─────────────────────────────────────────────────────────────────────

def verify_wheel(wheel_path: Path, so_map: dict[str, Path]):
    print('▶ Verifying wheel...')
    with zipfile.ZipFile(wheel_path) as zf:
        names = zf.namelist()

    # Files intentionally kept as plain .py (CLI entry points, __main__, etc.)
    KEEP_AS_PY = frozenset([
        'enzo/cli.py',
        'enzo/setup.py',
        'enzo/__main__.py',
    ])

    so_in_wheel = [n for n in names if n.endswith('.so') or n.endswith('.pyd')]
    py_in_protected = [
        n for n in names
        if n.endswith('.py') and not n.endswith('__init__.py') and is_protected(n)
        and n not in KEEP_AS_PY
    ]

    print(f'  ✓ {len(so_in_wheel)} .so files in wheel')

    if py_in_protected:
        print(f'  ✗ {len(py_in_protected)} protected .py files still present:')
        for f in py_in_protected[:10]:
            print(f'      {f}')
        raise RuntimeError('Protected .py source files were not stripped')

    total_py = len([n for n in names if n.endswith('.py')])
    print('  ✓ No .py source in protected packages (excluding __init__.py)')
    print(f'  ✓ {total_py} .py files remaining (unprotected + __init__.py only)')


# ─────────────────────────────────────────────────────────────────────
# Cleanup: remove inplace .so files from source tree
# ─────────────────────────────────────────────────────────────────────

def cleanup_inplace_so():
    """Remove any .so files built inplace in the source tree."""
    for _, rel_source in PROTECTED_PACKAGES:
        source_dir = PROJECT_ROOT / rel_source
        if not source_dir.exists():
            continue
        for so_file in source_dir.rglob('*.so'):
            so_file.unlink()


# ─────────────────────────────────────────────────────────────────────
# Main
# ─────────────────────────────────────────────────────────────────────

def main():
    import argparse
    parser = argparse.ArgumentParser(
        description='Build Cython-compiled REACHABLE wheel',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=(
            'Cache workflow (local multi-platform):\n'
            '  1. python build_cython_wheel.py --transpile-only   # .py→.c, write cache\n'
            '  2. python build_cython_wheel.py                    # mac build (uses cache)\n'
            '  3. ./build.sh linux-cython                         # linux build (uses cache)\n'
            '\nCache management:\n'
            '  python build_cython_wheel.py --cache-status        # inspect cache\n'
            '  python build_cython_wheel.py --clear-cache         # wipe cache\n'
        ),
    )
    parser.add_argument('--output-dir', '-o', default='dist', help='Output directory (default: dist/)')
    parser.add_argument('--dev', action='store_true',
        help='Dev build: CFLAGS=-O0 for fast local iteration (not for release)')
    parser.add_argument('--cache-dir', default=None,
        help=f'Override cache directory (default: {DEFAULT_CACHE_DIR})')
    parser.add_argument('--universal2', action='store_true',
        help='macOS only: build fat binary (ARM64 + x86_64) via ARCHFLAGS + build_ext -j2')

    # Cache lifecycle flags
    parser.add_argument('--transpile-only', action='store_true',
        help='Only run Cython transpilation (.py→.c), write cache, then exit — no gcc, no wheel')
    parser.add_argument('--skip-transpile', action='store_true',
        help='Skip Cython transpilation — restore .c from cache and compile with gcc only')
    parser.add_argument('--cache-status', action='store_true',
        help='Show cache status and exit')
    parser.add_argument('--clear-cache', action='store_true',
        help='Clear the C-file cache and exit')
    args = parser.parse_args()

    cache_dir = get_cache_dir(args.cache_dir)

    # ── Cache management commands (no build) ──
    if args.cache_status:
        print('\n📦 Cython C-file cache status')
        print_cache_status(cache_dir)
        return 0

    if args.clear_cache:
        print('\n🗑  Clearing Cython C-file cache')
        clear_cache(cache_dir)
        return 0

    # ── Dev build flag ──
    if args.dev:
        os.environ.setdefault('CFLAGS', '-O0')
        print('  ⚡ Dev build: CFLAGS=-O0 (fast compile, not for release)\n')

    modules = collect_protected_py_files()
    print(f'  Found {len(modules)} .py files to protect')

    # ── Transpile-only mode: .py→.c + write cache, no gcc, no wheel ──
    if args.transpile_only:
        print(f'\n🔁 REACHABLE {get_version()} — Cython transpilation only (.py→.c)')
        cache_key = _source_cache_key(modules)
        status = cache_status(cache_dir)
        if status['valid'] and status['cache_key'] == cache_key:
            print(f'  ✓ Cache already valid and up-to-date (key={cache_key[:16]}...)')
            print(f'  {status["file_count"]} .c files, {status["total_mb"]:.1f} MB, {status["age_hours"]:.1f}h old')
            return 0
        c_files = transpile_with_cython(modules)
        write_cache(cache_dir, c_files, cache_key, modules)
        # Clean .c from source tree — cache is the source of truth
        for _, c_path in c_files:
            c_path.unlink(missing_ok=True)
        print(f'\n✅ Transpilation complete. Cache at: {cache_dir}')
        print('   Run the platform builds now:  ./build.sh cython  or  ./build.sh linux-cython')
        return 0

    # ── Normal / skip-transpile build ──
    output_dir = Path(args.output_dir)
    std_dist = Path(tempfile.mkdtemp(prefix='reachable_std_'))
    build_lib = Path(tempfile.mkdtemp(prefix='reachable_cython_lib_'))

    skip_transpile = False
    if args.skip_transpile:
        # Validate cache before starting the (slow) standard wheel build
        status = cache_status(cache_dir)
        if not status['valid']:
            print(f'\n❌ --skip-transpile requested but cache is invalid: {status["reason"]}')
            print('   Run first: python building/build_cython_wheel.py --transpile-only')
            return 1
        print(f'  ✓ Cache valid: {status["file_count"]} .c files, '
              f'{status["total_mb"]:.1f} MB, key={status["cache_key"][:16]}...')
        skip_transpile = True
    else:
        # Auto-cache: if cache is valid and source unchanged, use it silently
        cache_key = _source_cache_key(modules)
        status = cache_status(cache_dir)
        if status['valid'] and status['cache_key'] == cache_key:
            print(f'  ✓ Cache hit (key={cache_key[:16]}...) — skipping Cython transpilation')
            skip_transpile = True
        # else: no cache or stale — full build, will re-transpile

    try:
        print(f'\n🔒 REACHABLE {get_version()} — Cython selective compilation')
        print(f'   Platform     : {get_platform_tag()}')
        print(f'   Python       : {get_python_tag()}')
        print(f'   Transpile    : {"from cache" if skip_transpile else "full (Cython)"}')
        print(f'   Packages     : {len(PROTECTED_PACKAGES)}\n')

        if skip_transpile:
            restore_from_cache(cache_dir)
        else:
            # Full path — will also write cache for future builds
            cache_key = _source_cache_key(modules)

        std_wheel = build_standard_wheel(std_dist)
        universal2 = getattr(args, 'universal2', False)
        so_map = compile_with_cython(modules, build_lib, skip_transpile=skip_transpile, universal2=universal2)

        if not skip_transpile:
            # Collect .c files that were just generated and cache them
            c_files = [(str(py.with_suffix('.c').relative_to(PROJECT_ROOT)), py.with_suffix('.c'))
                       for _, py in modules if py.with_suffix('.c').exists()]
            if c_files:
                write_cache(cache_dir, c_files, cache_key, modules)

        wheel_path = repack_wheel(std_wheel, so_map, output_dir, universal2=universal2)
        verify_wheel(wheel_path, so_map)

        print(f'\n✅ Wheel: {wheel_path}')
        return 0

    except Exception as e:
        print(f'\n❌ Build failed: {e}', file=sys.stderr)
        import traceback
        traceback.print_exc()
        return 1

    finally:
        shutil.rmtree(std_dist, ignore_errors=True)
        shutil.rmtree(build_lib, ignore_errors=True)
        cleanup_inplace_so()
        # Clean .c files restored from cache — source tree stays clean
        if skip_transpile:
            for _, py_path in modules:
                c_path = py_path.with_suffix('.c')
                c_path.unlink(missing_ok=True)


if __name__ == '__main__':
    sys.exit(main())
