#!/usr/bin/env python3
# Copyright (c) 2026 Sthenos Security. All rights reserved.
"""
License signing tool — internal use only. NOT shipped in wheel.

Four modes:

  1. Local file (manual signing):
     python tools/licensing/sign_license.py --type trial --days 30 \
       --private-key ~/.reachable/keys/license_private.pem \
       --out reachable/licensing/trial_license.json

  2. CI/CD (GitHub Actions — key from env var):
     python tools/licensing/sign_license.py --type trial --days 30 \
       --private-key-env STHENOS_LICENSE_SIGNING_KEY \
       --out reachable/licensing/trial_license.json

  3. Interactive (paste key when prompted):
     python tools/licensing/sign_license.py --type trial --days 30 \
       --out reachable/licensing/trial_license.json

  4. Dev license (properly signed, expires 2099):
     python tools/licensing/sign_license.py --type dev \
       --private-key ~/.reachable/keys/license_private.pem \
       --out ~/.reachable/license.json

Key generation (first time only):
     python tools/licensing/sign_license.py --gen-key
"""

import argparse
import base64
import json
import os
import re
import sys
import tempfile
import uuid
from datetime import datetime, timedelta, timezone
from pathlib import Path

KEYS_DIR = Path.home() / '.reachable' / 'keys'
PRIVATE_KEY_FILE = KEYS_DIR / 'license_private.pem'
PUBLIC_KEY_FILE = KEYS_DIR / 'license_public.pem'

DEV_EXPIRES = '2099-12-31T00:00:00Z'


def _normalize_pem(pem: str) -> str:
    """Normalize a PEM string from any transport format into proper RFC 7468 form.

    Handles all known transport encodings:
      - Raw PEM (ideal case)
      - Hex-encoded PEM (macOS keychain `security` command output)
      - Base64-encoded PEM (some secret managers double-encode)
      - Literal \\n sequences (GitHub Secrets)
      - CRLF line endings
      - Whitespace corruption in the base64 body
    """
    import binascii
    pem = pem.strip()

    # If it doesn't start with '-', it's encoded — try to decode
    if pem and not pem.startswith('-'):
        # Try hex first (macOS keychain returns hex)
        try:
            candidate = binascii.unhexlify(pem).decode('ascii')
            if '-----BEGIN' in candidate:
                pem = candidate
        except Exception:
            pass

        # Try base64 (some secret managers double-encode)
        if not pem.startswith('-'):
            try:
                import base64 as _b64
                candidate = _b64.b64decode(pem).decode('ascii')
                if '-----BEGIN' in candidate:
                    pem = candidate
            except Exception:
                pass

    # Restore literal \n sequences injected by secret storage / env vars
    pem = pem.replace('\\n', '\n').replace('\r\n', '\n').strip()

    m = re.match(
        r'-----BEGIN ([^-]+)-----([\s\S]+?)-----END ([^-]+)-----',
        pem,
    )
    if not m:
        return pem  # not recognizable PEM — return as-is and let caller fail clearly

    key_type = m.group(1).strip()
    body = re.sub(r'\s+', '', m.group(2))  # strip ALL whitespace from base64 body
    chunks = [body[i:i + 64] for i in range(0, len(body), 64)]
    return f'-----BEGIN {key_type}-----\n' + '\n'.join(chunks) + f'\n-----END {key_type}-----\n'


def gen_keypair():
    """Generate Ed25519 keypair and save to ~/.reachable/keys/."""
    try:
        from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
        from cryptography.hazmat.primitives.serialization import (
            Encoding,
            NoEncryption,
            PrivateFormat,
            PublicFormat,
        )
    except ImportError:
        print('ERROR: pip install cryptography', file=sys.stderr)
        sys.exit(1)

    if PRIVATE_KEY_FILE.exists():
        print(f'ERROR: Private key already exists: {PRIVATE_KEY_FILE}')
        print('Delete it first to regenerate (WARNING: invalidates all existing licenses)')
        sys.exit(1)

    KEYS_DIR.mkdir(parents=True, exist_ok=True)
    KEYS_DIR.chmod(0o700)

    priv = Ed25519PrivateKey.generate()
    pub = priv.public_key()

    PRIVATE_KEY_FILE.write_bytes(priv.private_bytes(Encoding.PEM, PrivateFormat.PKCS8, NoEncryption()))
    PRIVATE_KEY_FILE.chmod(0o600)
    PUBLIC_KEY_FILE.write_bytes(pub.public_bytes(Encoding.PEM, PublicFormat.SubjectPublicKeyInfo))

    print('Keypair generated')
    print(f'  Private : {PRIVATE_KEY_FILE}')
    print(f'  Public  : {PUBLIC_KEY_FILE}')
    print()
    print('Next: copy the public key below into reachable/licensing/_public_key.py')
    print()
    print(PUBLIC_KEY_FILE.read_text())


def sign_license(license_type, private_key_path=None, days=None, customer=None, email=None, features=None, private_key_bytes=None):
    from cryptography.hazmat.primitives.serialization import load_pem_private_key

    if private_key_bytes is not None:
        pem_str = _normalize_pem(private_key_bytes.decode() if isinstance(private_key_bytes, bytes) else private_key_bytes)
        priv = load_pem_private_key(pem_str.encode(), password=None)
    else:
        raw = Path(private_key_path).read_text()
        pem_str = _normalize_pem(raw)
        priv = load_pem_private_key(pem_str.encode(), password=None)
    now = datetime.now(timezone.utc)

    if license_type == 'trial':
        expires_at = None
        duration_days = days
    elif license_type == 'dev':
        expires_at = DEV_EXPIRES
        duration_days = None
        customer = customer or 'sthenos-dev'
        email = email or 'dev@sthenosec.com'
    else:
        # annual / enterprise — absolute expiry baked into signed payload
        expires_at = (now + timedelta(days=days)).strftime('%Y-%m-%dT%H:%M:%SZ')
        duration_days = None

    payload = {
        'license_id': str(uuid.uuid4()),
        'license_type': license_type,
        'issued_at': now.strftime('%Y-%m-%dT%H:%M:%SZ'),
        'duration_days': duration_days,
        'expires_at': expires_at,
        'customer': customer,
        'email': email,
        'features': features,
    }

    canonical = json.dumps(payload, sort_keys=True, separators=(',', ':')).encode()
    sig = priv.sign(canonical)
    payload['signature'] = base64.urlsafe_b64encode(sig).rstrip(b'=').decode()
    return payload


def main():
    parser = argparse.ArgumentParser(description='Sthenos license signing tool')
    parser.add_argument('--gen-key', action='store_true', help='Generate Ed25519 keypair (first time only)')
    parser.add_argument('--type', choices=['trial', 'annual', 'enterprise', 'dev'])
    parser.add_argument('--days', type=int, default=30, help='Duration in days (trial/annual/enterprise)')
    parser.add_argument('--customer', default=None)
    parser.add_argument('--email', default=None)
    parser.add_argument('--private-key', default=None, help='Path to private key PEM')
    parser.add_argument('--private-key-env', default=None, help='Env var containing PEM contents (CI/CD)')
    parser.add_argument('--out', default=None, help='Output license.json path')
    parser.add_argument('--features', default=None, help='JSON features object')
    args = parser.parse_args()

    if args.gen_key:
        gen_keypair()
        return

    if not args.type:
        parser.error('--type is required')
    if not args.out:
        parser.error('--out is required')

    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)

    # Resolve private key
    key_path = None
    tmp_file = None

    if args.private_key:
        if not Path(args.private_key).exists():
            print(f'ERROR: private key not found: {args.private_key}', file=sys.stderr)
            sys.exit(1)
        key_path = args.private_key

    elif args.private_key_env:
        pem = os.environ.get(args.private_key_env, '')
        if not pem:
            print(f'ERROR: env var {args.private_key_env} is empty', file=sys.stderr)
            sys.exit(1)
        pem = _normalize_pem(pem)
        tmp_file = tempfile.NamedTemporaryFile(mode='w', suffix='.pem', delete=False)
        tmp_file.write(pem)
        tmp_file.close()
        key_path = tmp_file.name

    else:
        # Interactive — paste PEM
        print('Paste private key PEM then press Ctrl-D:')
        lines = []
        try:
            while True:
                lines.append(input())
        except EOFError:
            pass
        pem = '\n'.join(lines)
        if 'BEGIN' not in pem:
            print('ERROR: invalid PEM', file=sys.stderr)
            sys.exit(1)
        tmp_file = tempfile.NamedTemporaryFile(mode='w', suffix='.pem', delete=False)
        tmp_file.write(pem)
        tmp_file.close()
        key_path = tmp_file.name

    if args.type not in ('trial', 'dev') and not args.customer:
        print('ERROR: --customer is required for annual/enterprise licenses', file=sys.stderr)
        sys.exit(1)

    features = json.loads(args.features) if args.features else None

    try:
        lic = sign_license(
            license_type=args.type,
            private_key_path=key_path,
            days=args.days,
            customer=args.customer,
            email=args.email,
            features=features,
        )
    finally:
        if tmp_file:
            Path(tmp_file.name).unlink(missing_ok=True)

    out.write_text(json.dumps(lic, indent=2))

    print(f'License signed → {out}')
    print(f'  Type    : {lic["license_type"]}')
    print(f'  ID      : {lic["license_id"]}')
    print(f'  Customer: {lic["customer"] or "(trial)"}')
    if lic['expires_at']:
        print(f'  Expires : {lic["expires_at"]}')
    else:
        print(f'  Duration: {lic["duration_days"]} days from first install')


if __name__ == '__main__':
    main()
