#!/usr/bin/env python3
"""
load_signing_key.py — decode and write the signing key from env var.

Handles:
  1. Raw PEM (real newlines or literal \\n from GitHub Secrets)
  2. base64-encoded PEM

Usage:
  python load_signing_key.py <env_var_name> <output_path>
"""

import base64
import os
import sys


def load_key(pem_bytes: bytes):
    from cryptography.hazmat.primitives.serialization import load_pem_private_key
    return load_pem_private_key(pem_bytes, password=None)


def decode_key(raw: str) -> bytes:
    # Restore literal \n sequences GitHub Secrets may inject
    restored = raw.replace('\\n', '\n').strip()

    # Try 1: raw PEM
    try:
        load_key(restored.encode())
        return restored.encode()
    except Exception:
        pass

    # Try 2: hex-encoded PEM (macOS keychain `security find-generic-password -w` returns hex)
    try:
        import binascii
        decoded = binascii.unhexlify(restored.replace('\n', '').strip())
        load_key(decoded)
        return decoded
    except Exception:
        pass

    # Try 3: base64-encoded PEM
    try:
        decoded = base64.b64decode(restored + '==')
        load_key(decoded)
        return decoded
    except Exception:
        pass

    raise ValueError(
        f"Could not load signing key as raw PEM, hex-encoded PEM, or base64-encoded PEM.\n"
        f"First 80 chars: {repr(raw[:80])}"
    )


def main():
    if len(sys.argv) != 3:
        print(f"Usage: {sys.argv[0]} <env_var_name> <output_path>", file=sys.stderr)
        sys.exit(1)

    env_var, out_path = sys.argv[1], sys.argv[2]
    raw = os.environ.get(env_var, '')
    if not raw:
        print(f"ERROR: env var '{env_var}' is empty or not set", file=sys.stderr)
        sys.exit(1)

    try:
        pem_bytes = decode_key(raw)
    except ValueError as e:
        print(f"ERROR: {e}", file=sys.stderr)
        sys.exit(1)

    with open(out_path, 'wb') as f:
        f.write(pem_bytes)
    os.chmod(out_path, 0o600)
    print(f"✅ Key written to {out_path}")


if __name__ == '__main__':
    main()
