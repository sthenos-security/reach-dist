#!/usr/bin/env python3
# Copyright (c) 2026 Sthenos Security. All rights reserved.
"""
License system test suite.

Tests every code path in licensing/verifier.py without touching
the real ~/.reachable/license.json or install stamp.

Usage:
    python3 scripts/test_license.py
    python3 scripts/test_license.py -v   # verbose
"""

import base64
import json
import sys
import tempfile
from datetime import datetime, timedelta, timezone
from pathlib import Path
from unittest.mock import patch

# Ensure repo root is on path
sys.path.insert(0, str(Path(__file__).parent.parent))

VERBOSE = "-v" in sys.argv

PASS = "\033[32m✓\033[0m"
FAIL = "\033[31m✗\033[0m"
SKIP = "\033[33m~\033[0m"

results = []


def test(name, fn):
    try:
        fn()
        results.append((True, name, None))
        print(f"  {PASS}  {name}")
    except AssertionError as e:
        results.append((False, name, str(e)))
        print(f"  {FAIL}  {name}")
        if VERBOSE:
            print(f"       AssertionError: {e}")
    except Exception as e:
        results.append((False, name, f"{type(e).__name__}: {e}"))
        print(f"  {FAIL}  {name}")
        if VERBOSE:
            import traceback
            traceback.print_exc()


# ── Helpers ───────────────────────────────────────────────────────────────

def _load_private_key():
    """Load the Ed25519 private key from the keys/ directory."""
    keys_dir = Path(__file__).parent.parent / "reachable" / "licensing" / "keys"
    for candidate in ["sthenos-private.pem", "private.pem", "ed25519_private.pem"]:
        p = keys_dir / candidate
        if p.exists():
            from cryptography.hazmat.primitives.serialization import load_pem_private_key
            return load_pem_private_key(p.read_bytes(), password=None)
    return None


def _sign(payload: bytes) -> str:
    """Sign payload with the private key, return base64url signature."""
    priv = _load_private_key()
    if priv is None:
        raise RuntimeError("Private key not found in reachable/licensing/keys/")
    sig = priv.sign(payload)
    return base64.urlsafe_b64encode(sig).rstrip(b"=").decode()


def _make_license(license_type="trial", duration_days=30, expires_at=None,
                  customer=None, email=None, features=None,
                  issued_at=None, sign=True, bad_sig=False) -> dict:
    """Build a license dict, optionally signed."""
    import uuid

    from reachable.licensing.schema import LicenseFile
    lic = LicenseFile(
        license_id=str(uuid.uuid4()),
        license_type=license_type,
        issued_at=issued_at or datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
        duration_days=duration_days,
        expires_at=expires_at,
        customer=customer,
        email=email,
        features=features,
        signature="",
    )
    if sign:
        sig = _sign(lic.canonical_payload())
        lic.signature = "BADSIG_TAMPERED" if bad_sig else sig
    else:
        lic.signature = "UNSIGNED"
    return lic.to_dict()


def _patch_paths(tmp: Path, license_data: dict = None, stamp_data: dict = None,
                 bundled_trial: Path = None):
    """
    Return a context manager that patches LICENSE_FILE, LICENSE_DIR,
    INSTALL_STAMP_FILE, and BUNDLED_TRIAL to point into a temp directory.

    BUNDLED_TRIAL is patched to a nonexistent path by default so that
    _ensure_license_installed() never auto-installs during tests unless
    you explicitly pass bundled_trial=<real_path>.
    """
    import unittest.mock as mock

    lic_dir = tmp / "reachable"
    lic_dir.mkdir(parents=True, exist_ok=True)
    lic_file = lic_dir / "license.json"
    stamp_file = lic_dir / ".license_install"

    if license_data is not None:
        lic_file.write_text(json.dumps(license_data))
    if stamp_data is not None:
        stamp_file.write_text(json.dumps(stamp_data))

    # Default: point to a nonexistent file so auto-install never fires
    _bundled = bundled_trial if bundled_trial is not None else (tmp / "no_bundled_trial.json")

    return mock.patch.multiple(
        "reachable.licensing.verifier",
        LICENSE_DIR=lic_dir,
        LICENSE_FILE=lic_file,
        INSTALL_STAMP_FILE=stamp_file,
        BUNDLED_TRIAL=_bundled,
    )


# ── Test groups ───────────────────────────────────────────────────────────

def run_schema_tests():
    print("\n[schema]")

    def t_canonical_payload_excludes_signature():
        from reachable.licensing.schema import LicenseFile
        lic = LicenseFile(
            license_id="x", license_type="trial", issued_at="2026-01-01T00:00:00Z",
            duration_days=30, expires_at=None, signature="SHOULDNOTAPPEAR"
        )
        payload = lic.canonical_payload()
        assert b"SHOULDNOTAPPEAR" not in payload, "signature must not be in canonical payload"
        d = json.loads(payload)
        assert "signature" not in d

    def t_canonical_payload_is_sorted():
        from reachable.licensing.schema import LicenseFile
        lic = LicenseFile(
            license_id="abc", license_type="annual", issued_at="2026-01-01T00:00:00Z",
            duration_days=None, expires_at="2027-01-01T00:00:00Z",
            customer="Acme", email="a@b.com", features={"scan": True},
            signature=""
        )
        payload1 = lic.canonical_payload()
        payload2 = lic.canonical_payload()
        assert payload1 == payload2, "canonical payload must be deterministic"

    def t_roundtrip():
        from reachable.licensing.schema import LicenseFile
        d = {
            "license_id": "test-123", "license_type": "trial",
            "issued_at": "2026-01-01T00:00:00Z", "duration_days": 30,
            "expires_at": None, "customer": None, "email": None,
            "features": None, "signature": "abc"
        }
        lic = LicenseFile.from_dict(d)
        assert lic.to_dict() == d

    test("canonical payload excludes signature", t_canonical_payload_excludes_signature)
    test("canonical payload is deterministic", t_canonical_payload_is_sorted)
    test("LicenseFile roundtrip from_dict/to_dict", t_roundtrip)


def run_signature_tests():
    print("\n[signature]")

    priv = _load_private_key()
    if priv is None:
        print(f"  {SKIP}  (skipping — private key not found in licensing/keys/)")
        results.append((None, "signature tests skipped — no private key", None))
        return

    def t_valid_sig():
        lic_dict = _make_license(sign=True)
        from reachable.licensing.schema import LicenseFile
        from reachable.licensing.verifier import _verify_signature
        lic = LicenseFile.from_dict(lic_dict)
        assert _verify_signature(lic) is True

    def t_bad_sig():
        lic_dict = _make_license(sign=True, bad_sig=True)
        from reachable.licensing.schema import LicenseFile
        from reachable.licensing.verifier import _verify_signature
        lic = LicenseFile.from_dict(lic_dict)
        assert _verify_signature(lic) is False

    def t_tampered_claims():
        """Modifying any claim after signing must invalidate the signature."""
        lic_dict = _make_license(sign=True, duration_days=30)
        lic_dict["duration_days"] = 36500  # tamper
        from reachable.licensing.schema import LicenseFile
        from reachable.licensing.verifier import _verify_signature
        lic = LicenseFile.from_dict(lic_dict)
        assert _verify_signature(lic) is False

    def t_tampered_customer():
        lic_dict = _make_license(sign=True, customer=None)
        lic_dict["customer"] = "Injected Corp"
        from reachable.licensing.schema import LicenseFile
        from reachable.licensing.verifier import _verify_signature
        lic = LicenseFile.from_dict(lic_dict)
        assert _verify_signature(lic) is False

    test("valid signature verifies", t_valid_sig)
    test("bad signature rejected", t_bad_sig)
    test("tampered duration_days rejected", t_tampered_claims)
    test("tampered customer rejected", t_tampered_customer)


def run_trial_tests():
    print("\n[trial license]")

    priv = _load_private_key()

    def t_trial_active():
        """Fresh trial — stamp written today, 30 days remaining."""
        if priv is None:
            # Use bundled trial license instead
            from reachable.licensing.verifier import BUNDLED_TRIAL
            lic_dict = json.loads(BUNDLED_TRIAL.read_bytes())
        else:
            lic_dict = _make_license(sign=True, duration_days=30)

        stamp = {"installed_at": datetime.now(timezone.utc).isoformat()}
        with tempfile.TemporaryDirectory() as tmp:
            with _patch_paths(Path(tmp), license_data=lic_dict, stamp_data=stamp):
                from reachable.licensing.verifier import check
                state = check()
        assert state.valid, f"expected valid, got: {state.error}"
        assert state.license_type == "trial"
        assert state.days_remaining >= 29  # allow for test clock drift

    def t_trial_expired():
        """Trial stamp is 31 days ago — should be expired."""
        if priv is None:
            from reachable.licensing.verifier import BUNDLED_TRIAL
            lic_dict = json.loads(BUNDLED_TRIAL.read_bytes())
        else:
            lic_dict = _make_license(sign=True, duration_days=30)

        old_stamp = datetime.now(timezone.utc) - timedelta(days=31)
        stamp = {"installed_at": old_stamp.isoformat()}
        with tempfile.TemporaryDirectory() as tmp:
            with _patch_paths(Path(tmp), license_data=lic_dict, stamp_data=stamp):
                from reachable.licensing.verifier import check
                state = check()
        assert not state.valid, "expired trial should be invalid"
        assert state.status == "expired"

    def t_trial_expiring_soon():
        """5 days left — should be expiring_soon."""
        if priv is None:
            from reachable.licensing.verifier import BUNDLED_TRIAL
            lic_dict = json.loads(BUNDLED_TRIAL.read_bytes())
        else:
            lic_dict = _make_license(sign=True, duration_days=30)

        stamp_dt = datetime.now(timezone.utc) - timedelta(days=25)
        stamp = {"installed_at": stamp_dt.isoformat()}
        with tempfile.TemporaryDirectory() as tmp:
            with _patch_paths(Path(tmp), license_data=lic_dict, stamp_data=stamp):
                from reachable.licensing.verifier import check
                state = check()
        assert state.valid
        assert state.status == "expiring_soon", f"expected expiring_soon, got {state.status}"

    def t_no_license_file():
        """No license file at all — should fail with helpful message."""
        with tempfile.TemporaryDirectory() as tmp:
            with _patch_paths(Path(tmp)):  # no license_data written
                from reachable.licensing.verifier import check
                state = check()
        assert not state.valid
        assert "No license found" in (state.error or "") or state.status == "invalid"

    test("trial active (fresh install)", t_trial_active)
    test("trial expired (31 days old stamp)", t_trial_expired)
    test("trial expiring_soon (5 days left)", t_trial_expiring_soon)
    test("no license file → invalid", t_no_license_file)


def run_annual_tests():
    print("\n[annual license]")

    priv = _load_private_key()
    if priv is None:
        print(f"  {SKIP}  (skipping annual signing tests — no private key)")
        results.append((None, "annual tests skipped — no private key", None))
        return

    def t_annual_active():
        future = (datetime.now(timezone.utc) + timedelta(days=365)).strftime("%Y-%m-%dT%H:%M:%SZ")
        lic_dict = _make_license(
            license_type="annual", duration_days=None,
            expires_at=future, customer="Acme Corp", email="sec@acme.com"
        )
        with tempfile.TemporaryDirectory() as tmp:
            with _patch_paths(Path(tmp), license_data=lic_dict):
                from reachable.licensing.verifier import check
                state = check()
        assert state.valid, f"expected valid: {state.error}"
        assert state.license_type == "annual"
        assert state.customer == "Acme Corp"
        assert state.days_remaining >= 364

    def t_annual_expired():
        past = (datetime.now(timezone.utc) - timedelta(days=10)).strftime("%Y-%m-%dT%H:%M:%SZ")
        lic_dict = _make_license(
            license_type="annual", duration_days=None,
            expires_at=past, customer="Acme Corp", email="sec@acme.com"
        )
        with tempfile.TemporaryDirectory() as tmp:
            with _patch_paths(Path(tmp), license_data=lic_dict):
                from reachable.licensing.verifier import check
                state = check()
        assert not state.valid
        assert state.status == "expired"

    def t_annual_tampered_expiry():
        """Extend expiry after signing — must be rejected."""
        future = (datetime.now(timezone.utc) + timedelta(days=365)).strftime("%Y-%m-%dT%H:%M:%SZ")
        lic_dict = _make_license(
            license_type="annual", duration_days=None,
            expires_at=future, customer="Acme Corp", email="sec@acme.com"
        )
        # Tamper: extend expiry to 100 years
        lic_dict["expires_at"] = "2126-01-01T00:00:00Z"
        with tempfile.TemporaryDirectory() as tmp:
            with _patch_paths(Path(tmp), license_data=lic_dict):
                from reachable.licensing.verifier import check
                state = check()
        assert not state.valid
        assert "tampered" in (state.error or "").lower() or state.status == "invalid"

    test("annual active", t_annual_active)
    test("annual expired", t_annual_expired)
    test("annual tampered expiry rejected", t_annual_tampered_expiry)


def run_install_tests():
    print("\n[license install / replace]")

    priv = _load_private_key()
    REAL_BUNDLED = Path(__file__).parent.parent / "reachable" / "licensing" / "trial_license.json"

    def t_bundled_trial_auto_installed():
        """
        On first run with no license file, _ensure_license_installed copies
        the bundled trial automatically.
        """
        if not REAL_BUNDLED.exists():
            raise AssertionError("trial_license.json not found — wheel packaging issue")
        stamp = {"installed_at": datetime.now(timezone.utc).isoformat()}
        with tempfile.TemporaryDirectory() as tmp:
            # Pass the real bundled trial so auto-install can fire
            with _patch_paths(Path(tmp), stamp_data=stamp, bundled_trial=REAL_BUNDLED):
                from reachable.licensing.verifier import check
                state = check()
        assert state.valid, f"bundled trial auto-install failed: {state.error}"
        assert state.license_type == "trial"

    def t_install_annual_over_trial():
        """
        User installs an annual license after using trial — new state should
        reflect annual type and the provided expiry.
        """
        if priv is None:
            return  # skipped below
        future = (datetime.now(timezone.utc) + timedelta(days=365)).strftime("%Y-%m-%dT%H:%M:%SZ")
        annual = _make_license(
            license_type="annual", duration_days=None,
            expires_at=future, customer="Beta Customer", email="beta@example.com"
        )
        # Start with trial already in place
        trial = _make_license(sign=True, duration_days=30) if priv else json.loads(REAL_BUNDLED.read_bytes())
        stamp = {"installed_at": datetime.now(timezone.utc).isoformat()}
        with tempfile.TemporaryDirectory() as tmp:
            tmp_path = Path(tmp)
            with _patch_paths(tmp_path, license_data=trial, stamp_data=stamp):
                from reachable.licensing.verifier import LICENSE_FILE, check
                # Simulate `reachctl license install` — overwrite license.json
                LICENSE_FILE.write_text(json.dumps(annual))
                state = check()
        assert state.valid, f"expected valid after install: {state.error}"
        assert state.license_type == "annual"
        assert state.customer == "Beta Customer"
        assert state.days_remaining >= 364

    def t_install_new_trial_resets_stamp():
        """
        Installing a fresh trial over an expired one should reset the clock.
        Stamp is old (31 days) → expired. After 'reinstall', new stamp → active.
        """
        if priv is None:
            lic_dict = json.loads(REAL_BUNDLED.read_bytes())
        else:
            lic_dict = _make_license(sign=True, duration_days=30)

        old_stamp = {"installed_at": (datetime.now(timezone.utc) - timedelta(days=31)).isoformat()}
        with tempfile.TemporaryDirectory() as tmp:
            tmp_path = Path(tmp)
            with _patch_paths(tmp_path, license_data=lic_dict, stamp_data=old_stamp):
                from reachable.licensing.verifier import INSTALL_STAMP_FILE, check
                # Verify it's expired first
                state_before = check()
                assert not state_before.valid and state_before.status == "expired"
                # Simulate trial reinstall: delete stamp (reachctl license install does this)
                INSTALL_STAMP_FILE.unlink(missing_ok=True)
                state_after = check()
        assert state_after.valid, f"expected valid after stamp reset: {state_after.error}"
        assert state_after.days_remaining >= 29

    def t_install_tampered_license_rejected():
        """
        A user-provided license with a bad signature must be rejected after install.
        """
        if priv is None:
            return  # skipped below
        bad = _make_license(sign=True, bad_sig=True, license_type="annual",
                            duration_days=None,
                            expires_at=(datetime.now(timezone.utc) + timedelta(days=365)).strftime("%Y-%m-%dT%H:%M:%SZ"))
        with tempfile.TemporaryDirectory() as tmp:
            with _patch_paths(Path(tmp), license_data=bad):
                from reachable.licensing.verifier import check
                state = check()
        assert not state.valid
        assert "tampered" in (state.error or "").lower() or "invalid" in (state.error or "").lower()

    test("bundled trial auto-installed on first run", t_bundled_trial_auto_installed)
    if priv is None:
        print(f"  {SKIP}  install annual over trial → annual state (no private key)")
        results.append((None, "install annual over trial skipped — no private key", None))
    else:
        test("install annual over trial → annual state", t_install_annual_over_trial)
    test("reinstall trial resets expiry clock", t_install_new_trial_resets_stamp)
    if priv is None:
        print(f"  {SKIP}  tampered license rejected after install (no private key)")
        results.append((None, "tampered license install skipped — no private key", None))
    else:
        test("tampered license rejected after install", t_install_tampered_license_rejected)


def run_bundled_trial_test():
    print("\n[bundled trial_license.json]")

    def t_bundled_sig_valid():
        """The shipped trial_license.json must have a valid signature."""
        from reachable.licensing.schema import LicenseFile
        from reachable.licensing.verifier import BUNDLED_TRIAL, _verify_signature
        lic_dict = json.loads(BUNDLED_TRIAL.read_bytes())
        lic = LicenseFile.from_dict(lic_dict)
        assert _verify_signature(lic) is True, "bundled trial signature is invalid!"

    def t_bundled_is_30_days():
        from reachable.licensing.verifier import BUNDLED_TRIAL
        lic_dict = json.loads(BUNDLED_TRIAL.read_bytes())
        assert lic_dict["duration_days"] == 30
        assert lic_dict["expires_at"] is None
        assert lic_dict["license_type"] == "trial"

    test("bundled trial_license.json signature is valid", t_bundled_sig_valid)
    test("bundled trial is 30-day relative", t_bundled_is_30_days)


def run_clock_tests():
    """
    Freeze datetime.now() inside the verifier to specific moments.
    This lets us test exact expiry boundaries for both trial and annual
    licenses without sleeping or manipulating real system time.
    """
    print("\n[clock / expiry boundary]")

    priv = _load_private_key()
    REAL_BUNDLED = Path(__file__).parent.parent / "reachable" / "licensing" / "trial_license.json"

    def _freeze(fake_now: datetime):
        """Patch datetime.now in the verifier to return fake_now.
        Subclasses real datetime so fromisoformat/arithmetic all still work.
        """
        from datetime import datetime as _real_datetime
        _frozen = fake_now.replace(tzinfo=timezone.utc)

        class _FakeDatetime(_real_datetime):
            @classmethod
            def now(cls, tz=None):
                return _frozen

        return patch("reachable.licensing.verifier.datetime", _FakeDatetime)

    # ── Annual license boundary tests ─────────────────────────────────

    def t_annual_active_one_day_before_expiry():
        if priv is None:
            raise AssertionError("no private key")
        expiry = datetime(2026, 6, 1, 0, 0, 0, tzinfo=timezone.utc)
        lic_dict = _make_license(
            license_type="annual", duration_days=None,
            expires_at=expiry.strftime("%Y-%m-%dT%H:%M:%SZ"),
            customer="Acme"
        )
        fake_now = expiry - timedelta(days=1)   # one day before
        with tempfile.TemporaryDirectory() as tmp:
            with _patch_paths(Path(tmp), license_data=lic_dict):
                with _freeze(fake_now):
                    from reachable.licensing.verifier import check
                    state = check()
        assert state.valid, f"should be valid 1 day before expiry: {state.error}"
        assert state.days_remaining == 1
        assert state.status == "expiring_soon"   # within 7-day window

    def t_annual_expires_exactly_now():
        """When now == expiry the license is expired."""
        if priv is None:
            raise AssertionError("no private key")
        expiry = datetime(2026, 6, 1, 12, 0, 0, tzinfo=timezone.utc)
        lic_dict = _make_license(
            license_type="annual", duration_days=None,
            expires_at=expiry.strftime("%Y-%m-%dT%H:%M:%SZ"),
            customer="Acme"
        )
        with tempfile.TemporaryDirectory() as tmp:
            with _patch_paths(Path(tmp), license_data=lic_dict):
                with _freeze(expiry):             # now == expiry
                    from reachable.licensing.verifier import check
                    state = check()
        assert not state.valid
        assert state.status == "expired"

    def t_annual_expired_one_second_ago():
        if priv is None:
            raise AssertionError("no private key")
        expiry = datetime(2026, 6, 1, 0, 0, 0, tzinfo=timezone.utc)
        lic_dict = _make_license(
            license_type="annual", duration_days=None,
            expires_at=expiry.strftime("%Y-%m-%dT%H:%M:%SZ"),
            customer="Acme"
        )
        fake_now = expiry + timedelta(seconds=1)  # one second past
        with tempfile.TemporaryDirectory() as tmp:
            with _patch_paths(Path(tmp), license_data=lic_dict):
                with _freeze(fake_now):
                    from reachable.licensing.verifier import check
                    state = check()
        assert not state.valid
        assert state.status == "expired"

    def t_annual_active_7_days_before_expiry():
        """Exactly 7 days remaining → expiring_soon."""
        if priv is None:
            raise AssertionError("no private key")
        expiry = datetime(2026, 6, 1, 0, 0, 0, tzinfo=timezone.utc)
        lic_dict = _make_license(
            license_type="annual", duration_days=None,
            expires_at=expiry.strftime("%Y-%m-%dT%H:%M:%SZ"),
            customer="Acme"
        )
        fake_now = expiry - timedelta(days=7)
        with tempfile.TemporaryDirectory() as tmp:
            with _patch_paths(Path(tmp), license_data=lic_dict):
                with _freeze(fake_now):
                    from reachable.licensing.verifier import check
                    state = check()
        assert state.valid
        assert state.days_remaining == 7
        assert state.status == "expiring_soon"

    def t_annual_active_8_days_before_expiry():
        """8 days remaining → still 'active' (above threshold)."""
        if priv is None:
            raise AssertionError("no private key")
        expiry = datetime(2026, 6, 1, 0, 0, 0, tzinfo=timezone.utc)
        lic_dict = _make_license(
            license_type="annual", duration_days=None,
            expires_at=expiry.strftime("%Y-%m-%dT%H:%M:%SZ"),
            customer="Acme"
        )
        fake_now = expiry - timedelta(days=8)
        with tempfile.TemporaryDirectory() as tmp:
            with _patch_paths(Path(tmp), license_data=lic_dict):
                with _freeze(fake_now):
                    from reachable.licensing.verifier import check
                    state = check()
        assert state.valid
        assert state.days_remaining == 8
        assert state.status == "active"

    # ── Trial license clock tests ──────────────────────────────────────
    # Trial expiry = install_stamp + duration_days.
    # We freeze *now* and set the stamp to a known past time.

    def t_trial_exactly_on_expiry_day():
        """now == stamp + 30d → expired."""
        lic_dict = (_make_license(sign=True, duration_days=30) if priv
                    else json.loads(REAL_BUNDLED.read_bytes()))
        install_time = datetime(2026, 1, 1, 0, 0, 0, tzinfo=timezone.utc)
        fake_now = install_time + timedelta(days=30)   # exactly on expiry
        stamp = {"installed_at": install_time.isoformat()}
        with tempfile.TemporaryDirectory() as tmp:
            with _patch_paths(Path(tmp), license_data=lic_dict, stamp_data=stamp):
                with _freeze(fake_now):
                    from reachable.licensing.verifier import check
                    state = check()
        assert not state.valid
        assert state.status == "expired"

    def t_trial_one_day_before_expiry():
        lic_dict = (_make_license(sign=True, duration_days=30) if priv
                    else json.loads(REAL_BUNDLED.read_bytes()))
        install_time = datetime(2026, 1, 1, 0, 0, 0, tzinfo=timezone.utc)
        fake_now = install_time + timedelta(days=29)   # one day before
        stamp = {"installed_at": install_time.isoformat()}
        with tempfile.TemporaryDirectory() as tmp:
            with _patch_paths(Path(tmp), license_data=lic_dict, stamp_data=stamp):
                with _freeze(fake_now):
                    from reachable.licensing.verifier import check
                    state = check()
        assert state.valid
        assert state.days_remaining == 1
        assert state.status == "expiring_soon"

    def t_trial_day_zero():
        """Installed today, now == install time → 30 days remaining."""
        lic_dict = (_make_license(sign=True, duration_days=30) if priv
                    else json.loads(REAL_BUNDLED.read_bytes()))
        install_time = datetime(2026, 3, 6, 10, 0, 0, tzinfo=timezone.utc)
        fake_now = install_time          # same moment
        stamp = {"installed_at": install_time.isoformat()}
        with tempfile.TemporaryDirectory() as tmp:
            with _patch_paths(Path(tmp), license_data=lic_dict, stamp_data=stamp):
                with _freeze(fake_now):
                    from reachable.licensing.verifier import check
                    state = check()
        assert state.valid
        assert state.days_remaining == 30
        assert state.status == "active"

    # ── Dev license ────────────────────────────────────────────────────

    def t_dev_license_active_in_2099():
        """Freeze clock to 2098 — dev license (expires 2099) must still be active."""
        if priv is None:
            raise AssertionError("no private key")
        dev_lic = _make_license(
            license_type="dev", duration_days=None,
            expires_at="2099-12-31T00:00:00Z",
            customer="sthenos-dev"
        )
        fake_now = datetime(2098, 6, 1, 0, 0, 0, tzinfo=timezone.utc)
        with tempfile.TemporaryDirectory() as tmp:
            with _patch_paths(Path(tmp), license_data=dev_lic):
                with _freeze(fake_now):
                    from reachable.licensing.verifier import check
                    state = check()
        assert state.valid, f"dev license should be valid in 2098: {state.error}"
        assert state.license_type == "dev"

    def t_dev_license_expired_in_2100():
        """Freeze clock past 2099 — even dev license must expire."""
        if priv is None:
            raise AssertionError("no private key")
        dev_lic = _make_license(
            license_type="dev", duration_days=None,
            expires_at="2099-12-31T00:00:00Z",
            customer="sthenos-dev"
        )
        fake_now = datetime(2100, 1, 1, 0, 0, 0, tzinfo=timezone.utc)
        with tempfile.TemporaryDirectory() as tmp:
            with _patch_paths(Path(tmp), license_data=dev_lic):
                with _freeze(fake_now):
                    from reachable.licensing.verifier import check
                    state = check()
        assert not state.valid
        assert state.status == "expired"

    if priv is None:
        _skip_msg = "(skipping clock tests that require signing — no private key)"
        annual_tests = [
            "annual active 1 day before expiry",
            "annual expires exactly now → expired",
            "annual expired 1 second ago",
            "annual 7 days remaining → expiring_soon",
            "annual 8 days remaining → active",
            "dev license active in year 2098",
            "dev license expired in year 2100",
        ]
        print(f"  {SKIP}  {_skip_msg}")
        for name in annual_tests:
            results.append((None, name, None))
    else:
        test("annual: active 1 day before expiry",     t_annual_active_one_day_before_expiry)
        test("annual: expires exactly now → expired",   t_annual_expires_exactly_now)
        test("annual: expired 1 second ago",            t_annual_expired_one_second_ago)
        test("annual: 7 days remaining → expiring_soon", t_annual_active_7_days_before_expiry)
        test("annual: 8 days remaining → active",       t_annual_active_8_days_before_expiry)
        test("dev: active in year 2098",                t_dev_license_active_in_2099)
        test("dev: expired in year 2100",               t_dev_license_expired_in_2100)

    # Trial clock tests work with or without private key
    test("trial: exactly on expiry day → expired",   t_trial_exactly_on_expiry_day)
    test("trial: 1 day before expiry → expiring_soon", t_trial_one_day_before_expiry)
    test("trial: day 0 (just installed) → 30 days",  t_trial_day_zero)


def run_banner_test():
    print("\n[banner]")

    def t_trial_banner():
        from reachable.licensing.schema import LicenseState
        s = LicenseState(valid=True, license_id="x", license_type="trial",
                         customer=None, email=None, expires_at="2026-04-01T00:00:00Z",
                         days_remaining=15, status="active")
        assert "Trial" in s.banner
        assert "15 days" in s.banner

    def t_expiring_banner():
        from reachable.licensing.schema import LicenseState
        s = LicenseState(valid=True, license_id="x", license_type="annual",
                         customer="Acme", email=None, expires_at="2026-03-10T00:00:00Z",
                         days_remaining=5, status="expiring_soon")
        assert "expir" in s.banner.lower()
        assert "5 day" in s.banner

    def t_invalid_banner():
        from reachable.licensing.schema import LicenseState
        s = LicenseState(valid=False, license_id="", license_type="",
                         customer=None, email=None, expires_at="",
                         days_remaining=0, status="invalid",
                         error="No license found.")
        assert "No license found" in s.banner

    test("trial banner format", t_trial_banner)
    test("expiring_soon banner format", t_expiring_banner)
    test("invalid banner shows error", t_invalid_banner)


# ── Main ──────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    print("=" * 60)
    print("  REACHABLE License System Tests")
    print("=" * 60)

    run_schema_tests()
    run_signature_tests()
    run_bundled_trial_test()
    run_trial_tests()
    run_annual_tests()
    run_install_tests()
    run_clock_tests()
    run_banner_test()

    print("\n" + "=" * 60)
    passed = sum(1 for ok, _, _ in results if ok is True)
    failed = sum(1 for ok, _, _ in results if ok is False)
    skipped = sum(1 for ok, _, _ in results if ok is None)
    total = passed + failed
    print(f"  {passed}/{total} passed", end="")
    if skipped:
        print(f"  ({skipped} skipped)", end="")
    if failed:
        print(f"  \033[31m{failed} FAILED\033[0m", end="")
        print()
        print()
        for ok, name, err in results:
            if ok is False:
                print(f"  FAIL: {name}")
                print(f"        {err}")
    print()
    sys.exit(0 if failed == 0 else 1)
