# REACHABLE DLP Security Module - PII Taint Sources
# Copyright (c) 2026 Sthenos Security. All rights reserved.

"""
PII Taint Sources - Origins of sensitive data in code.

Categories:
- User Input: Forms, HTTP requests, CLI input
- Database: Query results containing user data
- Session/Auth: User sessions, authentication tokens
- External: API responses, file reads
- Internal: Variables/attributes containing PII

Usage:
    from reachable.dlp.taint.sources import PIISourceType, PYTHON_PII_SOURCES

from reachable.logger import logger
    
    # Find PII sources in code
    for source_type, patterns in PYTHON_PII_SOURCES.items():
        for pattern in patterns:
            if re.search(pattern, line):
                logger.info(f"Found {source_type.value} source")
"""

import re

from dataclasses import dataclass, field
from enum import Enum
from typing import List, Dict, Optional


class PIISourceType(Enum):
    """Types of PII data sources."""
    
    # HTTP/Web sources
    HTTP_FORM = "http_form"              # request.form, form data
    HTTP_JSON = "http_json"              # request.json, JSON body
    HTTP_QUERY = "http_query"            # request.args, query params
    HTTP_HEADER = "http_header"          # request.headers (auth, cookies)
    
    # User session
    USER_SESSION = "user_session"        # session.user, current_user
    USER_AUTH = "user_auth"              # authentication tokens
    
    # Database
    DB_QUERY = "db_query"                # cursor.fetchall(), ORM queries
    DB_MODEL = "db_model"                # User.query, Model.get()
    
    # File/External
    FILE_READ = "file_read"              # open().read(), CSV/JSON files
    API_RESPONSE = "api_response"        # requests.get().json()
    
    # PII-specific attributes
    PII_ATTRIBUTE = "pii_attribute"      # .ssn, .credit_card, .email
    PII_DICT_KEY = "pii_dict_key"        # data['ssn'], user['email']
    PII_VARIABLE = "pii_variable"        # ssn = ..., credit_card = ...
    
    # Environment
    ENVIRONMENT = "environment"          # os.environ, env vars
    
    # Message queues
    MESSAGE_QUEUE = "message_queue"      # kafka, rabbitmq messages


@dataclass
class PIISource:
    """A source of PII data in code."""
    source_type: PIISourceType
    location: str                        # file:line
    variable: str                        # Variable name
    pii_type: str = ""                   # Detected PII type (ssn, email, etc.)
    confidence: float = 1.0
    context: str = ""                    # Surrounding code context


# =============================================================================
# PYTHON PII SOURCE PATTERNS
# =============================================================================

# PII attribute/key names to detect
PII_ATTRIBUTES = [
    'ssn', 'social_security', 'social_security_number',
    'credit_card', 'creditcard', 'card_number', 'pan',
    'cvv', 'cvc', 'security_code',
    'bank_account', 'account_number', 'routing_number', 'iban',
    'email', 'email_address', 'user_email',
    'phone', 'phone_number', 'mobile', 'telephone',
    'address', 'street_address', 'mailing_address', 'home_address',
    'dob', 'date_of_birth', 'birthdate', 'birthday',
    'passport', 'passport_number',
    'drivers_license', 'license_number', 'dl_number',
    'tax_id', 'ein', 'tin',
    'mrn', 'medical_record', 'patient_id',
    'npi', 'provider_id',
    'password', 'passwd', 'pwd', 'secret',
    'api_key', 'apikey', 'auth_token',
    'first_name', 'last_name', 'full_name', 'name',
    'ip_address', 'ipaddress', 'client_ip',
    'user_data', 'personal_info', 'pii', 'sensitive_data',
]

# Build regex patterns for PII attributes
_pii_attr_pattern = '|'.join(PII_ATTRIBUTES)

PYTHON_PII_SOURCES: Dict[PIISourceType, List[str]] = {
    # HTTP/Web sources
    PIISourceType.HTTP_FORM: [
        r'request\.form\[',
        r'request\.form\.get\(',
        r'request\.values\[',
        r'request\.values\.get\(',
        r'form\.data',
        r'form\.cleaned_data',  # Django
        r'Form\([^)]*\)\.data',
    ],
    PIISourceType.HTTP_JSON: [
        r'request\.json',
        r'request\.get_json\(',
        r'request\.data',  # Flask/FastAPI
        r'await request\.json\(',
        r'body\s*=\s*await\s+request\.body\(',
        r'Body\(',  # FastAPI
    ],
    PIISourceType.HTTP_QUERY: [
        r'request\.args\[',
        r'request\.args\.get\(',
        r'request\.params\[',
        r'request\.query_params',
        r'Query\(',  # FastAPI
    ],
    PIISourceType.HTTP_HEADER: [
        r'request\.headers\[',
        r'request\.headers\.get\(',
        r'request\.cookies\[',
        r'request\.cookies\.get\(',
        r'Header\(',  # FastAPI
    ],
    
    # User session
    PIISourceType.USER_SESSION: [
        r'session\[',
        r'session\.get\(',
        r'current_user\.',
        r'g\.user\.',  # Flask
        r'request\.user\.',  # Django
        r'flask_login\.current_user',
    ],
    PIISourceType.USER_AUTH: [
        r'jwt\.decode\(',
        r'decode_token\(',
        r'get_current_user\(',
        r'authenticate\(',
        r'credentials\.',
    ],
    
    # Database
    PIISourceType.DB_QUERY: [
        r'cursor\.fetchone\(',
        r'cursor\.fetchall\(',
        r'cursor\.fetchmany\(',
        r'\.execute\([^)]+\)\.fetch',
        r'connection\.execute\(',
        r'session\.execute\(',  # SQLAlchemy
        r'pd\.read_sql\(',  # Pandas
    ],
    PIISourceType.DB_MODEL: [
        r'User\.query\.',
        r'User\.objects\.',  # Django ORM
        r'User\.get\(',
        r'\.filter\([^)]+\)\.first\(',
        r'\.filter_by\([^)]+\)\.first\(',
        r'get_user_by_',
        r'find_user\(',
        r'Customer\.query\.',
        r'Patient\.query\.',
    ],
    
    # File/External
    PIISourceType.FILE_READ: [
        r'open\([^)]+\)\.read',
        r'Path\([^)]+\)\.read_text',
        r'\.read_csv\(',
        r'\.read_json\(',
        r'\.read_excel\(',
        r'json\.load\(',
        r'csv\.reader\(',
        r'csv\.DictReader\(',
    ],
    PIISourceType.API_RESPONSE: [
        r'requests\.get\([^)]+\)\.json\(',
        r'requests\.post\([^)]+\)\.json\(',
        r'httpx\.\w+\([^)]+\)\.json\(',
        r'response\.json\(',
        r'aiohttp\.\w+\([^)]+\)\.json\(',
    ],
    
    # PII-specific patterns
    PIISourceType.PII_ATTRIBUTE: [
        # user.ssn, data.credit_card, etc.
        rf'\.({_pii_attr_pattern})\b',
    ],
    PIISourceType.PII_DICT_KEY: [
        # data['ssn'], user['email'], etc.
        rf'\[\s*["\']({_pii_attr_pattern})["\']\s*\]',
        rf'\.get\(\s*["\']({_pii_attr_pattern})["\']',
    ],
    PIISourceType.PII_VARIABLE: [
        # ssn = ..., credit_card = ...
        rf'\b({_pii_attr_pattern})\s*=\s*',
    ],
    
    # Environment
    PIISourceType.ENVIRONMENT: [
        r'os\.environ\[',
        r'os\.environ\.get\(',
        r'os\.getenv\(',
        r'environ\[',
    ],
    
    # Message queues
    PIISourceType.MESSAGE_QUEUE: [
        r'\.consume\(',
        r'\.receive\(',
        r'consumer\.poll\(',
        r'channel\.basic_get\(',
        r'queue\.get\(',
    ],
}


# =============================================================================
# TYPESCRIPT/JAVASCRIPT PII SOURCE PATTERNS
# =============================================================================

TYPESCRIPT_PII_SOURCES: Dict[PIISourceType, List[str]] = {
    # HTTP/Web sources
    PIISourceType.HTTP_FORM: [
        r'req\.body\.',
        r'request\.body\.',
        r'formData\.get\(',
        r'new FormData\(',
    ],
    PIISourceType.HTTP_JSON: [
        r'req\.body',
        r'await req\.json\(',
        r'await request\.json\(',
        r'JSON\.parse\(.*body',
    ],
    PIISourceType.HTTP_QUERY: [
        r'req\.query\.',
        r'req\.params\.',
        r'request\.query\.',
        r'searchParams\.get\(',
        r'URLSearchParams',
    ],
    PIISourceType.HTTP_HEADER: [
        r'req\.headers\[',
        r'req\.headers\.',
        r'request\.headers\.',
        r'req\.cookies\.',
    ],
    
    # User session
    PIISourceType.USER_SESSION: [
        r'session\.',
        r'req\.session\.',
        r'req\.user\.',
        r'currentUser\.',
        r'getSession\(',
    ],
    PIISourceType.USER_AUTH: [
        r'jwt\.decode\(',
        r'verifyToken\(',
        r'authenticate\(',
        r'getUser\(',
    ],
    
    # Database
    PIISourceType.DB_QUERY: [
        r'\.query\([^)]+\)',
        r'\.findOne\(',
        r'\.findMany\(',
        r'\.find\(\{',
        r'prisma\.\w+\.findUnique',
        r'db\.query\(',
    ],
    PIISourceType.DB_MODEL: [
        r'User\.find',
        r'User\.get',
        r'Customer\.find',
        r'Patient\.find',
    ],
    
    # File/External
    PIISourceType.FILE_READ: [
        r'fs\.readFile',
        r'readFileSync\(',
        r'\.text\(\)',
        r'\.json\(\)',
    ],
    PIISourceType.API_RESPONSE: [
        r'fetch\([^)]+\)\.then\([^)]+\.json',
        r'await fetch\([^)]+\)\.json\(',
        r'axios\.\w+\([^)]+\)\.then',
        r'response\.data',
    ],
    
    # PII-specific patterns
    PIISourceType.PII_ATTRIBUTE: [
        rf'\.({_pii_attr_pattern})\b',
    ],
    PIISourceType.PII_DICT_KEY: [
        rf'\[\s*["\']({_pii_attr_pattern})["\']\s*\]',
    ],
    PIISourceType.PII_VARIABLE: [
        rf'\b({_pii_attr_pattern})\s*[=:]\s*',
    ],
    
    # Environment
    PIISourceType.ENVIRONMENT: [
        r'process\.env\.',
        r'process\.env\[',
    ],
}


# =============================================================================
# SOURCE TO PII TYPE MAPPING
# =============================================================================

# Map source patterns to likely PII types
SOURCE_TO_PII_TYPE: Dict[str, str] = {
    'ssn': 'ssn',
    'social_security': 'ssn',
    'credit_card': 'credit_card',
    'creditcard': 'credit_card',
    'card_number': 'credit_card',
    'pan': 'credit_card',
    'cvv': 'cvv',
    'cvc': 'cvv',
    'bank_account': 'bank_account',
    'account_number': 'bank_account',
    'routing_number': 'routing_number',
    'iban': 'iban',
    'email': 'email',
    'email_address': 'email',
    'phone': 'phone',
    'phone_number': 'phone',
    'mobile': 'phone',
    'address': 'address',
    'street_address': 'address',
    'dob': 'dob',
    'date_of_birth': 'dob',
    'birthdate': 'dob',
    'passport': 'passport',
    'drivers_license': 'drivers_license',
    'license_number': 'drivers_license',
    'tax_id': 'tax_id',
    'mrn': 'mrn',
    'medical_record': 'mrn',
    'patient_id': 'mrn',
    'npi': 'npi',
    'password': 'password',
    'api_key': 'api_key',
    'name': 'person_name',
    'first_name': 'person_name',
    'last_name': 'person_name',
    'ip_address': 'ip_address',
    'user_data': 'user_data',
    'personal_info': 'user_data',
    'pii': 'user_data',
}


def infer_pii_type_from_source(source_code: str) -> str:
    """Infer PII type from source code pattern.
    
    b14 FIX: Use word-boundary regex instead of substring matching.
    Previously 'pan' matched 'span', 'company', 'expand' → credit_card FP.
    Previously 'name' matched 'serviceName', 'filename' → person_name FP.
    Now requires the keyword to appear as a standalone word/identifier segment.
    """
    source_lower = source_code.lower()
    
    # b14: Sort by longest keyword first so 'credit_card' matches before 'card'
    # and 'email_address' matches before 'address'
    sorted_items = sorted(SOURCE_TO_PII_TYPE.items(), key=lambda x: -len(x[0]))
    
    for keyword, pii_type in sorted_items:
        # b14: Word-boundary match — keyword must be a standalone identifier
        # segment, not a substring of a larger word.
        # \b handles: credit_card=..., data.email, get_phone(), "address"
        # This prevents: 'pan' matching 'span', 'name' matching 'serviceName'
        if re.search(r'\b' + re.escape(keyword) + r'\b', source_lower):
            return pii_type
    
    return 'user_data'  # Default


def get_source_confidence(source_type: PIISourceType) -> float:
    """Get confidence score for a source type."""
    HIGH_CONFIDENCE = {
        PIISourceType.PII_ATTRIBUTE,
        PIISourceType.PII_DICT_KEY,
        PIISourceType.DB_MODEL,
    }
    MEDIUM_CONFIDENCE = {
        PIISourceType.HTTP_FORM,
        PIISourceType.HTTP_JSON,
        PIISourceType.USER_SESSION,
        PIISourceType.DB_QUERY,
        PIISourceType.PII_VARIABLE,
    }
    
    if source_type in HIGH_CONFIDENCE:
        return 0.9
    elif source_type in MEDIUM_CONFIDENCE:
        return 0.7
    else:
        return 0.5
