#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.

"""
Storage Management Utilities for REACHABLE

Provides disk usage analysis, cleanup, and compression functions.
Used by `reachctl system` commands.
"""

import os
import shutil
import subprocess
import sqlite3
import tarfile
import gzip
from pathlib import Path
from datetime import datetime, timedelta
from typing import Dict, Any, List, Tuple, Optional
import json
import logging

# Initialize module-level logger
logger = logging.getLogger(__name__)


def get_dir_size(path: Path) -> int:
    """Get total size of directory in bytes."""
    if not path.exists():
        return 0
    total = 0
    try:
        for entry in path.rglob('*'):
            if entry.is_file():
                try:
                    total += entry.stat().st_size
                except (OSError, PermissionError):
                    pass
    except (OSError, PermissionError):
        pass
    return total


def get_file_count(path: Path) -> int:
    """Get total file count in directory."""
    if not path.exists():
        return 0
    count = 0
    try:
        for entry in path.rglob('*'):
            if entry.is_file():
                count += 1
    except (OSError, PermissionError):
        pass
    return count


def format_size(size_bytes: int) -> str:
    """Format bytes as human-readable string."""
    if size_bytes < 1024:
        return f"{size_bytes} B"
    elif size_bytes < 1024 * 1024:
        return f"{size_bytes / 1024:.1f} KB"
    elif size_bytes < 1024 * 1024 * 1024:
        return f"{size_bytes / (1024 * 1024):.1f} MB"
    else:
        return f"{size_bytes / (1024 * 1024 * 1024):.2f} GB"


def get_top_files(path: Path, n: int = 10) -> List[Tuple[Path, int]]:
    """Get top N largest files in directory."""
    if not path.exists():
        return []
    
    files = []
    try:
        for entry in path.rglob('*'):
            if entry.is_file():
                try:
                    files.append((entry, entry.stat().st_size))
                except (OSError, PermissionError):
                    pass
    except (OSError, PermissionError):
        pass
    
    files.sort(key=lambda x: x[1], reverse=True)
    return files[:n]


def get_top_dirs(path: Path, n: int = 10) -> List[Tuple[Path, int]]:
    """Get top N largest immediate subdirectories."""
    if not path.exists():
        return []
    
    dirs = []
    try:
        for entry in path.iterdir():
            if entry.is_dir():
                size = get_dir_size(entry)
                dirs.append((entry, size))
    except (OSError, PermissionError):
        pass
    
    dirs.sort(key=lambda x: x[1], reverse=True)
    return dirs[:n]


def check_colima_status() -> Dict[str, Any]:
    """Check if Colima is running."""
    result = {
        'installed': False,
        'running': False,
        'vm_type': None,
        'cpu': None,
        'memory': None,
        'disk': None,
    }
    
    # Check if colima exists
    colima_path = shutil.which('colima')
    if not colima_path:
        return result
    
    result['installed'] = True
    
    try:
        # Check status
        proc = subprocess.run(
            ['colima', 'status'],
            capture_output=True, text=True, timeout=5
        )
        if proc.returncode == 0 and 'running' in proc.stdout.lower():
            result['running'] = True
            # Parse status output
            for line in proc.stdout.split('\n'):
                line_lower = line.lower()
                if 'runtime:' in line_lower:
                    result['vm_type'] = line.split(':')[-1].strip()
                elif 'cpu:' in line_lower:
                    result['cpu'] = line.split(':')[-1].strip()
                elif 'memory:' in line_lower:
                    result['memory'] = line.split(':')[-1].strip()
                elif 'disk:' in line_lower:
                    result['disk'] = line.split(':')[-1].strip()
    except (subprocess.TimeoutExpired, FileNotFoundError, Exception):
        pass
    
    return result


def check_firecracker_status() -> Dict[str, Any]:
    """Check if Firecracker microVMs are running."""
    result = {
        'installed': False,
        'running': False,
        'vm_count': 0,
        'sockets': [],
    }
    
    # Check if firecracker exists
    fc_path = shutil.which('firecracker')
    if not fc_path:
        # Also check common locations
        for path in ['/usr/local/bin/firecracker', '/opt/firecracker/firecracker']:
            if Path(path).exists():
                fc_path = path
                break
    
    if not fc_path:
        return result
    
    result['installed'] = True
    
    try:
        # Check for running firecracker processes
        proc = subprocess.run(
            ['pgrep', '-f', 'firecracker'],
            capture_output=True, text=True, timeout=5
        )
        if proc.returncode == 0 and proc.stdout.strip():
            pids = proc.stdout.strip().split('\n')
            result['running'] = True
            result['vm_count'] = len(pids)
        
        # Check for API sockets in .reachable
        reachable_home = Path.home() / '.reachable'
        sandbox_dir = reachable_home / 'sandbox'
        if sandbox_dir.exists():
            for sock in sandbox_dir.glob('**/*.sock'):
                result['sockets'].append(str(sock))
    except (subprocess.TimeoutExpired, FileNotFoundError, Exception):
        pass
    
    return result


def check_docker_status() -> Dict[str, Any]:
    """Check Docker daemon status."""
    result = {
        'installed': False,
        'running': False,
        'containers': 0,
        'images': 0,
        'version': None,
    }
    
    docker_path = shutil.which('docker')
    if not docker_path:
        return result
    
    result['installed'] = True
    
    try:
        # Check if daemon is running
        proc = subprocess.run(
            ['docker', 'info', '--format', '{{.Containers}}'],
            capture_output=True, text=True, timeout=5
        )
        if proc.returncode == 0:
            result['running'] = True
            result['containers'] = int(proc.stdout.strip() or 0)
        
        # Get version
        proc = subprocess.run(
            ['docker', '--version'],
            capture_output=True, text=True, timeout=5
        )
        if proc.returncode == 0:
            result['version'] = proc.stdout.strip()
        
        # Count images
        proc = subprocess.run(
            ['docker', 'images', '-q'],
            capture_output=True, text=True, timeout=5
        )
        if proc.returncode == 0:
            result['images'] = len(proc.stdout.strip().split('\n')) if proc.stdout.strip() else 0
    except (subprocess.TimeoutExpired, FileNotFoundError, Exception):
        pass
    
    return result


def get_grype_db_info() -> Dict[str, Any]:
    """Get Grype vulnerability database info."""
    result = {
        'exists': False,
        'size': 0,
        'size_human': '0 B',
        'last_update': None,
        'age_hours': None,
        'path': None,
    }
    
    # Check REACHABLE cache location first
    grype_db_dir = Path.home() / '.reachable' / 'cache' / 'grype-db'
    if not grype_db_dir.exists():
        # Check default grype location
        grype_db_dir = Path.home() / '.cache' / 'grype' / 'db'
    
    if grype_db_dir.exists():
        result['exists'] = True
        result['size'] = get_dir_size(grype_db_dir)
        result['size_human'] = format_size(result['size'])
        result['path'] = str(grype_db_dir)
        
        # Check timestamp
        timestamp_file = grype_db_dir / '.last_update'
        if timestamp_file.exists():
            try:
                ts = timestamp_file.read_text().strip()
                result['last_update'] = ts
                last_dt = datetime.fromisoformat(ts)
                result['age_hours'] = (datetime.now() - last_dt).total_seconds() / 3600
            except:
                pass
        
        # Check for metadata file (grype's own tracking)
        for meta in grype_db_dir.glob('**/metadata.json'):
            try:
                data = json.loads(meta.read_text())
                if 'built' in data:
                    result['db_built'] = data['built']
                if 'version' in data:
                    result['db_version'] = data['version']
            except:
                pass
    
    return result


def get_db_table_sizes(db_path: Path) -> Dict[str, Dict[str, Any]]:
    """Get size breakdown of tables in a SQLite database."""
    result = {}
    if not db_path.exists():
        return result
    
    try:
        conn = sqlite3.connect(str(db_path))
        cursor = conn.cursor()
        
        # Get table names
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table'")
        tables = [row[0] for row in cursor.fetchall()]
        
        for table in tables:
            try:
                cursor.execute(f"SELECT COUNT(*) FROM {table}")
                count = cursor.fetchone()[0]
                
                # Estimate size by sampling
                cursor.execute(f"SELECT * FROM {table} LIMIT 1")
                row = cursor.fetchone()
                avg_row_size = len(str(row)) if row else 0
                estimated_size = count * avg_row_size
                
                result[table] = {
                    'rows': count,
                    'estimated_size': estimated_size,
                    'estimated_size_human': format_size(estimated_size),
                }
            except:
                pass
        
        conn.close()
    except:
        pass
    
    return result


def get_storage_breakdown(reachable_home: Path = None) -> Dict[str, Any]:
    """Get comprehensive storage breakdown."""
    if reachable_home is None:
        reachable_home = Path.home() / '.reachable'
    
    if not reachable_home.exists():
        return {'exists': False, 'total': 0, 'total_human': '0 B'}
    
    result = {
        'exists': True,
        'path': str(reachable_home),
        'total': 0,
        'total_human': '0 B',
        'components': {},
        'top_repos': [],
        'top_files': [],
    }
    
    # Get total size
    result['total'] = get_dir_size(reachable_home)
    result['total_human'] = format_size(result['total'])
    
    # Component breakdown
    components = {
        'scans': reachable_home / 'scans',
        'cache': reachable_home / 'cache',
        'tools': reachable_home / 'tools',
        'sandbox': reachable_home / 'sandbox',
        'logs': reachable_home / 'logs',
    }
    
    for name, path in components.items():
        if path.exists():
            size = get_dir_size(path)
            result['components'][name] = {
                'size': size,
                'size_human': format_size(size),
                'file_count': get_file_count(path),
                'path': str(path),
            }
    
    # Cache sub-components
    cache_dir = reachable_home / 'cache'
    if cache_dir.exists():
        result['cache_breakdown'] = {}
        for subdir in cache_dir.iterdir():
            if subdir.is_dir():
                size = get_dir_size(subdir)
                result['cache_breakdown'][subdir.name] = {
                    'size': size,
                    'size_human': format_size(size),
                }
    
    # Top repos by size
    scans_dir = reachable_home / 'scans'
    if scans_dir.exists():
        result['top_repos'] = []
        for repo_dir, size in get_top_dirs(scans_dir, n=10):
            # Count scans in repo
            scan_count = 0
            db_path = repo_dir / 'repo.db'
            db_size = 0
            branch_count = 0
            oldest_scan = None
            newest_scan = None
            
            if db_path.exists():
                db_size = db_path.stat().st_size
                try:
                    conn = sqlite3.connect(str(db_path))
                    cursor = conn.cursor()
                    cursor.execute("SELECT COUNT(*) FROM scans")
                    scan_count = cursor.fetchone()[0]
                    cursor.execute("SELECT COUNT(DISTINCT branch) FROM scans")
                    branch_count = cursor.fetchone()[0]
                    cursor.execute("SELECT MIN(timestamp), MAX(timestamp) FROM scans")
                    row = cursor.fetchone()
                    oldest_scan = row[0]
                    newest_scan = row[1]
                    conn.close()
                except:
                    pass
            
            result['top_repos'].append({
                'name': repo_dir.name,
                'size': size,
                'size_human': format_size(size),
                'scan_count': scan_count,
                'branch_count': branch_count,
                'db_size': db_size,
                'db_size_human': format_size(db_size),
                'oldest_scan': oldest_scan,
                'newest_scan': newest_scan,
            })
    
    # Top files overall
    result['top_files'] = []
    for file_path, size in get_top_files(reachable_home, n=20):
        result['top_files'].append({
            'path': str(file_path.relative_to(reachable_home)),
            'full_path': str(file_path),
            'size': size,
            'size_human': format_size(size),
        })
    
    return result


def get_system_info() -> Dict[str, Any]:
    """Get comprehensive system information."""
    reachable_home = Path.home() / '.reachable'
    
    info = {
        'timestamp': datetime.now().isoformat(),
        'reachable_home': str(reachable_home),
        'storage': get_storage_breakdown(reachable_home),
        'grype_db': get_grype_db_info(),
        'sandboxes': {
            'colima': check_colima_status(),
            'firecracker': check_firecracker_status(),
            'docker': check_docker_status(),
        },
    }
    
    return info


def print_system_info(verbose: bool = False, json_output: bool = False):
    """Print formatted system information."""
    info = get_system_info()
    
    if json_output:
        print(json.dumps(info, indent=2, default=str))
        return
    
    print("=" * 70)
    logger.info("REACHABLE SYSTEM INFO")
    print("=" * 70)
    
    # Storage Overview
    storage = info['storage']
    if not storage['exists']:
        logger.info("\n📁 Storage: ~/.reachable does not exist yet")
    else:
        logger.info(f"\n📁 STORAGE OVERVIEW")
        logger.info(f"   Location: {storage['path']}")
        logger.info(f"   Total:    {storage['total_human']}")
        
        if storage.get('components'):
            logger.info(f"\n   Components:")
            for name, data in sorted(storage['components'].items(), key=lambda x: x[1]['size'], reverse=True):
                pct = (data['size'] / storage['total'] * 100) if storage['total'] > 0 else 0
                bar = '█' * int(pct / 5) + '░' * (20 - int(pct / 5))
                logger.info(f"     {name:12} {data['size_human']:>10}  {bar} {pct:5.1f}%  ({data['file_count']:,} files)")
        
        if storage.get('cache_breakdown'):
            logger.info(f"\n   Cache Breakdown:")
            for name, data in sorted(storage['cache_breakdown'].items(), key=lambda x: x[1]['size'], reverse=True):
                logger.info(f"     {name:20} {data['size_human']:>10}")
        
        if storage.get('top_repos'):
            logger.info(f"\n   Top Repositories:")
            for repo in storage['top_repos'][:5]:
                logger.info(f"     {repo['name'][:35]:35} {repo['size_human']:>10}  ({repo['scan_count']} scans, {repo['branch_count']} branches)")
        
        if storage.get('top_files') and verbose:
            logger.info(f"\n   Top Files (by size):")
            for f in storage['top_files'][:15]:
                logger.info(f"     {f['size_human']:>10}  {f['path'][:55]}")
    
    # Grype DB
    grype = info['grype_db']
    logger.info(f"\n🗄️  VULNERABILITY DATABASE (Grype)")
    if grype['exists']:
        age_str = f"{grype['age_hours']:.1f}h ago" if grype.get('age_hours') else "unknown"
        stale = grype.get('age_hours', 0) > 24 if grype.get('age_hours') else True
        status = "⚠️  STALE" if stale else "✓ Fresh"
        logger.info(f"   Size:     {grype['size_human']}")
        logger.info(f"   Updated:  {age_str} {status}")
        if grype.get('db_version'):
            logger.info(f"   Version:  {grype['db_version']}")
    else:
        logger.info("   Status: Not initialized (run a scan to populate)")
    
    # Sandboxes
    logger.info(f"\n🐳 SANDBOX STATUS")
    
    colima = info['sandboxes']['colima']
    if colima['installed']:
        status = "🟢 Running" if colima['running'] else "⚪ Stopped"
        logger.info(f"   Colima:      {status}")
        if colima['running']:
            details = []
            if colima.get('cpu'):
                details.append(f"CPU: {colima['cpu']}")
            if colima.get('memory'):
                details.append(f"Memory: {colima['memory']}")
            if colima.get('disk'):
                details.append(f"Disk: {colima['disk']}")
            if details:
                logger.info(f"                {', '.join(details)}")
    else:
        logger.info("   Colima:      Not installed")
    
    fc = info['sandboxes']['firecracker']
    if fc['installed']:
        status = f"🟢 Running ({fc['vm_count']} VMs)" if fc['running'] else "⚪ Stopped"
        logger.info(f"   Firecracker: {status}")
    else:
        logger.info("   Firecracker: Not installed")
    
    docker = info['sandboxes']['docker']
    if docker['installed']:
        status = f"🟢 Running ({docker['containers']} containers, {docker['images']} images)" if docker['running'] else "⚪ Daemon not running"
        logger.info(f"   Docker:      {status}")
    else:
        logger.info("   Docker:      Not installed")
    
    # Recommendations
    logger.info(f"\n💡 RECOMMENDATIONS")
    recommendations = []
    
    # Calculate prunable storage (exclude required components: cache/grype-db, tools, venv)
    essential_size = 0
    for comp_name in ('cache', 'tools'):
        if comp_name in storage.get('components', {}):
            essential_size += storage['components'][comp_name]['size']
    prunable_size = storage['total'] - essential_size
    
    if prunable_size > 5 * 1024 * 1024 * 1024:  # > 5GB of scan/log data
        recommendations.append(f"   • Scan data is {format_size(prunable_size)}. Run 'reachctl system prune' to clean up.")
    
    if (grype.get('age_hours') or 999) > 48:
        recommendations.append(f"   • Grype DB is stale. Run 'reachctl db update' to refresh.")
    
    if storage.get('top_repos'):
        for repo in storage['top_repos']:
            if repo['scan_count'] > 30:
                recommendations.append(f"   • {repo['name'][:20]} has {repo['scan_count']} scans. Consider pruning.")
    
    if not recommendations:
        logger.info("   ✓ No issues detected")
    else:
        for rec in recommendations:
            print(rec)
    
    print()


def prune_storage(
    max_age_days: int = 21,
    max_scans_per_branch: int = 20,
    compress_after_days: int = 14,
    dry_run: bool = False,
    verbose: bool = False
) -> Dict[str, Any]:
    """
    Prune old scan data and compress older dashboards.
    
    Args:
        max_age_days: Delete scans older than this
        max_scans_per_branch: Keep only this many scans per branch
        compress_after_days: Compress dashboards older than this
        dry_run: Only show what would be deleted
        verbose: Print detailed progress
        
    Returns:
        Dict with cleanup statistics
    """
    reachable_home = Path.home() / '.reachable'
    scans_dir = reachable_home / 'scans'
    
    result = {
        'scans_deleted': 0,
        'dirs_deleted': 0,
        'dirs_compressed': 0,
        'bytes_freed': 0,
        'bytes_freed_human': '0 B',
        'errors': [],
    }
    
    if not scans_dir.exists():
        return result
    
    cutoff_delete = datetime.now() - timedelta(days=max_age_days)
    cutoff_compress = datetime.now() - timedelta(days=compress_after_days)
    
    # Process each repository
    for repo_dir in scans_dir.iterdir():
        if not repo_dir.is_dir():
            continue
        
        db_path = repo_dir / 'repo.db'
        if not db_path.exists():
            continue
        
        try:
            conn = sqlite3.connect(str(db_path))
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            
            # Get branches
            cursor.execute("SELECT DISTINCT branch FROM scans")
            branches = [row['branch'] for row in cursor.fetchall()]
            
            for branch in branches:
                # Find scans to delete (by count)
                cursor.execute("""
                    SELECT id, scan_dir, timestamp FROM scans 
                    WHERE branch = ? AND status = 'complete'
                    ORDER BY timestamp DESC
                    LIMIT -1 OFFSET ?
                """, (branch, max_scans_per_branch))
                
                scans_to_delete = list(cursor.fetchall())
                
                # Also delete by age
                cursor.execute("""
                    SELECT id, scan_dir, timestamp FROM scans 
                    WHERE branch = ? AND timestamp < ?
                """, (branch, cutoff_delete.isoformat()))
                
                scans_to_delete.extend(cursor.fetchall())
                
                # Dedupe by ID
                seen_ids = set()
                unique_scans = []
                for scan in scans_to_delete:
                    if scan['id'] not in seen_ids:
                        seen_ids.add(scan['id'])
                        unique_scans.append(scan)
                
                # Delete scans and their directories
                for scan in unique_scans:
                    scan_dir = scan['scan_dir']
                    if scan_dir:
                        scan_path = Path(scan_dir)
                        if scan_path.exists():
                            dir_size = get_dir_size(scan_path)
                            if verbose:
                                logger.info(f"  {'Would delete' if dry_run else 'Deleting'}: {scan_path} ({format_size(dir_size)})")
                            
                            if not dry_run:
                                try:
                                    shutil.rmtree(scan_path)
                                    result['dirs_deleted'] += 1
                                    result['bytes_freed'] += dir_size
                                except Exception as e:
                                    result['errors'].append(f"Failed to delete {scan_path}: {e}")
                    
                    if not dry_run:
                        cursor.execute("DELETE FROM scans WHERE id = ?", (scan['id'],))
                        result['scans_deleted'] += 1
                
                # Find scans to compress (older than compress_after_days but not deleted)
                cursor.execute("""
                    SELECT id, scan_dir, timestamp FROM scans 
                    WHERE branch = ? AND timestamp < ? AND timestamp >= ?
                """, (branch, cutoff_compress.isoformat(), cutoff_delete.isoformat()))
                
                for scan in cursor.fetchall():
                    scan_dir = scan['scan_dir']
                    if scan_dir:
                        scan_path = Path(scan_dir)
                        dashboard_dir = scan_path / 'dashboard'
                        archive_path = scan_path / 'dashboard.tar.gz'
                        
                        # Compress dashboard if not already compressed
                        if dashboard_dir.exists() and dashboard_dir.is_dir() and not archive_path.exists():
                            dir_size = get_dir_size(dashboard_dir)
                            if verbose:
                                logger.info(f"  {'Would compress' if dry_run else 'Compressing'}: {dashboard_dir} ({format_size(dir_size)})")
                            
                            if not dry_run:
                                try:
                                    with tarfile.open(archive_path, "w:gz") as tar:
                                        tar.add(dashboard_dir, arcname='dashboard')
                                    
                                    # Remove original if archive created successfully
                                    if archive_path.exists():
                                        shutil.rmtree(dashboard_dir)
                                        result['dirs_compressed'] += 1
                                        # Calculate savings
                                        new_size = archive_path.stat().st_size
                                        result['bytes_freed'] += (dir_size - new_size)
                                except Exception as e:
                                    result['errors'].append(f"Failed to compress {dashboard_dir}: {e}")
            
            if not dry_run:
                conn.commit()
                # Vacuum to reclaim space
                conn.execute("VACUUM")
            
            conn.close()
            
        except Exception as e:
            result['errors'].append(f"Error processing {repo_dir}: {e}")
    
    # Clean up orphaned cache entries
    cache_dir = reachable_home / 'cache'
    if cache_dir.exists() and not dry_run:
        # Clean old semgrep cache
        semgrep_cache = cache_dir / 'semgrep'
        if semgrep_cache.exists():
            for entry in semgrep_cache.iterdir():
                try:
                    mtime = datetime.fromtimestamp(entry.stat().st_mtime)
                    if mtime < cutoff_delete:
                        size = get_dir_size(entry) if entry.is_dir() else entry.stat().st_size
                        if entry.is_dir():
                            shutil.rmtree(entry)
                        else:
                            entry.unlink()
                        result['bytes_freed'] += size
                except:
                    pass
    
    result['bytes_freed_human'] = format_size(result['bytes_freed'])
    return result


if __name__ == "__main__":
    import sys
    import logging
    
    if len(sys.argv) > 1 and sys.argv[1] == 'prune':
        dry_run = '--dry-run' in sys.argv
        verbose = '-v' in sys.argv or '--verbose' in sys.argv
        logger.info("REACHABLE Storage Prune")
        print("=" * 50)
        result = prune_storage(dry_run=dry_run, verbose=verbose)
        logger.info(f"\nResults:")
        logger.info(f"  Scans deleted:     {result['scans_deleted']}")
        logger.info(f"  Directories deleted: {result['dirs_deleted']}")
        logger.info(f"  Directories compressed: {result['dirs_compressed']}")
        logger.info(f"  Space freed:       {result['bytes_freed_human']}")
        if result['errors']:
            logger.info(f"\nErrors:")
            for err in result['errors']:
                logger.info(f"  • {err}")
    else:
        verbose = '-v' in sys.argv or '--verbose' in sys.argv
        json_output = '--json' in sys.argv
        print_system_info(verbose=verbose, json_output=json_output)
