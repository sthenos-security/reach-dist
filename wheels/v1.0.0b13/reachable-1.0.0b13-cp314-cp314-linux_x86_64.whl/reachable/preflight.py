#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.

"""
Preflight Check - Single function to verify REACHABLE is ready to run.

Call this before scan, selftest, or doctor. Optionally auto-fix issues.

Usage:
    from reachable.preflight import preflight_check
    
    # Check only (returns issues list)
    issues = preflight_check()
    
    # Check and fix
    issues = preflight_check(fix=True)
    
    # Quiet mode (no output)
    issues = preflight_check(quiet=True)
"""

import os
import sys
import shutil
import subprocess
import logging
from pathlib import Path
from typing import List, Dict, Optional, Tuple

# Initialize module-level logger
logger = logging.getLogger(__name__)

# Cross-process lock for concurrent scan safety
from reachable.guarddog_setup import setup_lock

# Tool locations
REACHABLE_HOME = Path.home() / '.reachable'
TOOLS_BIN = REACHABLE_HOME / 'tools' / 'bin'
VENV_DIR = REACHABLE_HOME / 'venv'
VENV_BIN = VENV_DIR / 'bin'
GUARDDOG_VENV = REACHABLE_HOME / 'guarddog-venv'
GUARDDOG_BIN = GUARDDOG_VENV / 'bin'
GRYPE_DB_CACHE = REACHABLE_HOME / 'cache' / 'grype-db'

# Tool versions (pinned for reproducibility)
SYFT_VERSION = "v1.18.1"
GRYPE_VERSION = "v0.84.0"


class PreflightResult:
    """Result of preflight check."""
    
    def __init__(self):
        self.checks: List[Dict] = []
        self.issues: List[str] = []
        self.fixed: List[str] = []
    
    def add_check(self, name: str, status: str, message: str = "", fixable: bool = False):
        """Add a check result."""
        self.checks.append({
            'name': name,
            'status': status,  # 'ok', 'warn', 'fail'
            'message': message,
            'fixable': fixable
        })
        if status == 'fail':
            self.issues.append(f"{name}: {message}")
    
    def add_fixed(self, name: str):
        """Record that something was fixed."""
        self.fixed.append(name)
    
    @property
    def ok(self) -> bool:
        """True if no failures."""
        return len(self.issues) == 0
    
    @property
    def has_warnings(self) -> bool:
        """True if there are warnings."""
        return any(c['status'] == 'warn' for c in self.checks)


def preflight_check(
    fix: bool = False,
    quiet: bool = False,
    verbose: bool = False,
    skip_vulndb: bool = False
) -> PreflightResult:
    """
    Single preflight check for all REACHABLE dependencies.
    
    Checks:
        1. Python version (>= 3.9)
        2. syft binary in ~/.reachable/tools/bin/
        3. grype binary in ~/.reachable/tools/bin/
        4. semgrep in ~/.reachable/venv/bin/
        5. guarddog in ~/.reachable/guarddog-venv/bin/
        6. grype vulnerability DB (unless skip_vulndb=True)
    
    Args:
        fix: If True, attempt to install missing components
        quiet: If True, suppress all output
        verbose: If True, show detailed progress
        skip_vulndb: If True, skip vulnerability DB check (faster)
    
    Returns:
        PreflightResult with check status and any issues
    """
    result = PreflightResult()
    
    def log(msg: str):
        if not quiet:
            print(msg)
    
    def log_verbose(msg: str):
        if verbose and not quiet:
            print(msg)
    
    if not quiet:
        log("🔍 Preflight check...")
    
    # 1. git client (required — not auto-fixable)
    git_path = shutil.which('git')
    if git_path:
        result.add_check('git', 'ok')
        log_verbose(f"  ✅ git")
    else:
        result.add_check('git', 'fail', 'not found — scanner cannot clone library source', fixable=False)
        log(f"  ❌ git not found (install: brew install git | sudo apt install git)")
    
    # 2. Python version
    py_ver = sys.version_info
    if py_ver >= (3, 9):
        result.add_check('python', 'ok', f'{py_ver.major}.{py_ver.minor}')
        log_verbose(f"  ✅ Python {py_ver.major}.{py_ver.minor}")
    else:
        result.add_check('python', 'fail', f'{py_ver.major}.{py_ver.minor} < 3.9 required', fixable=False)
        log(f"  ❌ Python {py_ver.major}.{py_ver.minor} (3.9+ required)")
    
    # 3. syft binary
    syft_path = TOOLS_BIN / 'syft'
    if syft_path.exists() and _check_tool_works(syft_path, 'version'):
        result.add_check('syft', 'ok')
        log_verbose(f"  ✅ syft")
    else:
        if fix:
            log(f"  📦 Installing syft...")
            if _install_syft():
                result.add_check('syft', 'ok')
                result.add_fixed('syft')
                log(f"  ✅ syft installed")
            else:
                result.add_check('syft', 'fail', 'installation failed', fixable=True)
                log(f"  ❌ syft installation failed")
        else:
            result.add_check('syft', 'fail', 'not found', fixable=True)
            log(f"  ❌ syft not found")
    
    # 4. grype binary
    grype_path = TOOLS_BIN / 'grype'
    if grype_path.exists() and _check_tool_works(grype_path, 'version'):
        result.add_check('grype', 'ok')
        log_verbose(f"  ✅ grype")
    else:
        if fix:
            log(f"  📦 Installing grype...")
            if _install_grype():
                result.add_check('grype', 'ok')
                result.add_fixed('grype')
                log(f"  ✅ grype installed")
            else:
                result.add_check('grype', 'fail', 'installation failed', fixable=True)
                log(f"  ❌ grype installation failed")
        else:
            result.add_check('grype', 'fail', 'not found', fixable=True)
            log(f"  ❌ grype not found")
    
    # 5. semgrep in venv
    semgrep_path = VENV_BIN / 'semgrep'
    if semgrep_path.exists() and _check_tool_works(semgrep_path, '--version'):
        result.add_check('semgrep', 'ok')
        log_verbose(f"  ✅ semgrep")
    else:
        if fix:
            log(f"  📦 Installing semgrep...")
            if _install_semgrep():
                result.add_check('semgrep', 'ok')
                result.add_fixed('semgrep')
                log(f"  ✅ semgrep installed")
            else:
                result.add_check('semgrep', 'fail', 'installation failed', fixable=True)
                log(f"  ❌ semgrep installation failed")
        else:
            result.add_check('semgrep', 'fail', 'not found', fixable=True)
            log(f"  ❌ semgrep not found")
    
    # 6. guarddog in isolated venv
    guarddog_path = GUARDDOG_BIN / 'guarddog'
    if guarddog_path.exists() and _check_tool_works(guarddog_path, '--version'):
        result.add_check('guarddog', 'ok')
        log_verbose(f"  ✅ guarddog")
    else:
        if fix:
            log(f"  📦 Installing guarddog (isolated venv)...")
            if _install_guarddog():
                result.add_check('guarddog', 'ok')
                result.add_fixed('guarddog')
                log(f"  ✅ guarddog installed")
            else:
                result.add_check('guarddog', 'fail', 'installation failed', fixable=True)
                log(f"  ❌ guarddog installation failed")
        else:
            result.add_check('guarddog', 'fail', 'not found', fixable=True)
            log(f"  ❌ guarddog not found")
    
    # 7. grype vulnerability DB
    if not skip_vulndb:
        db_status = _check_vulndb()
        if db_status == 'ok':
            result.add_check('vulndb', 'ok')
            log_verbose(f"  ✅ grype vulnerability DB")
        elif db_status == 'stale':
            result.add_check('vulndb', 'warn', 'stale (> 24h old)', fixable=True)
            log(f"  ⚠️  grype DB stale (will refresh on scan)")
        else:  # missing
            if fix:
                log(f"  📦 Downloading vulnerability database...")
                if _update_vulndb():
                    result.add_check('vulndb', 'ok')
                    result.add_fixed('vulndb')
                    log(f"  ✅ vulnerability DB downloaded")
                else:
                    result.add_check('vulndb', 'warn', 'download failed (will retry on scan)', fixable=True)
                    log(f"  ⚠️  vulnerability DB download failed")
            else:
                result.add_check('vulndb', 'warn', 'not initialized', fixable=True)
                log(f"  ⚠️  grype DB not initialized (will download on first scan)")
    
    # Summary
    if not quiet:
        if result.ok:
            if result.has_warnings:
                log(f"✅ Preflight passed with warnings")
            else:
                log(f"✅ Preflight passed")
        else:
            log(f"❌ Preflight failed: {len(result.issues)} issue(s)")
            if not fix:
                log(f"   Run with --fix to auto-install missing tools")
    
    return result


def _check_tool_works(path: Path, version_arg: str) -> bool:
    """Check if a tool binary works."""
    try:
        result = subprocess.run(
            [str(path), version_arg],
            capture_output=True,
            timeout=10
        )
        return result.returncode == 0
    except Exception:
        return False


def _check_vulndb() -> str:
    """Check vulnerability DB status. Returns 'ok', 'stale', or 'missing'."""
    try:
        from .vulndb import VulnDBManager
        mgr = VulnDBManager()
        status = mgr.get_status()
        
        if not status['exists']:
            return 'missing'
        if status['is_stale']:
            return 'stale'
        return 'ok'
    except Exception:
        return 'missing'


def _update_vulndb() -> bool:
    """Update vulnerability database (lock-protected)."""
    with setup_lock('grype-db'):
        # Skip if another process already updated while we waited
        try:
            status = _check_vulndb()
            if status == 'ok':
                return True
        except Exception:
            pass
        
        try:
            from .vulndb import VulnDBManager
            mgr = VulnDBManager()
            return mgr.update(force=True, verbose=False)
        except Exception:
            return False


def _install_syft() -> bool:
    """Install syft using Anchore's install script (lock-protected)."""
    with setup_lock('syft'):
        # Skip if another process already installed while we waited
        if (TOOLS_BIN / 'syft').exists() and _check_tool_works(TOOLS_BIN / 'syft', 'version'):
            return True
        
        TOOLS_BIN.mkdir(parents=True, exist_ok=True)
        
        try:
            install_cmd = f'curl -sSfL https://raw.githubusercontent.com/anchore/syft/main/install.sh | sh -s -- -b {TOOLS_BIN} {SYFT_VERSION}'
            result = subprocess.run(
                install_cmd,
                shell=True,
                capture_output=True,
                timeout=120
            )
            return result.returncode == 0 and (TOOLS_BIN / 'syft').exists()
        except Exception:
            return False


def _install_grype() -> bool:
    """Install grype using Anchore's install script (lock-protected)."""
    with setup_lock('grype'):
        # Skip if another process already installed while we waited
        if (TOOLS_BIN / 'grype').exists() and _check_tool_works(TOOLS_BIN / 'grype', 'version'):
            return True
        
        TOOLS_BIN.mkdir(parents=True, exist_ok=True)
        
        try:
            install_cmd = f'curl -sSfL https://raw.githubusercontent.com/anchore/grype/main/install.sh | sh -s -- -b {TOOLS_BIN} {GRYPE_VERSION}'
            result = subprocess.run(
                install_cmd,
                shell=True,
                capture_output=True,
                timeout=120
            )
            return result.returncode == 0 and (TOOLS_BIN / 'grype').exists()
        except Exception:
            return False


def _install_semgrep() -> bool:
    """Install semgrep into REACHABLE's venv (lock-protected)."""
    with setup_lock('semgrep-venv'):
        # Skip if another process already installed while we waited
        if (VENV_BIN / 'semgrep').exists() and _check_tool_works(VENV_BIN / 'semgrep', '--version'):
            return True
        
        VENV_DIR.mkdir(parents=True, exist_ok=True)
        
        try:
            # Create venv if it doesn't exist
            venv_python = VENV_BIN / 'python3'
            if not venv_python.exists():
                venv_python = VENV_BIN / 'python'  # Fallback for some systems
            
            if not venv_python.exists():
                subprocess.run(
                    [sys.executable, '-m', 'venv', str(VENV_DIR)],
                    check=True,
                    capture_output=True,
                    timeout=60
                )
                # Re-check after creation
                venv_python = VENV_BIN / 'python3'
                if not venv_python.exists():
                    venv_python = VENV_BIN / 'python'
            
            python_path = str(venv_python)
            
            # Ensure pip is available (some systems create venv without pip)
            subprocess.run(
                [python_path, '-m', 'ensurepip', '--upgrade'],
                capture_output=True,
                timeout=60
            )
            
            # Install semgrep using python -m pip (more reliable than pip binary)
            result = subprocess.run(
                [python_path, '-m', 'pip', 'install', 'semgrep', '-q'],
                capture_output=True,
                timeout=300
            )
            return result.returncode == 0 and (VENV_BIN / 'semgrep').exists()
        except Exception:
            return False


def _install_guarddog() -> bool:
    """Install guarddog into isolated venv.
    
    Uses the centralized guarddog_setup module which handles:
    - macOS: Installing libgit2 via Homebrew
    - Linux: Installing libgit2-dev via apt/dnf/yum/pacman/apk/zypper
    - Cross-platform venv creation and pip install
    """
    try:
        from reachable.guarddog_setup import setup_guarddog
        return setup_guarddog(verbose=True)
    except Exception as e:
        logger.info(f"  ⚠️  guarddog setup failed: {e}")
        return False


def ensure_ready(fix: bool = True, quiet: bool = False) -> bool:
    """
    Ensure REACHABLE is ready to run. Convenience wrapper.
    
    Args:
        fix: Auto-fix issues (default True)
        quiet: Suppress output
    
    Returns:
        True if ready, False if critical issues remain
    """
    result = preflight_check(fix=fix, quiet=quiet)
    return result.ok


# CLI entry point for testing
if __name__ == '__main__':
    import argparse
    
    parser = argparse.ArgumentParser(description='REACHABLE Preflight Check')
    parser.add_argument('--fix', action='store_true', help='Auto-fix issues')
    parser.add_argument('--quiet', '-q', action='store_true', help='Quiet mode')
    parser.add_argument('--verbose', '-v', action='store_true', help='Verbose mode')
    args = parser.parse_args()
    
    result = preflight_check(fix=args.fix, quiet=args.quiet, verbose=args.verbose)
    sys.exit(0 if result.ok else 1)
