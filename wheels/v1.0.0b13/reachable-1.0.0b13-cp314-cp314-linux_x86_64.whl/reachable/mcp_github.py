#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.

"""
MCP GitHub Integration for REACHABLE

Allows REACHABLE to analyze GitHub repositories directly using MCP,
without requiring explicit git clone operations.

This is now the DEFAULT mode. Manual git cloning is available via --git-clone flag.

Features:
- Fetch repository contents via GitHub API (MCP-style)
- Support for public and private repos (with GITHUB_TOKEN)
- Cache downloaded repositories
- Analyze dependencies from requirements.txt
- Support for specific branches/tags/commits
- No git binary required

Usage:
    # Default: MCP mode (fetch via API)
    vera scan github:owner/repo
    
    # Legacy: Manual git clone
    vera scan github:owner/repo --git-clone
"""

import os
import json
import tempfile
import shutil
import time
from pathlib import Path
from typing import Optional, Dict, List, Tuple
from dataclasses import dataclass
import subprocess
import base64
import urllib.request
import urllib.error
import logging

# Initialize module-level logger
logger = logging.getLogger(__name__)

@dataclass
class GitHubRepo:
    """GitHub repository information"""
    owner: str
    repo: str
    branch: Optional[str] = None
    commit: Optional[str] = None
    tag: Optional[str] = None
    
    @property
    def full_name(self):
        return f"{self.owner}/{self.repo}"
    
    @property
    def ref(self):
        """Get the reference (branch, tag, or commit)"""
        if self.commit:
            return self.commit
        elif self.tag:
            return f"refs/tags/{self.tag}"
        elif self.branch:
            return f"refs/heads/{self.branch}"
        else:
            return "refs/heads/main"
    
    @ref.setter
    def ref(self, value: str):
        """Set the reference - determines if it's a tag, branch, or commit"""
        if value is None:
            return
        
        # Check if it looks like a version tag (starts with v or is semver-like)
        if value.startswith('v') or value[0].isdigit():
            self.tag = value
            self.branch = None
            self.commit = None
        # Check if it looks like a commit SHA (40 hex chars)
        elif len(value) == 40 and all(c in '0123456789abcdef' for c in value.lower()):
            self.commit = value
            self.tag = None
            self.branch = None
        else:
            # Assume it's a branch name
            self.branch = value
            self.tag = None
            self.commit = None
    
    @classmethod
    def parse(cls, repo_url: str) -> 'GitHubRepo':
        """
        Parse GitHub URL or shorthand
        
        Supports:
        - github:owner/repo
        - github:owner/repo@branch
        - github:owner/repo@tag
        - github:owner/repo#commit
        - https://github.com/owner/repo
        - https://github.com/owner/repo/tree/branch
        - git://github.com/owner/repo.git (legacy, deprecated by GitHub)
        - git+https://github.com/owner/repo
        - ssh://git@github.com/owner/repo
        """
        # Validate that we have something to work with
        if not repo_url or len(repo_url) < 5:
            raise ValueError(f"Invalid GitHub repo format: {repo_url}")
        
        # Convert git:// to https:// (GitHub disabled git protocol in 2022)
        # Also handle malformed git:/ (single slash)
        if repo_url.startswith('git://'):
            repo_url = repo_url.replace('git://', 'https://', 1)
        elif repo_url.startswith('git:/') and not repo_url.startswith('git://'):
            # Malformed URL with single slash - try to fix it
            repo_url = 'https://' + repo_url[5:]
        
        # Convert git+https:// to https://
        if repo_url.startswith('git+https://'):
            repo_url = repo_url.replace('git+https://', 'https://', 1)
        
        # Convert ssh:// URLs
        if repo_url.startswith('ssh://git@github.com'):
            repo_url = repo_url.replace('ssh://git@github.com', 'https://github.com', 1)
        
        # Validate this is actually a GitHub URL
        if 'github.com' not in repo_url.lower():
            raise ValueError(f"Not a GitHub URL: {repo_url}")
        
        # Remove github: prefix
        if repo_url.startswith('github:'):
            repo_url = repo_url[7:]
        
        # Remove https://github.com/ prefix
        if repo_url.startswith('https://github.com/'):
            repo_url = repo_url[19:]
        
        # Remove http://github.com/ prefix (shouldn't happen but just in case)
        if repo_url.startswith('http://github.com/'):
            repo_url = repo_url[18:]
        
        # Remove .git suffix
        if repo_url.endswith('.git'):
            repo_url = repo_url[:-4]
        
        # Parse owner/repo@ref or owner/repo#commit
        parts = repo_url.split('/')
        if len(parts) < 2:
            raise ValueError(f"Invalid GitHub repo format: {repo_url}")
        
        owner = parts[0]
        repo_part = parts[1]
        
        # Validate owner and repo are not empty
        if not owner or not repo_part:
            raise ValueError(f"Invalid GitHub repo format (empty owner or repo): {repo_url}")
        
        # Check for branch/tag after @
        if '@' in repo_part:
            repo, ref = repo_part.split('@', 1)
            return cls(owner=owner, repo=repo, branch=ref)
        
        # Check for commit after #
        elif '#' in repo_part:
            repo, commit = repo_part.split('#', 1)
            return cls(owner=owner, repo=repo, commit=commit)
        
        # Check for /tree/branch pattern
        elif len(parts) > 3 and parts[2] == 'tree':
            repo = repo_part
            branch = '/'.join(parts[3:])
            return cls(owner=owner, repo=repo, branch=branch)
        
        else:
            return cls(owner=owner, repo=repo_part)
    
    # Alias for backward compatibility
    from_url = parse

class MCPGitHubClient:
    """
    MCP-based GitHub client for fetching repository contents
    
    Uses GitHub API to fetch repository files without git clone.
    This is the DEFAULT mode for REACHABLE.
    
    Supports both public and private repositories with GITHUB_TOKEN.
    """
    
    # Token environment variables to check (in priority order)
    TOKEN_ENV_VARS = ['GITHUB_TOKEN', 'GH_TOKEN', 'MCP_GITHUB_TOKEN']
    
    def __init__(self, github_token: Optional[str] = None):
        """
        Initialize MCP GitHub client
        
        Args:
            github_token: GitHub personal access token (or from GITHUB_TOKEN/GH_TOKEN/MCP_GITHUB_TOKEN env)
        """
        # Check multiple env vars for token
        self.token = github_token
        if not self.token:
            for var in self.TOKEN_ENV_VARS:
                self.token = os.getenv(var)
                if self.token:
                    break
        self.api_base = "https://api.github.com"
        self.cache_dir = Path.home() / ".reachable-cache" / "github-repos"
        self.cache_dir.mkdir(parents=True, exist_ok=True)
    
    def fetch_repository(self, repo: GitHubRepo, target_dir: Optional[Path] = None) -> Path:
        """
        Fetch repository contents via GitHub API (MCP mode - DEFAULT)
        
        Args:
            repo: GitHubRepo object with owner/repo/ref
            target_dir: Optional target directory (uses cache if None)
        
        Returns:
            Path to downloaded repository
        """
        import time
        start_time = time.time()
        
        # Use cache directory if no target specified
        if target_dir is None:
            cache_key = f"{repo.full_name}@{repo.ref}".replace('/', '_').replace(':', '_')
            target_dir = self.cache_dir / cache_key
        
        # Check if already cached
        if target_dir.exists():
            duration_ms = (time.time() - start_time) * 1000
            logger.info(f"   ✓ Using cached repository: {target_dir}")
            
            # Log cache hit
            try:
                from reachable.audit_log import get_audit_logger
                audit_logger = get_audit_logger()
                audit_logger.log_github_fetch(
                    mode='mcp',
                    repo_url=f"github:{repo.full_name}",
                    success=True,
                    duration_ms=duration_ms,
                    cached=True,
                    details={'cache_path': str(target_dir)}
                )
            except:
                pass  # Don't fail if audit logging fails
            
            return target_dir
        
        logger.info(f"   📡 [MCP] Fetching {repo.full_name} (ref: {repo.ref}) via GitHub API...")
        
        # Log authentication status with token type detection
        if self.token:
            masked = self.token[:7] + "***" + self.token[-3:] if len(self.token) > 10 else "***"
            token_type = "fine-grained" if self.token.startswith('github_pat_') else "classic" if self.token.startswith('ghp_') else "unknown"
            logger.info(f"      [MCP] Authentication: Token present ({masked}, type: {token_type})")
        else:
            logger.info(f"      [MCP] Authentication: None (public access, rate limited)")
            logger.info(f"      [MCP] Tip: Set GITHUB_TOKEN or MCP_GITHUB_TOKEN for higher rate limits")
        
        try:
            # Create target directory
            target_dir.mkdir(parents=True, exist_ok=True)
            
            # Get repository tree
            logger.info(f"      [MCP] Fetching tree SHA for ref: {repo.ref}")
            
            # Add overall timeout for entire fetch operation (60s max)
            import signal
            def timeout_handler(signum, frame):
                raise TimeoutError("MCP fetch timeout (60s) - falling back to git clone")
            
            # Set up timeout signal (Unix only)
            try:
                signal.signal(signal.SIGALRM, timeout_handler)
                signal.alarm(60)  # 60 second timeout for entire operation
            except:
                pass  # Skip on Windows
            
            tree_sha = self._get_tree_sha(repo)
            logger.info(f"      [MCP] Tree SHA: {tree_sha[:12]}...")
            
            logger.info(f"      [MCP] Fetching recursive tree...")
            tree = self._get_tree_recursive(repo, tree_sha)
            
            # Download all files
            total_files = len([item for item in tree['tree'] if item['type'] == 'blob'])
            logger.info(f"      [MCP] Found {total_files} files to download")
            downloaded = 0
            
            for item in tree['tree']:
                if item['type'] == 'blob':
                    self._download_file(repo, item, target_dir)
                    downloaded += 1
                    if downloaded % 50 == 0:
                        logger.info(f"      [MCP] Progress: {downloaded}/{total_files} files...")
            
            duration_ms = (time.time() - start_time) * 1000
            logger.info(f"      ✅ [MCP] Downloaded {downloaded} files in {duration_ms:.0f}ms")
            logger.info(f"      [MCP] Saved to: {target_dir}")
            
            # Cancel timeout signal
            try:
                signal.alarm(0)
            except:
                pass
            
            # Cancel timeout signal
            try:
                signal.alarm(0)
            except:
                pass
            
            # Log successful fetch
            try:
                from reachable.audit_log import get_audit_logger
                audit_logger = get_audit_logger()
                audit_logger.log_github_fetch(
                    mode='mcp',
                    repo_url=f"github:{repo.full_name}",
                    success=True,
                    duration_ms=duration_ms,
                    cached=False,
                    details={
                        'file_count': downloaded,
                        'cache_path': str(target_dir),
                        'ref': repo.ref
                    }
                )
            except:
                pass  # Don't fail if audit logging fails
            
            return target_dir
        
        except Exception as e:
            duration_ms = (time.time() - start_time) * 1000
            error_str = str(e)
            
            logger.debug("[MCP] Failed: {error_str}")
            
            # Check if it's a rate limit or auth error (403/401)
            is_rate_limit = ('403' in error_str or 'rate limit' in error_str.lower())
            is_auth_error = ('401' in error_str or 'unauthorized' in error_str.lower())
            
            if is_rate_limit or is_auth_error:
                if is_rate_limit:
                    logger.debug("[MCP] Reason: Rate limit exceeded or token expired")
                else:
                    logger.debug("[MCP] Reason: Authentication failed")
                
                logger.debug(f"      ⚡ [FALLBACK] Attempting git clone...")
                
                try:
                    result = self._fallback_to_git_clone(repo, target_dir, start_time)
                    return result
                except Exception as fallback_error:
                    logger.debug(f"      ❌ [FALLBACK] Git clone also failed: {fallback_error}")
                    raise Exception(f"Both MCP and git clone failed. MCP: {error_str}, Git: {fallback_error}")
            
            # Log failed fetch
            try:
                from reachable.audit_log import get_audit_logger
                audit_logger = get_audit_logger()
                audit_logger.log_github_fetch(
                    mode='mcp',
                    repo_url=f"github:{repo.full_name}",
                    success=False,
                    duration_ms=duration_ms,
                    cached=False,
                    error=error_str,
                    details={'ref': repo.ref}
                )
            except:
                pass
            
            raise
    
    def _fallback_to_git_clone(self, repo: GitHubRepo, target_dir: Path, start_time: float) -> Path:
        """
        Automatic fallback to git clone when MCP fails.
        
        This happens automatically on 403 (rate limit) or 401 (auth) errors.
        """
        # Defensive imports - ensure availability in threaded/subprocess contexts
        import subprocess
        import shutil
        import time
        import os
        
        logger.info(f"      [GIT] Initializing git clone fallback...")
        
        # Check if user has GitHub SSH access configured
        # Try SSH first (works for private repos), fallback to HTTPS (public only)
        import pathlib
        ssh_configured = (pathlib.Path.home() / '.ssh' / 'id_rsa').exists() or \
                        (pathlib.Path.home() / '.ssh' / 'id_ed25519').exists()
        
        # Prefer SSH if configured, otherwise use HTTPS
        if ssh_configured:
            clone_url = f"git@github.com:{repo.full_name}.git"
        else:
            clone_url = f"https://github.com/{repo.full_name}.git"
        
        cmd = ["git", "clone", "--depth=1", "--single-branch"]
        
        # Strip refs/tags/ or refs/heads/ prefix for git clone --branch
        branch_ref = repo.ref
        if branch_ref.startswith('refs/tags/'):
            branch_ref = branch_ref.replace('refs/tags/', '', 1)
            # CRITICAL FIX: For tags, MUST use --branch flag (git treats tags as branches)
            cmd.extend(["--branch", branch_ref])
        elif branch_ref.startswith('refs/heads/'):
            branch_ref = branch_ref.replace('refs/heads/', '', 1)
            if branch_ref != "HEAD" and branch_ref != "main" and branch_ref != "master":
                cmd.extend(["--branch", branch_ref])
        else:
            # Unknown ref format - try as branch
            if branch_ref != "HEAD" and branch_ref != "main" and branch_ref != "master":
                cmd.extend(["--branch", branch_ref])
        
        cmd.extend([clone_url, str(target_dir)])
        
        logger.info(f"      [GIT] Running: {' '.join(cmd[:5])}... ({'SSH' if ssh_configured else 'HTTPS'})")
        
        # Prevent interactive prompts
        env = os.environ.copy()
        env['GIT_TERMINAL_PROMPT'] = '0'
        env['GIT_ASKPASS'] = 'echo'
        
        try:
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=300,
                env=env
            )
            
            if result.returncode != 0:
                raise Exception(f"Git clone failed: {result.stderr}")
            
            duration_ms = (time.time() - start_time) * 1000
            
            # Count files
            file_count = sum(1 for _ in target_dir.rglob('*') if _.is_file())
            
            logger.info(f"      ✅ [GIT] Clone complete ({file_count} files, {duration_ms:.0f}ms)")
            
            # Log successful fallback
            try:
                from reachable.audit_log import get_audit_logger
                audit_logger = get_audit_logger()
                audit_logger.log_github_fetch(
                    mode='git-clone-fallback',
                    repo_url=f"github:{repo.full_name}",
                    success=True,
                    duration_ms=duration_ms,
                    cached=False,
                    details={
                        'reason': 'MCP failed, automatic fallback',
                        'file_count': file_count,
                        'ref': repo.ref
                    }
                )
            except:
                pass
            
            return target_dir
            
        except FileNotFoundError:
            raise Exception("git binary not found. Install git or fix GitHub token for MCP mode.")
        except subprocess.TimeoutExpired:
            raise Exception("Git clone timed out after 5 minutes")
        except Exception as e:
            raise Exception(f"Git clone failed: {e}")
    
    @staticmethod
    def _normalize_tag(tag: str) -> str:
        """Strip common prefixes/suffixes to get bare version number.
        
        Mirrors the same logic used in lib_manager._clone_with_git
        so both MCP and git paths resolve tags identically.
        """
        t = tag
        for prefix in ('release-', 'version-', 'rel-', 'v'):
            if t.lower().startswith(prefix):
                t = t[len(prefix):]
                break
        for suffix in ('-release', '-stable', '-final'):
            if t.lower().endswith(suffix):
                t = t[:-len(suffix)]
                break
        return t

    def _list_remote_tags(self, repo: GitHubRepo) -> List[Dict[str, str]]:
        """List all tags for a repository via GitHub API.
        
        Uses the paginated tags endpoint (100 per page) to fetch all tags.
        Returns list of {'name': tag_name, 'sha': commit_sha} dicts.
        """
        all_tags = []
        page = 1
        while True:
            url = f"{self.api_base}/repos/{repo.full_name}/tags?per_page=100&page={page}"
            try:
                data = self._api_request(url)
                if not data:
                    break
                for tag_obj in data:
                    all_tags.append({
                        'name': tag_obj['name'],
                        'sha': tag_obj.get('commit', {}).get('sha', ''),
                    })
                if len(data) < 100:
                    break
                page += 1
                # Safety: cap at 50 pages (5000 tags)
                if page > 50:
                    break
            except Exception:
                break
        return all_tags

    def _get_tree_sha(self, repo: GitHubRepo) -> str:
        """Get tree SHA for the specified ref.
        
        Strategy (mirrors lib_manager git path):
        1. Quick exact tries: v{tag}, {tag} (2 API calls max)
        2. If that fails: list all remote tags via API
        3. Normalize + exact match against tag list
        4. Fuzzy match (80%+ threshold) against tag list
        5. Fallback to default branch
        """
        
        if not repo.tag:
            # Branch or commit - try directly
            ref = repo.ref.replace('refs/', '')
            url = f"{self.api_base}/repos/{repo.full_name}/git/ref/{ref}"
            try:
                data = self._api_request(url)
                return data['object']['sha']
            except Exception as e:
                raise Exception(f"Could not find ref '{ref}' for {repo.full_name}: {e}")
        
        # --- TAG resolution ---
        tag = repo.tag
        bare_version = tag.lstrip('v')  # Normalize: "v2.0.0" → "2.0.0"
        
        # Step 1: Quick exact tries (cheap - 2 API calls max)
        quick_refs = []
        if tag.startswith('v'):
            quick_refs = [f"tags/{tag}", f"tags/{tag[1:]}"]
        else:
            quick_refs = [f"tags/v{tag}", f"tags/{tag}"]
        
        last_error = None
        for ref in quick_refs:
            url = f"{self.api_base}/repos/{repo.full_name}/git/ref/{ref}"
            try:
                data = self._api_request(url)
                return data['object']['sha']
            except Exception as e:
                last_error = e
                continue
        
        # Step 2: Quick tries failed - list all remote tags via API
        remote_tag_list = self._list_remote_tags(repo)
        
        if remote_tag_list:
            # Build lookup: tag_name -> sha
            tag_names = [t['name'] for t in remote_tag_list]
            tag_sha_map = {t['name']: t['sha'] for t in remote_tag_list}
            
            logger.info(f"      [MCP] 📋 Found {len(tag_names)} remote tags, matching '{tag}'...")
            
            # Step 3: Normalize + exact match
            matched_tag = None
            for remote_tag in tag_names:
                if self._normalize_tag(remote_tag) == bare_version:
                    matched_tag = remote_tag
                    if remote_tag != tag:
                        logger.info(f"      [MCP] 🔗 Matched: '{tag}' → tag '{matched_tag}'")
                    break
            
            # Step 4: Fuzzy match (80%+ threshold)
            if not matched_tag:
                try:
                    from rapidfuzz import fuzz, process as rf_process
                    
                    norm_map = {self._normalize_tag(t): t for t in tag_names}
                    best = rf_process.extractOne(
                        bare_version,
                        list(norm_map.keys()),
                        scorer=fuzz.ratio,
                        score_cutoff=80
                    )
                    if best:
                        matched_norm, score, _ = best
                        matched_tag = norm_map[matched_norm]
                        logger.info(f"      [MCP] 🔍 Fuzzy matched: '{tag}' → '{matched_tag}' ({score:.0f}%)")
                except ImportError:
                    pass  # rapidfuzz not available
            
            # Step 5: Resolve matched tag to SHA (already have it from listing)
            if matched_tag:
                sha = tag_sha_map.get(matched_tag)
                if sha:
                    return sha
                
                # SHA missing from tags listing - try refs API as fallback
                url = f"{self.api_base}/repos/{repo.full_name}/git/ref/tags/{matched_tag}"
                try:
                    data = self._api_request(url)
                    return data['object']['sha']
                except Exception:
                    pass
        
        # Step 6: Fallback to default branch
        try:
            url = f"{self.api_base}/repos/{repo.full_name}"
            data = self._api_request(url)
            default_branch = data['default_branch']
            
            url = f"{self.api_base}/repos/{repo.full_name}/git/ref/heads/{default_branch}"
            data = self._api_request(url)
            return data['object']['sha']
        except Exception:
            pass
        
        # Re-raise the last error
        if last_error:
            raise last_error
        raise Exception(f"Could not find ref for {repo.full_name}")
    
    def _get_tree_recursive(self, repo: GitHubRepo, tree_sha: str) -> Dict:
        """Get recursive tree structure"""
        url = f"{self.api_base}/repos/{repo.full_name}/git/trees/{tree_sha}"
        params = "?recursive=1"
        
        return self._api_request(url + params)
    
    def _download_file(self, repo: GitHubRepo, item: Dict, target_dir: Path):
        """Download a single file"""
        file_path = target_dir / item['path']
        file_path.parent.mkdir(parents=True, exist_ok=True)
        
        # Download file content
        url = f"{self.api_base}/repos/{repo.full_name}/git/blobs/{item['sha']}"
        data = self._api_request(url)
        
        # Decode base64 content
        content = base64.b64decode(data['content'])
        
        # Write to file
        with open(file_path, 'wb') as f:
            f.write(content)
    
    def _api_request(self, url: str) -> Dict:
        """Make GitHub API request with authentication"""
        request = urllib.request.Request(url)
        
        # Add authentication - support both classic and fine-grained PATs
        if self.token:
            # Fine-grained tokens start with github_pat_, classic start with ghp_
            # Both work with Bearer format (recommended by GitHub)
            if self.token.startswith('github_pat_') or self.token.startswith('ghp_'):
                request.add_header('Authorization', f'Bearer {self.token}')
            else:
                # Fallback to token format for older tokens
                request.add_header('Authorization', f'token {self.token}')
        
        request.add_header('Accept', 'application/vnd.github.v3+json')
        request.add_header('User-Agent', 'REACHABLE-Security-Scanner')
        
        try:
            with urllib.request.urlopen(request, timeout=10) as response:
                return json.loads(response.read().decode())
        except urllib.error.HTTPError as e:
            error_msg = f"GitHub API error: {e.code} {e.reason}"
            if e.code == 401:
                error_msg += " (Invalid token or insufficient permissions)"
                error_msg += "\n      [MCP] Fine-grained tokens need: Contents (read), Metadata (read)"
                error_msg += "\n      [MCP] Create token at: https://github.com/settings/tokens?type=beta"
            elif e.code == 403:
                error_msg += " (Rate limit exceeded or insufficient permissions)"
            elif e.code == 404:
                error_msg += " (Repository or ref not found)"
            raise Exception(error_msg)
        except urllib.error.URLError as e:
            raise Exception(f"GitHub API connection error: {e.reason}")

class GitCloneClient:
    """
    Legacy git clone client (OPTIONAL testing mode)
    
    Uses git binary to clone repositories.
    Only used when --git-clone flag is specified.
    """
    
    # Token environment variables to check (in priority order)
    TOKEN_ENV_VARS = ['GITHUB_TOKEN', 'GH_TOKEN', 'MCP_GITHUB_TOKEN']
    
    def __init__(self, github_token: Optional[str] = None):
        """
        Initialize git clone client
        
        Args:
            github_token: GitHub personal access token for private repos
        """
        # Check multiple env vars for token
        self.token = github_token
        if not self.token:
            for var in self.TOKEN_ENV_VARS:
                self.token = os.getenv(var)
                if self.token:
                    break
        self.cache_dir = Path.home() / ".reachable-cache" / "git-clones"
        self.cache_dir.mkdir(parents=True, exist_ok=True)
    
    def clone_repository(self, repo: GitHubRepo, target_dir: Optional[Path] = None) -> Path:
        """
        Clone repository using git (legacy mode)
        
        Args:
            repo: GitHubRepo object
            target_dir: Optional target directory
        
        Returns:
            Path to cloned repository
        """
        import time
        start_time = time.time()
        
        if target_dir is None:
            cache_key = f"{repo.full_name}@{repo.ref}".replace('/', '_').replace(':', '_')
            target_dir = self.cache_dir / cache_key
        
        # Check if already cloned
        if target_dir.exists() and (target_dir / '.git').exists():
            duration_ms = (time.time() - start_time) * 1000
            logger.info(f"   ✓ Using cached clone: {target_dir}")
            
            # Log cache hit
            try:
                from reachable.audit_log import get_audit_logger
                logger = get_audit_logger()
                logger.log_github_fetch(
                    mode='git-clone',
                    repo_url=f"github:{repo.full_name}",
                    success=True,
                    duration_ms=duration_ms,
                    cached=True,
                    details={'cache_path': str(target_dir)}
                )
            except:
                pass
            
            return target_dir
        
        logger.info(f"   🔄 Cloning {repo.full_name} (ref: {repo.ref}) via git...")
        
        # Build clone URL
        if self.token:
            clone_url = f"https://{self.token}@github.com/{repo.full_name}.git"
        else:
            clone_url = f"https://github.com/{repo.full_name}.git"
        
        # Clone repository
        cmd = ['git', 'clone', '--depth', '1']
        
        # Add branch/tag if specified
        if repo.branch:
            cmd.extend(['--branch', repo.branch])
        elif repo.tag:
            cmd.extend(['--branch', repo.tag])
        
        cmd.extend([clone_url, str(target_dir)])
        
        # Set environment to prevent credential prompts
        env = os.environ.copy()
        env['GIT_TERMINAL_PROMPT'] = '0'
        env['GIT_ASKPASS'] = 'true'
        
        try:
            subprocess.run(cmd, check=True, capture_output=True, text=True, env=env)
            
            # If commit specified, checkout that commit
            if repo.commit:
                subprocess.run(
                    ['git', '-C', str(target_dir), 'checkout', repo.commit],
                    check=True,
                    capture_output=True,
                    env=env
                )
            
            duration_ms = (time.time() - start_time) * 1000
            logger.info(f"   ✓ Cloned to {target_dir}")
            
            # Log successful clone
            try:
                from reachable.audit_log import get_audit_logger
                logger = get_audit_logger()
                logger.log_github_fetch(
                    mode='git-clone',
                    repo_url=f"github:{repo.full_name}",
                    success=True,
                    duration_ms=duration_ms,
                    cached=False,
                    details={
                        'cache_path': str(target_dir),
                        'ref': repo.ref
                    }
                )
            except:
                pass
            
            return target_dir
        
        except subprocess.CalledProcessError as e:
            duration_ms = (time.time() - start_time) * 1000
            error_msg = f"Git clone failed: {e.stderr}"
            
            # Log failed clone
            try:
                from reachable.audit_log import get_audit_logger
                logger = get_audit_logger()
                logger.log_github_fetch(
                    mode='git-clone',
                    repo_url=f"github:{repo.full_name}",
                    success=False,
                    duration_ms=duration_ms,
                    cached=False,
                    error=error_msg,
                    details={'ref': repo.ref}
                )
            except:
                pass
            
            raise Exception(error_msg)
        except FileNotFoundError:
            duration_ms = (time.time() - start_time) * 1000
            error_msg = "git binary not found. Install git or use default MCP mode."
            
            # Log failed clone
            try:
                from reachable.audit_log import get_audit_logger
                logger = get_audit_logger()
                logger.log_github_fetch(
                    mode='git-clone',
                    repo_url=f"github:{repo.full_name}",
                    success=False,
                    duration_ms=duration_ms,
                    cached=False,
                    error=error_msg
                )
            except:
                pass
            
            raise Exception(error_msg)

def analyze_github_repository(
    repo_url: str,
    use_git_clone: bool = False,
    github_token: Optional[str] = None
) -> Tuple[Path, GitHubRepo]:
    """
    Analyze GitHub repository using REACHABLE
    
    Args:
        repo_url: GitHub repository URL or shorthand (github:owner/repo)
        use_git_clone: If True, use git clone (legacy). Default: False (MCP mode)
        github_token: Optional GitHub token for private repos
    
    Returns:
        Tuple of (repository_path, GitHubRepo object)
    """
    # Parse repository URL
    repo = GitHubRepo.parse(repo_url)
    
    # Fetch repository
    if use_git_clone:
        logger.info("⚠️  Using LEGACY git clone mode (--git-clone flag specified)")
        client = GitCloneClient(github_token)
        repo_path = client.clone_repository(repo)
    else:
        logger.info("✅ Using DEFAULT MCP mode (GitHub API)")
        client = MCPGitHubClient(github_token)
        repo_path = client.fetch_repository(repo)
    
    return repo_path, repo

def clone_github_repo_mcp(repo_url: str, target_dir: str, branch_or_tag: str = None) -> bool:
    """
    Clone a GitHub repository using MCP (GitHub API) mode.
    
    This is the function called by lib_manager for library cloning.
    
    Args:
        repo_url: GitHub repository URL (https or github: format)
        target_dir: Target directory for cloning
        branch_or_tag: Branch or tag to checkout (version)
    
    Returns:
        True if successful, False otherwise
    """
    try:
        target_path = Path(target_dir)
        
        # Parse repository URL to create GitHubRepo
        repo = GitHubRepo.parse(repo_url)
        
        # Set ref if provided
        if branch_or_tag:
            repo.ref = branch_or_tag
        
        # Create MCP client
        client = MCPGitHubClient()
        
        # Fetch repository
        result_path = client.fetch_repository(repo, target_dir=target_path)
        
        return result_path.exists() and any(result_path.iterdir())
        
    except Exception as e:
        logger.debug(f"         ⚠️  MCP clone error: {str(e)[:100]}")
        return False

if __name__ == '__main__':
    import sys
    
    if len(sys.argv) < 2:
        logger.info("Usage: python mcp_github.py <repo_url> [--git-clone]")
        print()
        logger.info("Examples:")
        logger.info("  python mcp_github.py github:psf/requests")
        logger.info("  python mcp_github.py github:django/django@main")
        logger.info("  python mcp_github.py https://github.com/flask/flask")
        logger.info("  python mcp_github.py github:psf/requests --git-clone  # Legacy mode")
        sys.exit(1)
    
    repo_url = sys.argv[1]
    use_git = '--git-clone' in sys.argv
    
    try:
        repo_path, repo = analyze_github_repository(repo_url, use_git_clone=use_git)
        print()
        logger.info(f"✅ Repository ready: {repo_path}")
        logger.info(f"   Owner: {repo.owner}")
        logger.info(f"   Repo: {repo.repo}")
        logger.info(f"   Ref: {repo.ref}")
        print()
        logger.info("Next: Run REACHABLE analysis")
        logger.info(f"  ./run-validation-tests.sh {repo_path}")
    
    except Exception as e:
        logger.info(f"❌ Error: {e}")
        sys.exit(1)
