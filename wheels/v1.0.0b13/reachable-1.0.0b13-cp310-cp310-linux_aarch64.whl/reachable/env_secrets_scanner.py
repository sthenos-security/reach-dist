#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.

"""
REACHABLE Environment & Configuration Secrets Scanner (Policy ENV-001)

PURPOSE:
Scans repositories for secrets in configuration files that Semgrep misses.
These are files that should NEVER be committed to a repository.

KEY CAPABILITIES:
1. Detect credential files that shouldn't be in repos (.git-credentials, .aws/credentials)
2. Scan .env files for hardcoded secrets
3. Parse YAML/JSON configs for sensitive values
4. DECODE BASE64 and inspect contents (K8s secrets, Docker auth)
5. Detect git URL credentials (https://user:pass@github.com)
6. Flag weak/placeholder secrets (changeme, password123)

POLICY: ENV-001 - Environment & Configuration Secrets Detection
VERSION: 1.0.0
"""

import os
import re
import base64
import json
import time
import fnmatch
from pathlib import Path
from typing import Dict, List, Optional, Tuple, Set, Any
from dataclasses import dataclass, field
from enum import Enum
import logging

# Initialize module-level logger
logger = logging.getLogger(__name__)

# =============================================================================
# ENUMS
# =============================================================================

class SecretSeverity(Enum):
    CRITICAL = "CRITICAL"
    HIGH = "HIGH"
    MEDIUM = "MEDIUM"
    LOW = "LOW"
    INFO = "INFO"

class SecretType(Enum):
    PASSWORD = "password"
    API_KEY = "api_key"
    TOKEN = "token"
    PRIVATE_KEY = "private_key"
    PRIVATE_KEY_BASE64 = "private_key_base64"
    CERTIFICATE = "certificate"
    DATABASE_URL = "database_url"
    DATABASE_PASSWORD = "database_password"
    OAUTH_CLIENT_SECRET = "oauth_client_secret"
    JWT_SECRET = "jwt_secret"
    ENCRYPTION_KEY = "encryption_key"
    CLOUD_ACCESS_KEY = "cloud_access_key"
    CLOUD_SECRET_KEY = "cloud_secret_key"
    GIT_CREDENTIAL = "git_credential"
    GIT_URL_CREDENTIAL = "git_url_credential"
    REGISTRY_TOKEN = "registry_token"
    DOCKER_AUTH = "docker_auth"
    K8S_SECRET = "k8s_secret"
    WEBHOOK_SECRET = "webhook_secret"
    SMTP_PASSWORD = "smtp_password"
    SSH_KEY = "ssh_key"
    BEARER_TOKEN = "bearer_token"
    SIGNING_KEY = "signing_key"
    GENERIC_SECRET = "generic_secret"
    DECODED_SECRET = "decoded_secret"
    WEAK_SECRET = "weak_secret"
    CREDENTIAL_FILE = "credential_file"

# =============================================================================
# FORBIDDEN FILES - Should NEVER be in a repository
# =============================================================================

FORBIDDEN_CREDENTIAL_FILES = {
    ".git-credentials": ("Git credentials", SecretType.GIT_CREDENTIAL),
    ".netrc": ("Network credentials", SecretType.GIT_CREDENTIAL),
    "_netrc": ("Network credentials (Windows)", SecretType.GIT_CREDENTIAL),
    ".aws/credentials": ("AWS credentials", SecretType.CLOUD_SECRET_KEY),
    ".boto": ("Boto AWS config", SecretType.CLOUD_SECRET_KEY),
    ".s3cfg": ("S3cmd config", SecretType.CLOUD_SECRET_KEY),
    ".azure/credentials": ("Azure credentials", SecretType.CLOUD_SECRET_KEY),
    ".docker/config.json": ("Docker registry auth", SecretType.DOCKER_AUTH),
    ".dockercfg": ("Legacy Docker auth", SecretType.DOCKER_AUTH),
    ".kube/config": ("Kubernetes config", SecretType.K8S_SECRET),
    "kubeconfig": ("Kubernetes config", SecretType.K8S_SECRET),
    ".npmrc": ("npm auth tokens", SecretType.REGISTRY_TOKEN),
    ".pypirc": ("PyPI credentials", SecretType.REGISTRY_TOKEN),
    ".gem/credentials": ("RubyGems API key", SecretType.REGISTRY_TOKEN),
    ".cargo/credentials": ("Cargo registry token", SecretType.REGISTRY_TOKEN),
    ".cargo/credentials.toml": ("Cargo registry token", SecretType.REGISTRY_TOKEN),
    ".composer/auth.json": ("Composer auth", SecretType.REGISTRY_TOKEN),
    ".m2/settings.xml": ("Maven settings", SecretType.PASSWORD),
    ".pgpass": ("PostgreSQL passwords", SecretType.DATABASE_PASSWORD),
    ".my.cnf": ("MySQL credentials", SecretType.DATABASE_PASSWORD),
    ".mylogin.cnf": ("MySQL encrypted login", SecretType.DATABASE_PASSWORD),
    ".vault-token": ("Vault token", SecretType.TOKEN),
    "id_rsa": ("SSH private key", SecretType.SSH_KEY),
    "id_dsa": ("SSH private key", SecretType.SSH_KEY),
    "id_ecdsa": ("SSH private key", SecretType.SSH_KEY),
    "id_ed25519": ("SSH private key", SecretType.SSH_KEY),
}

# =============================================================================
# FILE PATTERNS TO SCAN
# =============================================================================

ENV_FILE_PATTERNS = [".env", ".env.*", "*.env", ".envrc"]
CONFIG_FILE_PATTERNS = [
    "config.yaml", "config.yml", "config.json", "config.toml",
    "settings.yaml", "settings.yml", "settings.json",
    "secrets.yaml", "secrets.yml", "security_findings.json",
    "application.properties", "application.yml", "application.yaml",
    "application-*.properties", "application-*.yml",
    "appsettings.json", "appsettings.*.json",
    "database.yml", "database.yaml",
    "docker-compose.yml", "docker-compose.yaml",
    "docker-compose.*.yml", "docker-compose.*.yaml",
    "values.yaml", "values.yml",
]
CICD_FILE_PATTERNS = [
    ".gitlab-ci.yml", ".gitlab-ci.yaml",
    ".travis.yml", ".travis.yaml",
    "azure-pipelines.yml", ".azure-pipelines.yml",
    "bitbucket-pipelines.yml",
    "Jenkinsfile", "jenkinsfile",
    "appveyor.yml", ".appveyor.yml",
    "cloudbuild.yaml", "cloudbuild.yml",
]
TERRAFORM_PATTERNS = ["*.tfvars", "terraform.tfvars", ".terraformrc"]
K8S_SECRET_PATTERNS = ["*-secret.yaml", "*-secret.yml", "secret-*.yaml", "secret-*.yml"]

# =============================================================================
# SECRET KEY PATTERNS
# =============================================================================

SECRET_KEY_PATTERNS = [
    # Passwords
    (r'(?i)^[A-Z_]*PASSWORD[A-Z_]*$', SecretType.PASSWORD),
    (r'(?i)^[A-Z_]*PASSWD[A-Z_]*$', SecretType.PASSWORD),
    (r'(?i)^[A-Z_]*PWD[A-Z_]*$', SecretType.PASSWORD),
    (r'(?i)^[A-Z_]*PASS[A-Z_]*$', SecretType.PASSWORD),
    (r'(?i)^DB_PASS.*$', SecretType.DATABASE_PASSWORD),
    (r'(?i)^.*DATABASE.*PASS.*$', SecretType.DATABASE_PASSWORD),
    (r'(?i)^POSTGRES.*PASSWORD$', SecretType.DATABASE_PASSWORD),
    (r'(?i)^MYSQL.*PASSWORD$', SecretType.DATABASE_PASSWORD),
    (r'(?i)^MONGO.*PASSWORD$', SecretType.DATABASE_PASSWORD),
    (r'(?i)^REDIS.*PASSWORD$', SecretType.DATABASE_PASSWORD),
    
    # API Keys
    (r'(?i)^[A-Z_]*API[_-]?KEY[A-Z_]*$', SecretType.API_KEY),
    (r'(?i)^[A-Z_]*APIKEY[A-Z_]*$', SecretType.API_KEY),
    (r'(?i)^ACCESS[_-]?KEY[_-]?ID$', SecretType.CLOUD_ACCESS_KEY),
    (r'(?i)^AWS[_-]?ACCESS[_-]?KEY.*$', SecretType.CLOUD_ACCESS_KEY),
    (r'(?i)^SECRET[_-]?ACCESS[_-]?KEY$', SecretType.CLOUD_SECRET_KEY),
    (r'(?i)^AWS[_-]?SECRET.*$', SecretType.CLOUD_SECRET_KEY),
    
    # Tokens
    (r'(?i)^[A-Z_]*TOKEN[A-Z_]*$', SecretType.TOKEN),
    (r'(?i)^[A-Z_]*AUTH[_-]?TOKEN[A-Z_]*$', SecretType.TOKEN),
    (r'(?i)^BEARER[_-]?TOKEN$', SecretType.BEARER_TOKEN),
    (r'(?i)^ACCESS[_-]?TOKEN$', SecretType.TOKEN),
    (r'(?i)^REFRESH[_-]?TOKEN$', SecretType.TOKEN),
    (r'(?i)^GITHUB[_-]?TOKEN$', SecretType.TOKEN),
    (r'(?i)^GITLAB[_-]?TOKEN$', SecretType.TOKEN),
    (r'(?i)^NPM[_-]?TOKEN$', SecretType.REGISTRY_TOKEN),
    (r'(?i)^_AUTHTOKEN$', SecretType.REGISTRY_TOKEN),
    
    # OAuth/OIDC
    (r'(?i)^[A-Z_]*CLIENT[_-]?SECRET[A-Z_]*$', SecretType.OAUTH_CLIENT_SECRET),
    (r'(?i)^[A-Z_]*OAUTH[_-]?SECRET[A-Z_]*$', SecretType.OAUTH_CLIENT_SECRET),
    (r'(?i)^[A-Z_]*OIDC[_-]?SECRET[A-Z_]*$', SecretType.OAUTH_CLIENT_SECRET),
    
    # JWT
    (r'(?i)^JWT[_-]?SECRET$', SecretType.JWT_SECRET),
    (r'(?i)^JWT[_-]?KEY$', SecretType.JWT_SECRET),
    (r'(?i)^SIGNING[_-]?KEY$', SecretType.SIGNING_KEY),
    (r'(?i)^SIGNING[_-]?SECRET$', SecretType.SIGNING_KEY),
    
    # Encryption
    (r'(?i)^[A-Z_]*ENCRYPTION[_-]?KEY[A-Z_]*$', SecretType.ENCRYPTION_KEY),
    (r'(?i)^[A-Z_]*CIPHER[_-]?KEY[A-Z_]*$', SecretType.ENCRYPTION_KEY),
    (r'(?i)^[A-Z_]*CIPHER[_-]?SECRET[A-Z_]*$', SecretType.ENCRYPTION_KEY),
    (r'(?i)^[A-Z_]*COOKIE[_-]?SECRET[A-Z_]*$', SecretType.ENCRYPTION_KEY),
    (r'(?i)^[A-Z_]*SESSION[_-]?SECRET[A-Z_]*$', SecretType.ENCRYPTION_KEY),
    (r'(?i)^[A-Z_]*CSRF[_-]?SECRET[A-Z_]*$', SecretType.ENCRYPTION_KEY),
    (r'(?i)^[A-Z_]*AES[_-]?KEY[A-Z_]*$', SecretType.ENCRYPTION_KEY),
    
    # Database URLs
    (r'(?i)^DATABASE[_-]?URL$', SecretType.DATABASE_URL),
    (r'(?i)^DB[_-]?URL$', SecretType.DATABASE_URL),
    (r'(?i)^CONNECTION[_-]?STRING$', SecretType.DATABASE_URL),
    (r'(?i)^.*DSN$', SecretType.DATABASE_URL),
    (r'(?i)^REDIS[_-]?URL$', SecretType.DATABASE_URL),
    (r'(?i)^MONGO.*URL$', SecretType.DATABASE_URL),
    
    # Private Keys
    (r'(?i)^[A-Z_]*PRIVATE[_-]?KEY[A-Z_]*$', SecretType.PRIVATE_KEY),
    (r'(?i)^[A-Z_]*SSH[_-]?KEY[A-Z_]*$', SecretType.SSH_KEY),
    (r'(?i)^.*KEY[_-]?BASE64$', SecretType.PRIVATE_KEY_BASE64),
    (r'(?i)^.*PEM[_-]?BASE64$', SecretType.PRIVATE_KEY_BASE64),
    (r'(?i)^.*CERTIFICATE[_-]?BASE64$', SecretType.PRIVATE_KEY_BASE64),
    
    # Webhooks
    (r'(?i)^WEBHOOK[_-]?SECRET$', SecretType.WEBHOOK_SECRET),
    (r'(?i)^SLACK[_-]?WEBHOOK.*$', SecretType.WEBHOOK_SECRET),
    (r'(?i)^DISCORD[_-]?WEBHOOK.*$', SecretType.WEBHOOK_SECRET),
    
    # SMTP
    (r'(?i)^SMTP[_-]?PASS.*$', SecretType.SMTP_PASSWORD),
    (r'(?i)^MAIL[_-]?PASS.*$', SecretType.SMTP_PASSWORD),
    (r'(?i)^SENDGRID.*KEY$', SecretType.API_KEY),
    (r'(?i)^MAILGUN.*KEY$', SecretType.API_KEY),
    
    # Hydra/Kratos/ORY (common in auth systems)
    (r'(?i)^HYDRA.*SECRET$', SecretType.GENERIC_SECRET),
    (r'(?i)^KRATOS.*SECRET$', SecretType.ENCRYPTION_KEY),
    (r'(?i)^SCIM.*TOKEN$', SecretType.BEARER_TOKEN),
    (r'(?i)^SAML.*KEY$', SecretType.PRIVATE_KEY),
    
    # Generic
    (r'(?i)^[A-Z_]*SECRET[A-Z_]*$', SecretType.GENERIC_SECRET),
    (r'(?i)^[A-Z_]*CREDENTIAL[A-Z_]*$', SecretType.GENERIC_SECRET),
]

# =============================================================================
# VALUE PATTERNS - Detect real secrets by their format
# =============================================================================

REAL_SECRET_PATTERNS = [
    # AWS
    (r'^AKIA[0-9A-Z]{16}$', "AWS Access Key ID", SecretSeverity.CRITICAL),
    (r'^[A-Za-z0-9/+=]{40}$', "AWS Secret Key (40 chars)", SecretSeverity.HIGH),
    
    # Google
    (r'^AIza[0-9A-Za-z_-]{35}$', "Google API Key", SecretSeverity.CRITICAL),
    (r'^GOCSPX-[A-Za-z0-9_-]+$', "Google OAuth Secret", SecretSeverity.CRITICAL),
    
    # GitHub
    (r'^gh[ps]_[A-Za-z0-9]{36}$', "GitHub Token", SecretSeverity.CRITICAL),
    (r'^github_pat_[A-Za-z0-9_]{22,}$', "GitHub PAT", SecretSeverity.CRITICAL),
    (r'^gho_[A-Za-z0-9]{36}$', "GitHub OAuth", SecretSeverity.CRITICAL),
    
    # GitLab
    (r'^glpat-[A-Za-z0-9_-]{20,}$', "GitLab PAT", SecretSeverity.CRITICAL),
    
    # Slack
    (r'^xox[baprs]-[0-9A-Za-z-]+$', "Slack Token", SecretSeverity.CRITICAL),
    
    # Stripe
    (r'^sk_live_[0-9a-zA-Z]{24,}$', "Stripe Live Key", SecretSeverity.CRITICAL),
    (r'^sk_test_[0-9a-zA-Z]{24,}$', "Stripe Test Key", SecretSeverity.HIGH),
    (r'^rk_live_[0-9a-zA-Z]{24,}$', "Stripe Restricted Key", SecretSeverity.CRITICAL),
    
    # npm
    (r'^npm_[A-Za-z0-9]{36}$', "npm Token", SecretSeverity.CRITICAL),
    
    # Private Keys (in value)
    (r'-----BEGIN[A-Z ]*PRIVATE KEY-----', "Private Key", SecretSeverity.CRITICAL),
    (r'-----BEGIN RSA PRIVATE KEY-----', "RSA Private Key", SecretSeverity.CRITICAL),
    (r'-----BEGIN EC PRIVATE KEY-----', "EC Private Key", SecretSeverity.CRITICAL),
    (r'-----BEGIN OPENSSH PRIVATE KEY-----', "OpenSSH Key", SecretSeverity.CRITICAL),
    (r'-----BEGIN PGP PRIVATE KEY-----', "PGP Private Key", SecretSeverity.CRITICAL),
    
    # JWT (decoded)
    (r'^eyJ[A-Za-z0-9_-]+\.eyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+$', "JWT Token", SecretSeverity.HIGH),
    
    # Database URLs with passwords
    (r'(?i)(postgres|mysql|mongodb|redis)://[^:]+:[^@]+@', "DB URL with password", SecretSeverity.CRITICAL),
]

# =============================================================================
# WEAK/PLACEHOLDER SECRETS
# =============================================================================

WEAK_SECRET_VALUES = {
    # Common placeholders
    'changeme', 'changethis', 'change_me', 'change-me', 'CHANGEME',
    'replace_me', 'replaceme', 'replace-me', 'REPLACEME',
    'your_secret', 'your_password', 'your_token', 'your_key',
    'your-secret', 'your-password', 'your-token', 'your-key',
    'xxx', 'XXX', 'xxxx', 'XXXX',
    'TODO', 'FIXME', 'todo', 'fixme',
    
    # Common weak passwords
    'password', 'password123', 'password1', 'PASSWORD',
    'admin', 'admin123', 'administrator',
    'root', 'root123', 'toor',
    'secret', 'secret123', 'SECRET',
    'test', 'test123', 'testing',
    'example', 'sample', 'demo',
    'default', 'DEFAULT',
    'development', 'dev', 'DEV',
    'staging', 'stage',
    'production', 'prod',  # Ironically weak if used as actual secret
    'foobar', 'foo', 'bar', 'baz',
    'asdf', 'asdfasdf', 'qwerty', 'qwerty123',
    '123456', '12345678', '123456789',
    'abc123', 'letmein', 'welcome',
    'monkey', 'dragon', 'master',
    'trustno1', 'whatever', 'shadow',
    
    # Placeholder patterns
    'placeholder', 'PLACEHOLDER',
    'dummy', 'DUMMY',
    'fake', 'FAKE',
    'mock', 'MOCK',
    'temp', 'temporary',
}

# Patterns that indicate placeholder (regex)
WEAK_SECRET_PATTERNS = [
    r'^changeme.*$',
    r'^replace.*$',
    r'^your[_-].*$',
    r'^xxx+$',
    r'^placeholder.*$',
    r'^dummy.*$',
    r'^fake.*$',
    r'^test.*$',
    r'^example.*$',
    r'^sample.*$',
    r'^\$\{.*\}$',  # ${VAR} - unexpanded variable
    r'^<.*>$',  # <placeholder>
    r'^\[.*\]$',  # [placeholder]
]

# =============================================================================
# DATA CLASSES
# =============================================================================

@dataclass
class EnvSecretFinding:
    """A single secret finding"""
    file_path: str
    line_number: int
    key_name: str
    secret_type: SecretType
    severity: SecretSeverity
    value_preview: str
    message: str
    category: str = ""
    is_weak_secret: bool = False
    is_base64_decoded: bool = False
    decoded_preview: str = ""
    remediation: List[str] = field(default_factory=list)
    
    def to_dict(self) -> Dict[str, Any]:
        result = {
            'file': self.file_path,
            'line': self.line_number,
            'key': self.key_name,
            'type': self.secret_type.value,
            'severity': self.severity.value,
            'value_preview': self.value_preview,
            'message': self.message,
            'category': self.category,
            'is_weak_secret': self.is_weak_secret,
            'remediation': self.remediation,
        }
        if self.is_base64_decoded:
            result['is_base64_decoded'] = True
            result['decoded_preview'] = self.decoded_preview
        return result

@dataclass 
class EnvScanResult:
    """Results from env/config scanning"""
    total_files_scanned: int = 0
    total_secrets_found: int = 0
    findings: List[EnvSecretFinding] = field(default_factory=list)
    files_with_secrets: Set[str] = field(default_factory=set)
    forbidden_files_found: List[str] = field(default_factory=list)
    secrets_by_type: Dict[str, int] = field(default_factory=dict)
    secrets_by_severity: Dict[str, int] = field(default_factory=dict)
    secrets_by_category: Dict[str, int] = field(default_factory=dict)
    weak_secrets_count: int = 0
    base64_decoded_count: int = 0
    scan_time_ms: float = 0.0
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'policy': 'ENV-001',
            'policy_name': 'Environment & Configuration Secrets Detection',
            'version': '1.0.0',
            'total_files_scanned': self.total_files_scanned,
            'total_secrets_found': self.total_secrets_found,
            'files_with_secrets': len(self.files_with_secrets),
            'forbidden_files_found': self.forbidden_files_found,
            'findings': [f.to_dict() for f in self.findings],
            'summary': {
                'by_type': self.secrets_by_type,
                'by_severity': self.secrets_by_severity,
                'by_category': self.secrets_by_category,
                'weak_secrets': self.weak_secrets_count,
                'base64_decoded': self.base64_decoded_count,
            },
            'scan_time_ms': round(self.scan_time_ms, 2),
        }

# =============================================================================
# HELPER FUNCTIONS
# =============================================================================

def mask_secret(value: str, show_chars: int = 4) -> str:
    """Mask a secret value for safe display"""
    if not value:
        return ""
    if len(value) <= show_chars * 2:
        return "*" * len(value)
    return value[:show_chars] + "*" * (len(value) - show_chars * 2) + value[-show_chars:]

def is_base64(value: str) -> bool:
    """Check if a value looks like Base64"""
    if not value or len(value) < 20:
        return False
    # Base64 pattern: alphanumeric, +, /, = padding
    if not re.match(r'^[A-Za-z0-9+/]+=*$', value):
        return False
    # Check length is valid for Base64
    if len(value) % 4 != 0:
        return False
    return True

def decode_base64(value: str) -> Optional[str]:
    """Attempt to decode Base64 value"""
    try:
        # Handle URL-safe Base64
        value = value.replace('-', '+').replace('_', '/')
        # Add padding if needed
        padding = 4 - len(value) % 4
        if padding != 4:
            value += '=' * padding
        decoded = base64.b64decode(value)
        # Try to decode as UTF-8
        return decoded.decode('utf-8', errors='replace')
    except Exception:
        return None

def is_weak_secret(value: str) -> bool:
    """Check if value is a weak/placeholder secret"""
    if not value:
        return False
    value_lower = value.lower().strip()
    
    # Check exact matches
    if value_lower in WEAK_SECRET_VALUES or value in WEAK_SECRET_VALUES:
        return True
    
    # Check patterns
    for pattern in WEAK_SECRET_PATTERNS:
        if re.match(pattern, value_lower, re.IGNORECASE):
            return True
    
    return False

def classify_key(key: str) -> Optional[SecretType]:
    """Classify a key name to determine if it's a secret"""
    for pattern, secret_type in SECRET_KEY_PATTERNS:
        if re.match(pattern, key):
            return secret_type
    return None

def check_value_pattern(value: str) -> Optional[Tuple[str, SecretSeverity]]:
    """Check if value matches known secret patterns"""
    for pattern, description, severity in REAL_SECRET_PATTERNS:
        if re.search(pattern, value):
            return (description, severity)
    return None

def get_remediation(secret_type: SecretType, file_category: str) -> List[str]:
    """Get remediation guidance for a secret type"""
    remediation = []
    
    # General guidance
    remediation.append("1. REVOKE this secret immediately")
    remediation.append("2. ROTATE to a new secret value")
    
    # Type-specific
    if secret_type in (SecretType.CLOUD_ACCESS_KEY, SecretType.CLOUD_SECRET_KEY):
        remediation.append("3. Use IAM roles or instance profiles instead")
        remediation.append("4. Use AWS Secrets Manager or SSM Parameter Store")
    elif secret_type in (SecretType.DATABASE_PASSWORD, SecretType.DATABASE_URL):
        remediation.append("3. Use environment variables from secure storage")
        remediation.append("4. Use connection poolers with IAM auth")
    elif secret_type == SecretType.PRIVATE_KEY:
        remediation.append("3. Store in HashiCorp Vault or cloud KMS")
        remediation.append("4. Use certificate managers (Let's Encrypt, ACM)")
    elif secret_type == SecretType.REGISTRY_TOKEN:
        remediation.append("3. Use credential helpers (docker-credential-*)")
        remediation.append("4. Configure CI/CD to inject tokens at runtime")
    else:
        remediation.append("3. Use a secrets manager (Vault, AWS Secrets Manager)")
        remediation.append("4. Use environment variables from secure storage")
    
    # File category specific
    if file_category == "env":
        remediation.append("5. Add .env* to .gitignore")
    elif file_category == "forbidden":
        remediation.append("5. This file should be in $HOME, not in repo")
        remediation.append("6. Remove from repo and purge from git history")
    
    return remediation

# =============================================================================
# SCANNER CLASS
# =============================================================================

class EnvSecretsScanner:
    """
    Scanner for secrets in environment and configuration files.
    
    Policy: ENV-001
    Version: 1.0.0
    """
    
    def __init__(self, 
                 scan_env: bool = True,
                 scan_configs: bool = True,
                 scan_cicd: bool = True,
                 scan_k8s: bool = True,
                 scan_shell: bool = False,
                 decode_base64: bool = True,
                 max_file_size_kb: int = 1024):
        self.scan_env = scan_env
        self.scan_configs = scan_configs
        self.scan_cicd = scan_cicd
        self.scan_k8s = scan_k8s
        self.scan_shell = scan_shell
        self.decode_base64 = decode_base64
        self.max_file_size = max_file_size_kb * 1024
    
    def scan(self, target_dir: Path) -> EnvScanResult:
        """Scan a directory for secrets in config files"""
        start_time = time.time()
        result = EnvScanResult()
        target_dir = Path(target_dir)
        
        if not target_dir.exists():
            return result
        
        # Find all files to scan
        files_to_scan = self._find_files(target_dir)
        result.total_files_scanned = len(files_to_scan)
        
        # Track forbidden files
        forbidden_files = set()
        
        # Scan each file
        for file_path, category in files_to_scan:
            # Track forbidden files
            if category == "forbidden":
                forbidden_files.add(str(file_path))
            
            findings = self._scan_file(file_path, category, target_dir)
            if findings:
                result.findings.extend(findings)
                result.files_with_secrets.add(str(file_path))
        
        # Set forbidden files found
        result.forbidden_files_found = list(forbidden_files)
        
        # Aggregate stats
        result.total_secrets_found = len(result.findings)
        for finding in result.findings:
            # By type
            type_key = finding.secret_type.value
            result.secrets_by_type[type_key] = result.secrets_by_type.get(type_key, 0) + 1
            
            # By severity
            sev_key = finding.severity.value
            result.secrets_by_severity[sev_key] = result.secrets_by_severity.get(sev_key, 0) + 1
            
            # By category
            cat_key = finding.category or "unknown"
            result.secrets_by_category[cat_key] = result.secrets_by_category.get(cat_key, 0) + 1
            
            # Weak secrets
            if finding.is_weak_secret:
                result.weak_secrets_count += 1
            
            # Base64 decoded
            if finding.is_base64_decoded:
                result.base64_decoded_count += 1
        
        result.scan_time_ms = (time.time() - start_time) * 1000
        return result
    
    def _find_files(self, target_dir: Path) -> List[Tuple[Path, str]]:
        """Find all files to scan"""
        files = []
        
        for root, dirs, filenames in os.walk(target_dir):
            # Skip .git directory contents (but not .git* files)
            if '.git' in dirs:
                dirs.remove('.git')
            
            root_path = Path(root)
            rel_root = root_path.relative_to(target_dir) if root_path != target_dir else Path('.')
            
            for filename in filenames:
                file_path = root_path / filename
                rel_path = str(rel_root / filename)
                
                # Check file size
                try:
                    if file_path.stat().st_size > self.max_file_size:
                        continue
                except OSError:
                    continue
                
                # Check for forbidden credential files
                for forbidden, _ in FORBIDDEN_CREDENTIAL_FILES.items():
                    if rel_path.endswith(forbidden) or filename == forbidden:
                        files.append((file_path, "forbidden"))
                        break
                else:
                    # Check other patterns
                    category = self._categorize_file(filename, rel_path)
                    if category:
                        files.append((file_path, category))
        
        return files
    
    def _categorize_file(self, filename: str, rel_path: str) -> Optional[str]:
        """Categorize a file for scanning"""
        # Environment files
        if self.scan_env:
            for pattern in ENV_FILE_PATTERNS:
                if fnmatch.fnmatch(filename, pattern):
                    if '.example' in filename or '.sample' in filename or '.template' in filename:
                        return "env_example"
                    return "env"
        
        # Config files
        if self.scan_configs:
            for pattern in CONFIG_FILE_PATTERNS:
                if fnmatch.fnmatch(filename, pattern):
                    return "config"
        
        # CI/CD files
        if self.scan_cicd:
            for pattern in CICD_FILE_PATTERNS:
                if fnmatch.fnmatch(filename, pattern):
                    return "cicd"
            # GitHub Actions
            if '.github/workflows' in rel_path and (filename.endswith('.yml') or filename.endswith('.yaml')):
                return "cicd"
        
        # Kubernetes secrets
        if self.scan_k8s:
            for pattern in K8S_SECRET_PATTERNS:
                if fnmatch.fnmatch(filename, pattern):
                    return "k8s"
        
        # Terraform
        for pattern in TERRAFORM_PATTERNS:
            if fnmatch.fnmatch(filename, pattern):
                return "terraform"
        
        # Shell configs
        if self.scan_shell:
            if filename in ['.bashrc', '.bash_profile', '.zshrc', '.profile', '.zprofile']:
                return "shell"
        
        return None
    
    def _scan_file(self, file_path: Path, category: str, target_dir: Path) -> List[EnvSecretFinding]:
        """Scan a single file for secrets"""
        findings = []
        rel_path = str(file_path.relative_to(target_dir))
        
        try:
            content = file_path.read_text(errors='replace')
        except Exception:
            return findings
        
        # Handle forbidden credential files
        if category == "forbidden":
            filename = file_path.name
            for forbidden_name, (desc, secret_type) in FORBIDDEN_CREDENTIAL_FILES.items():
                if filename == forbidden_name or rel_path.endswith(forbidden_name):
                    finding = EnvSecretFinding(
                        file_path=rel_path,
                        line_number=1,
                        key_name=filename,
                        secret_type=secret_type,
                        severity=SecretSeverity.CRITICAL,
                        value_preview="[FILE CONTENTS]",
                        message=f"FORBIDDEN FILE: {desc} - should be in $HOME, not committed to repo",
                        category="forbidden",
                        remediation=get_remediation(secret_type, "forbidden"),
                    )
                    findings.append(finding)
                    
                    # Also scan contents for additional secrets
                    findings.extend(self._scan_content(content, rel_path, category))
                    return findings
        
        # Scan content based on format
        if category in ("env", "env_example", "shell"):
            findings.extend(self._scan_env_format(content, rel_path, category))
        elif category in ("config", "k8s", "cicd", "terraform"):
            findings.extend(self._scan_content(content, rel_path, category))
        else:
            findings.extend(self._scan_content(content, rel_path, category))
        
        return findings
    
    def _scan_env_format(self, content: str, file_path: str, category: str) -> List[EnvSecretFinding]:
        """Scan KEY=VALUE format (env files, shell exports)"""
        findings = []
        
        # Pattern for KEY=VALUE or export KEY=VALUE
        env_pattern = re.compile(r'^(?:export\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=\s*["\']?([^"\'#\n]*)["\']?', re.MULTILINE)
        
        for line_num, line in enumerate(content.split('\n'), 1):
            line = line.strip()
            
            # Skip comments and empty lines
            if not line or line.startswith('#'):
                continue
            
            match = env_pattern.match(line)
            if not match:
                continue
            
            key = match.group(1)
            value = match.group(2).strip()
            
            # Skip empty values or very short values
            if not value or len(value) < 3:
                continue
            
            # Check if key indicates a secret
            secret_type = classify_key(key)
            
            # Also check value for known secret patterns (even if key doesn't match)
            value_check = check_value_pattern(value)
            
            # Skip if neither key nor value indicates a secret
            if not secret_type and not value_check:
                continue
            
            # Default secret type if only value pattern matched
            if not secret_type:
                secret_type = SecretType.GENERIC_SECRET
            
            # Determine severity
            severity = SecretSeverity.HIGH
            is_weak = False
            decoded_value = None
            
            # Check for weak/placeholder values
            if is_weak_secret(value):
                severity = SecretSeverity.MEDIUM
                is_weak = True
            
            # Use value pattern severity if available
            if value_check:
                severity = value_check[1]
            
            # Check for Base64 and decode
            is_b64_encoded = False
            if self.decode_base64 and is_base64(value):
                decoded_value = decode_base64(value)
                if decoded_value:
                    is_b64_encoded = True
                    # Check decoded content for secrets
                    if '-----BEGIN' in decoded_value and 'PRIVATE KEY' in decoded_value:
                        secret_type = SecretType.PRIVATE_KEY_BASE64
                        severity = SecretSeverity.CRITICAL
                    decoded_check = check_value_pattern(decoded_value)
                    if decoded_check:
                        severity = decoded_check[1]
            
            # Adjust severity for example files
            if category == "env_example":
                severity = SecretSeverity.INFO
            
            # Create finding
            finding = EnvSecretFinding(
                file_path=file_path,
                line_number=line_num,
                key_name=key,
                secret_type=secret_type,
                severity=severity,
                value_preview=mask_secret(value),
                message=f"Secret detected: {key} ({secret_type.value})",
                category=category,
                is_weak_secret=is_weak,
                is_base64_decoded=is_b64_encoded,
                decoded_preview=mask_secret(decoded_value) if decoded_value else "",
                remediation=get_remediation(secret_type, category),
            )
            findings.append(finding)
        
        return findings
    
    def _scan_content(self, content: str, file_path: str, category: str) -> List[EnvSecretFinding]:
        """Scan general content for secrets (YAML, JSON, etc.)"""
        findings = []
        lines = content.split('\n')
        
        # Check for KEY: VALUE or "KEY": "VALUE" patterns
        kv_pattern = re.compile(r'["\']?([A-Za-z_][A-Za-z0-9_]*)["\']?\s*[:=]\s*["\']?([^"\'#\n,}\]]+)["\']?')
        
        for line_num, line in enumerate(lines, 1):
            # Skip comments
            stripped = line.strip()
            if stripped.startswith('#') or stripped.startswith('//'):
                continue
            
            for match in kv_pattern.finditer(line):
                key = match.group(1)
                value = match.group(2).strip()
                
                if not value or len(value) < 3:
                    continue
                
                # Check if key indicates a secret
                secret_type = classify_key(key)
                
                # Also check value for secret patterns even if key doesn't match
                value_check = check_value_pattern(value)
                
                if not secret_type and not value_check:
                    continue
                
                if not secret_type:
                    secret_type = SecretType.GENERIC_SECRET
                
                # Determine severity
                severity = SecretSeverity.HIGH
                is_weak = False
                decoded_value = None
                is_base64_val = False
                
                if is_weak_secret(value):
                    severity = SecretSeverity.MEDIUM
                    is_weak = True
                
                if value_check:
                    severity = value_check[1]
                
                # Check for Base64
                if self.decode_base64 and is_base64(value):
                    decoded_value = decode_base64(value)
                    if decoded_value:
                        is_base64_val = True
                        if '-----BEGIN' in decoded_value and 'PRIVATE KEY' in decoded_value:
                            secret_type = SecretType.PRIVATE_KEY_BASE64
                            severity = SecretSeverity.CRITICAL
                
                # K8s secrets are often in data: blocks
                if category == "k8s" and is_base64_val:
                    secret_type = SecretType.K8S_SECRET
                    severity = SecretSeverity.CRITICAL
                
                finding = EnvSecretFinding(
                    file_path=file_path,
                    line_number=line_num,
                    key_name=key,
                    secret_type=secret_type,
                    severity=severity,
                    value_preview=mask_secret(value),
                    message=f"Secret detected: {key} ({secret_type.value})",
                    category=category,
                    is_weak_secret=is_weak,
                    is_base64_decoded=is_base64_val,
                    decoded_preview=mask_secret(decoded_value) if decoded_value else "",
                    remediation=get_remediation(secret_type, category),
                )
                findings.append(finding)
        
        # Also scan for git credential URLs
        findings.extend(self._scan_git_urls(content, file_path, category, lines))
        
        return findings
    
    def _scan_git_urls(self, content: str, file_path: str, category: str, lines: List[str]) -> List[EnvSecretFinding]:
        """Scan for git URLs with embedded credentials"""
        findings = []
        
        # Pattern: https://user:password@host or git://user:password@host
        git_url_pattern = re.compile(r'(https?|git)://([^:]+):([^@]+)@([^\s/]+)')
        
        for line_num, line in enumerate(lines, 1):
            for match in git_url_pattern.finditer(line):
                protocol = match.group(1)
                username = match.group(2)
                password = match.group(3)
                host = match.group(4)
                
                # Skip if password looks like a variable
                if password.startswith('$') or password.startswith('%'):
                    continue
                
                finding = EnvSecretFinding(
                    file_path=file_path,
                    line_number=line_num,
                    key_name=f"git_url_{host}",
                    secret_type=SecretType.GIT_URL_CREDENTIAL,
                    severity=SecretSeverity.CRITICAL,
                    value_preview=f"{protocol}://{username}:{mask_secret(password)}@{host}",
                    message=f"Git URL with embedded credentials for {host}",
                    category=category,
                    remediation=[
                        "1. Use git credential helpers instead of inline credentials",
                        "2. Use SSH keys for authentication",
                        "3. Use personal access tokens via environment variables",
                        "4. Configure .netrc in $HOME (not in repo)",
                    ],
                )
                findings.append(finding)
        
        return findings

# =============================================================================
# CLI / MAIN
# =============================================================================

def print_findings(result: EnvScanResult, verbose: bool = False):
    """Print scan results to console"""
    print("\n" + "=" * 70)
    logger.info("ENV-001: Environment & Configuration Secrets Scan")
    print("=" * 70)
    
    logger.info(f"\n📁 Files scanned: {result.total_files_scanned}")
    logger.info(f"🔐 Secrets found: {result.total_secrets_found}")
    logger.info(f"📄 Files with secrets: {len(result.files_with_secrets)}")
    
    if result.forbidden_files_found:
        logger.info(f"\n🚨 FORBIDDEN FILES IN REPO: {len(result.forbidden_files_found)}")
        for f in result.forbidden_files_found:
            logger.info(f"   ❌ {f}")
    
    if result.secrets_by_severity:
        logger.info(f"\n📊 By Severity:")
        for sev in ["CRITICAL", "HIGH", "MEDIUM", "LOW", "INFO"]:
            count = result.secrets_by_severity.get(sev, 0)
            if count:
                icon = {"CRITICAL": "🔴", "HIGH": "🟠", "MEDIUM": "🟡", "LOW": "🔵", "INFO": "⚪"}.get(sev, "⚪")
                logger.info(f"   {icon} {sev}: {count}")
    
    if result.secrets_by_category:
        logger.info(f"\n📂 By Category:")
        for cat, count in sorted(result.secrets_by_category.items()):
            logger.info(f"   • {cat}: {count}")
    
    if result.weak_secrets_count:
        logger.info(f"\n⚠️  Weak/placeholder secrets: {result.weak_secrets_count}")
    
    if result.base64_decoded_count:
        logger.info(f"🔓 Base64-decoded secrets: {result.base64_decoded_count}")
    
    if verbose and result.findings:
        logger.info(f"\n📋 Issues:")
        for f in result.findings[:20]:
            sev_icon = {"CRITICAL": "🔴", "HIGH": "🟠", "MEDIUM": "🟡", "LOW": "🔵", "INFO": "⚪"}.get(f.severity.value, "⚪")
            logger.info(f"\n   {sev_icon} {f.file_path}:{f.line_number}")
            logger.info(f"      Key: {f.key_name}")
            logger.info(f"      Type: {f.secret_type.value}")
            logger.info(f"      Value: {f.value_preview}")
            if f.is_base64_decoded:
                logger.info(f"      Decoded: {f.decoded_preview}")
        
        if len(result.findings) > 20:
            logger.info(f"\n   ... and {len(result.findings) - 20} more issues")
    
    logger.info(f"\n⏱️  Scan time: {result.scan_time_ms:.2f}ms")
    print("=" * 70)

if __name__ == '__main__':
    import sys
    
    target = Path(sys.argv[1]) if len(sys.argv) > 1 else Path('.')
    verbose = '-v' in sys.argv or '--verbose' in sys.argv
    
    scanner = EnvSecretsScanner(
        scan_env=True,
        scan_configs=True,
        scan_cicd=True,
        scan_k8s=True,
        scan_shell=True,
        decode_base64=True,
    )
    
    result = scanner.scan(target)
    print_findings(result, verbose=verbose)
    
    # Exit with error if critical secrets found
    critical = result.secrets_by_severity.get('CRITICAL', 0)
    if critical > 0:
        sys.exit(1)
