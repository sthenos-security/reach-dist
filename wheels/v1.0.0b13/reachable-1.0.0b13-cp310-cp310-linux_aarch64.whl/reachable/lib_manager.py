#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.
"""
Smart Library Manager - Multi-source auto-discovery

Discovers library repositories using multiple sources in priority order:
1. importlib.metadata (FASTEST - from installed packages, no network!)
2. PyPI API (FALLBACK - if package not installed)
3. Known repos (LAST RESORT - if all else fails)

Tracks source of each repo URL for transparency and future MCP integration.

Usage:
    # Standalone
    python lib_manager.py vulns.json libs/

    # As module
    from reachable.lib_manager import LibraryManager
    manager = LibraryManager(Path('libs'))
    manager.clone_vulnerable_libraries(vulns_data)
"""

import json
import logging
import os
import shutil
import subprocess
import sys
import time
from pathlib import Path
from typing import Dict, Set, List, Optional, Tuple
from functools import lru_cache
from concurrent.futures import ThreadPoolExecutor, as_completed
import threading

# Initialize module-level logger
logger = logging.getLogger(__name__)

class RepoInfo:
    """Information about a discovered repository"""
    def __init__(self, url: str, source: str, is_github: bool):
        self.url = url
        self.source = source  # 'installed', 'pypi', 'fallback'
        self.is_github = is_github
        self.clone_method = 'mcp' if is_github else 'git'  # Future: MCP for GitHub

class LibraryManager:
    """Manages cloning of vulnerable library source code with multi-source auto-discovery"""
    
    # Minimal fallback for when all discovery methods fail
    FALLBACK_REPOS = {
        'urllib3': 'https://github.com/urllib3/urllib3.git',
        'requests': 'https://github.com/psf/requests.git',
    }
    
    # Keys to check in metadata for source URLs
    METADATA_KEYS = ['Source', 'Source Code', 'Repository', 'Code', 'Homepage']
    
    # Directories to remove after cloning (not needed for reachability analysis)
    CLEANUP_DIRS = {
        '.git',           # Git history (not needed, saves huge space)
        '.github',        # GitHub workflows
        '.vscode',        # VS Code settings
        '.idea',          # IntelliJ settings
        'docs',           # Documentation
        'doc',            # Documentation alt
        'documentation',  # Documentation alt
        'examples',       # Example code
        'example',        # Example alt
        'test',           # Test files
        'tests',          # Test files alt
        '__tests__',      # Jest tests
        'spec',           # RSpec/Jasmine tests
        'specs',          # Tests alt
        'benchmark',      # Benchmarks
        'benchmarks',     # Benchmarks alt
        'bench',          # Benchmarks alt
        'fixtures',       # Test fixtures
        'testdata',       # Test data
        'test-data',      # Test data alt
        'coverage',       # Code coverage
        '.nyc_output',    # NYC coverage
        'node_modules',   # npm deps (shouldn't be there but just in case)
        'vendor',         # Go/Ruby vendor
        'e2e',            # End-to-end tests
        'integration',    # Integration tests
        'scripts',        # Build scripts
        'tools',          # Build tools
        '.circleci',      # CircleCI
        '.travis',        # Travis CI
        '.gitlab',        # GitLab CI
        'demo',           # Demo files
        'demos',          # Demo files alt
    }
    
    # Files to remove after cloning (not needed for analysis)
    CLEANUP_FILES = {
        'yarn.lock',
        'package-lock.json',
        'pnpm-lock.yaml',
        'Gemfile.lock',
        'poetry.lock',
        'Cargo.lock',
        '.gitignore',
        '.gitattributes',
        '.editorconfig',
        '.prettierrc',
        '.prettierrc.json',
        '.prettierrc.yaml',
        '.eslintrc',
        '.eslintrc.json',
        '.eslintrc.js',
        '.eslintignore',
        'tsconfig.json',
        'tsconfig.build.json',
        'jest.config.js',
        'jest.config.ts',
        'vitest.config.js',
        'vitest.config.ts',
        'karma.conf.js',
        'Makefile',
        'Dockerfile',
        'docker-compose.yml',
        'docker-compose.yaml',
        '.dockerignore',
        'LICENSE',
        'LICENSE.md',
        'LICENSE.txt',
        'CONTRIBUTING.md',
        'CHANGELOG.md',
        'HISTORY.md',
        'CODE_OF_CONDUCT.md',
        'SECURITY.md',
        '.npmignore',
        '.npmrc',
        'renovate.json',
        'dependabot.yml',
    }
    
    def __init__(self, libs_dir: Path, enable_discovery: bool = True, verbose: bool = True,
                 metadata_dir: Optional[Path] = None, scan_context=None, use_global_cache: bool = True):
        """
        Initialize library manager
        
        Args:
            libs_dir: Directory to clone libraries into (project-specific)
            enable_discovery: If True, use importlib.metadata and PyPI API
            verbose: Print progress messages
            metadata_dir: Directory for sharing metadata between scan steps
            scan_context: ScanContext instance with ecosystem hints from scan plan
            use_global_cache: If True, use ~/.reachable-cache/libs as global cache
        """
        self.libs_dir = Path(libs_dir)
        self.libs_dir.mkdir(parents=True, exist_ok=True)
        self.enable_discovery = enable_discovery
        self.verbose = verbose
        self.scan_context = scan_context
        self.use_global_cache = use_global_cache
        
        # Global cache directory for reuse across scans
        # Consolidated path: ~/.reachable/cache/libs (v4.5.40)
        self.global_cache_dir = Path.home() / '.reachable' / 'cache' / 'libs'
        if use_global_cache:
            self.global_cache_dir.mkdir(parents=True, exist_ok=True)
        
        # Metadata directory for CI/CD integration
        self.metadata_dir = Path(metadata_dir) if metadata_dir else self.libs_dir / ".metadata"
        self.metadata_dir.mkdir(parents=True, exist_ok=True)
        
        # Cache for discovered repos
        self._discovery_cache = {}
        
        # Track repo sources for logging/debugging
        self.repo_sources = {}  # package_name -> RepoInfo
        
        # Cloning metrics
        self.metrics = {
            'total_attempted': 0,
            'mcp_success': 0,
            'mcp_failed': 0,
            'git_success': 0,
            'git_failed': 0,
            'npm_pack_success': 0,  # npm pack fallback successes
            'npm_pack_failed': 0,
            'total_failed': 0,
            'clone_methods': [],  # List of (package, method, success)
            'direct_dependencies': 0,
            'transitive_dependencies': 0,
            'obsolete_packages': [],  # Packages that failed to clone due to missing versions
            'cache_hits': 0,  # Libraries found in global cache
            'cache_misses': 0,  # Libraries cloned fresh
            'cleanup_bytes_freed': 0,  # Total bytes freed by cleanup
            'cleanup_dirs_removed': 0,  # Total dirs removed by cleanup
            'cleanup_files_removed': 0  # Total files removed by cleanup
        }
        
        # Provenance verification (lazy loaded)
        self.verify_provenance = True
        self.provenance_verifier = None
        
        # Provenance metrics
        self.provenance_metrics = {
            'packages_checked': 0,
            'with_provenance': 0,
            'without_provenance': 0,
            'suspicious_packages': [],
            'typosquatting_detected': [],
            'integrity_verified': 0,
            'integrity_failed': 0
        }
    
    def _get_provenance_verifier(self):
        """Lazy load provenance verifier"""
        if self.provenance_verifier is None:
            try:
                from reachable.provenance_verifier import ProvenanceVerifier
                self.provenance_verifier = ProvenanceVerifier()
            except ImportError:
                if self.verbose:
                    logger.info("   ⚠️  Provenance verifier not available")
                self.verify_provenance = False
        return self.provenance_verifier
    
    def _cleanup_cloned_repo(self, target_dir: Path) -> dict:
        """
        Clean up cloned repository by removing unnecessary files/dirs.
        
        This dramatically reduces disk usage (often 70-90% reduction) by removing:
        - .git directory (git history)
        - Documentation, tests, examples, benchmarks
        - Lock files, config files, CI/CD configs
        
        Only keeps source code needed for reachability analysis.
        
        Args:
            target_dir: Path to the cloned library directory
            
        Returns:
            Dict with cleanup metrics
        """
        if not target_dir.exists():
            return {'removed_dirs': 0, 'removed_files': 0, 'bytes_freed': 0}
        
        removed_dirs = 0
        removed_files = 0
        bytes_freed = 0
        
        # Remove directories (recursive walk to catch nested ones)
        for item in list(target_dir.rglob('*')):
            if item.is_dir() and item.name.lower() in {d.lower() for d in self.CLEANUP_DIRS}:
                try:
                    # Calculate size before removal
                    dir_size = sum(f.stat().st_size for f in item.rglob('*') if f.is_file())
                    bytes_freed += dir_size
                    shutil.rmtree(item, ignore_errors=True)
                    removed_dirs += 1
                except Exception:
                    pass
        
        # Remove files at any level
        for item in list(target_dir.rglob('*')):
            if item.is_file() and item.name in self.CLEANUP_FILES:
                try:
                    bytes_freed += item.stat().st_size
                    item.unlink()
                    removed_files += 1
                except Exception:
                    pass
        
        # Also remove any remaining dotfiles/dotdirs at root level
        for item in target_dir.iterdir():
            if item.name.startswith('.') and item.name not in {'.dev'}:
                try:
                    if item.is_dir():
                        dir_size = sum(f.stat().st_size for f in item.rglob('*') if f.is_file())
                        bytes_freed += dir_size
                        shutil.rmtree(item, ignore_errors=True)
                        removed_dirs += 1
                    else:
                        bytes_freed += item.stat().st_size
                        item.unlink()
                        removed_files += 1
                except Exception:
                    pass
        
        return {
            'removed_dirs': removed_dirs,
            'removed_files': removed_files,
            'bytes_freed': bytes_freed
        }
    
    def _verify_package_provenance(self, package_name: str, version: str, ecosystem: str) -> Optional[Dict]:
        """
        Verify package provenance and integrity
        
        Returns:
            Dict with verification results or None if verification unavailable
        """
        if not self.verify_provenance or ecosystem != 'npm':
            return None
        
        verifier = self._get_provenance_verifier()
        if not verifier:
            return None
        
        self.provenance_metrics['packages_checked'] += 1
        
        try:
            result = verifier.verify_package(package_name, version)
            
            # Track provenance status
            if result.has_provenance or result.has_signatures:
                self.provenance_metrics['with_provenance'] += 1
            else:
                self.provenance_metrics['without_provenance'] += 1
            
            # Track suspicious packages
            if result.risk_level in ['high', 'critical']:
                self.provenance_metrics['suspicious_packages'].append({
                    'package': package_name,
                    'version': version,
                    'risk': result.risk_level,
                    'reasons': result.reasons
                })
            
            # Track typosquatting
            if result.is_typosquatting:
                self.provenance_metrics['typosquatting_detected'].append({
                    'package': package_name,
                    'is_typosquatting': True,
                    'similar_to': result.similar_packages
                })
            
            return {
                'has_provenance': result.has_provenance,
                'has_signatures': result.has_signatures,
                'risk_level': result.risk_level,
                'reasons': result.reasons
            }
        except Exception as e:
            if self.verbose:
                logger.info(f"   ⚠️  Provenance check failed for {package_name}: {e}")
            return None
    
    @lru_cache(maxsize=256)
    def get_repo_info(self, package_name: str, ecosystem: str = 'unknown') -> Optional['RepoInfo']:
        """
        Get repository info for a package using multi-source discovery
        
        Tries in order:
        1. importlib.metadata (from installed package) ← PRIMARY, NO NETWORK!
        2. Registry API (PyPI/NPM based on ecosystem)
        3. Fallback dictionary (if all else fails)
        
        Args:
            package_name: Name of the package (e.g., 'urllib3', 'next')
            ecosystem: Package ecosystem ('python', 'npm', 'go', 'unknown')
            
        Returns:
            RepoInfo with URL, source, and metadata, or None
        """
        if not self.enable_discovery:
            # Discovery disabled, use fallback only
            if package_name in self.FALLBACK_REPOS:
                url = self._normalize_git_url(self.FALLBACK_REPOS[package_name])
                is_github = self._is_github_repo(url)
                info = RepoInfo(url, source='fallback', is_github=is_github)
                self.repo_sources[package_name] = info
                return info
            return None
        
        # Try 1: importlib.metadata (BEST - no network, instant!) - Python only
        if ecosystem in ('python', 'unknown'):
            url = self._query_installed_metadata(package_name)
            if url:
                is_github = self._is_github_repo(url)
                info = RepoInfo(url, source='installed', is_github=is_github)
                self.repo_sources[package_name] = info
                return info
        
        # Try 2: Registry API based on ecosystem
        if ecosystem == 'npm':
            url = self._query_npm(package_name)
        elif ecosystem == 'python':
            url = self._query_pypi(package_name)
        elif ecosystem == 'go':
            # Go modules use their import path as the repo
            url = self._get_go_repo(package_name)
        else:
            # Unknown ecosystem - try PyPI as fallback
            url = self._query_pypi(package_name)
        
        if url:
            is_github = self._is_github_repo(url)
            source = f'{ecosystem}-registry' if ecosystem != 'unknown' else 'pypi'
            info = RepoInfo(url, source=source, is_github=is_github)
            self.repo_sources[package_name] = info
            return info
        
        # Try 3: Fallback dictionary (LAST RESORT)
        if package_name in self.FALLBACK_REPOS:
            url = self._normalize_git_url(self.FALLBACK_REPOS[package_name])
            is_github = self._is_github_repo(url)
            info = RepoInfo(url, source='fallback', is_github=is_github)
            self.repo_sources[package_name] = info
            return info
        
        # Not found anywhere
        return None
    
    def _query_installed_metadata(self, package_name: str) -> Optional[str]:
        """
        Query installed package metadata using importlib.metadata
        
        This is the FASTEST method - no network calls!
        Uses metadata from the installed package in the environment.
        
        Returns:
            Git repository URL or None
        """
        try:
            from importlib.metadata import metadata
            
            md = metadata(package_name)
            
            # Try Project-URL entries first (most reliable)
            project_urls = md.get_all('Project-URL')
            if project_urls:
                for entry in project_urls:
                    # Format: "Source, https://github.com/org/repo"
                    parts = entry.split(',', 1)
                    if len(parts) == 2:
                        key, url = parts[0].strip(), parts[1].strip()
                        if key in self.METADATA_KEYS:
                            if self._is_valid_git_url(url):
                                return self._normalize_git_url(url)
            
            # Fallback to Home-page
            home_page = md.get('Home-page')
            if home_page and self._is_valid_git_url(home_page):
                return self._normalize_git_url(home_page)
            
            return None
            
        except Exception:
            # Package not installed or metadata unavailable
            return None
    
    def _query_pypi(self, package_name: str) -> Optional[str]:
        """
        Query PyPI JSON API for package repository URL
        
        Fallback for when package is not installed locally.
        
        Returns:
            Git repository URL or None
        """
        # Check cache first
        if package_name in self._discovery_cache:
            return self._discovery_cache[package_name]
        
        try:
            import requests
            
            response = requests.get(
                f"https://pypi.org/pypi/{package_name}/json",
                timeout=5
            )
            response.raise_for_status()
            data = response.json()
            
            # Look for source code URL in project_urls
            project_urls = data.get('info', {}).get('project_urls', {})
            
            if project_urls:
                for key in self.METADATA_KEYS:
                    if key in project_urls:
                        url = project_urls[key]
                        if self._is_valid_git_url(url):
                            url = self._normalize_git_url(url)
                            self._discovery_cache[package_name] = url
                            return url
            
            self._discovery_cache[package_name] = None
            return None
            
        except Exception:
            # Network error, package doesn't exist, etc.
            self._discovery_cache[package_name] = None
            return None
    
    def _query_npm(self, package_name: str) -> Optional[str]:
        """Query NPM registry for package repository URL"""
        if package_name in self._discovery_cache:
            return self._discovery_cache[package_name]
        
        try:
            import requests
            response = requests.get(f"https://registry.npmjs.org/{package_name}", timeout=5)
            response.raise_for_status()
            data = response.json()
            
            repo = data.get('repository', {})
            url = repo.get('url', '') if isinstance(repo, dict) else (repo if isinstance(repo, str) else '')
            
            if url.startswith('git+'):
                url = url[4:]
            
            if url and self._is_valid_git_url(url):
                normalized = self._normalize_git_url(url)
                self._discovery_cache[package_name] = normalized
                return normalized
            
            homepage = data.get('homepage', '')
            if homepage and self._is_valid_git_url(homepage):
                normalized = self._normalize_git_url(homepage)
                self._discovery_cache[package_name] = normalized
                return normalized
            
            self._discovery_cache[package_name] = None
            return None
        except Exception:
            self._discovery_cache[package_name] = None
            return None
    
    def get_package_age_info(self, package_name: str, version: str, ecosystem: str) -> Optional[dict]:
        """
        Get package age information from registry.
        Returns publish date, age in days, and risk assessment.
        """
        from datetime import datetime, timezone
        
        try:
            import requests
            
            publish_date = None
            latest_version = None
            is_deprecated = False
            
            if ecosystem == 'npm':
                response = requests.get(f"https://registry.npmjs.org/{package_name}", timeout=10)
                if response.status_code == 200:
                    data = response.json()
                    
                    # Get publish date for specific version
                    time_data = data.get('time', {})
                    if version in time_data:
                        publish_date = time_data[version]
                    
                    # Get latest version
                    dist_tags = data.get('dist-tags', {})
                    latest_version = dist_tags.get('latest')
                    
                    # Check if deprecated
                    versions = data.get('versions', {})
                    if version in versions:
                        is_deprecated = versions[version].get('deprecated') is not None
                        
            elif ecosystem == 'python':
                response = requests.get(f"https://pypi.org/pypi/{package_name}/json", timeout=10)
                if response.status_code == 200:
                    data = response.json()
                    
                    # Get publish date for specific version
                    releases = data.get('releases', {})
                    if version in releases and releases[version]:
                        publish_date = releases[version][0].get('upload_time_iso_8601') or releases[version][0].get('upload_time')
                    
                    # Get latest version
                    latest_version = data.get('info', {}).get('version')
                    
            elif ecosystem == 'go':
                # Go proxy API
                clean_version = version.lstrip('v')
                response = requests.get(f"https://proxy.golang.org/{package_name}/@v/{clean_version}.info", timeout=10)
                if response.status_code == 200:
                    data = response.json()
                    publish_date = data.get('Time')
            
            if not publish_date:
                return None
            
            # Parse date and calculate age
            if isinstance(publish_date, str):
                # Handle various date formats
                for fmt in ['%Y-%m-%dT%H:%M:%S.%fZ', '%Y-%m-%dT%H:%M:%SZ', '%Y-%m-%dT%H:%M:%S', '%Y-%m-%d %H:%M:%S']:
                    try:
                        pub_dt = datetime.strptime(publish_date.split('+')[0].split('.')[0] + 'Z', '%Y-%m-%dT%H:%M:%SZ')
                        break
                    except:
                        try:
                            pub_dt = datetime.strptime(publish_date[:19], '%Y-%m-%dT%H:%M:%S')
                            break
                        except:
                            continue
                else:
                    return None
            else:
                return None
            
            now = datetime.now(timezone.utc).replace(tzinfo=None)
            age_days = (now - pub_dt).days
            age_years = round(age_days / 365.25, 1)
            
            # Risk assessment based on age
            if age_years >= 5:
                risk_level = 'CRITICAL'
                risk_reason = f'Extremely old ({age_years} years) - likely unmaintained and insecure'
            elif age_years >= 3:
                risk_level = 'HIGH'
                risk_reason = f'Very old ({age_years} years) - may have unpatched vulnerabilities'
            elif age_years >= 2:
                risk_level = 'MEDIUM'
                risk_reason = f'Old version ({age_years} years) - consider upgrading'
            elif age_years >= 1:
                risk_level = 'LOW'
                risk_reason = f'Aging version ({age_years} years)'
            else:
                risk_level = 'INFO'
                risk_reason = 'Recently published'
            
            # Check version lag
            versions_behind = None
            if latest_version and latest_version != version:
                # Just note that it's not latest
                risk_reason += f' (latest: {latest_version})'
            
            if is_deprecated:
                risk_level = 'CRITICAL'
                risk_reason = 'DEPRECATED by maintainer - ' + risk_reason
            
            return {
                'package': package_name,
                'version': version,
                'ecosystem': ecosystem,
                'publish_date': publish_date,
                'age_days': age_days,
                'age_years': age_years,
                'latest_version': latest_version,
                'is_deprecated': is_deprecated,
                'risk_level': risk_level,
                'risk_reason': risk_reason
            }
            
        except Exception as e:
            return None
    
    def _get_go_repo(self, package_name: str) -> Optional[str]:
        """Get Go module repository URL from import path"""
        # Strip Go module version suffixes (e.g., /v2, /v9) from path
        # Example: github.com/redis/go-redis/v9 → github.com/redis/go-redis
        import re
        package_name = re.sub(r'/v\d+$', '', package_name)
        
        if package_name.startswith('github.com/'):
            return f"https://{package_name}.git"
        elif package_name.startswith('golang.org/x/'):
            module_name = package_name.replace('golang.org/x/', '')
            return f"https://go.googlesource.com/{module_name}"
        return None
    
    def _is_valid_git_url(self, url: str) -> bool:
        """Check if URL looks like a valid git repository"""
        if not url:
            return False
        
        # Support GitHub, GitLab, Bitbucket, SourceForge, etc.
        git_hosts = [
            'github.com',
            'gitlab.com', 
            'bitbucket.org',
            'git.sr.ht',
            'codeberg.org',
            'sourceforge.net',
        ]
        
        url_lower = url.lower()
        return any(host in url_lower for host in git_hosts)
    
    def _is_github_repo(self, url: str) -> bool:
        """Check if URL is a GitHub repository (for future MCP integration)"""
        return 'github.com' in url.lower()
    
    def _normalize_git_url(self, url: str) -> str:
        """
        Normalize URL to git clone format
        
        Converts various URL formats to https:// which is the only reliable protocol:
          git://github.com/user/repo.git -> https://github.com/user/repo.git
          git+https://github.com/user/repo -> https://github.com/user/repo.git
          ssh://git@github.com/user/repo -> https://github.com/user/repo.git
          github.com/user/repo -> https://github.com/user/repo.git
          https://github.com/urllib3/urllib3 -> https://github.com/urllib3/urllib3.git
        
        Note: GitHub disabled git:// protocol in 2022, so we must convert to https://
        """
        # Remove trailing slashes
        url = url.rstrip('/')
        
        # Convert git:// to https:// (GitHub disabled git protocol in 2022)
        if url.startswith('git://'):
            url = url.replace('git://', 'https://', 1)
        
        # Convert git+https:// to https://
        if url.startswith('git+https://'):
            url = url.replace('git+https://', 'https://', 1)
        
        # Convert git+ssh:// or ssh:// to https://
        if url.startswith('git+ssh://') or url.startswith('ssh://'):
            url = url.replace('git+ssh://', 'https://', 1)
            url = url.replace('ssh://', 'https://', 1)
            # Also need to remove git@ if present
            url = url.replace('git@github.com:', 'github.com/', 1)
            url = url.replace('git@github.com/', 'github.com/', 1)
        
        # Handle git@github.com:user/repo format (SSH shorthand)
        if url.startswith('git@github.com:'):
            url = 'https://github.com/' + url.replace('git@github.com:', '', 1)
        
        # Ensure https:// prefix for GitHub URLs
        if 'github.com' in url and not url.startswith('https://'):
            # Extract the path portion
            if '://' in url:
                url = 'https://' + url.split('://', 1)[1]
            else:
                url = 'https://' + url
        
        # Add .git if not present and it's a GitHub URL
        if 'github.com' in url and not url.endswith('.git'):
            url = url + '.git'
        
        return url
    
    def get_vulnerable_packages(self, vulns_data: dict) -> Dict[str, dict]:
        """
        Extract unique vulnerable packages from Grype output with ecosystem info
        
        Returns:
            Dict mapping package_name -> {'versions': set(), 'ecosystem': str, 'is_transitive': bool}
        """
        vulnerable = {}
        
        for match in vulns_data.get('matches', []):
            pkg_name = match['artifact']['name']
            pkg_version = match['artifact']['version']
            pkg_type = match['artifact'].get('type', 'unknown')
            
            # Check if this is a transitive dependency
            # Grype/Syft marks this in relationships or metadata
            relationships = match.get('relatedVulnerabilities', [])
            metadata = match['artifact'].get('metadata', {})
            is_transitive = metadata.get('is_transitive', False) or len(relationships) > 0
            
            # Use scan context for ecosystem hints if available
            if self.scan_context:
                # Try scan context first (most accurate for monorepos)
                hint = self.scan_context.get_ecosystem_hint(pkg_name)
                if hint != 'unknown':
                    ecosystem = hint
                else:
                    # Fallback to basic detection from artifact type
                    if pkg_type in ('npm', 'yarn'):
                        ecosystem = 'npm'
                    elif pkg_type in ('python', 'wheel', 'egg'):
                        ecosystem = 'python'
                    elif pkg_type in ('go-module', 'go-binary'):
                        ecosystem = 'go'
                    elif 'go' in pkg_name or pkg_name.startswith('golang.org') or pkg_name.startswith('github.com'):
                        ecosystem = 'go'
                    else:
                        ecosystem = 'unknown'
            else:
                # No scan context - use basic detection
                if pkg_type in ('npm', 'yarn'):
                    ecosystem = 'npm'
                elif pkg_type in ('python', 'wheel', 'egg'):
                    ecosystem = 'python'
                elif pkg_type in ('go-module', 'go-binary'):
                    ecosystem = 'go'
                elif 'go' in pkg_name or pkg_name.startswith('golang.org') or pkg_name.startswith('github.com'):
                    ecosystem = 'go'
                else:
                    ecosystem = 'unknown'
            
            if pkg_name not in vulnerable:
                vulnerable[pkg_name] = {
                    'versions': set(),
                    'ecosystem': ecosystem,
                    'is_transitive': is_transitive
                }
            
            vulnerable[pkg_name]['versions'].add(pkg_version)
            # Update transitive flag (if any version is direct, mark as direct)
            if not is_transitive:
                vulnerable[pkg_name]['is_transitive'] = False
        
        return vulnerable
    
    def should_clone_library(self, package_name: str, vulnerable_packages: Dict) -> bool:
        """
        Decide if we should clone this library's source code
        
        Only clone if:
        1. Package has CVEs
        2. We can find a repo URL (any discovery method)
        3. It's not already cloned
        """
        if package_name not in vulnerable_packages:
            return False
        
        # Get ecosystem from vulnerable_packages dict
        pkg_info = vulnerable_packages[package_name]
        ecosystem = pkg_info.get('ecosystem', 'unknown') if isinstance(pkg_info, dict) else 'unknown'
        
        repo_info = self.get_repo_info(package_name, ecosystem)
        if not repo_info:
            return False
        
        lib_path = self.libs_dir / package_name
        if lib_path.exists():
            if self.verbose:
                logger.info(f"      ✓ {package_name} already cloned")
            return False
        
        return True
    
    def _clone_with_mcp(self, repo_url: str, target_dir: Path, version: str) -> bool:
        """
        Clone using MCP (Model Context Protocol) for GitHub repos.
        
        Returns True if successful, False otherwise.
        """
        try:
            # Import MCP GitHub module
            from reachable.mcp_github import clone_github_repo_mcp
            
            # Defensive: normalize URL in case it wasn't normalized earlier
            # This handles edge cases like git:// URLs from npm registry
            normalized_url = self._normalize_git_url(repo_url)
            
            if self.verbose:
                logger.info(f"         🔄 Trying MCP clone...")
            
            success = clone_github_repo_mcp(normalized_url, str(target_dir), branch_or_tag=version)
            
            if success:
                if self.verbose:
                    logger.info(f"         ✅ MCP clone successful")
                return True
            else:
                if self.verbose:
                    logger.info(f"         ⚠️  MCP clone failed")
                return False
                
        except ImportError:
            if self.verbose:
                logger.info(f"         ⚠️  MCP not available (module not found)")
            return False
        except Exception as e:
            if self.verbose:
                logger.info(f"         ⚠️  MCP error: {str(e)[:100]}")
            return False
    
    def _clone_with_git(self, repo_url: str, target_dir: Path, version: str, ecosystem: str = "unknown", package_name: str = None) -> bool:
        """
        Clone using git clone command (fallback method).
        
        Args:
            repo_url: Git repository URL
            target_dir: Target directory for cloning
            version: Version/tag to clone
            ecosystem: Package ecosystem ('npm', 'pypi', 'go')
            package_name: Package name (needed for npm registry fallback)
        
        Returns True if successful, False otherwise.
        """
        # Prevent any interactive prompts
        env = os.environ.copy()
        env['GIT_TERMINAL_PROMPT'] = '0'  # No terminal prompts
        env['GIT_ASKPASS'] = 'echo'       # Return empty for password prompts
        
        if self.verbose:
            logger.info(f"         🔄 Trying git clone...")
        
        # Try to clone at specific version tag
        # Let git use whatever auth is configured (SSH keys, credential helpers, etc)
        
        # Handle Go pseudo-versions (e.g., v0.0.0-20190812203447-cdfb69ac37fc)
        # Format 1: v0.0.0-YYYYMMDDHHMMSS-commithash (standard)
        # Format 2: vX.Y.Z-0.YYYYMMDDHHMMSS-commithash (non-standard, e.g. gogo/protobuf)
        import re
        go_pseudo_version = re.match(r'v\d+\.\d+\.\d+-(?:0\.)?(\d{14})-([a-f0-9]{12,40})$', version)
        
        if go_pseudo_version:
            # Extract commit SHA from pseudo-version
            commit_sha = go_pseudo_version.group(2)  # group(2) because we have 2 capture groups now
            if self.verbose:
                logger.info(f"         🔍 Detected Go pseudo-version")
                logger.info(f"         📌 Commit SHA: {commit_sha}")
            
            # Clone the full repo first (shallow won't work for specific commits)
            try:
                subprocess.run(
                    ['git', 'clone', '--no-checkout', repo_url, str(target_dir)],
                    check=True,
                    capture_output=True,
                    text=True,
                    env=env,
                    timeout=120
                )
                
                # Checkout specific commit
                subprocess.run(
                    ['git', '-C', str(target_dir), 'checkout', commit_sha],
                    check=True,
                    capture_output=True,
                    text=True,
                    timeout=30
                )
                
                if self.verbose:
                    logger.info(f"         ✅ Cloned at commit {commit_sha[:12]}")
                return True
                
            except subprocess.CalledProcessError as e:
                if self.verbose:
                    logger.info(f"         ❌ Failed to clone Go pseudo-version")
                    logger.info(f"         💡 Commit {commit_sha} may not exist in repository")
                return False
            except subprocess.TimeoutExpired:
                if self.verbose:
                    logger.info(f"         ❌ Git clone timeout")
                return False
        
        # Try multiple tag/branch formats (for normal version tags)
        # Different projects use different tag naming conventions:
        # - Most: v1.2.3 or 1.2.3
        # - H2 Database: version-2.0.202
        # - Spring: v5.3.21 or 5.3.21
        # - Some Java: release-1.2.3
        version_formats_list = [
            version,              # e.g., "5.2.18" or "v5.2.18"
            f"v{version}" if not version.startswith('v') else version,  # Add v if not present
            version.lstrip('v'),  # Remove v if present (e.g., v9.7.0 -> 9.7.0)
            f"version-{version.lstrip('v')}",  # H2 Database style: version-2.0.202
            f"{version}-release", # e.g., "5.2.18-release"
            f"release-{version}", # e.g., "release-5.2.18"
            f"release-{version.lstrip('v')}", # release-5.2.18 (without v)
            f"@{version}",        # npm style @version
            f"v{version.lstrip('v')}-stable",  # stable tags
            version.rsplit('.', 1)[0] if '.' in version else version,  # Try without patch (e.g., v9.7.0 -> v9.7)
        ]
        # Remove duplicates while preserving order
        version_formats = list(dict.fromkeys(version_formats_list))
        
        git_success = False
        last_error = None
        
        for version_format in version_formats:
            try:
                result = subprocess.run(
                    ['git', 'clone', '--depth', '1', '--branch', version_format, 
                     repo_url, str(target_dir)],
                    check=True,
                    capture_output=True,
                    text=True,
                    env=env,
                    timeout=60
                )
                
                if self.verbose:
                    logger.info(f"         ✅ Git clone successful (tag: {version_format})")
                git_success = True
                break
                
            except subprocess.CalledProcessError as e:
                last_error = e
                continue
            except subprocess.TimeoutExpired:
                if self.verbose:
                    logger.info(f"         ❌ Git clone timeout (60s)")
                return False
        
        if git_success:
            return True
        
        # FALLBACK FOR NPM: Try commit-based cloning
        # Many old npm versions don't have git tags but DO have commit SHAs in registry
        if ecosystem == 'npm' and repo_url:
            if self.verbose:
                logger.info(f"         🔄 Tag not found, trying npm registry for commit SHA...")
            
            try:
                import requests
                # Query npm registry for this version's git commit
                npm_api_url = f"https://registry.npmjs.org/{package_name}/{version}"
                response = requests.get(npm_api_url, timeout=10)
                
                if response.status_code == 200:
                    npm_data = response.json()
                    git_head = npm_data.get('gitHead')
                    
                    if git_head:
                        if self.verbose:
                            logger.info(f"         📌 Found commit SHA from npm: {git_head[:8]}")
                        
                        # Clone repo and checkout specific commit
                        try:
                            # Clone entire repo (shallow won't work for specific commits)
                            subprocess.run(
                                ['git', 'clone', '--no-checkout', repo_url, str(target_dir)],
                                check=True,
                                capture_output=True,
                                text=True,
                                env=env,
                                timeout=120
                            )
                            
                            # Checkout specific commit
                            subprocess.run(
                                ['git', '-C', str(target_dir), 'checkout', git_head],
                                check=True,
                                capture_output=True,
                                text=True,
                                timeout=30
                            )
                            
                            if self.verbose:
                                logger.info(f"         ✅ Cloned at commit {git_head[:8]} (from npm registry)")
                            return True
                            
                        except (subprocess.CalledProcessError, subprocess.TimeoutExpired) as e:
                            # Clean up partial clone
                            if target_dir.exists():
                                shutil.rmtree(target_dir, ignore_errors=True)
                            if self.verbose:
                                logger.info(f"         ❌ Commit {git_head[:8]} not found in git repo")
            except Exception as e:
                if self.verbose:
                    logger.info(f"         ⚠️  npm registry check failed: {e}")
        
        # FALLBACK FOR NPM: Use npm pack to download the published tarball
        # This works even for very old versions where git tags don't exist
        if ecosystem == 'npm' and package_name:
            if self.verbose:
                logger.info(f"         🔄 Trying npm pack (registry tarball)...")
            
            try:
                import tempfile
                
                with tempfile.TemporaryDirectory() as tmpdir:
                    # Run npm pack to download the tarball
                    pack_result = subprocess.run(
                        ['npm', 'pack', f'{package_name}@{version}'],
                        cwd=tmpdir,
                        capture_output=True,
                        text=True,
                        timeout=60
                    )
                    
                    if pack_result.returncode == 0:
                        # Find the downloaded tarball
                        tarball_name = pack_result.stdout.strip()
                        tarball_path = Path(tmpdir) / tarball_name
                        
                        if tarball_path.exists():
                            # Extract the tarball
                            import tarfile
                            target_dir.mkdir(parents=True, exist_ok=True)
                            
                            with tarfile.open(tarball_path, 'r:gz') as tar:
                                # npm pack creates a 'package' directory inside
                                tar.extractall(path=tmpdir)
                            
                            # Move contents from 'package' folder to target_dir
                            package_dir = Path(tmpdir) / 'package'
                            if package_dir.exists():
                                for item in package_dir.iterdir():
                                    shutil.move(str(item), str(target_dir / item.name))
                            
                            if self.verbose:
                                logger.info(f"         ✅ Downloaded via npm pack (registry tarball)")
                            return True
                    else:
                        if self.verbose:
                            logger.info(f"         ❌ npm pack failed: {pack_result.stderr.strip()[:100]}")
            except subprocess.TimeoutExpired:
                if self.verbose:
                    logger.info(f"         ❌ npm pack timeout")
            except Exception as e:
                if self.verbose:
                    logger.info(f"         ⚠️  npm pack failed: {e}")
        
        # All tag formats failed
        if self.verbose:
            logger.info(f"         ❌ Version '{version}' not found (tried: {', '.join(version_formats)})")
        
        # Check if this version EXISTS in registry but is just not in git (OBSOLETE)
        obsolete_info = self._check_if_obsolete_in_registry(package_name, version, ecosystem)
        
        if obsolete_info:
            if self.verbose:
                logger.info(f"         📦 Version {version} EXISTS in registry but not in git")
                logger.info(f"         ⚠️  OBSOLETE PACKAGE: {obsolete_info.get('reason', 'deprecated')}")
                if obsolete_info.get('age_years'):
                    logger.info(f"         📅 Package age: {obsolete_info['age_years']:.1f} years old")
                if obsolete_info.get('latest_version'):
                    logger.info(f"         📌 Latest available: {obsolete_info['latest_version']}")
                if obsolete_info.get('deprecated'):
                    logger.info(f"         🚨 DEPRECATED: {obsolete_info.get('deprecation_message', 'No message')}")
            
            # Track as OBSOLETE (unhealthy) package
            self.metrics['obsolete_packages'].append({
                'package': package_name,
                'version': version,
                'ecosystem': ecosystem,
                'reason': 'obsolete_not_in_git',
                'age_years': obsolete_info.get('age_years'),
                'latest_version': obsolete_info.get('latest_version'),
                'deprecated': obsolete_info.get('deprecated', False),
                'deprecation_message': obsolete_info.get('deprecation_message'),
                'publish_date': obsolete_info.get('publish_date'),
                'health_status': 'CRITICAL',  # Mark as unhealthy
                'message': f"Version {version} is obsolete - exists in registry but removed from git"
            })
        else:
            # Truly not found anywhere
            self.metrics['obsolete_packages'].append({
                'package': package_name,
                'version': version,
                'ecosystem': ecosystem,
                'reason': 'version_not_found',
                'health_status': 'UNKNOWN',
                'message': f"Version {version} not found in git or registry"
            })
        
        return False
    
    def _check_if_obsolete_in_registry(self, package_name: str, version: str, ecosystem: str) -> Optional[dict]:
        """
        Check if a package version exists in registry but is obsolete/deprecated.
        
        Returns dict with obsolete info if found, None if not in registry at all.
        """
        from datetime import datetime
        
        try:
            import requests
        except ImportError:
            return None
        
        if ecosystem == 'npm':
            try:
                # Check npm registry for this specific version
                response = requests.get(
                    f"https://registry.npmjs.org/{package_name}/{version}",
                    timeout=10
                )
                
                if response.status_code == 200:
                    version_data = response.json()
                    
                    # Get full package info for latest version
                    full_response = requests.get(
                        f"https://registry.npmjs.org/{package_name}",
                        timeout=10
                    )
                    
                    result = {
                        'exists_in_registry': True,
                        'deprecated': version_data.get('deprecated') is not None,
                        'deprecation_message': version_data.get('deprecated'),
                    }
                    
                    if full_response.status_code == 200:
                        full_data = full_response.json()
                        result['latest_version'] = full_data.get('dist-tags', {}).get('latest')
                        
                        # Calculate age
                        time_data = full_data.get('time', {})
                        if version in time_data:
                            publish_date = time_data[version]
                            result['publish_date'] = publish_date
                            try:
                                pub_dt = datetime.fromisoformat(publish_date.replace('Z', '+00:00'))
                                age_days = (datetime.now(pub_dt.tzinfo) - pub_dt).days
                                result['age_years'] = age_days / 365.25
                                
                                # Determine reason
                                if result['deprecated']:
                                    result['reason'] = 'deprecated'
                                elif result['age_years'] > 5:
                                    result['reason'] = 'ancient (>5 years old)'
                                elif result['age_years'] > 3:
                                    result['reason'] = 'very old (>3 years)'
                                else:
                                    result['reason'] = 'old version not in git'
                            except:
                                result['reason'] = 'old version'
                    
                    return result
                    
            except Exception as e:
                pass
        
        elif ecosystem in ['go', 'golang']:
            try:
                # Check Go proxy for module info
                module_name = package_name.replace('golang.org/', 'golang.org/')
                response = requests.get(
                    f"https://proxy.golang.org/{module_name}/@v/list",
                    timeout=10
                )
                
                if response.status_code == 200:
                    versions = response.text.strip().split('\n')
                    version_clean = version.lstrip('v')
                    
                    if version in versions or f"v{version_clean}" in versions:
                        return {
                            'exists_in_registry': True,
                            'reason': 'exists in Go proxy but not clonable',
                            'latest_version': versions[-1] if versions else None
                        }
            except:
                pass
        
        elif ecosystem == 'pypi':
            try:
                response = requests.get(
                    f"https://pypi.org/pypi/{package_name}/{version}/json",
                    timeout=10
                )
                
                if response.status_code == 200:
                    data = response.json()
                    info = data.get('info', {})
                    
                    return {
                        'exists_in_registry': True,
                        'deprecated': info.get('yanked', False),
                        'deprecation_message': info.get('yanked_reason'),
                        'reason': 'yanked' if info.get('yanked') else 'old version'
                    }
            except:
                pass
        
        return None
    
    def clone_library(self, package_name: str, version: str, ecosystem: str = "unknown") -> Optional[Path]:
        """
        Clone library source code at specific version.
        
        STRATEGY (Priority Order):
        1. Check global cache (~/.reachable-cache/libs) - INSTANT
        2. Try MCP (if GitHub repo) - PREFERRED, faster, logs "MCP"
        3. Fallback to git clone - ALWAYS WORKS, logs "Git"
        
        Logs all attempts and maintains metrics for reporting.
        
        Returns:
            Path to cloned library, or None if failed
        """
        self.metrics['total_attempted'] += 1
        
        # Check global cache first
        if self.use_global_cache:
            # Normalize package name for filesystem safety
            import urllib.parse
            safe_pkg_name = urllib.parse.quote(package_name, safe='@')
            cache_key = f"{safe_pkg_name}@{version}"
            cached_path = self.global_cache_dir / ecosystem / cache_key
            if cached_path.exists() and any(cached_path.iterdir()):
                # Found in global cache - link or copy to local libs_dir
                target_dir = self.libs_dir / package_name
                if not target_dir.exists():
                    shutil.copytree(cached_path, target_dir, dirs_exist_ok=True)
                    
                    # v4.4.5: Run cleanup on cached copy (handles pre-cleanup cache entries)
                    cleanup_result = self._cleanup_cloned_repo(target_dir)
                    self.metrics['cleanup_bytes_freed'] += cleanup_result['bytes_freed']
                    self.metrics['cleanup_dirs_removed'] += cleanup_result['removed_dirs']
                    self.metrics['cleanup_files_removed'] += cleanup_result['removed_files']
                    
                    # Update cache with cleaned version if we removed anything
                    if cleanup_result['bytes_freed'] > 0:
                        shutil.rmtree(cached_path, ignore_errors=True)
                        shutil.copytree(target_dir, cached_path, dirs_exist_ok=True)
                    
                    freed_mb = cleanup_result['bytes_freed'] / (1024 * 1024)
                    if self.verbose:
                        if freed_mb >= 0.1:
                            logger.info(f"      ✅ {package_name} v{version} (from cache, cleaned {freed_mb:.1f}MB)")
                        else:
                            logger.info(f"      ✅ {package_name} v{version} (from global cache)")
                self.metrics['cache_hits'] += 1
                return target_dir
            self.metrics['cache_misses'] += 1
        
        repo_info = self.get_repo_info(package_name, ecosystem)
        
        if not repo_info:
            if self.verbose:
                logger.info(f"      ⚠️  No repository found for {package_name}")
            self.metrics['total_failed'] += 1
            self.metrics['clone_methods'].append((package_name, 'none', False))
            return None
        
        # Verify provenance for npm packages
        if ecosystem == 'npm' and self.verify_provenance:
            prov_result = self._verify_package_provenance(package_name, version, ecosystem)
            if prov_result:
                if prov_result['risk_level'] in ['high', 'critical']:
                    if self.verbose:
                        logger.info(f"         ⚠️  Security Warning: {prov_result['risk_level'].upper()} risk")
                        for reason in prov_result['reasons'][:2]:  # Show first 2 reasons
                            logger.info(f"            • {reason}")
                elif not prov_result['has_provenance'] and not prov_result['has_signatures']:
                    if self.verbose:
                        logger.info(f"         ℹ️  No provenance/signatures (common for older packages)")
        
        target_dir = self.libs_dir / package_name
        
        # Log source
        source_labels = {
            'installed': 'Installed metadata',
            'pypi': 'PyPI',
            'fallback': 'Fallback'
        }
        source_label = source_labels.get(repo_info.source, repo_info.source)
        
        if self.verbose:
            logger.info(f"      📥 Cloning {package_name} v{version}")
            logger.info(f"         Source: {source_label}")
            logger.info(f"         URL: {repo_info.url}")
        
        # Strategy: MCP first (if GitHub), then git clone
        method_used = None
        success = False
        
        if repo_info.is_github:
            # Try MCP first for GitHub repos
            if self._clone_with_mcp(repo_info.url, target_dir, version):
                method_used = 'mcp'
                success = True
                self.metrics['mcp_success'] += 1
            else:
                # MCP failed, track it and fallback to git
                self.metrics['mcp_failed'] += 1
                if self.verbose:
                    logger.info(f"         🔄 MCP failed, falling back to git clone...")
                
                if self._clone_with_git(repo_info.url, target_dir, version, ecosystem, package_name):
                    method_used = 'git'
                    success = True
                    self.metrics['git_success'] += 1
                else:
                    method_used = 'git'
                    success = False
                    self.metrics['git_failed'] += 1
                    self.metrics['total_failed'] += 1
        else:
            # Non-GitHub repo, use git clone only
            if self._clone_with_git(repo_info.url, target_dir, version, ecosystem, package_name):
                method_used = 'git'
                success = True
                self.metrics['git_success'] += 1
            else:
                method_used = 'git'
                success = False
                self.metrics['git_failed'] += 1
                self.metrics['total_failed'] += 1
        
        # Record attempt
        self.metrics['clone_methods'].append((package_name, method_used, success))
        
        if success:
            # Clean up unnecessary files to save disk space (70-90% reduction)
            cleanup_result = self._cleanup_cloned_repo(target_dir)
            self.metrics['cleanup_bytes_freed'] += cleanup_result['bytes_freed']
            self.metrics['cleanup_dirs_removed'] += cleanup_result['removed_dirs']
            self.metrics['cleanup_files_removed'] += cleanup_result['removed_files']
            
            # Save to global cache AFTER cleanup (so cached version is already clean)
            if self.use_global_cache and target_dir.exists():
                # Normalize package name for filesystem safety
                import urllib.parse
                safe_pkg_name = urllib.parse.quote(package_name, safe='@')
                cache_key = f"{safe_pkg_name}@{version}"
                cached_path = self.global_cache_dir / ecosystem / cache_key
                if not cached_path.exists():
                    try:
                        cached_path.parent.mkdir(parents=True, exist_ok=True)
                        shutil.copytree(target_dir, cached_path, dirs_exist_ok=True)
                        if self.verbose:
                            logger.info(f"         💾 Cached to {cached_path}")
                    except Exception as e:
                        if self.verbose:
                            logger.info(f"         ⚠️  Cache write failed: {e}")
            
            # Save metrics to metadata
            if hasattr(self, 'metadata_dir'):
                self._save_cloning_metrics()
            
            if self.verbose:
                freed_mb = cleanup_result['bytes_freed'] / (1024 * 1024)
                if freed_mb >= 0.1:
                    logger.info(f"      ✅ Cloned {package_name} using {method_used.upper()} (cleaned {freed_mb:.1f}MB)")
                else:
                    logger.info(f"      ✅ Cloned {package_name} using {method_used.upper()}")
            return target_dir
        else:
            if self.verbose:
                logger.info(f"      ❌ Failed to clone {package_name}")
            return None
    
    def _save_cloning_metrics(self):
        """Save cloning metrics to metadata directory for CI/CD"""
        import json
        from datetime import datetime
        
        metrics_file = self.metadata_dir / "lib-cloning-metrics.json"
        
        total_success = self.metrics['mcp_success'] + self.metrics['git_success'] + self.metrics.get('npm_pack_success', 0)
        total_failed = self.metrics['total_failed']
        total_attempted = self.metrics['total_attempted']
        
        metrics_data = {
            "timestamp": datetime.now().isoformat(),
            "total_attempted": total_attempted,
            "total_success": total_success,
            "total_failed": total_failed,
            "success_rate": f"{(total_success/total_attempted*100):.1f}%" if total_attempted > 0 else "0%",
            # Clone method breakdown
            "mcp_success": self.metrics['mcp_success'],
            "mcp_failed": self.metrics['mcp_failed'],
            "git_success": self.metrics['git_success'],
            "git_failed": self.metrics['git_failed'],
            "npm_pack_success": self.metrics.get('npm_pack_success', 0),
            "npm_pack_failed": self.metrics.get('npm_pack_failed', 0),
            # Cache metrics
            "cache_hits": self.metrics.get('cache_hits', 0),
            "cache_misses": self.metrics.get('cache_misses', 0),
            "cache_hit_rate": f"{(self.metrics.get('cache_hits', 0)/(self.metrics.get('cache_hits', 0)+self.metrics.get('cache_misses', 0))*100):.1f}%" if (self.metrics.get('cache_hits', 0)+self.metrics.get('cache_misses', 0)) > 0 else "0%",
            # Cleanup metrics
            "cleanup_bytes_freed": self.metrics.get('cleanup_bytes_freed', 0),
            "cleanup_dirs_removed": self.metrics.get('cleanup_dirs_removed', 0),
            "cleanup_files_removed": self.metrics.get('cleanup_files_removed', 0),
            # Failed packages with details
            "failed_packages": [
                {
                    "package": pkg.get('package'),
                    "version": pkg.get('version'),
                    "ecosystem": pkg.get('ecosystem'),
                    "reason": pkg.get('reason'),
                    "health_status": pkg.get('health_status', 'UNKNOWN'),
                    "message": pkg.get('message', ''),
                    "deprecated": pkg.get('deprecated', False),
                    "latest_version": pkg.get('latest_version')
                }
                for pkg in self.metrics.get('obsolete_packages', [])
            ],
            # Clone methods log
            "methods": [
                {"package": pkg, "method": method, "success": success}
                for pkg, method, success in self.metrics['clone_methods']
            ]
        }
        
        with open(metrics_file, 'w') as f:
            json.dump(metrics_data, f, indent=2)
    
    def get_metrics_summary(self) -> Dict:
        """Get summary of cloning metrics for reporting"""
        total_success = self.metrics['mcp_success'] + self.metrics['git_success']
        total_attempts = self.metrics['total_attempted']
        
        return {
            'total_attempted': total_attempts,
            'total_success': total_success,
            'total_failed': self.metrics['total_failed'],
            'success_rate': f"{(total_success/total_attempts*100):.1f}%" if total_attempts > 0 else "0%",
            'mcp': {
                'success': self.metrics['mcp_success'],
                'failed': self.metrics['mcp_failed'],
                'rate': f"{(self.metrics['mcp_success']/(self.metrics['mcp_success']+self.metrics['mcp_failed'])*100):.1f}%" if (self.metrics['mcp_success']+self.metrics['mcp_failed']) > 0 else "0%"
            },
            'git': {
                'success': self.metrics['git_success'],
                'failed': self.metrics['git_failed'],
                'rate': f"{(self.metrics['git_success']/(self.metrics['git_success']+self.metrics['git_failed'])*100):.1f}%" if (self.metrics['git_success']+self.metrics['git_failed']) > 0 else "0%"
            }
        }
    
    def clone_vulnerable_libraries(self, vulns_data: dict, verbose: bool = True) -> List[Path]:
        """
        Clone all vulnerable libraries using multi-source discovery
        
        Args:
            vulns_data: Grype vulnerability JSON
            verbose: Print progress messages
        
        Returns:
            List of paths to cloned libraries
        """
        vulnerable = self.get_vulnerable_packages(vulns_data)
        
        if not vulnerable:
            if verbose:
                logger.info("   ℹ️  No vulnerable packages found")
            return []
        
        if verbose:
            # Calculate severity breakdown
            total_cves = 0
            critical_cves = 0
            high_cves = 0
            medium_cves = 0
            low_cves = 0
            cves_with_fix = 0
            
            for match in vulns_data.get('matches', []):
                total_cves += 1
                severity = match.get('vulnerability', {}).get('severity', 'Unknown').upper()
                
                if severity == 'CRITICAL':
                    critical_cves += 1
                elif severity == 'HIGH':
                    high_cves += 1
                elif severity == 'MEDIUM':
                    medium_cves += 1
                elif severity == 'LOW':
                    low_cves += 1
                
                # Check if fix is available
                fix_state = match.get('vulnerability', {}).get('fix', {}).get('state', '')
                if fix_state in ['fixed', 'wont-fix', 'unknown']:
                    if fix_state == 'fixed':
                        cves_with_fix += 1
            
            # Display summary
            logger.info(f"   🔍 Found {len(vulnerable)} package(s) with {total_cves} total CVEs:")
            severity_parts = []
            # ANSI colors: red for critical, orange for high, yellow for medium, blue for low
            RED = "\033[91m"
            ORANGE = "\033[38;5;208m"
            YELLOW = "\033[93m"
            BLUE = "\033[94m"
            RESET = "\033[0m"
            if critical_cves > 0:
                severity_parts.append(f"{RED}💀 {critical_cves} Critical{RESET}")
            if high_cves > 0:
                severity_parts.append(f"{ORANGE}🚨 {high_cves} High{RESET}")
            if medium_cves > 0:
                severity_parts.append(f"{YELLOW}⚠️  {medium_cves} Medium{RESET}")
            if low_cves > 0:
                severity_parts.append(f"{BLUE}ℹ️  {low_cves} Low{RESET}")
            
            if severity_parts:
                logger.info(f"      Severity: {', '.join(severity_parts)}")
            
            # Per-language CVE breakdown
            cves_by_lang = {}
            for match in vulns_data.get('matches', []):
                pkg = match.get('artifact', {}).get('name', '').lower()
                # Detect language from package name
                if any(x in pkg for x in ['golang.org', 'github.com/', 'k8s.io', 'gopkg.in']):
                    lang = 'Go'
                elif pkg.startswith('@') or any(x in pkg for x in ['react', 'next', 'vue', 'express', 'lodash', 'webpack']):
                    lang = 'JavaScript'
                elif '-' in pkg and '.' not in pkg and '/' not in pkg:
                    lang = 'JavaScript'
                elif any(x in pkg for x in ['django', 'flask', 'requests', 'numpy', 'pandas']):
                    lang = 'Python'
                else:
                    lang = 'Other'
                cves_by_lang[lang] = cves_by_lang.get(lang, 0) + 1
            
            if cves_by_lang and len(cves_by_lang) > 1:
                lang_parts = [f"{lang}: {count}" for lang, count in sorted(cves_by_lang.items(), key=lambda x: -x[1])]
                logger.info(f"      By Language: {', '.join(lang_parts)}")
            
            # Calculate per-language fix status
            fixed_by_lang = {}
            unfixed_by_lang = {}
            for match in vulns_data.get('matches', []):
                pkg = match.get('artifact', {}).get('name', '').lower()
                fix_state = match.get('vulnerability', {}).get('fix', {}).get('state', '')
                
                # Detect language
                if any(x in pkg for x in ['golang.org', 'github.com/', 'k8s.io', 'gopkg.in']):
                    lang = 'Go'
                elif pkg.startswith('@') or any(x in pkg for x in ['react', 'next', 'vue', 'express', 'lodash', 'webpack']):
                    lang = 'JavaScript'
                elif '-' in pkg and '.' not in pkg and '/' not in pkg:
                    lang = 'JavaScript'
                elif any(x in pkg for x in ['django', 'flask', 'requests', 'numpy', 'pandas']):
                    lang = 'Python'
                else:
                    lang = 'Other'
                
                if fix_state in ['fixed', 'wont-fix', 'unknown']:
                    fixed_by_lang[lang] = fixed_by_lang.get(lang, 0) + 1
                else:
                    unfixed_by_lang[lang] = unfixed_by_lang.get(lang, 0) + 1
            
            if cves_with_fix > 0:
                logger.info(f"      ✅ {cves_with_fix} CVEs have known fixes available")
                if fixed_by_lang and len(fixed_by_lang) > 1:
                    lang_parts = [f"{lang}: {c}" for lang, c in sorted(fixed_by_lang.items(), key=lambda x: -x[1])]
                    logger.info(f"         By Language: {', '.join(lang_parts)}")
            
            unfixed = total_cves - cves_with_fix
            if unfixed > 0:
                logger.info(f"      ⚠️  {unfixed} CVEs have no fix yet")
                if unfixed_by_lang and len(unfixed_by_lang) > 1:
                    lang_parts = [f"{lang}: {c}" for lang, c in sorted(unfixed_by_lang.items(), key=lambda x: -x[1])]
                    logger.info(f"         By Language: {', '.join(lang_parts)}")
            
            print()
            logger.info("   📦 Affected packages:")
            
            for pkg, pkg_info in sorted(vulnerable.items()):
                versions = pkg_info['versions']
                version_str = ', '.join(sorted(versions))
                # Get CVEs for this package
                pkg_matches = [m for m in vulns_data.get('matches', []) 
                              if m['artifact']['name'] == pkg]
                cve_count = len(pkg_matches)
                
                # Count severity for this package
                pkg_critical = sum(1 for m in pkg_matches 
                                  if m.get('vulnerability', {}).get('severity', '').upper() == 'CRITICAL')
                pkg_high = sum(1 for m in pkg_matches 
                              if m.get('vulnerability', {}).get('severity', '').upper() == 'HIGH')
                pkg_medium = sum(1 for m in pkg_matches 
                                if m.get('vulnerability', {}).get('severity', '').upper() == 'MEDIUM')
                pkg_low = sum(1 for m in pkg_matches 
                             if m.get('vulnerability', {}).get('severity', '').upper() == 'LOW')
                
                # Count fixable CVEs for this package
                pkg_fixable = sum(1 for m in pkg_matches 
                                if m.get('vulnerability', {}).get('fix', {}).get('state') in ['fixed', 'wont-fix', 'unknown'])
                pkg_unfixable = cve_count - pkg_fixable
                
                # Build readable severity string
                severity_parts = []
                if pkg_critical > 0:
                    severity_parts.append(f"{pkg_critical} Critical")
                if pkg_high > 0:
                    severity_parts.append(f"{pkg_high} High")
                if pkg_medium > 0:
                    severity_parts.append(f"{pkg_medium} Medium")
                if pkg_low > 0:
                    severity_parts.append(f"{pkg_low} Low")
                
                severity_display = ", ".join(severity_parts) if severity_parts else "Unknown"
                
                # Build fixable status
                if pkg_fixable > 0 and pkg_unfixable > 0:
                    fix_status = f"{pkg_fixable} fixable, \033[91m{pkg_unfixable} unfixable\033[0m"
                elif pkg_fixable == cve_count:
                    fix_status = "all fixable"
                elif pkg_unfixable == cve_count:
                    fix_status = f"\033[91m{pkg_unfixable} unfixable\033[0m"
                else:
                    fix_status = "fix status unknown"
                
                logger.info(f"      • {pkg}: {version_str}")
                logger.info(f"        └─ {cve_count} CVEs: {severity_display} ({fix_status})")
        
        print()
        
        # Determine what needs cloning
        packages_to_clone = []
        for package_name, pkg_info in vulnerable.items():
            if self.should_clone_library(package_name, vulnerable):
                versions = pkg_info['versions']
                ecosystem = pkg_info['ecosystem']
                is_transitive = pkg_info.get('is_transitive', False)
                packages_to_clone.append((package_name, sorted(versions)[0], ecosystem, is_transitive))
                
                # Track metrics
                if is_transitive:
                    self.metrics['transitive_dependencies'] += 1
                else:
                    self.metrics['direct_dependencies'] += 1
        
        if not packages_to_clone:
            if verbose:
                logger.info("   ℹ️  All vulnerable libraries already cloned or no repos found")
            return []
        
        if verbose:
            # Calculate per-language breakdown for cloning
            clone_by_lang = {}
            for pkg_name, version, ecosystem, is_trans in packages_to_clone:
                pkg_lower = pkg_name.lower()
                if any(x in pkg_lower for x in ['golang.org', 'github.com/', 'k8s.io', 'gopkg.in']):
                    lang = 'Go'
                elif pkg_lower.startswith('@') or any(x in pkg_lower for x in ['react', 'next', 'vue', 'express', 'lodash', 'webpack']):
                    lang = 'JavaScript'
                elif '-' in pkg_lower and '.' not in pkg_lower and '/' not in pkg_lower:
                    lang = 'JavaScript'
                elif any(x in pkg_lower for x in ['django', 'flask', 'requests', 'numpy', 'pandas']):
                    lang = 'Python'
                else:
                    lang = 'Other'
                clone_by_lang[lang] = clone_by_lang.get(lang, 0) + 1
            
            logger.info(f"   📦 Cloning {len(packages_to_clone)} vulnerable libraries...")
            if clone_by_lang:
                lang_parts = [f"{lang}: {c}" for lang, c in sorted(clone_by_lang.items(), key=lambda x: -x[1])]
                logger.info(f"      By Language: {', '.join(lang_parts)}")
        
        cloned_paths = []
        failed_packages = []
        
        # Dynamic concurrency based on total packages
        # Small repos: 2 workers, Medium: 4, Large: 8
        total_to_clone = len(packages_to_clone)
        if total_to_clone <= 10:
            max_workers = 2
        elif total_to_clone <= 50:
            max_workers = 4
        elif total_to_clone <= 100:
            max_workers = 6
        else:
            max_workers = 8
        
        if verbose:
            logger.info(f"      Parallel workers: {max_workers} (based on {total_to_clone} packages)")
        
        # Thread-safe counter for progress
        progress_lock = threading.Lock()
        completed_count = [0]  # Mutable container for closure
        retry_count = [0]  # Track total retries
        
        # Retry configuration
        MAX_RETRIES = 3
        RETRY_DELAYS = [1, 3, 5]  # Exponential backoff in seconds
        
        def clone_with_retry(args: Tuple[str, str, str, bool]) -> Tuple[str, Optional[Path], Optional[str], int]:
            """Clone a single library with retry logic, return (name, path, error, retries_used)"""
            package_name, version, ecosystem, is_transitive = args
            last_error = None
            retries_used = 0
            
            for attempt in range(MAX_RETRIES):
                try:
                    lib_path = self.clone_library(package_name, version, ecosystem)
                    with progress_lock:
                        completed_count[0] += 1
                        if retries_used > 0:
                            retry_count[0] += retries_used
                        if verbose and completed_count[0] % 10 == 0:
                            logger.info(f"      Progress: {completed_count[0]}/{total_to_clone} packages...")
                    return (package_name, lib_path, None, retries_used)
                    
                except Exception as e:
                    last_error = str(e)
                    error_lower = last_error.lower()
                    
                    # Determine if error is retryable
                    retryable_errors = [
                        'timeout', 'timed out', 'connection', 'ssl', 
                        'handshake', 'reset', 'refused', 'temporary',
                        'rate limit', '429', '503', '502', '504',
                        'urlopen error', 'network', 'socket'
                    ]
                    is_retryable = any(err in error_lower for err in retryable_errors)
                    
                    # Non-retryable errors (404, auth issues, etc.)
                    non_retryable = ['404', '401', '403', 'not found', 'unauthorized', 'no such', 'does not exist']
                    is_non_retryable = any(err in error_lower for err in non_retryable)
                    
                    if is_non_retryable:
                        # Don't retry 404s, auth errors, etc.
                        with progress_lock:
                            completed_count[0] += 1
                        break
                    
                    if is_retryable and attempt < MAX_RETRIES - 1:
                        delay = RETRY_DELAYS[attempt]
                        retries_used += 1
                        time.sleep(delay)
                        continue
                    
                    # Unknown error or last attempt
                    with progress_lock:
                        completed_count[0] += 1
                    break
            
            return (package_name, None, last_error, retries_used)
        
        # Execute clones in parallel with error isolation
        with ThreadPoolExecutor(max_workers=max_workers) as executor:
            # Submit all tasks
            future_to_pkg = {}
            for pkg in packages_to_clone:
                future = executor.submit(clone_with_retry, pkg)
                future_to_pkg[future] = pkg[0]
            
            # Collect results as they complete
            for future in as_completed(future_to_pkg):
                package_name = future_to_pkg[future]
                try:
                    result = future.result(timeout=300)  # 5 min timeout per package
                    name, lib_path, error, retries = result
                    if lib_path:
                        cloned_paths.append(lib_path)
                    elif error:
                        failed_packages.append((name, error))
                except TimeoutError:
                    failed_packages.append((package_name, "Clone timed out after 5 minutes"))
                except Exception as e:
                    failed_packages.append((package_name, f"Unexpected error: {str(e)}"))
        
        # Report failures if any
        if failed_packages and verbose:
            logger.info(f"\n   ⚠️  Failed to clone {len(failed_packages)} packages:")
            for name, error in failed_packages[:5]:  # Show first 5
                short_error = error[:60] + "..." if len(error) > 60 else error
                logger.info(f"      • {name}: {short_error}")
            if len(failed_packages) > 5:
                logger.info(f"      ... and {len(failed_packages) - 5} more")
        
        if verbose:
            if cloned_paths:
                logger.info(f"\n   ✅ Successfully cloned {len(cloned_paths)} libraries to {self.libs_dir}")
                
                #Dependency type breakdown
                direct = self.metrics['direct_dependencies']
                transitive = self.metrics['transitive_dependencies']
                
                # Summary of sources
                installed_count = sum(1 for info in self.repo_sources.values() if info.source == 'installed')
                pypi_count = sum(1 for info in self.repo_sources.values() if info.source == 'pypi')
                fallback_count = sum(1 for info in self.repo_sources.values() if info.source == 'fallback')
                github_count = sum(1 for info in self.repo_sources.values() if info.is_github)
                
                # Build per-language breakdown FIRST
                pkgs_by_lang = {}
                direct_by_lang = {}
                transitive_by_lang = {}
                for pkg_name, pkg_info in vulnerable.items():
                    pkg_lower = pkg_name.lower()
                    is_trans = pkg_info.get('is_transitive', False)
                    
                    # Detect language
                    if any(x in pkg_lower for x in ['golang.org', 'github.com/', 'k8s.io', 'gopkg.in']):
                        lang = 'Go'
                    elif pkg_lower.startswith('@') or any(x in pkg_lower for x in ['react', 'next', 'vue', 'express', 'lodash', 'webpack']):
                        lang = 'JavaScript'
                    elif '-' in pkg_lower and '.' not in pkg_lower and '/' not in pkg_lower:
                        lang = 'JavaScript'
                    elif any(x in pkg_lower for x in ['django', 'flask', 'requests', 'numpy', 'pandas']):
                        lang = 'Python'
                    else:
                        lang = 'Other'
                    
                    pkgs_by_lang[lang] = pkgs_by_lang.get(lang, 0) + 1
                    if is_trans:
                        transitive_by_lang[lang] = transitive_by_lang.get(lang, 0) + 1
                    else:
                        direct_by_lang[lang] = direct_by_lang.get(lang, 0) + 1
                
                def format_by_lang(by_lang_dict):
                    if by_lang_dict:
                        parts = [f"{lang}: {c}" for lang, c in sorted(by_lang_dict.items(), key=lambda x: -x[1])]
                        return ', '.join(parts)
                    return None
                
                logger.info(f"   📊 Discovery summary:")
                logger.info(f"      • Total packages: {len(vulnerable)}")
                lang_str = format_by_lang(pkgs_by_lang)
                if lang_str:
                    logger.info(f"        By Language: {lang_str}")
                
                if direct > 0 or transitive > 0:
                    logger.info(f"      • Direct dependencies: {direct}")
                    lang_str = format_by_lang(direct_by_lang)
                    if lang_str:
                        logger.info(f"        By Language: {lang_str}")
                    logger.info(f"      • Transitive dependencies: {transitive}")
                    lang_str = format_by_lang(transitive_by_lang)
                    if lang_str:
                        logger.info(f"        By Language: {lang_str}")
                
                logger.info(f"      • From installed metadata: {installed_count}")
                logger.info(f"      • From PyPI API: {pypi_count}")
                logger.info(f"      • From fallback: {fallback_count}")
                logger.info(f"      • GitHub repos (MCP-ready): {github_count}")
                logger.info(f"      • Non-GitHub repos: {len(self.repo_sources) - github_count}")
                
                # Cleanup metrics
                if self.metrics['cleanup_bytes_freed'] > 0:
                    freed_mb = self.metrics['cleanup_bytes_freed'] / (1024 * 1024)
                    logger.info(f"   \n   🧹 Cleanup summary:")
                    logger.info(f"      • Disk space saved: {freed_mb:.1f}MB")
                    logger.info(f"      • Directories removed: {self.metrics['cleanup_dirs_removed']}")
                    logger.info(f"      • Files removed: {self.metrics['cleanup_files_removed']}")
                
                # Provenance metrics (if any checks were done)
                if self.provenance_metrics['packages_checked'] > 0:
                    logger.info(f"\n   🔒 Provenance verification:")
                    logger.info(f"      • Packages checked: {self.provenance_metrics['packages_checked']}")
                    
                    # Per-language provenance breakdown
                    prov_by_lang = {}
                    for pkg_name in list(self.repo_sources.keys())[:self.provenance_metrics['packages_checked']]:
                        pkg_lower = pkg_name.lower()
                        if any(x in pkg_lower for x in ['golang.org', 'github.com/', 'k8s.io']):
                            lang = 'Go'
                        elif pkg_lower.startswith('@') or '-' in pkg_lower and '.' not in pkg_lower:
                            lang = 'JavaScript'
                        elif any(x in pkg_lower for x in ['django', 'flask', 'requests']):
                            lang = 'Python'
                        else:
                            lang = 'Other'
                        prov_by_lang[lang] = prov_by_lang.get(lang, 0) + 1
                    
                    lang_str = format_by_lang(prov_by_lang)
                    if lang_str:
                        logger.info(f"        By Language: {lang_str}")
                    
                    logger.info(f"      • With provenance/signatures: {self.provenance_metrics['with_provenance']}")
                    logger.info(f"      • Without provenance: {self.provenance_metrics['without_provenance']}")
                    
                    if self.provenance_metrics['suspicious_packages']:
                        logger.info(f"      • ⚠️  Suspicious packages: {len(self.provenance_metrics['suspicious_packages'])}")
                        for susp in self.provenance_metrics['suspicious_packages'][:3]:
                            logger.info(f"         - {susp['package']} ({susp['risk'].upper()})")
                    
                    if self.provenance_metrics['typosquatting_detected']:
                        logger.info(f"      • 🚨 Typosquatting detected: {len(self.provenance_metrics['typosquatting_detected'])}")
                        for typo in self.provenance_metrics['typosquatting_detected'][:2]:
                            logger.info(f"         - {typo['package']} (similar to: {', '.join(typo['similar_to'][:2])})")
            else:
                logger.info(f"\n   ⚠️  No libraries were cloned")
        
        return cloned_paths

def main():
    """CLI interface for standalone usage"""
    if len(sys.argv) < 2 or sys.argv[1] in ['--help', '-h', 'help']:
        logger.info("Usage: python lib_manager.py <vulns.json> [libs_dir]")
        logger.info("")
        logger.info("Example:")
        logger.info("  python lib_manager.py output/vulns.json libs/")
        logger.info("")
        logger.info("Description:")
        logger.info("  Intelligently clones vulnerable library source code.")
        logger.info("  Discovery methods (in priority order):")
        logger.info("    1. Installed package metadata (fastest, no network!)")
        logger.info("    2. PyPI API (fallback)")
        logger.info("    3. Known repos (last resort)")
        logger.info("  Tracks source of each repo for transparency.")
        sys.exit(0 if len(sys.argv) > 1 else 1)
    
    vulns_file = Path(sys.argv[1])
    libs_dir = Path(sys.argv[2]) if len(sys.argv) > 2 else Path('libs')
    
    if not vulns_file.exists():
        logger.info(f"❌ Error: {vulns_file} not found")
        sys.exit(1)
    
    logger.info(f"📂 Reading vulnerabilities from: {vulns_file}")
    logger.info(f"📂 Target directory: {libs_dir}")
    logger.info("")
    
    with open(vulns_file) as f:
        vulns_data = json.load(f)
    
    manager = LibraryManager(libs_dir)
    cloned = manager.clone_vulnerable_libraries(vulns_data)
    
    logger.info("")
    logger.info(f"✅ Done! Cloned {len(cloned)} libraries")
    sys.exit(0)

if __name__ == '__main__':
    main()
