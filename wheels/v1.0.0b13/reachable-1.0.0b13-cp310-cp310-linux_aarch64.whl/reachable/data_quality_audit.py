"""
REACHABLE Data Quality Audit - Complete Pipeline Validation

Traces every finding through the entire data flow:
Log → Raw JSON → Database → Dashboard

Validates:
- Finding counts (CVE, CWE, secrets, config, AI, DLP, malware)
- Reachability states (REACHABLE, NOT_REACHABLE, UNKNOWN)
- Severity levels (CRITICAL, HIGH, MEDIUM, LOW)
- Risk scoring and correlation
- Noise reduction metrics
- Data consistency at each stage
"""

import sqlite3
import json
import gzip
import logging
import re
from pathlib import Path
from typing import Dict, Optional, List

logger = logging.getLogger(__name__)


class DataQualityAuditor:
    """Complete pipeline audit for data quality validation."""
    
    def __init__(self):
        self.scans_dir = Path.home() / '.reachable' / 'scans'
    
    def auto_detect_latest_scan(self) -> Optional[Path]:
        """Find most recent scan across all repos/branches."""
        if not self.scans_dir.exists():
            return None
        
        latest_scan = None
        latest_time = 0
        
        for repo_dir in self.scans_dir.iterdir():
            if not repo_dir.is_dir():
                continue
            for branch_dir in repo_dir.iterdir():
                if not branch_dir.is_dir():
                    continue
                latest_link = branch_dir / 'latest'
                if latest_link.exists() and latest_link.is_symlink():
                    scan_dir = latest_link.resolve()
                    if scan_dir.exists():
                        mtime = scan_dir.stat().st_mtime
                        if mtime > latest_time:
                            latest_time = mtime
                            latest_scan = scan_dir
        
        return latest_scan
    
    def audit_scan_log(self, scan_path: Path) -> Dict:
        """Extract metrics from scan.log."""
        log_path = scan_path / 'scan.log'
        
        if not log_path.exists():
            return {'error': 'scan.log not found'}
        
        try:
            log_content = log_path.read_text()
            
            # Extract summary from log
            metrics = {
                'source': 'scan.log',
                'cves': self._extract_log_metric(log_content, r'CVEs:\s+(\d+)\s+total'),
                'cves_reachable': self._extract_log_metric(log_content, r'CVEs.*?(\d+)\s+reachable'),
                'secrets': self._extract_log_metric(log_content, r'Secrets:\s+(\d+)\s+total'),
                'secrets_reachable': self._extract_log_metric(log_content, r'Secrets.*?(\d+)\s+reachable'),
                'cwe': self._extract_log_metric(log_content, r'CWE:\s+(\d+)\s+total'),
                'cwe_reachable': self._extract_log_metric(log_content, r'CWE.*?(\d+)\s+reachable'),
                'malware': self._extract_log_metric(log_content, r'Malware:\s+(\d+)\s+total'),
                'ai': self._extract_log_metric(log_content, r'AI/LLM:\s+(\d+)\s+total'),
                'dlp': self._extract_log_metric(log_content, r'DLP/PII:\s+(\d+)\s+total'),
                'config': self._extract_log_metric(log_content, r'Config:\s+(\d+)\s+total'),
                'risk_score': self._extract_log_metric(log_content, r'Risk Score:\s+(\d+)'),
                'risk_level': self._extract_log_text(log_content, r'Risk Level:\s+(\w+)')
            }
            
            return metrics
            
        except Exception as e:
            return {'error': f'Log parsing error: {e}'}
    
    def audit_raw_data(self, scan_path: Path) -> Dict:
        """Audit raw JSON files."""
        raw_dir = scan_path / 'raw'
        
        if not raw_dir.exists():
            return {'error': 'raw/ directory not found'}
        
        try:
            metrics = {'source': 'raw JSON'}
            
            # CVEs from raw/cves.json or reachable-report.json
            report_file = scan_path / 'reachable-report.json.gz'
            if not report_file.exists():
                report_file = scan_path / 'reachable-report.json'
            
            if report_file.exists():
                report = self._load_json(report_file)
                
                reachable_cves = report.get('reachable', {})
                unreachable_cves = report.get('unreachable', {})
                
                metrics['cves_total'] = len(reachable_cves) + len(unreachable_cves)
                metrics['cves_reachable'] = len(reachable_cves)
                metrics['cves_unreachable'] = len(unreachable_cves)
                
                # Count by severity
                metrics['cves_by_severity'] = self._count_by_severity(
                    list(reachable_cves.values()) + list(unreachable_cves.values())
                )
                
                # Detailed findings
                detailed = report.get('detailed_findings', {})
                
                # Secrets
                secrets_data = detailed.get('secrets', {})
                if isinstance(secrets_data, dict):
                    secrets_findings = secrets_data.get('findings', [])
                    metrics['secrets_total'] = len(secrets_findings)
                    metrics['secrets_reachable'] = sum(
                        1 for f in secrets_findings 
                        if f.get('reachability', '').lower() == 'reachable'
                    )
                
                # CWE
                cwe_data = detailed.get('cwe', {})
                if isinstance(cwe_data, dict):
                    cwe_findings = cwe_data.get('findings', [])
                    metrics['cwe_total'] = len(cwe_findings)
                    metrics['cwe_reachable'] = sum(
                        1 for f in cwe_findings 
                        if f.get('is_reachable', False)
                    )
                
                # Risk
                summary = report.get('summary', {})
                overall_risk = summary.get('overall_risk', {})
                metrics['risk_score'] = overall_risk.get('risk_score', 0)
                metrics['risk_level'] = overall_risk.get('risk_level', 'UNKNOWN')
                
                # Noise reduction
                totals = summary.get('totals', {})
                metrics['noise_reduction_pct'] = summary.get('risk_reduction_pct', 0)
            
            # AI findings
            ai_file = raw_dir / 'ai-security.json'
            if ai_file.exists():
                ai_data = self._load_json(ai_file)
                metrics['ai_total'] = ai_data.get('total', 0)
                metrics['ai_by_severity'] = ai_data.get('by_severity', {})
            
            # DLP findings
            dlp_file = raw_dir / 'dlp-security.json'
            if dlp_file.exists():
                dlp_data = self._load_json(dlp_file)
                metrics['dlp_total'] = dlp_data.get('total', 0)
                metrics['dlp_reachable'] = dlp_data.get('reachable', 0)
            
            # Malware
            malware_file = raw_dir / 'malware.json'
            if malware_file.exists():
                malware_data = self._load_json(malware_file)
                malicious = malware_data.get('malicious_packages', [])
                metrics['malware_total'] = len(malicious) if isinstance(malicious, list) else malicious
            
            return metrics
            
        except Exception as e:
            return {'error': f'Raw data error: {e}'}
    
    def audit_database(self, scan_path: Path) -> Dict:
        """Audit database contents - COMPLETE."""
        scan_path = scan_path.resolve()
        repo_dir = scan_path.parent.parent
        db_path = repo_dir / 'repo.db'
        
        if not db_path.exists():
            return {'error': f'Database not found at {db_path}'}
        
        try:
            conn = sqlite3.connect(str(db_path))
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            
            # Get latest scan
            cursor.execute("SELECT * FROM scans ORDER BY id DESC LIMIT 1")
            scan_row = cursor.fetchone()
            
            if not scan_row:
                conn.close()
                return {'error': 'No scan records'}
            
            scan_id = scan_row['id']
            metrics = {
                'source': 'repo.db',
                'db_path': str(db_path),
                'db_size_mb': db_path.stat().st_size / 1024 / 1024,
                'scan_id': scan_id,
                'risk_score': scan_row['risk_score'],
                'risk_level': scan_row['risk_level'],
                'source_files_scanned': scan_row.get('source_files_scanned', 0)
            }
            
            # Main findings table (CVE, CWE, secrets, config)
            cursor.execute("""
                SELECT finding_type,
                       COUNT(*) as total,
                       SUM(CASE WHEN app_reachability = 'REACHABLE' THEN 1 ELSE 0 END) as reachable,
                       SUM(CASE WHEN app_reachability = 'NOT_REACHABLE' THEN 1 ELSE 0 END) as unreachable,
                       SUM(CASE WHEN app_reachability = 'UNKNOWN' THEN 1 ELSE 0 END) as unknown,
                       SUM(CASE WHEN severity = 'CRITICAL' THEN 1 ELSE 0 END) as critical,
                       SUM(CASE WHEN severity = 'HIGH' THEN 1 ELSE 0 END) as high,
                       SUM(CASE WHEN severity = 'MEDIUM' THEN 1 ELSE 0 END) as medium,
                       SUM(CASE WHEN severity = 'LOW' THEN 1 ELSE 0 END) as low
                FROM findings
                WHERE scan_id = ?
                GROUP BY finding_type
            """, (scan_id,))
            
            findings_detail = {}
            for row in cursor.fetchall():
                ftype = row['finding_type']
                findings_detail[ftype] = {
                    'total': row['total'],
                    'reachable': row['reachable'],
                    'unreachable': row['unreachable'],
                    'unknown': row['unknown'],
                    'by_severity': {
                        'CRITICAL': row['critical'],
                        'HIGH': row['high'],
                        'MEDIUM': row['medium'],
                        'LOW': row['low']
                    }
                }
            
            metrics['findings_detail'] = findings_detail
            
            # AI findings
            try:
                cursor.execute("""
                    SELECT COUNT(*) as total,
                           SUM(CASE WHEN is_reachable = 1 THEN 1 ELSE 0 END) as reachable,
                           SUM(CASE WHEN severity = 'ERROR' THEN 1 ELSE 0 END) as error,
                           SUM(CASE WHEN severity = 'WARNING' THEN 1 ELSE 0 END) as warning,
                           SUM(CASE WHEN severity = 'INFO' THEN 1 ELSE 0 END) as info
                    FROM ai_findings
                    WHERE scan_id = ?
                """, (scan_id,))
                row = cursor.fetchone()
                if row and row['total']:
                    metrics['ai'] = {
                        'total': row['total'],
                        'reachable': row['reachable'] or 0,
                        'by_severity': {
                            'ERROR': row['error'],
                            'WARNING': row['warning'],
                            'INFO': row['info']
                        }
                    }
            except sqlite3.OperationalError:
                pass
            
            # DLP findings
            try:
                cursor.execute("""
                    SELECT COUNT(*) as total,
                           SUM(CASE WHEN is_reachable = 1 THEN 1 ELSE 0 END) as reachable,
                           SUM(CASE WHEN is_sanitized = 1 THEN 1 ELSE 0 END) as sanitized,
                           SUM(CASE WHEN severity = 'CRITICAL' THEN 1 ELSE 0 END) as critical,
                           SUM(CASE WHEN severity = 'HIGH' THEN 1 ELSE 0 END) as high,
                           SUM(CASE WHEN severity = 'MEDIUM' THEN 1 ELSE 0 END) as medium
                    FROM dlp_findings
                    WHERE scan_id = ?
                """, (scan_id,))
                row = cursor.fetchone()
                if row and row['total']:
                    metrics['dlp'] = {
                        'total': row['total'],
                        'reachable': row['reachable'] or 0,
                        'sanitized': row['sanitized'] or 0,
                        'by_severity': {
                            'CRITICAL': row['critical'],
                            'HIGH': row['high'],
                            'MEDIUM': row['medium']
                        }
                    }
            except sqlite3.OperationalError:
                pass
            
            # Calculate totals
            total_findings = sum(d['total'] for d in findings_detail.values())
            total_reachable = sum(d['reachable'] for d in findings_detail.values())
            
            if 'ai' in metrics:
                total_findings += metrics['ai']['total']
                total_reachable += metrics['ai']['reachable']
            
            if 'dlp' in metrics:
                total_findings += metrics['dlp']['total']
                total_reachable += metrics['dlp']['reachable']
            
            metrics['total_findings'] = total_findings
            metrics['total_reachable'] = total_reachable
            metrics['total_unreachable'] = total_findings - total_reachable
            metrics['noise_reduction_pct'] = (
                100 * (1 - total_reachable / total_findings) if total_findings > 0 else 0
            )
            
            conn.close()
            return metrics
            
        except Exception as e:
            return {'error': f'Database error: {e}'}
    
    def audit_dashboard(self, scan_path: Path) -> Dict:
        """Audit dashboard data."""
        scan_path = scan_path.resolve()
        dash_path = scan_path / 'dashboard' / 'index.html'
        
        if not dash_path.exists():
            return {'error': f'Dashboard not found at {dash_path}'}
        
        try:
            content = dash_path.read_text()
            
            # Extract dashboardData
            match = re.search(r'window\.dashboardData\s*=\s*({.*?});', content, re.DOTALL)
            if not match:
                return {'error': 'Could not find dashboardData'}
            
            data = json.loads(match.group(1))
            
            issues = data.get('issues', [])
            metrics_obj = data.get('metrics', {})
            
            # Count by type and severity
            by_type = {}
            by_severity = {}
            reachable_count = 0
            
            for issue in issues:
                itype = issue.get('type', 'unknown')
                severity = issue.get('severity', 'MEDIUM')
                is_reachable = issue.get('reachable', False)
                
                by_type[itype] = by_type.get(itype, 0) + 1
                by_severity[severity] = by_severity.get(severity, 0) + 1
                
                if is_reachable:
                    reachable_count += 1
            
            return {
                'source': 'dashboard',
                'dash_path': str(dash_path),
                'version': data.get('version', 'unknown'),
                'risk_level': data.get('riskLevel', 'UNKNOWN'),
                'risk_score': data.get('riskScore', 0),
                'issues_total': len(issues),
                'issues_reachable': reachable_count,
                'issues_by_type': by_type,
                'issues_by_severity': by_severity,
                'metrics': metrics_obj,
                'dlp_findings': len(data.get('dlpFindings', [])),
                'ai_findings': len(data.get('aiFindings', []))
            }
            
        except Exception as e:
            return {'error': f'Dashboard error: {e}'}
    
    def compare_pipeline(self, log_data: Dict, raw_data: Dict, db_data: Dict, dash_data: Dict) -> Dict:
        """Compare all stages of the pipeline."""
        issues = []
        warnings = []
        
        # Check for errors
        for stage, data in [('Log', log_data), ('Raw', raw_data), ('DB', db_data), ('Dashboard', dash_data)]:
            if 'error' in data:
                issues.append(f"{stage}: {data['error']}")
        
        if issues:
            return {'critical_issues': issues, 'warnings': [], 'passed': False}
        
        # Compare CVE counts
        if raw_data.get('cves_total') != db_data.get('findings_detail', {}).get('cve', {}).get('total'):
            issues.append(
                f"CVE count mismatch: Raw={raw_data.get('cves_total')}, "
                f"DB={db_data.get('findings_detail', {}).get('cve', {}).get('total')}"
            )
        
        # Compare reachability
        raw_reach = raw_data.get('cves_reachable', 0)
        db_reach = db_data.get('findings_detail', {}).get('cve', {}).get('reachable', 0)
        if raw_reach != db_reach:
            warnings.append(
                f"CVE reachability mismatch: Raw={raw_reach}, DB={db_reach}"
            )
        
        # Check dashboard issues array
        db_total = db_data.get('total_findings', 0)
        dash_total = dash_data.get('issues_total', 0)
        
        if db_total > 0 and dash_total == 0:
            issues.append(
                f"P2.44 BUG: Dashboard issues array is EMPTY "
                f"(DB has {db_total} findings)"
            )
        
        # Risk score consistency
        db_risk = db_data.get('risk_score')
        dash_risk = dash_data.get('risk_score')
        if db_risk and dash_risk and abs(db_risk - dash_risk) > 1:
            warnings.append(f"Risk score drift: DB={db_risk}, Dashboard={dash_risk}")
        
        # Noise reduction validation
        noise_reduction = db_data.get('noise_reduction_pct', 0)
        if noise_reduction < 0 or noise_reduction > 100:
            issues.append(f"Invalid noise reduction: {noise_reduction}%")
        
        return {
            'critical_issues': issues,
            'warnings': warnings,
            'passed': len(issues) == 0,
            'noise_reduction_pct': noise_reduction,
            'total_findings': db_total,
            'total_reachable': db_data.get('total_reachable', 0)
        }
    
    def print_comprehensive_report(self, scan_path: Path, log_data: Dict, raw_data: Dict, 
                                    db_data: Dict, dash_data: Dict, comparison: Dict):
        """Print complete data quality report."""
        print("=" * 100)
        logger.info("REACHABLE DATA QUALITY AUDIT - COMPLETE PIPELINE VALIDATION")
        print("=" * 100)
        logger.info(f"\n📂 Scan: {scan_path}\n")
        
        # Pipeline stages
        for stage, data in [('SCAN LOG', log_data), ('RAW JSON', raw_data), 
                            ('DATABASE', db_data), ('DASHBOARD', dash_data)]:
            print("─" * 100)
            logger.info(f"{stage}")
            print("─" * 100)
            
            if 'error' in data:
                logger.info(f"❌ {data['error']}\n")
                continue
            
            if stage == 'DATABASE':
                self._print_db_section(data)
            elif stage == 'DASHBOARD':
                self._print_dashboard_section(data)
            else:
                self._print_generic_section(data)
            
            print()
        
        # Comparison results
        print("─" * 100)
        logger.info("PIPELINE VALIDATION RESULTS")
        print("─" * 100)
        
        if comparison['passed']:
            logger.info("✅ ALL CHECKS PASSED - Data integrity confirmed across entire pipeline")
            logger.info(f"\n📊 Noise Reduction: {comparison['noise_reduction_pct']:.1f}%")
            logger.info(f"   Total Findings: {comparison['total_findings']}")
            logger.info(f"   Reachable: {comparison['total_reachable']}")
            logger.info(f"   Filtered Out: {comparison['total_findings'] - comparison['total_reachable']}")
        else:
            if comparison['critical_issues']:
                logger.info(f"🚨 {len(comparison['critical_issues'])} CRITICAL ISSUE(S):")
                for issue in comparison['critical_issues']:
                    logger.info(f"   • {issue}")
            
            if comparison['warnings']:
                logger.info(f"\n⚠️  {len(comparison['warnings'])} WARNING(S):")
                for warning in comparison['warnings']:
                    logger.info(f"   • {warning}")
        
        print("\n" + "=" * 100)
    
    def _print_db_section(self, data: Dict):
        """Print database section."""
        logger.info(f"Path: {data['db_path']}")
        logger.info(f"Size: {data['db_size_mb']:.2f} MB")
        logger.info(f"Risk: {data['risk_level']} (score: {data['risk_score']})")
        logger.info(f"Files Scanned: {data['source_files_scanned']}")
        print(f"\nTotal: {data['total_findings']} | Reachable: {data['total_reachable']} | "
              f"Noise Reduction: {data['noise_reduction_pct']:.1f}%")
        
        logger.info("\nFindings by Type:")
        for ftype, details in sorted(data.get('findings_detail', {}).items()):
            print(f"  {ftype:10} {details['total']:4} total  |  "
                  f"R:{details['reachable']:4}  U:{details['unreachable']:4}  ?:{details['unknown']:4}")
        
        if 'ai' in data:
            ai = data['ai']
            logger.info(f"  {'ai':10} {ai['total']:4} total  |  R:{ai['reachable']:4}")
        
        if 'dlp' in data:
            dlp = data['dlp']
            logger.info(f"  {'dlp':10} {dlp['total']:4} total  |  R:{dlp['reachable']:4}  S:{dlp['sanitized']:4}")
    
    def _print_dashboard_section(self, data: Dict):
        """Print dashboard section."""
        logger.info(f"Path: {data['dash_path']}")
        logger.info(f"Risk: {data['risk_level']} (score: {data['risk_score']})")
        logger.info(f"Issues: {data['issues_total']} (Reachable: {data['issues_reachable']})")
        
        if data['issues_total'] == 0:
            logger.info("⚠️  Issues array is EMPTY")
        
        if data.get('issues_by_type'):
            logger.info("\nIssues by Type:")
            for itype, count in sorted(data['issues_by_type'].items()):
                logger.info(f"  {itype:10} {count:4}")
    
    def _print_generic_section(self, data: Dict):
        """Print generic section."""
        for key, value in data.items():
            if key == 'source':
                continue
            if isinstance(value, (int, float, str)):
                logger.info(f"{key}: {value}")
    
    def _load_json(self, path: Path) -> Dict:
        """Load JSON with gzip support."""
        if str(path).endswith('.gz'):
            with gzip.open(path, 'rt') as f:
                return json.load(f)
        else:
            with open(path) as f:
                return json.load(f)
    
    def _extract_log_metric(self, content: str, pattern: str) -> int:
        """Extract numeric metric from log."""
        match = re.search(pattern, content)
        return int(match.group(1)) if match else 0
    
    def _extract_log_text(self, content: str, pattern: str) -> str:
        """Extract text metric from log."""
        match = re.search(pattern, content)
        return match.group(1) if match else 'unknown'
    
    def _count_by_severity(self, findings: List[Dict]) -> Dict:
        """Count findings by severity."""
        counts = {'CRITICAL': 0, 'HIGH': 0, 'MEDIUM': 0, 'LOW': 0}
        for f in findings:
            sev = f.get('severity', 'MEDIUM').upper()
            counts[sev] = counts.get(sev, 0) + 1
        return counts
