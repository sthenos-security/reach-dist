#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.

"""
REACHABLE v4.5.41 - IaC Severity Classifier

Context-aware severity classification for Infrastructure as Code findings.

Problem Statement:
- IaC findings (Dockerfile, K8s, Terraform) have "unknown reachability"
- Actual risk depends on deployment context (standalone Docker vs K8s with policies)
- Some issues are best practices, not exploitable vulnerabilities
- Need intelligent severity adjustment based on rule type and deployment context
- IaC findings use CWE IDs with instance suffixes (CWE-250-24) that need parsing

Approach:
1. Classify IaC rules into categories (security-critical, hardening, best-practice)
2. Apply deployment context modifiers (standalone, k8s, ecs, serverless)
3. Provide actionable severity that reflects real-world risk
4. Generate context-appropriate action messages (not generic "rotate credential")

Reference: Trivy's approach classifies misconfigs by:
- CRITICAL: Direct security impact, exploitable
- HIGH: Significant risk, should fix
- MEDIUM: Hardening recommendations
- LOW: Best practices, informational

ROADMAP:
- [ ] Import Trivy misconfiguration rules from github.com/aquasecurity/trivy-policies
- [ ] Import Checkov policies from github.com/bridgecrewio/checkov
- [ ] Add Terraform-specific rules (AWS, GCP, Azure)
- [ ] Add Kubernetes manifest rules (RBAC, NetworkPolicy)
- [ ] Auto-detect deployment context from repo structure
"""

import re
from enum import Enum
from typing import Dict, Any, Optional, Tuple, List
from dataclasses import dataclass, field


class DeploymentContext(Enum):
    """Deployment context affects IaC severity"""
    UNKNOWN = "unknown"           # Default - conservative
    STANDALONE_DOCKER = "docker"  # Standalone Docker, no orchestration
    KUBERNETES = "k8s"            # K8s with potential PodSecurityPolicies
    ECS = "ecs"                   # AWS ECS with task definitions
    SERVERLESS = "serverless"     # Lambda/Cloud Functions (minimal container risk)
    DEVELOPMENT = "dev"           # Dev environment - lower severity
    PRODUCTION = "prod"           # Production - higher severity


@dataclass
class IaCRuleClassification:
    """Classification for an IaC rule"""
    rule_id: str
    category: str                 # 'privilege', 'secrets', 'network', 'hardening', 'best-practice'
    base_severity: str            # Base severity before context adjustment
    description: str
    context_modifiers: Dict[str, str]  # {context: adjusted_severity}
    remediation: str
    references: List[str] = field(default_factory=list)
    cwe_ids: List[str] = field(default_factory=list)  # Related CWE IDs


# Global deployment context (can be set via CLI or config)
_current_deployment_context: DeploymentContext = DeploymentContext.UNKNOWN


def set_deployment_context(context: str) -> None:
    """Set the deployment context for IaC severity adjustment"""
    global _current_deployment_context
    try:
        _current_deployment_context = DeploymentContext(context.lower())
    except ValueError:
        _current_deployment_context = DeploymentContext.UNKNOWN


def get_deployment_context() -> DeploymentContext:
    """Get current deployment context"""
    return _current_deployment_context


# =============================================================================
# IAC SEVERITY MAP - Rule Classifications
# =============================================================================

IAC_SEVERITY_MAP: Dict[str, IaCRuleClassification] = {
    # =========================================================================
    # PRIVILEGE ISSUES - Container privilege escalation
    # =========================================================================
    'CWE-250': IaCRuleClassification(
        rule_id='CWE-250',
        category='privilege',
        base_severity='MEDIUM',
        description='Dockerfile runs as root (no USER statement)',
        context_modifiers={
            'unknown': 'HIGH',
            'docker': 'HIGH',
            'k8s': 'MEDIUM',
            'ecs': 'MEDIUM',
            'serverless': 'LOW',
            'dev': 'LOW',
            'prod': 'HIGH',
        },
        remediation='Add USER directive: USER nonroot:nonroot',
        references=['https://docs.docker.com/develop/develop-images/dockerfile_best-practices/#user'],
        cwe_ids=['CWE-250'],
    ),
    
    'DS002': IaCRuleClassification(
        rule_id='DS002',
        category='privilege',
        base_severity='HIGH',
        description='Container running as root',
        context_modifiers={
            'unknown': 'HIGH',
            'docker': 'HIGH',
            'k8s': 'MEDIUM',
            'ecs': 'MEDIUM',
            'serverless': 'LOW',
            'dev': 'MEDIUM',
            'prod': 'HIGH',
        },
        remediation='Set runAsNonRoot: true in securityContext',
        references=['https://kubernetes.io/docs/concepts/security/pod-security-standards/'],
        cwe_ids=['CWE-250'],
    ),
    
    'CKV_DOCKER_3': IaCRuleClassification(
        rule_id='CKV_DOCKER_3',
        category='privilege',
        base_severity='MEDIUM',
        description='Ensure that a user for the container has been created',
        context_modifiers={
            'unknown': 'HIGH',
            'docker': 'HIGH',
            'k8s': 'MEDIUM',
            'ecs': 'MEDIUM',
            'serverless': 'LOW',
            'dev': 'LOW',
            'prod': 'HIGH',
        },
        remediation='Add USER directive with non-root user',
        references=['https://docs.bridgecrew.io/docs/ensure-that-a-user-for-the-container-has-been-created'],
        cwe_ids=['CWE-250'],
    ),
    
    'privileged-container': IaCRuleClassification(
        rule_id='privileged-container',
        category='privilege',
        base_severity='CRITICAL',
        description='Container running in privileged mode',
        context_modifiers={
            'unknown': 'CRITICAL',
            'docker': 'CRITICAL',
            'k8s': 'CRITICAL',
            'ecs': 'CRITICAL',
            'serverless': 'CRITICAL',
            'dev': 'HIGH',
            'prod': 'CRITICAL',
        },
        remediation='Remove privileged: true, use specific capabilities instead',
        references=['https://docs.docker.com/engine/reference/run/#runtime-privilege-and-linux-capabilities'],
        cwe_ids=['CWE-250', 'CWE-269'],
    ),
    
    'DS005': IaCRuleClassification(
        rule_id='DS005',
        category='privilege',
        base_severity='LOW',
        description='ADD used instead of COPY (potential remote URL fetch)',
        context_modifiers={
            'unknown': 'LOW',
            'docker': 'LOW',
            'k8s': 'LOW',
            'ecs': 'LOW',
            'serverless': 'LOW',
            'dev': 'INFO',
            'prod': 'MEDIUM',
        },
        remediation='Use COPY for local files, only ADD for tar extraction',
        references=['https://docs.docker.com/develop/develop-images/dockerfile_best-practices/#add-or-copy'],
        cwe_ids=[],
    ),
    
    'DS007': IaCRuleClassification(
        rule_id='DS007',
        category='best-practice',
        base_severity='MEDIUM',
        description='Using latest tag for base image',
        context_modifiers={
            'unknown': 'MEDIUM',
            'docker': 'MEDIUM',
            'k8s': 'MEDIUM',
            'ecs': 'MEDIUM',
            'serverless': 'MEDIUM',
            'dev': 'LOW',
            'prod': 'HIGH',
        },
        remediation='Pin base image to specific version or digest',
        references=['https://docs.docker.com/develop/develop-images/dockerfile_best-practices/#from'],
        cwe_ids=[],
    ),
    
    # =========================================================================
    # SECRETS ISSUES - Credential exposure
    # =========================================================================
    'secrets-in-dockerfile': IaCRuleClassification(
        rule_id='secrets-in-dockerfile',
        category='secrets',
        base_severity='CRITICAL',
        description='Secrets/credentials hardcoded in Dockerfile',
        context_modifiers={
            'unknown': 'CRITICAL',
            'docker': 'CRITICAL',
            'k8s': 'CRITICAL',
            'ecs': 'CRITICAL',
            'serverless': 'CRITICAL',
            'dev': 'HIGH',
            'prod': 'CRITICAL',
        },
        remediation='Use build secrets, environment variables, or secret management',
        references=['https://docs.docker.com/develop/develop-images/build_enhancements/#new-docker-build-secret-information'],
        cwe_ids=['CWE-798', 'CWE-259'],
    ),
    
    'DS017': IaCRuleClassification(
        rule_id='DS017',
        category='secrets',
        base_severity='CRITICAL',
        description='Sensitive data in ENV instruction',
        context_modifiers={
            'unknown': 'CRITICAL',
            'docker': 'CRITICAL',
            'k8s': 'CRITICAL',
            'ecs': 'CRITICAL',
            'serverless': 'CRITICAL',
            'dev': 'HIGH',
            'prod': 'CRITICAL',
        },
        remediation='Use ARG for build-time secrets, or Docker secrets',
        references=['https://docs.docker.com/engine/swarm/secrets/'],
        cwe_ids=['CWE-798', 'CWE-259'],
    ),
    
    # =========================================================================
    # NETWORK ISSUES - Port/network exposure
    # =========================================================================
    'exposed-port': IaCRuleClassification(
        rule_id='exposed-port',
        category='network',
        base_severity='INFO',
        description='Port exposed in Dockerfile',
        context_modifiers={
            'unknown': 'INFO',
            'docker': 'MEDIUM',
            'k8s': 'INFO',
            'ecs': 'INFO',
            'serverless': 'INFO',
            'dev': 'INFO',
            'prod': 'LOW',
        },
        remediation='Review if port exposure is necessary; use internal networking where possible',
        references=['https://docs.docker.com/engine/reference/builder/#expose'],
        cwe_ids=[],
    ),
    
    'CKV_DOCKER_1': IaCRuleClassification(
        rule_id='CKV_DOCKER_1',
        category='network',
        base_severity='HIGH',
        description='SSH port 22 exposed',
        context_modifiers={
            'unknown': 'HIGH',
            'docker': 'CRITICAL',
            'k8s': 'HIGH',
            'ecs': 'HIGH',
            'serverless': 'HIGH',
            'dev': 'MEDIUM',
            'prod': 'CRITICAL',
        },
        remediation='Remove EXPOSE 22; use kubectl exec or docker exec for debugging',
        references=['https://docs.bridgecrew.io/docs/ensure-port-22-is-not-exposed'],
        cwe_ids=['CWE-200'],
    ),
    
    # =========================================================================
    # HARDENING ISSUES - Security configuration
    # =========================================================================
    'missing-healthcheck': IaCRuleClassification(
        rule_id='missing-healthcheck',
        category='hardening',
        base_severity='LOW',
        description='No HEALTHCHECK instruction in Dockerfile',
        context_modifiers={
            'unknown': 'LOW',
            'docker': 'LOW',
            'k8s': 'INFO',
            'ecs': 'MEDIUM',
            'serverless': 'INFO',
            'dev': 'INFO',
            'prod': 'MEDIUM',
        },
        remediation='Add HEALTHCHECK instruction for container health monitoring',
        references=['https://docs.docker.com/engine/reference/builder/#healthcheck'],
        cwe_ids=[],
    ),
    
    'DS010': IaCRuleClassification(
        rule_id='DS010',
        category='best-practice',
        base_severity='INFO',
        description='apt cache not cleaned after install',
        context_modifiers={
            'unknown': 'INFO',
            'docker': 'INFO',
            'k8s': 'INFO',
            'ecs': 'INFO',
            'serverless': 'INFO',
            'dev': 'INFO',
            'prod': 'LOW',
        },
        remediation='Add rm -rf /var/lib/apt/lists/* after apt-get install',
        references=['https://docs.docker.com/develop/develop-images/dockerfile_best-practices/#apt-get'],
        cwe_ids=[],
    ),
    
    # =========================================================================
    # KUBERNETES-SPECIFIC RULES
    # =========================================================================
    'KSV001': IaCRuleClassification(
        rule_id='KSV001',
        category='privilege',
        base_severity='CRITICAL',
        description='Container running as privileged',
        context_modifiers={
            'unknown': 'CRITICAL',
            'docker': 'CRITICAL',
            'k8s': 'CRITICAL',
            'ecs': 'CRITICAL',
            'serverless': 'CRITICAL',
            'dev': 'HIGH',
            'prod': 'CRITICAL',
        },
        remediation='Set securityContext.privileged: false',
        references=['https://kubernetes.io/docs/concepts/security/pod-security-standards/'],
        cwe_ids=['CWE-250', 'CWE-269'],
    ),
    
    'KSV003': IaCRuleClassification(
        rule_id='KSV003',
        category='privilege',
        base_severity='HIGH',
        description='Container has dangerous capabilities',
        context_modifiers={
            'unknown': 'HIGH',
            'docker': 'HIGH',
            'k8s': 'HIGH',
            'ecs': 'HIGH',
            'serverless': 'MEDIUM',
            'dev': 'MEDIUM',
            'prod': 'HIGH',
        },
        remediation='Drop all capabilities and add only required ones',
        references=['https://kubernetes.io/docs/tasks/configure-pod-container/security-context/#set-capabilities-for-a-container'],
        cwe_ids=['CWE-250'],
    ),
    
    'KSV021': IaCRuleClassification(
        rule_id='KSV021',
        category='hardening',
        base_severity='MEDIUM',
        description='Container has no resource limits',
        context_modifiers={
            'unknown': 'MEDIUM',
            'docker': 'LOW',
            'k8s': 'MEDIUM',
            'ecs': 'MEDIUM',
            'serverless': 'LOW',
            'dev': 'LOW',
            'prod': 'HIGH',
        },
        remediation='Set resources.limits.cpu and resources.limits.memory',
        references=['https://kubernetes.io/docs/concepts/configuration/manage-resources-containers/'],
        cwe_ids=['CWE-400'],
    ),
}


# =============================================================================
# HELPER FUNCTIONS
# =============================================================================

def parse_iac_rule_id(raw_id: str) -> Tuple[str, str, Optional[int]]:
    """
    Parse IaC rule ID to extract base rule and instance number.
    
    IaC findings often have instance suffixes like CWE-250-24 where -24 is
    just an instance counter, not part of the CWE ID.
    
    Examples:
        'CWE-250-24' -> ('CWE-250-24', 'CWE-250', 24)
        'CWE-250' -> ('CWE-250', 'CWE-250', None)
        'DS002' -> ('DS002', 'DS002', None)
        'KSV001-3' -> ('KSV001-3', 'KSV001', 3)
    
    Returns:
        Tuple of (raw_id, base_rule_id, instance_number)
    """
    if not raw_id:
        return ('', '', None)
    
    raw_id = raw_id.strip()
    
    # Match patterns like CWE-XXX-NN (e.g., CWE-250-24)
    match = re.match(r'^(CWE-\d+)-(\d+)$', raw_id, re.IGNORECASE)
    if match:
        base_rule = match.group(1).upper()
        instance = int(match.group(2))
        return (raw_id, base_rule, instance)
    
    # Match patterns like DS002-3, KSV001-5
    match = re.match(r'^([A-Z]+\d+)-(\d+)$', raw_id, re.IGNORECASE)
    if match:
        base_rule = match.group(1).upper()
        instance = int(match.group(2))
        return (raw_id, base_rule, instance)
    
    # No instance suffix
    return (raw_id, raw_id.upper(), None)


def get_iac_action_message(classification: IaCRuleClassification, severity: str) -> str:
    """
    Generate appropriate action message for IaC finding.
    
    Replaces generic "rotate credential" messages with context-appropriate guidance.
    """
    category = classification.category
    
    if category == 'secrets':
        return (
            "⚠️ ACTION REQUIRED: Secrets detected in configuration. "
            "1) Remove hardcoded secrets immediately. "
            "2) Use secret management (K8s Secrets, AWS Secrets Manager, Vault). "
            "3) Rotate any exposed credentials."
        )
    
    elif category == 'privilege':
        if severity in ('CRITICAL', 'HIGH'):
            return (
                "⚠️ ACTION REQUIRED: Privilege escalation risk. "
                "1) Review if elevated privileges are necessary. "
                "2) Apply principle of least privilege. "
                "3) Use security contexts to restrict capabilities."
            )
        else:
            return (
                "ℹ️ RECOMMENDATION: Security hardening opportunity. "
                "Consider adding USER directive or restricting privileges. "
                "Impact depends on deployment context."
            )
    
    elif category == 'network':
        return (
            "ℹ️ REVIEW: Network exposure detected. "
            "1) Verify exposed ports are intentional. "
            "2) Use network policies to restrict access. "
            "3) Ensure services are not publicly accessible unless required."
        )
    
    elif category == 'hardening':
        return (
            "ℹ️ HARDENING: Security best practice recommendation. "
            "Consider implementing for defense in depth."
        )
    
    else:  # best-practice
        return (
            "ℹ️ BEST PRACTICE: Code quality recommendation. "
            "Low security impact but improves maintainability."
        )


# =============================================================================
# SEVERITY CLASSIFICATION FUNCTIONS
# =============================================================================

def classify_iac_severity(
    finding: Dict[str, Any],
    context: Optional[DeploymentContext] = None
) -> Tuple[str, str, Dict[str, Any]]:
    """
    Classify IaC finding severity based on rule type and deployment context.
    
    Args:
        finding: Finding dict with 'id', 'cwe_id', 'finding_id', etc.
        context: Deployment context (uses global if not provided)
        
    Returns:
        Tuple of (adjusted_severity, original_severity, metadata)
        metadata includes: category, remediation, references, reason, action_message
    """
    if context is None:
        context = _current_deployment_context
    
    # Get rule ID from various possible fields
    raw_rule_id = (
        finding.get('finding_id') or 
        finding.get('id') or 
        finding.get('rule_id') or 
        finding.get('cwe_id') or 
        ''
    )
    
    # Parse rule ID to extract base rule (strip instance suffix like -24)
    raw_id, rule_id, instance_num = parse_iac_rule_id(raw_rule_id)
    rule_id_upper = rule_id.upper().strip()
    
    # Look up in our classification map
    classification = None
    
    # Try exact match first
    if rule_id in IAC_SEVERITY_MAP:
        classification = IAC_SEVERITY_MAP[rule_id]
    elif rule_id_upper in IAC_SEVERITY_MAP:
        classification = IAC_SEVERITY_MAP[rule_id_upper]
    else:
        # Try matching by CWE ID from finding
        cwe_id = finding.get('cwe_id', '')
        if cwe_id:
            _, cwe_base, _ = parse_iac_rule_id(cwe_id)
            if cwe_base in IAC_SEVERITY_MAP:
                classification = IAC_SEVERITY_MAP[cwe_base]
    
    if not classification:
        # Unknown rule - return original severity with note
        original_sev = finding.get('severity', 'MEDIUM').upper()
        return original_sev, original_sev, {
            'category': 'unknown',
            'reason': f'No classification found for rule {rule_id}',
            'remediation': None,
            'references': [],
            'action_message': (
                "ℹ️ REVIEW: IaC configuration issue detected. "
                "Assess impact based on your deployment context."
            ),
            'base_rule_id': rule_id,
            'instance_number': instance_num,
        }
    
    # Get context-adjusted severity
    context_key = context.value
    original_sev = classification.base_severity
    adjusted_sev = classification.context_modifiers.get(context_key, original_sev)
    
    # Generate action message
    action_msg = get_iac_action_message(classification, adjusted_sev)
    
    return adjusted_sev, original_sev, {
        'category': classification.category,
        'reason': f'Adjusted from {original_sev} to {adjusted_sev} for {context_key} deployment',
        'remediation': classification.remediation,
        'references': classification.references,
        'cwe_ids': classification.cwe_ids,
        'description': classification.description,
        'action_message': action_msg,
        'base_rule_id': rule_id,
        'instance_number': instance_num,
    }


def adjust_iac_findings(
    findings: List[Dict[str, Any]],
    context: Optional[DeploymentContext] = None
) -> List[Dict[str, Any]]:
    """
    Adjust severity for a list of IaC findings.
    
    Args:
        findings: List of finding dicts
        context: Deployment context
        
    Returns:
        List of findings with adjusted severity and metadata
    """
    adjusted = []
    
    for f in findings:
        # Only adjust CONFIG/IaC type findings
        ftype = (f.get('type') or f.get('finding_type') or '').upper()
        if ftype not in ('CONFIG', 'IAC', 'MISCONFIG'):
            adjusted.append(f)
            continue
        
        adj_sev, orig_sev, metadata = classify_iac_severity(f, context)
        
        # Create adjusted copy
        f_adj = dict(f)
        f_adj['severity'] = adj_sev
        f_adj['original_severity'] = orig_sev
        f_adj['iac_classification'] = metadata
        
        # Replace generic action message with context-appropriate one
        if metadata.get('action_message'):
            f_adj['action_message'] = metadata['action_message']
        
        # Add remediation if not present
        if metadata.get('remediation') and not f_adj.get('remediation'):
            f_adj['remediation'] = {'steps': [metadata['remediation']]}
        
        adjusted.append(f_adj)
    
    return adjusted


def detect_deployment_context(repo_path: str) -> DeploymentContext:
    """
    Auto-detect deployment context from repository structure.
    
    Looks for:
    - kubernetes/, k8s/, manifests/ → KUBERNETES
    - docker-compose*.yml → STANDALONE_DOCKER
    - ecs-task-definition.json, taskdef.json → ECS
    - serverless.yml, lambda/ → SERVERLESS
    """
    from pathlib import Path
    
    repo = Path(repo_path)
    
    # Check for Kubernetes
    k8s_indicators = ['kubernetes', 'k8s', 'manifests', 'helm', 'charts']
    for indicator in k8s_indicators:
        if (repo / indicator).exists():
            return DeploymentContext.KUBERNETES
    
    # Check for ECS
    ecs_indicators = ['ecs-task-definition.json', 'taskdef.json', 'ecs']
    for indicator in ecs_indicators:
        if (repo / indicator).exists():
            return DeploymentContext.ECS
    
    # Check for Serverless
    serverless_indicators = ['serverless.yml', 'serverless.yaml', 'lambda', 'sam.yaml', 'template.yaml']
    for indicator in serverless_indicators:
        if (repo / indicator).exists():
            return DeploymentContext.SERVERLESS
    
    # Check for docker-compose (standalone docker)
    compose_patterns = list(repo.glob('docker-compose*.yml')) + list(repo.glob('docker-compose*.yaml'))
    if compose_patterns:
        return DeploymentContext.STANDALONE_DOCKER
    
    return DeploymentContext.UNKNOWN


def get_severity_legend() -> str:
    """Return legend explaining IaC severity adjustments"""
    return """
IaC Severity Classification:
  CRITICAL - Direct security impact, exploitable (secrets, privileged mode)
  HIGH     - Significant risk, should fix (root user, dangerous capabilities)
  MEDIUM   - Hardening recommendations (missing healthcheck, unpinned versions)
  LOW      - Best practices (cache cleanup, COPY vs ADD)
  INFO     - Informational (port exposure documentation)

Deployment Context Modifiers:
  --iac-context docker     Standalone Docker (more conservative)
  --iac-context k8s        Kubernetes (assumes PSP/PSS in place)
  --iac-context ecs        AWS ECS
  --iac-context serverless Lambda/Cloud Functions
  --iac-context dev        Development environment (lower severity)
  --iac-context prod       Production (higher severity)
"""
