# Copyright © 2026 Sthenos Security. All rights reserved.

"""
YARA-based Malware Signature Scanner (MAL-012)

Detects embedded malware signatures in:
- Binary files (.so, .dll, .pyd, .exe)
- Compiled Python bytecode (.pyc, .pyo)
- Archive contents (wheels, tarballs)
- Base64-encoded payloads
- High-entropy blobs (packed/encrypted)

This complements:
- MAL-001: GuardDog (package database)
- MAL-002: Semgrep (code patterns)
- MAL-003: Sandbox (behavioral)
"""

import os
import math
import hashlib
from pathlib import Path
from dataclasses import dataclass, field
from typing import List, Dict, Optional
import logging

logger = logging.getLogger(__name__)

# Built-in YARA rules for common malware patterns
# These are generic signatures that don't require external YARA library
BUILTIN_SIGNATURES = {
    # Shellcode patterns
    "shellcode_x86_nop_sled": {
        "pattern": b"\x90\x90\x90\x90\x90\x90\x90\x90",
        "description": "x86 NOP sled (shellcode indicator)",
        "severity": "HIGH",
        "category": "shellcode"
    },
    "shellcode_x86_execve": {
        "pattern": b"\x31\xc0\x50\x68\x2f\x2f\x73\x68",
        "description": "x86 execve /bin/sh shellcode",
        "severity": "CRITICAL",
        "category": "shellcode"
    },
    "shellcode_x64_syscall": {
        "pattern": b"\x48\x31\xc0\x48\x31\xff\x0f\x05",
        "description": "x64 syscall pattern",
        "severity": "HIGH",
        "category": "shellcode"
    },
    
    # Metasploit patterns
    "metasploit_meterpreter": {
        "pattern": b"metsrv.dll",
        "description": "Metasploit Meterpreter payload",
        "severity": "CRITICAL",
        "category": "rat"
    },
    "metasploit_reverse_tcp": {
        "pattern": b"\xfc\xe8\x82\x00\x00\x00",
        "description": "Metasploit reverse_tcp stub",
        "severity": "CRITICAL",
        "category": "payload"
    },
    
    # Cobalt Strike
    "cobaltstrike_beacon": {
        "pattern": b"ReflectiveLoader",
        "description": "Cobalt Strike Beacon loader",
        "severity": "CRITICAL",
        "category": "rat"
    },
    "cobaltstrike_pipe": {
        "pattern": b"\\\\.\\pipe\\msagent_",
        "description": "Cobalt Strike named pipe",
        "severity": "CRITICAL",
        "category": "c2"
    },
    
    # Cryptominers
    "cryptominer_xmrig": {
        "pattern": b"stratum+tcp://",
        "description": "Mining pool connection string",
        "severity": "HIGH",
        "category": "miner"
    },
    "cryptominer_pool": {
        "pattern": b"pool.minexmr.com",
        "description": "Known mining pool domain",
        "severity": "HIGH",
        "category": "miner"
    },
    
    # Infostealers
    "infostealer_browser_db": {
        "pattern": b"Login Data",
        "description": "Browser credential database path",
        "severity": "HIGH",
        "category": "stealer"
    },
    "infostealer_wallet": {
        "pattern": b"wallet.dat",
        "description": "Cryptocurrency wallet file access",
        "severity": "HIGH",
        "category": "stealer"
    },
    
    # Ransomware indicators
    "ransomware_extension_check": {
        "pattern": b".encrypted",
        "description": "Common ransomware file extension",
        "severity": "MEDIUM",
        "category": "ransomware"
    },
    "ransomware_readme": {
        "pattern": b"YOUR FILES HAVE BEEN ENCRYPTED",
        "description": "Ransomware ransom note pattern",
        "severity": "CRITICAL",
        "category": "ransomware"
    },
    
    # Backdoor patterns
    "backdoor_reverse_shell": {
        "pattern": b"/bin/sh -i",
        "description": "Reverse shell command",
        "severity": "CRITICAL",
        "category": "backdoor"
    },
    "backdoor_netcat": {
        "pattern": b"nc -e /bin/",
        "description": "Netcat backdoor pattern",
        "severity": "CRITICAL",
        "category": "backdoor"
    },
    
    # Obfuscation indicators
    "obfuscation_base64_exec": {
        "pattern": b"base64 -d | sh",
        "description": "Base64 decode and execute",
        "severity": "HIGH",
        "category": "obfuscation"
    },
    "obfuscation_eval_base64": {
        "pattern": b"eval(base64.b64decode(",
        "description": "Python base64 eval pattern",
        "severity": "HIGH",
        "category": "obfuscation"
    },
    
    # Exfiltration
    "exfil_dns_tunnel": {
        "pattern": b"TXT record",
        "description": "DNS tunneling indicator",
        "severity": "MEDIUM",
        "category": "exfil"
    },
    "exfil_webhook": {
        "pattern": b"discord.com/api/webhooks",
        "description": "Discord webhook exfiltration",
        "severity": "HIGH",
        "category": "exfil"
    },
    "exfil_telegram": {
        "pattern": b"api.telegram.org/bot",
        "description": "Telegram bot exfiltration",
        "severity": "HIGH",
        "category": "exfil"
    }
}

# File extensions to scan for binaries
BINARY_EXTENSIONS = {
    '.so', '.dll', '.pyd', '.exe', '.dylib',
    '.pyc', '.pyo', '.class', '.jar',
    '.whl', '.egg', '.tar.gz', '.tgz', '.zip'
}

@dataclass
class MalwareSignatureMatch:
    """Represents a malware signature match"""
    file: str
    signature_id: str
    description: str
    severity: str
    category: str
    offset: int
    context: bytes = b""
    sha256: str = ""

@dataclass
class YaraScanResult:
    """Results from YARA scanning"""
    files_scanned: int = 0
    binaries_found: int = 0
    signatures_matched: int = 0
    findings: List[MalwareSignatureMatch] = field(default_factory=list)
    high_entropy_files: List[Dict] = field(default_factory=list)
    verdict: str = "CLEAN"
    policy_id: str = "MAL-012"
    policy_name: str = "Malware Signature Detection"

def calculate_entropy(data: bytes) -> float:
    """Calculate Shannon entropy of data (0-8 for bytes)"""
    if not data:
        return 0.0
    
    freq = {}
    for byte in data:
        freq[byte] = freq.get(byte, 0) + 1
    
    entropy = 0.0
    length = len(data)
    for count in freq.values():
        p = count / length
        entropy -= p * math.log2(p)
    
    return entropy

def is_binary_file(filepath: str) -> bool:
    """Check if file is binary based on extension or content"""
    ext = Path(filepath).suffix.lower()
    if ext in BINARY_EXTENSIONS:
        return True
    
    # Check for binary content
    try:
        with open(filepath, 'rb') as f:
            chunk = f.read(8192)
            # High ratio of non-printable bytes indicates binary
            if chunk:
                non_printable = sum(1 for b in chunk if b < 32 and b not in (9, 10, 13))
                return non_printable / len(chunk) > 0.3
    except Exception:
        pass
    
    return False

def scan_file_for_signatures(filepath: str, signatures: Dict = None) -> List[MalwareSignatureMatch]:
    """Scan a single file for malware signatures"""
    if signatures is None:
        signatures = BUILTIN_SIGNATURES
    
    matches = []
    
    try:
        with open(filepath, 'rb') as f:
            content = f.read()
        
        file_hash = hashlib.sha256(content).hexdigest()
        
        for sig_id, sig_data in signatures.items():
            pattern = sig_data['pattern']
            
            # Find all occurrences
            offset = 0
            while True:
                idx = content.find(pattern, offset)
                if idx == -1:
                    break
                
                # Get context (32 bytes before and after)
                start = max(0, idx - 32)
                end = min(len(content), idx + len(pattern) + 32)
                context = content[start:end]
                
                matches.append(MalwareSignatureMatch(
                    file=filepath,
                    signature_id=sig_id,
                    description=sig_data['description'],
                    severity=sig_data['severity'],
                    category=sig_data['category'],
                    offset=idx,
                    context=context[:64],  # Limit context size
                    sha256=file_hash
                ))
                
                offset = idx + 1
                
    except Exception as e:
        logger.warning(f"Error scanning {filepath}: {e}")
    
    return matches

def scan_for_high_entropy(filepath: str, threshold: float = 7.0) -> Optional[Dict]:
    """Check if file has suspiciously high entropy (packed/encrypted)"""
    try:
        with open(filepath, 'rb') as f:
            content = f.read()
        
        if len(content) < 1024:  # Skip small files
            return None
        
        entropy = calculate_entropy(content)
        
        if entropy >= threshold:
            return {
                "file": filepath,
                "entropy": round(entropy, 2),
                "size": len(content),
                "verdict": "SUSPICIOUS" if entropy >= 7.5 else "ELEVATED",
                "reason": "High entropy indicates packed/encrypted content"
            }
            
    except Exception as e:
        logger.warning(f"Error checking entropy for {filepath}: {e}")
    
    return None

def scan_directory(target_path: str, custom_rules: Dict = None) -> YaraScanResult:
    """
    Scan a directory for malware signatures
    
    Args:
        target_path: Directory to scan
        custom_rules: Optional additional YARA-like rules
        
    Returns:
        YaraScanResult with findings
    """
    result = YaraScanResult()
    
    # Merge custom rules with builtin
    signatures = {**BUILTIN_SIGNATURES}
    if custom_rules:
        signatures.update(custom_rules)
    
    # Collect files to scan
    files_to_scan = []
    for root, dirs, files in os.walk(target_path):
        # Skip common non-code directories
        dirs[:] = [d for d in dirs if d not in {
            'node_modules', '.git', '__pycache__', '.venv', 'venv',
            '.tox', '.pytest_cache', 'dist', 'build', '.eggs'
        }]
        
        for filename in files:
            filepath = os.path.join(root, filename)
            files_to_scan.append(filepath)
    
    result.files_scanned = len(files_to_scan)
    
    # Scan files
    for filepath in files_to_scan:
        try:
            # Check if binary
            if is_binary_file(filepath):
                result.binaries_found += 1
                
                # Scan for signatures
                matches = scan_file_for_signatures(filepath, signatures)
                result.findings.extend(matches)
                result.signatures_matched += len(matches)
                
                # Check entropy
                entropy_result = scan_for_high_entropy(filepath)
                if entropy_result:
                    result.high_entropy_files.append(entropy_result)
            
            # Also scan text files for encoded payloads
            else:
                # Quick scan for obfuscation patterns only
                obfuscation_sigs = {k: v for k, v in signatures.items() 
                                   if v['category'] == 'obfuscation'}
                if obfuscation_sigs:
                    matches = scan_file_for_signatures(filepath, obfuscation_sigs)
                    result.findings.extend(matches)
                    result.signatures_matched += len(matches)
                    
        except Exception as e:
            logger.debug(f"Error processing {filepath}: {e}")
    
    # Determine verdict
    if any(m.severity == 'CRITICAL' for m in result.findings):
        result.verdict = "MALICIOUS"
    elif result.findings or any(e['verdict'] == 'SUSPICIOUS' for e in result.high_entropy_files):
        result.verdict = "SUSPICIOUS"
    else:
        result.verdict = "CLEAN"
    
    return result

def get_signature_report(result: YaraScanResult) -> Dict:
    """Convert scan results to JSON-serializable report"""
    return {
        "policy_id": result.policy_id,
        "policy_name": result.policy_name,
        "scanner": "YARA Signature Scanner (built-in)",
        "verdict": result.verdict,
        "summary": {
            "files_scanned": result.files_scanned,
            "binaries_found": result.binaries_found,
            "signatures_matched": result.signatures_matched,
            "high_entropy_files": len(result.high_entropy_files),
            "categories_found": list(set(m.category for m in result.findings))
        },
        "findings": [
            {
                "file": m.file,
                "signature_id": m.signature_id,
                "description": m.description,
                "severity": m.severity,
                "category": m.category,
                "offset": m.offset,
                "sha256": m.sha256
            }
            for m in result.findings
        ],
        "high_entropy_files": result.high_entropy_files,
        "note": "Static signature detection for embedded malware. Complements behavioral sandbox analysis."
    }

# ═══════════════════════════════════════════════════════════════════════════════
# YARA RULE SOURCES - DOCUMENTATION
# ═══════════════════════════════════════════════════════════════════════════════
#
# CURRENTLY SUPPORTED:
# - Built-in signatures (25+ patterns for shellcode, RATs, miners, stealers, etc.)
#
# OPEN SOURCE RULE SETS (Roadmap - Phase 1):
# ─────────────────────────────────────────────────────────────────────────────────
#
# TIER 1 - HIGH PRIORITY (Recommended)
# ─────────────────────────────────────
#
# 1. Neo23x0/signature-base (RECOMMENDED FIRST)
#    URL: https://github.com/Neo23x0/signature-base
#    License: CC BY-NC 4.0 (free for non-commercial)
#    Contents:
#      - yara/apt_*.yar - APT/nation-state malware
#      - yara/crime_*.yar - Crimeware/ransomware
#      - yara/exploit_*.yar - Exploit kits
#      - yara/gen_*.yar - Generic signatures
#      - yara/mal_*.yar - Malware families
#    Size: ~3,000 rules
#    Quality: HIGH - curated by Florian Roth (THOR scanner author)
#    Update Frequency: Weekly
#
# 2. YARAHQ/yara-forge (AGGREGATOR - NEW)
#    URL: https://github.com/YARAHQ/yara-forge
#    License: Various (aggregated)
#    Contents:
#      - Aggregates rules from 30+ top-tier sources
#      - Filters and reformats for consistency
#      - Includes: ReversingLabs, Elastic, Mandiant, ESET
#    Size: ~10,000+ rules (combined)
#    Quality: HIGH - pre-filtered, optimized release packages
#    Update Frequency: Regular releases
#    Note: Best single source for comprehensive coverage
#
# TIER 2 - MEDIUM PRIORITY (Community)
# ─────────────────────────────────────
#
# 3. Yara-Rules/rules (COMMUNITY STANDARD)
#    URL: https://github.com/Yara-Rules/rules
#    License: GPL-2.0
#    Contents:
#      - malware/ - Malware family signatures
#      - packers/ - Packer detection
#      - crypto/ - Cryptominer detection
#      - webshells/ - Web shell detection
#      - CVE_Rules/ - Exploit signatures
#      - antidebug_antivm/ - Evasion technique detection
#    Size: ~2,000 rules
#    Quality: MEDIUM - community contributed
#    Update Frequency: Monthly
#
# 4. bartblaze/Yara-rules (THREAT HUNTING)
#    URL: https://github.com/bartblaze/Yara-rules
#    License: GPL-3.0
#    Contents:
#      - Ransomware families (Ryuk, REvil, LockBit, etc.)
#      - Threat hunting rules
#      - Malware-specific signatures
#    Size: ~200 rules
#    Quality: HIGH - frequently updated, focused
#    Update Frequency: Weekly
#
# TIER 3 - SUPPLEMENTARY
# ─────────────────────────────────────
#
# 5. ReversingLabs/reversinglabs-yara-rules
#    URL: https://github.com/reversinglabs/reversinglabs-yara-rules
#    License: MIT
#    Contents:
#      - ByteSignatures/ - File format detection
#      - Zero false positive guarantee
#    Size: ~500 rules
#    Quality: HIGH - commercial vendor, rigorous QA
#    Update Frequency: Quarterly
#
# 6. MalwareBazaar YARA
#    URL: https://bazaar.abuse.ch/export/yara/
#    License: CC0 (public domain)
#    Contents:
#      - Fresh signatures from malware samples
#      - Auto-generated from submissions
#    Size: ~5,000+ rules (grows daily)
#    Quality: VARIABLE - auto-generated, may have FPs
#    Update Frequency: Daily
#
# META RESOURCE:
# ─────────────────────────────────────
#
# InQuest/awesome-yara (CURATED LIST)
#    URL: https://github.com/InQuest/awesome-yara
#    Purpose: Definitive curated list of YARA resources
#    Contains: Links to specialized repos from ESET, Fidelis, Avast, etc.
#    Use: Reference for discovering new rule sources
#
# COMMERCIAL RULE SETS (Roadmap - Phase 2):
# ─────────────────────────────────────────────────────────────────────────────────
#
# 1. THOR (Nextron Systems)
#    URL: https://www.nextron-systems.com/thor/
#    Pricing: €2,500/year (single host)
#    Contents: 15,000+ rules, APT focus, threat intel integrated
#    Quality: ENTERPRISE-GRADE
#
# 2. Kaspersky YARA Rules (via Threat Intelligence Portal)
#    URL: https://tip.kaspersky.com/
#    Pricing: Custom
#    Contents: APT signatures, campaign tracking
#    Quality: ENTERPRISE-GRADE
#
# 3. CrowdStrike Falcon Intelligence
#    URL: https://www.crowdstrike.com/products/threat-intelligence/
#    Pricing: Custom (enterprise)
#    Contents: YARA rules + IOCs + attribution
#    Quality: ENTERPRISE-GRADE
#
# 4. VirusTotal Livehunt (Custom YARA)
#    URL: https://www.virustotal.com/gui/hunting-overview
#    Pricing: $600/month (premium)
#    Contents: Run custom YARA on VirusTotal corpus
#    Quality: Depends on your rules
#
# ─────────────────────────────────────────────────────────────────────────────────
#
# We plan to develop custom YARA rules specifically for:
# - Supply chain attacks (npm, PyPI, RubyGems patterns)
# - Crypto wallet stealers (targeting developers)
# - IDE/Git credential theft (VSCode, JetBrains extensions)
# - CI/CD pipeline compromise (GitHub Actions, Jenkins)
# - Cloud credential harvesting (AWS, GCP, Azure)
# - Developer tool backdoors (node_modules, pip packages)
#
# RECOMMENDED INTEGRATION ORDER:
# ─────────────────────────────────────────────────────────────────────────────────
# 1. yara-forge (single source, aggregated, high quality)
# 2. Neo23x0/signature-base (APT/enterprise threats)
# 3. bartblaze (ransomware focus)
# 4. Custom supply chain rules
#
# ═══════════════════════════════════════════════════════════════════════════════
