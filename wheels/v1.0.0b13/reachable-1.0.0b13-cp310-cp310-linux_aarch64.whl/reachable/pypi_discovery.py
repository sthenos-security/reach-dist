#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.

"""
Auto-discover library repository URLs from PyPI

Instead of maintaining KNOWN_REPOS manually, this module
queries PyPI's JSON API to find source code URLs automatically.
"""

import requests
from typing import Optional
from functools import lru_cache
import logging

logger = logging.getLogger(__name__)

class PyPIRepoDiscovery:
    """Automatically discover repository URLs from PyPI metadata"""
    
    # Common keys in PyPI's project_urls that point to source code
    SOURCE_KEYS = [
        'Source',
        'Source Code', 
        'Repository',
        'Code',
        'Homepage',  # Sometimes homepage IS the repo
    ]
    
    # Fallback: Known repos for packages with missing/bad PyPI metadata
    FALLBACK_REPOS = {
        'urllib3': 'https://github.com/urllib3/urllib3.git',
        'requests': 'https://github.com/psf/requests.git',
        'flask': 'https://github.com/pallets/flask.git',
        'django': 'https://github.com/django/django.git',
        'numpy': 'https://github.com/numpy/numpy.git',
        'pillow': 'https://github.com/python-pillow/Pillow.git',
        'cryptography': 'https://github.com/pyca/cryptography.git',
    }
    
    def __init__(self, use_fallback=True, verbose=True):
        self.use_fallback = use_fallback
        self.verbose = verbose
        self.cache = {}
    
    @lru_cache(maxsize=128)
    def get_repo_url(self, package_name: str) -> Optional[str]:
        """
        Get repository URL for a package
        
        Tries in order:
        1. PyPI API query
        2. Fallback dictionary
        3. Return None
        
        Args:
            package_name: Name of the package (e.g., 'urllib3')
            
        Returns:
            Git repository URL or None
        """
        # Try PyPI API first
        url = self._query_pypi(package_name)
        if url:
            if self.verbose:
                logger.info(f"      📡 Found {package_name} repo via PyPI API")
            return url
        
        # Try fallback dictionary
        if self.use_fallback and package_name in self.FALLBACK_REPOS:
            if self.verbose:
                logger.info(f"      📋 Using fallback repo for {package_name}")
            return self.FALLBACK_REPOS[package_name]
        
        if self.verbose:
            logger.info(f"      ⚠️  No repository found for {package_name}")
        return None
    
    def _query_pypi(self, package_name: str) -> Optional[str]:
        """Query PyPI JSON API for package metadata"""
        try:
            response = requests.get(
                f"https://pypi.org/pypi/{package_name}/json",
                timeout=5
            )
            response.raise_for_status()
            data = response.json()
            
            # Look for source code URL in project_urls
            project_urls = data.get('info', {}).get('project_urls', {})
            
            if not project_urls:
                return None
            
            # Try common source code keys
            for key in self.SOURCE_KEYS:
                if key in project_urls:
                    url = project_urls[key]
                    # Verify it's a git-compatible URL
                    if self._is_git_repo(url):
                        return self._normalize_git_url(url)
            
            return None
            
        except requests.RequestException:
            # Network error, API down, package doesn't exist, etc.
            return None
        except (KeyError, ValueError):
            # Malformed JSON or unexpected structure
            return None
    
    def _is_git_repo(self, url: str) -> bool:
        """Check if URL looks like a git repository"""
        if not url:
            return False
        
        # Support GitHub, GitLab, Bitbucket, etc.
        git_hosts = [
            'github.com',
            'gitlab.com', 
            'bitbucket.org',
            'git.sr.ht',
            'codeberg.org',
        ]
        
        url_lower = url.lower()
        return any(host in url_lower for host in git_hosts)
    
    def _normalize_git_url(self, url: str) -> str:
        """
        Normalize URL to git clone format
        
        Converts:
          https://github.com/urllib3/urllib3 
        To:
          https://github.com/urllib3/urllib3.git
        """
        # Remove trailing slashes
        url = url.rstrip('/')
        
        # Add .git if not present and it's a GitHub URL
        if 'github.com' in url and not url.endswith('.git'):
            url = url + '.git'
        
        return url
    
    def bulk_discover(self, package_names: list) -> dict:
        """
        Discover repos for multiple packages at once
        
        Args:
            package_names: List of package names
            
        Returns:
            Dict mapping package_name -> repo_url (or None)
        """
        results = {}
        for package_name in package_names:
            results[package_name] = self.get_repo_url(package_name)
        return results

# Simple function interface
def find_repo_url(package_name: str) -> Optional[str]:
    """
    Simple function to find repository URL for a package
    
    Usage:
        url = find_repo_url('urllib3')
        # Returns: 'https://github.com/urllib3/urllib3.git'
    """
    discovery = PyPIRepoDiscovery(verbose=False)
    return discovery.get_repo_url(package_name)

def main():
    """Test the discovery system"""
    import sys
    
    if len(sys.argv) < 2:
        logger.info("Usage: python pypi_discovery.py <package_name> [package_name...]")
        logger.info("")
        logger.info("Example:")
        logger.info("  python pypi_discovery.py urllib3 requests werkzeug")
        sys.exit(1)
    
    discovery = PyPIRepoDiscovery()
    
    for package_name in sys.argv[1:]:
        logger.info(f"\n🔍 Looking up: {package_name}")
        url = discovery.get_repo_url(package_name)
        
        if url:
            logger.info(f"   ✅ Found: {url}")
        else:
            logger.info(f"   ❌ Not found")

if __name__ == '__main__':
    main()
