#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.

"""
REACHABLE CLI - Security Analysis with Reachability-Based Prioritization

Commands:
    scan        Analyze a repository for security issues
    dashboard   Generate or access scan dashboard (CI/CD friendly)
    selftest    Verify installation
    doctor      Check system dependencies
    cache       Manage local caches
    system      System info, storage management, cleanup
    primer      Quick-start guide and playbook
    version     Show version info

Usage:
    reachctl scan /path/to/repo
    reachctl scan /path/to/repo --debug
    reachctl dashboard --generate
    reachctl dashboard --path              # CI/CD: get artifact path
    reachctl system                        # Show system info
    reachctl system df                     # Disk usage breakdown
    reachctl system prune --dry-run        # Preview cleanup
    reachctl system prune                  # Clean up old data
"""

# Suppress urllib3/OpenSSL warnings on macOS
import warnings
warnings.filterwarnings('ignore', message='.*urllib3.*')
warnings.filterwarnings('ignore', message='.*OpenSSL.*')

import argparse
import logging
import sys
import json
import shutil
import subprocess
import io
from pathlib import Path
from typing import Optional, List
import warnings

from . import __version__

# Suppress urllib3 OpenSSL warning on macOS (LibreSSL vs OpenSSL)
warnings.filterwarnings('ignore', message='.*urllib3 v2 only supports OpenSSL.*')
warnings.filterwarnings('ignore', category=DeprecationWarning, module='urllib3')

# Initialize module-level logger
logger = logging.getLogger(__name__)

class TeeOutput:
    """Tee stdout to both console and a log file, with optional console suppression"""
    def __init__(self, log_path: Path, console_enabled: bool = True):
        self.terminal = sys.stdout
        self.log_file = open(log_path, 'w', encoding='utf-8')
        self.log_path = log_path
        self.console_enabled = console_enabled
    
    def write(self, message):
        if self.console_enabled:
            self.terminal.write(message)
        self.log_file.write(message)
        self.log_file.flush()
    
    def flush(self):
        if self.console_enabled:
            self.terminal.flush()
        self.log_file.flush()
    
    def enable_console(self):
        """Re-enable console output"""
        self.console_enabled = True
    
    def disable_console(self):
        """Suppress console output (still logs to file)"""
        self.console_enabled = False
    
    def close(self):
        self.log_file.close()
    
    def __enter__(self):
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()


def _extract_vulnerability_ids(vuln_data):
    """Extract both CVE and GHSA IDs from Grype vulnerability data."""
    cve_id = None
    ghsa_id = None
    
    # Primary ID
    primary_id = vuln_data.get('id', '')
    if primary_id.startswith('CVE-'):
        cve_id = primary_id
    elif primary_id.startswith('GHSA-'):
        ghsa_id = primary_id
    
    # Check relatedVulnerabilities (array of objects with 'id' field)
    for rel in vuln_data.get('relatedVulnerabilities', []):
        if isinstance(rel, dict):
            rel_id = rel.get('id', '')
            if rel_id.startswith('CVE-') and not cve_id:
                cve_id = rel_id
            elif rel_id.startswith('GHSA-') and not ghsa_id:
                ghsa_id = rel_id
    
    return cve_id, ghsa_id


def setup_logger(debug: bool = False):
    """
    Configure logging for reachctl.
    
    Args:
        debug: If True, include timestamps and set level to DEBUG.
               If False, no timestamps and level is INFO.
    """
    if debug:
        fmt = "%(asctime)s %(levelname)s %(message)s"
        datefmt = "%Y-%m-%dT%H:%M:%S"
        level = logging.DEBUG
    else:
        fmt = "%(levelname)s %(message)s"
        datefmt = None
        level = logging.INFO
    
    logging.basicConfig(
        level=level,
        format=fmt,
        datefmt=datefmt,
        handlers=[logging.StreamHandler(sys.stderr)],
        force=True
    )
    
    # Suppress noisy third-party loggers
    logging.getLogger('urllib3').setLevel(logging.WARNING)
    logging.getLogger('requests').setLevel(logging.WARNING)
    logging.getLogger('git').setLevel(logging.WARNING)


def _format_vulnerability_display_id(cve_id, ghsa_id, primary_id):
    """Format display ID showing both IDs."""
    if cve_id and ghsa_id:
        if primary_id and primary_id.startswith('GHSA-'):
            return f"{ghsa_id} (CVE: {cve_id})"
        return f"{cve_id} (GHSA: {ghsa_id})"
    elif ghsa_id:
        return f"{ghsa_id} (⚠️ No CVE assigned)"
    elif cve_id:
        return cve_id
    return "UNKNOWN"

def _check_venv_activation():
    """Check if running in activated venv and warn if not."""
    import sys
    from pathlib import Path
    
    # Check if we're in a venv
    in_venv = (
        hasattr(sys, 'real_prefix') or  # virtualenv
        (hasattr(sys, 'base_prefix') and sys.base_prefix != sys.prefix)  # venv
    )
    
    if in_venv:
        return  # All good
    
    # Not in venv - check if running from source (./reachctl)
    cli_path = Path(__file__).resolve()
    project_root = cli_path.parent.parent
    venv_dir = project_root / 'venv'
    
    # Only warn if venv exists but isn't activated
    if venv_dir.exists():
        print()
        print("\033[93m" + "=" * 60 + "\033[0m")  # Yellow
        logger.info("\033[93m⚠️  WARNING: Virtual environment not activated\033[0m")
        print("\033[93m" + "=" * 60 + "\033[0m")
        print()
        logger.info("Some tools (semgrep, guarddog) may not be available.")
        print()
        logger.info("To activate:")
        logger.info(f"  source {venv_dir}/bin/activate")
        print()
        logger.info("Or run setup first:")
        logger.info("  ./setup.sh && source venv/bin/activate")
        print()
        print("-" * 60)
        print()


def run_command(cmd: list, description: str, capture=False, check=True, env=None) -> Optional[str]:
    """Run a shell command with error handling.
    
    Args:
        cmd: Command and arguments
        description: Human-readable description for error messages
        capture: If True, return stdout
        check: If True, exit on non-zero return code
        env: Optional environment variables dict
    """
    try:
        if capture:
            result = subprocess.run(cmd, check=check, capture_output=True, text=True, env=env)
            return result.stdout
        else:
            result = subprocess.run(cmd, check=check, capture_output=True, text=True, env=env)
            return None
    except subprocess.CalledProcessError as e:
        if check:
            logger.info(f"❌ Error during {description}")
            if e.stderr:
                logger.info(f"   {e.stderr}")
            sys.exit(1)
        return None
    except FileNotFoundError:
        logger.info(f"❌ Command not found: {cmd[0]}")
        logger.info(f"   Please ensure {cmd[0]} is installed")
        sys.exit(1)

def check_github_connectivity(verbose: bool = False):
    """Check GitHub token and SSH access for library cloning"""
    import os
    
    if verbose:
        print()
        logger.info("🔐 Checking GitHub Connectivity...")
    
    has_auth = False
    
    # Check for GitHub token
    token_vars = ['GITHUB_TOKEN', 'GH_TOKEN', 'MCP_GITHUB_TOKEN']
    token_found = False
    token_var = None
    
    for var in token_vars:
        if os.getenv(var):
            token_found = True
            token_var = var
            break
    
    if token_found:
        if verbose:
            logger.info(f"   ✅ GitHub token found: ${token_var}")
        has_auth = True
    else:
        if verbose:
            logger.info(f"   ℹ️  No GitHub token (checked: {', '.join(token_vars)})")
    
    # Check SSH access
    try:
        result = subprocess.run(
            ['ssh', '-T', 'git@github.com'],
            capture_output=True,
            text=True,
            timeout=5
        )
        # SSH to GitHub always returns exit code 1, but with specific message
        if 'successfully authenticated' in result.stderr.lower():
            username = ''
            if 'Hi ' in result.stderr:
                username = result.stderr.split('Hi ')[1].split('!')[0]
            if verbose:
                logger.info(f"   ✅ SSH access configured{f' (user: {username})' if username else ''}")
            has_auth = True
        else:
            if verbose:
                logger.info("   ℹ️  SSH access not configured")
    except (subprocess.TimeoutExpired, FileNotFoundError):
        if verbose:
            logger.info("   ℹ️  SSH check skipped (not available)")
    
    if verbose:
        if has_auth:
            logger.info("   ✅ GitHub authentication available - can clone private repositories")
        else:
            logger.info("   ⚠️  No GitHub authentication - only public repositories accessible")
            logger.info("   💡 To enable:")
            logger.info("      Token: export GITHUB_TOKEN='ghp_your_token'")
            logger.info("      SSH:   ssh-keygen && add to https://github.com/settings/keys")
        print()

def selftest(args=None):
    """Run validation tests
    
    Usage:
        reachctl selftest              Run all tests (unit + integration)
        reachctl selftest --quick      Quick sanity check (no pytest)
        reachctl selftest --coverage   Run tests with coverage report
    
    For fine-grained control, use pytest directly:
        pytest -m unit                 Run only unit tests
        pytest -m integration          Run only integration tests
    """
    from pathlib import Path
    
    # Check which mode we're in
    run_quick = getattr(args, 'quick', False) if args else False
    coverage = getattr(args, 'coverage', False) if args else False
    quiet = getattr(args, 'quiet', False) if args else False
    
    # Try to use the new test runner from tests/run_tests.py
    try:
        tests_dir = Path(__file__).parent.parent / 'tests'
        run_tests_path = tests_dir / 'run_tests.py'
        
        if run_tests_path.exists():
            sys.path.insert(0, str(tests_dir))
            
            if run_quick:
                # Quick selftest (no pytest needed)
                from run_tests import SelfTest
                test = SelfTest(verbose=not quiet)
                result = test.run()
                sys.exit(result)
            else:
                # Default: Run all tests (unit + integration)
                from run_tests import TestRunner
                runner = TestRunner(verbose=not quiet)
                result = runner.run_all_tests(coverage=coverage)
                sys.exit(result)
    
    except ImportError as e:
        if not run_quick:
            logger.info(f"Error: Could not load test runner: {e}")
            logger.info("Make sure you're running from the reach-core source directory.")
            sys.exit(1)
        # For quick selftest, fall back to built-in implementation
    except Exception as e:
        logger.info(f"Error loading test runner: {e}")
        if not run_quick:
            sys.exit(1)
    
    # Fallback: Original selftest implementation (quick check only)
    print("=" * 70)
    logger.info("REACHABLE SELFTEST - Validating Installation")
    print("=" * 70)
    print()
    
    # Find project root
    cli_dir = Path(__file__).parent.parent
    tests_dir = cli_dir / "tests"
    
    logger.info(f"📂 Project root: {cli_dir}")
    logger.info(f"🧪 Tests directory: {tests_dir}")
    print()
    
    # Run basic import validation first
    print("=" * 70)
    logger.info("PHASE 1: Module Import Validation")
    print("=" * 70)
    
    modules_to_test = [
        ('reachable.reachable', 'ReachabilityAnalyzer'),
        ('reachable.cli', 'main'),
        ('reachable.semgrep_scanner', 'SemgrepScanner'),
        ('reachable.health_metrics', 'HealthMetrics'),
        ('reachable.correlation_engine', 'ComprehensiveCorrelationEngine'),
        ('reachable.java_parser', 'JavaEcosystemAnalyzer'),
        ('reachable.go_parser', 'GoParser'),
        ('reachable.javascript_parser', 'JavaScriptParser'),
        ('reachable.yara_scanner', 'scan_directory'),  # Function, not class
        ('reachable.guarddog_scanner', 'GuardDogScanner'),
        ('reachable.phantom_detector', 'PhantomDetector'),
        ('reachable.trufflehog_scanner', 'TruffleHogScanner'),
        ('reachable.entropy_scanner', 'EntropyScanner'),
    ]
    
    import_failures = 0
    for module_name, class_name in modules_to_test:
        try:
            module = __import__(module_name, fromlist=[class_name])
            if hasattr(module, class_name):
                logger.info(f"  ✅ {module_name}.{class_name}")
            else:
                logger.info(f"  ⚠️  {module_name} - missing {class_name}")
                import_failures += 1
        except Exception as e:
            logger.info(f"  ❌ {module_name}: {e}")
            import_failures += 1
    
    print()
    if import_failures > 0:
        logger.info(f"⚠️  {import_failures} import issues found")
    else:
        logger.info("✅ All core modules loaded successfully")
    
    # Phase 2: Tool availability and functional validation
    print()
    print("=" * 70)
    logger.info("PHASE 2: Tool Availability & Functional Validation")
    print("=" * 70)
    
    try:
        from reachable.reachable import ReachabilityAnalyzer
        logger.info("  ✅ ReachabilityAnalyzer instantiation ready")
        
        from reachable.java_parser import JavaEcosystemAnalyzer
        logger.info("  ✅ JavaEcosystemAnalyzer ready (Maven/Gradle support)")
        
        from reachable.yara_rules_manager import YaraRulesManager
        manager = YaraRulesManager()
        status = manager.get_cache_status()
        logger.info(f"  ✅ YARA Rules Manager ready ({status['total_rules']} rules cached)")
        
        # Run preflight check for tools and vulndb
        print()
        logger.info("  Tool Status (via preflight check):")
        try:
            from .preflight import preflight_check
            preflight = preflight_check(fix=False, quiet=True, verbose=False)
            for check in preflight.checks:
                icon = {'ok': '✅', 'warn': '⚠️', 'fail': '❌'}.get(check['status'], '❓')
                msg = f" ({check['message']})" if check['message'] else ""
                logger.info(f"    {icon} {check['name']}{msg}")
            
            if not preflight.ok:
                print()
                logger.info("    💡 Run 'reachctl doctor' to install missing tools")
        except Exception as e:
            logger.info(f"    ⚠️  Preflight check failed: {e}")
        
        print()
        print("=" * 70)
        logger.info("✅ SELFTEST PASSED - REACHABLE is ready to use")
        print("=" * 70)
        print()
        logger.info("Next steps:")
        logger.info("  reachctl scan /path/to/your/project")
        logger.info("  reachctl doctor    # Check all dependencies")
        print()
        sys.exit(0)
        
    except Exception as e:
        logger.info(f"  ❌ Functional test failed: {e}")
        print()
        print("=" * 70)
        logger.info("❌ SELFTEST FAILED")
        print("=" * 70)
        sys.exit(1)

def show_primer(args):
    """Show quick-start guide"""
    print()
    print("REACHABLE Primer")
    print("=" * 60)
    print()
    print("WHAT IS REACHABLE?")
    print("  REACHABLE scans your code to discover executable security risks.")
    print("  It identifies which vulnerabilities, secrets, and threats are truly")
    print("  reachable through your application's code paths — not just theoretical.")
    print()
    print("QUICK START")
    print("  reachctl scan <path>          # Scan your code")
    print("  reachctl dashboard open       # View results in browser")
    print("  reachctl doctor               # Check dependencies")
    print("  reachctl --help               # See all commands")
    print()
    print("WHAT IT DETECTS")
    print("  • CVEs (vulnerabilities in dependencies)")
    print("  • Secrets (hardcoded credentials, API keys)")
    print("  • CWEs (code security weaknesses)")
    print("  • Malware (in dependencies)")
    print("  • AI/LLM Risks (OWASP LLM Top 10, prompt injection, etc.)")
    print("  • PII/DLP (sensitive data leaks, GDPR/HIPAA violations)")
    print("  • Config Issues (security misconfigurations)")
    print()
    print("  Reachability Analysis:")
    print("    REACHABLE shows which issues are actually exploitable through")
    print("    your code, not just present in dependencies.")
    print()
    print("STORAGE")
    print("  ~/.reachable/                 # All data: scans, logs, caches, etc.")
    print()
    print("OPTIONAL TOOLS")
    print("  TruffleHog:")
    print("    brew install trufflehog     # Deep secret scanning + Git history")
    print()
    print("  Dynamic Sandbox:")
    print("    Mac: Available now (Colima + Docker)")
    print("    Linux: Coming soon (Firecracker)")
    print()
    print("BASIC WORKFLOW")
    print("  1. Run scan:       reachctl scan <path>")
    print("  2. Open dashboard: reachctl dashboard open")
    print("  3. Review risks:   Dashboard shows reachable vs unreachable findings")
    print()
    print("CI/CD INTEGRATION")
    print("  reachctl scan <path> --fail-on high --quiet")
    print()
    print("GITHUB AUTHENTICATION (for cloning vulnerable library source)")
    print("  export GITHUB_TOKEN='ghp_your_token_here'")
    print("  # Or use SSH keys: ssh -T git@github.com")
    print()
    print("NEED HELP?")
    print("  reachctl --help               # Command overview")
    print("  reachctl scan --help          # Scan options")
    print("  reachctl doctor               # System health check")
    print()
    print("  # Clean reinstall (removes old data)")
    print("  rm -rf ~/.reachable && ./install.sh")
    print()
    print("ADVANCED TUNING")
    print("  Environment variables (require --debug to take effect):")
    print()
    print("  Semgrep parallelism:")
    print("    Default: -j <floor(ncpu * 0.85)>.  Always applied.")
    print("    Keeps the host responsive by leaving ~15% of cores free.")
    print()
    print("  REACHABLE_SEMGREP_JOBS=N")
    print("    Override the default parallelism (requires --debug).")
    print("    Use to cap CPU in CI or on shared hosts.")
    print("    Example: REACHABLE_SEMGREP_JOBS=2 reachctl scan --debug .")
    print()
    print("  REACHABLE_TRACE_SEMGREP=1")
    print("    Enable per-rule/per-file timing from Semgrep.")
    print("    Shows the 5 slowest rules so you can diagnose bottlenecks.")
    print("    Example: REACHABLE_TRACE_SEMGREP=1 reachctl scan --debug .")
    print()
    print("  REACHABLE_CACHE_TTL_HOURS=N")
    print("    Semgrep result cache lifetime (default: 24 hours).")
    print("    Applies globally to all scan types (secrets, CWE, malware).")
    print("    Cache busts immediately on source file changes (SHA mismatch).")
    print("    TTL ensures new Semgrep rules are picked up periodically.")
    print("    Set to 0 to disable caching entirely (fresh scan every time).")
    print("    Example: REACHABLE_CACHE_TTL_HOURS=48 reachctl scan .")
    print("    Example: REACHABLE_CACHE_TTL_HOURS=0  reachctl scan .  # no cache")
    print()
    print("  Semgrep cache management:")
    print("    reachctl cache                          # show cache status")
    print("    reachctl cache --clear-semgrep           # clear all repos")
    print("    reachctl cache --clear-semgrep -r myrepo # clear one repo")
    print()
    print("  Semgrep ignore file:")
    print("    Create .semgrepignore in your repo root (gitignore syntax).")
    print("    Semgrep reads it natively — no REACHABLE-specific format needed.")
    print("    Example:")
    print("      # .semgrepignore")
    print("      tests/")
    print("      docs/")
    print("      generated/")
    print("      *.pb.go")
    print()
    print("SUPPORT")
    print("  Email: adazzi@sthenosec.com")
    print()

def open_dashboard(args):
    """Generate or access scan dashboard"""
    import webbrowser
    from pathlib import Path
    import json
    
    # Get REACHABLE home directory
    reachable_home = Path.home() / '.reachable' / 'scans'
    
    # List mode
    if getattr(args, 'list', False):
        if not reachable_home.exists():
            logger.info("No scans found.")
            return
        logger.info("Available dashboards:")
        print()
        found = False
        for scan_dir in sorted(reachable_home.iterdir()):
            if scan_dir.is_dir():
                latest = scan_dir / 'latest'
                if latest.exists() and latest.is_symlink():
                    dashboard = latest / 'dashboard' / 'index.html'
                    if dashboard.exists():
                        found = True
                        # Extract repo name from directory (remove hash suffix)
                        dir_name = scan_dir.name
                        repo_name = dir_name.rsplit('-', 1)[0] if '-' in dir_name else dir_name
                        logger.info(f"  {repo_name}")
                        logger.info(f"    reachctl dashboard --repo {repo_name}")
        if not found:
            logger.info("  (none)")
        return
    
    # Helper: find latest scan dir, accounting for branch subdirectories
    def find_latest_in_repo(repo_dir: Path) -> Optional[Path]:
        """Find latest scan in repo dir, checking for branch subdirectories.
        
        Structure can be either:
          - {repo}/latest/  (old structure)
          - {repo}/{branch}/latest/  (new structure with branches)
        """
        # Check old structure first
        direct_latest = repo_dir / 'latest'
        if direct_latest.exists() and (direct_latest / 'dashboard' / 'index.html').exists():
            return direct_latest  # Return symlink path, not resolved target
        
        # Check for branch subdirectories (new structure)
        latest_scan = None
        latest_mtime = 0
        
        for subdir in repo_dir.iterdir():
            if not subdir.is_dir():
                continue
            # Skip non-branch directories
            if subdir.name.startswith('.'):
                continue
            
            branch_latest = subdir / 'latest'
            if branch_latest.exists():
                dashboard = branch_latest / 'dashboard' / 'index.html'
                if dashboard.exists():
                    mtime = branch_latest.stat().st_mtime
                    if mtime > latest_mtime:
                        latest_mtime = mtime
                        latest_scan = branch_latest  # Return symlink path, not resolved target
        
        return latest_scan
    
    # Helper: fuzzy match repo name against scan directories
    def find_scan_dir(search_term: str) -> Optional[Path]:
        """Find scan directory by fuzzy matching repo name or path"""
        if not reachable_home.exists():
            return None
        
        search_lower = search_term.lower()
        matches = []
        
        for sd in reachable_home.iterdir():
            if not sd.is_dir():
                continue
            
            dir_name = sd.name.lower()
            # Extract repo name (remove hash suffix like -abc123)
            repo_name = dir_name.rsplit('-', 1)[0] if '-' in dir_name else dir_name
            
            # Exact match
            if repo_name == search_lower or dir_name == search_lower:
                latest = find_latest_in_repo(sd)
                if latest:
                    return latest
            
            # Partial match (search term contained in repo name)
            if search_lower in repo_name or search_lower in dir_name:
                latest = find_latest_in_repo(sd)
                if latest:
                    matches.append((sd, latest))
        
        # Return best match (most recent if multiple)
        if matches:
            # Sort by modification time, newest first
            matches.sort(key=lambda x: x[0].stat().st_mtime, reverse=True)
            return matches[0][1]
        
        return None
    
    # Determine scan directory
    repo = getattr(args, 'repo', None)
    scan_dir = None
    
    if repo:
        repo_input = repo
        repo_path = Path(repo).resolve()
        
        # Check if it's a direct path to a scan output directory
        if repo_path.exists() and repo_path.is_dir():
            # Check if it looks like a scan output dir (has reachable-report.json)
            if (repo_path / 'reachable-report.json').exists() or (repo_path / 'reachable-report.json.gz').exists():
                scan_dir = repo_path
            else:
                # It's a repo path, look for scans by repo name
                scan_dir = find_scan_dir(repo_path.name)
        else:
            # It's a repo name, search in scans with fuzzy matching
            scan_dir = find_scan_dir(repo)
        
        if not scan_dir:
            print(f"No scan found for: {repo_input}", file=sys.stderr)
            print()
            print("Available repos:", file=sys.stderr)
            if reachable_home.exists():
                for sd in sorted(reachable_home.iterdir()):
                    if sd.is_dir():
                        dir_name = sd.name
                        repo_name = dir_name.rsplit('-', 1)[0] if '-' in dir_name else dir_name
                        print(f"  {repo_name}", file=sys.stderr)
            print()
            print("Usage: reachctl dashboard --repo <name>", file=sys.stderr)
            sys.exit(1)
    else:
        # Find most recent scan with a dashboard across all repos
        if reachable_home.exists():
            # Collect all valid dashboards with their mtimes
            valid_scans = []
            for repo_dir in reachable_home.iterdir():
                if not repo_dir.is_dir():
                    continue
                latest = find_latest_in_repo(repo_dir)
                if latest:
                    valid_scans.append((latest, latest.stat().st_mtime))
            
            if valid_scans:
                # Sort by mtime, newest first
                valid_scans.sort(key=lambda x: x[1], reverse=True)
                scan_dir = valid_scans[0][0]
    
    if not scan_dir:
        print("No scan found. Run a scan first:", file=sys.stderr)
        print("  reachctl scan /path/to/repo", file=sys.stderr)
        sys.exit(1)
    
    # Generate mode - regenerate dashboard from scan results
    if getattr(args, 'generate', False):
        # Find report file
        report_file = scan_dir / 'reachable-report.json'
        if not report_file.exists():
            report_file = scan_dir / 'reachable-report.json.gz'
        
        if not report_file.exists():
            print(f"Report not found in: {scan_dir}", file=sys.stderr)
            sys.exit(1)
        
        # Load report
        try:
            if str(report_file).endswith('.gz'):
                import gzip
                with gzip.open(report_file, 'rt') as f:
                    results = json.load(f)
            else:
                with open(report_file) as f:
                    results = json.load(f)
        except Exception as e:
            print(f"Failed to load report: {e}", file=sys.stderr)
            sys.exit(1)
        
        # Determine output directory
        output_dir = Path(args.output).resolve() if args.output else scan_dir
        
        # Generate dashboard
        try:
            from reachable.dashboard_v2.generator import DashboardV2Generator
            
            generator = DashboardV2Generator()
            dashboard_dir = generator.generate_from_report(results, output_dir)
            dashboard_path = dashboard_dir / 'index.html'
            
            logger.info(f"Dashboard generated: {dashboard_path}")
            
            # Output path if requested
            if getattr(args, 'path', False):
                print(dashboard_path.absolute())
            
            # Open if requested
            if getattr(args, 'open', False):
                url = f"file://{dashboard_path.absolute()}"
                webbrowser.open(url)
                
        except ImportError as e:
            print(f"Dashboard generator not available: {e}", file=sys.stderr)
            sys.exit(1)
        except Exception as e:
            print(f"Dashboard generation failed: {e}", file=sys.stderr)
            sys.exit(1)
        
        return
    
    # Default: find existing dashboard
    dashboard = scan_dir / 'dashboard' / 'index.html'
    
    if not dashboard.exists():
        print(f"Dashboard not found: {dashboard}", file=sys.stderr)
        print()
        print("Generate with: reachctl dashboard --generate", file=sys.stderr)
        sys.exit(1)
    
    # Path-only mode (for CI/CD)
    if getattr(args, 'path', False):
        print(dashboard.absolute())
        return
    
    # Open mode
    if getattr(args, 'open', False):
        url = f"file://{dashboard.absolute()}"
        logger.info(f"Opening: {url}")
        webbrowser.open(url)
        return
    
    # Default: print path info (CI/CD friendly)
    logger.info(f"Dashboard: {dashboard.absolute()}")
    logger.info(f"URL: file://{dashboard.absolute()}")
    print()
    logger.info("Options:")
    logger.info("  --path       Print path only (for CI/CD artifacts)")
    logger.info("  --open       Open in browser")
    logger.info("  --generate   Regenerate from scan results")

def generate_sbom(repo_path: Path, output_dir: Path, verbose: bool = False) -> Path:
    """Generate SBOM using Syft (reuses existing logic)"""
    from .vulndb import get_syft_path
    
    if verbose:
        logger.info("[1/5] Generating SBOM...")
    sbom_file = output_dir / "sbom.json"
    
    # Use local syft from ~/.reachable/tools/bin/ if available
    syft_path = get_syft_path()
    
    result = run_command(
        [str(syft_path), 'scan', f'dir:{repo_path}', '-o', 'json', '-q'],
        'SBOM generation',
        capture=True
    )
    
  
    try:
        from .compression import save_json
        sbom_data = json.loads(result)
        actual_file = save_json(sbom_data, sbom_file, compress=True)
        if verbose:
            logger.info(f"   ✓ SBOM saved to {actual_file.name} (compressed)")
        return actual_file
    except ImportError:
        # Fallback to uncompressed
        sbom_file.write_text(result)
        if verbose:
            logger.info(f"   ✓ SBOM saved to {sbom_file}")
        return sbom_file

def scan_vulnerabilities(sbom_file: Path, output_dir: Path, verbose: bool = False) -> Path:
    """Scan for vulnerabilities using Grype with cached DB.
    
    Uses local grype from ~/.reachable/tools/bin/ and cached vulnerability
    database from ~/.reachable/cache/grype-db/. Auto-refreshes DB if > 24h old.
    """
    from .vulndb import VulnDBManager, get_grype_path
    
    if verbose:
        print()
        logger.info("[2/5] Scanning for vulnerabilities...")
    vulns_file = output_dir / "vulns.json"
    
    # Ensure vulnerability DB is fresh (auto-refresh if > 24h old)
    db_mgr = VulnDBManager()
    db_mgr.ensure_fresh(verbose=verbose)
    
    # Use local grype from ~/.reachable/tools/bin/ if available
    grype_path = get_grype_path()
    
    actual_sbom_file = sbom_file
    temp_sbom = None
    
    if str(sbom_file).endswith('.gz'):
        import gzip
        import tempfile
        
        # Decompress to temp file for Grype
        temp_sbom = output_dir / "sbom_temp.json"
        with gzip.open(sbom_file, 'rt') as f_in:
            temp_sbom.write_text(f_in.read())
        actual_sbom_file = temp_sbom
    
    try:
        # Run grype with cached DB location
        result = run_command(
            [str(grype_path), f'sbom:{actual_sbom_file}', '-o', 'json', '-q'],
            'vulnerability scanning',
            capture=True,
            env=db_mgr.get_grype_env()
        )
        
        vulns_file.write_text(result)
        
        # Count vulnerabilities
        vulns_data = json.loads(result)
        vuln_count = len(vulns_data.get('matches', []))
        
        if verbose:
            logger.info(f"   ✓ Found {vuln_count} vulnerabilities (Syft SBOM + Grype scanner)")
            logger.info(f"   ✓ Results saved to {vulns_file}")
        
        return vulns_file
    finally:
        # Clean up temp file
        if temp_sbom and temp_sbom.exists():
            temp_sbom.unlink()

def clone_vulnerable_libs(vulns_file: Path, libs_dir: Path, scan_ctx=None, verbose: bool = False) -> tuple:
    """Clone vulnerable libraries using smart lib manager"""
    if verbose:
        print()
        logger.info("[3/5] Cloning vulnerable library source code...")
    
    from .lib_manager import LibraryManager
    
    with open(vulns_file) as f:
        vulns_data = json.load(f)
    
    # Pass scan context to library manager for ecosystem hints
    manager = LibraryManager(libs_dir, scan_context=scan_ctx)
    cloned_paths = manager.clone_vulnerable_libraries(vulns_data)
    
    # Capture library manager metrics (includes obsolete packages)
    lib_metrics = manager.metrics
    
    # IMPORTANT: Return libs_dir even if nothing was freshly cloned
    # (libraries may already exist from previous runs)
    if libs_dir.exists() and any(libs_dir.iterdir()):
        return libs_dir, lib_metrics
    elif cloned_paths:
        return libs_dir, lib_metrics
    else:
        if verbose:
            logger.info("   ⚠️  No vulnerable libraries found or cloning failed")
        return None, lib_metrics

def run_dynamic_malware_sandbox(sbom_file: Path, output_dir: Path) -> Optional[dict]:
    """
    Run dynamic malware sandbox analysis on dependencies.
    
    Platform behavior:
    - macOS: Requires Colima (not Docker Desktop - insecure for malware testing)
    - Linux: Firecracker sandbox (not yet implemented)
    
    Static malware analysis (GuardDog) always runs separately.
    
    Args:
        sbom_file: Path to SBOM JSON file
        output_dir: Output directory for results
        
    Returns:
        Sandbox results dict or None if sandbox unavailable
    """
    import platform
    import time
    
    system = platform.system().lower()
    logger.info("   🔒 Dynamic Malware Sandbox")
    logger.info(f"      Platform: {platform.system()} ({platform.machine()})")
    
    start_time = time.time()
    
    # ==========================================================================
    # LINUX: Firecracker sandbox (not yet implemented)
    # ==========================================================================
    if system == 'linux':
        logger.info("      ⚠️  Firecracker sandbox not yet implemented on Linux")
        logger.info("      💡 Static malware analysis (GuardDog) still runs")
        logger.info("      📋 Firecracker support planned for v4.7.x")
        return {
            "verdict": "NOT_RUN",
            "reason": "Firecracker sandbox not yet implemented on Linux",
            "platform": "linux",
            "packages_tested": 0,
            "findings": [],
            "static_malware": "enabled",
            "dynamic_malware": "not_implemented",
            "duration_ms": int((time.time() - start_time) * 1000)
        }
    
    # ==========================================================================
    # macOS: Colima + Docker jail required (Docker Desktop is insecure)
    # ==========================================================================
    if system == 'darwin':
        colima_status = _check_colima_status()
        
        if colima_status == 'not_installed':
            logger.info("      ⚠️  Colima not installed - dynamic sandbox skipped")
            logger.info("      ")
            logger.info("      To enable dynamic malware detection, install Colima:")
            logger.info("         brew install colima docker")
            logger.info("         colima start --cpu 2 --memory 4")
            logger.info("      ")
            logger.info("      Alternative (manual):")
            logger.info("         Download from: https://github.com/abiosoft/colima/releases")
            logger.info("      ")
            logger.info("      📋 Static malware analysis (GuardDog) still runs")
            
            return {
                "verdict": "NOT_RUN",
                "reason": "Colima not installed",
                "platform": "darwin",
                "packages_tested": 0,
                "findings": [],
                "static_malware": "enabled",
                "dynamic_malware": "skipped",
                "install_instructions": "brew install colima docker && colima start",
                "duration_ms": int((time.time() - start_time) * 1000)
            }
        
        if colima_status == 'stopped':
            logger.info("      🔄 Starting Colima VM...")
            if not _start_colima():
                logger.info("      ❌ Failed to start Colima")
                return {
                    "verdict": "NOT_RUN",
                    "reason": "Failed to start Colima VM",
                    "platform": "darwin",
                    "packages_tested": 0,
                    "findings": [],
                    "static_malware": "enabled",
                    "dynamic_malware": "skipped",
                    "duration_ms": int((time.time() - start_time) * 1000)
                }
            logger.info("      ✅ Colima started")
        else:
            logger.info("      ✅ Colima running (secure VM isolation)")
        
        # Ensure sandbox image exists
        if not _ensure_sandbox_image():
            logger.info("      ⚠️  Sandbox image not available")
            return {
                "verdict": "NOT_RUN",
                "reason": "Sandbox Docker image not available",
                "platform": "darwin",
                "packages_tested": 0,
                "findings": [],
                "static_malware": "enabled",
                "dynamic_malware": "skipped",
                "duration_ms": int((time.time() - start_time) * 1000)
            }
        
        # Run sandbox analysis
        logger.info("      🐳 Running behavioral analysis in Colima sandbox...")
        result = _run_colima_sandbox(sbom_file, output_dir)
        
        if result:
            result['platform'] = 'darwin'
            result['runtime'] = 'colima'
            result['static_malware'] = 'enabled'
            result['dynamic_malware'] = 'enabled'
        
        return result
    
    # ==========================================================================
    # Other platforms: Not supported
    # ==========================================================================
    logger.info(f"      ⚠️  Dynamic malware sandbox not supported on {system}")
    return {
        "verdict": "NOT_RUN",
        "reason": f"Platform {system} not supported for dynamic analysis",
        "platform": system,
        "packages_tested": 0,
        "findings": [],
        "static_malware": "enabled",
        "dynamic_malware": "not_supported",
        "duration_ms": int((time.time() - start_time) * 1000)
    }


def _check_colima_status() -> str:
    """
    Check Colima installation and running status.
    
    Returns:
        'running' - Colima is installed and running
        'stopped' - Colima is installed but not running
        'not_installed' - Colima is not installed
    """
    try:
        # Check if colima command exists
        if not shutil.which('colima'):
            return 'not_installed'
        
        # Check if colima is running
        # colima status returns 0 if running, non-zero if not
        result = subprocess.run(
            ['colima', 'status'],
            capture_output=True, text=True, timeout=10
        )
        
        # Check both stdout and stderr for status indicators
        output = (result.stdout + result.stderr).lower()
        
        if result.returncode == 0:
            return 'running'
        elif 'not running' in output or 'not exist' in output:
            return 'stopped'
        else:
            # Fallback: try docker info to see if docker daemon is accessible
            try:
                docker_result = subprocess.run(
                    ['docker', 'info'],
                    capture_output=True, timeout=5
                )
                if docker_result.returncode == 0:
                    return 'running'
            except:
                pass
            return 'stopped'
            
    except FileNotFoundError:
        return 'not_installed'
    except subprocess.TimeoutExpired:
        return 'stopped'
    except Exception:
        return 'not_installed'


def _start_colima() -> bool:
    """
    Start Colima VM with appropriate resources for sandbox.
    
    Returns:
        True if Colima started successfully, False otherwise
    """
    try:
        logger.info("         (this may take 2-3 minutes on first run)")
        result = subprocess.run(
            ['colima', 'start', '--cpu', '2', '--memory', '4', '--disk', '10'],
            capture_output=False, text=True, timeout=300  # 5 min timeout, show output
        )
        if result.returncode == 0:
            # Give Docker daemon time to initialize
            import time
            time.sleep(5)
            return True
        else:
            logger.info("         Colima start returned error")
            return False
    except subprocess.TimeoutExpired:
        logger.info("         Timeout waiting for Colima to start")
        return False
    except Exception as e:
        logger.info(f"         Error: {e}")
        return False


def _get_docker_client():
    """
    Get Docker client, trying Colima socket first on macOS.
    
    Returns:
        docker.DockerClient or None
    """
    import platform
    
    try:
        import docker
    except ImportError:
        return None
    
    # On macOS, try Colima socket first
    if platform.system() == 'Darwin':
        colima_socket = Path.home() / '.colima' / 'default' / 'docker.sock'
        if colima_socket.exists():
            try:
                client = docker.DockerClient(base_url=f'unix://{colima_socket}')
                client.ping()
                return client
            except:
                pass
    
    # Try default socket
    try:
        client = docker.from_env()
        client.ping()
        return client
    except:
        return None


def _ensure_sandbox_image() -> bool:
    """
    Ensure the sandbox Docker image is available.
    Uses Dockerfile hash to detect if rebuild is needed (cache invalidation).
    
    Returns:
        True if image is available, False otherwise
    """
    import hashlib
    
    try:
        import docker
    except ImportError:
        logger.info("         Docker SDK not installed (pip install docker)")
        return False
    
    client = _get_docker_client()
    if not client:
        logger.info("         Docker not running - start Colima first")
        return False
    
    image_name = "reachable/sandbox:latest"
    
    # Find sandbox directory
    sandbox_dir = Path(__file__).parent.parent / "sandbox"
    dockerfile = sandbox_dir / "Dockerfile"
    
    if not dockerfile.exists():
        sandbox_dir = Path(__file__).parent / "sandbox"
        dockerfile = sandbox_dir / "Dockerfile"
    
    if not dockerfile.exists():
        logger.info("         Dockerfile not found")
        return False
    
    # Compute hash of Dockerfile + runner.py (detection rules)
    hasher = hashlib.sha256()
    hasher.update(dockerfile.read_bytes())
    runner_py = sandbox_dir / "runner.py"
    if runner_py.exists():
        hasher.update(runner_py.read_bytes())
    current_hash = hasher.hexdigest()[:12]  # Short hash for label
    
    # Check if image exists with matching hash
    try:
        image = client.images.get(image_name)
        cached_hash = image.labels.get('reachable.sandbox.hash', '')
        
        if cached_hash == current_hash:
            logger.info("      ✅ Sandbox image ready (cached)")
            return True
        else:
            logger.info(f"      🔄 Sandbox image outdated (rebuilding...)")
    except docker.errors.ImageNotFound:
        logger.info("      🔨 Building sandbox image (first time only)...")
    
    # Build image with hash label
    try:
        logger.info(f"         Building from {sandbox_dir}")
        image, build_logs = client.images.build(
            path=str(sandbox_dir),
            tag=image_name,
            labels={'reachable.sandbox.hash': current_hash},
            rm=True,
            quiet=False
        )
        logger.info("      ✅ Sandbox image built")
        return True
    except Exception as e:
        logger.info(f"         Build failed: {e}")
        return False


def _run_colima_sandbox(sbom_file: Path, output_dir: Path) -> Optional[dict]:
    """
    Internal: Run Docker-based sandbox when Colima is available.
    
    Colima provides a proper VM isolation layer, making it safe to run
    potentially malicious code (unlike Docker Desktop on macOS).
    """
    # Delegate to the existing sandbox analysis logic
    return run_sandbox_analysis(sbom_file, output_dir)


def run_sandbox_analysis(sbom_file: Path, output_dir: Path) -> Optional[dict]:
    """
    Run behavioral sandbox analysis on dependencies (internal implementation).
    
    Uses hybrid testing: batch first, then individual tests if issues found.
    
    Args:
        sbom_file: Path to SBOM JSON file
        output_dir: Output directory for results
        
    Returns:
        Sandbox results dict or None if sandbox unavailable
    """
    logger.info("      🔒 Checking sandbox prerequisites...")
    
    # Check 1: Docker Python SDK
    docker_sdk_installed = False
    try:
        import docker
        docker_sdk_installed = True
        logger.info("   ✓ Docker SDK: installed")
    except ImportError:
        logger.info("   ✗ Docker SDK: not installed")
        logger.info("   📦 Installing docker Python SDK...")
        import subprocess
        try:
            subprocess.check_call(
                [sys.executable, "-m", "pip", "install", "docker", "-q"],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL
            )
            import docker
            docker_sdk_installed = True
            logger.info("   ✓ Docker SDK: installed successfully")
        except Exception as e:
            logger.info(f"   ✗ Docker SDK: installation failed - {e}")
            logger.info("   💡 Run manually: pip install docker")
            return {
                "verdict": "NOT_RUN",
                "reason": "Could not install docker Python SDK",
                "packages_tested": 0,
                "findings": [],
                "prerequisites": {
                    "docker_sdk": False,
                    "docker_daemon": False
                }
            }
    
    # Check 2: Docker daemon running
    docker_daemon_running = False
    daemon_error = None
    try:
        client = docker.from_env()
        client.ping()
        docker_daemon_running = True
        docker_version = client.version().get('Version', 'unknown')
        logger.info(f"   ✓ Docker daemon: running (v{docker_version})")
    except Exception as e:
        daemon_error = str(e)
        if "connection refused" in daemon_error.lower() or "connect" in daemon_error.lower():
            logger.info("   ✗ Docker daemon: not running")
            logger.info("   💡 Start Docker Desktop or run: sudo systemctl start docker")
        elif "permission denied" in daemon_error.lower():
            logger.info("   ✗ Docker daemon: permission denied")
            logger.info("   💡 Add user to docker group: sudo usermod -aG docker $USER")
        else:
            logger.info(f"   ✗ Docker daemon: {daemon_error}")
    
    if not docker_daemon_running:
        return {
            "verdict": "NOT_RUN",
            "reason": daemon_error or "Docker daemon not available",
            "packages_tested": 0,
            "findings": [],
            "prerequisites": {
                "docker_sdk": docker_sdk_installed,
                "docker_daemon": False,
                "error": daemon_error
            }
        }
    
    # Both prerequisites met
    try:
        from .sandbox.runner import SandboxRunner, Verdict
        from .comprehensive_metrics import SandboxMetrics
    except ImportError as e:
        logger.info(f"   ⚠️  Sandbox module not available: {e}")
        return None
    
    # Create runner (Docker is confirmed available)
    runner = SandboxRunner(timeout=300, parallel=4)
    
    # Parse SBOM to get packages (handles both compressed and uncompressed)
    try:
        try:
            from .compression import load_json
            sbom = load_json(sbom_file)
        except ImportError:
            with open(sbom_file) as f:
                sbom = json.load(f)
    except Exception as e:
        logger.info(f"   ⚠️  Could not read SBOM: {e}")
        return None
    
    # Extract packages from SBOM (Syft format uses 'artifacts', CycloneDX uses 'components')
    packages = []
    
    # Try Syft format first (artifacts), then CycloneDX (components)
    components = sbom.get('artifacts', []) or sbom.get('components', [])
    
    if not components:
        logger.info("   ℹ️  No packages found in SBOM")
        return {
            "verdict": "CLEAN",
            "reason": "No packages in SBOM",
            "packages_tested": 0,
            "findings": []
        }
    
    npm_count = 0
    pip_count = 0
    skipped_count = 0
    skipped_by_type = {}  # Track why packages were skipped
    
    for comp in components:
        name = comp.get('name', '')
        version = comp.get('version')
        
        # Syft format uses 'type', CycloneDX uses 'purl'
        pkg_type = comp.get('type', '').lower()
        purl = comp.get('purl', '')
        
        # Determine ecosystem
        ecosystem = None
        if pkg_type in ('npm', 'node'):
            ecosystem = 'npm'
            npm_count += 1
        elif pkg_type in ('pip', 'pypi', 'python'):
            ecosystem = 'pip'
            pip_count += 1
        elif 'pkg:pypi' in purl:
            ecosystem = 'pip'
            pip_count += 1
        elif 'pkg:npm' in purl:
            ecosystem = 'npm'
            npm_count += 1
        elif pkg_type in ('go-module', 'go', 'golang') or 'pkg:golang' in purl:
            skipped_count += 1
            skipped_by_type['Go'] = skipped_by_type.get('Go', 0) + 1
            continue  # Skip Go packages (different install mechanism)
        elif pkg_type in ('maven', 'gradle', 'java') or 'pkg:maven' in purl:
            skipped_count += 1
            skipped_by_type['Java/Maven'] = skipped_by_type.get('Java/Maven', 0) + 1
            continue  # Skip Java packages
        elif pkg_type in ('cargo', 'rust') or 'pkg:cargo' in purl:
            skipped_count += 1
            skipped_by_type['Rust'] = skipped_by_type.get('Rust', 0) + 1
            continue  # Skip Rust packages
        elif pkg_type in ('gem', 'ruby') or 'pkg:gem' in purl:
            skipped_count += 1
            skipped_by_type['Ruby'] = skipped_by_type.get('Ruby', 0) + 1
            continue  # Skip Ruby packages
        else:
            skipped_count += 1
            skipped_by_type['Other'] = skipped_by_type.get('Other', 0) + 1
            continue  # Skip unknown ecosystems
        
        if name and ecosystem:
            packages.append((name, ecosystem, version))
    
    if not packages:
        reason = f"No pip/npm packages found in SBOM to sandbox test"
        if skipped_count > 0:
            reason += f" ({skipped_count} Go/Java/other packages skipped)"
        logger.info(f"   ℹ️  {reason}")
        return {
            "verdict": "CLEAN",
            "reason": reason,
            "packages_tested": 0,
            "findings": [],
            "stats": {
                "npm_packages": npm_count,
                "pip_packages": pip_count,
                "skipped_packages": skipped_count,
                "sbom_total": len(components)
            }
        }
    
    # Show breakdown before testing
    logger.info(f"   🔒 Sandbox will test {len(packages)} packages:")
    logger.info(f"      • npm: {npm_count}")
    logger.info(f"      • pip: {pip_count}")
    if skipped_count > 0:
        skipped_detail = ", ".join(f"{k}: {v}" for k, v in sorted(skipped_by_type.items(), key=lambda x: -x[1]))
        logger.info(f"      • skipped: {skipped_count} ({skipped_detail})")
        logger.info(f"        ℹ️  Why skipped:")
        logger.info(f"           • Go modules: No install-time hooks (uses go.mod declarative imports)")
        logger.info(f"           • Java/Maven: Build-time dependencies (Gradle/Maven manages lifecycle)")
        logger.info(f"           • Other: Ecosystem not yet supported for behavioral testing")
        logger.info(f"        💡 Tip: These packages are still scanned by GuardDog static analysis")
    print()
    logger.info(f"   🐳 Running behavioral sandbox analysis...")
    logger.info(f"      Strategy: Batch test all → individual tests if suspicious")
    
    # Use hybrid testing for efficiency
    def progress_callback(phase, current, total, pkg):
        if phase == "batch":
            if current == 0:
                logger.info(f"      Phase 1: Batch testing all packages...")
            else:
                logger.info(f"      Phase 1: Complete")
        elif phase == "individual":
            logger.info(f"      Phase 2: Testing {pkg} ({current}/{total})...")
    
    try:
        result = runner.test_hybrid(packages, progress_callback=progress_callback)
        
        # Convert to metrics for structured data
        metrics = SandboxMetrics.from_hybrid_result(result)
        
        # Count malicious/suspicious for risk score integration
        malicious_count = len(result.malicious_packages) if result.malicious_packages else 0
        suspicious_count = len(result.batch_result.suspicious_packages) if result.batch_result.suspicious_packages else 0
        
        # Map WARNING → suspicious, CRITICAL → malicious for risk score
        if result.verdict.value == "CRITICAL" and malicious_count == 0:
            malicious_count = 1  # At least one if CRITICAL verdict
        elif result.verdict.value == "WARNING" and suspicious_count == 0:
            suspicious_count = 1  # At least one if WARNING verdict
        
        # Build result dict for JSON/dashboard
        sandbox_data = {
            "verdict": result.verdict.value,
            "capability_score": metrics.min_capability_score,
            "packages_tested": metrics.packages_tested,
            "duration_ms": result.duration_ms,
            "strategy": "hybrid",
            # Summary for risk score integration (matches sandbox_executor format)
            "summary": {
                "malicious": malicious_count,
                "suspicious": suspicious_count,
                "clean": metrics.packages_tested - malicious_count - suspicious_count,
                "verdict_explanation": {
                    "CLEAN": "No suspicious behavior detected",
                    "INFO": "Minor activity detected, not concerning",
                    "WARNING": "Suspicious behavior (HIGH severity) - network calls, env access",
                    "CRITICAL": "Malicious behavior confirmed - credential theft, exfiltration",
                    "ERROR": "Sandbox execution failed"
                }.get(result.verdict.value, "Unknown verdict")
            },
            "findings": [
                {
                    "rule": f.rule,
                    "severity": f.severity.value if hasattr(f.severity, 'value') else str(f.severity),
                    "description": f.description,
                    "phase": f.phase,
                    "evidence": f.evidence
                }
                for f in result.batch_result.findings
            ],
            "malicious_packages": result.malicious_packages,
            "suspicious_packages": result.batch_result.suspicious_packages,
            "metrics": metrics.to_dict(),
            "batch": {
                "verdict": result.batch_result.verdict.value,
                "duration_ms": result.batch_result.duration_ms,
                "findings_count": len(result.batch_result.findings)
            },
            "individual_tests": len(result.individual_results)
        }
        
        # Add individual findings
        for r in result.individual_results:
            for f in r.findings:
                sandbox_data["findings"].append({
                    "rule": f.rule,
                    "severity": f.severity.value if hasattr(f.severity, 'value') else str(f.severity),
                    "description": f.description,
                    "phase": f.phase,
                    "evidence": f.evidence,
                    "package": r.package
                })
        
        # Print summary with explanation
        verdict_icon = {
            "CLEAN": "✅",
            "INFO": "ℹ️",
            "WARNING": "⚠️",
            "CRITICAL": "🚨",
            "ERROR": "❌"
        }.get(result.verdict.value, "❓")
        
        verdict_explanation = {
            "CLEAN": "No suspicious install-time behavior",
            "INFO": "Minor activity detected",
            "WARNING": f"Suspicious behavior ({suspicious_count} packages) - review issues",
            "CRITICAL": f"MALICIOUS behavior ({malicious_count} packages) - immediate action needed",
            "ERROR": "Sandbox execution failed"
        }.get(result.verdict.value, "")
        
        logger.info(f"      {verdict_icon} Sandbox verdict: {result.verdict.value}")
        if verdict_explanation:
            logger.info(f"         → {verdict_explanation}")
        if result.malicious_packages:
            logger.info(f"      🚨 Malicious packages: {', '.join(result.malicious_packages)}")
        if result.batch_result.suspicious_packages:
            logger.info(f"      ⚠️  Suspicious packages: {', '.join(result.batch_result.suspicious_packages[:5])}")
            if len(result.batch_result.suspicious_packages) > 5:
                logger.info(f"         ... and {len(result.batch_result.suspicious_packages) - 5} more")
            
            # Show details about WHY packages are suspicious 
            if result.batch_result.findings:
                logger.info(f"      📋 Suspicious behaviors detected:")
                finding_types = {}
                for finding in result.batch_result.findings[:20]:  # Limit output
                    finding_type = finding.finding_type if hasattr(finding, 'finding_type') else 'unknown'
                    finding_types[finding_type] = finding_types.get(finding_type, 0) + 1
                for ftype, count in sorted(finding_types.items(), key=lambda x: -x[1])[:5]:
                    logger.info(f"         • {ftype}: {count} occurrences")
                if len(result.batch_result.findings) > 20:
                    logger.info(f"         ... and {len(result.batch_result.findings) - 20} more issues")
        logger.info(f"      ⏱️  Duration: {result.duration_ms}ms")
        
        return sandbox_data
        
    except Exception as e:
        logger.info(f"   ⚠️  Sandbox error: {e}")
        import traceback
        traceback.print_exc()
        return {
            "verdict": "ERROR",
            "reason": str(e),
            "packages_tested": len(packages),
            "findings": []
        }

def run_reachability_analysis(
    repo_path: Path,
    sbom_file: Path,
    vulns_file: Path,
    libs_dir: Optional[Path],
    output_dir: Path,
    enable_dynamic_malware: bool = True,
    debug: bool = False,
    progress_callback = None,
    ai_findings: List = None,  # v4.5.18: AI/LLM security findings
    ai_scan_time: float = 0.0,  # v4.5.39: AI scan timing for step breakdown
    dlp_scan_time: float = 0.0,  # v4.5.50: DLP scan timing for step breakdown
):
    """Run reachability analysis (reuses existing reachable.py)
    
    Args:
        ai_findings: AI/LLM security findings (OWASP LLM Top 10)
        ai_scan_time: Time spent on AI scanning (for step breakdown)
        dlp_scan_time: Time spent on DLP scanning (for step breakdown)
    
    Note: OWASP Top 10 (Web) data is derived from CWE findings automatically.
    """
    # Import existing analyzer
    from .reachable import ReachabilityAnalyzer
    
    # Create and run analyzer
    analyzer = ReachabilityAnalyzer(
        app_dir=repo_path,
        libs_dir=libs_dir,
        sbom_file=sbom_file,
        vulns_file=vulns_file,
        verbose=debug,  # Only print details in debug mode
        progress_callback=progress_callback,
        ai_findings=ai_findings,  # v4.5.18: AI/LLM security findings
        ai_scan_time=ai_scan_time,  # v4.5.39: AI scan timing
        dlp_scan_time=dlp_scan_time,  # v4.5.50: DLP scan timing
    )
    
    results = analyzer.analyze()
    
    # Run dynamic malware sandbox analysis if enabled
    # Note: Static malware analysis (GuardDog) always runs as part of reachability analysis
    sandbox_results = None
    if enable_dynamic_malware:
        if progress_callback:
            progress_callback(15, 15, "Dynamic Malware Sandbox", "Checking platform...")
        sandbox_results = run_dynamic_malware_sandbox(sbom_file, output_dir)
        if progress_callback:
            progress_callback(15, 15, "Dynamic Malware Sandbox", "Complete")
    if sandbox_results:
        results['dynamic_malware'] = sandbox_results
        # Also add to security_scans for dashboard compatibility
        if 'security_scans' not in results:
            results['security_scans'] = {}
        results['security_scans']['dynamic_malware'] = sandbox_results
    
    # Save results
    print()
    logger.info("[5/5] Saving results...")
    
    # Helper to add timestamp to any dict
    from datetime import datetime
    def add_timestamp(data: dict) -> dict:
        """Add scan timestamp to JSON output"""
        data['_metadata'] = {
            'generated_at': datetime.now().isoformat() + 'Z',
            'reachable_version': results.get('reachable_version', __version__),
            'schema': 'REACHABLE'
        }
        return data
    
  
    try:
        from .compression import save_json as save_json_compressed
        use_compression = True
    except ImportError:
        use_compression = False
    
    # 1. Main report (everything) - use compression for large reports
    report_file = output_dir / "reachable-report.json"
    if use_compression:
        actual_file = save_json_compressed(results, report_file, compress=True)
        logger.info(f"   ✓ Master report: {actual_file.name} (compressed)")
    else:
        with open(report_file, 'w') as f:
            json.dump(results, f, indent=2)
        logger.info(f"   ✓ Master report: reachable-report.json")
    
    # Note: sbom.json and vulns.json already created in steps 1-2
    logger.info(f"   ℹ️  Core files: sbom.json, vulns.json (created earlier)")
    
    # Legacy mode: create individual JSON files in raw/ (disabled by default)
    # Set to True for backward compatibility with older integrations
    legacy_raw = False
  
    # But always create for scan-manifest.json (needed for CI/CD)
    raw_dir = output_dir / "raw"
    raw_dir.mkdir(exist_ok=True)
    
    if legacy_raw:
        logger.info("   💾 Legacy mode: Creating detailed JSON files in raw/")
    
    # Generate scan manifest for CI/CD coordination
    scan_id = results.get('metadata', {}).get('scan_id', 
              results.get('metadata', {}).get('scan_timing', {}).get('start_timestamp', 'unknown'))
    git_info = results.get('metadata', {}).get('git_info')
    scan_manifest = {
        'schema_version': '3.0',
        'scan_id': scan_id,
        'generated_at': results.get('metadata', {}).get('generated_at', ''),
        'generator_version': results.get('reachable_version', 'unknown'),
        'target': {
            'path': str(results.get('metadata', {}).get('analysis_target', {}).get('app_directory', '')),
            'git_commit': git_info.get('commit_sha') if git_info else None,
            'git_branch': git_info.get('branch') if git_info else None,
        },
        'components': {},
        'outputs': {
            'report': str(report_file.name),
            'dashboard': 'dashboard/index.html',
            'dashboard_data': 'dashboard/data.json',
        }
    }
    
    # 2. Save detailed data files to raw/ subfolder
    logger.info(f"   📊 Saving detailed data files to raw/...")
    
    # CVEs - detailed findings with remediation
    if 'reachable' in results or 'unreachable' in results:
        cve_data = add_timestamp({
            "summary": {
                "total_cves": len(results.get('reachable', {})) + len(results.get('unreachable', {})),
                "reachable": len(results.get('reachable', {})),
                "unreachable": len(results.get('unreachable', {})),
                "by_severity": results.get('summary', {}).get('totals', {})
            },
            "reachable_cves": results.get('reachable', {}),
            "unreachable_cves": results.get('unreachable', {}),
            "exploitability": results.get('threat_intelligence', {})
        })
        
      
        if legacy_raw:
            cve_file = raw_dir / "cves.json"
            with open(cve_file, 'w') as f:
                json.dump(cve_data, f, indent=2)
            logger.info(f"      ✓ raw/cves.json ({len(cve_data['reachable_cves']) + len(cve_data['unreachable_cves'])} CVEs)")
            scan_manifest['components']['cves'] = {'status': 'complete', 'file': 'raw/cves.json'}
        else:
          
            logger.info(f"      ✓ CVEs in database ({len(cve_data['reachable_cves']) + len(cve_data['unreachable_cves'])} CVEs)")
            scan_manifest['components']['cves'] = {'status': 'complete', 'location': 'database'}
    
    # Secrets - with locations and reachability
    if 'security_scans' in results and 'secrets' in results['security_scans']:
        secrets_data = results['security_scans']['secrets']
        if secrets_data:
            secrets_data = add_timestamp(secrets_data if isinstance(secrets_data, dict) else {"findings": secrets_data})
            security_file = raw_dir / "security_findings.json"
            with open(security_file, 'w') as f:
                json.dump(secrets_data, f, indent=2)
            total_secrets = secrets_data.get('total_findings', 0)
            logger.info(f"      ✓ raw/security_findings.json ({total_secrets} secrets)")
            scan_manifest['components']['secrets'] = {'status': 'complete', 'file': 'raw/security_findings.json'}
    
    # Malware - tier 1/2/3 detections
    if 'malware_detection' in results and results['malware_detection']:
        malware_data = add_timestamp(results['malware_detection'])
        malware_file = raw_dir / "malware.json"
        with open(malware_file, 'w') as f:
            json.dump(malware_data, f, indent=2)
        malicious = malware_data.get('malicious_packages', 0)
        if isinstance(malicious, list):
            malicious = len(malicious)
        logger.info(f"      ✓ raw/malware.json ({malicious} malicious packages)")
        scan_manifest['components']['malware'] = {'status': 'complete', 'file': 'raw/malware.json'}
    
    # Sandbox - behavioral analysis findings
    sandbox_data = None
    if 'sandbox' in results and results['sandbox']:
        sandbox_data = results['sandbox']
    elif 'security_scans' in results and 'sandbox' in results['security_scans']:
        sandbox_data = results['security_scans']['sandbox']
    
    if sandbox_data:
        sandbox_data = add_timestamp(sandbox_data if isinstance(sandbox_data, dict) else {"findings": sandbox_data})
        sandbox_file = raw_dir / "sandbox.json"
        with open(sandbox_file, 'w') as f:
            json.dump(sandbox_data, f, indent=2)
        verdict = sandbox_data.get('verdict', 'N/A')
        findings = sandbox_data.get('findings', [])
        if not isinstance(findings, list):
            findings = []
        findings_count = len(findings)
        critical_count = sum(1 for f in findings if isinstance(f, dict) and f.get('severity') == 'CRITICAL')
        logger.info(f"      ✓ raw/sandbox.json (verdict: {verdict}, {findings_count} issues, {critical_count} critical)")
        scan_manifest['components']['sandbox'] = {'status': 'complete', 'file': 'raw/sandbox.json'}
    
    # Package Health - unmaintained/risky packages
    if 'tool_execution_log' in results and 'package_health_analyzer' in results['tool_execution_log']:
        health_log = results['tool_execution_log']['package_health_analyzer']
        if health_log.get('executed'):
            health_data = add_timestamp({
                "summary": {
                    "total_packages": health_log['metrics']['packages_analyzed'],
                    "health_distribution": health_log['metrics']['health_distribution'],
                    "unmaintained": health_log['metrics']['health_distribution'].get('CRITICAL', 0),
                    "risky": health_log['metrics']['health_distribution'].get('MEDIUM', 0)
                },
                "findings": results.get('findings', {}).get('package_health_issues', [])
            })
            health_file = raw_dir / "health.json"
            with open(health_file, 'w') as f:
                json.dump(health_data, f, indent=2)
            logger.info(f"      ✓ raw/health.json ({health_data['summary']['total_packages']} packages)")
            scan_manifest['components']['health'] = {'status': 'complete', 'file': 'raw/health.json'}
    
    # Correlation - threat correlations (large file, use compression)
    if 'correlation' in results and results['correlation']:
        correlation_data = add_timestamp(results['correlation'])
        correlation_file = raw_dir / "correlation.json"
        if use_compression:
            actual_file = save_json_compressed(correlation_data, correlation_file, compress=True)
            total_threats = correlation_data.get('summary', {}).get('total_composite_threats', 0)
            logger.info(f"      ✓ raw/{actual_file.name} ({total_threats} composite threats)")
            scan_manifest['components']['correlation'] = {'status': 'complete', 'file': f'raw/{actual_file.name}'}
        else:
            with open(correlation_file, 'w') as f:
                json.dump(correlation_data, f, indent=2)
            total_threats = correlation_data.get('summary', {}).get('total_composite_threats', 0)
            logger.info(f"      ✓ raw/correlation.json ({total_threats} composite threats)")
            scan_manifest['components']['correlation'] = {'status': 'complete', 'file': 'raw/correlation.json'}
    
    # Attack Surface - phantom deps, shadow imports
    if 'findings' in results and 'attack_surface' in results['findings']:
        attack_surface_data = add_timestamp(results['findings']['attack_surface'])
        attack_surface_file = raw_dir / "attack_surface.json"
        with open(attack_surface_file, 'w') as f:
            json.dump(attack_surface_data, f, indent=2)
        phantom = attack_surface_data.get('phantom_dependencies', {}).get('count', 0)
        logger.info(f"      ✓ raw/attack_surface.json ({phantom} phantom dependencies)")
        scan_manifest['components']['attack_surface'] = {'status': 'complete', 'file': 'raw/attack_surface.json'}
    
    # Call graphs (keep in output_dir for easy access, also copy to raw/)
    if 'call_graph_exports' in results:
        for format_name, content in results['call_graph_exports'].items():
            graph_file = output_dir / f"call-graph.{format_name}"
            with open(graph_file, 'w') as f:
                f.write(content)
            # Also save to raw/
            raw_graph_file = raw_dir / f"call-graph.{format_name}"
            with open(raw_graph_file, 'w') as f:
                f.write(content)
        logger.info(f"      ✓ call-graph.json (+ raw/)")
        scan_manifest['components']['call_graph'] = {'status': 'complete', 'file': 'raw/call-graph.json'}
    
    # Save scan manifest
    manifest_file = raw_dir / "scan-manifest.json"
    with open(manifest_file, 'w') as f:
        json.dump(scan_manifest, f, indent=2)
    logger.info(f"      ✓ raw/scan-manifest.json (CI/CD coordination)")
    
    # Populate database with all findings (after raw files exist)
    # v4.5.8: Store to repo.db (per-repo database with history)
    # v4.5.10: Extract and pass risk data to DB storage
    overall_risk = results.get('summary', {}).get('overall_risk', {})
    db_risk_score = overall_risk.get('risk_score', 0)
    db_risk_level = overall_risk.get('risk_level', None)
    
    # v4.5.29: Pass AI findings directly to DB storage (don't rely on JSON file)
    ai_findings_for_db = [f.to_dict() if hasattr(f, 'to_dict') else f for f in (ai_findings or [])]
    
    store_scan_to_database(output_dir, use_legacy_raw=legacy_raw, repo_path=repo_path,
                           risk_score=db_risk_score, risk_level=db_risk_level,
                           ai_findings=ai_findings_for_db)
    
    # Store repo.db path in results for dashboard generator
    from .database_storage import get_repo_db_path
    results['_repo_db_path'] = str(get_repo_db_path(repo_path))
    
    # v4.6.8: Auto-maintenance after scan (checkpoint, vacuum, prune)
    try:
        from .config_manager import is_auto_maintenance_enabled, load_config
        from .auto_maintenance import run_auto_maintenance
        
        if is_auto_maintenance_enabled():
            repo_db = get_repo_db_path(repo_path)
            if repo_db and repo_db.exists():
                config = load_config()
                auto_results = run_auto_maintenance(repo_db, config)
                
                if debug and auto_results.get('checkpointed'):
                    logger.debug("✓ Auto-maintenance: database checkpointed")
                if debug and auto_results.get('vacuumed'):
                    logger.debug("✓ Auto-maintenance: database vacuumed")
                if auto_results.get('pruned', 0) > 0 and debug:
                    logger.debug(f"✓ Auto-maintenance: {auto_results['pruned']} old scans removed")
    except Exception as e:
        if debug:
            logger.debug(f"Auto-maintenance warning: {e}")
    
    return results

def _generate_dashboard(results: dict, output_dir: Path, skip: bool = False) -> None:
    """Generate Dashboard v2 (funnel visualization with Executive + Engineering views)"""
    if skip:
        logger.info(f"      ⏭️  Dashboard skipped (--no-dashboard)")
        return
    
    try:
        from reachable.dashboard_v2.generator import DashboardV2Generator
        
        generator = DashboardV2Generator()
        dashboard_dir = generator.generate_from_report(results, output_dir)
        # Dashboard path is shown in scan_complete banner - no need to repeat here
    except Exception as e:
        logger.info(f"      ⚠ Dashboard generation failed: {e}")

def print_summary(results: dict):
    """Print summary (reuses existing format)"""
    print()
    print("=" * 70)
    logger.info("ANALYSIS COMPLETE")
    print("=" * 70)
    
    summary = results.get('summary', {})
    totals = summary.get('totals', {})
    
    print()
    logger.info("📊 CVE Summary:")
    total_cves = totals.get('cves_total', summary.get('total_cves', 0))
    logger.info(f"   Total CVEs found: {total_cves}")
    
    # Severity breakdown
    critical = totals.get('cves_critical', 0)
    high = totals.get('cves_high', 0)
    medium = totals.get('cves_medium', 0)
    low = totals.get('cves_low', 0)
    
    if critical + high + medium + low > 0:
        logger.info(f"   📋 Severity Breakdown:")
        if critical > 0:
            logger.info(f"      🔴 Critical: {critical}")
        if high > 0:
            logger.info(f"      🟠 High: {high}")
        if medium > 0:
            logger.info(f"      🟡 Medium: {medium}")
        if low > 0:
            logger.info(f"      🟢 Low: {low}")
    
    print()
    reachable = totals.get('cves_reachable', summary.get('reachable_cves', 0))
    unreachable = totals.get('cves_unreachable', summary.get('unreachable_cves', 0))
    logger.info(f"   ✅ REACHABLE: {reachable} (require immediate attention)")
    logger.info(f"   ❌ UNREACHABLE: {unreachable} (Risk: LOW)")
    logger.info(f"   📉 Risk Reduction: {summary.get('risk_reduction_pct', 0):.1f}%")
    
    print()
    logger.info("📈 Code Coverage:")
    logger.info(f"   Functions analyzed: {summary.get('total_functions', 0)}")
    reachable_count = summary.get('reachable_functions', 0)
    total_funcs = summary.get('total_functions', 1)
    pct = (reachable_count / total_funcs * 100) if total_funcs > 0 else 0
    logger.info(f"   Reachable from entrypoints: {reachable_count} ({pct:.1f}%)")
    print()

def _get_repo_stats(repo_path: Path) -> dict:
    """
    Get repository scan statistics from repo.db.
    
    Returns:
        dict with branch, scan_count, first_scan_date
    """
    import subprocess
    from .database_storage import get_repo_db_path
    
    stats = {
        'branch': 'unknown',
        'scan_count': 0,
        'first_scan_date': None,
    }
    
    # Get current git branch
    try:
        result = subprocess.run(
            ['git', 'rev-parse', '--abbrev-ref', 'HEAD'],
            capture_output=True, text=True, cwd=repo_path, timeout=5
        )
        if result.returncode == 0:
            stats['branch'] = result.stdout.strip()
    except:
        pass
    
    # Get scan history from repo.db
    try:
        import sqlite3
        repo_db_path = get_repo_db_path(repo_path)
        if repo_db_path.exists():
            conn = sqlite3.connect(str(repo_db_path))
            cursor = conn.cursor()
            
            # Get total scan count for this repo
            cursor.execute("SELECT COUNT(*) FROM scans WHERE status = 'complete'")
            stats['scan_count'] = cursor.fetchone()[0]
            
            # Get first scan date
            cursor.execute("SELECT MIN(timestamp) FROM scans")
            first = cursor.fetchone()[0]
            if first:
                stats['first_scan_date'] = first[:10]  # YYYY-MM-DD
            
            conn.close()
    except:
        pass
    
    return stats

def scan_repo(args):
    """Scan an arbitrary repository"""
    from .output_manager import OutputManager
    from .output_modes import print_quiet_summary, print_enhanced_summary, print_verbose_summary
    from .scan_logger import ScanLogger
    from .database_storage import RepoDatabase, get_repo_db_path
    from .preflight import preflight_check
    from . import __version__
    import time
    
    # Preflight check - ensure all tools are ready (auto-fix if missing)
    quiet_mode = getattr(args, 'quiet', False)
    preflight = preflight_check(fix=True, quiet=quiet_mode, skip_vulndb=False)
    if not preflight.ok:
        logger.info("\n❌ Cannot start scan - missing dependencies:")
        for issue in preflight.issues:
            logger.info(f"  - {issue}")
        logger.info("\nRun 'reachctl doctor' to resolve.")
        sys.exit(1)
    
    # Initialize structured logger
    debug_mode = getattr(args, 'debug', False)
    quiet_mode = getattr(args, 'quiet', False)
    fail_on_threshold = getattr(args, 'fail_on', 'none')
    force_rebuild = getattr(args, 'force_rebuild', False)
    no_dashboard = getattr(args, 'no_dashboard', False)
    
    repo_path = Path(args.repo).resolve()
    
    # Initialize output manager first to get output_dir
    custom_output = Path(args.output).resolve() if args.output else None
    output_mgr = OutputManager(repo_path, custom_output, force_rebuild=force_rebuild)
    output_dir = output_mgr.scan_dir
    
    # Initialize logger with log file
    log_path = output_dir / "scan.log"
    logger = ScanLogger(debug=debug_mode, log_file=log_path)
    
    # Get license info for banner
    license_info = None
    try:
        from .license import validate_license
        license_info = validate_license()
    except:
        pass
    
    # Get repo stats for banner
    repo_stats = _get_repo_stats(repo_path)
    
    # Initialize scan context early for language/build system detection in header
    from .scan_context import ScanContext
    scan_ctx = ScanContext(repo_path, output_dir)
    
    # Print scan header with analysis scope (before tee takes over)
    logger.scan_start_msg(repo_path.name, repo_path, __version__, 
                          license_info=license_info, repo_stats=repo_stats,
                          scan_context=scan_ctx)
    
    # Use output manager for all paths
    libs_dir = output_mgr.scan_dir / "libs"
    
    # Tee output to log file - suppress console unless in debug mode
    # Quiet mode also suppresses console (for CI/CD)
    # This captures all verbose output from scanners to the log file
    # while showing only our structured output on console
    console_enabled = debug_mode and not quiet_mode
    tee = TeeOutput(log_path, console_enabled=console_enabled)
    original_stdout = sys.stdout
    sys.stdout = tee
    
    try:
        # Validate inputs
        if not repo_path.exists():
            logger.info(f"❌ Error: Repository not found: {repo_path}")
            sys.exit(1)
        
        if not repo_path.is_dir():
            logger.info(f"❌ Error: Not a directory: {repo_path}")
            sys.exit(1)
        
        # scan_ctx already initialized above for header display
        if debug_mode:
            scan_ctx.print_scan_header()
        
        # Check GitHub connectivity (for library cloning) - only show in debug mode
        check_github_connectivity(verbose=debug_mode)
        
        # Print scan plan for monorepos (only in debug mode)
        if debug_mode:
            scan_ctx.print_scan_plan()
        
        # Save scan plan (what we're going to scan)
        scan_plan = {
            'timestamp': output_mgr.timestamp,
            'repo_path': str(repo_path),
            'repo_name': output_mgr.repo_name,
            'project_type': scan_ctx.project_type,
            'languages': scan_ctx.detected_languages,
            'is_monorepo': scan_ctx.is_monorepo,
            'subprojects': scan_ctx.subprojects,
            'file_counts': scan_ctx.total_files
        }
        output_mgr.save_scan_plan(scan_plan)
        
        # Initialize scan metadata (tool versions, policies)
        scan_metadata = {
            'scan_started': output_mgr.timestamp,
            'command': ' '.join(sys.argv),
            'scan_dir': str(output_dir),
            'tools_used': {},
            'policies_applied': {}
        }
        
        # Run analysis pipeline (reuses all existing logic!)
        # Step 1: Generate SBOM (reuses existing syft logic)
        logger.phase_start(1, "SBOM Generation", "Syft", total_phases=5)
        sbom_file = generate_sbom(repo_path, output_dir, verbose=debug_mode)
        logger.phase_end(1, f"Created {sbom_file.name}")
        
        # Step 2: Scan vulnerabilities (reuses existing grype logic)
        logger.phase_start(2, "Vulnerability Scan", "Grype", total_phases=5)
        vulns_file = scan_vulnerabilities(sbom_file, output_dir, verbose=debug_mode)
        logger.phase_end(2, "CVE scan complete")
        
        # Step 3: Clone vulnerable libs (NEW smart cloning)
        logger.phase_start(3, "Library Cloning", "MCP/Git", total_phases=5)
        libs_path, lib_metrics = clone_vulnerable_libs(vulns_file, libs_dir, scan_ctx, verbose=debug_mode)
        cloned_count = lib_metrics.get('mcp_success', 0) + lib_metrics.get('git_success', 0) + lib_metrics.get('cache_hits', 0)
        logger.phase_end(3, f"{cloned_count} libraries cloned")
        
        # Step 4 & 5: Reachability analysis (reuses existing reachable.py)
        logger.phase_start(4, "Security Analysis", "Multi-Signal Analysis", total_phases=5)
        if debug_mode:
            scan_ctx.print_phase_header(4, 5, "Running Security Analysis", "Multi-Signal Analysis", 
                                       f"Analyzing {scan_ctx.project_type} project with {', '.join(scan_ctx.detected_languages)}")
        
        # Check dynamic malware sandbox settings
        enable_dynamic_malware = not getattr(args, 'no_dynamic_malware', False)
        
        # v4.5.39: AI security scan ON by default (use --no-ai to skip)
        disable_ai = getattr(args, 'disable_ai', False)
        ai_findings_for_correlation = []
        ai_scanner = None
        ai_scan_time = 0.0  # v4.5.39: Track AI scan timing
        
        if not disable_ai:
            try:
                from .ai import AISecurityScanner, AIScanConfig
                
                ai_scan_start = time.time()
                ai_scanner = AISecurityScanner(config=AIScanConfig.full())
                ai_findings_list = list(ai_scanner.scan(repo_path))
                ai_scan_time = time.time() - ai_scan_start
                
                # v4.5.30: Pass AIFinding objects (not dicts) so they can be enriched with call graph reachability
                # Correlation engine handles both AIFinding objects and dicts
                ai_findings_for_correlation = ai_findings_list
                
                if debug_mode:
                    logger._write(f"  🤖 AI Security: {len(ai_findings_list)} findings in {ai_scan_time:.1f}s")
            except ImportError as e:
                if debug_mode:
                    logger._write(f"  ⚠️  AI module not available: {e}")
            except Exception as e:
                if debug_mode:
                    logger._write(f"  ⚠️  AI pre-scan error: {e}")
        
        analysis_start = time.time()
        last_step_time = [analysis_start]  # Use list to allow mutation in closure
        
        def progress_callback(step: int, total: int, name: str, status: str):
            """Show intermediate progress during Security Analysis"""
            now = time.time()
            step_elapsed = now - last_step_time[0]
            total_elapsed = now - analysis_start
            last_step_time[0] = now
            # Print inline progress update
            sys.__stdout__.write(f"\r    [{step}/{total}] {name}: {status} ({step_elapsed:.1f}s)".ljust(70))
            sys.__stdout__.flush()
            if step == total:
                sys.__stdout__.write("\n")
                sys.__stdout__.flush()
        
        results = run_reachability_analysis(
            repo_path,
            sbom_file,
            vulns_file,
            libs_path,
            output_dir,
            enable_dynamic_malware=enable_dynamic_malware,
            debug=debug_mode,
            progress_callback=progress_callback,
            ai_findings=ai_findings_for_correlation,  # v4.5.18: Pass AI findings for correlation
            ai_scan_time=ai_scan_time,  # v4.5.39: Pass AI scan timing for step breakdown
        )
        logger.phase_end(4, "Analysis complete")
        
        # Add library metrics to results (includes obsolete packages info)
        results['library_metrics'] = lib_metrics
        
        # Optional: Run deployment advisories scan (IaC/config)
        if getattr(args, 'enable_config_mgt', False):
            logger.phase_start(5, "Config Scanning", "Checkov/Semgrep", total_phases=6)
            
            from .deployment_advisories import DeploymentAdvisoriesScanner, print_advisories
            
            use_checkov = getattr(args, 'use_checkov', False)
            adv_scanner = DeploymentAdvisoriesScanner(use_checkov=use_checkov)
            adv_result = adv_scanner.scan(repo_path)
            
            # Save results
            adv_file = output_dir / "deployment-advisories.json"
            import json
            with open(adv_file, 'w') as f:
                json.dump(adv_result.to_dict(), f, indent=2)
            
            # Add to results (but clearly marked as NOT in risk score)
            results['deployment_advisories'] = {
                'enabled': True,
                'included_in_risk_score': False,
                'total': len(adv_result.advisories),
                'by_category': adv_result.by_category,
                'by_severity': adv_result.by_severity,
                'source': adv_result.source,
                'output_file': str(adv_file),
            }
            
            logger.phase_end(5, f"{len(adv_result.advisories)} advisories found")
            
            # Print summary in debug mode
            if debug_mode:
                print_advisories(adv_result, verbose=True)
        else:
            results['deployment_advisories'] = {
                'enabled': False,
                'message': 'Use --enable-config-mgt to scan IaC/deployment configs',
            }
        
        # Save AI security results (v4.5.39: AI scan runs by default)
        if not disable_ai and ai_scanner is not None:
            # Save AI results to file
            ai_findings_list = ai_scanner._findings
            by_owasp = {}
            by_severity = {'ERROR': 0, 'WARNING': 0, 'INFO': 0}
            for f in ai_findings_list:
                cat = f.owasp_category or 'OTHER'
                if cat not in by_owasp:
                    by_owasp[cat] = []
                by_owasp[cat].append(f.to_dict())
                by_severity[f.severity] = by_severity.get(f.severity, 0) + 1
            
            ai_file = output_dir / "raw" / "ai-security.json"  # v4.5.29: Move to raw/ for debug
            import json
            with open(ai_file, 'w') as f:
                json.dump({
                    'total': len(ai_findings_list),
                    'by_owasp': {k: len(v) for k, v in by_owasp.items()},
                    'by_severity': by_severity,
                    'findings': [finding.to_dict() for finding in ai_findings_list],
                }, f, indent=2, default=str)
            
            # Count reachable and guarded
            ai_reachable = sum(1 for f in ai_findings_list if f.is_reachable)
            ai_guarded = sum(1 for f in ai_findings_list if f.guards)
            
            # Add to results
            results['ai_security'] = {
                'enabled': True,
                'included_in_risk_score': True,  # v4.5.18: Integrated into correlation
                'total': len(ai_findings_list),
                'reachable': ai_reachable,
                'guarded': ai_guarded,
                'by_owasp': {k: len(v) for k, v in by_owasp.items()},
                'by_severity': by_severity,
                'critical_findings': sum(1 for f in ai_findings_list if f.is_critical),
                'output_file': str(ai_file),
            }
        else:
            results['ai_security'] = {
                'enabled': False,
                'message': 'AI analysis skipped (--no-ai flag)',
            }
        
        # v4.5.50: DLP/PII analysis (ON by default, use --no-dlp to skip)
        disable_dlp = getattr(args, 'disable_dlp', False)
        dlp_scanner = None
        dlp_scan_time = 0.0
        
        if not disable_dlp:
            try:
                from .dlp import DLPScanner, DLPScanConfig
                
                dlp_scan_start = time.time()
                dlp_scanner = DLPScanner(config=DLPScanConfig.full())
                dlp_findings_list = dlp_scanner.scan(repo_path)
                dlp_scan_time = time.time() - dlp_scan_start
                
                # Always show DLP timing (v4.5.50)
                logger._write(f"  🔐 DLP/PII Security: {len(dlp_findings_list)} findings in {dlp_scan_time:.1f}s")
            except ImportError as e:
                if debug_mode:
                    logger._write(f"  ⚠️  DLP module not available: {e}")
            except Exception as e:
                if debug_mode:
                    logger._write(f"  ⚠️  DLP scan error: {e}")
        
        # Save DLP results
        if not disable_dlp and dlp_scanner is not None:
            dlp_stats = dlp_scanner.statistics
            
            # Save DLP results to file
            dlp_file = output_dir / "raw" / "dlp-security.json"
            import json
            with open(dlp_file, 'w') as f:
                json.dump({
                    'total': dlp_stats.get('total_findings', 0),
                    'discovery_findings': dlp_stats.get('discovery_findings', 0),
                    'taint_findings': dlp_stats.get('taint_findings', 0),
                    'ai_findings': dlp_stats.get('ai_findings', 0),
                    'by_pii_type': dlp_stats.get('by_pii_type', {}),
                    'by_severity': dlp_stats.get('by_severity', {}),
                    'by_sink_type': dlp_stats.get('by_sink_type', {}),
                    'findings': [f.to_dict() for f in dlp_scanner.findings],
                }, f, indent=2, default=str)
            
            results['dlp_security'] = {
                'enabled': True,
                'included_in_risk_score': True,
                'total': dlp_stats.get('total_findings', 0),
                'discovery_findings': dlp_stats.get('discovery_findings', 0),
                'taint_findings': dlp_stats.get('taint_findings', 0),
                'ai_findings': dlp_stats.get('ai_findings', 0),
                'reachable': dlp_stats.get('reachable_findings', 0),
                'sanitized': dlp_stats.get('sanitized_findings', 0),
                'by_pii_type': dlp_stats.get('by_pii_type', {}),
                'by_severity': dlp_stats.get('by_severity', {}),
                'output_file': str(dlp_file),
                'scan_time': dlp_scan_time,  # v4.5.50: Track DLP scan timing
            }
        else:
            results['dlp_security'] = {
                'enabled': False,
                'message': 'DLP analysis skipped (--no-dlp flag)',
            }
        
        # v4.5.50: Store DLP findings to database (separate from main store_scan_to_database)
        if not disable_dlp and dlp_scanner is not None and dlp_scanner.findings:
            try:
                from .database_storage import RepoDatabase, get_repo_db_path
                repo_db_path = get_repo_db_path(repo_path)
                if repo_db_path.exists():
                    db = RepoDatabase(repo_db_path)
                    # Get current scan_id from the most recent scan
                    cursor = db.conn.execute(
                        "SELECT id FROM scans ORDER BY id DESC LIMIT 1"
                    )
                    row = cursor.fetchone()
                    if row:
                        db._current_scan_id = row[0]
                        dlp_findings_for_db = [f.to_dict() if hasattr(f, 'to_dict') else f for f in dlp_scanner.findings]
                        stored_count = db.store_dlp_findings(dlp_findings_for_db)
                        
                        # P2.50 FIX: Update scans table totals to include DLP
                        # (complete_scan() runs before DLP is stored, so we need to update)
                        db.conn.execute("""
                            UPDATE scans SET
                                total_findings = (
                                    SELECT COALESCE(SUM(cnt), 0) FROM (
                                        SELECT COUNT(*) as cnt FROM findings WHERE scan_id = ?
                                        UNION ALL SELECT COUNT(*) FROM ai_findings WHERE scan_id = ?
                                        UNION ALL SELECT COUNT(*) FROM dlp_findings WHERE scan_id = ?
                                    )
                                ),
                                reachable_findings = (
                                    SELECT COALESCE(SUM(cnt), 0) FROM (
                                        SELECT COUNT(*) as cnt FROM findings WHERE scan_id = ? AND app_reachability = 'REACHABLE'
                                        UNION ALL SELECT COUNT(*) FROM ai_findings WHERE scan_id = ? AND is_reachable = 1
                                        UNION ALL SELECT COUNT(*) FROM dlp_findings WHERE scan_id = ? AND is_reachable = 1
                                    )
                                )
                            WHERE id = ?
                        """, (db._current_scan_id,) * 7)
                        db.conn.commit()
                        
                        if debug_mode:
                            logger._write(f"  💾 Stored {stored_count} DLP findings to database (scans table updated)")
                    db.close()
            except Exception as e:
                if debug_mode:
                    logger._write(f"  ⚠️  Error storing DLP findings to DB: {e}")
        
        # v4.5.50: Set DLP timing for timing summary
        logger.set_dlp_timing(dlp_scan_time)
        
        # Print timing summary
        logger.print_timing_summary()
        
        # Extract results for summary - with error handling
        try:
            summary = results.get('summary', {})
            totals = summary.get('totals', {})
            
            # Set counts for logger (v4.5.17: Enhanced with unknown counts)
            # Get security_scans for malware breakdown
            security_scans = results.get('security_scans', {})
            dynamic_malware = results.get('dynamic_malware', security_scans.get('dynamic_malware', {}))
            
            # AI Security counts (v4.5.18)
            ai_security = results.get('ai_security', {})
            ai_total = ai_security.get('total', 0)
            ai_reachable = ai_security.get('reachable', ai_total)  # Default all reachable
            ai_guarded = ai_security.get('guarded', 0)
            
            # DLP/PII Security counts (v4.5.50)
            dlp_security = results.get('dlp_security', {})
            dlp_total = dlp_security.get('total', 0)
            dlp_reachable = dlp_security.get('reachable', dlp_total)  # Default all reachable
            dlp_sanitized = dlp_security.get('sanitized', 0)
            
            logger.set_counts(
                # CVEs
                cves_total=totals.get('cves_total', 0),
                cves_reachable=totals.get('cves_reachable', 0),
                cves_unknown=totals.get('cves_unknown', 0),
                # CVE severity breakdown
                cves_critical=totals.get('cves_critical', 0),
                cves_high=totals.get('cves_high', 0),
                cves_medium=totals.get('cves_medium', 0),
                cves_low=totals.get('cves_low', 0),
                # Malware (static + dynamic)
                malware_static=totals.get('malware_total', 0),
                malware_dynamic=dynamic_malware.get('summary', {}).get('malicious', 0) if dynamic_malware else 0,
                malware_reachable=totals.get('malware_reachable', 0),
                malware_count=totals.get('malware_total', 0),  # backward compat
                # Secrets
                secrets_total=totals.get('secrets_total', 0),
                secrets_reachable=totals.get('secrets_reachable', 0),
                secrets_unknown=totals.get('secrets_unknown', 0),
                # Secret severity breakdown
                secrets_critical=totals.get('secrets_critical', 0),
                secrets_high=totals.get('secrets_high', 0),
                secrets_medium=totals.get('secrets_medium', 0),
                secrets_low=totals.get('secrets_low', 0),
                # CWE
                cwe_total=totals.get('cwe_total', 0),
                cwe_reachable=totals.get('cwe_reachable', 0),
                cwe_unknown=totals.get('cwe_unknown', 0),
                # CWE severity breakdown
                cwe_critical=totals.get('cwe_critical', 0),
                cwe_high=totals.get('cwe_high', 0),
                cwe_medium=totals.get('cwe_medium', 0),
                cwe_low=totals.get('cwe_low', 0),
                # Config (always unknown)
                config_total=totals.get('config_total', 0),
                # AI Security (v4.5.18)
                ai_total=ai_total,
                ai_reachable=ai_reachable,
                ai_guarded=ai_guarded,
                # AI severity breakdown
                ai_critical=ai_security.get('by_severity', {}).get('CRITICAL', 0),
                ai_high=ai_security.get('by_severity', {}).get('HIGH', 0),
                ai_medium=ai_security.get('by_severity', {}).get('MEDIUM', 0),
                ai_low=ai_security.get('by_severity', {}).get('LOW', 0),
                # DLP/PII Security (v4.5.50)
                dlp_total=dlp_total,
                dlp_reachable=dlp_reachable,
                dlp_sanitized=dlp_sanitized,
                # DLP severity breakdown
                dlp_critical=dlp_security.get('by_severity', {}).get('CRITICAL', 0),
                dlp_high=dlp_security.get('by_severity', {}).get('HIGH', 0),
                dlp_medium=dlp_security.get('by_severity', {}).get('MEDIUM', 0),
                dlp_low=dlp_security.get('by_severity', {}).get('LOW', 0),
            )
            
            # Print results summary
            logger.print_results_summary()
            
            # Get risk score (v4.5.3 fix: risk is nested in overall_risk)
            overall_risk = summary.get('overall_risk', {})
            risk_score = overall_risk.get('risk_score', 0)
            risk_level = overall_risk.get('risk_level', 'UNKNOWN')
            
            # Print scan complete banner with dashboard link
            logger.print_scan_complete(risk_score, risk_level, output_dir)
            
            # Print debug report if in debug mode
            logger.print_debug_report()
            
        except Exception as summary_err:
            # Make sure we see any errors in summary generation
            logger._write(f"⚠️  Error generating summary: {summary_err}")
            import traceback
            logger._write(traceback.format_exc())
        
        # Generate dashboard
        _generate_dashboard(results, output_dir, skip=no_dashboard)
        
        # Create 'latest' symlink
        output_mgr.create_latest_symlink()
        
        # v4.6.4: Run data quality audit (only in debug mode)
        if debug_mode and not quiet_mode:
            try:
                from .audit import run_audit
                audit_result = run_audit(output_dir, compact=True, no_dashboard=no_dashboard)
                if audit_result.get('error'):
                    logger._write(f"\n⚠️  Audit error: {audit_result['error']}")
            except Exception as audit_err:
                logger._write(f"\n⚠️  Audit skipped: {audit_err}")
        
        # Auto-trim now handled inside store_scan_to_database (repo.db cleanup)
        
        # Quiet mode: print single-line summary
        if quiet_mode:
            print_quiet_summary(results, output_dir)
        
        # === FAIL-ON THRESHOLD CHECK (v4.5.0) ===
        exit_code = 0
        if fail_on_threshold != 'none':
            from .sarif_exporter import check_threshold
            should_fail, reason = check_threshold(results, fail_on_threshold)
            if should_fail:
                if quiet_mode:
                    # v4.5.2: Always show gate result in CI/CD (use real stdout)
                    sys.__stdout__.write(f"🚨 CI/CD GATE FAILED: {reason}\n")
                    sys.__stdout__.flush()
                else:
                    logger.info(f"\n🚨 CI/CD GATE FAILED: {reason}")
                    logger.info(f"   Threshold: --fail-on {fail_on_threshold}")
                exit_code = 1
            else:
                if quiet_mode:
                    # v4.5.2: Always show gate result in CI/CD (use real stdout)
                    sys.__stdout__.write(f"✅ CI/CD gate passed: {reason}\n")
                    sys.__stdout__.flush()
                else:
                    logger.info(f"\n✅ CI/CD gate passed: {reason}")
        
        # Store exit code for later (after finally block)
        scan_exit_code = exit_code
        
    except Exception as e:
        # Use multiple approaches to ensure error is visible
        error_msg = f"❌ Error during analysis: {e}"
        try:
            logger._write("")
            logger._write(error_msg)
        except:
            pass
        # Also print to original stdout directly (sys is already imported at module level)
        sys.__stdout__.write(f"\n{error_msg}\n")
        sys.__stdout__.flush()
        import traceback
        traceback.print_exc(file=sys.__stdout__)
        sys.exit(1)
    finally:
        # Close log file and restore stdout
        sys.stdout = original_stdout
        tee.close()
    
    # Exit with appropriate code (after finally block)
    # scan_exit_code is set in the try block based on --fail-on threshold
    if 'scan_exit_code' in locals() and scan_exit_code != 0:
        sys.exit(scan_exit_code)

def _is_dev_build() -> bool:
    """Check if this is a development build (not customer distribution)"""
    from pathlib import Path
    import os
    
    # Check for .dev marker file (present in dev, removed in customer builds)
    dev_marker = Path(__file__).parent / '.dev'
    if dev_marker.exists():
        return True
    
    # Check for compiled Cython modules (customer builds have these)
    core_dir = Path(__file__).parent / 'core'
    if core_dir.exists():
        compiled = list(core_dir.glob('*.so')) + list(core_dir.glob('*.pyd'))
        if compiled:
            return False  # Customer build has compiled modules
    
    # Check environment variable override
    if os.environ.get('REACHABLE_DEV_MODE') == '1':
        return True
    
    return True  # Default: dev build

def format_size(size_bytes: int) -> str:
    """Format bytes as human-readable size"""
    for unit in ['B', 'KB', 'MB', 'GB']:
        if size_bytes < 1024:
            return f"{size_bytes:.1f} {unit}"
        size_bytes /= 1024
    return f"{size_bytes:.1f} TB"

def run_admin_command(args):
    """Handle admin subcommands"""
    if not args.admin_command:
        logger.info("Usage: reachctl admin <cache|test|version|doctor>")
        print()
        logger.info("Admin commands:")
        logger.info("  cache    Cache management (--clear, --status)")
        logger.info("  test     Run test suite")
        logger.info("  version  Show detailed version info")
        logger.info("  doctor   Check system dependencies")
        sys.exit(1)
    
    if args.admin_command == 'cache':
        admin_cache(args)
    elif args.admin_command == 'test':
        admin_test(args)
    elif args.admin_command == 'version':
        admin_version()
    elif args.admin_command == 'doctor':
        admin_doctor()
    else:
        logger.info(f"Unknown admin command: {args.admin_command}")
        sys.exit(1)

def admin_cache(args):
    """Cache management commands (v4.5.40)"""
    from pathlib import Path
    import shutil
    
    # Default to --status if no option specified
    options = ['status', 'clear', 'clear_libs', 'clear_vuln', 'clear_epss', 'clear_semgrep', 'warm']
    if not any([getattr(args, opt, False) for opt in options]):
        args.status = True
    
    cache_base = Path.home() / '.reachable'
    cache_dir = cache_base / 'cache'  # v4.5.40: Consolidated cache location
    reachable_pkg = Path(__file__).parent  # The reachable package directory
    
    # Cache directories
    cache_dirs = {
        'libs': cache_dir / 'libs',  # v4.5.40: Now under cache/
        'guarddog': cache_dir / 'guarddog',  # GuardDog malware scan results
        'guarddog_venv': cache_dir / 'guarddog-venv',  # GuardDog venv
        'vuln_db': cache_dir / 'grype-db',  # Grype vulnerability DB
        'scans': cache_base / 'scans',
    }
    
    # Exploitability cache files (not directories)
    cache_files = {
        'epss': cache_dir / 'epss_cache.json',
        'kev': cache_dir / 'kev_cache.json',
        'exploit_db': cache_dir / 'exploitdb_cve_map.json',
        'metasploit': cache_dir / 'metasploit_cve_map.json',
        'ghsa': cache_dir / 'ghsa_cve_map.json',
        'health_metrics': cache_dir / 'health-metrics',
    }
    
    # Find all __pycache__ directories in the reachable package
    pycache_dirs = list(reachable_pkg.rglob('__pycache__'))
    
    if args.status:
        print("=" * 60)
        logger.info("REACHABLE CACHE STATUS")
        print("=" * 60)
        print()
        logger.info(f"Cache location: {cache_base}")
        print()
        
        total_size = 0
        
        # Show cache directories
        for name, path in cache_dirs.items():
            if path.exists():
                size = sum(f.stat().st_size for f in path.rglob('*') if f.is_file())
                total_size += size
                file_count = sum(1 for _ in path.rglob('*') if _.is_file())
                logger.info(f"  {name:15} {format_size(size):>10}  ({file_count} files)")
            else:
                logger.info(f"  {name:15} {'(empty)':>10}")
        
        # Show exploitability cache files
        print()  # Separator
        logger.info("  Threat Intelligence:")
        for name, path in cache_files.items():
            if path.exists():
                if path.is_file():
                    size = path.stat().st_size
                    total_size += size
                    logger.info(f"    {name:13} {format_size(size):>10}")
                else:  # Directory (health_metrics)
                    size = sum(f.stat().st_size for f in path.rglob('*') if f.is_file())
                    total_size += size
                    file_count = sum(1 for _ in path.rglob('*') if _.is_file())
                    logger.info(f"    {name:13} {format_size(size):>10}  ({file_count} files)")
            else:
                logger.info(f"    {name:13} {'(empty)':>10}")
        
        # Show bytecode cache size
        bytecode_size = 0
        bytecode_files = 0
        for pycache in pycache_dirs:
            if pycache.exists():
                bytecode_size += sum(f.stat().st_size for f in pycache.rglob('*.pyc') if f.is_file())
                bytecode_files += sum(1 for f in pycache.rglob('*.pyc') if f.is_file())
        if bytecode_size > 0:
            total_size += bytecode_size
            logger.info(f"  {'bytecode':15} {format_size(bytecode_size):>10}  ({bytecode_files} .pyc files)")
        else:
            logger.info(f"  {'bytecode':15} {'(empty)':>10}")
        
        # Show Semgrep SHA caches per repo
        scans_root = cache_base / 'scans'
        semgrep_caches = []
        semgrep_total = 0
        if scans_root.exists():
            for repo_dir in sorted(scans_root.iterdir()):
                cf = repo_dir / 'semgrep-cache.json'
                if cf.exists():
                    size = cf.stat().st_size
                    semgrep_total += size
                    semgrep_caches.append((repo_dir.name, size))
        if semgrep_caches:
            print()
            logger.info("  Semgrep Result Caches:")
            for repo_name, size in semgrep_caches:
                logger.info(f"    {repo_name[:30]:30} {format_size(size):>10}")
            total_size += semgrep_total
        
        print()
        logger.info(f"  {'TOTAL':15} {format_size(total_size):>10}")
        return
    
    # Warm caches
    if args.warm:
        admin_cache_warm()
        return
    
    # Determine what to clear
    dir_targets = []  # Directories to clear
    file_targets = []  # Files to clear (exploitability caches)
    clear_bytecode = False
    
    clear_semgrep_all = False
    if args.clear:
        dir_targets = ['libs', 'vuln_db']
        file_targets = ['epss', 'kev', 'exploit_db', 'metasploit', 'ghsa']  # Threat intel files
        clear_bytecode = True  # v4.5.3: Also clear bytecode cache
        clear_semgrep_all = True  # Also clear all Semgrep SHA caches
    elif getattr(args, 'clear_libs', False):
        dir_targets = ['libs']
    elif getattr(args, 'clear_vuln', False):
        dir_targets = ['vuln_db']
    elif getattr(args, 'clear_epss', False):
        file_targets = ['epss', 'kev', 'exploit_db', 'metasploit', 'ghsa']  # All threat intel
    elif getattr(args, 'clear_semgrep', False):
        # Clear Semgrep SHA result caches
        scans_root = cache_base / 'scans'
        repo_filter = getattr(args, 'repo', None)
        if not scans_root.exists():
            logger.info("No Semgrep caches found")
            return
        
        # Find matching repos
        targets = []
        for repo_dir in sorted(scans_root.iterdir()):
            cf = repo_dir / 'semgrep-cache.json'
            if cf.exists():
                if repo_filter is None or repo_filter.lower() in repo_dir.name.lower():
                    targets.append((repo_dir.name, cf))
        
        if not targets:
            if repo_filter:
                logger.info(f"No Semgrep caches matching '{repo_filter}'")
            else:
                logger.info("No Semgrep caches found")
            return
        
        # Confirm unless --force
        if not args.force:
            logger.info(f"This will clear Semgrep caches for {len(targets)} repo(s):")
            for name, cf in targets:
                size = cf.stat().st_size
                logger.info(f"  - {name}: {format_size(size)}")
            confirm = input("Continue? [y/N] ").strip().lower()
            if confirm != 'y':
                logger.info("Cancelled.")
                return
        
        removed = 0
        for name, cf in targets:
            try:
                cf.unlink()
                removed += 1
                logger.info(f"Cleared Semgrep cache: {name}")
            except Exception as e:
                logger.info(f"Failed to clear {name}: {e}")
        logger.info(f"Cleared {removed} Semgrep cache(s)")
        return
    
    if not dir_targets and not file_targets:
        logger.info("No cache target specified")
        return
    
    # Confirm unless --force
    if not args.force:
        logger.info("This will clear the following caches:")
        for name in dir_targets:
            path = cache_dirs.get(name)
            if path and path.exists():
                size = sum(f.stat().st_size for f in path.rglob('*') if f.is_file())
                logger.info(f"  - {name}: {format_size(size)}")
        for name in file_targets:
            path = cache_files.get(name)
            if path and path.exists():
                size = path.stat().st_size if path.is_file() else sum(f.stat().st_size for f in path.rglob('*') if f.is_file())
                logger.info(f"  - {name}: {format_size(size)}")
        confirm = input("Continue? [y/N] ").strip().lower()
        if confirm != 'y':
            logger.info("Cancelled.")
            return
    
    # Clear directory caches
    for name in dir_targets:
        path = cache_dirs.get(name)
        if path and path.exists():
            try:
                shutil.rmtree(path)
                logger.info(f"Cleared {name}: {path}")
            except Exception as e:
                logger.info(f"Failed to clear {name}: {e}")
        else:
            logger.info(f"{name}: already empty")
    
    # Clear file caches (exploitability/threat intel)
    for name in file_targets:
        path = cache_files.get(name)
        if path and path.exists():
            try:
                if path.is_file():
                    path.unlink()
                else:
                    shutil.rmtree(path)
                logger.info(f"Cleared {name}: {path}")
            except Exception as e:
                logger.info(f"Failed to clear {name}: {e}")
        else:
            logger.info(f"{name}: already empty")
    
    # v4.5.3: Clear bytecode cache to avoid stale .pyc issues
    if clear_bytecode:
        bytecode_cleared = 0
        for pycache in pycache_dirs:
            if pycache.exists():
                try:
                    shutil.rmtree(pycache)
                    bytecode_cleared += 1
                except Exception as e:
                    logger.info(f"Failed to clear {pycache}: {e}")
        if bytecode_cleared > 0:
            logger.info(f"Cleared bytecode: {bytecode_cleared} __pycache__ directories")
        else:
            logger.info("bytecode: already empty")
    
    # Clear Semgrep SHA caches when --clear (all)
    if clear_semgrep_all:
        scans_root = cache_base / 'scans'
        semgrep_cleared = 0
        if scans_root.exists():
            for repo_dir in scans_root.iterdir():
                cf = repo_dir / 'semgrep-cache.json'
                if cf.exists():
                    try:
                        cf.unlink()
                        semgrep_cleared += 1
                    except Exception as e:
                        logger.info(f"Failed to clear semgrep cache {repo_dir.name}: {e}")
        if semgrep_cleared > 0:
            logger.info(f"Cleared semgrep: {semgrep_cleared} repo cache(s)")
        else:
            logger.info("semgrep: already empty")
    
    logger.info("Cache cleared successfully")

def admin_cache_warm():
    """Pre-warm caches by creating tool venvs and downloading data"""
    from pathlib import Path
    import os
    
    print("=" * 60)
    logger.info("REACHABLE CACHE WARM-UP")
    print("=" * 60)
    print()
    
    # Show CI/CD cache tip
    cache_dir = os.environ.get('REACHABLE_CACHE_DIR')
    if cache_dir:
        logger.info(f"✅ REACHABLE_CACHE_DIR set: {cache_dir}")
    else:
        cache_dir = Path.home() / '.reachable-cache'
        logger.info(f"💡 Tip: Set REACHABLE_CACHE_DIR for CI/CD caching")
        logger.info(f"   export REACHABLE_CACHE_DIR=/path/to/ci-cache")
    print()
    
    # 1. GuardDog venv
    logger.info("📦 1/3: GuardDog venv...")
    try:
        from reachable.guarddog_scanner import GuardDogScanner
        scanner = GuardDogScanner()
        if scanner.is_available():
            logger.info("   ✅ GuardDog venv ready")
        else:
            logger.info("   ❌ GuardDog setup failed")
    except Exception as e:
        logger.info(f"   ⚠️  GuardDog check failed: {e}")
    
    # 2. Semgrep (uses system install, but check availability)
    logger.info("📦 2/3: Semgrep...")
    try:
        import subprocess
        result = subprocess.run(['semgrep', '--version'], capture_output=True, timeout=5)
        if result.returncode == 0:
            version = result.stdout.decode().strip()
            logger.info(f"   ✅ Semgrep available: {version}")
        else:
            logger.info("   ⚠️  Semgrep not installed (pip install semgrep)")
    except FileNotFoundError:
        logger.info("   ⚠️  Semgrep not installed (pip install semgrep)")
    except Exception as e:
        logger.info(f"   ⚠️  Semgrep check failed: {e}")
    
    # 3. Grype/Syft (external tools)
    logger.info("📦 3/3: Grype & Syft...")
    tools_ok = True
    for tool in ['grype', 'syft']:
        try:
            import subprocess
            result = subprocess.run([tool, 'version'], capture_output=True, timeout=5)
            if result.returncode == 0:
                logger.info(f"   ✅ {tool} available")
            else:
                logger.info(f"   ⚠️  {tool} not working properly")
                tools_ok = False
        except FileNotFoundError:
            logger.info(f"   ❌ {tool} not installed")
            tools_ok = False
        except Exception as e:
            logger.info(f"   ⚠️  {tool} check failed: {e}")
            tools_ok = False
    
    print()
    print("=" * 60)
    
    # CI/CD cache instructions
    cache_base = Path(cache_dir) if cache_dir else Path.home() / '.reachable-cache'
    logger.info("📋 CI/CD Cache Configuration:")
    print()
    logger.info("   GitHub Actions:")
    logger.info("   ```yaml")
    logger.info("   - uses: actions/cache@v3")
    logger.info("     with:")
    logger.info("       path: ~/.reachable-cache")
    logger.info("       key: reachable-cache-${{ runner.os }}-v1")
    logger.info("   ```")
    print()
    logger.info("   GitLab CI:")
    logger.info("   ```yaml")
    logger.info("   cache:")
    logger.info("     paths:")
    logger.info("       - ~/.reachable-cache/")
    logger.info("     key: reachable-${CI_COMMIT_REF_SLUG}")
    logger.info("   ```")
    print()
    logger.info(f"   Cache location: {cache_base}")
    print()
    if cache_base.exists():
        size = sum(f.stat().st_size for f in cache_base.rglob('*') if f.is_file())
        logger.info(f"   Current size: {format_size(size)}")
    print("=" * 60)

def admin_test(args):
    """Run test suite"""
    import subprocess
    from pathlib import Path
    
    print("=" * 60)
    logger.info("REACHABLE TEST SUITE")
    print("=" * 60)
    
    test_dir = Path(__file__).parent.parent / 'tests'
    if not test_dir.exists():
        test_dir = Path(__file__).parent / 'tests'
    
    if not test_dir.exists():
        logger.info("Test directory not found")
        logger.info("Tests are only available in the development distribution")
        sys.exit(1)
    
    cmd = ['python', '-m', 'pytest', str(test_dir)]
    
    if args.verbose:
        cmd.append('-v')
    if args.quick:
        cmd.extend(['-m', 'not slow and not network'])
    if args.coverage:
        cmd.extend(['--cov=reachable', '--cov-report=html', '--cov-report=term'])
    if args.filter:
        cmd.extend(['-k', args.filter])
    
    logger.info(f"Command: {' '.join(cmd)}")
    print("-" * 60)
    
    try:
        result = subprocess.run(cmd, cwd=Path(__file__).parent.parent)
        sys.exit(result.returncode)
    except FileNotFoundError:
        logger.info("pytest not installed. Install with: pip install pytest pytest-cov")
        sys.exit(1)

def admin_version():
    """Show detailed version information"""
    from pathlib import Path
    import platform
    
    print("=" * 60)
    logger.info("REACHABLE VERSION INFO")
    print("=" * 60)
    print()
    logger.info(f"REACHABLE Version:  {__version__}")
    logger.info(f"Build Type:         {'Development' if _is_dev_build() else 'Customer Release'}")
    print()
    logger.info("System:")
    logger.info(f"  Python:           {platform.python_version()}")
    logger.info(f"  Platform:         {platform.system()} {platform.release()}")
    logger.info(f"  Architecture:     {platform.machine()}")
    
    import shutil
    print()
    logger.info("External Tools:")
    for tool in ['syft', 'grype', 'semgrep', 'guarddog', 'trufflehog']:
        path = shutil.which(tool)
        status = path if path else "not found"
        logger.info(f"  {tool:12} {status}")

def admin_db(args):
    """Manage scan databases and storage (v4.5.40)
    
    Commands:
        --status      Show database status (default): sizes, WAL, bloat ratio
        --compact     Compact databases: checkpoint WAL + VACUUM INTO if needed
        --checkpoint  Checkpoint WAL only (fast, no vacuum)
        --check       Check database integrity
        --repair      Attempt to repair corrupted database
        --trim        Trim old scans (30 days / 20 per branch)
        --optimize    [DEPRECATED] Use --compact instead
    
    Options:
        --repo NAME   Target specific repository (fuzzy match)
        --force       Force vacuum even if low bloat
        --dry-run     Preview without making changes
        --verbose     Show detailed information
    """
    from pathlib import Path
    from .database_compaction import (
        DatabaseCompactor,
        get_all_database_stats,
        compact_all_databases,
        check_all_databases,
        format_size
    )
    from .storage_cleanup import trim_storage
    
    reachable_home = Path.home() / '.reachable'
    scans_dir = reachable_home / 'scans'
    
    verbose = getattr(args, 'verbose', False)
    dry_run = getattr(args, 'dry_run', False)
    force = getattr(args, 'force', False)
    repo_filter = getattr(args, 'repo', None)
    
    # Default to --status if no option specified
    options = ['status', 'compact', 'checkpoint', 'check', 'repair', 'trim', 'optimize']
    if not any([getattr(args, opt, False) for opt in options]):
        args.status = True
    
    # Helper to filter repos
    def get_target_repos():
        if not scans_dir.exists():
            return []
        repos = list(scans_dir.glob('*/repo.db'))
        if repo_filter:
            repos = [r for r in repos if repo_filter.lower() in r.parent.name.lower()]
        return sorted(repos)
    
    # =========================================================================
    # --status: Show database statistics
    # =========================================================================
    if getattr(args, 'status', False):
        print("=" * 60)
        logger.info("REACHABLE DATABASE STATUS")
        print("=" * 60)
        print()
        
        stats = get_all_database_stats(reachable_home)
        
        if not stats['databases']:
            logger.info("No databases found.")
            return
        
        logger.info(f"Total DB size:  {stats['total_db_size_human']}")
        logger.info(f"Total WAL size: {stats['total_wal_size_human']}")
        logger.info(f"Total:          {stats['total_size_human']}")
        print()
        
        # Filter if requested
        databases = stats['databases']
        if repo_filter:
            databases = [d for d in databases if repo_filter.lower() in d['repo'].lower()]
        
        logger.info(f"{'Repository':<40} {'DB':>10} {'WAL':>10} {'Bloat':>8} {'Status':<12}")
        print("-" * 84)
        
        for db in databases:
            # Determine status
            status_parts = []
            if db.get('needs_checkpoint'):
                status_parts.append('wal!')
            if db.get('needs_vacuum'):
                status_parts.append('bloat!')
            status = ', '.join(status_parts) if status_parts else 'healthy'
            
            indicator = '⚠️ ' if status_parts else '   '
            repo_name = db['repo'][:38]
            
            logger.info(f"{indicator}{repo_name:<37} {db['db_size_human']:>10} {db['wal_size_human']:>10} {db['bloat_percent']:>8} {status:<12}")
        
        # Show scan counts if verbose
        if verbose:
            print()
            logger.info("Scan details:")
            print("-" * 60)
            
            import sqlite3
            for db in databases:
                repo_db = scans_dir / db['repo'] / 'repo.db'
                try:
                    conn = sqlite3.connect(str(repo_db))
                    cursor = conn.cursor()
                    cursor.execute("SELECT COUNT(*) FROM scans WHERE status = 'complete'")
                    scan_count = cursor.fetchone()[0]
                    cursor.execute("SELECT MAX(timestamp) FROM scans")
                    last_scan = cursor.fetchone()[0] or 'never'
                    conn.close()
                    
                    logger.info(f"  {db['repo']}: {scan_count} scans, last: {last_scan[:16] if last_scan != 'never' else 'never'}")
                except Exception as e:
                    logger.info(f"  {db['repo']}: ERROR - {e}")
        
        print()
        
        # Show recommendations
        needs_attention = [d for d in databases if d.get('needs_checkpoint') or d.get('needs_vacuum')]
        if needs_attention:
            logger.info(f"💡 {len(needs_attention)} database(s) need attention. Run: reachctl db --compact")
    
    # =========================================================================
    # --compact: Checkpoint WAL + VACUUM INTO if needed
    # =========================================================================
    elif getattr(args, 'compact', False):
        target_repos = get_target_repos()
        
        if not target_repos:
            logger.info("No databases found.")
            return
        
        if repo_filter:
            # Compact specific repo(s)
            logger.info(f"\n{'[DRY RUN] ' if dry_run else ''}Compacting {len(target_repos)} database(s)...")
            print("=" * 60)
            
            for repo_db in target_repos:
                repo_name = repo_db.parent.name
                compactor = DatabaseCompactor(repo_db)
                stats = compactor.get_stats()
                
                logger.info(f"\n  {repo_name}:")
                logger.info(f"    DB: {stats['db_size_human']}, WAL: {stats['wal_size_human']}, Bloat: {stats['bloat_percent']}")
                
                if dry_run:
                    if stats['needs_checkpoint'] or stats['needs_vacuum'] or force:
                        logger.info(f"    → Would compact")
                    else:
                        logger.info(f"    → Would skip (healthy)")
                else:
                    result = compactor.compact(force=force)
                    if result['error']:
                        logger.info(f"    → Error: {result['error']}")
                    else:
                        actions = []
                        if result['checkpointed']:
                            actions.append('checkpointed')
                        if result['vacuumed']:
                            actions.append(f"vacuumed ({format_size(result['bytes_freed'])} freed)")
                        elif result['method'] and 'skipped' in result['method']:
                            actions.append(result['method'])
                        logger.info(f"    → {', '.join(actions) or 'no action needed'}")
        else:
            # Compact all
            compact_all_databases(
                reachable_home=reachable_home,
                force=force,
                dry_run=dry_run,
                verbose=True
            )
    
    # =========================================================================
    # --checkpoint: Just checkpoint WAL (fast)
    # =========================================================================
    elif getattr(args, 'checkpoint', False):
        target_repos = get_target_repos()
        
        if not target_repos:
            logger.info("No databases found.")
            return
        
        logger.info(f"\n{'[DRY RUN] ' if dry_run else ''}Checkpointing WAL...")
        print("=" * 60)
        
        total_wal = 0
        for repo_db in target_repos:
            repo_name = repo_db.parent.name
            compactor = DatabaseCompactor(repo_db)
            stats = compactor.get_stats()
            
            if stats['wal_size'] == 0:
                if verbose:
                    logger.info(f"  {repo_name}: no WAL")
                continue
            
            total_wal += stats['wal_size']
            
            if dry_run:
                logger.info(f"  {repo_name}: would checkpoint {stats['wal_size_human']}")
            else:
                try:
                    pages, remaining, blocked = compactor.checkpoint('TRUNCATE')
                    status = "blocked" if blocked else f"done ({pages} pages)"
                    logger.info(f"  {repo_name}: {status}")
                except Exception as e:
                    logger.info(f"  {repo_name}: ERROR - {e}")
        
        print()
        logger.info(f"Total WAL {'to checkpoint' if dry_run else 'checkpointed'}: {format_size(total_wal)}")
    
    # =========================================================================
    # --check: Integrity check
    # =========================================================================
    elif getattr(args, 'check', False):
        if repo_filter:
            target_repos = get_target_repos()
            if not target_repos:
                logger.info(f"No database found matching '{repo_filter}'")
                return
            
            logger.info(f"\nDatabase Integrity Check")
            print("=" * 60)
            
            for repo_db in target_repos:
                repo_name = repo_db.parent.name
                compactor = DatabaseCompactor(repo_db)
                is_ok, message = compactor.integrity_check()
                
                if is_ok:
                    logger.info(f"  ✅ {repo_name}: OK")
                else:
                    logger.info(f"  ❌ {repo_name}: {message}")
        else:
            check_all_databases(reachable_home, verbose=True)
    
    # =========================================================================
    # --repair: Attempt to repair corrupted database
    # =========================================================================
    elif getattr(args, 'repair', False):
        target_repos = get_target_repos()
        
        if not target_repos:
            if repo_filter:
                logger.info(f"No database found matching '{repo_filter}'")
            else:
                logger.info("No databases found. Use --repo to specify which to repair.")
            return
        
        if len(target_repos) > 1 and not repo_filter:
            logger.info("Multiple databases found. Use --repo to specify which to repair:")
            for repo_db in target_repos:
                logger.info(f"  {repo_db.parent.name}")
            return
        
        repo_db = target_repos[0]
        repo_name = repo_db.parent.name
        
        logger.info(f"\nRepairing {repo_name}...")
        print("=" * 60)
        
        if dry_run:
            logger.info("[DRY RUN] Would attempt repair")
            return
        
        compactor = DatabaseCompactor(repo_db)
        
        # Check current state
        is_ok, message = compactor.integrity_check()
        if is_ok:
            logger.info(f"  ℹ️  Database is healthy, no repair needed.")
            return
        
        logger.info(f"  Current state: {message}")
        logger.info(f"  Attempting repair...")
        
        success, repair_message = compactor.repair()
        
        if success:
            logger.info(f"  ✅ {repair_message}")
        else:
            logger.info(f"  ❌ {repair_message}")
    
    # =========================================================================
    # --trim: Trim old scans
    # =========================================================================
    elif getattr(args, 'trim', False):
        result = trim_storage(
            reachable_home=reachable_home,
            retention_days=30,
            min_scans_keep=5,
            dry_run=dry_run,
            verbose=True
        )
        
        # Also compact after trim
        if not dry_run and result.get('scans_deleted', 0) > 0:
            print()
            logger.info("Compacting databases after trim...")
            compact_all_databases(reachable_home=reachable_home, verbose=verbose)
    
    # =========================================================================
    # --optimize: [DEPRECATED] Use --compact
    # =========================================================================
    elif getattr(args, 'optimize', False):
        logger.info("⚠️  --optimize is deprecated. Use --compact instead.")
        print()
        # Run compact for backwards compatibility
        compact_all_databases(
            reachable_home=reachable_home,
            force=force,
            dry_run=dry_run,
            verbose=True
        )

def admin_doctor(args=None):
    """Check system health and dependencies, auto-fix missing tools by default.
    
    Uses the centralized preflight_check() function.
    """
    from .preflight import preflight_check
    
    # Auto-fix by default (use --no-fix to just check)
    fix_mode = not getattr(args, 'no_fix', False) if args else True
    
    print("=" * 60)
    logger.info("REACHABLE SYSTEM CHECK")
    print("=" * 60)
    print()
    
    # Run preflight check (handles everything)
    result = preflight_check(fix=fix_mode, quiet=False, verbose=True)
    
    print()
    if not result.ok:
        logger.info(f"❌ {len(result.issues)} issue(s) found:")
        for issue in result.issues:
            logger.info(f"  - {issue}")

        sys.exit(1)
    elif result.has_warnings:
        logger.info("✅ All required tools present (with warnings)")
        logger.info("   Warnings will auto-resolve on first scan.")
    else:
        logger.info("✅ All checks passed - system ready")
    
    # Check for optional TruffleHog (active secret verification)
    trufflehog_installed = shutil.which('trufflehog') is not None
    print()
    logger.info("OPTIONAL ENHANCEMENTS:")
    if trufflehog_installed:
        logger.info("  ✅ trufflehog - Active secret verification available")
        logger.info("     Note: For full Git history scanning, use: git fetch --unshallow")
    else:
        logger.info("  💡 trufflehog - For active secret verification (validates credentials against APIs)")
        logger.info("                  and scanning Git history for deleted/rotated secrets")
        logger.info("     Install: brew install trufflehog  # or: pip install trufflehog")
        logger.info("     Note: For full Git history scanning, use: git fetch --unshallow")

def sandbox_command(args):
    """
    Manage dynamic malware sandbox.
    
    Platform-specific:
    - macOS: Colima (brew install/uninstall)
    - Linux: Firecracker (not yet implemented)
    """
    import platform
    
    system = platform.system().lower()
    
    print("=" * 60)
    logger.info("REACHABLE DYNAMIC MALWARE SANDBOX")
    print("=" * 60)
    print()
    logger.info(f"Platform: {platform.system()} ({platform.machine()})")
    print()
    
    # Default to --status if no option specified
    if getattr(args, 'init', False):
        _sandbox_init(system)
    elif getattr(args, 'remove', False):
        _sandbox_remove(system)
    else:
        # Default behavior: show status
        _sandbox_status(system)


def _sandbox_status(system: str):
    """Check sandbox installation status"""
    
    if system == 'darwin':
        logger.info("Checking Colima status...")
        print()
        
        colima_status = _check_colima_status()
        
        if colima_status == 'not_installed':
            logger.info("  Colima:        ❌ NOT INSTALLED")
            print("  Docker CLI:    " + _check_docker_cli_status())
            print()
            logger.info("  Dynamic malware sandbox is NOT available.")
            logger.info("  Run: reachctl sandbox --init")
            sys.exit(1)
        elif colima_status == 'stopped':
            logger.info("  Colima:        ⚠️  INSTALLED but stopped")
            print("  Docker CLI:    " + _check_docker_cli_status())
            print()
            logger.info("  Sandbox installed but not running.")
            logger.info("  It will auto-start during scans, or run: colima start")
        else:
            logger.info("  Colima:        ✅ RUNNING")
            print("  Docker CLI:    " + _check_docker_cli_status())
            
            # Check sandbox image
            image_status = _check_sandbox_image_status()
            logger.info(f"  Sandbox Image: {image_status}")
            print()
            logger.info("  Dynamic malware sandbox is READY.")
    
    elif system == 'linux':
        logger.info("  Firecracker:   ⚠️  NOT YET IMPLEMENTED")
        print()
        logger.info("  Linux sandbox (Firecracker) planned for v4.7.x")
        logger.info("  Static malware analysis (GuardDog) is always available.")
    
    else:
        logger.info(f"  Platform {system} not supported for dynamic sandbox.")
        logger.info("  Static malware analysis (GuardDog) is always available.")
        sys.exit(1)


def _sandbox_init(system: str):
    """Install sandbox components"""
    
    if system == 'darwin':
        logger.info("Installing Colima for macOS...")
        print()
        
        # Check if already installed
        colima_status = _check_colima_status()
        if colima_status != 'not_installed':
            logger.info("  ✅ Colima is already installed")
            if colima_status == 'stopped':
                logger.info("  🔄 Starting Colima...")
                if _start_colima():
                    logger.info("  ✅ Colima started")
                else:
                    logger.info("  ❌ Failed to start Colima")
                    sys.exit(1)
            if _ensure_sandbox_image():
                print()
                logger.info("  Sandbox is ready!")
            else:
                print()
                logger.info("  ⚠️  Sandbox image not ready - will build on first scan")
            return
        
        # Check for brew
        if not shutil.which('brew'):
            logger.info("  ❌ Homebrew not found")
            print()
            logger.info("  Please install Homebrew first:")
            print("    /bin/bash -c \"$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)\"")
            print()
            logger.info("  Or install Colima manually:")
            logger.info("    https://github.com/abiosoft/colima/releases")
            sys.exit(1)
        
        # Install colima and docker CLI via brew
        logger.info("  📦 Installing colima and docker via Homebrew...")
        logger.info("     (this may take a few minutes)")
        print()
        
        try:
            result = subprocess.run(
                ['brew', 'install', 'colima', 'docker'],
                timeout=600,  # 10 minute timeout
                capture_output=False  # Show output to user
            )
            if result.returncode != 0:
                print()
                logger.info("  ❌ Installation failed")
                sys.exit(1)
        except subprocess.TimeoutExpired:
            logger.info("  ❌ Installation timed out")
            sys.exit(1)
        except Exception as e:
            logger.info(f"  ❌ Installation error: {e}")
            sys.exit(1)
        
        print()
        logger.info("  ✅ Colima and Docker CLI installed")
        
        # Start Colima
        logger.info("  🔄 Starting Colima VM...")
        logger.info("     (first start downloads VM image, may take 2-3 minutes)")
        if _start_colima():
            logger.info("  ✅ Colima started")
        else:
            logger.info("  ❌ Failed to start Colima")
            logger.info("  Try manually: colima start --cpu 2 --memory 4")
            sys.exit(1)
        
        # Build sandbox image
        _ensure_sandbox_image()
        
        print()
        print("=" * 60)
        logger.info("✅ SANDBOX INSTALLATION COMPLETE")
        print("=" * 60)
        print()
        logger.info("Dynamic malware detection is now enabled.")
        logger.info("Run 'reachctl scan /path/to/repo' to use it.")
    
    elif system == 'linux':
        logger.info("  ⚠️  Linux sandbox (Firecracker) not yet implemented")
        print()
        logger.info("  Planned for v4.7.x")
        logger.info("  Static malware analysis (GuardDog) is always available.")
        sys.exit(0)
    
    else:
        logger.info(f"  ❌ Platform {system} not supported")
        sys.exit(1)


def _sandbox_remove(system: str):
    """Remove sandbox components"""
    
    if system == 'darwin':
        logger.info("Removing Colima sandbox...")
        print()
        
        # Check if installed
        colima_status = _check_colima_status()
        if colima_status == 'not_installed':
            logger.info("  ℹ️  Colima is not installed")
            return
        
        # Stop Colima if running
        if colima_status == 'running':
            logger.info("  🔄 Stopping Colima...")
            try:
                subprocess.run(['colima', 'stop'], timeout=60, capture_output=True)
                logger.info("  ✅ Colima stopped")
            except Exception as e:
                logger.info(f"  ⚠️  Failed to stop Colima: {e}")
        
        # Delete Colima VM
        logger.info("  🗑️  Deleting Colima VM...")
        try:
            subprocess.run(['colima', 'delete', '-f'], timeout=60, capture_output=True)
            logger.info("  ✅ Colima VM deleted")
        except Exception as e:
            logger.info(f"  ⚠️  Failed to delete VM: {e}")
        
        # Check for brew
        if not shutil.which('brew'):
            print()
            logger.info("  ⚠️  Homebrew not found - cannot uninstall packages")
            logger.info("  Colima VM deleted, but binaries remain.")
            logger.info("  Remove manually if needed.")
            return
        
        # Uninstall via brew
        logger.info("  📦 Uninstalling colima via Homebrew...")
        try:
            result = subprocess.run(
                ['brew', 'uninstall', 'colima'],
                timeout=120,
                capture_output=True,
                text=True
            )
            if result.returncode == 0:
                logger.info("  ✅ Colima uninstalled")
            else:
                logger.info(f"  ⚠️  Uninstall warning: {result.stderr[:100]}")
        except Exception as e:
            logger.info(f"  ⚠️  Uninstall error: {e}")
        
        # Ask about docker CLI
        print()
        logger.info("  ℹ️  Docker CLI was NOT removed (may be used by other tools)")
        logger.info("  To remove: brew uninstall docker")
        
        print()
        print("=" * 60)
        logger.info("✅ SANDBOX REMOVED")
        print("=" * 60)
        print()
        logger.info("Dynamic malware detection is now disabled.")
        logger.info("Static malware analysis (GuardDog) still works.")
    
    elif system == 'linux':
        logger.info("  ℹ️  Linux sandbox (Firecracker) not yet implemented")
        logger.info("  Nothing to remove.")
    
    else:
        logger.info(f"  ℹ️  Platform {system} has no sandbox to remove")


def _check_docker_cli_status() -> str:
    """Check if docker CLI is installed"""
    if shutil.which('docker'):
        try:
            result = subprocess.run(
                ['docker', '--version'],
                capture_output=True, text=True, timeout=5
            )
            if result.returncode == 0:
                version = result.stdout.strip().split()[2].rstrip(',')
                return f"✅ installed (v{version})"
        except:
            pass
        return "✅ installed"
    return "❌ not installed"


def _check_sandbox_image_status() -> str:
    """Check if sandbox Docker image exists and is up-to-date"""
    import hashlib
    
    try:
        import docker
    except ImportError:
        return "❓ unknown (docker SDK not installed)"
    
    client = _get_docker_client()
    if not client:
        return "❓ unknown (Docker not connected)"
    
    # Compute current hash
    sandbox_dir = Path(__file__).parent.parent / "sandbox"
    dockerfile = sandbox_dir / "Dockerfile"
    if not dockerfile.exists():
        sandbox_dir = Path(__file__).parent / "sandbox"
        dockerfile = sandbox_dir / "Dockerfile"
    
    if dockerfile.exists():
        hasher = hashlib.sha256()
        hasher.update(dockerfile.read_bytes())
        runner_py = sandbox_dir / "runner.py"
        if runner_py.exists():
            hasher.update(runner_py.read_bytes())
        current_hash = hasher.hexdigest()[:12]
    else:
        current_hash = None
    
    # Check image
    try:
        image = client.images.get("reachable/sandbox:latest")
        cached_hash = image.labels.get('reachable.sandbox.hash', '')
        
        if current_hash and cached_hash == current_hash:
            return f"✅ ready (cached, hash: {cached_hash})"
        elif cached_hash:
            return f"⚠️  outdated (will rebuild on next scan)"
        else:
            return "✅ ready (no hash - legacy build)"
    except docker.errors.ImageNotFound:
        return "⚠️  not built (will build on first scan)"
    except Exception as e:
        return f"❓ unknown ({e})"


# =============================================================================
# v4.5.51: Bug Fixes - Call Path and Risk Level Population
# =============================================================================

def _calculate_risk_level(severity: str, reachability: str, is_exploited: bool = False, epss_score: float = 0.0) -> str:
    """
    Calculate risk level based on severity, reachability, and threat intelligence.
    
    Risk Levels and SLA Mapping:
    - CRITICAL: 24 hours  (Actively exploited OR Critical+Reachable)
    - HIGH: 7 days        (High+Reachable OR Critical+Unknown)
    - MEDIUM: 30 days     (Medium+Reachable OR High+Unknown)
    - LOW: 90 days        (Low severity OR unreachable)
    - INFO: Best effort   (Informational findings)
    """
    severity = (severity or 'MEDIUM').upper()
    reachability = (reachability or 'UNKNOWN').upper()
    
    # Map non-standard severities
    severity_map = {'ERROR': 'HIGH', 'WARNING': 'MEDIUM'}
    severity = severity_map.get(severity, severity)
    
    # Actively exploited = always CRITICAL
    if is_exploited:
        return 'CRITICAL'
    
    # High EPSS score (>0.5) increases risk
    epss_boost = epss_score > 0.5
    
    # Risk matrix
    if severity == 'CRITICAL':
        if reachability == 'REACHABLE':
            return 'CRITICAL'
        elif reachability == 'UNKNOWN':
            return 'HIGH'
        else:
            return 'MEDIUM'
    elif severity == 'HIGH':
        if reachability == 'REACHABLE':
            return 'CRITICAL' if epss_boost else 'HIGH'
        elif reachability == 'UNKNOWN':
            return 'HIGH' if epss_boost else 'MEDIUM'
        else:
            return 'LOW'
    elif severity == 'MEDIUM':
        if reachability == 'REACHABLE':
            return 'HIGH' if epss_boost else 'MEDIUM'
        elif reachability == 'UNKNOWN':
            return 'MEDIUM' if epss_boost else 'LOW'
        else:
            return 'LOW'
    elif severity in ('LOW', 'INFO'):
        return 'LOW' if reachability == 'REACHABLE' else 'INFO'
    return 'LOW'


def _extract_call_path(finding_data: dict) -> list:
    """
    Extract call path from various finding formats.
    
    Handles: reachable_via, call_path, reachability_path, call_stacks (govulncheck)
    """
    for key in ['call_path', 'reachable_via', 'reachability_path']:
        path = finding_data.get(key, [])
        if path and isinstance(path, list) and len(path) > 0:
            return path
    
    # Govulncheck format
    call_stacks = finding_data.get('call_stacks', [])
    if call_stacks and len(call_stacks) > 0:
        frames = call_stacks[0].get('frames', []) if isinstance(call_stacks[0], dict) else []
        if frames:
            return [f.get('function', f.get('name', '')) for f in frames if f.get('function') or f.get('name')]
    
    return []


def store_scan_to_database(output_dir: Path, use_legacy_raw: bool = False, repo_path: Path = None,
                           risk_score: int = 0, risk_level: str = None, ai_findings: list = None,
                           dlp_findings: list = None) -> None:
    """
    Store scan findings to per-repo database (repo.db)
    
    Architecture:
        ~/.reachable/scans/{repo-hash}/repo.db  <- ONE db per repo
        
    Args:
        output_dir: Scan session directory (for reading JSON files)
        use_legacy_raw: If True, also create raw/ files for compatibility
        repo_path: Repository root path (required for repo.db location)
        ai_findings: AI security findings to store (passed directly, not from JSON)
        dlp_findings: DLP/PII security findings to store
    """
    import json
    import gzip
    from pathlib import Path
    from .database_storage import RepoDatabase, get_repo_db_path
    
    raw_dir = output_dir / 'raw'
    created_items = []
    
    # Determine repo.db path
    if repo_path is None:
        # Fallback: try to get from scan-plan.json
        scan_plan_file = output_dir / 'scan-plan.json'
        if scan_plan_file.exists():
            with open(scan_plan_file) as f:
                plan = json.load(f)
                repo_path = Path(plan.get('repo_path', '/tmp/unknown'))
        else:
            repo_path = Path('/tmp/unknown')
    
    repo_db_path = get_repo_db_path(repo_path)
    db_exists = repo_db_path.exists()
    
  
    if use_legacy_raw and not raw_dir.exists():
        raw_dir.mkdir(exist_ok=True)
        created_items.append("✓ Created raw/ directory (legacy mode)")
    
    # Initialize RepoDatabase and start scan
    try:
        from . import __version__
        
        # Get branch and commit from scan-plan or git
        branch = 'unknown'
        commit_hash = None
        scan_plan_file = output_dir / 'scan-plan.json'
        if scan_plan_file.exists():
            with open(scan_plan_file) as f:
                plan = json.load(f)
                # Try to get branch from output_dir path structure
                # Path: ~/.reachable/scans/{repo-hash}/{branch}/{timestamp}/
                parts = output_dir.parts
                if len(parts) >= 2:
                    branch = parts[-2]  # Second to last is branch
        
        # Initialize repo database (creates schema if needed)
        db = RepoDatabase(repo_db_path)
        
        # Start a new scan record
        scan_id = db.start_scan(
            branch=branch,
            commit_hash=commit_hash,
            scan_dir=str(output_dir),
            version=__version__
        )
        
        # Collect findings from JSON files
        cve_findings = []
        secret_findings = []
        cwe_findings = []
        config_findings = []  # v4.5.18: Separate config findings
        
        # v4.5.18 BUG FIX: Import CVEs from reachable-report.json (has reachability data)
        # NOT from vulns.json (raw grype output without reachability)
        report_file = output_dir / 'reachable-report.json.gz'
        if not report_file.exists():
            report_file = output_dir / 'reachable-report.json'
        
        seen_cve_ids = set()  # Deduplicate CVEs
        
        if report_file.exists():
            try:
                if str(report_file).endswith('.gz'):
                    with gzip.open(report_file, 'rt') as f:
                        report_data = json.load(f)
                else:
                    with open(report_file) as f:
                        report_data = json.load(f)
                
                # Process REACHABLE CVEs
                for cve_id, cve_data in report_data.get('reachable', {}).items():
                    if cve_id in seen_cve_ids:
                        continue
                    seen_cve_ids.add(cve_id)
                    
                    # Check if reachability is actually unknown
                    if cve_data.get('reachability_unknown', False):
                        app_reach = 'UNKNOWN'
                    else:
                        app_reach = 'REACHABLE'
                    
                    # v4.5.51: Extract call path and calculate risk level
                    call_path = _extract_call_path(cve_data)
                    risk_level = _calculate_risk_level(
                        cve_data.get('severity', 'MEDIUM'), app_reach,
                        cve_data.get('is_exploited', cve_data.get('in_kev', False)),
                        cve_data.get('epss_score', cve_data.get('epss', 0.0))
                    )
                    
                    cve_findings.append({
                        'id': cve_id,
                        'cve_id': cve_data.get('cve_id'),
                        'ghsa_id': cve_data.get('ghsa_id'),
                        'display_id': cve_data.get('display_id'),
                        'severity': cve_data.get('severity', 'MEDIUM'),
                        'risk_level': risk_level,
                        'title': cve_id,
                        'description': (cve_data.get('description', '') or '')[:500],
                        'package': cve_data.get('package', ''),
                        'version': cve_data.get('version', ''),
                        'app_reachability': app_reach,
                        'reachability_path': call_path,
                        'cvss_score': cve_data.get('cvss_score', 0.0) or 0.0,
                        'fix_status': 'fix_available' if cve_data.get('is_fixable') else 'no_fix',
                        'fix_version': ','.join(cve_data.get('fix_versions', [])) or None,
                        'remediation': cve_data.get('remediation'),  # P2.21
                        'urls': cve_data.get('urls', []),  # P2.21
                        'dataSource': cve_data.get('dataSource'),  # P2.21
                        'exploitability': cve_data.get('exploitability'),  # P2.21
                        'compliance_mapping': cve_data.get('compliance_mapping'),  # P2.21
                        'is_transitive': cve_data.get('is_transitive', False),  # P2.21
                        'scanner': 'grype'
                    })
                
                # Process UNREACHABLE CVEs
                for cve_id, cve_data in report_data.get('unreachable', {}).items():
                    if cve_id in seen_cve_ids:
                        continue
                    seen_cve_ids.add(cve_id)
                    
                    # Check if reachability is actually unknown
                    if cve_data.get('reachability_unknown', False):
                        app_reach = 'UNKNOWN'
                    else:
                        app_reach = 'NOT_REACHABLE'
                    
                    # v4.5.51: Extract call path and calculate risk level
                    call_path = _extract_call_path(cve_data)
                    risk_level = _calculate_risk_level(
                        cve_data.get('severity', 'MEDIUM'), app_reach,
                        cve_data.get('is_exploited', cve_data.get('in_kev', False)),
                        cve_data.get('epss_score', cve_data.get('epss', 0.0))
                    )
                    
                    cve_findings.append({
                        'id': cve_id,
                        'cve_id': cve_data.get('cve_id'),
                        'ghsa_id': cve_data.get('ghsa_id'),
                        'display_id': cve_data.get('display_id'),
                        'severity': cve_data.get('severity', 'MEDIUM'),
                        'risk_level': risk_level,
                        'title': cve_id,
                        'description': (cve_data.get('description', '') or '')[:500],
                        'package': cve_data.get('package', ''),
                        'version': cve_data.get('version', ''),
                        'app_reachability': app_reach,
                        'reachability_path': call_path,
                        'cvss_score': cve_data.get('cvss_score', 0.0) or 0.0,
                        'fix_status': 'fix_available' if cve_data.get('is_fixable') else 'no_fix',
                        'fix_version': ','.join(cve_data.get('fix_versions', [])) or None,
                        'remediation': cve_data.get('remediation'),  # P2.21
                        'urls': cve_data.get('urls', []),  # P2.21
                        'dataSource': cve_data.get('dataSource'),  # P2.21
                        'exploitability': cve_data.get('exploitability'),  # P2.21
                        'compliance_mapping': cve_data.get('compliance_mapping'),  # P2.21
                        'is_transitive': cve_data.get('is_transitive', False),  # P2.21
                        'scanner': 'grype'
                    })
                    
            except Exception as e:
                logger.error(f"Exception loading report: {e}")
                import traceback
                traceback.print_exc()
                created_items.append(f"⚠️  Error loading report: {e}")
        
        # Fallback to vulns.json if report doesn't exist (shouldn't happen normally)
        # REMOVED FALLBACK - must have report data
        if not cve_findings:
            logger.error("No CVE findings from report! Report may be corrupted.")
            return
        
        # Store CVE findings
        if cve_findings:
            # DEBUG: Show first CVE dict before storage
            logger.info(f"\n{'='*60}")
            logger.debug(f"About to store {len(cve_findings)} CVEs to database")
            logger.debug(f"First CVE dict:")
            first_cve = cve_findings[0]
            for key in ['id', 'cve_id', 'ghsa_id', 'display_id']:
                logger.info(f"  {key}: {first_cve.get(key)}")
            logger.info(f"  All keys: {list(first_cve.keys())}")
            logger.info(f"{'='*60}\n")
            
            db.store_findings(cve_findings, 'cve')
            # P2.21 VALIDATION: Ensure critical fields are present
            for cve in cve_findings[:3]:  # Check first 3
                if 'ghsa_id' not in cve and 'cve_id' not in cve:
                    raise ValueError(f"BUG: CVE record missing both cve_id and ghsa_id fields! Record: {cve.get('id')}")
                if 'display_id' not in cve:
                    raise ValueError(f"BUG: CVE record missing display_id field! Record: {cve.get('id')}")
            
            db.store_findings(cve_findings, 'cve')
            
            # P2.21 VALIDATION: Verify data was actually stored correctly
            cursor = db.conn.cursor()
            cursor.execute("""
                SELECT ghsa_id, display_id 
                FROM findings 
                WHERE scan_id=? AND finding_type='cve' 
                LIMIT 1
            """, (db._current_scan_id,))
            row = cursor.fetchone()
            if row and row[0] is None and row[1] is None:
                raise ValueError("BUG: CVE fields were NULL in database after insertion! Database schema issue or store_findings bug!")
        
        # Import security findings (secrets, CWEs, config)
        # v4.5.18 BUG FIX: Read from reachable-report.json (analyzed data)
        # and properly classify findings by type with correct reachability
        
        # Helper to determine if file is config (not code)
        CONFIG_EXTENSIONS = ('.yaml', '.yml', '.json', '.tf', '.hcl', '.toml', '.ini', '.cfg', '.conf')
        CONFIG_PATTERNS = ('dockerfile', 'docker-compose', '.github/')
        CODE_EXTENSIONS = ('.go', '.py', '.js', '.ts', '.java', '.rb', '.rs', '.c', '.cpp', '.cs', '.php', '.swift', '.kt')
        
        def is_config_file(filepath: str) -> bool:
            """Check if file is a config file (not code)"""
            if not filepath:
                return False
            filepath_lower = filepath.lower()
            # Code files are never config, even in config directories
            if any(filepath_lower.endswith(ext) for ext in CODE_EXTENSIONS):
                return False
            # Check config extension
            if any(filepath_lower.endswith(ext) for ext in CONFIG_EXTENSIONS):
                return True
            # Check config patterns (Dockerfile, etc.)
            if any(pattern in filepath_lower for pattern in CONFIG_PATTERNS):
                return True
            return False
        
        # Config rule patterns from cwe_reachability.py
        CONFIG_RULE_PATTERNS = [
            'dockerfile.', 'docker-compose.', 'kubernetes.', 'k8s.',
            'terraform.', 'cloudformation.', 'helm.', 'yaml.',
            'cicd.', 'github-actions.', 'gitlab-ci.', 'jenkins.',
            'security-headers', 'cors.', 'ssl.', 'tls.',
        ]
        
        def determine_reachability(finding: dict, is_config: bool, finding_type: str = 'cwe') -> str:
            """Determine app_reachability for a finding
            
            Rules (from cwe_reachability.py and ARCHITECTURE.md):
            - CONFIG files: Always UNKNOWN (except secrets with confirmed loaders)
            - CONFIG rule patterns: Always UNKNOWN  
            - CWE: Use is_reachable boolean (NOT reachable_via)
            - Secrets: Use reachability field + reachability_confidence
            """
            # For secrets: check loader confirmation FIRST (overrides config file check)
            if finding_type == 'secret':
                confidence = finding.get('reachability_confidence', '').upper()
                reachable_via = finding.get('reachable_via', [])
                if confidence == 'CONFIRMED' and reachable_via and len(reachable_via) > 0:
                    return 'REACHABLE'  # Loader confirmed, even in config file
                
                # Check explicit reachability field
                reach = finding.get('reachability', '').lower()
                if reach == 'reachable':
                    return 'REACHABLE'
                elif reach in ('not_reachable', 'unreachable'):
                    return 'NOT_REACHABLE'
                
                # UNKNOWN_EXPLOITABLE or no confidence = UNKNOWN
                return 'UNKNOWN'
            
            # For CWE/config: config files are UNKNOWN
            if is_config:
                return 'UNKNOWN'
            
            # Check if rule_id indicates config issue
            rule_id = finding.get('rule_id', '').lower()
            if any(pattern in rule_id for pattern in CONFIG_RULE_PATTERNS):
                return 'UNKNOWN'
            
            # For CWE: use is_reachable boolean directly
            if finding_type == 'cwe':
                is_reach = finding.get('is_reachable')
                if is_reach is True:
                    return 'REACHABLE'
                elif is_reach is False:
                    return 'NOT_REACHABLE'
                return 'UNKNOWN'
            
            return 'UNKNOWN'
        
        # Process findings from report if available
        if report_file.exists():
            try:
                df = report_data.get('detailed_findings', {})
                
                # Process CWE findings (from detailed_findings.cwe.findings)
                cwe_data = df.get('cwe', {})
                cwe_findings_list = cwe_data.get('findings', []) if isinstance(cwe_data, dict) else []
                
                for finding in cwe_findings_list:
                    filepath = finding.get('file', '')
                    is_config = is_config_file(filepath)
                    app_reach = determine_reachability(finding, is_config, 'cwe')
                    
                    finding_dict = {
                        'id': finding.get('finding_id', f"{finding.get('rule_id', '')}_{filepath}_{finding.get('line', 0)}"),
                        'severity': finding.get('severity', 'MEDIUM'),
                        'title': finding.get('message', 'CWE Finding')[:200],
                        'description': finding.get('message', ''),
                        'file': filepath,
                        'line': finding.get('line'),
                        'app_reachability': app_reach,
                        'cwe_id': finding.get('cwe_id') or finding.get('policy_id', '').replace('CWE-', ''),
                        'scanner': 'semgrep'
                    }
                    
                    if is_config:
                        config_findings.append(finding_dict)
                    else:
                        cwe_findings.append(finding_dict)
                
                # Process SECRET findings (from detailed_findings.secrets.findings)
                secrets_data = df.get('secrets', {})
                secrets_findings_list = secrets_data.get('findings', []) if isinstance(secrets_data, dict) else []
                
                for finding in secrets_findings_list:
                    # Only process actual secrets, not CWE/config issues
                    if not finding.get('is_actual_secret'):
                        continue  # Skip - already processed in CWE loop
                    
                    filepath = finding.get('file', '')
                    is_config = is_config_file(filepath)
                    app_reach = determine_reachability(finding, is_config, 'secret')
                    
                    finding_dict = {
                        'id': finding.get('finding_id') or f"secret_{filepath}_{finding.get('line', 0)}_{finding.get('type', 'unknown')}",
                        'severity': finding.get('severity', 'HIGH'),
                        'title': finding.get('message', 'Secret Finding')[:200],
                        'description': finding.get('message', ''),
                        'file': filepath,
                        'line': finding.get('line'),
                        'app_reachability': app_reach,
                        'secret_type': finding.get('type', 'unknown'),
                        'scanner': finding.get('scanner', 'semgrep')
                    }
                    secret_findings.append(finding_dict)
                    
            except Exception as e:
                created_items.append(f"⚠️  Error processing detailed findings: {e}")
        
        # Fallback to security_findings.json if report doesn't have detailed_findings
        
        # Store secret and CWE findings
        if secret_findings:
            db.store_findings(secret_findings, 'secret')
        if cwe_findings:
            db.store_findings(cwe_findings, 'cwe')
        if config_findings:
            db.store_findings(config_findings, 'config')
        
        # Store AI/LLM security findings (v4.5.29: passed directly, not from JSON)
        if ai_findings:
            try:
                db.store_ai_findings(ai_findings)
                created_items.append(f"✓ Stored {len(ai_findings)} AI findings")
            except Exception as e:
                created_items.append(f"⚠️  Error storing AI findings: {e}")
        
        # Store DLP/PII security findings (v4.5.50: passed directly)
        if dlp_findings:
            try:
                db.store_dlp_findings(dlp_findings)
                created_items.append(f"✓ Stored {len(dlp_findings)} DLP findings")
            except Exception as e:
                created_items.append(f"⚠️  Error storing DLP findings: {e}")
        
        # Complete the scan with risk data
        # Extract source_files_scanned from report if available
        source_files_scanned = 0
        if 'report_data' in locals() and report_data:
            source_files_scanned = report_data.get('metadata', {}).get('source_files_scanned', 0)
        
        db.complete_scan(
            duration_seconds=0, 
            risk_score=risk_score, 
            risk_level=risk_level,
            source_files_scanned=source_files_scanned
        )
        
        # Auto-trim old scans (30 days / 20 per branch)
        trim_result = db.cleanup_old_scans()
        if trim_result.get('scans_deleted', 0) > 0:
            created_items.append(f"✓ Trimmed {trim_result['scans_deleted']} old scans")
        
        db.close()
        
        db_size_kb = repo_db_path.stat().st_size / 1024
        if not db_exists:
            created_items.append(f"✓ Created repo.db ({db_size_kb:.1f}KB)")
        else:
            created_items.append(f"✓ Updated repo.db ({db_size_kb:.1f}KB, scan #{scan_id})")
        
        # Also create symlink for backward compatibility
        legacy_db = output_dir / 'scan.db'
        if not legacy_db.exists():
            try:
                legacy_db.symlink_to(repo_db_path)
            except:
                pass  # Symlink not critical
            
    except Exception as e:
        created_items.append(f"✗ Database error: {str(e)}")
    
  
    if use_legacy_raw:
        # Legacy file creation (for compatibility)
        # ... existing legacy code ...
        created_items.append("✓ Created legacy raw/ files (compatibility mode)")
    
    # Database storage complete - no need to print features message
    pass


def config_command(args):
    """
    Manage REACHABLE configuration.
    
    Commands:
        status  - Show current configuration
        get     - Get specific value
        set     - Set specific value
        enable  - Enable auto-maintenance
        disable - Disable auto-maintenance
        reset   - Reset to defaults
    """
    import sys
    from .config_manager import (
        load_config, save_config, get_config_value, 
        set_config_value, DEFAULT_CONFIG
    )
    
    action = getattr(args, 'config_action', 'status')
    
    if action == 'status':
        config = load_config()
        auto = config.get('auto_maintenance', {})
        
        print()
        print("=" * 60)
        print("REACHABLE Configuration")
        print("=" * 60)
        print()
        
        enabled = auto.get('enabled', True)
        status_icon = "✅" if enabled else "❌"
        print(f"Auto-Maintenance: {status_icon} {'ENABLED' if enabled else 'DISABLED'}")
        print()
        
        if enabled:
            print("Settings:")
            print(f"  Max scans per branch: {auto.get('max_scans_per_branch', 50)}")
            print(f"  Max scan age (days):  {auto.get('max_age_days', 30)}")
            print(f"  Vacuum threshold:     {auto.get('vacuum_threshold_pct', 30)}%")
            print(f"  WAL checkpoint:       {'Yes' if auto.get('wal_checkpoint', True) else 'No'}")
            print()
            print("What happens automatically:")
            print("  • Database checkpoint after every scan")
            print("  • Vacuum when bloat exceeds threshold")
            print("  • Remove scans older than max age")
            print("  • Keep only max scans per branch")
        else:
            print("⚠️  Auto-maintenance is DISABLED")
            print("   Run 'reachctl config enable' to turn it back on")
        print()
    
    elif action == 'get':
        key = getattr(args, 'key', None)
        if not key:
            print("Error: Must specify key")
            print("Usage: reachctl config get <key>")
            sys.exit(1)
        
        # Map friendly names to config paths
        key_map = {
            'max-scans': 'auto_maintenance.max_scans_per_branch',
            'max-age': 'auto_maintenance.max_age_days',
            'vacuum-threshold': 'auto_maintenance.vacuum_threshold_pct',
            'enabled': 'auto_maintenance.enabled',
        }
        
        config_key = key_map.get(key, f'auto_maintenance.{key}')
        value = get_config_value(config_key)
        
        if value is None:
            print(f"Error: Unknown key '{key}'")
            sys.exit(1)
        
        print(f"{key}: {value}")
    
    elif action == 'set':
        key = getattr(args, 'key', None)
        value_str = getattr(args, 'value', None)
        
        if not key or value_str is None:
            print("Error: Must specify key and value")
            print("Usage: reachctl config set <key> <value>")
            sys.exit(1)
        
        # Map friendly names and parse values
        key_map = {
            'max-scans': ('auto_maintenance.max_scans_per_branch', int),
            'max-age': ('auto_maintenance.max_age_days', int),
            'vacuum-threshold': ('auto_maintenance.vacuum_threshold_pct', int),
        }
        
        if key not in key_map:
            print(f"Error: Unknown key '{key}'")
            print("Valid keys: max-scans, max-age, vacuum-threshold")
            sys.exit(1)
        
        config_key, value_type = key_map[key]
        
        try:
            value = value_type(value_str)
        except ValueError:
            print(f"Error: Invalid value for {key}: {value_str}")
            sys.exit(1)
        
        # Validation
        if key == 'max-scans' and value < 1:
            print("Error: max-scans must be at least 1")
            sys.exit(1)
        if key == 'max-age' and value < 1:
            print("Error: max-age must be at least 1 day")
            sys.exit(1)
        if key == 'vacuum-threshold' and not (1 <= value <= 100):
            print("Error: vacuum-threshold must be 1-100%")
            sys.exit(1)
        
        set_config_value(config_key, value)
        print(f"✅ Set {key} = {value}")
    
    elif action == 'enable':
        set_config_value('auto_maintenance.enabled', True)
        print("✅ Auto-maintenance ENABLED")
    
    elif action == 'disable':
        set_config_value('auto_maintenance.enabled', False)
        print("⚠️  Auto-maintenance DISABLED")
        print("   Databases and storage will not be maintained automatically")
    
    elif action == 'reset':
        save_config(dict(DEFAULT_CONFIG))
        print("✅ Configuration reset to defaults")
    
    else:
        print(f"Error: Unknown action '{action}'")
        sys.exit(1)


def cleanup_command(args):
    """
    Emergency cleanup: compact databases and prune old scans.
    
    Usage:
        reachctl cleanup                    # Run cleanup
        reachctl cleanup --dry-run          # Preview only
        reachctl cleanup --force            # Force vacuum even if low bloat
    """
    import sys
    import time
    from .auto_maintenance import run_cleanup
    
    dry_run = getattr(args, 'dry_run', False)
    force = getattr(args, 'force', False)
    
    print()
    print("=" * 60)
    if dry_run:
        print("CLEANUP PREVIEW (DRY RUN)")
    else:
        print("RUNNING CLEANUP")
    print("=" * 60)
    print()
    
    print("This will:")
    print("  • Checkpoint all database WAL files")
    print("  • Vacuum databases to reclaim space")
    print("  • Remove old scans based on retention policy")
    print()
    
    if not dry_run:
        print("Starting in 3 seconds... (Ctrl+C to cancel)")
        try:
            time.sleep(3)
        except KeyboardInterrupt:
            print("\nCancelled")
            sys.exit(0)
    
    results = run_cleanup(force=force, dry_run=dry_run, verbose=True)
    
    print()
    print("=" * 60)
    print("CLEANUP RESULTS")
    print("=" * 60)
    print()
    
    if results.get('error'):
        print(f"❌ Error: {results['error']}")
        sys.exit(1)
    
    print(f"Repositories processed: {results['repos_processed']}")
    print(f"Databases checkpointed: {results['total_checkpointed']}")
    print(f"Databases vacuumed:     {results['total_vacuumed']}")
    print(f"Scans pruned:           {results['total_pruned']}")
    
    if not dry_run and results['space_reclaimed_mb'] > 0:
        print(f"Space reclaimed:        {results['space_reclaimed_mb']:.1f} MB")
    
    if results['errors']:
        print()
        print("Errors:")
        for err in results['errors']:
            print(f"  • {err}")
    
    print()
    
    if dry_run:
        print("This was a dry run. Run without --dry-run to apply changes.")


def main():
    """Main CLI entry point"""
    
    # Check if venv is activated (warn if not)
    _check_venv_activation()
    
    parser = argparse.ArgumentParser(
        prog='reachctl',
        description='REACHABLE - Security vulnerability analysis with reachability intelligence',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  reachctl scan /path/to/repo    Analyze repository
  reachctl selftest              Verify installation
  reachctl doctor                Check dependencies

After scanning, open the dashboard:
  reachctl dashboard --open

© 2026 Sthenos Security. All rights reserved.
Support: adazzi@sthenosec.com
        """
    )
    
    parser.add_argument('--version', '-V', action='store_true',
                       help='Show version and exit')
    
    subparsers = parser.add_subparsers(dest='command', metavar='COMMAND')
    
    # ==========================================================================
    # scan - Main command
    # ==========================================================================
    scan_parser = subparsers.add_parser(
        'scan', 
        help='Scan & discover executable risk in your code repo',
        description='Run complete security analysis on a repository'
    )
    scan_parser.add_argument('repo', metavar='PATH',
                            help='Path to repository to scan')
    
    # Options
    scan_parser.add_argument('--output', '-o', metavar='DIR',
                            help='Output directory (default: ~/.reachable/scans/<repo>)')
    scan_parser.add_argument('--fail-on', choices=['critical', 'high', 'medium', 'any', 'none'],
                            default='none',
                            help='Exit non-zero if findings meet threshold (default: none)')
    scan_parser.add_argument('--quiet', '-q', action='store_true',
                            help='Minimal output (CI-friendly)')
    scan_parser.add_argument('--debug', '-d', action='store_true',
                            help='Verbose output for debugging')
    scan_parser.add_argument('--no-ai', '--disable-ai', action='store_true',
                            dest='disable_ai',
                            help='Skip AI/LLM security analysis (faster scans)')
    scan_parser.add_argument('--no-dlp', '--disable-dlp', action='store_true',
                            dest='disable_dlp',
                            help='Skip DLP/PII analysis')
    scan_parser.add_argument('--no-dashboard', action='store_true',
                            dest='no_dashboard',
                            help='Skip dashboard generation (faster CI/CD scans)')
    scan_parser.add_argument('--force-rebuild', '--force', action='store_true',
                            help='Force new scan (skip cache, always regenerate with latest template)')
    
    # ==========================================================================
    # dashboard - Generate or access scan dashboard
    # ==========================================================================
    dashboard_parser = subparsers.add_parser(
        'dashboard', 
        help='Generate or access scan dashboard',
        description='Generate dashboard from scan results or get path for CI/CD artifacts'
    )
    dashboard_parser.add_argument('--repo', '-r', metavar='NAME',
                                 help='Repository name (fuzzy match) or path')
    dashboard_parser.add_argument('--generate', '-g', action='store_true',
                                 help='Regenerate dashboard from scan results')
    dashboard_parser.add_argument('--output', '-o', metavar='DIR',
                                 help='Output directory for generated dashboard')
    dashboard_parser.add_argument('--path', '-p', action='store_true',
                                 help='Print dashboard path only (for CI/CD artifacts)')
    dashboard_parser.add_argument('--open', action='store_true',
                                 help='Open dashboard in browser')
    dashboard_parser.add_argument('--list', '-l', action='store_true',
                                 help='List all available dashboards')
    
    # ==========================================================================
    # selftest - Run all validation tests
    # ==========================================================================
    selftest_parser = subparsers.add_parser(
        'selftest', 
        help='Run all validation tests',
        description='Verify REACHABLE works by running all tests (unit + integration)'
    )
    selftest_parser.add_argument('--quick', action='store_true',
                                  help='Quick sanity check (no pytest needed)')
    selftest_parser.add_argument('--coverage', '-c', action='store_true',
                                  help='Run with coverage report')
    selftest_parser.add_argument('--quiet', '-q', action='store_true',
                                  help='Minimal output')
    
    # ==========================================================================
    # doctor - System health check
    # ==========================================================================
    doctor_parser = subparsers.add_parser(
        'doctor', 
        help='Check system dependencies and configuration',
        description='Verify all required and optional tools are available'
    )
    doctor_parser.add_argument('--no-fix', action='store_true',
                              help='Check only, do not auto-install missing tools')
    
    # ==========================================================================
    # cleanup - Emergency maintenance (USER-FACING)
    # ==========================================================================
    cache_parser = subparsers.add_parser(
        'cache',
        help=argparse.SUPPRESS,  # Hidden - use 'reachctl cleanup' or 'reachctl admin cache'
        description='View, clear, or warm up REACHABLE caches'
    )
    cache_group = cache_parser.add_mutually_exclusive_group(required=False)  # Default to --status
    cache_group.add_argument('--status', action='store_true',
                            help='Show cache usage and sizes (default)')
    cache_group.add_argument('--clear', action='store_true',
                            help='Clear all caches')
    cache_group.add_argument('--clear-libs', action='store_true',
                            help='Clear library cache only')
    cache_group.add_argument('--clear-semgrep', action='store_true',
                            help='Clear Semgrep result caches (per-repo SHA caches)')
    cache_group.add_argument('--warm', action='store_true',
                            help='Pre-warm caches for faster scans')
    cache_parser.add_argument('--repo', '-r', metavar='NAME',
                             help='Repository name (fuzzy match) - for --clear-semgrep')
    cache_parser.add_argument('--force', '-f', action='store_true',
                             help='Skip confirmation prompts')
    
    # ==========================================================================
    # db - Database management (v4.5.8)
    # ==========================================================================
    db_parser = subparsers.add_parser(
        'db',
        help=argparse.SUPPRESS,  # Hidden - use 'reachctl cleanup' or 'reachctl admin db'
        description='View status, compact, trim, or repair databases'
    )
    db_parser.add_argument('--repo', '-r', metavar='NAME',
                          help='Repository name (fuzzy match) - default: all repos')
    db_group = db_parser.add_mutually_exclusive_group(required=False)  # Default to --status
    db_group.add_argument('--status', action='store_true',
                         help='Show database status: sizes, WAL, bloat (default)')
    db_group.add_argument('--compact', action='store_true',
                         help='Compact databases: checkpoint WAL + VACUUM INTO if needed')
    db_group.add_argument('--checkpoint', action='store_true',
                         help='Checkpoint WAL only (fast, no vacuum)')
    db_group.add_argument('--check', action='store_true',
                         help='Check database integrity')
    db_group.add_argument('--repair', action='store_true',
                         help='Attempt to repair corrupted database')
    db_group.add_argument('--trim', action='store_true',
                         help='Trim old scans (30 days / 20 per branch)')
    db_group.add_argument('--optimize', action='store_true',
                         help='[DEPRECATED] Use --compact instead')
    db_parser.add_argument('--force', action='store_true',
                          help='Force vacuum even if low bloat')
    db_parser.add_argument('--dry-run', action='store_true',
                          help='Show what would be done without doing it')
    db_parser.add_argument('--verbose', '-v', action='store_true',
                          help='Show detailed information')
    
    # ==========================================================================
    # primer - Quick-start guide
    # ==========================================================================
    primer_parser = subparsers.add_parser(
        'primer', 
        help='Quick-start guide and playbook',
        description='Built-in playbook with overview, install/config tips, debugging, and examples'
    )
    
    # ==========================================================================
    # sandbox - Dynamic malware sandbox management
    # ==========================================================================
    sandbox_parser = subparsers.add_parser(
        'sandbox', 
        help='Manage dynamic malware sandbox',
        description='Install, remove, or check status of the dynamic malware sandbox (Colima on macOS)'
    )
    sandbox_group = sandbox_parser.add_mutually_exclusive_group(required=False)  # Default to --status
    sandbox_group.add_argument('--init', action='store_true',
                              help='Install sandbox (Colima on macOS)')
    sandbox_group.add_argument('--remove', action='store_true',
                              help='Remove sandbox')
    sandbox_group.add_argument('--status', action='store_true',
                              help='Check sandbox status (default)')
    
    # ==========================================================================
    # vulndb - Vulnerability database management
    # ==========================================================================
    vulndb_parser = subparsers.add_parser(
        'vulndb', 
        help='Manage grype vulnerability database',
        description='View status, update, or clear the grype CVE database cache'
    )
    vulndb_group = vulndb_parser.add_mutually_exclusive_group(required=False)  # Default to --status
    vulndb_group.add_argument('--status', action='store_true',
                             help='Show vulnerability DB status (default)')
    vulndb_group.add_argument('--update', action='store_true',
                             help='Force refresh the vulnerability database')
    vulndb_group.add_argument('--reset', action='store_true',
                             help='Delete and rebuild the database from scratch')
    
    # ==========================================================================
    # pipeline - Distributed CI/CD execution
    # ==========================================================================
    from .pipeline_cli import setup_pipeline_parser
    setup_pipeline_parser(subparsers)
    
    # ==========================================================================
    # system - System info, storage management, cleanup
    # ==========================================================================
    system_parser = subparsers.add_parser(
        'system',
        help=argparse.SUPPRESS,  # Hidden - use 'reachctl cleanup' or 'reachctl admin system'
        description='View storage usage, manage caches, and prune old data'
    )
    system_parser.add_argument('action', nargs='?', default='info',
                               choices=['info', 'df', 'prune'],
                               help='info: show system info (default), df: disk usage breakdown, prune: clean up old data')
    system_parser.add_argument('--verbose', '-v', action='store_true',
                               help='Show detailed information')
    system_parser.add_argument('--json', action='store_true',
                               help='Output in JSON format')
    system_parser.add_argument('--dry-run', action='store_true',
                               help='Show what would be deleted without actually deleting')
    system_parser.add_argument('--max-age', type=int, default=21,
                               help='Delete scans older than N days (default: 21)')
    system_parser.add_argument('--max-scans', type=int, default=20,
                               help='Keep only N scans per branch (default: 20)')

    
    # ==========================================================================
    # config - Configuration management
    # ==========================================================================
    config_parser = subparsers.add_parser(
        'config',
        help='Manage REACHABLE configuration',
        description='Configure auto-maintenance and other settings'
    )
    config_parser.add_argument('config_action', nargs='?', default='status',
                               choices=['status', 'get', 'set', 'enable', 'disable', 'reset'],
                               help='Action: status (default), get, set, enable, disable, reset')
    config_parser.add_argument('key', nargs='?',
                               help='Config key (for get/set)')
    config_parser.add_argument('value', nargs='?',
                               help='Config value (for set)')
    
    # ==========================================================================
    # cleanup - Emergency maintenance
    # ==========================================================================
    cleanup_parser = subparsers.add_parser(
        'cleanup',
        help='Emergency cleanup: compact DBs and prune old scans',
        description='Run maintenance tasks to fix stuck systems'
    )
    cleanup_parser.add_argument('--dry-run', action='store_true',
                                help='Preview what would be removed')
    cleanup_parser.add_argument('--force', action='store_true',
                                help='Force vacuum even if bloat is low')

    # ==========================================================================
    # trends - View historical security trends (FUTURE)
    # ==========================================================================
    # NOTE: Trends command parser defined but handler not yet implemented
    # trends_parser = subparsers.add_parser(
    #     'trends',
    #     help='View historical security trends',
    #     description='Display security metrics over time (survives scan pruning)'
    # )
    # trends_parser.add_argument('--repo', '-r', metavar='NAME',
    #                            help='Repository name (fuzzy match)')
    # trends_parser.add_argument('--days', '-d', type=int, default=30,
    #                            help='Number of days to show (default: 30)')
    # trends_parser.add_argument('--branch', '-b',
    #                            help='Specific branch (default: all)')
    # trends_parser.add_argument('--type', choices=['all', 'cve', 'secret', 'cwe', 'ai', 'dlp'],
    #                            default='all',
    #                            help='Finding type to show (default: all)')
    # trends_parser.add_argument('--json', action='store_true',
    #                            help='Output in JSON format')

    # ==========================================================================
    # version - Show version
    # ==========================================================================
    version_parser = subparsers.add_parser(
        'version', 
        help='Show version and tool information'
    )
    version_parser.add_argument('--wheel', '-w', action='store_true',

    
                               help='Show wheel package verification info')
    
    # ==========================================================================
    # top10size - Repo file distribution diagnostic
    # ==========================================================================
    top10_parser = subparsers.add_parser(
        'top10size',
        help='Show top-level directory file counts (scan performance diagnostic)',
        description='Show which directories contain the most files.\n'
                    'Use this to understand why scans are slow — if venv/ or '
                    'node_modules/ dominates, your .semgrepignore may need updating.'
    )
    top10_parser.add_argument('path', nargs='?', default='.',
                              help='Repository path (default: current directory)')
    top10_parser.add_argument('-n', '--top', type=int, default=10,
                              help='Number of directories to show (default: 10)')
    top10_parser.add_argument('--all', action='store_true',
                              help='Show all directories, not just top N')

    # Admin command (hidden)
    admin_parser = subparsers.add_parser('admin', help=argparse.SUPPRESS)
    admin_parser.add_argument('admin_args', nargs=argparse.REMAINDER, help=argparse.SUPPRESS)
    
    # Audit command
    audit_parser = subparsers.add_parser("audit", help="Audit scan metrics")
    audit_parser.add_argument("--scan-path", help="Scan directory")
    audit_parser.add_argument("--json", action="store_true")

    # Parse arguments
    args = parser.parse_args()

    # Setup logger based on debug flag
    debug_mode = getattr(args, 'debug', False)
    setup_logger(debug=debug_mode)
    
    
    # Handle --version flag at top level
    if getattr(args, 'version', False) and args.command is None:
        print_version()
        sys.exit(0)
    
    # No command specified
    if not args.command:
        parser.print_help()
        sys.exit(1)
    
    # Check license before running any command (except version/help)
    # This enforces the 30-day evaluation period
    try:
        from .license import check_license_or_exit
        quiet = getattr(args, 'quiet', False)
        check_license_or_exit(quiet=quiet)
    except ImportError:
        pass  # License module not available, continue
    
    # Route to command handlers
    if args.command == 'scan':
        scan_repo(args)
    elif args.command == 'dashboard':
        open_dashboard(args)
    elif args.command == 'selftest':
        selftest(args)
    elif args.command == 'doctor':
        admin_doctor(args)
    elif args.command == 'cache':
        # Map to existing admin_cache function
        admin_cache(args)
    elif args.command == 'db':
        admin_db(args)
    elif args.command == 'sandbox':
        sandbox_command(args)
    elif args.command == 'vulndb':
        vulndb_command(args)
    elif args.command == 'system':
        system_command(args)
    elif args.command == 'pipeline':
        from .pipeline_cli import pipeline_command
        sys.exit(pipeline_command(args))
    elif args.command == 'primer':
        show_primer(args)
    elif args.command == 'version':
        print_version(args)
    elif args.command == 'admin':
        # Reset argv for admin_cli to parse
        sys.argv = ['reachctl', 'admin'] + args.admin_args
        from .admin_cli import main as admin_main
        sys.exit(admin_main())
    elif args.command == 'config':
        config_command(args)
    elif args.command == 'cleanup':
        cleanup_command(args)
    
    elif args.command == "audit":
        sys.exit(audit_command(args))
    else:
        parser.print_help()
        sys.exit(1)


def system_command(args):
    """
    System information and storage management.
    
    Actions:
        info  - Show system overview (storage, sandboxes, DB status)
        df    - Detailed disk usage breakdown
        prune - Clean up old scans and compress older dashboards
    """
    from .storage_utils import (
        print_system_info, 
        get_system_info, 
        get_storage_breakdown,
        prune_storage,
        format_size
    )
    
    action = getattr(args, 'action', 'info')
    verbose = getattr(args, 'verbose', False)
    json_output = getattr(args, 'json', False)
    
    if action == 'info':
        print_system_info(verbose=verbose, json_output=json_output)
    
    elif action == 'df':
        # Detailed disk usage
        storage = get_storage_breakdown()
        
        if json_output:
            import json
            print(json.dumps(storage, indent=2, default=str))
            return
        
        print("=" * 70)
        logger.info("REACHABLE DISK USAGE")
        print("=" * 70)
        
        if not storage['exists']:
            logger.info("\n~/.reachable does not exist yet")
            return
        
        logger.info(f"\nTotal: {storage['total_human']}")
        logger.info(f"Path:  {storage['path']}")
        
        # Components
        if storage.get('components'):
            print("\n" + "-" * 50)
            logger.info("COMPONENTS")
            print("-" * 50)
            for name, data in sorted(storage['components'].items(), key=lambda x: x[1]['size'], reverse=True):
                pct = (data['size'] / storage['total'] * 100) if storage['total'] > 0 else 0
                logger.info(f"  {name:15} {data['size_human']:>12}  ({pct:5.1f}%)  {data['file_count']:>6,} files")
        
        # Cache breakdown
        if storage.get('cache_breakdown'):
            print("\n" + "-" * 50)
            logger.info("CACHE BREAKDOWN")
            print("-" * 50)
            for name, data in sorted(storage['cache_breakdown'].items(), key=lambda x: x[1]['size'], reverse=True):
                logger.info(f"  {name:25} {data['size_human']:>12}")
        
        # Top repositories
        if storage.get('top_repos'):
            print("\n" + "-" * 50)
            logger.info("TOP REPOSITORIES (by size)")
            print("-" * 50)
            for repo in storage['top_repos']:
                logger.info(f"  {repo['name'][:40]:40} {repo['size_human']:>10}")
                logger.info(f"    {repo['scan_count']} scans, {repo['branch_count']} branches, DB: {repo['db_size_human']}")
                if repo.get('newest_scan'):
                    logger.info(f"    Last scan: {repo['newest_scan'][:19]}")
        
        # Top files
        if storage.get('top_files') and verbose:
            print("\n" + "-" * 50)
            logger.info("TOP FILES (by size)")
            print("-" * 50)
            for f in storage['top_files']:
                logger.info(f"  {f['size_human']:>12}  {f['path']}")
        
        print()
    
    elif action == 'prune':
        # Clean up old data
        dry_run = getattr(args, 'dry_run', False)
        max_age = getattr(args, 'max_age', 21)
        max_scans = getattr(args, 'max_scans', 20)
        
        print("=" * 70)
        logger.info("REACHABLE STORAGE PRUNE")
        print("=" * 70)
        
        if dry_run:
            logger.info("\n⚠️  DRY RUN - No changes will be made\n")
        
        logger.info(f"Settings:")
        logger.info(f"  Max scan age:        {max_age} days")
        logger.info(f"  Max scans per branch: {max_scans}")
        logger.info(f"  Compress after:      14 days")
        print()
        
        result = prune_storage(
            max_age_days=max_age,
            max_scans_per_branch=max_scans,
            compress_after_days=14,
            dry_run=dry_run,
            verbose=verbose
        )
        
        print("\n" + "-" * 50)
        logger.info("RESULTS")
        print("-" * 50)
        logger.info(f"  Scans deleted:         {result['scans_deleted']}")
        logger.info(f"  Directories deleted:   {result['dirs_deleted']}")
        logger.info(f"  Directories compressed: {result['dirs_compressed']}")
        logger.info(f"  Space freed:           {result['bytes_freed_human']}")
        
        if result.get('errors'):
            logger.info("\n⚠️  Errors:")
            for err in result['errors']:
                logger.info(f"  • {err}")
        
        if dry_run:
            logger.info("\n💡 Run without --dry-run to apply changes")
        else:
            logger.info("\n✅ Cleanup complete")
        
        print()


def vulndb_command(args):
    """
    Manage grype vulnerability database.
    
    The vulnerability DB is cached locally at ~/.reachable/cache/grype-db/
    and auto-refreshed if older than 24 hours during scans.
    """
    from .vulndb import VulnDBManager
    
    print("=" * 60)
    logger.info("REACHABLE VULNERABILITY DATABASE")
    print("=" * 60)
    print()
    
    mgr = VulnDBManager()
    
    if getattr(args, 'update', False):
        # Force update
        logger.info("Updating vulnerability database...")
        print()
        if mgr.update(force=True, verbose=True):
            print()
            logger.info("✅ Vulnerability database updated successfully.")
        else:
            print()
            logger.info("❌ Failed to update vulnerability database.")
            sys.exit(1)
    
    elif getattr(args, 'reset', False):
        # Clear and rebuild
        logger.info("Resetting vulnerability database...")
        print()
        if mgr.clear(verbose=True):
            print()
            logger.info("Downloading fresh database...")
            if mgr.update(force=True, verbose=True):
                print()
                logger.info("✅ Vulnerability database reset successfully.")
            else:
                print()
                logger.info("❌ Failed to download new database.")
                sys.exit(1)
        else:
            print()
            logger.info("❌ Failed to clear database.")
            sys.exit(1)
    
    else:
        # Default: show status
        status = mgr.get_status()
        
        logger.info(f"Location:    {status['location']}")
        print()
        
        if status['exists']:
            logger.info(f"  Status:      ✅ Available")
            logger.info(f"  Size:        {status['size_mb']:.1f} MB")
            
            if status['age_hours'] is not None:
                age_hours = status['age_hours']
                if age_hours < 1:
                    age_str = f"{int(age_hours * 60)} minutes"
                elif age_hours < 24:
                    age_str = f"{age_hours:.1f} hours"
                else:
                    age_str = f"{age_hours / 24:.1f} days"
                logger.info(f"  Age:         {age_str}")
                logger.info(f"  Last Update: {status['last_update']}")
                
                if status['is_stale']:
                    print()
                    logger.info(f"  ⚠️  Database is stale (> {status['max_age_hours']}h old)")
                    logger.info(f"      Will auto-refresh on next scan, or run:")
                    logger.info(f"      reachctl vulndb --update")
                else:
                    print()
                    logger.info(f"  ✅ Database is fresh (auto-refresh at {status['max_age_hours']}h)")
            else:
                logger.info(f"  Age:         Unknown (no timestamp)")
        else:
            logger.info(f"  Status:      ❌ Not initialized")
            print()
            logger.info("  The database will be downloaded automatically on first scan.")
            logger.info("  Or run: reachctl vulndb --update")
        
        print()
        logger.info("Commands:")
        logger.info("  reachctl vulndb --status   Show this status")
        logger.info("  reachctl vulndb --update   Force refresh now")
        logger.info("  reachctl vulndb --reset    Delete and rebuild from scratch")

def print_version(args=None):
    """Print version information with tool locations"""
    from . import __version__, __git_info__, __build_date__
    import platform
    import re
    
    # Version line
    logger.info(f"REACHABLE {__version__}")
    print()
    
    # Python info
    logger.info(f"Python:   {platform.python_version()}")
    logger.info(f"Platform: {platform.system().lower()}")
    print()
    
    # Base tools - check ONLY our managed locations (not system PATH)
    logger.info("Base Tools:")
    
    # Define tool locations
    reachable_home = Path.home() / '.reachable'
    venv_bin = reachable_home / 'venv' / 'bin'           # Python tools (semgrep)
    tools_bin = reachable_home / 'tools' / 'bin'         # Local syft/grype binaries
    guarddog_venv_bin = reachable_home / 'guarddog-venv' / 'bin'  # Isolated guarddog
    
    def get_version(tool_path: Path, tool_name: str) -> str:
        """Get version from tool, return None if not found."""
        if not tool_path.exists():
            return None
        try:
            # Use --version for most tools, 'version' for syft/grype
            version_arg = 'version' if tool_name in ('syft', 'grype') else '--version'
            result = subprocess.run(
                [str(tool_path), version_arg],
                capture_output=True, text=True, timeout=10
            )
            if result.returncode == 0:
                output = result.stdout.strip() or result.stderr.strip()
                # Extract version number (X.Y.Z pattern)
                match = re.search(r'(\d+\.\d+\.?\d*)', output)
                if match:
                    return match.group(1)
                return 'installed'
        except Exception:
            pass
        return None
    
    # Syft & Grype in tools/bin/
    for tool in ['syft', 'grype']:
        tool_path = tools_bin / tool
        version = get_version(tool_path, tool)
        if version:
            logger.info(f"  {tool}: {version} (tools)")
        else:
            logger.info(f"  {tool}: not found")
    
    # Semgrep in venv/bin/
    semgrep_path = venv_bin / 'semgrep'
    version = get_version(semgrep_path, 'semgrep')
    if version:
        logger.info(f"  semgrep: {version} (venv)")
    else:
        logger.info(f"  semgrep: not found")
    
    # GuardDog in isolated venv
    guarddog_path = guarddog_venv_bin / 'guarddog'
    version = get_version(guarddog_path, 'guarddog')
    if version:
        logger.info(f"  guarddog: {version} (isolated-venv)")
    else:
        logger.info(f"  guarddog: not found")
    
    print()
    
    # Commit info
    git = __git_info__
    if git.get("sha"):
        commit_line = f"Commit: {git['sha']}"
        if git.get("date"):
            commit_line += f" ({git['date']})"
        if git.get("branch"):
            commit_line += f" [{git['branch']}]"
        print(commit_line)
    
    # Build date (only for wheel installs from CI/CD)
    if __build_date__:
        logger.info(f"Build: {__build_date__}")
    
    print()
    logger.info(f"© 2026 Sthenos Security. All rights reserved.")

def audit_command(args):
    """
    Comprehensive data quality audit across entire pipeline.
    Validates: Raw JSON → Database → Dashboard
    Checks ALL finding types, states, severities, and reduction metrics.
    """
    from reachable.audit import ComprehensiveAuditor, find_latest_scan
    from pathlib import Path
    
    # Get scan path
    scan_path = Path(args.scan_path) if args.scan_path else None
    
    if not scan_path:
        scan_path = find_latest_scan()
        if not scan_path:
            logger.info("Error: No scans found. Run a scan first or specify --scan-path")
            return 1
    
    if not scan_path.exists():
        logger.info(f"Error: Scan directory not found: {scan_path}")
        return 1
    
    # Run comprehensive audit
    auditor = ComprehensiveAuditor(scan_path)
    
    raw = auditor.audit_raw()
    db = auditor.audit_database()
    dash = auditor.audit_dashboard()
    
    issues = auditor.compare_stages(raw, db, dash)
    
    passed = auditor.print_report(raw, db, dash, issues)
    
    return 0 if passed else 1

if __name__ == '__main__':
    main()
