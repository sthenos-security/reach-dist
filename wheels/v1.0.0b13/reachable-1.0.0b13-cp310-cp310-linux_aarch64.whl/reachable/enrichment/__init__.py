#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.

"""
REACHABLE Enrichment Module

Provides CVE/GHSA enrichment from various sources:
- GitHub Advisory Database
- NVD (future)
- OSV (future)
"""

from .ghsa_enricher import (
    GHSAEnricher,
    enrich_cve_findings,
    get_ghsa_for_cve,
    get_cve_for_ghsa,
    get_fix_info,
)

__all__ = [
    'GHSAEnricher',
    'enrich_cve_findings',
    'get_ghsa_for_cve',
    'get_cve_for_ghsa',
    'get_fix_info',
]
