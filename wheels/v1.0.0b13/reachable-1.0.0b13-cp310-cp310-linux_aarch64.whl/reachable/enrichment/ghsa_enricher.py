#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.

"""
REACHABLE v4.5.41 - GitHub Security Advisory (GHSA) Enricher

Enriches CVE findings with fix information from GitHub Advisory Database.

Data Sources:
1. GitHub REST API (/advisories endpoint) - Real-time, rate limited
2. Local clone of github/advisory-database - Bulk, offline capable

Features:
- CVE → GHSA mapping
- GHSA → CVE mapping  
- Fix version extraction
- Affected package/version ranges
- References (patches, security advisories)
- Caching to avoid repeated lookups
"""

import json
import os
import sqlite3
import time
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from pathlib import Path
from typing import Dict, Any, List, Optional, Tuple
import logging

logger = logging.getLogger(__name__)


@dataclass
class GHSAInfo:
    """GitHub Security Advisory information"""
    ghsa_id: str
    cve_ids: List[str] = field(default_factory=list)
    summary: str = ""
    description: str = ""
    severity: str = "UNKNOWN"
    cvss_score: Optional[float] = None
    cvss_vector: Optional[str] = None
    
    # Affected packages and fix versions
    affected_packages: List[Dict[str, Any]] = field(default_factory=list)
    fix_versions: Dict[str, List[str]] = field(default_factory=dict)  # {package: [versions]}
    
    # References
    references: List[Dict[str, str]] = field(default_factory=list)
    
    # Metadata
    published_at: Optional[str] = None
    updated_at: Optional[str] = None
    withdrawn_at: Optional[str] = None
    
    def has_fix(self, package_name: str = None) -> bool:
        """Check if fix is available for package (or any package if not specified)"""
        if package_name:
            # Normalize package name for comparison
            pkg_lower = package_name.lower()
            for pkg, versions in self.fix_versions.items():
                if pkg.lower() == pkg_lower and versions:
                    return True
            return False
        return len(self.fix_versions) > 0 and any(v for v in self.fix_versions.values())
    
    def get_fix_version(self, package_name: str = None) -> Optional[str]:
        """Get earliest fix version for package"""
        if package_name:
            pkg_lower = package_name.lower()
            for pkg, versions in self.fix_versions.items():
                if pkg.lower() == pkg_lower and versions:
                    return versions[0]
            return None
        # Return first available fix version
        for versions in self.fix_versions.values():
            if versions:
                return versions[0]
        return None
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary"""
        return {
            'ghsa_id': self.ghsa_id,
            'cve_ids': self.cve_ids,
            'summary': self.summary,
            'severity': self.severity,
            'cvss_score': self.cvss_score,
            'affected_packages': self.affected_packages,
            'fix_versions': self.fix_versions,
            'references': self.references,
            'published_at': self.published_at,
            'has_fix': self.has_fix(),
        }


class GHSAEnricher:
    """
    GitHub Security Advisory enricher.
    
    Supports two modes:
    1. API mode: Uses GitHub REST API (requires token, rate limited)
    2. Local mode: Uses cloned github/advisory-database repo (offline capable)
    """
    
    CACHE_TTL_HOURS = 24
    API_RATE_LIMIT_DELAY = 0.5
    
    def __init__(
        self,
        github_token: Optional[str] = None,
        local_db_path: Optional[str] = None,
        cache_path: Optional[str] = None,
        use_api: bool = True,
    ):
        self.github_token = github_token or os.environ.get('GITHUB_TOKEN')
        self.local_db_path = Path(local_db_path) if local_db_path else None
        self.use_api = use_api and self.github_token is not None
        
        if cache_path:
            self.cache_path = Path(cache_path)
        else:
            self.cache_path = Path.home() / '.reachable' / 'cache' / 'ghsa_cache.db'
        
        self.cache_path.parent.mkdir(parents=True, exist_ok=True)
        self._init_cache()
        
        self._session_cache: Dict[str, GHSAInfo] = {}
        self._last_api_call = 0
        self._local_index: Dict[str, str] = {}
        
        if self.local_db_path and self.local_db_path.exists():
            self._build_local_index()
    
    def _init_cache(self):
        """Initialize SQLite cache"""
        conn = sqlite3.connect(str(self.cache_path))
        conn.execute("""
            CREATE TABLE IF NOT EXISTS ghsa_cache (
                lookup_key TEXT PRIMARY KEY,
                ghsa_id TEXT,
                data TEXT,
                cached_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        conn.execute("CREATE INDEX IF NOT EXISTS idx_ghsa_id ON ghsa_cache(ghsa_id)")
        conn.commit()
        conn.close()
    
    def _get_cached(self, lookup_key: str) -> Optional[GHSAInfo]:
        """Get from cache if not expired"""
        if lookup_key in self._session_cache:
            return self._session_cache[lookup_key]
        
        conn = sqlite3.connect(str(self.cache_path))
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        cursor.execute("SELECT data, cached_at FROM ghsa_cache WHERE lookup_key = ?", (lookup_key,))
        row = cursor.fetchone()
        conn.close()
        
        if row:
            cached_at = datetime.fromisoformat(row['cached_at'])
            if datetime.now() - cached_at < timedelta(hours=self.CACHE_TTL_HOURS):
                try:
                    data = json.loads(row['data'])
                    info = self._dict_to_ghsa_info(data)
                    self._session_cache[lookup_key] = info
                    return info
                except:
                    pass
        return None
    
    def _set_cached(self, lookup_key: str, info: GHSAInfo):
        """Store in cache"""
        self._session_cache[lookup_key] = info
        conn = sqlite3.connect(str(self.cache_path))
        conn.execute(
            "INSERT OR REPLACE INTO ghsa_cache (lookup_key, ghsa_id, data, cached_at) VALUES (?, ?, ?, CURRENT_TIMESTAMP)",
            (lookup_key, info.ghsa_id, json.dumps(info.to_dict()))
        )
        conn.commit()
        conn.close()
    
    def _build_local_index(self):
        """Build index of CVE→GHSA mappings from local database"""
        logger.info(f"Building local GHSA index from {self.local_db_path}")
        
        advisories_path = self.local_db_path / 'advisories' / 'github-reviewed'
        if not advisories_path.exists():
            advisories_path = self.local_db_path / 'advisories'
        
        if not advisories_path.exists():
            logger.warning(f"Advisory path not found: {advisories_path}")
            return
        
        count = 0
        for json_file in advisories_path.rglob('GHSA-*.json'):
            try:
                with open(json_file) as f:
                    data = json.load(f)
                
                ghsa_id = data.get('id', '')
                aliases = data.get('aliases', [])
                
                for alias in aliases:
                    if alias.startswith('CVE-'):
                        self._local_index[alias] = str(json_file)
                
                if ghsa_id:
                    self._local_index[ghsa_id] = str(json_file)
                
                count += 1
            except Exception as e:
                logger.debug(f"Error indexing {json_file}: {e}")
        
        logger.info(f"Indexed {count} advisories, {len(self._local_index)} lookup keys")
    
    def _dict_to_ghsa_info(self, data: Dict[str, Any]) -> GHSAInfo:
        """Convert dict to GHSAInfo object"""
        return GHSAInfo(
            ghsa_id=data.get('ghsa_id', data.get('id', '')),
            cve_ids=data.get('cve_ids', data.get('aliases', [])),
            summary=data.get('summary', ''),
            description=data.get('description', data.get('details', '')),
            severity=data.get('severity', 'UNKNOWN'),
            cvss_score=data.get('cvss_score'),
            cvss_vector=data.get('cvss_vector'),
            affected_packages=data.get('affected_packages', data.get('affected', [])),
            fix_versions=data.get('fix_versions', {}),
            references=data.get('references', []),
            published_at=data.get('published_at', data.get('published')),
            updated_at=data.get('updated_at', data.get('modified')),
        )
    
    def _parse_osv_advisory(self, data: Dict[str, Any]) -> GHSAInfo:
        """Parse OSV-format advisory (used by GitHub)"""
        ghsa_id = data.get('id', '')
        cve_ids = [a for a in data.get('aliases', []) if a.startswith('CVE-')]
        
        severity = 'UNKNOWN'
        cvss_score = None
        cvss_vector = None
        
        severity_list = data.get('severity', [])
        if severity_list:
            for sev in severity_list:
                if sev.get('type') == 'CVSS_V3':
                    cvss_vector = sev.get('score', '')
        
        db_specific = data.get('database_specific', {})
        if db_specific:
            severity = db_specific.get('severity', severity)
            cvss_info = db_specific.get('cvss', {})
            if isinstance(cvss_info, dict):
                cvss_score = cvss_info.get('score')
        
        affected_packages = []
        fix_versions = {}
        
        for affected in data.get('affected', []):
            pkg = affected.get('package', {})
            ecosystem = pkg.get('ecosystem', 'unknown')
            pkg_name = pkg.get('name', '')
            
            affected_packages.append({
                'ecosystem': ecosystem,
                'name': pkg_name,
                'versions': affected.get('versions', []),
            })
            
            for range_info in affected.get('ranges', []):
                for event in range_info.get('events', []):
                    if 'fixed' in event:
                        fix_ver = event['fixed']
                        if pkg_name not in fix_versions:
                            fix_versions[pkg_name] = []
                        if fix_ver not in fix_versions[pkg_name]:
                            fix_versions[pkg_name].append(fix_ver)
        
        references = []
        for ref in data.get('references', []):
            references.append({
                'type': ref.get('type', 'WEB'),
                'url': ref.get('url', ''),
            })
        
        return GHSAInfo(
            ghsa_id=ghsa_id,
            cve_ids=cve_ids,
            summary=data.get('summary', ''),
            description=data.get('details', ''),
            severity=severity,
            cvss_score=cvss_score,
            cvss_vector=cvss_vector,
            affected_packages=affected_packages,
            fix_versions=fix_versions,
            references=references,
            published_at=data.get('published'),
            updated_at=data.get('modified'),
            withdrawn_at=data.get('withdrawn'),
        )
    
    def _fetch_from_local(self, lookup_key: str) -> Optional[GHSAInfo]:
        """Fetch advisory from local database"""
        if not self._local_index:
            return None
        
        file_path = self._local_index.get(lookup_key)
        if not file_path:
            return None
        
        try:
            with open(file_path) as f:
                data = json.load(f)
            return self._parse_osv_advisory(data)
        except Exception as e:
            logger.error(f"Error reading {file_path}: {e}")
            return None
    
    def _fetch_from_api(self, lookup_key: str) -> Optional[GHSAInfo]:
        """Fetch advisory from GitHub API"""
        if not self.use_api or not self.github_token:
            return None
        
        elapsed = time.time() - self._last_api_call
        if elapsed < self.API_RATE_LIMIT_DELAY:
            time.sleep(self.API_RATE_LIMIT_DELAY - elapsed)
        
        try:
            import urllib.request
            import urllib.error
            
            if lookup_key.startswith('GHSA-'):
                url = f"https://api.github.com/advisories/{lookup_key}"
            elif lookup_key.startswith('CVE-'):
                url = f"https://api.github.com/advisories?cve_id={lookup_key}"
            else:
                return None
            
            req = urllib.request.Request(url)
            req.add_header('Authorization', f'Bearer {self.github_token}')
            req.add_header('Accept', 'application/vnd.github+json')
            req.add_header('X-GitHub-Api-Version', '2022-11-28')
            
            self._last_api_call = time.time()
            
            with urllib.request.urlopen(req, timeout=10) as response:
                data = json.loads(response.read().decode())
            
            if isinstance(data, list):
                if not data:
                    return None
                data = data[0]
            
            return self._parse_api_response(data)
            
        except urllib.error.HTTPError as e:
            if e.code == 404:
                logger.debug(f"Advisory not found: {lookup_key}")
            elif e.code == 403:
                logger.warning("GitHub API rate limit exceeded")
            else:
                logger.error(f"GitHub API error {e.code}: {e.reason}")
            return None
        except Exception as e:
            logger.error(f"Error fetching from GitHub API: {e}")
            return None
    
    def _parse_api_response(self, data: Dict[str, Any]) -> GHSAInfo:
        """Parse GitHub API response format"""
        ghsa_id = data.get('ghsa_id', '')
        
        cve_ids = []
        if data.get('cve_id'):
            cve_ids.append(data['cve_id'])
        for identifier in data.get('identifiers', []):
            if identifier.get('type') == 'CVE':
                cve_id = identifier.get('value')
                if cve_id and cve_id not in cve_ids:
                    cve_ids.append(cve_id)
        
        severity = (data.get('severity') or 'UNKNOWN').upper()
        cvss = data.get('cvss', {}) or {}
        cvss_score = cvss.get('score')
        cvss_vector = cvss.get('vector_string')
        
        affected_packages = []
        fix_versions = {}
        
        for vuln in data.get('vulnerabilities', []):
            pkg = vuln.get('package', {})
            ecosystem = pkg.get('ecosystem', 'unknown')
            pkg_name = pkg.get('name', '')
            
            affected_packages.append({
                'ecosystem': ecosystem,
                'name': pkg_name,
                'vulnerable_version_range': vuln.get('vulnerable_version_range'),
                'first_patched_version': vuln.get('first_patched_version'),
            })
            
            patched = vuln.get('first_patched_version')
            if patched:
                patched_ver = patched.get('identifier') if isinstance(patched, dict) else patched
                if patched_ver:
                    if pkg_name not in fix_versions:
                        fix_versions[pkg_name] = []
                    if patched_ver not in fix_versions[pkg_name]:
                        fix_versions[pkg_name].append(patched_ver)
        
        references = []
        for ref in data.get('references', []):
            if isinstance(ref, str):
                references.append({'type': 'WEB', 'url': ref})
            elif isinstance(ref, dict):
                references.append({'type': ref.get('type', 'WEB'), 'url': ref.get('url', '')})
        
        return GHSAInfo(
            ghsa_id=ghsa_id,
            cve_ids=cve_ids,
            summary=data.get('summary', ''),
            description=data.get('description', ''),
            severity=severity,
            cvss_score=cvss_score,
            cvss_vector=cvss_vector,
            affected_packages=affected_packages,
            fix_versions=fix_versions,
            references=references,
            published_at=data.get('published_at'),
            updated_at=data.get('updated_at'),
            withdrawn_at=data.get('withdrawn_at'),
        )
    
    def lookup(self, lookup_key: str) -> Optional[GHSAInfo]:
        """
        Look up advisory by CVE ID or GHSA ID.
        
        Args:
            lookup_key: CVE-XXXX-XXXXX or GHSA-xxxx-xxxx-xxxx
            
        Returns:
            GHSAInfo if found, None otherwise
        """
        # Check cache first
        cached = self._get_cached(lookup_key)
        if cached:
            return cached
        
        # Try local database first (faster, no rate limit)
        info = self._fetch_from_local(lookup_key)
        
        # Fall back to API if local not available
        if not info and self.use_api:
            info = self._fetch_from_api(lookup_key)
        
        # Cache result (even None to avoid repeated lookups)
        if info:
            self._set_cached(lookup_key, info)
        
        return info
    
    def enrich_cve(self, cve_id: str, package_name: str = None) -> Dict[str, Any]:
        """
        Enrich a CVE with GHSA data.
        
        Args:
            cve_id: CVE identifier (e.g., CVE-2022-32149)
            package_name: Optional package name to get specific fix version
            
        Returns:
            Dict with enrichment data
        """
        info = self.lookup(cve_id)
        
        if not info:
            return {
                'ghsa_id': None,
                'has_fix': False,
                'fix_version': None,
                'fix_status': 'unknown',
                'references': [],
            }
        
        fix_version = info.get_fix_version(package_name)
        has_fix = info.has_fix(package_name)
        
        return {
            'ghsa_id': info.ghsa_id,
            'has_fix': has_fix,
            'fix_version': fix_version,
            'fix_status': 'fix_available' if has_fix else 'no_fix',
            'fix_versions': info.fix_versions,
            'severity': info.severity,
            'cvss_score': info.cvss_score,
            'summary': info.summary,
            'references': info.references,
            'affected_packages': info.affected_packages,
        }


# =============================================================================
# CONVENIENCE FUNCTIONS
# =============================================================================

# Global enricher instance (lazy initialized)
_enricher: Optional[GHSAEnricher] = None


def get_enricher() -> GHSAEnricher:
    """Get or create global enricher instance"""
    global _enricher
    if _enricher is None:
        _enricher = GHSAEnricher()
    return _enricher


def get_ghsa_for_cve(cve_id: str) -> Optional[str]:
    """Get GHSA ID for a CVE"""
    info = get_enricher().lookup(cve_id)
    return info.ghsa_id if info else None


def get_cve_for_ghsa(ghsa_id: str) -> List[str]:
    """Get CVE IDs for a GHSA"""
    info = get_enricher().lookup(ghsa_id)
    return info.cve_ids if info else []


def get_fix_info(cve_id: str, package_name: str = None) -> Dict[str, Any]:
    """Get fix information for a CVE"""
    return get_enricher().enrich_cve(cve_id, package_name)


def enrich_cve_findings(
    findings: List[Dict[str, Any]],
    enricher: Optional[GHSAEnricher] = None
) -> List[Dict[str, Any]]:
    """
    Enrich a list of CVE findings with GHSA data.
    
    Args:
        findings: List of finding dicts
        enricher: Optional enricher instance (uses global if not provided)
        
    Returns:
        List of enriched findings
    """
    if enricher is None:
        enricher = get_enricher()
    
    enriched = []
    
    for f in findings:
        f_enriched = dict(f)
        
        # Only enrich CVE type findings
        ftype = (f.get('type') or f.get('finding_type') or '').upper()
        if ftype != 'CVE':
            enriched.append(f_enriched)
            continue
        
        # Get CVE ID
        cve_id = f.get('id') or f.get('finding_id') or ''
        if not cve_id.startswith('CVE-'):
            enriched.append(f_enriched)
            continue
        
        # Get package name for specific fix version
        package_name = f.get('package_name') or f.get('package', '').split()[0]
        
        # Enrich with GHSA data
        ghsa_data = enricher.enrich_cve(cve_id, package_name)
        
        # Update finding with enrichment data
        if ghsa_data.get('ghsa_id'):
            f_enriched['ghsa_id'] = ghsa_data['ghsa_id']
        
        # Update fix status if we have better data
        if ghsa_data.get('has_fix'):
            f_enriched['fix_status'] = 'fix_available'
            f_enriched['fix_available'] = True
            if ghsa_data.get('fix_version'):
                f_enriched['fix_version'] = ghsa_data['fix_version']
                if not f_enriched.get('remediation'):
                    f_enriched['remediation'] = {}
                f_enriched['remediation']['fixed_in'] = ghsa_data['fix_version']
        elif ghsa_data.get('fix_status') == 'no_fix' and not f_enriched.get('fix_status'):
            f_enriched['fix_status'] = 'no_fix'
            f_enriched['fix_available'] = False
        
        # Add references
        if ghsa_data.get('references'):
            if not f_enriched.get('remediation'):
                f_enriched['remediation'] = {}
            f_enriched['remediation']['references'] = ghsa_data['references']
        
        enriched.append(f_enriched)
    
    return enriched


def setup_local_advisory_db(target_path: str = None) -> str:
    """
    Clone or update GitHub Advisory Database locally.
    
    Args:
        target_path: Target directory (default: ~/.reachable/data/advisory-database)
        
    Returns:
        Path to local database
    """
    import subprocess
    
    if target_path is None:
        target_path = str(Path.home() / '.reachable' / 'data' / 'advisory-database')
    
    target = Path(target_path)
    
    if target.exists() and (target / '.git').exists():
        # Update existing clone
        logger.info("Updating GitHub Advisory Database...")
        subprocess.run(['git', 'pull', '--quiet'], cwd=target, check=True)
    else:
        # Fresh clone
        target.parent.mkdir(parents=True, exist_ok=True)
        logger.info("Cloning GitHub Advisory Database (this may take a while)...")
        subprocess.run([
            'git', 'clone', '--depth=1',
            'https://github.com/github/advisory-database.git',
            str(target)
        ], check=True)
    
    logger.info(f"Advisory database ready at {target}")
    return str(target)
