#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.

"""
CVE Verdict System - Combines Reachability + Exploitability

Provides actionable recommendations by combining:
1. Code reachability (from static analysis)
2. Exploitability metrics (KEV, EPSS, CVSS)

Output: Clear verdict with priority tier and action timeline.
"""

from dataclasses import dataclass
from typing import Optional
from enum import Enum
import logging

# Initialize module-level logger
logger = logging.getLogger(__name__)

class VerdictLevel(Enum):
    """
    Risk levels after reachability analysis
    
    IMPORTANT: This is RISK, not SEVERITY or PRIORITY.
    - Severity = raw scanner output (CVSS, CWE category) - never changes
    - Risk = Severity × Likelihood (reachability, exploits) - what we act on
    - Priority = business scheduling term - we don't use this
    
    Risk determines SLA (compliance timeline).
    """
    CRITICAL = 1   # SLA: 1-48 hours - Reachable + actively exploited
    HIGH = 2       # SLA: 7-14 days - Reachable + high severity
    MEDIUM = 3     # SLA: 30 days - Reachable + moderate severity
    LOW = 4        # SLA: 90 days - Unreachable high/critical OR reachable low
    INFO = 5       # No SLA - Unreachable medium/low, awareness only

@dataclass
class CVEVerdict:
    """
    Combined verdict for a CVE
    
    Terminology:
    - severity: Raw CVSS severity (never changes)
    - risk: Effective risk level after reachability analysis (determines SLA)
    - verdict: Recommended action (FIX, MONITOR, ACCEPT_RISK)
    """
    cve_id: str
    
    # Inputs
    is_reachable: bool
    in_kev: bool
    epss_score: Optional[float]
    cvss_score: Optional[float]
    cvss_severity: Optional[str]  # Raw severity from CVSS
    
    # Exploit data
    exploit_db_available: bool = False
    metasploit_module: bool = False
    
    # Calculated outputs
    risk_level: VerdictLevel = VerdictLevel.INFO  # Risk after analysis
    verdict: str = "MONITOR"  # FIX, MONITOR, or ACCEPT_RISK
    verdict_name: str = ""  # Human-readable risk name
    action_timeline: str = ""  # SLA
    reasoning: str = ""
    risk_score: float = 0.0  # 0-100, combined risk metric
    
    # Legacy aliases for backward compatibility
    @property
    def verdict_level(self) -> VerdictLevel:
        """Backward compatibility alias for risk_level"""
        return self.risk_level

class VerdictEngine:
    """
    Decision engine for CVE prioritization
    
    Combines reachability analysis with exploitability metrics
    to produce actionable verdicts.
    """
    
    # Risk weights for scoring
    WEIGHT_REACHABILITY = 40  # 40% of risk score
    WEIGHT_KEV = 30           # 30% of risk score
    WEIGHT_EPSS = 20          # 20% of risk score
    WEIGHT_CVSS = 10          # 10% of risk score
    
    def calculate_verdict(
        self,
        cve_id: str,
        is_reachable: bool,
        in_kev: bool = False,
        epss_score: Optional[float] = None,
        cvss_score: Optional[float] = None,
        cvss_severity: Optional[str] = None,
        exploit_db_available: bool = False,
        metasploit_module: bool = False
    ) -> CVEVerdict:
        """
        Calculate comprehensive verdict for a CVE
        
        Args:
            cve_id: CVE identifier
            is_reachable: True if code path is reachable
            in_kev: True if in CISA KEV catalog
            epss_score: EPSS probability (0-1)
            cvss_score: CVSS score (0-10)
            cvss_severity: CVSS severity label (raw, never changes)
            exploit_db_available: True if public exploit exists
            metasploit_module: True if Metasploit module exists
            
        Returns:
            CVEVerdict with risk level, verdict action, and SLA
        """
        # Calculate combined risk score (0-100)
        risk_score = self._calculate_risk_score(
            is_reachable, in_kev, epss_score, cvss_score, 
            exploit_db_available, metasploit_module
        )
        
        # Determine risk level (Risk = Severity × Likelihood)
        risk_level, reasoning, verdict_action = self._determine_verdict_level(
            is_reachable, in_kev, epss_score, cvss_score, risk_score,
            exploit_db_available, metasploit_module, cvss_severity
        )
        
        # Get SLA timeline
        risk_name, sla_timeline = self._get_action_plan(risk_level)
        
        return CVEVerdict(
            cve_id=cve_id,
            is_reachable=is_reachable,
            in_kev=in_kev,
            epss_score=epss_score,
            cvss_score=cvss_score,
            cvss_severity=cvss_severity,
            exploit_db_available=exploit_db_available,
            metasploit_module=metasploit_module,
            risk_level=risk_level,
            verdict=verdict_action,
            verdict_name=risk_name,
            action_timeline=sla_timeline,
            reasoning=reasoning,
            risk_score=risk_score
        )
    
    def _calculate_risk_score(
        self,
        is_reachable: bool,
        in_kev: bool,
        epss_score: Optional[float],
        cvss_score: Optional[float],
        exploit_db_available: bool,
        metasploit_module: bool
    ) -> float:
        """
        Calculate combined risk score (0-100)
        
        Combines all factors with weights:
        - Reachability: 35%
        - KEV: 25%
        - EPSS: 15%
        - CVSS: 10%
        - Exploit-DB: 10%
        - Metasploit: 5%
        """
        score = 0.0
        
        # Reachability contribution (0 or 35)
        if is_reachable:
            score += 35
        
        # KEV contribution (0 or 25)
        if in_kev:
            score += 25
        
        # EPSS contribution (0-15)
        if epss_score is not None:
            score += epss_score * 15
        
        # CVSS contribution (0-10)
        if cvss_score is not None:
            score += (cvss_score / 10.0) * 10
        
        # Exploit-DB contribution (0 or 10)
        if exploit_db_available:
            score += 10
        
        # Metasploit contribution (0 or 5)
        if metasploit_module:
            score += 5
        
        return round(score, 1)
    
    def _determine_verdict_level(
        self,
        is_reachable: bool,
        in_kev: bool,
        epss_score: Optional[float],
        cvss_score: Optional[float],
        risk_score: float,
        exploit_db_available: bool,
        metasploit_module: bool,
        cvss_severity: Optional[str] = None
    ) -> tuple[VerdictLevel, str, str]:
        """
        Determine risk level with reasoning
        
        Risk = Severity × Likelihood
        - Severity comes from CVSS (numeric or string label)
        - Likelihood comes from reachability + exploits
        
        Returns:
            (VerdictLevel, reasoning_string, verdict_action)
        """
        # Helper: Check severity by string label OR numeric score (v2.9.75)
        severity_upper = (cvss_severity or '').upper()
        is_critical_severity = (cvss_score and cvss_score >= 9.0) or severity_upper == 'CRITICAL'
        is_high_severity = (cvss_score and cvss_score >= 7.0) or severity_upper in ('HIGH', 'CRITICAL')
        is_medium_severity = (cvss_score and cvss_score >= 4.0) or severity_upper in ('MEDIUM', 'HIGH', 'CRITICAL')
        
        # CRITICAL RISK: Reachable + actively exploited
        if is_reachable and in_kev:
            return (
                VerdictLevel.CRITICAL,
                "Reachable + actively exploited in wild (KEV)",
                "FIX"
            )
        
        # CRITICAL RISK: Reachable + weaponized exploit
        if is_reachable and metasploit_module:
            return (
                VerdictLevel.CRITICAL,
                "Reachable + weaponized exploit available (Metasploit)",
                "FIX"
            )
        
        # CRITICAL RISK: Reachable + public exploit + high EPSS
        if is_reachable and exploit_db_available and epss_score and epss_score > 0.5:
            return (
                VerdictLevel.CRITICAL,
                f"Reachable + public exploit + high exploitation probability (EPSS: {epss_score:.0%})",
                "FIX"
            )
        
        # HIGH RISK: Reachable + critical severity
        if is_reachable and is_critical_severity:
            sev_source = f"CVSS: {cvss_score}" if cvss_score and cvss_score >= 9.0 else f"Severity: {cvss_severity}"
            return (
                VerdictLevel.HIGH,
                f"Reachable + critical severity ({sev_source})",
                "FIX"
            )
        
        # HIGH RISK: Reachable + public exploit
        if is_reachable and exploit_db_available:
            return (
                VerdictLevel.HIGH,
                "Reachable + public exploit available (Exploit-DB)",
                "FIX"
            )
        
        # HIGH RISK: Reachable + high EPSS + high severity (v2.9.75: use severity flag)
        if is_reachable and epss_score and epss_score > 0.3 and is_high_severity:
            return (
                VerdictLevel.HIGH,
                f"Reachable + elevated exploitation risk (EPSS: {epss_score:.0%}, Severity: {cvss_severity or cvss_score})",
                "FIX"
            )
        
        # HIGH RISK: Reachable + high severity (v2.9.75: use severity string when CVSS missing)
        if is_reachable and is_high_severity:
            sev_source = f"CVSS: {cvss_score}" if cvss_score and cvss_score >= 7.0 else f"Severity: {cvss_severity}"
            return (
                VerdictLevel.HIGH,
                f"Reachable + high severity ({sev_source})",
                "FIX"
            )
        
        # MEDIUM RISK: Reachable + medium severity (v2.9.75: use severity string when CVSS missing)
        if is_reachable and is_medium_severity:
            sev_source = f"CVSS: {cvss_score}" if cvss_score and cvss_score >= 4.0 else f"Severity: {cvss_severity}"
            return (
                VerdictLevel.MEDIUM,
                f"Reachable + medium severity ({sev_source})",
                "FIX"
            )
        
        # LOW RISK: Unreachable but in KEV (verify manually)
        if not is_reachable and in_kev:
            return (
                VerdictLevel.LOW,
                "Unreachable but in KEV - verify attack vectors manually",
                "MONITOR"
            )
        
        # LOW RISK: Reachable but low severity
        if is_reachable:
            return (
                VerdictLevel.LOW,
                f"Reachable but low severity (Risk score: {risk_score})",
                "MONITOR"
            )
        
        # LOW RISK: Unreachable high/critical severity
        if not is_reachable and cvss_score and cvss_score >= 7.0:
            return (
                VerdictLevel.LOW,
                f"Severity {cvss_score} but unreachable - risk reduced to LOW",
                "MONITOR"
            )
        
        # INFO: Unreachable medium/low severity
        if not is_reachable:
            return (
                VerdictLevel.INFO,
                "Unreachable code path - awareness only",
                "ACCEPT_RISK"
            )
        
        # Default: LOW
        return (
            VerdictLevel.LOW,
            "Insufficient data for accurate risk assessment",
            "MONITOR"
        )
    
    def _get_action_plan(self, level: VerdictLevel) -> tuple[str, str]:
        """
        Get action plan for risk level
        
        Returns:
            (risk_name, sla_timeline)
        """
        action_plans = {
            VerdictLevel.CRITICAL: (
                "🔴 CRITICAL",
                "1-48 hours"
            ),
            VerdictLevel.HIGH: (
                "🟠 HIGH",
                "7-14 days"
            ),
            VerdictLevel.MEDIUM: (
                "🟡 MEDIUM",
                "30 days"
            ),
            VerdictLevel.LOW: (
                "🔵 LOW",
                "90 days"
            ),
            VerdictLevel.INFO: (
                "⚪ INFO",
                "No SLA"
            )
        }
        
        return action_plans.get(level, ("UNKNOWN", "Unknown"))
    
    def format_verdict_summary(self, verdict: CVEVerdict) -> str:
        """
        Format verdict as human-readable summary
        
        Returns:
            Multi-line formatted string
        """
        lines = []
        lines.append(f"{'=' * 70}")
        lines.append(f"CVE: {verdict.cve_id}")
        lines.append(f"{'=' * 70}")
        
        # Verdict
        lines.append(f"\n📊 VERDICT: {verdict.verdict_name}")
        lines.append(f"   Action Timeline: {verdict.action_timeline}")
        lines.append(f"   Risk Score: {verdict.risk_score}/100")
        
        # Contributing factors
        lines.append("\n🔍 Analysis:")
        lines.append(f"   Reachability: {'✅ REACHABLE' if verdict.is_reachable else '❌ UNREACHABLE'}")
        lines.append(f"   KEV Status: {'🚨 IN KEV (actively exploited)' if verdict.in_kev else '✓ Not in KEV'}")
        
        if verdict.epss_score is not None:
            lines.append(f"   EPSS Score: {verdict.epss_score:.4f} ({verdict.epss_score*100:.2f}% exploitation likelihood)")
        
        if verdict.cvss_score is not None:
            lines.append(f"   CVSS Score: {verdict.cvss_score} ({verdict.cvss_severity or 'Unknown'})")
        
        # Reasoning
        lines.append("\n💡 Reasoning:")
        lines.append(f"   {verdict.reasoning}")
        
        return '\n'.join(lines)

def main():
    """Test verdict system with example CVEs"""
    engine = VerdictEngine()
    
    print("=" * 70)
    logger.info("CVE VERDICT SYSTEM - TEST CASES")
    print("=" * 70)
    
    test_cases = [
        {
            'name': 'Worst Case: Reachable + KEV',
            'cve_id': 'CVE-2023-0001',
            'is_reachable': True,
            'in_kev': True,
            'epss_score': 0.95,
            'cvss_score': 9.8,
            'cvss_severity': 'Critical'
        },
        {
            'name': 'Best Case: Unreachable + Not KEV + Low',
            'cve_id': 'CVE-2023-0002',
            'is_reachable': False,
            'in_kev': False,
            'epss_score': 0.01,
            'cvss_score': 5.5,
            'cvss_severity': 'Medium'
        },
        {
            'name': 'Edge Case: Unreachable but in KEV',
            'cve_id': 'CVE-2023-0003',
            'is_reachable': False,
            'in_kev': True,
            'epss_score': 0.85,
            'cvss_score': 9.1,
            'cvss_severity': 'Critical'
        },
        {
            'name': 'Common: Reachable + High CVSS but low EPSS',
            'cve_id': 'CVE-2023-0004',
            'is_reachable': True,
            'in_kev': False,
            'epss_score': 0.05,
            'cvss_score': 9.5,
            'cvss_severity': 'Critical'
        },
        {
            'name': 'Tricky: Unreachable but Critical CVSS',
            'cve_id': 'CVE-2023-0005',
            'is_reachable': False,
            'in_kev': False,
            'epss_score': 0.02,
            'cvss_score': 10.0,
            'cvss_severity': 'Critical'
        }
    ]
    
    for i, test in enumerate(test_cases, 1):
        logger.info(f"\n\n{'=' * 70}")
        logger.info(f"TEST CASE {i}: {test['name']}")
        logger.info(f"{'=' * 70}")
        
        verdict = engine.calculate_verdict(
            cve_id=test['cve_id'],
            is_reachable=test['is_reachable'],
            in_kev=test['in_kev'],
            epss_score=test['epss_score'],
            cvss_score=test['cvss_score'],
            cvss_severity=test['cvss_severity']
        )
        
        logger.info(f"\n📊 VERDICT: {verdict.verdict_name}")
        logger.info(f"   Timeline: {verdict.action_timeline}")
        logger.info(f"   Risk Score: {verdict.risk_score}/100")
        logger.info(f"\n💡 Reasoning: {verdict.reasoning}")

if __name__ == '__main__':
    main()
