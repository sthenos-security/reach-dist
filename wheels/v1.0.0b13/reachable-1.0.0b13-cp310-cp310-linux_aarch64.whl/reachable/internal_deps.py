#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.

"""
REACHABLE Internal Dependency Manager

Manages an internal virtual environment for REACHABLE's Python dependencies.
This ensures REACHABLE is self-contained and doesn't require users to 
modify their system environment.

Location: ~/.reachable/venv/

Dependencies managed:
- pyyaml: K8s/Docker Compose scanning
- requests: API calls (PyPI, npm, EPSS, etc.)

Usage:
    from reachable.internal_deps import ensure_deps, get_internal_python
    
    # Ensure deps are installed (call once at startup)
    ensure_deps()
    
    # Import from internal venv
    yaml = import_from_internal('yaml')
    requests = import_from_internal('requests')
"""

import os
import sys
import subprocess
import importlib
from pathlib import Path
from typing import Optional, List
import logging

# Initialize module-level logger
logger = logging.getLogger(__name__)

# Internal venv location
REACHABLE_HOME = Path.home() / '.reachable'
INTERNAL_VENV = REACHABLE_HOME / 'venv'
INTERNAL_PYTHON = INTERNAL_VENV / 'bin' / 'python'
INTERNAL_PIP = INTERNAL_VENV / 'bin' / 'pip'
INTERNAL_SITE_PACKAGES = INTERNAL_VENV / 'lib'

# Required internal dependencies
INTERNAL_DEPS = {
    'pyyaml': '>=6.0',
    'requests': '>=2.25.0',
}

# Track if deps have been ensured this session
_deps_ensured = False
_internal_path_added = False

def get_internal_venv_path() -> Path:
    """Get path to internal venv"""
    return INTERNAL_VENV

def get_internal_python() -> Path:
    """Get path to internal Python interpreter"""
    return INTERNAL_PYTHON

def _find_site_packages() -> Optional[Path]:
    """Find the site-packages directory in internal venv"""
    if not INTERNAL_VENV.exists():
        return None
    
    lib_dir = INTERNAL_VENV / 'lib'
    if not lib_dir.exists():
        return None
    
    # Find python3.x directory
    for item in lib_dir.iterdir():
        if item.name.startswith('python'):
            site_packages = item / 'site-packages'
            if site_packages.exists():
                return site_packages
    
    return None

def _add_internal_to_path():
    """Add internal venv site-packages to sys.path"""
    global _internal_path_added
    
    if _internal_path_added:
        return
    
    site_packages = _find_site_packages()
    if site_packages and str(site_packages) not in sys.path:
        sys.path.insert(0, str(site_packages))
        _internal_path_added = True

def _create_internal_venv() -> bool:
    """Create the internal virtual environment"""
    try:
        REACHABLE_HOME.mkdir(parents=True, exist_ok=True)
        
        # Create venv
        result = subprocess.run(
            [sys.executable, '-m', 'venv', str(INTERNAL_VENV)],
            capture_output=True,
            text=True,
            timeout=60
        )
        
        if result.returncode != 0:
            logger.info(f"Failed to create internal venv: {result.stderr}")
            return False
        
        return INTERNAL_PYTHON.exists()
        
    except Exception as e:
        logger.info(f"Error creating internal venv: {e}")
        return False

def _install_deps(deps: List[str], quiet: bool = True) -> bool:
    """Install dependencies into internal venv"""
    if not INTERNAL_PIP.exists():
        return False
    
    try:
        cmd = [str(INTERNAL_PIP), 'install', '--upgrade']
        if quiet:
            cmd.append('--quiet')
        cmd.extend(deps)
        
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=120
        )
        
        return result.returncode == 0
        
    except Exception as e:
        logger.info(f"Error installing internal deps: {e}")
        return False

def _check_dep_installed(package_name: str) -> bool:
    """Check if a dependency is installed in internal venv"""
    site_packages = _find_site_packages()
    if not site_packages:
        return False
    
    # Check for package directory or .dist-info
    package_dir = site_packages / package_name.replace('-', '_')
    dist_info = list(site_packages.glob(f"{package_name.replace('-', '_')}*.dist-info"))
    
    return package_dir.exists() or len(dist_info) > 0

def ensure_deps(force: bool = False, quiet: bool = True) -> bool:
    """
    Ensure internal dependencies are installed.
    
    Call this once at startup (e.g., in cli.py main()).
    
    Args:
        force: Reinstall even if already installed
        quiet: Suppress pip output
        
    Returns:
        True if all deps available, False otherwise
    """
    global _deps_ensured
    
    if _deps_ensured and not force:
        return True
    
    # Check if venv exists
    if not INTERNAL_VENV.exists():
        if not _create_internal_venv():
            return False
    
    # Check which deps need installing
    to_install = []
    for pkg, version in INTERNAL_DEPS.items():
        # Map package names (pyyaml installs as yaml)
        check_name = 'yaml' if pkg == 'pyyaml' else pkg
        if force or not _check_dep_installed(check_name):
            to_install.append(f"{pkg}{version}")
    
    # Install missing deps
    if to_install:
        if not quiet:
            logger.info(f"Installing internal deps: {', '.join(to_install)}")
        if not _install_deps(to_install, quiet):
            return False
    
    # Add to path
    _add_internal_to_path()
    
    _deps_ensured = True
    return True

def import_from_internal(module_name: str):
    """
    Import a module from the internal venv.
    
    Ensures deps are installed first.
    
    Args:
        module_name: Name of module to import (e.g., 'yaml', 'requests')
        
    Returns:
        The imported module, or None if not available
    """
    ensure_deps()
    _add_internal_to_path()
    
    try:
        # Force reimport from new path
        if module_name in sys.modules:
            del sys.modules[module_name]
        
        return importlib.import_module(module_name)
    except ImportError:
        return None

def get_yaml():
    """Get yaml module from internal venv"""
    return import_from_internal('yaml')

def get_requests():
    """Get requests module from internal venv"""
    return import_from_internal('requests')

# Lazy-loaded modules
_yaml = None
_requests = None

def yaml():
    """Lazy-load yaml module"""
    global _yaml
    if _yaml is None:
        _yaml = get_yaml()
    return _yaml

def requests():
    """Lazy-load requests module"""
    global _requests
    if _requests is None:
        _requests = get_requests()
    return _requests

def cleanup_internal_venv():
    """Remove internal venv (for troubleshooting)"""
    import shutil
    if INTERNAL_VENV.exists():
        shutil.rmtree(INTERNAL_VENV)
        return True
    return False

def get_status() -> dict:
    """Get status of internal dependency management"""
    site_packages = _find_site_packages()
    
    status = {
        'venv_exists': INTERNAL_VENV.exists(),
        'venv_path': str(INTERNAL_VENV),
        'python_path': str(INTERNAL_PYTHON) if INTERNAL_PYTHON.exists() else None,
        'site_packages': str(site_packages) if site_packages else None,
        'deps': {}
    }
    
    for pkg, version in INTERNAL_DEPS.items():
        check_name = 'yaml' if pkg == 'pyyaml' else pkg
        status['deps'][pkg] = {
            'required': version,
            'installed': _check_dep_installed(check_name)
        }
    
    return status

if __name__ == '__main__':
    logger.info("REACHABLE Internal Dependency Manager")
    print("=" * 50)
    
    status = get_status()
    logger.info(f"Venv exists: {status['venv_exists']}")
    logger.info(f"Venv path: {status['venv_path']}")
    
    logger.info("\nDependencies:")
    for pkg, info in status['deps'].items():
        installed = "✅" if info['installed'] else "❌"
        logger.info(f"  {installed} {pkg} {info['required']}")
    
    logger.info("\nEnsuring dependencies...")
    if ensure_deps(quiet=False):
        logger.info("✅ All dependencies available")
        
        # Test imports
        y = get_yaml()
        r = get_requests()
        logger.info(f"\nyaml: {y}")
        logger.info(f"requests: {r}")
    else:
        logger.info("❌ Failed to ensure dependencies")
