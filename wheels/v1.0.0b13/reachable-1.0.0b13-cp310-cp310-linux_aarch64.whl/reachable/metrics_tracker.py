# Copyright © 2026 Sthenos Security. All rights reserved.

"""
Metrics Tracker for REACHABLE

Ensures ALL metrics have consistent breakdowns by:
- Language (Go, JavaScript, Python, etc.)
- Project/Subproject (for monorepos)

Every metric captured includes both global totals AND breakdowns.
"""

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Any
from datetime import datetime
import json
import logging

# Initialize module-level logger
logger = logging.getLogger(__name__)

@dataclass
class MetricBreakdown:
    """A single metric with required breakdowns"""
    name: str
    total: int = 0
    by_language: Dict[str, int] = field(default_factory=dict)
    by_project: Dict[str, int] = field(default_factory=dict)
    by_severity: Dict[str, int] = field(default_factory=dict)
    by_status: Dict[str, int] = field(default_factory=dict)
    timestamp: str = field(default_factory=lambda: datetime.now().isoformat())
    
    def add(self, count: int = 1, language: str = None, project: str = None, 
            severity: str = None, status: str = None):
        """Add to metric with breakdown tracking"""
        self.total += count
        if language:
            self.by_language[language] = self.by_language.get(language, 0) + count
        if project:
            self.by_project[project] = self.by_project.get(project, 0) + count
        if severity:
            self.by_severity[severity] = self.by_severity.get(severity, 0) + count
        if status:
            self.by_status[status] = self.by_status.get(status, 0) + count
    
    def format_breakdown(self, max_items: int = 5) -> str:
        """Format breakdown for display"""
        parts = []
        if self.by_language:
            lang_str = ", ".join(f"{k}: {v}" for k, v in 
                                 sorted(self.by_language.items(), key=lambda x: -x[1])[:max_items])
            parts.append(f"By Language: {lang_str}")
        if self.by_project and len(self.by_project) > 1:
            proj_str = ", ".join(f"{k}: {v}" for k, v in 
                                 sorted(self.by_project.items(), key=lambda x: -x[1])[:max_items])
            parts.append(f"By Project: {proj_str}")
        return "\n      ".join(parts) if parts else ""
    
    def to_dict(self) -> Dict:
        """Export as dictionary for JSON serialization"""
        return {
            'name': self.name,
            'total': self.total,
            'by_language': self.by_language,
            'by_project': self.by_project,
            'by_severity': self.by_severity if self.by_severity else None,
            'by_status': self.by_status if self.by_status else None,
            'timestamp': self.timestamp
        }

@dataclass 
class ScanMetrics:
    """
    Complete scan metrics with ALL breakdowns.
    
    Every metric MUST have:
    - Total count
    - Breakdown by language
    - Breakdown by project (for monorepos)
    """
    
    # Scan metadata
    scan_id: str = ""
    scan_start: str = ""
    scan_end: str = ""
    scan_duration_seconds: float = 0.0
    repository: str = ""
    
    # Step timings
    step_timings: Dict[str, float] = field(default_factory=dict)
    
    # SBOM metrics
    sbom_packages: MetricBreakdown = field(default_factory=lambda: MetricBreakdown("sbom_packages"))
    
    # Vulnerability metrics
    vulnerabilities_total: MetricBreakdown = field(default_factory=lambda: MetricBreakdown("vulnerabilities_total"))
    vulnerabilities_reachable: MetricBreakdown = field(default_factory=lambda: MetricBreakdown("vulnerabilities_reachable"))
    vulnerabilities_unreachable: MetricBreakdown = field(default_factory=lambda: MetricBreakdown("vulnerabilities_unreachable"))
    
    # Code analysis metrics
    functions_app: MetricBreakdown = field(default_factory=lambda: MetricBreakdown("functions_app"))
    functions_lib: MetricBreakdown = field(default_factory=lambda: MetricBreakdown("functions_lib"))
    functions_reachable: MetricBreakdown = field(default_factory=lambda: MetricBreakdown("functions_reachable"))
    call_edges: MetricBreakdown = field(default_factory=lambda: MetricBreakdown("call_edges"))
    entrypoints: MetricBreakdown = field(default_factory=lambda: MetricBreakdown("entrypoints"))
    
    # Security findings
    secrets: MetricBreakdown = field(default_factory=lambda: MetricBreakdown("secrets"))
    secrets_reachable: MetricBreakdown = field(default_factory=lambda: MetricBreakdown("secrets_reachable"))
    malware_packages: MetricBreakdown = field(default_factory=lambda: MetricBreakdown("malware_packages"))
    phantom_deps: MetricBreakdown = field(default_factory=lambda: MetricBreakdown("phantom_deps"))
    
    # Package health
    packages_healthy: MetricBreakdown = field(default_factory=lambda: MetricBreakdown("packages_healthy"))
    packages_risky: MetricBreakdown = field(default_factory=lambda: MetricBreakdown("packages_risky"))
    packages_critical: MetricBreakdown = field(default_factory=lambda: MetricBreakdown("packages_critical"))
    
    # Threat correlation
    composite_threats: MetricBreakdown = field(default_factory=lambda: MetricBreakdown("composite_threats"))
    attack_paths: MetricBreakdown = field(default_factory=lambda: MetricBreakdown("attack_paths"))
    
    # Exploitability
    cves_in_kev: MetricBreakdown = field(default_factory=lambda: MetricBreakdown("cves_in_kev"))
    cves_with_exploit: MetricBreakdown = field(default_factory=lambda: MetricBreakdown("cves_with_exploit"))
    
    # Verdicts (Risk levels)
    verdicts_fix_now: MetricBreakdown = field(default_factory=lambda: MetricBreakdown("verdicts_critical"))
    verdicts_fix_soon: MetricBreakdown = field(default_factory=lambda: MetricBreakdown("verdicts_high"))
    verdicts_low_risk: MetricBreakdown = field(default_factory=lambda: MetricBreakdown("verdicts_low_risk"))
    
    def to_dict(self) -> Dict:
        """Export all metrics as dictionary"""
        return {
            'scan_metadata': {
                'scan_id': self.scan_id,
                'scan_start': self.scan_start,
                'scan_end': self.scan_end,
                'scan_duration_seconds': self.scan_duration_seconds,
                'repository': self.repository,
                'step_timings': self.step_timings
            },
            'sbom': {
                'packages': self.sbom_packages.to_dict()
            },
            'vulnerabilities': {
                'total': self.vulnerabilities_total.to_dict(),
                'reachable': self.vulnerabilities_reachable.to_dict(),
                'unreachable': self.vulnerabilities_unreachable.to_dict()
            },
            'code_analysis': {
                'functions_app': self.functions_app.to_dict(),
                'functions_lib': self.functions_lib.to_dict(),
                'functions_reachable': self.functions_reachable.to_dict(),
                'call_edges': self.call_edges.to_dict(),
                'entrypoints': self.entrypoints.to_dict()
            },
            'security_findings': {
                'secrets': self.secrets.to_dict(),
                'secrets_reachable': self.secrets_reachable.to_dict(),
                'malware_packages': self.malware_packages.to_dict(),
                'phantom_deps': self.phantom_deps.to_dict()
            },
            'package_health': {
                'healthy': self.packages_healthy.to_dict(),
                'risky': self.packages_risky.to_dict(),
                'critical': self.packages_critical.to_dict()
            },
            'threat_correlation': {
                'composite_threats': self.composite_threats.to_dict(),
                'attack_paths': self.attack_paths.to_dict()
            },
            'exploitability': {
                'cves_in_kev': self.cves_in_kev.to_dict(),
                'cves_with_exploit': self.cves_with_exploit.to_dict()
            },
            'verdicts': {
                'critical': self.verdicts_fix_now.to_dict(),
                'high': self.verdicts_fix_soon.to_dict(),
                'low_risk': self.verdicts_low_risk.to_dict()
            }
        }
    
    def to_json(self, indent: int = 2) -> str:
        """Export as JSON string"""
        return json.dumps(self.to_dict(), indent=indent, default=str)

def detect_package_language(package_name: str) -> str:
    """
    Detect programming language/ecosystem from package name.
    Comprehensive detection for Go, JavaScript, Python, Java, Rust.
    """
    if not package_name:
        return "Unknown"
    pkg = package_name.lower()
    
    # Go patterns
    if pkg == 'stdlib' or pkg.startswith('go1.'):
        return "Go"
    if any(x in pkg for x in ['golang.org', 'github.com/', 'k8s.io', 'gopkg.in', 
                               'go.uber.org', 'google.golang.org']):
        return "Go"
    
    # Python patterns
    if any(x in pkg for x in ['requests', 'flask', 'django', 'numpy', 'pandas', 
                               'scipy', 'pip', 'setuptools', 'pytest', 'urllib3',
                               'cryptography', 'pillow', 'beautifulsoup', 'boto3']):
        return "Python"
    
    # Java patterns
    if any(x in pkg for x in ['springframework', 'maven', 'apache', 'javax', 
                               'log4j', 'jackson', 'hibernate', 'junit', 'gradle']):
        return "Java"
    
    # Rust patterns
    if any(x in pkg for x in ['crates.io', 'tokio', 'serde', 'cargo']):
        return "Rust"
    
    # JavaScript patterns
    if pkg.startswith('@'):
        return "JavaScript"
    js_patterns = ['next', 'react', 'vue', 'angular', 'express', 'lodash', 
                   'webpack', 'babel', 'eslint', 'typescript', 'jest', 'postcss',
                   'braces', 'micromatch', 'yargs', 'js-yaml', 'axios', 'moment',
                   'set-value', 'defaults-deep', 'expand-object', 'parse-git-config',
                   'csstools', 'sass', 'emotion', 'styled', 'tailwind']
    if any(x in pkg for x in js_patterns):
        return "JavaScript"
    
    # npm-style package names
    if '-' in pkg and '.' not in pkg and '/' not in pkg:
        return "JavaScript"
    
    # Simple lowercase names are likely npm
    if pkg.isalnum() and pkg.islower() and len(pkg) > 2:
        return "JavaScript"
    
    return "Other"

def detect_file_language(file_path: str) -> str:
    """Detect programming language from file extension"""
    if not file_path:
        return "Other"
    fp = file_path.lower()
    
    if fp.endswith(('.py', '.pyx', '.pyi')):
        return 'Python'
    elif fp.endswith(('.js', '.ts', '.jsx', '.tsx', '.mjs', '.cjs', '.vue', '.svelte')):
        return 'JavaScript'
    elif fp.endswith('.go'):
        return 'Go'
    elif fp.endswith(('.java', '.kt', '.scala', '.groovy')):
        return 'Java'
    elif fp.endswith('.rs'):
        return 'Rust'
    elif fp.endswith(('.c', '.cpp', '.cc', '.h', '.hpp')):
        return 'C/C++'
    elif fp.endswith(('.yml', '.yaml')):
        return 'YAML'
    elif fp.endswith('.json'):
        return 'JSON'
    elif fp.endswith(('.tf', '.tfvars', '.hcl')):
        return 'Terraform'
    elif fp.endswith(('.env', '.sh', '.bash', '.zsh')):
        return 'Shell/Env'
    elif fp.endswith(('.toml', '.ini', '.cfg', '.conf', '.config')):
        return 'Config'
    elif fp.endswith(('.xml', '.plist')):
        return 'XML'
    elif fp.endswith(('.html', '.htm')):
        return 'HTML'
    elif fp.endswith(('.css', '.scss', '.sass', '.less')):
        return 'CSS'
    elif fp.endswith(('.sql', '.psql')):
        return 'SQL'
    elif fp.endswith(('.md', '.markdown', '.rst', '.txt')):
        return 'Docs'
    elif 'dockerfile' in fp:
        return 'Docker'
    elif '/k8s/' in fp or '/kubernetes/' in fp or '/helm/' in fp:
        return 'Kubernetes'
    
    return 'Other'

def extract_project_from_path(file_path: str, base_dir: str = "") -> str:
    """Extract project/subproject from file path"""
    if not file_path:
        return "root"
    
    # Remove base directory prefix
    if base_dir:
        file_path = file_path.replace(base_dir, '').strip('/')
    
    parts = file_path.split('/')
    if len(parts) > 1:
        # Return first directory as project
        return parts[0]
    return "root"

def print_metric_with_breakdown(label: str, metric: MetricBreakdown, indent: str = "   "):
    """Print a metric with its breakdowns"""
    logger.info(f"{indent}{label}: {metric.total}")
    
    if metric.by_language:
        lang_parts = [f"{k}: {v}" for k, v in 
                     sorted(metric.by_language.items(), key=lambda x: -x[1])[:5]]
        logger.info(f"{indent}   By Language: {', '.join(lang_parts)}")
    
    if metric.by_project and len(metric.by_project) > 1:
        proj_parts = [f"{k}: {v}" for k, v in 
                     sorted(metric.by_project.items(), key=lambda x: -x[1])[:5]]
        logger.info(f"{indent}   By Project:  {', '.join(proj_parts)}")
    
    if metric.by_severity:
        sev_parts = [f"{k}: {v}" for k, v in 
                    sorted(metric.by_severity.items(), 
                          key=lambda x: {'CRITICAL': 0, 'HIGH': 1, 'MEDIUM': 2, 'LOW': 3}.get(x[0], 4))]
        logger.info(f"{indent}   By Severity: {', '.join(sev_parts)}")
