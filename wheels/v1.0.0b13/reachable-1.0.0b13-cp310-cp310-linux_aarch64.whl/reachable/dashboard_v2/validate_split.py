#!/usr/bin/env python3
"""
Validate dashboard component split integrity.
Ensures all components are properly injected into compiled template.
"""

import sys
import re
from pathlib import Path

from reachable.logger import logger

# Paths
base = Path(__file__).parent
components_dir = base / 'split/components'
compiled_template = base / 'split/template-shell-compiled.html'

print("=" * 80)
logger.info("DASHBOARD COMPONENT VALIDATION")
print("=" * 80)
print()

# Check compiled template exists
if not compiled_template.exists():
    logger.info(f"❌ Compiled template not found: {compiled_template}")
    logger.info("   Run: ./rebuild-template.sh")
    sys.exit(1)

compiled = compiled_template.read_text()
logger.info(f"✓ Compiled template: {len(compiled):,} bytes")
print()

# Components to validate
components = [
    ('dashboard-styles.css', 'styles/dashboard-styles.css', ['.tab-bar', '.owasp-card']),
    ('dashboard-body.html', 'dashboard-body.html', ['id="riskScore"', 'class="header"']),
    ('main.js', 'scripts/main.js', ['function renderDashboard', 'dashboardData']),
    ('tabs.js', 'scripts/tabs.js', ['function showTab']),
    ('tab-wiring.js', 'scripts/tab-wiring.js', ['DOMContentLoaded']),
    ('owasp-cards.js', 'scripts/owasp-cards.js', ['renderOWASPCards']),
]

all_valid = True
logger.info("Validating components:")

for name, path, critical_patterns in components:
    component_path = components_dir / path
    
    if not component_path.exists():
        logger.info(f"  ❌ {name}: File not found at {path}")
        all_valid = False
        continue
    
    component_content = component_path.read_text()
    component_size = len(component_content)
    
    # Check if component content exists in compiled template
    # Use a small sample to verify injection (not full content due to minification/formatting)
    sample = component_content[:200].strip()
    if sample and sample not in compiled:
        # Try checking for critical patterns instead
        patterns_found = sum(1 for p in critical_patterns if p in compiled)
        if patterns_found < len(critical_patterns):
            logger.info(f"  ⚠️  {name}: Content may not be fully injected ({patterns_found}/{len(critical_patterns)} patterns)")
            all_valid = False
        else:
            logger.info(f"  ✓ {name}: {component_size:,} bytes ({patterns_found}/{len(critical_patterns)} patterns)")
    else:
        logger.info(f"  ✓ {name}: {component_size:,} bytes (content verified)")

print()

# Check for unreplaced markers
markers = [
    '<!-- INJECTED: dashboard-styles.css -->',
    '<!-- INJECTED: dashboard-body.html -->',
    '<!-- INJECTED: main.js -->',
    '<!-- INJECTED: tabs.js -->',
    '<!-- INJECTED: tab-wiring.js -->',
    '<!-- INJECTED: owasp-cards.js -->',
    '{{STYLES}}',
    '{{SCRIPTS}}',
    '{{BODY}}',
]

logger.info("Checking for unreplaced markers:")
markers_found = []
for marker in markers:
    if marker in compiled:
        markers_found.append(marker)
        logger.info(f"  ⚠️  Found unreplaced: {marker}")
        all_valid = False

if not markers_found:
    logger.info("  ✓ No unreplaced markers")

print()

# Critical functionality checks
critical_patterns = [
    ('Dashboard data declaration', r'(window\.dashboardData|var dashboardData|let dashboardData)'),
    ('Render function', r'function renderDashboard'),
    ('Filter function', r'function applyFilters'),
    ('Tab system', r'function activateTab'),
    ('OWASP rendering', r'function renderOwaspTop10'),
]

logger.info("Critical functionality:")
for name, pattern in critical_patterns:
    found = bool(re.search(pattern, compiled))
    status = "✓" if found else "❌"
    logger.info(f"  {status} {name}")
    if not found:
        all_valid = False

print()
print("=" * 80)

if all_valid:
    logger.info("✅ VALIDATION PASSED - Dashboard is properly compiled")
    sys.exit(0)
else:
    logger.info("❌ VALIDATION FAILED - Rebuild required")
    logger.info("   Run: ./rebuild-template.sh")
    sys.exit(1)
