#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.

"""
Metrics calculation and risk level determination.
"""

from typing import Dict, Any, List


def calculate_metrics_from_summary(summary: Dict[str, int], dlp_total: int = 0, dlp_reachable: int = 0) -> Dict[str, Any]:
    """Calculate dashboard metrics from summary (v4.4.4: 8 signal types + DLP)"""
    return {
        'cves_total': summary['cves_total'],
        'cves_reachable': summary['cves_reachable'],
        'cves_critical': summary['cves_critical'],
        'cves_high': summary['cves_high'],
        'cves_no_fix': summary.get('cves_no_fix', 0),
        # P2.21 FIX: security_findings_total should NOT include CONFIG or DLP
        # CONFIG is infrastructure/IaC (separate signal)
        # DLP is data loss prevention (separate signal)
        # Security findings = CVE + SECRET + CWE only
        'security_findings_total': (summary['cves_total'] + summary['secrets_total'] + summary['cwe_total']),
        'security_findings_reachable': (summary['cves_reachable'] + summary['secrets_reachable'] + summary['cwe_reachable']),
        'security_findings_critical': summary['secrets_reachable'],  # Reachable secrets are critical
        'secrets_total': summary['secrets_total'],
        'secrets_reachable': summary['secrets_reachable'],
        'cwe_total': summary['cwe_total'],
        'cwe_reachable': summary['cwe_reachable'],
        'config_total': summary.get('config_total', 0),
        'config_unknown': summary.get('config_total', 0),  # Config always has UNKNOWN reachability
        'sast_findings': summary['cwe_total'],
        'malware_total': summary['malware_total'],
        'malware_reachable': summary['malware_total'],  # Malware always considered reachable
        'suspicious_total': summary.get('suspicious_total', 0),
        'suspicious_reachable': summary.get('suspicious_reachable', 0),
        # v4.4.4: Threat Intel (KEV/EPSS)
        'threatintel_total': summary.get('threatintel_total', 0),
        'threatintel_reachable': summary.get('threatintel_reachable', summary.get('threatintel_total', 0)),
        # v4.4.4: Phantom Libraries
        'phantom_total': summary.get('phantom_total', 0),
        'phantom_reachable': summary.get('phantom_reachable', summary.get('phantom_total', 0)),
        'packages_scanned': 0,  # TODO: Get from metrics table
        'sandbox_packages_tested': 0,
        'raw_total': (summary['cves_total'] + summary['secrets_total'] + 
                     summary['cwe_total'] + summary['malware_total'] + 
                     summary.get('suspicious_total', 0) + summary.get('config_total', 0) +
                     summary.get('threatintel_total', 0) + summary.get('phantom_total', 0) + dlp_total),
        
        # DLP metrics
        'dlp_total': dlp_total,
        'dlp_reachable': dlp_reachable,
        
        # Unknown reachability
        'secrets_unknown': summary.get('secrets_unknown', 0),
        'cwe_unknown': summary.get('cwe_unknown', 0),
        
        # ACTIONABLE counts (single source of truth)
        'actionable_immediate': summary['secrets_reachable'] + dlp_reachable,
        'actionable_fix': summary['cves_reachable'] + summary.get('secrets_unknown', 0) + summary['cwe_reachable'],
        'actionable_review': summary.get('secrets_unknown', 0) + summary.get('config_total', 0),
    }


def calculate_risk_level(
    summary: Dict[str, int], 
    metrics: Dict[str, Any], 
    issues: List[Dict[str, Any]] = None
) -> str:
    """
    Calculate overall risk level based on reachable issues.
    
    Priority (highest severity reachable issue determines posture):
    1. Any malware → CRITICAL
    2. Any CRITICAL severity reachable → CRITICAL  
    3. Any KEV or high EPSS reachable → CRITICAL (actively exploited)
    4. Any HIGH severity reachable → HIGH
    5. Any MEDIUM severity reachable → MEDIUM
    6. Otherwise → LOW
    """
    # Malware is always critical
    if summary.get('malware_total', 0) > 0 or summary.get('suspicious_total', 0) > 0:
        return 'CRITICAL'
    
    # Check for actively exploited vulnerabilities (KEV/EPSS amplifiers)
    if metrics.get('kev_total', 0) > 0 or metrics.get('epss_high', 0) > 0:
        return 'CRITICAL'
    
    # Count reachable issues by severity
    issues_list = issues or []
    reachable_critical = 0
    reachable_high = 0
    reachable_medium = 0
    
    for issue in issues_list:
        if issue.get('reachability_state') == 'reachable' or issue.get('is_reachable'):
            sev = (issue.get('severity') or 'MEDIUM').upper()
            if sev == 'CRITICAL':
                reachable_critical += 1
            elif sev == 'HIGH':
                reachable_high += 1
            elif sev == 'MEDIUM':
                reachable_medium += 1
    
    # Determine posture based on highest reachable severity
    if reachable_critical > 0:
        return 'CRITICAL'
    if reachable_high > 0:
        return 'HIGH'
    if reachable_medium > 0:
        return 'MEDIUM'
    
    return 'LOW'


def format_summary(summary: Dict[str, int], dlp_total: int = 0) -> Dict[str, str]:
    """Format summary for display (v4.4.0 + DLP)"""
    return {
        'cves': f"{summary['cves_total']} total, {summary['cves_reachable']} reachable",
        'cves_no_fix': f"{summary.get('cves_no_fix', 0)} without fix",
        'security_findings': f"{summary['cves_total'] + summary['secrets_total'] + summary['cwe_total'] + summary.get('config_total', 0) + dlp_total} total",
        'secrets': f"{summary['secrets_total']} secrets",
        'config': f"{summary.get('config_total', 0)} config issues",
        'cwe': f"{summary['cwe_total']} code weaknesses (CWE)",
        'malware': f"{summary['malware_total']} malicious packages",
        'suspicious': f"{summary.get('suspicious_total', 0)} suspicious packages",
    }
