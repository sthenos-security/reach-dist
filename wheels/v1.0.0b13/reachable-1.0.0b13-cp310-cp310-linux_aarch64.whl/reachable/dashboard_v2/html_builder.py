#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.

"""
HTML generation for dashboard.
Handles template loading, logo setup, and HTML creation.

Auto-build: If running from source and template is missing/outdated,
automatically rebuilds from components before loading.
"""

import json
import os
import shutil
from pathlib import Path
from typing import Dict, Any

from .utils import get_version

# Auto-rebuild disabled temporarily due to import issues
# try:
#     from .auto_rebuild import ensure_dashboard_built
#     ensure_dashboard_built()
# except Exception as e:
#     import sys
#     print(f"⚠️  Dashboard auto-rebuild check failed: {e}", file=sys.stderr)


# Path constants
MODULE_DIR = Path(__file__).parent
ASSETS_DIR = MODULE_DIR.parent / 'assets'
LOGO_PATH = ASSETS_DIR / 'logo.png'
LOGO_PATH_FALLBACK = ASSETS_DIR / 'sthenos-logo-cropped.png'
CENTRAL_ASSETS_DIR = Path.home() / '.reachable' / 'assets'


def setup_logo(dashboard_dir: Path):
    CENTRAL_ASSETS_DIR.mkdir(parents=True, exist_ok=True)
    central_logo = CENTRAL_ASSETS_DIR / 'logo.png'
    if not central_logo.exists():
        if LOGO_PATH.exists():
            shutil.copy(LOGO_PATH, central_logo)
        elif LOGO_PATH_FALLBACK.exists():
            shutil.copy(LOGO_PATH_FALLBACK, central_logo)
    dashboard_logo = dashboard_dir / 'logo.png'
    if dashboard_logo.exists() or dashboard_logo.is_symlink():
        dashboard_logo.unlink()
    if central_logo.exists():
        try:
            os.symlink(central_logo, dashboard_logo)
        except OSError:
            shutil.copy(central_logo, dashboard_logo)


def create_index_html(dashboard_dir: Path, data: Dict[str, Any]):
    """Create index.html from template with embedded data (for file:// support)"""
    index_path = dashboard_dir / 'index.html'
    setup_logo(dashboard_dir)
    
    # _load_template() will raise RuntimeError if template doesn't exist
    template = _load_template()
    
    try:
        version = get_version()
        data['version'] = version
        template = template.replace('{{VERSION}}', version)
        
        # CRITICAL FIX: Properly escape JSON for embedding in HTML/JavaScript context
        # ensure_ascii=True prevents unicode issues, then we escape </script> sequences
        data_json = json.dumps(data, default=str, ensure_ascii=True)
        # Escape any </script> or </SCRIPT> that might appear in the JSON data
        data_json = data_json.replace('</script>', r'<\/script>').replace('</SCRIPT>', r'<\/SCRIPT>')
        
        # v4.6.8 FIX: Inject data BEFORE scripts run, not after!
        # renderDashboard() is called during script execution and needs dashboardData to exist.
        # We inject right after <body> so data is available before any scripts execute.
        # v4.6.11 FIX: Use window.dashboardData to ensure global scope
        data_script = f'''<body>
<script>
// Embedded dashboard data - MUST be before scripts that use it (file:// protocol support)
// Use window.dashboardData to ensure global scope and prevent main.js from overwriting
window.dashboardData = {data_json};
var dashboardData = window.dashboardData;  // Alias for backward compatibility
</script>'''
        
        # Replace the first <body> tag (handles both <body> and <body> with attributes)
        # v4.6.10 FIX: Use lambda to avoid regex interpreting backslashes in JSON as escape sequences
        import re
        template = re.sub(r'<body[^>]*>', lambda m: data_script, template, count=1)
        index_path.write_text(template)
        
        # Verify the file was actually created
        if not index_path.exists():
            raise RuntimeError(f"Failed to create {index_path} - write_text() succeeded but file doesn't exist")
            
    except re.error as e:
        # Regex error - likely escaping issue
        raise RuntimeError(
            f"Dashboard generation failed due to regex error: {e}. "
            "This usually indicates an escaping issue in the data. "
            "Check for special characters in file paths or descriptions."
        ) from e
    except json.JSONDecodeError as e:
        # JSON encoding error
        raise RuntimeError(
            f"Dashboard generation failed - cannot encode data as JSON: {e}"
        ) from e
    except Exception as e:
        # Any other error
        raise RuntimeError(
            f"Dashboard generation failed unexpectedly: {type(e).__name__}: {e}"
        ) from e


def _load_template() -> str:
    """Load compiled template - NO FALLBACKS"""
    # v4.6.9+: ONLY use compiled template from split/template-shell-compiled.html
    # If template doesn't exist, FAIL HARD - user must run rebuild-template.sh
    TEMPLATE_COMPILED_PATH = MODULE_DIR / 'split' / 'template-shell-compiled.html'
    
    if not TEMPLATE_COMPILED_PATH.exists():
        raise RuntimeError(
            f"Compiled template not found at {TEMPLATE_COMPILED_PATH}\n"
            "Run './rebuild-template.sh' in reachable/dashboard_v2/ to build it."
        )
    
    return TEMPLATE_COMPILED_PATH.read_text()


def create_fallback_html(path: Path):
    """Create minimal fallback dashboard"""
    html = '''<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>REACHABLE Security Dashboard</title>
    <style>
        body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; background: #0f172a; color: #e2e8f0; padding: 20px; margin: 0; }
        .header { background: linear-gradient(90deg, #1e40af 0%, #7c3aed 100%); padding: 20px; border-radius: 12px; margin-bottom: 20px; }
        .header h1 { margin: 0; font-size: 24px; }
        .error { background: #dc2626; padding: 20px; border-radius: 12px; margin: 20px 0; }
        .card { background: #1e293b; padding: 20px; border-radius: 12px; margin: 10px 0; }
        table { width: 100%; border-collapse: collapse; }
        th, td { padding: 10px; text-align: left; border-bottom: 1px solid #334155; }
        th { color: #94a3b8; }
        .badge { display: inline-block; padding: 2px 8px; border-radius: 4px; font-size: 12px; font-weight: 500; }
        .badge-critical { background: #dc2626; color: white; }
        .badge-high { background: #f59e0b; color: black; }
        .badge-medium { background: #eab308; color: black; }
        .badge-low { background: #22c55e; color: white; }
    </style>
</head>
<body>
    <div class="header"><h1>REACHABLE Security Dashboard</h1><p id="scanInfo">Loading...</p></div>
    <div id="errorContainer"></div>
    <div class="card"><h2>Summary</h2><div id="summaryContainer">Loading...</div></div>
    <div class="card"><h2>Findings</h2><table><thead><tr><th>ID</th><th>Type</th><th>Severity</th><th>Description</th></tr></thead><tbody id="findingsTable"></tbody></table></div>
    <script>
        fetch('data.json').then(r => r.json()).then(data => {
            document.getElementById('scanInfo').textContent = data.scan.display + ' | Risk: ' + data.risk_level;
            document.getElementById('summaryContainer').innerHTML = '<p>CVEs: '+data.summary.cves+'</p><p>Secrets: '+data.summary.secrets+'</p>';
            const tbody = document.getElementById('findingsTable');
            data.findings.slice(0,50).forEach(f => { tbody.innerHTML += '<tr><td>'+f.id+'</td><td>'+f.type+'</td><td>'+f.severity+'</td><td>'+(f.description||'').substring(0,100)+'</td></tr>'; });
        }).catch(err => { document.getElementById('errorContainer').innerHTML = '<div class="error"><h3>Failed to load</h3><p>'+err.message+'</p></div>'; });
    </script>
</body>
</html>'''
    path.write_text(html)
