/* === Tabs wiring (guaranteed) === */
(function() {
  const tabs = document.querySelectorAll('.tab');
  const pages = document.querySelectorAll('.tab-page');
  if (!tabs.length || !pages.length) return;

  function activate(tabEl) {
    tabs.forEach(t => t.classList.remove('active'));
    pages.forEach(p => p.classList.remove('active'));
    tabEl.classList.add('active');
    const key = tabEl.dataset.tab;
    const page = document.getElementById(`tab-${key}`);
    if (page) page.classList.add('active');
  }

  tabs.forEach(t => t.addEventListener('click', () => activate(t)));

  // Ensure exactly one active page on load
  const firstActive = document.querySelector('.tab.active') || tabs[0];
  activate(firstActive);
  
  // === GLOBAL FUNCTION: activateTab(tabId) ===
  // Called by onclick handlers in Action Required section
  // tabId should be like 'tab-security-issues' (with 'tab-' prefix)
  window.activateTab = function(tabId) {
    // Strip 'tab-' prefix to get the data-tab value
    const key = tabId.replace(/^tab-/, '');
    const tabEl = document.querySelector(`.tab[data-tab="${key}"]`);
    if (tabEl) {
      activate(tabEl);
    } else {
      console.warn('activateTab: Tab not found for', tabId);
    }
  };
})();
