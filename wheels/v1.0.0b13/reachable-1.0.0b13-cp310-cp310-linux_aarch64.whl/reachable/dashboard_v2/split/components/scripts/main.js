// dashboardData is injected by html_builder.py before this script loads
// Don't overwrite it if it already exists
if (typeof dashboardData === 'undefined') {
    var dashboardData = null;
}
let allIssues = [];

    // === NULL-SAFE DOM HELPERS (added v4.6.4 for robustness) ===
    function setEl(id, val) {
        const el = document.getElementById(id);
        if (el) el.textContent = val;
    }
    function setHTML(id, val) {
        const el = document.getElementById(id);
        if (el) el.innerHTML = val;
    }
    function setVal(id, val) {
        const el = document.getElementById(id);
        if (el) el.value = val;
    }
    function setStyle(id, prop, val) {
        const el = document.getElementById(id);
        if (el) el.style[prop] = val;
    }
    function addClass(id, cls) {
        const el = document.getElementById(id);
        if (el) el.classList.add(cls);
    }
    function removeClass(id, cls) {
        const el = document.getElementById(id);
        if (el) el.classList.remove(cls);
    }
    // === END NULL-SAFE DOM HELPERS ===

    // === CALL GRAPH VISUALIZATION ===
    function buildCallGraphViz(issue) {
        if (!issue.call_path || !Array.isArray(issue.call_path) || issue.call_path.length === 0) {
            return '<div style="color:#64748b;font-size:12px;">No call path available</div>';
        }
        
        let html = '<div style="background:#0f172a;border-radius:8px;padding:16px;margin-top:12px;">';
        html += '<div style="color:#94a3b8;font-size:11px;font-weight:600;margin-bottom:12px;">CALL GRAPH</div>';
        
        for (let i = 0; i < issue.call_path.length; i++) {
            const node = issue.call_path[i];
            const isLast = i === issue.call_path.length - 1;
            const isFirst = i === 0;
            
            // Node
            html += '<div style="display:flex;align-items:center;margin-bottom:8px;">';
            
            // Depth indicator
            html += '<div style="width:' + (i * 20) + 'px;"></div>';
            
            // Icon
            if (isFirst) {
                html += '<span style="color:#22c55e;margin-right:8px;">🚪</span>';
            }
            
            // Icon
            if (isFirst) {
                html += '<span style="color:#22c55e;margin-right:8px;">🚪</span>';
            } else if (isLast) {
                html += '<span style="color:#ef4444;margin-right:8px;">💥</span>';
            } else {
                html += '<span style="color:#60a5fa;margin-right:8px;">→</span>';
            }
            
            // Function name
            const funcName = node.function || node.name || 'unknown';
            const file = node.file || node.filename || '';
            const line = node.line || '';
            
            html += '<div style="flex:1;">';
            html += '<div style="color:#e2e8f0;font-size:12px;font-weight:600;">' + funcName + '</div>';
            if (file) {
                html += '<div style="color:#64748b;font-size:10px;">' + file;
                if (line) html += ':' + line;
                html += '</div>';
            }
            html += '</div>';
            html += '</div>';
            
            // Arrow connector
            if (!isLast) {
                html += '<div style="margin-left:' + ((i+1) * 20) + 'px;color:#334155;font-size:10px;margin-bottom:4px;">↓</div>';
            }
        }
        
        html += '</div>';
        return html;
    }
    
    // Add call graph to issue detail expansion
    function showIssueDetail(issue) {
        const detailHTML = buildCallGraphViz(issue);
        // Insert into details area
        const detailEl = document.getElementById('issueDetail_' + issue.id);
        if (detailEl) {
            detailEl.innerHTML = detailHTML;
            detailEl.style.display = 'block';
        }
    }
    

        
        // GRC SLA timelines (in hours)
        const GRC_SLA_TIMELINES = {
            'default':          { CRITICAL: 24,  HIGH: 168,  MEDIUM: 720,  LOW: 2160 },
            // International
            'iso27001':         { CRITICAL: 72,  HIGH: 720,  MEDIUM: 2160, LOW: 4320 },
            'soc2':             { CRITICAL: 72,  HIGH: 720,  MEDIUM: 2160, LOW: null },
            // Industry
            'pci-dss':          { CRITICAL: 24,  HIGH: 720,  MEDIUM: 2160, LOW: 4320 },
            'hipaa':            { CRITICAL: 48,  HIGH: 720,  MEDIUM: 1440, LOW: 4320 },
            // US Federal
            'fedramp-high':     { CRITICAL: 24,  HIGH: 720,  MEDIUM: 2160, LOW: 4320 },
            'fedramp-moderate': { CRITICAL: 72,  HIGH: 720,  MEDIUM: 2160, LOW: 8760 },
            'fisma-high':       { CRITICAL: 24,  HIGH: 720,  MEDIUM: 2160, LOW: 4320 },
            'fisma-moderate':   { CRITICAL: 72,  HIGH: 720,  MEDIUM: 2160, LOW: 8760 },
            'nist-800-53':      { CRITICAL: 24,  HIGH: 720,  MEDIUM: 2160, LOW: 4320 },
            'nist-800-171':     { CRITICAL: 72,  HIGH: 720,  MEDIUM: 2160, LOW: 4320 },
            // Defense
            'cmmc-l2':          { CRITICAL: 72,  HIGH: 720,  MEDIUM: 2160, LOW: 4320 },
            'cmmc-l3':          { CRITICAL: 24,  HIGH: 720,  MEDIUM: 2160, LOW: 4320 },
            'disa-stig':        { CRITICAL: 24,  HIGH: 720,  MEDIUM: 2160, LOW: 4320 },
        };
        
        // Compliance framework link generators
        const complianceLinkGenerators = {
            'OWASP': (code) => {
                const mapping = {
                    'A01:2021': 'https://owasp.org/Top10/A01_2021-Broken_Access_Control/',
                    'A02:2021': 'https://owasp.org/Top10/A02_2021-Cryptographic_Failures/',
                    'A03:2021': 'https://owasp.org/Top10/A03_2021-Injection/',
                    'A04:2021': 'https://owasp.org/Top10/A04_2021-Insecure_Design/',
                    'A05:2021': 'https://owasp.org/Top10/A05_2021-Security_Misconfiguration/',
                    'A06:2021': 'https://owasp.org/Top10/A06_2021-Vulnerable_and_Outdated_Components/',
                    'A07:2021': 'https://owasp.org/Top10/A07_2021-Identification_and_Authentication_Failures/',
                    'A08:2021': 'https://owasp.org/Top10/A08_2021-Software_and_Data_Integrity_Failures/',
                    'A09:2021': 'https://owasp.org/Top10/A09_2021-Security_Logging_and_Monitoring_Failures/',
                    'A10:2021': 'https://owasp.org/Top10/A10_2021-Server-Side_Request_Forgery_%28SSRF%29/',
                };
                return mapping[code] || null;
            },
            // NIST Family
            'NIST-800-53': (ctrl) => `https://csrc.nist.gov/projects/cprt/catalog#/cprt/framework/version/SP_800_53_5_1_0/home?element=${ctrl}`,
            'NIST-800-171': () => 'https://csrc.nist.gov/pubs/sp/800/171/r3/final',
            // Federal
            'FedRAMP': (ctrl) => `https://csrc.nist.gov/projects/cprt/catalog#/cprt/framework/version/SP_800_53_5_1_0/home?element=${ctrl}`,
            'FEDRAMP': (ctrl) => `https://csrc.nist.gov/projects/cprt/catalog#/cprt/framework/version/SP_800_53_5_1_0/home?element=${ctrl}`,
            'FISMA': (ctrl) => `https://csrc.nist.gov/projects/cprt/catalog#/cprt/framework/version/SP_800_53_5_1_0/home?element=${ctrl}`,
            'CISA-BOD': (bod) => `https://www.cisa.gov/news-events/directives/${bod.toLowerCase()}`,
            // Defense
            'CMMC': () => 'https://dodcio.defense.gov/CMMC/',
            'DISA-STIG': () => 'https://public.cyber.mil/stigs/',
            // Industry
            'HIPAA': (sec) => `https://www.law.cornell.edu/cfr/text/45/${sec.split('(')[0]}`,
            'PCI-DSS': () => 'https://www.pcisecuritystandards.org/document_library/',
            'SOC2': () => 'https://www.aicpa-cima.com/topic/audit-assurance/audit-and-assurance-greater-than-soc-2',
            // International
            'ISO27001': () => 'https://www.iso.org/standard/27001',
            // CWE
            'CWE-TOP-25': (cwe) => `https://cwe.mitre.org/data/definitions/${cwe.replace('CWE-', '')}.html`,
        };
        
        function getComplianceLink(framework, code) {
            const gen = complianceLinkGenerators[framework];
            return gen ? gen(code) : null;
        }
        
        function renderComplianceTag(framework, codes) {
            const codeArr = Array.isArray(codes) ? codes : [codes];
            return codeArr.map(code => {
                const link = getComplianceLink(framework, code);
                if (link) {
                    return `<a href="${link}" class="compliance-tag compliance-link" target="_blank" title="View ${framework} ${code}">${framework}: ${code}</a>`;
                }
                return `<span class="compliance-tag">${framework}: ${code}</span>`;
            }).join('');
        }
        
        // Normalize Semgrep severity (ERROR→CRITICAL, WARNING→HIGH)
        // P2.20-A6 FIX: Removed INFO→LOW mapping
        function normalizeSeverity(sev) {
            if (!sev || sev === 'Unknown') return sev || 'Unknown';  // Preserve Unknown
            const s = sev.toUpperCase();
            if (s === 'ERROR') return 'CRITICAL';
            if (s === 'WARNING') return 'HIGH';
            return s;
        }

        // v4.6.0: Normalize issue types for consistent UI buckets
        // P2.20 Fix 4: Use "Config" terminology (database uses lowercase 'config')
        function normalizeIssueType(typeRaw) {
            const t = String(typeRaw || '').trim().toUpperCase();

            // Config normalization (database uses 'config')
            if (t === 'CONFIG' || t === 'IAC' || t === 'INFRA' || t === 'INFRASTRUCTURE') return 'Config';

            // Keep existing canonical types stable
            if (t === 'CVE') return 'CVE';
            if (t === 'CWE') return 'CWE';
            if (t === 'SECRET' || t === 'SECRETS') return 'SECRET';
            if (t === 'MALWARE') return 'MALWARE';
            if (t === 'SUSPICIOUS') return 'SUSPICIOUS';
            if (t === 'PHANTOM') return 'PHANTOM';
            if (t === 'THREATINTEL') return 'THREATINTEL';

            // Default: preserve original value (but avoid empty)
            return typeRaw || 'UNKNOWN';
        }
        
        function fmt(n) { return (n || 0).toLocaleString(); }
        function pctFiltered(raw, reach) { 
            if (!raw || raw === 0) return ''; 
            const pct = ((raw - reach) / raw * 100).toFixed(1);
            return `(${pct}% filtered)`; 
        }
        
        // v4.4.6: Simplified SLA - just show suggested remediation time, no countdown
        // P2.20 Fix 2: Add Unknown severity handling
        function getSlaInfo(severity) {
            const slaMap = {
                'CRITICAL': { display: '24 hours', class: 'sla-critical' },
                'HIGH': { display: '7 days', class: 'sla-high' },
                'MEDIUM': { display: '30 days', class: 'sla-medium' },
                'LOW': { display: '90 days', class: 'sla-low' },
                'Unknown': { display: 'ASSESS', class: 'sla-unknown' }  // NEW: Grype unknown severity
            };
            return slaMap[severity] || { display: 'N/A', class: '' };
        }
        
        // P2.20 Fix 6: Handle Config variants in reachability check
        function getReachabilityState(finding) {
            // Config findings have UNKNOWN reachability (handle all variants)
            if (finding.type === 'Config' || finding.type === 'CONFIG' || finding.type === 'config') return 'unknown';
            if (finding.reachability_state) return finding.reachability_state;
            if (finding.is_reachable === true) return 'reachable';
            if (finding.is_reachable === false) return 'not_reachable';
            return 'unknown';
        }
        
        function renderDashboard() {
            const d = dashboardData;
            setEl('versionDisplay', `v${d.version || '4.5.8'}`);
            
            const scan = d.scan || {};
            
            // Populate exec header (v4.5.9: Enhanced repo/commit panel)
            const execRepoEl = document.getElementById('execRepo');
            const execBranchEl = document.getElementById('execBranch');
            const execCommitEl = document.getElementById('execCommit');
            const execDateEl = document.getElementById('execDate');
            const execGithubLink = document.getElementById('execGithubLink');
            const scanDateEl = document.getElementById('scanDate');
            const scanFirstEl = document.getElementById('scanFirst');
            const scanNumberEl = document.getElementById('scanNumber');
            
            // Repo name (just the name, not the full display)
            if (execRepoEl) execRepoEl.textContent = scan.repository || 'Unknown';
            
            // Branch badge
            if (execBranchEl) execBranchEl.textContent = scan.branch || 'main';
            
            // Commit hash
            if (execCommitEl) execCommitEl.textContent = scan.commit ? scan.commit.substring(0, 8) : '';
            
            // Date
            if (execDateEl) execDateEl.textContent = scan.date || new Date().toLocaleDateString();
            
            // GitHub link (show/hide based on availability)
            if (execGithubLink) {
                if (scan.github_url) {
                    execGithubLink.href = scan.github_url;
                    execGithubLink.classList.remove('hidden');
                } else {
                    execGithubLink.classList.add('hidden');
                }
            }
            
            // Scan metadata - extract from scan_history, repo_metadata, or URL path
            const repoMeta = d.repo_metadata || {};
            let scanDateStr = '-';
            let firstScanStr = '-';
            let scanNumStr = '-';
            
            // Try 1: Get scan date from scan_history (most accurate)
            if (d.scan_history && d.scan_history.length > 0) {
                const latestScan = d.scan_history[d.scan_history.length - 1];
                const firstScan = d.scan_history[0];
                if (latestScan.timestamp) {
                    scanDateStr = latestScan.timestamp.split(' ')[0];
                }
                if (firstScan.timestamp) {
                    firstScanStr = firstScan.timestamp.split(' ')[0];
                }
                scanNumStr = `#${d.scan_history.length}`;
            }
            
            // Try 2: Get from repo_metadata
            if (scanDateStr === '-' && repoMeta.first_scan) {
                firstScanStr = repoMeta.first_scan;
            }
            if (scanNumStr === '-' && repoMeta.scan_number) {
                scanNumStr = `#${repoMeta.scan_number}`;
            }
            
            // Try 3: Extract scan date from URL path (format: .../20260113-190306-xxxxx/dashboard/)
            if (scanDateStr === '-') {
                const pathMatch = window.location.pathname.match(/\/([0-9]{8})-[0-9]{6}-[a-f0-9]+\/dashboard/);
                if (pathMatch) {
                    const dateStr = pathMatch[1]; // 20260113
                    scanDateStr = `${dateStr.slice(0,4)}-${dateStr.slice(4,6)}-${dateStr.slice(6,8)}`;
                    // If no first scan, use same date (assume first scan)
                    if (firstScanStr === '-') firstScanStr = scanDateStr;
                    if (scanNumStr === '-') scanNumStr = '#1';
                }
            }
            
            // Try 4: Use today's date as last resort
            if (scanDateStr === '-') {
                scanDateStr = new Date().toISOString().split('T')[0];
            }
            
            if (scanDateEl) scanDateEl.textContent = scanDateStr;
            if (scanFirstEl) scanFirstEl.textContent = firstScanStr;
            if (scanNumberEl) scanNumberEl.textContent = scanNumStr;
            
            // Populate breakdown fields
            const scanTimeEl = document.getElementById('scanTime');
            const scanAgeEl = document.getElementById('scanAge');
            const scanFreqEl = document.getElementById('scanFreq');
            
            // Scan time (from scan_history or URL)
            if (scanTimeEl) {
                let timeStr = '';
                if (d.scan_history && d.scan_history.length > 0) {
                    const ts = d.scan_history[d.scan_history.length - 1].timestamp;
                    if (ts && ts.includes(' ')) {
                        timeStr = ts.split(' ')[1].substring(0, 5); // HH:MM
                    }
                } else {
                    // Extract from URL: 20260113-214645-xxx
                    const timeMatch = window.location.pathname.match(/[0-9]{8}-([0-9]{2})([0-9]{2})([0-9]{2})-/);
                    if (timeMatch) {
                        timeStr = `${timeMatch[1]}:${timeMatch[2]}`;
                    }
                }
                scanTimeEl.textContent = timeStr || '';
            }
            
            // Scan age (days since first scan)
            if (scanAgeEl && firstScanStr !== '-') {
                const firstDate = new Date(firstScanStr);
                const today = new Date();
                const diffDays = Math.floor((today - firstDate) / (1000 * 60 * 60 * 24));
                if (diffDays === 0) {
                    scanAgeEl.textContent = 'Today';
                } else if (diffDays === 1) {
                    scanAgeEl.textContent = '1 day ago';
                } else {
                    scanAgeEl.textContent = `${diffDays} days ago`;
                }
            }
            
            // Scan frequency hint
            if (scanFreqEl && d.scan_history && d.scan_history.length > 1) {
                // Count scans today
                const todayStr = new Date().toISOString().split('T')[0];
                const scansToday = d.scan_history.filter(s => s.timestamp && s.timestamp.startsWith(todayStr)).length;
                if (scansToday > 1) {
                    scanFreqEl.textContent = `+${scansToday - 1} today`;
                } else {
                    scanFreqEl.textContent = `of ${d.scan_history.length} total`;
                }
            } else if (scanFreqEl) {
                scanFreqEl.textContent = '';
            }
            
            // Calculate counts from issues
            const issues = d.issues || [];
            const reachable = issues.filter(f => getReachabilityState(f) === 'reachable');
            const criticalReach = reachable.filter(f => normalizeSeverity(f.severity) === 'CRITICAL').length;
            const highReach = reachable.filter(f => normalizeSeverity(f.severity) === 'HIGH').length;
            const mediumReach = reachable.filter(f => normalizeSeverity(f.severity) === 'MEDIUM').length;
            
            const m = d.metrics || {};
            
            // Malware count (v4.5.3: combined)
            const totalMalware = (m.suspicious_total || 0) + (m.malware_total || 0);
            
            // v4.6.6: UNIFIED COUNTING - Calculate totals from issues array for consistency
            // This ensures Funnel, Signal Quality table, and Trends all use the same data
            
            // Count all issues by type and reachability state from the issues array
            const countByTypeAndReach = (type, reachState) => {
                return issues.filter(f => {
                    const t = (f.type || '').toUpperCase();
                    const typeMatch = type === 'ALL' || t === type || 
                        (type === 'MALWARE' && (t === 'MALWARE' || t === 'SUSPICIOUS'));
                    if (!typeMatch) return false;
                    if (reachState === 'ALL') return true;
                    return getReachabilityState(f) === reachState;
                }).length;
            };
            
            // Get unreachable count for noise reduction calculation (matches Signal Quality table)
            const getUnreachableCount = (type) => countByTypeAndReach(type, 'not_reachable');
            const getTotalCount = (type) => countByTypeAndReach(type, 'ALL');
            
            // Calculate noise reduction as unreachable/total (same formula as Signal Quality table)
            // This is the TRUE noise reduction - issues we filtered OUT
            const calcNoiseReduction = (total, unreach) => {
                if (total === 0) return 0;
                return ((unreach / total) * 100).toFixed(1);
            };
            
            // P2.50 CRITICAL: Read ALL funnel values from d.funnel (database = single source of truth)
            // NO calculations here - just display what the database computed
            const funnel = d.funnel || {};
            const rawSignals = funnel.raw_signals || {};
            const reachSignals = funnel.reachable_signals || {};
            const unknownSignals = funnel.unknown_signals || {};
            const unreachSignals = funnel.unreachable_signals || {};
            
            // Totals from pre-computed funnel
            const totalAllIssues = funnel.raw_total || 0;
            const totalReachable = funnel.reachable_total || 0;
            const totalUnreachable = totalAllIssues - totalReachable;
            const unifiedNoiseReduction = funnel.noise_reduction_pct || 0;
            
            // Update funnel display elements with pre-computed values
            const reductionPctEl = document.getElementById('reductionPct');
            const reductionPercentageEl = document.getElementById('reductionPercentage');
            const reductionDetailEl = document.getElementById('reductionDetail');
            if (reductionPctEl) reductionPctEl.textContent = `${unifiedNoiseReduction}%`;
            if (reductionPercentageEl) reductionPercentageEl.textContent = `${unifiedNoiseReduction}%`;
            if (reductionDetailEl) reductionDetailEl.textContent = `${fmt(totalUnreachable)} of ${fmt(totalAllIssues)} issues filtered as unreachable`;
            
            // Funnel - Raw signals (read from d.funnel.raw_signals)
            const rawCves = rawSignals.CVE || 0;
            const rawSecrets = rawSignals.SECRET || 0;
            const rawCwe = rawSignals.CWE || 0;
            const rawConfig = rawSignals.CONFIG || 0;
            const rawAi = rawSignals.AI || 0;
            const rawDlp = rawSignals.DLP || 0;
            // Legacy signals (not in new funnel structure - keep 0)
            const rawMalware = rawSignals.MALWARE || 0;
            const rawSuspicious = rawSignals.SUSPICIOUS || 0;
            const rawPhantom = rawSignals.PHANTOM || 0;
            
            setEl('rawCves', fmt(rawCves));
            setEl('rawMalwareStatic', fmt(rawMalware));
            setEl('rawMalwareDynamic', fmt(rawSuspicious));
            setEl('rawSecrets', fmt(rawSecrets));
            setEl('rawCwe', fmt(rawCwe));
            setEl('rawConfig', fmt(rawConfig));
            setEl('rawPhantom', fmt(rawPhantom));
            setEl('rawAi', fmt(rawAi));
            setEl('rawDlp', fmt(rawDlp));
            setEl('rawTotal', fmt(totalAllIssues));
            
            // v4.5.0: Packages scanned (from health analysis)
            const packagesScanned = m.packages_scanned || 0;
            const packagesScannedEl = document.getElementById('packagesScanned');
            if (packagesScannedEl) packagesScannedEl.textContent = fmt(packagesScanned);
            
            // Funnel - Reachable signals (read from d.funnel.reachable_signals)
            const reachCves = reachSignals.CVE || 0;
            const reachSecrets = reachSignals.SECRET || 0;
            const reachCwe = reachSignals.CWE || 0;
            const reachConfig = reachSignals.CONFIG || 0;
            const reachAi = reachSignals.AI || 0;
            const reachDlp = reachSignals.DLP || 0;
            // Legacy signals
            const reachMalware = reachSignals.MALWARE || 0;
            const reachSuspicious = reachSignals.SUSPICIOUS || 0;
            const reachPhantom = reachSignals.PHANTOM || 0;
            
            setEl('reachCves', fmt(reachCves));
            setEl('reachCvesPct', '');
            setEl('reachMalwareStatic', fmt(reachMalware));
            setEl('reachMalwareStaticPct', '');
            setEl('reachMalwareDynamic', fmt(reachSuspicious));
            setEl('reachMalwareDynamicPct', '');
            setEl('reachSecrets', fmt(reachSecrets));
            setEl('reachSecretsPct', '');
            setEl('reachCwe', fmt(reachCwe));
            setEl('reachCwePct', '');
            setEl('reachConfig', fmt(reachConfig));
            setEl('reachConfigPct', '');
            setEl('reachPhantom', fmt(reachPhantom));
            setEl('reachPhantomPct', '');
            setEl('reachAi', fmt(reachAi));
            setEl('reachAiPct', '');
            setEl('reachDlp', fmt(reachDlp));
            setEl('reachDlpPct', '');
            setEl('reachTotal', fmt(totalReachable));
            
            // DLP findings reference for other uses
            const dlpFindings = d.dlp_findings || [];
            
            // v4.5.0: Vulnerable packages count (distinct packages with CVEs)
            const vulnerablePackages = issues.filter(f => f.type === 'CVE').reduce((acc, f) => {
                const pkg = f.package || '';
                if (pkg && !acc.includes(pkg)) acc.push(pkg);
                return acc;
            }, []).length;
            
            // v4.5.1: Packages with REACHABLE CVEs (for package reduction calculation)
            const reachableVulnPackages = issues.filter(f => f.type === 'CVE' && getReachabilityState(f) === 'reachable').reduce((acc, f) => {
                const pkg = f.package || '';
                if (pkg && !acc.includes(pkg)) acc.push(pkg);
                return acc;
            }, []).length;

            // v4.6.0: Normalize types for UI consistency (e.g., CONFIG + IAC -> IaC)
            issues.forEach(f => { f.type = normalizeIssueType(f.type); });

            allIssues = issues;
            
            // P2.50 REMOVED: AI and DLP are now added to issues[] by loaders.py
            // via _convert_ai_to_issues() and _convert_dlp_to_issues()
            // Do NOT merge them again here or they will be double-counted
            // See: loaders.py lines 70-78 (DLP) and lines 74-78 (AI)
            
            // v4.5.22: Default sort by risk descending, then type (CVE, CWE, SECRET, MALWARE, Config), then reachability
            // P2.20 Fix 5: Remove IAC duplicate - now using Config
            const riskOrder = { CRITICAL: 0, HIGH: 1, MEDIUM: 2, LOW: 3, INFO: 4 };
            const typeOrder = { CVE: 0, CWE: 1, AI: 2, DLP: 3, SECRET: 4, MALWARE: 5, SUSPICIOUS: 5, CONFIG: 6, PHANTOM: 7, THREATINTEL: 8 };
            const reachOrder = { reachable: 0, unknown: 1, not_reachable: 2 };
            allIssues.sort((a, b) => {
                // Primary: Risk level descending
                const aRisk = riskOrder[calculateRisk(a)] ?? 5;
                const bRisk = riskOrder[calculateRisk(b)] ?? 5;
                if (aRisk !== bRisk) return aRisk - bRisk;
                // Secondary: Type order (CVE first, then CWE, SECRET, MALWARE, CONFIG)
                const aType = typeOrder[(a.type || '').toUpperCase()] ?? 7;
                const bType = typeOrder[(b.type || '').toUpperCase()] ?? 7;
                if (aType !== bType) return aType - bType;
                // Tertiary: Reachability (reachable first)
                const aReach = reachOrder[getReachabilityState(a)] ?? 3;
                const bReach = reachOrder[getReachabilityState(b)] ?? 3;
                return aReach - bReach;
            });
            
            renderTable(allIssues);
            
            // v4.5.12: Populate Engineering Details Panel
            populateEngineeringPanel(issues);
            
            // Enrichments Panel (v4.4.4) - v4.5.0: Fixed to show packages not CVE counts
            const enrichments = d.enrichments || {};
            setEl('enrichKev', fmt(enrichments.kev_count || m.threatintel_kev || 0));
            setEl('enrichEpss', fmt(enrichments.high_epss_count || m.threatintel_epss_high || 0));
            setEl('enrichExploits', fmt(enrichments.exploit_count || 0));
            setEl('enrichHealthCritical', fmt(enrichments.health_critical || 0));
            setEl('enrichHealthRisky', fmt(enrichments.health_risky || 0));
            setEl('enrichUnmaintained', fmt(enrichments.unmaintained || 0));
            setEl('enrichEntrypoints', fmt(m.entrypoints || m.entrypoints_count || enrichments.entrypoints || 0));
            setEl('enrichShadow', fmt(enrichments.shadow_imports || 0));
            setEl('enrichPhantom', fmt(rawPhantom));
            // v4.5.1: Files scanned (source files analyzed by Semgrep)
            const filesScanned = m.source_files_scanned || 0;
            const enrichFilesScannedEl = document.getElementById('enrichFilesScanned');
            if (enrichFilesScannedEl) enrichFilesScannedEl.textContent = filesScanned > 0 ? fmt(filesScanned) : 'N/A';
            
            // v4.5.0: Show packages scanned and vulnerable packages, not CVE counts
            setEl('enrichTotalDeps', fmt(packagesScanned));
            const enrichVulnPkgsEl = document.getElementById('enrichVulnPkgs');
            if (enrichVulnPkgsEl) enrichVulnPkgsEl.textContent = fmt(vulnerablePackages);
            // v4.5.0: Direct vs Transitive CVEs - supply chain visibility
            const transitiveCves = issues.filter(f => f.type === 'CVE' && f.is_transitive).length;
            const directCves = issues.filter(f => f.type === 'CVE' && !f.is_transitive).length;
            const enrichDirectCvesEl = document.getElementById('enrichDirectCves');
            if (enrichDirectCvesEl) enrichDirectCvesEl.textContent = fmt(directCves);
            const enrichTransitiveCvesEl = document.getElementById('enrichTransitiveCves');
            if (enrichTransitiveCvesEl) enrichTransitiveCvesEl.textContent = fmt(transitiveCves);
            
            // v4.5.7: Sleek Executive Summary Panel
            const lowReach = reachable.filter(f => normalizeSeverity(f.severity) === 'LOW').length;
            const malwareTotalCombined = rawMalware + rawSuspicious;  // Combined for exec summary
            const totalReachableIssues = reachable.length;
            
            // v4.5.26: ACTIONABLE = reachable OR unknown (including all types)
            // P2.21 FIX: Include CONFIG - it was being excluded then counted (causing wrong totals)
            const actionable = issues.filter(f => 
                getReachabilityState(f) !== 'not_reachable'
            );
            
            // v4.5.26: Calculate severity-tiered counts from ACTIONABLE items (not just reachable)
            const criticalReachAll = actionable.filter(f => normalizeSeverity(f.severity) === 'CRITICAL').length;
            const highReachAll = actionable.filter(f => normalizeSeverity(f.severity) === 'HIGH').length;
            
            // Breakdown by type for CRITICAL (from actionable) - v4.5.40: Added AI
            // P2.20-E1 FIX: Added CONFIG and DLP
            const criticalCves = actionable.filter(f => f.type === 'CVE' && normalizeSeverity(f.severity) === 'CRITICAL').length;
            const criticalSecrets = actionable.filter(f => f.type === 'SECRET' && normalizeSeverity(f.severity) === 'CRITICAL').length;
            const criticalCwes = actionable.filter(f => f.type === 'CWE' && normalizeSeverity(f.severity) === 'CRITICAL').length;
            const criticalMalware = actionable.filter(f => (f.type === 'MALWARE' || f.type === 'SUSPICIOUS') && normalizeSeverity(f.severity) === 'CRITICAL').length;
            const criticalAi = actionable.filter(f => f.type === 'AI' && normalizeSeverity(f.severity) === 'CRITICAL').length;
            const criticalConfig = actionable.filter(f => f.type === 'CONFIG' && normalizeSeverity(f.severity) === 'CRITICAL').length;
            const criticalDlp = actionable.filter(f => f.type === 'DLP' && normalizeSeverity(f.severity) === 'CRITICAL').length;
            
            // Breakdown by type for HIGH (from actionable) - v4.5.40: Added AI
            // P2.20-E1 FIX: Added CONFIG and DLP
            const highCves = actionable.filter(f => f.type === 'CVE' && normalizeSeverity(f.severity) === 'HIGH').length;
            const highSecrets = actionable.filter(f => f.type === 'SECRET' && normalizeSeverity(f.severity) === 'HIGH').length;
            const highCwes = actionable.filter(f => f.type === 'CWE' && normalizeSeverity(f.severity) === 'HIGH').length;
            const highMalware = actionable.filter(f => (f.type === 'MALWARE' || f.type === 'SUSPICIOUS') && normalizeSeverity(f.severity) === 'HIGH').length;
            const highAi = actionable.filter(f => f.type === 'AI' && normalizeSeverity(f.severity) === 'HIGH').length;
            const highConfig = actionable.filter(f => f.type === 'CONFIG' && normalizeSeverity(f.severity) === 'HIGH').length;
            const highDlp = actionable.filter(f => f.type === 'DLP' && normalizeSeverity(f.severity) === 'HIGH').length;
            
            // v4.5.26: Calculate risk posture based on actionable issues (override data.risk_level if needed)
            // If we have CRITICAL actionable items, posture is CRITICAL regardless of what generator said
            let posture = 'low';
            if (criticalReachAll > 0) {
                posture = 'critical';
            } else if (highReachAll > 0) {
                posture = 'high';
            } else if (actionable.filter(f => normalizeSeverity(f.severity) === 'MEDIUM').length > 0) {
                posture = 'medium';
            }
            
            // Update posture row
            const execPostureEl = document.getElementById('execPosture');
            const execPostureDotEl = document.getElementById('execPostureDot');
            const execPostureTextEl = document.getElementById('execPostureText');
            const postureEmojis = { critical: '🔴', high: '🟠', medium: '🟡', low: '🟢' };
            if (execPostureEl) {
                execPostureEl.className = `status ${posture}`;
            }
            if (execPostureDotEl) {
                execPostureDotEl.textContent = postureEmojis[posture] || '🔴';
            }
            if (execPostureTextEl) {
                execPostureTextEl.textContent = posture.charAt(0).toUpperCase() + posture.slice(1);
            }
            
            // v4.5.25: Populate severity-tiered action lines
            const execCriticalLineEl = document.getElementById('execCriticalLine');
            const execCriticalCountEl = document.getElementById('execCriticalCount');
            const execCriticalBreakdownEl = document.getElementById('execCriticalBreakdown');
            const execHighLineEl = document.getElementById('execHighLine');
            const execHighCountEl = document.getElementById('execHighCount');
            const execHighBreakdownEl = document.getElementById('execHighBreakdown');
            const execNoActionLineEl = document.getElementById('execNoActionLine');
            
            // v4.5.40: Helper to build breakdown string - ALWAYS show breakdown for visibility (added AI)
            // P2.20-E1 FIX: Added config and dlp parameters
            // P2.63 FIX: Breakdown items are now plain text (no clickable links) - only the main total is clickable
            function buildBreakdown(cves, secrets, cwes, malware, ai = 0, config = 0, dlp = 0, severity = 'CRITICAL') {
                // P2.63: Plain text breakdown (no links) - clicking the main line handles filtering
                const parts = [
                    `<span style="color:#94a3b8;">🛡️ ${cves} CVE${cves !== 1 ? 's' : ''}</span>`,
                    `<span style="color:#94a3b8;">🔐 ${secrets} secret${secrets !== 1 ? 's' : ''}</span>`,
                    `<span style="color:#94a3b8;">⚠️ ${cwes} CWE${cwes !== 1 ? 's' : ''}</span>`,
                    `<span style="color:#94a3b8;">☠️ ${malware} malware</span>`,
                    `<span style="color:#94a3b8;">🤖 ${ai} AI</span>`,
                    `<span style="color:#94a3b8;">⚙️ ${config} config</span>`,
                    `<span style="color:#94a3b8;">🔒 ${dlp} DLP</span>`
                ];
                return parts.join(' · ');
            }
            
            // P2.46: Quick filter helper for clicking breakdown links
            window.applyQuickFilter = function(type, severity) {
                // Wait for DOM to be ready
                setTimeout(() => {
                    const typeFilter = document.getElementById('filterType');
                    const sevFilter = document.getElementById('filterSeverity');
                    if (typeFilter) typeFilter.value = type;
                    if (sevFilter) sevFilter.value = severity;
                    // Call applyFilters directly instead of clicking
                    if (typeof applyFilters === 'function') {
                        applyFilters();
                    }
                }, 100);
            };
            
            // CRITICAL line
            if (execCriticalLineEl && execCriticalCountEl) {
                if (criticalReachAll > 0) {
                    execCriticalCountEl.textContent = criticalReachAll;
                    execCriticalLineEl.style.display = 'block';
                    if (execCriticalBreakdownEl) {
                        execCriticalBreakdownEl.innerHTML = buildBreakdown(criticalCves, criticalSecrets, criticalCwes, criticalMalware, criticalAi, criticalConfig, criticalDlp, 'CRITICAL');
                    }
                } else {
                    execCriticalLineEl.style.display = 'none';
                }
            }
            
            // HIGH line
            if (execHighLineEl && execHighCountEl) {
                if (highReachAll > 0) {
                    execHighCountEl.textContent = highReachAll;
                    execHighLineEl.style.display = 'block';
                    if (execHighBreakdownEl) {
                        execHighBreakdownEl.innerHTML = buildBreakdown(highCves, highSecrets, highCwes, highMalware, highAi, highConfig, highDlp, 'HIGH');
                    }
                } else {
                    execHighLineEl.style.display = 'none';
                }
            }
            
            // No action line (only show if no CRITICAL or HIGH)
            if (execNoActionLineEl) {
                execNoActionLineEl.style.display = (criticalReachAll === 0 && highReachAll === 0) ? 'block' : 'none';
            }
            
            // Update signal quality - v4.5.50: Show BOTH technical and global noise reduction
            const execPctEl = document.getElementById('execReductionPct');
            const execFilterDetailEl = document.getElementById('execFilterDetail');
            
            // v4.6.6: Use UNIFIED noise reduction (same as funnel and Signal Quality table)
            // Global totals come from issues array, not metrics (ensures consistency)
            const globalReductionPct = unifiedNoiseReduction;
            
            
            if (execPctEl) execPctEl.textContent = `${globalReductionPct}%`;
            if (execFilterDetailEl) {
                // v4.6.6: Use unified totals from issues array
                const totalActionable = totalAllIssues - totalUnreachable;
                const line1 = `${fmt(totalUnreachable)} unreachable issues filtered from ${fmt(totalAllIssues)} total`;
                const line2 = `${globalReductionPct}% noise reduction · ${fmt(totalAllIssues)} total → ${fmt(totalActionable)} actionable`;
                execFilterDetailEl.innerHTML = `${line1}<br><span style="font-size: 11px; color: #86efac;">${line2}</span>`;
            }
            
            // v4.6.5: Populate Signal Quality breakdown table
            populateSignalQualityTable(d.funnel);
            
            // v4.5.25: Populate review required count (unknown reachability, including all types)
            // P2.21 FIX: Include CONFIG for complete breakdown
            const unknownReach = issues.filter(f => getReachabilityState(f) === 'unknown');
            const unknownCves = unknownReach.filter(f => f.type === 'CVE').length;
            const unknownSecrets = unknownReach.filter(f => f.type === 'SECRET').length;
            const unknownCwes = unknownReach.filter(f => f.type === 'CWE').length;
            const unknownMalware = unknownReach.filter(f => f.type === 'MALWARE' || f.type === 'SUSPICIOUS').length;
            const unknownAi = unknownReach.filter(f => f.type === 'AI').length;
            const unknownConfig = unknownReach.filter(f => f.type === 'CONFIG').length;  // P2.21: Add CONFIG
            const unknownDlp = unknownReach.filter(f => f.type === 'DLP').length;  // P2.21: Add DLP
            const totalUnknown = unknownReach.length;
            
            const execReviewCountEl = document.getElementById('execReviewCount');
            const execReviewLineEl = document.getElementById('execReviewLine');
            const execReviewBreakdownEl = document.getElementById('execReviewBreakdown');
            if (execReviewCountEl) execReviewCountEl.textContent = totalUnknown;
            if (execReviewLineEl) {
                execReviewLineEl.style.display = totalUnknown > 0 ? 'block' : 'none';
            }
            // Add breakdown for review items (only if multiple types)
            // P2.21: Added CONFIG and DLP to breakdown
            if (execReviewBreakdownEl && totalUnknown > 0) {
                execReviewBreakdownEl.innerHTML = buildBreakdown(unknownCves, unknownSecrets, unknownCwes, unknownMalware, unknownAi, unknownConfig, unknownDlp, '');
            }
            
            // v4.5.8: Populate footer metadata (scan count, first scan, db size)
            const footerMetaEl = document.getElementById('footerScanMeta');
            if (footerMetaEl && repoMeta.scan_number) {
                let metaLine = `Scan #${repoMeta.scan_number}`;
                if (repoMeta.first_scan) metaLine += ` · First: ${repoMeta.first_scan}`;
                if (repoMeta.db_size_display) metaLine += ` · DB: ${repoMeta.db_size_display}`;
                footerMetaEl.textContent = metaLine;
            
                const repoMetaEl = document.getElementById('repoScanMeta');
                if (repoMetaEl) repoMetaEl.textContent = metaLine;
}
        }
        
        function calculateRisk(f) {
            const sev = normalizeSeverity(f.severity);
            const reachState = getReachabilityState(f);
            
            // Malware is always high risk
            if (f.type === 'MALWARE') return 'CRITICAL';
            
            // Config has UNKNOWN reachability - use raw severity
            if (reachState === 'unknown') return sev;
            
            // Reachable findings keep severity, unreachable downgrade
            if (reachState === 'reachable') return sev;
            
            // Downgrade unreachable
            const downgrade = { CRITICAL: 'MEDIUM', HIGH: 'LOW', MEDIUM: 'LOW', LOW: 'INFO' };
            return downgrade[sev] || sev;
        }
        
        // v4.6.5: Populate Signal Quality breakdown table
        // P2.50 CRITICAL: Read from d.funnel (database = single source of truth)
        function populateSignalQualityTable(funnel) {
            const tbody = document.getElementById('signalQualityTableBody');
            if (!tbody) return;
            
            const rawSignals = funnel?.raw_signals || {};
            const reachSignals = funnel?.reachable_signals || {};
            const unknownSignals = funnel?.unknown_signals || {};
            const unreachSignals = funnel?.unreachable_signals || {};
            
            // Signal type metadata
            const signalMeta = {
                'CVE': { icon: '🛡️', label: 'CVE Vulnerabilities', color: '#fca5a5' },
                'SECRET': { icon: '🔐', label: 'Exposed Secrets', color: '#fbbf24' },
                'CWE': { icon: '⚠️', label: 'Code Weaknesses', color: '#f9a8d4' },
                'CONFIG': { icon: '⚙️', label: 'Config Issues', color: '#67e8f9', isConfig: true },
                'AI': { icon: '🤖', label: 'AI/LLM Security', color: '#a78bfa' },
                'DLP': { icon: '🔒', label: 'DLP / PII', color: '#fdba74' }
            };
            
            let html = '';
            let totalAll = 0, totalReach = 0, totalUnkn = 0, totalUnreach = 0;
            
            Object.entries(signalMeta).forEach(([key, meta]) => {
                const total = rawSignals[key] || 0;
                const reach = reachSignals[key] || 0;
                const unkn = unknownSignals[key] || 0;
                const unreach = unreachSignals[key] || 0;
                
                const filtered = total > 0 ? ((unreach / total) * 100).toFixed(1) : '0.0';
                const filteredDisplay = `${filtered}%`;
                
                // Special styling for config issues (not in risk calculation)
                const labelStyle = meta.isConfig ? 'color: #cbd5e1; opacity: 0.7;' : 'color: #cbd5e1;';
                const configNote = meta.isConfig ? ' <span style="color: #64748b; font-size: 10px; font-weight: 500;">(not in risk)</span>' : '';
                
                html += `
                    <tr>
                        <td style="padding: 8px 4px; ${labelStyle}">
                            <span style="color: ${meta.color};">${meta.icon}</span> ${meta.label}${configNote}
                        </td>
                        <td style="text-align: right; padding: 8px 4px; color: #f8fafc; font-weight: 600;">${total}</td>
                        <td style="text-align: right; padding: 8px 4px; color: #ef4444; font-weight: 600;">${reach}</td>
                        <td style="text-align: right; padding: 8px 4px; color: #fbbf24; font-weight: 600;">${unkn}</td>
                        <td style="text-align: right; padding: 8px 4px; color: #64748b;">${unreach}</td>
                        <td style="text-align: right; padding: 8px 4px; color: #94a3b8; font-weight: 600;">${filteredDisplay}</td>
                    </tr>
                `;
                
                // Don't count CONFIG in totals (not part of risk calculation)
                if (!meta.isConfig) {
                    totalAll += total;
                    totalReach += reach;
                    totalUnkn += unkn;
                    totalUnreach += unreach;
                }
            });
            
            // Add total row (no separator)
            const totalFiltered = totalAll > 0 ? ((totalUnreach / totalAll) * 100).toFixed(1) : '0.0';
            html += `
                <tr style="font-weight: 700;">
                    <td style="padding: 10px 4px; color: #f8fafc;">Total</td>
                    <td style="text-align: right; padding: 10px 4px; color: #f8fafc;">${totalAll}</td>
                    <td style="text-align: right; padding: 10px 4px; color: #ef4444;">${totalReach}</td>
                    <td style="text-align: right; padding: 10px 4px; color: #fbbf24;">${totalUnkn}</td>
                    <td style="text-align: right; padding: 10px 4px; color: #64748b;">${totalUnreach}</td>
                    <td style="text-align: right; padding: 10px 4px; color: #f8fafc;">${totalFiltered}%</td>
                </tr>
            `;
            
            tbody.innerHTML = html;
        }
        
        function renderTable(issues) {
            const tbody = document.getElementById('issuesBody');

            // --- Normalization helpers (v4.6.3) ---
            // Different scanners/DB records use different field names.
            // These helpers keep the Security Issues table consistent across CVE/CWE/AI/DLP/SECRET/CONFIG/MALWARE.
            const pickFirst = (obj, keys) => {
                for (const k of keys) {
                    const v = obj?.[k];
                    if (v === 0) return 0;
                    if (v !== undefined && v !== null && String(v).trim() !== '' && String(v).trim() !== '-') return v;
                }
                return '';
            };

            const normLine = (f) => {
                const v = pickFirst(f, ['line','line_no','line_number','start_line','line_start','begin_line']);
                const n = parseInt(v, 10);
                return Number.isFinite(n) && n > 0 ? n : null;
            };

            const normIssueId = (f, idx) => {
                const t = (f.type || '').toUpperCase();
                if (t === 'CVE') {
                    return String(pickFirst(f, ['ghsa_id','ghsa','cve_id','cve','advisory_id','id','finding_id','rule_id'])).trim() || `CVE-${idx}`;
                }
                if (t === 'CWE' || t === 'CODE') {
                    return String(pickFirst(f, ['cwe_id','cwe','rule_id','check_id','policy_id','id','finding_id'])).trim() || `CWE-${idx}`;
                }
                if (t === 'SECRET') {
                    return String(pickFirst(f, ['secret_type','detector','rule_id','id','finding_id','policy_id'])).trim() || `SECRET-${idx}`;
                }
                if (t === 'DLP') {
                    return String(pickFirst(f, ['dlp_id','policy_id','rule_id','id','finding_id'])).trim() || `DLP-${idx}`;
                }
                if (t === 'AI') {
                    return String(pickFirst(f, ['rule_id','ai_rule_id','policy_id','id','finding_id','owasp_llm','owasp'])).trim() || `AI-${idx}`;
                }
                if (t === 'CONFIG' || t === 'IAC') {
                    return String(pickFirst(f, ['rule_id','policy_id','id','finding_id'])).trim() || `${t}-${idx}`;
                }
                if (t === 'MALWARE' || t === 'SUSPICIOUS') {
                    return String(pickFirst(f, ['package','purl','id','finding_id','rule_id'])).trim() || `${t}-${idx}`;
                }
                return String(pickFirst(f, ['id','rule_id','policy_id','finding_id'])).trim() || `${t || 'ISSUE'}-${idx}`;
            };

            const normFilePath = (f) => pickFirst(f, ['file_path','file','path','source_file','source_path','location_path']);

            const normLocation = (f) => {
                const t = (f.type || '').toUpperCase();
                if (t === 'CVE') return pickFirst(f, ['package','purl','dependency','component','location']) || 'Unknown package';
                if (t === 'MALWARE' || t === 'SUSPICIOUS') return pickFirst(f, ['package','purl','dependency','component']) || 'Package';
                if (t === 'DLP') {
                    return pickFirst(f, ['file_path','source_file','source_path']) || pickFirst(f, ['sink_function','sink_type']) || 'UNKNOWN';
                }
                if (t === 'SECRET') return pickFirst(f, ['file_path','source_file','source_path']) || 'Repository';
                return normFilePath(f) || pickFirst(f, ['package','purl']) || '-';
            };

            const normFixTag = (f) => pickFirst(f, ['fix_tag_display','fix_display','fix','fixed_in','upgrade_to','recommended_fix']) || '-';

            const normSlaTag = (f) => {
                // Prefer explicit display/class from DB, but accept common alternates
                const display = pickFirst(f, ['sla_display','sla','sla_text','sla_label']);
                const klass = pickFirst(f, ['sla_class','sla_level','sla_badge_class']);
                if (!display) return null;
                return `<span class="sla-tag ${klass || ''}">${display}</span>`;
            };

            if (!issues.length) {
                tbody.innerHTML = '<tr><td colspan="11" class="loading">No issues found matching filters</td></tr>';
                return;
            }
            
            let html = '';
            issues.forEach((f, idx) => {
                const reachState = getReachabilityState(f);
                const isReachable = reachState === 'reachable';
                const isUnknown = reachState === 'unknown';
                
                let rowClass = 'clickable';
                if (!isReachable && !isUnknown) rowClass += ' unreachable';
                if (isUnknown) rowClass += ' unknown-reach';
                
                const severity = normalizeSeverity(f.severity);
                const riskLevel = calculateRisk(f);
                const typeClass = `type-${(f.type || 'cwe').toLowerCase()}`;
                const sevClass = `severity-${severity.toLowerCase()}`;
                const riskClass = `risk-${riskLevel.toLowerCase()}`;
                // Normalized core fields (v4.6.3)
                const filePath = normFilePath(f);
                const lineNo = normLine(f);
                const loc = normLocation(f);
                const locShort = loc.length > 35 ? '...' + loc.substring(loc.length - 32) : loc;

                // Fix + SLA display (prefer DB fields, but accept common alternates)
                const fixTag = normFixTag(f);
                const slaTag = normSlaTag(f) || '-';
                
                // Build link for file location
                const githubBase = dashboardData.scan?.github_url || '';
                const branch = dashboardData.scan?.branch || 'main';
                const repoRoot = dashboardData.scan?.repo_root || '';
                const buildLocLink = (path, line) => {
                    if (!path || path === '-' || path.startsWith('pkg:')) return null;
                    if (githubBase) {
                        let cleanPath = path;
                        if (repoRoot && path.startsWith(repoRoot)) cleanPath = path.substring(repoRoot.length);
                        cleanPath = cleanPath.replace(/^\/+/, '');
                        if (!cleanPath) return null;
                        let url = `${githubBase}/blob/${branch}/${cleanPath}`;
                        if (line) url += `#L${line}`;
                        return url;
                    }
                    return `vscode://file${path}${line ? ':' + line : ''}`;
                };
                const locLink = buildLocLink(filePath, lineNo);
                
                // Normalized Issue ID (v4.6.3)
                const issueId = normIssueId(f, idx);
                
                // v4.6.2: Better description fallbacks for each issue type
                let desc = f.description || f.message || f.title || '';
                if (!desc || desc === '-') {
                    if (f.type === 'CVE') desc = f.title || `Vulnerable dependency: ${f.package || 'unknown'}`;
                    else if (f.type === 'CWE') desc = f.title || 'Code vulnerability detected';
                    else if (f.type === 'SECRET') desc = f.title || 'Exposed credential/secret';
                    else if (f.type === 'MALWARE' || f.type === 'SUSPICIOUS') desc = f.title || 'Malicious package detected';
                    else if (f.type === 'AI') desc = f.owasp_name || f.title || 'AI/LLM security finding';
                    else if (f.type === 'DLP') desc = `${f.pii_type || 'Sensitive data'} flows to ${f.sink_type || 'external sink'}`;
                    else if (f.type === 'CONFIG' || f.type === 'IAC') desc = f.title || 'Configuration/infrastructure issue';
                }
                desc = desc.substring(0, 60);
                // P2.20 FIX: Ensure desc is never empty (fallback if no match above)
                if (!desc || desc.trim() === '') {
                    desc = 'Security issue detected';
                }
                
                // Reachability display
                let reachDisplay = '';
                // v4.5.11 - Show "call graph" hint for reachable items with call path
                const hasCallPath = f.call_path && f.call_path.length > 0;
                if (isReachable) {
                    reachDisplay = hasCallPath 
                        ? '<span class="reachable-status reachable-yes" style="color:#fb923c;">🔥 Yes <span style="font-size:10px;color:#6b7280;font-weight:normal;">(call graph)</span></span>'
                        : '<span class="reachable-status reachable-yes" style="color:#fb923c;">🔥 Yes</span>';
                } else if (isUnknown) {
                    reachDisplay = '<span class="reachable-status reachable-unknown">unknown Unknown</span> <span style="color:#94a3b8;font-size:10px;font-weight:500;">(review)</span>';
                } else {
                    reachDisplay = '<span class="reachable-status reachable-no">⬜ No</span>';
                }
                
                html += `<tr class="${rowClass}" data-id="${idx}">
                    <td><span class="expand-arrow">▶</span></td>
                    <td><span class="risk-badge ${riskClass}">${riskLevel}</span></td>
                    <td><span class="issue-type ${typeClass}">${f.type || 'CWE'}</span></td>
                    <td><strong>${issueId}</strong></td>
                    <td>${fixTag || '-'}</td>
                    <td title="${loc}">${locLink ? '<a href="' + locLink + '" class="loc-link" onclick="event.stopPropagation()">' + locShort + '</a>' : locShort}</td>
                    <td title="${f.description || f.message || ''}">${desc}${desc.length >= 60 ? '...' : ''}</td>
                    <td><span class="severity-badge ${sevClass}">${severity}</span></td>
                    <td>${reachDisplay}</td>
                    <td>${slaTag}</td>
                </tr>`;
                
                // Expanded row with remediation details
                const rem = f.remediation || {};
                const steps = rem.steps || [];
                const refs = rem.references || [];
                const compMapping = f.compliance_mapping || {};
                const evidence = f.evidence || {};
                
                html += `<tr class="expanded-row" data-parent="${idx}">
                    <td colspan="10">
                        <div class="expanded-content">
                            <div class="remediation-grid">
                                <div class="remediation-block">
                                    <div class="remediation-title">🔧 Remediation</div>
                                    <div class="remediation-content">
                                        <strong>Action:</strong> ${f.type === 'DLP' ? (rem.action || 'Implement data sanitization before external transmission. Add PII masking or encryption for sensitive data flows.') : (rem.action || 'Review and assess')}<br>
                                        ${f.type === 'DLP' ? `<div style="margin-top:8px;padding:10px;background:#eff6ff;border-radius:4px;border-left:3px solid #3b82f6;"><strong style="color:#1e3a8a;">🚨 DLP Remediation Steps:</strong><ol style="margin:8px 0 0 16px;padding:0;color:#1e40af;"><li>Review data flow from source to sink</li><li>Implement input validation/sanitization</li><li>Add PII masking (e.g., ${f.pii_type === 'SSN' ? 'XXX-XX-####' : f.pii_type === 'CREDIT_CARD' ? '****-****-****-####' : 'redact/mask'})</li><li>Consider encryption for data at rest/transit</li><li>Add audit logging for sensitive data access</li></ol></div>` : ''}<br>
                                        ${rem.fixed_in ? `<strong>Upgrade to:</strong> <code style="background:#dcfce7;padding:2px 6px;border-radius:3px;font-family:monospace;">${rem.fixed_in}</code><br>` : ''}
                                        ${f.fix_status === 'no_fix' ? `<div class="context-note">⚠️ <em>No fix currently available. Monitor for updates or consider alternative packages.</em></div>` : ''}
                                        ${rem.summary ? `<strong>Summary:</strong> ${rem.summary}<br>` : ''}
                                        ${steps.length > 0 ? `<ol class="remediation-steps">${steps.map(s => `<li>${s}</li>`).join('')}</ol>` : ''}
                                        ${rem.workaround ? `<div class="code-block">${rem.workaround}</div>` : ''}
                                    </div>
                                </div>
                                <div class="remediation-block">
                                    <div class="remediation-title">📋 Details & References</div>
                                    <div class="remediation-content">
                                        <strong>ID:</strong> ${issueId || 'N/A'}<br>
                                        <strong>Type:</strong> ${f.type || 'Unknown'}${f.is_transitive ? ' <span style="background:rgba(245,158,11,0.2);color:#fbbf24;padding:2px 6px;border-radius:3px;font-size:10px;">TRANSITIVE DEP</span>' : ''}<br>
                                        <strong>Severity:</strong> <span class="severity-badge ${sevClass}">${severity}</span><br>
                                        <strong>Risk:</strong> <span class="risk-badge ${riskClass}">${riskLevel}</span> <span style="color:#6b7280;font-size:11px;">(${isReachable ? 'reachable' : isUnknown ? 'unknown reachability' : 'not reachable'})</span><br>
                                        ${isReachable ? `<strong>Suggested SLA:</strong> <span class="sla-tag ${f.sla_class || ''}">${f.sla_display || 'N/A'}</span><br>` : ''}
                                        ${isUnknown && f.type !== 'CONFIG' && f.type !== 'IaC' ? `<div class="context-note" style="background:#fef3c7;padding:8px;border-radius:4px;margin-top:8px;">⚠️ <strong>REVIEW REQUIRED:</strong> Reachability could not be determined. Check: 1) Is this code path reachable from an entry point? 2) Is it loaded dynamically?${f.type === 'SECRET' ? ' 3) Rotate credential if in doubt.' : ''}</div>` : ''}
                                        ${(f.type === 'CONFIG' || f.type === 'IaC') ? 
                                            `<div class="context-note" style="background:#dbeafe;padding:8px;border-radius:4px;margin-top:8px;">${f.action_message || (f.iac_classification ? f.iac_classification.action_message : null) || 'ℹ️ <strong>REVIEW:</strong> IaC finding with context-dependent impact. Severity may vary based on deployment context (standalone Docker, Kubernetes with PodSecurityPolicies, etc.).'}</div>` : ''}
                                        ${f.type === 'DLP' ? `<strong>Data Flow:</strong> ${f.pii_type || 'Sensitive Data'} → ${f.sink_type || 'External Sink'}<br><strong>Source File:</strong> ${filePath || '-'}${lineNo ? ':' + lineNo : ''}<br>` : `<strong>Package:</strong> ${f.package || loc}${f.version ? ' @ ' + f.version : ''}<br>`}
                                        ${f.is_transitive ? `<div class="context-note">🔗 <em>This is a transitive (indirect) dependency. It is not directly imported in your code but comes from another package in your dependency tree.</em></div>` : ''}
                                        ${f.file_path && f.file_path !== f.package ? `<strong>Used In:</strong> ${locLink ? `<a href="${locLink}" class="loc-link">${f.file_path}${f.line ? `:${f.line}` : ''}</a>` : `${f.file_path}${f.line ? `:${f.line}` : ''}`}<br>` : ''}
                                        ${f.cwe_id ? `<strong>CWE:</strong> ${f.cwe_id}<br>` : ''}
                                        ${f.owasp_llm && f.owasp_llm !== 'NONE' ? `<strong>OWASP LLM:</strong> <span style="background:#a855f7;color:white;padding:2px 8px;border-radius:4px;font-size:11px;font-weight:600;">${f.owasp_llm}</span><br>` : ''}
                                        ${refs.length > 0 ? `<div class="reference-links">${refs.map(r => `<a href="${r}" class="reference-link" target="_blank">${r.includes('github') ? 'GitHub Advisory' : r.includes('nvd') ? 'NVD' : 'Reference'}</a>`).join('')}</div>` : ''}
                                        ${f.type === 'DLP' && f.compliance_mapping?.regulations?.length > 0 ? `<div style="margin-top: 12px; padding: 12px; background:rgba(245,158,11,0.15);border-radius:6px; border-left: 4px solid #f59e0b;"><strong>⚠️ Regulatory Impact:</strong><div style="margin-top: 8px; display: flex; flex-wrap: wrap; gap: 8px;">${f.compliance_mapping.regulations.map(r => `<span style="background: ${r.includes('GDPR') ? '#dc2626' : r.includes('CCPA') ? '#2563eb' : r.includes('HIPAA') ? '#059669' : r.includes('PCI') ? '#7c3aed' : '#64748b'}; color: white; padding: 4px 10px; border-radius: 4px; font-weight: 600; font-size: 11px;">${r}</span>`).join('')}</div><div style="margin-top: 8px; font-size: 11px; color:#fbbf24;">This data flow may violate data protection regulations. Immediate remediation recommended.</div></div>` : ''}
                                        ${Object.keys(compMapping).length > 0 && f.type !== 'DLP' ? `<div style="margin-top: 10px;"><strong>Compliance:</strong></div><div class="compliance-tags">${Object.entries(compMapping).map(([framework, codes]) => renderComplianceTag(framework, codes)).join('')}</div>` : ''}
                                    </div>
                                </div>
                            </div>
                            ${(f.type === 'MALWARE' || f.type === 'SUSPICIOUS') && (evidence.static || evidence.dynamic) ? `
                                <div class="evidence-panel">
                                    <div class="evidence-title">🔍 Detection Evidence</div>
                                    ${evidence.static ? `
                                        <div class="evidence-section">
                                            <div class="evidence-label">Static Malware (${evidence.static.scanner || 'Static'})</div>
                                            <div class="evidence-items">
                                                ${(evidence.static.indicators || []).map(i => `<div class="evidence-item">${i.type}: ${i.detail || i}</div>`).join('')}
                                            </div>
                                        </div>
                                    ` : ''}
                                    ${evidence.dynamic ? `
                                        <div class="evidence-section">
                                            <div class="evidence-label">Dynamic Malware (${evidence.dynamic.scanner || 'Dynamic'})</div>
                                            <div class="evidence-items">
                                                ${(evidence.dynamic.behaviors || []).map(b => `<div class="evidence-item">${b.type}: ${b.detail || b}</div>`).join('')}
                                            </div>
                                        </div>
                                    ` : '<div class="evidence-section"><div class="evidence-label">Dynamic Malware</div><div class="evidence-items"><div class="evidence-item">Not performed (static indicators only)</div></div></div>'}
                                </div>
                            ` : ''}
                            ${f.call_path && f.call_path.length > 0 ? `
                            <div style="margin-top:20px;padding:15px;background:#0f172a;border-radius:8px;border:1px solid #334155;">
                                <div style="font-size:12px;font-weight:600;color:#10b981;margin-bottom:12px;">📍 CALL GRAPH</div>
                                <div style="font-family:monospace;font-size:11px;color:#e2e8f0;line-height:1.8;">
                                    ${f.call_path.map((step, i) => {
                                        const funcName = step.function || step.name || step.method || 'unknown';
                                        const file = step.file || step.filename || '';
                                        const line = step.line || '';
                                        const isFirst = i === 0;
                                        const isLast = i === f.call_path.length - 1;
                                        const color = isFirst ? '#22c55e' : isLast ? '#ef4444' : '#94a3b8';
                                        const icon = isFirst ? '🚪' : isLast ? '💥' : '→';
                                        return `
                                        <div style="padding-left:${i*20}px;margin-bottom:6px;">
                                            <span style="color:${color};font-weight:600;">${icon} ${funcName}</span>
                                            ${file ? `<span style="color:#64748b;font-size:10px;margin-left:8px;">${file}${line ? ':'+line : ''}</span>` : ''}
                                        </div>`;
                                    }).join('')}
                                </div>
                            </div>
                            ` : ''}
                            ${f.description || f.message ? `<div style="margin-top: 15px; padding: 10px; background: white; border-radius: 4px; font-size: 12px; color: #374151;"><strong>Full Description:</strong> ${f.description || f.message}</div>` : ''}
                        </div>
                    </td>
                </tr>`;
            });
            tbody.innerHTML = html;
            attachRowHandlers();
        }
        
        function attachRowHandlers() {
            document.querySelectorAll('tr.clickable').forEach(row => {
                row.addEventListener('click', (e) => {
                    if (e.target.tagName === 'A') return;
                    const exp = document.querySelector(`tr[data-parent="${row.dataset.id}"]`);
                    const arr = row.querySelector('.expand-arrow');
                    if (exp) { 
                        exp.classList.toggle('show'); 
                        arr.classList.toggle('expanded'); 
                        arr.textContent = arr.classList.contains('expanded') ? '▼' : '▶'; 
                    }
                });
            });
        }
        
        // v4.4.6: Improved compliance framework matching
        function normalizeComplianceKey(key) {
            if (!key) return '';
            // Remove special chars, normalize to uppercase, handle common variations
            return key.toUpperCase()
                .replace(/[^A-Z0-9]/g, '')
                .replace('TOP25', 'TOP25')
                .replace('80053', '80053')
                .replace('800171', '800171');
        }
        
        // v4.4.6: Check if compliance mapping contains a framework
        function hasComplianceFramework(mapping, filterValue) {
            if (!mapping || !filterValue) return false;
            const normalizedFilter = normalizeComplianceKey(filterValue);
            
            // v4.5.38: Handle OWASP category filters (OWASP-A01, OWASP-LLM01, etc.)
            if (filterValue.startsWith('OWASP-A') || filterValue.startsWith('OWASP-LLM')) {
                const category = filterValue.replace('OWASP-', ''); // A01, LLM01, etc.
                // Check if finding has this OWASP category
                if (mapping.OWASP && Array.isArray(mapping.OWASP)) {
                    return mapping.OWASP.some(code => code.startsWith(category));
                }
                if (mapping['OWASP-LLM'] && Array.isArray(mapping['OWASP-LLM'])) {
                    return mapping['OWASP-LLM'].some(code => code.startsWith(category));
                }
                // v4.5.39 FIX: Data uses OWASP_LLM (underscore), not OWASP-LLM (dash)
                if (mapping.OWASP_LLM && Array.isArray(mapping.OWASP_LLM)) {
                    return mapping.OWASP_LLM.some(code => code.startsWith(category));
                }
                // Also check llm_category field directly
                const llmCat = mapping.llm_category || mapping.owasp_llm;
                if (llmCat && llmCat.startsWith(category)) return true;
                // Also check owasp_category field directly
                const owaspCat = mapping.owasp_category || mapping.owasp_llm_category;
                if (owaspCat && owaspCat.startsWith(category)) return true;
                return false;
            }
            
            // Common aliases for frameworks
            const aliases = {
                'OWASP': ['OWASP', 'OWASPTOP10'],
                'CWETOP25': ['CWETOP25', 'CWE25', 'CWETOP'],
                'PCIDSS': ['PCIDSS', 'PCI'],
                'NIST80053': ['NIST80053', 'NIST53', 'SP80053'],
                'NIST800171': ['NIST800171', 'NIST171', 'SP800171'],
                'FEDRAMP': ['FEDRAMP', 'FEDRAMPMODERATE', 'FEDRAMPHIGH'],
                'ISO27001': ['ISO27001', 'ISO27K', 'ISO'],
                'SOC2': ['SOC2', 'SOC', 'AICPA'],
                'CMMC': ['CMMC', 'CMMCL2', 'CMMCL3'],
                'DISASTIG': ['DISASTIG', 'STIG', 'DISA']
            };
            
            // Get all possible matches for filter
            const filterAliases = aliases[normalizedFilter] || [normalizedFilter];
            
            // Check each key in the mapping
            return Object.keys(mapping).some(key => {
                const normalizedKey = normalizeComplianceKey(key);
                // Check direct match or alias match
                return filterAliases.some(alias => 
                    normalizedKey === alias || 
                    normalizedKey.includes(alias) ||
                    alias.includes(normalizedKey)
                );
            });
        }
        
        // v4.5.3: Keywords that should NOT match in free text search (they have dedicated filters)
        const STATUS_KEYWORDS = ['unknown', 'reachable', 'not_reachable', 'critical', 'high', 'medium', 'low', 'info'];
        
        function applyFilters() {
            const search = document.getElementById('searchBox').value.toLowerCase().trim();
            const typeF = document.getElementById('typeFilter').value.toUpperCase();
            const riskF = document.getElementById('riskFilter').value;
            const reachF = document.getElementById('reachableFilter').value;
            const compF = document.getElementById('complianceFilter').value;
            const fixF = document.getElementById('fixStatusFilter').value;
            
            const filtered = allIssues.filter(f => {
                // Search filter - check multiple fields
                // v4.5.3: If searching for a status keyword, match the actual status field instead
                if (search) {
                    // Check if searching for a status keyword
                    if (STATUS_KEYWORDS.includes(search)) {
                        const reachState = getReachabilityState(f);
                        const severity = normalizeSeverity(f.severity).toLowerCase();
                        const risk = calculateRisk(f).toLowerCase();
                        // Match against actual status fields only
                        if (search === 'unknown' && reachState !== 'unknown') return false;
                        if (search === 'reachable' && reachState !== 'reachable') return false;
                        if (search === 'not_reachable' && reachState !== 'not_reachable') return false;
                        if (['critical', 'high', 'medium', 'low', 'info'].includes(search)) {
                            if (severity !== search && risk !== search) return false;
                        }
                    } else {
                        // v4.5.39 FIX: Also search OWASP/LLM policy codes in compliance_mapping
                        // This enables searching for "A01", "LLM01" etc from search box
                        const mapping = f.compliance_mapping || inferComplianceMapping(f);
                        const owaspCodes = (mapping && mapping.OWASP) ? mapping.OWASP.join(' ') : '';
                        // v4.5.39 FIX: Data uses OWASP_LLM (underscore), not OWASP-LLM (dash)
                        const llmCodes = (mapping && mapping.OWASP_LLM) ? mapping.OWASP_LLM.join(' ') : '';
                        // Also check llm_category field directly on the finding
                        const llmCategory = f.llm_category || f.owasp_llm || '';
                        const policyId = f.policy_id || '';
                        
                        // Regular text search - include policy codes for OWASP/LLM filtering
                        const searchFields = [
                            f.id, f.title, f.package, f.file_path, f.type, policyId, owaspCodes, llmCodes, llmCategory
                        ].filter(Boolean).join(' ').toLowerCase();
                        if (!searchFields.includes(search)) return false;
                    }
                }
                
                // Type filter (case-insensitive)
                if (typeF && (f.type || '').toUpperCase() !== typeF) return false;
                
                // Risk filter (v4.4.7: filter by calculated RISK, not raw severity)
                if (riskF && calculateRisk(f) !== riskF) return false;
                
                // Reachability filter
                const reachState = getReachabilityState(f);
                if (reachF === 'reachable' && reachState !== 'reachable') return false;
                if (reachF === 'not_reachable' && reachState !== 'not_reachable') return false;
                if (reachF === 'unknown' && reachState !== 'unknown') return false;
                
                // Fix status filter
                if (fixF) {
                    const hasFixAvailable = f.fix_available === true || f.fix_status === 'fix_available';
                    const hasNoFix = f.fix_status === 'no_fix' || f.fix_available === false;
                    if (fixF === 'fix_available' && !hasFixAvailable) return false;
                    if (fixF === 'no_fix' && !hasNoFix) return false;
                    if (fixF === 'unknown' && (hasFixAvailable || hasNoFix)) return false;
                }
                
                // v4.4.5: Fixed compliance filter with proper matching
                if (compF) {
                    const mapping = f.compliance_mapping || inferComplianceMapping(f);
                    // v4.5.39 FIX: Also check f.llm_category directly for LLM findings
                    if (compF.startsWith('OWASP-LLM')) {
                        const filterCat = compF.replace('OWASP-', ''); // LLM01, LLM02, etc.
                        const findingLlmCat = f.llm_category || f.owasp_llm || '';
                        if (findingLlmCat === filterCat || findingLlmCat.startsWith(filterCat)) {
                            // Match found via direct field
                        } else if (!hasComplianceFramework(mapping, compF)) {
                            return false;
                        }
                    } else if (!hasComplianceFramework(mapping, compF)) {
                        return false;
                    }
                }
                
                return true;
            });
            renderTable(filtered);
        }
        
        // Infer compliance mapping for items without explicit mapping
        function inferComplianceMapping(finding) {
            const type = finding.type;
            const severity = normalizeSeverity(finding.severity);
            
            // CVEs typically map to multiple frameworks
            if (type === 'CVE') {
                return {
                    'OWASP': ['A06:2021'],  // Vulnerable Components
                    'CWE-TOP-25': true,
                    'PCI-DSS': ['6.3'],
                    'NIST-800-53': ['SI-2'],
                    'ISO27001': ['A.12.6.1'],
                    'SOC2': ['CC6.1'],
                    'HIPAA': ['164.308(a)(5)(ii)(B)'],
                    'CMMC': ['SI.2.216'],
                    'FEDRAMP': ['SI-2'],
                    'FISMA': ['SI-2']
                };
            }
            
            // Secrets map to auth/crypto frameworks
            if (type === 'SECRET') {
                return {
                    'OWASP': ['A02:2021'],  // Cryptographic Failures
                    'PCI-DSS': ['3.4', '8.2'],
                    'NIST-800-53': ['SC-12', 'SC-13'],
                    'ISO27001': ['A.10.1.1'],
                    'SOC2': ['CC6.1'],
                    'HIPAA': ['164.312(a)(2)(iv)']
                };
            }
            
            // CWE findings have specific mappings
            if (type === 'CWE') {
                return {
                    'OWASP': ['A03:2021'],  // Injection
                    'CWE-TOP-25': true,
                    'PCI-DSS': ['6.5'],
                    'NIST-800-53': ['SI-10']
                };
            }
            
            return null;
        }
        
        function exportCSV() {
            const rows = [['Risk', 'Type', 'ID', 'Fix Status', 'Severity', 'Reachable', 'Location', 'Description', 'Compliance']];
            allIssues.forEach(f => {
                const reachState = getReachabilityState(f);
                rows.push([
                    calculateRisk(f),
                    f.type || 'CWE',
                    f.id || '',
                    f.fix_available ? 'Fix Available' : (f.fix_status || 'Unknown'),
                    normalizeSeverity(f.severity),
                    reachState,
                    f.file_path || f.package || '',
                    (f.description || '').replace(/,/g, ';'),
                    f.compliance_mapping ? Object.keys(f.compliance_mapping).join('; ') : ''
                ]);
            });
            const csv = rows.map(r => r.join(',')).join('\n');
            const blob = new Blob([csv], { type: 'text/csv' });
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a'); a.href = url; a.download = 'reachable-issues.csv'; a.click();
        }
        
        // v4.5.38: Click OWASP/LLM category card → filter Security Issues table
        function filterByOwaspCategory(category, isLlm = false) {
            // v4.5.39 FIX: Switch to Security Issues tab (where risk-inventory-wrapper is moved)
            const securityTab = document.querySelector('[data-tab="security-issues"]');
            if (securityTab) {
                document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
                document.querySelectorAll('.tab-page').forEach(p => p.classList.remove('active'));
                securityTab.classList.add('active');
                document.getElementById('tab-security-issues').classList.add('active');
            }
            
            // v4.5.39 FIX: Populate search box with category code (e.g., A01, LLM01)
            // This allows users to see the filter and easily modify it
            const searchBox = document.getElementById('searchBox');
            if (searchBox) {
                searchBox.value = category; // e.g., "A01" or "LLM01"
            }
            
            // Also set compliance filter for precise filtering
            // v4.6.5 FIX: Use correct format - OWASP-A01 for Web, OWASP-LLM01 for LLM
            const filterValue = isLlm ? `OWASP-${category}` : `OWASP-${category}`;
            const complianceFilter = document.getElementById('complianceFilter');
            if (complianceFilter) {
                // Reset to empty first, then apply - search box handles the actual filtering
                complianceFilter.value = '';
            }
            
            // Expand Security Issues section if collapsed
            const inventoryContent = document.getElementById('inventorySectionContent');
            if (inventoryContent && inventoryContent.style.display === 'none') {
                toggleSection('inventory');
            }
            
            // Apply filters and scroll to table
            applyFilters();
            
            // Scroll to Security Issues section
            const issuesTable = document.getElementById('issuesTable');
            if (issuesTable) {
                issuesTable.scrollIntoView({ behavior: 'smooth', block: 'start' });
            }
        }
        
        // Initialize
        const searchBox = document.getElementById('searchBox');
        const typeFilter = document.getElementById('typeFilter');
        const riskFilter = document.getElementById('riskFilter');
        const reachableFilter = document.getElementById('reachableFilter');
        const fixStatusFilter = document.getElementById('fixStatusFilter');
        const complianceFilter = document.getElementById('complianceFilter');
        const exportBtn = document.getElementById('exportBtn');
        
        if (searchBox) searchBox.addEventListener('input', applyFilters);
        if (typeFilter) typeFilter.addEventListener('change', applyFilters);
        if (riskFilter) riskFilter.addEventListener('change', applyFilters);
        if (reachableFilter) reachableFilter.addEventListener('change', applyFilters);
        if (fixStatusFilter) fixStatusFilter.addEventListener('change', applyFilters);
        if (complianceFilter) complianceFilter.addEventListener('change', applyFilters);
        if (exportBtn) exportBtn.addEventListener('click', exportCSV);
        
        // Sorting
        document.querySelectorAll('th.sortable').forEach(th => {
            th.addEventListener('click', () => {
                const col = th.dataset.column;
                const isAsc = th.classList.contains('sorted-asc');
                document.querySelectorAll('th').forEach(h => h.classList.remove('sorted-asc', 'sorted-desc'));
                th.classList.add(isAsc ? 'sorted-desc' : 'sorted-asc');
                
                allIssues.sort((a, b) => {
                    let aVal, bVal;
                    if (col === 'severity') { aVal = normalizeSeverity(a.severity); bVal = normalizeSeverity(b.severity); }
                    else if (col === 'risk') { aVal = calculateRisk(a); bVal = calculateRisk(b); }
                    else if (col === 'reachable') { aVal = getReachabilityState(a); bVal = getReachabilityState(b); }
                    else if (col === 'file_path') { aVal = a.file_path || a.package || ''; bVal = b.file_path || b.package || ''; }
                    else if (col === 'type') { aVal = (a.type || '').toUpperCase(); bVal = (b.type || '').toUpperCase(); }
                    else { aVal = a[col] || ''; bVal = b[col] || ''; }
                    
                    const sevOrder = { CRITICAL: 0, HIGH: 1, MEDIUM: 2, LOW: 3, INFO: 4 };
                    const reachOrder = { reachable: 0, unknown: 1, not_reachable: 2 };
                    
                    if (col === 'severity' || col === 'risk') {
                        aVal = sevOrder[aVal] ?? 5; bVal = sevOrder[bVal] ?? 5;
                    }
                    if (col === 'reachable') {
                        aVal = reachOrder[aVal] ?? 3; bVal = reachOrder[bVal] ?? 3;
                    }
                    
                    if (aVal < bVal) return isAsc ? 1 : -1;
                    if (aVal > bVal) return isAsc ? -1 : 1;
                    return 0;
                });
                applyFilters();
            });
        });
        

        // v4.5.22: Main Panel Toggle (Risk Overview / Remediation Overview)
        function toggleMainPanel(panelName) {
            const content = document.getElementById(panelName + 'Content');
            const toggle = document.getElementById(panelName + 'Toggle');
            if (content && toggle) {
                content.classList.toggle('collapsed');
                toggle.classList.toggle('collapsed');
            }
        }
        
        // v4.5.12: Engineering Panel Toggle (legacy - now uses toggleSection)
        function toggleEngineeringPanel() {
            toggleSection('engineering');
        }
        
        // v4.5.13: Exec Panel (Risk Posture) Toggle
        function toggleExecPanel() {
            const content = document.getElementById('execPanelContent');
            const toggle = document.getElementById('execPanelToggle');
            if (content && toggle) {
                content.classList.toggle('collapsed');
                toggle.classList.toggle('collapsed');
            }
        }
        
        // v4.5.20: Generic Section Toggle for Collapsible Panels
        function toggleSection(sectionName) {
            const content = document.getElementById(sectionName + 'SectionContent');
            const toggle = document.getElementById(sectionName + 'SectionToggle');
            if (content && toggle) {
                content.classList.toggle('collapsed');
                toggle.classList.toggle('collapsed');
            }
        }
        
        // v4.5.12: Populate Engineering Details Panel
        function populateEngineeringPanel(issues) {
            // CVEs - v4.5.17: Include reachability breakdown
            const allCves = issues.filter(f => f.type === 'CVE');
            const cvesReachable = allCves.filter(f => getReachabilityState(f) === 'reachable');
            const cvesUnknown = allCves.filter(f => getReachabilityState(f) === 'unknown');
            const actionableCves = [...cvesReachable, ...cvesUnknown];
            const cveCritical = actionableCves.filter(f => normalizeSeverity(f.severity) === 'CRITICAL').length;
            const cveHigh = actionableCves.filter(f => normalizeSeverity(f.severity) === 'HIGH').length;
            const cveMedium = actionableCves.filter(f => normalizeSeverity(f.severity) === 'MEDIUM').length;
            const cveLow = actionableCves.filter(f => normalizeSeverity(f.severity) === 'LOW').length;
            // Populate CVE reachability
            const engCveReachEl = document.getElementById('engCveReachable');
            const engCveUnknownEl = document.getElementById('engCveUnknown');
            if (engCveReachEl) engCveReachEl.textContent = cvesReachable.length;
            if (engCveUnknownEl) engCveUnknownEl.textContent = cvesUnknown.length;
            setEl('engCveCritical', cveCritical);
            setEl('engCveHigh', cveHigh);
            setEl('engCveMedium', cveMedium);
            setEl('engCveLow', cveLow);
            setEl('engCveTotal', actionableCves.length);
            // v4.5.19: Count fixable CVEs (actionable + has fix available)
            const cvesFixable = actionableCves.filter(f => f.fix_available === true || f.fix_status === 'fix_available').length;
            const cvesNotFixable = actionableCves.length - cvesFixable;
            const engCveFixableEl = document.getElementById('engCveFixable');
            const engCveNotFixableEl = document.getElementById('engCveNotFixable');
            if (engCveFixableEl) engCveFixableEl.textContent = cvesFixable;
            if (engCveNotFixableEl) engCveNotFixableEl.textContent = cvesNotFixable;
            
            // Secrets by type - v4.5.14: Include reachability breakdown
            const secrets = issues.filter(f => f.type === 'SECRET');
            const secretsReachableEng = secrets.filter(f => getReachabilityState(f) === 'reachable').length;
            const secretsUnknownEng = secrets.filter(f => getReachabilityState(f) === 'unknown').length;
            const secretsNotReachableEng = secrets.filter(f => getReachabilityState(f) === 'not_reachable').length;
            const secretsAws = secrets.filter(f => (f.id || '').toLowerCase().includes('aws') || (f.description || '').toLowerCase().includes('aws')).length;
            const secretsApi = secrets.filter(f => (f.id || '').toLowerCase().includes('api') || (f.description || '').toLowerCase().includes('api key')).length;
            const secretsPrivate = secrets.filter(f => (f.id || '').toLowerCase().includes('private') || (f.description || '').toLowerCase().includes('private key')).length;
            const secretsTokens = secrets.filter(f => (f.id || '').toLowerCase().includes('token') || (f.description || '').toLowerCase().includes('token')).length;
            const secretsOther = secrets.length - secretsAws - secretsApi - secretsPrivate - secretsTokens;
            setEl('engSecretsAws', secretsAws);
            setEl('engSecretsApi', secretsApi);
            setEl('engSecretsPrivate', secretsPrivate);
            setEl('engSecretsTokens', secretsTokens);
setEl('engSecretsOther', Math.max(0, secretsOther));
            // v4.5.19: Add severity breakdown to secrets (actionable = reachable + unknown)
            const actionableSecrets = secrets.filter(f => getReachabilityState(f) !== 'not_reachable');
            const secretsCritical = actionableSecrets.filter(f => normalizeSeverity(f.severity) === 'CRITICAL').length;
            const secretsHigh = actionableSecrets.filter(f => normalizeSeverity(f.severity) === 'HIGH').length;
            const secretsMedium = actionableSecrets.filter(f => normalizeSeverity(f.severity) === 'MEDIUM').length;
            setEl('engSecretsCritical', secretsCritical);
            setEl('engSecretsHigh', secretsHigh);
            setEl('engSecretsMedium', secretsMedium);
            setEl('engSecretsTotal', actionableSecrets.length);
            // v4.5.19: Add passwords type
            const secretsPasswords = secrets.filter(f => (f.id || '').toLowerCase().includes('password') || (f.description || '').toLowerCase().includes('password')).length;
            const engSecretsPasswordsEl = document.getElementById('engSecretsPasswords');
            if (engSecretsPasswordsEl) engSecretsPasswordsEl.textContent = secretsPasswords;
            // v4.5.14: Add reachability breakdown to secrets panel
            const engSecretsReachEl = document.getElementById('engSecretsReachable');
            const engSecretsUnknownEl = document.getElementById('engSecretsUnknown');
            if (engSecretsReachEl) engSecretsReachEl.textContent = secretsReachableEng;
            if (engSecretsUnknownEl) engSecretsUnknownEl.textContent = secretsUnknownEng;
            
            // CWEs by severity - v4.5.14: Include all CWEs with reachability breakdown
            const cwes = issues.filter(f => f.type === 'CWE');
            const cwesReachableEng = cwes.filter(f => getReachabilityState(f) === 'reachable');
            const cwesUnknownEng = cwes.filter(f => getReachabilityState(f) === 'unknown');
            const cwesNotReachableEng = cwes.filter(f => getReachabilityState(f) === 'not_reachable');
            // Count by severity for actionable items (reachable + unknown)
            const actionableCwes = [...cwesReachableEng, ...cwesUnknownEng];
            const cweCritical = actionableCwes.filter(f => normalizeSeverity(f.severity) === 'CRITICAL').length;
            const cweHigh = actionableCwes.filter(f => normalizeSeverity(f.severity) === 'HIGH').length;
            const cweMedium = actionableCwes.filter(f => normalizeSeverity(f.severity) === 'MEDIUM').length;
            const cweLow = actionableCwes.filter(f => normalizeSeverity(f.severity) === 'LOW').length;
            setEl('engCweCritical', cweCritical);
            setEl('engCweHigh', cweHigh);
            setEl('engCweMedium', cweMedium);
            setEl('engCweLow', cweLow);
            setEl('engCweTotal', actionableCwes.length);
            // v4.5.14: Add reachability breakdown to CWE panel
            const engCweReachEl = document.getElementById('engCweReachable');
            const engCweUnknownEl = document.getElementById('engCweUnknown');
            if (engCweReachEl) engCweReachEl.textContent = cwesReachableEng.length;
            if (engCweUnknownEl) engCweUnknownEl.textContent = cwesUnknownEng.length;
            
            // v4.5.19: CWE by Policy categorization
            const matchCwePolicy = (f, keywords) => {
                const desc = (f.description || '').toLowerCase();
                const id = (f.id || '').toLowerCase();
                const ruleId = (f.rule_id || '').toLowerCase();
                return keywords.some(kw => desc.includes(kw) || id.includes(kw) || ruleId.includes(kw));
            };
            const cweInjection = actionableCwes.filter(f => matchCwePolicy(f, ['injection', 'sql', 'sqli', 'command-injection', 'code-injection', 'os-command', 'eval(', 'exec('])).length;
            const cweXss = actionableCwes.filter(f => matchCwePolicy(f, ['xss', 'cross-site', 'script', 'reflected', 'stored-xss', 'dom-xss'])).length;
            const cwePathTraversal = actionableCwes.filter(f => matchCwePolicy(f, ['path-traversal', 'directory-traversal', 'lfi', 'rfi', '../', 'file-inclusion'])).length;
            const cweCrypto = actionableCwes.filter(f => matchCwePolicy(f, ['crypto', 'cipher', 'hash', 'md5', 'sha1', 'weak-hash', 'hardcoded-secret', 'random'])).length;
            const cweAuth = actionableCwes.filter(f => matchCwePolicy(f, ['auth', 'session', 'jwt', 'token', 'password', 'credential', 'login', 'permission'])).length;
            const cweSsrf = actionableCwes.filter(f => matchCwePolicy(f, ['ssrf', 'redirect', 'open-redirect', 'url', 'request-forgery'])).length;
            const categorizedCweCount = cweInjection + cweXss + cwePathTraversal + cweCrypto + cweAuth + cweSsrf;
            const cweOtherCount = Math.max(0, actionableCwes.length - categorizedCweCount);
            // Populate CWE policy elements
            const setCwePolicy = (id, val) => { const el = document.getElementById(id); if (el) el.textContent = val; };
            setCwePolicy('engCweInjection', cweInjection);
            setCwePolicy('engCweXss', cweXss);
            setCwePolicy('engCwePathTraversal', cwePathTraversal);
            setCwePolicy('engCweCrypto', cweCrypto);
            setCwePolicy('engCweAuth', cweAuth);
            setCwePolicy('engCweSsrf', cweSsrf);
            setCwePolicy('engCweOther', cweOtherCount);
            
            // Malware by type - v4.5.22: Include reachability + severity breakdown
            const malware = issues.filter(f => f.type === 'MALWARE' || f.type === 'SUSPICIOUS');
            const malwareReachable = malware.filter(f => getReachabilityState(f) === 'reachable').length;
            const malwareUnknown = malware.filter(f => getReachabilityState(f) === 'unknown').length;
            // Severity breakdown for malware
            const malwareCritical = malware.filter(f => normalizeSeverity(f.severity) === 'CRITICAL').length;
            const malwareHighSev = malware.filter(f => normalizeSeverity(f.severity) === 'HIGH').length;
            const malwareMediumSev = malware.filter(f => normalizeSeverity(f.severity) === 'MEDIUM').length;
            // Categorize by malware type (check description and id for keywords)
            const matchMalwareType = (f, keywords) => {
                const desc = (f.description || '').toLowerCase();
                const id = (f.id || '').toLowerCase();
                return keywords.some(kw => desc.includes(kw) || id.includes(kw));
            };
            const malwareBackdoor = malware.filter(f => matchMalwareType(f, ['backdoor', 'reverse shell', 'remote access'])).length;
            const malwareCrypto = malware.filter(f => matchMalwareType(f, ['crypto', 'miner', 'mining', 'coinhive'])).length;
            const malwareExfil = malware.filter(f => matchMalwareType(f, ['exfil', 'data theft', 'stealer', 'send data'])).length;
            const malwareTypo = malware.filter(f => matchMalwareType(f, ['typosquat', 'typo-squat', 'similar name'])).length;
            const malwareObfuscation = malware.filter(f => matchMalwareType(f, ['obfuscat', 'base64', 'encoded', 'hidden code', 'steganograph'])).length;
            const malwareCmdInject = malware.filter(f => matchMalwareType(f, ['cmd', 'command', 'shell', 'exec', 'os.system', 'subprocess'])).length;
            const categorizedCount = malwareBackdoor + malwareCrypto + malwareExfil + malwareTypo + malwareObfuscation + malwareCmdInject;
            const malwareOther = Math.max(0, malware.length - categorizedCount);
            // Distinct packages with malware (for removal count)
            const malwarePackages = malware.reduce((acc, f) => {
                const pkg = f.package || '';
                if (pkg && !acc.includes(pkg)) acc.push(pkg);
                return acc;
            }, []).length;
            // Populate malware reachability + severity
            const engMalwareReachEl = document.getElementById('engMalwareReachable');
            const engMalwareUnknownEl = document.getElementById('engMalwareUnknown');
            if (engMalwareReachEl) engMalwareReachEl.textContent = malwareReachable;
            if (engMalwareUnknownEl) engMalwareUnknownEl.textContent = malwareUnknown;
            // Populate malware severity
            const engMalwareCriticalEl = document.getElementById('engMalwareCritical');
            const engMalwareHighEl = document.getElementById('engMalwareHigh');
            const engMalwareMediumEl = document.getElementById('engMalwareMedium');
            if (engMalwareCriticalEl) engMalwareCriticalEl.textContent = malwareCritical;
            if (engMalwareHighEl) engMalwareHighEl.textContent = malwareHighSev;
            if (engMalwareMediumEl) engMalwareMediumEl.textContent = malwareMediumSev;
            setEl('engMalwareBackdoor', malwareBackdoor);
            setEl('engMalwareCrypto', malwareCrypto);
            setEl('engMalwareExfil', malwareExfil);
            setEl('engMalwareTypo', malwareTypo);
            const engMalwareObfEl = document.getElementById('engMalwareObfuscation');
            const engMalwareCmdEl = document.getElementById('engMalwareCmdInject');
            if (engMalwareObfEl) engMalwareObfEl.textContent = malwareObfuscation;
            if (engMalwareCmdEl) engMalwareCmdEl.textContent = malwareCmdInject;
            setEl('engMalwareOther', malwareOther);
            setEl('engMalwareTotal', malware.length);
            // v4.5.19: Packages to remove count
            const engMalwarePkgsEl = document.getElementById('engMalwarePackages');
            if (engMalwarePkgsEl) engMalwarePkgsEl.textContent = malwarePackages;
            
            // Config issues by type
            const configs = issues.filter(f => f.type === 'CONFIG');
            const configK8s = configs.filter(f => (f.file_path || '').toLowerCase().includes('kubernetes') || (f.file_path || '').toLowerCase().includes('k8s') || (f.description || '').toLowerCase().includes('resource limit')).length;
            const configDocker = configs.filter(f => (f.file_path || '').toLowerCase().includes('dockerfile') || (f.description || '').toLowerCase().includes('docker')).length;
            const configPorts = configs.filter(f => (f.description || '').toLowerCase().includes('port') || (f.description || '').toLowerCase().includes('expose')).length;
            const configOther = configs.length - configK8s - configDocker - configPorts;
            setEl('engConfigK8s', configK8s);
            setEl('engConfigDocker', configDocker);
            setEl('engConfigPorts', configPorts);
            setEl('engConfigOther', Math.max(0, configOther));
            setEl('engConfigTotal', configs.length);
            
            // Health issues (from enrichments or inferred)
            const enrichments = dashboardData.enrichments || {};
            const metrics = dashboardData.metrics || {};
            // v4.5.19: Add packages scanned to health panel
            const engHealthPkgsEl = document.getElementById('engHealthPackagesScanned');
            if (engHealthPkgsEl) engHealthPkgsEl.textContent = fmt(metrics.packages_scanned || 0);
            setEl('engHealthUnmaintained', enrichments.unmaintained || 0);
            setEl('engHealthOutdated', enrichments.outdated || 0);
            setEl('engHealthNoLicense', enrichments.no_license || 0);
            setEl('engHealthLowQuality', enrichments.low_quality || 0);
            setEl('engHealthTotal', (enrichments.unmaintained || 0) + (enrichments.outdated || 0) + (enrichments.no_license || 0) + (enrichments.low_quality || 0));
        }
        
        // v4.5.19: Trends Chart Initialization
        let trendsChart = null;
        
        
// === Trends series builder (Raw / Reachable / Critical / High / Unknown) ===
// P2.53 FIX: Use pre-computed values from trends.data_points (excludes CONFIG, includes AI/DLP)
function buildTrendsSeries(history, aiSecurity) {
  // P2.53: Database pre-computes these values in loaders.py _build_trends_from_history()
  // Use history.raw and history.reachable directly - they already have CONFIG excluded
  const raw = history.map(h => h.raw || 0);
  const reachable = history.map(h => h.reachable || 0);

  const reachableCritical = history.map(h => {
    if (typeof h.reachable_critical === 'number') return h.reachable_critical;
    const reach = h.reachable_issues || 0;
    const denom = (h.critical||0)+(h.high||0)+(h.medium||0)+(h.low||0) || (h.total_issues||1);
    return Math.round(reach * ((h.critical||0) / denom));
  });

  const reachableHigh = history.map(h => {
    if (typeof h.reachable_high === 'number') return h.reachable_high;
    const reach = h.reachable_issues || 0;
    const denom = (h.critical||0)+(h.high||0)+(h.medium||0)+(h.low||0) || (h.total_issues||1);
    return Math.round(reach * ((h.high||0) / denom));
  });

  const unknown = history.map((h, i) => {
    if (typeof h.unknown_issues === 'number') return h.unknown_issues;
    // v4.5.40: Use reachable[i] which already includes AI for latest
    return Math.max(0, (raw[i]||0) - (reachable[i]||0));
  });

  return { raw, reachable, reachableCritical, reachableHigh, unknown };
}

function initTrendsChart(data) {
            // P2.53 FIX: Use pre-computed trends.data_points (has .raw field with CONFIG excluded)
            // NOT scan_history (has total_issues field without .raw)
            const history = data.trends?.data_points || data.scan_history || [];
            const trendsNoData = document.getElementById('trendsNoData');
            const trendsChartWrapper = document.getElementById('trendsChartWrapper');
            const trendsSection = document.getElementById('trendsSection');
            
            // Need at least 2 data points for trends
            if (history.length < 2) {
                if (trendsNoData) trendsNoData.style.display = 'block';
                if (trendsChartWrapper) trendsChartWrapper.style.display = 'none';
                return;
            }
            
            // Show chart, hide no-data message
            if (trendsNoData) trendsNoData.style.display = 'none';
            if (trendsChartWrapper) trendsChartWrapper.style.display = 'block';
            
            // Prepare chart data
            const series = buildTrendsSeries(history, data.ai_security);
            const labels = history.map(h => {
                const date = new Date(h.timestamp);
                return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
            });
            const totalData = history.map(h => h.total_issues || 0);
            const reachableData = history.map(h => h.reachable_issues || 0);
            const criticalData = history.map(h => (h.critical || 0) + (h.high || 0));
            
            // Create/update chart
            const ctx = document.getElementById('trendsChart');
            if (!ctx) return;
            
            if (trendsChart) {
                trendsChart.destroy();
            }
            
            trendsChart = new Chart(ctx, {
                type: 'line',
                data: {
                    labels: labels,
                    datasets: [
      { label: 'Raw', data: series.raw, tension: 0.3, fill: false },
      { label: 'Reachable', data: series.reachable, tension: 0.3, fill: false },
      { label: 'Critical', data: series.reachableCritical, tension: 0.3, fill: false },
      { label: 'High', data: series.reachableHigh, tension: 0.3, fill: false },
      { label: 'Unknown', data: series.unknown, tension: 0.3, fill: false }
    ]},
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    interaction: {
                        intersect: false,
                        mode: 'index'
                    },
                    plugins: {
                        legend: {
                            position: 'top',
                            labels: {
                                color: '#94a3b8',
                                usePointStyle: true,
                                padding: 20
                            }
                        },
                        tooltip: {
                            backgroundColor: 'rgba(15, 23, 42, 0.9)',
                            titleColor: '#f1f5f9',
                            bodyColor: '#94a3b8',
                            borderColor: 'rgba(255,255,255,0.1)',
                            borderWidth: 1,
                            padding: 12,
                            displayColors: true
                        }
                    },
                    scales: {
                        x: {
                            grid: { color: 'rgba(255,255,255,0.05)' },
                            ticks: { color: '#64748b' }
                        },
                        y: {
                            beginAtZero: true,
                            grid: { color: 'rgba(255,255,255,0.05)' },
                            ticks: { color: '#64748b' }
                        }
                    }
                }
            });
            
            // Update summary stats
            const latest = history[history.length - 1];
            const previous = history[history.length - 2];
            
            const updateTrendStat = (valueId, changeId, current, prev) => {
                const valueEl = document.getElementById(valueId);
                const changeEl = document.getElementById(changeId);
                if (valueEl) valueEl.textContent = current;
                if (changeEl) {
                    const diff = current - prev;
                    const pct = prev > 0 ? Math.round((diff / prev) * 100) : 0;
                    if (diff < 0) {
                        changeEl.className = 'trend-stat-change positive';
                        changeEl.textContent = `↓ ${Math.abs(pct)}% (${Math.abs(diff)} fewer)`;
                    } else if (diff > 0) {
                        changeEl.className = 'trend-stat-change negative';
                        changeEl.textContent = `↑ ${pct}% (${diff} more)`;
                    } else {
                        changeEl.className = 'trend-stat-change neutral';
                        changeEl.textContent = '— No change';
                    }
                }
            };
            
            // P2.53 FIX: Use pre-computed values from trends data (already includes AI/DLP, excludes CONFIG)
            // latest.raw and latest.reachable are computed in Python and already have correct counts
            const latestRaw = latest.raw || 0;
            const latestReachable = latest.reachable || 0;
            
            updateTrendStat('trendRawValue', 'trendRawChange', latestRaw, previous.raw || 0);
            updateTrendStat('trendReachableValue', 'trendReachableChange', latestReachable, previous.reachable || 0);
            updateTrendStat('trendCriticalValue', 'trendCriticalChange', (latest.critical || 0) + (latest.high || 0), (previous.critical || 0) + (previous.high || 0));
            updateTrendStat('trendHighValue', 'trendHighChange', latest.high || 0, previous.high || 0);
            updateTrendStat('trendUnknownValue', 'trendUnknownChange', latest.unknown_issues || 0, previous.unknown_issues || 0);
            
            // Fixed count (issues in previous but not in current)
            const fixedCount = Math.max(0, (previous.raw || 0) - (latest.raw || 0));
            const trendFixedValueEl = document.getElementById('trendFixedValue');
            const trendFixedChangeEl = document.getElementById('trendFixedChange');
            if (trendFixedValueEl) trendFixedValueEl.textContent = fixedCount;
            if (trendFixedChangeEl) {
                if (fixedCount > 0) {
                    trendFixedChangeEl.className = 'trend-stat-change positive';
                    trendFixedChangeEl.textContent = `✅ ${fixedCount} resolved`;
                } else {
                    trendFixedChangeEl.className = 'trend-stat-change neutral';
                    trendFixedChangeEl.textContent = '— Since last scan';
                }
            }
        }
        
        // Embedded data (works with file:// protocol)
        renderDashboard();
        initTrendsChart(dashboardData);
        // v4.5.28: Render OWASP and LLM panels
        if (typeof renderOwaspTop10 === 'function') renderOwaspTop10(dashboardData);
        if (typeof renderLlmTop10 === 'function') renderLlmTop10(dashboardData);
    

        // === FILTER FUNCTIONS FOR CLICKABLE NUMBERS ===
        // P2.47: Fixed to use correct filter dropdown IDs and applyFilters function
        function filterBySeverity(severity) {
            console.log('Filtering Security Issues by severity:', severity);
            
            // Wait for DOM to be ready after tab switch
            setTimeout(() => {
                // Clear other filters first
                const typeFilter = document.getElementById('typeFilter');
                const reachableFilter = document.getElementById('reachableFilter');
                const riskFilter = document.getElementById('riskFilter');
                const searchBox = document.getElementById('searchBox');
                
                if (typeFilter) typeFilter.value = '';
                if (reachableFilter) reachableFilter.value = '';
                if (searchBox) searchBox.value = '';
                
                // Set severity filter (riskFilter is the dropdown ID)
                if (riskFilter) riskFilter.value = severity;
                
                // Apply filters
                if (typeof applyFilters === 'function') {
                    applyFilters();
                }
            }, 150);
        }
        
        function filterByReachability(state) {
            console.log('Filtering Security Issues by reachability:', state);
            
            // Normalize state value (UNKNOWN -> unknown)
            const normalizedState = state.toLowerCase();
            
            // Wait for DOM to be ready after tab switch
            setTimeout(() => {
                // Clear other filters first
                const typeFilter = document.getElementById('typeFilter');
                const riskFilter = document.getElementById('riskFilter');
                const reachableFilter = document.getElementById('reachableFilter');
                const searchBox = document.getElementById('searchBox');
                
                if (typeFilter) typeFilter.value = '';
                if (riskFilter) riskFilter.value = '';
                if (searchBox) searchBox.value = '';
                
                // Set reachability filter
                if (reachableFilter) reachableFilter.value = normalizedState;
                
                // Apply filters
                if (typeof applyFilters === 'function') {
                    applyFilters();
                }
            }, 150);
        }
        
        // P2.47: Combined filter - filter by both type and severity
        function filterByTypeAndSeverity(type, severity) {
            console.log('Filtering Security Issues by type:', type, 'and severity:', severity);
            
            // Wait for DOM to be ready after tab switch
            setTimeout(() => {
                const typeFilter = document.getElementById('typeFilter');
                const riskFilter = document.getElementById('riskFilter');
                const reachableFilter = document.getElementById('reachableFilter');
                const searchBox = document.getElementById('searchBox');
                
                // Clear search and reachability
                if (searchBox) searchBox.value = '';
                if (reachableFilter) reachableFilter.value = '';
                
                // Set type and severity filters
                if (typeFilter) typeFilter.value = type;
                if (riskFilter) riskFilter.value = severity;
                
                // Apply filters
                if (typeof applyFilters === 'function') {
                    applyFilters();
                }
            }, 150);
        }
        
        // P2.52: Combined filter - filter by both type and reachability (for Review Required breakdown)
        function filterByTypeAndReachability(type, reachability) {
            console.log('Filtering Security Issues by type:', type, 'and reachability:', reachability);
            
            // Normalize reachability value
            const normalizedReach = reachability.toLowerCase();
            
            // Wait for DOM to be ready after tab switch
            setTimeout(() => {
                const typeFilter = document.getElementById('typeFilter');
                const riskFilter = document.getElementById('riskFilter');
                const reachableFilter = document.getElementById('reachableFilter');
                const searchBox = document.getElementById('searchBox');
                
                // Clear search and severity
                if (searchBox) searchBox.value = '';
                if (riskFilter) riskFilter.value = '';
                
                // Set type and reachability filters
                if (typeFilter) typeFilter.value = type;
                if (reachableFilter) reachableFilter.value = normalizedReach;
                
                // Apply filters
                if (typeof applyFilters === 'function') {
                    applyFilters();
                }
            }, 150);
        }

        // === EXPOSE FILTER FUNCTIONS GLOBALLY FOR ONCLICK HANDLERS ===
        window.filterBySeverity = filterBySeverity;
        window.filterByReachability = filterByReachability;
        window.filterByTypeAndSeverity = filterByTypeAndSeverity;
        window.filterByTypeAndReachability = filterByTypeAndReachability;
        window.applyFilters = applyFilters;
        window.toggleMainPanel = toggleMainPanel;
        window.toggleSection = toggleSection;

        // P2.50: Filter Security Issues by type and switch to Security Issues tab
        function filterSecurityIssuesByType(type) {
            console.log('Filtering Security Issues by type:', type);
            
            // Switch to Security Issues tab
            const securityTab = document.querySelector('[data-tab="security-issues"]');
            if (securityTab) securityTab.click();
            
            // Wait for tab switch, then apply filter
            setTimeout(() => {
                const typeFilter = document.getElementById('typeFilter');
                const searchBox = document.getElementById('searchBox');
                const riskFilter = document.getElementById('riskFilter');
                const reachableFilter = document.getElementById('reachableFilter');
                
                // Clear other filters
                if (searchBox) searchBox.value = '';
                if (riskFilter) riskFilter.value = '';
                if (reachableFilter) reachableFilter.value = '';
                
                // Set type filter
                if (typeFilter) typeFilter.value = type;
                
                // Apply filters
                if (typeof applyFilters === 'function') {
                    applyFilters();
                }
            }, 150);
        }
        window.filterSecurityIssuesByType = filterSecurityIssuesByType;

        // P2.60: Filter by OWASP category (for OWASP Top 10 card clicks)
        // Maps OWASP categories to issue types or uses search
        function filterByOwaspCategory(category, isLlm = false) {
            console.log('Filtering by OWASP category:', category, 'isLlm:', isLlm);
            
            // Switch to Security Issues tab first (use 'security-issues' not 'tab-security-issues')
            if (typeof activateTab === 'function') {
                activateTab('security-issues');
            }
            
            setTimeout(() => {
                const typeFilter = document.getElementById('typeFilter');
                const riskFilter = document.getElementById('riskFilter');
                const reachableFilter = document.getElementById('reachableFilter');
                const searchBox = document.getElementById('searchBox');
                
                // Clear all filters first
                if (riskFilter) riskFilter.value = '';
                if (reachableFilter) reachableFilter.value = '';
                if (searchBox) searchBox.value = '';
                if (typeFilter) typeFilter.value = '';
                
                // LLM/AI categories - filter by AI type only (search doesn't work reliably)
                if (isLlm || category.startsWith('LLM')) {
                    // Filter to AI type - the owasp_llm field may not be searchable
                    if (typeFilter) typeFilter.value = 'AI';
                    // Don't set search - just filter by type
                }
                // OWASP Web categories
                else if (category === 'A06') {
                    // A06: Vulnerable Components = CVEs
                    if (typeFilter) typeFilter.value = 'CVE';
                }
                else if (category === 'A05') {
                    // A05: Security Misconfiguration = Config issues
                    if (typeFilter) typeFilter.value = 'CONFIG';
                }
                else if (category === 'A03') {
                    // A03: Injection = CWEs with injection patterns
                    if (typeFilter) typeFilter.value = 'CWE';
                    if (searchBox) searchBox.value = 'injection';
                }
                else {
                    // Other OWASP categories - search by category code in compliance tags
                    if (searchBox) searchBox.value = category;
                }
                
                // Apply filters
                if (typeof applyFilters === 'function') {
                    applyFilters();
                }
            }, 150);
        }
        window.filterByOwaspCategory = filterByOwaspCategory;


