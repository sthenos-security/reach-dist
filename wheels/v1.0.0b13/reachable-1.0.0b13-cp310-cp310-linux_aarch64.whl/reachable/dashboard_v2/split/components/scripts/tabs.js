/* Tabs wiring + validation helpers */
(function(){
  function activateTab(name){
    document.querySelectorAll('.tab').forEach(t=>t.classList.toggle('active', t.dataset.tab===name));
    document.querySelectorAll('.tab-page').forEach(p=>p.classList.toggle('active', p.id===`tab-${name}`));
  }

  function moveRiskInventory(){
    const mount = document.getElementById('inventoryMount');
    const inv = document.querySelector('.risk-inventory-wrapper');
    if(mount && inv && !mount.contains(inv)){
      mount.appendChild(inv);
      // v4.5.36 fix: Match OWASP panel structure exactly
      // margin:20px like main-panel-wrapper, padding:20px for header negative margins
      inv.style.margin = '20px';
      inv.style.padding = '20px';
      inv.style.borderRadius = '12px';
      inv.style.boxSizing = 'border-box';
    }
  }


  function buildOwaspSummary(){
    const mount = document.getElementById('owaspSummary');
    if(!mount) return;
    const data = (typeof dashboardData !== 'undefined') ? dashboardData : null;
    
    // Use owasp_web data from transformers.py (CWE→OWASP mapping)
    const owaspWeb = data && data.owasp_web;
    if(!owaspWeb || owaspWeb.total === 0){
      // Fallback: try legacy compliance_mapping approach
      if(!data || !Array.isArray(data.issues)){
        mount.innerHTML = '<div style="color:#94a3b8;font-size:12px;">No dataset loaded.</div>';
        return;
      }
      const counts = {};
      for(const f of data.issues){
        const mapping = f.compliance_mapping || {};
        const owasp = mapping.OWASP || mapping.Owasp || mapping.owasp;
        if(Array.isArray(owasp)){
          for(const code of owasp){ counts[String(code)] = (counts[String(code)]||0) + 1; }
        }
      }
      const rows = Object.entries(counts).sort((a,b)=>b[1]-a[1]);
      if(rows.length===0){
        mount.innerHTML = '<div style="color:#94a3b8;font-size:12px;">No OWASP findings detected in this scan.</div>';
        return;
      }
      mount.innerHTML = `<div class="table-container" style="border:1px solid rgba(148,163,184,0.2);"><table><thead><tr><th>Category</th><th style="text-align:right;">Count</th></tr></thead><tbody>${rows.slice(0,12).map(([k,v])=>`<tr><td>${k}</td><td style="text-align:right;">${v}</td></tr>`).join('')}</tbody></table></div>`;
      return;
    }

    // Use owasp_web data structure
    const byCat = owaspWeb.by_category || {};
    const names = owaspWeb.category_names || {};
    const bySev = owaspWeb.by_severity || {};
    const total = owaspWeb.total || 0;
    const reachable = owaspWeb.reachable || 0;

    // Build OWASP grid cards
    const categories = ['A01','A02','A03','A04','A05','A06','A07','A08','A09','A10'];
    const icons = {A01:'🚫',A02:'🔐',A03:'💉',A04:'📐',A05:'⚙️',A06:'📦',A07:'🔑',A08:'✅',A09:'📝',A10:'🌐'};
    
    const byCatBreakdown = owaspWeb.by_category_breakdown || {};
    const cards = categories.map(cat => {
      const count = byCat[cat] || 0;
      const name = names[cat] || cat;
      const hasIssues = count > 0;
      const countClass = count === 0 ? 'zero' : (count >= 10 ? 'critical' : 'warning');
      const bd = byCatBreakdown[cat] || {reachable:0,unreachable:0,unknown:count};
      const breakdownHtml = count > 0 ? `<div style="display:flex;flex-direction:column;gap:2px;margin-top:8px;font-size:10px;border-top:1px solid #334155;padding-top:6px;">
        <div style="display:flex;justify-content:space-between;"><span style="color:#dc2626;">🔥 Reachable</span><span style="font-weight:600;color:#dc2626;">${bd.reachable}</span></div>
        <div style="display:flex;justify-content:space-between;"><span style="color:#22c55e;">✅ Unreachable</span><span style="font-weight:600;color:#22c55e;">${bd.unreachable}</span></div>
        <div style="display:flex;justify-content:space-between;"><span style="color:#94a3b8;">❓ Unknown</span><span style="font-weight:600;color:#94a3b8;">${bd.unknown}</span></div>
      </div>` : '';
      return `<div class="owasp-card ${hasIssues ? 'has-issues' : ''}" style="min-width:160px;">
        <div class="owasp-card-id">${icons[cat] || '🔒'} ${cat}</div>
        <div class="owasp-card-name">${name}</div>
        <div class="owasp-card-count ${countClass}">${count}</div>
        ${breakdownHtml}
      </div>`;
    }).join('');

    const sevBar = `<div style="display:flex;gap:12px;margin-bottom:16px;font-size:12px;">
      <span style="color:#f87171;">● Critical: ${bySev.CRITICAL||0}</span>
      <span style="color:#f59e0b;">● High: ${bySev.HIGH||0}</span>
      <span style="color:#eab308;">● Medium: ${bySev.MEDIUM||0}</span>
      <span style="color:#22c55e;">● Low: ${bySev.LOW||0}</span>
      <span style="color:#94a3b8;margin-left:auto;">Total: ${total} (${reachable} reachable)</span>
    </div>`;

    mount.innerHTML = `
      <div style="display:flex;flex-direction:column;gap:12px;">
        <div style="font-size:14px;font-weight:700;color:#e2e8f0;">OWASP Top 10 (2021) - Web Application Security</div>
        ${sevBar}
        <div class="owasp-grid">${cards}</div>
        <div style="font-size:11px;color:#64748b;">Tip: CVE findings map to A06 (Vulnerable Components). CWE findings map to other categories based on weakness type.</div>
      </div>
    `;
  }


  function buildLlmSummary(){
    const mount = document.getElementById('llmSummary');
    if(!mount) return;
    const data = (typeof dashboardData !== 'undefined') ? dashboardData : null;
    
    // Use ai_security data from scan (--enable-ai flag)
    const aiSec = data && data.ai_security;
    if(!aiSec || !aiSec.enabled || aiSec.total === 0){
      mount.innerHTML = `
        <div style="display:flex;flex-direction:column;gap:10px;">
          <div style="font-size:14px;font-weight:700;color:#e2e8f0;">AI / Agent Security (OWASP LLM Top 10)</div>
          <div style="color:#94a3b8;font-size:12px;">No AI security findings in this scan. Use <code style="color:#4ade80;">--enable-ai</code> flag to scan for OWASP LLM Top 10 vulnerabilities.</div>
          <div style="padding:16px;background:rgba(34,197,94,0.1);border:1px solid rgba(34,197,94,0.3);border-radius:8px;margin-top:8px;">
            <div style="color:#22c55e;font-weight:600;">✅ No AI/LLM vulnerabilities detected</div>
            <div style="color:#94a3b8;font-size:11px;margin-top:4px;">This scan did not detect prompt injection, excessive agency, or other LLM risks.</div>
          </div>
        </div>
      `;
      return;
    }

    // OWASP LLM Top 10 (2025) definitions
    const llmDefs = {
      LLM01: {name:'Prompt Injection',icon:'💉',color:'#dc2626'},
      LLM02: {name:'Sensitive Information Disclosure',icon:'🔓',color:'#f59e0b'},
      LLM03: {name:'Supply Chain',icon:'📦',color:'#f59e0b'},
      LLM04: {name:'Data and Model Poisoning',icon:'☠️',color:'#eab308'},
      LLM05: {name:'Improper Output Handling',icon:'⚠️',color:'#dc2626'},
      LLM06: {name:'Excessive Agency',icon:'🤖',color:'#dc2626'},
      LLM07: {name:'System Prompt Leakage',icon:'📋',color:'#eab308'},
      LLM08: {name:'Vector and Embedding Weaknesses',icon:'🔢',color:'#22c55e'},
      LLM09: {name:'Misinformation',icon:'❓',color:'#22c55e'},
      LLM10: {name:'Unbounded Consumption',icon:'📈',color:'#22c55e'},
      MCP:   {name:'MCP Security',icon:'🔌',color:'#f59e0b'},
      CONTROLS:{name:'Missing Controls',icon:'🛡️',color:'#eab308'},
      NONE:  {name:'Uncategorized',icon:'📋',color:'#64748b'},
      OTHER: {name:'Other',icon:'📋',color:'#64748b'}
    };

    const total = aiSec.total || 0;
    const reachable = aiSec.reachable || total;
    const guarded = aiSec.guarded || 0;
    const unguarded = total - guarded;
    const byOwasp = aiSec.by_owasp || {};
    const bySev = aiSec.by_severity || {};

    // Summary metrics
    const metrics = `<div style="display:grid;grid-template-columns:repeat(4,1fr);gap:12px;margin-bottom:16px;">
      <div style="background:rgba(255,255,255,0.05);padding:12px;border-radius:8px;text-align:center;">
        <div style="font-size:24px;font-weight:700;color:#f1f5f9;">${total}</div>
        <div style="font-size:11px;color:#94a3b8;">Total Findings</div>
      </div>
      <div style="background:rgba(255,255,255,0.05);padding:12px;border-radius:8px;text-align:center;">
        <div style="font-size:24px;font-weight:700;color:#f59e0b;">${reachable}</div>
        <div style="font-size:11px;color:#94a3b8;">Reachable</div>
      </div>
      <div style="background:rgba(34,197,94,0.1);padding:12px;border-radius:8px;text-align:center;border:1px solid rgba(34,197,94,0.3);">
        <div style="font-size:24px;font-weight:700;color:#22c55e;">${guarded}</div>
        <div style="font-size:11px;color:#94a3b8;">Guarded</div>
      </div>
      <div style="background:rgba(220,38,38,0.1);padding:12px;border-radius:8px;text-align:center;border:1px solid rgba(220,38,38,0.3);">
        <div style="font-size:24px;font-weight:700;color:#dc2626;">${unguarded}</div>
        <div style="font-size:11px;color:#94a3b8;">Unguarded</div>
      </div>
    </div>`;

    // Build category cards (only show categories with findings)
    const byOwaspBreakdown = aiSec.by_owasp_breakdown || {};
    const sortedCats = Object.entries(byOwasp).sort((a,b) => b[1] - a[1]);
    const cards = sortedCats.map(([cat, count]) => {
      const def = llmDefs[cat] || llmDefs.OTHER;
      const bd = byOwaspBreakdown[cat] || {reachable:0,unreachable:0,unknown:count};
      const breakdownHtml = `<div style="display:flex;flex-direction:column;gap:2px;margin-top:8px;font-size:10px;border-top:1px solid #334155;padding-top:6px;">
        <div style="display:flex;justify-content:space-between;"><span style="color:#dc2626;">🔥 Reachable</span><span style="font-weight:600;color:#dc2626;">${bd.reachable}</span></div>
        <div style="display:flex;justify-content:space-between;"><span style="color:#22c55e;">✅ Unreachable</span><span style="font-weight:600;color:#22c55e;">${bd.unreachable}</span></div>
        <div style="display:flex;justify-content:space-between;"><span style="color:#94a3b8;">❓ Unknown</span><span style="font-weight:600;color:#94a3b8;">${bd.unknown}</span></div>
      </div>`;
      return `<div class="owasp-card has-issues" style="border-left:3px solid ${def.color};min-width:160px;">
        <div class="owasp-card-id">${def.icon} ${cat}</div>
        <div class="owasp-card-name">${def.name}</div>
        <div class="owasp-card-count warning">${count}</div>
        ${breakdownHtml}
      </div>`;
    }).join('');

    // Risk indicator
    const riskLevel = unguarded > 20 ? 'CRITICAL' : (unguarded > 5 ? 'HIGH' : (unguarded > 0 ? 'MEDIUM' : 'LOW'));
    const riskColors = {CRITICAL:'#dc2626',HIGH:'#f59e0b',MEDIUM:'#eab308',LOW:'#22c55e'};
    const riskBadge = `<span style="background:${riskColors[riskLevel]};color:white;padding:2px 8px;border-radius:4px;font-size:11px;font-weight:600;">${riskLevel}</span>`;

    mount.innerHTML = `
      <div style="display:flex;flex-direction:column;gap:12px;">
        <div style="display:flex;justify-content:space-between;align-items:center;">
          <div style="font-size:14px;font-weight:700;color:#e2e8f0;">AI / Agent Security (OWASP LLM Top 10 2025)</div>
          ${riskBadge}
        </div>
        ${metrics}
        <div style="font-size:12px;font-weight:600;color:#94a3b8;margin-top:8px;">Findings by Category</div>
        <div class="owasp-grid" style="grid-template-columns:repeat(auto-fill,minmax(140px,1fr));">${cards || '<div style="color:#94a3b8;">No categorized findings</div>'}</div>
        <div style="font-size:11px;color:#64748b;margin-top:8px;">
          <b>Guards detected:</b> Input validation, output sanitization, human-in-the-loop, rate limiting, and other mitigations reduce risk score.
          <a href="https://genai.owasp.org/llm-top-10/" target="_blank" style="color:#4ade80;margin-left:8px;">Learn more →</a>
        </div>
      </div>
    `;
  }

  function buildDlpSummary(){
    const statsMount = document.getElementById('dlpSummaryStats');
    const typeMount = document.getElementById('dlpByType');
    const complianceMount = document.getElementById('dlpComplianceImpact');
    const tableMount = document.getElementById('dlpFindingsTable');
    const noDataMount = document.getElementById('dlpNoData');
    
    if(!statsMount) return;
    
    const data = (typeof dashboardData !== 'undefined') ? dashboardData : null;
    const dlpFindings = data && data.dlp_findings ? data.dlp_findings : [];
    
    if(!dlpFindings || dlpFindings.length === 0){
      if(noDataMount) noDataMount.style.display = 'block';
      return;
    }
    if(noDataMount) noDataMount.style.display = 'none';
    
    // Summary stats
    const total = dlpFindings.length;
    const bySeverity = {CRITICAL:0, HIGH:0, MEDIUM:0, LOW:0};
    const byPiiType = {};
    const bySinkType = {};
    const byCompliance = {};
    
    for(const f of dlpFindings){
      const sev = (f.severity || 'MEDIUM').toUpperCase();
      if(bySeverity[sev] !== undefined) bySeverity[sev]++;
      
      const pii = f.pii_type || f.source_type || 'Unknown';
      byPiiType[pii] = (byPiiType[pii]||0) + 1;
      
      const sink = f.sink_type || f.flow_type || 'Unknown';
      bySinkType[sink] = (bySinkType[sink]||0) + 1;
      
      const regs = f.compliance || f.regulations || [];
      for(const r of (Array.isArray(regs) ? regs : [])){
        byCompliance[r] = (byCompliance[r]||0) + 1;
      }
    }
    
    // Stats cards - clickable to filter Security Issues
    statsMount.innerHTML = `
      <div style="background:#0f172a;padding:12px 16px;border-radius:8px;border-left:4px solid #8b5cf6;cursor:pointer;" onclick="activateTab('security-issues');document.getElementById('typeFilter').value='DLP';document.getElementById('riskFilter').value='';if(typeof applyFilters==='function')applyFilters();">
        <div style="font-size:24px;font-weight:700;color:#8b5cf6;">${total}</div>
        <div style="font-size:11px;color:#94a3b8;">Total DLP Findings</div>
      </div>
      <div style="background:#0f172a;padding:12px 16px;border-radius:8px;border-left:4px solid #dc2626;cursor:pointer;" onclick="activateTab('security-issues');window.filterByTypeAndSeverity('DLP','CRITICAL');">
        <div style="font-size:24px;font-weight:700;color:#dc2626;">${bySeverity.CRITICAL}</div>
        <div style="font-size:11px;color:#94a3b8;">Critical</div>
      </div>
      <div style="background:#0f172a;padding:12px 16px;border-radius:8px;border-left:4px solid #f59e0b;cursor:pointer;" onclick="activateTab('security-issues');window.filterByTypeAndSeverity('DLP','HIGH');">
        <div style="font-size:24px;font-weight:700;color:#f59e0b;">${bySeverity.HIGH}</div>
        <div style="font-size:11px;color:#94a3b8;">High</div>
      </div>
      <div style="background:#0f172a;padding:12px 16px;border-radius:8px;border-left:4px solid #eab308;cursor:pointer;" onclick="activateTab('security-issues');window.filterByTypeAndSeverity('DLP','MEDIUM');">
        <div style="font-size:24px;font-weight:700;color:#eab308;">${bySeverity.MEDIUM}</div>
        <div style="font-size:11px;color:#94a3b8;">Medium</div>
      </div>
    `;
    
    // By Type panels
    const piiHtml = Object.entries(byPiiType).sort((a,b)=>b[1]-a[1]).slice(0,6)
      .map(([k,v])=>`<div style="display:flex;justify-content:space-between;padding:4px 0;border-bottom:1px solid #334155;"><span style="color:#cbd5e1;">${k}</span><span style="color:#8b5cf6;font-weight:600;">${v}</span></div>`).join('');
    const sinkHtml = Object.entries(bySinkType).sort((a,b)=>b[1]-a[1]).slice(0,6)
      .map(([k,v])=>`<div style="display:flex;justify-content:space-between;padding:4px 0;border-bottom:1px solid #334155;"><span style="color:#cbd5e1;">${k}</span><span style="color:#f59e0b;font-weight:600;">${v}</span></div>`).join('');
    const sevHtml = Object.entries(bySeverity).filter(([k,v])=>v>0)
      .map(([k,v])=>{const c={CRITICAL:'#dc2626',HIGH:'#f59e0b',MEDIUM:'#eab308',LOW:'#22c55e'}[k];const label=k.charAt(0)+k.slice(1).toLowerCase();return `<div style="display:flex;justify-content:space-between;padding:4px 0;border-bottom:1px solid #334155;cursor:pointer;" onclick="activateTab('security-issues');window.filterByTypeAndSeverity('DLP','${k}');"><span style="color:#cbd5e1;">${label}</span><span style="color:${c};font-weight:600;">${v}</span></div>`;}).join('');
    
    if(typeMount) typeMount.innerHTML = `
      <div style="background:#0f172a;padding:16px;border-radius:8px;">
        <div style="font-size:12px;font-weight:600;color:#94a3b8;margin-bottom:12px;">BY PII TYPE</div>
        ${piiHtml || '<div style="color:#64748b;">No data</div>'}
      </div>
      <div style="background:#0f172a;padding:16px;border-radius:8px;">
        <div style="font-size:12px;font-weight:600;color:#94a3b8;margin-bottom:12px;">BY SINK TYPE</div>
        ${sinkHtml || '<div style="color:#64748b;">No data</div>'}
      </div>
      <div style="background:#0f172a;padding:16px;border-radius:8px;">
        <div style="font-size:12px;font-weight:600;color:#94a3b8;margin-bottom:12px;">BY SEVERITY</div>
        ${sevHtml || '<div style="color:#64748b;">No data</div>'}
      </div>
    `;
    
    // Compliance impact
    const compHtml = Object.entries(byCompliance).sort((a,b)=>b[1]-a[1])
      .map(([k,v])=>`<span style="background:#1e3a5f;color:#60a5fa;padding:4px 10px;border-radius:4px;font-size:11px;font-weight:600;">${k}: ${v}</span>`).join(' ');
    if(complianceMount) complianceMount.innerHTML = compHtml ? `
      <div style="font-size:12px;font-weight:600;color:#94a3b8;margin-bottom:8px;">COMPLIANCE IMPACT</div>
      <div style="display:flex;flex-wrap:wrap;gap:8px;">${compHtml}</div>
    ` : '';
    
    // Findings table (top 20)
    const rows = dlpFindings.slice(0,20).map((f,i)=>{
      const sevColor = {CRITICAL:'#dc2626',HIGH:'#f59e0b',MEDIUM:'#eab308',LOW:'#22c55e'}[(f.severity||'MEDIUM').toUpperCase()] || '#94a3b8';
      
      // v4.6.3: Fix call path display - DLP findings are always reachable (they have data flow)
      // Show actual path if available, otherwise show "Confirmed flow" (not "Direct reference")
      let callPathHtml = '';
      if (f.call_path && f.call_path.length > 0) {
        callPathHtml = f.call_path.map((step,idx)=>`<span style="color:${idx===0?'#22c55e':idx===f.call_path.length-1?'#f87171':'#94a3b8'};">${step}</span>`).join(' <span style="color:#4ade80;">→</span> ');
      } else {
        // DLP findings always represent actual data flow - they ARE reachable
        callPathHtml = `<span style="color:#22c55e;">${f.pii_type || 'data'}</span> <span style="color:#4ade80;">→</span> <span style="color:#f87171;">${f.sink_type || 'sink'}</span>`;
      }
      
      // v4.6.3: Fix location - use file_path and line_start (not file/line)
      const filePath = f.file_path || f.file || '';
      const lineNum = f.line_start || f.line || '';
      const locDisplay = filePath ? (filePath.length > 30 ? '...' + filePath.slice(-27) : filePath) + (lineNum ? ':' + lineNum : '') : '-';
      
      return `
        <tr style="border-bottom:1px solid #334155;">
          <td style="padding:8px;"><span style="background:${sevColor};color:white;padding:2px 6px;border-radius:4px;font-size:10px;">${(f.severity||'MED').toUpperCase().slice(0,4)}</span></td>
          <td style="padding:8px;color:#cbd5e1;">${f.pii_type || f.source_type || '-'}</td>
          <td style="padding:8px;color:#f59e0b;">${f.sink_type || f.flow_type || '-'}</td>
          <td style="padding:8px;color:#94a3b8;font-family:monospace;font-size:11px;" title="${filePath}">${locDisplay}</td>
          <td style="padding:8px;font-size:11px;">${callPathHtml}</td>
        </tr>`;
    }).join('');
    
    if(tableMount) tableMount.innerHTML = `
      <div style="font-size:12px;font-weight:600;color:#94a3b8;margin-bottom:12px;">FINDINGS (Top 20)</div>
      <table style="width:100%;border-collapse:collapse;font-size:12px;">
        <thead><tr style="border-bottom:2px solid #475569;">
          <th style="padding:8px;text-align:left;color:#64748b;">Sev</th>
          <th style="padding:8px;text-align:left;color:#64748b;">PII Type</th>
          <th style="padding:8px;text-align:left;color:#64748b;">Sink</th>
          <th style="padding:8px;text-align:left;color:#64748b;">Location</th>
          <th style="padding:8px;text-align:left;color:#64748b;">Call Graph</th>
        </tr></thead>
        <tbody>${rows}</tbody>
      </table>
    `;
  }

  document.addEventListener('DOMContentLoaded', ()=>{
    moveRiskInventory();

    // Build summaries AFTER renderDashboard() runs (it is invoked in the main script block).
    // We schedule a microtask to run after the current call stack.
    setTimeout(()=>{
      renderDashboard();
      initTrendsChart(dashboardData);
      buildOwaspSummary();
      buildLlmSummary();
      buildDlpSummary();
    }, 0);
  });

  document.addEventListener('click', (e)=>{
    const btn = e.target && e.target.closest ? e.target.closest('.tab') : null;
    if(!btn) return;
    const name = btn.dataset.tab;
    activateTab(name);

    // v4.5.39 FIX: Clear search/filters when switching to security-issues tab
    if(name==='security-issues'){
      const searchBox = document.getElementById('searchBox');
      const complianceFilter = document.getElementById('complianceFilter');
      if(searchBox) searchBox.value = '';
      if(complianceFilter) complianceFilter.value = '';
      if(typeof applyFilters === 'function') applyFilters();
    }

    if(name==='inventory'){
      // ensure inventory section is expanded when visiting inventory tab
      try{
        if(typeof toggleSection==='function'){
          const content = document.getElementById('inventorySectionContent');
          if(content && content.style.display==='none'){ toggleSection('inventory'); }
        }
      } catch(_){}
    }
  });

  // Expose activateTab globally for onclick handlers
  window.activateTab = activateTab;

  // Default tab
  activateTab('risk');
})();
</script>


<div class="footer">
        <p style="margin-bottom: 6px;"><span style="font-weight: 600;">ΣReachable</span> <span id="footerScanMeta" style="font-family: 'Monaco', 'Courier New', monospace; color: #94a3b8; margin-left: 8px;"></span></p>
        <p style="margin-bottom: 6px;">Σthenos Security © 2026 Sthenos Security. All rights reserved.</p>
        <p style="font-size: 10px; color: rgba(255,255,255,0.5); max-width: 800px; margin-left: auto; margin-right: auto;">
            ⚠️ Results are risk-informed guidance based on available data sources; not a guarantee of security or compliance.
        </p>
    </div>


