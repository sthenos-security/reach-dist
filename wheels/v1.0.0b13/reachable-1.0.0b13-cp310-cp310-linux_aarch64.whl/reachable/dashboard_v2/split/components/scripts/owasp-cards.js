// OWASP Top 10 (2021) Category Info
const OWASP_2021 = {
  A01: { name: 'Broken Access Control', icon: '🔓', color: '#ef4444', desc: 'Access control failures, privilege escalation' },
  A02: { name: 'Cryptographic Failures', icon: '🔐', color: '#f97316', desc: 'Weak crypto, sensitive data exposure' },
  A03: { name: 'Injection', icon: '💉', color: '#dc2626', desc: 'SQL, NoSQL, OS, LDAP injection' },
  A04: { name: 'Insecure Design', icon: '📐', color: '#eab308', desc: 'Missing security controls, flawed design' },
  A05: { name: 'Security Misconfiguration', icon: '⚙️', color: '#84cc16', desc: 'Default configs, verbose errors' },
  A06: { name: 'Vulnerable Components', icon: '📦', color: '#22c55e', desc: 'Outdated libraries, known CVEs' },
  A07: { name: 'Auth Failures', icon: '🔑', color: '#14b8a6', desc: 'Broken auth, session management' },
  A08: { name: 'Data Integrity', icon: '🧬', color: '#06b6d4', desc: 'Insecure deserialization, CI/CD flaws' },
  A09: { name: 'Logging Failures', icon: '📝', color: '#3b82f6', desc: 'Missing logs, insufficient monitoring' },
  A10: { name: 'SSRF', icon: '🌐', color: '#8b5cf6', desc: 'Server-side request forgery' }
};

// OWASP LLM Top 10 (2025) Category Info
const OWASP_LLM_2025 = {
  LLM01: { name: 'Prompt Injection', icon: '💬', color: '#dc2626', desc: 'Direct/indirect prompt manipulation' },
  LLM02: { name: 'Sensitive Info Disclosure', icon: '🔍', color: '#ef4444', desc: 'PII/secrets in responses' },
  LLM03: { name: 'Supply Chain', icon: '📦', color: '#f97316', desc: 'Compromised models, data poisoning' },
  LLM04: { name: 'Data & Model Poisoning', icon: '☠️', color: '#eab308', desc: 'Training data manipulation' },
  LLM05: { name: 'Improper Output Handling', icon: '📤', color: '#84cc16', desc: 'XSS, SSRF via LLM output' },
  LLM06: { name: 'Excessive Agency', icon: '🤖', color: '#22c55e', desc: 'Overprivileged actions, tool misuse' },
  LLM07: { name: 'System Prompt Leakage', icon: '🔓', color: '#14b8a6', desc: 'System instruction exposure' },
  LLM08: { name: 'Vector/Embedding Weakness', icon: '📊', color: '#06b6d4', desc: 'RAG manipulation, embedding attacks' },
  LLM09: { name: 'Misinformation', icon: '❌', color: '#3b82f6', desc: 'Hallucination, false content' },
  LLM10: { name: 'Unbounded Consumption', icon: '💸', color: '#8b5cf6', desc: 'DoS via resource exhaustion' }
};

// Agentic Security Index (ASI) 2025
const OWASP_ASI_2025 = {
  ASI01: { name: 'Agent Goal Hijacking', icon: '🎯', color: '#dc2626', desc: 'Adversarial manipulation of agent objectives' },
  ASI02: { name: 'Tool Misuse', icon: '🛠️', color: '#ef4444', desc: 'Unintended or malicious tool invocation' },
  ASI03: { name: 'Identity & Privilege Abuse', icon: '🔑', color: '#f97316', desc: 'Agents hold and abuse credentials' },
  ASI04: { name: 'Supply Chain Vulnerabilities', icon: '🔗', color: '#eab308', desc: 'Compromised agent dependencies' },
  ASI05: { name: 'Unexpected Code Execution', icon: '⚡', color: '#84cc16', desc: 'Agents trigger unintended system actions' },
  ASI06: { name: 'Memory & Context Poisoning', icon: '🧠', color: '#22c55e', desc: 'Corrupted persistent state/memory' },
  ASI07: { name: 'Inter-Agent Communication', icon: '🔗', color: '#14b8a6', desc: 'Insecure agent-to-agent messaging' },
  ASI08: { name: 'Cascading Failures', icon: '💥', color: '#06b6d4', desc: 'Multi-system chain reactions' },
  ASI09: { name: 'Human-Agent Trust Exploit', icon: '🤝', color: '#3b82f6', desc: 'Social engineering via agent trust' },
  ASI10: { name: 'Rogue Agents', icon: '👾', color: '#8b5cf6', desc: 'Agents acting outside boundaries' }
};

// LLM → ASI Mapping (same detection, dual tags)
const LLM_ASI_MAPPING = {
  LLM01: { asi: ['ASI01', 'ASI06'], desc: 'Prompt injection → Goal hijack, Memory poison' },
  LLM03: { asi: ['ASI04'], desc: 'Supply chain risks' },
  LLM05: { asi: ['ASI04', 'ASI05'], desc: 'Output handling → Code execution' },
  LLM06: { asi: ['ASI02', 'ASI03', 'ASI05', 'ASI09'], desc: 'Excessive agency → Tool misuse, Privilege abuse' },
  LLM09: { asi: ['ASI09'], desc: 'Overreliance → Trust exploitation' },
  LLM10: { asi: ['ASI08'], desc: 'Unbounded → Cascading failures' }
};

// ASI categories that have NO LLM equivalent (truly new agentic risks)
const ASI_ONLY = ['ASI07', 'ASI10'];

// LLM categories that are model-centric only (no agentic mapping)
const LLM_ONLY = ['LLM02', 'LLM04', 'LLM07', 'LLM08'];

function renderOwaspTop10(data) {
  const statsEl = document.getElementById('owaspSummaryStats');
  const gridEl = document.getElementById('owaspCategoryGrid');
  const noDataEl = document.getElementById('owaspNoData');
  if (!statsEl || !gridEl) return;

  const owasp = data.owasp_web || {};
  const byCategory = owasp.by_category || {};
  const byCategoryBreakdown = owasp.by_category_breakdown || {};
  const bySeverity = owasp.by_severity || {};
  const total = owasp.total || 0;

  if (total === 0) {
    noDataEl.style.display = 'block';
    return;
  }
  noDataEl.style.display = 'none';

  // Calculate totals from breakdown data for accuracy
  let totalReachable = 0;
  let totalUnreachable = 0;
  let totalUnknown = 0;
  for (const bd of Object.values(byCategoryBreakdown)) {
    totalReachable += bd.reachable || 0;
    totalUnreachable += bd.unreachable || 0;
    totalUnknown += bd.unknown || 0;
  }

  // Calculate breakdown per severity (using ratio)
  const reachableRatio = total > 0 ? totalReachable / total : 0;
  const unreachableRatio = total > 0 ? totalUnreachable / total : 0;
  const unknownRatio = total > 0 ? totalUnknown / total : 0;
  
  const critRaw = bySeverity.CRITICAL || 0;
  const critReach = Math.round(critRaw * reachableRatio);
  const critUnreach = Math.round(critRaw * unreachableRatio);
  const critUnknown = Math.round(critRaw * unknownRatio);
  
  const highRaw = bySeverity.HIGH || 0;
  const highReach = Math.round(highRaw * reachableRatio);
  const highUnreach = Math.round(highRaw * unreachableRatio);
  const highUnknown = Math.round(highRaw * unknownRatio);
  
  const medRaw = bySeverity.MEDIUM || 0;
  const medReach = Math.round(medRaw * reachableRatio);
  const medUnreach = Math.round(medRaw * unreachableRatio);
  const medUnknown = Math.round(medRaw * unknownRatio);

  statsEl.innerHTML = `
    <div style="background:#334155;border-radius:8px;padding:14px 18px;text-align:center;min-width:100px;border:1px solid #475569;">
      <div style="font-size:26px;font-weight:700;color:#f8fafc;">${total}</div>
      <div style="font-size:11px;color:#94a3b8;text-transform:uppercase;letter-spacing:0.5px;">Raw</div>
    </div>
    <div style="background:#334155;border-radius:8px;padding:14px 18px;text-align:center;min-width:100px;border:1px solid #3b82f6;">
      <div style="font-size:26px;font-weight:700;color:#93c5fd;">${totalUnreachable}</div>
      <div style="font-size:11px;color:#60a5fa;text-transform:uppercase;letter-spacing:0.5px;">Filtered</div>
    </div>
    <div style="background:#334155;border-radius:8px;padding:14px 18px;text-align:center;min-width:100px;border:2px solid #fb923c;box-shadow:0 0 12px rgba(251,146,60,0.3);">
      <div style="font-size:28px;font-weight:800;color:#fb923c;">${totalReachable}</div>
      <div style="font-size:11px;color:#fb923c;text-transform:uppercase;letter-spacing:0.5px;font-weight:600;">FIX NOW</div>
    </div>
    <div style="background:#334155;border-radius:8px;padding:14px 18px;text-align:center;min-width:100px;border:1px solid #64748b;">
      <div style="font-size:26px;font-weight:700;color:#cbd5e1;">${totalUnknown}</div>
      <div style="font-size:11px;color:#94a3b8;text-transform:uppercase;letter-spacing:0.5px;">Review</div>
    </div>
    <div style="background:#334155;border-radius:8px;padding:14px 18px;text-align:center;min-width:100px;border-left:3px solid #ef4444;">
      <div style="font-size:11px;color:#f87171;font-weight:600;margin-bottom:4px;">CRITICAL</div>
      <div style="display:flex;gap:6px;justify-content:center;align-items:center;font-size:11px;">
        <span style="color:#94a3b8;">Σ${critRaw}</span>
        <span style="color:#60a5fa;">✅${critUnreach}</span>
        <span style="color:#fca5a5;font-weight:700;font-size:13px;">🔥${critReach}</span>
      </div>
    </div>
    <div style="background:#334155;border-radius:8px;padding:14px 18px;text-align:center;min-width:100px;border-left:3px solid #f97316;">
      <div style="font-size:11px;color:#fb923c;font-weight:600;margin-bottom:4px;">HIGH</div>
      <div style="display:flex;gap:6px;justify-content:center;align-items:center;font-size:11px;">
        <span style="color:#94a3b8;">Σ${highRaw}</span>
        <span style="color:#60a5fa;">✅${highUnreach}</span>
        <span style="color:#fdba74;font-weight:700;font-size:13px;">🔥${highReach}</span>
      </div>
    </div>
    <div style="background:#334155;border-radius:8px;padding:14px 18px;text-align:center;min-width:100px;border-left:3px solid #eab308;">
      <div style="font-size:11px;color:#facc15;font-weight:600;margin-bottom:4px;">MEDIUM</div>
      <div style="display:flex;gap:6px;justify-content:center;align-items:center;font-size:11px;">
        <span style="color:#94a3b8;">Σ${medRaw}</span>
        <span style="color:#60a5fa;">✅${medUnreach}</span>
        <span style="color:#fde047;font-weight:700;font-size:13px;">🔥${medReach}</span>
      </div>
    </div>
  `;
  
  // Add small legend
  const parentEl = statsEl.parentElement;
  if (parentEl && parentEl.style.position !== 'relative') {
    parentEl.style.position = 'relative';
  }
  const existingLegend = document.getElementById('owaspLegend');
  if (existingLegend) existingLegend.remove();
  const legendEl = document.createElement('div');
  legendEl.id = 'owaspLegend';
  legendEl.innerHTML = `
    <span style="font-size:9px;color:#94a3b8;display:flex;align-items:center;gap:3px;"><span style="font-weight:700;">Σ</span> Raw</span>
    <span style="font-size:9px;color:#60a5fa;display:flex;align-items:center;gap:3px;"><span style="font-weight:700;">✅</span> Filtered</span>
    <span style="font-size:9px;color:#fb923c;display:flex;align-items:center;gap:3px;"><span style="font-weight:700;">🔥</span> Fix</span>
    <span style="font-size:9px;color:#cbd5e1;display:flex;align-items:center;gap:3px;"><span style="font-weight:700;">❓</span> Review</span>
  `;
  legendEl.style.cssText = 'position:absolute;top:12px;right:20px;display:flex;gap:12px;align-items:center;background:#1e293b;padding:6px 14px;border-radius:6px;border:1px solid #475569;z-index:10;';
  parentEl.insertBefore(legendEl, statsEl);

  // Category grid
  let gridHtml = '';
  for (const [cat, info] of Object.entries(OWASP_2021)) {
    const count = byCategory[cat] || 0;
    const breakdown = byCategoryBreakdown[cat] || {};
    const opacity = count > 0 ? '1' : '0.5';
    const r = breakdown.reachable || 0;
    const u = breakdown.unreachable || 0;
    const k = breakdown.unknown || 0;
    const badgeHtml = count > 0 
      ? `<div class="category-breakdown">
           <span class="bd-pill bd-raw">Σ${count}</span>
           <span class="bd-pill bd-unreach">✅${u}</span>
           <span class="bd-pill bd-reach">🔥${r}</span>
           <span class="bd-pill bd-unknown">❓${k}</span>
         </div>`
      : '';
    const clickable = count > 0 ? `onclick="filterByOwaspCategory('${cat}')" style="cursor:pointer;"` : '';
    gridHtml += `
      <div ${clickable} class="owasp-card" style="background:#334155;border-radius:8px;padding:16px;border-left:3px solid ${count>0?info.color:'#64748b'};opacity:${opacity};transition:all 0.2s ease;">
        <div style="display:flex;align-items:center;gap:10px;margin-bottom:8px;">
          <span style="font-size:20px;">${info.icon}</span>
          <span style="font-weight:600;color:#f8fafc;font-size:15px;">${cat}</span>
          ${badgeHtml}
        </div>
        <div style="font-size:13px;color:#e2e8f0;font-weight:500;">${info.name}</div>
        <div style="font-size:11px;color:#94a3b8;margin-top:6px;line-height:1.4;">${info.desc}</div>
      </div>
    `;
  }
  gridEl.innerHTML = gridHtml;
}

function renderLlmTop10(data) {
  const statsEl = document.getElementById('llmSummaryStats');
  const gridEl = document.getElementById('llmCategoryGrid');
  const asiGridEl = document.getElementById('asiCategoryGrid');
  const asiSection = document.getElementById('asiOnlySection');
  const noDataEl = document.getElementById('llmNoData');
  if (!statsEl || !gridEl) return;

  const ai = data.ai_security || {};
  const total = ai.total || 0;
  
  if (!ai || total === 0) {
    if (noDataEl) noDataEl.style.display = 'block';
    if (asiSection) asiSection.style.display = 'none';
    return;
  }
  if (noDataEl) noDataEl.style.display = 'none';
  if (asiSection) asiSection.style.display = 'block';

  const byLlm = ai.by_owasp || {};
  const byLlmBreakdown = ai.by_owasp_breakdown || {};
  const byAsi = ai.by_asi || {};  // NEW: ASI breakdown from scanner
  
  // Calculate totals from breakdown data
  let totalReachable = 0;
  let totalUnreachable = 0;
  let totalUnknown = 0;
  for (const bd of Object.values(byLlmBreakdown)) {
    totalReachable += bd.reachable || 0;
    totalUnreachable += bd.unreachable || 0;
    totalUnknown += bd.unknown || 0;
  }
  
  // Map severity
  const rawSev = ai.by_severity || {};
  const bySev = { 
    CRITICAL: rawSev.CRITICAL || 0, 
    HIGH: rawSev.HIGH || rawSev.ERROR || 0, 
    MEDIUM: rawSev.MEDIUM || rawSev.WARNING || 0, 
    LOW: rawSev.LOW || rawSev.INFO || 0 
  };

  // Calculate breakdown per severity
  const reachableRatio = total > 0 ? totalReachable / total : 0;
  const unreachableRatio = total > 0 ? totalUnreachable / total : 0;
  const unknownRatio = total > 0 ? totalUnknown / total : 0;
  
  const critRaw = bySev.CRITICAL;
  const critReach = Math.round(critRaw * reachableRatio);
  const critUnreach = Math.round(critRaw * unreachableRatio);
  
  const highRaw = bySev.HIGH;
  const highReach = Math.round(highRaw * reachableRatio);
  const highUnreach = Math.round(highRaw * unreachableRatio);
  
  const medRaw = bySev.MEDIUM;
  const medReach = Math.round(medRaw * reachableRatio);
  const medUnreach = Math.round(medRaw * unreachableRatio);

  // Summary stats
  statsEl.innerHTML = `
    <div style="background:#334155;border-radius:8px;padding:14px 18px;text-align:center;min-width:100px;border:1px solid #a855f7;">
      <div style="font-size:26px;font-weight:700;color:#e9d5ff;">${total}</div>
      <div style="font-size:11px;color:#c084fc;text-transform:uppercase;letter-spacing:0.5px;">Raw</div>
    </div>
    <div style="background:#334155;border-radius:8px;padding:14px 18px;text-align:center;min-width:100px;border:1px solid #3b82f6;">
      <div style="font-size:26px;font-weight:700;color:#93c5fd;">${totalUnreachable}</div>
      <div style="font-size:11px;color:#60a5fa;text-transform:uppercase;letter-spacing:0.5px;">Filtered</div>
    </div>
    <div style="background:#334155;border-radius:8px;padding:14px 18px;text-align:center;min-width:100px;border:2px solid #fb923c;box-shadow:0 0 12px rgba(251,146,60,0.3);">
      <div style="font-size:28px;font-weight:800;color:#fb923c;">${totalReachable}</div>
      <div style="font-size:11px;color:#fb923c;text-transform:uppercase;letter-spacing:0.5px;font-weight:600;">FIX NOW</div>
    </div>
    <div style="background:#334155;border-radius:8px;padding:14px 18px;text-align:center;min-width:100px;border:1px solid #64748b;">
      <div style="font-size:26px;font-weight:700;color:#cbd5e1;">${totalUnknown}</div>
      <div style="font-size:11px;color:#94a3b8;text-transform:uppercase;letter-spacing:0.5px;">Review</div>
    </div>
    <div style="background:#334155;border-radius:8px;padding:14px 18px;text-align:center;min-width:100px;border-left:3px solid #ef4444;">
      <div style="font-size:11px;color:#f87171;font-weight:600;margin-bottom:4px;">CRITICAL</div>
      <div style="display:flex;gap:6px;justify-content:center;align-items:center;font-size:11px;">
        <span style="color:#94a3b8;">Σ${critRaw}</span>
        <span style="color:#60a5fa;">✅${critUnreach}</span>
        <span style="color:#fca5a5;font-weight:700;font-size:13px;">🔥${critReach}</span>
      </div>
    </div>
    <div style="background:#334155;border-radius:8px;padding:14px 18px;text-align:center;min-width:100px;border-left:3px solid #f97316;">
      <div style="font-size:11px;color:#fb923c;font-weight:600;margin-bottom:4px;">HIGH</div>
      <div style="display:flex;gap:6px;justify-content:center;align-items:center;font-size:11px;">
        <span style="color:#94a3b8;">Σ${highRaw}</span>
        <span style="color:#60a5fa;">✅${highUnreach}</span>
        <span style="color:#fdba74;font-weight:700;font-size:13px;">🔥${highReach}</span>
      </div>
    </div>
    <div style="background:#334155;border-radius:8px;padding:14px 18px;text-align:center;min-width:100px;border-left:3px solid #eab308;">
      <div style="font-size:11px;color:#facc15;font-weight:600;margin-bottom:4px;">MEDIUM</div>
      <div style="display:flex;gap:6px;justify-content:center;align-items:center;font-size:11px;">
        <span style="color:#94a3b8;">Σ${medRaw}</span>
        <span style="color:#60a5fa;">✅${medUnreach}</span>
        <span style="color:#fde047;font-weight:700;font-size:13px;">🔥${medReach}</span>
      </div>
    </div>
  `;
  
  // Add legend
  const parentEl = statsEl.parentElement;
  if (parentEl && parentEl.style.position !== 'relative') {
    parentEl.style.position = 'relative';
  }
  const existingLegend = document.getElementById('llmLegend');
  if (existingLegend) existingLegend.remove();
  const legendEl = document.createElement('div');
  legendEl.id = 'llmLegend';
  legendEl.innerHTML = `
    <span style="font-size:9px;color:#94a3b8;display:flex;align-items:center;gap:3px;"><span style="font-weight:700;">Σ</span> Raw</span>
    <span style="font-size:9px;color:#60a5fa;display:flex;align-items:center;gap:3px;"><span style="font-weight:700;">✅</span> Filtered</span>
    <span style="font-size:9px;color:#fb923c;display:flex;align-items:center;gap:3px;"><span style="font-weight:700;">🔥</span> Fix</span>
    <span style="font-size:9px;color:#cbd5e1;display:flex;align-items:center;gap:3px;"><span style="font-weight:700;">❓</span> Review</span>
  `;
  legendEl.style.cssText = 'position:absolute;top:12px;right:20px;display:flex;gap:12px;align-items:center;background:#1e293b;padding:6px 14px;border-radius:6px;border:1px solid #475569;z-index:10;';
  parentEl.insertBefore(legendEl, statsEl);

  // ═══════════════════════════════════════════════════════════════════════
  // CONSOLIDATED CATEGORY GRID (LLM cards with ASI tags where they overlap)
  // ═══════════════════════════════════════════════════════════════════════
  let gridHtml = '';
  
  for (const [llmCat, llmInfo] of Object.entries(OWASP_LLM_2025)) {
    const count = byLlm[llmCat] || 0;
    const breakdown = byLlmBreakdown[llmCat] || {};
    const opacity = count > 0 ? '1' : '0.5';
    const r = breakdown.reachable || 0;
    const u = breakdown.unreachable || 0;
    const k = breakdown.unknown || 0;
    
    // Badge HTML
    const badgeHtml = count > 0 
      ? `<div class="category-breakdown">
           <span class="bd-pill bd-raw">Σ${count}</span>
           <span class="bd-pill bd-unreach">✅${u}</span>
           <span class="bd-pill bd-reach">🔥${r}</span>
           <span class="bd-pill bd-unknown">❓${k}</span>
         </div>`
      : '';
    
    // ASI mapping - show dual tags with HIGH CONTRAST SOLID BACKGROUNDS
    const asiMapping = LLM_ASI_MAPPING[llmCat];
    let tagsHtml = `<span style="display:inline-block;padding:4px 10px;background:#3730a3;color:#ffffff;border-radius:4px;font-size:11px;font-weight:700;">${llmCat}</span>`;
    
    if (asiMapping && asiMapping.asi.length > 0) {
      // Has ASI mappings - show dual tags with SOLID PURPLE BACKGROUND
      tagsHtml += asiMapping.asi.map(asi => 
        `<span style="display:inline-block;padding:4px 10px;background:#7c3aed;color:#ffffff;border-radius:4px;font-size:11px;font-weight:700;">${asi}</span>`
      ).join('');
    } else if (LLM_ONLY.includes(llmCat)) {
      // LLM-only tag
      tagsHtml += `<span style="display:inline-block;padding:3px 8px;background:#475569;color:#e2e8f0;border-radius:4px;font-size:10px;font-weight:600;">LLM-only</span>`;
    }
    
    // ASI relationship explanation (subtle)
    const asiExplainHtml = asiMapping 
      ? `<div style="margin-top:8px;font-size:10px;color:#8b5cf6;font-style:italic;">↳ ${asiMapping.desc}</div>`
      : '';
    
    const clickable = count > 0 ? `onclick="filterByOwaspCategory('${llmCat}', true)" style="cursor:pointer;"` : '';
    
    gridHtml += `
      <div ${clickable} class="owasp-card" style="background:linear-gradient(135deg, #334155 0%, #1e293b 100%);border-radius:10px;padding:18px;border-left:4px solid ${count>0?llmInfo.color:'#475569'};opacity:${opacity};transition:all 0.2s ease;">
        <div style="display:flex;align-items:center;gap:10px;margin-bottom:10px;flex-wrap:wrap;">
          <span style="font-size:22px;">${llmInfo.icon}</span>
          <span style="font-weight:700;color:#f8fafc;font-size:15px;">${llmInfo.name}</span>
          ${badgeHtml}
        </div>
        <div style="display:flex;gap:6px;flex-wrap:wrap;margin-bottom:8px;">
          ${tagsHtml}
        </div>
        <div style="font-size:12px;color:#94a3b8;line-height:1.5;">${llmInfo.desc}</div>
        ${asiExplainHtml}
      </div>
    `;
  }
  
  // Add "Other" card for uncategorized findings
  const noneCount = byLlm['NONE'] || 0;
  if (noneCount > 0) {
    const noneBreakdown = byLlmBreakdown['NONE'] || {};
    const nr = noneBreakdown.reachable || 0;
    const nu = noneBreakdown.unreachable || 0;
    const nk = noneBreakdown.unknown || 0;
    gridHtml += `
      <div class="owasp-card" style="background:linear-gradient(135deg, #334155 0%, #1e293b 100%);border-radius:10px;padding:18px;border-left:4px solid #6b7280;transition:all 0.2s ease;">
        <div style="display:flex;align-items:center;gap:10px;margin-bottom:10px;flex-wrap:wrap;">
          <span style="font-size:22px;">❓</span>
          <span style="font-weight:700;color:#f8fafc;font-size:15px;">Other AI Findings</span>
          <div class="category-breakdown">
            <span class="bd-pill bd-raw">Σ${noneCount}</span>
            <span class="bd-pill bd-unreach">✅${nu}</span>
            <span class="bd-pill bd-reach">🔥${nr}</span>
            <span class="bd-pill bd-unknown">❓${nk}</span>
          </div>
        </div>
        <div style="display:flex;gap:6px;flex-wrap:wrap;margin-bottom:8px;">
          <span style="display:inline-block;padding:4px 10px;background:#475569;color:#ffffff;border-radius:4px;font-size:11px;font-weight:700;">UNCATEGORIZED</span>
        </div>
        <div style="font-size:12px;color:#94a3b8;line-height:1.5;">AI security findings not mapped to OWASP LLM Top 10</div>
      </div>
    `;
  }
  
  gridEl.innerHTML = gridHtml;
  
  // ═══════════════════════════════════════════════════════════════════════
  // ASI-ONLY SECTION (new agentic risks with no LLM equivalent)
  // ═══════════════════════════════════════════════════════════════════════
  if (asiGridEl) {
    let asiGridHtml = '';
    
    for (const asiCat of ASI_ONLY) {
      const asiInfo = OWASP_ASI_2025[asiCat];
      if (!asiInfo) continue;
      
      // Check if we have ASI-specific findings (future: from scanner)
      const asiCount = byAsi[asiCat] || 0;
      const opacity = asiCount > 0 ? '1' : '0.6';
      
      const badgeHtml = asiCount > 0 
        ? `<div class="category-breakdown">
             <span class="bd-pill bd-raw">Σ${asiCount}</span>
           </div>`
        : '';
      
      asiGridHtml += `
        <div class="owasp-card" style="background:linear-gradient(135deg, #2e1065 0%, #1e1b4b 100%);border-radius:10px;padding:18px;border-left:4px solid ${asiInfo.color};opacity:${opacity};transition:all 0.2s ease;">
          <div style="display:flex;align-items:center;gap:10px;margin-bottom:10px;flex-wrap:wrap;">
            <span style="font-size:22px;">${asiInfo.icon}</span>
            <span style="font-weight:700;color:#e9d5ff;font-size:15px;">${asiInfo.name}</span>
            ${badgeHtml}
          </div>
          <div style="display:flex;gap:6px;flex-wrap:wrap;margin-bottom:8px;">
            <span style="display:inline-block;padding:4px 10px;background:#7c3aed;color:#ffffff;border-radius:4px;font-size:11px;font-weight:700;">${asiCat}</span>
            <span style="display:inline-block;padding:3px 8px;background:#581c87;color:#f3e8ff;border-radius:4px;font-size:10px;font-weight:600;">ASI-ONLY</span>
          </div>
          <div style="font-size:12px;color:#d4d4d8;line-height:1.5;">${asiInfo.desc}</div>
          <div style="margin-top:8px;font-size:10px;color:#a78bfa;font-style:italic;">⚠️ New agentic risk class (no LLM equivalent)</div>
        </div>
      `;
    }
    
    asiGridEl.innerHTML = asiGridHtml;
  }
}

// Hook into renderDashboard
const _origRenderDashboard = typeof renderDashboard === 'function' ? renderDashboard : null;
function renderDashboardWithOwasp() {
  if (_origRenderDashboard) _origRenderDashboard();
  if (dashboardData) {
    renderOwaspTop10(dashboardData);
    renderLlmTop10(dashboardData);
  }
}
if (_origRenderDashboard) renderDashboard = renderDashboardWithOwasp;
