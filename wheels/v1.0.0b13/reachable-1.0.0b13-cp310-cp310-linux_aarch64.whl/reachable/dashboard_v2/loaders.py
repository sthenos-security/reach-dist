#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.

"""
Data loaders for dashboard generation.
Handles loading from SQLite database and JSON files.
"""

import gzip
import json
import sqlite3
from pathlib import Path
from typing import Dict, Any, List, Optional

from .utils import get_version
from .metrics import calculate_metrics_from_summary, calculate_risk_level, format_summary


def load_from_database(db_path: Path) -> Dict[str, Any]:
    """Load dashboard data directly from SQLite database"""
    conn = sqlite3.connect(str(db_path))
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    
    try:
        # v4.5.37: Get the latest completed scan_id to filter all queries
        # This fixes the bug where metrics accumulated across all scans
        latest_scan_id = _get_latest_scan_id(cursor)
        
        # Get scan metadata
        metadata = _get_scan_metadata(cursor)
        
        # Get issues summary (was 'findings') - filtered by scan_id
        issues_summary = _get_issues_summary(cursor, latest_scan_id)
        
        # Get all security issues for table - filtered by scan_id
        issues = _get_all_issues(cursor, latest_scan_id)
        
        # v4.5.41: Apply IaC severity classification to CONFIG findings
        issues = _apply_iac_classification(issues)
        
        # v4.5.28: Build OWASP Top 10 web summary from CWE findings
        owasp_web = _build_owasp_web_from_issues(issues)
        
        # v4.5.28: Load AI security findings from ai_findings table
        # v4.5.37: Filter by latest_scan_id to prevent accumulation
        ai_security = load_ai_security_from_db(cursor, latest_scan_id)
        
        # v4.5.40: Load DLP/PII findings from dlp_findings table
        dlp_security = load_dlp_findings_from_db(cursor, latest_scan_id)
        
        # P2.21: Calculate metrics AFTER loading DLP to include DLP total AND reachable
        dlp_total = dlp_security.get('total', 0) if dlp_security else 0
        dlp_reachable = dlp_security.get('reachable', 0) if dlp_security else 0
        metrics = calculate_metrics_from_summary(issues_summary, dlp_total, dlp_reachable)
        
        # v4.5.10: Read risk_level from scans table (stored at scan time)
        risk_level = _get_stored_risk_level(cursor)
        if not risk_level:
            # Fallback: recalculate if not stored (legacy scans)
            risk_level = calculate_risk_level(issues_summary, metrics, issues)
        
        # v4.5.40: Export dlp_findings as array for template compatibility
        # P2.21: Limit to prevent browser crash with massive DLP datasets
        dlp_findings = dlp_security.get('findings', []) if dlp_security else []
        
        # P2.21: Show ALL DLP findings in dashboard
        
        # P2.21 FIX: Add simplified DLP findings to issues array for Action Required panel
        # Keep full dlp_findings for detailed DLP panel, but add to issues for breakdown
        dlp_issues = _convert_dlp_to_issues(dlp_findings)
        issues.extend(dlp_issues)
        
        # P2.50 FIX: Add AI findings to issues array (like DLP)
        # This ensures funnel and issues[] have matching counts
        ai_findings_list = ai_security.get('findings', []) if ai_security else []
        ai_issues = _convert_ai_to_issues(ai_findings_list)
        issues.extend(ai_issues)
        
        # P2.21 FIX: Load scan history for trends chart visualization
        # repo.db is at repo root: ~/.reachable/scans/<repo-hash>/repo.db
        # We need to pass repo root (db_path.parent), not scan_dir
        repo_root = Path(db_path).parent
        scan_history = get_scan_history(repo_root, days=30)
        
        # P2.50 CRITICAL FIX: Database is the SINGLE SOURCE OF TRUTH
        # All dashboard values must come from database - NO JS recalculation
        # Build funnel, trends, and other pre-computed sections here
        
        # P2.50: Build FUNNEL section from database counts
        # This is the source of truth for the Analysis Funnel panel
        funnel = _build_funnel_from_db(cursor, latest_scan_id, dlp_security, ai_security)
        
        # P2.50: Build TRENDS section from scan_history
        # Transform scan_history into the format dashboard expects
        trends = _build_trends_from_history(scan_history)
        
        # P2.50: Build repo_metadata for Scan Context panel
        repo_metadata = get_repo_metadata(Path(db_path).parent)
        
        return {
            'version': get_version(),
            'scan': metadata,
            'risk_level': risk_level,
            'metrics': metrics,
            'summary': format_summary(issues_summary, dlp_total),
            'issues': issues,
            # OWASP data - provide both key names for compatibility
            'owasp_web': owasp_web,
            'owasp_top10': owasp_web,  # P2.50: Alias for dashboard compatibility
            # AI Security
            'ai_security': ai_security,
            # DLP data - provide both key names for compatibility  
            'dlp_findings': dlp_findings,
            'dlp_summary': dlp_security,
            'dlp_security': dlp_security,  # P2.50: Alias for dashboard compatibility
            # P2.50 CRITICAL: Pre-computed sections (DB = truth, no JS recalc)
            'funnel': funnel,
            'trends': trends,
            'scan_history': scan_history,
            'repo_metadata': repo_metadata,
            'clone_metrics': None,  # Loaded separately via get_clone_metrics()
        }
        
    finally:
        conn.close()


def load_from_json(json_path: Path) -> Dict[str, Any]:
    """Load report from JSON file (gzipped or plain)"""
    if str(json_path).endswith('.gz'):
        with gzip.open(json_path, 'rt', encoding='utf-8') as f:
            return json.load(f)
    else:
        with open(json_path, 'r', encoding='utf-8') as f:
            return json.load(f)


def load_dlp_findings_from_db(cursor, scan_id: Optional[int] = None) -> Optional[Dict[str, Any]]:
    """
    Load DLP/PII findings from dlp_findings table in repo.db
    
    v4.5.40: Added for DLP dashboard panel support
    """
    try:
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='dlp_findings'")
        if not cursor.fetchone():
            return None
        
        # Filter by scan_id if provided
        if scan_id:
            cursor.execute("""
                SELECT 
                    rule_id, finding_type, pii_type, pii_sample, pii_count,
                    sink_type, sink_function, severity,
                    base_risk_score, adjusted_risk_score,
                    file_class, file_class_modifier,
                    is_reachable, reachability_confidence, call_path,
                    sanitizer_present, sanitizer_type, sanitizer_effectiveness,
                    regulations, file_path, line_start, line_end,
                    message, remediation, detection_source, confidence
                FROM dlp_findings
                WHERE scan_id = ?
                ORDER BY adjusted_risk_score DESC
            """, (scan_id,))
        else:
            cursor.execute("""
                SELECT 
                    rule_id, finding_type, pii_type, pii_sample, pii_count,
                    sink_type, sink_function, severity,
                    base_risk_score, adjusted_risk_score,
                    file_class, file_class_modifier,
                    is_reachable, reachability_confidence, call_path,
                    sanitizer_present, sanitizer_type, sanitizer_effectiveness,
                    regulations, file_path, line_start, line_end,
                    message, remediation, detection_source, confidence
                FROM dlp_findings
                ORDER BY adjusted_risk_score DESC
            """)
        
        findings = []
        by_pii_type = {}
        by_sink_type = {}
        by_severity = {'CRITICAL': 0, 'HIGH': 0, 'MEDIUM': 0, 'LOW': 0, 'WARNING': 0}
        reachable_count = 0
        sanitized_count = 0
        
        for row in cursor.fetchall():
            pii_type = row[2] or 'UNKNOWN'
            sink_type = row[5] or 'UNKNOWN'
            severity = (row[7] or 'MEDIUM').upper()
            is_reach = row[12]
            is_sanitized = row[15]
            
            # Aggregate stats
            by_pii_type[pii_type] = by_pii_type.get(pii_type, 0) + 1
            by_sink_type[sink_type] = by_sink_type.get(sink_type, 0) + 1
            if severity in by_severity:
                by_severity[severity] += 1
            if is_reach == 1:
                reachable_count += 1
            if is_sanitized == 1:
                sanitized_count += 1
            
            # Parse call_path and regulations from JSON
            call_path = None
            regulations = []
            try:
                if row[14]:
                    parsed_path = json.loads(row[14])
                    # Convert string array to object array
                    if parsed_path and isinstance(parsed_path, list) and parsed_path:
                        if isinstance(parsed_path[0], str):
                            call_path = []
                            for i, func_name in enumerate(parsed_path):
                                call_path.append({
                                    'function': func_name,
                                    'file': '',
                                    'line': None,
                                    'type': 'source' if i == 0 else ('sink' if i == len(parsed_path)-1 else 'flow')
                                })
                        else:
                            call_path = parsed_path
            except:
                pass
            try:
                if row[18]:
                    regulations = json.loads(row[18])
            except:
                pass
            
            # P2.20: Compute SLA and fix tag for DLP findings
            is_reach_bool = bool(row[12])  # is_reachable column
            
            sla_display, sla_class = _compute_sla_display(
                is_reachable=is_reach_bool,
                severity=severity,
                fix_status=None,  # DLP findings don't have fix_status
                finding_type='DLP'
            )
            
            fix_tag_display = _compute_fix_tag_display(
                finding_type='DLP',
                fix_status=None,
                fix_version=None
            )
            
            # P2.21: Add missing fields for security issues table compatibility
            file_path = row[19] or ''
            line_start = row[20] or 1
            message = row[22] or f"{pii_type} detected"
            
            # Build location string (file:line format)
            location = file_path
            if line_start:
                location = f"{file_path}:{line_start}"
            
            # Build reachability_state from is_reachable
            is_reach_bool = bool(row[12])
            reachability_state = 'reachable' if is_reach_bool else 'unknown'
            
            findings.append({
                # DLP-specific fields (original)
                'rule_id': row[0],
                'finding_type': row[1],
                'pii_type': pii_type,
                'pii_sample': row[3],
                'pii_count': row[4] or 1,
                'sink_type': sink_type,
                'sink_function': row[6],
                'severity': severity,
                'base_risk_score': row[8],
                'adjusted_risk_score': row[9],
                'file_class': row[10],
                'file_class_modifier': row[11],
                'is_reachable': is_reach_bool,
                'reachability_confidence': row[13],
                'call_path': call_path,
                'sanitizer_present': bool(row[15]),
                'sanitizer_type': row[16],
                'sanitizer_effectiveness': row[17],
                'regulations': regulations,
                'file_path': file_path,
                'line_start': line_start,
                'line_end': row[21],
                'message': message,
                'remediation': row[23],
                'detection_source': row[24],
                'confidence': row[25],
                # P2.20: Pre-computed display fields
                'sla_display': sla_display,
                'sla_class': sla_class,
                'fix_tag_display': fix_tag_display,
                # P2.21: Security issues table compatibility fields
                'id': row[0],  # Use rule_id as ID
                'type': 'DLP',
                'title': message,  # Use message as title
                'description': message,  # Full description
                'location': location,  # file:line format
                'line': line_start,  # Single line number for table
                'reachability_state': reachability_state,  # State string
                'compliance_mapping': {},  # Empty for DLP
                'cwe_id': '',  # Empty for DLP
                'package': '',  # Empty for DLP
                'fix_available': False,  # DLP doesn't have fixes
                'fix_status': None,  # DLP doesn't have fix status
                'fix_version': None,  # DLP doesn't have fix versions
            })
        
        if not findings:
            return None
        
        # P2.42: Separate discovery findings (PII exists) from data
        # loss (PII flows to sink)
        # Discovery = PII detected in source code, no external flow
        # Data Loss = PII flows to external sink (API, log, storage, etc.)
        discovery_findings = [
            f for f in findings
            if not f.get('sink_type') or f.get('sink_type') == 'UNKNOWN'
        ]
        data_loss_findings = [
            f for f in findings
            if f.get('sink_type') and f.get('sink_type') != 'UNKNOWN'
        ]
        
        return {
            'total': len(findings),
            'reachable': reachable_count,
            'sanitized': sanitized_count,
            'by_pii_type': by_pii_type,
            'by_sink_type': by_sink_type,
            'by_severity': by_severity,
            'findings': findings,
            # P2.42: Separate discovery from data loss
            'discovery_count': len(discovery_findings),
            'data_loss_count': len(data_loss_findings),
            'discovery_findings': discovery_findings,
            'data_loss_findings': data_loss_findings,
        }
        
    except Exception as e:
        return None


def _convert_dlp_to_issues(dlp_findings: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """
    Convert DLP findings to simplified issue format for Action Required panel.
    
    P2.21 FIX: DLP findings were in separate dlp_findings array and not counted
    in Action Required breakdown. This converts them to match the issues schema
    so they appear in severity breakdowns alongside CVE/SECRET/CONFIG/CWE.
    
    The full detailed dlp_findings array is kept separate for the DLP panel.
    """
    simplified_issues = []
    
    for dlp in dlp_findings:
        # Build location string
        file_path = dlp.get('file_path', '')
        line_start = dlp.get('line_start')
        location = f"{file_path}:{line_start}" if line_start else file_path
        
        # Determine reachability state
        is_reachable = dlp.get('is_reachable', False)
        if isinstance(is_reachable, (int, bool)):
            reachability_state = 'reachable' if is_reachable else 'unknown'
        else:
            reachability_state = 'unknown'
        
        # Create simplified issue matching the standard issue schema
        simplified_issues.append({
            'id': dlp.get('rule_id', ''),
            'type': 'DLP',
            'severity': dlp.get('severity', 'MEDIUM'),
            'raw_severity': dlp.get('severity', 'MEDIUM'),
            'is_reachable': bool(is_reachable),
            'reachability_state': reachability_state,
            'title': dlp.get('message', f"{dlp.get('pii_type', 'PII')} detected"),
            'description': dlp.get('message', ''),
            'file_path': file_path,
            'location': location,
            'line': line_start or 1,
            'package': '',  # DLP doesn't have packages
            'cwe_id': '',   # DLP doesn't map to CWE
            'fix_available': False,  # DLP has sanitization guidance, not fixes
            'fix_status': None,
            'compliance_mapping': {},
            # Keep minimal DLP-specific context
            'pii_type': dlp.get('pii_type', 'UNKNOWN'),
            'sink_type': dlp.get('sink_type', 'UNKNOWN'),
            'sanitizer_present': dlp.get('sanitizer_present', False),
        })
    
    return simplified_issues


def _convert_ai_to_issues(ai_findings: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """
    Convert AI findings to simplified issue format for issues array.
    
    P2.50 FIX: AI findings were in separate ai_security.findings array and not
    counted in issues[]. This converts them to match the issues schema so
    funnel and issues[] have matching counts.
    """
    simplified_issues = []
    
    for ai in ai_findings:
        # Determine reachability state
        is_reachable = ai.get('is_reachable', False)
        if is_reachable is True:
            reachability_state = 'reachable'
        elif is_reachable is False:
            reachability_state = 'not_reachable'
        else:
            reachability_state = 'unknown'
        
        # Build location string
        file_path = ai.get('file_path', '')
        line_start = ai.get('line_start')
        location = f"{file_path}:{line_start}" if line_start else file_path
        
        simplified_issues.append({
            'id': ai.get('rule_id', '') or ai.get('policy_id', ''),
            'type': 'AI',
            'severity': ai.get('severity', 'MEDIUM'),
            'is_reachable': bool(is_reachable),
            'reachability_state': reachability_state,
            'title': ai.get('owasp_name', '') or ai.get('message', 'AI Security Finding'),
            'description': ai.get('message', ''),
            'file_path': file_path,
            'location': location,
            'line': line_start or 1,
            'package': '',
            'cwe_id': '',
            'owasp_llm': ai.get('owasp_llm', ''),
            'call_path': ai.get('call_path'),
            'compliance_mapping': ai.get('compliance_mapping', {}),
            'fix_available': False,
            'fix_status': None,
            # Pre-computed display fields
            'sla_display': ai.get('sla_display', ''),
            'sla_class': ai.get('sla_class', ''),
            'fix_tag_display': ai.get('fix_tag_display', ''),
        })
    
    return simplified_issues


def load_ai_security_from_db(cursor, scan_id: Optional[int] = None) -> Optional[Dict[str, Any]]:
    """
    Load AI security findings from ai_findings table in repo.db
    
    v4.5.28: Added for OWASP LLM Top 10 dashboard support
    v4.5.37: Added scan_id filter to prevent accumulation across scans
    """
    try:
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='ai_findings'")
        if not cursor.fetchone():
            return None
        
        # v4.5.37: Filter by scan_id if provided
        # v4.5.38: Removed cwe_id from SELECT - AI findings don't have CWE mappings
        if scan_id:
            cursor.execute("""
                SELECT 
                    rule_id, policy_id, owasp_category, owasp_name, severity,
                    base_risk_score, adjusted_risk_score, is_reachable,
                    call_path, guards, guard_risk_reduction,
                    file_path, line_start, line_end, message,
                    framework, provider, detection_source
                FROM ai_findings
                WHERE scan_id = ?
                ORDER BY adjusted_risk_score DESC
            """, (scan_id,))
        else:
            cursor.execute("""
                SELECT 
                    rule_id, policy_id, owasp_category, owasp_name, severity,
                    base_risk_score, adjusted_risk_score, is_reachable,
                    call_path, guards, guard_risk_reduction,
                    file_path, line_start, line_end, message,
                    framework, provider, detection_source
                FROM ai_findings
                ORDER BY adjusted_risk_score DESC
            """)
        
        findings = []
        by_owasp = {}  # Total counts
        by_owasp_breakdown = {}  # {cat: {reachable:N, unreachable:N, unknown:N}}
        by_severity = {'CRITICAL': 0, 'HIGH': 0, 'MEDIUM': 0, 'LOW': 0}
        
        for row in cursor.fetchall():
            owasp_cat = row[2] or 'NONE'
            raw_severity = (row[4] or 'WARNING').upper()
            # P2.45 FIX: Normalize AI severity to standard levels BEFORE aggregation
            severity_map = {'CRITICAL':'CRITICAL','HIGH':'HIGH','ERROR':'HIGH','MEDIUM':'MEDIUM','WARNING':'MEDIUM','LOW':'LOW','INFO':'LOW'}
            severity = severity_map.get(raw_severity, 'MEDIUM')
            is_reach = row[7]
            
            by_owasp[owasp_cat] = by_owasp.get(owasp_cat, 0) + 1
            if owasp_cat not in by_owasp_breakdown:
                by_owasp_breakdown[owasp_cat] = {'reachable': 0, 'unreachable': 0, 'unknown': 0}
            # SQLite stores booleans as 0/1 integers, use == not is
            if is_reach == 1:
                by_owasp_breakdown[owasp_cat]['reachable'] += 1
            elif is_reach == 0:
                by_owasp_breakdown[owasp_cat]['unreachable'] += 1
            else:
                by_owasp_breakdown[owasp_cat]['unknown'] += 1
            if severity in by_severity:
                by_severity[severity] += 1
            
            # Parse call_path and guards from JSON
            call_path = None
            guards = []
            try:
                if row[8]:
                    parsed_path = json.loads(row[8])
                    # Convert string array to object array
                    if parsed_path and isinstance(parsed_path, list) and parsed_path:
                        if isinstance(parsed_path[0], str):
                            call_path = []
                            for i, func_name in enumerate(parsed_path):
                                call_path.append({
                                    'function': func_name,
                                    'file': '',
                                    'line': None,
                                    'type': 'entry' if i == 0 else ('vulnerable' if i == len(parsed_path)-1 else 'chain')
                                })
                        else:
                            call_path = parsed_path
            except:
                pass
            try:
                if row[9]:
                    guards = json.loads(row[9])
            except:
                pass
            
            # Build compliance mapping for AI findings
            # v4.5.38: AI findings use OWASP LLM Top 10, not CWE
            ai_compliance = {}
            if owasp_cat and owasp_cat != 'NONE':
                ai_compliance['OWASP_LLM'] = [owasp_cat]
                # Map OWASP LLM to compliance frameworks
                # LLM01 (Prompt Injection), LLM05 (Improper Output), LLM06 (Excessive Agency) are critical security issues
                if owasp_cat in ['LLM01', 'LLM05', 'LLM06']:
                    ai_compliance['NIST'] = ['AC-4', 'SC-7', 'SI-10']
                    ai_compliance['FedRAMP'] = ['AC-4', 'SC-7', 'SI-10']
                    ai_compliance['CMMC'] = ['AC.L2-3.1.3', 'SC.L2-3.13.1']
                # LLM02 (Sensitive Info Disclosure), LLM07 (System Prompt Leakage)
                elif owasp_cat in ['LLM02', 'LLM07']:
                    ai_compliance['NIST'] = ['AC-3', 'SC-8', 'SC-28']
                    ai_compliance['FedRAMP'] = ['AC-3', 'SC-8', 'SC-28']
                    ai_compliance['CMMC'] = ['AC.L2-3.1.1', 'SC.L2-3.13.8']
                # LLM03 (Supply Chain), LLM04 (Data Poisoning)
                elif owasp_cat in ['LLM03', 'LLM04']:
                    ai_compliance['NIST'] = ['SA-12', 'SR-3', 'SR-4']
                    ai_compliance['FedRAMP'] = ['SA-12', 'SR-3', 'SR-4']
                    ai_compliance['CMMC'] = ['SR.L2-3.17.1', 'SR.L2-3.17.2']
            
            # P2.20: Compute SLA and fix tag for AI findings
            is_reach_bool = bool(row[7])  # is_reachable column
            
            sla_display, sla_class = _compute_sla_display(
                is_reachable=is_reach_bool,
                severity=severity,
                fix_status=None,  # AI findings don't have fix_status
                finding_type='AI'
            )
            
            fix_tag_display = _compute_fix_tag_display(
                finding_type='AI',
                fix_status=None,
                fix_version=None
            )
            
            # v4.5.38: Removed row indices - cwe_id removed from SELECT
            # New indices: message=14, framework=15, provider=16, detection_source=17
            findings.append({
                'rule_id': row[0],
                'policy_id': row[1],
                'owasp_llm': owasp_cat,
                'llm_category': owasp_cat,
                'owasp_name': row[3],
                'severity': severity,
                'base_risk_score': row[5],
                'adjusted_risk_score': row[6],
                'is_reachable': bool(row[7]),
                'call_path': call_path,
                'guards': guards,
                'guard_risk_reduction': row[10],
                'file_path': row[11],
                'line_start': row[12],
                'line_end': row[13],
                'message': row[14],
                'framework': row[15],
                'provider': row[16],
                'detection_source': row[17],
                'compliance_mapping': ai_compliance,
                # P2.20: Pre-computed display fields
                'sla_display': sla_display,
                'sla_class': sla_class,
                'fix_tag_display': fix_tag_display,
            })
        
        if not findings:
            return None
        
        # v4.5.31: Compute reachable count for AI findings
        reachable_count = sum(1 for f in findings if f.get('is_reachable'))
        
        return {
            'total': len(findings),
            'reachable': reachable_count,
            'by_owasp': by_owasp,
            'by_owasp_breakdown': by_owasp_breakdown,
            'by_severity': by_severity,
            'findings': findings,
        }
        
    except Exception:
        return None


def get_repo_metadata(scan_dir: Path) -> Dict[str, Any]:
    """
    Get repo-level metadata from repo.db: scan count, first scan date, db size
    """
    try:
        repo_root = scan_dir.parent.parent
        repo_db = repo_root / 'repo.db'
        
        if not repo_db.exists():
            branch_dir = scan_dir.parent
            scan_dirs = sorted([
                d for d in branch_dir.iterdir() 
                if d.is_dir() and d.name[0].isdigit() and len(d.name) >= 15
            ])
            return {
                'scan_number': len(scan_dirs),
                'first_scan': scan_dirs[0].name[:8] if scan_dirs else '',
                'db_size_display': 'N/A',
            }
        
        conn = sqlite3.connect(str(repo_db))
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        
        cursor.execute("SELECT COUNT(*) as cnt FROM scans WHERE status = 'complete'")
        scan_count = cursor.fetchone()['cnt']
        
        cursor.execute("""
            SELECT MIN(timestamp) as first_scan 
            FROM scans WHERE status = 'complete'
        """)
        row = cursor.fetchone()
        first_scan = row['first_scan'] if row else None
        
        first_scan_display = ''
        if first_scan:
            try:
                from datetime import datetime
                dt = datetime.fromisoformat(first_scan.replace('Z', '+00:00'))
                first_scan_display = dt.strftime('%Y-%m-%d')
            except:
                first_scan_display = first_scan[:10] if len(first_scan) >= 10 else first_scan
        
        conn.close()
        
        db_size_bytes = repo_db.stat().st_size
        db_size_mb = round(db_size_bytes / (1024 * 1024), 2)
        
        return {
            'scan_number': scan_count,
            'first_scan': first_scan_display,
            'db_size_mb': db_size_mb,
            'db_size_display': f"{db_size_mb} MB" if db_size_mb >= 1 else f"{round(db_size_bytes / 1024, 1)} KB",
        }
        
    except Exception as e:
        return {'error': str(e)}


def get_scan_history(repo_root: Path, days: int = 30) -> List[Dict[str, Any]]:
    """Get scan history for trends visualization
    
    P2.50 FIX: Now takes repo_root directly (where repo.db lives)
    instead of scan_dir.
    """
    try:
        # P2.50: repo_root is now passed directly, repo.db is here
        repo_db = repo_root / 'repo.db'
        
        if not repo_db.exists():
            return []
        
        conn = sqlite3.connect(str(repo_db))
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        
        cursor.execute("PRAGMA table_info(scans)")
        columns = [col[1] for col in cursor.fetchall()]
        has_config = 'config_count' in columns
        has_unknown = 'unknown_count' in columns
        
        if has_config and has_unknown:
            cursor.execute("""
                SELECT 
                    id, timestamp, branch, total_findings, reachable_findings,
                    critical_count, high_count, medium_count, low_count,
                    risk_level, config_count, unknown_count
                FROM scans 
                WHERE status = 'complete'
                AND timestamp >= datetime('now', '-' || ? || ' days')
                ORDER BY timestamp ASC
            """, (days,))
        elif has_config:
            cursor.execute("""
                SELECT 
                    id, timestamp, branch, total_findings, reachable_findings,
                    critical_count, high_count, medium_count, low_count,
                    risk_level, config_count
                FROM scans 
                WHERE status = 'complete'
                AND timestamp >= datetime('now', '-' || ? || ' days')
                ORDER BY timestamp ASC
            """, (days,))
        else:
            cursor.execute("""
                SELECT 
                    id, timestamp, branch, total_findings, reachable_findings,
                    critical_count, high_count, medium_count, low_count,
                    risk_level
                FROM scans 
                WHERE status = 'complete'
                AND timestamp >= datetime('now', '-' || ? || ' days')
                ORDER BY timestamp ASC
            """, (days,))
        
        history = []
        for row in cursor.fetchall():
            try:
                config = row['config_count'] or 0
            except (IndexError, KeyError):
                config = 0
            try:
                unknown = row['unknown_count'] or 0
            except (IndexError, KeyError):
                unknown = 0
            history.append({
                'scan_id': row['id'],
                'timestamp': row['timestamp'],
                'branch': row['branch'],
                'total_issues': row['total_findings'] or 0,
                'reachable_issues': row['reachable_findings'] or 0,
                'critical': row['critical_count'] or 0,
                'high': row['high_count'] or 0,
                'medium': row['medium_count'] or 0,
                'low': row['low_count'] or 0,
                'risk_level': row['risk_level'] or 'UNKNOWN',
                'unknown_reachability': unknown,
                'config_count': config,
            })
        
        conn.close()
        return history
        
    except Exception:
        return []


# --- Private helpers for database loading ---

def _get_latest_scan_id(cursor) -> Optional[int]:
    """
    Get the latest completed scan_id from the database.
    
    v4.5.37: Added to fix accumulation bug - all queries should filter by this scan_id
    """
    try:
        cursor.execute("SELECT id FROM scans WHERE status = 'complete' ORDER BY id DESC LIMIT 1")
        row = cursor.fetchone()
        if row:
            return row['id'] if isinstance(row, dict) or hasattr(row, 'keys') else row[0]
    except:
        pass
    return None


def _get_stored_risk_level(cursor) -> Optional[str]:
    """Read risk_level from scans table"""
    try:
        cursor.execute("SELECT risk_level FROM scans ORDER BY id DESC LIMIT 1")
        row = cursor.fetchone()
        if row and row['risk_level']:
            return row['risk_level']
    except:
        pass
    return None


def _get_scan_metadata(cursor) -> Dict[str, Any]:
    """Extract scan metadata from database"""
    try:
        cursor.execute("SELECT * FROM scan_summary LIMIT 1")
        row = cursor.fetchone()
        if row:
            repo_path = row['repo_path'] if row['repo_path'] else ''
            if repo_path:
                return {
                    'repository': repo_path.split('/')[-1],
                    'branch': 'main',
                    'commit': '',
                    'display': repo_path.split('/')[-1],
                }
    except:
        pass
    
    try:
        cursor.execute("""
            SELECT repo_path, branch, commit_sha 
            FROM scans 
            ORDER BY id DESC LIMIT 1
        """)
        row = cursor.fetchone()
        if row:
            repo_path = row['repo_path'] if 'repo_path' in row.keys() else ''
            if repo_path:
                return {
                    'repository': repo_path.split('/')[-1],
                    'branch': row['branch'] if 'branch' in row.keys() else 'main',
                    'commit': (row['commit_sha'] or '')[:8] if 'commit_sha' in row.keys() else '',
                    'display': repo_path.split('/')[-1],
                }
    except:
        pass
    
    # v4.5.33: Fallback to scan-plan.json for repo name (fixed exception handling)
    scan_dir = None
    try:
        cursor.execute("SELECT scan_dir FROM scans ORDER BY id DESC LIMIT 1")
        scan_row = cursor.fetchone()
        if scan_row and 'scan_dir' in scan_row.keys():
            scan_dir = scan_row['scan_dir']
    except:
        pass
    
    if scan_dir:
        try:
            scan_plan_path = Path(scan_dir) / 'scan-plan.json'
            if scan_plan_path.exists():
                with open(scan_plan_path) as f:
                    plan = json.load(f)
                    repo_path = plan.get('repo_path', '') or plan.get('app_dir', '')
                    if repo_path:
                        return {
                            'repository': Path(repo_path).name,
                            'branch': plan.get('branch', 'main'),
                            'commit': '',
                            'display': Path(repo_path).name,
                        }
        except:
            pass
    
    # v4.5.34: Final fallback - extract repo name from scan_dir path structure
    # scan_dir format: ~/.reachable/scans/<repo-name-hash>/<branch>/<timestamp>/
    if scan_dir:
        try:
            path_parts = Path(scan_dir).parts
            # Find the 'scans' directory and get the next part (repo folder)
            for i, part in enumerate(path_parts):
                if part == 'scans' and i + 1 < len(path_parts):
                    repo_folder = path_parts[i + 1]
                    # repo_folder is like "my-repo-abc123" - strip hash suffix
                    # Hash is typically 8 hex chars at the end
                    if len(repo_folder) > 9 and repo_folder[-8:].replace('-', '').isalnum():
                        repo_name = repo_folder[:-9] if repo_folder[-9] == '-' else repo_folder
                    else:
                        repo_name = repo_folder
                    if repo_name:
                        return {
                            'repository': repo_name,
                            'branch': path_parts[i + 2] if i + 2 < len(path_parts) else 'main',
                            'commit': '',
                            'display': repo_name,
                        }
        except:
            pass
    
    return {
        'repository': 'unknown',
        'branch': 'main',
        'commit': '',
        'display': 'unknown',
    }


def _get_issues_summary(cursor, scan_id: Optional[int] = None) -> Dict[str, int]:
    """
    Get aggregated findings counts from database.
    
    v4.5.37: Added scan_id filter to prevent accumulation across scans
    """
    summary = {
        'cves_total': 0,
        'cves_reachable': 0,
        'cves_critical': 0,
        'cves_high': 0,
        'cves_medium': 0,
        'cves_low': 0,
        'secrets_total': 0,
        'secrets_reachable': 0,
        'secrets_unknown': 0,  # P2.21: Track unknown secrets separately
        'cwe_total': 0,
        'cwe_reachable': 0,
        'config_total': 0,
        'config_unknown': 0,
        'malware_total': 0,
    }
    
    try:
        # v4.5.37: Filter by scan_id to get only current scan findings
        if scan_id:
            cursor.execute("""
                SELECT 
                    finding_type,
                    severity,
                    app_reachability,
                    COUNT(*) as count
                FROM findings
                WHERE scan_id = ?
                GROUP BY finding_type, severity, app_reachability
            """, (scan_id,))
        else:
            cursor.execute("""
                SELECT 
                    finding_type,
                    severity,
                    app_reachability,
                    COUNT(*) as count
                FROM findings
                GROUP BY finding_type, severity, app_reachability
            """)
    except:
        return summary
    
    for row in cursor.fetchall():
        ftype = (row['finding_type'] or '').lower()
        sev = (row['severity'] or '').upper()
        reachability = (row['app_reachability'] or '').upper()
        count = row['count']
        
        # FIX: Proper reachability mapping
        # REACHABLE → reachable
        # NOT_REACHABLE → not reachable
        # UNKNOWN → depends on type (secrets=reachable, config=unknown)
        is_reachable = reachability == 'REACHABLE'
        is_unknown = reachability == 'UNKNOWN'
        
        if ftype == 'cve':
            summary['cves_total'] += count
            if is_reachable:
                summary['cves_reachable'] += count
            if sev == 'CRITICAL':
                summary['cves_critical'] += count
            elif sev == 'HIGH':
                summary['cves_high'] += count
            elif sev == 'MEDIUM':
                summary['cves_medium'] += count
            elif sev == 'LOW':
                summary['cves_low'] += count
        
        elif ftype == 'secret':
            summary['secrets_total'] += count
            # P2.21 FIX: Only REACHABLE secrets count as reachable, not UNKNOWN
            if is_reachable:
                summary['secrets_reachable'] += count
            # Add secrets_unknown metric
            if is_unknown:
                if 'secrets_unknown' not in summary:
                    summary['secrets_unknown'] = 0
                summary['secrets_unknown'] += count
        
        elif ftype == 'cwe':
            summary['cwe_total'] += count
            if is_reachable:
                summary['cwe_reachable'] += count
        
        elif ftype == 'config':
            summary['config_total'] += count
            summary['config_unknown'] += count  # All config is unknown reachability
        
        elif ftype == 'malware':
            summary['malware_total'] += count
    
    return summary


def _get_all_issues(cursor, scan_id: Optional[int] = None) -> List[Dict[str, Any]]:
    """
    Get all findings for the issues table.
    
    v4.5.37: Added scan_id filter to prevent accumulation across scans
    v4.5.41: Added fix_status, fix_version for CVE fix availability display
    """
    findings = []
    
    try:
        # v4.5.37: Filter by scan_id to get only current scan findings
        # v4.5.41: Added fix_status, fix_version columns
        # P2.21: Added display_id, ghsa_id, id_note for dual CVE/GHSA display
        if scan_id:
            cursor.execute("""
                SELECT 
                    id,
                    finding_type,
                    finding_id,
                    display_id,
                    ghsa_id,
                    id_note,
                    severity,
                    title,
                    description,
                    file_path,
                    line_number,
                    package_name,
                    package_version,
                    app_reachability,
                    app_reachability_confidence,
                    app_reachability_path,
                    cwe_id,
                    fix_status,
                    fix_version
                FROM findings
                WHERE scan_id = ?
                ORDER BY 
                    CASE severity 
                        WHEN 'CRITICAL' THEN 1 
                        WHEN 'HIGH' THEN 2 
                        WHEN 'MEDIUM' THEN 3 
                        WHEN 'LOW' THEN 4 
                        ELSE 5 
                    END,
                    CASE app_reachability
                        WHEN 'REACHABLE' THEN 1
                        WHEN 'UNKNOWN' THEN 2
                        ELSE 3
                    END
            """, (scan_id,))
        else:
            cursor.execute("""
                SELECT 
                    id,
                    finding_type,
                    finding_id,
                    display_id,
                    ghsa_id,
                    id_note,
                    severity,
                    title,
                    description,
                    file_path,
                    line_number,
                    package_name,
                    package_version,
                    app_reachability,
                    app_reachability_confidence,
                    app_reachability_path,
                    cwe_id,
                    fix_status,
                    fix_version
                FROM findings
                ORDER BY 
                    CASE severity 
                        WHEN 'CRITICAL' THEN 1 
                        WHEN 'HIGH' THEN 2 
                        WHEN 'MEDIUM' THEN 3 
                        WHEN 'LOW' THEN 4 
                        ELSE 5 
                    END,
                    CASE app_reachability
                        WHEN 'REACHABLE' THEN 1
                        WHEN 'UNKNOWN' THEN 2
                        ELSE 3
                    END
            """)
    except:
        return findings
    
    for row in cursor.fetchall():
        ftype = (row['finding_type'] or '').upper()
        reachability = (row['app_reachability'] or '').upper()
        
        # Proper is_reachable mapping based on type and reachability
        if reachability == 'REACHABLE':
            is_reachable = True
            reachability_state = 'reachable'
        elif reachability == 'NOT_REACHABLE':
            is_reachable = False
            reachability_state = 'not_reachable'
        elif reachability == 'UNKNOWN':
            if ftype == 'SECRET':
                is_reachable = False  # P2.21 FIX: Unknown secrets are not proven reachable
                reachability_state = 'unknown'
            elif ftype == 'CONFIG':
                is_reachable = None
                reachability_state = 'unknown'
            else:
                is_reachable = False
                reachability_state = 'unknown'
        else:
            is_reachable = False
            reachability_state = 'unknown'
        
        # Parse call_path from JSON string
        call_path = None
        if row['app_reachability_path']:
            try:
                parsed = json.loads(row['app_reachability_path'])
                # Convert string array to object array for dashboard
                if parsed and isinstance(parsed, list):
                    if isinstance(parsed[0], str):
                        # Format: ["main", "handler", "func"] -> [{function: "main", ...}, ...]
                        call_path = []
                        for i, func_name in enumerate(parsed):
                            call_path.append({
                                'function': func_name,
                                'name': func_name,
                                'file': '',
                                'line': None,
                                'type': 'entry' if i == 0 else ('vulnerable' if i == len(parsed)-1 else 'chain')
                            })
                    else:
                        # Already in object format
                        call_path = parsed
            except:
                call_path = None
        
        # v4.5.31: Normalize CWE ID (CWE-016 -> CWE-16)
        raw_cwe = row['cwe_id'] or ''
        cwe_id = _normalize_cwe_id(raw_cwe) if raw_cwe else ''
        
        # v4.5.32: Build compliance mapping for finding
        compliance_mapping = {}
        if cwe_id:
            compliance_mapping['CWE'] = [cwe_id]
            owasp_cat = _CWE_TO_OWASP.get(cwe_id)
            if owasp_cat:
                compliance_mapping['OWASP'] = [owasp_cat]
        if ftype == 'CVE':
            compliance_mapping['OWASP'] = ['A06']
        
        # v4.5.35: Fix duplicate CWE-CWE prefix
        raw_id = row['finding_id'] or f"{ftype}-{row['id']}"
        clean_id = raw_id.replace('CWE-CWE-', 'CWE-') if raw_id else raw_id
        
        # v4.5.41: Include fix_status and fix_version for CVE fix availability
        fix_status = row['fix_status'] or None
        fix_version = row['fix_version'] or None
        
        # P2.20: Compute display fields at load time (lightweight JS)
        sla_display, sla_class = _compute_sla_display(
            is_reachable=is_reachable,
            severity=row['severity'] or 'UNKNOWN',
            fix_status=fix_status,
            finding_type=ftype
        )
        
        fix_tag_display = _compute_fix_tag_display(
            finding_type=ftype,
            fix_status=fix_status,
            fix_version=fix_version
        )
        
        findings.append({
            'id': clean_id,
            'type': ftype,
            'severity': row['severity'] or 'UNKNOWN',
            'is_reachable': is_reachable,
            'reachability_state': reachability_state,
            'title': row['title'] or row['finding_id'] or '',
            'description': row['description'] or '',
            'package': f"{row['package_name'] or ''} {row['package_version'] or ''}".strip(),
            'file_path': row['file_path'] or '',
            # P2.20: Dashboard expects 'location' field - map from file_path or package_name
            'location': row['file_path'] or row['package_name'] or 'unknown',
            'line': row['line_number'],
            'cwe_id': cwe_id,
            'call_path': call_path,
            'compliance_mapping': compliance_mapping,
            # v4.5.41: Fix availability for CVEs
            'fix_status': fix_status,
            'fix_version': fix_version,
            'fix_available': fix_status == 'fix_available',
            'remediation': {'fixed_in': fix_version} if fix_version else None,
            # P2.20: Pre-computed display fields (source of truth)
            'sla_display': sla_display,
            'sla_class': sla_class,
            'fix_tag_display': fix_tag_display,
        })
    
    return findings


def _normalize_cwe_id(cwe_id: str) -> str:
    """
    Normalize CWE ID: CWE-016 -> CWE-16, 094 -> CWE-94
    
    v4.5.31: Added for consistent CWE ID handling
    """
    if not cwe_id:
        return ''
    cwe_id = cwe_id.upper().strip()
    if cwe_id.startswith('CWE-'):
        # Remove leading zeros: CWE-016 -> CWE-16
        num_part = cwe_id[4:].lstrip('0') or '0'
        return f'CWE-{num_part}'
    elif cwe_id.isdigit():
        # Just a number: 094 -> CWE-94
        return f'CWE-{cwe_id.lstrip("0") or "0"}'
    return cwe_id


def _apply_iac_classification(issues: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """
    Apply IaC severity classification to CONFIG findings.
    
    v4.5.41: Added for context-aware IaC severity adjustment.
    
    This:
    1. Parses IaC rule IDs (CWE-250-24 → CWE-250)
    2. Adjusts severity based on deployment context
    3. Replaces generic action messages with context-appropriate ones
    """
    try:
        from ..iac import classify_iac_severity, get_deployment_context
    except ImportError:
        # IaC module not available, return issues unchanged
        return issues
    
    adjusted = []
    
    for f in issues:
        # Only adjust CONFIG/IaC type findings
        ftype = (f.get('type') or '').upper()
        if ftype not in ('CONFIG', 'IAC'):
            adjusted.append(f)
            continue
        
        try:
            adj_sev, orig_sev, metadata = classify_iac_severity(f)
            
            # Create adjusted copy
            f_adj = dict(f)
            f_adj['severity'] = adj_sev
            f_adj['original_severity'] = orig_sev
            f_adj['iac_classification'] = metadata
            
            # Replace generic action message with context-appropriate one
            if metadata.get('action_message'):
                f_adj['action_message'] = metadata['action_message']
            
            # Add remediation if not present
            if metadata.get('remediation') and not f_adj.get('remediation'):
                f_adj['remediation'] = {'steps': [metadata['remediation']]}
            
            adjusted.append(f_adj)
        except Exception:
            # On error, keep original
            adjusted.append(f)
    
    return adjusted


# CWE to OWASP Top 10 2021 mapping
_CWE_TO_OWASP = {
    # A01: Broken Access Control
    'CWE-22': 'A01', 'CWE-23': 'A01', 'CWE-35': 'A01', 'CWE-59': 'A01',
    'CWE-200': 'A01', 'CWE-284': 'A01', 'CWE-285': 'A01', 'CWE-352': 'A01',
    'CWE-639': 'A01', 'CWE-862': 'A01', 'CWE-863': 'A01',
    # A02: Cryptographic Failures
    'CWE-259': 'A02', 'CWE-327': 'A02', 'CWE-328': 'A02', 'CWE-330': 'A02',
    'CWE-326': 'A02', 'CWE-319': 'A02', 'CWE-321': 'A02',
    # A03: Injection
    'CWE-20': 'A03', 'CWE-74': 'A03', 'CWE-77': 'A03', 'CWE-78': 'A03',
    'CWE-79': 'A03', 'CWE-89': 'A03', 'CWE-94': 'A03', 'CWE-917': 'A03',
    # A04: Insecure Design
    'CWE-209': 'A04', 'CWE-256': 'A04', 'CWE-501': 'A04', 'CWE-522': 'A04',
    # A05: Security Misconfiguration
    'CWE-16': 'A05', 'CWE-611': 'A05', 'CWE-614': 'A05',
    # A06: Vulnerable Components (CVEs)
    'CWE-937': 'A06', 'CWE-1035': 'A06', 'CWE-1104': 'A06',
    # A07: Auth Failures
    'CWE-287': 'A07', 'CWE-384': 'A07', 'CWE-613': 'A07', 'CWE-798': 'A07',
    # A08: Data Integrity Failures
    'CWE-345': 'A08', 'CWE-502': 'A08', 'CWE-829': 'A08',
    # A09: Logging Failures
    'CWE-117': 'A09', 'CWE-223': 'A09', 'CWE-532': 'A09', 'CWE-778': 'A09',
    # A10: SSRF
    'CWE-918': 'A10',
}


def _build_owasp_web_from_issues(issues: List[Dict[str, Any]]) -> Dict[str, Any]:
    """
    Build OWASP Top 10 (2021) Web summary from CWE findings.
    
    v4.5.28: Added for OWASP dashboard panel
    v4.5.29: Fixed CWE normalization (CWE-016 -> CWE-16)
    v4.5.32: Added by_category_breakdown for reachable/unreachable/unknown per category
    v4.5.36: Fixed severity mapping (ERROR→HIGH, WARNING→MEDIUM)
    """
    by_category = {f'A{i:02d}': 0 for i in range(1, 11)}
    by_category_breakdown = {f'A{i:02d}': {'reachable': 0, 'unreachable': 0, 'unknown': 0} for i in range(1, 11)}
    by_severity = {'CRITICAL': 0, 'HIGH': 0, 'MEDIUM': 0, 'LOW': 0}
    total = 0
    reachable = 0
    
    # v4.5.36: Map non-standard severity to standard levels
    severity_map = {
        'CRITICAL': 'CRITICAL',
        'HIGH': 'HIGH',
        'ERROR': 'HIGH',
        'MEDIUM': 'MEDIUM',
        'WARNING': 'MEDIUM',
        'LOW': 'LOW',
        'INFO': 'LOW',
    }
    
    for issue in issues:
        cwe_id = issue.get('cwe_id', '') or ''
        ftype = issue.get('type', '').upper()
        is_reach = issue.get('is_reachable')
        
        # Map CWE to OWASP category
        owasp_cat = None
        if cwe_id:
            # Normalize CWE ID: CWE-016 -> CWE-16, 094 -> CWE-94
            cwe_id = cwe_id.upper().strip()
            if cwe_id.startswith('CWE-'):
                # Remove leading zeros: CWE-016 -> CWE-16
                num_part = cwe_id[4:].lstrip('0') or '0'
                cwe_id = f'CWE-{num_part}'
            elif cwe_id.isdigit():
                # Just a number: 094 -> CWE-94
                cwe_id = f'CWE-{cwe_id.lstrip("0") or "0"}'
            owasp_cat = _CWE_TO_OWASP.get(cwe_id)
        
        # CVEs map to A06 (Vulnerable Components)
        if ftype == 'CVE':
            owasp_cat = 'A06'
        
        if owasp_cat:
            by_category[owasp_cat] += 1
            # Track breakdown
            if is_reach is True:
                by_category_breakdown[owasp_cat]['reachable'] += 1
            elif is_reach is False:
                by_category_breakdown[owasp_cat]['unreachable'] += 1
            else:
                by_category_breakdown[owasp_cat]['unknown'] += 1
            total += 1
            # v4.5.36: Map severity to standard levels
            raw_sev = (issue.get('severity') or 'MEDIUM').upper()
            sev = severity_map.get(raw_sev, 'MEDIUM')
            by_severity[sev] += 1
            if is_reach:
                reachable += 1
    
    return {
        'total': total,
        'reachable': reachable,
        'by_category': by_category,
        'by_category_breakdown': by_category_breakdown,
        'by_severity': by_severity,
    }


def get_clone_metrics(scan_dir: Path) -> Optional[Dict[str, Any]]:
    """
    Load library clone metrics from scan directory.
    
    Returns dict with clone success/failure statistics or None if not found.
    """
    # Try to find lib-cloning-metrics.json in scan directory or raw/ subdirectory
    candidates = [
        scan_dir / 'lib-cloning-metrics.json',
        scan_dir / 'raw' / 'lib-cloning-metrics.json',
    ]
    
    for metrics_file in candidates:
        if metrics_file.exists():
            try:
                with open(metrics_file) as f:
                    return json.load(f)
            except Exception:
                pass
    
    return None


def _compute_sla_display(
    is_reachable: Optional[bool],
    severity: str,
    fix_status: Optional[str],
    finding_type: str
) -> tuple[str, str]:
    """
    Compute SLA display and CSS class for a finding.
    
    P2.20: Business logic for SLA moved to Python (database population)
    JavaScript just displays what's here (lightweight).
    
    Returns:
        (display_text, css_class)
    """
    # P2.21: Fix tri-state reachability - None (UNKNOWN) must show ASSESS
    # Not reachable (False) → no SLA
    if is_reachable is False:
        return '-', ''
    # Unknown reachability (None) → show ASSESS
    if is_reachable is None:
        return 'ASSESS', 'sla-unknown'
    
    # Normalize severity
    sev = (severity or 'UNKNOWN').upper()
    
    # CVEs: check fix status
    if finding_type == 'CVE':
        if fix_status == 'fix_available':
            # Fixable CVE → show timeline based on severity
            if sev == 'CRITICAL':
                return '24 hours', 'sla-critical'
            elif sev == 'HIGH':
                return '7 days', 'sla-high'
            elif sev == 'MEDIUM':
                return '30 days', 'sla-medium'
            elif sev == 'LOW':
                return '90 days', 'sla-low'
            elif sev == 'UNKNOWN':
                return 'ASSESS', 'sla-unknown'
            else:
                return 'ASSESS', 'sla-unknown'
        else:
            # Unfixable CVE (not-fixed, wont_fix, unknown, NULL)
            return 'NO FIX', 'sla-none'
    
    # All other types (SECRET, CWE, MALWARE, CONFIG, etc) → always show SLA when reachable
    else:
        if sev == 'CRITICAL':
            return '24 hours', 'sla-critical'
        elif sev == 'HIGH':
            return '7 days', 'sla-high'
        elif sev == 'MEDIUM':
            return '30 days', 'sla-medium'
        elif sev == 'LOW':
            return '90 days', 'sla-low'
        elif sev == 'UNKNOWN':
            return 'ASSESS', 'sla-unknown'
        else:
            return 'ASSESS', 'sla-unknown'


def _compute_fix_tag_display(
    finding_type: str,
    fix_status: Optional[str],
    fix_version: Optional[str]
) -> str:
    """
    Compute fix tag HTML for a finding.
    
    P2.20: Business logic for fix tags moved to Python (database population)
    JavaScript just displays what's here (lightweight).
    
    Returns:
        HTML string for fix tag
    """
    ftype = finding_type.upper()
    
    if ftype == 'CVE':
        if fix_status == 'fix_available':
            if fix_version:
                return f'<span class="fix-tag fix-available">✅ {fix_version}</span>'
            else:
                return '<span class="fix-tag fix-available">✅ FIX</span>'
        elif fix_status == 'wont_fix':
            return '<span class="fix-tag fix-wontfix">🚫 WONT FIX</span>'
        elif fix_status == 'not-fixed':
            return '<span class="fix-tag fix-none">⚠️ NO FIX</span>'
        else:
            # unknown or NULL
            return '<span class="fix-tag fix-unknown">❓ UNKNOWN</span>'
    
    elif ftype == 'SECRET':
        return '<span class="fix-tag" style="background:#fef3c7;color:#92400e;">🔑 ROTATE</span>'
    
    elif ftype in ('MALWARE', 'SUSPICIOUS'):
        return '<span class="fix-tag" style="background:#fee2e2;color:#991b1b;">🗑️ REMOVE</span>'
    
    elif ftype == 'AI':
        return '<span class="fix-tag" style="background:#ede9fe;color:#5b21b6;">🛡️ MITIGATE</span>'
    
    elif ftype == 'DLP':
        return '<span class="fix-tag" style="background:#fce7f3;color:#9d174d;">🔒 SANITIZE</span>'
    
    elif ftype == 'CWE':
        return '<span class="fix-tag" style="background:#dbeafe;color:#1e40af;">🔧 CODE FIX</span>'
    
    elif ftype in ('CONFIG', 'IAC'):
        return '<span class="fix-tag" style="background:#e0e7ff;color:#3730a3;">⚙️ CONFIG</span>'
    
    else:
        return '-'


def _build_funnel_from_db(
    cursor,
    scan_id: Optional[int],
    dlp_security: Optional[Dict[str, Any]],
    ai_security: Optional[Dict[str, Any]]
) -> Dict[str, Any]:
    """
    Build the Analysis Funnel data directly from database.
    
    P2.50 CRITICAL: This is the SINGLE SOURCE OF TRUTH for funnel metrics.
    Dashboard JS must NOT recalculate these values.
    
    Returns:
        {
            'raw_total': int,
            'reachable_total': int,
            'noise_reduction_pct': float,
            'raw_signals': {'CVE': N, 'SECRET': N, 'CWE': N, 'CONFIG': N, 'AI': N, 'DLP': N},
            'reachable_signals': {'CVE': N, 'SECRET': N, 'CWE': N, 'CONFIG': N, 'AI': N, 'DLP': N},
            'unknown_signals': {'CVE': N, 'SECRET': N, 'CWE': N, 'CONFIG': N, 'AI': N, 'DLP': N},
            'unreachable_signals': {'CVE': N, 'SECRET': N, 'CWE': N, 'CONFIG': N, 'AI': N, 'DLP': N},
        }
    """
    # Initialize signal counts
    raw_signals = {'CVE': 0, 'SECRET': 0, 'CWE': 0, 'CONFIG': 0, 'AI': 0, 'DLP': 0}
    reachable_signals = {'CVE': 0, 'SECRET': 0, 'CWE': 0, 'CONFIG': 0, 'AI': 0, 'DLP': 0}
    unknown_signals = {'CVE': 0, 'SECRET': 0, 'CWE': 0, 'CONFIG': 0, 'AI': 0, 'DLP': 0}
    unreachable_signals = {'CVE': 0, 'SECRET': 0, 'CWE': 0, 'CONFIG': 0, 'AI': 0, 'DLP': 0}
    
    try:
        # Query findings table for CVE, SECRET, CWE, CONFIG counts
        if scan_id:
            cursor.execute("""
                SELECT 
                    finding_type,
                    app_reachability,
                    COUNT(*) as count
                FROM findings
                WHERE scan_id = ?
                GROUP BY finding_type, app_reachability
            """, (scan_id,))
        else:
            cursor.execute("""
                SELECT 
                    finding_type,
                    app_reachability,
                    COUNT(*) as count
                FROM findings
                GROUP BY finding_type, app_reachability
            """)
        
        for row in cursor.fetchall():
            ftype = (row['finding_type'] or '').upper()
            reachability = (row['app_reachability'] or '').upper()
            count = row['count'] or 0
            
            if ftype not in raw_signals:
                continue
            
            raw_signals[ftype] += count
            
            if reachability == 'REACHABLE':
                reachable_signals[ftype] += count
            elif reachability == 'NOT_REACHABLE':
                unreachable_signals[ftype] += count
            elif reachability == 'UNKNOWN':
                unknown_signals[ftype] += count
    except Exception:
        pass
    
    # Add AI findings from ai_security dict
    if ai_security:
        ai_total = ai_security.get('total', 0) or 0
        ai_reachable = ai_security.get('reachable', 0) or 0
        raw_signals['AI'] = ai_total
        reachable_signals['AI'] = ai_reachable
        unreachable_signals['AI'] = ai_total - ai_reachable
    
    # Add DLP findings from dlp_security dict
    if dlp_security:
        dlp_total = dlp_security.get('total', 0) or 0
        dlp_reachable = dlp_security.get('reachable', 0) or 0
        raw_signals['DLP'] = dlp_total
        reachable_signals['DLP'] = dlp_reachable
        unreachable_signals['DLP'] = dlp_total - dlp_reachable
    
    # Calculate totals (exclude CONFIG - not part of risk calculation, matches Signal Quality table)
    raw_total = sum(v for k, v in raw_signals.items() if k.upper() != 'CONFIG')
    reachable_total = sum(v for k, v in reachable_signals.items() if k.upper() != 'CONFIG')
    unknown_total = sum(v for k, v in unknown_signals.items() if k.upper() != 'CONFIG')
    unreachable_total = sum(v for k, v in unreachable_signals.items() if k.upper() != 'CONFIG')
    
    # Calculate noise reduction percentage (unreachable / total)
    if raw_total > 0:
        noise_reduction_pct = round((unreachable_total / raw_total) * 100, 1)
    else:
        noise_reduction_pct = 0.0
    
    return {
        'raw_total': raw_total,
        'reachable_total': reachable_total,
        'unknown_total': unknown_total,  # P2.50: Add for consistency
        'unreachable_total': unreachable_total,  # P2.50: Add for consistency
        'noise_reduction_pct': noise_reduction_pct,
        'raw_signals': raw_signals,
        'reachable_signals': reachable_signals,
        'unknown_signals': unknown_signals,
        'unreachable_signals': unreachable_signals,
        'config_excluded': True,  # P2.50: Flag that CONFIG is excluded from totals
    }


def _build_trends_from_history(scan_history: List[Dict[str, Any]]) -> Dict[str, Any]:
    """
    Transform scan_history into the trends format expected by dashboard.
    
    P2.50 CRITICAL: This is the SINGLE SOURCE OF TRUTH for trends data.
    Dashboard JS must NOT recalculate these values.
    
    Returns:
        {
            'data_points': [
                {
                    'timestamp': str,
                    'raw': int,
                    'reachable': int,
                    'critical': int,
                    'high': int,
                    'medium': int,
                    'low': int
                },
                ...
            ],
            'latest': {...}  # Most recent data point
        }
    """
    data_points = []
    
    for entry in scan_history:
        data_points.append({
            'timestamp': entry.get('timestamp', ''),
            'scan_id': entry.get('scan_id'),
            'branch': entry.get('branch', 'main'),
            'raw': entry.get('total_issues', 0) - entry.get('config_count', 0),  # P2.53: Exclude CONFIG to match funnel
            'reachable': entry.get('reachable_issues', 0),
            'critical': entry.get('critical', 0),
            'high': entry.get('high', 0),
            'medium': entry.get('medium', 0),
            'low': entry.get('low', 0),
            'risk_level': entry.get('risk_level', 'UNKNOWN'),
        })
    
    # Get latest data point
    latest = data_points[-1] if data_points else {
        'timestamp': '',
        'raw': 0,
        'reachable': 0,
        'critical': 0,
        'high': 0,
        'medium': 0,
        'low': 0,
    }
    
    return {
        'data_points': data_points,
        'latest': latest,
        'count': len(data_points),
    }
