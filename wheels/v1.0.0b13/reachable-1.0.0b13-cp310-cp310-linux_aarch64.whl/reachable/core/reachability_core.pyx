# cython: language_level=3
# cython: boundscheck=False
# cython: wraparound=False
# cython: cdivision=True

"""
REACHABLE Core - Cython Implementation
High-performance reachability analysis algorithms.

This module is compiled with Cython for 10-50x speedup on:
- Call graph traversal (BFS/DFS)
- Reachability matrix computation
- Risk score calculations
- Pattern matching
"""

from libc.stdlib cimport malloc, free
from cpython.dict cimport PyDict_GetItem, PyDict_SetItem
from cpython.set cimport PySet_Add, PySet_Contains

import re
from typing import Dict, Set, List, Tuple, Optional

# Secret detection patterns compiled once
cdef list SECRET_PATTERNS = [
    'hardcoded', 'secret', 'password', 'api-key', 'api_key', 'apikey',
    'token', 'credential', 'private-key', 'private_key', 'aws-', 'gcp-',
    'azure-', 'slack-', 'github-token', 'jwt', 'bearer', 'generic-',
    'detected-', 'exposed-'
]


cpdef dict compute_reachability_fast(dict call_graph, set entry_points):
    """
    Compute reachable functions from entry points using optimized BFS.
    
    Args:
        call_graph: Dict mapping function -> set of called functions
        entry_points: Set of entry point function names
        
    Returns:
        Dict with 'reachable' set and 'unreachable' set
    """
    cdef set reachable = set()
    cdef set visited = set()
    cdef list queue = list(entry_points)
    cdef str current
    cdef set callees
    cdef str callee
    
    while queue:
        current = queue.pop(0)
        if current in visited:
            continue
        visited.add(current)
        reachable.add(current)
        
        # Get callees for this function
        callees = call_graph.get(current, set())
        for callee in callees:
            if callee not in visited:
                queue.append(callee)
    
    # Compute unreachable as all functions minus reachable
    cdef set all_functions = set(call_graph.keys())
    for callees in call_graph.values():
        all_functions.update(callees)
    
    cdef set unreachable = all_functions - reachable
    
    return {
        'reachable': reachable,
        'unreachable': unreachable,
        'total': len(all_functions),
        'reachable_count': len(reachable),
        'unreachable_count': len(unreachable)
    }


cpdef list traverse_call_graph(dict call_graph, str start_func, int max_depth=10):
    """
    Traverse call graph from a starting function and return call paths.
    
    Args:
        call_graph: Dict mapping function -> set of called functions
        start_func: Starting function name
        max_depth: Maximum traversal depth
        
    Returns:
        List of call paths (each path is a list of function names)
    """
    cdef list paths = []
    cdef list stack = [([start_func], 0)]  # (path, depth)
    cdef list current_path
    cdef int depth
    cdef str last_func
    cdef set callees
    cdef str callee
    
    while stack:
        current_path, depth = stack.pop()
        
        if depth >= max_depth:
            paths.append(current_path)
            continue
            
        last_func = current_path[-1]
        callees = call_graph.get(last_func, set())
        
        if not callees:
            paths.append(current_path)
            continue
            
        for callee in callees:
            if callee not in current_path:  # Avoid cycles
                new_path = current_path + [callee]
                stack.append((new_path, depth + 1))
    
    return paths


cpdef dict calculate_risk_score(dict severity_breakdown, int kev_count=0, 
                                int malware_count=0, int phantom_deps=0,
                                int no_fix_count=0):
    """
    Calculate risk score using weighted formula.
    
    Risk Score Formula:
    - Critical Reachable: 250 points each
    - Critical Unreachable: 25 points each (10% weight)
    - High Reachable: 100 points each
    - High Unreachable: 10 points each
    - Medium Reachable: 40 points each
    - Medium Unreachable: 4 points each
    - Low Reachable: 10 points each
    - KEV Amplifier: +100 per KEV CVE
    - Malware: +500 per malicious package
    - Phantom Deps: +50 each
    - No Fix Available: +30 each
    
    Args:
        severity_breakdown: Dict with critical/high/medium/low -> {live, dead}
        kev_count: Number of CISA KEV CVEs
        malware_count: Number of malicious packages
        phantom_deps: Number of phantom dependencies
        no_fix_count: Number of CVEs with no fix
        
    Returns:
        Dict with score, level, components breakdown
    """
    cdef int score = 0
    cdef dict components = {}
    
    # Critical
    cdef int crit_live = severity_breakdown.get('critical', {}).get('live', 0)
    cdef int crit_dead = severity_breakdown.get('critical', {}).get('dead', 0)
    cdef int crit_score = crit_live * 250 + crit_dead * 25
    score += crit_score
    components['critical'] = {'live': crit_live, 'dead': crit_dead, 'score': crit_score}
    
    # High
    cdef int high_live = severity_breakdown.get('high', {}).get('live', 0)
    cdef int high_dead = severity_breakdown.get('high', {}).get('dead', 0)
    cdef int high_score = high_live * 100 + high_dead * 10
    score += high_score
    components['high'] = {'live': high_live, 'dead': high_dead, 'score': high_score}
    
    # Medium
    cdef int med_live = severity_breakdown.get('medium', {}).get('live', 0)
    cdef int med_dead = severity_breakdown.get('medium', {}).get('dead', 0)
    cdef int med_score = med_live * 40 + med_dead * 4
    score += med_score
    components['medium'] = {'live': med_live, 'dead': med_dead, 'score': med_score}
    
    # Low
    cdef int low_live = severity_breakdown.get('low', {}).get('live', 0)
    cdef int low_dead = severity_breakdown.get('low', {}).get('dead', 0)
    cdef int low_score = low_live * 10
    score += low_score
    components['low'] = {'live': low_live, 'dead': low_dead, 'score': low_score}
    
    # Amplifiers
    cdef int kev_score = kev_count * 100
    cdef int malware_score = malware_count * 500
    cdef int phantom_score = phantom_deps * 50
    cdef int nofix_score = no_fix_count * 30
    
    score += kev_score + malware_score + phantom_score + nofix_score
    
    components['kev'] = {'count': kev_count, 'score': kev_score}
    components['malware'] = {'count': malware_count, 'score': malware_score}
    components['phantom'] = {'count': phantom_deps, 'score': phantom_score}
    components['no_fix'] = {'count': no_fix_count, 'score': nofix_score}
    
    # Determine risk level
    cdef str level
    if score >= 800 or crit_live > 0 or malware_count > 0:
        level = "CRITICAL"
    elif score >= 400 or high_live > 2:
        level = "HIGH"
    elif score >= 150 or high_live > 0:
        level = "MEDIUM"
    else:
        level = "LOW"
    
    return {
        'score': score,
        'max_score': 1000,
        'normalized': min(10.0, score / 100.0),
        'level': level,
        'components': components
    }


cpdef bint match_secret_patterns(str rule_id):
    """
    Check if a rule ID matches secret detection patterns.
    
    Args:
        rule_id: The rule ID to check
        
    Returns:
        True if matches secret pattern, False for SAST finding
    """
    cdef str rule_lower = rule_id.lower()
    cdef str pattern
    
    for pattern in SECRET_PATTERNS:
        if pattern in rule_lower:
            return True
    return False


cpdef dict classify_findings(list findings):
    """
    Classify security findings into secrets vs SAST.
    
    Args:
        findings: List of finding dicts with rule_id, message, etc.
        
    Returns:
        Dict with 'secrets' and 'sast' lists
    """
    cdef list secrets = []
    cdef list sast = []
    cdef dict finding
    cdef str rule_id
    cdef str msg_lower
    
    for finding in findings:
        rule_id = finding.get('rule_id', '') or ''
        
        if match_secret_patterns(rule_id):
            finding['is_actual_secret'] = True
            finding['finding_type'] = 'SECRET'
            secrets.append(finding)
        else:
            # Check message for secret indicators
            msg_lower = (finding.get('message', '') or '').lower()
            if any(kw in msg_lower for kw in ['hardcoded password', 'api key', 'credential', 'private key']):
                finding['is_actual_secret'] = True
                finding['finding_type'] = 'SECRET'
                secrets.append(finding)
            else:
                finding['is_actual_secret'] = False
                finding['finding_type'] = 'SAST'
                sast.append(finding)
    
    return {
        'secrets': secrets,
        'sast': sast,
        'secrets_count': len(secrets),
        'sast_count': len(sast)
    }


cpdef dict compute_workload_reduction(int total_cves, int unreachable_cves):
    """
    Compute workload reduction metrics.
    
    Args:
        total_cves: Total number of CVEs found
        unreachable_cves: Number of unreachable CVEs
        
    Returns:
        Dict with reduction metrics
    """
    cdef float reduction_pct = 0.0
    cdef float hours_per_cve = 10.5  # Industry benchmark
    cdef float hourly_rate = 100.0
    
    if total_cves > 0:
        reduction_pct = (unreachable_cves / <float>total_cves) * 100.0
    
    cdef float hours_saved = unreachable_cves * hours_per_cve
    cdef float cost_savings = hours_saved * hourly_rate
    
    return {
        'reduction_percentage': round(reduction_pct, 1),
        'issues_eliminated': unreachable_cves,
        'hours_saved': round(hours_saved, 1),
        'cost_savings': round(cost_savings, 2),
        'benchmark_source': 'Ponemon Institute'
    }


# =============================================================================
# CISA/NIST SECRET SEVERITY MATRIX (v2.9.37)
# Based on CISA SSVC and NIST SP 800-204D
# =============================================================================

# Scenario constants (must match pure Python version)
SCENARIO_TOXIC_COMBINATION = 'TOXIC_COMBINATION'  # Active + Reachable = CRITICAL
SCENARIO_EXPOSED_ASSET = 'EXPOSED_ASSET'          # Active + Unreachable = HIGH
SCENARIO_DEAD_LINK = 'DEAD_LINK'                  # Inactive + Reachable = MEDIUM
SCENARIO_SECURITY_DEBT = 'SECURITY_DEBT'          # Inactive + Unreachable = LOW

# Action categories
ACTION_ACT = 'ACT'           # Immediate action - active breach
ACTION_ATTEND = 'ATTEND'     # Attack chain risk - rotate priority
ACTION_TRACK = 'TRACK'       # Compliance fix only


cpdef dict classify_secret_severity(bint is_active, bint is_reachable):
    """
    Classify secret severity using CISA/NIST two-dimensional model.
    
    Scenarios:
    - TOXIC_COMBINATION: Active + Reachable = CRITICAL (ACT)
    - EXPOSED_ASSET: Active + Unreachable = HIGH (ATTEND)
    - DEAD_LINK: Inactive + Reachable = MEDIUM (TRACK)
    - SECURITY_DEBT: Inactive + Unreachable = LOW (TRACK)
    
    Args:
        is_active: Whether the secret is valid/active at provider
        is_reachable: Whether secret is in code path (main/prod)
        
    Returns:
        Dict with scenario, severity, action, timeline
    """
    cdef str scenario
    cdef str severity
    cdef str action
    cdef str timeline
    cdef int risk_weight
    
    if is_active and is_reachable:
        scenario = 'TOXIC_COMBINATION'
        severity = 'CRITICAL'
        action = 'ACT'
        timeline = '24-48 hours'
        risk_weight = 100
    elif is_active and not is_reachable:
        scenario = 'EXPOSED_ASSET'
        severity = 'HIGH'
        action = 'ATTEND'
        timeline = '7 days'
        risk_weight = 75
    elif not is_active and is_reachable:
        scenario = 'DEAD_LINK'
        severity = 'MEDIUM'
        action = 'TRACK'
        timeline = '30 days'
        risk_weight = 25
    else:
        scenario = 'SECURITY_DEBT'
        severity = 'LOW'
        action = 'TRACK'
        timeline = '90 days'
        risk_weight = 10
    
    return {
        'scenario': scenario,
        'severity': severity,
        'action': action,
        'timeline': timeline,
        'risk_weight': risk_weight,
    }


cpdef dict calculate_sandbox_risk(dict sandbox_results):
    """
    Calculate risk from malware sandbox (MALWARE-003).
    
    Args:
        sandbox_results: Dict with summary containing malicious/suspicious counts
        
    Returns:
        Dict with score, verdict, and risk factors
    """
    cdef int score = 0
    cdef list risk_factors = []
    cdef str verdict = 'SKIPPED'
    
    if not sandbox_results:
        return {'score': 0, 'verdict': 'SKIPPED', 'policy_id': 'MALWARE-003', 'risk_factors': []}
    
    cdef dict summary = sandbox_results.get('summary', {})
    cdef int malicious = summary.get('malicious', 0)
    cdef int suspicious = summary.get('suspicious', 0)
    
    if malicious > 0:
        score += malicious * 500
        risk_factors.append(f"{malicious} malicious packages [MALWARE-003]")
        verdict = 'MALICIOUS'
    
    if suspicious > 0:
        score += suspicious * 100
        risk_factors.append(f"{suspicious} suspicious packages [MALWARE-003]")
        if verdict != 'MALICIOUS':
            verdict = 'SUSPICIOUS'
    
    if verdict == 'SKIPPED' and malicious == 0 and suspicious == 0:
        verdict = 'CLEAN'
    
    return {
        'score': score,
        'verdict': verdict,
        'policy_id': 'MALWARE-003',
        'risk_factors': risk_factors,
    }


# Module version
__version__ = '2.9.38'
