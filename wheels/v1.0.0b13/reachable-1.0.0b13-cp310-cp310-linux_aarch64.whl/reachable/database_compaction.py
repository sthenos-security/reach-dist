#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.

"""
REACHABLE Database Compaction Module

Safe SQLite database compaction and maintenance using VACUUM INTO strategy.

Features:
- WAL checkpointing (prevents unbounded WAL growth)
- Safe compaction via VACUUM INTO (original DB intact until verified)
- Integrity checking
- Repair capability for corrupted databases
- Batch operations across all repo.db files

Usage:
    # CLI
    reachctl db --status          # Show WAL size, bloat ratio
    reachctl db --compact         # Checkpoint + VACUUM INTO if needed
    reachctl db --compact --force # Force vacuum even if low bloat
    reachctl db --checkpoint      # Just checkpoint WAL (fast)
    reachctl db --check           # Integrity check
    reachctl db --repair          # Attempt repair

    # Python
    from reachable.database_compaction import DatabaseCompactor
    
    compactor = DatabaseCompactor(Path('repo.db'))
    result = compactor.compact()
"""

import sqlite3
import shutil
import logging
from pathlib import Path
from typing import Dict, Tuple, Optional, List
from datetime import datetime

logger = logging.getLogger(__name__)

# Thresholds
DEFAULT_WAL_THRESHOLD_MB = 50      # Checkpoint if WAL > 50MB
DEFAULT_BLOAT_THRESHOLD = 0.20    # VACUUM if freelist > 20%


def format_size(size_bytes: int) -> str:
    """Format bytes as human-readable string."""
    for unit in ['B', 'KB', 'MB', 'GB']:
        if size_bytes < 1024:
            return f"{size_bytes:.1f} {unit}"
        size_bytes /= 1024
    return f"{size_bytes:.1f} TB"


class DatabaseCompactor:
    """
    Safe database compaction using VACUUM INTO.
    
    VACUUM INTO advantages:
    - Original DB stays intact until verified
    - Easy rollback if something fails
    - No temp space needed inside original file
    - Available in SQLite 3.27+ (2019)
    
    What VACUUM does NOT do (we handle separately):
    - Checkpoint WAL → We do PRAGMA wal_checkpoint(TRUNCATE) first
    - Fix corruption → Need dump/reload or .recover
    - Update statistics → We run ANALYZE after
    """
    
    def __init__(self, db_path: Path):
        self.db_path = Path(db_path)
        self.wal_path = Path(str(self.db_path) + '-wal')
        self.shm_path = Path(str(self.db_path) + '-shm')
    
    def get_stats(self) -> Dict:
        """Get database size and health statistics."""
        stats = {
            'db_path': str(self.db_path),
            'exists': self.db_path.exists(),
            'db_size': 0,
            'db_size_human': '0 B',
            'wal_size': 0,
            'wal_size_human': '0 B',
            'shm_size': 0,
            'total_size': 0,
            'total_size_human': '0 B',
            'page_size': 0,
            'page_count': 0,
            'freelist_count': 0,
            'bloat_ratio': 0.0,
            'bloat_percent': '0%',
            'needs_checkpoint': False,
            'needs_vacuum': False,
            'sqlite_version': '',
            'journal_mode': '',
        }
        
        if not self.db_path.exists():
            return stats
        
        # File sizes
        stats['db_size'] = self.db_path.stat().st_size
        stats['db_size_human'] = format_size(stats['db_size'])
        
        if self.wal_path.exists():
            stats['wal_size'] = self.wal_path.stat().st_size
            stats['wal_size_human'] = format_size(stats['wal_size'])
        
        if self.shm_path.exists():
            stats['shm_size'] = self.shm_path.stat().st_size
        
        stats['total_size'] = stats['db_size'] + stats['wal_size'] + stats['shm_size']
        stats['total_size_human'] = format_size(stats['total_size'])
        
        # Internal stats from SQLite
        try:
            conn = sqlite3.connect(str(self.db_path), timeout=30)
            cursor = conn.cursor()
            
            cursor.execute('SELECT sqlite_version()')
            stats['sqlite_version'] = cursor.fetchone()[0]
            
            cursor.execute('PRAGMA journal_mode')
            stats['journal_mode'] = cursor.fetchone()[0]
            
            cursor.execute('PRAGMA page_size')
            stats['page_size'] = cursor.fetchone()[0]
            
            cursor.execute('PRAGMA page_count')
            stats['page_count'] = cursor.fetchone()[0]
            
            cursor.execute('PRAGMA freelist_count')
            stats['freelist_count'] = cursor.fetchone()[0]
            
            conn.close()
            
            # Calculate bloat ratio
            if stats['page_count'] > 0:
                stats['bloat_ratio'] = stats['freelist_count'] / stats['page_count']
                stats['bloat_percent'] = f"{stats['bloat_ratio'] * 100:.1f}%"
            
        except Exception as e:
            logger.warning(f"Could not get DB stats for {self.db_path}: {e}")
            stats['error'] = str(e)
        
        # Determine if maintenance needed
        stats['needs_checkpoint'] = stats['wal_size'] > DEFAULT_WAL_THRESHOLD_MB * 1024 * 1024
        stats['needs_vacuum'] = stats['bloat_ratio'] > DEFAULT_BLOAT_THRESHOLD
        
        return stats
    
    def checkpoint(self, mode: str = 'TRUNCATE') -> Tuple[int, int, bool]:
        """
        Checkpoint WAL file to main database.
        
        IMPORTANT: VACUUM does NOT checkpoint WAL. Do this first!
        
        Modes:
          - PASSIVE: Don't block, checkpoint what's possible
          - FULL: Block until complete
          - RESTART: Like FULL, then restart WAL
          - TRUNCATE: Like RESTART, then truncate WAL to zero (recommended)
        
        Returns: (pages_written, pages_remaining, was_blocked)
        """
        if not self.db_path.exists():
            return (0, 0, False)
        
        try:
            conn = sqlite3.connect(str(self.db_path), timeout=30)
            cursor = conn.cursor()
            
            cursor.execute(f'PRAGMA wal_checkpoint({mode})')
            result = cursor.fetchone()
            
            conn.close()
            
            # Result: (blocked, log_pages, checkpointed_pages)
            # blocked: 0 = success, 1 = blocked by other connection
            if result and len(result) >= 3:
                blocked = result[0] == 1
                log_pages = result[1]
                checkpointed = result[2]
                return (checkpointed, log_pages - checkpointed, blocked)
            
            return (0, 0, False)
            
        except Exception as e:
            logger.error(f"Checkpoint failed for {self.db_path}: {e}")
            raise
    
    def integrity_check(self) -> Tuple[bool, str]:
        """
        Check database integrity.
        
        Returns: (is_ok, message)
        """
        if not self.db_path.exists():
            return (False, "Database does not exist")
        
        try:
            conn = sqlite3.connect(str(self.db_path), timeout=30)
            cursor = conn.cursor()
            cursor.execute('PRAGMA integrity_check')
            result = cursor.fetchone()[0]
            conn.close()
            
            is_ok = result == 'ok'
            return (is_ok, result)
            
        except Exception as e:
            return (False, str(e))
    
    def _vacuum_into_safe(self) -> Tuple[bool, int]:
        """
        Safe VACUUM using VACUUM INTO + atomic swap.
        
        Strategy:
        1. VACUUM INTO new file (original stays intact)
        2. Verify new file integrity
        3. Atomic swap: original -> backup, new -> original
        4. Delete backup
        5. Clean orphaned WAL/SHM
        
        Returns: (success, bytes_freed)
        """
        new_path = self.db_path.with_suffix('.db.new')
        backup_path = self.db_path.with_suffix('.db.bak')
        
        size_before = self.db_path.stat().st_size
        
        try:
            # Step 1: Create compacted copy
            conn = sqlite3.connect(str(self.db_path), timeout=60)
            conn.execute(f"VACUUM INTO '{new_path}'")
            conn.close()
            
            # Step 2: Verify integrity of new file
            new_conn = sqlite3.connect(str(new_path), timeout=30)
            check = new_conn.execute("PRAGMA integrity_check").fetchone()[0]
            new_conn.close()
            
            if check != 'ok':
                raise Exception(f"Integrity check failed on new DB: {check}")
            
            # Step 3: Atomic swap
            self.db_path.rename(backup_path)
            new_path.rename(self.db_path)
            
            # Step 4: Delete backup (success confirmed)
            backup_path.unlink()
            
            # Step 5: Clean orphaned WAL/SHM from old DB
            for orphan_path in [self.wal_path, self.shm_path]:
                if orphan_path.exists():
                    orphan_path.unlink()
            
            size_after = self.db_path.stat().st_size
            bytes_freed = size_before - size_after
            
            return (True, max(0, bytes_freed))
            
        except Exception as e:
            # Rollback: clean up partial state
            if new_path.exists():
                new_path.unlink()
            if backup_path.exists() and not self.db_path.exists():
                backup_path.rename(self.db_path)
            raise
    
    def compact(self, force: bool = False) -> Dict:
        """
        Full compaction: checkpoint WAL + VACUUM INTO if needed.
        
        Args:
            force: If True, vacuum even if bloat is low
        
        Returns:
            Dict with results:
            - checkpointed: bool
            - vacuumed: bool
            - bytes_freed: int
            - method: str
            - error: Optional[str]
        """
        result = {
            'db_path': str(self.db_path),
            'checkpointed': False,
            'vacuumed': False,
            'pages_checkpointed': 0,
            'bytes_freed': 0,
            'method': None,
            'error': None,
            'stats_before': None,
            'stats_after': None,
        }
        
        if not self.db_path.exists():
            result['error'] = "Database does not exist"
            return result
        
        # Get stats before
        result['stats_before'] = self.get_stats()
        
        # Step 1: Always checkpoint WAL first (VACUUM doesn't do this!)
        try:
            pages, remaining, blocked = self.checkpoint('TRUNCATE')
            result['checkpointed'] = True
            result['pages_checkpointed'] = pages
            if blocked:
                logger.warning(f"Checkpoint was blocked for {self.db_path}")
        except Exception as e:
            result['error'] = f"Checkpoint failed: {e}"
            return result
        
        # Step 2: Check if vacuum needed
        stats = self.get_stats()  # Refresh after checkpoint
        
        if not force and stats['bloat_ratio'] < DEFAULT_BLOAT_THRESHOLD:
            result['method'] = f"skipped (bloat {stats['bloat_percent']} < {DEFAULT_BLOAT_THRESHOLD*100:.0f}%)"
            result['stats_after'] = stats
            return result
        
        # Step 3: VACUUM INTO (safe method)
        try:
            success, bytes_freed = self._vacuum_into_safe()
            if success:
                result['vacuumed'] = True
                result['method'] = 'VACUUM INTO'
                result['bytes_freed'] = bytes_freed
                
                # Run ANALYZE to update statistics
                try:
                    conn = sqlite3.connect(str(self.db_path), timeout=30)
                    conn.execute('ANALYZE')
                    conn.close()
                except:
                    pass  # Non-critical
                
        except Exception as e:
            result['error'] = f"Vacuum failed: {e}"
            logger.error(f"Vacuum failed for {self.db_path}: {e}")
        
        # Get stats after
        result['stats_after'] = self.get_stats()
        
        return result
    
    def repair(self) -> Tuple[bool, str]:
        """
        Attempt to repair a corrupted database.
        
        Strategy:
        1. Try .recover command (SQLite 3.29+)
        2. Fallback: dump readable data and rebuild
        
        Returns: (success, message)
        """
        if not self.db_path.exists():
            return (False, "Database does not exist")
        
        backup_path = self.db_path.with_suffix('.db.corrupt')
        new_path = self.db_path.with_suffix('.db.recovered')
        
        try:
            # Backup the corrupt file first
            shutil.copy2(self.db_path, backup_path)
            
            conn = sqlite3.connect(str(self.db_path), timeout=60)
            
            # Try to get schema
            cursor = conn.cursor()
            try:
                cursor.execute("SELECT sql FROM sqlite_master WHERE sql IS NOT NULL")
                schema = [row[0] for row in cursor.fetchall() if row[0]]
            except:
                schema = []
            
            # Create new database
            new_conn = sqlite3.connect(str(new_path))
            
            # Recreate schema
            for sql in schema:
                try:
                    new_conn.execute(sql)
                except Exception as e:
                    logger.warning(f"Could not create schema element: {e}")
            
            # Get table names
            try:
                cursor.execute("SELECT name FROM sqlite_master WHERE type='table'")
                tables = [row[0] for row in cursor.fetchall()]
            except:
                tables = []
            
            # Copy data table by table
            rows_recovered = 0
            for table in tables:
                if table.startswith('sqlite_'):
                    continue
                try:
                    cursor.execute(f"SELECT * FROM {table}")
                    rows = cursor.fetchall()
                    if rows:
                        cursor.execute(f"PRAGMA table_info({table})")
                        cols = len(cursor.fetchall())
                        placeholders = ','.join(['?' for _ in range(cols)])
                        new_conn.executemany(
                            f"INSERT INTO {table} VALUES ({placeholders})",
                            rows
                        )
                        rows_recovered += len(rows)
                except Exception as e:
                    logger.warning(f"Could not recover table {table}: {e}")
            
            new_conn.commit()
            conn.close()
            new_conn.close()
            
            # Verify recovered DB
            check_conn = sqlite3.connect(str(new_path))
            check = check_conn.execute("PRAGMA integrity_check").fetchone()[0]
            check_conn.close()
            
            if check != 'ok':
                new_path.unlink()
                return (False, f"Recovered DB failed integrity check: {check}")
            
            # Replace original with recovered
            self.db_path.unlink()
            new_path.rename(self.db_path)
            
            # Clean up WAL/SHM
            for orphan in [self.wal_path, self.shm_path]:
                if orphan.exists():
                    orphan.unlink()
            
            return (True, f"Recovered {rows_recovered} rows. Corrupt backup at {backup_path}")
            
        except Exception as e:
            # Clean up
            if new_path.exists():
                new_path.unlink()
            return (False, f"Repair failed: {e}")


def compact_all_databases(
    reachable_home: Path = None,
    force: bool = False,
    verbose: bool = True,
    dry_run: bool = False
) -> Dict:
    """
    Compact all repo.db databases in .reachable directory.
    
    Args:
        reachable_home: REACHABLE home directory (default: ~/.reachable)
        force: Force vacuum even if low bloat
        verbose: Print progress
        dry_run: Just report, don't actually compact
    
    Returns:
        Summary statistics
    """
    home = reachable_home or Path.home() / '.reachable'
    scans_dir = home / 'scans'
    
    summary = {
        'databases_found': 0,
        'databases_compacted': 0,
        'databases_skipped': 0,
        'total_bytes_freed': 0,
        'total_wal_checkpointed': 0,
        'errors': [],
        'details': [],
    }
    
    if not scans_dir.exists():
        if verbose:
            logger.info(f"No scans directory found at {scans_dir}")
        return summary
    
    # Find all repo.db files
    repo_dbs = list(scans_dir.glob('*/repo.db'))
    summary['databases_found'] = len(repo_dbs)
    
    if verbose:
        logger.info(f"\n{'[DRY RUN] ' if dry_run else ''}Database Compaction")
        print("=" * 60)
        logger.info(f"Found {len(repo_dbs)} databases")
        print()
    
    for repo_db in sorted(repo_dbs):
        repo_name = repo_db.parent.name
        compactor = DatabaseCompactor(repo_db)
        stats = compactor.get_stats()
        
        detail = {
            'repo': repo_name,
            'db_size': stats['db_size_human'],
            'wal_size': stats['wal_size_human'],
            'bloat': stats['bloat_percent'],
            'action': None,
            'bytes_freed': 0,
        }
        
        if verbose:
            logger.info(f"  {repo_name}:")
            logger.info(f"    DB: {stats['db_size_human']}, WAL: {stats['wal_size_human']}, Bloat: {stats['bloat_percent']}")
        
        needs_work = stats['needs_checkpoint'] or stats['needs_vacuum'] or force
        
        if not needs_work:
            detail['action'] = 'skipped (healthy)'
            summary['databases_skipped'] += 1
            if verbose:
                logger.info(f"    → Skipped (healthy)")
        elif dry_run:
            detail['action'] = 'would compact'
            if verbose:
                logger.info(f"    → Would compact")
        else:
            result = compactor.compact(force=force)
            
            if result['error']:
                detail['action'] = f"error: {result['error']}"
                summary['errors'].append(f"{repo_name}: {result['error']}")
                if verbose:
                    logger.info(f"    → Error: {result['error']}")
            else:
                actions = []
                if result['checkpointed']:
                    actions.append('checkpointed')
                    summary['total_wal_checkpointed'] += 1
                if result['vacuumed']:
                    actions.append(f"vacuumed ({format_size(result['bytes_freed'])} freed)")
                    summary['databases_compacted'] += 1
                    summary['total_bytes_freed'] += result['bytes_freed']
                    detail['bytes_freed'] = result['bytes_freed']
                elif result['method'] and 'skipped' in result['method']:
                    actions.append(result['method'])
                    summary['databases_skipped'] += 1
                
                detail['action'] = ', '.join(actions) or 'no action needed'
                
                if verbose:
                    logger.info(f"    → {detail['action']}")
        
        summary['details'].append(detail)
    
    # Summary
    if verbose:
        print()
        print("=" * 60)
        logger.info(f"{'Would free' if dry_run else 'Freed'}: {format_size(summary['total_bytes_freed'])}")
        logger.info(f"Compacted: {summary['databases_compacted']}")
        logger.info(f"Skipped: {summary['databases_skipped']}")
        if summary['errors']:
            logger.info(f"Errors: {len(summary['errors'])}")
        print("=" * 60)
    
    return summary


def check_all_databases(
    reachable_home: Path = None,
    verbose: bool = True
) -> Dict:
    """
    Check integrity of all databases.
    
    Returns:
        Dict with results for each database
    """
    home = reachable_home or Path.home() / '.reachable'
    scans_dir = home / 'scans'
    
    results = {
        'total': 0,
        'healthy': 0,
        'corrupt': 0,
        'details': [],
    }
    
    if not scans_dir.exists():
        return results
    
    repo_dbs = list(scans_dir.glob('*/repo.db'))
    results['total'] = len(repo_dbs)
    
    if verbose:
        logger.info(f"\nDatabase Integrity Check")
        print("=" * 60)
    
    for repo_db in sorted(repo_dbs):
        repo_name = repo_db.parent.name
        compactor = DatabaseCompactor(repo_db)
        is_ok, message = compactor.integrity_check()
        
        detail = {
            'repo': repo_name,
            'path': str(repo_db),
            'ok': is_ok,
            'message': message,
        }
        results['details'].append(detail)
        
        if is_ok:
            results['healthy'] += 1
            if verbose:
                logger.info(f"  ✅ {repo_name}: OK")
        else:
            results['corrupt'] += 1
            if verbose:
                logger.info(f"  ❌ {repo_name}: {message}")
    
    if verbose:
        print()
        logger.info(f"Healthy: {results['healthy']}/{results['total']}")
        if results['corrupt'] > 0:
            logger.info(f"⚠️  Corrupt: {results['corrupt']} (run 'reachctl db --repair' to attempt recovery)")
    
    return results


def get_all_database_stats(reachable_home: Path = None) -> Dict:
    """
    Get statistics for all databases.
    
    Returns:
        Dict with aggregate and per-database stats
    """
    home = reachable_home or Path.home() / '.reachable'
    scans_dir = home / 'scans'
    
    result = {
        'total_db_size': 0,
        'total_wal_size': 0,
        'total_size': 0,
        'databases': [],
    }
    
    if not scans_dir.exists():
        return result
    
    for repo_db in sorted(scans_dir.glob('*/repo.db')):
        compactor = DatabaseCompactor(repo_db)
        stats = compactor.get_stats()
        
        result['databases'].append({
            'repo': repo_db.parent.name,
            **stats
        })
        
        result['total_db_size'] += stats['db_size']
        result['total_wal_size'] += stats['wal_size']
        result['total_size'] += stats['total_size']
    
    result['total_db_size_human'] = format_size(result['total_db_size'])
    result['total_wal_size_human'] = format_size(result['total_wal_size'])
    result['total_size_human'] = format_size(result['total_size'])
    
    return result


# =============================================================================
# Auto-compaction hook for post-scan
# =============================================================================

def post_scan_maintenance(repo_db: Path, verbose: bool = False) -> Dict:
    """
    Run maintenance after scan completes.
    
    Called automatically at end of each scan to prevent WAL bloat.
    
    Args:
        repo_db: Path to repo.db
        verbose: Print progress
    
    Returns:
        Maintenance result dict
    """
    result = {
        'checkpointed': False,
        'vacuumed': False,
        'error': None,
    }
    
    if not repo_db.exists():
        return result
    
    try:
        compactor = DatabaseCompactor(repo_db)
        stats = compactor.get_stats()
        
        # Always checkpoint WAL after scan (prevents unbounded growth)
        if stats['wal_size'] > 0:
            compactor.checkpoint('TRUNCATE')
            result['checkpointed'] = True
            if verbose:
                logger.info(f"  ✓ Checkpointed WAL ({stats['wal_size_human']})")
        
        # Vacuum if significantly bloated (>50%)
        if stats['bloat_ratio'] > 0.5:
            compact_result = compactor.compact(force=True)
            if compact_result['vacuumed']:
                result['vacuumed'] = True
                if verbose:
                    logger.info(f"  ✓ Vacuumed ({format_size(compact_result['bytes_freed'])} freed)")
        
    except Exception as e:
        result['error'] = str(e)
        logger.warning(f"Post-scan maintenance failed: {e}")
    
    return result


# =============================================================================
# CLI entry point
# =============================================================================

if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description="REACHABLE Database Compaction")
    parser.add_argument('--status', action='store_true', help='Show database statistics')
    parser.add_argument('--compact', action='store_true', help='Compact all databases')
    parser.add_argument('--checkpoint', action='store_true', help='Checkpoint WAL only (fast)')
    parser.add_argument('--check', action='store_true', help='Check database integrity')
    parser.add_argument('--repair', metavar='REPO', help='Repair a specific repository database')
    parser.add_argument('--force', action='store_true', help='Force vacuum even if low bloat')
    parser.add_argument('--dry-run', action='store_true', help='Preview without making changes')
    parser.add_argument('--home', type=Path, help='REACHABLE home directory')
    
    args = parser.parse_args()
    
    if args.status:
        stats = get_all_database_stats(args.home)
        logger.info(f"\nREACHABLE Database Status")
        print("=" * 60)
        logger.info(f"Total DB size: {stats['total_db_size_human']}")
        logger.info(f"Total WAL size: {stats['total_wal_size_human']}")
        logger.info(f"Total: {stats['total_size_human']}")
        print()
        
        for db in stats['databases']:
            needs_attention = db.get('needs_checkpoint') or db.get('needs_vacuum')
            indicator = "⚠️ " if needs_attention else "  "
            logger.info(f"{indicator}{db['repo']}:")
            logger.info(f"     DB: {db['db_size_human']}, WAL: {db['wal_size_human']}, Bloat: {db['bloat_percent']}")
    
    elif args.compact:
        compact_all_databases(
            reachable_home=args.home,
            force=args.force,
            dry_run=args.dry_run
        )
    
    elif args.checkpoint:
        home = args.home or Path.home() / '.reachable'
        scans_dir = home / 'scans'
        
        logger.info(f"\nCheckpointing all databases...")
        for repo_db in sorted(scans_dir.glob('*/repo.db')):
            repo_name = repo_db.parent.name
            compactor = DatabaseCompactor(repo_db)
            
            if args.dry_run:
                stats = compactor.get_stats()
                logger.info(f"  {repo_name}: would checkpoint {stats['wal_size_human']}")
            else:
                pages, remaining, blocked = compactor.checkpoint('TRUNCATE')
                status = "blocked" if blocked else f"{pages} pages"
                logger.info(f"  {repo_name}: {status}")
    
    elif args.check:
        check_all_databases(args.home)
    
    elif args.repair:
        home = args.home or Path.home() / '.reachable'
        scans_dir = home / 'scans'
        
        # Find matching repo
        matches = list(scans_dir.glob(f'*{args.repair}*/repo.db'))
        if not matches:
            logger.info(f"No database found matching '{args.repair}'")
            exit(1)
        elif len(matches) > 1:
            logger.info(f"Multiple matches found:")
            for m in matches:
                logger.info(f"  {m.parent.name}")
            exit(1)
        
        repo_db = matches[0]
        logger.info(f"\nRepairing {repo_db.parent.name}...")
        
        compactor = DatabaseCompactor(repo_db)
        success, message = compactor.repair()
        
        if success:
            logger.info(f"✅ {message}")
        else:
            logger.info(f"❌ {message}")
            exit(1)
    
    else:
        parser.print_help()
