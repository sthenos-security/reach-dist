# Copyright © 2026 Sthenos Security. All rights reserved.

"""
REACHABLE Kubernetes Security Scanner

Detects security misconfigurations in K8s manifests:
- Missing resource limits (CPU/memory)
- Privileged containers
- Host network/PID/IPC access
- Missing security contexts
- Dangerous capabilities
"""

import re
from pathlib import Path
from typing import Dict, List, Any, Optional
from dataclasses import dataclass
import logging

logger = logging.getLogger(__name__)

try:
    import yaml
except ImportError:
    yaml = None

@dataclass
class K8sFinding:
    """Kubernetes security finding"""
    rule_id: str
    severity: str
    title: str
    description: str
    file_path: str
    line_number: int
    resource_kind: str
    resource_name: str
    namespace: str
    remediation: str

class K8sSecurityScanner:
    """Scanner for Kubernetes manifest security issues"""
    
    # Security rules
    RULES = {
        'K8S-001': {
            'title': 'Missing CPU Limits',
            'severity': 'MEDIUM',
            'description': 'Container does not specify CPU limits, risking resource exhaustion',
            'remediation': 'Add resources.limits.cpu to container spec',
            'cwe': 'CWE-770',
        },
        'K8S-002': {
            'title': 'Missing Memory Limits',
            'severity': 'MEDIUM',
            'description': 'Container does not specify memory limits, risking OOM kills',
            'remediation': 'Add resources.limits.memory to container spec',
            'cwe': 'CWE-770',
        },
        'K8S-003': {
            'title': 'Privileged Container',
            'severity': 'CRITICAL',
            'description': 'Container runs in privileged mode with full host access',
            'remediation': 'Set securityContext.privileged to false',
            'cwe': 'CWE-250',
        },
        'K8S-004': {
            'title': 'Host Network Enabled',
            'severity': 'HIGH',
            'description': 'Pod uses host network namespace, bypassing network isolation',
            'remediation': 'Set hostNetwork to false unless absolutely required',
            'cwe': 'CWE-653',
        },
        'K8S-005': {
            'title': 'Host PID Enabled',
            'severity': 'HIGH',
            'description': 'Pod shares host PID namespace, can see/kill host processes',
            'remediation': 'Set hostPID to false',
            'cwe': 'CWE-653',
        },
        'K8S-006': {
            'title': 'Run as Root',
            'severity': 'MEDIUM',
            'description': 'Container runs as root user (UID 0)',
            'remediation': 'Set runAsNonRoot: true or runAsUser to non-zero',
            'cwe': 'CWE-250',
        },
        'K8S-007': {
            'title': 'Dangerous Capabilities',
            'severity': 'HIGH',
            'description': 'Container has dangerous Linux capabilities',
            'remediation': 'Remove unnecessary capabilities, use drop: [ALL]',
            'cwe': 'CWE-250',
        },
        'K8S-008': {
            'title': 'Writable Root Filesystem',
            'severity': 'LOW',
            'description': 'Container has writable root filesystem',
            'remediation': 'Set readOnlyRootFilesystem: true',
            'cwe': 'CWE-732',
        },
        'K8S-009': {
            'title': 'Missing Liveness Probe',
            'severity': 'LOW',
            'description': 'Container has no liveness probe for health checking',
            'remediation': 'Add livenessProbe to container spec',
            'cwe': 'CWE-754',
        },
        'K8S-010': {
            'title': 'Latest Tag Used',
            'severity': 'MEDIUM',
            'description': 'Container uses :latest tag which is mutable',
            'remediation': 'Pin to specific image digest or version tag',
            'cwe': 'CWE-829',
        },
        'K8S-011': {
            'title': 'Allow Privilege Escalation',
            'severity': 'HIGH',
            'description': 'Container allows privilege escalation via setuid/setgid',
            'remediation': 'Set allowPrivilegeEscalation: false',
            'cwe': 'CWE-269',
        },
        'K8S-012': {
            'title': 'Host Path Mount',
            'severity': 'HIGH',
            'description': 'Pod mounts host filesystem path',
            'remediation': 'Avoid hostPath volumes or restrict to read-only',
            'cwe': 'CWE-552',
        },
    }
    
    # Dangerous capabilities
    DANGEROUS_CAPS = {
        'SYS_ADMIN', 'NET_ADMIN', 'SYS_PTRACE', 'SYS_RAWIO',
        'DAC_OVERRIDE', 'SETUID', 'SETGID', 'NET_RAW',
        'SYS_CHROOT', 'MKNOD', 'AUDIT_WRITE', 'SETFCAP'
    }
    
    def __init__(self):
        self.findings: List[K8sFinding] = []
    
    def scan_directory(self, path: Path) -> List[K8sFinding]:
        """Scan directory for K8s manifests"""
        if yaml is None:
            return []  # YAML not available
            
        self.findings = []
        
        # Find YAML files
        yaml_patterns = ['*.yaml', '*.yml']
        for pattern in yaml_patterns:
            for yaml_file in path.rglob(pattern):
                # Skip hidden dirs and common non-k8s locations
                if any(p.startswith('.') for p in yaml_file.parts):
                    continue
                if 'node_modules' in yaml_file.parts:
                    continue
                    
                self._scan_file(yaml_file)
        
        return self.findings
    
    def _scan_file(self, file_path: Path) -> None:
        """Scan a single YAML file"""
        if yaml is None:
            return
            
        try:
            content = file_path.read_text()
            
            # Parse all documents in file (multi-doc YAML)
            for doc_idx, doc in enumerate(yaml.safe_load_all(content)):
                if doc is None:
                    continue
                    
                # Check if it's a K8s resource
                if not isinstance(doc, dict):
                    continue
                if 'apiVersion' not in doc or 'kind' not in doc:
                    continue
                
                self._scan_resource(doc, file_path, doc_idx)
                
        except yaml.YAMLError:
            pass  # Not valid YAML
        except Exception:
            pass  # Skip files we can't read
    
    def _scan_resource(self, resource: Dict, file_path: Path, doc_idx: int) -> None:
        """Scan a K8s resource for security issues"""
        kind = resource.get('kind', '')
        metadata = resource.get('metadata', {})
        name = metadata.get('name', 'unnamed')
        namespace = metadata.get('namespace', 'default')
        
        # Get pod spec based on resource type
        pod_spec = None
        if kind == 'Pod':
            pod_spec = resource.get('spec', {})
        elif kind in ('Deployment', 'StatefulSet', 'DaemonSet', 'ReplicaSet', 'Job'):
            pod_spec = resource.get('spec', {}).get('template', {}).get('spec', {})
        elif kind == 'CronJob':
            pod_spec = resource.get('spec', {}).get('jobTemplate', {}).get('spec', {}).get('template', {}).get('spec', {})
        
        if not pod_spec:
            return
        
        # Check pod-level settings
        self._check_pod_security(pod_spec, file_path, kind, name, namespace)
        
        # Check each container
        for container in pod_spec.get('containers', []):
            self._check_container_security(container, file_path, kind, name, namespace)
        
        for container in pod_spec.get('initContainers', []):
            self._check_container_security(container, file_path, kind, name, namespace, is_init=True)
        
        # Check volumes
        for volume in pod_spec.get('volumes', []):
            self._check_volume_security(volume, file_path, kind, name, namespace)
    
    def _check_pod_security(self, pod_spec: Dict, file_path: Path, kind: str, name: str, namespace: str) -> None:
        """Check pod-level security settings"""
        
        # K8S-004: Host Network
        if pod_spec.get('hostNetwork', False):
            self._add_finding('K8S-004', file_path, kind, name, namespace)
        
        # K8S-005: Host PID
        if pod_spec.get('hostPID', False):
            self._add_finding('K8S-005', file_path, kind, name, namespace)
        
        # Also check hostIPC
        if pod_spec.get('hostIPC', False):
            self._add_finding('K8S-005', file_path, kind, name, namespace,
                            description='Pod shares host IPC namespace')
    
    def _check_container_security(self, container: Dict, file_path: Path, kind: str, 
                                   name: str, namespace: str, is_init: bool = False) -> None:
        """Check container security settings"""
        container_name = container.get('name', 'unnamed')
        
        # K8S-001: CPU Limits
        resources = container.get('resources', {})
        limits = resources.get('limits', {})
        if 'cpu' not in limits:
            self._add_finding('K8S-001', file_path, kind, name, namespace,
                            description=f"Container '{container_name}' missing CPU limits")
        
        # K8S-002: Memory Limits
        if 'memory' not in limits:
            self._add_finding('K8S-002', file_path, kind, name, namespace,
                            description=f"Container '{container_name}' missing memory limits")
        
        # Security context checks
        sec_ctx = container.get('securityContext', {})
        
        # K8S-003: Privileged
        if sec_ctx.get('privileged', False):
            self._add_finding('K8S-003', file_path, kind, name, namespace,
                            description=f"Container '{container_name}' runs privileged")
        
        # K8S-006: Run as root
        run_as_user = sec_ctx.get('runAsUser')
        run_as_non_root = sec_ctx.get('runAsNonRoot', False)
        if run_as_user == 0 or (run_as_user is None and not run_as_non_root):
            self._add_finding('K8S-006', file_path, kind, name, namespace,
                            description=f"Container '{container_name}' may run as root")
        
        # K8S-007: Dangerous capabilities
        caps = sec_ctx.get('capabilities', {})
        added_caps = set(caps.get('add', []))
        dangerous = added_caps & self.DANGEROUS_CAPS
        if dangerous:
            self._add_finding('K8S-007', file_path, kind, name, namespace,
                            description=f"Container '{container_name}' has dangerous capabilities: {dangerous}")
        
        # K8S-008: Writable root filesystem
        if not sec_ctx.get('readOnlyRootFilesystem', False):
            self._add_finding('K8S-008', file_path, kind, name, namespace,
                            description=f"Container '{container_name}' has writable root filesystem")
        
        # K8S-009: Missing liveness probe (skip init containers)
        if not is_init and 'livenessProbe' not in container:
            self._add_finding('K8S-009', file_path, kind, name, namespace,
                            description=f"Container '{container_name}' missing liveness probe")
        
        # K8S-010: Latest tag
        image = container.get('image', '')
        if ':latest' in image or (':' not in image and '@' not in image):
            self._add_finding('K8S-010', file_path, kind, name, namespace,
                            description=f"Container '{container_name}' uses mutable tag: {image}")
        
        # K8S-011: Allow privilege escalation
        if sec_ctx.get('allowPrivilegeEscalation', True):  # Default is true!
            self._add_finding('K8S-011', file_path, kind, name, namespace,
                            description=f"Container '{container_name}' allows privilege escalation")
    
    def _check_volume_security(self, volume: Dict, file_path: Path, kind: str, name: str, namespace: str) -> None:
        """Check volume security"""
        volume_name = volume.get('name', 'unnamed')
        
        # K8S-012: Host path
        if 'hostPath' in volume:
            host_path = volume['hostPath'].get('path', '')
            self._add_finding('K8S-012', file_path, kind, name, namespace,
                            description=f"Volume '{volume_name}' mounts host path: {host_path}")
    
    def _add_finding(self, rule_id: str, file_path: Path, kind: str, name: str, 
                     namespace: str, description: str = None, line_number: int = 1) -> None:
        """Add a finding"""
        rule = self.RULES.get(rule_id, {})
        
        finding = K8sFinding(
            rule_id=rule_id,
            severity=rule.get('severity', 'MEDIUM'),
            title=rule.get('title', rule_id),
            description=description or rule.get('description', ''),
            file_path=str(file_path),
            line_number=line_number,
            resource_kind=kind,
            resource_name=name,
            namespace=namespace,
            remediation=rule.get('remediation', '')
        )
        self.findings.append(finding)
    
    def to_dict(self) -> List[Dict]:
        """Convert findings to dictionary format"""
        return [
            {
                'type': 'CONFIG',
                'subtype': 'K8S',
                'rule_id': f.rule_id,
                'severity': f.severity,
                'title': f.title,
                'description': f.description,
                'file': f.file_path,
                'line': f.line_number,
                'resource': f"{f.resource_kind}/{f.resource_name}",
                'namespace': f.namespace,
                'remediation': f.remediation,
                'reachability': 'UNKNOWN',
            }
            for f in self.findings
        ]

def scan_k8s_manifests(path: Path) -> List[Dict]:
    """Convenience function to scan K8s manifests"""
    scanner = K8sSecurityScanner()
    scanner.scan_directory(path)
    return scanner.to_dict()

if __name__ == '__main__':
    import sys
    
    if len(sys.argv) < 2:
        logger.info("Usage: python k8s_scanner.py <path>")
        sys.exit(1)
    
    path = Path(sys.argv[1])
    findings = scan_k8s_manifests(path)
    
    logger.info(f"Found {len(findings)} K8s security issues:")
    for f in findings:
        logger.info(f"  [{f['severity']}] {f['rule_id']}: {f['title']}")
        logger.info(f"      {f['resource']} in {f['file']}")
