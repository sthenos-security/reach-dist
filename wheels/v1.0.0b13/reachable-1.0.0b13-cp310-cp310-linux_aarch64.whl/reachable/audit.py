#!/usr/bin/env python3
"""
REACHABLE Comprehensive Data Quality Audit

Complete pipeline validation from Log → Raw JSON → Database → Dashboard
Checks ALL finding types, states, severities, risk scores, and reduction metrics.

This is the "smoking gun" audit to prove data quality to customers.
"""

import sqlite3
import json
import gzip
import re
import sys
import logging
from pathlib import Path
from typing import Dict, Optional, List
from collections import defaultdict

logger = logging.getLogger(__name__)

# Canonical order for finding types (must match scan log RESULTS table)
FINDING_TYPE_ORDER = ['cve', 'malware', 'secret', 'cwe', 'config', 'ai', 'dlp']


def normalize_severity(sev: str) -> str:
    """Normalize non-standard severities to standard levels."""
    sev = (sev or 'MEDIUM').upper()
    if sev == 'ERROR':
        return 'HIGH'
    elif sev == 'WARNING':
        return 'MEDIUM'
    return sev


class PipelineMetrics:
    """Metrics from one stage of the pipeline."""
    
    def __init__(self, stage: str):
        self.stage = stage
        
        # Finding counts by type and reachability
        self.findings = defaultdict(lambda: {'total': 0, 'reachable': 0, 'unreachable': 0, 'unknown': 0})
        
        # Severity counts (normalized)
        self.severity = {'CRITICAL': 0, 'HIGH': 0, 'MEDIUM': 0, 'LOW': 0, 'INFO': 0}
        
        # Risk metrics
        self.risk_score = None
        self.risk_level = None
        self.reduction_pct = None
        
        # Metadata
        self.files_scanned = None
        self.db_size_mb = None
        
        # Errors
        self.errors = []
    
    def total_findings(self) -> int:
        # P2.50: Exclude CONFIG from totals (not part of risk calculation)
        return sum(f['total'] for k, f in self.findings.items() if k.upper() != 'CONFIG')
    
    def total_reachable(self) -> int:
        # P2.50: Exclude CONFIG from totals (not part of risk calculation)
        return sum(f['reachable'] for k, f in self.findings.items() if k.upper() != 'CONFIG')
    
    def total_unreachable(self) -> int:
        # P2.50: Exclude CONFIG from totals (not part of risk calculation)
        return sum(f['unreachable'] for k, f in self.findings.items() if k.upper() != 'CONFIG')


class ComprehensiveAuditor:
    """Complete data quality auditor."""
    
    def __init__(self, scan_path: Path):
        self.scan_path = scan_path.resolve()
        self.repo_dir = self.scan_path.parent.parent
        self.db_path = self.repo_dir / 'repo.db'
    
    def audit_raw(self) -> PipelineMetrics:
        """Audit raw JSON files (ground truth from scanners)."""
        m = PipelineMetrics('RAW JSON')
        
        # Load reachable-report.json.gz
        report_file = self.scan_path / 'reachable-report.json.gz'
        if not report_file.exists():
            report_file = self.scan_path / 'reachable-report.json'
        
        if not report_file.exists():
            m.errors.append("reachable-report.json not found")
            return m
        
        try:
            if str(report_file).endswith('.gz'):
                with gzip.open(report_file, 'rt') as f:
                    report = json.load(f)
            else:
                with open(report_file) as f:
                    report = json.load(f)
            
            # CVEs
            reachable_cves = report.get('reachable', {})
            unreachable_cves = report.get('unreachable', {})
            
            m.findings['cve']['reachable'] = len(reachable_cves)
            m.findings['cve']['unreachable'] = len(unreachable_cves)
            m.findings['cve']['total'] = m.findings['cve']['reachable'] + m.findings['cve']['unreachable']
            
            # Count CVE severities
            for cve in list(reachable_cves.values()) + list(unreachable_cves.values()):
                sev = normalize_severity(cve.get('severity', 'MEDIUM'))
                m.severity[sev] = m.severity.get(sev, 0) + 1
            
            # Detailed findings
            df = report.get('detailed_findings', {})
            
            # CWE
            cwe_data = df.get('cwe', {})
            if isinstance(cwe_data, dict):
                for finding in cwe_data.get('findings', []):
                    m.findings['cwe']['total'] += 1
                    if finding.get('is_reachable'):
                        m.findings['cwe']['reachable'] += 1
                    elif finding.get('is_reachable') is False:
                        m.findings['cwe']['unreachable'] += 1
                    else:
                        m.findings['cwe']['unknown'] += 1
                    
                    sev = normalize_severity(finding.get('severity', 'MEDIUM'))
                    m.severity[sev] = m.severity.get(sev, 0) + 1
            
            # Secrets
            secrets_data = df.get('secrets', {})
            if isinstance(secrets_data, dict):
                for finding in secrets_data.get('findings', []):
                    if not finding.get('is_actual_secret'):
                        continue
                    m.findings['secret']['total'] += 1
                    reach = finding.get('reachability', '').upper()
                    if reach == 'REACHABLE':
                        m.findings['secret']['reachable'] += 1
                    elif reach in ('NOT_REACHABLE', 'UNREACHABLE'):
                        m.findings['secret']['unreachable'] += 1
                    else:
                        m.findings['secret']['unknown'] += 1
                    
                    sev = normalize_severity(finding.get('severity', 'MEDIUM'))
                    m.severity[sev] = m.severity.get(sev, 0) + 1
            
            # Config (always unknown)
            config_data = df.get('config', {})
            if isinstance(config_data, dict):
                config_findings = config_data.get('findings', [])
                m.findings['config']['total'] = len(config_findings)
                m.findings['config']['unknown'] = len(config_findings)
                
                for finding in config_findings:
                    sev = normalize_severity(finding.get('severity', 'MEDIUM'))
                    m.severity[sev] = m.severity.get(sev, 0) + 1
            
            # AI
            ai_sec = report.get('ai_security', {})
            if ai_sec and ai_sec.get('enabled'):
                m.findings['ai']['total'] = ai_sec.get('total', 0)
                m.findings['ai']['reachable'] = ai_sec.get('reachable', 0)
                m.findings['ai']['unreachable'] = m.findings['ai']['total'] - m.findings['ai']['reachable']
            
            # DLP
            dlp_sec = report.get('dlp_security', {})
            if dlp_sec and dlp_sec.get('enabled'):
                m.findings['dlp']['total'] = dlp_sec.get('total', 0)
                m.findings['dlp']['reachable'] = dlp_sec.get('reachable', 0)
                m.findings['dlp']['unreachable'] = m.findings['dlp']['total'] - m.findings['dlp']['reachable']
            
            # Malware
            malware_det = report.get('malware_detection', {})
            if malware_det:
                malicious = malware_det.get('malicious_packages', [])
                if isinstance(malicious, list):
                    m.findings['malware']['total'] = len(malicious)
                    m.findings['malware']['reachable'] = len(malicious)  # All malware is reachable
                else:
                    m.findings['malware']['total'] = malicious
                    m.findings['malware']['reachable'] = malicious
            
            # Risk metrics
            summary = report.get('summary', {})
            overall_risk = summary.get('overall_risk', {})
            m.risk_score = overall_risk.get('risk_score')
            m.risk_level = overall_risk.get('risk_level')
            m.reduction_pct = summary.get('risk_reduction_pct')
            
            # Metadata
            metadata = report.get('metadata', {})
            m.files_scanned = metadata.get('source_files_scanned')
            
        except Exception as e:
            m.errors.append(f"Error reading raw data: {e}")
        
        return m
    
    def audit_database(self) -> PipelineMetrics:
        """Audit database (persisted scan data)."""
        m = PipelineMetrics('DATABASE')
        
        if not self.db_path.exists():
            m.errors.append(f"repo.db not found (--no-db mode or first scan)")
            return m
        
        m.db_size_mb = self.db_path.stat().st_size / 1024 / 1024
        
        try:
            conn = sqlite3.connect(str(self.db_path))
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            
            # Get scan that matches this specific scan path
            # scan_dir in DB stores the full path to the scan directory
            cursor.execute("""
                SELECT * FROM scans 
                WHERE scan_dir = ?
                ORDER BY id DESC LIMIT 1
            """, (str(self.scan_path),))
            scan_row = cursor.fetchone()
            
            # Fallback: try with just the timestamp portion of the path
            if not scan_row:
                scan_timestamp = self.scan_path.name  # e.g., "20260130-140715-2b9f8b"
                cursor.execute("""
                    SELECT * FROM scans 
                    WHERE scan_dir LIKE ?
                    ORDER BY id DESC LIMIT 1
                """, (f'%/{scan_timestamp}',))
                scan_row = cursor.fetchone()
            
            # Final fallback: try matching on timestamp prefix
            if not scan_row:
                scan_prefix = self.scan_path.name[:15]  # "20260130-140715"
                cursor.execute("""
                    SELECT * FROM scans 
                    WHERE scan_dir LIKE ?
                    ORDER BY id DESC LIMIT 1
                """, (f'%{scan_prefix}%',))
                scan_row = cursor.fetchone()
                if scan_row:
                    m.errors.append(f"WARNING: Using partial match for scan path")
            
            if not scan_row:
                m.errors.append("No data for this scan in database (scan may not have completed)")
                conn.close()
                return m
            
            scan_id = scan_row['id']
            m.risk_score = scan_row['risk_score']
            m.risk_level = scan_row['risk_level']
            try:
                m.files_scanned = scan_row['source_files_scanned']
            except (KeyError, IndexError):
                m.files_scanned = None
            
            # CVE, CWE, secrets, config from findings table
            cursor.execute("""
                SELECT finding_type,
                       app_reachability,
                       severity,
                       COUNT(*) as count
                FROM findings
                WHERE scan_id = ?
                GROUP BY finding_type, app_reachability, severity
            """, (scan_id,))
            
            for row in cursor.fetchall():
                ftype = row['finding_type'].lower()
                reach = row['app_reachability']
                sev = normalize_severity(row['severity'])
                count = row['count']
                
                m.findings[ftype]['total'] += count
                
                if reach == 'REACHABLE':
                    m.findings[ftype]['reachable'] += count
                elif reach == 'NOT_REACHABLE':
                    m.findings[ftype]['unreachable'] += count
                else:
                    m.findings[ftype]['unknown'] += count
                
                m.severity[sev] = m.severity.get(sev, 0) + count
            
            # AI findings
            try:
                cursor.execute("""
                    SELECT is_reachable, severity, COUNT(*) as count
                    FROM ai_findings
                    WHERE scan_id = ?
                    GROUP BY is_reachable, severity
                """, (scan_id,))
                
                for row in cursor.fetchall():
                    count = row['count']
                    m.findings['ai']['total'] += count
                    
                    if row['is_reachable']:
                        m.findings['ai']['reachable'] += count
                    else:
                        m.findings['ai']['unreachable'] += count
                    
                    sev = normalize_severity(row['severity'])
                    m.severity[sev] = m.severity.get(sev, 0) + count
            except sqlite3.OperationalError:
                pass
            
            # DLP findings
            try:
                cursor.execute("""
                    SELECT is_reachable, severity, COUNT(*) as count
                    FROM dlp_findings
                    WHERE scan_id = ?
                    GROUP BY is_reachable, severity
                """, (scan_id,))
                
                for row in cursor.fetchall():
                    count = row['count']
                    m.findings['dlp']['total'] += count
                    
                    if row['is_reachable']:
                        m.findings['dlp']['reachable'] += count
                    else:
                        m.findings['dlp']['unreachable'] += count
                    
                    sev = normalize_severity(row['severity'])
                    m.severity[sev] = m.severity.get(sev, 0) + count
            except sqlite3.OperationalError:
                pass
            
            # Calculate noise reduction
            total = m.total_findings()
            unreachable = m.total_unreachable()
            if total > 0:
                m.reduction_pct = 100 * (unreachable / total)
            
            conn.close()
            
        except Exception as e:
            m.errors.append(f"Database error: {e}")
        
        return m
    
    def audit_dashboard(self) -> PipelineMetrics:
        """Audit dashboard data.json or embedded HTML data."""
        m = PipelineMetrics('DASHBOARD')
        
        # Prefer data.json (more reliable than parsing HTML)
        data_json_path = self.scan_path / 'dashboard' / 'data.json'
        dash_html_path = self.scan_path / 'dashboard' / 'index.html'
        
        data = None
        
        if data_json_path.exists():
            try:
                data = json.loads(data_json_path.read_text())
            except Exception as e:
                m.errors.append(f"data.json parse error: {e}")
        
        if data is None and dash_html_path.exists():
            try:
                content = dash_html_path.read_text()
                match = re.search(r'window\.dashboardData\s*=\s*({.*?});', content, re.DOTALL)
                if match:
                    data = json.loads(match.group(1))
            except Exception as e:
                m.errors.append(f"HTML parse error: {e}")
        
        if data is None:
            m.errors.append(f"Dashboard not found")
            return m
        
        try:
            m.risk_score = data.get('riskScore') or data.get('risk_score')
            m.risk_level = data.get('riskLevel') or data.get('risk_level')
            
            # Count issues from issues array
            issues = data.get('issues', [])
            for issue in issues:
                itype = issue.get('type', 'unknown').lower()
                sev = normalize_severity(issue.get('severity', 'MEDIUM'))
                is_reach = issue.get('reachable', False) or issue.get('is_reachable', False)
                reach_state = issue.get('reachability_state', '').lower()
                
                m.findings[itype]['total'] += 1
                
                if is_reach or reach_state == 'reachable':
                    m.findings[itype]['reachable'] += 1
                elif reach_state == 'unknown':
                    m.findings[itype]['unknown'] += 1
                else:
                    m.findings[itype]['unreachable'] += 1
                
                m.severity[sev] = m.severity.get(sev, 0) + 1
            
            # P2.50 FIX: AI and DLP are now included in issues[] via loaders.py
            # _convert_ai_to_issues() and _convert_dlp_to_issues()
            # Only count from separate arrays if NOT already in issues[]
            
            # AI findings - only count if not already in issues[]
            ai_in_issues = m.findings.get('ai', {}).get('total', 0)
            if ai_in_issues == 0:
                ai_security = data.get('ai_security', {})
                if isinstance(ai_security, dict) and ai_security.get('total', 0) > 0:
                    m.findings['ai']['total'] = ai_security.get('total', 0)
                    m.findings['ai']['reachable'] = ai_security.get('reachable', 0)
                    m.findings['ai']['unreachable'] = m.findings['ai']['total'] - m.findings['ai']['reachable']
                elif isinstance(ai_security, dict):
                    ai_findings = ai_security.get('findings', [])
                    for finding in ai_findings:
                        m.findings['ai']['total'] += 1
                        if finding.get('is_reachable'):
                            m.findings['ai']['reachable'] += 1
                        else:
                            m.findings['ai']['unreachable'] += 1
            
            # DLP findings - only count if not already in issues[]
            dlp_in_issues = m.findings.get('dlp', {}).get('total', 0)
            if dlp_in_issues == 0:
                dlp_findings = data.get('dlp_findings', []) or data.get('dlpFindings', [])
                for finding in dlp_findings:
                    m.findings['dlp']['total'] += 1
                    if finding.get('is_reachable'):
                        m.findings['dlp']['reachable'] += 1
                    else:
                        m.findings['dlp']['unreachable'] += 1
            
        except Exception as e:
            m.errors.append(f"Dashboard error: {e}")
        
        return m
    
    def compare_stages(self, raw: PipelineMetrics, db: PipelineMetrics, dash: PipelineMetrics) -> List[str]:
        """Compare stages and return list of issues."""
        issues = []
        
        for ftype in FINDING_TYPE_ORDER:
            raw_f = raw.findings.get(ftype, {})
            db_f = db.findings.get(ftype, {})
            dash_f = dash.findings.get(ftype, {})
            
            raw_total = raw_f.get('total', 0)
            db_total = db_f.get('total', 0)
            dash_total = dash_f.get('total', 0)
            
            # Only flag mismatch if both have data and they differ significantly
            if raw_total > 0 and db_total > 0 and abs(raw_total - db_total) > 5:
                issues.append(f"❌ {ftype.upper()}: Raw={raw_total}, DB={db_total} (MISMATCH)")
            
            # P2.44 check: DB has findings but dashboard shows 0
            if db_total > 0 and dash_total == 0:
                issues.append(f"🚨 P2.44 BUG: {ftype.upper()} dashboard shows 0 but DB has {db_total}")
            
            # Compare reachable counts
            raw_reach = raw_f.get('reachable', 0)
            db_reach = db_f.get('reachable', 0)
            
            if raw_reach > 0 and db_reach > 0 and abs(raw_reach - db_reach) > 2:
                issues.append(f"⚠️  {ftype.upper()} reachable: Raw={raw_reach}, DB={db_reach}")
        
        # Risk score drift
        if raw.risk_score and db.risk_score and abs(raw.risk_score - db.risk_score) > 10:
            issues.append(f"⚠️  Risk score drift: Raw={raw.risk_score}, DB={db.risk_score}")
        
        if db.risk_score and dash.risk_score and abs(db.risk_score - dash.risk_score) > 10:
            issues.append(f"⚠️  Risk score drift: DB={db.risk_score}, Dashboard={dash.risk_score}")
        
        return issues
    
    def print_report(self, raw: PipelineMetrics, db: PipelineMetrics, dash: PipelineMetrics, issues: List[str]):
        """Print comprehensive report."""
        print("")
        print("🔍 REACHABLE DATA QUALITY AUDIT (deduplicated, from DB unique records)")
        print(f"   Scan: {self.scan_path}")
        db_size_str = f"{db.db_size_mb:.2f} MB" if db.db_size_mb is not None else "N/A"
        print(f"   Database: {self.db_path} ({db_size_str})")
        print("")
        
        # Stage comparison table
        # Note: Raw = scanner output (may have duplicates), DB/Dash = deduplicated unique records
        print(f"{'Type':<10} {'Raw':>6} {'DB':>6} {'Dash':>6}  {'Reach':>5} {'Unrch':>5} {'Unkn':>5}  {'Filtered':>8}")
        print("─" * 68)
        
        # Use canonical order for finding types
        for ftype in FINDING_TYPE_ORDER:
            raw_f = raw.findings.get(ftype, {})
            db_f = db.findings.get(ftype, {})
            dash_f = dash.findings.get(ftype, {})
            
            raw_total = raw_f.get('total', 0)
            db_total = db_f.get('total', 0)
            dash_total = dash_f.get('total', 0)
            
            db_reach = db_f.get('reachable', 0)
            db_unreach = db_f.get('unreachable', 0)
            db_unknown = db_f.get('unknown', 0)
            
            reduction = ""
            if db_total > 0:
                pct = 100 * (db_unreach / db_total)
                reduction = f"{pct:5.1f}%"
            
            match = "✓" if abs(raw_total - db_total) <= 5 or raw_total == 0 or db_total == 0 else "✗"
            
            print(f"{ftype.upper():<10} {raw_total:>6} {db_total:>6} {dash_total:>6}  "
                  f"{db_reach:>5} {db_unreach:>5} {db_unknown:>5}  {reduction:>8} {match}")
        
        # Totals
        print("─" * 68)
        raw_total = raw.total_findings()
        db_total = db.total_findings()
        dash_total = dash.total_findings()
        db_reach = db.total_reachable()
        db_unreach = db.total_unreachable()
        # P2.50: Exclude CONFIG from unknown total (not part of risk calculation)
        db_unknown = sum(f.get('unknown', 0) for k, f in db.findings.items() if k.upper() != 'CONFIG')
        
        total_reduction = ""
        if db_total > 0:
            pct = 100 * (db_unreach / db_total)
            total_reduction = f"{pct:5.1f}%"
        
        print(f"{'TOTAL':<10} {raw_total:>6} {db_total:>6} {dash_total:>6}  "
              f"{db_reach:>5} {db_unreach:>5} {db_unknown:>5}  {total_reduction:>8}")
        print(f"{'(excl CONFIG)':<10}")
        
        # Severity breakdown (inline)
        print("")
        sev_parts = []
        for sev in ['CRITICAL', 'HIGH', 'MEDIUM', 'LOW', 'INFO']:
            count = db.severity.get(sev, 0)
            if count > 0:
                sev_parts.append(f"{sev}: {count}")
        if sev_parts:
            print(f"Severity: {' | '.join(sev_parts)}")
        
        # Risk metrics (inline)
        risk_parts = []
        if db.risk_level:
            risk_parts.append(f"Level: {db.risk_level}")
        if db.risk_score:
            risk_parts.append(f"Score: {db.risk_score}")
        if db.reduction_pct:
            risk_parts.append(f"Noise Reduction: {db.reduction_pct:.1f}%")
        if risk_parts:
            print(f"Risk: {' | '.join(risk_parts)}")
        
        # Validation results
        print("")
        if not issues and not any([raw.errors, db.errors, dash.errors]):
            print("✅ All checks passed - data integrity confirmed")
        else:
            for err in raw.errors + db.errors + dash.errors:
                print(f"❌ {err}")
            for issue in issues:
                print(f"{issue}")
            if not issues:
                print("✓ No data consistency issues")
        
        print("")
        return len(issues) == 0 and not any([raw.errors, db.errors, dash.errors])
    
    def print_compact_report(self, raw: PipelineMetrics, db: PipelineMetrics, dash: PipelineMetrics, issues: List[str]):
        """
        Print compact audit report suitable for scan log.
        
        v4.6.4: Added for integration with scan completion flow.
        Shows key metrics in a condensed format that complements the RESULTS table.
        """
        print("")
        print("🔍 DATA INTEGRITY CHECK")
        print("─" * 68)
        
        # Quick summary
        db_total = db.total_findings()
        db_reach = db.total_reachable()
        db_unreach = db.total_unreachable()
        dash_total = dash.total_findings()
        raw_total = raw.total_findings()
        
        # Check if dashboard was skipped
        dash_skipped = any('skipped' in e.lower() for e in dash.errors)
        
        # Check for issues (excluding dashboard-skipped errors)
        real_errors = raw.errors + db.errors
        if not dash_skipped:
            real_errors += dash.errors
        has_issues = len(issues) > 0 or any(real_errors)
        
        # Pipeline flow check
        if dash_skipped:
            print(f"  Pipeline: Raw({raw_total}) → DB({db_total}) → Dashboard(skipped)")
        else:
            print(f"  Pipeline: Raw({raw_total}) → DB({db_total}) → Dashboard({dash_total})")
        
        if not has_issues:
            if dash_skipped:
                print(f"  ✅ Raw → DB consistent (dashboard skipped)")
            else:
                print(f"  ✅ All stages consistent - no data loss detected")
        else:
            print(f"  ⚠️  Discrepancies detected:")
            # Show errors first (but not dashboard-skipped)
            for err in real_errors[:2]:
                print(f"     ❌ {err}")
            # Show comparison issues
            for issue in issues[:2]:
                print(f"     {issue}")
            remaining = len(issues) + len(real_errors) - 4
            if remaining > 0:
                print(f"     Run 'reachctl audit' for full report")
        
        # Severity distribution (valuable info not in RESULTS table)
        print("")
        print("  Severity Distribution:")
        sev_parts = []
        for sev, icon in [('CRITICAL', '🔴'), ('HIGH', '🟠'), ('MEDIUM', '🟡'), ('LOW', '🟢')]:
            count = db.severity.get(sev, 0)
            if count > 0:
                sev_parts.append(f"{icon} {count} {sev.lower()}")
        if sev_parts:
            print(f"     {' | '.join(sev_parts)}")
        else:
            print(f"     No findings")
        
        print("─" * 68)


def find_latest_scan() -> Optional[Path]:
    """Find most recent scan by modification time."""
    scans_dir = Path.home() / '.reachable' / 'scans'
    
    if not scans_dir.exists():
        return None
    
    latest_scan = None
    latest_time = 0
    
    for repo_dir in scans_dir.iterdir():
        if not repo_dir.is_dir():
            continue
        for branch_dir in repo_dir.iterdir():
            if not branch_dir.is_dir():
                continue
            # Check all scan directories, not just 'latest' symlink
            for scan_dir in branch_dir.iterdir():
                if not scan_dir.is_dir():
                    continue
                if scan_dir.name == 'latest':
                    continue
                # Check for dashboard as indicator of completed scan
                if (scan_dir / 'dashboard' / 'index.html').exists():
                    mtime = scan_dir.stat().st_mtime
                    if mtime > latest_time:
                        latest_time = mtime
                        latest_scan = scan_dir
    
    return latest_scan


def run_audit(scan_path: Path, compact: bool = False, no_dashboard: bool = False) -> dict:
    """
    Run comprehensive audit and return results.
    
    v4.6.4: Added for integration with scan completion flow.
    
    Structure expected:
        ~/.reachable/scans/{repo-hash}/{branch}/{timestamp}/
        ~/.reachable/scans/{repo-hash}/repo.db  (shared per-repo database)
    
    Args:
        scan_path: Path to scan directory (the timestamp dir)
        compact: If True, print compact format suitable for scan log
        no_dashboard: If True, dashboard was skipped (--no-dashboard flag)
        
    Returns:
        Dict with audit results:
        - passed: bool - True if all checks passed
        - raw: PipelineMetrics - Raw JSON audit results  
        - db: PipelineMetrics - Database audit results
        - dash: PipelineMetrics - Dashboard audit results
        - issues: List[str] - List of detected issues
        - skipped: bool - True if audit was skipped
        - warnings: List[str] - Non-fatal warnings
    """
    scan_path = Path(scan_path).expanduser().resolve()
    warnings = []
    
    if not scan_path.exists():
        return {'passed': False, 'error': f'Scan directory not found: {scan_path}'}
    
    # Extract branch from path: scan_path.parent is the branch dir
    branch_dir = scan_path.parent
    branch_name = branch_dir.name
    repo_dir = branch_dir.parent
    
    # Check for repo.db at repo level
    repo_db = repo_dir / 'repo.db'
    if not repo_db.exists():
        if compact:
            print("")
            print("🔍 DATA INTEGRITY CHECK")
            print("─" * 68)
            print("  ⚠️  Skipped: No database (--no-db mode or first scan)")
            print("─" * 68)
        return {'passed': True, 'skipped': True, 'reason': 'No database (repo.db not found)'}
    
    # Check for dashboard (may have been skipped with --no-dashboard)
    dashboard_dir = scan_path / 'dashboard'
    if no_dashboard or not dashboard_dir.exists():
        warnings.append('Dashboard not generated (--no-dashboard)')
    
    try:
        auditor = ComprehensiveAuditor(scan_path)
        
        raw = auditor.audit_raw()
        db = auditor.audit_database()
        
        # Check if we found a matching scan record
        if db.total_findings() == 0 and 'No data for this scan' in str(db.errors):
            # No scan record found for this specific run
            if compact:
                print("")
                print("🔍 DATA INTEGRITY CHECK")
                print("─" * 68)
                print(f"  ⚠️  No data in DB for this scan (branch: {branch_name})")
                print(f"     Scan may not have completed or DB was trimmed")
                print("─" * 68)
            return {
                'passed': False,
                'skipped': True,
                'reason': f'No scan record in database for this run',
                'warnings': warnings,
            }
        
        # Handle missing dashboard gracefully
        if no_dashboard or not dashboard_dir.exists():
            dash = PipelineMetrics('DASHBOARD')
            dash.errors.append('Dashboard skipped (--no-dashboard)')
        else:
            dash = auditor.audit_dashboard()
        
        issues = auditor.compare_stages(raw, db, dash)
        
        # Don't flag dashboard issues if dashboard was intentionally skipped
        if no_dashboard or not dashboard_dir.exists():
            issues = [i for i in issues if 'dashboard' not in i.lower() and 'P2.44' not in i]
        
        if compact:
            auditor.print_compact_report(raw, db, dash, issues)
        
        passed = len(issues) == 0 and not any([raw.errors, db.errors])
        # Don't fail on dashboard errors if dashboard was skipped
        if not no_dashboard and dashboard_dir.exists():
            passed = passed and not dash.errors
        
        return {
            'passed': passed,
            'raw': raw,
            'db': db, 
            'dash': dash,
            'issues': issues,
            'warnings': warnings,
        }
    except Exception as e:
        return {'passed': False, 'error': str(e)}


def main():
    """Run comprehensive audit."""
    import argparse
    
    parser = argparse.ArgumentParser(description='REACHABLE Data Quality Audit')
    parser.add_argument('scan_path', type=Path, nargs='?', help='Scan directory to audit (e.g., ~/.reachable/scans/repo/branch/20260130-123456-abc123)')
    parser.add_argument('--scan-path', '-p', type=Path, dest='scan_path_opt', help='Scan directory (alternative syntax)')
    args = parser.parse_args()
    
    # Support both positional and --scan-path
    scan_path = args.scan_path or args.scan_path_opt
    
    if not scan_path:
        scan_path = find_latest_scan()
        if not scan_path:
            print("Error: No scans found. Run a scan first or specify scan path.")
            print("Usage: reachctl audit [SCAN_PATH]")
            print("       reachctl audit --scan-path PATH")
            sys.exit(1)
    
    # Expand ~ and resolve
    scan_path = Path(scan_path).expanduser().resolve()
    
    if not scan_path.exists():
        print(f"Error: Scan directory not found: {scan_path}")
        sys.exit(1)
    
    # Verify it looks like a scan directory
    if not (scan_path / 'dashboard').exists() and not (scan_path / 'reachable-report.json.gz').exists():
        print(f"Error: {scan_path} doesn't appear to be a valid scan directory")
        print("Expected to find 'dashboard/' or 'reachable-report.json.gz'")
        sys.exit(1)
    
    # Run audit
    auditor = ComprehensiveAuditor(scan_path)
    
    raw = auditor.audit_raw()
    db = auditor.audit_database()
    dash = auditor.audit_dashboard()
    
    issues = auditor.compare_stages(raw, db, dash)
    
    passed = auditor.print_report(raw, db, dash, issues)
    
    sys.exit(0 if passed else 1)


if __name__ == '__main__':
    main()
