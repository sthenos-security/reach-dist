#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.

"""
GuardDog Malware Detection Integration

Integrates GuardDog to scan Python packages for malicious code patterns.
GuardDog checks for:
- Obfuscated code
- Network connections to suspicious domains
- Code execution patterns
- Credential theft attempts
- And more...

CI/CD Caching:
    Set REACHABLE_CACHE_DIR to a cached path for faster CI builds.
    The guarddog-venv subdirectory will be created there.
    
    GitHub Actions example:
        - uses: actions/cache@v4
          with:
            path: ~/.reachable-cache
            key: reachable-cache-${{ runner.os }}-v1
        - run: reachable scan .
          env:
            REACHABLE_CACHE_DIR: ~/.reachable-cache
    
    GitLab CI example:
        cache:
          paths:
            - .reachable-cache/
        variables:
          REACHABLE_CACHE_DIR: .reachable-cache
"""

import json
import logging
import os
import sys
import shutil
import subprocess
import time
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional
from dataclasses import dataclass

# Initialize module-level logger
logger = logging.getLogger(__name__)

# Version marker for cache invalidation
# Bump this when GuardDog dependencies change significantly
# v1.1.0: Fixed parsing for GuardDog 2.x JSON format (int vs list for findings)
GUARDDOG_CACHE_VERSION = "1.1.0"

# Cache refresh interval (seconds) - default 7 days
# Set GUARDDOG_CACHE_TTL=0 to disable TTL-based refresh
GUARDDOG_CACHE_TTL = int(os.environ.get('GUARDDOG_CACHE_TTL', 7 * 24 * 60 * 60))

@dataclass
class MalwareDetection:
    """Malware detection result"""
    package_name: str
    package_version: str
    is_malicious: bool
    risk_level: str  # LOW, MEDIUM, HIGH, CRITICAL
    detections: List[Dict]
    confidence: str  # LOW, MEDIUM, HIGH

class GuardDogScanner:
    """GuardDog integration for malware detection"""
    
    # Enterprise configurable error threshold
    # Set via GUARDDOG_ERROR_LIMIT env var or constructor
    DEFAULT_ERROR_LIMIT = 10
    
    def __init__(self, cache_dir: Optional[Path] = None, error_limit: Optional[int] = None):
        """
        Initialize GuardDog scanner
        
        Args:
            cache_dir: Directory to cache scan results (per-package)
            error_limit: Max errors to show before suppressing (default: 10, enterprise: set higher or -1 for unlimited)
        
        Environment Variables:
            REACHABLE_CACHE_DIR: Base directory for all caches (venv, results)
                                 Useful for CI/CD caching. Default: ~/.reachable-cache
            GUARDDOG_ERROR_LIMIT: Max errors to display
        """
        self.cache_dir = Path(cache_dir) if cache_dir else None
        if self.cache_dir:
            self.cache_dir.mkdir(parents=True, exist_ok=True)
        
        # Cache statistics for performance monitoring
        self.cache_hits = 0
        self.cache_misses = 0
        
        # Error limit: -1 = unlimited, 0 = suppress all, N = show first N
        env_limit = os.environ.get('GUARDDOG_ERROR_LIMIT')
        if error_limit is not None:
            self.error_limit = error_limit
        elif env_limit is not None:
            try:
                self.error_limit = int(env_limit)
            except ValueError:
                self.error_limit = self.DEFAULT_ERROR_LIMIT
        else:
            self.error_limit = self.DEFAULT_ERROR_LIMIT
        
        # GuardDog isolated venv - respect REACHABLE_CACHE_DIR for CI/CD
        # Consolidated path: ~/.reachable/cache/guarddog-venv (v4.5.40)
        cache_base = os.environ.get('REACHABLE_CACHE_DIR')
        if cache_base:
            self.guarddog_venv = Path(cache_base).expanduser() / 'guarddog-venv'
        else:
            self.guarddog_venv = Path.home() / '.reachable' / 'cache' / 'guarddog-venv'
        
        self._available = None  # Will check/setup on first use
    
    def _sanitize_package_name(self, package_name: str) -> str:
        """
        Sanitize package name for use in filenames
        
        Handles scoped packages like @babel/code-frame:
        - Replaces / with -
        - Replaces @ with at-
        - Replaces other unsafe chars
        
        Examples:
            @babel/code-frame → at-babel-code-frame
            ../nexee-api-specs → ..-nexee-api-specs
            actions/checkout → actions-checkout
        """
        sanitized = package_name
        sanitized = sanitized.replace('@', 'at-')
        sanitized = sanitized.replace('/', '-')
        sanitized = sanitized.replace('\\', '-')
        sanitized = sanitized.replace(':', '-')
        sanitized = sanitized.replace(' ', '_')
        return sanitized
    
    def _get_venv_paths(self):
        """Get platform-specific venv paths"""
        import platform
        
        if platform.system() == 'Windows':
            bin_dir = self.guarddog_venv / 'Scripts'
            python_exe = bin_dir / 'python.exe'
            pip_exe = bin_dir / 'pip.exe'
            guarddog_exe = bin_dir / 'guarddog.exe'
        else:
            bin_dir = self.guarddog_venv / 'bin'
            python_exe = bin_dir / 'python3'
            pip_exe = bin_dir / 'pip'
            guarddog_exe = bin_dir / 'guarddog'
        
        return {
            'bin_dir': bin_dir,
            'python': python_exe,
            'pip': pip_exe,
            'guarddog': guarddog_exe
        }
    
    def _setup_guarddog_venv(self) -> bool:
        """
        Set up GuardDog environment using centralized setup module.
        
        Delegates to guarddog_setup.setup_guarddog() which handles:
        - System dependencies (libgit2)
        - Venv creation
        - Guarddog installation
        - Cache versioning
        """
        try:
            from reachable.guarddog_setup import setup_guarddog
            return setup_guarddog(venv_dir=self.guarddog_venv, verbose=True)
        except Exception as e:
            logger.info(f"   ⚠️  GuardDog setup failed: {e}")
            return False
    
    def _check_guarddog_available(self) -> bool:
        """Check/setup GuardDog on-demand"""
        if self._available is None:
            # First time check - try to setup if needed
            self._available = self._setup_guarddog_venv()
        return self._available
    
    def is_available(self) -> bool:
        """Check if GuardDog is available"""
        return self._check_guarddog_available()
    
    def _detect_ecosystem(self, package_name: str) -> str:
        """
        Auto-detect package ecosystem from name patterns
        
        NPM packages often have:
        - Scoped names (@babel/core)
        - Kebab-case (lodash-es)
        
        PyPI packages often have:
        - Underscores (urllib3)
        - Hyphens (requests-mock)
        
        Args:
            package_name: Package name
            
        Returns:
            'npm' or 'pypi'
        """
        # Scoped packages are always NPM
        if package_name.startswith('@'):
            return 'npm'
        
        # Common NPM-only packages
        npm_packages = {
            'react', 'vue', 'angular', 'next', 'express', 'webpack',
            'lodash', 'axios', 'chalk', 'commander', 'semver', 'debug',
            'typescript', 'eslint', 'prettier', 'jest', 'mocha', 'babel'
        }
        base_name = package_name.split('/')[1] if '/' in package_name else package_name
        base_name = base_name.split('-')[0] if '-' in base_name else base_name
        
        if base_name.lower() in npm_packages:
            return 'npm'
        
        # Common PyPI-only packages
        pypi_packages = {
            'django', 'flask', 'pandas', 'numpy', 'scipy', 'requests',
            'urllib3', 'boto3', 'pytest', 'pillow', 'sqlalchemy'
        }
        base_name = package_name.replace('-', '_').split('_')[0]
        
        if base_name.lower() in pypi_packages:
            return 'pypi'
        
        # Default: check SBOM if available, otherwise assume npm
        # (npm is more common in modern web apps)
        return 'npm'
    
    def scan_local_directory(self, package_dir: Path, ecosystem: str = 'npm') -> Optional[MalwareDetection]:
        """
        Scan a locally cloned package directory with multi-tier detection
        
        DETECTION TIERS:
        1. GuardDog: Metadata + Semgrep patterns
        2. YARA: Byte-level signatures (fast)
        3. Deep Scanner: Entropy + AST (slow, confirms encryption)
        
        This is MORE accurate than remote scanning because:
        1. GuardDog can analyze actual code, not just metadata
        2. YARA finds byte patterns that evade AST
        3. Deep scanner confirms encrypted payloads
        
        Args:
            package_dir: Path to package directory
            ecosystem: 'npm' or 'pypi'
            
        Returns:
            Combined multi-tier detection results
        """
        if not self._available:
            return None
        
        try:
            # TIER 1: GuardDog scan
            paths = self._get_venv_paths()
            guarddog_cmd = str(paths['guarddog'])
            
            result = subprocess.run(
                [guarddog_cmd, ecosystem, 'scan', str(package_dir), '--output-format', 'json'],
                capture_output=True,
                text=True,
                timeout=60
            )
            
            # Parse GuardDog results (supports both old and new 2.x format)
            guarddog_detections = []
            guarddog_is_malicious = False
            guarddog_risk = 'LOW'
            
            if result.stdout and result.stdout.strip():
                try:
                    data = json.loads(result.stdout)
                    
                    # Handle old format with 'issues' key
                    if 'issues' in data and isinstance(data['issues'], list):
                        guarddog_detections = data['issues']
                    else:
                        # New GuardDog 2.x format: package names as top-level keys
                        for pkg_key, rules in data.items():
                            if not isinstance(rules, dict):
                                continue
                            for rule_name, findings in rules.items():
                                # CRITICAL FIX: Skip integers (0 = no findings)
                                if isinstance(findings, int):
                                    continue
                                if not isinstance(findings, list):
                                    continue
                                for finding in findings:
                                    if isinstance(finding, dict):
                                        finding['rule_id'] = rule_name  # Add rule name for risk calc
                                        guarddog_detections.append(finding)
                    
                    guarddog_is_malicious = len(guarddog_detections) > 0
                    guarddog_risk = self._calculate_risk_from_issues(guarddog_detections)
                except (json.JSONDecodeError, ValueError):
                    pass
            
            # TIER 2: YARA byte-level scan (fast, catches obfuscated patterns)
            yara_detections = []
            try:
                from reachable.yara_scanner import YaraScanner
                yara = YaraScanner()
                if yara.is_available():
                    yara_results = yara.scan_directory(package_dir)
                    if yara_results:
                        summary = yara.get_summary(yara_results)
                        
                        # Convert YARA matches to detections
                        for file_path, matches in yara_results.items():
                            for match in matches:
                                yara_detections.append({
                                    'type': 'yara_signature',
                                    'rule': match.rule_name,
                                    'severity': match.severity,
                                    'file': file_path,
                                    'description': match.meta.get('description', '')
                                })
                        
                        # Escalate if YARA found critical patterns
                        if summary['severity']['critical'] > 0:
                            guarddog_risk = 'CRITICAL'
                            guarddog_is_malicious = True
            except ImportError:
                pass  # YARA not available
            
            # TIER 3: Deep scanner (runs on suspicious packages)
            deep_detections = []
            has_obfuscation = any('obfuscation' in str(d).lower() for d in guarddog_detections)
            has_encryption_sig = any('Encryption' in d.get('rule', '') for d in yara_detections)
            has_suspicious_patterns = guarddog_is_malicious or len(yara_detections) > 0
            
            # Run Tier 3 if ANY suspicious indicators (more aggressive)
            if has_suspicious_patterns or has_obfuscation or has_encryption_sig:
                try:
                    from reachable.deep_malware_scanner import analyze_package_directory
                    deep_results = analyze_package_directory(package_dir, verbose=False)
                    
                    # Escalate if deep scanner confirms encryption
                    critical_files = [r for r in deep_results.values() if r.verdict == 'CRITICAL']
                    if critical_files:
                        guarddog_risk = 'CRITICAL'
                        guarddog_is_malicious = True
                        deep_detections = [{
                            'type': 'encrypted_payload_confirmed',
                            'severity': 'CRITICAL',
                            'description': f'Encrypted malware confirmed by deep scan: {len(critical_files)} files',
                            'evidence': {
                                'entropy_spikes': len([r for r in critical_files if r.has_high_entropy]),
                                'unpacker_patterns': len([r for r in critical_files if r.has_unpacker_logic]),
                                'files': [r.file_path for r in critical_files[:3]]  # First 3
                            }
                        }]
                except ImportError:
                    pass  # Deep scanner not available
            
            # Combine all detections
            all_detections = guarddog_detections + yara_detections + deep_detections
            
            package_name = package_dir.name
            
            return MalwareDetection(
                package_name=package_name,
                package_version='local',
                is_malicious=guarddog_is_malicious,
                risk_level=guarddog_risk,
                detections=all_detections,
                confidence='HIGH' if deep_detections else 'MEDIUM'
            )
            
        except Exception as e:
            return None
    
    def _calculate_risk_from_issues(self, issues: List[Dict]) -> str:
        """Calculate risk level from GuardDog issues"""
        if not issues:
            return 'LOW'
        
        # Check for critical patterns
        critical_patterns = ['exec-base64', 'shady-links', 'install-script']
        high_patterns = ['obfuscation', 'serialize-environment']
        
        for issue in issues:
            rule_id = issue.get('rule_id', '').lower()
            if any(p in rule_id for p in critical_patterns):
                return 'CRITICAL'
        
        for issue in issues:
            rule_id = issue.get('rule_id', '').lower()
            if any(p in rule_id for p in high_patterns):
                return 'HIGH'
        
        return 'MEDIUM'
    
    def scan_package(self, package_name: str, package_version: str, ecosystem: str = None) -> Optional[MalwareDetection]:
        """
        Scan a package for malware
        
        Args:
            package_name: Name of the package
            package_version: Version of the package
            ecosystem: 'pypi', 'npm', or None (auto-detect)
            
        Returns:
            MalwareDetection result or None if scan failed
        """
        if not self._available:
            return None
        
        # Auto-detect ecosystem if not specified
        if ecosystem is None:
            ecosystem = self._detect_ecosystem(package_name)
        
        # Check cache
        if self.cache_dir:
            safe_name = self._sanitize_package_name(package_name)
            cache_file = self.cache_dir / f"guarddog_{ecosystem}_{safe_name}_{package_version}.json"
            if cache_file.exists():
                try:
                    with open(cache_file) as f:
                        cached = json.load(f)
                        self.cache_hits += 1  # Track cache hit
                        return MalwareDetection(**cached)
                except:
                    pass
        
        # Cache miss - will scan
        self.cache_misses += 1
        
        try:
            # Use guarddog from isolated venv
            paths = self._get_venv_paths()
            guarddog_cmd = str(paths['guarddog'])
            
            # Run GuardDog scan with ecosystem
            # Format: guarddog {pypi|npm} scan <package>
            package_spec = f"{package_name}@{package_version}" if ecosystem == 'npm' else f"{package_name}=={package_version}"
            
            result = subprocess.run(
                [guarddog_cmd, ecosystem, 'scan', package_spec, '--output-format', 'json'],
                capture_output=True,
                text=True,
                timeout=30
            )
            
            # Parse GuardDog JSON output
            # GuardDog 2.x format:
            # {
            #   "package==version": {
            #     "rule_name": [findings...] or 0 (integer when no findings)
            #   }
            # }
            try:
                guarddog_data = json.loads(result.stdout) if result.stdout.strip() else {}
            except (json.JSONDecodeError, ValueError):
                guarddog_data = {}
            
            # Extract detections from new GuardDog 2.x format
            detections = []
            risk_level = 'LOW'
            
            # Handle both old format (with 'issues' key) and new format (package as key)
            if guarddog_data:
                # Check for old format first
                if 'issues' in guarddog_data and isinstance(guarddog_data['issues'], list):
                    for issue in guarddog_data['issues']:
                        if not isinstance(issue, dict):
                            continue
                        severity = str(issue.get('severity', 'LOW')).upper()
                        detections.append({
                            'rule': issue.get('rule', 'unknown'),
                            'description': issue.get('description', ''),
                            'severity': severity,
                            'location': issue.get('location', ''),
                        })
                else:
                    # New GuardDog 2.x format: package names as top-level keys
                    for pkg_key, rules in guarddog_data.items():
                        # Skip non-dict entries (like 'errors', 'dependency_results')
                        if not isinstance(rules, dict):
                            continue
                        
                        for rule_name, findings in rules.items():
                            # CRITICAL FIX: GuardDog returns 0 (int) when no findings
                            # instead of an empty list. Skip integers.
                            if isinstance(findings, int):
                                continue
                            if not isinstance(findings, list):
                                continue
                            
                            for finding in findings:
                                if not isinstance(finding, dict):
                                    continue
                                severity = str(finding.get('severity', 'WARNING')).upper()
                                # Map GuardDog severities to our levels
                                if severity in ('ERROR', 'CRITICAL'):
                                    severity = 'CRITICAL'
                                elif severity in ('WARNING', 'HIGH'):
                                    severity = 'HIGH'
                                elif severity == 'INFO':
                                    severity = 'LOW'
                                else:
                                    severity = 'MEDIUM'
                                
                                detections.append({
                                    'rule': rule_name,
                                    'description': finding.get('message', finding.get('description', '')),
                                    'severity': severity,
                                    'location': finding.get('location', ''),
                                    'code': finding.get('code', ''),
                                })
            
            # Determine highest risk level from detections
            for det in detections:
                sev = det.get('severity', 'LOW')
                if sev == 'CRITICAL':
                    risk_level = 'CRITICAL'
                    break
                elif sev == 'HIGH' and risk_level not in ('CRITICAL',):
                    risk_level = 'HIGH'
                elif sev == 'MEDIUM' and risk_level not in ('CRITICAL', 'HIGH'):
                    risk_level = 'MEDIUM'
            
            detection = MalwareDetection(
                package_name=package_name,
                package_version=package_version,
                is_malicious=len(detections) > 0,
                risk_level=risk_level,
                detections=detections,
                confidence='HIGH' if len(detections) > 2 else 'MEDIUM'
            )
            
            # Cache result
            if self.cache_dir:
                safe_name = self._sanitize_package_name(package_name)
                cache_file = self.cache_dir / f"guarddog_{ecosystem}_{safe_name}_{package_version}.json"
                with open(cache_file, 'w') as f:
                    json.dump({
                        'package_name': detection.package_name,
                        'package_version': detection.package_version,
                        'is_malicious': detection.is_malicious,
                        'risk_level': detection.risk_level,
                        'detections': detection.detections,
                        'confidence': detection.confidence
                    }, f, indent=2)
            
            return detection
            
        except subprocess.TimeoutExpired:
            logger.info(f"   ⚠️  GuardDog scan timeout for {package_name}")
            return None
        except Exception as e:
            logger.info(f"   ⚠️  GuardDog scan failed for {package_name}: {e}")
            return None
    
    def scan_packages_from_sbom(self, sbom_file: Path) -> Dict[str, MalwareDetection]:
        """
        Scan all packages from SBOM
        
        Args:
            sbom_file: Path to SBOM JSON file (supports .json and .json.gz)
            
        Returns:
            Dict mapping package name → MalwareDetection
        """
        import gzip
        
        if not self._available:
            return {}
        
        results = {}
        
        try:
            # Handle both compressed and uncompressed SBOM files
            sbom_path = Path(sbom_file)
            
            # Try .json.gz first if .json doesn't exist
            if not sbom_path.exists() and sbom_path.with_suffix('.json.gz').exists():
                sbom_path = sbom_path.with_suffix('.json.gz')
            elif not sbom_path.exists() and str(sbom_path).endswith('.json'):
                gz_path = Path(str(sbom_path) + '.gz')
                if gz_path.exists():
                    sbom_path = gz_path
            
            if str(sbom_path).endswith('.gz'):
                with gzip.open(sbom_path, 'rt', encoding='utf-8') as f:
                    sbom = json.load(f)
            else:
                with open(sbom_path) as f:
                    sbom = json.load(f)
            
            packages = sbom.get('artifacts', [])
            total_packages = len(packages)
            
            # Track skipped packages by ecosystem (v2.9.61)
            skipped_by_ecosystem = {}  # ecosystem -> list of package names
            supported_ecosystems = {'npm', 'pypi', 'pip'}
            
            # Pre-filter packages by ecosystem to avoid unnecessary scan attempts
            scannable_packages = []
            for artifact in packages:
                name = artifact.get('name', '')
                version = artifact.get('version', '')
                pkg_type = artifact.get('type', '').lower()
                purl = artifact.get('purl', '')
                
                # Detect ecosystem from SBOM data
                ecosystem = None
                if pkg_type in supported_ecosystems:
                    ecosystem = 'npm' if pkg_type == 'npm' else 'pypi'
                elif 'npm' in purl or pkg_type == 'npm':
                    ecosystem = 'npm'
                elif 'pypi' in purl or pkg_type in ('pip', 'pypi', 'python'):
                    ecosystem = 'pypi'
                elif 'golang' in purl or pkg_type in ('go', 'golang', 'go-module'):
                    ecosystem = 'go'
                elif 'maven' in purl or pkg_type in ('java', 'maven', 'gradle'):
                    ecosystem = 'java'
                elif 'cargo' in purl or pkg_type == 'rust':
                    ecosystem = 'rust'
                else:
                    # Try auto-detection from name
                    ecosystem = self._detect_ecosystem(name)
                
                if ecosystem in supported_ecosystems or ecosystem in ('npm', 'pypi'):
                    scannable_packages.append((name, version, ecosystem if ecosystem != 'pip' else 'pypi'))
                else:
                    # Track skipped package
                    skip_reason = ecosystem or 'unknown'
                    if skip_reason not in skipped_by_ecosystem:
                        skipped_by_ecosystem[skip_reason] = []
                    skipped_by_ecosystem[skip_reason].append(name)
            
            scannable_count = len(scannable_packages)
            skipped_count = total_packages - scannable_count
            
            if packages:
                logger.info(f"   🔍 GuardDog scanning {scannable_count} packages (npm/pip)...")
                if skipped_count > 0:
                    skip_details = ', '.join([f"{eco}: {len(pkgs)}" for eco, pkgs in sorted(skipped_by_ecosystem.items())])
                    logger.info(f"      ⏭️  Skipped {skipped_count} unsupported packages ({skip_details})")
            
            scanned = 0
            errors = 0
            error_types = {}  # Track error categories for enterprise summary
            max_errors_shown = self.error_limit  # Configurable: -1 = unlimited
            
            for name, version, ecosystem in scannable_packages:
                try:
                    detection = self.scan_package(name, version, ecosystem)
                    if detection:
                        results[name] = detection
                        
                        if detection.is_malicious:
                            logger.info(f"   🚨 MALWARE DETECTED: {name} {version} ({detection.risk_level})")
                except Exception as e:
                    errors += 1
                    # Categorize error for enterprise summary
                    error_str = str(e).lower()
                    if 'timeout' in error_str:
                        error_cat = 'timeout'
                    elif 'network' in error_str or 'connection' in error_str or 'socket' in error_str:
                        error_cat = 'network'
                    elif 'not found' in error_str or '404' in error_str or 'no such' in error_str:
                        error_cat = 'not_found'
                    elif 'permission' in error_str or 'access denied' in error_str:
                        error_cat = 'permission'
                    elif 'rate limit' in error_str or '429' in error_str:
                        error_cat = 'rate_limit'
                    else:
                        error_cat = 'other'
                    error_types[error_cat] = error_types.get(error_cat, 0) + 1
                    
                    # Show errors based on configurable limit (-1 = show all)
                    if max_errors_shown == -1 or errors <= max_errors_shown:
                        logger.info(f"   ⚠️  GuardDog scan failed for {name}: {e}")
                    elif max_errors_shown > 0 and errors == max_errors_shown + 1:
                        logger.info(f"   ⚠️  ... suppressing further error messages (will show summary)")
                        logger.info(f"      💡 Set GUARDDOG_ERROR_LIMIT=-1 to see all errors")
                
                scanned += 1
                # Show progress every 100 packages or at end, with cache stats
                if scanned % 100 == 0 or scanned == scannable_count:
                    cache_str = f" [cache: {self.cache_hits} hits]" if self.cache_hits > 0 else ""
                    print(f"      Progress: [{scanned}/{scannable_count}] packages scanned...{cache_str}", end='\r' if scanned < scannable_count else '\n')
            
            clean_count = sum(1 for d in results.values() if not d.is_malicious)
            malicious_count = sum(1 for d in results.values() if d.is_malicious)
            
            if results:
                logger.info(f"   ✓ GuardDog scan complete: {clean_count} clean, {malicious_count} malicious")
                # Show cache statistics for performance monitoring
                if self.cache_hits > 0 or self.cache_misses > 0:
                    total_scans = self.cache_hits + self.cache_misses
                    cache_pct = (self.cache_hits / total_scans * 100) if total_scans > 0 else 0
                    logger.info(f"   💾 Cache: {self.cache_hits} hits, {self.cache_misses} scanned ({cache_pct:.1f}% from cache)")
            
            # Show error summary if many errors occurred (enterprise visibility)
            if max_errors_shown != -1 and errors > max_errors_shown:
                logger.info(f"   ⚠️  Total scan errors: {errors}/{total_packages} packages failed")
                if error_types:
                    error_summary = [f"{cat}: {cnt}" for cat, cnt in sorted(error_types.items(), key=lambda x: -x[1])]
                    logger.info(f"      Error breakdown: {', '.join(error_summary)}")
                    # Provide actionable guidance
                    if error_types.get('rate_limit', 0) > 5:
                        logger.info(f"      💡 Tip: Rate limiting detected - try running with fewer workers or add delays")
                    if error_types.get('network', 0) > 10:
                        logger.info(f"      💡 Tip: Network issues detected - check connectivity and firewall rules")
                    if error_types.get('not_found', 0) > 20:
                        logger.info(f"      💡 Tip: Many packages not found - these may be private/internal packages")
            
            return results
            
        except Exception as e:
            logger.info(f"   ⚠️  GuardDog SBOM scan failed: {e}")
            return {}

if __name__ == '__main__':
    # Test GuardDog scanner
    scanner = GuardDogScanner()
    
    if scanner.is_available():
        logger.info("✓ GuardDog is available")
        
        # Test with a known clean package
        result = scanner.scan_package('requests', '2.31.0')
        if result:
            logger.info(f"\nTest scan result:")
            logger.info(f"  Package: {result.package_name} {result.package_version}")
            logger.info(f"  Malicious: {result.is_malicious}")
            logger.info(f"  Risk: {result.risk_level}")
    else:
        logger.info("❌ GuardDog not available")
        logger.info("   Install with: pip install guarddog")
