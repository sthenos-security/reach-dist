#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.

"""
YARA Rules Manager - Commercial-Safe Rule Sources with Caching

Downloads, caches, and manages YARA rules from ONLY commercial-safe sources:
- ReversingLabs (MIT License) - Zero false positive guarantee
- MalwareBazaar (CC0 Public Domain) - Fresh malware signatures

EXCLUDED from commercial builds (license restrictions):
- Neo23x0/signature-base (CC BY-NC 4.0 - Non-Commercial only)
- Yara-Rules/rules (GPL-2.0 - Copyleft)
- bartblaze/Yara-rules (GPL-3.0 - Copyleft)

Caching Strategy:
- Rules cached to ~/.reachable/yara-rules/
- ReversingLabs: 7-day TTL (quarterly updates)
- MalwareBazaar: 24-hour TTL (daily updates)
- ETag/Last-Modified checking for efficient updates
- Fallback to cached version if download fails
"""

import json
import hashlib
import logging
import zipfile
import shutil
import time
import re
from pathlib import Path
from datetime import datetime, timedelta
from dataclasses import dataclass
from typing import Dict, List, Optional, Any
from urllib.request import urlopen, Request
from urllib.error import URLError, HTTPError

logger = logging.getLogger(__name__)

# ═══════════════════════════════════════════════════════════════════════════════
# CONFIGURATION
# ═══════════════════════════════════════════════════════════════════════════════

CACHE_DIR = Path.home() / '.reachable' / 'yara-rules'
CACHE_METADATA_FILE = CACHE_DIR / 'cache_metadata.json'

# Commercial-safe sources ONLY
RULE_SOURCES = {
    "reversinglabs": {
        "name": "ReversingLabs YARA Rules",
        "url": "https://github.com/reversinglabs/reversinglabs-yara-rules/archive/refs/heads/main.zip",
        "license": "MIT",
        "commercial_use": True,
        "description": "High-quality rules with zero false positive guarantee",
        "rule_count_estimate": 500,
        "ttl_hours": 168,  # 7 days
        "extract_subdir": "reversinglabs-yara-rules-main/yara",
    },
    "malwarebazaar": {
        "name": "MalwareBazaar YARA Rules", 
        "url": "https://bazaar.abuse.ch/export/yara/full/",
        "license": "CC0",
        "commercial_use": True,
        "description": "Fresh signatures from submitted malware samples",
        "rule_count_estimate": 5000,
        "ttl_hours": 24,  # 1 day
        "extract_subdir": None,
        "filename": "malwarebazaar_full.yar",
    },
}

@dataclass
class CacheEntry:
    """Metadata for a cached rule source."""
    source_id: str
    downloaded_at: str
    etag: Optional[str] = None
    last_modified: Optional[str] = None
    content_hash: Optional[str] = None
    rule_count: int = 0
    file_size_bytes: int = 0
    ttl_hours: int = 24
    
    @property
    def is_expired(self) -> bool:
        try:
            downloaded = datetime.fromisoformat(self.downloaded_at.replace('Z', '+00:00'))
            expiry = downloaded + timedelta(hours=self.ttl_hours)
            return datetime.now(downloaded.tzinfo) > expiry
        except Exception:
            return True
    
    @property
    def age_hours(self) -> float:
        try:
            downloaded = datetime.fromisoformat(self.downloaded_at.replace('Z', '+00:00'))
            delta = datetime.now(downloaded.tzinfo) - downloaded
            return delta.total_seconds() / 3600
        except Exception:
            return float('inf')

class CacheMetadata:
    """Manages cache metadata for all rule sources."""
    
    def __init__(self):
        self.entries: Dict[str, CacheEntry] = {}
        self._load()
    
    def _load(self):
        if CACHE_METADATA_FILE.exists():
            try:
                with open(CACHE_METADATA_FILE, 'r') as f:
                    data = json.load(f)
                for source_id, entry_data in data.get('entries', {}).items():
                    self.entries[source_id] = CacheEntry(**entry_data)
            except Exception as e:
                logger.warning(f"Failed to load cache metadata: {e}")
    
    def _save(self):
        CACHE_DIR.mkdir(parents=True, exist_ok=True)
        try:
            data = {
                'version': '1.0',
                'updated_at': datetime.utcnow().isoformat() + 'Z',
                'entries': {
                    source_id: {
                        'source_id': entry.source_id,
                        'downloaded_at': entry.downloaded_at,
                        'etag': entry.etag,
                        'last_modified': entry.last_modified,
                        'content_hash': entry.content_hash,
                        'rule_count': entry.rule_count,
                        'file_size_bytes': entry.file_size_bytes,
                        'ttl_hours': entry.ttl_hours,
                    }
                    for source_id, entry in self.entries.items()
                }
            }
            with open(CACHE_METADATA_FILE, 'w') as f:
                json.dump(data, f, indent=2)
        except Exception as e:
            logger.warning(f"Failed to save cache metadata: {e}")
    
    def get(self, source_id: str) -> Optional[CacheEntry]:
        return self.entries.get(source_id)
    
    def update(self, entry: CacheEntry):
        self.entries[entry.source_id] = entry
        self._save()
    
    def get_summary(self) -> Dict[str, Any]:
        total_rules = sum(e.rule_count for e in self.entries.values())
        total_size = sum(e.file_size_bytes for e in self.entries.values())
        return {
            'sources_cached': len(self.entries),
            'total_rules': total_rules,
            'total_size_mb': round(total_size / (1024 * 1024), 2),
            'sources': {
                source_id: {
                    'rule_count': entry.rule_count,
                    'age_hours': round(entry.age_hours, 1),
                    'expired': entry.is_expired,
                    'size_kb': round(entry.file_size_bytes / 1024, 1),
                }
                for source_id, entry in self.entries.items()
            }
        }

class YaraRulesManager:
    """Manages downloading, caching, and loading of YARA rules."""
    
    def __init__(self, cache_dir: Optional[Path] = None):
        self.cache_dir = cache_dir or CACHE_DIR
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        self.metadata = CacheMetadata()
        self._compiled_rules: Dict[str, List[Dict]] = {}
    
    def get_cache_status(self) -> Dict[str, Any]:
        """Get status of cached rules."""
        summary = self.metadata.get_summary()
        for source_id, source_info in RULE_SOURCES.items():
            if source_id in summary['sources']:
                summary['sources'][source_id]['name'] = source_info['name']
                summary['sources'][source_id]['license'] = source_info['license']
            else:
                summary['sources'][source_id] = {
                    'name': source_info['name'],
                    'license': source_info['license'],
                    'cached': False,
                    'rule_count': 0,
                }
        return summary
    
    def update_rules(self, force: bool = False, sources: Optional[List[str]] = None) -> Dict[str, Any]:
        """Update YARA rules from configured sources."""
        results = {}
        sources_to_update = sources or list(RULE_SOURCES.keys())
        
        for source_id in sources_to_update:
            if source_id not in RULE_SOURCES:
                results[source_id] = {'status': 'error', 'message': f'Unknown source: {source_id}'}
                continue
            
            source = RULE_SOURCES[source_id]
            cache_entry = self.metadata.get(source_id)
            
            # Check if update needed
            if not force and cache_entry and not cache_entry.is_expired:
                results[source_id] = {
                    'status': 'cached',
                    'message': f'Cache fresh ({cache_entry.age_hours:.1f}h old, TTL {cache_entry.ttl_hours}h)',
                    'rule_count': cache_entry.rule_count,
                }
                continue
            
            try:
                result = self._download_source(source_id, source, cache_entry)
                results[source_id] = result
            except Exception as e:
                logger.error(f"Failed to update {source_id}: {e}")
                results[source_id] = {
                    'status': 'error',
                    'message': str(e),
                    'fallback': cache_entry is not None,
                }
        
        return results
    
    def _download_source(self, source_id: str, source: Dict, existing_entry: Optional[CacheEntry]) -> Dict:
        """Download rules from a single source."""
        url = source['url']
        source_cache_dir = self.cache_dir / source_id
        source_cache_dir.mkdir(parents=True, exist_ok=True)
        
        logger.info(f"      → Downloading {source['name']}...")
        start_time = time.time()
        
        try:
            req = Request(url)
            req.add_header('User-Agent', 'REACHABLE-Security-Scanner/2.9')
            
            if existing_entry:
                if existing_entry.etag:
                    req.add_header('If-None-Match', existing_entry.etag)
                if existing_entry.last_modified:
                    req.add_header('If-Modified-Since', existing_entry.last_modified)
            
            with urlopen(req, timeout=60) as response:
                content = response.read()
                etag = response.headers.get('ETag')
                last_modified = response.headers.get('Last-Modified')
            
            download_time = time.time() - start_time
            content_hash = hashlib.sha256(content).hexdigest()
            
            # Check if content changed
            if existing_entry and existing_entry.content_hash == content_hash:
                existing_entry.downloaded_at = datetime.utcnow().isoformat() + 'Z'
                self.metadata.update(existing_entry)
                return {
                    'status': 'unchanged',
                    'message': 'Content identical (hash match)',
                    'rule_count': existing_entry.rule_count,
                    'download_seconds': round(download_time, 2),
                }
            
            # Process content
            rule_count = 0
            file_size = len(content)
            
            if source.get('extract_subdir'):
                rule_count = self._extract_zip(content, source_cache_dir, source)
            else:
                filename = source.get('filename', f'{source_id}.yar')
                output_path = source_cache_dir / filename
                with open(output_path, 'wb') as f:
                    f.write(content)
                rule_count = self._count_rules_in_file(output_path)
            
            cache_entry = CacheEntry(
                source_id=source_id,
                downloaded_at=datetime.utcnow().isoformat() + 'Z',
                etag=etag,
                last_modified=last_modified,
                content_hash=content_hash,
                rule_count=rule_count,
                file_size_bytes=file_size,
                ttl_hours=source.get('ttl_hours', 24),
            )
            self.metadata.update(cache_entry)
            
            logger.info(f"        ✓ {rule_count} rules downloaded in {download_time:.1f}s")
            
            return {
                'status': 'updated',
                'message': f'Downloaded {rule_count} rules',
                'rule_count': rule_count,
                'size_kb': round(file_size / 1024, 1),
                'download_seconds': round(download_time, 2),
            }
            
        except HTTPError as e:
            if e.code == 304 and existing_entry:
                existing_entry.downloaded_at = datetime.utcnow().isoformat() + 'Z'
                self.metadata.update(existing_entry)
                return {
                    'status': 'not_modified',
                    'message': 'Rules unchanged (304)',
                    'rule_count': existing_entry.rule_count,
                }
            raise
        except URLError as e:
            if existing_entry:
                return {
                    'status': 'offline',
                    'message': f'Network error, using cached: {e.reason}',
                    'rule_count': existing_entry.rule_count,
                    'cache_age_hours': round(existing_entry.age_hours, 1),
                }
            raise
    
    def _extract_zip(self, content: bytes, dest_dir: Path, source: Dict) -> int:
        import io
        for f in dest_dir.glob('*.yar*'):
            f.unlink()
        
        rule_count = 0
        with zipfile.ZipFile(io.BytesIO(content)) as zf:
            extract_subdir = source.get('extract_subdir', '')
            
            for name in zf.namelist():
                if extract_subdir and not name.startswith(extract_subdir):
                    continue
                if not (name.endswith('.yar') or name.endswith('.yara')):
                    continue
                if name.endswith('/'):
                    continue
                
                filename = Path(name).name
                output_path = dest_dir / filename
                
                with zf.open(name) as src, open(output_path, 'wb') as dst:
                    dst.write(src.read())
                
                rule_count += self._count_rules_in_file(output_path)
        
        return rule_count
    
    def _count_rules_in_file(self, filepath: Path) -> int:
        try:
            content = filepath.read_text(encoding='utf-8', errors='ignore')
            return len(re.findall(r'^\s*rule\s+\w+', content, re.MULTILINE))
        except Exception:
            return 0
    
    def get_all_rule_files(self) -> List[Path]:
        rule_files = []
        for source_id in RULE_SOURCES:
            source_dir = self.cache_dir / source_id
            if source_dir.exists():
                rule_files.extend(source_dir.glob('*.yar'))
                rule_files.extend(source_dir.glob('*.yara'))
        return rule_files
    
    def get_compiled_patterns(self) -> Dict[str, List[Dict]]:
        """Get all rules as compiled byte patterns for scanning."""
        if self._compiled_rules:
            return self._compiled_rules
        
        patterns = {}
        
        for source_id in RULE_SOURCES:
            source_patterns = []
            source_dir = self.cache_dir / source_id
            
            if not source_dir.exists():
                continue
            
            for rule_file in list(source_dir.glob('*.yar')) + list(source_dir.glob('*.yara')):
                try:
                    file_patterns = self._parse_yara_file(rule_file, source_id)
                    source_patterns.extend(file_patterns)
                except Exception as e:
                    logger.debug(f"Failed to parse {rule_file}: {e}")
            
            if source_patterns:
                patterns[source_id] = source_patterns
        
        self._compiled_rules = patterns
        return patterns
    
    def _parse_yara_file(self, filepath: Path, source_id: str) -> List[Dict]:
        """Parse YARA file and extract byte patterns."""
        patterns = []
        content = filepath.read_text(encoding='utf-8', errors='ignore')
        
        rule_pattern = re.compile(r'rule\s+(\w+).*?{(.*?)}', re.DOTALL)
        string_pattern = re.compile(
            r'\$\w+\s*=\s*(?:{([^}]+)}|"([^"]+)")',
            re.MULTILINE
        )
        
        for rule_match in rule_pattern.finditer(content):
            rule_name = rule_match.group(1)
            rule_body = rule_match.group(2)
            
            strings_match = re.search(r'strings\s*:(.*?)(?:condition|$)', rule_body, re.DOTALL)
            if not strings_match:
                continue
            
            strings_section = strings_match.group(1)
            
            for str_match in string_pattern.finditer(strings_section):
                hex_str = str_match.group(1)
                regular_str = str_match.group(2)
                
                pattern_bytes = None
                
                if hex_str:
                    try:
                        hex_clean = re.sub(r'[\s\-]', '', hex_str)
                        pattern_bytes = bytes.fromhex(hex_clean)
                    except ValueError:
                        continue
                elif regular_str:
                    pattern_bytes = regular_str.encode('utf-8', errors='ignore')
                
                if pattern_bytes and len(pattern_bytes) >= 4:
                    patterns.append({
                        'id': f"{source_id}.{rule_name}",
                        'pattern': pattern_bytes,
                        'description': f"YARA rule: {rule_name}",
                        'severity': 'HIGH',
                        'category': 'malware',
                        'source': source_id,
                    })
        
        return patterns
    
    def clear_cache(self, sources: Optional[List[str]] = None):
        sources_to_clear = sources or list(RULE_SOURCES.keys())
        for source_id in sources_to_clear:
            source_dir = self.cache_dir / source_id
            if source_dir.exists():
                shutil.rmtree(source_dir)
            if source_id in self.metadata.entries:
                del self.metadata.entries[source_id]
        self.metadata._save()
        self._compiled_rules = {}

# Convenience functions
def get_cached_rules_summary() -> Dict[str, Any]:
    return YaraRulesManager().get_cache_status()

def ensure_rules_updated(max_age_hours: int = 24) -> Dict[str, Any]:
    return YaraRulesManager().update_rules()

def get_yara_patterns() -> Dict[str, List[Dict]]:
    return YaraRulesManager().get_compiled_patterns()

if __name__ == '__main__':
    import sys
    logging.basicConfig(level=logging.INFO)
    
    manager = YaraRulesManager()
    
    if len(sys.argv) > 1:
        cmd = sys.argv[1]
        if cmd == 'status':
            print(json.dumps(manager.get_cache_status(), indent=2))
        elif cmd == 'update':
            print(json.dumps(manager.update_rules(force='--force' in sys.argv), indent=2))
        elif cmd == 'clear':
            manager.clear_cache()
            logger.info("Cache cleared")
    else:
        status = manager.get_cache_status()
        logger.info(f"YARA Rules Cache: {status['total_rules']} rules, {status['total_size_mb']} MB")
