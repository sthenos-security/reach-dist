#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.

"""
REACHABLE Monorepo Orchestrator
Coordinates scanning of multiple projects in a monorepo

Flow:
1. Dispatcher discovers projects and their languages
2. Orchestrator invokes REACHABLE scanner for each language
3. Results aggregated by PROJECT (not language)
4. Generates monorepo-level report
"""

import os
import sys
import json
import subprocess
from datetime import datetime
from pathlib import Path
from typing import List, Dict, Optional
import logging

# Initialize module-level logger
logger = logging.getLogger(__name__)

from .monorepo_dispatcher import MonorepoDispatcher, ProjectUnit, LanguageScanTarget

class MonorepoOrchestrator:
    """
    Orchestrates REACHABLE scans across a monorepo.
    
    Responsibilities:
    1. Discover projects via MonorepoDispatcher
    2. For each project → for each language → invoke REACHABLE
    3. Aggregate results under project namespace
    4. Generate monorepo summary report
    """
    
    def __init__(self, monorepo_root: str, output_dir: str = "monorepo-scan-results"):
        self.monorepo_root = os.path.abspath(monorepo_root)
        self.output_dir = os.path.abspath(output_dir)
        self.dispatcher = MonorepoDispatcher()
        
        # Create output directory structure
        os.makedirs(self.output_dir, exist_ok=True)
    
    def _generate_sbom(self, project: ProjectUnit, lang_target: LanguageScanTarget) -> Optional[str]:
        """
        Generate SBOM for a specific language in a project.
        
        Returns path to SBOM file, or None if generation failed.
        """
        project_output = os.path.join(
            self.output_dir,
            project.project_name,
            lang_target.language
        )
        os.makedirs(project_output, exist_ok=True)
        
        sbom_path = os.path.join(project_output, "sbom.json")
        
        # Determine what to scan based on language
        if lang_target.language == "python":
            # Scan requirements.txt, pyproject.toml, or setup.py
            manifest = os.path.join(project.path, lang_target.anchor_file)
            cmd = ["syft", "scan", f"file:{manifest}", "-o", "json", "--by-cve", "-q"]
        
        elif lang_target.language == "js_ts":
            # Scan package.json
            cmd = ["syft", "scan", f"dir:{project.path}", "-o", "json", "--by-cve", "-q"]
        
        elif lang_target.language == "go":
            # Scan go.mod
            cmd = ["syft", "scan", f"dir:{project.path}", "-o", "json", "--by-cve", "-q"]
        
        elif lang_target.is_hermetic:
            # Bazel requires special handling
            logger.info(f"   ⚠️  Bazel projects require hermetic scanning (not yet implemented)")
            return None
        
        else:
            # Generic: scan the directory
            cmd = ["syft", "scan", f"dir:{project.path}", "-o", "json", "--by-cve", "-q"]
        
        try:
            with open(sbom_path, 'w') as f:
                result = subprocess.run(cmd, stdout=f, stderr=subprocess.PIPE, 
                                      cwd=project.path, timeout=300)
            
            if result.returncode == 0:
                return sbom_path
            else:
                logger.info(f"   ⚠️  Syft failed: {result.stderr.decode()[:200]}")
                return None
                
        except Exception as e:
            logger.info(f"   ⚠️  SBOM generation failed: {e}")
            return None
    
    def _scan_vulnerabilities(self, sbom_path: str, project: ProjectUnit, 
                             lang_target: LanguageScanTarget) -> Optional[str]:
        """
        Scan SBOM for vulnerabilities using Grype.
        
        Returns path to vulnerabilities JSON, or None if scan failed.
        """
        from .vulndb import get_grype_env  # Use shared cache at ~/.reachable/cache/grype-db/
        
        project_output = os.path.join(
            self.output_dir,
            project.project_name,
            lang_target.language
        )
        vulns_path = os.path.join(project_output, "vulns.json")
        
        cmd = ["grype", f"sbom:{sbom_path}", "-o", "json", "--by-cve", "-q"]
        
        try:
            with open(vulns_path, 'w') as f:
                result = subprocess.run(
                    cmd, 
                    stdout=f, 
                    stderr=subprocess.PIPE, 
                    timeout=300,
                    env=get_grype_env()  # BUG FIX: Use shared cache instead of /tmp
                )
            
            if result.returncode == 0:
                return vulns_path
            else:
                logger.info(f"   ⚠️  Grype failed: {result.stderr.decode()[:200]}")
                return None
                
        except Exception as e:
            logger.info(f"   ⚠️  Vulnerability scan failed: {e}")
            return None
    
    def _run_reachable_scan(self, project: ProjectUnit, lang_target: LanguageScanTarget,
                           sbom_path: str, vulns_path: str) -> Optional[str]:
        """
        Run REACHABLE analysis on a project language.
        
        This calls the main reachable.py scanner.
        
        Returns path to REACHABLE report, or None if scan failed.
        """
        project_output = os.path.join(
            self.output_dir,
            project.project_name,
            lang_target.language
        )
        report_path = os.path.join(project_output, "reachable-report.json")
        
        # Build command to invoke REACHABLE scanner
        cmd = [
            sys.executable,  # Use same Python interpreter
            "-m", "reachable.reachable",
            "scan",
            project.path,
            "--sbom", sbom_path,
            "--vulns", vulns_path,
            "--output", report_path
        ]
        
        try:
            result = subprocess.run(cmd, capture_output=True, timeout=600, 
                                  cwd=self.monorepo_root)
            
            if result.returncode == 0 and os.path.exists(report_path):
                return report_path
            else:
                logger.info(f"   ⚠️  REACHABLE scan failed:")
                logger.info(f"      stdout: {result.stdout.decode()[:300]}")
                logger.info(f"      stderr: {result.stderr.decode()[:300]}")
                return None
                
        except Exception as e:
            logger.info(f"   ⚠️  REACHABLE execution failed: {e}")
            return None
    
    def _scan_project_language(self, project: ProjectUnit, 
                              lang: str, lang_target: LanguageScanTarget) -> bool:
        """
        Complete scan workflow for ONE language within a project.
        
        Steps:
        1. Generate SBOM
        2. Scan vulnerabilities (Grype)
        3. Run REACHABLE analysis
        4. Update lang_target with results
        
        Returns True if scan succeeded, False otherwise.
        """
        logger.info(f"\n   Scanning {lang.upper()} in {project.project_name}...")
        lang_target.scan_status = "running"
        
        # Step 1: Generate SBOM
        logger.info(f"      [1/3] Generating SBOM...")
        sbom_path = self._generate_sbom(project, lang_target)
        if not sbom_path:
            lang_target.scan_status = "failed"
            lang_target.error_message = "SBOM generation failed"
            return False
        lang_target.sbom_path = sbom_path
        
        # Step 2: Scan vulnerabilities
        logger.info(f"      [2/3] Scanning vulnerabilities...")
        vulns_path = self._scan_vulnerabilities(sbom_path, project, lang_target)
        if not vulns_path:
            lang_target.scan_status = "failed"
            lang_target.error_message = "Vulnerability scan failed"
            return False
        lang_target.vulns_path = vulns_path
        
        # Step 3: Run REACHABLE
        logger.info(f"      [3/3] Running REACHABLE analysis...")
        report_path = self._run_reachable_scan(project, lang_target, sbom_path, vulns_path)
        if not report_path:
            lang_target.scan_status = "failed"
            lang_target.error_message = "REACHABLE analysis failed"
            return False
        lang_target.report_path = report_path
        
        lang_target.scan_status = "success"
        logger.info(f"      ✅ {lang.upper()} scan complete")
        return True
    
    def scan_monorepo(self) -> Dict:
        """
        Main orchestration function.
        
        Returns monorepo-level summary report.
        """
        print("="*70)
        logger.info("REACHABLE MONOREPO SCANNER")
        print("="*70)
        print()
        logger.info(f"Monorepo root: {self.monorepo_root}")
        logger.info(f"Output directory: {self.output_dir}")
        print()
        
        # Step 1: Discover projects
        logger.info("[1/3] Discovering projects...")
        projects = self.dispatcher.get_scan_units(self.monorepo_root)
        
        total_languages = sum(len(p.language_targets) for p in projects)
        logger.info(f"   Found {len(projects)} projects ({total_languages} language scans)")
        print()
        
        # Display discovered projects
        for p in projects:
            polyglot = " [POLYGLOT]" if p.is_polyglot else ""
            logger.info(f"   • {p.project_name}{polyglot}: {', '.join(p.languages)}")
        print()
        
        # Step 2: Scan each project
        logger.info(f"[2/3] Scanning projects...")
        
        successful_scans = 0
        failed_scans = 0
        
        for project in projects:
            logger.info(f"\n📦 PROJECT: {project.project_name} ({project.relative_path})")
            
            for lang, lang_target in project.language_targets.items():
                success = self._scan_project_language(project, lang, lang_target)
                if success:
                    successful_scans += 1
                else:
                    failed_scans += 1
        
        print()
        logger.info(f"[3/3] Generating monorepo summary...")
        
        # Step 3: Aggregate results
        summary = self._generate_summary(projects)
        
        # Save summary report
        summary_path = os.path.join(self.output_dir, "monorepo-summary.json")
        with open(summary_path, 'w') as f:
            json.dump(summary, f, indent=2)
        
        print()
        print("="*70)
        logger.info("MONOREPO SCAN COMPLETE")
        print("="*70)
        logger.info(f"✅ Successful scans: {successful_scans}")
        logger.info(f"❌ Failed scans: {failed_scans}")
        logger.info(f"📄 Summary report: {summary_path}")
        print()
        
        return summary
    
    def _generate_summary(self, projects: List[ProjectUnit]) -> Dict:
        """Generate monorepo-level summary from all project scans."""
        summary = {
            "monorepo_root": self.monorepo_root,
            "scan_timestamp": datetime.now().isoformat(),
            "total_projects": len(projects),
            "projects": [],
            "global_summary": {
                "total_cves": 0,
                "total_reachable": 0,
                "total_unreachable": 0,
                "total_secrets": 0,
                "total_malware": 0,
            }
        }
        
        for project in projects:
            project_data = {
                "name": project.project_name,
                "path": project.relative_path,
                "languages": project.languages,
                "is_polyglot": project.is_polyglot,
                "language_results": {}
            }
            
            for lang, lang_target in project.language_targets.items():
                lang_data = {
                    "status": lang_target.scan_status,
                    "anchor_file": lang_target.anchor_file,
                }
                
                if lang_target.scan_status == "success" and lang_target.report_path:
                    # Load REACHABLE report
                    try:
                        with open(lang_target.report_path) as f:
                            report = json.load(f)
                            
                        # Extract summary
                        report_summary = report.get('summary', {})
                        totals = report_summary.get('totals', report_summary)
                        
                        lang_data["cves_found"] = totals.get('cves_found', 0)
                        lang_data["cves_reachable"] = totals.get('cves_reachable', 0)
                        lang_data["cves_unreachable"] = totals.get('cves_unreachable', 0)
                        
                        # Aggregate to global summary
                        summary["global_summary"]["total_cves"] += lang_data["cves_found"]
                        summary["global_summary"]["total_reachable"] += lang_data["cves_reachable"]
                        summary["global_summary"]["total_unreachable"] += lang_data["cves_unreachable"]
                        
                    except Exception as e:
                        lang_data["error"] = f"Failed to load report: {e}"
                
                elif lang_target.scan_status == "failed":
                    lang_data["error"] = lang_target.error_message
                
                project_data["language_results"][lang] = lang_data
            
            summary["projects"].append(project_data)
        
        return summary

def main():
    """CLI entry point for monorepo scanning."""
    import argparse
    
    parser = argparse.ArgumentParser(description="REACHABLE Monorepo Scanner")
    parser.add_argument("monorepo_path", nargs="?", default=".", 
                       help="Path to monorepo root (default: current directory)")
    parser.add_argument("--output", "-o", default="monorepo-scan-results",
                       help="Output directory for scan results")
    
    args = parser.parse_args()
    
    orchestrator = MonorepoOrchestrator(args.monorepo_path, args.output)
    orchestrator.scan_monorepo()

if __name__ == "__main__":
    main()
