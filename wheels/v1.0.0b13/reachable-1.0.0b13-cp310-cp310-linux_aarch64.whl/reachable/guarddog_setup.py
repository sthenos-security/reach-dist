#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.

"""
GuardDog Environment Setup - Single Source of Truth

This module provides the ONE function to set up GuardDog across all REACHABLE code:
- preflight.py (doctor --fix)
- guarddog_scanner.py (on-demand setup)
- install.sh (initial installation)

Handles:
- macOS: Installing libgit2 via Homebrew
- Linux: Installing libgit2-dev via apt/dnf/yum/pacman/apk/zypper
- Cross-platform venv creation
- GuardDog pip installation with correct environment flags
- Cache versioning for CI/CD

Usage:
    from reachable.guarddog_setup import setup_guarddog, is_guarddog_available
    
    # Check if already available
    if is_guarddog_available():
        logger.info("GuardDog ready")
    
    # Setup (install if needed)
    if setup_guarddog():
        logger.info("GuardDog installed successfully")
"""

import os
import sys
import shutil
import subprocess
import platform
import time
from pathlib import Path
from typing import Optional
import logging

# Initialize module-level logger
logger = logging.getLogger(__name__)

# =============================================================================
# Configuration
# =============================================================================

# Version marker for cache invalidation - bump when dependencies change
GUARDDOG_CACHE_VERSION = "1.2.0"

# Cache refresh interval (seconds) - default 7 days
# Set GUARDDOG_CACHE_TTL=0 to disable TTL-based refresh
GUARDDOG_CACHE_TTL = int(os.environ.get('GUARDDOG_CACHE_TTL', 7 * 24 * 60 * 60))


def _get_guarddog_venv_path() -> Path:
    """Get the guarddog venv path, respecting CI/CD cache settings."""
    cache_base = os.environ.get('REACHABLE_CACHE_DIR')
    if cache_base:
        return Path(cache_base).expanduser() / 'guarddog-venv'
    else:
        return Path.home() / '.reachable' / 'guarddog-venv'


def _get_venv_paths(venv_dir: Path) -> dict:
    """Get platform-specific venv paths."""
    if platform.system() == 'Windows':
        bin_dir = venv_dir / 'Scripts'
        return {
            'bin_dir': bin_dir,
            'python': bin_dir / 'python.exe',
            'pip': bin_dir / 'pip.exe',
            'guarddog': bin_dir / 'guarddog.exe'
        }
    else:
        bin_dir = venv_dir / 'bin'
        return {
            'bin_dir': bin_dir,
            'python': bin_dir / 'python',
            'pip': bin_dir / 'pip',
            'guarddog': bin_dir / 'guarddog'
        }


# =============================================================================
# Public API
# =============================================================================

def is_guarddog_available(venv_dir: Optional[Path] = None) -> bool:
    """
    Check if GuardDog is installed and working.
    
    Args:
        venv_dir: Optional custom venv path (default: auto-detect)
    
    Returns:
        True if guarddog command works, False otherwise
    """
    if venv_dir is None:
        venv_dir = _get_guarddog_venv_path()
    
    paths = _get_venv_paths(venv_dir)
    
    if not paths['guarddog'].exists():
        return False
    
    try:
        result = subprocess.run(
            [str(paths['guarddog']), '--version'],
            capture_output=True,
            timeout=10
        )
        return result.returncode == 0
    except Exception:
        return False


def setup_guarddog(
    venv_dir: Optional[Path] = None,
    verbose: bool = True,
    force: bool = False
) -> bool:
    """
    Set up GuardDog environment - THE single function for all setup.
    
    This handles:
    1. Checking if already installed and working
    2. Installing system dependencies (libgit2)
    3. Creating isolated Python venv
    4. Installing guarddog with correct flags
    5. Cache versioning for CI/CD
    
    Args:
        venv_dir: Optional custom venv path (default: ~/.reachable/guarddog-venv)
        verbose: Print progress messages
        force: Force reinstall even if already working
    
    Returns:
        True if guarddog is available after setup, False on failure
    
    Example:
        if setup_guarddog():
            scanner = GuardDogScanner()
            results = scanner.scan_package('requests', '2.31.0')
    """
    if venv_dir is None:
        venv_dir = _get_guarddog_venv_path()
    
    paths = _get_venv_paths(venv_dir)
    version_marker = venv_dir / '.cache_version'
    
    def log(msg: str):
        if verbose:
            print(msg)
    
    # Check if already set up and working (unless force=True)
    if not force and paths['guarddog'].exists():
        # Verify cache version and TTL
        cache_valid = False
        
        if version_marker.exists():
            try:
                cached_version = version_marker.read_text().strip()
                cache_valid = (cached_version == GUARDDOG_CACHE_VERSION)
                
                if not cache_valid:
                    log(f"   ♻️  GuardDog cache outdated (v{cached_version} → v{GUARDDOG_CACHE_VERSION}), rebuilding...")
                elif GUARDDOG_CACHE_TTL > 0:
                    # Check cache age
                    cache_age = time.time() - version_marker.stat().st_mtime
                    if cache_age > GUARDDOG_CACHE_TTL:
                        days_old = int(cache_age / 86400)
                        log(f"   ♻️  GuardDog cache expired ({days_old} days old), refreshing...")
                        cache_valid = False
            except Exception:
                pass
        
        if cache_valid:
            try:
                result = subprocess.run(
                    [str(paths['guarddog']), '--version'],
                    capture_output=True,
                    timeout=10
                )
                if result.returncode == 0:
                    return True  # Already working
            except Exception:
                pass  # Need to reinstall
    
    # Need to install/reinstall
    log("   📦 Setting up GuardDog...")
    
    # Step 1: Install system dependencies
    if not _install_system_dependencies(verbose):
        log("   ⚠️  System dependency installation had issues (continuing anyway)")
    
    # Step 2: Create venv and install guarddog
    if not _create_guarddog_venv(venv_dir, paths, verbose):
        return False
    
    # Step 3: Verify installation
    if is_guarddog_available(venv_dir):
        # Write version marker
        try:
            version_marker.write_text(GUARDDOG_CACHE_VERSION)
        except Exception:
            pass  # Non-fatal
        
        log("   ✅ GuardDog ready")
        return True
    else:
        log("   ❌ GuardDog installation failed verification")
        return False


def get_guarddog_executable(venv_dir: Optional[Path] = None) -> Optional[Path]:
    """
    Get path to guarddog executable if available.
    
    Args:
        venv_dir: Optional custom venv path
    
    Returns:
        Path to guarddog executable, or None if not available
    """
    if venv_dir is None:
        venv_dir = _get_guarddog_venv_path()
    
    paths = _get_venv_paths(venv_dir)
    
    if paths['guarddog'].exists():
        return paths['guarddog']
    return None


# =============================================================================
# Internal Implementation
# =============================================================================

def _install_system_dependencies(verbose: bool = True) -> bool:
    """Install system-level dependencies (libgit2) based on OS."""
    system = platform.system().lower()
    
    def log(msg: str):
        if verbose:
            print(msg)
    
    try:
        if system == "darwin":  # macOS
            return _install_libgit2_macos(verbose)
        elif system == "linux":
            return _install_libgit2_linux(verbose)
        elif system == "windows":
            # Windows uses pre-built wheels, no system deps needed
            return True
        else:
            log(f"   ⚠️  Unknown OS: {system}")
            return False
    except Exception as e:
        log(f"   ⚠️  System dependency check failed: {e}")
        return False


def _install_libgit2_macos(verbose: bool = True) -> bool:
    """Install libgit2 via Homebrew on macOS."""
    def log(msg: str):
        if verbose:
            print(msg)
    
    # Check if brew exists
    if shutil.which('brew') is None:
        log("   ⚠️  Homebrew not found - cannot install libgit2")
        log("      Install Homebrew: https://brew.sh")
        log("      Then run: brew install libgit2")
        return False
    
    # Check if libgit2 already installed
    try:
        result = subprocess.run(
            ['brew', 'list', 'libgit2'],
            capture_output=True,
            timeout=30
        )
        if result.returncode == 0:
            return True  # Already installed
    except Exception:
        pass
    
    # Install libgit2
    log("   📦 Installing libgit2 via Homebrew...")
    try:
        result = subprocess.run(
            ['brew', 'install', 'libgit2'],
            capture_output=True,
            timeout=300
        )
        if result.returncode == 0:
            log("   ✅ libgit2 installed")
            return True
        else:
            stderr = result.stderr.decode('utf-8', errors='ignore')[:200]
            log(f"   ❌ libgit2 installation failed: {stderr}")
            return False
    except subprocess.TimeoutExpired:
        log("   ⚠️  libgit2 installation timed out")
        return False


def _install_libgit2_linux(verbose: bool = True) -> bool:
    """Install libgit2-dev via package manager on Linux."""
    def log(msg: str):
        if verbose:
            print(msg)
    
    # Detect Linux distro
    distro = None
    if os.path.exists('/etc/os-release'):
        try:
            with open('/etc/os-release', 'r') as f:
                content = f.read().lower()
                if 'ubuntu' in content or 'debian' in content:
                    distro = 'debian'
                elif 'rhel' in content or 'fedora' in content or 'centos' in content or 'rocky' in content or 'alma' in content:
                    distro = 'rhel'
                elif 'arch' in content or 'manjaro' in content:
                    distro = 'arch'
                elif 'alpine' in content:
                    distro = 'alpine'
                elif 'suse' in content or 'opensuse' in content:
                    distro = 'suse'
        except Exception:
            pass
    
    if distro is None:
        log("   ⚠️  Unknown Linux distro - please install libgit2-dev manually")
        return False
    
    log(f"   📦 Installing libgit2 for {distro}...")
    
    try:
        if distro == 'debian':
            subprocess.run(['sudo', 'apt-get', 'update', '-qq'], timeout=60, check=False)
            subprocess.run(
                ['sudo', 'apt-get', 'install', '-y', 'libgit2-dev', 'pkg-config'],
                timeout=300,
                check=True,
                capture_output=True
            )
        elif distro == 'rhel':
            pkg_mgr = 'dnf' if os.path.exists('/usr/bin/dnf') else 'yum'
            subprocess.run(
                ['sudo', pkg_mgr, 'install', '-y', 'libgit2-devel', 'pkgconfig'],
                timeout=300,
                check=True,
                capture_output=True
            )
        elif distro == 'arch':
            subprocess.run(
                ['sudo', 'pacman', '-S', '--noconfirm', 'libgit2', 'pkg-config'],
                timeout=300,
                check=True,
                capture_output=True
            )
        elif distro == 'alpine':
            subprocess.run(
                ['sudo', 'apk', 'add', 'libgit2-dev', 'pkgconf'],
                timeout=300,
                check=True,
                capture_output=True
            )
        elif distro == 'suse':
            subprocess.run(
                ['sudo', 'zypper', 'install', '-y', 'libgit2-devel', 'pkg-config'],
                timeout=300,
                check=True,
                capture_output=True
            )
        
        log("   ✅ libgit2 installed")
        return True
        
    except subprocess.CalledProcessError as e:
        stderr = e.stderr.decode('utf-8', errors='ignore')[:200] if e.stderr else str(e)
        log(f"   ❌ libgit2 installation failed: {stderr}")
        return False
    except subprocess.TimeoutExpired:
        log("   ⚠️  libgit2 installation timed out")
        return False


def _create_guarddog_venv(venv_dir: Path, paths: dict, verbose: bool = True) -> bool:
    """Create venv and install guarddog."""
    import venv as venv_module
    
    def log(msg: str):
        if verbose:
            print(msg)
    
    try:
        # Create/recreate venv
        venv_dir.parent.mkdir(parents=True, exist_ok=True)
        if venv_dir.exists():
            shutil.rmtree(venv_dir)
        
        log("   📦 Creating isolated venv...")
        venv_module.create(venv_dir, with_pip=True)
        
        # Upgrade pip
        log("   📦 Upgrading pip...")
        result = subprocess.run(
            [str(paths['python']), '-m', 'pip', 'install', '--upgrade', 'pip', 'setuptools', 'wheel'],
            capture_output=True,
            timeout=120,
            text=True
        )
        if result.returncode != 0:
            log(f"   ⚠️  pip upgrade warning: {result.stderr[:100]}")
        
        # Platform-specific environment for compilation
        env = os.environ.copy()
        
        if platform.system() == 'Darwin':
            # macOS: Set flags for libgit2 (Homebrew paths)
            for hb_path in ['/opt/homebrew', '/usr/local']:
                if Path(hb_path).exists():
                    env['LDFLAGS'] = f"-L{hb_path}/lib"
                    env['CPPFLAGS'] = f"-I{hb_path}/include"
                    env['PKG_CONFIG_PATH'] = f"{hb_path}/lib/pkgconfig"
                    
                    # Apple Silicon: Ensure arm64 builds
                    if platform.machine() == 'arm64':
                        env['ARCHFLAGS'] = '-arch arm64'
                    break
        
        # Install guarddog
        log("   📦 Installing guarddog...")
        install_cmd = [str(paths['pip']), 'install', 'guarddog']
        
        # Windows: prefer binary wheels
        if platform.system() == 'Windows':
            install_cmd.extend(['--only-binary', ':all:'])
        
        result = subprocess.run(
            install_cmd,
            capture_output=True,
            timeout=300,
            env=env,
            text=True
        )
        
        if result.returncode != 0:
            log(f"   ❌ guarddog installation failed")
            stderr = result.stderr[:300] if result.stderr else "Unknown error"
            log(f"      Error: {stderr}")
            
            # Helpful hints
            if 'libgit2' in stderr or 'git2.h' in stderr:
                log("")
                log("   💡 libgit2 is required. Install it:")
                log("      macOS:   brew install libgit2")
                log("      Ubuntu:  sudo apt-get install libgit2-dev")
                log("")
                log(f"      Then retry: rm -rf {venv_dir}")
            
            return False
        
        # Verify it works
        if not paths['guarddog'].exists():
            log("   ❌ guarddog binary not found after install")
            return False
        
        test_result = subprocess.run(
            [str(paths['guarddog']), '--version'],
            capture_output=True,
            timeout=10
        )
        
        if test_result.returncode != 0:
            log("   ❌ guarddog installed but not working")
            stderr = test_result.stderr.decode('utf-8', errors='ignore')[:200]
            log(f"      Error: {stderr}")
            return False
        
        return True
        
    except subprocess.TimeoutExpired:
        log("   ❌ Installation timed out")
        return False
    except Exception as e:
        log(f"   ❌ Setup error: {e}")
        return False


# =============================================================================
# CLI for testing
# =============================================================================

if __name__ == '__main__':
    import argparse
    
    parser = argparse.ArgumentParser(description='GuardDog Environment Setup')
    parser.add_argument('--force', '-f', action='store_true', help='Force reinstall')
    parser.add_argument('--quiet', '-q', action='store_true', help='Quiet mode')
    parser.add_argument('--check', '-c', action='store_true', help='Check only, no install')
    args = parser.parse_args()
    
    if args.check:
        if is_guarddog_available():
            logger.info("✅ GuardDog is available")
            exe = get_guarddog_executable()
            logger.info(f"   Executable: {exe}")
            sys.exit(0)
        else:
            logger.info("❌ GuardDog is not available")
            sys.exit(1)
    else:
        success = setup_guarddog(verbose=not args.quiet, force=args.force)
        sys.exit(0 if success else 1)
