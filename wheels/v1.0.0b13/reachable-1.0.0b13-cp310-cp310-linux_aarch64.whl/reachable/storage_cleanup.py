#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.

"""
REACHABLE Storage Cleanup Module (v4.5.40)

Handles retention/trimming for:
1. Scan session directories (dashboards, data.json, cache/, etc.)
2. Database records (coordinated with filesystem)  
3. Caches (SBOM, call graphs, intermediate files)
4. Temporary/orphaned files
5. Intermediate scan files (SBOM, vulns, call-graph - all regenerable)

NEW in v4.5.40:
- nuke_intermediate_files(): Remove redundant per-scan files
- post_scan_cleanup(): Combined cleanup + checkpoint after each scan
- Integration with database_compaction.py

CLI: reachctl db --trim [--dry-run] [--days N] [--keep N]
"""

import os
import shutil
from datetime import datetime, timedelta
from pathlib import Path
from typing import Dict, List, Optional, Tuple
import json
import sqlite3
import logging

logger = logging.getLogger(__name__)

# Defaults
DEFAULT_RETENTION_DAYS = 30
DEFAULT_MIN_SCANS_KEEP = 5
DEFAULT_REACHABLE_HOME = Path.home() / ".reachable"

# Files that are REDUNDANT and can be deleted after scan
# (all data is stored in repo.db, these can be regenerated)
REDUNDANT_FILES = {
    'sbom.json',
    'sbom.json.gz',
    'vulns.json',
    'vulns.json.gz',
    'call-graph.json',
    'call-graph.json.gz',
    'reachable-report.json',
    'reachable-report.json.gz',
    'scan.log',
    'debug.log',
}

# Directories that are REDUNDANT (all in repo.db or regenerable)
REDUNDANT_DIRS = {
    'raw',           # Old raw output directory
    'cache',         # Per-scan cache (now using global cache)
    'dashboard',     # Regenerable from repo.db
    'libs',          # Cloned libraries (now using global cache)
    '.metadata',     # CI/CD metadata (ephemeral)
}

# Files to KEEP in scan directories
KEEP_FILES = {
    '.session.json',  # Scan metadata (small, <1KB)
}


def get_scan_timestamp(scan_dir: Path) -> Optional[datetime]:
    """
    Parse timestamp from scan directory name.
    
    Format: 20260109-234040-f86740 (YYYYMMDD-HHMMSS-hash)
    """
    try:
        name = scan_dir.name
        # Extract timestamp portion (first 15 chars: YYYYMMDD-HHMMSS)
        ts_str = name[:15]
        return datetime.strptime(ts_str, "%Y%m%d-%H%M%S")
    except (ValueError, IndexError):
        # Fallback to directory mtime
        try:
            mtime = scan_dir.stat().st_mtime
            return datetime.fromtimestamp(mtime)
        except:
            return None


def get_dir_size(path: Path) -> int:
    """Get total size of directory in bytes."""
    total = 0
    try:
        for f in path.rglob("*"):
            if f.is_file():
                total += f.stat().st_size
    except:
        pass
    return total


def format_size(size_bytes: int) -> str:
    """Format bytes as human-readable string."""
    for unit in ['B', 'KB', 'MB', 'GB']:
        if size_bytes < 1024:
            return f"{size_bytes:.1f} {unit}"
        size_bytes /= 1024
    return f"{size_bytes:.1f} TB"


class StorageCleanup:
    """
    Comprehensive storage cleanup for REACHABLE.
    
    Directory structure:
        ~/.reachable/
        ├── scans/
        │   └── {repo-name}-{hash}/
        │       ├── repo.db                    # Per-repo database
        │       └── {branch}/
        │           └── {timestamp}-{hash}/    # Scan session
        │               ├── data.json
        │               ├── dashboard/
        │               ├── cache/
        │               └── raw/               # (deprecated)
        ├── venv/                              # Tool virtualenvs
        └── yara-rules/                        # YARA rules cache
    """
    
    def __init__(self, 
                 reachable_home: Path = None,
                 retention_days: int = DEFAULT_RETENTION_DAYS,
                 min_scans_keep: int = DEFAULT_MIN_SCANS_KEEP):
        self.home = reachable_home or DEFAULT_REACHABLE_HOME
        self.scans_dir = self.home / "scans"
        self.retention_days = retention_days
        self.min_scans_keep = min_scans_keep
        self.cutoff_date = datetime.now() - timedelta(days=retention_days)
    
    def get_stats(self) -> Dict:
        """Get storage statistics."""
        stats = {
            'total_size': 0,
            'repos': {},
            'oldest_scan': None,
            'newest_scan': None,
            'total_scans': 0,
            'orphaned_files': 0
        }
        
        if not self.scans_dir.exists():
            return stats
        
        oldest_ts = None
        newest_ts = None
        
        for repo_dir in self.scans_dir.iterdir():
            if not repo_dir.is_dir() or repo_dir.name.startswith('.'):
                continue
            
            repo_stats = {
                'size': 0,
                'branches': {},
                'scan_count': 0,
                'db_size': 0
            }
            
            # Check for repo.db
            repo_db = repo_dir / "repo.db"
            if repo_db.exists():
                repo_stats['db_size'] = repo_db.stat().st_size
                repo_stats['size'] += repo_stats['db_size']
            
            # Iterate branches
            for branch_dir in repo_dir.iterdir():
                if not branch_dir.is_dir() or branch_dir.name == 'repo.db':
                    continue
                
                branch_scans = []
                
                for scan_dir in branch_dir.iterdir():
                    if not scan_dir.is_dir():
                        continue
                    
                    ts = get_scan_timestamp(scan_dir)
                    size = get_dir_size(scan_dir)
                    
                    branch_scans.append({
                        'path': scan_dir,
                        'timestamp': ts,
                        'size': size
                    })
                    
                    repo_stats['size'] += size
                    repo_stats['scan_count'] += 1
                    stats['total_scans'] += 1
                    
                    if ts:
                        if oldest_ts is None or ts < oldest_ts:
                            oldest_ts = ts
                        if newest_ts is None or ts > newest_ts:
                            newest_ts = ts
                
                repo_stats['branches'][branch_dir.name] = len(branch_scans)
            
            stats['repos'][repo_dir.name] = repo_stats
            stats['total_size'] += repo_stats['size']
        
        stats['oldest_scan'] = oldest_ts.isoformat() if oldest_ts else None
        stats['newest_scan'] = newest_ts.isoformat() if newest_ts else None
        
        return stats
    
    def find_scans_to_delete(self) -> List[Dict]:
        """
        Find scan directories eligible for deletion.
        
        Criteria:
        - Older than retention_days AND
        - Beyond min_scans_keep per branch
        """
        to_delete = []
        
        if not self.scans_dir.exists():
            return to_delete
        
        for repo_dir in self.scans_dir.iterdir():
            if not repo_dir.is_dir() or repo_dir.name.startswith('.'):
                continue
            
            for branch_dir in repo_dir.iterdir():
                if not branch_dir.is_dir() or branch_dir.name.endswith('.db'):
                    continue
                
                # Collect all scans for this branch
                scans = []
                for scan_dir in branch_dir.iterdir():
                    # Skip symlinks (like 'latest')
                    if scan_dir.is_symlink():
                        continue
                    if not scan_dir.is_dir():
                        continue
                    
                    ts = get_scan_timestamp(scan_dir)
                    scans.append({
                        'path': scan_dir,
                        'timestamp': ts,
                        'size': get_dir_size(scan_dir),
                        'repo': repo_dir.name,
                        'branch': branch_dir.name
                    })
                
                # Sort by timestamp (newest first)
                scans.sort(key=lambda x: x['timestamp'] or datetime.min, reverse=True)
                
                # Mark old scans beyond keep limit for deletion
                for i, scan in enumerate(scans):
                    if i < self.min_scans_keep:
                        continue  # Always keep recent N
                    
                    if scan['timestamp'] and scan['timestamp'] < self.cutoff_date:
                        to_delete.append(scan)
        
        return to_delete
    
    def find_orphaned_caches(self) -> List[Path]:
        """Find cache directories without corresponding scan data."""
        orphaned = []
        
        if not self.scans_dir.exists():
            return orphaned
        
        for repo_dir in self.scans_dir.iterdir():
            if not repo_dir.is_dir():
                continue
            
            for branch_dir in repo_dir.iterdir():
                if not branch_dir.is_dir():
                    continue
                
                for scan_dir in branch_dir.iterdir():
                    # Skip symlinks (like 'latest')
                    if scan_dir.is_symlink():
                        continue
                    if not scan_dir.is_dir():
                        continue
                    
                    # Check for orphaned cache (cache exists but no data.json)
                    cache_dir = scan_dir / "cache"
                    data_json = scan_dir / "data.json"
                    
                    if cache_dir.exists() and not data_json.exists():
                        orphaned.append(cache_dir)
                    
                    # Check for deprecated raw/ directory
                    raw_dir = scan_dir / "raw"
                    if raw_dir.exists():
                        orphaned.append(raw_dir)
        
        return orphaned
    
    def cleanup_database(self, repo_dir: Path, deleted_scan_dirs: List[str]) -> int:
        """
        Clean up database records for deleted scan directories.
        
        Returns number of records deleted.
        """
        repo_db = repo_dir / "repo.db"
        if not repo_db.exists():
            return 0
        
        deleted_count = 0
        
        try:
            conn = sqlite3.connect(str(repo_db))
            cursor = conn.cursor()
            
            for scan_dir in deleted_scan_dirs:
                # Delete by scan_dir path
                cursor.execute(
                    "DELETE FROM scans WHERE scan_dir = ? OR scan_dir LIKE ?",
                    (scan_dir, f"%{Path(scan_dir).name}%")
                )
                deleted_count += cursor.rowcount
            
            # Clean up old cache entries
            cutoff_iso = self.cutoff_date.isoformat()
            
            cursor.execute("""
                DELETE FROM sbom_cache 
                WHERE created_at < ? 
                AND commit_hash NOT IN (SELECT DISTINCT commit_hash FROM scans WHERE commit_hash IS NOT NULL)
            """, (cutoff_iso,))
            
            cursor.execute("""
                DELETE FROM call_graph_cache 
                WHERE created_at < ?
            """, (cutoff_iso,))
            
            conn.commit()
            
            # Vacuum to reclaim space
            conn.execute("VACUUM")
            conn.close()
            
        except Exception as e:
            logger.info(f"  Warning: DB cleanup failed for {repo_db}: {e}")
        
        return deleted_count
    
    def trim(self, dry_run: bool = False, verbose: bool = True) -> Dict:
        """
        Perform full storage cleanup.
        
        Args:
            dry_run: If True, don't actually delete, just report
            verbose: Print progress
            
        Returns:
            Dict with cleanup statistics
        """
        results = {
            'scans_deleted': 0,
            'bytes_freed': 0,
            'caches_cleaned': 0,
            'db_records_deleted': 0,
            'errors': []
        }
        
        if verbose:
            logger.info(f"\n{'[DRY RUN] ' if dry_run else ''}Storage Cleanup")
            logger.info(f"  Retention: {self.retention_days} days")
            logger.info(f"  Keep minimum: {self.min_scans_keep} scans per branch")
            logger.info(f"  Cutoff date: {self.cutoff_date.strftime('%Y-%m-%d')}")
            print()
        
        # Find scans to delete
        to_delete = self.find_scans_to_delete()
        
        if verbose and to_delete:
            logger.info(f"Scans to delete: {len(to_delete)}")
        
        # Group by repo for database cleanup
        by_repo = {}
        for scan in to_delete:
            repo = scan['repo']
            if repo not in by_repo:
                by_repo[repo] = []
            by_repo[repo].append(scan)
        
        # Delete scans
        for repo, scans in by_repo.items():
            repo_dir = self.scans_dir / repo
            deleted_paths = []
            
            for scan in scans:
                path = scan['path']
                size = scan['size']
                ts = scan['timestamp']
                
                if verbose:
                    ts_str = ts.strftime('%Y-%m-%d') if ts else 'unknown'
                    logger.info(f"  {'Would delete' if dry_run else 'Deleting'}: {path.name} ({ts_str}, {format_size(size)})")
                
                if not dry_run:
                    try:
                        shutil.rmtree(path)
                        results['scans_deleted'] += 1
                        results['bytes_freed'] += size
                        deleted_paths.append(str(path))
                    except Exception as e:
                        results['errors'].append(f"Failed to delete {path}: {e}")
                else:
                    results['scans_deleted'] += 1
                    results['bytes_freed'] += size
                    deleted_paths.append(str(path))
            
            # Clean up database
            if deleted_paths and not dry_run:
                db_deleted = self.cleanup_database(repo_dir, deleted_paths)
                results['db_records_deleted'] += db_deleted
            
            # Remove empty branch directories
            if not dry_run:
                for branch_dir in repo_dir.iterdir():
                    if branch_dir.is_dir() and not any(branch_dir.iterdir()):
                        try:
                            branch_dir.rmdir()
                        except:
                            pass
        
        # Clean orphaned caches
        orphaned = self.find_orphaned_caches()
        if verbose and orphaned:
            logger.info(f"\nOrphaned caches: {len(orphaned)}")
        
        for cache_path in orphaned:
            size = get_dir_size(cache_path)
            
            if verbose:
                logger.info(f"  {'Would delete' if dry_run else 'Deleting'}: {cache_path} ({format_size(size)})")
            
            if not dry_run:
                try:
                    shutil.rmtree(cache_path)
                    results['caches_cleaned'] += 1
                    results['bytes_freed'] += size
                except Exception as e:
                    results['errors'].append(f"Failed to delete {cache_path}: {e}")
            else:
                results['caches_cleaned'] += 1
                results['bytes_freed'] += size
        
        # Summary
        if verbose:
            print()
            print("=" * 50)
            logger.info(f"{'Would free' if dry_run else 'Freed'}: {format_size(results['bytes_freed'])}")
            logger.info(f"Scans: {results['scans_deleted']}")
            logger.info(f"Caches: {results['caches_cleaned']}")
            if results['db_records_deleted']:
                logger.info(f"DB records: {results['db_records_deleted']}")
            if results['errors']:
                logger.info(f"Errors: {len(results['errors'])}")
                for err in results['errors']:
                    logger.info(f"  ⚠️  {err}")
            print("=" * 50)
        
        return results


def trim_storage(reachable_home: Path = None,
                 retention_days: int = DEFAULT_RETENTION_DAYS,
                 min_scans_keep: int = DEFAULT_MIN_SCANS_KEEP,
                 dry_run: bool = False,
                 verbose: bool = True) -> Dict:
    """
    Convenience function for storage cleanup.
    
    Args:
        reachable_home: REACHABLE home directory (default: ~/.reachable)
        retention_days: Delete scans older than this (default: 30)
        min_scans_keep: Keep at least this many per branch (default: 5)
        dry_run: Preview without deleting
        verbose: Print progress
        
    Returns:
        Cleanup statistics dict
    """
    cleaner = StorageCleanup(
        reachable_home=reachable_home,
        retention_days=retention_days,
        min_scans_keep=min_scans_keep
    )
    return cleaner.trim(dry_run=dry_run, verbose=verbose)


def get_storage_stats(reachable_home: Path = None) -> Dict:
    """Get storage statistics."""
    cleaner = StorageCleanup(reachable_home=reachable_home)
    return cleaner.get_stats()


# =============================================================================
# INTERMEDIATE FILE CLEANUP (v4.5.40)
# =============================================================================

def nuke_intermediate_files(scan_dir: Path, dry_run: bool = False, verbose: bool = False) -> Dict:
    """
    Remove redundant intermediate files from a scan directory.
    
    These files are regenerable from repo.db:
    - sbom.json(.gz) - run syft again
    - vulns.json(.gz) - stored in repo.db
    - call-graph.json(.gz) - paths stored in findings
    - reachable-report.json(.gz) - regenerate from repo.db
    - scan.log - debug only
    - dashboard/ - regenerate from repo.db
    - raw/ - old deprecated directory
    - libs/ - using global cache now
    - cache/ - using global cache now
    
    Keeps only:
    - .session.json (scan metadata, <1KB)
    
    Args:
        scan_dir: Path to scan directory
        dry_run: If True, just report what would be deleted
        verbose: Print progress
        
    Returns:
        Dict with bytes_freed, files_deleted, dirs_deleted
    """
    result = {
        'bytes_freed': 0,
        'files_deleted': 0,
        'dirs_deleted': 0,
        'kept': [],
        'errors': []
    }
    
    if not scan_dir.exists():
        return result
    
    # Delete redundant files
    for item in scan_dir.iterdir():
        if item.is_file():
            if item.name in REDUNDANT_FILES:
                size = item.stat().st_size
                if verbose:
                    logger.info(f"    {'Would delete' if dry_run else 'Deleting'} file: {item.name} ({format_size(size)})")
                
                if not dry_run:
                    try:
                        item.unlink()
                        result['files_deleted'] += 1
                        result['bytes_freed'] += size
                    except Exception as e:
                        result['errors'].append(f"Failed to delete {item}: {e}")
                else:
                    result['files_deleted'] += 1
                    result['bytes_freed'] += size
            elif item.name in KEEP_FILES:
                result['kept'].append(item.name)
        
        elif item.is_dir():
            if item.name in REDUNDANT_DIRS:
                size = get_dir_size(item)
                if verbose:
                    logger.info(f"    {'Would delete' if dry_run else 'Deleting'} dir: {item.name}/ ({format_size(size)})")
                
                if not dry_run:
                    try:
                        shutil.rmtree(item)
                        result['dirs_deleted'] += 1
                        result['bytes_freed'] += size
                    except Exception as e:
                        result['errors'].append(f"Failed to delete {item}: {e}")
                else:
                    result['dirs_deleted'] += 1
                    result['bytes_freed'] += size
    
    return result


def nuke_all_intermediate_files(
    reachable_home: Path = None,
    dry_run: bool = False,
    verbose: bool = True
) -> Dict:
    """
    Remove redundant intermediate files from ALL scan directories.
    
    Target storage structure after cleanup:
        ~/.reachable/
        ├── cache/                          # Global cache (shared)
        │   ├── grype-db/                   # Vuln DB (~100MB)
        │   ├── libs/{pkg}@{ver}/           # Cloned libraries
        │   ├── guarddog-venv/              # GuardDog venv
        │   └── cache.db                    # smart_cache SQLite
        ├── scans/{repo}/
        │   └── repo.db                     # ALL findings (only file needed!)
        ├── tools/bin/                      # syft, grype binaries
        └── venv/                           # Python tool venvs
    
    Returns:
        Summary statistics
    """
    home = reachable_home or DEFAULT_REACHABLE_HOME
    scans_dir = home / 'scans'
    
    summary = {
        'scan_dirs_processed': 0,
        'total_bytes_freed': 0,
        'total_files_deleted': 0,
        'total_dirs_deleted': 0,
        'errors': []
    }
    
    if not scans_dir.exists():
        if verbose:
            logger.info("No scans directory found.")
        return summary
    
    if verbose:
        logger.info(f"\n{'[DRY RUN] ' if dry_run else ''}Nuking Intermediate Files")
        print("=" * 60)
        logger.info("Removing redundant files (all data is in repo.db)...")
        print()
    
    # Find all scan directories
    for repo_dir in sorted(scans_dir.iterdir()):
        if not repo_dir.is_dir() or repo_dir.name.startswith('.'):
            continue
        
        for branch_dir in repo_dir.iterdir():
            if not branch_dir.is_dir() or branch_dir.name.endswith('.db'):
                continue
            
            for scan_dir in branch_dir.iterdir():
                if scan_dir.is_symlink() or not scan_dir.is_dir():
                    continue
                
                if verbose:
                    logger.info(f"  {repo_dir.name}/{branch_dir.name}/{scan_dir.name}:")
                
                result = nuke_intermediate_files(scan_dir, dry_run=dry_run, verbose=verbose)
                
                summary['scan_dirs_processed'] += 1
                summary['total_bytes_freed'] += result['bytes_freed']
                summary['total_files_deleted'] += result['files_deleted']
                summary['total_dirs_deleted'] += result['dirs_deleted']
                summary['errors'].extend(result['errors'])
                
                if verbose and result['bytes_freed'] > 0:
                    logger.info(f"    → Freed {format_size(result['bytes_freed'])}")
    
    # Summary
    if verbose:
        print()
        print("=" * 60)
        logger.info(f"{'Would free' if dry_run else 'Freed'}: {format_size(summary['total_bytes_freed'])}")
        logger.info(f"Scan dirs processed: {summary['scan_dirs_processed']}")
        logger.info(f"Files deleted: {summary['total_files_deleted']}")
        logger.info(f"Dirs deleted: {summary['total_dirs_deleted']}")
        if summary['errors']:
            logger.info(f"Errors: {len(summary['errors'])}")
        print("=" * 60)
    
    return summary


def post_scan_cleanup(
    scan_dir: Path,
    repo_db: Path,
    verbose: bool = False
) -> Dict:
    """
    Run cleanup after scan completes.
    
    Performs:
    1. Nuke intermediate files (keep only .session.json)
    2. Checkpoint WAL (prevent unbounded growth)
    3. Vacuum if significantly bloated (>50%)
    
    Called automatically at end of each scan.
    
    Args:
        scan_dir: Path to current scan directory
        repo_db: Path to repo.db
        verbose: Print progress
        
    Returns:
        Cleanup result dict
    """
    result = {
        'intermediate_files_cleaned': False,
        'bytes_freed': 0,
        'db_checkpointed': False,
        'db_vacuumed': False,
        'error': None
    }
    
    # Step 1: Nuke intermediate files
    try:
        nuke_result = nuke_intermediate_files(scan_dir, dry_run=False, verbose=verbose)
        result['intermediate_files_cleaned'] = True
        result['bytes_freed'] = nuke_result['bytes_freed']
        
        if verbose and nuke_result['bytes_freed'] > 0:
            logger.info(f"  ✓ Cleaned intermediate files ({format_size(nuke_result['bytes_freed'])} freed)")
    except Exception as e:
        result['error'] = f"Intermediate file cleanup failed: {e}"
        logger.warning(result['error'])
    
    # Step 2: Database maintenance (checkpoint + conditional vacuum)
    try:
        from .database_compaction import post_scan_maintenance
        
        db_result = post_scan_maintenance(repo_db, verbose=verbose)
        result['db_checkpointed'] = db_result.get('checkpointed', False)
        result['db_vacuumed'] = db_result.get('vacuumed', False)
        
    except ImportError:
        # database_compaction not available, do basic checkpoint
        try:
            import sqlite3
            conn = sqlite3.connect(str(repo_db), timeout=30)
            conn.execute("PRAGMA wal_checkpoint(TRUNCATE)")
            conn.close()
            result['db_checkpointed'] = True
            if verbose:
                logger.info("  ✓ Checkpointed WAL")
        except Exception as e:
            logger.warning(f"WAL checkpoint failed: {e}")
    except Exception as e:
        result['error'] = f"Database maintenance failed: {e}"
        logger.warning(result['error'])
    
    return result

if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description="REACHABLE Storage Cleanup")
    parser.add_argument("--trim", action="store_true", help="Perform cleanup")
    parser.add_argument("--stats", action="store_true", help="Show storage stats")
    parser.add_argument("--dry-run", action="store_true", help="Preview without deleting")
    parser.add_argument("--days", type=int, default=DEFAULT_RETENTION_DAYS,
                        help=f"Retention days (default: {DEFAULT_RETENTION_DAYS})")
    parser.add_argument("--keep", type=int, default=DEFAULT_MIN_SCANS_KEEP,
                        help=f"Minimum scans to keep per branch (default: {DEFAULT_MIN_SCANS_KEEP})")
    parser.add_argument("--home", type=Path, help="REACHABLE home directory")
    
    args = parser.parse_args()
    
    if args.stats:
        stats = get_storage_stats(args.home)
        logger.info("\nREACHABLE Storage Stats")
        print("=" * 50)
        logger.info(f"Total size: {format_size(stats['total_size'])}")
        logger.info(f"Total scans: {stats['total_scans']}")
        logger.info(f"Oldest scan: {stats['oldest_scan'] or 'N/A'}")
        logger.info(f"Newest scan: {stats['newest_scan'] or 'N/A'}")
        print()
        logger.info("By repository:")
        for repo, repo_stats in stats['repos'].items():
            logger.info(f"  {repo}: {format_size(repo_stats['size'])} ({repo_stats['scan_count']} scans)")
            if repo_stats['db_size']:
                logger.info(f"    DB: {format_size(repo_stats['db_size'])}")
    
    elif args.trim:
        trim_storage(
            reachable_home=args.home,
            retention_days=args.days,
            min_scans_keep=args.keep,
            dry_run=args.dry_run
        )
    
    else:
        parser.print_help()
