#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.

"""
CI/CD-friendly output modes for REACHABLE scans.

Provides different output formats optimized for:
- GitHub Actions / GitLab CI / Jenkins
- Human-readable summaries
- Machine-readable formats (JSON, SARIF)
"""

import json
import sys
import logging
from pathlib import Path
from typing import Dict, Any, Optional

# Initialize module-level logger
logger = logging.getLogger(__name__)

def print_quiet_summary(results: Dict[str, Any], output_dir: Path) -> None:
    """
    Print minimal CI-friendly summary (one line).
    
    Format: REACHABLE: <status> | Risk: <score> | Critical: <n> | High: <n> | Dashboard: <path>
    
    v4.5.2: Uses sys.__stdout__ directly to ensure output appears in CI/CD logs
    even when TeeOutput has console disabled.
    """
    
    summary = results.get('summary', {})
    totals = summary.get('totals', {})
    
    risk_score = summary.get('risk_score', 0)
    risk_level = summary.get('risk_level', 'UNKNOWN')
    
    critical = totals.get('cves_critical_reachable', 0) + totals.get('malware_count', 0)
    high = totals.get('cves_high_reachable', 0) + totals.get('secrets_reachable', 0)
    
    dashboard_path = output_dir / 'dashboard' / 'index.html'
    
    # Status emoji based on findings
    if critical > 0:
        status = "🚨 CRITICAL"
    elif high > 0:
        status = "⚠️  WARNING"
    elif risk_score > 50:
        status = "⚠️  ELEVATED"
    else:
        status = "✅ PASS"
    
    # v4.5.2: Write directly to real stdout for CI/CD visibility
    output = f"REACHABLE: {status} | Risk: {risk_score:.0f}/100 ({risk_level}) | Critical: {critical} | High: {high} | Dashboard: {dashboard_path}\n"
    sys.__stdout__.write(output)
    sys.__stdout__.flush()

def print_enhanced_summary(results: Dict[str, Any], output_dir: Path) -> None:
    """
    Print enhanced summary with key metrics (multi-line, still concise).
    """
    summary = results.get('summary', {})
    totals = summary.get('totals', {})
    
    risk_score = summary.get('risk_score', 0)
    risk_level = summary.get('risk_level', 'UNKNOWN')
    reduction = summary.get('risk_reduction_pct', 0)
    
    # Header
    print()
    print("=" * 60)
    logger.info("REACHABLE SCAN COMPLETE")
    print("=" * 60)
    
    # Risk score with visual bar
    bar_filled = int(risk_score / 10)
    bar_empty = 10 - bar_filled
    risk_bar = "█" * bar_filled + "░" * bar_empty
    
    if risk_level == 'CRITICAL':
        risk_icon = "🚨"
    elif risk_level == 'HIGH':
        risk_icon = "🔴"
    elif risk_level == 'MEDIUM':
        risk_icon = "🟠"
    elif risk_level == 'LOW':
        risk_icon = "🟢"
    else:
        risk_icon = "⚪"
    
    logger.info(f"\n{risk_icon} Risk Score: {risk_score:.0f}/100 [{risk_bar}] {risk_level}")
    logger.info(f"   Noise Reduction: {reduction:.0f}% (unreachable findings deprioritized)")
    
    # Key findings table
    logger.info("\n📊 Findings Summary:")
    print("   " + "-" * 50)
    
    # CVEs
    cves_total = totals.get('cves_total', 0)
    cves_reachable = totals.get('cves_reachable', 0)
    if cves_total > 0:
        logger.info(f"   CVEs:      {cves_reachable:3d} reachable / {cves_total:3d} total")
    
    # Secrets
    secrets_total = totals.get('secrets_total', 0)
    secrets_reachable = totals.get('secrets_reachable', 0)
    if secrets_total > 0:
        logger.info(f"   Secrets:   {secrets_reachable:3d} reachable / {secrets_total:3d} total")
    
    # CWE/SAST
    cwe_total = totals.get('cwe_total', 0)
    cwe_reachable = totals.get('cwe_reachable', 0)
    if cwe_total > 0:
        logger.info(f"   CWE/SAST:  {cwe_reachable:3d} reachable / {cwe_total:3d} total")
    
    # Malware
    malware_count = totals.get('malware_count', 0)
    if malware_count > 0:
        logger.info(f"   🚨 Malware: {malware_count:3d} packages flagged")
    
    print("   " + "-" * 50)
    
    # Dashboard link
    dashboard_path = output_dir / 'dashboard' / 'index.html'
    if dashboard_path.exists():
        logger.info(f"\n📈 Dashboard: file://{dashboard_path.absolute()}")
    
    # Report path
    report_path = output_dir / 'reachable-report.json.gz'
    if not report_path.exists():
        report_path = output_dir / 'reachable-report.json'
    logger.info(f"📄 Report:    {report_path}")
    
    print()

def print_verbose_summary(results: Dict[str, Any], output_dir: Path) -> None:
    """
    Print detailed verbose summary with all findings.
    """
    print_enhanced_summary(results, output_dir)
    
    # Add detailed breakdowns
    summary = results.get('summary', {})
    totals = summary.get('totals', {})
    
    # Severity breakdown for reachable CVEs
    logger.info("📋 Reachable CVE Severity Breakdown:")
    logger.info(f"   🔴 Critical: {totals.get('cves_critical_reachable', 0)}")
    logger.info(f"   🟠 High:     {totals.get('cves_high_reachable', 0)}")
    logger.info(f"   🟡 Medium:   {totals.get('cves_medium_reachable', 0)}")
    logger.info(f"   🟢 Low:      {totals.get('cves_low_reachable', 0)}")
    
    # Top findings
    reachable = results.get('reachable', {})
    if reachable:
        logger.info("\n🎯 Top Reachable CVEs:")
        # Sort by CVSS score
        sorted_cves = sorted(
            reachable.items(),
            key=lambda x: x[1].get('cvss_score', 0),
            reverse=True
        )[:5]
        
        for cve_id, data in sorted_cves:
            severity = data.get('severity', 'MEDIUM')
            package = data.get('package', 'unknown')
            version = data.get('version', '?')
            cvss = data.get('cvss_score', 0)
            logger.info(f"   • {cve_id} [{severity}] {package}@{version} (CVSS: {cvss})")
    
    print()

def export_markdown_summary(results: Dict[str, Any], output_path: Path) -> None:
    """
    Export results as Markdown summary (for PR comments, etc).
    """
    summary = results.get('summary', {})
    totals = summary.get('totals', {})
    
    risk_score = summary.get('risk_score', 0)
    risk_level = summary.get('risk_level', 'UNKNOWN')
    reduction = summary.get('risk_reduction_pct', 0)
    
    # Build markdown
    md_lines = [
        "## 🛡️ REACHABLE Security Scan Results",
        "",
        f"**Risk Score:** {risk_score:.0f}/100 ({risk_level})",
        f"**Noise Reduction:** {reduction:.0f}%",
        "",
        "### Findings Summary",
        "",
        "| Category | Reachable | Total |",
        "|----------|-----------|-------|",
        f"| CVEs | {totals.get('cves_reachable', 0)} | {totals.get('cves_total', 0)} |",
        f"| Secrets | {totals.get('secrets_reachable', 0)} | {totals.get('secrets_total', 0)} |",
        f"| CWE/SAST | {totals.get('cwe_reachable', 0)} | {totals.get('cwe_total', 0)} |",
        f"| Malware | {totals.get('malware_count', 0)} | {totals.get('malware_count', 0)} |",
        "",
    ]
    
    # Add severity breakdown
    md_lines.extend([
        "### CVE Severity (Reachable Only)",
        "",
        f"- 🔴 **Critical:** {totals.get('cves_critical_reachable', 0)}",
        f"- 🟠 **High:** {totals.get('cves_high_reachable', 0)}",
        f"- 🟡 **Medium:** {totals.get('cves_medium_reachable', 0)}",
        f"- 🟢 **Low:** {totals.get('cves_low_reachable', 0)}",
        "",
    ])
    
    # Add top CVEs
    reachable = results.get('reachable', {})
    if reachable:
        md_lines.extend([
            "### Top Reachable CVEs",
            "",
            "| CVE | Severity | Package | CVSS |",
            "|-----|----------|---------|------|",
        ])
        
        sorted_cves = sorted(
            reachable.items(),
            key=lambda x: x[1].get('cvss_score', 0),
            reverse=True
        )[:10]
        
        for cve_id, data in sorted_cves:
            severity = data.get('severity', 'MEDIUM')
            package = data.get('package', 'unknown')
            version = data.get('version', '?')
            cvss = data.get('cvss_score', 0)
            md_lines.append(f"| [{cve_id}](https://nvd.nist.gov/vuln/detail/{cve_id}) | {severity} | {package}@{version} | {cvss} |")
        
        md_lines.append("")
    
    # Footer
    md_lines.extend([
        "---",
        f"*Generated by REACHABLE {results.get('reachable_version', 'unknown')}*",
    ])
    
    # Write file
    output_path.write_text("\n".join(md_lines))

def export_json_summary(results: Dict[str, Any], output_path: Path) -> None:
    """
    Export minimal JSON summary for CI/CD parsing.
    """
    summary = results.get('summary', {})
    totals = summary.get('totals', {})
    
    ci_summary = {
        "status": "pass" if summary.get('risk_score', 0) < 70 else "fail",
        "risk_score": summary.get('risk_score', 0),
        "risk_level": summary.get('risk_level', 'UNKNOWN'),
        "noise_reduction_pct": summary.get('risk_reduction_pct', 0),
        "findings": {
            "cves": {
                "total": totals.get('cves_total', 0),
                "reachable": totals.get('cves_reachable', 0),
                "critical": totals.get('cves_critical_reachable', 0),
                "high": totals.get('cves_high_reachable', 0),
            },
            "secrets": {
                "total": totals.get('secrets_total', 0),
                "reachable": totals.get('secrets_reachable', 0),
            },
            "cwe": {
                "total": totals.get('cwe_total', 0),
                "reachable": totals.get('cwe_reachable', 0),
            },
            "malware": totals.get('malware_count', 0),
        },
        "version": results.get('reachable_version', 'unknown'),
    }
    
    with open(output_path, 'w') as f:
        json.dump(ci_summary, f, indent=2)

def format_github_actions_output(results: Dict[str, Any]) -> str:
    """
    Format results for GitHub Actions output variables.
    
    Usage in workflow:
        echo "$(reachctl scan . --format github-actions)" >> $GITHUB_OUTPUT
    """
    summary = results.get('summary', {})
    totals = summary.get('totals', {})
    
    lines = [
        f"risk_score={summary.get('risk_score', 0):.0f}",
        f"risk_level={summary.get('risk_level', 'UNKNOWN')}",
        f"cves_reachable={totals.get('cves_reachable', 0)}",
        f"secrets_reachable={totals.get('secrets_reachable', 0)}",
        f"malware_count={totals.get('malware_count', 0)}",
        f"critical_count={totals.get('cves_critical_reachable', 0)}",
    ]
    
    return "\n".join(lines)
