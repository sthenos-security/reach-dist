# REACHABLE DLP Security Module
# Copyright (c) 2026 Sthenos Security. All rights reserved.

"""
REACHABLE DLP (Data Loss Prevention) Module

Reachability-aware detection of sensitive data exposure in source code.
Unlike traditional runtime DLP, REACHABLE DLP operates at the source level.

Key Differentiators:
- Reachability-aware: Dead code PII = LOW severity (80% noise reduction)
- Taint-based: Tracks Source → Sink flows, not just pattern matching
- AI-integrated: LLM APIs as first-class sinks (CRITICAL severity)
- Context-aware: Fixture PII ≠ production code severity

Architecture:
    File Classification → PII Discovery → Taint Analysis → Risk Scoring
                                               ↓
                                    Call Graph Integration

Usage:
    from reachable.dlp import DLPScanner, DLPScanConfig
    
    # Full scan
    scanner = DLPScanner()
    findings = scanner.scan("/path/to/repo")
    
    # With configuration
    config = DLPScanConfig.ai_focused()  # Focus on LLM sinks
    scanner = DLPScanner(config=config)
    findings = scanner.scan("/path/to/repo")
    
    # Filter by type
    ai_findings = scanner.get_ai_findings()
    taint_findings = scanner.get_taint_findings()
    critical = scanner.get_critical_findings()

Integration with Correlation Engine:
    from reachable.correlation_engine import correlate_all_signals
    
    result = correlate_all_signals(
        dlp_findings=scanner.to_correlation_format(),
        ...
    )

Version: 1.1.0 (Phase 2-4 Complete)
"""

# Core scanner
from reachable.dlp.scanner import DLPScanner, run_dlp_scan

# Configuration
from reachable.dlp.config import DLPScanConfig

# Schema (enums and dataclasses)
from reachable.dlp.schema import (
    DLPFinding,
    DLPFindingType,
    PIIEntityType,
    FileClass,
    SinkType,
    RegulationType,
    DataSensitivityTier,
    ReachabilityState,
    TIER_BASE_RISK,
    SINK_RISK_BONUS,
    PII_SENSITIVITY_TIER,
    PII_TO_REGULATIONS,
    SEVERITY_MATRIX,
)

# Discovery module (file classification only - P2.45: regex discovery removed)
from reachable.dlp.discovery.file_classifier import (
    FileClassifier,
    FileClassification,
)

# Taint analysis module (Phase 2-4)
try:
    from reachable.dlp.taint import (
        # Sources
        PIISourceType,
        PIISource,
        PYTHON_PII_SOURCES,
        TYPESCRIPT_PII_SOURCES,
        
        # Sinks
        DLPSinkType,
        DLPSink,
        PYTHON_DLP_SINKS,
        TYPESCRIPT_DLP_SINKS,
        SINK_REGULATIONS,
        SINK_RISK_SCORES,
        
        # Sanitizers
        SanitizerType,
        Sanitizer,
        PYTHON_SANITIZERS,
        TYPESCRIPT_SANITIZERS,
        
        # Flow Analysis
        DLPFlowAnalyzer,
        DLPDataFlow,
        DLPReachabilityResult,
        analyze_dlp_flows,
    )
    TAINT_AVAILABLE = True
except ImportError:
    TAINT_AVAILABLE = False

__version__ = "1.1.0"

__all__ = [
    # Core
    "DLPScanner",
    "run_dlp_scan",
    "DLPScanConfig",
    
    # Schema
    "DLPFinding",
    "DLPFindingType",
    "PIIEntityType",
    "FileClass",
    "SinkType",
    "RegulationType",
    "DataSensitivityTier",
    "ReachabilityState",
    "TIER_BASE_RISK",
    "SINK_RISK_BONUS",
    "PII_SENSITIVITY_TIER",
    "SEVERITY_MATRIX",
    "PII_TO_REGULATIONS",
    
    # Discovery (file classification only)
    "FileClassifier",
    "FileClassification",
]

# Add taint exports if available
if TAINT_AVAILABLE:
    __all__.extend([
        # Taint Sources
        "PIISourceType",
        "PIISource",
        "PYTHON_PII_SOURCES",
        "TYPESCRIPT_PII_SOURCES",
        
        # Taint Sinks
        "DLPSinkType",
        "DLPSink",
        "PYTHON_DLP_SINKS",
        "TYPESCRIPT_DLP_SINKS",
        "SINK_REGULATIONS",
        "SINK_RISK_SCORES",
        
        # Sanitizers
        "SanitizerType",
        "Sanitizer",
        "PYTHON_SANITIZERS",
        "TYPESCRIPT_SANITIZERS",
        
        # Flow Analysis
        "DLPFlowAnalyzer",
        "DLPDataFlow",
        "DLPReachabilityResult",
        "analyze_dlp_flows",
    ])
