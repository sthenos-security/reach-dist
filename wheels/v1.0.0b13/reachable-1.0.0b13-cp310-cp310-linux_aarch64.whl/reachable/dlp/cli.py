#!/usr/bin/env python3
# REACHABLE DLP Security Module - CLI
# Copyright (c) 2026 Sthenos Security. All rights reserved.

"""
DLP CLI - Command-line interface for DLP scanning.

Usage:
    # Standalone
    python -m reachable.dlp.cli scan /path/to/repo
    python -m reachable.dlp.cli scan /path/to/repo --debug
    python -m reachable.dlp.cli scan /path/to/repo --taint
    python -m reachable.dlp.cli scan /path/to/repo --ai-only
    
    # Via reachctl (when integrated)
    reachctl dlp scan /path/to/repo
    reachctl dlp scan /path/to/repo --output dlp-report.json
"""

import argparse
import sys
import json
import logging
from pathlib import Path
from typing import Optional

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(message)s',
)
logger = logging.getLogger(__name__)


def setup_debug_logging():
    """Enable debug logging."""
    logging.getLogger().setLevel(logging.DEBUG)
    logging.getLogger('reachable.dlp').setLevel(logging.DEBUG)


def cmd_scan(args):
    """Run DLP scan on repository."""
    from reachable.dlp import DLPScanner, DLPScanConfig
    from reachable.dlp.schema import DLPFindingType
    
    repo_path = Path(args.path).resolve()
    
    if not repo_path.exists():
        logger.error(f"Path does not exist: {repo_path}")
        sys.exit(1)
    
    # Configure scan
    if args.quick:
        config = DLPScanConfig.quick()
    elif args.ai_only:
        config = DLPScanConfig.ai_focused()
    elif args.pci:
        config = DLPScanConfig.pci()
    elif args.hipaa:
        config = DLPScanConfig.hipaa()
    else:
        config = DLPScanConfig.full()
    
    # Override config options
    if args.no_taint:
        config.enable_taint = False
    
    logger.info(f"")
    logger.info(f"🔍 REACHABLE DLP Scanner")
    logger.info(f"=" * 60)
    logger.info(f"Target: {repo_path}")
    logger.info(f"Config: {config.preset_name}")
    logger.info(f"")
    
    # Run scan
    scanner = DLPScanner(config=config)
    
    try:
        findings = scanner.scan(repo_path)
    except Exception as e:
        logger.error(f"Scan failed: {e}")
        if args.debug:
            import traceback
            traceback.print_exc()
        sys.exit(1)
    
    # Get statistics
    stats = scanner.statistics
    
    # Print summary
    logger.info(f"")
    logger.info(f"📊 SCAN RESULTS")
    logger.info(f"=" * 60)
    logger.info(f"Files scanned:    {stats['files_scanned']}")
    logger.info(f"Files skipped:    {stats['files_skipped']}")
    logger.info(f"Total findings:   {stats['total_findings']}")
    logger.info(f"")
    
    if stats['total_findings'] > 0:
        logger.info(f"📋 BY FINDING TYPE:")
        logger.info(f"   Taint flows:         {stats.get('taint_findings', 0)}")
        logger.info(f"   AI/LLM flows:        {stats.get('ai_findings', 0)}")
        logger.info(f"")
        
        if stats.get('by_severity'):
            logger.info(f"📊 BY SEVERITY:")
            for sev, count in sorted(stats['by_severity'].items()):
                icon = {'CRITICAL': '🔴', 'HIGH': '🟠', 'MEDIUM': '🟡', 'LOW': '🟢'}.get(sev, '⚪')
                logger.info(f"   {icon} {sev}: {count}")
            logger.info(f"")
        
        if stats.get('by_pii_type'):
            logger.info(f"🔐 BY PII TYPE:")
            for pii, count in sorted(stats['by_pii_type'].items(), key=lambda x: -x[1])[:10]:
                logger.info(f"   {pii}: {count}")
            logger.info(f"")
    
    # Show critical findings
    critical = [f for f in findings if f.adjusted_severity in ('CRITICAL', 'HIGH')]
    if critical and not args.quiet:
        logger.info(f"🚨 HIGH/CRITICAL FINDINGS ({len(critical)}):")
        logger.info(f"-" * 60)
        
        for finding in critical[:20]:  # Show top 20
            logger.info(f"")
            logger.info(f"{finding.severity_icon} [{finding.adjusted_severity}] {finding.display_pii_type}")
            logger.info(f"   Location: {finding.location}")
            logger.info(f"   Type: {finding.finding_type.value}")
            
            if finding.sink_type:
                logger.info(f"   Sink: {finding.display_sink_type}")
            
            if finding.pii_sample:
                logger.info(f"   Sample: {finding.pii_sample}")
            
            if finding.regulations:
                logger.info(f"   Regs: {', '.join(finding.regulations)}")
            
            if finding.sanitizer_present:
                logger.info(f"   ✅ Sanitizer present")
            
            if not finding.is_reachable:
                logger.info(f"   ⚠️  Not reachable (test/fixture code)")
        
        if len(critical) > 20:
            logger.info(f"")
            logger.info(f"   ... and {len(critical) - 20} more")
        
        logger.info(f"")
    
    # Save output
    if args.output:
        output_path = Path(args.output)
        scanner.save_report(output_path)
        logger.info(f"📄 Report saved to: {output_path}")
    
    # JSON output
    if args.json:
        print(scanner.to_json())
    
    # Exit code based on findings
    if args.fail_on:
        severity_order = ['LOW', 'MEDIUM', 'HIGH', 'CRITICAL']
        threshold_idx = severity_order.index(args.fail_on.upper())
        
        for finding in findings:
            finding_idx = severity_order.index(finding.adjusted_severity)
            if finding_idx >= threshold_idx:
                logger.info(f"")
                logger.info(f"❌ Findings at or above {args.fail_on.upper()} severity found")
                sys.exit(1)
    
    logger.info(f"✅ DLP scan complete")
    sys.exit(0)


def cmd_test(args):
    """Run DLP taint analysis tests."""
    from reachable.dlp import DLPScanner, DLPScanConfig
    
    logger.info(f"")
    logger.info(f"🧪 DLP Taint Analysis Tests")
    logger.info(f"=" * 60)
    logger.info(f"P2.45: PII detection via Semgrep taint analysis only.")
    logger.info(f"")
    logger.info(f"Run a full scan to verify taint detection:")
    logger.info(f"  python -m reachable.dlp.cli scan /path/to/repo")
    logger.info(f"")
    logger.info(f"Or analyze taint flows directly:")
    logger.info(f"  python -m reachable.dlp.cli flows /path/to/repo")
    
    sys.exit(0)


def cmd_flows(args):
    """Analyze taint flows in repository."""
    from reachable.dlp.taint import analyze_dlp_flows
    
    repo_path = Path(args.path).resolve()
    
    if not repo_path.exists():
        logger.error(f"Path does not exist: {repo_path}")
        sys.exit(1)
    
    logger.info(f"")
    logger.info(f"🔀 DLP Taint Flow Analysis")
    logger.info(f"=" * 60)
    logger.info(f"Target: {repo_path}")
    logger.info(f"")
    
    results = analyze_dlp_flows(repo_path, verbose=args.debug)
    
    summary = results['summary']
    
    logger.info(f"📊 FLOW SUMMARY")
    logger.info(f"-" * 40)
    logger.info(f"Files analyzed:   {results['files_analyzed']}")
    logger.info(f"Total flows:      {summary['total_flows']}")
    logger.info(f"Sanitized:        {summary['sanitized_flows']}")
    logger.info(f"Unsanitized:      {summary['unsanitized_flows']}")
    logger.info(f"High risk (≥60):  {summary['high_risk_flows']}")
    logger.info(f"Critical (≥80):   {summary['critical_flows']}")
    logger.info(f"")
    
    if summary.get('by_sink_type'):
        logger.info(f"📤 BY SINK TYPE:")
        for sink, count in sorted(summary['by_sink_type'].items(), key=lambda x: -x[1]):
            logger.info(f"   {sink}: {count}")
        logger.info(f"")
    
    if summary.get('by_pii_type'):
        logger.info(f"🔐 BY PII TYPE:")
        for pii, count in sorted(summary['by_pii_type'].items(), key=lambda x: -x[1]):
            logger.info(f"   {pii}: {count}")
        logger.info(f"")
    
    # Show critical unsanitized flows
    critical = [f for f in results['flows'] if f.final_risk >= 60 and not f.is_sanitized]
    if critical:
        logger.info(f"🚨 CRITICAL UNSANITIZED FLOWS ({len(critical)}):")
        logger.info(f"-" * 40)
        
        for flow in critical[:15]:
            logger.info(f"")
            logger.info(f"[{flow.severity}] {flow.pii_type} → {flow.sink_type}")
            logger.info(f"   File: {flow.file_path}")
            logger.info(f"   Risk: {flow.final_risk:.1f}")
            logger.info(f"   Path: {' → '.join(flow.path)}")
    
    # Save output
    if args.output:
        output_path = Path(args.output)
        output_data = {
            'summary': summary,
            'flows': [
                {
                    'flow_id': f.flow_id,
                    'pii_type': f.pii_type,
                    'sink_type': f.sink_type,
                    'file_path': f.file_path,
                    'is_sanitized': f.is_sanitized,
                    'is_reachable': f.is_reachable,
                    'risk': f.final_risk,
                    'severity': f.severity,
                }
                for f in results['flows']
            ],
        }
        output_path.write_text(json.dumps(output_data, indent=2))
        logger.info(f"")
        logger.info(f"📄 Report saved to: {output_path}")
    
    sys.exit(0)


def main():
    """Main entry point."""
    parser = argparse.ArgumentParser(
        description='REACHABLE DLP Security Scanner',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
    # Full DLP scan
    python -m reachable.dlp.cli scan /path/to/repo
    
    # Quick scan (critical PII only)
    python -m reachable.dlp.cli scan /path/to/repo --quick
    
    # AI-focused scan (PII → LLM APIs)
    python -m reachable.dlp.cli scan /path/to/repo --ai-only
    
    # PCI compliance scan
    python -m reachable.dlp.cli scan /path/to/repo --pci
    
    # Taint flow analysis only
    python -m reachable.dlp.cli flows /path/to/repo
    
    # Run pattern tests
    python -m reachable.dlp.cli test
"""
    )
    
    parser.add_argument('--debug', '-d', action='store_true',
                       help='Enable debug output')
    
    subparsers = parser.add_subparsers(dest='command', help='Commands')
    
    # scan command
    scan_parser = subparsers.add_parser('scan', help='Run DLP scan')
    scan_parser.add_argument('path', help='Repository path to scan')
    scan_parser.add_argument('--output', '-o', help='Output file for JSON report')
    scan_parser.add_argument('--quick', '-q', action='store_true',
                            help='Quick scan (critical PII only)')
    scan_parser.add_argument('--ai-only', action='store_true',
                            help='AI-focused scan (PII → LLM APIs)')
    scan_parser.add_argument('--pci', action='store_true',
                            help='PCI-DSS compliance scan')
    scan_parser.add_argument('--hipaa', action='store_true',
                            help='HIPAA compliance scan')
    scan_parser.add_argument('--no-taint', action='store_true',
                            help='Disable taint analysis')
    scan_parser.add_argument('--fail-on', choices=['low', 'medium', 'high', 'critical'],
                            help='Exit non-zero if findings at or above severity')
    scan_parser.add_argument('--json', action='store_true',
                            help='Output results as JSON')
    scan_parser.add_argument('--quiet', action='store_true',
                            help='Minimal output')
    
    # flows command
    flows_parser = subparsers.add_parser('flows', help='Analyze taint flows')
    flows_parser.add_argument('path', help='Repository path to analyze')
    flows_parser.add_argument('--output', '-o', help='Output file for JSON report')
    
    # test command
    test_parser = subparsers.add_parser('test', help='Run pattern tests')
    
    args = parser.parse_args()
    
    if args.debug:
        setup_debug_logging()
    
    if args.command == 'scan':
        cmd_scan(args)
    elif args.command == 'flows':
        cmd_flows(args)
    elif args.command == 'test':
        cmd_test(args)
    else:
        parser.print_help()
        sys.exit(1)


if __name__ == '__main__':
    main()
