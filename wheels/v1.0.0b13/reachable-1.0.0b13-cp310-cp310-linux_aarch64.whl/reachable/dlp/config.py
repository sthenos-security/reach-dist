# REACHABLE DLP Security Module - Configuration
# Copyright (c) 2026 Sthenos Security. All rights reserved.

"""
DLP Configuration - Scan configuration options.

Usage:
    from reachable.dlp import DLPScanConfig
    
    # Full scan (Semgrep taint analysis)
    config = DLPScanConfig.full()
    
    # Custom config
    config = DLPScanConfig(
        enable_taint=True,
        enable_ai_sinks=True,
        pii_types=['ssn', 'credit_card'],
        scan_fixtures=False,
    )
"""

from dataclasses import dataclass, field
from typing import List, Optional, Set
from pathlib import Path

from reachable.dlp.schema import PIIEntityType, SinkType, FileClass


@dataclass
class DLPScanConfig:
    """Configuration for DLP scanning."""
    
    # Preset name (set by factory methods)
    preset_name: str = "custom"
    
    # Feature toggles
    # P2.45: Removed regex discovery - use ONLY Semgrep for PII detection + taint
    enable_taint: bool = True              # Semgrep taint analysis (PII detection + flows)
    enable_ai_sinks: bool = True           # AI/LLM specific sinks
    enable_context_scoring: bool = True    # Context-aware severity
    
    # PII types to detect (None = all)
    pii_types: Optional[List[str]] = None
    
    # Sink types to track (None = all)
    sink_types: Optional[List[str]] = None
    
    # File handling
    scan_fixtures: bool = True             # Scan fixtures/, testdata/, seed/
    scan_generated: bool = False           # Scan node_modules/, vendor/
    scan_docs: bool = False                # Scan .md, .ipynb files
    scan_data_files: bool = True           # Scan .csv, .json, .sql files
    
    # Exclusions
    exclude_paths: List[str] = field(default_factory=list)
    exclude_patterns: List[str] = field(default_factory=list)
    
    # Severity thresholds
    min_severity: str = "LOW"              # LOW, MEDIUM, HIGH, CRITICAL
    min_confidence: str = "LOW"            # LOW, MEDIUM, HIGH
    
    # Performance
    timeout_seconds: int = 300             # 5 minute default
    max_file_size_kb: int = 10240          # 10MB max file size
    parallel_workers: int = 4              # Parallel file processing
    
    # Output
    include_samples: bool = True           # Include redacted PII samples
    sample_max_length: int = 20            # Max length of samples
    
    # Integration
    check_presidio: bool = True            # Check if Presidio is installed
    check_sanitizers: bool = True          # Detect sanitizer usage
    
    # Debug
    verbose: bool = False
    debug: bool = False
    
    def __post_init__(self):
        """Validate configuration."""
        if self.pii_types:
            valid_types = {t.value for t in PIIEntityType}
            for pt in self.pii_types:
                if pt.lower() not in valid_types:
                    raise ValueError(f"Invalid PII type: {pt}. Valid: {valid_types}")
        
        if self.sink_types:
            valid_sinks = {s.value for s in SinkType}
            for st in self.sink_types:
                if st.lower() not in valid_sinks:
                    raise ValueError(f"Invalid sink type: {st}. Valid: {valid_sinks}")
    
    @classmethod
    def full(cls) -> "DLPScanConfig":
        """Full scan configuration (Semgrep taint analysis)."""
        return cls(
            preset_name="full",
            enable_taint=True,
            enable_ai_sinks=True,
            enable_context_scoring=True,
            scan_fixtures=True,
            scan_data_files=True,
            check_presidio=True,
            check_sanitizers=True,
        )
    
    @classmethod
    def quick(cls) -> "DLPScanConfig":
        """Quick scan (critical PII only, no fixtures)."""
        return cls(
            preset_name="quick",
            enable_taint=True,
            enable_ai_sinks=True,
            enable_context_scoring=False,
            pii_types=['ssn', 'credit_card', 'bank_account', 'password'],
            scan_fixtures=False,
            scan_data_files=False,
            min_severity="HIGH",
        )
    
    @classmethod
    def ai_focused(cls) -> "DLPScanConfig":
        """AI/LLM focused scan (detects PII flowing to LLM APIs)."""
        return cls(
            preset_name="ai_focused",
            enable_taint=True,
            enable_ai_sinks=True,
            enable_context_scoring=True,
            sink_types=['llm_api', 'vector_store'],
            scan_fixtures=False,
        )
    
    @classmethod
    def pci(cls) -> "DLPScanConfig":
        """PCI-DSS focused scan (credit cards, bank accounts)."""
        return cls(
            preset_name="pci",
            enable_taint=True,
            enable_ai_sinks=True,
            enable_context_scoring=True,
            pii_types=['credit_card', 'bank_account', 'cvv', 'routing_number', 'iban'],
            scan_fixtures=True,
            scan_data_files=True,
        )
    
    @classmethod
    def hipaa(cls) -> "DLPScanConfig":
        """HIPAA focused scan (health information)."""
        return cls(
            preset_name="hipaa",
            enable_taint=True,
            enable_ai_sinks=True,
            enable_context_scoring=True,
            pii_types=['mrn', 'icd10', 'npi', 'diagnosis', 'dob'],
            scan_fixtures=True,
            scan_data_files=True,
        )
    
    def get_pii_types(self) -> Set[PIIEntityType]:
        """Get PII types to scan for."""
        if self.pii_types:
            return {PIIEntityType(pt.lower()) for pt in self.pii_types}
        return set(PIIEntityType)
    
    def get_sink_types(self) -> Set[SinkType]:
        """Get sink types to track."""
        if self.sink_types:
            return {SinkType(st.lower()) for st in self.sink_types}
        return set(SinkType)
    
    def should_scan_file(self, file_path: Path, file_class: FileClass) -> bool:
        """Determine if a file should be scanned based on config."""
        # Check exclusions
        path_str = str(file_path)
        for excl in self.exclude_paths:
            if excl in path_str:
                return False
        for pattern in self.exclude_patterns:
            if file_path.match(pattern):
                return False
        
        # Check by file class
        if file_class == FileClass.FIXTURE and not self.scan_fixtures:
            return False
        if file_class == FileClass.GENERATED and not self.scan_generated:
            return False
        if file_class == FileClass.DOCS and not self.scan_docs:
            return False
        if file_class == FileClass.DATA_ARTIFACT and not self.scan_data_files:
            return False
        
        return True
    
    def to_dict(self) -> dict:
        """Convert to dictionary for serialization."""
        return {
            "enable_taint": self.enable_taint,
            "enable_ai_sinks": self.enable_ai_sinks,
            "enable_context_scoring": self.enable_context_scoring,
            "pii_types": self.pii_types,
            "sink_types": self.sink_types,
            "scan_fixtures": self.scan_fixtures,
            "scan_generated": self.scan_generated,
            "scan_docs": self.scan_docs,
            "scan_data_files": self.scan_data_files,
            "exclude_paths": self.exclude_paths,
            "exclude_patterns": self.exclude_patterns,
            "min_severity": self.min_severity,
            "min_confidence": self.min_confidence,
            "timeout_seconds": self.timeout_seconds,
            "max_file_size_kb": self.max_file_size_kb,
            "parallel_workers": self.parallel_workers,
            "include_samples": self.include_samples,
            "sample_max_length": self.sample_max_length,
            "check_presidio": self.check_presidio,
            "check_sanitizers": self.check_sanitizers,
            "verbose": self.verbose,
            "debug": self.debug,
        }
