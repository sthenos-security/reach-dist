# REACHABLE DLP Security Module - File Classifier
# Copyright (c) 2026 Sthenos Security. All rights reserved.

"""
File Classifier - Classify files by type and purpose for context-aware scanning.

File classification is critical for DLP because:
- Fixture/test data should have lower severity than production code
- Data artifacts (.csv, .json) need different scanning than source code
- Generated/vendor code should typically be skipped

Usage:
    from reachable.dlp.discovery import FileClassifier, classify_file
    
    # Quick classification
    file_class = classify_file(Path("fixtures/users.csv"))
    # Returns: FileClass.FIXTURE
    
    # Full classification with metadata
    classifier = FileClassifier()
    result = classifier.classify(Path("api/users.py"))
    # Returns: FileClassification(file_class=FileClass.SOURCE, ...)
"""

from dataclasses import dataclass
from typing import Optional, List, Set
from pathlib import Path
import re

from reachable.dlp.schema import FileClass


# Risk modifiers by file class (multiplier for severity)
FILE_CLASS_MODIFIERS = {
    FileClass.SOURCE: 1.0,           # Normal severity
    FileClass.FIXTURE: 0.3,          # 70% severity reduction for test data
    FileClass.DATA_ARTIFACT: 0.8,    # Slight reduction for data files
    FileClass.DOCS: 0.5,             # 50% reduction for docs
    FileClass.CONFIG: 0.9,           # Slight reduction for config
    FileClass.GENERATED: 0.0,        # Skip generated code
}


# Path patterns that indicate fixtures/test data
FIXTURE_PATTERNS: List[str] = [
    r"fixtures?/",
    r"test_?data/",
    r"seed/",
    r"seeds/",
    r"dumps?/",
    r"samples?/",
    r"mock_?data/",
    r"stubs?/",
    r"__fixtures__/",
    r"__mocks__/",
    r"factory/",
    r"factories/",
]

# Path patterns that indicate generated/vendor code
GENERATED_PATTERNS: List[str] = [
    r"node_modules/",
    r"vendor/",
    r"\.venv/",
    r"venv/",
    r"env/",
    r"\.git/",
    r"__pycache__/",
    r"\.cache/",
    r"dist/",
    r"build/",
    r"\.next/",
    r"\.nuxt/",
    r"target/",
    r"\.gradle/",
    r"\.m2/",
    r"Pods/",
    r"\.idea/",
    r"\.vscode/",
]

# Path patterns that indicate documentation
DOCS_PATTERNS: List[str] = [
    r"docs?/",
    r"documentation/",
    r"wiki/",
    r"README",
    r"CHANGELOG",
    r"LICENSE",
    r"\.github/",
]

# File extensions for data artifacts
DATA_ARTIFACT_EXTENSIONS: Set[str] = {
    ".csv",
    ".tsv",
    ".json",
    ".jsonl",
    ".ndjson",
    ".xml",
    ".sql",
    ".dump",
    ".sqlite",
    ".db",
    ".parquet",
    ".avro",
    ".xlsx",
    ".xls",
    ".ods",
}

# File extensions for documentation
DOCS_EXTENSIONS: Set[str] = {
    ".md",
    ".rst",
    ".txt",
    ".ipynb",
    ".pdf",
    ".doc",
    ".docx",
}

# File extensions for source code
SOURCE_EXTENSIONS: Set[str] = {
    ".py",
    ".js",
    ".ts",
    ".jsx",
    ".tsx",
    ".go",
    ".java",
    ".kt",
    ".scala",
    ".rb",
    ".php",
    ".rs",
    ".c",
    ".cpp",
    ".cs",
    ".swift",
    ".m",
    ".sh",
    ".bash",
}

# File extensions for config files
CONFIG_EXTENSIONS: Set[str] = {
    ".yaml",
    ".yml",
    ".toml",
    ".ini",
    ".conf",
    ".config",
    ".env",
    ".properties",
}


@dataclass
class FileClassification:
    """Result of file classification."""
    file_path: Path
    file_class: FileClass
    risk_modifier: float
    scan_strategy: str
    reason: str
    is_text: bool = True
    encoding: str = "utf-8"
    
    @property
    def should_scan(self) -> bool:
        """Whether this file should be scanned (not generated)."""
        return self.file_class != FileClass.GENERATED


class FileClassifier:
    """
    Classify files for context-aware DLP scanning.
    
    Classification determines:
    - File class (source, fixture, data artifact, etc.)
    - Risk modifier (fixture = lower severity)
    - Scan strategy (pattern matching vs taint analysis)
    """
    
    def __init__(
        self,
        additional_fixture_patterns: Optional[List[str]] = None,
        additional_skip_patterns: Optional[List[str]] = None,
    ):
        """
        Initialize classifier.
        
        Args:
            additional_fixture_patterns: Extra patterns to identify fixtures
            additional_skip_patterns: Extra patterns to skip
        """
        # Compile patterns for efficiency
        self._fixture_patterns = [
            re.compile(p, re.IGNORECASE) 
            for p in FIXTURE_PATTERNS + (additional_fixture_patterns or [])
        ]
        self._generated_patterns = [
            re.compile(p, re.IGNORECASE)
            for p in GENERATED_PATTERNS + (additional_skip_patterns or [])
        ]
        self._docs_patterns = [
            re.compile(p, re.IGNORECASE)
            for p in DOCS_PATTERNS
        ]
    
    def classify(self, file_path: Path) -> FileClassification:
        """
        Classify a file by its path and extension.
        
        Args:
            file_path: Path to the file
            
        Returns:
            FileClassification with class, modifier, and scan strategy
        """
        path_str = str(file_path)
        suffix = file_path.suffix.lower()
        
        # Check generated/vendor first (skip these)
        for pattern in self._generated_patterns:
            if pattern.search(path_str):
                return FileClassification(
                    file_path=file_path,
                    file_class=FileClass.GENERATED,
                    risk_modifier=FILE_CLASS_MODIFIERS[FileClass.GENERATED],
                    scan_strategy="skip",
                    reason=f"Generated/vendor code: {pattern.pattern}",
                    is_text=True,
                )
        
        # Check fixtures/test data
        for pattern in self._fixture_patterns:
            if pattern.search(path_str):
                return FileClassification(
                    file_path=file_path,
                    file_class=FileClass.FIXTURE,
                    risk_modifier=FILE_CLASS_MODIFIERS[FileClass.FIXTURE],
                    scan_strategy="pii_discovery",
                    reason=f"Test/fixture data: {pattern.pattern}",
                    is_text=True,
                )
        
        # Check documentation
        for pattern in self._docs_patterns:
            if pattern.search(path_str):
                return FileClassification(
                    file_path=file_path,
                    file_class=FileClass.DOCS,
                    risk_modifier=FILE_CLASS_MODIFIERS[FileClass.DOCS],
                    scan_strategy="pii_discovery",
                    reason=f"Documentation: {pattern.pattern}",
                    is_text=True,
                )
        
        # Classify by extension
        if suffix in DATA_ARTIFACT_EXTENSIONS:
            return FileClassification(
                file_path=file_path,
                file_class=FileClass.DATA_ARTIFACT,
                risk_modifier=FILE_CLASS_MODIFIERS[FileClass.DATA_ARTIFACT],
                scan_strategy="pii_discovery",
                reason=f"Data artifact: {suffix}",
                is_text=suffix not in {".parquet", ".avro", ".xlsx", ".xls", ".db", ".sqlite"},
            )
        
        if suffix in DOCS_EXTENSIONS:
            return FileClassification(
                file_path=file_path,
                file_class=FileClass.DOCS,
                risk_modifier=FILE_CLASS_MODIFIERS[FileClass.DOCS],
                scan_strategy="pii_discovery",
                reason=f"Documentation: {suffix}",
                is_text=suffix not in {".pdf", ".doc", ".docx"},
            )
        
        if suffix in CONFIG_EXTENSIONS:
            return FileClassification(
                file_path=file_path,
                file_class=FileClass.CONFIG,
                risk_modifier=FILE_CLASS_MODIFIERS.get(FileClass.CONFIG, 0.9),
                scan_strategy="pii_discovery",
                reason=f"Configuration: {suffix}",
                is_text=True,
            )
        
        if suffix in SOURCE_EXTENSIONS:
            return FileClassification(
                file_path=file_path,
                file_class=FileClass.SOURCE,
                risk_modifier=FILE_CLASS_MODIFIERS[FileClass.SOURCE],
                scan_strategy="taint_analysis",
                reason=f"Source code: {suffix}",
                is_text=True,
            )
        
        # Default: treat as source if it looks like text
        return FileClassification(
            file_path=file_path,
            file_class=FileClass.SOURCE,
            risk_modifier=1.0,
            scan_strategy="pii_discovery",
            reason="Unknown file type, treating as text",
            is_text=True,
        )
    
    def classify_directory(self, dir_path: Path) -> List[FileClassification]:
        """
        Classify all files in a directory tree.
        
        Args:
            dir_path: Path to directory
            
        Returns:
            List of FileClassification for each file
        """
        results = []
        
        for file_path in dir_path.rglob("*"):
            if file_path.is_file():
                classification = self.classify(file_path)
                results.append(classification)
        
        return results
    
    def get_scannable_files(
        self,
        dir_path: Path,
        include_fixtures: bool = True,
        include_data_files: bool = True,
        include_docs: bool = False,
    ) -> List[FileClassification]:
        """
        Get list of files that should be scanned.
        
        Args:
            dir_path: Path to directory
            include_fixtures: Whether to include fixture files
            include_data_files: Whether to include data artifacts
            include_docs: Whether to include documentation
            
        Returns:
            List of FileClassification for scannable files
        """
        all_files = self.classify_directory(dir_path)
        
        scannable = []
        for fc in all_files:
            # Skip generated
            if fc.file_class == FileClass.GENERATED:
                continue
            
            # Skip based on options
            if fc.file_class == FileClass.FIXTURE and not include_fixtures:
                continue
            if fc.file_class == FileClass.DATA_ARTIFACT and not include_data_files:
                continue
            if fc.file_class == FileClass.DOCS and not include_docs:
                continue
            
            scannable.append(fc)
        
        return scannable
    
    @staticmethod
    def is_binary_file(file_path: Path) -> bool:
        """
        Check if a file appears to be binary.
        
        Args:
            file_path: Path to file
            
        Returns:
            True if file appears to be binary
        """
        binary_extensions = {
            ".exe", ".dll", ".so", ".dylib",
            ".png", ".jpg", ".jpeg", ".gif", ".ico", ".webp",
            ".mp3", ".mp4", ".wav", ".avi", ".mov",
            ".zip", ".tar", ".gz", ".bz2", ".7z",
            ".pdf", ".doc", ".docx", ".xls", ".xlsx",
            ".pyc", ".pyo", ".class",
            ".o", ".a", ".lib",
            ".whl", ".egg",
        }
        
        if file_path.suffix.lower() in binary_extensions:
            return True
        
        # Check file content for binary data
        try:
            with open(file_path, "rb") as f:
                chunk = f.read(1024)
                if b'\x00' in chunk:
                    return True
        except:
            pass
        
        return False


def classify_file(file_path: Path) -> FileClass:
    """
    Quick classification of a single file.
    
    Args:
        file_path: Path to file
        
    Returns:
        FileClass enum value
    """
    classifier = FileClassifier()
    result = classifier.classify(file_path)
    return result.file_class


def is_fixture_file(file_path: Path) -> bool:
    """Check if a file is in a fixture/test data directory."""
    return classify_file(file_path) == FileClass.FIXTURE


def is_source_file(file_path: Path) -> bool:
    """Check if a file is source code."""
    return classify_file(file_path) == FileClass.SOURCE


def get_risk_modifier(file_path: Path) -> float:
    """Get risk modifier for a file based on its classification."""
    classifier = FileClassifier()
    result = classifier.classify(file_path)
    return result.risk_modifier
