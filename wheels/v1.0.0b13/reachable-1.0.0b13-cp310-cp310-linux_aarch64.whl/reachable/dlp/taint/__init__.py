# REACHABLE DLP Security Module - Taint Analysis
# Copyright (c) 2026 Sthenos Security. All rights reserved.

"""
DLP Taint Analysis - Track PII data flows from sources to sinks.

Follows the same architecture as AI Reachability Analyzer:
    PII Sources → [Taint Tracking] → Sanitizers? → Dangerous Sinks
                                          ↓
                                    Risk Adjustment

This module provides:
- PII-aware taint sources (user data, database queries, form inputs)
- DLP-specific sinks (logs, external APIs, LLM APIs, analytics)
- Sanitizer detection (Presidio, scrubadub, masking functions)
- AST-based flow tracking with call graph integration
"""

from reachable.dlp.taint.sources import (
    PIISourceType,
    PIISource,
    PYTHON_PII_SOURCES,
    TYPESCRIPT_PII_SOURCES,
)
from reachable.dlp.taint.sinks import (
    DLPSinkType,
    DLPSink,
    PYTHON_DLP_SINKS,
    TYPESCRIPT_DLP_SINKS,
    SINK_REGULATIONS,
    SINK_RISK_SCORES,
)
from reachable.dlp.taint.sanitizers import (
    SanitizerType,
    Sanitizer,
    PYTHON_SANITIZERS,
    TYPESCRIPT_SANITIZERS,
)
from reachable.dlp.taint.flow_analyzer import (
    DLPFlowAnalyzer,
    DLPDataFlow,
    DLPReachabilityResult,
    analyze_dlp_flows,
)

__all__ = [
    # Sources
    'PIISourceType',
    'PIISource',
    'PYTHON_PII_SOURCES',
    'TYPESCRIPT_PII_SOURCES',
    
    # Sinks
    'DLPSinkType',
    'DLPSink',
    'PYTHON_DLP_SINKS',
    'TYPESCRIPT_DLP_SINKS',
    'SINK_REGULATIONS',
    'SINK_RISK_SCORES',
    
    # Sanitizers
    'SanitizerType',
    'Sanitizer',
    'PYTHON_SANITIZERS',
    'TYPESCRIPT_SANITIZERS',
    
    # Flow Analysis
    'DLPFlowAnalyzer',
    'DLPDataFlow',
    'DLPReachabilityResult',
    'analyze_dlp_flows',
]
