# REACHABLE DLP Security Module - DLP Taint Sinks
# Copyright (c) 2026 Sthenos Security. All rights reserved.

"""
DLP Taint Sinks - Dangerous destinations for PII data.

Categories:
- Logging: print, logger.*, console.*
- External APIs: requests.post, fetch
- LLM/AI APIs: openai.*, anthropic.*, langchain
- Analytics: segment, mixpanel, amplitude
- Vector Stores: chromadb, pinecone (RAG risk)
- File/Storage: open().write, S3 upload

Severity based on exposure risk:
- LLM_API: CRITICAL (data leaves org, stored by 3rd party)
- EXTERNAL_API: HIGH (data leaves org)
- ANALYTICS: HIGH (often unencrypted, 3rd party)
- VECTOR_STORE: HIGH (RAG retrieval exposes to future queries)
- LOG: MEDIUM (internal, but may be aggregated externally)
- DATABASE: LOW-MEDIUM (internal storage)
"""

from dataclasses import dataclass
from enum import Enum
from typing import List, Dict, Set

from reachable.logger import logger


class DLPSinkType(Enum):
    """Types of dangerous DLP sinks."""
    
    # Logging (often aggregated to cloud services)
    LOG = "log"                          # logger.*, print()
    CONSOLE = "console"                  # console.log, console.error
    
    # External APIs
    EXTERNAL_API = "external_api"        # requests.post, fetch
    WEBHOOK = "webhook"                  # Outbound webhooks
    
    # AI/LLM APIs (CRITICAL - data leaves org + stored by 3rd party)
    LLM_API = "llm_api"                  # openai.*, anthropic.*
    LLM_PROMPT = "llm_prompt"            # User content in prompts
    LLM_EMBEDDING = "llm_embedding"      # Embedding generation (reveals content)
    
    # Vector Stores (RAG risk - future queries may expose PII)
    VECTOR_STORE = "vector_store"        # chromadb, pinecone, weaviate
    
    # Analytics (often unencrypted, long retention)
    ANALYTICS = "analytics"              # segment, mixpanel, amplitude
    TELEMETRY = "telemetry"              # Application telemetry
    
    # Storage
    FILE_WRITE = "file_write"            # Writing to files
    DATABASE = "database"                # Database inserts/updates
    CACHE = "cache"                      # Redis, memcached
    
    # Communication
    EMAIL = "email"                      # SMTP, SendGrid, etc.
    SMS = "sms"                          # Twilio, etc.
    SLACK = "slack"                      # Slack webhooks/API
    
    # Error tracking (often includes request data)
    ERROR_TRACKER = "error_tracker"      # Sentry, Rollbar, Bugsnag


@dataclass
class DLPSink:
    """A dangerous sink for PII data."""
    sink_type: DLPSinkType
    location: str                        # file:line
    function: str                        # Function being called
    argument: str = ""                   # Which argument receives PII
    confidence: float = 1.0
    context: str = ""                    # Surrounding code context


# =============================================================================
# SINK RISK SCORES (0-100)
# =============================================================================

SINK_RISK_SCORES: Dict[DLPSinkType, int] = {
    # CRITICAL - Data leaves organization + stored by 3rd party
    DLPSinkType.LLM_API: 100,
    DLPSinkType.LLM_PROMPT: 100,
    DLPSinkType.LLM_EMBEDDING: 90,
    
    # HIGH - Data leaves organization
    DLPSinkType.EXTERNAL_API: 85,
    DLPSinkType.ANALYTICS: 80,
    DLPSinkType.VECTOR_STORE: 80,
    DLPSinkType.WEBHOOK: 75,
    DLPSinkType.ERROR_TRACKER: 70,
    DLPSinkType.EMAIL: 70,
    DLPSinkType.SMS: 70,
    DLPSinkType.SLACK: 65,
    DLPSinkType.TELEMETRY: 60,
    
    # MEDIUM - Internal but may be exposed
    DLPSinkType.LOG: 50,
    DLPSinkType.CONSOLE: 45,
    DLPSinkType.FILE_WRITE: 40,
    
    # LOW - Internal storage
    DLPSinkType.DATABASE: 30,
    DLPSinkType.CACHE: 25,
}


# =============================================================================
# SINK TO REGULATION MAPPING
# =============================================================================

SINK_REGULATIONS: Dict[DLPSinkType, List[str]] = {
    DLPSinkType.LLM_API: ['GDPR', 'CCPA', 'HIPAA'],  # AI Act too
    DLPSinkType.LLM_PROMPT: ['GDPR', 'CCPA', 'HIPAA'],
    DLPSinkType.LLM_EMBEDDING: ['GDPR', 'CCPA'],
    DLPSinkType.EXTERNAL_API: ['GDPR', 'CCPA', 'PCI-DSS'],
    DLPSinkType.ANALYTICS: ['GDPR', 'CCPA'],
    DLPSinkType.VECTOR_STORE: ['GDPR', 'CCPA', 'HIPAA'],
    DLPSinkType.LOG: ['GDPR', 'PCI-DSS'],
    DLPSinkType.EMAIL: ['GDPR', 'CCPA', 'HIPAA'],
    DLPSinkType.DATABASE: ['GDPR', 'PCI-DSS', 'HIPAA'],
    DLPSinkType.ERROR_TRACKER: ['GDPR', 'CCPA'],
}


# =============================================================================
# PYTHON DLP SINK PATTERNS
# =============================================================================

PYTHON_DLP_SINKS: Dict[DLPSinkType, List[str]] = {
    # Logging
    DLPSinkType.LOG: [
        r'\blogger\.debug\s*\(',
        r'\blogger\.info\s*\(',
        r'\blogger\.warning\s*\(',
        r'\blogger\.error\s*\(',
        r'\blogger\.critical\s*\(',
        r'\blogger\.exception\s*\(',
        r'\blogging\.debug\s*\(',
        r'\blogging\.info\s*\(',
        r'\blogging\.warning\s*\(',
        r'\blogging\.error\s*\(',
        r'\bprint\s*\(',
        r'\bpprint\s*\(',
    ],
    DLPSinkType.CONSOLE: [
        r'\bprint\s*\(',
        r'\bsys\.stdout\.write\s*\(',
        r'\bsys\.stderr\.write\s*\(',
    ],
    
    # External APIs
    DLPSinkType.EXTERNAL_API: [
        r'requests\.post\s*\(',
        r'requests\.put\s*\(',
        r'requests\.patch\s*\(',
        r'httpx\.post\s*\(',
        r'httpx\.put\s*\(',
        r'aiohttp\.\w+\.post\s*\(',
        r'urllib\.request\.urlopen\s*\(',
        r'http\.client\.\w+\.request\s*\(',
    ],
    DLPSinkType.WEBHOOK: [
        r'webhook\s*[=\.]\s*',
        r'\.send_webhook\s*\(',
        r'post_to_webhook\s*\(',
    ],
    
    # LLM/AI APIs
    DLPSinkType.LLM_API: [
        # OpenAI
        r'openai\.ChatCompletion\.create\s*\(',
        r'openai\.chat\.completions\.create\s*\(',
        r'client\.chat\.completions\.create\s*\(',
        r'\.chat\.completions\.create\s*\(',
        # Anthropic
        r'anthropic\.messages\.create\s*\(',
        r'client\.messages\.create\s*\(',
        r'\.messages\.create\s*\(',
        # LangChain
        r'llm\.invoke\s*\(',
        r'llm\s*\(\s*',
        r'chain\.run\s*\(',
        r'chain\.invoke\s*\(',
        r'ChatOpenAI\s*\(',
        r'ChatAnthropic\s*\(',
        # Generic
        r'\.generate\s*\(',
        r'\.complete\s*\(',
        r'\.predict\s*\(',
    ],
    DLPSinkType.LLM_EMBEDDING: [
        r'openai\.embeddings\.create\s*\(',
        r'\.embed_query\s*\(',
        r'\.embed_documents\s*\(',
        r'OpenAIEmbeddings\s*\(',
        r'HuggingFaceEmbeddings\s*\(',
    ],
    
    # Vector Stores
    DLPSinkType.VECTOR_STORE: [
        # ChromaDB
        r'\.add_documents\s*\(',
        r'\.add_texts\s*\(',
        r'collection\.add\s*\(',
        r'chromadb\.\w+\.add\s*\(',
        # Pinecone
        r'pinecone\.\w+\.upsert\s*\(',
        r'index\.upsert\s*\(',
        # Weaviate
        r'weaviate\.\w+\.create\s*\(',
        r'client\.data_object\.create\s*\(',
        # FAISS
        r'faiss\.IndexFlatL2\s*\(',
        r'\.add_vectors\s*\(',
        # Generic LangChain
        r'vectorstore\.add\s*\(',
        r'\.from_documents\s*\(',
    ],
    
    # Analytics
    DLPSinkType.ANALYTICS: [
        r'analytics\.track\s*\(',
        r'analytics\.identify\s*\(',
        r'segment\.track\s*\(',
        r'segment\.identify\s*\(',
        r'mixpanel\.track\s*\(',
        r'mixpanel\.people\.set\s*\(',
        r'amplitude\.track\s*\(',
        r'posthog\.capture\s*\(',
    ],
    DLPSinkType.TELEMETRY: [
        r'opentelemetry\.\w+\.record\s*\(',
        r'tracer\.start_span\s*\(',
        r'meter\.create_counter\s*\(',
    ],
    
    # Storage
    DLPSinkType.FILE_WRITE: [
        r'open\s*\([^)]+["\']w',
        r'\.write\s*\(',
        r'\.writelines\s*\(',
        r'Path\s*\([^)]+\)\.write_text\s*\(',
        r'json\.dump\s*\(',
        r'\.to_csv\s*\(',
        r'\.to_json\s*\(',
        r's3\.put_object\s*\(',
        r's3\.upload_file\s*\(',
    ],
    DLPSinkType.DATABASE: [
        r'cursor\.execute\s*\(',
        r'session\.add\s*\(',
        r'session\.commit\s*\(',
        r'\.insert\s*\(',
        r'\.update\s*\(',
        r'db\.execute\s*\(',
        r'\.bulk_insert\s*\(',
    ],
    DLPSinkType.CACHE: [
        r'redis\.set\s*\(',
        r'redis\.hset\s*\(',
        r'cache\.set\s*\(',
        r'memcache\.set\s*\(',
    ],
    
    # Communication
    DLPSinkType.EMAIL: [
        r'smtp\.send_message\s*\(',
        r'sendgrid\.send\s*\(',
        r'mail\.send\s*\(',
        r'send_mail\s*\(',
        r'EmailMessage\s*\(',
    ],
    DLPSinkType.SMS: [
        r'twilio\.messages\.create\s*\(',
        r'\.send_sms\s*\(',
        r'sns\.publish\s*\(',
    ],
    DLPSinkType.SLACK: [
        r'slack\.chat_postMessage\s*\(',
        r'slack_client\.chat_postMessage\s*\(',
        r'WebhookClient\s*\([^)]+\)\.send\s*\(',
        r'requests\.post\s*\([^)]*slack[^)]*\)',
    ],
    
    # Error tracking
    DLPSinkType.ERROR_TRACKER: [
        r'sentry_sdk\.capture_message\s*\(',
        r'sentry_sdk\.capture_exception\s*\(',
        r'sentry_sdk\.set_user\s*\(',
        r'sentry_sdk\.set_context\s*\(',
        r'rollbar\.report_message\s*\(',
        r'bugsnag\.notify\s*\(',
        r'raygun\.send\s*\(',
    ],
}


# =============================================================================
# TYPESCRIPT/JAVASCRIPT DLP SINK PATTERNS
# =============================================================================

TYPESCRIPT_DLP_SINKS: Dict[DLPSinkType, List[str]] = {
    # Logging
    DLPSinkType.CONSOLE: [
        r'console\.log\s*\(',
        r'console\.info\s*\(',
        r'console\.warn\s*\(',
        r'console\.error\s*\(',
        r'console\.debug\s*\(',
    ],
    DLPSinkType.LOG: [
        r'logger\.log\s*\(',
        r'logger\.info\s*\(',
        r'logger\.warn\s*\(',
        r'logger\.error\s*\(',
        r'winston\.log\s*\(',
        r'pino\.\w+\s*\(',
    ],
    
    # External APIs
    DLPSinkType.EXTERNAL_API: [
        r'fetch\s*\(',
        r'axios\.post\s*\(',
        r'axios\.put\s*\(',
        r'axios\.patch\s*\(',
        r'got\.post\s*\(',
        r'superagent\.post\s*\(',
    ],
    
    # LLM/AI APIs
    DLPSinkType.LLM_API: [
        r'openai\.chat\.completions\.create\s*\(',
        r'anthropic\.messages\.create\s*\(',
        r'generateText\s*\(',
        r'streamText\s*\(',
        r'generateObject\s*\(',
        r'\.invoke\s*\(',
    ],
    
    # Analytics
    DLPSinkType.ANALYTICS: [
        r'analytics\.track\s*\(',
        r'analytics\.identify\s*\(',
        r'segment\.track\s*\(',
        r'mixpanel\.track\s*\(',
        r'amplitude\.track\s*\(',
        r'posthog\.capture\s*\(',
    ],
    
    # Error tracking
    DLPSinkType.ERROR_TRACKER: [
        r'Sentry\.captureMessage\s*\(',
        r'Sentry\.captureException\s*\(',
        r'Sentry\.setUser\s*\(',
        r'Bugsnag\.notify\s*\(',
    ],
}


def get_sink_severity(sink_type: DLPSinkType) -> str:
    """Get severity level for a sink type."""
    score = SINK_RISK_SCORES.get(sink_type, 50)
    
    if score >= 90:
        return 'CRITICAL'
    elif score >= 70:
        return 'HIGH'
    elif score >= 40:
        return 'MEDIUM'
    else:
        return 'LOW'


def get_sink_regulations(sink_type: DLPSinkType) -> List[str]:
    """Get applicable regulations for a sink type."""
    return SINK_REGULATIONS.get(sink_type, ['GDPR'])


def is_llm_sink(sink_type: DLPSinkType) -> bool:
    """Check if a sink type is an LLM/AI sink."""
    LLM_SINKS = {
        DLPSinkType.LLM_API,
        DLPSinkType.LLM_PROMPT,
        DLPSinkType.LLM_EMBEDDING,
        DLPSinkType.VECTOR_STORE,
    }
    return sink_type in LLM_SINKS
