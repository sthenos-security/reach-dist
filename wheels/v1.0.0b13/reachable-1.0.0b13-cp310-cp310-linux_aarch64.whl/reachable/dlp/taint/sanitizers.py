# REACHABLE DLP Security Module - DLP Sanitizers
# Copyright (c) 2026 Sthenos Security. All rights reserved.

"""
DLP Sanitizers - Functions that reduce PII exposure risk.

Sanitizers transform or remove PII before it reaches dangerous sinks.
Detection of sanitizers on a data flow path reduces the risk score.

Categories:
- Masking: mask(), redact(), anonymize()
- Encryption: encrypt(), hash()
- Tokenization: tokenize(), pseudonymize()
- Validation: validate(), filter()
- PII-specific: Presidio, scrubadub, Microsoft Presidio

Effectiveness ratings (0.0-1.0):
- 0.9: Full anonymization (Presidio, differential privacy)
- 0.7: Strong masking (hash, encrypt)
- 0.5: Partial masking (last 4 digits, email domain)
- 0.3: Validation (length check, format check)
"""

from dataclasses import dataclass
from enum import Enum
from typing import List, Dict, Tuple


class SanitizerType(Enum):
    """Types of PII sanitizers."""
    
    # Full anonymization
    PRESIDIO = "presidio"                # Microsoft Presidio
    SCRUBADUB = "scrubadub"              # Scrubadub library
    FAKER = "faker"                      # Data generation/replacement
    DIFFERENTIAL_PRIVACY = "diff_privacy" # DP mechanisms
    
    # Masking
    MASK = "mask"                        # Generic masking
    REDACT = "redact"                    # Full redaction
    TRUNCATE = "truncate"                # Truncation
    
    # Cryptographic
    HASH = "hash"                        # Hashing (SHA, MD5)
    ENCRYPT = "encrypt"                  # Encryption (AES, RSA)
    HMAC = "hmac"                        # HMAC for tokens
    
    # Tokenization
    TOKENIZE = "tokenize"                # Token replacement
    PSEUDONYMIZE = "pseudonymize"        # Pseudonymization
    
    # Validation/Filtering
    VALIDATE = "validate"                # Input validation
    FILTER = "filter"                    # Content filtering
    ALLOWLIST = "allowlist"              # Allowlist filtering
    
    # Format-specific
    EMAIL_MASK = "email_mask"            # j***@example.com
    PHONE_MASK = "phone_mask"            # (***) ***-1234
    SSN_MASK = "ssn_mask"                # ***-**-1234
    CC_MASK = "cc_mask"                  # ****-****-****-1234


@dataclass
class Sanitizer:
    """A sanitizer on a data flow path."""
    sanitizer_type: SanitizerType
    location: str                        # file:line
    function: str                        # Function name
    effectiveness: float                 # 0.0-1.0 risk reduction
    confidence: float = 1.0
    context: str = ""                    # Surrounding code


# =============================================================================
# SANITIZER EFFECTIVENESS RATINGS
# =============================================================================

SANITIZER_EFFECTIVENESS: Dict[SanitizerType, float] = {
    # Full anonymization (0.85-0.95)
    SanitizerType.PRESIDIO: 0.95,
    SanitizerType.SCRUBADUB: 0.90,
    SanitizerType.FAKER: 0.90,
    SanitizerType.DIFFERENTIAL_PRIVACY: 0.95,
    
    # Strong masking (0.70-0.85)
    SanitizerType.REDACT: 0.85,
    SanitizerType.HASH: 0.80,
    SanitizerType.ENCRYPT: 0.85,
    SanitizerType.HMAC: 0.80,
    SanitizerType.TOKENIZE: 0.80,
    SanitizerType.PSEUDONYMIZE: 0.85,
    
    # Partial masking (0.50-0.70)
    SanitizerType.MASK: 0.70,
    SanitizerType.EMAIL_MASK: 0.60,
    SanitizerType.PHONE_MASK: 0.60,
    SanitizerType.SSN_MASK: 0.65,
    SanitizerType.CC_MASK: 0.65,
    SanitizerType.TRUNCATE: 0.50,
    
    # Validation (0.20-0.40)
    SanitizerType.VALIDATE: 0.30,
    SanitizerType.FILTER: 0.40,
    SanitizerType.ALLOWLIST: 0.50,
}


# =============================================================================
# PYTHON SANITIZER PATTERNS
# =============================================================================

# Pattern format: (regex_pattern, effectiveness)
PYTHON_SANITIZERS: Dict[SanitizerType, List[Tuple[str, float]]] = {
    # Presidio (Microsoft)
    SanitizerType.PRESIDIO: [
        (r'from\s+presidio_anonymizer', 0.95),
        (r'AnonymizerEngine\s*\(', 0.95),
        (r'anonymizer\.anonymize\s*\(', 0.95),
        (r'AnalyzerEngine\s*\(', 0.90),
        (r'\.analyze\s*\([^)]*text', 0.90),
    ],
    
    # Scrubadub
    SanitizerType.SCRUBADUB: [
        (r'import\s+scrubadub', 0.90),
        (r'scrubadub\.clean\s*\(', 0.90),
        (r'Scrubber\s*\(', 0.90),
        (r'\.clean\s*\([^)]*text', 0.85),
    ],
    
    # Faker (data replacement)
    SanitizerType.FAKER: [
        (r'from\s+faker\s+import', 0.90),
        (r'Faker\s*\(', 0.90),
        (r'fake\.\w+\s*\(', 0.85),
    ],
    
    # Masking functions
    SanitizerType.MASK: [
        (r'\.mask\s*\(', 0.70),
        (r'mask_\w+\s*\(', 0.70),
        (r'_mask\s*\(', 0.70),
        (r'masked\s*=', 0.65),
        (r'\*{3,}', 0.50),  # Literal asterisks (weak)
    ],
    
    # Redaction
    SanitizerType.REDACT: [
        (r'\.redact\s*\(', 0.85),
        (r'redact_\w+\s*\(', 0.85),
        (r'_redact\s*\(', 0.85),
        (r'\[REDACTED\]', 0.80),
    ],
    
    # Hashing
    SanitizerType.HASH: [
        (r'hashlib\.sha256\s*\(', 0.80),
        (r'hashlib\.sha512\s*\(', 0.80),
        (r'hashlib\.md5\s*\(', 0.70),  # MD5 weaker
        (r'\.hexdigest\s*\(', 0.75),
        (r'bcrypt\.hash\s*\(', 0.85),
        (r'argon2\.hash\s*\(', 0.85),
    ],
    
    # Encryption
    SanitizerType.ENCRYPT: [
        (r'from\s+cryptography', 0.85),
        (r'Fernet\s*\(', 0.85),
        (r'\.encrypt\s*\(', 0.85),
        (r'AES\.new\s*\(', 0.85),
        (r'cipher\.encrypt\s*\(', 0.85),
    ],
    
    # Tokenization
    SanitizerType.TOKENIZE: [
        (r'\.tokenize\s*\(', 0.80),
        (r'tokenize_\w+\s*\(', 0.80),
        (r'create_token\s*\(', 0.80),
        (r'uuid\.uuid4\s*\(', 0.75),  # UUID replacement
    ],
    
    # Validation
    SanitizerType.VALIDATE: [
        (r'pydantic', 0.30),
        (r'@validator\s*\(', 0.30),
        (r'@field_validator\s*\(', 0.30),
        (r'schema\.validate\s*\(', 0.30),
        (r'\.validate\s*\(', 0.25),
    ],
    
    # Format-specific masking
    SanitizerType.EMAIL_MASK: [
        (r'mask_email\s*\(', 0.60),
        (r'email.*\*{2,}.*@', 0.55),
    ],
    SanitizerType.SSN_MASK: [
        (r'mask_ssn\s*\(', 0.65),
        (r'\*{3}-\*{2}-\d{4}', 0.60),
    ],
    SanitizerType.CC_MASK: [
        (r'mask_card\s*\(', 0.65),
        (r'mask_credit_card\s*\(', 0.65),
        (r'\*{4}-\*{4}-\*{4}-\d{4}', 0.60),
    ],
}


# =============================================================================
# TYPESCRIPT/JAVASCRIPT SANITIZER PATTERNS
# =============================================================================

TYPESCRIPT_SANITIZERS: Dict[SanitizerType, List[Tuple[str, float]]] = {
    # Masking
    SanitizerType.MASK: [
        (r'\.mask\s*\(', 0.70),
        (r'maskString\s*\(', 0.70),
        (r'masked\s*=', 0.65),
    ],
    
    # Redaction
    SanitizerType.REDACT: [
        (r'\.redact\s*\(', 0.85),
        (r'redactPII\s*\(', 0.85),
    ],
    
    # Hashing (crypto)
    SanitizerType.HASH: [
        (r'crypto\.createHash\s*\(', 0.80),
        (r'\.digest\s*\(', 0.75),
        (r'bcrypt\.hash\s*\(', 0.85),
    ],
    
    # Encryption
    SanitizerType.ENCRYPT: [
        (r'crypto\.createCipheriv\s*\(', 0.85),
        (r'\.encrypt\s*\(', 0.85),
    ],
    
    # Validation
    SanitizerType.VALIDATE: [
        (r'zod', 0.30),
        (r'z\.object', 0.30),
        (r'\.safeParse\s*\(', 0.35),
        (r'joi\.', 0.30),
        (r'yup\.', 0.30),
    ],
}


def get_sanitizer_effectiveness(sanitizer_type: SanitizerType) -> float:
    """Get effectiveness rating for a sanitizer type."""
    return SANITIZER_EFFECTIVENESS.get(sanitizer_type, 0.5)


def calculate_combined_effectiveness(sanitizers: List[Sanitizer]) -> float:
    """
    Calculate combined effectiveness of multiple sanitizers.
    
    Uses formula: 1 - ∏(1 - effectiveness_i)
    This models sanitizers as independent risk reducers.
    
    Example:
        Two sanitizers with 0.7 and 0.5 effectiveness:
        combined = 1 - (0.3 * 0.5) = 1 - 0.15 = 0.85
    """
    if not sanitizers:
        return 0.0
    
    remaining_risk = 1.0
    for sanitizer in sanitizers:
        remaining_risk *= (1.0 - sanitizer.effectiveness)
    
    # Cap at 0.95 (never assume 100% sanitization)
    return min(1.0 - remaining_risk, 0.95)
