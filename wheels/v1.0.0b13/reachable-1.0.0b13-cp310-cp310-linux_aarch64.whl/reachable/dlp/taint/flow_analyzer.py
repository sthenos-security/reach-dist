# REACHABLE DLP Security Module - Taint Flow Analyzer
# Copyright (c) 2026 Sthenos Security. All rights reserved.

"""
DLP Flow Analyzer - AST-based taint tracking for PII data flows.

Analyzes code to find:
1. PII Sources: Where sensitive data enters the system
2. PII Sinks: Where data could be exposed
3. Sanitizers: Transformations that reduce risk
4. Data Flows: Source → Sanitizer? → Sink paths

Integrates with REACHABLE's call graph for cross-function analysis.

Architecture:
    PII Sources → [Taint Propagation] → Sanitizers? → Sinks
                         ↑                    ↓
                    Call Graph          Risk Calculation

Usage:
    from reachable.dlp.taint import DLPFlowAnalyzer, analyze_dlp_flows
    
    analyzer = DLPFlowAnalyzer(call_graph=cg, reachable_functions=rf)
    results = analyzer.analyze_directory(Path("/path/to/repo"))
    
    for result in results:
        for flow in result.flows:
            logger.info(f"{flow.source.pii_type} → {flow.sink.sink_type.value}")
"""

from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Dict, List, Optional, Set, Tuple, Any
import re
import ast
import logging

from reachable.dlp.taint.sources import (
    PIISourceType, PIISource, PYTHON_PII_SOURCES, TYPESCRIPT_PII_SOURCES,
    infer_pii_type_from_source, get_source_confidence,
)
from reachable.dlp.taint.sinks import (
    DLPSinkType, DLPSink, PYTHON_DLP_SINKS, TYPESCRIPT_DLP_SINKS,
    SINK_RISK_SCORES, SINK_REGULATIONS, get_sink_severity,
)
from reachable.dlp.taint.sanitizers import (
    SanitizerType, Sanitizer, PYTHON_SANITIZERS, TYPESCRIPT_SANITIZERS,
    get_sanitizer_effectiveness, calculate_combined_effectiveness,
)
from reachable.dlp.schema import (
    DLPFinding, DLPFindingType, PIIEntityType, FileClass, SinkType as SchemaSinkType,
    PII_SENSITIVITY_TIER, TIER_BASE_RISK,
)

logger = logging.getLogger(__name__)


# =============================================================================
# DATA CLASSES
# =============================================================================

@dataclass
class DLPDataFlow:
    """A complete data flow from PII source to sink."""
    flow_id: str
    source: PIISource
    sink: DLPSink
    sanitizers: List[Sanitizer] = field(default_factory=list)
    path: List[str] = field(default_factory=list)  # Variable flow path
    
    # Reachability
    is_reachable: bool = True
    reachability_confidence: float = 1.0
    
    # Risk calculation
    base_risk: float = 0.0
    sanitized_risk: float = 0.0
    final_risk: float = 0.0
    
    # Compliance
    regulations: List[str] = field(default_factory=list)
    
    # Metadata
    file_path: str = ""
    pii_type: str = ""
    sink_type: str = ""
    
    def __post_init__(self):
        """Calculate risk scores after initialization."""
        self._calculate_risk()
    
    def _calculate_risk(self):
        """Calculate risk based on PII type, sink type, and sanitizers."""
        # Base risk from sink (0-100)
        sink_risk = SINK_RISK_SCORES.get(self.sink.sink_type, 50)
        
        # PII type multiplier - look up tier first, then risk
        pii_type_enum = self._get_pii_enum()
        tier = PII_SENSITIVITY_TIER.get(pii_type_enum, None)
        if tier:
            pii_risk = TIER_BASE_RISK.get(tier, 50)
        else:
            pii_risk = 50  # Default for unknown PII types
        
        # Combined base risk (average of sink and PII risks)
        self.base_risk = (sink_risk + pii_risk) / 2
        
        # Apply sanitizer reduction
        if self.sanitizers:
            effectiveness = calculate_combined_effectiveness(self.sanitizers)
            self.sanitized_risk = self.base_risk * (1 - effectiveness)
        else:
            self.sanitized_risk = self.base_risk
        
        # Apply reachability adjustment
        if not self.is_reachable:
            self.final_risk = self.sanitized_risk * 0.2  # 80% reduction for unreachable
        else:
            self.final_risk = self.sanitized_risk
        
        # Set regulations based on sink
        self.regulations = SINK_REGULATIONS.get(self.sink.sink_type, ['GDPR'])
    
    def _get_pii_enum(self) -> PIIEntityType:
        """Convert string pii_type to enum."""
        pii_map = {
            'ssn': PIIEntityType.SSN,
            'credit_card': PIIEntityType.CREDIT_CARD,
            'email': PIIEntityType.EMAIL,
            'phone': PIIEntityType.PHONE,
            'person_name': PIIEntityType.PERSON_NAME,
            'address': PIIEntityType.ADDRESS,
            'dob': PIIEntityType.DATE_OF_BIRTH,
            'date_of_birth': PIIEntityType.DATE_OF_BIRTH,
            'passport': PIIEntityType.PASSPORT,
            'drivers_license': PIIEntityType.DRIVERS_LICENSE,
            'bank_account': PIIEntityType.BANK_ACCOUNT,
            'mrn': PIIEntityType.MRN,
            'user_data': PIIEntityType.EMAIL,  # Default
        }
        return pii_map.get(self.pii_type or self.source.pii_type, PIIEntityType.EMAIL)
    
    @property
    def severity(self) -> str:
        """Get severity based on final risk."""
        if self.final_risk >= 80:
            return 'CRITICAL'
        elif self.final_risk >= 60:
            return 'HIGH'
        elif self.final_risk >= 40:
            return 'MEDIUM'
        else:
            return 'LOW'
    
    @property
    def is_sanitized(self) -> bool:
        """Check if flow has any sanitizers."""
        return len(self.sanitizers) > 0
    
    def to_dlp_finding(self, file_path: str = None) -> DLPFinding:
        """Convert to DLPFinding for correlation engine."""
        # Map sink type
        sink_type_map = {
            DLPSinkType.LOG: SchemaSinkType.LOG,
            DLPSinkType.CONSOLE: SchemaSinkType.LOG,
            DLPSinkType.EXTERNAL_API: SchemaSinkType.EXTERNAL_API,
            DLPSinkType.LLM_API: SchemaSinkType.LLM_API,
            DLPSinkType.LLM_PROMPT: SchemaSinkType.LLM_API,
            DLPSinkType.LLM_EMBEDDING: SchemaSinkType.LLM_API,
            DLPSinkType.VECTOR_STORE: SchemaSinkType.VECTOR_STORE,
            DLPSinkType.ANALYTICS: SchemaSinkType.ANALYTICS,
            DLPSinkType.DATABASE: SchemaSinkType.DATABASE,
            DLPSinkType.FILE_WRITE: SchemaSinkType.FILE_WRITE,
            DLPSinkType.EMAIL: SchemaSinkType.EXTERNAL_API,
        }
        
        schema_sink = sink_type_map.get(self.sink.sink_type, SchemaSinkType.LOG)
        
        # Use provided file_path or extract from self
        actual_file_path = file_path or self.file_path
        
        # Get line number from sink location
        try:
            line_num = int(self.sink.location.split(':')[-1])
        except (ValueError, IndexError):
            line_num = 0
        
        return DLPFinding.create_taint(
            file_path=actual_file_path,
            line_start=line_num,
            pii_type=self._get_pii_enum(),
            source=self.source.variable,
            sink=self.sink.function,
            sink_type=schema_sink,
            sanitizer_present=self.is_sanitized,
            
        )


@dataclass
class DLPReachabilityResult:
    """Result of DLP flow analysis for a file."""
    file_path: str
    flows: List[DLPDataFlow] = field(default_factory=list)
    sources_found: int = 0
    sinks_found: int = 0
    sanitizers_found: int = 0
    
    # Flow statistics
    total_flows: int = 0
    sanitized_flows: int = 0
    unsanitized_flows: int = 0
    high_risk_flows: int = 0
    
    # By sink type
    flows_by_sink: Dict[str, int] = field(default_factory=dict)
    
    # By PII type  
    flows_by_pii: Dict[str, int] = field(default_factory=dict)
    
    # v4.6.5: LLM-specific flows (for AI security integration)
    llm_flows: List[DLPDataFlow] = field(default_factory=list)
    
    def __post_init__(self):
        self._calculate_stats()
    
    def _calculate_stats(self):
        """Calculate statistics from flows."""
        self.total_flows = len(self.flows)
        self.sanitized_flows = sum(1 for f in self.flows if f.is_sanitized)
        self.unsanitized_flows = self.total_flows - self.sanitized_flows
        self.high_risk_flows = sum(1 for f in self.flows if f.final_risk >= 60)
        
        # Count by sink type
        for flow in self.flows:
            sink_type = flow.sink.sink_type.value
            self.flows_by_sink[sink_type] = self.flows_by_sink.get(sink_type, 0) + 1
        
        # Count by PII type
        for flow in self.flows:
            pii_type = flow.source.pii_type or 'unknown'
            self.flows_by_pii[pii_type] = self.flows_by_pii.get(pii_type, 0) + 1


# =============================================================================
# FLOW ANALYZER
# =============================================================================

class DLPFlowAnalyzer:
    """
    AST-based taint flow analyzer for PII data.
    
    Integrates with REACHABLE's call graph for cross-function tracking.
    """
    
    def __init__(
        self,
        call_graph: Optional[Dict] = None,
        reachable_functions: Optional[Set[str]] = None,
        entrypoints: Optional[Set[str]] = None,
        verbose: bool = False,
    ):
        """
        Initialize analyzer.
        
        Args:
            call_graph: Application call graph from REACHABLE
            reachable_functions: Set of functions reachable from entrypoints
            entrypoints: Application entry points
            verbose: Enable verbose logging
        """
        self.call_graph = call_graph or {}
        self.reachable_functions = reachable_functions or set()
        self.entrypoints = entrypoints or set()
        self.verbose = verbose
        
        # Results
        self.all_flows: List[DLPDataFlow] = []
        self.flow_counter = 0
    
    def analyze_file(self, file_path: Path) -> DLPReachabilityResult:
        """Analyze a single file for PII data flows."""
        result = DLPReachabilityResult(file_path=str(file_path))
        
        try:
            content = file_path.read_text(encoding='utf-8', errors='ignore')
            lines = content.split('\n')
        except Exception as e:
            logger.debug(f"Could not read {file_path}: {e}")
            return result
        
        # Determine language
        ext = file_path.suffix.lower()
        is_typescript = ext in ['.ts', '.js', '.tsx', '.jsx']
        
        # Find sources, sinks, sanitizers
        sources = self._find_sources(lines, file_path, is_typescript)
        result.sources_found = len(sources)
        
        sinks = self._find_sinks(lines, file_path, is_typescript)
        result.sinks_found = len(sinks)
        
        sanitizers = self._find_sanitizers(lines, file_path, is_typescript)
        result.sanitizers_found = len(sanitizers)
        
        # Build flows
        flows = self._build_flows(sources, sinks, sanitizers, lines, file_path)
        result.flows = flows
        
        # Recalculate stats
        result._calculate_stats()
        
        return result
    
    def analyze_directory(
        self,
        dir_path: Path,
        extensions: Optional[List[str]] = None,
        exclude_patterns: Optional[List[str]] = None,
    ) -> List[DLPReachabilityResult]:
        """Analyze all files in a directory."""
        if extensions is None:
            extensions = ['.py', '.js', '.ts', '.tsx', '.jsx', '.go', '.java']
        
        if exclude_patterns is None:
            exclude_patterns = [
                '.venv', 'venv', 'node_modules', '__pycache__', '.git',
                'dist', 'build', '.tox', '.pytest_cache', 'vendor',
            ]
        
        results = []
        
        for ext in extensions:
            for file_path in dir_path.rglob(f'*{ext}'):
                # Skip excluded patterns
                path_str = str(file_path)
                if any(excl in path_str for excl in exclude_patterns):
                    continue
                
                if self.verbose:
                    logger.info(f"Analyzing: {file_path}")
                
                result = self.analyze_file(file_path)
                
                # Only include files with flows or detected sources/sinks
                if result.flows or result.sources_found > 0 or result.sinks_found > 0:
                    results.append(result)
                    self.all_flows.extend(result.flows)
        
        return results
    
    def _find_sources(
        self,
        lines: List[str],
        file_path: Path,
        is_typescript: bool = False,
    ) -> List[PIISource]:
        """Find PII sources in code."""
        sources = []
        patterns = TYPESCRIPT_PII_SOURCES if is_typescript else PYTHON_PII_SOURCES
        
        for line_num, line in enumerate(lines, 1):
            for source_type, pattern_list in patterns.items():
                for pattern in pattern_list:
                    match = re.search(pattern, line, re.IGNORECASE)
                    if match:
                        # Extract variable name
                        var_match = re.search(r'(\w+)\s*=', line)
                        var_name = var_match.group(1) if var_match else "data"
                        
                        # Infer PII type from source code
                        pii_type = infer_pii_type_from_source(line)
                        
                        sources.append(PIISource(
                            source_type=source_type,
                            location=f"{file_path}:{line_num}",
                            variable=var_name,
                            pii_type=pii_type,
                            confidence=get_source_confidence(source_type),
                            context=line.strip()[:100],
                        ))
                        break  # One match per line per source type
        
        return sources
    
    def _find_sinks(
        self,
        lines: List[str],
        file_path: Path,
        is_typescript: bool = False,
    ) -> List[DLPSink]:
        """Find DLP sinks in code."""
        sinks = []
        patterns = TYPESCRIPT_DLP_SINKS if is_typescript else PYTHON_DLP_SINKS
        
        for line_num, line in enumerate(lines, 1):
            for sink_type, pattern_list in patterns.items():
                for pattern in pattern_list:
                    match = re.search(pattern, line, re.IGNORECASE)
                    if match:
                        # Extract function name
                        func_match = re.search(r'\.(\w+)\s*\(', line)
                        func_name = func_match.group(1) if func_match else "unknown"
                        
                        sinks.append(DLPSink(
                            sink_type=sink_type,
                            location=f"{file_path}:{line_num}",
                            function=func_name,
                            confidence=1.0,
                            context=line.strip()[:100],
                        ))
                        break  # One match per line per sink type
        
        return sinks
    
    def _find_sanitizers(
        self,
        lines: List[str],
        file_path: Path,
        is_typescript: bool = False,
    ) -> List[Sanitizer]:
        """Find sanitizers in code."""
        sanitizers = []
        patterns = TYPESCRIPT_SANITIZERS if is_typescript else PYTHON_SANITIZERS
        
        for line_num, line in enumerate(lines, 1):
            for sanitizer_type, pattern_list in patterns.items():
                for pattern, effectiveness in pattern_list:
                    match = re.search(pattern, line, re.IGNORECASE)
                    if match:
                        # Extract function name
                        func_match = re.search(r'(\w+)\s*\(', line)
                        func_name = func_match.group(1) if func_match else "sanitizer"
                        
                        sanitizers.append(Sanitizer(
                            sanitizer_type=sanitizer_type,
                            location=f"{file_path}:{line_num}",
                            function=func_name,
                            effectiveness=effectiveness,
                            confidence=1.0,
                            context=line.strip()[:100],
                        ))
                        break
        
        return sanitizers
    
    def _build_flows(
        self,
        sources: List[PIISource],
        sinks: List[DLPSink],
        sanitizers: List[Sanitizer],
        lines: List[str],
        file_path: Path,
    ) -> List[DLPDataFlow]:
        """Build data flows connecting sources to sinks."""
        flows = []
        
        for source in sources:
            source_line = int(source.location.split(':')[1])
            
            for sink in sinks:
                sink_line = int(sink.location.split(':')[1])
                
                # Heuristic: source before sink in same file (within reasonable distance)
                # For cross-function flows, we'd use the call graph
                if source_line < sink_line and (sink_line - source_line) < 200:
                    # Find sanitizers between source and sink
                    applicable_sanitizers = []
                    for san in sanitizers:
                        san_line = int(san.location.split(':')[1])
                        if source_line < san_line < sink_line:
                            applicable_sanitizers.append(san)
                    
                    # Check reachability via call graph
                    is_reachable = self._check_reachability(file_path, source_line, sink_line)
                    
                    # Create flow
                    self.flow_counter += 1
                    flow = DLPDataFlow(
                        flow_id=f"dlp-flow-{self.flow_counter:04d}",
                        source=source,
                        sink=sink,
                        sanitizers=applicable_sanitizers,
                        path=[source.variable, f"→ {sink.function}"],
                        
                        file_path=str(file_path),
                        pii_type=source.pii_type,
                        sink_type=sink.sink_type.value,
                    )
                    
                    flows.append(flow)
        
        return flows
    
    def _check_reachability(
        self,
        file_path: Path,
        source_line: int,
        sink_line: int,
    ) -> bool:
        """
        Check if a flow is reachable using the call graph.
        
        If no call graph is provided, assume reachable (conservative).
        """
        if not self.reachable_functions:
            return True  # No call graph, assume reachable
        
        # Check if any function in the file is reachable
        file_str = str(file_path)
        
        for func in self.reachable_functions:
            if file_str in func or func in file_str:
                return True
        
        # Additional: check if file is under test/ or fixture/
        if '/test' in file_str.lower() or '/fixture' in file_str.lower():
            return False  # Test code typically not reachable in production
        
        return True  # Default to reachable
    
    def get_findings(self) -> List[DLPFinding]:
        """Convert all flows to DLPFinding objects for correlation."""
        return [flow.to_dlp_finding() for flow in self.all_flows]
    
    def get_summary(self) -> Dict[str, Any]:
        """Get summary statistics of all analyzed flows."""
        return {
            'total_flows': len(self.all_flows),
            'sanitized_flows': sum(1 for f in self.all_flows if f.is_sanitized),
            'unsanitized_flows': sum(1 for f in self.all_flows if not f.is_sanitized),
            'high_risk_flows': sum(1 for f in self.all_flows if f.final_risk >= 60),
            'critical_flows': sum(1 for f in self.all_flows if f.final_risk >= 80),
            'reachable_flows': sum(1 for f in self.all_flows if f.is_reachable),
            'by_sink_type': self._count_by_attr('sink_type'),
            'by_pii_type': self._count_by_attr('pii_type'),
        }
    
    def _count_by_attr(self, attr: str) -> Dict[str, int]:
        """Count flows by attribute."""
        counts = {}
        for flow in self.all_flows:
            value = getattr(flow, attr, 'unknown')
            counts[value] = counts.get(value, 0) + 1
        return counts


# =============================================================================
# HIGH-LEVEL INTEGRATION FUNCTIONS
# =============================================================================

def analyze_dlp_flows(
    target_path: Path,
    call_graph: Optional[Dict] = None,
    reachable_functions: Optional[Set[str]] = None,
    verbose: bool = False,
) -> Dict[str, Any]:
    """
    High-level function to analyze DLP flows in a codebase.
    
    Returns dict suitable for integration with correlation engine.
    """
    analyzer = DLPFlowAnalyzer(
        call_graph=call_graph,
        reachable_functions=reachable_functions,
        verbose=verbose,
    )
    
    if target_path.is_file():
        results = [analyzer.analyze_file(target_path)]
    else:
        results = analyzer.analyze_directory(target_path)
    
    return {
        'files_analyzed': len(results),
        'results': results,
        'flows': analyzer.all_flows,
        'findings': analyzer.get_findings(),
        'summary': analyzer.get_summary(),
        'analyzer': analyzer,
    }


# =============================================================================
# CLI ENTRY POINT
# =============================================================================

if __name__ == "__main__":
    import sys
    
    if len(sys.argv) < 2:
        logger.info("Usage: python flow_analyzer.py <path>")
        sys.exit(1)
    
    target = Path(sys.argv[1])
    results = analyze_dlp_flows(target, verbose=True)
    
    logger.info(f"\n🔍 DLP Flow Analysis: {target}")
    print("=" * 70)
    logger.info(f"📁 Files analyzed: {results['files_analyzed']}")
    
    summary = results['summary']
    logger.info(f"\n📊 Flow Summary:")
    logger.info(f"   Total flows: {summary['total_flows']}")
    logger.info(f"   Sanitized: {summary['sanitized_flows']}")
    logger.info(f"   Unsanitized: {summary['unsanitized_flows']}")
    logger.info(f"   High risk (≥60): {summary['high_risk_flows']}")
    logger.info(f"   Critical (≥80): {summary['critical_flows']}")
    
    if summary.get('by_sink_type'):
        logger.info(f"\n📤 By Sink Type:")
        for sink, count in sorted(summary['by_sink_type'].items(), key=lambda x: -x[1]):
            logger.info(f"   {sink}: {count}")
    
    if summary.get('by_pii_type'):
        logger.info(f"\n🔐 By PII Type:")
        for pii, count in sorted(summary['by_pii_type'].items(), key=lambda x: -x[1]):
            logger.info(f"   {pii}: {count}")
    
    # Show critical flows
    critical = [f for f in results['flows'] if f.final_risk >= 60 and not f.is_sanitized]
    if critical:
        logger.info(f"\n🚨 High-Risk Unsanitized Flows ({len(critical)}):")
        for flow in critical[:10]:
            logger.info(f"   [{flow.severity}] {flow.pii_type} → {flow.sink_type}")
            logger.info(f"      {flow.file_path}")
            logger.info(f"      Risk: {flow.final_risk:.1f}")
