#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.

"""
Configuration manager for REACHABLE auto-maintenance and user preferences.

Manages ~/.reachable/config.json for:
- Auto-maintenance policies (WAL checkpoint, vacuum, pruning)
- User preferences (future: dashboard themes, notification settings)
"""

import json
import copy
from pathlib import Path
from typing import Dict, Any, Optional


# Config file path (can be patched in tests)
CONFIG_PATH = Path.home() / '.reachable' / 'config.json'


# Default configuration
DEFAULT_CONFIG = {
    "version": "1.0",
    "auto_maintenance": {
        "enabled": True,
        "wal_checkpoint": True,          # Always checkpoint after scans
        "vacuum_enabled": True,
        "vacuum_threshold_pct": 30,      # Run VACUUM if bloat > 30%
        "prune_enabled": True,
        "max_scans_per_branch": 50,      # Max scans per branch
        "max_age_days": 30,              # Max scan age in days
    },
    "user_preferences": {
        # Future: dashboard themes, notification settings, etc.
    },
    "cache": {
        # Roadmap: Centralize cache TTLs here instead of env vars.
        # Currently overridden by REACHABLE_CACHE_TTL_HOURS env var.
        # "semgrep_ttl_hours": 24,
        # "threat_intel_ttl_hours": 24,
        # "vuln_db_ttl_hours": 24,
    }
}


def get_config_path() -> Path:
    """Get path to config file"""
    return CONFIG_PATH


def load_config() -> Dict[str, Any]:
    """
    Load configuration from ~/.reachable/config.json
    
    Returns default config if file doesn't exist or is invalid.
    """
    config_path = get_config_path()
    
    if not config_path.exists():
        # Create default config file
        default = copy.deepcopy(DEFAULT_CONFIG)
        save_config(default)
        return default
    
    try:
        with open(config_path, 'r') as f:
            user_config = json.load(f)
        
        # Merge with defaults (in case new settings were added)
        config = copy.deepcopy(DEFAULT_CONFIG)
        _deep_merge(config, user_config)
        
        return config
    except Exception:
        # If config is corrupted, return defaults
        return copy.deepcopy(DEFAULT_CONFIG)


def save_config(config: Dict[str, Any]) -> bool:
    """
    Save configuration to ~/.reachable/config.json
    
    Returns:
        True if successful, False otherwise
    """
    config_path = get_config_path()
    
    try:
        # Ensure directory exists
        config_path.parent.mkdir(parents=True, exist_ok=True)
        
        # Write with pretty formatting
        with open(config_path, 'w') as f:
            json.dump(config, f, indent=2)
        
        return True
    except Exception:
        return False


def get_config_value(key_path: str) -> Any:
    """
    Get a config value using dot notation.
    
    Examples:
        get_config_value('auto_maintenance.enabled') → True
        get_config_value('auto_maintenance.prune_max_scans') → 50
    
    Args:
        key_path: Dot-separated path to config value
    
    Returns:
        Config value or None if not found
    """
    config = load_config()
    
    keys = key_path.split('.')
    value = config
    
    for key in keys:
        if isinstance(value, dict) and key in value:
            value = value[key]
        else:
            return None
    
    return value


def set_config_value(key_path: str, value: Any) -> bool:
    """
    Set a config value using dot notation.
    
    Examples:
        set_config_value('auto_maintenance.enabled', True)
        set_config_value('auto_maintenance.prune_max_scans', 100)
    
    Args:
        key_path: Dot-separated path to config value
        value: New value
    
    Returns:
        True if successful, False otherwise
    """
    config = load_config()
    
    keys = key_path.split('.')
    
    # Navigate to parent dict
    current = config
    for key in keys[:-1]:
        if key not in current or not isinstance(current[key], dict):
            current[key] = {}
        current = current[key]
    
    # Set the value
    current[keys[-1]] = value
    
    return save_config(config)


def reset_config() -> bool:
    """
    Reset configuration to defaults.
    
    Returns:
        True if successful, False otherwise
    """
    return save_config(copy.deepcopy(DEFAULT_CONFIG))


def get_auto_maintenance_config() -> Dict[str, Any]:
    """
    Get auto-maintenance configuration section.
    
    Returns:
        Auto-maintenance config dict
    """
    config = load_config()
    return config.get('auto_maintenance', copy.deepcopy(DEFAULT_CONFIG['auto_maintenance']))


def is_auto_maintenance_enabled() -> bool:
    """Check if auto-maintenance is enabled"""
    return get_config_value('auto_maintenance.enabled') is True


def should_checkpoint() -> bool:
    """Check if WAL checkpoint should run"""
    checkpoint_policy = get_config_value('auto_maintenance.wal_checkpoint')
    return checkpoint_policy is True


def should_vacuum() -> bool:
    """Check if vacuum is enabled"""
    return get_config_value('auto_maintenance.vacuum_enabled') is True


def get_vacuum_threshold() -> int:
    """Get vacuum bloat threshold percentage"""
    threshold = get_config_value('auto_maintenance.vacuum_threshold_pct')
    return threshold if threshold is not None else 30


def should_prune() -> bool:
    """Check if pruning is enabled"""
    return get_config_value('auto_maintenance.prune_enabled') is True


def get_prune_max_scans() -> int:
    """Get max scans per branch for pruning"""
    max_scans = get_config_value('auto_maintenance.max_scans_per_branch')
    return max_scans if max_scans is not None else 50


def get_prune_max_age_days() -> int:
    """Get max scan age in days for pruning"""
    max_age = get_config_value('auto_maintenance.max_age_days')
    return max_age if max_age is not None else 30


def _deep_merge(base: Dict, update: Dict) -> None:
    """
    Deep merge update dict into base dict (in-place).
    
    Used to merge user config with defaults, preserving new default settings.
    """
    for key, value in update.items():
        if key in base and isinstance(base[key], dict) and isinstance(value, dict):
            _deep_merge(base[key], value)
        else:
            base[key] = value


def validate_config_value(key_path: str, value: Any) -> tuple[bool, Optional[str]]:
    """
    Validate a config value before setting.
    
    Args:
        key_path: Dot-separated path to config value
        value: Value to validate
    
    Returns:
        (is_valid, error_message)
    """
    # Validate auto_maintenance settings
    if key_path == 'auto_maintenance.enabled':
        if not isinstance(value, bool):
            return False, "Value must be true or false"
    
    elif key_path == 'auto_maintenance.wal_checkpoint':
        if value not in ['always', 'never', 'auto']:
            return False, "Value must be 'always', 'never', or 'auto'"
    
    elif key_path == 'auto_maintenance.vacuum_enabled':
        if not isinstance(value, bool):
            return False, "Value must be true or false"
    
    elif key_path == 'auto_maintenance.vacuum_threshold_pct':
        if not isinstance(value, int) or value < 0 or value > 100:
            return False, "Value must be an integer between 0 and 100"
    
    elif key_path == 'auto_maintenance.prune_enabled':
        if not isinstance(value, bool):
            return False, "Value must be true or false"
    
    elif key_path == 'auto_maintenance.prune_max_scans':
        if not isinstance(value, int) or value < 1:
            return False, "Value must be a positive integer"
    
    elif key_path == 'auto_maintenance.prune_max_age_days':
        if not isinstance(value, int) or value < 1:
            return False, "Value must be a positive integer"
    
    else:
        # Unknown setting - allow it (for future extensibility)
        pass
    
    return True, None


# Convenience function for getting all config as formatted string
def format_config_display(config: Optional[Dict] = None) -> str:
    """
    Format config as human-readable display.
    
    Args:
        config: Config dict (loads if not provided)
    
    Returns:
        Formatted string
    """
    if config is None:
        config = load_config()
    
    auto_maint = config.get('auto_maintenance', {})
    
    lines = []
    lines.append("CONFIGURATION")
    lines.append("=" * 60)
    lines.append("")
    lines.append("Auto-Maintenance:")
    lines.append(f"  Enabled:             {auto_maint.get('enabled', False)}")
    lines.append(f"  WAL Checkpoint:      {auto_maint.get('wal_checkpoint', 'always')}")
    lines.append(f"  Vacuum Enabled:      {auto_maint.get('vacuum_enabled', True)}")
    lines.append(f"  Vacuum Threshold:    {auto_maint.get('vacuum_threshold_pct', 30)}%")
    lines.append(f"  Pruning Enabled:     {auto_maint.get('prune_enabled', True)}")
    lines.append(f"  Max Scans/Branch:    {auto_maint.get('max_scans_per_branch', 50)}")
    lines.append(f"  Max Scan Age:        {auto_maint.get('max_age_days', 30)} days")
    lines.append("")
    lines.append(f"Config file: {get_config_path()}")
    
    return "\n".join(lines)
