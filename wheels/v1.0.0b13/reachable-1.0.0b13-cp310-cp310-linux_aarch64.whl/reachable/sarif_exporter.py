#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.

"""
SARIF (Static Analysis Results Interchange Format) Exporter

Exports REACHABLE findings to SARIF 2.1.0 format for integration with:
- GitHub Code Scanning
- GitLab SAST
- Azure DevOps
- SonarQube
- Any SARIF-compatible tool

SARIF Spec: https://docs.oasis-open.org/sarif/sarif/v2.1.0/sarif-v2.1.0.html
"""

import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, List, Any, Optional
from . import __version__

# SARIF severity mapping
SEVERITY_TO_SARIF_LEVEL = {
    'CRITICAL': 'error',
    'HIGH': 'error',
    'MEDIUM': 'warning',
    'LOW': 'note',
    'INFO': 'none',
}

# CWE to SARIF rule mapping
FINDING_TYPE_TO_RULE_PREFIX = {
    'cve': 'CVE',
    'secret': 'SECRET',
    'cwe': 'CWE',
    'malware': 'MALWARE',
    'config': 'CONFIG',
    'license': 'LICENSE',
}

def export_to_sarif(
    results: Dict[str, Any],
    output_path: Optional[Path] = None,
    repo_uri: Optional[str] = None,
) -> Dict[str, Any]:
    """
    Export REACHABLE results to SARIF 2.1.0 format.
    
    Args:
        results: REACHABLE scan results dict
        output_path: Optional path to write SARIF file
        repo_uri: Optional repository URI for artifact location
        
    Returns:
        SARIF document as dict
    """
    # Build SARIF document
    sarif = {
        "$schema": "https://raw.githubusercontent.com/oasis-tcs/sarif-spec/master/Schemata/sarif-schema-2.1.0.json",
        "version": "2.1.0",
        "runs": [
            _build_run(results, repo_uri)
        ]
    }
    
    # Write to file if path provided
    if output_path:
        output_path = Path(output_path)
        with open(output_path, 'w') as f:
            json.dump(sarif, f, indent=2)
    
    return sarif

def _build_run(results: Dict[str, Any], repo_uri: Optional[str] = None) -> Dict[str, Any]:
    """Build a SARIF run object from REACHABLE results."""
    
    # Collect all findings and rules
    all_results = []
    rules_map = {}  # rule_id -> rule definition
    
    # Process CVEs
    for cve_id, cve_data in results.get('reachable', {}).items():
        rule_id = f"CVE/{cve_id}"
        result, rule = _cve_to_sarif(cve_id, cve_data, is_reachable=True)
        all_results.append(result)
        rules_map[rule_id] = rule
    
    for cve_id, cve_data in results.get('unreachable', {}).items():
        rule_id = f"CVE/{cve_id}"
        result, rule = _cve_to_sarif(cve_id, cve_data, is_reachable=False)
        all_results.append(result)
        if rule_id not in rules_map:
            rules_map[rule_id] = rule
    
    # Process secrets
    security_scans = results.get('security_scans', {})
    secrets_data = security_scans.get('secrets', {})
    for finding in secrets_data.get('findings', []):
        if finding.get('is_actual_secret'):
            result, rule = _secret_to_sarif(finding)
            all_results.append(result)
            rule_id = rule['id']
            if rule_id not in rules_map:
                rules_map[rule_id] = rule
    
    # Process CWE findings
    cwe_data = security_scans.get('cwe', {})
    for finding in cwe_data.get('findings', []):
        result, rule = _cwe_to_sarif(finding)
        all_results.append(result)
        rule_id = rule['id']
        if rule_id not in rules_map:
            rules_map[rule_id] = rule
    
    # Process malware findings
    malware_data = results.get('malware_detection', {})
    for finding in malware_data.get('findings', []):
        result, rule = _malware_to_sarif(finding)
        all_results.append(result)
        rule_id = rule['id']
        if rule_id not in rules_map:
            rules_map[rule_id] = rule
    
    # Build tool component
    tool = {
        "driver": {
            "name": "REACHABLE",
            "version": results.get('reachable_version', __version__),
            "informationUri": "https://reachable.dev",
            "rules": list(rules_map.values()),
            "properties": {
                "reachabilityAnalysis": True,
                "multiSignalCorrelation": True,
            }
        }
    }
    
    # Build invocation
    metadata = results.get('metadata', {})
    invocation = {
        "executionSuccessful": True,
        "startTimeUtc": metadata.get('scan_timing', {}).get('start_timestamp', datetime.now(timezone.utc).isoformat().replace('+00:00', 'Z')),
        "endTimeUtc": metadata.get('scan_timing', {}).get('end_timestamp', datetime.now(timezone.utc).isoformat().replace('+00:00', 'Z')),
    }
    
    # Build artifacts (files scanned)
    artifacts = []
    if repo_uri:
        artifacts.append({
            "location": {
                "uri": repo_uri
            },
            "sourceLanguage": ", ".join(metadata.get('languages', []))
        })
    
    run = {
        "tool": tool,
        "invocations": [invocation],
        "results": all_results,
        "artifacts": artifacts if artifacts else None,
        "properties": {
            "summary": results.get('summary', {}),
            "riskScore": results.get('summary', {}).get('risk_score', 0),
            "riskLevel": results.get('summary', {}).get('risk_level', 'UNKNOWN'),
        }
    }
    
    # Remove None values
    return {k: v for k, v in run.items() if v is not None}

def _cve_to_sarif(cve_id: str, cve_data: Dict, is_reachable: bool) -> tuple:
    """Convert CVE finding to SARIF result and rule."""
    
    severity = cve_data.get('severity', 'MEDIUM').upper()
    level = SEVERITY_TO_SARIF_LEVEL.get(severity, 'warning')
    
    # Reduce severity for unreachable CVEs
    if not is_reachable and level == 'error':
        level = 'warning'
    
    rule_id = f"CVE/{cve_id}"
    
    # Build result
    result = {
        "ruleId": rule_id,
        "level": level,
        "message": {
            "text": f"{cve_id} in {cve_data.get('package', 'unknown')}@{cve_data.get('version', 'unknown')}: {cve_data.get('description', 'No description')[:200]}"
        },
        "properties": {
            "reachable": is_reachable,
            "reachabilityConfidence": cve_data.get('reachability_confidence', 'UNKNOWN'),
            "package": cve_data.get('package'),
            "version": cve_data.get('version'),
            "fixedVersion": cve_data.get('fixed_version'),
            "cvssScore": cve_data.get('cvss_score'),
            "epssScore": cve_data.get('epss_score'),
        }
    }
    
    # Add location if available
    locations = cve_data.get('locations', [])
    if locations:
        result["locations"] = [
            {
                "physicalLocation": {
                    "artifactLocation": {
                        "uri": loc.get('file', 'unknown')
                    },
                    "region": {
                        "startLine": loc.get('line', 1)
                    } if loc.get('line') else None
                }
            }
            for loc in locations[:10]  # Limit to 10 locations
        ]
    
    # Build rule
    rule = {
        "id": rule_id,
        "name": cve_id,
        "shortDescription": {
            "text": f"{cve_id}: {cve_data.get('package', 'unknown')} vulnerability"
        },
        "fullDescription": {
            "text": cve_data.get('description', f"Vulnerability {cve_id}")[:1000]
        },
        "defaultConfiguration": {
            "level": SEVERITY_TO_SARIF_LEVEL.get(severity, 'warning')
        },
        "helpUri": f"https://nvd.nist.gov/vuln/detail/{cve_id}",
        "properties": {
            "severity": severity,
            "category": "vulnerability",
            "cwe": cve_data.get('cwe_ids', []),
        }
    }
    
    return result, rule

def _secret_to_sarif(finding: Dict) -> tuple:
    """Convert secret finding to SARIF result and rule."""
    
    secret_type = finding.get('type', 'generic-secret')
    rule_id = f"SECRET/{secret_type}"
    
    severity = finding.get('severity', 'HIGH').upper()
    level = SEVERITY_TO_SARIF_LEVEL.get(severity, 'error')
    
    # Reduce severity for unreachable secrets
    if not finding.get('is_reachable', True) and level == 'error':
        level = 'warning'
    
    result = {
        "ruleId": rule_id,
        "level": level,
        "message": {
            "text": f"Exposed {secret_type} detected: {finding.get('message', 'Secret found in code')}"
        },
        "locations": [
            {
                "physicalLocation": {
                    "artifactLocation": {
                        "uri": finding.get('file', 'unknown')
                    },
                    "region": {
                        "startLine": finding.get('line', 1),
                        "startColumn": finding.get('column', 1),
                    }
                }
            }
        ],
        "properties": {
            "reachable": finding.get('is_reachable', True),
            "secretType": secret_type,
            "verified": finding.get('verified', False),
        }
    }
    
    rule = {
        "id": rule_id,
        "name": f"Exposed {secret_type}",
        "shortDescription": {
            "text": f"Exposed {secret_type} in source code"
        },
        "fullDescription": {
            "text": f"A {secret_type} was found exposed in the source code. This could lead to unauthorized access if the code is publicly accessible."
        },
        "defaultConfiguration": {
            "level": "error"
        },
        "properties": {
            "severity": "HIGH",
            "category": "secret",
        }
    }
    
    return result, rule

def _cwe_to_sarif(finding: Dict) -> tuple:
    """Convert CWE finding to SARIF result and rule."""
    
    cwe_id = finding.get('cwe_id', finding.get('rule_id', 'unknown'))
    rule_id = f"CWE/{cwe_id}"
    
    severity = finding.get('severity', 'MEDIUM').upper()
    level = SEVERITY_TO_SARIF_LEVEL.get(severity, 'warning')
    
    # Reduce severity for unreachable findings
    if not finding.get('is_reachable', True) and level == 'error':
        level = 'warning'
    
    result = {
        "ruleId": rule_id,
        "level": level,
        "message": {
            "text": finding.get('message', f"CWE violation: {cwe_id}")
        },
        "locations": [
            {
                "physicalLocation": {
                    "artifactLocation": {
                        "uri": finding.get('file', 'unknown')
                    },
                    "region": {
                        "startLine": finding.get('line', 1),
                        "endLine": finding.get('end_line', finding.get('line', 1)),
                    }
                }
            }
        ],
        "properties": {
            "reachable": finding.get('is_reachable', True),
            "reachabilityConfidence": finding.get('reachability_confidence', 'UNKNOWN'),
        }
    }
    
    rule = {
        "id": rule_id,
        "name": cwe_id,
        "shortDescription": {
            "text": finding.get('rule_name', f"CWE: {cwe_id}")
        },
        "fullDescription": {
            "text": finding.get('description', f"Common Weakness Enumeration: {cwe_id}")[:1000]
        },
        "defaultConfiguration": {
            "level": SEVERITY_TO_SARIF_LEVEL.get(severity, 'warning')
        },
        "helpUri": f"https://cwe.mitre.org/data/definitions/{cwe_id.replace('CWE-', '')}.html" if cwe_id.startswith('CWE-') else None,
        "properties": {
            "severity": severity,
            "category": "code-quality",
        }
    }
    
    return result, rule

def _malware_to_sarif(finding: Dict) -> tuple:
    """Convert malware finding to SARIF result and rule."""
    
    package = finding.get('package', 'unknown')
    rule_id = f"MALWARE/{finding.get('detection_type', 'suspicious')}"
    
    severity = finding.get('severity', 'CRITICAL').upper()
    level = SEVERITY_TO_SARIF_LEVEL.get(severity, 'error')
    
    result = {
        "ruleId": rule_id,
        "level": level,
        "message": {
            "text": f"Malware detected in {package}: {finding.get('description', 'Suspicious behavior detected')}"
        },
        "properties": {
            "package": package,
            "version": finding.get('version'),
            "detectionType": finding.get('detection_type'),
            "confidence": finding.get('confidence', 'HIGH'),
            "indicators": finding.get('indicators', []),
        }
    }
    
    rule = {
        "id": rule_id,
        "name": f"Malware: {finding.get('detection_type', 'suspicious')}",
        "shortDescription": {
            "text": f"Malicious package detected"
        },
        "fullDescription": {
            "text": f"A package with malicious behavior was detected. This could indicate supply chain compromise."
        },
        "defaultConfiguration": {
            "level": "error"
        },
        "properties": {
            "severity": "CRITICAL",
            "category": "malware",
        }
    }
    
    return result, rule

def get_sarif_summary(sarif: Dict) -> Dict[str, Any]:
    """Get summary statistics from SARIF document."""
    
    results = sarif.get('runs', [{}])[0].get('results', [])
    
    summary = {
        'total': len(results),
        'error': 0,
        'warning': 0,
        'note': 0,
        'none': 0,
        'by_rule_prefix': {},
    }
    
    for result in results:
        level = result.get('level', 'warning')
        summary[level] = summary.get(level, 0) + 1
        
        rule_id = result.get('ruleId', '')
        prefix = rule_id.split('/')[0] if '/' in rule_id else 'OTHER'
        summary['by_rule_prefix'][prefix] = summary['by_rule_prefix'].get(prefix, 0) + 1
    
    return summary

def check_threshold(
    results: Dict[str, Any],
    threshold: str,
) -> tuple[bool, str]:
    """
    Check if findings exceed the specified threshold.
    
    Args:
        results: REACHABLE scan results
        threshold: One of 'critical', 'high', 'medium', 'any', 'none'
        
    Returns:
        Tuple of (should_fail: bool, reason: str)
    """
    if threshold == 'none':
        return False, "No threshold set"
    
    summary = results.get('summary', {})
    totals = summary.get('totals', {})
    
    # Only count REACHABLE findings for threshold
    critical = totals.get('cves_critical_reachable', 0) + totals.get('malware_count', 0)
    high = totals.get('cves_high_reachable', 0) + totals.get('secrets_reachable', 0)
    medium = totals.get('cves_medium_reachable', 0) + totals.get('cwe_reachable', 0)
    
    if threshold == 'critical':
        if critical > 0:
            return True, f"Found {critical} critical reachable findings"
        return False, "No critical reachable findings"
    
    elif threshold == 'high':
        if critical > 0:
            return True, f"Found {critical} critical reachable findings"
        if high > 0:
            return True, f"Found {high} high reachable findings"
        return False, "No critical/high reachable findings"
    
    elif threshold == 'medium':
        if critical > 0:
            return True, f"Found {critical} critical reachable findings"
        if high > 0:
            return True, f"Found {high} high reachable findings"
        if medium > 0:
            return True, f"Found {medium} medium reachable findings"
        return False, "No critical/high/medium reachable findings"
    
    elif threshold == 'any':
        total_reachable = totals.get('cves_reachable', 0) + totals.get('secrets_reachable', 0) + totals.get('cwe_reachable', 0) + totals.get('malware_count', 0)
        if total_reachable > 0:
            return True, f"Found {total_reachable} reachable findings"
        return False, "No reachable findings"
    
    return False, f"Unknown threshold: {threshold}"

if __name__ == '__main__':
    # Test with sample data
    sample_results = {
        'reachable_version': '4.5.0',
        'reachable': {
            'CVE-2024-1234': {
                'severity': 'HIGH',
                'package': 'requests',
                'version': '2.28.0',
                'description': 'Test vulnerability',
            }
        },
        'unreachable': {},
        'summary': {
            'totals': {
                'cves_total': 1,
                'cves_reachable': 1,
            }
        }
    }
    
    sarif = export_to_sarif(sample_results)
    print(json.dumps(sarif, indent=2))
