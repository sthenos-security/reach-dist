#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.

"""
REACHABLE - Reachability & Call Graph Diagnostic

This module diagnoses and fixes the core issues with reachability analysis.

CRITICAL BUGS FOUND:
====================

1. JAVASCRIPT PARSER - CALL GRAPH NEVER POPULATED
   Location: javascript_parser.py lines 134-141
   Bug: Code creates potential_func but NEVER adds it to call_graph!
   Result: JS call graph has 0 edges

2. GO PARSER - CALL GRAPH NEVER POPULATED  
   Location: go_parser.py lines 139-141
   Bug: Same issue - creates potential_func but doesn't use it
   Result: Go call graph has 0 edges

3. CVE FALLBACK MAPS ALL CVEs TO ALL ENTRYPOINTS
   Location: reachable.py lines 2244-2250
   Bug: When function_imports is empty (JS/Go), fallback to ALL entrypoints
   Result: ALL CVEs marked reachable (100%), 0% workload reduction

4. FUNCTION_IMPORTS NEVER POPULATED FOR JS/GO
   Location: javascript_parser.py, go_parser.py
   Bug: Parsers don't track which imports are used by which functions
   Result: Cannot determine which functions use vulnerable packages

5. REACHABILITY ONLY WORKS WITH CALL GRAPH EDGES
   Location: reachable.py _compute_reachability()
   Bug: BFS only follows edges - but we have almost no edges!
   Result: Only entrypoints are reachable (0.2%)

ROOT CAUSE SUMMARY:
==================
The core reachability algorithm is CORRECT, but the data it depends on is BROKEN:
- Call graph has no edges → BFS finds nothing
- Function imports empty → CVE fallback triggers
- CVE fallback = all entrypoints → 100% CVE reachability
- Result: Zero workload reduction, meaningless results
"""

import re
from pathlib import Path
from typing import Dict, Set, List, Tuple
from collections import defaultdict
import logging

# Initialize module-level logger
logger = logging.getLogger(__name__)

# =============================================================================
# FIXED JAVASCRIPT PARSER
# =============================================================================

class FixedJavaScriptParser:
    """
    Fixed JavaScript/TypeScript parser with ACTUAL call graph building.
    
    Key fixes:
    1. Track current function context
    2. Add ALL function calls to call graph (not just method calls)
    3. Track imports per function
    """
    
    def __init__(self):
        self.call_graph = defaultdict(set)  # caller -> set of callees
        self.imports_map = defaultdict(set)  # module -> set of imports
        self.function_imports = defaultdict(set)  # function -> set of imported packages
        self.all_functions = set()
        self.current_module = ""
    
    def parse_directory(self, directory: Path, prefix: str = "app") -> Tuple[Dict, Dict, Set, Dict]:
        """
        Parse all JavaScript/TypeScript files in directory.
        
        Returns:
            (call_graph, imports_map, all_functions, function_imports)
        """
        extensions = ['.js', '.ts', '.jsx', '.tsx', '.mjs', '.cjs']
        all_files = []
        
        for ext in extensions:
            all_files.extend(directory.rglob(f'*{ext}'))
        
        # Exclude node_modules, test files, etc.
        all_files = [f for f in all_files if 
                     'node_modules' not in str(f) and
                     '__tests__' not in str(f) and
                     '.test.' not in str(f) and
                     '.spec.' not in str(f) and
                     f.is_file()]
        
        for file_path in all_files:
            try:
                self._parse_file(file_path, prefix)
            except Exception as e:
                pass  # Skip unparseable files
        
        return (
            dict(self.call_graph),
            dict(self.imports_map),
            self.all_functions,
            dict(self.function_imports)
        )
    
    def _parse_file(self, file_path: Path, prefix: str):
        """Parse a single JavaScript/TypeScript file."""
        with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
            code = f.read()
        
        # Build module name from path
        try:
            rel_path = str(file_path.relative_to(file_path.parent.parent.parent))
        except:
            rel_path = str(file_path.name)
        
        module_name = rel_path.replace('/', '.').replace('\\', '.')
        for ext in ['.js', '.ts', '.jsx', '.tsx', '.mjs', '.cjs']:
            module_name = module_name.replace(ext, '')
        
        self.current_module = f"{prefix}.{module_name}"
        
        # Extract imports first (needed for function_imports tracking)
        imports = self._extract_imports(code)
        self.imports_map[self.current_module].update(imports)
        
        # Extract functions and their calls
        self._extract_functions_and_calls(code, imports)
    
    def _extract_imports(self, code: str) -> Set[str]:
        """Extract imported packages."""
        imports = set()
        
        patterns = [
            r'require\s*\(\s*[\'"]([^\'"]+)[\'"]\s*\)',  # require('module')
            r'import\s+.*?\s+from\s+[\'"]([^\'"]+)[\'"]',  # import ... from 'module'
            r'import\s*\(\s*[\'"]([^\'"]+)[\'"]\s*\)',  # dynamic import('module')
            r'import\s+[\'"]([^\'"]+)[\'"]',  # import 'module'
        ]
        
        for pattern in patterns:
            for match in re.finditer(pattern, code, re.MULTILINE):
                module = match.group(1)
                # Skip relative imports
                if not module.startswith('.') and not module.startswith('/'):
                    # Get package name (e.g., '@babel/core' -> '@babel/core', 'lodash/get' -> 'lodash')
                    if module.startswith('@'):
                        # Scoped package
                        parts = module.split('/')
                        if len(parts) >= 2:
                            imports.add('/'.join(parts[:2]))
                    else:
                        imports.add(module.split('/')[0])
        
        return imports
    
    def _extract_functions_and_calls(self, code: str, imports: Set[str]):
        """Extract function definitions and their calls."""
        
        # Remove comments and strings to avoid false positives
        clean_code = self._remove_comments_and_strings(code)
        
        # Function definition patterns
        func_patterns = [
            # function foo() {}
            (r'function\s+(\w+)\s*\([^)]*\)\s*\{', 'function'),
            # async function foo() {}
            (r'async\s+function\s+(\w+)\s*\([^)]*\)\s*\{', 'async_function'),
            # const foo = function() {}
            (r'(?:const|let|var)\s+(\w+)\s*=\s*function\s*\([^)]*\)\s*\{', 'var_function'),
            # const foo = () => {}
            (r'(?:const|let|var)\s+(\w+)\s*=\s*(?:async\s*)?\([^)]*\)\s*=>', 'arrow'),
            # const foo = async () => {}
            (r'(?:const|let|var)\s+(\w+)\s*=\s*async\s+\([^)]*\)\s*=>', 'async_arrow'),
            # class method: foo() {}
            (r'^\s+(\w+)\s*\([^)]*\)\s*\{', 'method'),
            # object method: foo: function() {}
            (r'(\w+)\s*:\s*(?:async\s*)?function\s*\([^)]*\)\s*\{', 'object_method'),
            # object method: foo() {} (shorthand)
            (r'(\w+)\s*\([^)]*\)\s*\{', 'shorthand_method'),
        ]
        
        functions_found = []
        
        for pattern, func_type in func_patterns:
            for match in re.finditer(pattern, clean_code, re.MULTILINE):
                func_name = match.group(1)
                # Skip keywords
                if func_name in ['if', 'for', 'while', 'switch', 'catch', 'with', 'return', 
                                'new', 'class', 'import', 'export', 'default', 'async', 'await']:
                    continue
                
                start_pos = match.start()
                qualified_name = f"{self.current_module}.{func_name}"
                self.all_functions.add(qualified_name)
                
                # Find function body to extract calls
                body_start = match.end() - 1  # Position of opening brace
                body = self._extract_function_body(clean_code, body_start)
                
                if body:
                    functions_found.append((qualified_name, body, start_pos))
        
        # Sort by position to handle nested functions correctly
        functions_found.sort(key=lambda x: x[2])
        
        # Extract calls from each function
        for qualified_name, body, _ in functions_found:
            calls = self._extract_calls(body)
            
            for call in calls:
                # Add to call graph
                self.call_graph[qualified_name].add(call)
                
                # Check if call uses an imported package
                call_base = call.split('.')[0] if '.' in call else call
                for imp in imports:
                    if call_base == imp or call_base == imp.replace('-', '').replace('/', ''):
                        self.function_imports[qualified_name].add(imp)
    
    def _remove_comments_and_strings(self, code: str) -> str:
        """Remove comments and string literals to avoid false positives."""
        # Remove single-line comments
        code = re.sub(r'//.*$', '', code, flags=re.MULTILINE)
        # Remove multi-line comments
        code = re.sub(r'/\*[\s\S]*?\*/', '', code)
        # Replace string contents (but keep structure)
        code = re.sub(r'"[^"\\]*(?:\\.[^"\\]*)*"', '""', code)
        code = re.sub(r"'[^'\\]*(?:\\.[^'\\]*)*'", "''", code)
        code = re.sub(r'`[^`\\]*(?:\\.[^`\\]*)*`', '``', code)
        return code
    
    def _extract_function_body(self, code: str, start: int) -> str:
        """Extract function body by matching braces."""
        if start >= len(code) or code[start] != '{':
            return ""
        
        depth = 0
        end = start
        
        for i in range(start, min(start + 50000, len(code))):  # Limit search
            char = code[i]
            if char == '{':
                depth += 1
            elif char == '}':
                depth -= 1
                if depth == 0:
                    end = i
                    break
        
        return code[start:end+1] if end > start else ""
    
    def _extract_calls(self, body: str) -> Set[str]:
        """Extract function calls from function body."""
        calls = set()
        
        # Pattern for function calls
        # Matches: foo(), bar.baz(), this.method(), await fetch()
        call_pattern = r'(?:await\s+)?(\w+(?:\.\w+)*)\s*\('
        
        for match in re.finditer(call_pattern, body):
            call = match.group(1)
            
            # Skip built-ins and keywords
            skip_names = {
                'if', 'for', 'while', 'switch', 'catch', 'with', 'return', 
                'new', 'throw', 'typeof', 'instanceof', 'delete', 'void',
                'console', 'Math', 'JSON', 'Object', 'Array', 'String',
                'Number', 'Boolean', 'Date', 'RegExp', 'Error', 'Promise',
                'Map', 'Set', 'WeakMap', 'WeakSet', 'Symbol', 'Proxy',
                'Reflect', 'Intl', 'require', 'import', 'export',
                'parseInt', 'parseFloat', 'isNaN', 'isFinite',
                'encodeURI', 'decodeURI', 'encodeURIComponent', 'decodeURIComponent',
                'setTimeout', 'setInterval', 'clearTimeout', 'clearInterval',
                'alert', 'confirm', 'prompt', 'fetch', 'XMLHttpRequest',
            }
            
            call_base = call.split('.')[0]
            if call_base not in skip_names:
                # Qualify local calls with module
                if '.' not in call:
                    call = f"{self.current_module}.{call}"
                calls.add(call)
        
        return calls

# =============================================================================
# FIXED GO PARSER
# =============================================================================

class FixedGoParser:
    """
    Fixed Go parser with ACTUAL call graph building.
    
    Key fixes:
    1. Track current function context
    2. Add ALL function calls to call graph
    3. Track imports per function
    """
    
    def __init__(self):
        self.call_graph = defaultdict(set)
        self.imports_map = defaultdict(set)
        self.function_imports = defaultdict(set)
        self.all_functions = set()
        self.current_module = ""
        self.package_name = ""
    
    def parse_directory(self, directory: Path, prefix: str = "app") -> Tuple[Dict, Dict, Set, Dict]:
        """Parse all Go files in directory."""
        go_files = list(directory.rglob('*.go'))
        go_files = [f for f in go_files if 
                    'vendor' not in str(f) and
                    '_test.go' not in str(f) and
                    f.is_file()]
        
        for file_path in go_files:
            try:
                self._parse_file(file_path, prefix)
            except Exception as e:
                pass
        
        return (
            dict(self.call_graph),
            dict(self.imports_map),
            self.all_functions,
            dict(self.function_imports)
        )
    
    def _parse_file(self, file_path: Path, prefix: str):
        """Parse a single Go file."""
        with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
            code = f.read()
        
        # Get module name from package declaration and path
        package_match = re.search(r'^\s*package\s+(\w+)', code, re.MULTILINE)
        if package_match:
            self.package_name = package_match.group(1)
        
        try:
            rel_path = str(file_path.parent.relative_to(file_path.parent.parent.parent))
        except:
            rel_path = file_path.parent.name
        
        module_name = rel_path.replace('/', '.').replace('\\', '.')
        self.current_module = f"{prefix}.{module_name}"
        
        # Extract imports
        imports = self._extract_imports(code)
        self.imports_map[self.current_module].update(imports)
        
        # Extract functions and their calls
        self._extract_functions_and_calls(code, imports)
    
    def _extract_imports(self, code: str) -> Set[str]:
        """Extract imported packages."""
        imports = set()
        
        # Single import
        for match in re.finditer(r'import\s+"([^"]+)"', code):
            imports.add(match.group(1))
        
        # Import block
        import_blocks = re.findall(r'import\s+\(([\s\S]*?)\)', code)
        for block in import_blocks:
            for match in re.finditer(r'"([^"]+)"', block):
                imports.add(match.group(1))
        
        # Named import
        for match in re.finditer(r'import\s+\w+\s+"([^"]+)"', code):
            imports.add(match.group(1))
        
        return imports
    
    def _extract_functions_and_calls(self, code: str, imports: Set[str]):
        """Extract function definitions and their calls."""
        
        # Remove comments
        code = re.sub(r'//.*$', '', code, flags=re.MULTILINE)
        code = re.sub(r'/\*[\s\S]*?\*/', '', code)
        
        # Function patterns
        func_patterns = [
            # Regular function: func Name(params) { or func Name(params) rettype {
            r'func\s+([A-Za-z_][A-Za-z0-9_]*)\s*\([^)]*\)[^{]*\{',
            # Method: func (r Type) Name(params) { or func (r *Type) Name(params) {
            r'func\s+\([^)]+\)\s+([A-Za-z_][A-Za-z0-9_]*)\s*\([^)]*\)[^{]*\{',
        ]
        
        for pattern in func_patterns:
            for match in re.finditer(pattern, code):
                func_name = match.group(1)
                qualified_name = f"{self.current_module}.{func_name}"
                self.all_functions.add(qualified_name)
                
                # Extract function body
                body_start = match.end() - 1
                body = self._extract_function_body(code, body_start)
                
                if body:
                    calls = self._extract_calls(body, imports)
                    
                    for call, is_imported in calls:
                        self.call_graph[qualified_name].add(call)
                        
                        if is_imported:
                            # Track which imports this function uses
                            call_pkg = call.split('.')[0] if '.' in call else ''
                            for imp in imports:
                                if imp.endswith('/' + call_pkg) or imp == call_pkg:
                                    self.function_imports[qualified_name].add(imp)
    
    def _extract_function_body(self, code: str, start: int) -> str:
        """Extract function body by matching braces."""
        if start >= len(code) or code[start] != '{':
            return ""
        
        depth = 0
        end = start
        
        for i in range(start, min(start + 100000, len(code))):
            char = code[i]
            if char == '{':
                depth += 1
            elif char == '}':
                depth -= 1
                if depth == 0:
                    end = i
                    break
        
        return code[start:end+1] if end > start else ""
    
    def _extract_calls(self, body: str, imports: Set[str]) -> List[Tuple[str, bool]]:
        """Extract function calls from function body."""
        calls = []
        
        # Go call pattern: identifier() or pkg.Function() or obj.Method()
        call_pattern = r'([a-zA-Z_][a-zA-Z0-9_]*(?:\.[a-zA-Z_][a-zA-Z0-9_]*)*)\s*\('
        
        skip_keywords = {
            'if', 'for', 'switch', 'select', 'case', 'return', 'defer', 'go',
            'func', 'make', 'new', 'len', 'cap', 'append', 'copy', 'delete',
            'panic', 'recover', 'print', 'println', 'close', 'complex', 'real', 'imag',
            'range', 'type', 'struct', 'interface', 'map', 'chan',
        }
        
        for match in re.finditer(call_pattern, body):
            call = match.group(1)
            call_base = call.split('.')[0]
            
            if call_base in skip_keywords:
                continue
            
            # Check if this is a call to an imported package
            is_imported = False
            if '.' in call:
                pkg = call.split('.')[0]
                for imp in imports:
                    imp_pkg = imp.split('/')[-1]
                    if pkg == imp_pkg:
                        is_imported = True
                        break
            
            # Qualify with module if local call
            if '.' not in call:
                call = f"{self.current_module}.{call}"
            
            calls.append((call, is_imported))
        
        return calls

# =============================================================================
# DIAGNOSTIC FUNCTIONS
# =============================================================================

def diagnose_call_graph(call_graph: Dict, all_functions: Set, entrypoints: Set) -> Dict:
    """
    Diagnose call graph quality.
    
    Returns diagnostic report.
    """
    total_functions = len(all_functions)
    total_edges = sum(len(callees) for callees in call_graph.values())
    callers = len(call_graph)
    
    # Compute reachability
    reachable = set(entrypoints)
    queue = list(entrypoints)
    while queue:
        func = queue.pop(0)
        for callee in call_graph.get(func, set()):
            if callee not in reachable and callee in all_functions:
                reachable.add(callee)
                queue.append(callee)
    
    unreachable = all_functions - reachable
    
    # Calculate metrics
    avg_outdegree = total_edges / callers if callers > 0 else 0
    connectivity = callers / total_functions if total_functions > 0 else 0
    reachability_pct = len(reachable) / total_functions * 100 if total_functions > 0 else 0
    
    return {
        'summary': {
            'total_functions': total_functions,
            'total_edges': total_edges,
            'callers_with_edges': callers,
            'avg_outdegree': round(avg_outdegree, 2),
            'connectivity': round(connectivity * 100, 1),
            'entrypoints': len(entrypoints),
            'reachable': len(reachable),
            'unreachable': len(unreachable),
            'reachability_pct': round(reachability_pct, 1),
        },
        'health': {
            'has_edges': total_edges > 0,
            'reasonable_edges': total_edges > total_functions * 0.5,
            'good_connectivity': connectivity > 0.1,
            'effective_reachability': reachability_pct < 50,  # <50% = some code is filtered
        },
        'issues': get_issues(total_edges, total_functions, connectivity, reachability_pct),
        'reachable_functions': sorted(reachable)[:50],
        'sample_edges': dict(list(call_graph.items())[:10]),
    }

def get_issues(edges: int, funcs: int, connectivity: float, reach_pct: float) -> List[str]:
    """Identify issues with call graph."""
    issues = []
    
    if edges == 0:
        issues.append("CRITICAL: Call graph has ZERO edges - reachability analysis is ineffective")
    elif edges < funcs * 0.1:
        issues.append(f"WARNING: Very few edges ({edges}) for {funcs} functions - call extraction may be incomplete")
    
    if connectivity < 0.05:
        issues.append("WARNING: Low connectivity - most functions don't call other functions")
    
    if reach_pct > 90:
        issues.append("WARNING: >90% reachability suggests all CVEs will be marked reachable")
    elif reach_pct > 70:
        issues.append("NOTE: High reachability (>70%) - limited CVE filtering possible")
    
    if not issues:
        issues.append("OK: Call graph appears healthy")
    
    return issues

# =============================================================================
# TEST
# =============================================================================

if __name__ == '__main__':
    print("=" * 70)
    logger.info("REACHABLE - Call Graph & Reachability Diagnostic")
    print("=" * 70)
    
    # Test JavaScript parser on sample code
    js_code = '''
    import React from 'react';
    import axios from 'axios';
import logging

# Initialize module-level logger
logger = logging.getLogger(__name__)

# Initialize module-level logger
logger = logging.getLogger(__name__)
    
    function fetchData() {
        return axios.get('/api/data');
    }
    
    function processData(data) {
        return data.map(item => item.value);
    }
    
    async function main() {
        const data = await fetchData();
        const processed = processData(data);
        console.log(processed);
    }
    
    export default main;
    '''
    
    logger.info("\n[TEST] JavaScript Parser")
    print("-" * 40)
    
    # Simulate parsing
    parser = FixedJavaScriptParser()
    parser.current_module = "app.test"
    imports = parser._extract_imports(js_code)
    logger.info(f"Imports: {imports}")
    
    parser._extract_functions_and_calls(js_code, imports)
    logger.info(f"Functions: {parser.all_functions}")
    logger.info(f"Call graph: {dict(parser.call_graph)}")
    logger.info(f"Function imports: {dict(parser.function_imports)}")
    
    # Diagnose
    logger.info("\n[DIAGNOSTIC]")
    print("-" * 40)
    
    entrypoints = {'app.test.main'}
    diag = diagnose_call_graph(dict(parser.call_graph), parser.all_functions, entrypoints)
    
    logger.info(f"Summary: {diag['summary']}")
    logger.info(f"Health: {diag['health']}")
    logger.info(f"Issues: {diag['issues']}")
