#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.

"""
REACHABLE Smart Cache System

Provides efficient caching across multiple runs over the same repository.
Caches are keyed by content hashes so only changed files/packages are reprocessed.

CACHEABLE ITEMS:
1. AST/Call Graph - Per-file, keyed by file content hash
2. Package Malware - Per-package+version, keyed by name@version
3. CVE/Vulnerability - Per-lockfile, keyed by lockfile hash
4. Exploitability - Per-CVE, with TTL (KEV=24h, EPSS=24h)
5. Health Metrics - Per-package, with TTL (7 days)
6. Secrets Scan - Per-file, keyed by file content hash
7. SAST Findings - Per-file, keyed by file content hash

CACHE LOCATION:
- Default: ~/.reachable/cache/
- Per-repo: .reachable/cache/ (gitignored)
- Configurable via REACHABLE_CACHE_DIR

CACHE FORMAT:
- SQLite database for metadata + small items
- JSON files for large items (call graphs)
- Compressed with gzip for space efficiency
"""

import os
import json
import gzip
import sqlite3
import hashlib
import time
from pathlib import Path
from typing import Dict, List, Any, Optional, Tuple
from dataclasses import dataclass, field
from datetime import datetime, timedelta
import threading
import logging

# Initialize module-level logger
logger = logging.getLogger(__name__)

# TTL defaults (in seconds)
TTL_AST = 0  # Never expires (content-hashed)
TTL_MALWARE = 86400 * 7  # 7 days
TTL_CVE_SCAN = 86400  # 24 hours (new CVEs published daily)
TTL_KEV = 86400  # 24 hours
TTL_EPSS = 86400  # 24 hours
TTL_EXPLOIT_DB = 86400 * 3  # 3 days
TTL_HEALTH = 86400 * 7  # 7 days
TTL_SECRETS = 0  # Never expires (content-hashed)
TTL_SAST = 0  # Never expires (content-hashed)

@dataclass
class CacheStats:
    """Statistics for cache performance"""
    hits: int = 0
    misses: int = 0
    writes: int = 0
    evictions: int = 0
    bytes_saved: int = 0
    time_saved_ms: float = 0.0
    
    # Per-category stats
    by_category: Dict[str, Dict[str, int]] = field(default_factory=dict)
    
    def record_hit(self, category: str, size_bytes: int = 0, time_ms: float = 0.0):
        self.hits += 1
        self.bytes_saved += size_bytes
        self.time_saved_ms += time_ms
        if category not in self.by_category:
            self.by_category[category] = {'hits': 0, 'misses': 0}
        self.by_category[category]['hits'] += 1
    
    def record_miss(self, category: str):
        self.misses += 1
        if category not in self.by_category:
            self.by_category[category] = {'hits': 0, 'misses': 0}
        self.by_category[category]['misses'] += 1
    
    def hit_rate(self) -> float:
        total = self.hits + self.misses
        return (self.hits / total * 100) if total > 0 else 0.0
    
    def to_dict(self) -> Dict:
        return {
            'hits': self.hits,
            'misses': self.misses,
            'writes': self.writes,
            'evictions': self.evictions,
            'hit_rate': f"{self.hit_rate():.1f}%",
            'bytes_saved': self.bytes_saved,
            'time_saved_ms': round(self.time_saved_ms, 2),
            'by_category': self.by_category
        }

class ReachableCache:
    """
    Smart cache for REACHABLE analysis results.
    Uses SQLite for metadata and JSON files for large objects.
    """
    
    SCHEMA = """
    CREATE TABLE IF NOT EXISTS cache_metadata (
        key TEXT PRIMARY KEY,
        category TEXT NOT NULL,
        content_hash TEXT,
        created_at REAL NOT NULL,
        expires_at REAL,
        size_bytes INTEGER,
        hit_count INTEGER DEFAULT 0,
        last_accessed REAL,
        is_file INTEGER DEFAULT 0,
        file_path TEXT
    );
    
    CREATE TABLE IF NOT EXISTS cache_data (
        key TEXT PRIMARY KEY,
        data BLOB NOT NULL,
        compressed INTEGER DEFAULT 0
    );
    
    CREATE TABLE IF NOT EXISTS file_hashes (
        file_path TEXT PRIMARY KEY,
        content_hash TEXT NOT NULL,
        mtime REAL NOT NULL,
        size_bytes INTEGER NOT NULL
    );
    
    CREATE INDEX IF NOT EXISTS idx_category ON cache_metadata(category);
    CREATE INDEX IF NOT EXISTS idx_expires ON cache_metadata(expires_at);
    CREATE INDEX IF NOT EXISTS idx_content_hash ON cache_metadata(content_hash);
    """
    
    def __init__(self, cache_dir: str = None, repo_path: str = None):
        """
        Initialize cache.
        
        Args:
            cache_dir: Explicit cache directory (overrides defaults)
            repo_path: Repository path (for per-repo caching)
        """
        self.cache_dir = self._resolve_cache_dir(cache_dir, repo_path)
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        
        self.db_path = self.cache_dir / "cache.db"
        self.data_dir = self.cache_dir / "data"
        self.data_dir.mkdir(exist_ok=True)
        
        self._local = threading.local()
        self._init_db()
        
        self.stats = CacheStats()
        self.verbose = False
    
    def _resolve_cache_dir(self, cache_dir: str, repo_path: str) -> Path:
        """Resolve cache directory location"""
        if cache_dir:
            return Path(cache_dir)
        
        # Check environment variable
        env_cache = os.environ.get('REACHABLE_CACHE_DIR')
        if env_cache:
            return Path(env_cache)
        
        # Per-repo cache (preferred for repo-specific data)
        if repo_path:
            repo_cache = Path(repo_path) / ".reachable" / "cache"
            if repo_cache.parent.exists() or not (Path.home() / ".reachable").exists():
                return repo_cache
        
        # Global cache
        return Path.home() / ".reachable" / "cache"
    
    @property
    def _conn(self) -> sqlite3.Connection:
        """Thread-local database connection"""
        if not hasattr(self._local, 'conn') or self._local.conn is None:
            self._local.conn = sqlite3.connect(str(self.db_path), timeout=30)
            self._local.conn.row_factory = sqlite3.Row
        return self._local.conn
    
    def _init_db(self):
        """Initialize database schema"""
        self._conn.executescript(self.SCHEMA)
        self._conn.commit()
    
    def _hash_content(self, content: bytes) -> str:
        """Generate SHA256 hash of content"""
        return hashlib.sha256(content).hexdigest()[:16]
    
    def _hash_file(self, file_path: Path) -> str:
        """Get or compute file content hash (with mtime optimization)"""
        path_str = str(file_path.resolve())
        stat = file_path.stat()
        
        # Check if we have a cached hash with matching mtime
        cursor = self._conn.execute(
            "SELECT content_hash, mtime FROM file_hashes WHERE file_path = ?",
            (path_str,)
        )
        row = cursor.fetchone()
        
        if row and abs(row['mtime'] - stat.st_mtime) < 0.001:
            return row['content_hash']
        
        # Compute new hash
        content_hash = self._hash_content(file_path.read_bytes())
        
        # Cache the hash
        self._conn.execute(
            """INSERT OR REPLACE INTO file_hashes 
               (file_path, content_hash, mtime, size_bytes) VALUES (?, ?, ?, ?)""",
            (path_str, content_hash, stat.st_mtime, stat.st_size)
        )
        self._conn.commit()
        
        return content_hash
    
    def _make_key(self, category: str, identifier: str, content_hash: str = None) -> str:
        """Create cache key"""
        if content_hash:
            return f"{category}:{identifier}:{content_hash}"
        return f"{category}:{identifier}"
    
    def get(self, category: str, identifier: str, content_hash: str = None) -> Optional[Any]:
        """
        Get item from cache.
        
        Args:
            category: Cache category (ast, malware, cve, etc.)
            identifier: Unique identifier within category
            content_hash: Optional content hash for content-addressed items
            
        Returns:
            Cached data or None if not found/expired
        """
        key = self._make_key(category, identifier, content_hash)
        now = time.time()
        
        # Check metadata
        cursor = self._conn.execute(
            """SELECT * FROM cache_metadata WHERE key = ? 
               AND (expires_at IS NULL OR expires_at > ?)""",
            (key, now)
        )
        meta = cursor.fetchone()
        
        if not meta:
            self.stats.record_miss(category)
            return None
        
        # Get data
        if meta['is_file']:
            file_path = Path(meta['file_path'])
            if not file_path.exists():
                self.stats.record_miss(category)
                return None
            with gzip.open(file_path, 'rt', encoding='utf-8') as f:
                data = json.load(f)
        else:
            cursor = self._conn.execute(
                "SELECT data, compressed FROM cache_data WHERE key = ?", (key,)
            )
            row = cursor.fetchone()
            if not row:
                self.stats.record_miss(category)
                return None
            
            raw_data = row['data']
            if row['compressed']:
                raw_data = gzip.decompress(raw_data)
            data = json.loads(raw_data)
        
        # Update access stats
        self._conn.execute(
            """UPDATE cache_metadata SET hit_count = hit_count + 1, 
               last_accessed = ? WHERE key = ?""",
            (now, key)
        )
        self._conn.commit()
        
        self.stats.record_hit(category, meta['size_bytes'] or 0)
        
        if self.verbose:
            logger.info(f"   💾 Cache HIT: {category}:{identifier[:30]}...")
        
        return data
    
    def set(self, category: str, identifier: str, data: Any, 
            content_hash: str = None, ttl: int = None) -> None:
        """
        Store item in cache.
        
        Args:
            category: Cache category
            identifier: Unique identifier
            data: Data to cache (must be JSON serializable)
            content_hash: Optional content hash
            ttl: Time-to-live in seconds (None = never expires)
        """
        key = self._make_key(category, identifier, content_hash)
        now = time.time()
        expires_at = now + ttl if ttl else None
        
        # Serialize data
        json_data = json.dumps(data, separators=(',', ':'))
        size_bytes = len(json_data)
        
        # Decide storage: file for large items, DB for small
        is_file = size_bytes > 100_000  # 100KB threshold
        file_path = None
        
        if is_file:
            # Store in compressed file
            file_name = hashlib.sha256(key.encode()).hexdigest()[:32] + ".json.gz"
            file_path = self.data_dir / file_name
            with gzip.open(file_path, 'wt', encoding='utf-8') as f:
                f.write(json_data)
        else:
            # Store in DB (compress if beneficial)
            compressed = 0
            stored_data = json_data.encode()
            if size_bytes > 1000:
                compressed_data = gzip.compress(stored_data)
                if len(compressed_data) < len(stored_data) * 0.8:
                    stored_data = compressed_data
                    compressed = 1
            
            self._conn.execute(
                "INSERT OR REPLACE INTO cache_data (key, data, compressed) VALUES (?, ?, ?)",
                (key, stored_data, compressed)
            )
        
        # Store metadata
        self._conn.execute(
            """INSERT OR REPLACE INTO cache_metadata 
               (key, category, content_hash, created_at, expires_at, 
                size_bytes, hit_count, last_accessed, is_file, file_path)
               VALUES (?, ?, ?, ?, ?, ?, 0, ?, ?, ?)""",
            (key, category, content_hash, now, expires_at, 
             size_bytes, now, 1 if is_file else 0, str(file_path) if file_path else None)
        )
        self._conn.commit()
        
        self.stats.writes += 1
        
        if self.verbose:
            logger.info(f"   💾 Cache WRITE: {category}:{identifier[:30]}... ({size_bytes} bytes)")
    
    def invalidate(self, category: str = None, identifier: str = None) -> int:
        """
        Invalidate cache entries.
        
        Args:
            category: Optional category to invalidate
            identifier: Optional identifier pattern to match
            
        Returns:
            Number of entries invalidated
        """
        if category and identifier:
            key_pattern = f"{category}:{identifier}%"
            cursor = self._conn.execute(
                "SELECT key, is_file, file_path FROM cache_metadata WHERE key LIKE ?",
                (key_pattern,)
            )
        elif category:
            cursor = self._conn.execute(
                "SELECT key, is_file, file_path FROM cache_metadata WHERE category = ?",
                (category,)
            )
        else:
            cursor = self._conn.execute(
                "SELECT key, is_file, file_path FROM cache_metadata"
            )
        
        rows = cursor.fetchall()
        count = 0
        
        for row in rows:
            if row['is_file'] and row['file_path']:
                file_path = Path(row['file_path'])
                if file_path.exists():
                    file_path.unlink()
            
            self._conn.execute("DELETE FROM cache_data WHERE key = ?", (row['key'],))
            self._conn.execute("DELETE FROM cache_metadata WHERE key = ?", (row['key'],))
            count += 1
        
        self._conn.commit()
        self.stats.evictions += count
        return count
    
    def cleanup_expired(self) -> int:
        """Remove expired entries"""
        now = time.time()
        
        cursor = self._conn.execute(
            """SELECT key, is_file, file_path FROM cache_metadata 
               WHERE expires_at IS NOT NULL AND expires_at < ?""",
            (now,)
        )
        rows = cursor.fetchall()
        
        for row in rows:
            if row['is_file'] and row['file_path']:
                file_path = Path(row['file_path'])
                if file_path.exists():
                    file_path.unlink()
        
        self._conn.execute(
            "DELETE FROM cache_data WHERE key IN (SELECT key FROM cache_metadata WHERE expires_at < ?)",
            (now,)
        )
        self._conn.execute(
            "DELETE FROM cache_metadata WHERE expires_at IS NOT NULL AND expires_at < ?",
            (now,)
        )
        self._conn.commit()
        
        count = len(rows)
        self.stats.evictions += count
        return count
    
    def get_stats(self) -> Dict:
        """Get cache statistics"""
        cursor = self._conn.execute("""
            SELECT category, COUNT(*) as count, SUM(size_bytes) as total_bytes,
                   SUM(hit_count) as total_hits
            FROM cache_metadata GROUP BY category
        """)
        
        by_category = {}
        for row in cursor.fetchall():
            by_category[row['category']] = {
                'entries': row['count'],
                'bytes': row['total_bytes'] or 0,
                'hits': row['total_hits'] or 0
            }
        
        cursor = self._conn.execute(
            "SELECT COUNT(*) as total, SUM(size_bytes) as total_bytes FROM cache_metadata"
        )
        totals = cursor.fetchone()
        
        return {
            'location': str(self.cache_dir),
            'total_entries': totals['total'],
            'total_bytes': totals['total_bytes'] or 0,
            'total_mb': round((totals['total_bytes'] or 0) / 1024 / 1024, 2),
            'by_category': by_category,
            'session_stats': self.stats.to_dict()
        }
    
    # =========================================================================
    # HIGH-LEVEL CACHE METHODS FOR SPECIFIC DATA TYPES
    # =========================================================================
    
    def get_file_ast(self, file_path: Path) -> Optional[Dict]:
        """Get cached AST for a file"""
        content_hash = self._hash_file(file_path)
        return self.get('ast', str(file_path), content_hash)
    
    def set_file_ast(self, file_path: Path, ast_data: Dict) -> None:
        """Cache AST for a file"""
        content_hash = self._hash_file(file_path)
        self.set('ast', str(file_path), ast_data, content_hash, TTL_AST)
    
    def get_file_call_graph(self, file_path: Path) -> Optional[Dict]:
        """Get cached call graph edges for a file"""
        content_hash = self._hash_file(file_path)
        return self.get('callgraph', str(file_path), content_hash)
    
    def set_file_call_graph(self, file_path: Path, edges: Dict) -> None:
        """Cache call graph edges for a file"""
        content_hash = self._hash_file(file_path)
        self.set('callgraph', str(file_path), edges, content_hash, TTL_AST)
    
    def get_package_malware(self, package: str, version: str) -> Optional[Dict]:
        """Get cached malware scan for package"""
        identifier = f"{package}@{version}"
        return self.get('malware', identifier)
    
    def set_package_malware(self, package: str, version: str, result: Dict) -> None:
        """Cache malware scan for package"""
        identifier = f"{package}@{version}"
        self.set('malware', identifier, result, ttl=TTL_MALWARE)
    
    def get_lockfile_cves(self, lockfile_path: Path) -> Optional[Dict]:
        """Get cached CVE scan for lockfile"""
        content_hash = self._hash_file(lockfile_path)
        return self.get('cve', str(lockfile_path), content_hash)
    
    def set_lockfile_cves(self, lockfile_path: Path, cves: Dict) -> None:
        """Cache CVE scan for lockfile"""
        content_hash = self._hash_file(lockfile_path)
        self.set('cve', str(lockfile_path), cves, content_hash, TTL_CVE_SCAN)
    
    def get_cve_kev(self, cve_id: str) -> Optional[Dict]:
        """Get cached KEV status for CVE"""
        return self.get('kev', cve_id)
    
    def set_cve_kev(self, cve_id: str, kev_data: Dict) -> None:
        """Cache KEV status for CVE"""
        self.set('kev', cve_id, kev_data, ttl=TTL_KEV)
    
    def get_cve_epss(self, cve_id: str) -> Optional[Dict]:
        """Get cached EPSS score for CVE"""
        return self.get('epss', cve_id)
    
    def set_cve_epss(self, cve_id: str, epss_data: Dict) -> None:
        """Cache EPSS score for CVE"""
        self.set('epss', cve_id, epss_data, ttl=TTL_EPSS)
    
    def get_cve_exploits(self, cve_id: str) -> Optional[Dict]:
        """Get cached exploit info for CVE"""
        return self.get('exploits', cve_id)
    
    def set_cve_exploits(self, cve_id: str, exploit_data: Dict) -> None:
        """Cache exploit info for CVE"""
        self.set('exploits', cve_id, exploit_data, ttl=TTL_EXPLOIT_DB)
    
    def get_package_health(self, package: str) -> Optional[Dict]:
        """Get cached health metrics for package"""
        return self.get('health', package)
    
    def set_package_health(self, package: str, health_data: Dict) -> None:
        """Cache health metrics for package"""
        self.set('health', package, health_data, ttl=TTL_HEALTH)
    
    def get_file_secrets(self, file_path: Path) -> Optional[List]:
        """Get cached secrets scan for file"""
        content_hash = self._hash_file(file_path)
        return self.get('secrets', str(file_path), content_hash)
    
    def set_file_secrets(self, file_path: Path, secrets: List) -> None:
        """Cache secrets scan for file"""
        content_hash = self._hash_file(file_path)
        self.set('secrets', str(file_path), secrets, content_hash, TTL_SECRETS)
    
    def get_file_sast(self, file_path: Path) -> Optional[List]:
        """Get cached SAST findings for file"""
        content_hash = self._hash_file(file_path)
        return self.get('sast', str(file_path), content_hash)
    
    def set_file_sast(self, file_path: Path, findings: List) -> None:
        """Cache SAST findings for file"""
        content_hash = self._hash_file(file_path)
        self.set('sast', str(file_path), findings, content_hash, TTL_SAST)
    
    def get_kev_catalog(self) -> Optional[Dict]:
        """Get cached KEV catalog"""
        return self.get('kev_catalog', 'full')
    
    def set_kev_catalog(self, catalog: Dict) -> None:
        """Cache full KEV catalog"""
        self.set('kev_catalog', 'full', catalog, ttl=TTL_KEV)

# ============================================================================
# DIFFERENTIAL ANALYSIS
# ============================================================================

class DifferentialAnalyzer:
    """
    Determines what needs to be re-analyzed based on changes.
    """
    
    def __init__(self, cache: ReachableCache, repo_path: Path):
        self.cache = cache
        self.repo_path = repo_path
    
    def get_changed_files(self, file_paths: List[Path]) -> Tuple[List[Path], List[Path]]:
        """
        Split files into changed and unchanged based on cache.
        
        Returns:
            (changed_files, unchanged_files)
        """
        changed = []
        unchanged = []
        
        for file_path in file_paths:
            # Check if we have cached data for this file's current content
            content_hash = self.cache._hash_file(file_path)
            cached = self.cache.get('ast', str(file_path), content_hash)
            
            if cached is not None:
                unchanged.append(file_path)
            else:
                changed.append(file_path)
        
        return changed, unchanged
    
    def get_changed_packages(self, packages: Dict[str, str]) -> Tuple[Dict, Dict]:
        """
        Split packages into changed and unchanged.
        
        Args:
            packages: Dict of {name: version}
            
        Returns:
            (changed_packages, unchanged_packages)
        """
        changed = {}
        unchanged = {}
        
        for name, version in packages.items():
            cached = self.cache.get_package_malware(name, version)
            if cached is not None:
                unchanged[name] = version
            else:
                changed[name] = version
        
        return changed, unchanged

# ============================================================================
# CACHE-AWARE CALL GRAPH BUILDER
# ============================================================================

class CachedCallGraphBuilder:
    """
    Builds call graph incrementally using cache.
    Only parses changed files.
    """
    
    def __init__(self, cache: ReachableCache):
        self.cache = cache
        self.stats = {
            'files_from_cache': 0,
            'files_parsed': 0,
            'time_saved_ms': 0.0
        }
    
    def build_for_files(self, file_paths: List[Path], parse_func) -> Dict:
        """
        Build call graph for files, using cache where possible.
        
        Args:
            file_paths: List of files to process
            parse_func: Function to parse a file (called only for cache misses)
            
        Returns:
            Combined call graph edges
        """
        all_edges = {}
        
        for file_path in file_paths:
            # Try cache first
            cached = self.cache.get_file_call_graph(file_path)
            
            if cached is not None:
                self.stats['files_from_cache'] += 1
                all_edges.update(cached)
            else:
                # Parse file
                import time
                start = time.time()
                edges = parse_func(file_path)
                elapsed = (time.time() - start) * 1000
                
                # Cache result
                self.cache.set_file_call_graph(file_path, edges)
                
                self.stats['files_parsed'] += 1
                all_edges.update(edges)
        
        return all_edges

# Singleton cache instance
_cache_instance: Optional[ReachableCache] = None

def get_cache(repo_path: str = None) -> ReachableCache:
    """Get or create cache instance"""
    global _cache_instance
    if _cache_instance is None:
        _cache_instance = ReachableCache(repo_path=repo_path)
    return _cache_instance

def reset_cache(repo_path: str = None) -> ReachableCache:
    """Reset cache instance"""
    global _cache_instance
    _cache_instance = ReachableCache(repo_path=repo_path)
    return _cache_instance

if __name__ == '__main__':
    print("=" * 70)
    logger.info("REACHABLE Smart Cache System - Demo")
    print("=" * 70)
    
    # Create cache
    cache = ReachableCache(cache_dir="/tmp/reachable-cache-demo")
    cache.verbose = True
    
    # Simulate caching
    logger.info("\n1. Caching CVE data...")
    cache.set_cve_kev('CVE-2023-1234', {'in_catalog': True, 'date_added': '2023-06-15'})
    cache.set_cve_epss('CVE-2023-1234', {'score': 0.85, 'percentile': 0.95})
    
    logger.info("\n2. Retrieving from cache...")
    kev = cache.get_cve_kev('CVE-2023-1234')
    epss = cache.get_cve_epss('CVE-2023-1234')
    logger.info(f"   KEV: {kev}")
    logger.info(f"   EPSS: {epss}")
    
    logger.info("\n3. Cache miss example...")
    missing = cache.get_cve_kev('CVE-2023-9999')
    logger.info(f"   Result: {missing}")
    
    logger.info("\n4. Cache statistics:")
    stats = cache.get_stats()
    print(json.dumps(stats, indent=2))
    
    logger.info("\n5. Session statistics:")
    print(json.dumps(cache.stats.to_dict(), indent=2))
