#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.

"""
Phantom Dependency Detector v1.0

Detects supply chain risks from phantom and shadow dependencies:

1. PHANTOM DEPENDENCIES
   - Dependencies declared in package manifests but never imported
   - Risk: Attacker can claim the package name if it doesn't exist
   - Example: package.json lists "lodash-utils" but code never imports it

2. SHADOW IMPORTS  
   - Code imports packages not declared in manifests
   - Risk: Dependency confusion, typosquatting vulnerabilities
   - Example: Code imports "requests" but requirements.txt doesn't list it

3. DEAD DEPENDENCIES
   - Dependencies that were once used but code references removed
   - Risk: Unmaintained attack surface, potential supply chain compromise

This is Signal Type 8 in the REACHABLE 8-signal correlation engine.
"""

import json
import re
import ast
from pathlib import Path
from typing import Dict, List, Set, Tuple, Optional, Any
from dataclasses import dataclass, field
from enum import Enum
import logging

# Initialize module-level logger
logger = logging.getLogger(__name__)

class PhantomType(Enum):
    PHANTOM = "phantom"      # Declared but not imported
    SHADOW = "shadow"        # Imported but not declared  
    DEAD = "dead"            # Previously used, now orphaned

@dataclass
class PhantomFinding:
    """A phantom/shadow/dead dependency finding"""
    package: str
    finding_type: PhantomType
    ecosystem: str  # npm, pypi, maven, etc.
    severity: str = "MEDIUM"
    confidence: float = 0.8
    evidence: List[str] = field(default_factory=list)
    declared_in: Optional[str] = None  # Manifest file
    imported_in: List[str] = field(default_factory=list)  # Source files
    recommendation: str = ""
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'package': self.package,
            'type': self.finding_type.value,
            'ecosystem': self.ecosystem,
            'severity': self.severity,
            'confidence': self.confidence,
            'evidence': self.evidence,
            'declared_in': self.declared_in,
            'imported_in': self.imported_in,
            'recommendation': self.recommendation,
        }

class PhantomDetector:
    """
    Detects phantom, shadow, and dead dependencies across ecosystems.
    
    Supports:
    - Python (requirements.txt, pyproject.toml, setup.py)
    - JavaScript/Node.js (package.json)
    - Go (go.mod)
    - Java (pom.xml, build.gradle)
    """
    
    # Import patterns by ecosystem
    PYTHON_IMPORT_PATTERNS = [
        r'^\s*import\s+(\w+)',
        r'^\s*from\s+(\w+)',
    ]
    
    JS_IMPORT_PATTERNS = [
        r'require\([\'"]([^@][^\'"\/]+)',  # require('lodash')
        r'from\s+[\'"]([^@][^\'"\/]+)',    # import x from 'lodash'
        r'import\s+[\'"]([^@][^\'"\/]+)',  # import 'lodash'
    ]
    
    GO_IMPORT_PATTERNS = [
        r'import\s+"([^"]+)"',
        r'import\s+\w+\s+"([^"]+)"',
    ]
    
    # Known stdlib modules to ignore
    PYTHON_STDLIB = {
        'os', 'sys', 're', 'json', 'math', 'random', 'datetime', 'time',
        'collections', 'itertools', 'functools', 'typing', 'pathlib',
        'subprocess', 'threading', 'multiprocessing', 'socket', 'ssl',
        'http', 'urllib', 'email', 'html', 'xml', 'sqlite3', 'csv',
        'pickle', 'hashlib', 'hmac', 'secrets', 'base64', 'binascii',
        'struct', 'codecs', 'unicodedata', 'string', 'textwrap',
        'copy', 'pprint', 'enum', 'dataclasses', 'abc', 'contextlib',
        'warnings', 'traceback', 'logging', 'unittest', 'doctest',
        'argparse', 'optparse', 'getopt', 'configparser', 'io', 'tempfile',
        'shutil', 'glob', 'fnmatch', 'linecache', 'platform', 'ctypes',
        'asyncio', 'concurrent', 'queue', 'select', 'selectors',
        'signal', 'mmap', 'array', 'weakref', 'types', 'inspect',
        'dis', 'gc', 'atexit', 'builtins', '__future__',
    }
    
    NODE_BUILTINS = {
        'fs', 'path', 'os', 'http', 'https', 'url', 'util', 'stream',
        'events', 'buffer', 'crypto', 'child_process', 'cluster',
        'dns', 'net', 'tls', 'dgram', 'readline', 'repl', 'vm',
        'zlib', 'assert', 'querystring', 'string_decoder', 'timers',
        'tty', 'v8', 'perf_hooks', 'worker_threads', 'process',
    }
    
    def __init__(self, repo_path: Path, sbom_data: Optional[Dict] = None):
        """
        Initialize detector.
        
        Args:
            repo_path: Path to repository root
            sbom_data: Optional SBOM data (Syft format) for declared deps
        """
        self.repo_path = Path(repo_path)
        self.sbom_data = sbom_data or {}
        
        # Caches
        self._declared_deps: Dict[str, Set[str]] = {}  # ecosystem -> packages
        self._imported_deps: Dict[str, Dict[str, List[str]]] = {}  # ecosystem -> {pkg: [files]}
        
    def detect(self) -> Dict[str, Any]:
        """
        Run full phantom dependency detection.
        
        Returns:
            Dict with findings and summary
        """
        findings: List[PhantomFinding] = []
        
        # Detect ecosystem
        ecosystems = self._detect_ecosystems()
        
        for ecosystem in ecosystems:
            # Get declared dependencies
            declared = self._get_declared_deps(ecosystem)
            
            # Get imported dependencies
            imported = self._get_imported_deps(ecosystem)
            
            # Find phantoms (declared but not imported)
            phantoms = declared - set(imported.keys())
            for pkg in phantoms:
                findings.append(PhantomFinding(
                    package=pkg,
                    finding_type=PhantomType.PHANTOM,
                    ecosystem=ecosystem,
                    severity='MEDIUM',
                    confidence=0.85,
                    evidence=[f"Declared in manifest but no imports found"],
                    declared_in=self._get_manifest_path(ecosystem),
                    recommendation=f"Remove unused dependency '{pkg}' or verify it's needed at runtime",
                ))
            
            # Find shadows (imported but not declared)
            shadows = set(imported.keys()) - declared
            for pkg in shadows:
                files = imported[pkg]
                findings.append(PhantomFinding(
                    package=pkg,
                    finding_type=PhantomType.SHADOW,
                    ecosystem=ecosystem,
                    severity='HIGH',  # Shadow imports are higher risk
                    confidence=0.9,
                    evidence=[f"Imported in {len(files)} file(s) but not declared"],
                    imported_in=files[:5],  # Limit to first 5 files
                    recommendation=f"Add '{pkg}' to dependencies or remove the import",
                ))
        
        # Calculate summary
        summary = {
            'phantom_count': len([f for f in findings if f.finding_type == PhantomType.PHANTOM]),
            'shadow_count': len([f for f in findings if f.finding_type == PhantomType.SHADOW]),
            'dead_count': len([f for f in findings if f.finding_type == PhantomType.DEAD]),
            'total': len(findings),
            'ecosystems_scanned': ecosystems,
            'high_severity': len([f for f in findings if f.severity == 'HIGH']),
            'medium_severity': len([f for f in findings if f.severity == 'MEDIUM']),
        }
        
        return {
            'findings': [f.to_dict() for f in findings],
            'summary': summary,
            'scanner': 'phantom_detector',
            'version': '1.0',
        }
    
    def _detect_ecosystems(self) -> List[str]:
        """Detect which package ecosystems are present"""
        ecosystems = []
        
        # Python
        if (self.repo_path / 'requirements.txt').exists() or \
           (self.repo_path / 'pyproject.toml').exists() or \
           (self.repo_path / 'setup.py').exists():
            ecosystems.append('pypi')
        
        # JavaScript/Node
        if (self.repo_path / 'package.json').exists():
            ecosystems.append('npm')
        
        # Go
        if (self.repo_path / 'go.mod').exists():
            ecosystems.append('go')
        
        # Java
        if (self.repo_path / 'pom.xml').exists() or \
           (self.repo_path / 'build.gradle').exists():
            ecosystems.append('maven')
        
        return ecosystems
    
    def _get_manifest_path(self, ecosystem: str) -> str:
        """Get the manifest file path for an ecosystem"""
        manifests = {
            'pypi': ['requirements.txt', 'pyproject.toml', 'setup.py'],
            'npm': ['package.json'],
            'go': ['go.mod'],
            'maven': ['pom.xml', 'build.gradle'],
        }
        
        for manifest in manifests.get(ecosystem, []):
            if (self.repo_path / manifest).exists():
                return manifest
        return ''
    
    def _get_declared_deps(self, ecosystem: str) -> Set[str]:
        """Get declared dependencies from manifests"""
        if ecosystem in self._declared_deps:
            return self._declared_deps[ecosystem]
        
        deps = set()
        
        # First try SBOM if available
        if self.sbom_data:
            for artifact in self.sbom_data.get('artifacts', []):
                pkg_type = artifact.get('type', '').lower()
                name = artifact.get('name', '')
                
                # Map SBOM types to ecosystems
                if ecosystem == 'pypi' and pkg_type in ('python', 'pip', 'pypi'):
                    # Normalize Python package name
                    deps.add(self._normalize_python_pkg(name))
                elif ecosystem == 'npm' and pkg_type in ('npm', 'node'):
                    deps.add(name.split('/')[-1] if '/' in name else name)
                elif ecosystem == 'go' and pkg_type in ('go-module', 'go'):
                    deps.add(name)
                elif ecosystem == 'maven' and pkg_type in ('maven', 'java', 'gradle'):
                    deps.add(name)
        
        # Also parse manifest files directly
        if ecosystem == 'pypi':
            deps.update(self._parse_python_deps())
        elif ecosystem == 'npm':
            deps.update(self._parse_npm_deps())
        elif ecosystem == 'go':
            deps.update(self._parse_go_deps())
        
        self._declared_deps[ecosystem] = deps
        return deps
    
    def _normalize_python_pkg(self, name: str) -> str:
        """Normalize Python package name (PEP 503)"""
        return re.sub(r'[-_.]+', '-', name).lower()
    
    def _parse_python_deps(self) -> Set[str]:
        """Parse Python dependencies from manifests"""
        deps = set()
        
        # requirements.txt
        req_file = self.repo_path / 'requirements.txt'
        if req_file.exists():
            for line in req_file.read_text().splitlines():
                line = line.strip()
                if line and not line.startswith('#') and not line.startswith('-'):
                    # Extract package name (before ==, >=, etc.)
                    match = re.match(r'^([a-zA-Z0-9_-]+)', line)
                    if match:
                        deps.add(self._normalize_python_pkg(match.group(1)))
        
        # pyproject.toml
        pyproject = self.repo_path / 'pyproject.toml'
        if pyproject.exists():
            try:
                import tomllib
                data = tomllib.loads(pyproject.read_text())
                
                # PEP 621 format
                for dep in data.get('project', {}).get('dependencies', []):
                    match = re.match(r'^([a-zA-Z0-9_-]+)', dep)
                    if match:
                        deps.add(self._normalize_python_pkg(match.group(1)))
                
                # Poetry format
                for dep in data.get('tool', {}).get('poetry', {}).get('dependencies', {}).keys():
                    if dep != 'python':
                        deps.add(self._normalize_python_pkg(dep))
            except Exception:
                pass
        
        return deps
    
    def _parse_npm_deps(self) -> Set[str]:
        """Parse npm dependencies from package.json"""
        deps = set()
        
        pkg_json = self.repo_path / 'package.json'
        if pkg_json.exists():
            try:
                data = json.loads(pkg_json.read_text())
                
                for dep_type in ['dependencies', 'devDependencies', 'peerDependencies']:
                    for pkg in data.get(dep_type, {}).keys():
                        # Handle scoped packages (@org/pkg -> pkg)
                        name = pkg.split('/')[-1] if pkg.startswith('@') else pkg
                        deps.add(name)
            except Exception:
                pass
        
        return deps
    
    def _parse_go_deps(self) -> Set[str]:
        """Parse Go dependencies from go.mod"""
        deps = set()
        
        go_mod = self.repo_path / 'go.mod'
        if go_mod.exists():
            try:
                content = go_mod.read_text()
                # Match require statements
                for match in re.finditer(r'require\s+([^\s]+)\s+', content):
                    deps.add(match.group(1))
                # Match require blocks
                in_require = False
                for line in content.splitlines():
                    if line.strip() == 'require (':
                        in_require = True
                    elif in_require and line.strip() == ')':
                        in_require = False
                    elif in_require:
                        parts = line.strip().split()
                        if parts:
                            deps.add(parts[0])
            except Exception:
                pass
        
        return deps
    
    def _get_imported_deps(self, ecosystem: str) -> Dict[str, List[str]]:
        """Get imported dependencies from source files"""
        if ecosystem in self._imported_deps:
            return self._imported_deps[ecosystem]
        
        imports: Dict[str, List[str]] = {}
        
        if ecosystem == 'pypi':
            imports = self._scan_python_imports()
        elif ecosystem == 'npm':
            imports = self._scan_js_imports()
        elif ecosystem == 'go':
            imports = self._scan_go_imports()
        
        self._imported_deps[ecosystem] = imports
        return imports
    
    def _scan_python_imports(self) -> Dict[str, List[str]]:
        """Scan Python files for imports"""
        imports: Dict[str, List[str]] = {}
        
        for py_file in self.repo_path.rglob('*.py'):
            # Skip common non-app directories
            if any(part in py_file.parts for part in ['node_modules', '.git', 'venv', '.venv', '__pycache__', 'build', 'dist']):
                continue
            
            try:
                content = py_file.read_text()
                
                # Use AST for accurate parsing
                try:
                    tree = ast.parse(content)
                    for node in ast.walk(tree):
                        if isinstance(node, ast.Import):
                            for alias in node.names:
                                pkg = alias.name.split('.')[0]
                                if pkg not in self.PYTHON_STDLIB:
                                    pkg = self._normalize_python_pkg(pkg)
                                    if pkg not in imports:
                                        imports[pkg] = []
                                    imports[pkg].append(str(py_file.relative_to(self.repo_path)))
                        elif isinstance(node, ast.ImportFrom):
                            if node.module:
                                pkg = node.module.split('.')[0]
                                if pkg not in self.PYTHON_STDLIB:
                                    pkg = self._normalize_python_pkg(pkg)
                                    if pkg not in imports:
                                        imports[pkg] = []
                                    imports[pkg].append(str(py_file.relative_to(self.repo_path)))
                except SyntaxError:
                    # Fallback to regex for invalid Python files
                    for pattern in self.PYTHON_IMPORT_PATTERNS:
                        for match in re.finditer(pattern, content, re.MULTILINE):
                            pkg = match.group(1)
                            if pkg not in self.PYTHON_STDLIB:
                                pkg = self._normalize_python_pkg(pkg)
                                if pkg not in imports:
                                    imports[pkg] = []
                                imports[pkg].append(str(py_file.relative_to(self.repo_path)))
            except Exception:
                continue
        
        return imports
    
    def _scan_js_imports(self) -> Dict[str, List[str]]:
        """Scan JavaScript/TypeScript files for imports"""
        imports: Dict[str, List[str]] = {}
        
        for ext in ['*.js', '*.jsx', '*.ts', '*.tsx', '*.mjs']:
            for js_file in self.repo_path.rglob(ext):
                # Skip node_modules
                if 'node_modules' in js_file.parts or '.git' in js_file.parts:
                    continue
                
                try:
                    content = js_file.read_text()
                    
                    for pattern in self.JS_IMPORT_PATTERNS:
                        for match in re.finditer(pattern, content):
                            pkg = match.group(1)
                            # Skip relative imports and builtins
                            if not pkg.startswith('.') and pkg not in self.NODE_BUILTINS:
                                if pkg not in imports:
                                    imports[pkg] = []
                                imports[pkg].append(str(js_file.relative_to(self.repo_path)))
                except Exception:
                    continue
        
        return imports
    
    def _scan_go_imports(self) -> Dict[str, List[str]]:
        """Scan Go files for imports"""
        imports: Dict[str, List[str]] = {}
        
        for go_file in self.repo_path.rglob('*.go'):
            if '.git' in go_file.parts or 'vendor' in go_file.parts:
                continue
            
            try:
                content = go_file.read_text()
                
                for pattern in self.GO_IMPORT_PATTERNS:
                    for match in re.finditer(pattern, content):
                        pkg = match.group(1)
                        # Skip standard library
                        if not pkg.startswith('fmt') and '/' in pkg:
                            if pkg not in imports:
                                imports[pkg] = []
                            imports[pkg].append(str(go_file.relative_to(self.repo_path)))
            except Exception:
                continue
        
        return imports

def detect_phantom_deps(repo_path: Path, sbom_data: Optional[Dict] = None) -> Dict[str, Any]:
    """
    Convenience function to detect phantom dependencies.
    
    Args:
        repo_path: Path to repository
        sbom_data: Optional SBOM data
        
    Returns:
        Detection results
    """
    detector = PhantomDetector(repo_path, sbom_data)
    return detector.detect()

if __name__ == '__main__':
    import sys
    
    if len(sys.argv) < 2:
        logger.info("Usage: python phantom_detector.py <repo_path>")
        sys.exit(1)
    
    repo_path = Path(sys.argv[1])
    results = detect_phantom_deps(repo_path)
    
    print(json.dumps(results, indent=2))
    
    summary = results['summary']
    logger.info(f"\n📦 Phantom Dependencies: {summary['phantom_count']}")
    logger.info(f"👤 Shadow Imports: {summary['shadow_count']}")
    logger.info(f"💀 Dead Dependencies: {summary['dead_count']}")
