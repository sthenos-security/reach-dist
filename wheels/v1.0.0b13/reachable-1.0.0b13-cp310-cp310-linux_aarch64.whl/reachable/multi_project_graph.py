#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.

"""
REACHABLE Multi-Project Call Graph Builder

Builds call graphs per-project, then stitches them into a global graph.
This enables:
1. Per-project analysis (isolation)
2. Global reachability (cross-project flows)
3. Incremental updates (only rebuild changed projects)
4. Cache efficiency (smaller units to cache)

ARCHITECTURE:
    repo/
    ├── backend/          → call_graph_backend.json
    ├── frontend/         → call_graph_frontend.json
    ├── shared/           → call_graph_shared.json
    └── GLOBAL            → stitched graph with cross-project edges
"""

import os
import json
from pathlib import Path
from typing import Dict, List, Set, Optional, Tuple
from dataclasses import dataclass, field
from concurrent.futures import ThreadPoolExecutor, as_completed
import hashlib
import logging

# Initialize module-level logger
logger = logging.getLogger(__name__)

@dataclass
class ProjectCallGraph:
    """Call graph for a single project/subproject"""
    project_id: str
    project_path: Path
    
    # Core graph data
    nodes: Set[str] = field(default_factory=set)  # Function names
    edges: Dict[str, Set[str]] = field(default_factory=dict)  # caller -> [callees]
    
    # Metadata
    entrypoints: Set[str] = field(default_factory=set)
    exports: Set[str] = field(default_factory=set)  # Functions importable by other projects
    imports: Dict[str, str] = field(default_factory=dict)  # imported_func -> source_project
    
    # File mapping
    function_to_file: Dict[str, str] = field(default_factory=dict)
    file_functions: Dict[str, Set[str]] = field(default_factory=dict)
    
    # Stats
    file_count: int = 0
    function_count: int = 0
    edge_count: int = 0
    content_hash: str = ""
    
    def add_node(self, func_name: str, file_path: str = None):
        """Add a function node"""
        self.nodes.add(func_name)
        if file_path:
            self.function_to_file[func_name] = file_path
            if file_path not in self.file_functions:
                self.file_functions[file_path] = set()
            self.file_functions[file_path].add(func_name)
    
    def add_edge(self, caller: str, callee: str):
        """Add a call edge"""
        if caller not in self.edges:
            self.edges[caller] = set()
        self.edges[caller].add(callee)
    
    def add_entrypoint(self, func_name: str):
        """Mark function as entrypoint"""
        self.entrypoints.add(func_name)
    
    def add_export(self, func_name: str):
        """Mark function as exported (usable by other projects)"""
        self.exports.add(func_name)
    
    def add_import(self, func_name: str, source_project: str):
        """Record imported function from another project"""
        self.imports[func_name] = source_project
    
    def compute_hash(self) -> str:
        """Compute content hash for cache invalidation"""
        data = {
            'nodes': sorted(self.nodes),
            'edges': {k: sorted(v) for k, v in sorted(self.edges.items())},
            'entrypoints': sorted(self.entrypoints),
            'exports': sorted(self.exports)
        }
        content = json.dumps(data, sort_keys=True)
        self.content_hash = hashlib.sha256(content.encode()).hexdigest()[:16]
        return self.content_hash
    
    def finalize(self):
        """Compute final stats"""
        self.function_count = len(self.nodes)
        self.edge_count = sum(len(callees) for callees in self.edges.values())
        self.file_count = len(self.file_functions)
        self.compute_hash()
    
    def to_dict(self) -> Dict:
        """Export as dictionary"""
        return {
            'project_id': self.project_id,
            'project_path': str(self.project_path),
            'nodes': list(self.nodes),
            'edges': {k: list(v) for k, v in self.edges.items()},
            'entrypoints': list(self.entrypoints),
            'exports': list(self.exports),
            'imports': self.imports,
            'function_to_file': self.function_to_file,
            'stats': {
                'files': self.file_count,
                'functions': self.function_count,
                'edges': self.edge_count,
                'entrypoints': len(self.entrypoints),
                'exports': len(self.exports),
                'imports': len(self.imports)
            },
            'content_hash': self.content_hash
        }
    
    @classmethod
    def from_dict(cls, data: Dict) -> 'ProjectCallGraph':
        """Load from dictionary"""
        graph = cls(
            project_id=data['project_id'],
            project_path=Path(data['project_path'])
        )
        graph.nodes = set(data.get('nodes', []))
        graph.edges = {k: set(v) for k, v in data.get('edges', {}).items()}
        graph.entrypoints = set(data.get('entrypoints', []))
        graph.exports = set(data.get('exports', []))
        graph.imports = data.get('imports', {})
        graph.function_to_file = data.get('function_to_file', {})
        graph.content_hash = data.get('content_hash', '')
        
        # Rebuild file_functions
        for func, file_path in graph.function_to_file.items():
            if file_path not in graph.file_functions:
                graph.file_functions[file_path] = set()
            graph.file_functions[file_path].add(func)
        
        stats = data.get('stats', {})
        graph.file_count = stats.get('files', 0)
        graph.function_count = stats.get('functions', 0)
        graph.edge_count = stats.get('edges', 0)
        
        return graph

@dataclass
class GlobalCallGraph:
    """Stitched call graph combining all projects"""
    
    # Project graphs
    projects: Dict[str, ProjectCallGraph] = field(default_factory=dict)
    
    # Global graph (stitched)
    global_nodes: Set[str] = field(default_factory=set)
    global_edges: Dict[str, Set[str]] = field(default_factory=dict)
    
    # Cross-project edges
    cross_project_edges: List[Dict] = field(default_factory=list)
    
    # Global entrypoints (from all projects)
    global_entrypoints: Set[str] = field(default_factory=set)
    
    # Reachability (computed after stitching)
    reachable_nodes: Set[str] = field(default_factory=set)
    unreachable_nodes: Set[str] = field(default_factory=set)
    
    def add_project(self, project: ProjectCallGraph):
        """Add a project graph"""
        self.projects[project.project_id] = project
    
    def stitch(self):
        """
        Stitch all project graphs into global graph.
        Resolves cross-project imports/exports.
        """
        # Collect all exports by function name
        exports_map: Dict[str, str] = {}  # func_name -> project_id
        for proj_id, proj in self.projects.items():
            for export in proj.exports:
                full_name = f"{proj_id}:{export}"
                exports_map[export] = proj_id
                exports_map[full_name] = proj_id
        
        # Build global graph
        for proj_id, proj in self.projects.items():
            # Add all nodes with project prefix
            for node in proj.nodes:
                full_name = f"{proj_id}:{node}"
                self.global_nodes.add(full_name)
            
            # Add all edges with project prefix
            for caller, callees in proj.edges.items():
                full_caller = f"{proj_id}:{caller}"
                if full_caller not in self.global_edges:
                    self.global_edges[full_caller] = set()
                
                for callee in callees:
                    # Check if callee is an import from another project
                    if callee in proj.imports:
                        source_proj = proj.imports[callee]
                        full_callee = f"{source_proj}:{callee}"
                        self.cross_project_edges.append({
                            'from_project': proj_id,
                            'to_project': source_proj,
                            'caller': caller,
                            'callee': callee
                        })
                    else:
                        # Same project
                        full_callee = f"{proj_id}:{callee}"
                    
                    self.global_edges[full_caller].add(full_callee)
            
            # Add entrypoints
            for ep in proj.entrypoints:
                self.global_entrypoints.add(f"{proj_id}:{ep}")
    
    def compute_reachability(self):
        """Compute reachable nodes from all entrypoints"""
        self.reachable_nodes = set()
        
        # BFS from all entrypoints
        queue = list(self.global_entrypoints)
        visited = set()
        
        while queue:
            node = queue.pop(0)
            if node in visited:
                continue
            visited.add(node)
            self.reachable_nodes.add(node)
            
            # Add callees to queue
            for callee in self.global_edges.get(node, set()):
                if callee not in visited:
                    queue.append(callee)
        
        self.unreachable_nodes = self.global_nodes - self.reachable_nodes
    
    def get_project_reachability(self, project_id: str) -> Dict:
        """Get reachability stats for a specific project"""
        project = self.projects.get(project_id)
        if not project:
            return {}
        
        reachable = 0
        unreachable = 0
        
        for node in project.nodes:
            full_name = f"{project_id}:{node}"
            if full_name in self.reachable_nodes:
                reachable += 1
            else:
                unreachable += 1
        
        return {
            'project_id': project_id,
            'reachable': reachable,
            'unreachable': unreachable,
            'percentage': round(reachable / (reachable + unreachable) * 100, 1) if (reachable + unreachable) > 0 else 0
        }
    
    def to_dict(self) -> Dict:
        """Export as dictionary"""
        return {
            'projects': {k: v.to_dict() for k, v in self.projects.items()},
            'global_stats': {
                'total_nodes': len(self.global_nodes),
                'total_edges': sum(len(v) for v in self.global_edges.values()),
                'total_entrypoints': len(self.global_entrypoints),
                'cross_project_edges': len(self.cross_project_edges),
                'reachable': len(self.reachable_nodes),
                'unreachable': len(self.unreachable_nodes),
                'reachability_percentage': round(
                    len(self.reachable_nodes) / len(self.global_nodes) * 100, 1
                ) if self.global_nodes else 0
            },
            'cross_project_edges': self.cross_project_edges[:100],  # First 100
            'per_project_reachability': [
                self.get_project_reachability(p) for p in self.projects
            ]
        }

class MultiProjectGraphBuilder:
    """
    Builds call graphs for multi-project repositories.
    
    Features:
    - Per-project graph building
    - Cross-project import/export detection
    - Global graph stitching
    - Cache integration for incremental builds
    """
    
    def __init__(self, repo_path: Path, cache=None):
        self.repo_path = repo_path
        self.cache = cache
        self.verbose = True
        
        self.project_graphs: Dict[str, ProjectCallGraph] = {}
        self.global_graph: Optional[GlobalCallGraph] = None
    
    def detect_projects(self) -> List[Dict]:
        """
        Detect subprojects in the repository.
        
        Returns list of project info dicts.
        """
        projects = []
        
        # Common project indicators
        indicators = [
            'package.json', 'pyproject.toml', 'setup.py', 'Cargo.toml',
            'go.mod', 'pom.xml', 'build.gradle', 'requirements.txt'
        ]
        
        # Walk directory tree
        for root, dirs, files in os.walk(self.repo_path):
            # Skip common non-project directories
            dirs[:] = [d for d in dirs if d not in {
                'node_modules', '.git', '__pycache__', 'venv', '.venv',
                'vendor', 'target', 'build', 'dist', '.tox'
            }]
            
            root_path = Path(root)
            rel_path = root_path.relative_to(self.repo_path)
            
            # Check for project indicators
            for indicator in indicators:
                if indicator in files:
                    # Determine project type
                    proj_type = {
                        'package.json': 'node',
                        'pyproject.toml': 'python',
                        'setup.py': 'python',
                        'requirements.txt': 'python',
                        'Cargo.toml': 'rust',
                        'go.mod': 'go',
                        'pom.xml': 'java',
                        'build.gradle': 'java'
                    }.get(indicator, 'unknown')
                    
                    proj_id = str(rel_path) if str(rel_path) != '.' else 'root'
                    
                    projects.append({
                        'id': proj_id,
                        'path': root_path,
                        'type': proj_type,
                        'indicator': indicator,
                        'relative_path': str(rel_path)
                    })
                    break  # Only count once per directory
        
        # If no subprojects found, treat whole repo as one project
        if not projects:
            projects.append({
                'id': 'root',
                'path': self.repo_path,
                'type': 'unknown',
                'indicator': None,
                'relative_path': '.'
            })
        
        return projects
    
    def build_project_graph(self, project_info: Dict, parse_func) -> ProjectCallGraph:
        """
        Build call graph for a single project.
        
        Args:
            project_info: Project metadata from detect_projects()
            parse_func: Function to parse files and extract call graph
            
        Returns:
            ProjectCallGraph for this project
        """
        proj_id = project_info['id']
        proj_path = project_info['path']
        
        # Check cache first
        if self.cache:
            cached = self.cache.get('project_graph', proj_id)
            if cached:
                graph = ProjectCallGraph.from_dict(cached)
                if self.verbose:
                    logger.info(f"   💾 Loaded {proj_id} from cache ({graph.function_count} functions)")
                return graph
        
        if self.verbose:
            logger.info(f"   🔧 Building graph for {proj_id}...")
        
        graph = ProjectCallGraph(project_id=proj_id, project_path=proj_path)
        
        # Find source files
        source_extensions = {'.py', '.js', '.ts', '.jsx', '.tsx', '.go', '.rs', '.java'}
        source_files = []
        
        for root, dirs, files in os.walk(proj_path):
            # Skip non-source directories
            dirs[:] = [d for d in dirs if d not in {
                'node_modules', '__pycache__', 'venv', '.venv', 'vendor', 'test', 'tests'
            }]
            
            for file in files:
                if Path(file).suffix in source_extensions:
                    source_files.append(Path(root) / file)
        
        # Parse files and build graph
        for file_path in source_files:
            try:
                result = parse_func(file_path)
                
                # Add nodes and edges
                for func in result.get('functions', []):
                    graph.add_node(func, str(file_path.relative_to(proj_path)))
                
                for caller, callees in result.get('calls', {}).items():
                    for callee in callees:
                        graph.add_edge(caller, callee)
                
                # Detect entrypoints
                for ep in result.get('entrypoints', []):
                    graph.add_entrypoint(ep)
                
                # Detect exports
                for exp in result.get('exports', []):
                    graph.add_export(exp)
                
                # Detect imports from other projects
                for imp, source in result.get('imports', {}).items():
                    graph.add_import(imp, source)
                    
            except Exception as e:
                if self.verbose:
                    logger.info(f"      ⚠️  Error parsing {file_path}: {e}")
        
        graph.finalize()
        
        # Cache the result
        if self.cache:
            self.cache.set('project_graph', proj_id, graph.to_dict())
        
        if self.verbose:
            logger.info(f"      ✅ {proj_id}: {graph.function_count} functions, {graph.edge_count} edges")
        
        return graph
    
    def build_all(self, parse_func, parallel: bool = True) -> GlobalCallGraph:
        """
        Build all project graphs and stitch into global graph.
        
        Args:
            parse_func: Function to parse files
            parallel: Whether to build projects in parallel
            
        Returns:
            GlobalCallGraph with all projects stitched
        """
        projects = self.detect_projects()
        
        if self.verbose:
            logger.info(f"\n📦 Detected {len(projects)} projects:")
            for p in projects:
                logger.info(f"   • {p['id']} ({p['type']})")
        
        self.global_graph = GlobalCallGraph()
        
        if parallel and len(projects) > 1:
            # Build in parallel
            with ThreadPoolExecutor(max_workers=4) as executor:
                futures = {
                    executor.submit(self.build_project_graph, p, parse_func): p['id']
                    for p in projects
                }
                
                for future in as_completed(futures):
                    proj_id = futures[future]
                    try:
                        graph = future.result()
                        self.global_graph.add_project(graph)
                    except Exception as e:
                        if self.verbose:
                            logger.info(f"   ❌ Failed to build {proj_id}: {e}")
        else:
            # Build sequentially
            for project_info in projects:
                graph = self.build_project_graph(project_info, parse_func)
                self.global_graph.add_project(graph)
        
        # Stitch and compute reachability
        if self.verbose:
            logger.info("\n🔗 Stitching global call graph...")
        
        self.global_graph.stitch()
        self.global_graph.compute_reachability()
        
        if self.verbose:
            stats = self.global_graph.to_dict()['global_stats']
            logger.info(f"   ✅ Global: {stats['total_nodes']} nodes, {stats['total_edges']} edges")
            logger.info(f"   ✅ Cross-project: {stats['cross_project_edges']} edges")
            logger.info(f"   ✅ Reachability: {stats['reachability_percentage']}%")
        
        return self.global_graph

# Example usage
if __name__ == '__main__':
    print("=" * 70)
    logger.info("Multi-Project Call Graph Builder - Demo")
    print("=" * 70)
    
    # Mock parse function
    def mock_parse(file_path):
        return {
            'functions': [f'func_{i}' for i in range(3)],
            'calls': {'func_0': ['func_1', 'func_2']},
            'entrypoints': ['main'] if 'main' in str(file_path) else [],
            'exports': ['func_0'],
            'imports': {}
        }
    
    # Create sample structure
    import tempfile
    with tempfile.TemporaryDirectory() as tmpdir:
        repo = Path(tmpdir)
        
        # Create mock projects
        (repo / "backend").mkdir()
        (repo / "backend" / "pyproject.toml").write_text("[project]\nname='backend'")
        (repo / "backend" / "main.py").write_text("def main(): pass")
        
        (repo / "frontend").mkdir()
        (repo / "frontend" / "package.json").write_text('{"name": "frontend"}')
        (repo / "frontend" / "app.js").write_text("function app() {}")
        
        (repo / "shared").mkdir()
        (repo / "shared" / "pyproject.toml").write_text("[project]\nname='shared'")
        (repo / "shared" / "utils.py").write_text("def helper(): pass")
        
        # Build graphs
        builder = MultiProjectGraphBuilder(repo)
        global_graph = builder.build_all(mock_parse)
        
        logger.info("\n📊 Results:")
        print(json.dumps(global_graph.to_dict(), indent=2, default=str))
