# REACHABLE AI Security Module - Framework Adapters
# Copyright (c) 2026 Sthenos Security. All rights reserved.

"""Framework-specific adapters for AI pattern detection."""
