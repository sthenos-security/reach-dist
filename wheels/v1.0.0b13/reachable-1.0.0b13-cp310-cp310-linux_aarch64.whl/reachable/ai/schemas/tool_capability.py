# REACHABLE AI Security Module - Tool Capability Schema
# Copyright (c) 2026 Sthenos Security. All rights reserved.

"""
Tool Capability data model.

Represents AI tool definitions and their capabilities:
- READ: Read data (search, fetch, query)
- WRITE: Modify data (db update, file write, message send)
- EXEC: Execute code (shell, eval, subprocess)
- EGRESS: Network outbound (HTTP, email, webhook)
- AUTH: Authentication operations
- ADMIN: Administrative operations
"""

from dataclasses import dataclass, field
from enum import Enum, auto
from typing import Optional


class CapabilityType(Enum):
    """Categories of tool capabilities."""
    READ = auto()       # Read data (search, fetch, query)
    WRITE = auto()      # Modify data (db update, file write, message send)
    EXEC = auto()       # Execute code (shell, eval, subprocess)
    EGRESS = auto()     # Network outbound (HTTP, email, webhook)
    AUTH = auto()       # Authentication operations
    ADMIN = auto()      # Administrative operations


class RiskLevel(Enum):
    """Risk level for capabilities."""
    LOW = 1
    MEDIUM = 2
    HIGH = 3
    CRITICAL = 4


@dataclass
class ToolCapability:
    """Represents a capability exposed by a tool."""
    
    name: str
    description: str
    capability_type: CapabilityType
    risk_level: RiskLevel
    
    # What resources can this capability access?
    resource_scope: list[str] = field(default_factory=list)  # e.g., ["filesystem", "database"]
    
    # What data can flow through this capability?
    data_types: list[str] = field(default_factory=list)  # e.g., ["pii", "credentials"]
    
    # Is human confirmation required?
    requires_confirmation: bool = False
    
    # Rate limiting
    rate_limited: bool = False
    
    # Guards detected
    guards: list[str] = field(default_factory=list)
    
    def to_dict(self) -> dict:
        """Convert to dictionary for JSON serialization."""
        return {
            "name": self.name,
            "description": self.description,
            "capability_type": self.capability_type.name,
            "risk_level": self.risk_level.name,
            "resource_scope": self.resource_scope,
            "data_types": self.data_types,
            "requires_confirmation": self.requires_confirmation,
            "rate_limited": self.rate_limited,
            "guards": self.guards,
        }


@dataclass
class Tool:
    """Represents an AI tool definition."""
    
    name: str
    file_path: str
    line_number: int
    
    # Capabilities this tool exposes
    capabilities: list[ToolCapability] = field(default_factory=list)
    
    # Framework (langchain, mcp, openai, etc.)
    framework: str = "unknown"
    
    # Is this tool exposed to external input?
    externally_reachable: bool = False
    
    # Guards protecting this tool
    guards: list[str] = field(default_factory=list)
    
    # Tool description (from docstring or decorator)
    description: Optional[str] = None
    
    # Input schema if defined
    input_schema: Optional[dict] = None
    
    @property
    def max_risk_level(self) -> RiskLevel:
        """Highest risk level among capabilities."""
        if not self.capabilities:
            return RiskLevel.LOW
        return max(c.risk_level for c in self.capabilities)
    
    @property
    def has_dangerous_capability(self) -> bool:
        """True if tool has EXEC, WRITE, or EGRESS capability."""
        dangerous = {CapabilityType.EXEC, CapabilityType.WRITE, CapabilityType.EGRESS}
        return any(c.capability_type in dangerous for c in self.capabilities)
    
    @property
    def location(self) -> str:
        """Human-readable location string."""
        return f"{self.file_path}:{self.line_number}"
    
    @property
    def capability_summary(self) -> str:
        """Short summary of capabilities."""
        types = sorted(set(c.capability_type.name for c in self.capabilities))
        return ", ".join(types) if types else "none"
    
    def to_dict(self) -> dict:
        """Convert to dictionary for JSON serialization."""
        return {
            "name": self.name,
            "file_path": self.file_path,
            "line_number": self.line_number,
            "capabilities": [c.to_dict() for c in self.capabilities],
            "framework": self.framework,
            "externally_reachable": self.externally_reachable,
            "guards": self.guards,
            "description": self.description,
            "input_schema": self.input_schema,
            "max_risk_level": self.max_risk_level.name,
            "has_dangerous_capability": self.has_dangerous_capability,
        }
    
    @classmethod
    def from_dict(cls, data: dict) -> "Tool":
        """Create from dictionary."""
        data = data.copy()
        # Remove computed properties
        data.pop("max_risk_level", None)
        data.pop("has_dangerous_capability", None)
        
        # Convert capabilities
        if "capabilities" in data:
            caps = []
            for c in data["capabilities"]:
                c["capability_type"] = CapabilityType[c["capability_type"]]
                c["risk_level"] = RiskLevel[c["risk_level"]]
                caps.append(ToolCapability(**c))
            data["capabilities"] = caps
        
        return cls(**data)


# Mapping of common dangerous patterns to capabilities
DANGEROUS_PATTERNS = {
    # Code execution
    "eval": (CapabilityType.EXEC, RiskLevel.CRITICAL),
    "exec": (CapabilityType.EXEC, RiskLevel.CRITICAL),
    "subprocess": (CapabilityType.EXEC, RiskLevel.CRITICAL),
    "os.system": (CapabilityType.EXEC, RiskLevel.CRITICAL),
    "shell=True": (CapabilityType.EXEC, RiskLevel.CRITICAL),
    
    # File operations
    "open.*w": (CapabilityType.WRITE, RiskLevel.HIGH),
    "write_text": (CapabilityType.WRITE, RiskLevel.HIGH),
    "write_bytes": (CapabilityType.WRITE, RiskLevel.HIGH),
    "unlink": (CapabilityType.WRITE, RiskLevel.HIGH),
    "rmtree": (CapabilityType.WRITE, RiskLevel.CRITICAL),
    
    # Network
    "requests.post": (CapabilityType.EGRESS, RiskLevel.MEDIUM),
    "requests.put": (CapabilityType.EGRESS, RiskLevel.MEDIUM),
    "httpx.post": (CapabilityType.EGRESS, RiskLevel.MEDIUM),
    "fetch": (CapabilityType.EGRESS, RiskLevel.MEDIUM),
    "axios.post": (CapabilityType.EGRESS, RiskLevel.MEDIUM),
    
    # Database
    "execute.*INSERT": (CapabilityType.WRITE, RiskLevel.HIGH),
    "execute.*UPDATE": (CapabilityType.WRITE, RiskLevel.HIGH),
    "execute.*DELETE": (CapabilityType.WRITE, RiskLevel.HIGH),
    "execute.*DROP": (CapabilityType.WRITE, RiskLevel.CRITICAL),
}
