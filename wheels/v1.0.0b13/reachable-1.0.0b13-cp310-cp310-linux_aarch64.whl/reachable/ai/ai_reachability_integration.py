#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.

"""
REACHABLE AI Reachability Integration
=====================================

Integrates AI security findings with the core REACHABLE reachability analysis.

This module bridges:
1. AI Security Scanner findings (OWASP LLM Top 10)
2. AI-specific data flow analysis (ai_reachability.py)
3. Core REACHABLE call graph analysis
4. Correlation engine for unified risk scoring

Key Integration Points:
- Call graph from core reachability analysis
- Entrypoints detection (HTTP handlers, CLI, etc.)
- Cross-function taint tracking
- Guard detection across function boundaries
"""

from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Optional, Set, Tuple, Any
import logging

# Import AI reachability components
from reachable.ai.ai_reachability import (
    AIReachabilityAnalyzer,
    AIReachabilityResult,
    DataFlow,
    FlowType,
    SourceType,
    SinkType,
    GuardType,
    SINK_TO_OWASP_LLM,
    GUARD_TO_OWASP_LLM,
)

# Import AI finding schema
from reachable.ai.schemas.ai_finding import AIFinding

logger = logging.getLogger(__name__)


# ════════════════════════════════════════════════════════════════════════════════
# OWASP LLM TOP 10 (2025) RISK WEIGHTS
# ════════════════════════════════════════════════════════════════════════════════

# Risk weights for reachable code (points)
OWASP_LLM_REACHABLE_WEIGHTS = {
    "LLM01": 150,   # Prompt Injection - CRITICAL
    "LLM02": 80,    # Sensitive Information Disclosure - HIGH
    "LLM03": 100,   # Supply Chain - HIGH
    "LLM04": 60,    # Data and Model Poisoning - MEDIUM
    "LLM05": 200,   # Improper Output Handling - CRITICAL
    "LLM06": 100,   # Excessive Agency - HIGH
    "LLM07": 50,    # System Prompt Leakage - MEDIUM
    "LLM08": 40,    # Vector and Embedding Weaknesses - MEDIUM
    "LLM09": 20,    # Misinformation - LOW
    "LLM10": 30,    # Unbounded Consumption - MEDIUM
}

# Risk weights for unreachable code (reduced by ~75%)
OWASP_LLM_UNREACHABLE_WEIGHTS = {
    "LLM01": 40,
    "LLM02": 20,
    "LLM03": 30,
    "LLM04": 15,
    "LLM05": 50,
    "LLM06": 25,
    "LLM07": 12,
    "LLM08": 10,
    "LLM09": 5,
    "LLM10": 8,
}

# Guard effectiveness by type (risk reduction percentage)
GUARD_EFFECTIVENESS = {
    GuardType.INJECTION_DETECT: 0.80,   # Rebuff, LlamaGuard
    GuardType.HUMAN_APPROVAL: 0.90,     # Human in the loop
    GuardType.SANDBOX: 0.60,            # Sandboxed execution
    GuardType.ALLOWLIST: 0.70,          # Tool allowlist
    GuardType.OUTPUT_FILTER: 0.60,      # Output sanitization
    GuardType.INPUT_VALIDATION: 0.50,   # Pydantic, schema validation
    GuardType.HTML_ESCAPE: 0.60,        # XSS prevention
    GuardType.RATE_LIMIT: 0.40,         # DoS prevention
    GuardType.TOKEN_LIMIT: 0.40,        # Resource limiting
    GuardType.LENGTH_LIMIT: 0.30,       # Basic truncation
}


@dataclass
class AIReachabilityContext:
    """
    Context for AI finding reachability determination.
    
    Combines:
    - AI-specific flow analysis
    - Core call graph reachability
    - Guard detection
    """
    is_reachable: bool = True
    reachability_source: str = "unknown"  # ai_flow, call_graph, heuristic
    risk_weight: int = 0
    risk_reduction: float = 0.0
    guards_detected: List[str] = field(default_factory=list)
    call_path: List[str] = field(default_factory=list)
    owasp_llm: str = ""
    flow_type: str = ""
    source_type: str = ""
    sink_type: str = ""
    confidence: float = 1.0


class AIReachabilityIntegration:
    """
    Integrates AI security findings with REACHABLE's core reachability analysis.
    
    This class bridges:
    1. AI-specific taint tracking (source → sink flows)
    2. Core call graph analysis (function reachability)
    3. Guard detection (security controls)
    4. Risk scoring (OWASP LLM weights)
    """
    
    def __init__(
        self,
        call_graph: Optional[Dict[str, Set[str]]] = None,
        reachable_functions: Optional[Set[str]] = None,
        entrypoints: Optional[Set[str]] = None,
    ):
        """
        Initialize integration.
        
        Args:
            call_graph: Core REACHABLE call graph {caller: {callees}}
            reachable_functions: Functions reachable from any entrypoint
            entrypoints: Application entry points (HTTP handlers, main, etc.)
        """
        self.call_graph = call_graph or {}
        self.reachable_functions = reachable_functions or set()
        self.entrypoints = entrypoints or set()
        
        # AI-specific analyzer
        self.ai_analyzer = AIReachabilityAnalyzer(
            call_graph=call_graph,
            reachable_functions=reachable_functions,
            entrypoints=entrypoints,
        )
        
        # Cache for analyzed files
        self._file_cache: Dict[str, AIReachabilityResult] = {}
        self._flow_cache: Dict[str, DataFlow] = {}
        
        # Statistics
        self.stats = {
            "findings_analyzed": 0,
            "reachable_findings": 0,
            "guarded_findings": 0,
            "by_owasp": {},
        }
    
    def analyze_repository(self, repo_path: Path) -> Dict[str, Any]:
        """
        Analyze entire repository for AI reachability.
        
        Returns comprehensive analysis suitable for correlation engine.
        """
        repo_path = Path(repo_path).resolve()
        
        # Run AI-specific analysis
        results = self.ai_analyzer.analyze_directory(repo_path)
        
        # Cache results
        for result in results:
            self._file_cache[result.file_path] = result
            for flow in result.flows:
                self._flow_cache[f"{result.file_path}:{flow.sink.location}"] = flow
        
        # Aggregate statistics
        total_flows = sum(len(r.flows) for r in results)
        unguarded = sum(r.unguarded_flows for r in results)
        
        owasp_counts = {}
        for result in results:
            for flow in result.flows:
                owasp = flow.owasp_llm or "UNKNOWN"
                owasp_counts[owasp] = owasp_counts.get(owasp, 0) + 1
        
        return {
            "files_analyzed": len(results),
            "total_flows": total_flows,
            "unguarded_flows": unguarded,
            "guarded_flows": total_flows - unguarded,
            "owasp_breakdown": owasp_counts,
            "results": results,
        }
    
    def get_reachability_context(
        self,
        finding: AIFinding,
    ) -> AIReachabilityContext:
        """
        Get full reachability context for an AI security finding.
        
        Combines:
        1. AI-specific flow analysis
        2. Core call graph reachability
        3. Guard detection
        4. Risk scoring
        
        Args:
            finding: AI security finding from scanner
            
        Returns:
            AIReachabilityContext with all reachability data
        """
        context = AIReachabilityContext()
        
        # Step 1: Try AI-specific flow analysis
        file_path = finding.file_path
        line_num = finding.line_start
        
        if file_path in self._file_cache:
            result = self._file_cache[file_path]
            
            # Find closest flow to this finding
            best_flow = None
            min_distance = float('inf')
            
            for flow in result.flows:
                sink_line = int(flow.sink.location.split(':')[1])
                distance = abs(sink_line - line_num)
                if distance < min_distance:
                    min_distance = distance
                    best_flow = flow
            
            if best_flow and min_distance <= 10:
                context.is_reachable = best_flow.is_reachable
                context.reachability_source = "ai_flow"
                context.guards_detected = [g.guard_type.value for g in best_flow.guards]
                context.risk_reduction = best_flow.risk_reduction
                context.owasp_llm = best_flow.owasp_llm
                context.flow_type = best_flow.flow_type.value
                context.source_type = best_flow.source.source_type.value
                context.sink_type = best_flow.sink.sink_type.value
                context.call_path = best_flow.path
                context.confidence = 0.9  # High confidence from flow analysis
        
        # Step 2: If no flow found, try call graph analysis
        if context.reachability_source == "unknown" and self.reachable_functions:
            # Extract function name from finding (simplified)
            # In production, would parse AST to get actual function
            is_in_reachable = self._check_call_graph_reachability(file_path, line_num)
            context.is_reachable = is_in_reachable
            context.reachability_source = "call_graph"
            context.confidence = 0.7  # Medium confidence from call graph
        
        # Step 3: Fallback to heuristic
        if context.reachability_source == "unknown":
            # Conservative: assume reachable
            context.is_reachable = True
            context.reachability_source = "heuristic"
            context.confidence = 0.5  # Low confidence
        
        # Step 4: Determine OWASP category if not set
        if not context.owasp_llm:
            context.owasp_llm = finding.owasp_category or self._infer_owasp_from_rule(finding.rule_id)
        
        # Step 5: Calculate risk weight
        context.risk_weight = self._calculate_risk_weight(
            owasp_category=context.owasp_llm,
            is_reachable=context.is_reachable,
            guards=context.guards_detected,
        )
        
        # Update statistics
        self.stats["findings_analyzed"] += 1
        if context.is_reachable:
            self.stats["reachable_findings"] += 1
        if context.guards_detected:
            self.stats["guarded_findings"] += 1
        owasp = context.owasp_llm or "UNKNOWN"
        self.stats["by_owasp"][owasp] = self.stats["by_owasp"].get(owasp, 0) + 1
        
        return context
    
    def enrich_finding(self, finding: AIFinding) -> AIFinding:
        """
        Enrich an AI finding with reachability context.
        
        Updates finding in place with:
        - is_reachable
        - guards
        - guard_risk_reduction
        - call_path
        - adjusted_risk_score
        """
        context = self.get_reachability_context(finding)
        
        finding.is_reachable = context.is_reachable
        finding.guards = context.guards_detected
        finding.guard_risk_reduction = context.risk_reduction
        finding.call_path = context.call_path
        
        # Update OWASP category if not set
        if not finding.owasp_category:
            finding.owasp_category = context.owasp_llm
        
        # Recalculate risk score
        base_weight = OWASP_LLM_REACHABLE_WEIGHTS.get(context.owasp_llm, 50)
        if not context.is_reachable:
            base_weight = OWASP_LLM_UNREACHABLE_WEIGHTS.get(context.owasp_llm, 15)
        
        # Apply guard reduction
        adjusted = base_weight * (1 - context.risk_reduction)
        
        # Normalize to 0-10 scale for finding
        finding.base_risk_score = base_weight / 20.0
        finding.adjusted_risk_score = adjusted / 20.0
        
        return finding
    
    def _check_call_graph_reachability(self, file_path: str, line_num: int) -> bool:
        """Check if location is reachable via call graph."""
        # Simplified: check if file contains any reachable function
        file_name = Path(file_path).stem
        
        for func in self.reachable_functions:
            if file_name in func or func in file_path:
                return True
        
        # Check entrypoints
        for entry in self.entrypoints:
            if file_name in entry or entry in file_path:
                return True
        
        return False
    
    def _infer_owasp_from_rule(self, rule_id: str) -> str:
        """Infer OWASP LLM category from rule ID."""
        rule_lower = rule_id.lower()
        
        # Direct patterns
        for i in range(1, 11):
            if f"llm{i:02d}" in rule_lower or f"llm0{i}" in rule_lower:
                return f"LLM{i:02d}"
        
        # Indirect patterns
        patterns = {
            "prompt": "LLM01",
            "inject": "LLM01",
            "sensitive": "LLM02",
            "disclosure": "LLM02",
            "supply": "LLM03",
            "output": "LLM05",
            "exec": "LLM05",
            "agency": "LLM06",
            "tool": "LLM06",
            "leak": "LLM07",
            "system": "LLM07",
            "vector": "LLM08",
            "embed": "LLM08",
            "misinfo": "LLM09",
            "consumption": "LLM10",
            "unbounded": "LLM10",
        }
        
        for pattern, owasp in patterns.items():
            if pattern in rule_lower:
                return owasp
        
        return "LLM01"  # Default to prompt injection
    
    def _calculate_risk_weight(
        self,
        owasp_category: str,
        is_reachable: bool,
        guards: List[str],
    ) -> int:
        """Calculate final risk weight for a finding."""
        # Base weight
        if is_reachable:
            base = OWASP_LLM_REACHABLE_WEIGHTS.get(owasp_category, 50)
        else:
            base = OWASP_LLM_UNREACHABLE_WEIGHTS.get(owasp_category, 15)
        
        # Calculate guard reduction
        total_reduction = 0.0
        for guard_name in guards:
            try:
                guard_type = GuardType(guard_name)
                effectiveness = GUARD_EFFECTIVENESS.get(guard_type, 0.3)
                # Combine reductions: 1 - (1-r1)(1-r2)...
                total_reduction = 1 - (1 - total_reduction) * (1 - effectiveness)
            except ValueError:
                # Unknown guard type, assume 30% reduction
                total_reduction = 1 - (1 - total_reduction) * 0.7
        
        # Cap at 90% reduction
        total_reduction = min(total_reduction, 0.9)
        
        # Apply reduction
        final = int(base * (1 - total_reduction))
        
        return final
    
    def get_correlation_data(self) -> List[Dict[str, Any]]:
        """
        Get AI findings data formatted for correlation engine.
        
        Returns list of dicts with fields expected by SignalType.AI_SECURITY.
        """
        correlation_data = []
        
        for file_path, result in self._file_cache.items():
            for flow in result.flows:
                correlation_data.append({
                    "flow_id": flow.flow_id,
                    "file_path": file_path,
                    "owasp_llm": flow.owasp_llm,
                    "flow_type": flow.flow_type.value,
                    "is_reachable": flow.is_reachable,
                    "guards": [g.guard_type.value for g in flow.guards],
                    "risk_reduction": flow.risk_reduction,
                    "source_type": flow.source.source_type.value,
                    "sink_type": flow.sink.sink_type.value,
                    "source_location": flow.source.location,
                    "sink_location": flow.sink.location,
                    "risk_weight": self._calculate_risk_weight(
                        flow.owasp_llm,
                        flow.is_reachable,
                        [g.guard_type.value for g in flow.guards],
                    ),
                })
        
        return correlation_data


def integrate_ai_reachability(
    findings: List[AIFinding],
    call_graph: Optional[Dict] = None,
    reachable_functions: Optional[Set[str]] = None,
    entrypoints: Optional[Set[str]] = None,
    repo_path: Optional[Path] = None,
) -> Tuple[List[AIFinding], Dict[str, Any]]:
    """
    High-level function to integrate AI findings with reachability analysis.
    
    Args:
        findings: List of AI security findings from scanner
        call_graph: Core REACHABLE call graph
        reachable_functions: Set of reachable functions
        entrypoints: Application entry points
        repo_path: Repository path for flow analysis
        
    Returns:
        (enriched_findings, summary_stats)
    """
    integration = AIReachabilityIntegration(
        call_graph=call_graph,
        reachable_functions=reachable_functions,
        entrypoints=entrypoints,
    )
    
    # Analyze repository if path provided
    if repo_path:
        integration.analyze_repository(repo_path)
    
    # Enrich each finding
    enriched = []
    for finding in findings:
        enriched_finding = integration.enrich_finding(finding)
        enriched.append(enriched_finding)
    
    # Generate summary
    summary = {
        "total_findings": len(findings),
        "reachable_findings": integration.stats["reachable_findings"],
        "guarded_findings": integration.stats["guarded_findings"],
        "by_owasp_llm": integration.stats["by_owasp"],
        "correlation_data": integration.get_correlation_data(),
    }
    
    return enriched, summary


# ════════════════════════════════════════════════════════════════════════════════
# CLI ENTRY POINT
# ════════════════════════════════════════════════════════════════════════════════

if __name__ == "__main__":
    import sys
    import json
    
    if len(sys.argv) < 2:
        logger.info("Usage: python ai_reachability_integration.py <repo_path>")
        sys.exit(1)
    
    repo_path = Path(sys.argv[1])
    
    integration = AIReachabilityIntegration()
    results = integration.analyze_repository(repo_path)
    
    logger.info(f"\n🔍 AI Reachability Integration: {repo_path}")
    print("=" * 70)
    logger.info(f"📁 Files analyzed: {results['files_analyzed']}")
    logger.info(f"🔀 Total flows: {results['total_flows']}")
    logger.info(f"⚠️  Unguarded: {results['unguarded_flows']}")
    logger.info(f"🛡️  Guarded: {results['guarded_flows']}")
    
    logger.info(f"\n📊 OWASP LLM Breakdown:")
    for cat, count in sorted(results['owasp_breakdown'].items()):
        if count > 0:
            logger.info(f"   {cat}: {count}")
    
    # Output correlation data
    correlation_data = integration.get_correlation_data()
    if correlation_data:
        logger.info(f"\n📤 Correlation Data ({len(correlation_data)} flows)")
        print(json.dumps(correlation_data[:3], indent=2))  # Show first 3
