# REACHABLE AI Security Module - Scanner Orchestrator
# Copyright (c) 2026 Sthenos Security. All rights reserved.

"""
AI Security Scanner - Main orchestrator for AI security analysis.

Coordinates detection across:
- Semgrep rules (OWASP LLM Top 10, MCP, model controls)
- Tree-sitter AST extraction
- Taint analysis for prompt flows
- Tool capability mapping
- Reachability analysis with guard detection

Usage:
    from reachable.ai import AISecurityScanner, AIScanConfig
    
    scanner = AISecurityScanner()
    for finding in scanner.scan(repo_path):
        print(finding)

Integration:
    Results integrate with the correlation engine via SignalType.AI_SECURITY
    and get_ai_risk_weight() from owasp_llm_classifier.py
"""

from typing import Iterator, Optional, Dict, List, Set, Any
from pathlib import Path
import json
import subprocess
import logging
from datetime import datetime

from reachable.ai.config import AIScanConfig
from reachable.ai.schemas.ai_finding import AIFinding, LLM_TO_ASI_MAPPING, ASI_ONLY_CATEGORIES
import re
from reachable.ai.schemas.ai_primitive import AIPrimitive

# Import reachability analyzer
try:
    from reachable.ai.ai_reachability import (
        AIReachabilityAnalyzer, 
        analyze_ai_reachability,
        AIReachabilityResult
    )
    HAS_REACHABILITY = True
except ImportError:
    HAS_REACHABILITY = False
    AIReachabilityAnalyzer = None

# Import OWASP LLM classifier for risk scoring
try:
    from reachable.owasp_llm_classifier import (
        get_ai_risk_weight,
        classify_ai_finding,
        is_ai_security_finding,
        is_critical_ai_finding,
    )
    HAS_CLASSIFIER = True
except ImportError:
    HAS_CLASSIFIER = False
    get_ai_risk_weight = None

logger = logging.getLogger(__name__)

# Patterns that indicate agentic architecture
AGENTIC_PATTERNS = [
    # Agent frameworks
    r"from\s+crewai\s+import",
    r"from\s+autogen\s+import",
    r"from\s+langchain\.agents\s+import",
    r"from\s+llama_index\.agent\s+import",
    r"AgentExecutor\s*\(",
    r"create_react_agent\s*\(",
    r"create_openai_functions_agent\s*\(",
    # Tool usage
    r"@tool",
    r"tools\s*=\s*\[",
    r"StructuredTool\s*\(",
    r"Tool\s*\(\s*name\s*=",
    # MCP
    r"from\s+mcp\s+import",
    r"MCPClient",
    r"@server\.tool",
    r"FastMCP\s*\(",
    # Memory/state
    r"ConversationBufferMemory",
    r"ConversationSummaryMemory",
    r"memory\s*=",
    r"chat_history",
    r"agent_scratchpad",
    # Multi-agent
    r"Crew\s*\(",
    r"GroupChat\s*\(",
    r"agent\.send",
    r"agents\s*=\s*\[",
]


class AISecurityScanner:
    """Main orchestrator for AI security scanning."""
    
    # Path to built-in Semgrep rules
    SEMGREP_RULES_DIR = Path(__file__).parent / "detectors" / "semgrep"
    
    # Garak and Corpus derived rules
    GARAK_RULES_DIR = SEMGREP_RULES_DIR / "garak_derived"
    CORPUS_RULES_DIR = SEMGREP_RULES_DIR / "corpus_derived"
    
    def __init__(
        self, 
        config: Optional[AIScanConfig] = None,
        call_graph: Optional[Dict] = None,
        reachable_functions: Optional[Set[str]] = None,
        entrypoints: Optional[Set[str]] = None,
    ):
        """
        Initialize AI security scanner.
        
        Args:
            config: Scan configuration. Defaults to full analysis.
            call_graph: Application call graph for reachability analysis.
            reachable_functions: Set of functions reachable from entrypoints.
            entrypoints: Application entry points (HTTP handlers, main, etc.).
        """
        self.config = config or AIScanConfig.full()
        self._primitives: list[AIPrimitive] = []
        self._findings: list[AIFinding] = []
        self._reachability_results: list = []
        
        # Call graph integration for reachability
        self.call_graph = call_graph or {}
        self.reachable_functions = reachable_functions or set()
        self.entrypoints = entrypoints or set()
        
        # Statistics
        self._stats = {
            "semgrep_rules_loaded": 0,
            "semgrep_findings": 0,
            "reachable_findings": 0,
            "guarded_findings": 0,
            "by_owasp": {},
            "by_severity": {},
            "by_policy": {},
            "by_asi": {},  # NEW: Agentic Security Index breakdown
            "is_agentic_context": False,  # NEW: Whether agentic patterns detected
        }
    
    def _detect_agentic_context(self, repo_path: Path) -> bool:
        """
        Detect if repository contains agentic patterns.
        
        Scans Python files for patterns indicating agent frameworks,
        tool usage, MCP, memory systems, or multi-agent architectures.
        
        Returns:
            True if agentic patterns detected, False otherwise.
        """
        try:
            for py_file in repo_path.rglob("*.py"):
                try:
                    content = py_file.read_text(errors="ignore")
                    for pattern in AGENTIC_PATTERNS:
                        if re.search(pattern, content):
                            logger.info(f"Agentic pattern detected: {pattern} in {py_file}")
                            return True
                except Exception:
                    continue
        except Exception as e:
            logger.warning(f"Error detecting agentic context: {e}")
        return False
    
    def scan(self, repo_path: Path) -> Iterator[AIFinding]:
        """
        Run full AI security scan on repository.
        
        Args:
            repo_path: Path to repository root.
            
        Yields:
            AIFinding objects for each detected issue.
        """
        repo_path = Path(repo_path).resolve()
        
        if not repo_path.exists():
            raise ValueError(f"Repository path does not exist: {repo_path}")
        
        logger.info(f"Starting AI security scan: {repo_path}")
        
        # Phase 0a: Detect agentic context (for dual-tagging)
        self._stats["is_agentic_context"] = self._detect_agentic_context(repo_path)
        if self._stats["is_agentic_context"]:
            logger.info("Agentic context detected - will apply ASI dual tags")
        
        # Phase 0b: Run reachability analysis first (for guard detection)
        if HAS_REACHABILITY and self.config.enable_reachability:
            logger.info("Phase 0b: Running reachability analysis...")
            self._run_reachability_analysis(repo_path)
        
        # Phase 1: Semgrep detection (fast, high coverage)
        if self.config.enable_semgrep:
            logger.info("Phase 1: Running Semgrep detection...")
            for finding in self._run_semgrep_detection(repo_path):
                # Enrich with reachability
                self._enrich_with_reachability(finding)
                # Apply agentic tags (dual-tagging)
                finding.apply_agentic_tags(self._stats["is_agentic_context"])
                # Calculate risk score
                self._calculate_risk_score(finding)
                # Update statistics
                self._update_stats(finding)
                yield finding
        
        # Phase 2: Tree-sitter extraction (precise, custom frameworks)
        if self.config.enable_treesitter:
            logger.info("Phase 2: Running Tree-sitter extraction...")
            yield from self._run_treesitter_extraction(repo_path)
        
        # Phase 3: Taint analysis (flow tracking)
        if self.config.enable_taint_analysis:
            logger.info("Phase 3: Running taint analysis...")
            yield from self._run_taint_analysis(repo_path)
        
        # Log summary
        self._log_summary()
    
    def _run_reachability_analysis(self, repo_path: Path):
        """Run AI-specific reachability analysis."""
        if not HAS_REACHABILITY:
            logger.warning("AI reachability analyzer not available")
            return
        
        try:
            analyzer = AIReachabilityAnalyzer()
            self._reachability_results = analyzer.analyze_directory(repo_path)
            
            total_flows = sum(len(r.flows) for r in self._reachability_results)
            unguarded = sum(r.unguarded_flows for r in self._reachability_results)
            
            logger.info(f"Reachability: {len(self._reachability_results)} files, "
                        f"{total_flows} flows, {unguarded} unguarded")
        except Exception as e:
            logger.error(f"Reachability analysis failed: {e}")
    
    def _enrich_with_reachability(self, finding: AIFinding):
        """Enrich finding with reachability information."""
        if not self._reachability_results:
            # No reachability data - assume reachable (conservative)
            finding.is_reachable = True
            return
        
        # Check if finding location has a flow
        for result in self._reachability_results:
            if finding.file_path in result.file_path or result.file_path in finding.file_path:
                for flow in result.flows:
                    # Check if finding is near a sink
                    sink_line = int(flow.sink.location.split(':')[1])
                    if abs(finding.line_start - sink_line) <= 5:  # Within 5 lines
                        finding.is_reachable = True
                        finding.guards = [g.guard_type.value for g in flow.guards]
                        finding.guard_risk_reduction = flow.risk_reduction
                        
                        # Build call path
                        finding.call_path = [
                            f"Source: {flow.source.location} ({flow.source.source_type.value})",
                            f"Sink: {flow.sink.location} ({flow.sink.sink_type.value})",
                        ]
                        if flow.guards:
                            finding.call_path.append(
                                f"Guards: {', '.join(g.guard_type.value for g in flow.guards)}"
                            )
                        return
        
        # Check against call graph if available
        if self.reachable_functions:
            # Extract function name from finding location
            # This is a simplified check - real implementation would parse AST
            finding.is_reachable = any(
                func in finding.file_path for func in self.reachable_functions
            )
        else:
            # No call graph - assume reachable (conservative)
            finding.is_reachable = True
    
    def _calculate_risk_score(self, finding: AIFinding):
        """Calculate risk score using OWASP LLM classifier."""
        if not HAS_CLASSIFIER:
            # Fallback to basic scoring
            finding.calculate_adjusted_risk()
            return
        
        try:
            # Get risk weight from classifier
            weight, classification = get_ai_risk_weight(
                rule_id=finding.rule_id,
                message=finding.message,
                metadata=finding.metadata,
                is_reachable=finding.is_reachable,
                guards_detected=finding.guards,
            )
            
            # Update finding with classification
            if classification.owasp_llm_category:
                finding.owasp_category = classification.owasp_llm_category.value
                finding.owasp_name = classification.owasp_llm_name
            
            if classification.policy_ids:
                finding.policy_id = classification.policy_ids[0]
            
            if classification.cwe_ids:
                finding.cwe_id = f"CWE-{classification.cwe_ids[0]}"
            
            # Set risk scores (normalized to 0-10 scale)
            finding.base_risk_score = min(10.0, weight / 20.0)
            finding.adjusted_risk_score = finding.base_risk_score * (1 - finding.guard_risk_reduction)
            
        except Exception as e:
            logger.debug(f"Risk calculation fallback: {e}")
            finding.calculate_adjusted_risk()
    
    def _update_stats(self, finding: AIFinding):
        """Update scan statistics."""
        self._stats["semgrep_findings"] += 1
        
        if finding.is_reachable:
            self._stats["reachable_findings"] += 1
        
        if finding.guards:
            self._stats["guarded_findings"] += 1
        
        # By OWASP category
        owasp = finding.owasp_category or "UNKNOWN"
        self._stats["by_owasp"][owasp] = self._stats["by_owasp"].get(owasp, 0) + 1
        
        # By severity
        sev = finding.severity
        self._stats["by_severity"][sev] = self._stats["by_severity"].get(sev, 0) + 1
        
        # By policy
        policy = finding.policy_id or "UNKNOWN"
        self._stats["by_policy"][policy] = self._stats["by_policy"].get(policy, 0) + 1
        
        # By ASI category (dual-tagging)
        for asi in finding.agentic_categories:
            self._stats["by_asi"][asi] = self._stats["by_asi"].get(asi, 0) + 1
    
    def _log_summary(self):
        """Log scan summary."""
        total = len(self._findings)
        reachable = self._stats["reachable_findings"]
        guarded = self._stats["guarded_findings"]
        
        logger.info(f"AI security scan complete:")
        logger.info(f"  Total findings: {total}")
        logger.info(f"  Reachable: {reachable} ({reachable*100//max(1,total)}%)")
        logger.info(f"  Guarded: {guarded}")
        
        if self._stats["by_owasp"]:
            logger.info(f"  By OWASP LLM: {self._stats['by_owasp']}")
        
        if self._stats["by_severity"]:
            logger.info(f"  By severity: {self._stats['by_severity']}")
    
    def _run_semgrep_detection(self, repo_path: Path) -> Iterator[AIFinding]:
        """Run Semgrep with AI security rules."""
        # Collect rule files to use
        rule_files = list(self.SEMGREP_RULES_DIR.glob("*.yml"))
        rule_files.extend(self.SEMGREP_RULES_DIR.glob("*.yaml"))
        
        if not rule_files:
            logger.warning(f"No Semgrep rules found in {self.SEMGREP_RULES_DIR}")
            return
        
        # Filter by OWASP categories if specified
        if self.config.owasp_categories:
            filtered_rules = []
            for rf in rule_files:
                # Include rule file if it matches any requested category
                for cat in self.config.owasp_categories:
                    if cat.lower() in rf.name.lower():
                        filtered_rules.append(rf)
                        break
                # Always include base/common rules
                if "base" in rf.name.lower() or "common" in rf.name.lower():
                    filtered_rules.append(rf)
            rule_files = filtered_rules
        
        logger.info(f"Using {len(rule_files)} Semgrep rule files")
        
        # Build Semgrep command
        cmd = [
            "semgrep",
            "--json",
            "--quiet",
            f"--timeout={self.config.timeout_seconds}",
        ]
        
        for rf in rule_files:
            cmd.extend(["--config", str(rf)])
        
        cmd.append(str(repo_path))
        
        try:
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=self.config.timeout_seconds + 60,  # Extra buffer
            )
            
            if result.returncode not in (0, 1):  # 1 = findings found
                if result.stderr and result.stderr.strip():
                    logger.error(f"Semgrep error: {result.stderr.strip()}")
                return
            
            # Parse results
            if result.stdout:
                data = json.loads(result.stdout)
                results = data.get("results", [])
                
                for r in results:
                    finding = AIFinding.from_semgrep(r)
                    
                    # Filter by severity
                    if self._meets_severity_threshold(finding.severity):
                        self._findings.append(finding)
                        yield finding
                        
        except subprocess.TimeoutExpired:
            logger.error(f"Semgrep timed out after {self.config.timeout_seconds}s")
        except FileNotFoundError:
            logger.warning("Semgrep not found. Install with: pip install semgrep")
        except json.JSONDecodeError as e:
            logger.error(f"Failed to parse Semgrep output: {e}")
    
    def _run_treesitter_extraction(self, repo_path: Path) -> Iterator[AIFinding]:
        """Run Tree-sitter AST extraction for custom frameworks."""
        # TODO: Implement Tree-sitter extraction
        # This will extract AI primitives from frameworks Semgrep can't handle
        logger.debug("Tree-sitter extraction not yet implemented")
        return
        yield  # Make this a generator
    
    def _run_taint_analysis(self, repo_path: Path) -> Iterator[AIFinding]:
        """Run taint analysis for prompt injection flows."""
        # Taint analysis is now integrated into reachability analysis
        # Additional taint tracking using call graph would go here
        if not self._reachability_results:
            logger.debug("Taint analysis requires reachability results")
            return
        
        # v4.5.40: Deduplicate findings by SOURCE location
        # Multiple source → different sinks should produce ONE finding per source
        # (User fixes the source once, not each sink separately)
        seen_sources: Set[str] = set()
        
        # Generate findings for unguarded flows
        for result in self._reachability_results:
            for flow in result.flows:
                if not flow.guards and flow.is_reachable:
                    # Extract file and source line for deduplication
                    file_path = flow.source.location.split(':')[0]
                    source_line = int(flow.source.location.split(':')[1])
                    
                    # Deduplicate by file:source_line (same source = same finding)
                    # One tainted source appears once, regardless of how many sinks it flows to
                    dedup_key = f"{file_path}:{source_line}:{flow.source.source_type.value}"
                    if dedup_key in seen_sources:
                        continue
                    seen_sources.add(dedup_key)
                    
                    # Get sink line for the finding range
                    sink_line = int(flow.sink.location.split(':')[1])
                    
                    # Create finding for unguarded flow
                    finding = AIFinding(
                        rule_id="taint-unguarded-flow",
                        message=f"Unguarded data flow from {flow.source.source_type.value} to {flow.sink.sink_type.value}",
                        file_path=file_path,
                        line_start=source_line,
                        line_end=sink_line,
                        severity="WARNING",
                        policy_id="AI-001" if flow.sink.sink_type.value == "llm_prompt" else "AI-005",
                        is_reachable=True,
                        detection_source="taint",
                        call_path=[flow.source.location, flow.sink.location],
                    )
                    self._enrich_with_reachability(finding)
                    self._calculate_risk_score(finding)
                    # v4.5.40: Include taint findings in OWASP stats
                    self._update_stats(finding)
                    self._findings.append(finding)
                    yield finding
    
    def _meets_severity_threshold(self, severity: str) -> bool:
        """Check if severity meets configured threshold."""
        severity_order = {"INFO": 0, "WARNING": 1, "ERROR": 2}
        finding_level = severity_order.get(severity.upper(), 0)
        threshold_level = severity_order.get(self.config.min_severity, 0)
        return finding_level >= threshold_level
    
    @property
    def findings(self) -> list[AIFinding]:
        """Get all findings from last scan."""
        return self._findings.copy()
    
    @property  
    def primitives(self) -> list[AIPrimitive]:
        """Get all detected primitives from last scan."""
        return self._primitives.copy()
    
    @property
    def statistics(self) -> dict:
        """Get scan statistics."""
        return self._stats.copy()
    
    @property
    def reachability_results(self) -> list:
        """Get reachability analysis results."""
        return self._reachability_results
    
    def get_findings_by_owasp(self, category: str) -> list[AIFinding]:
        """Get findings for a specific OWASP LLM category."""
        return [f for f in self._findings if f.owasp_category == category]
    
    def get_findings_by_policy(self, policy_id: str) -> list[AIFinding]:
        """Get findings for a specific policy ID."""
        return [f for f in self._findings if f.policy_id == policy_id]
    
    def get_findings_by_severity(self, severity: str) -> list[AIFinding]:
        """Get findings by severity (ERROR, WARNING, INFO)."""
        return [f for f in self._findings if f.severity.upper() == severity.upper()]
    
    def get_reachable_findings(self) -> list[AIFinding]:
        """Get only findings in reachable code paths."""
        return [f for f in self._findings if f.is_reachable]
    
    def get_unguarded_findings(self) -> list[AIFinding]:
        """Get findings without guards on the code path."""
        return [f for f in self._findings if not f.guards]
    
    def get_critical_paths(self) -> list[dict]:
        """
        Get critical reachability paths.
        
        Returns paths where:
        ENTRYPOINT → SOURCE → PROMPT_SINK → TOOL → DANGEROUS_OP
        """
        critical_paths = []
        
        for result in self._reachability_results:
            for flow in result.flows:
                if flow.is_reachable and not flow.guards:
                    critical_paths.append({
                        "file": result.file_path,
                        "source": {
                            "type": flow.source.source_type.value,
                            "location": flow.source.location,
                            "variable": flow.source.variable,
                        },
                        "sink": {
                            "type": flow.sink.sink_type.value,
                            "location": flow.sink.location,
                            "function": flow.sink.function,
                        },
                        "flow_type": flow.flow_type.value,
                        "guards": [],
                        "risk_level": "HIGH" if flow.sink.sink_type.value in 
                            ["code_exec", "shell_exec", "llm_prompt"] else "MEDIUM",
                    })
        
        return sorted(critical_paths, key=lambda x: x["risk_level"], reverse=True)
    
    def get_summary(self) -> dict:
        """Get comprehensive scan summary for integration with correlation engine."""
        return {
            "enabled": True,
            "included_in_risk_score": True,  # AI findings now count!
            "total": len(self._findings),
            "reachable": self._stats["reachable_findings"],
            "guarded": self._stats["guarded_findings"],
            "unguarded": len(self._findings) - self._stats["guarded_findings"],
            "by_owasp": self._stats["by_owasp"],
            "by_severity": self._stats["by_severity"],
            "by_policy": self._stats["by_policy"],
            "by_asi": self._stats["by_asi"],  # NEW: Agentic breakdown
            "is_agentic_context": self._stats["is_agentic_context"],  # NEW
            "critical_paths": len(self.get_critical_paths()),
            "reachability_files_analyzed": len(self._reachability_results),
            "timestamp": datetime.now().isoformat(),
        }
    
    def to_correlation_format(self) -> list[dict]:
        """
        Convert findings to format expected by correlation engine.
        
        Returns list of dicts with fields expected by SignalType.AI_SECURITY.
        """
        return [
            {
                "finding_id": f"{f.rule_id}:{f.file_path}:{f.line_start}",
                "rule_id": f.rule_id,
                "policy_id": f.policy_id,
                "owasp_llm": f.owasp_category,
                "severity": f.severity,
                "file_path": f.file_path,
                "line_number": f.line_start,
                "message": f.message,
                "is_reachable": f.is_reachable,
                "guards": f.guards,
                "risk_weight": int(f.adjusted_risk_score * 20),  # Convert to 0-200 scale
                "cwe_id": f.cwe_id,
            }
            for f in self._findings
        ]
