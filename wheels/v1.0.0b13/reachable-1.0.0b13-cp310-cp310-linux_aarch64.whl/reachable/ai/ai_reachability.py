#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.

"""
REACHABLE P6.8: AI Reachability Analyzer
========================================

Traces data flows in AI/LLM applications to determine:
1. Whether user input can reach LLM calls (prompt injection risk)
2. Whether LLM output flows to dangerous sinks (output handling risk)
3. What guards/sanitizers exist on the path

This analyzer works with the call graph to provide reachability context
for AI security findings, enabling risk score adjustments.

Key Concepts:
- Source: Origin of untrusted data (HTTP params, user input, files)
- Sink: Dangerous operation (LLM call, exec, eval, file write)
- Guard: Sanitizer or validator that reduces risk
- Taint: Data that has touched a source without passing through a guard

Architecture:
    Sources → [Taint Tracking] → Guards? → Sinks
                                    ↓
                              Risk Adjustment

OWASP LLM Risk Mapping:
- LLM01 (Prompt Injection): Source → LLM_PROMPT without guards
- LLM05 (Output Handling): LLM_OUTPUT → CODE_EXEC/SHELL_EXEC without sanitization
- LLM06 (Excessive Agency): TOOL_CALL without HUMAN_APPROVAL guard
"""

from dataclasses import dataclass, field
from enum import Enum, auto
from pathlib import Path
from typing import Dict, List, Optional, Set, Tuple, Any
import re
import logging

logger = logging.getLogger(__name__)


class FlowType(Enum):
    """Type of data flow being tracked."""
    PROMPT_INPUT = "prompt_input"      # User → LLM prompt (LLM01 risk)
    PROMPT_OUTPUT = "prompt_output"    # LLM response → dangerous sink (LLM05 risk)
    TOOL_INPUT = "tool_input"          # User → tool parameters (LLM06 risk)
    TOOL_OUTPUT = "tool_output"        # Tool result → user/LLM
    RAG_CONTENT = "rag_content"        # Retrieved docs → LLM context (LLM01 indirect)
    SYSTEM_PROMPT = "system_prompt"    # System prompt exposure (LLM07 risk)


class SourceType(Enum):
    """Types of untrusted data sources."""
    HTTP_PARAM = "http_param"          # request.args, request.form
    HTTP_BODY = "http_body"            # request.json, request.data
    HTTP_HEADER = "http_header"        # request.headers
    USER_INPUT = "user_input"          # input(), stdin
    FILE_READ = "file_read"            # open().read()
    DATABASE = "database"              # cursor.fetchall()
    ENVIRONMENT = "environment"        # os.environ
    RAG_RETRIEVAL = "rag_retrieval"    # vector_store.similarity_search()
    WEBSOCKET = "websocket"            # ws.receive()
    MESSAGE_QUEUE = "message_queue"    # queue.get()
    MCP_INPUT = "mcp_input"            # MCP tool arguments
    LLM_OUTPUT = "llm_output"          # LLM response (for output handling)


class SinkType(Enum):
    """Types of dangerous sinks."""
    LLM_PROMPT = "llm_prompt"          # openai.chat.completions.create()
    LLM_SYSTEM = "llm_system"          # System prompt injection
    CODE_EXEC = "code_exec"            # exec(), eval()
    SHELL_EXEC = "shell_exec"          # subprocess, os.system
    FILE_WRITE = "file_write"          # open().write()
    HTTP_RESPONSE = "http_response"    # return Response()
    HTML_RENDER = "html_render"        # render_template()
    DATABASE_WRITE = "database_write"  # cursor.execute()
    TOOL_CALL = "tool_call"            # function_call, tool_use
    MCP_TOOL = "mcp_tool"              # MCP tool execution


class GuardType(Enum):
    """Types of guards/sanitizers."""
    INPUT_VALIDATION = "input_validation"      # Pydantic, Zod, schema
    LENGTH_LIMIT = "length_limit"              # len() check, [:N] slice
    ALLOWLIST = "allowlist"                    # in allowed_values
    BLOCKLIST = "blocklist"                    # not in blocked
    REGEX_FILTER = "regex_filter"              # re.sub(), re.match()
    HTML_ESCAPE = "html_escape"                # html.escape(), markupsafe
    SQL_PARAM = "sql_param"                    # Parameterized queries
    INJECTION_DETECT = "injection_detect"      # Rebuff, LlamaGuard, Lakera
    OUTPUT_FILTER = "output_filter"            # Content filtering
    HUMAN_APPROVAL = "human_approval"          # Confirmation required (LLM06)
    SANDBOX = "sandbox"                        # RestrictedPython (LLM05)
    RATE_LIMIT = "rate_limit"                  # Rate limiting (LLM10)
    TOKEN_LIMIT = "token_limit"                # Token limiting (LLM10)


# ════════════════════════════════════════════════════════════════════════════════
# DATA CLASSES
# ════════════════════════════════════════════════════════════════════════════════

@dataclass
class TaintSource:
    """A source of untrusted data."""
    source_type: SourceType
    location: str           # file:line
    variable: str           # Variable name
    confidence: float = 1.0
    owasp_llm: str = ""     # Related OWASP LLM category


@dataclass
class TaintSink:
    """A dangerous sink."""
    sink_type: SinkType
    location: str
    function: str           # Function being called
    argument: str           # Which argument receives taint
    confidence: float = 1.0
    owasp_llm: str = ""     # Related OWASP LLM category


@dataclass
class TaintGuard:
    """A guard/sanitizer on a data flow path."""
    guard_type: GuardType
    location: str
    effectiveness: float    # 0.0 - 1.0 risk reduction
    owasp_llm: List[str] = field(default_factory=list)  # Which OWASP categories it helps


@dataclass
class DataFlow:
    """A complete data flow from source to sink."""
    flow_id: str
    flow_type: FlowType
    source: TaintSource
    sink: TaintSink
    guards: List[TaintGuard] = field(default_factory=list)
    path: List[str] = field(default_factory=list)  # Variable flow path
    is_reachable: bool = True
    risk_reduction: float = 0.0  # Combined guard effectiveness
    owasp_llm: str = ""          # Primary OWASP LLM category for this flow


@dataclass
class AIReachabilityResult:
    """Result of AI reachability analysis."""
    file_path: str
    flows: List[DataFlow] = field(default_factory=list)
    sources_found: int = 0
    sinks_found: int = 0
    unguarded_flows: int = 0
    guarded_flows: int = 0
    guards_detected: Set[str] = field(default_factory=set)
    
    # OWASP LLM breakdown
    llm01_flows: int = 0  # Prompt injection flows
    llm05_flows: int = 0  # Output handling flows
    llm06_flows: int = 0  # Excessive agency flows
    llm07_flows: int = 0  # System prompt exposure


# ════════════════════════════════════════════════════════════════════════════════
# PATTERN DEFINITIONS - PYTHON
# ════════════════════════════════════════════════════════════════════════════════

PYTHON_SOURCES = {
    SourceType.HTTP_PARAM: [
        r'request\.args\[', r'request\.args\.get\(',
        r'request\.form\[', r'request\.form\.get\(',
        r'request\.values\[', r'request\.params\[',
        r'Query\(', r'Path\(', r'Body\(',  # FastAPI
    ],
    SourceType.HTTP_BODY: [
        r'request\.json', r'request\.get_json\(',
        r'request\.data', r'await request\.json\(',
        r'body\s*=\s*await\s+request\.body\(',
    ],
    SourceType.USER_INPUT: [
        r'\binput\s*\(', r'sys\.stdin\.read', r'fileinput\.input',
        r'st\.text_input\(', r'st\.text_area\(', r'st\.chat_input\(',  # Streamlit
    ],
    SourceType.FILE_READ: [
        r'open\s*\([^)]+\)\.read', r'Path\s*\([^)]+\)\.read_text',
        r'\.read_csv\(', r'\.read_json\(',
        r'st\.file_uploader\(',  # Streamlit
    ],
    SourceType.RAG_RETRIEVAL: [
        r'\.similarity_search\(', r'\.get_relevant_documents\(',
        r'retriever\.invoke\(', r'vector_store\.search\(', r'\.retrieve\(',
        r'query_engine\.query\(', r'\.as_retriever\(',  # LlamaIndex
    ],
    SourceType.WEBSOCKET: [
        r'websocket\.receive', r'ws\.recv\(', r'await ws\.receive\(',
    ],
    SourceType.MCP_INPUT: [
        r'@mcp\.tool', r'server\.request_context', r'tool\.arguments',
    ],
    SourceType.LLM_OUTPUT: [
        r'response\.choices\[', r'\.content', r'message\.content',
        r'completion\.choices', r'result\.content',
    ],
}

PYTHON_SINKS = {
    SinkType.LLM_PROMPT: [
        r'\.chat\.completions\.create\(', r'client\.chat\.completions\.create\(',
        r'openai\.ChatCompletion\.create\(',
        r'\.messages\.create\(', r'client\.messages\.create\(',
        r'Anthropic\(\)\.messages',
        r'\.invoke\(', r'llm\(', r'chain\.run\(', r'chain\.invoke\(',
        r'ChatOpenAI\(', r'ChatAnthropic\(',
        r'\.generate\(', r'\.complete\(', r'\.predict\(',
    ],
    SinkType.LLM_SYSTEM: [
        r'"role"\s*:\s*"system"', r"'role'\s*:\s*'system'",
        r'SystemMessage\(', r'system_message\s*=', r'system_prompt\s*=',
    ],
    SinkType.CODE_EXEC: [
        r'\bexec\s*\(', r'\beval\s*\(', r'compile\s*\(',
        r'PythonREPL\(', r'python_repl\.run\(',
    ],
    SinkType.SHELL_EXEC: [
        r'subprocess\.\w+\(', r'os\.system\(', r'os\.popen\(',
        r'ShellTool\(', r'BashProcess\(',
    ],
    SinkType.HTML_RENDER: [
        r'render_template\(', r'render_template_string\(',
        r'Markup\(', r'\.format_map\(',
        r'st\.markdown\(', r'st\.html\(',  # Streamlit
    ],
    SinkType.TOOL_CALL: [
        r'function_call', r'tool_use', r'\.call_tool\(', r'execute_tool\(',
        r'AgentExecutor\(', r'agent\.run\(', r'agent\.invoke\(',
        r'crew\.kickoff\(',  # CrewAI
    ],
    SinkType.MCP_TOOL: [
        r'@mcp\.tool', r'server\.call_tool\(', r'mcp\.types\.Tool\(',
    ],
}

PYTHON_GUARDS = {
    GuardType.INPUT_VALIDATION: [
        (r'pydantic', 0.5), (r'BaseModel', 0.5), (r'@validator', 0.5),
        (r'@field_validator', 0.5), (r'Field\(', 0.4), (r'schema\.validate', 0.5),
        (r'instructor\.patch', 0.6),
    ],
    GuardType.LENGTH_LIMIT: [
        (r'\[:(\d+)\]', 0.3), (r'len\([^)]+\)\s*[<>]=?\s*\d+', 0.3),
        (r'max_length\s*=', 0.3), (r'max_tokens\s*=', 0.3), (r'truncate\(', 0.3),
    ],
    GuardType.HTML_ESCAPE: [
        (r'html\.escape\(', 0.6), (r'markupsafe\.escape\(', 0.6),
        (r'bleach\.clean\(', 0.7), (r'escape\(', 0.5), (r'sanitize\(', 0.6),
    ],
    GuardType.INJECTION_DETECT: [
        (r'rebuff', 0.8), (r'LlamaGuard', 0.8), (r'NeMoGuardrails', 0.8),
        (r'guardrails', 0.7), (r'detect_injection', 0.7), (r'is_prompt_injection', 0.7),
        (r'lakera', 0.8), (r'protectai', 0.7), (r'prompt_armor', 0.7),
    ],
    GuardType.ALLOWLIST: [
        (r'\bin\s+\[', 0.6), (r'\bin\s+allowed', 0.7), (r'whitelist', 0.6),
        (r'allowed_values', 0.6), (r'permitted_tools', 0.7), (r'tool_allowlist', 0.7),
    ],
    GuardType.SANDBOX: [
        (r'RestrictedPython', 0.6), (r'pyodide', 0.5), (r'sandbox', 0.5),
        (r'CodeSandbox', 0.6), (r'isolated', 0.4),
    ],
    GuardType.HUMAN_APPROVAL: [
        (r'confirm', 0.9), (r'approval', 0.9), (r'human_in_the_loop', 0.9),
        (r'require_confirmation', 0.9), (r'await_approval', 0.9),
        (r'interrupt_before', 0.8),  # LangGraph
    ],
    GuardType.OUTPUT_FILTER: [
        (r'filter_output', 0.6), (r'content_filter', 0.6), (r'moderate\(', 0.5),
        (r'moderation\.create', 0.7), (r'ContentFilter', 0.6),
    ],
    GuardType.RATE_LIMIT: [
        (r'rate_limit', 0.4), (r'RateLimiter', 0.4), (r'throttle', 0.3),
    ],
    GuardType.TOKEN_LIMIT: [
        (r'max_tokens\s*=', 0.4), (r'token_limit', 0.4), (r'max_iterations', 0.5),
    ],
}

# ════════════════════════════════════════════════════════════════════════════════
# PATTERN DEFINITIONS - TYPESCRIPT/JAVASCRIPT
# ════════════════════════════════════════════════════════════════════════════════

TYPESCRIPT_SOURCES = {
    SourceType.HTTP_PARAM: [
        r'req\.query\[', r'req\.query\.', r'req\.params\[', r'req\.params\.',
        r'searchParams\.get\(',
    ],
    SourceType.HTTP_BODY: [
        r'req\.body', r'request\.body', r'await req\.json\(', r'await request\.json\(',
    ],
    SourceType.USER_INPUT: [
        r'prompt\(', r'readline\.', r'process\.stdin',
    ],
    SourceType.RAG_RETRIEVAL: [
        r'\.similaritySearch\(', r'\.query\(', r'retriever\.invoke\(',
    ],
}

TYPESCRIPT_SINKS = {
    SinkType.LLM_PROMPT: [
        r'openai\.chat\.completions\.create\(', r'anthropic\.messages\.create\(',
        r'generateText\(', r'streamText\(', r'generateObject\(',  # Vercel AI SDK
        r'\.invoke\(', r'chain\.call\(',
    ],
    SinkType.CODE_EXEC: [
        r'\beval\s*\(', r'new Function\(', r'vm\.runInContext\(',
    ],
    SinkType.SHELL_EXEC: [
        r'child_process\.exec\(', r'execSync\(', r'spawn\(',
    ],
    SinkType.HTML_RENDER: [
        r'innerHTML\s*=', r'dangerouslySetInnerHTML', r'\.html\(',
    ],
}

TYPESCRIPT_GUARDS = {
    GuardType.INPUT_VALIDATION: [
        (r'zod', 0.5), (r'z\.object', 0.5), (r'\.parse\(', 0.4),
        (r'\.safeParse\(', 0.5), (r'joi\.', 0.5), (r'yup\.', 0.5),
    ],
    GuardType.HTML_ESCAPE: [
        (r'DOMPurify', 0.7), (r'sanitizeHtml', 0.6), (r'xss\(', 0.6),
    ],
    GuardType.HUMAN_APPROVAL: [
        (r'confirm\(', 0.8), (r'approval', 0.9),
    ],
}

# ════════════════════════════════════════════════════════════════════════════════
# OWASP LLM CATEGORY MAPPING
# ════════════════════════════════════════════════════════════════════════════════

SINK_TO_OWASP_LLM = {
    SinkType.LLM_PROMPT: "LLM01",     # Prompt Injection
    SinkType.LLM_SYSTEM: "LLM07",     # System Prompt Leakage
    SinkType.CODE_EXEC: "LLM05",      # Improper Output Handling
    SinkType.SHELL_EXEC: "LLM05",     # Improper Output Handling
    SinkType.HTML_RENDER: "LLM05",    # Improper Output Handling
    SinkType.TOOL_CALL: "LLM06",      # Excessive Agency
    SinkType.MCP_TOOL: "LLM06",       # Excessive Agency
}

GUARD_TO_OWASP_LLM = {
    GuardType.INJECTION_DETECT: ["LLM01"],
    GuardType.INPUT_VALIDATION: ["LLM01", "LLM02"],
    GuardType.HTML_ESCAPE: ["LLM05"],
    GuardType.SANDBOX: ["LLM05"],
    GuardType.OUTPUT_FILTER: ["LLM02", "LLM05"],
    GuardType.HUMAN_APPROVAL: ["LLM06"],
    GuardType.ALLOWLIST: ["LLM06"],
    GuardType.RATE_LIMIT: ["LLM10"],
    GuardType.TOKEN_LIMIT: ["LLM10"],
}


# ════════════════════════════════════════════════════════════════════════════════
# ANALYZER
# ════════════════════════════════════════════════════════════════════════════════

class AIReachabilityAnalyzer:
    """
    Analyzes AI/LLM code for data flow reachability.
    
    Determines whether untrusted input can reach LLM calls
    and what guards exist on the path.
    
    Can integrate with REACHABLE's call graph for cross-function analysis.
    """
    
    def __init__(
        self, 
        call_graph: Optional[Dict] = None,
        reachable_functions: Optional[Set[str]] = None,
        entrypoints: Optional[Set[str]] = None,
    ):
        """
        Initialize analyzer.
        
        Args:
            call_graph: Application call graph from REACHABLE's reachability analysis
            reachable_functions: Set of functions reachable from entrypoints
            entrypoints: Application entry points (HTTP handlers, main, etc.)
        """
        self.call_graph = call_graph or {}
        self.reachable_functions = reachable_functions or set()
        self.entrypoints = entrypoints or set()
        
        self.flows: List[DataFlow] = []
        self.sources: List[TaintSource] = []
        self.sinks: List[TaintSink] = []
        self.guards: List[TaintGuard] = []
    
    def analyze_file(self, file_path: Path) -> AIReachabilityResult:
        """Analyze a single file for AI data flows."""
        result = AIReachabilityResult(file_path=str(file_path))
        
        try:
            content = file_path.read_text(encoding='utf-8', errors='ignore')
            lines = content.split('\n')
        except Exception as e:
            logger.debug(f"Could not read {file_path}: {e}")
            return result
        
        # Determine language
        ext = file_path.suffix.lower()
        is_typescript = ext in ['.ts', '.js', '.tsx', '.jsx']
        
        # Find sources, sinks, guards
        sources = self._find_sources(lines, file_path, is_typescript)
        result.sources_found = len(sources)
        
        sinks = self._find_sinks(lines, file_path, is_typescript)
        result.sinks_found = len(sinks)
        
        guards = self._find_guards(lines, file_path, is_typescript)
        for g in guards:
            result.guards_detected.add(g.guard_type.value)
        
        # Build flows
        flows = self._build_flows(sources, sinks, guards, lines, file_path)
        result.flows = flows
        
        # Categorize flows
        for flow in flows:
            if flow.guards:
                result.guarded_flows += 1
            else:
                result.unguarded_flows += 1
            
            # Count by OWASP LLM category
            if flow.owasp_llm == "LLM01":
                result.llm01_flows += 1
            elif flow.owasp_llm == "LLM05":
                result.llm05_flows += 1
            elif flow.owasp_llm == "LLM06":
                result.llm06_flows += 1
            elif flow.owasp_llm == "LLM07":
                result.llm07_flows += 1
        
        return result
    
    def analyze_directory(
        self, 
        dir_path: Path, 
        extensions: List[str] = None
    ) -> List[AIReachabilityResult]:
        """Analyze all files in a directory."""
        if extensions is None:
            extensions = ['.py', '.js', '.ts', '.tsx', '.jsx', '.go']
        
        results = []
        for ext in extensions:
            for file_path in dir_path.rglob(f'*{ext}'):
                # Skip common non-source directories
                path_str = str(file_path)
                if any(skip in path_str for skip in [
                    '.venv', 'node_modules', '__pycache__', '.git', 'dist', 'build'
                ]):
                    continue
                
                result = self.analyze_file(file_path)
                if result.flows or result.sources_found > 0 or result.sinks_found > 0:
                    results.append(result)
        
        return results
    
    def _find_sources(
        self, 
        lines: List[str], 
        file_path: Path,
        is_typescript: bool = False
    ) -> List[TaintSource]:
        """Find untrusted data sources in code."""
        sources = []
        patterns = TYPESCRIPT_SOURCES if is_typescript else PYTHON_SOURCES
        
        for line_num, line in enumerate(lines, 1):
            for source_type, pattern_list in patterns.items():
                for pattern in pattern_list:
                    if re.search(pattern, line):
                        var_match = re.search(r'(\w+)\s*=', line)
                        var_name = var_match.group(1) if var_match else "unknown"
                        
                        sources.append(TaintSource(
                            source_type=source_type,
                            location=f"{file_path}:{line_num}",
                            variable=var_name,
                        ))
                        break
        
        return sources
    
    def _find_sinks(
        self, 
        lines: List[str], 
        file_path: Path,
        is_typescript: bool = False
    ) -> List[TaintSink]:
        """Find dangerous sinks in code."""
        sinks = []
        patterns = TYPESCRIPT_SINKS if is_typescript else PYTHON_SINKS
        
        for line_num, line in enumerate(lines, 1):
            for sink_type, pattern_list in patterns.items():
                for pattern in pattern_list:
                    if re.search(pattern, line):
                        func_match = re.search(r'\.(\w+)\s*\(', line)
                        func_name = func_match.group(1) if func_match else "unknown"
                        
                        sinks.append(TaintSink(
                            sink_type=sink_type,
                            location=f"{file_path}:{line_num}",
                            function=func_name,
                            argument="content",
                            owasp_llm=SINK_TO_OWASP_LLM.get(sink_type, ""),
                        ))
                        break
        
        return sinks
    
    def _find_guards(
        self, 
        lines: List[str], 
        file_path: Path,
        is_typescript: bool = False
    ) -> List[TaintGuard]:
        """Find guards/sanitizers in code."""
        guards = []
        patterns = TYPESCRIPT_GUARDS if is_typescript else PYTHON_GUARDS
        
        for line_num, line in enumerate(lines, 1):
            for guard_type, pattern_list in patterns.items():
                for pattern, effectiveness in pattern_list:
                    if re.search(pattern, line, re.IGNORECASE):
                        guards.append(TaintGuard(
                            guard_type=guard_type,
                            location=f"{file_path}:{line_num}",
                            effectiveness=effectiveness,
                            owasp_llm=GUARD_TO_OWASP_LLM.get(guard_type, []),
                        ))
                        break
        
        return guards
    
    def _build_flows(
        self,
        sources: List[TaintSource],
        sinks: List[TaintSink],
        guards: List[TaintGuard],
        lines: List[str],
        file_path: Path
    ) -> List[DataFlow]:
        """Build data flow connections between sources and sinks."""
        flows = []
        flow_id = 0
        
        for source in sources:
            source_line = int(source.location.split(':')[1])
            
            for sink in sinks:
                sink_line = int(sink.location.split(':')[1])
                
                # Heuristic: source before sink in same file (within reasonable distance)
                if source_line < sink_line and (sink_line - source_line) < 100:
                    # Find guards between source and sink
                    applicable_guards = []
                    for guard in guards:
                        guard_line = int(guard.location.split(':')[1])
                        if source_line < guard_line < sink_line:
                            applicable_guards.append(guard)
                    
                    # Calculate combined risk reduction
                    risk_reduction = 0.0
                    for g in applicable_guards:
                        risk_reduction = 1 - (1 - risk_reduction) * (1 - g.effectiveness)
                    risk_reduction = min(risk_reduction, 0.9)  # Cap at 90%
                    
                    # Determine flow type and OWASP category
                    if sink.sink_type in [SinkType.LLM_PROMPT, SinkType.LLM_SYSTEM]:
                        if source.source_type == SourceType.RAG_RETRIEVAL:
                            flow_type = FlowType.RAG_CONTENT
                        else:
                            flow_type = FlowType.PROMPT_INPUT
                        owasp = "LLM01"
                    elif sink.sink_type in [SinkType.CODE_EXEC, SinkType.SHELL_EXEC, SinkType.HTML_RENDER]:
                        flow_type = FlowType.PROMPT_OUTPUT
                        owasp = "LLM05"
                    elif sink.sink_type in [SinkType.TOOL_CALL, SinkType.MCP_TOOL]:
                        flow_type = FlowType.TOOL_INPUT
                        owasp = "LLM06"
                    else:
                        flow_type = FlowType.PROMPT_INPUT
                        owasp = sink.owasp_llm or "LLM01"
                    
                    # Check reachability from call graph if available
                    is_reachable = True
                    if self.reachable_functions:
                        # Simple check: see if any function in the file is reachable
                        is_reachable = any(
                            func in str(file_path) for func in self.reachable_functions
                        )
                    
                    flow_id += 1
                    flows.append(DataFlow(
                        flow_id=f"flow-{flow_id:03d}",
                        flow_type=flow_type,
                        source=source,
                        sink=sink,
                        guards=applicable_guards,
                        path=[source.variable, f"→ {sink.function}"],
                        is_reachable=is_reachable,
                        risk_reduction=risk_reduction,
                        owasp_llm=owasp,
                    ))
        
        return flows
    
    def get_reachability_for_finding(
        self,
        finding_location: str,
        results: List[AIReachabilityResult]
    ) -> Tuple[bool, float, List[str], str]:
        """
        Get reachability info for a specific finding location.
        
        Args:
            finding_location: "file:line" format
            results: List of analysis results
            
        Returns:
            (is_reachable, risk_reduction, guards_detected, owasp_llm)
        """
        file_path = finding_location.split(':')[0]
        finding_line = int(finding_location.split(':')[1]) if ':' in finding_location else 0
        
        for result in results:
            if result.file_path in file_path or file_path in result.file_path:
                # Find closest flow to this finding
                best_flow = None
                min_distance = float('inf')
                
                for flow in result.flows:
                    sink_line = int(flow.sink.location.split(':')[1])
                    distance = abs(sink_line - finding_line)
                    if distance < min_distance:
                        min_distance = distance
                        best_flow = flow
                
                if best_flow and min_distance < 10:  # Within 10 lines
                    return (
                        best_flow.is_reachable,
                        best_flow.risk_reduction,
                        [g.guard_type.value for g in best_flow.guards],
                        best_flow.owasp_llm,
                    )
                
                # File analyzed but no close flows - return file-level guards
                return (True, 0.0, list(result.guards_detected), "")
        
        # File not analyzed, assume reachable (conservative)
        return (True, 0.0, [], "")


# ════════════════════════════════════════════════════════════════════════════════
# HIGH-LEVEL INTEGRATION FUNCTIONS
# ════════════════════════════════════════════════════════════════════════════════

def analyze_ai_reachability(
    target_path: Path,
    call_graph: Optional[Dict] = None,
    reachable_functions: Optional[Set[str]] = None,
) -> Dict[str, Any]:
    """
    High-level function to analyze AI reachability in a codebase.
    
    Returns dict suitable for integration with risk scoring and correlation engine.
    """
    analyzer = AIReachabilityAnalyzer(
        call_graph=call_graph,
        reachable_functions=reachable_functions,
    )
    
    if target_path.is_file():
        results = [analyzer.analyze_file(target_path)]
    else:
        results = analyzer.analyze_directory(target_path)
    
    # Aggregate results
    total_flows = 0
    unguarded_flows = 0
    all_guards = set()
    owasp_counts = {"LLM01": 0, "LLM05": 0, "LLM06": 0, "LLM07": 0, "LLM10": 0}
    
    for result in results:
        total_flows += len(result.flows)
        unguarded_flows += result.unguarded_flows
        all_guards.update(result.guards_detected)
        owasp_counts["LLM01"] += result.llm01_flows
        owasp_counts["LLM05"] += result.llm05_flows
        owasp_counts["LLM06"] += result.llm06_flows
        owasp_counts["LLM07"] += result.llm07_flows
    
    return {
        "files_analyzed": len(results),
        "total_flows": total_flows,
        "unguarded_flows": unguarded_flows,
        "guarded_flows": total_flows - unguarded_flows,
        "guards_detected": list(all_guards),
        "owasp_llm_breakdown": owasp_counts,
        "results": results,
        "analyzer": analyzer,  # Keep reference for detailed queries
    }


def get_reachability_for_ai_finding(
    finding: Dict[str, Any],
    reachability_data: Dict[str, Any],
) -> Dict[str, Any]:
    """
    Get reachability context for an AI security finding.
    
    Args:
        finding: AI security finding dict (from scanner)
        reachability_data: Results from analyze_ai_reachability()
        
    Returns:
        Dict with is_reachable, risk_reduction, guards, owasp_llm
    """
    location = finding.get("file_path", "") + ":" + str(finding.get("line_start", 0))
    
    analyzer = reachability_data.get("analyzer")
    results = reachability_data.get("results", [])
    
    if analyzer:
        is_reachable, reduction, guards, owasp = analyzer.get_reachability_for_finding(
            location, results
        )
        return {
            "is_reachable": is_reachable,
            "risk_reduction": reduction,
            "guards": guards,
            "owasp_llm": owasp,
        }
    
    return {
        "is_reachable": True,
        "risk_reduction": 0.0,
        "guards": [],
        "owasp_llm": finding.get("owasp_category", ""),
    }


# ════════════════════════════════════════════════════════════════════════════════
# CLI ENTRY POINT
# ════════════════════════════════════════════════════════════════════════════════

if __name__ == "__main__":
    import sys
    
    if len(sys.argv) < 2:
        logger.info("Usage: python ai_reachability.py <path>")
        sys.exit(1)
    
    target = Path(sys.argv[1])
    results = analyze_ai_reachability(target)
    
    logger.info(f"\n🔍 AI Reachability Analysis: {target}")
    print("=" * 70)
    logger.info(f"📁 Files analyzed: {results['files_analyzed']}")
    logger.info(f"🔀 Total flows: {results['total_flows']}")
    logger.info(f"⚠️  Unguarded flows: {results['unguarded_flows']}")
    logger.info(f"🛡️  Guarded flows: {results['guarded_flows']}")
    logger.info(f"🔒 Guards detected: {', '.join(results['guards_detected']) or 'None'}")
    
    logger.info(f"\n📊 OWASP LLM Breakdown:")
    for cat, count in results['owasp_llm_breakdown'].items():
        if count > 0:
            logger.info(f"   {cat}: {count} flows")
    
    # Show critical flows (unguarded, reachable)
    critical = []
    for result in results['results']:
        for flow in result.flows:
            if flow.is_reachable and not flow.guards:
                critical.append((result.file_path, flow))
    
    if critical:
        logger.info(f"\n🚨 Critical Unguarded Flows ({len(critical)}):")
        for file_path, flow in critical[:10]:  # Show top 10
            logger.info(f"   {flow.owasp_llm}: {flow.source.variable} → {flow.sink.function}")
            logger.info(f"      {file_path}")
