#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.

"""
REACHABLE P6.12: AI Security Schema Extension
=============================================

Extends the REACHABLE output schema to include AI security findings.
This ensures AI findings are properly structured for:
- Dashboard display
- CI/CD integration (SARIF export)
- Risk scoring integration
- Compliance reporting

Schema Version: 2.0 (with AI extension)
"""

from dataclasses import dataclass, field, asdict
from datetime import datetime
from enum import Enum
from typing import Any, Dict, List, Optional
import json


class AISeverity(Enum):
    """AI finding severity levels."""
    CRITICAL = "CRITICAL"
    HIGH = "HIGH"
    MEDIUM = "MEDIUM"
    LOW = "LOW"
    INFO = "INFO"


class AICategory(Enum):
    """AI security categories based on OWASP LLM Top 10."""
    LLM01_PROMPT_INJECTION = "LLM01"
    LLM02_SENSITIVE_DISCLOSURE = "LLM02"
    LLM03_SUPPLY_CHAIN = "LLM03"
    LLM04_DATA_POISONING = "LLM04"
    LLM05_OUTPUT_HANDLING = "LLM05"
    LLM06_EXCESSIVE_AGENCY = "LLM06"
    LLM07_SYSTEM_PROMPT_LEAK = "LLM07"
    LLM08_VECTOR_EMBEDDING = "LLM08"
    LLM09_MISINFORMATION = "LLM09"
    LLM10_UNBOUNDED_CONSUMPTION = "LLM10"
    MCP_SECURITY = "MCP"
    MODEL_CONTROLS = "CONTROLS"
    OTHER = "OTHER"


@dataclass
class AIFindingLocation:
    """Location of an AI security finding."""
    file: str
    line_start: int
    line_end: int
    column_start: Optional[int] = None
    column_end: Optional[int] = None
    snippet: Optional[str] = None


@dataclass
class AIFindingMetadata:
    """Metadata for an AI security finding."""
    policy_id: str                      # AI-001 through AI-010
    owasp_llm: str                      # LLM01 through LLM10
    cwe: str                            # CWE-77, CWE-79, etc.
    source: str                         # custom, garak, corpus
    confidence: str = "medium"          # high, medium, low
    source_dataset: Optional[str] = None  # tensortrust, jailbreakbench, etc.
    source_probe: Optional[str] = None    # dan, promptinject, etc.


@dataclass
class AIFinding:
    """
    A single AI security finding.
    
    Extends the base REACHABLE finding schema with AI-specific fields.
    """
    # Core fields
    id: str                             # Unique finding ID
    rule_id: str                        # Rule that triggered (e.g., garak-dan-001)
    message: str                        # Human-readable description
    severity: str                       # CRITICAL, HIGH, MEDIUM, LOW, INFO
    
    # Location
    location: AIFindingLocation
    
    # AI-specific
    category: str                       # OWASP LLM category
    metadata: AIFindingMetadata
    
    # Reachability (from P6.8)
    is_reachable: bool = True
    guards_detected: List[str] = field(default_factory=list)
    risk_reduction: float = 0.0
    
    # Risk scoring (from P6.18)
    base_score: int = 0
    adjusted_score: int = 0
    
    # Remediation
    remediation: Optional[str] = None
    references: List[str] = field(default_factory=list)
    
    def to_dict(self) -> Dict:
        """Convert to dictionary for JSON serialization."""
        return {
            "id": self.id,
            "rule_id": self.rule_id,
            "message": self.message,
            "severity": self.severity,
            "location": {
                "file": self.location.file,
                "line_start": self.location.line_start,
                "line_end": self.location.line_end,
                "column_start": self.location.column_start,
                "column_end": self.location.column_end,
                "snippet": self.location.snippet,
            },
            "category": self.category,
            "metadata": {
                "policy_id": self.metadata.policy_id,
                "owasp_llm": self.metadata.owasp_llm,
                "cwe": self.metadata.cwe,
                "source": self.metadata.source,
                "confidence": self.metadata.confidence,
                "source_dataset": self.metadata.source_dataset,
                "source_probe": self.metadata.source_probe,
            },
            "is_reachable": self.is_reachable,
            "guards_detected": self.guards_detected,
            "risk_reduction": self.risk_reduction,
            "base_score": self.base_score,
            "adjusted_score": self.adjusted_score,
            "remediation": self.remediation,
            "references": self.references,
        }
    
    def to_sarif(self) -> Dict:
        """Convert to SARIF result format."""
        return {
            "ruleId": self.rule_id,
            "level": self._severity_to_sarif_level(),
            "message": {
                "text": self.message
            },
            "locations": [{
                "physicalLocation": {
                    "artifactLocation": {
                        "uri": self.location.file
                    },
                    "region": {
                        "startLine": self.location.line_start,
                        "endLine": self.location.line_end,
                        "startColumn": self.location.column_start,
                        "endColumn": self.location.column_end,
                    }
                }
            }],
            "properties": {
                "policy_id": self.metadata.policy_id,
                "owasp_llm": self.metadata.owasp_llm,
                "cwe": self.metadata.cwe,
                "is_reachable": self.is_reachable,
                "risk_score": self.adjusted_score,
            }
        }
    
    def _severity_to_sarif_level(self) -> str:
        """Convert severity to SARIF level."""
        mapping = {
            "CRITICAL": "error",
            "HIGH": "error",
            "MEDIUM": "warning",
            "LOW": "note",
            "INFO": "note",
        }
        return mapping.get(self.severity.upper(), "note")


@dataclass
class AISecuritySummary:
    """Summary of AI security findings."""
    total_findings: int = 0
    
    # By severity
    critical: int = 0
    high: int = 0
    medium: int = 0
    low: int = 0
    info: int = 0
    
    # By OWASP LLM category
    by_category: Dict[str, int] = field(default_factory=dict)
    
    # By policy
    by_policy: Dict[str, int] = field(default_factory=dict)
    
    # Reachability stats
    reachable_findings: int = 0
    unreachable_findings: int = 0
    guarded_findings: int = 0
    
    # Risk score
    total_risk_score: int = 0
    adjusted_risk_score: int = 0
    
    # Guards detected across codebase
    guards_detected: List[str] = field(default_factory=list)
    
    def to_dict(self) -> Dict:
        """Convert to dictionary."""
        return {
            "total_findings": self.total_findings,
            "by_severity": {
                "CRITICAL": self.critical,
                "HIGH": self.high,
                "MEDIUM": self.medium,
                "LOW": self.low,
                "INFO": self.info,
            },
            "by_category": self.by_category,
            "by_policy": self.by_policy,
            "reachability": {
                "reachable": self.reachable_findings,
                "unreachable": self.unreachable_findings,
                "guarded": self.guarded_findings,
            },
            "risk_score": {
                "total": self.total_risk_score,
                "adjusted": self.adjusted_risk_score,
            },
            "guards_detected": self.guards_detected,
        }


@dataclass
class AISecurityReport:
    """
    Complete AI security report.
    
    This is the top-level schema for AI security output.
    """
    # Report metadata
    schema_version: str = "2.0"
    generated_at: str = field(default_factory=lambda: datetime.now().isoformat())
    scan_target: str = ""
    scan_duration_ms: int = 0
    
    # Summary
    summary: AISecuritySummary = field(default_factory=AISecuritySummary)
    
    # Findings
    findings: List[AIFinding] = field(default_factory=list)
    
    # Rule metadata (for SARIF)
    rules_used: List[Dict] = field(default_factory=list)
    
    def add_finding(self, finding: AIFinding):
        """Add a finding and update summary."""
        self.findings.append(finding)
        self.summary.total_findings += 1
        
        # Update severity counts
        sev = finding.severity.upper()
        if sev == "CRITICAL":
            self.summary.critical += 1
        elif sev == "HIGH":
            self.summary.high += 1
        elif sev == "MEDIUM":
            self.summary.medium += 1
        elif sev == "LOW":
            self.summary.low += 1
        else:
            self.summary.info += 1
        
        # Update category counts
        cat = finding.category
        self.summary.by_category[cat] = self.summary.by_category.get(cat, 0) + 1
        
        # Update policy counts
        policy = finding.metadata.policy_id
        self.summary.by_policy[policy] = self.summary.by_policy.get(policy, 0) + 1
        
        # Update reachability stats
        if finding.is_reachable:
            self.summary.reachable_findings += 1
        else:
            self.summary.unreachable_findings += 1
        
        if finding.guards_detected:
            self.summary.guarded_findings += 1
            for guard in finding.guards_detected:
                if guard not in self.summary.guards_detected:
                    self.summary.guards_detected.append(guard)
        
        # Update risk scores
        self.summary.total_risk_score += finding.base_score
        self.summary.adjusted_risk_score += finding.adjusted_score
    
    def to_dict(self) -> Dict:
        """Convert to dictionary for JSON serialization."""
        return {
            "schema_version": self.schema_version,
            "generated_at": self.generated_at,
            "scan_target": self.scan_target,
            "scan_duration_ms": self.scan_duration_ms,
            "summary": self.summary.to_dict(),
            "findings": [f.to_dict() for f in self.findings],
            "rules_used": self.rules_used,
        }
    
    def to_json(self, indent: int = 2) -> str:
        """Convert to JSON string."""
        return json.dumps(self.to_dict(), indent=indent)
    
    def to_sarif(self) -> Dict:
        """
        Convert to SARIF 2.1.0 format for CI/CD integration.
        
        SARIF (Static Analysis Results Interchange Format) is the
        standard format for security tool output in GitHub, GitLab, etc.
        
        Output filename convention: ai-security.sarif
        """
        return {
            "$schema": "https://raw.githubusercontent.com/oasis-tcs/sarif-spec/master/Schemata/sarif-schema-2.1.0.json",
            "version": "2.1.0",
            "runs": [{
                "tool": {
                    "driver": {
                        "name": "REACHABLE AI Security",
                        "version": self.schema_version,
                        "informationUri": "https://docs.reachable.dev",
                        "rules": self._get_sarif_rules(),
                    }
                },
                "results": [f.to_sarif() for f in self.findings],
                "invocations": [{
                    "executionSuccessful": True,
                    "endTimeUtc": self.generated_at,
                }]
            }]
        }
    
    def _get_sarif_rules(self) -> List[Dict]:
        """Get SARIF rule definitions for all rules used."""
        rules = {}
        
        for finding in self.findings:
            if finding.rule_id not in rules:
                rules[finding.rule_id] = {
                    "id": finding.rule_id,
                    "name": finding.rule_id,
                    "shortDescription": {
                        "text": finding.message[:100]
                    },
                    "fullDescription": {
                        "text": finding.message
                    },
                    "helpUri": f"https://docs.reachable.dev/rules/{finding.rule_id}",
                    "properties": {
                        "policy_id": finding.metadata.policy_id,
                        "owasp_llm": finding.metadata.owasp_llm,
                        "cwe": finding.metadata.cwe,
                    }
                }
        
        return list(rules.values())
    
    def save(self, path: str = None, format: str = "json"):
        """
        Save report to file.
        
        Args:
            path: Output file path. Defaults to:
                  - ai-security.json (JSON format)
                  - ai-security.sarif (SARIF format)
            format: Output format (json, sarif)
        
        Output Files:
            ai-security.json  - Full AI security report
            ai-security.sarif - SARIF format for CI/CD (GitHub, GitLab)
        """
        # Default filenames
        if path is None:
            path = "ai-security.sarif" if format == "sarif" else "ai-security.json"
        
        if format == "sarif":
            content = json.dumps(self.to_sarif(), indent=2)
        else:
            content = self.to_json()
        
        with open(path, 'w') as f:
            f.write(content)
        
        return path


# ════════════════════════════════════════════════════════════════════════════════
# CONVERSION UTILITIES
# ════════════════════════════════════════════════════════════════════════════════

def semgrep_to_ai_finding(semgrep_result: Dict, rule_metadata: Dict = None) -> AIFinding:
    """
    Convert a Semgrep result to an AIFinding.
    
    Args:
        semgrep_result: Single result from Semgrep JSON output
        rule_metadata: Optional additional metadata
        
    Returns:
        AIFinding instance
    """
    # Extract location
    location = AIFindingLocation(
        file=semgrep_result.get("path", ""),
        line_start=semgrep_result.get("start", {}).get("line", 0),
        line_end=semgrep_result.get("end", {}).get("line", 0),
        column_start=semgrep_result.get("start", {}).get("col"),
        column_end=semgrep_result.get("end", {}).get("col"),
        snippet=semgrep_result.get("extra", {}).get("lines"),
    )
    
    # Extract metadata from rule
    extra = semgrep_result.get("extra", {})
    meta = extra.get("metadata", {})
    
    metadata = AIFindingMetadata(
        policy_id=meta.get("policy_id", "AI-001"),
        owasp_llm=meta.get("owasp_llm", meta.get("owasp", "LLM01")),
        cwe=meta.get("cwe", "CWE-77"),
        source=meta.get("source", "custom"),
        confidence=meta.get("confidence", "medium"),
        source_dataset=meta.get("source_dataset"),
        source_probe=meta.get("source_probe"),
    )
    
    # Map severity
    severity = extra.get("severity", "WARNING").upper()
    if severity == "ERROR":
        severity = "HIGH"
    elif severity == "WARNING":
        severity = "MEDIUM"
    
    # Create finding
    rule_id = semgrep_result.get("check_id", "unknown")
    
    return AIFinding(
        id=f"{rule_id}-{location.line_start}",
        rule_id=rule_id,
        message=extra.get("message", "AI security issue detected"),
        severity=severity,
        location=location,
        category=metadata.owasp_llm,
        metadata=metadata,
        remediation=meta.get("remediation"),
        references=meta.get("references", []),
    )


def create_ai_report_from_semgrep(
    semgrep_output: Dict,
    scan_target: str = "",
    scan_duration_ms: int = 0
) -> AISecurityReport:
    """
    Create an AISecurityReport from Semgrep JSON output.
    
    Args:
        semgrep_output: Complete Semgrep JSON output
        scan_target: Path that was scanned
        scan_duration_ms: Scan duration
        
    Returns:
        AISecurityReport instance
    """
    report = AISecurityReport(
        scan_target=scan_target,
        scan_duration_ms=scan_duration_ms,
    )
    
    results = semgrep_output.get("results", [])
    
    for result in results:
        # Only include AI-related rules
        rule_id = result.get("check_id", "")
        if any(prefix in rule_id.lower() for prefix in [
            "llm", "ai-", "garak-", "corpus-", "mcp-", "prompt", "injection"
        ]):
            finding = semgrep_to_ai_finding(result)
            report.add_finding(finding)
    
    return report


# ════════════════════════════════════════════════════════════════════════════════
# INTEGRATION WITH MAIN REACHABLE OUTPUT
# ════════════════════════════════════════════════════════════════════════════════

def extend_reachable_output(base_output: Dict, ai_report: AISecurityReport) -> Dict:
    """
    Extend the base REACHABLE output with AI security data.
    
    Args:
        base_output: Existing REACHABLE scan output
        ai_report: AI security report
        
    Returns:
        Extended output with ai_security section
    """
    # Add AI security section
    base_output["ai_security"] = {
        "enabled": True,
        "schema_version": ai_report.schema_version,
        "summary": ai_report.summary.to_dict(),
        "findings": [f.to_dict() for f in ai_report.findings],
    }
    
    # Update overall risk score if present
    if "risk_score" in base_output:
        base_output["risk_score"]["ai_contribution"] = ai_report.summary.adjusted_risk_score
    
    return base_output


# ════════════════════════════════════════════════════════════════════════════════
# SCHEMA DOCUMENTATION
# ════════════════════════════════════════════════════════════════════════════════

SCHEMA_DOCS = """
REACHABLE AI Security Schema v2.0
=================================

Output Files:
- ai-security.json  : Full AI security report (default)
- ai-security.sarif : SARIF 2.1.0 format for CI/CD integration (GitHub, GitLab, Azure DevOps)

These files are generated in the scan output directory alongside other REACHABLE outputs.

Top-Level Structure:
{
  "schema_version": "2.0",
  "generated_at": "ISO-8601 timestamp",
  "scan_target": "/path/to/code",
  "scan_duration_ms": 1234,
  
  "summary": {
    "total_findings": 15,
    "by_severity": {"CRITICAL": 2, "HIGH": 5, ...},
    "by_category": {"LLM01": 8, "LLM05": 3, ...},
    "by_policy": {"AI-001": 10, "AI-005": 5, ...},
    "reachability": {
      "reachable": 12,
      "unreachable": 3,
      "guarded": 5
    },
    "risk_score": {
      "total": 450,
      "adjusted": 280
    },
    "guards_detected": ["input_validation", "injection_detect"]
  },
  
  "findings": [
    {
      "id": "garak-dan-001-42",
      "rule_id": "garak-dan-001",
      "message": "DAN jailbreak pattern detected",
      "severity": "HIGH",
      "location": {
        "file": "app/chat.py",
        "line_start": 42,
        "line_end": 45,
        "snippet": "you are now DAN..."
      },
      "category": "LLM01",
      "metadata": {
        "policy_id": "AI-001",
        "owasp_llm": "LLM01",
        "cwe": "CWE-77",
        "source": "garak",
        "source_probe": "dan"
      },
      "is_reachable": true,
      "guards_detected": [],
      "risk_reduction": 0.0,
      "base_score": 150,
      "adjusted_score": 150,
      "remediation": "Add input validation with injection detection",
      "references": ["https://owasp.org/www-project-top-10-for-large-language-model-applications/"]
    }
  ]
}

Policy IDs:
- AI-001: Direct prompt injection
- AI-002: Indirect prompt injection (RAG)
- AI-003: Sensitive data disclosure
- AI-004: AI supply chain
- AI-005: Improper output handling
- AI-006: Excessive agency
- AI-007: System prompt leakage
- AI-008: Unbounded consumption
- AI-009: MCP tool security
- AI-010: Model control bypass

OWASP LLM Categories:
- LLM01: Prompt Injection
- LLM02: Sensitive Information Disclosure
- LLM03: Supply Chain Vulnerabilities
- LLM04: Data and Model Poisoning
- LLM05: Improper Output Handling
- LLM06: Excessive Agency
- LLM07: System Prompt Leakage
- LLM08: Vector and Embedding Weaknesses
- LLM09: Misinformation
- LLM10: Unbounded Consumption
"""


if __name__ == "__main__":
    # Example usage
    print(SCHEMA_DOCS)
