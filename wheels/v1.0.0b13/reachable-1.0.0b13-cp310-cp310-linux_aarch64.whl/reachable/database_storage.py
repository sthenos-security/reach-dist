#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.

"""
REACHABLE v5.0.0 - Database Storage Module with v1.0 Schema

Per-repo database architecture as specified in DESIGN_v4.4.0.md:
- ONE repo.db per repository (not per-scan)
- Historical scan tracking via scans table
- Cache tables for SBOM and call graphs
- Automatic retention management
- Eliminates redundant raw/ directory
"""

import sqlite3
import json
import gzip
import hashlib
from pathlib import Path
from typing import Dict, Any, List, Optional, Tuple
from datetime import datetime, timedelta
import time
import logging

# v1.0: Collision detection and fingerprints
try:
    from .collision_detector import CollisionDetector
except ImportError:
    CollisionDetector = None  # Fallback if not available

logger = logging.getLogger(__name__)

class RepoDatabase:
    """
    v5.0.0: Per-repository database with v1.0 production schema
    
    v1.0 Changes:
    - Instance-level fingerprints (not global dedup)
    - Collision detection with 50-attempt resolution  
    - UNIQUE(scan_id, finding_id) only
    - type_detail column for performance
    - scan_audit table for data loss detection
    - ON CONFLICT DO UPDATE (not INSERT OR REPLACE)
    
    Structure:
        ~/.reachable/scans/{repo-hash}/repo.db
        
    Contains:
        - scans: Historical scan metadata
        - findings: All findings with scan_id FK
        - scan_audit: Data loss tracking (v1.0)
        - sbom_cache: Cached SBOMs by commit
        - call_graph_cache: Cached call graphs
        - large_objects: Compressed blobs (reports, correlation)
    """
    
    # Version
    VERSION = "5.0.0"
    SCHEMA_VERSION = "1.0"
    
    # Retention settings
    MAX_SCANS_PER_BRANCH = 20  # Reduced from 30
    MAX_SCAN_AGE_DAYS = 21     # Reduced from 30
    COMPRESS_AFTER_DAYS = 14   # Compress dashboards after 2 weeks
    
    def __init__(self, db_path: Path):
        """Initialize per-repo database"""
        self.db_path = Path(db_path)
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        
        # Secure the .reachable directory (contains sensitive scan data)
        reachable_home = Path.home() / '.reachable'
        if reachable_home.exists():
            try:
                reachable_home.chmod(0o700)  # Owner only
            except OSError:
                pass  # May fail on some filesystems
        
        self.conn = None
        self._current_scan_id = None
        self._initialize_database()
    
    def _initialize_database(self):
        """Create v5.0.0 schema with v1.0 production schema"""
        self.conn = sqlite3.connect(str(self.db_path))
        self.conn.row_factory = sqlite3.Row  # Enable dict-like access
        
        # Secure the database file (contains sensitive security data)
        try:
            self.db_path.chmod(0o600)  # Owner read/write only
        except OSError:
            pass  # May fail on some filesystems
        
        # Performance optimizations
        self.conn.execute("PRAGMA journal_mode=WAL")
        self.conn.execute("PRAGMA synchronous=NORMAL")
        self.conn.execute("PRAGMA cache_size=10000")
        self.conn.execute("PRAGMA temp_store=MEMORY")
        
        # Create schema
        self.conn.executescript("""
            -- ===========================================
            -- SCANS TABLE: Historical scan tracking
            -- ===========================================
            CREATE TABLE IF NOT EXISTS scans (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                branch TEXT NOT NULL,
                commit_hash TEXT,
                commit_short TEXT,
                scan_dir TEXT,                    -- Path to scan session directory
                timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
                duration_seconds REAL,
                version TEXT,                     -- REACHABLE version
                
                -- Summary stats
                total_findings INTEGER DEFAULT 0,
                reachable_findings INTEGER DEFAULT 0,
                critical_count INTEGER DEFAULT 0,
                high_count INTEGER DEFAULT 0,
                medium_count INTEGER DEFAULT 0,
                low_count INTEGER DEFAULT 0,
                
                -- Analysis coverage
                source_files_scanned INTEGER DEFAULT 0,  -- Number of source files analyzed
                
                -- Risk
                risk_score INTEGER DEFAULT 0,
                risk_level TEXT,                  -- 'CRITICAL', 'HIGH', 'MEDIUM', 'LOW'
                config_count INTEGER DEFAULT 0,   -- Config issues (not in risk score)
                unknown_count INTEGER DEFAULT 0,   -- Unknown reachability count
                
                -- Status
                status TEXT DEFAULT 'running'     -- 'running', 'complete', 'failed'
            );
            
            -- ===========================================
            -- FINDINGS TABLE: All finding types
            -- ===========================================
            CREATE TABLE IF NOT EXISTS findings (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                scan_id INTEGER NOT NULL REFERENCES scans(id) ON DELETE CASCADE,
                
                -- Finding identification (v1.0: fingerprint-based)
                finding_type TEXT NOT NULL,       -- 'cve', 'cwe', 'config', 'secret', 'malware', 'suspicious'
                finding_id TEXT NOT NULL,         -- v1.0: Instance fingerprint (16-char hex)
                type_detail TEXT,                 -- v1.0: Denormalized {type}:{subtype} for COALESCE queries
                
                -- Severity/Risk
                severity TEXT,                    -- 'CRITICAL', 'HIGH', 'MEDIUM', 'LOW', 'INFO'
                risk_level TEXT,                  -- After all adjustments
                cvss_score REAL,
                
                -- Reachability (two-dimensional per design doc)
                app_reachability TEXT DEFAULT 'UNKNOWN',        -- 'REACHABLE', 'NOT_REACHABLE', 'UNKNOWN'
                app_reachability_confidence TEXT DEFAULT 'LOW', -- 'HIGH', 'MEDIUM', 'LOW'
                app_reachability_path TEXT,                     -- JSON array of function names
                platform_exposure TEXT DEFAULT 'UNKNOWN',       -- 'EXPOSED', 'MITIGATED', 'UNKNOWN'
                
                -- Fix availability (CVEs)
                fix_status TEXT,                  -- 'no_fix', 'fix_available', 'wont_fix'
                fix_version TEXT,
                
                -- Location
                file_path TEXT,
                line_number INTEGER,
                
                -- Package info
                package_name TEXT,
                package_version TEXT,
                
                -- Details
                title TEXT,
                description TEXT,
                cwe_id TEXT,
                secret_type TEXT,
                
                -- Malware evidence (JSON blobs)
                evidence_static TEXT,             -- GuardDog/Semgrep findings
                evidence_dynamic TEXT,            -- Sandbox findings
                
                -- Compliance
                compliance_mapping TEXT,          -- JSON: {framework: [controls]}
                
                -- Metadata
                scanner TEXT,
                raw_data TEXT,                    -- Full original finding as JSON
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            );
            
            -- ===========================================
            -- SBOM CACHE: Reuse across scans
            -- ===========================================
            CREATE TABLE IF NOT EXISTS sbom_cache (
                commit_hash TEXT PRIMARY KEY,
                sbom_format TEXT DEFAULT 'cyclonedx',
                sbom_data BLOB,                   -- gzip compressed
                package_count INTEGER,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            );
            
            -- ===========================================
            -- CALL GRAPH CACHE: Reuse if source unchanged
            -- ===========================================
            CREATE TABLE IF NOT EXISTS call_graph_cache (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                commit_hash TEXT NOT NULL,
                source_hash TEXT NOT NULL,        -- Hash of source files
                graph_data BLOB,                  -- gzip compressed
                function_count INTEGER,
                edge_count INTEGER,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                UNIQUE(commit_hash, source_hash)
            );
            
            -- ===========================================
            -- LARGE OBJECTS: Compressed blob storage
            -- ===========================================
            CREATE TABLE IF NOT EXISTS large_objects (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                scan_id INTEGER REFERENCES scans(id) ON DELETE CASCADE,
                object_type TEXT NOT NULL,        -- 'report', 'correlation', 'vulns'
                compression TEXT DEFAULT 'gzip',
                size_original INTEGER,
                size_compressed INTEGER,
                data BLOB,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                UNIQUE(scan_id, object_type)
            );
            
            -- ===========================================
            -- METRICS: Timing and performance data
            -- ===========================================
            CREATE TABLE IF NOT EXISTS metrics (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                scan_id INTEGER REFERENCES scans(id) ON DELETE CASCADE,
                metric_type TEXT,
                metric_name TEXT,
                metric_value REAL,
                metadata TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            );
            
            -- ===========================================
            -- AI SECURITY FINDINGS (OWASP LLM Top 10)
            -- ===========================================
            CREATE TABLE IF NOT EXISTS ai_findings (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                scan_id INTEGER NOT NULL REFERENCES scans(id) ON DELETE CASCADE,
                
                -- Finding identification
                rule_id TEXT,
                policy_id TEXT,
                
                -- OWASP LLM classification
                owasp_category TEXT,              -- 'LLM01', 'LLM02', ..., 'LLM10', 'MCP', 'CONTROLS'
                owasp_name TEXT,                  -- 'Prompt Injection', 'Sensitive Information Disclosure', etc.
                
                -- Severity/Risk
                severity TEXT,                    -- 'ERROR', 'WARNING', 'INFO'
                base_risk_score REAL,
                adjusted_risk_score REAL,
                
                -- Reachability
                is_reachable BOOLEAN DEFAULT 1,
                call_path TEXT,                   -- JSON array
                
                -- Guards/Mitigations
                guards TEXT,                      -- JSON array: ['input_validation', 'injection_detect']
                guard_risk_reduction REAL,        -- 0.0 to 1.0
                
                -- Location
                file_path TEXT,
                line_start INTEGER,
                line_end INTEGER,
                
                -- Context
                message TEXT,
                cwe_id TEXT,
                framework TEXT,                   -- 'langchain', 'openai', 'anthropic', etc.
                provider TEXT,                    -- 'openai', 'anthropic', 'azure', etc.
                
                -- Metadata
                detection_source TEXT,            -- 'semgrep', 'taint', 'ast'
                raw_data TEXT,                    -- Full finding as JSON
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            );
            
            -- ===========================================
            -- DLP SECURITY FINDINGS (Data Loss Prevention)
            -- ===========================================
            CREATE TABLE IF NOT EXISTS dlp_findings (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                scan_id INTEGER NOT NULL REFERENCES scans(id) ON DELETE CASCADE,
                
                -- Finding identification
                rule_id TEXT,
                finding_type TEXT,                -- 'pii_discovery', 'pii_taint', 'pii_ai'
                
                -- PII classification
                pii_type TEXT,                    -- 'ssn', 'credit_card', 'email', etc.
                pii_sample TEXT,                  -- Redacted sample
                pii_count INTEGER DEFAULT 1,
                
                -- Sink info (for taint flows)
                sink_type TEXT,                   -- 'log', 'llm_api', 'external_api', etc.
                sink_function TEXT,               -- Function name
                
                -- Severity/Risk
                severity TEXT,                    -- 'CRITICAL', 'HIGH', 'MEDIUM', 'LOW'
                base_risk_score REAL,
                adjusted_risk_score REAL,
                
                -- File classification
                file_class TEXT,                  -- 'source', 'fixture', 'data_artifact'
                file_class_modifier REAL,         -- Risk modifier (0.1 - 1.2)
                
                -- Reachability
                is_reachable BOOLEAN DEFAULT 1,
                reachability_confidence TEXT DEFAULT 'LOW',
                call_path TEXT,                   -- JSON array
                
                -- Sanitization
                sanitizer_present BOOLEAN DEFAULT 0,
                sanitizer_type TEXT,
                sanitizer_effectiveness REAL,     -- 0.0 to 1.0
                
                -- Compliance
                regulations TEXT,                 -- JSON array: ['GDPR', 'HIPAA', 'PCI-DSS']
                
                -- Location
                file_path TEXT,
                line_start INTEGER,
                line_end INTEGER,
                
                -- Context
                message TEXT,
                remediation TEXT,
                detection_source TEXT,            -- 'pattern', 'taint', 'semgrep'
                confidence REAL,                  -- 0.0 to 1.0
                
                -- Metadata
                raw_data TEXT,                    -- Full finding as JSON
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            );
            
            -- ===========================================
            -- SCAN AUDIT: Data loss detection (v1.0)
            -- ===========================================
            CREATE TABLE IF NOT EXISTS scan_audit (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                scan_id INTEGER NOT NULL REFERENCES scans(id) ON DELETE CASCADE,
                finding_type TEXT NOT NULL,
                cli_count INTEGER NOT NULL,       -- Count from CLI output
                db_count INTEGER NOT NULL,        -- Count actually stored in DB
                loss_count INTEGER NOT NULL,      -- Difference (CLI - DB)
                loss_percentage REAL NOT NULL,    -- (loss_count / cli_count) * 100
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            );
            
            CREATE INDEX IF NOT EXISTS idx_scan_audit_scan ON scan_audit(scan_id);
            CREATE INDEX IF NOT EXISTS idx_scan_audit_type ON scan_audit(finding_type);
            
            -- ===========================================
            -- INDEXES
            -- ===========================================
            CREATE INDEX IF NOT EXISTS idx_scans_branch ON scans(branch);
            CREATE INDEX IF NOT EXISTS idx_scans_timestamp ON scans(timestamp);
        """)
        
        # Migration: add config_count if missing
        try:
            self.conn.execute("ALTER TABLE scans ADD COLUMN config_count INTEGER DEFAULT 0")
        except:
            pass
        try:
            self.conn.execute("ALTER TABLE scans ADD COLUMN unknown_count INTEGER DEFAULT 0")
        except:
            pass  # Column exists
        
        # P2.21: Migration - add CVE/GHSA display fields
        try:
            self.conn.execute("ALTER TABLE findings ADD COLUMN ghsa_id TEXT")
        except:
            pass  # Column exists
        try:
            self.conn.execute("ALTER TABLE findings ADD COLUMN display_id TEXT")
        except:
            pass  # Column exists
        try:
            self.conn.execute("ALTER TABLE findings ADD COLUMN id_note TEXT")
        except:
            pass  # Column exists
        
        # v1.0: UNIQUE constraint on (scan_id, finding_id) only
        # This allows same finding_id across finding_types (e.g., CWE-79 as both cwe and secret)
        # Per-scan uniqueness ensures instance-level deduplication
        try:
            self.conn.execute("""
                CREATE UNIQUE INDEX IF NOT EXISTS idx_findings_unique_v1 
                ON findings(scan_id, finding_id)
            """)
        except:
            pass  # Index might exist
        
        # Drop old index if it exists (migration)
        try:
            self.conn.execute("DROP INDEX IF EXISTS idx_findings_unique")
        except:
            pass
        
        self.conn.executescript("""
            CREATE INDEX IF NOT EXISTS idx_findings_scan ON findings(scan_id);
            CREATE INDEX IF NOT EXISTS idx_findings_type ON findings(finding_type);
            CREATE INDEX IF NOT EXISTS idx_findings_severity ON findings(severity);
            CREATE INDEX IF NOT EXISTS idx_findings_reachability ON findings(app_reachability);
            CREATE INDEX IF NOT EXISTS idx_findings_package ON findings(package_name);
            CREATE INDEX IF NOT EXISTS idx_sbom_commit ON sbom_cache(commit_hash);
            CREATE INDEX IF NOT EXISTS idx_callgraph_commit ON call_graph_cache(commit_hash);
            CREATE INDEX IF NOT EXISTS idx_large_objects_scan ON large_objects(scan_id);
            CREATE INDEX IF NOT EXISTS idx_ai_findings_scan ON ai_findings(scan_id);
            CREATE INDEX IF NOT EXISTS idx_ai_findings_owasp ON ai_findings(owasp_category);
            
            -- P2.44: UNIQUE constraint for AI findings deduplication
            -- Same rule at same location = same finding
            CREATE UNIQUE INDEX IF NOT EXISTS idx_ai_findings_unique 
                ON ai_findings(scan_id, file_path, line_start, rule_id);
            
            CREATE INDEX IF NOT EXISTS idx_dlp_findings_scan ON dlp_findings(scan_id);
            CREATE INDEX IF NOT EXISTS idx_dlp_findings_type ON dlp_findings(finding_type);
            CREATE INDEX IF NOT EXISTS idx_dlp_findings_pii ON dlp_findings(pii_type);
            
            -- P2.44: UNIQUE constraint for DLP findings deduplication
            -- Same PII type at same location flowing to same sink = same finding
            CREATE UNIQUE INDEX IF NOT EXISTS idx_dlp_findings_unique 
                ON dlp_findings(scan_id, file_path, line_start, pii_type, sink_type);
        """)
        
        self.conn.commit()
    
    # =========================================================================
    # SCAN MANAGEMENT
    # =========================================================================
    
    def start_scan(self, branch: str, commit_hash: str, scan_dir: str, version: str) -> int:
        """
        Start a new scan and return scan_id.
        
        All subsequent operations use this scan_id.
        """
        cursor = self.conn.cursor()
        cursor.execute("""
            INSERT INTO scans (branch, commit_hash, commit_short, scan_dir, version, status)
            VALUES (?, ?, ?, ?, ?, 'running')
        """, (branch, commit_hash, commit_hash[:8] if commit_hash else None, scan_dir, version))
        
        self.conn.commit()
        self._current_scan_id = cursor.lastrowid
        return self._current_scan_id
    
    def complete_scan(self, duration_seconds: float, risk_score: int = 0, risk_level: str = None, 
                     totals: dict = None, source_files_scanned: int = 0):
        """Mark current scan as complete and update summary stats.
        
        Args:
            totals: Optional dict with keys: total, reachable, unknown, critical, high, medium, low, config
                   If provided, uses these instead of recalculating from findings table.
            source_files_scanned: Number of source files analyzed (for dashboard coverage metric)
        """
        if not self._current_scan_id:
            return
        
        # Calculate summary stats from findings
        # v4.5.10: Use UPPER() for case-insensitive severity matching (data has 'Critical', not 'CRITICAL')
        cursor = self.conn.cursor()
        
        # Get stats from main findings table
        cursor.execute("""
            SELECT 
                COUNT(*) as total,
                SUM(CASE WHEN app_reachability = 'REACHABLE' THEN 1 ELSE 0 END) as reachable,
                SUM(CASE WHEN UPPER(severity) = 'CRITICAL' THEN 1 ELSE 0 END) as critical,
                SUM(CASE WHEN UPPER(severity) = 'HIGH' THEN 1 ELSE 0 END) as high,
                SUM(CASE WHEN UPPER(severity) = 'MEDIUM' THEN 1 ELSE 0 END) as medium,
                SUM(CASE WHEN UPPER(severity) = 'LOW' THEN 1 ELSE 0 END) as low,
                SUM(CASE WHEN LOWER(finding_type) = 'config' THEN 1 ELSE 0 END) as config,
                SUM(CASE WHEN app_reachability = 'UNKNOWN' THEN 1 ELSE 0 END) as unknown
            FROM findings WHERE scan_id = ?
        """, (self._current_scan_id,))
        
        findings_stats = cursor.fetchone()
        
        # P2.50 FIX: Also include DLP and AI findings in totals for accurate trends
        # Get DLP stats
        dlp_total = dlp_reachable = dlp_critical = dlp_high = dlp_medium = dlp_low = 0
        try:
            cursor.execute("""
                SELECT 
                    COUNT(*) as total,
                    SUM(CASE WHEN is_reachable = 1 THEN 1 ELSE 0 END) as reachable,
                    SUM(CASE WHEN UPPER(severity) = 'CRITICAL' THEN 1 ELSE 0 END) as critical,
                    SUM(CASE WHEN UPPER(severity) = 'HIGH' THEN 1 ELSE 0 END) as high,
                    SUM(CASE WHEN UPPER(severity) = 'MEDIUM' THEN 1 ELSE 0 END) as medium,
                    SUM(CASE WHEN UPPER(severity) = 'LOW' THEN 1 ELSE 0 END) as low
                FROM dlp_findings WHERE scan_id = ?
            """, (self._current_scan_id,))
            dlp_stats = cursor.fetchone()
            if dlp_stats:
                # Use explicit None checks since 0 is valid
                dlp_total = dlp_stats['total'] if dlp_stats['total'] is not None else 0
                dlp_reachable = dlp_stats['reachable'] if dlp_stats['reachable'] is not None else 0
                dlp_critical = dlp_stats['critical'] if dlp_stats['critical'] is not None else 0
                dlp_high = dlp_stats['high'] if dlp_stats['high'] is not None else 0
                dlp_medium = dlp_stats['medium'] if dlp_stats['medium'] is not None else 0
                dlp_low = dlp_stats['low'] if dlp_stats['low'] is not None else 0
                logger.debug(f"P2.50 DLP stats: total={dlp_total}, reach={dlp_reachable}")
        except Exception as e:
            logger.warning(f"P2.50 DLP query failed: {e}")
        
        # Get AI stats
        ai_total = ai_reachable = ai_critical = ai_high = ai_medium = ai_low = 0
        try:
            cursor.execute("""
                SELECT 
                    COUNT(*) as total,
                    SUM(CASE WHEN is_reachable = 1 THEN 1 ELSE 0 END) as reachable,
                    SUM(CASE WHEN UPPER(severity) = 'CRITICAL' THEN 1 ELSE 0 END) as critical,
                    SUM(CASE WHEN UPPER(severity) = 'HIGH' THEN 1 ELSE 0 END) as high,
                    SUM(CASE WHEN UPPER(severity) = 'MEDIUM' THEN 1 ELSE 0 END) as medium,
                    SUM(CASE WHEN UPPER(severity) = 'LOW' THEN 1 ELSE 0 END) as low
                FROM ai_findings WHERE scan_id = ?
            """, (self._current_scan_id,))
            ai_stats = cursor.fetchone()
            if ai_stats:
                # Use explicit None checks since 0 is valid
                ai_total = ai_stats['total'] if ai_stats['total'] is not None else 0
                ai_reachable = ai_stats['reachable'] if ai_stats['reachable'] is not None else 0
                ai_critical = ai_stats['critical'] if ai_stats['critical'] is not None else 0
                ai_high = ai_stats['high'] if ai_stats['high'] is not None else 0
                ai_medium = ai_stats['medium'] if ai_stats['medium'] is not None else 0
                ai_low = ai_stats['low'] if ai_stats['low'] is not None else 0
                logger.debug(f"P2.50 AI stats: total={ai_total}, reach={ai_reachable}")
        except Exception as e:
            logger.warning(f"P2.50 AI query failed: {e}")
        
        # Combine all stats (excluding CONFIG from totals per P2.50)
        config_count = findings_stats['config'] or 0
        stats = {
            'total': (findings_stats['total'] or 0) + dlp_total + ai_total - config_count,
            'reachable': (findings_stats['reachable'] or 0) + dlp_reachable + ai_reachable,
            'critical': (findings_stats['critical'] or 0) + dlp_critical + ai_critical,
            'high': (findings_stats['high'] or 0) + dlp_high + ai_high,
            'medium': (findings_stats['medium'] or 0) + dlp_medium + ai_medium,
            'low': (findings_stats['low'] or 0) + dlp_low + ai_low,
            'config': config_count,
            'unknown': findings_stats['unknown'] or 0,
        }
        
        cursor.execute("""
            UPDATE scans SET 
                status = 'complete',
                duration_seconds = ?,
                total_findings = ?,
                reachable_findings = ?,
                critical_count = ?,
                high_count = ?,
                medium_count = ?,
                low_count = ?,
                config_count = ?,
                unknown_count = ?,
                risk_score = ?,
                risk_level = ?,
                source_files_scanned = ?
            WHERE id = ?
        """, (
            duration_seconds,
            stats['total'] or 0,
            stats['reachable'] or 0,
            stats['critical'] or 0,
            stats['high'] or 0,
            stats['medium'] or 0,
            stats['low'] or 0,
            stats['config'] or 0,
            stats['unknown'] or 0,
            risk_score,
            risk_level,
            source_files_scanned,
            self._current_scan_id
        ))
        
        self.conn.commit()
    
    def fail_scan(self, error_message: str = None):
        """Mark current scan as failed."""
        if not self._current_scan_id:
            return
        
        self.conn.execute("""
            UPDATE scans SET status = 'failed' WHERE id = ?
        """, (self._current_scan_id,))
        self.conn.commit()
    
    @property
    def scan_id(self) -> Optional[int]:
        """Get current scan ID."""
        return self._current_scan_id
    
    def _derive_risk_level(self, severity: str, app_reachability: str = 'UNKNOWN') -> str:
        """
        Derive risk_level from severity + reachability for SLA guidance.
        
        v4.5.51: Risk considers reachability:
        - REACHABLE: maintains severity as risk level
        - UNKNOWN: maintains severity (assume worst case for SLA)
        - NOT_REACHABLE: downgrade to LOW/INFO
        
        Examples:
        - CRITICAL + REACHABLE → CRITICAL risk (24h SLA)
        - CRITICAL + UNREACHABLE → LOW risk (90d SLA)
        - HIGH + UNKNOWN → HIGH risk (7d SLA, assume worst case)
        """
        severity_upper = (severity or 'MEDIUM').upper()
        reach = (app_reachability or 'UNKNOWN').upper()
        
        # NOT_REACHABLE findings are downgraded
        if reach == 'NOT_REACHABLE':
            # CRITICAL/HIGH → LOW, MEDIUM/LOW → INFO
            if severity_upper in ('CRITICAL', 'HIGH', 'ERROR'):
                return 'LOW'  # Still track, but low priority
            else:
                return 'INFO'  # No SLA, informational only
        
        # REACHABLE or UNKNOWN: use severity as risk level
        mapping = {
            'CRITICAL': 'CRITICAL',
            'HIGH': 'HIGH', 
            'MEDIUM': 'MEDIUM',
            'LOW': 'LOW',
            'WARNING': 'LOW',
            'ERROR': 'HIGH',
            'INFO': 'INFO',
        }
        return mapping.get(severity_upper, 'MEDIUM')
    
    # =========================================================================
    # FINDINGS STORAGE
    # =========================================================================
    
    def _reclassify_secret_findings(self, findings: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """
        P2.20 Fix: Reclassify Semgrep CWE-UNK findings that are actually secrets.
        
        Root Cause: Semgrep secret rules output as CWE-UNK-XX with no type field.
        Fix: Post-process to correct type, finding_id, cwe_id, and secret_type.
        
        Args:
            findings: List of finding dictionaries
            
        Returns:
            Modified findings list with correct classifications
        """
        import re
        
        for f in findings:
            finding_id = f.get('id', f.get('finding_id', ''))
            
            # P2.44 FIX: Generate unique ID if correlation didn't provide one
            # This prevents location-based findings (secrets, CWEs) from being over-deduplicated
            if not finding_id:
                import hashlib
                
                # CRITICAL: Every finding MUST have file_path, line_number, and type
                # If these are missing, it's a pipeline bug that must be fixed
                file_path = f.get('file_path') or f.get('file')
                line_num = f.get('line_number') or f.get('line', 0)
                finding_type = f.get('type')
                
                if not file_path:
                    raise ValueError(f"Finding missing file_path: {f}")
                if not line_num:
                    raise ValueError(f"Finding missing line_number: {f}")
                if not finding_type:
                    raise ValueError(f"Finding missing type: {f}")
                
                # Generate unique ID from location + type
                id_components = [
                    str(file_path),
                    str(line_num),
                    str(finding_type),
                    str(f.get('rule_id', '')),
                ]
                id_str = ':'.join(id_components)
                finding_id = hashlib.sha256(id_str.encode()).hexdigest()[:16]
                f['id'] = finding_id  # Set the generated ID back on the finding
            
            description = f.get('description', f.get('message', ''))
            title = f.get('title', '')
            
            # Check if this is a misclassified secret
            # Pattern: CWE-UNK-XX + "Secret detected: <TYPE>"
            if finding_id.startswith('CWE-UNK') and ('Secret detected:' in (description or '') or 'Secret detected:' in (title or '')):
                # Extract secret type from description
                # Format: "Secret detected: AWS_ACCESS_KEY_ID (cloud_access_key)"
                text = description or title
                match = re.search(r'Secret detected:\s+([A-Z_0-9]+)', text)
                secret_type = match.group(1) if match else 'UNKNOWN'
                
                # Extract detector hint from parentheses
                detector_match = re.search(r'\(([^)]+)\)', text)
                detector_hint = detector_match.group(1) if detector_match else 'generic'
                
                # Fix the finding classification
                f['type'] = 'secret'
                f['finding_type'] = 'secret'
                f['secret_type'] = secret_type
                f['finding_id'] = f"semgrep-secret-{detector_hint.replace('_', '-')}"
                f['id'] = f['finding_id']  # Update id as well
                f['cwe_id'] = 'CWE-798'  # Use of Hard-coded Credentials
                
                logger.info(f"✓ P2.20 Fix: Reclassified CWE-UNK as SECRET: {secret_type} ({detector_hint})")
        
        return findings
    
    def _enrich_with_sla_tags(self, findings: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """
        P2.21 Fix: Enrich findings with correct SLA tags based on RISK LEVEL.
        
        UNIVERSAL POLICY (applies to ALL finding types):
        - Use risk_level (not severity) for SLA
        - risk_level considers: severity + reachability + exploitability
        
        SLA Timelines:
        - CRITICAL risk → 24 hours
        - HIGH risk → 7 days  
        - MEDIUM risk → 30 days
        - LOW risk → 90 days
        - INFO risk → No SLA (awareness only)
        
        Applies to: CVE, CWE, SECRET, DLP, AI, CONFIG, MALWARE
        """
        for f in findings:
            # Get risk level (already calculated considering reachability)
            risk = str(f.get('risk_level', '')).upper()
            
            # P2.21 DEBUG: Check if config findings have risk_level (commented out for clean output)
            # if f.get('finding_type') == 'config' or f.get('cwe_id', '').startswith('CWE-022'):
            #     logger.info(f"DEBUG SLA: type={f.get('finding_type', 'unknown')}, sev={f.get('severity')}, reach={f.get('app_reachability')}, risk_level={f.get('risk_level')}")
            
            # SLA mapping based on RISK not SEVERITY
            sla_map = {
                'CRITICAL': ('24h', 'sla-critical'),
                'HIGH': ('7d', 'sla-high'),
                'MEDIUM': ('30d', 'sla-medium'),
                'LOW': ('90d', 'sla-low'),
                'INFO': (None, None),  # No SLA
            }
            
            sla_display, sla_class = sla_map.get(risk, ('ASSESS', 'sla-unknown'))
            f['sla_display'] = sla_display
            f['sla_class'] = sla_class
        
        return findings
    
    def _format_vulnerability_id(self, cve_id: str = None, ghsa_id: str = None, primary_id: str = None) -> tuple[str, str, str]:
        """
        P2.21: Format vulnerability ID for display in natural order.
        
        Args:
            cve_id: CVE identifier (e.g., "CVE-2024-12345")
            ghsa_id: GHSA identifier (e.g., "GHSA-abcd-efgh-ijkl")
            primary_id: Which ID was primary in Grype output (to preserve natural order)
            
        Returns:
            Tuple of (primary_id, display_id, id_note)
            - primary_id: ID to use for sorting/grouping
            - display_id: Formatted string for display (primary first, then secondary in parens)
            - id_note: Additional context
        """
        # Normalize inputs
        cve = cve_id.strip() if cve_id and cve_id.upper() not in ('UNKNOWN', 'NONE', '') else None
        ghsa = ghsa_id.strip() if ghsa_id and ghsa_id.upper() not in ('UNKNOWN', 'NONE', '') else None
        
        # Case 1: Both CVE and GHSA exist - show in natural order
        if cve and ghsa:
            # If GHSA was primary (common), show: GHSA-xxx (CVE-yyy)
            if primary_id and primary_id.startswith('GHSA-'):
                return (ghsa, f"{ghsa} (CVE: {cve})", "")
            # Otherwise show: CVE-xxx (GHSA: yyy)
            else:
                return (cve, f"{cve} (GHSA: {ghsa})", "")
        
        # Case 2: GHSA only
        elif ghsa and not cve:
            return (ghsa, ghsa, "⚠️ No CVE assigned yet")
        
        # Case 3: CVE only
        elif cve and not ghsa:
            return (cve, cve, "")
        
        # Case 4: Neither exists (fallback)
        else:
            return ("UNKNOWN", "UNKNOWN", "⚠️ Missing vulnerability ID")
    
    def _extract_vulnerability_ids(self, vuln_data: dict) -> tuple[str, str]:
        """
        P2.21: Extract both CVE and GHSA IDs from Grype vulnerability data.
        
        Grype can provide:
        - vuln['id'] - Primary ID (could be CVE or GHSA)
        - vuln['dataSource'] - URL that might contain both IDs
        - vuln['relatedVulnerabilities'] - Array with both CVE and GHSA
        
        Args:
            vuln_data: Grype vulnerability dict
            
        Returns:
            Tuple of (cve_id, ghsa_id)
        """
        import re
        
        cve_id = None
        ghsa_id = None
        
        # Method 1: Check primary ID field
        primary_id = vuln_data.get('id', '')
#        logger.info(f"DEBUG P2.21: Extracting IDs - primary_id={primary_id}")
        
        if primary_id.startswith('CVE-'):
            cve_id = primary_id
        elif primary_id.startswith('GHSA-'):
            ghsa_id = primary_id
        
        # Method 2: Check relatedVulnerabilities array (can be objects or strings)
        related = vuln_data.get('relatedVulnerabilities', [])
#        logger.info(f"DEBUG P2.21: relatedVulnerabilities count={len(related)}")
        
        for i, rel in enumerate(related):
            # Handle both formats: [{id: "CVE-..."}, ...] or ["CVE-...", ...]
            if isinstance(rel, dict):
                rel_id = rel.get('id', '')
#                logger.info(f"DEBUG P2.21: related[{i}] is dict, id={rel_id}")
            elif isinstance(rel, str):
                rel_id = rel
#                logger.info(f"DEBUG P2.21: related[{i}] is string, value={rel_id}")
            else:
#                logger.info(f"DEBUG P2.21: related[{i}] is unknown type: {type(rel)}")
                continue  # Skip unknown format
            
            if rel_id.startswith('CVE-') and not cve_id:
                cve_id = rel_id
#                logger.info(f"DEBUG P2.21: Found CVE: {cve_id}")
            elif rel_id.startswith('GHSA-') and not ghsa_id:
                ghsa_id = rel_id
#                logger.info(f"DEBUG P2.21: Found GHSA: {ghsa_id}")
        
#        logger.info(f"DEBUG P2.21: Final IDs - cve_id={cve_id}, ghsa_id={ghsa_id}")
        return (cve_id, ghsa_id)
    
    def store_findings(self, findings: List[Dict[str, Any]], finding_type: str) -> int:
        """
        v5.0: Store findings with collision detection and fingerprints.
        
        Args:
            findings: List of finding dictionaries
            finding_type: 'cve', 'cwe', 'config', 'secret', 'malware', 'suspicious'
            
        Returns:
            Number of findings stored
        """
        if not findings or not self._current_scan_id:
            return 0
        
        cli_count = len(findings)  # v1.0: For audit
        
        # P2.20 Fix: Reclassify secret findings BEFORE fingerprinting
        if finding_type in ('cwe', 'secret', 'config'):
            findings = self._reclassify_secret_findings(findings)
        
        # P2.21 FIX: Calculate risk_level BEFORE SLA enrichment
        for f in findings:
            # P2.21.2 FIX: Check for None/empty, not just missing key
            if not f.get('risk_level'):
                # Determine app_reachability
                app_reach = 'UNKNOWN'
                if f.get('is_reachable') is True:
                    app_reach = 'REACHABLE'
                elif f.get('is_reachable') is False:
                    app_reach = 'NOT_REACHABLE'
                elif f.get('app_reachability'):
                    app_reach = f['app_reachability']
                
                # Calculate and store risk_level in dict (this will be in raw_data)
                calculated_risk = self._derive_risk_level(f.get('severity', 'MEDIUM'), app_reach)
                f['risk_level'] = calculated_risk
        
        # Enrich with SLA tags
        findings = self._enrich_with_sla_tags(findings)
        
        # v1.0: Collision detection
        detector = CollisionDetector() if CollisionDetector else None
        
        batch_data = []
        skipped_count = 0
        
        for f in findings:
            try:
                # v1.0: Collision detection (updates finding['id'] if collision)
                if detector:
                    f = detector.check_and_resolve(f)
                
                # Map is_reachable to app_reachability
                app_reach = 'UNKNOWN'
                if f.get('is_reachable') is True:
                    app_reach = 'REACHABLE'
                elif f.get('is_reachable') is False:
                    app_reach = 'NOT_REACHABLE'
                elif f.get('app_reachability'):
                    app_reach = f['app_reachability']
                
                # P2.44 VALIDATION: Log errors instead of crashing to prevent data loss
                finding_id = f.get('id', f.get('finding_id', f.get('cve_id', '')))
                
                # CRITICAL: finding_id MUST exist and be non-empty
                if not finding_id:
                    logger.info(f"⚠️  SKIPPED {finding_type}: Missing ID - File={f.get('file', f.get('file_path'))}, Line={f.get('line', f.get('line_number'))}")
                    skipped_count += 1
                    continue
                
                # CRITICAL: finding_id must be a string
                if not isinstance(finding_id, str):
                    logger.info(f"⚠️  SKIPPED {finding_type}: ID must be string, got {type(finding_id)}: {finding_id}")
                    skipped_count += 1
                    continue
                
                # CRITICAL: For location-based findings (secrets, CWEs, config), file_path and line_number MUST exist
                if finding_type in ('secret', 'cwe', 'config'):
                    file_path = f.get('file', f.get('file_path', ''))
                    line_num = f.get('line', f.get('line_number', 0))
                    
                    if not file_path:
                        logger.info(f"⚠️  SKIPPED {finding_type.upper()}: Missing file_path - ID={finding_id}")
                        skipped_count += 1
                        continue
                    if not line_num:
                        logger.info(f"⚠️  SKIPPED {finding_type.upper()}: Missing line_number - ID={finding_id}, File={file_path}")
                        skipped_count += 1
                        continue
                
                # CRITICAL: severity must be valid
                severity = f.get('severity', 'MEDIUM')
                if severity not in ('CRITICAL', 'HIGH', 'MEDIUM', 'LOW', 'INFO', 'ERROR', 'WARNING'):
                    logger.info(f"⚠️  SKIPPED {finding_type}: Invalid severity '{severity}' - ID={finding_id}")
                    skipped_count += 1
                    continue
                
                # CRITICAL: For CVEs, package_name must exist
                if finding_type == 'cve':
                    pkg_name = f.get('package', f.get('package_name', ''))
                    if not pkg_name:
                        logger.info(f"⚠️  SKIPPED CVE: Missing package_name - ID={finding_id}")
                        skipped_count += 1
                        continue
                    
                    # CRITICAL: CVEs must have version
                    pkg_version = f.get('version', f.get('package_version', ''))
                    if not pkg_version:
                        logger.info(f"⚠️  SKIPPED CVE: Missing package_version - ID={finding_id}, Package={pkg_name}")
                        skipped_count += 1
                        continue
                    
                    # CRITICAL: CVEs should have CVSS score (warn if missing)
                    cvss = f.get('cvss_score', f.get('cvss', 0.0))
                    if cvss == 0.0:
                        logger.warning(f"CVE {finding_id} has CVSS=0.0 - may be missing enrichment data")
                
                # CRITICAL: CWE findings must have cwe_id
                if finding_type == 'cwe':
                    cwe_id = f.get('cwe_id', f.get('cwe', ''))
                    if not cwe_id:
                        logger.info(f"⚠️  SKIPPED CWE: Missing cwe_id - ID={finding_id}")
                        skipped_count += 1
                        continue
                
                # CRITICAL: Secret findings must have secret_type
                if finding_type == 'secret':
                    secret_type = f.get('secret_type', f.get('rule_id', ''))
                    if not secret_type:
                        logger.info(f"⚠️  SKIPPED SECRET: Missing secret_type - ID={finding_id}")
                        skipped_count += 1
                        continue
                
                # CRITICAL: All findings must have title OR message
                title = f.get('title', f.get('message', ''))
                if not title:
                    logger.info(f"⚠️  SKIPPED {finding_type}: Missing title/message - ID={finding_id}")
                    skipped_count += 1
                    continue
                
                # CRITICAL: All findings must have scanner attribution (default to 'unknown' instead of failing)
                scanner = f.get('scanner', 'unknown')
                if scanner == 'unknown':
                    logger.info(f"⚠️  WARNING {finding_type}: Missing scanner field, using 'unknown' - ID={finding_id}")
                
                # v1.0: Build type_detail for performance
                type_detail = finding_type
                if finding_type == 'secret' and f.get('secret_type'):
                    type_detail = f"secret:{f['secret_type']}"
                elif finding_type == 'cwe' and f.get('cwe_id'):
                    type_detail = f"cwe:{f['cwe_id']}"
                elif finding_type == 'config' and f.get('cwe_id'):
                    type_detail = f"config:{f['cwe_id']}"
                
                batch_data.append((
                    self._current_scan_id,
                    finding_type,
                    finding_id,  # v1.0: Already validated and collision-checked
                    type_detail,                       # v1.0: NEW COLUMN
                    f.get('ghsa_id'),                  # P2.21: GHSA ID
                    f.get('display_id'),               # P2.21: Formatted display ID
                    f.get('id_note'),                  # P2.21: Additional context
                    f.get('severity', 'MEDIUM'),
                    f.get('risk_level') or self._derive_risk_level(f.get('severity', 'MEDIUM'), app_reach),
                    f.get('cvss_score', f.get('cvss', 0.0)),
                    app_reach,
                    f.get('reachability_confidence', f.get('app_reachability_confidence', 'LOW')),
                    json.dumps(f.get('reachability_path', f.get('call_path', f.get('call_paths', [])))) if f.get('reachability_path') or f.get('call_path') or f.get('call_paths') else None,
                    f.get('platform_exposure', 'UNKNOWN'),
                    f.get('fix_status'),
                    f.get('fix_version', f.get('fixed_in')),
                    f.get('file', f.get('file_path', '')),
                    f.get('line', f.get('line_number', 0)),
                    f.get('package', f.get('package_name', '')),
                    f.get('version', f.get('package_version', '')),
                    f.get('title', f.get('message', ''))[:500] if f.get('title') or f.get('message') else None,
                    f.get('description', '')[:1000] if f.get('description') else None,
                    f.get('cwe_id', f.get('cwe', '')),
                    f.get('secret_type', f.get('rule_id', '')),
                    json.dumps(f.get('evidence_static')) if f.get('evidence_static') else None,
                    json.dumps(f.get('evidence_dynamic')) if f.get('evidence_dynamic') else None,
                    json.dumps(f.get('compliance_mapping')) if f.get('compliance_mapping') else None,
                    scanner,
                    json.dumps(f) if len(json.dumps(f)) < 10000 else None  # Store raw if not too large
                ))
            
            except Exception as e:
                logger.info(f"❌ ERROR processing {finding_type} finding: {e}")
                logger.info(f"   Finding data: {f}")
                skipped_count += 1
                continue
        
        # Report skipped findings
        if skipped_count > 0:
            logger.info(f"\n⚠️  DATA QUALITY WARNING: Skipped {skipped_count}/{len(findings)} {finding_type} findings due to missing required fields")
            logger.info(f"   Stored: {len(batch_data)}/{len(findings)} findings")
            logger.info(f"   Loss: {skipped_count} findings ({skipped_count/len(findings)*100:.1f}%)")
        
        # If no valid findings, return early
        if len(batch_data) == 0:
            logger.info(f"⚠️  WARNING: No valid {finding_type} findings to store after validation")
            return 0
        
        cursor = self.conn.cursor()
        
        # v1.0: ON CONFLICT DO UPDATE (not INSERT OR REPLACE)
        # This preserves data on updates instead of deleting and reinserting
        cursor.executemany("""
            INSERT INTO findings (
                scan_id, finding_type, finding_id, type_detail, ghsa_id, display_id, id_note,
                severity, risk_level, cvss_score,
                app_reachability, app_reachability_confidence, app_reachability_path,
                platform_exposure, fix_status, fix_version,
                file_path, line_number, package_name, package_version,
                title, description, cwe_id, secret_type,
                evidence_static, evidence_dynamic, compliance_mapping,
                scanner, raw_data
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT(scan_id, finding_id) DO UPDATE SET
                severity = excluded.severity,
                risk_level = excluded.risk_level,
                cvss_score = excluded.cvss_score,
                app_reachability = excluded.app_reachability,
                app_reachability_confidence = excluded.app_reachability_confidence,
                app_reachability_path = excluded.app_reachability_path,
                platform_exposure = excluded.platform_exposure,
                fix_status = excluded.fix_status,
                fix_version = excluded.fix_version,
                raw_data = excluded.raw_data
        """, batch_data)
        
        self.conn.commit()
        stored_count = cursor.rowcount
        
        # v1.0: Log collision stats
        if detector:
            detector.log_stats(finding_type)
        
        # v1.0: Audit data loss
        self._audit_scan_storage(finding_type, cli_count, stored_count)
        
        # LOG: Track storage
        self._log_storage(finding_type, cli_count, stored_count, skipped_count)
        
        return stored_count
    
    def _log_storage(self, finding_type: str, total: int, stored: int, skipped: int):
        """Log database storage operations for audit trail"""
        import os
        from datetime import datetime
        
        # Check if DEBUG mode enabled
        debug_mode = os.environ.get('REACHABLE_DEBUG', '').lower() in ('1', 'true', 'yes')
        
        # Always print summary
        logger.info(f"📊 DB INSERT [{finding_type.upper()}]: {stored}/{total} stored ({skipped} skipped)")
        
        # Write detailed log if debug enabled
        if debug_mode:
            log_dir = Path.home() / '.reachable' / 'logs'
            log_dir.mkdir(parents=True, exist_ok=True)
            log_file = log_dir / 'db_audit.log'
            
            timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            scan_id = self._current_scan_id
            
            with open(log_file, 'a') as f:
                f.write(f"[{timestamp}] scan_id={scan_id} type={finding_type.upper():8s} total={total:4d} stored={stored:4d} skipped={skipped:4d} loss={skipped/total*100 if total > 0 else 0:5.1f}%\n")
    
    def _audit_scan_storage(self, finding_type: str, cli_count: int, db_count: int):
        """
        v1.0: Audit data loss for scan_audit table.
        
        Compares CLI output count vs database count to detect data loss.
        """
        if not self._current_scan_id:
            return
        
        loss_count = cli_count - db_count
        loss_percentage = (loss_count / cli_count * 100) if cli_count > 0 else 0.0
        
        self.conn.execute("""
            INSERT INTO scan_audit (scan_id, finding_type, cli_count, db_count, loss_count, loss_percentage)
            VALUES (?, ?, ?, ?, ?, ?)
        """, (self._current_scan_id, finding_type, cli_count, db_count, loss_count, loss_percentage))
        
        self.conn.commit()
        
        if loss_percentage > 1.0:  # > 1% loss is concerning
            logger.warning(f"⚠️  DATA LOSS: {finding_type} lost {loss_count}/{cli_count} ({loss_percentage:.1f}%)")
    
    def store_ai_findings(self, ai_findings: List[Dict[str, Any]]) -> int:
        """
        Store AI security findings (OWASP LLM Top 10).
        
        Args:
            ai_findings: List of AI finding dictionaries or AIFinding objects
            
        Returns:
            Number of findings stored
        """
        if not ai_findings or not self._current_scan_id:
            return 0
        
        # P2.20 Fix: Enrich AI findings with SLA tags
        ai_findings = self._enrich_with_sla_tags(ai_findings)
        
        batch_data = []
        
        for f in ai_findings:
            # v4.5.30: Handle both dict and AIFinding object formats
            if hasattr(f, 'to_dict'):
                f = f.to_dict()
            
            # P2.44 ASSERTIONS: Validate required fields for UNIQUE constraint
            file_path = f.get('file_path', '')
            line_start = f.get('line_start', f.get('line_number', 0))
            rule_id = f.get('rule_id', '')
            
            assert file_path, f"FATAL: AI finding missing file_path! Finding: {f}"
            assert line_start, f"FATAL: AI finding missing line_start! File={file_path}. Finding: {f}"
            assert rule_id, f"FATAL: AI finding missing rule_id! File={file_path}:{line_start}. Finding: {f}"
            
            severity = f.get('severity', 'WARNING')
            assert severity in ('CRITICAL', 'HIGH', 'MEDIUM', 'LOW', 'INFO', 'ERROR', 'WARNING'), \
                f"FATAL: Invalid severity '{severity}' for AI finding at {file_path}:{line_start}"
            
            batch_data.append((
                self._current_scan_id,
                f.get('rule_id', ''),
                f.get('policy_id', ''),
                f.get('owasp_category', f.get('owasp_llm', '')),
                f.get('owasp_name', ''),
                f.get('severity', 'WARNING'),
                f.get('base_risk_score', 0.0),
                f.get('adjusted_risk_score', 0.0),
                1 if f.get('is_reachable', True) else 0,
                json.dumps(f.get('call_path', f.get('call_paths', []))) if f.get('call_path') or f.get('call_paths') else None,
                json.dumps(f.get('guards', [])) if f.get('guards') else None,
                f.get('guard_risk_reduction', 0.0),
                f.get('file_path', ''),
                f.get('line_start', f.get('line_number', 0)),
                f.get('line_end', 0),
                f.get('message', '')[:500] if f.get('message') else None,
                '',  # v4.5.38: AI findings don't have CWE - removed design inconsistency
                f.get('framework', ''),
                f.get('provider', ''),
                f.get('detection_source', ''),
                json.dumps(f) if len(json.dumps(f)) < 10000 else None
            ))
        
        cursor = self.conn.cursor()
        # P2.44: Use INSERT OR REPLACE for deduplication (upsert)
        cursor.executemany("""
            INSERT OR REPLACE INTO ai_findings (
                scan_id, rule_id, policy_id, owasp_category, owasp_name,
                severity, base_risk_score, adjusted_risk_score,
                is_reachable, call_path, guards, guard_risk_reduction,
                file_path, line_start, line_end, message, cwe_id,
                framework, provider, detection_source, raw_data
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, batch_data)
        
        self.conn.commit()
        stored_count = cursor.rowcount
        
        # LOG: Track AI findings storage
        self._log_storage('ai', len(ai_findings), stored_count, 0)
        
        return stored_count
    
    def store_dlp_findings(self, dlp_findings: List[Dict[str, Any]]) -> int:
        """
        Store DLP/PII security findings.
        
        Args:
            dlp_findings: List of DLP finding dictionaries or DLPFinding objects
            
        Returns:
            Number of findings stored
        """
        if not dlp_findings or not self._current_scan_id:
            return 0
        
        # P2.21.2 FIX: Calculate risk_level BEFORE SLA enrichment
        for f in dlp_findings:
            # Handle object format
            if hasattr(f, 'to_dict'):
                f_dict = f.to_dict()
            else:
                f_dict = f
            
            if not f_dict.get('risk_level'):
                # Determine reachability
                if f_dict.get('is_reachable') is True:
                    app_reach = 'REACHABLE'
                elif f_dict.get('is_reachable') is False:
                    app_reach = 'NOT_REACHABLE'
                else:
                    app_reach = 'UNKNOWN'
                
                # Get severity
                severity = f_dict.get('severity', f_dict.get('adjusted_severity', 'MEDIUM'))
                
                # Calculate risk_level
                f_dict['risk_level'] = self._derive_risk_level(severity, app_reach)
        
        # P2.20 Fix: Enrich DLP findings with SLA tags (now risk_level exists)
        dlp_findings = self._enrich_with_sla_tags(dlp_findings)
        
        batch_data = []
        
        for f in dlp_findings:
            # Handle both dict and DLPFinding object formats
            if hasattr(f, 'to_dict'):
                f = f.to_dict()
            
            # P2.44 ASSERTIONS: Validate required fields for UNIQUE constraint
            file_path = f.get('file_path', '')
            line_start = f.get('line_start', f.get('line_number', 0))
            pii_type = f.get('pii_type', '')
            sink_type = f.get('sink_type', '')
            
            assert file_path, f"FATAL: DLP finding missing file_path! Finding: {f}"
            assert line_start, f"FATAL: DLP finding missing line_start! File={file_path}. Finding: {f}"
            assert pii_type, f"FATAL: DLP finding missing pii_type! File={file_path}:{line_start}. Finding: {f}"
            # sink_type can be empty for discovery findings (not taint flows)
            
            severity = f.get('severity', f.get('adjusted_severity', 'MEDIUM'))
            assert severity in ('CRITICAL', 'HIGH', 'MEDIUM', 'LOW', 'INFO', 'ERROR', 'WARNING'), \
                f"FATAL: Invalid severity '{severity}' for DLP finding at {file_path}:{line_start}"
            
            batch_data.append((
                self._current_scan_id,
                f.get('rule_id', ''),
                f.get('finding_type', 'pii_discovery'),
                f.get('pii_type', ''),
                f.get('pii_sample', ''),
                f.get('pii_count', 1),
                f.get('sink_type', ''),
                f.get('sink_function', ''),
                f.get('severity', f.get('adjusted_severity', 'MEDIUM')),
                f.get('base_risk_score', f.get('risk_score', 0.0)),
                f.get('adjusted_risk_score', f.get('risk_score', 0.0)),
                f.get('file_class', 'source'),
                f.get('file_class_modifier', 1.0),
                1 if f.get('is_reachable', True) else 0,
                f.get('reachability_confidence', 'LOW'),
                json.dumps(f.get('call_path', f.get('call_paths', []))) if f.get('call_path') or f.get('call_paths') else None,
                1 if f.get('sanitizer_present', False) else 0,
                f.get('sanitizer_type', ''),
                f.get('sanitizer_effectiveness', 0.0),
                json.dumps(f.get('regulations', [])) if f.get('regulations') else None,
                f.get('file_path', ''),
                f.get('line_start', f.get('line_number', 0)),
                f.get('line_end', 0),
                f.get('message', '')[:500] if f.get('message') else None,
                f.get('remediation', ''),
                f.get('detection_source', 'pattern'),
                f.get('confidence', 0.8),
                json.dumps(f) if len(json.dumps(f, default=str)) < 10000 else None
            ))
        
        cursor = self.conn.cursor()
        # P2.44: Use INSERT OR REPLACE for deduplication (upsert)
        cursor.executemany("""
            INSERT OR REPLACE INTO dlp_findings (
                scan_id, rule_id, finding_type, pii_type, pii_sample, pii_count,
                sink_type, sink_function, severity, base_risk_score, adjusted_risk_score,
                file_class, file_class_modifier, is_reachable, reachability_confidence,
                call_path, sanitizer_present, sanitizer_type, sanitizer_effectiveness,
                regulations, file_path, line_start, line_end, message, remediation,
                detection_source, confidence, raw_data
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, batch_data)
        
        self.conn.commit()
        stored_count = cursor.rowcount
        
        # LOG: Track DLP findings storage
        self._log_storage('dlp', len(dlp_findings), stored_count, 0)
        
        return stored_count
    
    def _enrich_cve_with_p221(self, cve: Dict[str, Any]):
        """
        P2.21: Add CVE/GHSA dual ID fields to ANY CVE dict.
        
        Works regardless of where the CVE data came from.
        """
#        logger.info(f"DEBUG P2.21: _enrich_cve_with_p221 called with: {cve.get('id', 'NO-ID')}")
        
        # Try to find vulnerability data in multiple locations
        vuln_data = cve.get('vulnerability') or cve
        
        # Extract both IDs
        cve_id, ghsa_id = self._extract_vulnerability_ids(vuln_data)
        original_primary_id = vuln_data.get('id', cve_id or ghsa_id)  # Get Grype's primary ID
        primary_id, display_id, id_note = self._format_vulnerability_id(cve_id, ghsa_id, original_primary_id)
        
#        logger.info(f"DEBUG P2.21: Extracted - cve_id={cve_id}, ghsa_id={ghsa_id}")
#        logger.info(f"DEBUG P2.21: Formatted - primary={primary_id}, display={display_id}, note={id_note}")
        
        # Set P2.21 fields
        cve['ghsa_id'] = ghsa_id
        cve['display_id'] = display_id
        cve['id_note'] = id_note
        
#        logger.info(f"DEBUG P2.21: After setting - cve dict now has: ghsa_id={cve.get('ghsa_id')}, display_id={cve.get('display_id')}")
        
        # Update primary ID if needed
        if primary_id and primary_id != 'UNKNOWN':
            cve['id'] = primary_id
    
    def store_cves(self, vulns_data: Dict[str, Any]) -> int:
        """Store CVEs using legacy pipeline."""
        from reachable.config import FLAGS
        
        # Use legacy pipeline (hybrid was for debugging only)
        return self._store_cves_legacy(vulns_data)

    def _store_cves_enrichment(self, vulns_data: Dict[str, Any]) -> int:
        """
        NEW: Single-pass storage with enrichment.
        
        Flow:
        1. Parse Grype data
        2. Enrich (GitHub API for missing CVE IDs, threat intel)
        3. Apply SLA tags
        4. Save enrichment.json
        5. Single INSERT with complete data
        """
        from reachable.cve_enricher import CVEEnricher
        from reachable.config import FLAGS
        
        logger.info("📊 Enrichment pipeline activated")
        
        # Step 1: Parse Grype data (reuse existing parser)
        cves = self._parse_grype_vulns(vulns_data)
        logger.info(f"   ✓ Parsed {len(cves)} CVEs from Grype data")
        
        # Step 2: Enrich with GitHub API
        enricher = CVEEnricher(
            fetch_missing_cves=FLAGS.FETCH_MISSING_CVE_IDS,
            apply_threat_intel=FLAGS.ENABLE_THREAT_INTEL_ENRICHMENT
        )
        enriched_cves = enricher.enrich(cves)
        logger.info(f"   ✓ Enriched {len(enriched_cves)} CVEs")
        
        # Step 3: Apply SLA tags (reuse existing method)
        enriched_cves = self._enrich_with_sla_tags(enriched_cves)
        
        # Step 4: Save enrichment.json
        if FLAGS.ENABLE_ENRICHMENT_JSON or FLAGS.CVE_STORAGE_MODE == 'enrichment':
            self._save_enrichment_json(enriched_cves)
        
        # Step 5: Single database insert
        count = self.store_findings(enriched_cves, 'cve')
        
        # Print stats
        stats = enricher.get_stats()
        if stats['cve_ids_fetched'] > 0:
            logger.info(f"   ✓ Fetched {stats['cve_ids_fetched']} missing CVE IDs from GitHub")
        if stats['github_cache_hits'] > 0:
            logger.info(f"   ✓ GitHub cache hits: {stats['github_cache_hits']}")
        if stats['errors']:
            logger.info(f"   ⚠️  Enrichment errors: {len(stats['errors'])}")
        
        return count

    def _store_cves_enrichment_dry_run(self, vulns_data: Dict[str, Any]) -> int:
        """
        Dry-run enrichment pipeline (for hybrid mode testing).
        Saves enrichment.json but doesn't write to DB.
        """
        from reachable.cve_enricher import CVEEnricher
        from reachable.config import FLAGS
        
#        logger.debug(f"_store_cves_enrichment_dry_run called")
        
        # Parse and enrich
#        logger.debug(f"Calling _parse_grype_vulns...")
        cves = self._parse_grype_vulns(vulns_data)
#        logger.debug(f"Parsed {len(cves)} CVEs from Grype data")
        
        # Show first CVE structure
        if cves:
            logger.debug(f"First CVE: id={cves[0].get('id')}, cve_id={cves[0].get('cve_id')}, ghsa_id={cves[0].get('ghsa_id')}")
        
#        logger.debug(f"Creating CVEEnricher...")
        enricher = CVEEnricher(
            fetch_missing_cves=FLAGS.FETCH_MISSING_CVE_IDS,
            apply_threat_intel=FLAGS.ENABLE_THREAT_INTEL_ENRICHMENT
        )
        
#        logger.debug(f"Running enrichment...")
        enriched_cves = enricher.enrich(cves)
#        logger.debug(f"Enriched {len(enriched_cves)} CVEs")
        
#        logger.debug(f"Adding SLA tags...")
        enriched_cves = self._enrich_with_sla_tags(enriched_cves)
        
        # Save for comparison but DON'T write to DB
#        logger.debug(f"Saving enrichment-dry-run.json...")
        self._save_enrichment_json(enriched_cves, suffix='-dry-run')
#        logger.debug(f"Enrichment dry-run complete!")
        
        return len(enriched_cves)

    def _parse_grype_vulns(self, vulns_data: Dict[str, Any]) -> List[Dict]:
        """
        Parse Grype vulns.json into CVE dicts.
        Shared by both legacy and enrichment pipelines.
        """
        cves = []
        
        if isinstance(vulns_data, list):
            cves = vulns_data
        
        elif 'matches' in vulns_data:
            for match in vulns_data.get('matches', []):
                vuln = match.get('vulnerability', {})
                artifact = match.get('artifact', {})
                fix_info = vuln.get('fix', {})
                
                # Determine fix status
                fix_state = fix_info.get('state', 'unknown')
                fix_versions = fix_info.get('versions', [])
                
                if fix_state == 'fixed' and fix_versions:
                    fix_status = 'fix_available'
                    fix_version = ', '.join(fix_versions)
                elif fix_state == 'wont-fix':
                    fix_status = 'wont_fix'
                    fix_version = None
                elif fix_state == 'not-fixed' or not fix_versions:
                    fix_status = 'no_fix'
                    fix_version = None
                else:
                    fix_status = 'unknown'
                    fix_version = None
                
                # Extract description
                description = (
                    vuln.get('description') or 
                    vuln.get('summary') or
                    f"Vulnerability in {artifact.get('name', 'package')}"
                )
                
                # Extract location
                locations = artifact.get('locations', [])
                if locations and locations[0].get('path'):
                    file_path = locations[0].get('path')
                else:
                    file_path = artifact.get('name') or 'unknown'
                
                # Extract CVSS score
                cvss_score = None
                if vuln.get('cvss'):
                    cvss_list = vuln.get('cvss', [])
                    if cvss_list and isinstance(cvss_list, list):
                        cvss_score = cvss_list[0].get('metrics', {}).get('baseScore')
                
                # Extract IDs - Grype provides both in different fields
                vuln_id = vuln.get('id', 'UNKNOWN')
                cve_id = None
                ghsa_id = None
                
                # DEBUG: Print what we're working with
#                logger.debug(f"Processing vuln_id={vuln_id}")
#                logger.debug(f"aliases={vuln.get('aliases', [])}")
#                logger.debug(f"relatedVulnerabilities={[r.get('id') if isinstance(r, dict) else r for r in vuln.get('relatedVulnerabilities', [])]}")
                
                # Primary ID (could be CVE or GHSA)
                if vuln_id.startswith('CVE-'):
                    cve_id = vuln_id
                elif vuln_id.startswith('GHSA-'):
                    ghsa_id = vuln_id
                
                # Check aliases field (Grype often puts CVE here when GHSA is primary)
                aliases = vuln.get('aliases', [])
                if aliases:
                    for alias in aliases:
                        if isinstance(alias, str):
                            if alias.startswith('CVE-') and not cve_id:
                                cve_id = alias
                                logger.debug(f"Found CVE in aliases: {cve_id}")
                            elif alias.startswith('GHSA-') and not ghsa_id:
                                ghsa_id = alias
                                logger.debug(f"Found GHSA in aliases: {ghsa_id}")
                
                # Also check relatedVulnerabilities (MAIN SOURCE - array of objects!)
                related = vuln.get('relatedVulnerabilities', [])
                if related:
                    for rel in related:
                        # relatedVulnerabilities is an array of objects: [{id: "CVE-...", ...}]
                        if isinstance(rel, dict):
                            rel_id = rel.get('id', '')
                        else:
                            rel_id = rel  # Fallback if it's a string
                        
                        if rel_id.startswith('CVE-') and not cve_id:
                            cve_id = rel_id
                            logger.debug(f"Found CVE in relatedVulnerabilities: {cve_id}")
                        elif rel_id.startswith('GHSA-') and not ghsa_id:
                            ghsa_id = rel_id
                            logger.debug(f"Found GHSA in relatedVulnerabilities: {ghsa_id}")
                
#                logger.debug(f"Final result - cve_id={cve_id}, ghsa_id={ghsa_id}")
                
                # Create display ID in natural order
                if cve_id and ghsa_id:
                    # Show both in natural order (primary first)
                    if vuln_id.startswith('GHSA-'):
                        display_id = f"{vuln_id} (CVE: {cve_id})"
                    else:
                        display_id = f"{vuln_id} (GHSA: {ghsa_id})"
                else:
                    display_id = vuln_id
                
                cve_record = {
                    'id': vuln_id,
                    'cve_id': cve_id,
                    'ghsa_id': ghsa_id,
                    'display_id': display_id,  # For dashboard/reports
                    'severity': vuln.get('severity', 'UNKNOWN').upper(),
                    'cvss_score': cvss_score or 0.0,
                    'description': description[:1000] if description else 'No description available',
                    'fix_status': fix_status,
                    'fix_version': fix_version,
                    'package': artifact.get('name', 'unknown'),
                    'version': artifact.get('version', 'unknown'),
                    'file_path': file_path or 'unknown',
                    'scanner': 'grype',
                    'title': f"{display_id} in {artifact.get('name', 'package')} {artifact.get('version', '')}"
                }
                
                # Ensure all fields
                self._ensure_cve_fields(cve_record)
                cves.append(cve_record)
        
        elif 'reachable_cves' in vulns_data or 'unreachable_cves' in vulns_data:
            # Legacy format
            for cve_id, data in vulns_data.get('reachable_cves', {}).items():
                data['id'] = cve_id
                data['is_reachable'] = True
                self._ensure_cve_fields(data)
                cves.append(data)
            for cve_id, data in vulns_data.get('unreachable_cves', {}).items():
                data['id'] = cve_id
                data['is_reachable'] = False
                self._ensure_cve_fields(data)
                cves.append(data)
        
        return cves

    def _save_enrichment_json(self, enriched_cves: List[Dict], suffix: str = ''):
        """Save enrichment.json for debugging/audit."""
        if not self._current_scan_id:
            return
        
        # Get scan directory
        scan_dir = self._get_current_scan_dir()
        if not scan_dir:
            return
        
        raw_dir = scan_dir / 'raw'
        raw_dir.mkdir(exist_ok=True)
        
        # Save file
        enrichment_file = raw_dir / f'enrichment{suffix}.json'
        
        from datetime import datetime
        import json
        
        with open(enrichment_file, 'w') as f:
            json.dump({
                'metadata': {
                    'version': '1.0.0',
                    'timestamp': datetime.utcnow().isoformat(),
                    'total_cves': len(enriched_cves),
                    'storage_mode': 'enrichment'
                },
                'cves': enriched_cves
            }, f, indent=2)
        
        logger.info(f"   ✓ raw/enrichment{suffix}.json ({len(enriched_cves)} CVEs)")

    def _get_current_scan_dir(self) -> Optional[Path]:
        """Get current scan directory from database."""
        if not self._current_scan_id:
            return None
        
        try:
            cursor = self.conn.cursor()
            cursor.execute("SELECT output_dir FROM scans WHERE id = ?", (self._current_scan_id,))
            row = cursor.fetchone()
            if row and row['output_dir']:
                return Path(row['output_dir'])
        except Exception:
            pass
        
        return None

    def _store_cves_legacy(self, vulns_data: Dict[str, Any]) -> int:
        """
        LEGACY: Two-pass storage (existing implementation).
        
        This is the ORIGINAL store_cves() code, just renamed.
        P2.20: CRITICAL - Ensure ALL fields populated for customer-facing quality.
        P2.21: CRITICAL - Extract CVE/GHSA dual IDs for ALL input formats.
        """
        # Use shared parser to avoid duplication (and double-insertion!)
        cves = self._parse_grype_vulns(vulns_data)
        
        # P2.21: Enrich any CVEs that need it
        for cve in cves:
            if not cve.get('ghsa_id') and not cve.get('display_id'):
                self._enrich_cve_with_p221(cve)
            self._ensure_cve_fields(cve)
        
        return self.store_findings(cves, 'cve')
    
    def _ensure_cve_fields(self, cve: Dict[str, Any]):
        """P2.20: Ensure all required CVE fields are populated with defaults if missing."""
        cve.setdefault('id', 'UNKNOWN')
        cve.setdefault('severity', 'UNKNOWN')
        cve.setdefault('cvss_score', 0.0)
        cve.setdefault('description', 'No description available')
        cve.setdefault('fix_status', 'unknown')
        cve.setdefault('fix_version', None)
        cve.setdefault('package', 'unknown')
        cve.setdefault('version', 'unknown')
        cve.setdefault('file_path', 'unknown')
        cve.setdefault('scanner', 'grype')
        if not cve.get('title'):
            cve['title'] = f"{cve['id']} in {cve['package']} {cve['version']}"
    
    def enrich_cve_fix_data(self) -> int:
        """
        P2.20: Enrich CVE findings with fix data from raw_data field.
        Safety net to populate missing fix_status/fix_version after initial storage.
        """
        if not self._current_scan_id:
            return 0
        
        cursor = self.conn.cursor()
        
        # Find CVEs with missing fix data
        cursor.execute("""
            SELECT id, raw_data, finding_id, package_name, package_version 
            FROM findings 
            WHERE scan_id = ? 
            AND finding_type = 'cve' 
            AND (fix_status IS NULL OR fix_status = '' OR fix_status = 'unknown')
            AND raw_data IS NOT NULL
        """, (self._current_scan_id,))
        
        updates = []
        for row in cursor.fetchall():
            try:
                raw = json.loads(row['raw_data'])
                fix_info = raw.get('fix', raw.get('vulnerability', {}).get('fix', {}))
                
                if fix_info:
                    fix_versions = fix_info.get('versions', [])
                    fix_state = fix_info.get('state', 'unknown')
                    
                    if fix_state == 'fixed' and fix_versions:
                        status = 'fix_available'
                        version = ', '.join(fix_versions)
                    elif fix_state == 'wont-fix':
                        status = 'wont_fix'
                        version = None
                    else:
                        status = 'no_fix'
                        version = None
                    
                    # Also ensure description and title are populated
                    description = raw.get('description') or raw.get('vulnerability', {}).get('description') or 'No description available'
                    title = f"{row['finding_id']} in {row['package_name']} {row['package_version']}"
                    
                    updates.append((status, version, description[:1000], title[:500], row['id']))
            except Exception:
                continue
        
        if updates:
            cursor.executemany("""
                UPDATE findings 
                SET fix_status = ?, fix_version = ?, description = ?, title = ?
                WHERE id = ?
            """, updates)
            self.conn.commit()
            
            # LOG: Track enrichment updates
            logger.info(f"📊 DB UPDATE [CVE_ENRICH]: {len(updates)} CVEs enriched with fix data")
            
            return len(updates)
        return 0
    
    # =========================================================================
    # CACHE MANAGEMENT
    # =========================================================================
    
    def get_cached_sbom(self, commit_hash: str) -> Optional[Dict]:
        """Get cached SBOM for commit if exists."""
        cursor = self.conn.cursor()
        cursor.execute("""
            SELECT sbom_data FROM sbom_cache WHERE commit_hash = ?
        """, (commit_hash,))
        
        row = cursor.fetchone()
        if row and row['sbom_data']:
            try:
                return json.loads(gzip.decompress(row['sbom_data']).decode())
            except:
                return None
        return None
    
    def cache_sbom(self, commit_hash: str, sbom_data: Dict, sbom_format: str = 'cyclonedx'):
        """Cache SBOM for commit."""
        compressed = gzip.compress(json.dumps(sbom_data).encode())
        package_count = len(sbom_data.get('components', sbom_data.get('packages', [])))
        
        self.conn.execute("""
            INSERT OR REPLACE INTO sbom_cache (commit_hash, sbom_format, sbom_data, package_count)
            VALUES (?, ?, ?, ?)
        """, (commit_hash, sbom_format, compressed, package_count))
        self.conn.commit()
    
    def get_cached_call_graph(self, commit_hash: str, source_hash: str) -> Optional[Dict]:
        """Get cached call graph if exists."""
        cursor = self.conn.cursor()
        cursor.execute("""
            SELECT graph_data FROM call_graph_cache 
            WHERE commit_hash = ? AND source_hash = ?
        """, (commit_hash, source_hash))
        
        row = cursor.fetchone()
        if row and row['graph_data']:
            try:
                return json.loads(gzip.decompress(row['graph_data']).decode())
            except:
                return None
        return None
    
    def cache_call_graph(self, commit_hash: str, source_hash: str, graph_data: Dict):
        """Cache call graph."""
        compressed = gzip.compress(json.dumps(graph_data).encode())
        function_count = len(graph_data.get('functions', graph_data.get('nodes', [])))
        edge_count = len(graph_data.get('calls', graph_data.get('edges', [])))
        
        self.conn.execute("""
            INSERT OR REPLACE INTO call_graph_cache 
            (commit_hash, source_hash, graph_data, function_count, edge_count)
            VALUES (?, ?, ?, ?, ?)
        """, (commit_hash, source_hash, compressed, function_count, edge_count))
        self.conn.commit()
    
    # =========================================================================
    # LARGE OBJECT STORAGE
    # =========================================================================
    
    def store_large_object(self, object_type: str, data: Any, compress: bool = True) -> Dict:
        """
        Store large object with compression.
        
        Args:
            object_type: 'report', 'correlation', 'vulns', etc.
            data: Data to store (will be JSON serialized)
            compress: Whether to gzip compress
            
        Returns:
            Dict with storage stats
        """
        if not self._current_scan_id:
            return {}
        
        json_data = json.dumps(data) if not isinstance(data, (str, bytes)) else data
        if isinstance(json_data, str):
            json_data = json_data.encode()
        
        original_size = len(json_data)
        
        if compress:
            compressed_data = gzip.compress(json_data)
            compression = 'gzip'
        else:
            compressed_data = json_data
            compression = 'none'
        
        compressed_size = len(compressed_data)
        
        self.conn.execute("""
            INSERT OR REPLACE INTO large_objects 
            (scan_id, object_type, compression, size_original, size_compressed, data)
            VALUES (?, ?, ?, ?, ?, ?)
        """, (self._current_scan_id, object_type, compression, original_size, compressed_size, compressed_data))
        self.conn.commit()
        
        ratio = (1 - compressed_size / original_size) * 100 if original_size > 0 else 0
        return {
            'original_size': original_size,
            'compressed_size': compressed_size,
            'compression_ratio': f"{ratio:.1f}%"
        }
    
    def get_large_object(self, object_type: str, scan_id: int = None) -> Optional[Any]:
        """Retrieve large object."""
        scan_id = scan_id or self._current_scan_id
        if not scan_id:
            return None
        
        cursor = self.conn.cursor()
        cursor.execute("""
            SELECT data, compression FROM large_objects 
            WHERE scan_id = ? AND object_type = ?
        """, (scan_id, object_type))
        
        row = cursor.fetchone()
        if row:
            data = row['data']
            if row['compression'] == 'gzip':
                data = gzip.decompress(data)
            return json.loads(data.decode())
        return None
    
    # =========================================================================
    # METRICS
    # =========================================================================
    
    def store_metrics(self, metrics: Dict[str, Any]):
        """Store scan metrics."""
        if not self._current_scan_id:
            return
        
        batch_data = []
        for metric_type, values in metrics.items():
            if isinstance(values, dict):
                for name, value in values.items():
                    if isinstance(value, (int, float)):
                        batch_data.append((self._current_scan_id, metric_type, name, value, None))
            elif isinstance(values, (int, float)):
                batch_data.append((self._current_scan_id, 'general', metric_type, values, None))
        
        if batch_data:
            self.conn.executemany("""
                INSERT INTO metrics (scan_id, metric_type, metric_name, metric_value, metadata)
                VALUES (?, ?, ?, ?, ?)
            """, batch_data)
            self.conn.commit()
    
    # =========================================================================
    # RETENTION & CLEANUP
    # =========================================================================
    
    def cleanup_old_scans(self, branch: str = None, 
                         max_scans: int = None, 
                         max_age_days: int = None) -> Dict[str, int]:
        """
        Clean up old scan data.
        
        Args:
            branch: Specific branch to clean (None = all)
            max_scans: Keep only this many scans per branch
            max_age_days: Delete scans older than this
            
        Returns:
            Dict with cleanup stats
        """
        max_scans = max_scans or self.MAX_SCANS_PER_BRANCH
        max_age_days = max_age_days or self.MAX_SCAN_AGE_DAYS
        
        # v4.6.x: Capture trends snapshot BEFORE pruning
        try:
            from .trends import TrendsTracker
            tracker = TrendsTracker(self.db_path)
            tracker.capture_snapshot()
            tracker.close()
        except Exception as e:
            logger.debug(f"Trends capture failed: {e}")
        
        cursor = self.conn.cursor()
        deleted_scans = 0
        deleted_findings = 0
        
        # Get branches to process
        if branch:
            branches = [branch]
        else:
            cursor.execute("SELECT DISTINCT branch FROM scans")
            branches = [row['branch'] for row in cursor.fetchall()]
        
        for br in branches:
            # Delete by count (keep last N)
            cursor.execute("""
                SELECT id FROM scans 
                WHERE branch = ? AND status = 'complete'
                ORDER BY timestamp DESC
                LIMIT -1 OFFSET ?
            """, (br, max_scans))
            
            old_ids = [row['id'] for row in cursor.fetchall()]
            
            # Delete by age
            cutoff = datetime.now() - timedelta(days=max_age_days)
            cursor.execute("""
                SELECT id FROM scans 
                WHERE branch = ? AND timestamp < ?
            """, (br, cutoff.isoformat()))
            
            old_ids.extend([row['id'] for row in cursor.fetchall()])
            old_ids = list(set(old_ids))  # Dedupe
            
            if old_ids:
                # Count findings to delete
                placeholders = ','.join('?' * len(old_ids))
                cursor.execute(f"""
                    SELECT COUNT(*) as cnt FROM findings WHERE scan_id IN ({placeholders})
                """, old_ids)
                deleted_findings += cursor.fetchone()['cnt']
                
                # Delete (CASCADE will handle findings, large_objects, metrics)
                cursor.execute(f"""
                    DELETE FROM scans WHERE id IN ({placeholders})
                """, old_ids)
                deleted_scans += cursor.rowcount
        
        # Clean up orphaned cache entries (older than 30 days, not used)
        cursor.execute("""
            DELETE FROM sbom_cache 
            WHERE created_at < datetime('now', '-30 days')
            AND commit_hash NOT IN (SELECT DISTINCT commit_hash FROM scans)
        """)
        
        cursor.execute("""
            DELETE FROM call_graph_cache 
            WHERE created_at < datetime('now', '-30 days')
        """)
        
        self.conn.commit()
        
        # Reclaim space
        self.conn.execute("VACUUM")
        
        return {
            'scans_deleted': deleted_scans,
            'findings_deleted': deleted_findings
        }
    
    # =========================================================================
    # QUERY HELPERS
    # =========================================================================
    
    def get_scan_history(self, branch: str = None, limit: int = 10) -> List[Dict]:
        """Get scan history for branch."""
        cursor = self.conn.cursor()
        
        if branch:
            cursor.execute("""
                SELECT * FROM scans WHERE branch = ? ORDER BY timestamp DESC LIMIT ?
            """, (branch, limit))
        else:
            cursor.execute("""
                SELECT * FROM scans ORDER BY timestamp DESC LIMIT ?
            """, (limit,))
        
        return [dict(row) for row in cursor.fetchall()]
    
    def get_findings_summary(self, scan_id: int = None) -> Dict[str, Any]:
        """Get findings summary for scan."""
        scan_id = scan_id or self._current_scan_id
        if not scan_id:
            return {}
        
        cursor = self.conn.cursor()
        cursor.execute("""
            SELECT 
                finding_type,
                COUNT(*) as total,
                SUM(CASE WHEN app_reachability = 'REACHABLE' THEN 1 ELSE 0 END) as reachable,
                SUM(CASE WHEN severity = 'CRITICAL' THEN 1 ELSE 0 END) as critical,
                SUM(CASE WHEN severity = 'HIGH' THEN 1 ELSE 0 END) as high
            FROM findings 
            WHERE scan_id = ?
            GROUP BY finding_type
        """, (scan_id,))
        
        return {row['finding_type']: dict(row) for row in cursor.fetchall()}
    
    def get_findings(self, scan_id: int = None, 
                    finding_type: str = None,
                    reachable_only: bool = False) -> List[Dict]:
        """Get findings with optional filters."""
        scan_id = scan_id or self._current_scan_id
        if not scan_id:
            return []
        
        query = "SELECT * FROM findings WHERE scan_id = ?"
        params = [scan_id]
        
        if finding_type:
            query += " AND finding_type = ?"
            params.append(finding_type)
        
        if reachable_only:
            query += " AND app_reachability = 'REACHABLE'"
        
        cursor = self.conn.cursor()
        cursor.execute(query, params)
        
        return [dict(row) for row in cursor.fetchall()]
    
    def get_database_stats(self) -> Dict[str, Any]:
        """Get database statistics."""
        cursor = self.conn.cursor()
        
        stats = {}
        
        # Table sizes
        for table in ['scans', 'findings', 'sbom_cache', 'call_graph_cache', 'large_objects']:
            cursor.execute(f"SELECT COUNT(*) as cnt FROM {table}")
            stats[f'{table}_count'] = cursor.fetchone()['cnt']
        
        # Database file size
        stats['db_size_bytes'] = self.db_path.stat().st_size if self.db_path.exists() else 0
        stats['db_size_mb'] = stats['db_size_bytes'] / (1024 * 1024)
        
        return stats
    
    # =========================================================================
    # EXPORT
    # =========================================================================
    
    def export_scan_report(self, scan_id: int = None) -> Dict[str, Any]:
        """Export complete scan report as JSON."""
        scan_id = scan_id or self._current_scan_id
        if not scan_id:
            return {}
        
        cursor = self.conn.cursor()
        
        # Get scan metadata
        cursor.execute("SELECT * FROM scans WHERE id = ?", (scan_id,))
        scan = dict(cursor.fetchone()) if cursor.fetchone() else {}
        
        # Get all findings
        cursor.execute("SELECT * FROM findings WHERE scan_id = ?", (scan_id,))
        findings = [dict(row) for row in cursor.fetchall()]
        
        # Get large objects
        large_objects = {}
        for obj_type in ['correlation', 'vulns']:
            obj = self.get_large_object(obj_type, scan_id)
            if obj:
                large_objects[obj_type] = obj
        
        return {
            'scan': scan,
            'findings': findings,
            **large_objects
        }
    
    # =========================================================================
    # LIFECYCLE
    # =========================================================================
    
    def optimize(self):
        """Optimize database."""
        self.conn.execute("VACUUM")
        self.conn.execute("ANALYZE")
        self.conn.commit()
    
    def close(self):
        """Close database connection."""
        if self.conn:
            self.conn.close()
            self.conn = None

# =============================================================================
# HELPER FUNCTIONS
# =============================================================================

def get_repo_db_path(repo_path: str, reachable_home: Path = None) -> Path:
    """
    Get the path to repo.db for a repository.
    
    Structure: ~/.reachable/scans/{repo-slug}/repo.db
    
    Uses the SAME slug calculation as output_manager.py to ensure
    scan directories and repo.db are in the same location.
    
    The repo.db is shared across all branches of the same repository.
    The `scans` table has a `branch` column to differentiate scans.
    """
    if reachable_home is None:
        reachable_home = Path.home() / '.reachable'
    
    # Import get_repo_slug to ensure consistent path calculation
    # This avoids the bug where database_storage used MD5 but output_manager used SHA256
    from .output_manager import get_repo_slug
    
    repo_slug = get_repo_slug(str(repo_path))
    
    return reachable_home / 'scans' / repo_slug / 'repo.db'

def compute_source_hash(source_dir: Path, extensions: List[str] = None) -> str:
    """Compute hash of source files for cache invalidation."""
    extensions = extensions or ['.py', '.js', '.ts', '.go', '.java', '.kt']
    
    hasher = hashlib.md5()
    
    for ext in extensions:
        for f in sorted(source_dir.rglob(f'*{ext}')):
            try:
                hasher.update(f.read_bytes())
            except:
                pass
    
    return hasher.hexdigest()[:16]

# =============================================================================
# BACKWARD COMPATIBILITY
# =============================================================================

class DatabaseStorage(RepoDatabase):
    """
    Backward compatibility wrapper.
    
    Maps old per-scan DatabaseStorage API to new per-repo RepoDatabase.
    """
    
    def __init__(self, db_path: Path):
        """Initialize with backward compatibility."""
        super().__init__(db_path)
        # Auto-start a scan for compatibility
        self._current_scan_id = None
    
    def store_findings_batch(self, findings: List[Dict], finding_type: str):
        """Backward compatible batch store."""
        if not self._current_scan_id:
            # Create a default scan for backward compatibility
            self._current_scan_id = self.start_scan('default', None, str(self.db_path.parent), 'legacy')
        return self.store_findings(findings, finding_type)

if __name__ == "__main__":
    logger.info("REACHABLE v5.0.0 - Database Storage Module with v1.0 Schema")
    print("=" * 60)
    logger.info("Per-repo database architecture per DESIGN_v4.4.0.md")
    print()
    logger.info("Features:")
    logger.info("  • Per-repo database (not per-scan)")
    logger.info("  • Historical scan tracking")
    logger.info("  • SBOM/call-graph caching")
    logger.info("  • Automatic retention cleanup")
    logger.info("  • Compressed blob storage")
    logger.info("  • Two-dimensional reachability model")
