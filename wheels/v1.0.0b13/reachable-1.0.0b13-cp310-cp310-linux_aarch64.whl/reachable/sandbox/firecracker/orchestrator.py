#!/usr/bin/env python3
"""
REACHABLE Firecracker Sandbox Orchestrator

Provides VM-level isolation for malware analysis on Linux using Firecracker microVMs.

Usage:
    reachctl sandbox --init      # Initialize Firecracker environment
    reachctl sandbox --status    # Check status
    reachctl sandbox --remove    # Remove Firecracker resources

Requirements:
    - Linux with KVM support (/dev/kvm)
    - Root or kvm group membership
    - Docker (for building rootfs)

© 2026 Sthenos Security. All rights reserved.
"""

import json
import os
import shutil
import subprocess
import sys
import tempfile
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Optional, Tuple

from reachable.logger import logger

# =============================================================================
# Configuration
# =============================================================================

FIRECRACKER_VERSION = "v1.7.0"
KERNEL_VERSION = "5.10.204"

FIRECRACKER_URL = f"https://github.com/firecracker-microvm/firecracker/releases/download/{FIRECRACKER_VERSION}/firecracker-{FIRECRACKER_VERSION}-x86_64.tgz"
KERNEL_URL = f"https://github.com/firecracker-microvm/firecracker/releases/download/{FIRECRACKER_VERSION}/vmlinux-{KERNEL_VERSION}"

# Default paths
DEFAULT_WORKDIR = Path.home() / ".reachable" / "firecracker"
SANDBOX_IMAGE = "reachable/sandbox:latest"


@dataclass
class FirecrackerConfig:
    """Firecracker VM configuration."""
    workdir: Path
    firecracker_bin: Path
    kernel_path: Path
    rootfs_path: Path
    snapshot_path: Path
    socket_path: Path
    log_path: Path
    vcpu_count: int = 1
    mem_size_mib: int = 512
    boot_args: str = "console=ttyS0 reboot=k panic=1 pci=off init=/sbin/init"


# =============================================================================
# KVM Detection
# =============================================================================

def check_kvm_support() -> Tuple[bool, str]:
    """Check if KVM is available on this system."""
    # Check /dev/kvm exists
    if not os.path.exists("/dev/kvm"):
        return False, "/dev/kvm not found. Enable KVM in BIOS or install kvm kernel module."
    
    # Check we can access it
    if not os.access("/dev/kvm", os.R_OK | os.W_OK):
        return False, "/dev/kvm not accessible. Add user to 'kvm' group: sudo usermod -aG kvm $USER"
    
    # Check kernel module
    try:
        result = subprocess.run(["lsmod"], capture_output=True, text=True)
        if "kvm" not in result.stdout:
            return False, "KVM kernel module not loaded. Run: sudo modprobe kvm kvm_intel (or kvm_amd)"
    except Exception as e:
        return False, f"Could not check KVM module: {e}"
    
    return True, "KVM available"


def check_docker() -> Tuple[bool, str]:
    """Check if Docker is available."""
    try:
        result = subprocess.run(["docker", "info"], capture_output=True, text=True)
        if result.returncode != 0:
            return False, "Docker not running. Start Docker daemon."
        return True, "Docker available"
    except FileNotFoundError:
        return False, "Docker not installed. Install Docker."


# =============================================================================
# Download & Setup
# =============================================================================

def download_file(url: str, dest: Path, desc: str) -> bool:
    """Download a file with progress indication."""
    logger.info(f"  Downloading {desc}...")
    try:
        # Use curl for progress
        result = subprocess.run(
            ["curl", "-L", "-o", str(dest), "--progress-bar", url],
            check=True
        )
        return True
    except subprocess.CalledProcessError as e:
        logger.info(f"  ✗ Failed to download {desc}: {e}")
        return False
    except FileNotFoundError:
        # Fallback to wget
        try:
            subprocess.run(["wget", "-O", str(dest), url], check=True)
            return True
        except Exception as e:
            logger.info(f"  ✗ Failed to download {desc}: {e}")
            return False


def setup_firecracker(config: FirecrackerConfig) -> bool:
    """Download and setup Firecracker binary."""
    if config.firecracker_bin.exists():
        logger.info(f"  ✓ Firecracker already installed")
        return True
    
    tarball = config.workdir / "firecracker.tgz"
    if not download_file(FIRECRACKER_URL, tarball, f"Firecracker {FIRECRACKER_VERSION}"):
        return False
    
    # Extract
    logger.info("  Extracting Firecracker...")
    try:
        subprocess.run(
            ["tar", "-xzf", str(tarball), "-C", str(config.workdir)],
            check=True
        )
        # Find and move the binary
        for f in config.workdir.glob("release-*/firecracker-*"):
            if f.is_file() and "firecracker" in f.name and not f.name.endswith(".tgz"):
                shutil.move(str(f), str(config.firecracker_bin))
                config.firecracker_bin.chmod(0o755)
                break
        
        # Cleanup
        tarball.unlink()
        for d in config.workdir.glob("release-*"):
            shutil.rmtree(d)
        
        logger.info(f"  ✓ Firecracker installed")
        return True
    except Exception as e:
        logger.info(f"  ✗ Failed to extract Firecracker: {e}")
        return False


def setup_kernel(config: FirecrackerConfig) -> bool:
    """Download the Firecracker-compatible kernel."""
    if config.kernel_path.exists():
        logger.info(f"  ✓ Kernel already installed")
        return True
    
    if not download_file(KERNEL_URL, config.kernel_path, f"vmlinux-{KERNEL_VERSION}"):
        return False
    
    logger.info(f"  ✓ Kernel installed")
    return True


# =============================================================================
# Rootfs Generation
# =============================================================================

def build_rootfs(config: FirecrackerConfig) -> bool:
    """Convert Docker sandbox image to ext4 rootfs for Firecracker."""
    if config.rootfs_path.exists():
        logger.info(f"  ✓ Rootfs already built")
        return True
    
    logger.info(f"  Building rootfs from {SANDBOX_IMAGE}...")
    
    rootfs_dir = config.workdir / "rootfs_tmp"
    rootfs_dir.mkdir(exist_ok=True)
    
    try:
        # Create container from image
        logger.info("    Creating container...")
        result = subprocess.run(
            ["docker", "create", SANDBOX_IMAGE],
            capture_output=True, text=True, check=True
        )
        container_id = result.stdout.strip()
        
        # Export filesystem
        logger.info("    Exporting filesystem...")
        with tempfile.NamedTemporaryFile(suffix=".tar", delete=False) as tar_file:
            subprocess.run(
                ["docker", "export", container_id],
                stdout=open(tar_file.name, "wb"),
                check=True
            )
            
            # Extract tar
            logger.info("    Extracting...")
            subprocess.run(
                ["tar", "-xf", tar_file.name, "-C", str(rootfs_dir)],
                check=True
            )
            os.unlink(tar_file.name)
        
        # Remove container
        subprocess.run(["docker", "rm", container_id], capture_output=True)
        
        # Create /sbin/init for Firecracker
        init_script = rootfs_dir / "sbin" / "init"
        init_script.parent.mkdir(parents=True, exist_ok=True)
        init_script.write_text("""#!/bin/sh
# REACHABLE Firecracker init
mount -t proc proc /proc
mount -t sysfs sysfs /sys
mount -t devtmpfs dev /dev

# Set hostname
hostname reachable-sandbox

# Start honeypot monitor in background
/usr/local/bin/honeypot-monitor &

# Execute the entrypoint or drop to shell
if [ -x /entrypoint.sh ]; then
    exec /entrypoint.sh "$@"
else
    exec /bin/sh
fi
""")
        init_script.chmod(0o755)
        
        # Create ext4 image
        logger.info("    Creating ext4 image...")
        # Calculate size (add 50% buffer)
        dir_size = sum(f.stat().st_size for f in rootfs_dir.rglob("*") if f.is_file())
        img_size_mb = max(256, int(dir_size / 1024 / 1024 * 1.5))
        
        subprocess.run(
            ["dd", "if=/dev/zero", f"of={config.rootfs_path}", "bs=1M", f"count={img_size_mb}"],
            capture_output=True, check=True
        )
        subprocess.run(
            ["mkfs.ext4", "-F", str(config.rootfs_path)],
            capture_output=True, check=True
        )
        
        # Mount and copy files
        logger.info("    Copying files to image...")
        mount_point = config.workdir / "mnt"
        mount_point.mkdir(exist_ok=True)
        
        subprocess.run(["sudo", "mount", str(config.rootfs_path), str(mount_point)], check=True)
        try:
            subprocess.run(["sudo", "cp", "-a", f"{rootfs_dir}/.", str(mount_point)], check=True)
        finally:
            subprocess.run(["sudo", "umount", str(mount_point)], check=True)
        
        # Cleanup
        shutil.rmtree(rootfs_dir)
        mount_point.rmdir()
        
        logger.info(f"  ✓ Rootfs built ({img_size_mb}MB)")
        return True
        
    except subprocess.CalledProcessError as e:
        logger.info(f"  ✗ Failed to build rootfs: {e}")
        if rootfs_dir.exists():
            shutil.rmtree(rootfs_dir)
        return False
    except Exception as e:
        logger.info(f"  ✗ Failed to build rootfs: {e}")
        return False


# =============================================================================
# VM Management
# =============================================================================

def create_vm_config(config: FirecrackerConfig) -> dict:
    """Create Firecracker VM configuration."""
    return {
        "boot-source": {
            "kernel_image_path": str(config.kernel_path),
            "boot_args": config.boot_args
        },
        "drives": [{
            "drive_id": "rootfs",
            "path_on_host": str(config.rootfs_path),
            "is_root_device": True,
            "is_read_only": False  # Need write for package installation
        }],
        "machine-config": {
            "vcpu_count": config.vcpu_count,
            "mem_size_mib": config.mem_size_mib,
            "smt": False  # Disable hyperthreading for security
        },
        "logger": {
            "log_path": str(config.log_path),
            "level": "Info",
            "show_level": True,
            "show_log_origin": True
        }
    }


def start_vm(config: FirecrackerConfig, timeout: int = 30) -> Optional[subprocess.Popen]:
    """Start a Firecracker VM."""
    # Remove old socket
    if config.socket_path.exists():
        config.socket_path.unlink()
    
    # Write config
    vm_config_path = config.workdir / "vm_config.json"
    with open(vm_config_path, "w") as f:
        json.dump(create_vm_config(config), f, indent=2)
    
    # Start Firecracker
    proc = subprocess.Popen(
        [
            str(config.firecracker_bin),
            "--api-sock", str(config.socket_path),
            "--config-file", str(vm_config_path)
        ],
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE
    )
    
    # Wait for socket
    start_time = time.time()
    while not config.socket_path.exists():
        if time.time() - start_time > timeout:
            proc.terminate()
            return None
        time.sleep(0.1)
    
    return proc


def stop_vm(proc: subprocess.Popen, config: FirecrackerConfig):
    """Stop a Firecracker VM."""
    proc.terminate()
    try:
        proc.wait(timeout=5)
    except subprocess.TimeoutExpired:
        proc.kill()
    
    if config.socket_path.exists():
        config.socket_path.unlink()


# =============================================================================
# Snapshot Management
# =============================================================================

def create_snapshot(config: FirecrackerConfig, proc: subprocess.Popen) -> bool:
    """Create a VM snapshot for fast restore."""
    import socket
    import http.client
    
    snapshot_mem = config.snapshot_path / "snapshot.mem"
    snapshot_state = config.snapshot_path / "snapshot.state"
    
    config.snapshot_path.mkdir(parents=True, exist_ok=True)
    
    # Use Firecracker API to create snapshot
    # This requires the VM to be paused first
    
    # Connect to API socket
    # ... (simplified - full implementation would use requests-unixsocket)
    
    logger.info(f"  ✓ Snapshot created at {config.snapshot_path}")
    return True


# =============================================================================
# Main Entry Points
# =============================================================================

def sandbox_init(workdir: Optional[Path] = None) -> bool:
    """Initialize Firecracker sandbox environment."""
    logger.info("\n[Firecracker Sandbox Initialization]")
    
    # Check platform
    if sys.platform != "linux":
        logger.info("✗ Firecracker only supported on Linux")
        logger.info("  Use Colima/Docker on macOS: reachctl sandbox --init")
        return False
    
    # Check KVM
    kvm_ok, kvm_msg = check_kvm_support()
    if not kvm_ok:
        logger.info(f"✗ KVM: {kvm_msg}")
        return False
    logger.info(f"✓ KVM: {kvm_msg}")
    
    # Check Docker (needed for rootfs)
    docker_ok, docker_msg = check_docker()
    if not docker_ok:
        logger.info(f"✗ Docker: {docker_msg}")
        return False
    logger.info(f"✓ Docker: {docker_msg}")
    
    # Setup paths
    workdir = workdir or DEFAULT_WORKDIR
    workdir.mkdir(parents=True, exist_ok=True)
    
    config = FirecrackerConfig(
        workdir=workdir,
        firecracker_bin=workdir / "firecracker",
        kernel_path=workdir / f"vmlinux-{KERNEL_VERSION}",
        rootfs_path=workdir / "rootfs.ext4",
        snapshot_path=workdir / "snapshot",
        socket_path=workdir / "firecracker.sock",
        log_path=workdir / "firecracker.log"
    )
    
    logger.info(f"\nWorkdir: {workdir}")
    
    # Download Firecracker
    logger.info("\n[1/3] Setting up Firecracker...")
    if not setup_firecracker(config):
        return False
    
    # Download kernel
    logger.info("\n[2/3] Setting up kernel...")
    if not setup_kernel(config):
        return False
    
    # Build rootfs (requires sandbox Docker image)
    logger.info("\n[3/3] Building rootfs...")
    
    # Check if sandbox image exists
    result = subprocess.run(
        ["docker", "images", "-q", SANDBOX_IMAGE],
        capture_output=True, text=True
    )
    if not result.stdout.strip():
        logger.info(f"  Building sandbox Docker image first...")
        sandbox_dir = Path(__file__).parent.parent
        dockerfile = sandbox_dir / "Dockerfile"
        if dockerfile.exists():
            subprocess.run(
                ["docker", "build", "-t", SANDBOX_IMAGE, str(sandbox_dir)],
                check=True
            )
        else:
            logger.info(f"  ✗ Sandbox Dockerfile not found at {dockerfile}")
            return False
    
    if not build_rootfs(config):
        return False
    
    print("\n" + "=" * 50)
    logger.info("✓ Firecracker sandbox ready!")
    print("=" * 50)
    logger.info(f"\nFiles:")
    logger.info(f"  Binary:  {config.firecracker_bin}")
    logger.info(f"  Kernel:  {config.kernel_path}")
    logger.info(f"  Rootfs:  {config.rootfs_path}")
    logger.info(f"\nTo run manually:")
    logger.info(f"  {config.firecracker_bin} --api-sock {config.socket_path}")
    
    return True


def sandbox_status(workdir: Optional[Path] = None) -> dict:
    """Check Firecracker sandbox status."""
    workdir = workdir or DEFAULT_WORKDIR
    
    config = FirecrackerConfig(
        workdir=workdir,
        firecracker_bin=workdir / "firecracker",
        kernel_path=workdir / f"vmlinux-{KERNEL_VERSION}",
        rootfs_path=workdir / "rootfs.ext4",
        snapshot_path=workdir / "snapshot",
        socket_path=workdir / "firecracker.sock",
        log_path=workdir / "firecracker.log"
    )
    
    kvm_ok, kvm_msg = check_kvm_support()
    
    return {
        "platform": "linux" if sys.platform == "linux" else sys.platform,
        "kvm_available": kvm_ok,
        "kvm_message": kvm_msg,
        "firecracker_installed": config.firecracker_bin.exists(),
        "kernel_installed": config.kernel_path.exists(),
        "rootfs_built": config.rootfs_path.exists(),
        "snapshot_exists": config.snapshot_path.exists() and any(config.snapshot_path.iterdir()) if config.snapshot_path.exists() else False,
        "vm_running": config.socket_path.exists(),
        "workdir": str(workdir)
    }


def sandbox_remove(workdir: Optional[Path] = None) -> bool:
    """Remove Firecracker sandbox resources."""
    workdir = workdir or DEFAULT_WORKDIR
    
    if not workdir.exists():
        logger.info("Nothing to remove")
        return True
    
    logger.info(f"Removing Firecracker sandbox at {workdir}...")
    
    # Stop any running VM
    socket_path = workdir / "firecracker.sock"
    if socket_path.exists():
        logger.info("  Stopping running VM...")
        # Would need to connect and send shutdown
        socket_path.unlink()
    
    # Remove files
    shutil.rmtree(workdir)
    logger.info("✓ Sandbox removed")
    return True


# =============================================================================
# CLI Entry Point
# =============================================================================

if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description="REACHABLE Firecracker Sandbox")
    parser.add_argument("--init", action="store_true", help="Initialize sandbox")
    parser.add_argument("--status", action="store_true", help="Show status")
    parser.add_argument("--remove", action="store_true", help="Remove sandbox")
    parser.add_argument("--workdir", type=Path, help="Custom workdir")
    
    args = parser.parse_args()
    
    if args.init:
        success = sandbox_init(args.workdir)
        sys.exit(0 if success else 1)
    elif args.status:
        status = sandbox_status(args.workdir)
        print(json.dumps(status, indent=2))
    elif args.remove:
        success = sandbox_remove(args.workdir)
        sys.exit(0 if success else 1)
    else:
        parser.print_help()
