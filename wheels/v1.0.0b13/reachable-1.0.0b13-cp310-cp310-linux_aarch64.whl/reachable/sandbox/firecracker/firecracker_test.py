#!/usr/bin/env python3
"""
REACHABLE Firecracker Sandbox - Standalone Test Script

Copy this single file to a Linux VM with KVM support and run:
    sudo python3 firecracker_test.py

This will:
1. Check KVM support
2. Download Firecracker + kernel
3. Create minimal rootfs
4. Boot a microVM
5. Run a test command
6. Collect output

No GitHub repo needed - completely self-contained.

© 2026 Sthenos Security. All rights reserved.
"""

import json
import os
import shutil
import subprocess
import sys
import tempfile
import time
from pathlib import Path

from reachable.logger import logger

# =============================================================================
# Configuration
# =============================================================================

FIRECRACKER_VERSION = "v1.7.0"
KERNEL_VERSION = "5.10.204"

FIRECRACKER_URL = f"https://github.com/firecracker-microvm/firecracker/releases/download/{FIRECRACKER_VERSION}/firecracker-{FIRECRACKER_VERSION}-x86_64.tgz"
KERNEL_URL = f"https://github.com/firecracker-microvm/firecracker/releases/download/{FIRECRACKER_VERSION}/vmlinux-{KERNEL_VERSION}"

WORKDIR = Path.home() / ".reachable-fc-test"


def run(cmd, **kwargs):
    """Run a shell command."""
    logger.info(f"  $ {cmd}")
    return subprocess.run(cmd, shell=True, check=True, **kwargs)


def check_root():
    """Check if running as root."""
    if os.geteuid() != 0:
        logger.info("✗ This script requires root privileges")
        logger.info("  Run: sudo python3 firecracker_test.py")
        return False
    return True


def check_kvm():
    """Check KVM support."""
    logger.info("\n[1/6] Checking KVM support...")
    
    if not os.path.exists("/dev/kvm"):
        logger.info("  ✗ /dev/kvm not found")
        logger.info("  Enable virtualization in BIOS/VM settings")
        logger.info("  Or run: sudo modprobe kvm kvm_intel (or kvm_amd)")
        return False
    
    if not os.access("/dev/kvm", os.R_OK | os.W_OK):
        logger.info("  ✗ /dev/kvm not accessible")
        return False
    
    logger.info("  ✓ KVM available")
    return True


def download_firecracker():
    """Download Firecracker binary."""
    logger.info("\n[2/6] Downloading Firecracker...")
    
    fc_bin = WORKDIR / "firecracker"
    if fc_bin.exists():
        logger.info("  ✓ Already downloaded")
        return fc_bin
    
    WORKDIR.mkdir(parents=True, exist_ok=True)
    tarball = WORKDIR / "firecracker.tgz"
    
    run(f"curl -L -o {tarball} {FIRECRACKER_URL}")
    run(f"tar -xzf {tarball} -C {WORKDIR}")
    
    # Find the binary
    for f in WORKDIR.glob("release-*/firecracker-*"):
        if f.is_file() and "firecracker" in f.name and not f.suffix:
            shutil.move(str(f), str(fc_bin))
            fc_bin.chmod(0o755)
            break
    
    # Cleanup
    tarball.unlink()
    for d in WORKDIR.glob("release-*"):
        shutil.rmtree(d)
    
    logger.info(f"  ✓ Firecracker {FIRECRACKER_VERSION} installed")
    return fc_bin


def download_kernel():
    """Download Firecracker-compatible kernel."""
    logger.info("\n[3/6] Downloading kernel...")
    
    kernel = WORKDIR / f"vmlinux-{KERNEL_VERSION}"
    if kernel.exists():
        logger.info("  ✓ Already downloaded")
        return kernel
    
    run(f"curl -L -o {kernel} {KERNEL_URL}")
    logger.info(f"  ✓ Kernel {KERNEL_VERSION} installed")
    return kernel


def create_rootfs():
    """Create a minimal rootfs with busybox."""
    logger.info("\n[4/6] Creating minimal rootfs...")
    
    rootfs_img = WORKDIR / "rootfs.ext4"
    if rootfs_img.exists():
        logger.info("  ✓ Already created")
        return rootfs_img
    
    rootfs_dir = WORKDIR / "rootfs"
    rootfs_dir.mkdir(exist_ok=True)
    
    # Check if busybox is available, or download static binary
    busybox_bin = rootfs_dir / "bin" / "busybox"
    (rootfs_dir / "bin").mkdir(parents=True, exist_ok=True)
    (rootfs_dir / "sbin").mkdir(parents=True, exist_ok=True)
    (rootfs_dir / "proc").mkdir(exist_ok=True)
    (rootfs_dir / "sys").mkdir(exist_ok=True)
    (rootfs_dir / "dev").mkdir(exist_ok=True)
    (rootfs_dir / "tmp").mkdir(exist_ok=True)
    
    # Download static busybox
    logger.info("  Downloading busybox...")
    run(f"curl -L -o {busybox_bin} https://busybox.net/downloads/binaries/1.35.0-x86_64-linux-musl/busybox")
    busybox_bin.chmod(0o755)
    
    # Create symlinks for common commands
    for cmd in ["sh", "ls", "cat", "echo", "sleep", "ps", "mount", "umount", "uname", "hostname"]:
        (rootfs_dir / "bin" / cmd).symlink_to("busybox")
    
    # Create init script
    init_script = rootfs_dir / "sbin" / "init"
    init_script.write_text("""#!/bin/sh
# Minimal init for Firecracker test

mount -t proc proc /proc
mount -t sysfs sysfs /sys
mount -t devtmpfs devtmpfs /dev

hostname firecracker-test

echo "========================================"
echo "REACHABLE Firecracker Sandbox Test"
echo "========================================"
echo ""
echo "Kernel: $(uname -r)"
echo "Hostname: $(hostname)"
echo "Uptime: $(cat /proc/uptime)"
echo ""
echo "SUCCESS: VM booted and init executed!"
echo ""
echo "Halting in 3 seconds..."
sleep 3

# Signal success and halt
echo "REACHABLE_TEST_COMPLETE"
poweroff -f
""")
    init_script.chmod(0o755)
    
    # Create ext4 image
    logger.info("  Creating ext4 image...")
    run(f"dd if=/dev/zero of={rootfs_img} bs=1M count=64", capture_output=True)
    run(f"mkfs.ext4 -F {rootfs_img}", capture_output=True)
    
    # Mount and copy
    mount_point = WORKDIR / "mnt"
    mount_point.mkdir(exist_ok=True)
    
    run(f"mount {rootfs_img} {mount_point}")
    try:
        run(f"cp -a {rootfs_dir}/. {mount_point}/")
    finally:
        run(f"umount {mount_point}")
    
    # Cleanup
    shutil.rmtree(rootfs_dir)
    mount_point.rmdir()
    
    logger.info("  ✓ Rootfs created (64MB)")
    return rootfs_img


def run_vm(fc_bin, kernel, rootfs):
    """Boot the Firecracker VM and capture output."""
    logger.info("\n[5/6] Starting Firecracker VM...")
    
    socket_path = WORKDIR / "firecracker.sock"
    log_path = WORKDIR / "firecracker.log"
    
    # Remove old socket
    if socket_path.exists():
        socket_path.unlink()
    
    # Create VM config
    config = {
        "boot-source": {
            "kernel_image_path": str(kernel),
            "boot_args": "console=ttyS0 reboot=k panic=1 pci=off init=/sbin/init"
        },
        "drives": [{
            "drive_id": "rootfs",
            "path_on_host": str(rootfs),
            "is_root_device": True,
            "is_read_only": True
        }],
        "machine-config": {
            "vcpu_count": 1,
            "mem_size_mib": 128,
            "smt": False
        }
    }
    
    config_path = WORKDIR / "vm_config.json"
    config_path.write_text(json.dumps(config, indent=2))
    
    logger.info(f"  Config: {config_path}")
    logger.info(f"  Socket: {socket_path}")
    logger.info("")
    print("  " + "=" * 50)
    logger.info("  VM OUTPUT:")
    print("  " + "=" * 50)
    
    # Run Firecracker (capture output)
    try:
        result = subprocess.run(
            [str(fc_bin), "--config-file", str(config_path)],
            capture_output=True,
            text=True,
            timeout=30
        )
        
        # Print VM output (serial console)
        for line in result.stdout.split('\n'):
            logger.info(f"  | {line}")
        
        if result.stderr:
            logger.info("  STDERR:")
            for line in result.stderr.split('\n'):
                logger.info(f"  | {line}")
        
        return "REACHABLE_TEST_COMPLETE" in result.stdout
        
    except subprocess.TimeoutExpired:
        logger.info("  ✗ VM timed out (30s)")
        return False
    except Exception as e:
        logger.info(f"  ✗ Error: {e}")
        return False


def print_results(success):
    """Print test results."""
    logger.info("\n[6/6] Results")
    print("=" * 60)
    
    if success:
        logger.info("✓ FIRECRACKER TEST PASSED")
        logger.info("")
        logger.info("Your Linux VM supports Firecracker microVMs!")
        logger.info("You can now use REACHABLE's dynamic malware sandbox.")
        logger.info("")
        logger.info(f"Files created in: {WORKDIR}")
        logger.info(f"  - firecracker (binary)")
        logger.info(f"  - vmlinux-{KERNEL_VERSION} (kernel)")
        logger.info(f"  - rootfs.ext4 (test filesystem)")
    else:
        logger.info("✗ FIRECRACKER TEST FAILED")
        logger.info("")
        logger.info("Check:")
        logger.info("  1. KVM is enabled (virtualization in BIOS/VM settings)")
        logger.info("  2. Nested virtualization is enabled (if running in VM)")
        logger.info("  3. Run with sudo")
    
    print("=" * 60)
    return success


def cleanup():
    """Remove test files."""
    if WORKDIR.exists():
        shutil.rmtree(WORKDIR)
        logger.info(f"Cleaned up {WORKDIR}")


def main():
    print("=" * 60)
    logger.info("REACHABLE Firecracker Sandbox Test")
    print("=" * 60)
    
    # Parse args
    if len(sys.argv) > 1 and sys.argv[1] == "--cleanup":
        cleanup()
        return 0
    
    # Check prerequisites
    if not check_root():
        return 1
    
    if not check_kvm():
        return 1
    
    # Setup
    try:
        fc_bin = download_firecracker()
        kernel = download_kernel()
        rootfs = create_rootfs()
        
        # Run test
        success = run_vm(fc_bin, kernel, rootfs)
        
        # Results
        print_results(success)
        return 0 if success else 1
        
    except subprocess.CalledProcessError as e:
        logger.info(f"\n✗ Command failed: {e}")
        return 1
    except Exception as e:
        logger.info(f"\n✗ Error: {e}")
        return 1


if __name__ == "__main__":
    sys.exit(main())
