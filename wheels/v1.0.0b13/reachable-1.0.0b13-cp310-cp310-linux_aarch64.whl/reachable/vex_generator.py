#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.

"""
VEX (Vulnerability Exploitability eXchange) Generator

Generates OpenVEX documents for compliance and supply chain communication.

VEX is used for:
- Regulatory compliance (EU Cyber Resilience Act, US EO 14028)
- Supply chain vulnerability disclosure
- SBOM enrichment with exploitability context
- Customer communication about vulnerability status

REACHABLE's advantage: Reachability analysis provides JUSTIFICATION for "not_affected" status!
"""

import json
from datetime import datetime, timezone
from typing import Dict, List, Optional
from dataclasses import dataclass
from enum import Enum
import logging

# Initialize module-level logger
logger = logging.getLogger(__name__)

class VEXStatus(Enum):
    """VEX vulnerability status"""
    NOT_AFFECTED = "not_affected"
    AFFECTED = "affected"
    FIXED = "fixed"
    UNDER_INVESTIGATION = "under_investigation"

class VEXJustification(Enum):
    """Justification for not_affected status"""
    COMPONENT_NOT_PRESENT = "component_not_present"
    VULNERABLE_CODE_NOT_PRESENT = "vulnerable_code_not_present"
    VULNERABLE_CODE_NOT_IN_EXECUTE_PATH = "vulnerable_code_not_in_execute_path"
    VULNERABLE_CODE_CANNOT_BE_CONTROLLED_BY_ADVERSARY = "vulnerable_code_cannot_be_controlled_by_adversary"
    INLINE_MITIGATIONS_ALREADY_EXIST = "inline_mitigations_already_exist"

@dataclass
class VEXProduct:
    """Product identification"""
    id: str  # PURL or CPE
    name: str
    version: str
    supplier: Optional[str] = None

@dataclass
class VEXStatement:
    """VEX statement about a vulnerability"""
    vulnerability: str  # CVE ID
    product: VEXProduct
    status: VEXStatus
    
    # For not_affected
    justification: Optional[VEXJustification] = None
    
    # For affected
    action_statement: Optional[str] = None
    action_statement_timestamp: Optional[str] = None
    
    # Impact assessment
    impact_statement: Optional[str] = None
    
    # Metadata
    last_updated: str = None
    
    def __post_init__(self):
        if self.last_updated is None:
            self.last_updated = datetime.now(timezone.utc).isoformat()

@dataclass
class VEXDocument:
    """OpenVEX document structure"""
    # Metadata
    context: str = "https://openvex.dev/ns/v0.2.0"
    id: str = None
    author: str = "REACHABLE Security Analysis"
    role: str = "Security Analyst"
    timestamp: str = None
    version: str = "1"
    
    # Statements
    statements: List[VEXStatement] = None
    
    def __post_init__(self):
        if self.id is None:
            self.id = f"vera-vex-{datetime.now(timezone.utc).strftime('%Y%m%d-%H%M%S')}"
        if self.timestamp is None:
            self.timestamp = datetime.now(timezone.utc).isoformat()
        if self.statements is None:
            self.statements = []

class VEXGenerator:
    """Generates VEX documents from REACHABLE analysis results"""
    
    def __init__(self, product_name: str, product_version: str, supplier: Optional[str] = None):
        self.product = VEXProduct(
            id=f"pkg:generic/{product_name}@{product_version}",
            name=product_name,
            version=product_version,
            supplier=supplier
        )
    
    def generate_from_vera_report(self, vera_report: Dict) -> VEXDocument:
        """
        Generate VEX document from REACHABLE analysis report
        
        Uses REACHABLE's reachability analysis to provide justification:
        - Reachable CVE → status: affected
        - Unreachable CVE → status: not_affected, justification: vulnerable_code_not_in_execute_path
        
        This is the KEY DIFFERENTIATOR: Most tools can't provide justification!
        """
        vex_doc = VEXDocument()
        
        # Process reachable CVEs (AFFECTED)
        reachable_cves = vera_report.get('reachable', {})
        for cve_id, cve_data in reachable_cves.items():
            statement = self._create_affected_statement(cve_id, cve_data)
            vex_doc.statements.append(statement)
        
        # Process unreachable CVEs (NOT_AFFECTED with justification!)
        unreachable_cves = vera_report.get('unreachable', {})
        for cve_id, cve_data in unreachable_cves.items():
            statement = self._create_not_affected_statement(cve_id, cve_data)
            vex_doc.statements.append(statement)
        
        return vex_doc
    
    def _create_affected_statement(self, cve_id: str, cve_data: Dict) -> VEXStatement:
        """Create statement for reachable (affected) CVE"""
        
        # Determine action based on verdict
        verdict = cve_data.get('verdict', {})
        verdict_name = verdict.get('name', 'UNKNOWN')
        action_time = verdict.get('action_timeline', 'Investigate immediately')
        
        # Build action statement
        action_parts = [f"Patch {cve_data.get('package')} to version {cve_data.get('fixed_in')}"]
        
        # Add exploitability context
        exploit_data = cve_data.get('exploitability', {})
        if exploit_data.get('kev', {}).get('in_catalog'):
            action_parts.append("URGENT: In CISA KEV catalog (actively exploited)")
        elif exploit_data.get('exploit_db', {}).get('exploit_available'):
            action_parts.append("Public exploit available")
        
        action_statement = f"{verdict_name}: {'. '.join(action_parts)}. Timeline: {action_time}"
        
        # Impact statement with reachability details
        app_functions = cve_data.get('app_functions', [])
        if app_functions:
            impact_statement = (
                f"Vulnerable code IS REACHABLE from application entrypoints. "
                f"Affected functions: {', '.join(app_functions[:3])}. "
                f"Risk score: {verdict.get('risk_score', 0)}/100"
            )
        else:
            impact_statement = f"Vulnerability is reachable. Risk score: {verdict.get('risk_score', 0)}/100"
        
        return VEXStatement(
            vulnerability=cve_id,
            product=self.product,
            status=VEXStatus.AFFECTED,
            action_statement=action_statement,
            action_statement_timestamp=datetime.now(timezone.utc).isoformat(),
            impact_statement=impact_statement
        )
    
    def _create_not_affected_statement(self, cve_id: str, cve_data: Dict) -> VEXStatement:
        """
        Create statement for unreachable (not_affected) CVE
        
        KEY: This provides JUSTIFICATION, which most tools can't do!
        """
        
        justification = VEXJustification.VULNERABLE_CODE_NOT_IN_EXECUTE_PATH
        
        # Impact statement explains WHY not affected
        impact_statement = (
            f"REACHABLE reachability analysis determined that vulnerable code in "
            f"{cve_data.get('package')} is NOT in any execution path from application "
            f"entrypoints. The vulnerable functions are present but unreachable, "
            f"providing 80% risk reduction for this CVE."
        )
        
        return VEXStatement(
            vulnerability=cve_id,
            product=self.product,
            status=VEXStatus.NOT_AFFECTED,
            justification=justification,
            impact_statement=impact_statement
        )
    
    def to_json(self, vex_doc: VEXDocument, indent: int = 2) -> str:
        """Convert VEX document to JSON"""
        
        # Convert to dict, handling enums and dataclasses
        def convert(obj):
            if isinstance(obj, Enum):
                return obj.value
            elif isinstance(obj, VEXProduct):
                return {
                    "@id": obj.id,
                    "name": obj.name,
                    "version": obj.version,
                    "supplier": obj.supplier
                }
            elif isinstance(obj, VEXStatement):
                stmt = {
                    "vulnerability": obj.vulnerability,
                    "products": [convert(obj.product)],
                    "status": obj.status.value,
                    "last_updated": obj.last_updated
                }
                
                if obj.justification:
                    stmt["justification"] = obj.justification.value
                if obj.action_statement:
                    stmt["action_statement"] = obj.action_statement
                    stmt["action_statement_timestamp"] = obj.action_statement_timestamp
                if obj.impact_statement:
                    stmt["impact_statement"] = obj.impact_statement
                
                return stmt
            elif isinstance(obj, VEXDocument):
                return {
                    "@context": obj.context,
                    "@id": obj.id,
                    "author": obj.author,
                    "role": obj.role,
                    "timestamp": obj.timestamp,
                    "version": obj.version,
                    "statements": [convert(stmt) for stmt in obj.statements]
                }
            return obj
        
        return json.dumps(convert(vex_doc), indent=indent)
    
    def to_file(self, vex_doc: VEXDocument, filename: str):
        """Save VEX document to file"""
        with open(filename, 'w') as f:
            f.write(self.to_json(vex_doc))

def generate_vex_from_vera(
    vera_report_file: str,
    product_name: str,
    product_version: str,
    output_file: str,
    supplier: Optional[str] = None
) -> str:
    """
    Generate VEX document from REACHABLE report
    
    Args:
        vera_report_file: Path to REACHABLE JSON report
        product_name: Your product/application name
        product_version: Your product version
        output_file: Where to save VEX document
        supplier: Optional supplier/vendor name
    
    Returns:
        Path to generated VEX file
    """
    # Load REACHABLE report
    with open(vera_report_file, 'r') as f:
        vera_report = json.load(f)
    
    # Generate VEX
    generator = VEXGenerator(product_name, product_version, supplier)
    vex_doc = generator.generate_from_vera_report(vera_report)
    
    # Save
    generator.to_file(vex_doc, output_file)
    
    return output_file

def generate_vex_summary(vex_file: str):
    """Print summary of VEX document"""
    with open(vex_file, 'r') as f:
        vex = json.load(f)
    
    print("=" * 70)
    logger.info("VEX DOCUMENT SUMMARY")
    print("=" * 70)
    print()
    logger.info(f"Document ID: {vex['@id']}")
    logger.info(f"Generated: {vex['timestamp']}")
    logger.info(f"Author: {vex['author']}")
    print()
    
    statements = vex.get('statements', [])
    
    # Count by status
    affected = sum(1 for s in statements if s['status'] == 'affected')
    not_affected = sum(1 for s in statements if s['status'] == 'not_affected')
    
    logger.info(f"📊 Vulnerability Statements: {len(statements)}")
    logger.info(f"   🚨 AFFECTED (reachable): {affected}")
    logger.info(f"   ✅ NOT_AFFECTED (unreachable): {not_affected}")
    print()
    
    if affected > 0:
        logger.info("🚨 AFFECTED VULNERABILITIES:")
        for stmt in statements:
            if stmt['status'] == 'affected':
                logger.info(f"   • {stmt['vulnerability']}")
                if 'action_statement' in stmt:
                    logger.info(f"     Action: {stmt['action_statement'][:80]}...")
        print()
    
    if not_affected > 0:
        logger.info("✅ NOT_AFFECTED (with justification):")
        for stmt in statements[:5]:
            if stmt['status'] == 'not_affected':
                logger.info(f"   • {stmt['vulnerability']}")
                if 'justification' in stmt:
                    logger.info(f"     Justification: {stmt['justification']}")
        if not_affected > 5:
            logger.info(f"   ... and {not_affected - 5} more")
        print()
    
    print("=" * 70)
    logger.info("VEX DOCUMENT READY FOR COMPLIANCE")
    print("=" * 70)
    print()
    logger.info("Use cases:")
    logger.info("  • Share with customers to explain vulnerability status")
    logger.info("  • Attach to SBOM for supply chain transparency")
    logger.info("  • Meet regulatory requirements (EU CRA, US EO 14028)")
    logger.info("  • Reduce customer security questionnaires")

if __name__ == '__main__':
    import sys
    
    if len(sys.argv) < 4:
        logger.info("Usage: python vex_generator.py <vera-report.json> <product-name> <product-version> [output.vex.json]")
        print()
        logger.info("Example:")
        logger.info("  python vex_generator.py vera-report.json MyApp 1.2.3 myapp.vex.json")
        sys.exit(1)
    
    vera_report = sys.argv[1]
    product_name = sys.argv[2]
    product_version = sys.argv[3]
    output_file = sys.argv[4] if len(sys.argv) > 4 else "output.vex.json"
    
    logger.info("Generating VEX document from REACHABLE report...")
    print()
    
    vex_file = generate_vex_from_vera(
        vera_report_file=vera_report,
        product_name=product_name,
        product_version=product_version,
        output_file=output_file
    )
    
    logger.info(f"✅ VEX document generated: {vex_file}")
    print()
    
    generate_vex_summary(vex_file)
