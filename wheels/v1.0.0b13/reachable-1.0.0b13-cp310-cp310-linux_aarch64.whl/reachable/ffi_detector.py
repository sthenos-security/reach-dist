# Copyright © 2026 Sthenos Security. All rights reserved.

"""
FFI (Foreign Function Interface) Detector

Detects cross-language function calls in Python code.
"""

import ast
import os
from pathlib import Path
from typing import List, Dict, Any
import json
import logging

# Initialize module-level logger
logger = logging.getLogger(__name__)

class FFIDetector:
    """Detects Python code calling foreign (non-Python) libraries."""
    
    def __init__(self, project_root: Path):
        self.project_root = Path(project_root)
        self.ffi_calls = []
    
    def detect_all(self) -> List[Dict[str, Any]]:
        """
        Scan project for all FFI patterns.
        
        Returns:
            List of FFI call dictionaries with metadata
        """
        self.ffi_calls = []
        
        # Scan all Python files
        for py_file in self.project_root.rglob('*.py'):
            try:
                with open(py_file, 'r', encoding='utf-8') as f:
                    source = f.read()
                
                tree = ast.parse(source, filename=str(py_file))
                self._analyze_file(tree, py_file)
            except Exception as e:
                # Skip files that can't be parsed
                continue
        
        return self.ffi_calls
    
    def _analyze_file(self, tree: ast.AST, filepath: Path):
        """Analyze a single file for FFI patterns."""
        
        # Pattern 1: ctypes
        ctypes_calls = self._detect_ctypes(tree, filepath)
        self.ffi_calls.extend(ctypes_calls)
        
        # Pattern 2: cffi
        cffi_calls = self._detect_cffi(tree, filepath)
        self.ffi_calls.extend(cffi_calls)
        
        # Pattern 3: pybind11 / compiled extensions
        extension_calls = self._detect_extensions(tree, filepath)
        self.ffi_calls.extend(extension_calls)
        
        # Pattern 4: subprocess calls to non-Python binaries
        subprocess_calls = self._detect_subprocess(tree, filepath)
        self.ffi_calls.extend(subprocess_calls)
    
    def _detect_ctypes(self, tree: ast.AST, filepath: Path) -> List[Dict]:
        """Detect ctypes FFI calls."""
        results = []
        
        class CTypesVisitor(ast.NodeVisitor):
            def __init__(self):
                self.ctypes_loads = []
            
            def visit_Call(self, node):
                # Pattern: ctypes.CDLL("library.so")
                if (isinstance(node.func, ast.Attribute) and
                    node.func.attr in ['CDLL', 'WinDLL', 'OleDLL', 'PyDLL']):
                    
                    if node.args:
                        lib_path = self._extract_string(node.args[0])
                        if lib_path:
                            self.ctypes_loads.append({
                                'library': lib_path,
                                'line': node.lineno
                            })
                
                self.generic_visit(node)
            
            def _extract_string(self, node):
                """Extract string value from AST node."""
                if isinstance(node, ast.Constant):
                    return node.value
                elif isinstance(node, ast.Str):
                    return node.s
                return None
        
        visitor = CTypesVisitor()
        visitor.visit(tree)
        
        for load in visitor.ctypes_loads:
            library = load['library']
            target_lang = self._guess_language_from_library(library)
            
            results.append({
                'type': 'ctypes',
                'file': str(filepath.relative_to(self.project_root)),
                'line': load['line'],
                'library': library,
                'target_language': target_lang,
                'mechanism': 'ctypes.CDLL',
                'risk': 'Memory safety boundary - validate all inputs/outputs'
            })
        
        return results
    
    def _detect_cffi(self, tree: ast.AST, filepath: Path) -> List[Dict]:
        """Detect cffi FFI calls."""
        results = []
        
        class CFFIVisitor(ast.NodeVisitor):
            def __init__(self):
                self.cffi_calls = []
            
            def visit_Import(self, node):
                for alias in node.names:
                    if alias.name == 'cffi':
                        self.cffi_calls.append({
                            'line': node.lineno,
                            'pattern': 'import cffi'
                        })
                self.generic_visit(node)
        
        visitor = CFFIVisitor()
        visitor.visit(tree)
        
        if visitor.cffi_calls:
            results.append({
                'type': 'cffi',
                'file': str(filepath.relative_to(self.project_root)),
                'line': visitor.cffi_calls[0]['line'],
                'target_language': 'c',
                'mechanism': 'cffi',
                'risk': 'C Foreign Function Interface - check type safety'
            })
        
        return results
    
    def _detect_extensions(self, tree: ast.AST, filepath: Path) -> List[Dict]:
        """Detect compiled extension imports."""
        results = []
        
        class ExtensionVisitor(ast.NodeVisitor):
            def __init__(self, project_root):
                self.project_root = project_root
                self.imports = []
            
            def visit_Import(self, node):
                for alias in node.names:
                    self.imports.append({
                        'module': alias.name,
                        'line': node.lineno
                    })
                self.generic_visit(node)
            
            def visit_ImportFrom(self, node):
                if node.module:
                    self.imports.append({
                        'module': node.module,
                        'line': node.lineno
                    })
                self.generic_visit(node)
        
        visitor = ExtensionVisitor(self.project_root)
        visitor.visit(tree)
        
        for imp in visitor.imports:
            module = imp['module']
            
            # Check if .so/.pyd/.dylib exists for this module
            for ext in ['.so', '.pyd', '.dylib', '.dll']:
                potential_lib = self.project_root / f"{module.replace('.', '/')}{ext}"
                if potential_lib.exists():
                    target_lang = self._guess_language_from_binary(potential_lib)
                    
                    results.append({
                        'type': 'compiled_extension',
                        'file': str(filepath.relative_to(self.project_root)),
                        'line': imp['line'],
                        'module': module,
                        'library': str(potential_lib),
                        'target_language': target_lang,
                        'mechanism': 'native_extension',
                        'risk': 'Compiled code boundary - potential memory safety issues'
                    })
        
        return results
    
    def _detect_subprocess(self, tree: ast.AST, filepath: Path) -> List[Dict]:
        """Detect subprocess calls to non-Python binaries."""
        results = []
        
        class SubprocessVisitor(ast.NodeVisitor):
            def __init__(self):
                self.subprocess_calls = []
            
            def visit_Call(self, node):
                # Pattern: subprocess.run(['binary', 'args'])
                if (isinstance(node.func, ast.Attribute) and
                    node.func.attr in ['run', 'call', 'Popen', 'check_output']):
                    
                    if node.args:
                        command = self._extract_command(node.args[0])
                        if command:
                            self.subprocess_calls.append({
                                'command': command,
                                'line': node.lineno
                            })
                
                self.generic_visit(node)
            
            def _extract_command(self, node):
                """Extract command from subprocess call."""
                if isinstance(node, ast.List):
                    if node.elts:
                        first_elem = node.elts[0]
                        if isinstance(first_elem, ast.Constant):
                            return first_elem.value
                        elif isinstance(first_elem, ast.Str):
                            return first_elem.s
                return None
        
        visitor = SubprocessVisitor()
        visitor.visit(tree)
        
        for call in visitor.subprocess_calls:
            command = call['command']
            
            # Skip Python interpreters
            if command in ['python', 'python3', 'python2']:
                continue
            
            target_lang = 'binary'
            if command.endswith('.go'):
                target_lang = 'go'
            elif command.endswith(('.c', '.cpp', '.cc')):
                target_lang = 'cpp'
            
            results.append({
                'type': 'subprocess',
                'file': str(filepath.relative_to(self.project_root)),
                'line': call['line'],
                'command': command,
                'target_language': target_lang,
                'mechanism': 'subprocess',
                'risk': 'Process boundary - validate command injection'
            })
        
        return results
    
    def _guess_language_from_library(self, library_path: str) -> str:
        """Guess target language from library filename."""
        library_lower = library_path.lower()
        
        if 'go' in library_lower or library_path.endswith('.so') and 'go_' in library_lower:
            return 'go'
        elif any(x in library_lower for x in ['cpp', 'cxx', 'cc', 'c++']):
            return 'cpp'
        elif library_path.endswith('.rs.so'):
            return 'rust'
        else:
            return 'c'  # Default assumption
    
    def _guess_language_from_binary(self, binary_path: Path) -> str:
        """Guess language from compiled binary."""
        # Check for Go build info
        try:
            with open(binary_path, 'rb') as f:
                content = f.read(1024)
                if b'Go build' in content or b'golang' in content:
                    return 'go'
                if b'rustc' in content:
                    return 'rust'
        except:
            pass
        
        return 'unknown'
    
    def save_to_file(self, output_path: Path):
        """Save FFI detection results to JSON file."""
        output = {
            'project': str(self.project_root),
            'ffi_calls_detected': len(self.ffi_calls),
            'cross_language_boundaries': self.ffi_calls,
            'languages_detected': list(set(call['target_language'] for call in self.ffi_calls)),
            'recommendation': self._generate_recommendation()
        }
        
        with open(output_path, 'w') as f:
            json.dump(output, f, indent=2)
    
    def _generate_recommendation(self) -> str:
        """Generate security recommendation based on FFI usage."""
        if not self.ffi_calls:
            return "No FFI calls detected. Standard single-language analysis applies."
        
        languages = set(call['target_language'] for call in self.ffi_calls)
        
        return (
            f"CROSS-LANGUAGE SECURITY ALERT: This project calls code in {len(languages)} "
            f"other language(s): {', '.join(languages)}. Vulnerabilities in foreign code "
            f"may be reachable from Python. Consider running language-specific scanners "
            f"on: {', '.join(languages)}. See POLYGLOT_CALL_GRAPHS.md for cross-language "
            f"correlation strategies."
        )

def main():
    """CLI entry point for FFI detection."""
    import sys
    
    if len(sys.argv) < 2:
        logger.info("Usage: python ffi_detector.py <project_directory>")
        sys.exit(1)
    
    project_dir = Path(sys.argv[1])
    if not project_dir.exists():
        logger.info(f"Error: {project_dir} does not exist")
        sys.exit(1)
    
    detector = FFIDetector(project_dir)
    ffi_calls = detector.detect_all()
    
    if not ffi_calls:
        logger.info("✅ No FFI calls detected")
        return
    
    logger.info(f"🔍 Detected {len(ffi_calls)} FFI call(s):")
    print()
    
    for call in ffi_calls:
        logger.info(f"  [{call['type'].upper()}] {call['file']}:{call['line']}")
        logger.info(f"    Target: {call['target_language']}")
        if 'library' in call:
            logger.info(f"    Library: {call['library']}")
        if 'command' in call:
            logger.info(f"    Command: {call['command']}")
        logger.info(f"    Risk: {call['risk']}")
        print()
    
    # Save to file
    output_path = project_dir / 'ffi_analysis.json'
    detector.save_to_file(output_path)
    logger.info(f"📄 Saved detailed analysis to: {output_path}")

if __name__ == '__main__':
    main()
