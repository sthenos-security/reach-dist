#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.

"""
NPM Provenance Verification System

Verifies package provenance and detects tampering using:
1. NPM signatures and attestations
2. Commit-to-publish gap detection
3. Package integrity verification
4. Typosquatting detection

Red Flags:
- No provenance/signatures
- Commit timestamp vs publish timestamp mismatch
- High entropy code + no provenance
- Suspicious package names (typosquatting)
- Recent package with old last-modified date

Usage:
    from provenance_verifier import ProvenanceVerifier
    
    verifier = ProvenanceVerifier()
    result = verifier.verify_package("suspicious-package", "1.0.0")
    
    if result.risk_level == "critical":
        logger.info(f"🚨 Block package: {result.reasons}")
"""

import subprocess
import json
from dataclasses import dataclass, field
from typing import List, Dict, Optional, Tuple
from datetime import datetime, timedelta
from pathlib import Path
import re
import logging

# Initialize module-level logger
logger = logging.getLogger(__name__)

@dataclass
class ProvenanceResult:
    """Result of provenance verification"""
    package_name: str
    version: str
    
    # Provenance status
    has_signatures: bool = False
    has_attestations: bool = False
    has_provenance: bool = False
    
    # Timestamps
    publish_time: Optional[datetime] = None
    commit_time: Optional[datetime] = None
    commit_to_publish_gap: Optional[timedelta] = None
    
    # Package metadata
    download_count: int = 0
    author: Optional[str] = None
    repository: Optional[str] = None
    license: Optional[str] = None
    
    # Risk assessment
    risk_level: str = "unknown"  # "safe", "low", "medium", "high", "critical"
    risk_score: int = 0  # 0-100
    reasons: List[str] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)
    
    # Additional checks
    is_typosquatting: bool = False
    similar_packages: List[str] = field(default_factory=list)
    
    def to_dict(self) -> Dict:
        """Convert to dictionary"""
        return {
            "package": f"{self.package_name}@{self.version}",
            "provenance": {
                "has_signatures": self.has_signatures,
                "has_attestations": self.has_attestations,
                "has_provenance": self.has_provenance,
            },
            "timestamps": {
                "publish_time": self.publish_time.isoformat() if self.publish_time else None,
                "commit_time": self.commit_time.isoformat() if self.commit_time else None,
                "commit_to_publish_gap_seconds": (
                    self.commit_to_publish_gap.total_seconds()
                    if self.commit_to_publish_gap else None
                ),
            },
            "metadata": {
                "downloads": self.download_count,
                "author": self.author,
                "repository": self.repository,
                "license": self.license,
            },
            "risk_assessment": {
                "level": self.risk_level,
                "score": self.risk_score,
                "reasons": self.reasons,
                "warnings": self.warnings,
            },
            "typosquatting": {
                "is_suspicious": self.is_typosquatting,
                "similar_packages": self.similar_packages,
            }
        }

class ProvenanceVerifier:
    """
    Verifies NPM package provenance and detects tampering
    
    Detection Strategy:
    1. Check for signatures/attestations (npm provenance)
    2. Detect commit-to-publish time gaps
    3. Cross-reference with typosquatting databases
    4. Combine with entropy scanning
    """
    
    # Known popular packages for typosquatting detection
    POPULAR_PACKAGES = [
        'react', 'vue', 'angular', 'lodash', 'axios', 'express', 'webpack',
        'babel', 'eslint', 'typescript', 'jest', 'mocha', 'chai', 'sinon',
        'next', 'nuxt', 'gatsby', 'electron', 'socket.io', 'moment', 'date-fns',
        '@whiskeysockets/baileys'  # Known target for supply chain attacks
    ]
    
    def __init__(self):
        """Initialize provenance verifier"""
        self.npm_available = self._check_npm()
    
    def _check_npm(self) -> bool:
        """Check if npm is available"""
        try:
            subprocess.run(['npm', '--version'], capture_output=True, check=True)
            return True
        except (subprocess.CalledProcessError, FileNotFoundError):
            return False
    
    def _get_package_info(self, package_name: str, version: Optional[str] = None) -> Optional[Dict]:
        """Get package information from npm registry"""
        if not self.npm_available:
            return None
        
        try:
            package_spec = f"{package_name}@{version}" if version else package_name
            result = subprocess.run(
                ['npm', 'info', package_spec, '--json'],
                capture_output=True,
                text=True,
                check=True
            )
            return json.loads(result.stdout)
        except (subprocess.CalledProcessError, json.JSONDecodeError):
            return None
    
    def _check_provenance(self, package_info: Dict) -> Tuple[bool, bool, bool]:
        """
        Check for NPM provenance data
        
        Returns:
            (has_signatures, has_attestations, has_provenance)
        """
        dist = package_info.get('dist', {})
        
        has_signatures = bool(dist.get('signatures'))
        has_attestations = bool(dist.get('attestations'))
        has_provenance = has_signatures or has_attestations
        
        return has_signatures, has_attestations, has_provenance
    
    def _parse_timestamp(self, timestamp_str: Optional[str]) -> Optional[datetime]:
        """Parse ISO timestamp string"""
        if not timestamp_str:
            return None
        
        try:
            # Handle both with and without timezone
            if timestamp_str.endswith('Z'):
                timestamp_str = timestamp_str[:-1] + '+00:00'
            return datetime.fromisoformat(timestamp_str)
        except (ValueError, AttributeError):
            return None
    
    def _calculate_commit_gap(self, package_info: Dict) -> Optional[timedelta]:
        """
        Calculate gap between commit time and publish time
        
        Large gaps indicate possible tampering:
        - Normal: < 1 hour (automated CI/CD)
        - Suspicious: > 24 hours
        - Critical: > 1 week
        """
        # Get publish time from package metadata
        time_str = package_info.get('time', {}).get(package_info.get('version'))
        publish_time = self._parse_timestamp(time_str)
        
        if not publish_time:
            return None
        
        # Try to get commit time from repository
        # This would require additional API calls to GitHub/GitLab
        # For now, we'll check for suspicious patterns in the metadata
        
        # Check for modified time vs created time
        created = self._parse_timestamp(package_info.get('time', {}).get('created'))
        modified = self._parse_timestamp(package_info.get('time', {}).get('modified'))
        
        if created and modified:
            return modified - created
        
        return None
    
    def _detect_typosquatting(self, package_name: str) -> Tuple[bool, List[str]]:
        """
        Detect potential typosquatting
        
        Checks for:
        - Similar names to popular packages
        - Common substitutions (0/O, 1/l, rn/m)
        - Extra/missing characters
        
        Does NOT flag:
        - The popular packages themselves
        - Very short package names (< 3 chars) - too many false positives
        - Scoped packages (@org/pkg) unless the pkg part matches
        """
        similar = []
        is_suspicious = False
        
        # Normalize for comparison
        normalized = package_name.lower().replace('-', '').replace('_', '')
        
        # Handle scoped packages - extract the package name part
        original_name = package_name
        if package_name.startswith('@') and '/' in package_name:
            package_name = package_name.split('/')[-1]
            normalized = package_name.lower().replace('-', '').replace('_', '')
        
        # Skip very short names - too many false positives
        if len(normalized) < 3:
            return False, []
        
        # Build set of normalized popular package names for fast lookup
        popular_normalized_set = set()
        for p in self.POPULAR_PACKAGES:
            p_norm = p.lower().replace('-', '').replace('_', '')
            # Handle scoped popular packages
            if p.startswith('@') and '/' in p:
                p_norm = p.split('/')[-1].lower().replace('-', '').replace('_', '')
            popular_normalized_set.add(p_norm)
        
        # If this IS a popular package, don't flag it
        if normalized in popular_normalized_set:
            return False, []
        
        for popular in self.POPULAR_PACKAGES:
            popular_normalized = popular.lower().replace('-', '').replace('_', '')
            # Handle scoped popular packages
            if popular.startswith('@') and '/' in popular:
                popular_normalized = popular.split('/')[-1].lower().replace('-', '').replace('_', '')
            
            # Skip if same package (case insensitive)
            if normalized == popular_normalized:
                continue
            
            # Skip comparison if length difference is too big (not likely typosquat)
            len_diff = abs(len(normalized) - len(popular_normalized))
            if len_diff > 2:
                continue
            
            # Calculate edit distance (Levenshtein-like)
            # For typosquatting, we want very close matches (1-2 char difference)
            min_len = min(len(normalized), len(popular_normalized))
            max_len = max(len(normalized), len(popular_normalized))
            
            # Simple character difference for same-length strings
            if len(normalized) == len(popular_normalized):
                differences = sum(1 for a, b in zip(normalized, popular_normalized) if a != b)
                # Only flag if exactly 1 character different and name is long enough
                if differences == 1 and len(normalized) >= 4:
                    similar.append(popular)
                    is_suspicious = True
                    continue
            
            # For different lengths, check if one is substring of other + 1 char
            if len_diff == 1:
                # Check if adding/removing one char makes them match
                if min_len >= 4:  # Only for longer names
                    shorter = normalized if len(normalized) < len(popular_normalized) else popular_normalized
                    longer = popular_normalized if len(normalized) < len(popular_normalized) else normalized
                    
                    # Check each position for single char insertion
                    for i in range(len(longer)):
                        if shorter == longer[:i] + longer[i+1:]:
                            similar.append(popular)
                            is_suspicious = True
                            break
            
            # Check for common substitutions (0/O, 1/l, rn/m, etc.)
            substitutions = {
                '0': 'o', '1': 'l', 'rn': 'm', 'vv': 'w',
                'cl': 'd', 'nn': 'rn', '1i': 'li', 'll': 'li'
            }
            
            test = normalized
            for bad, good in substitutions.items():
                if bad in test:
                    test = test.replace(bad, good)
            
            if test == popular_normalized and test != normalized:
                similar.append(popular)
                is_suspicious = True
        
        # Deduplicate
        similar = list(set(similar))
        
        return is_suspicious, similar
    
    def _calculate_risk_score(self, result: ProvenanceResult) -> Tuple[str, int]:
        """
        Calculate risk score and level
        
        Scoring:
        - No provenance: +40 points
        - High commit gap (>7 days): +30 points
        - Typosquatting: +50 points
        - Low downloads (<100): +20 points
        - No repository: +10 points
        - Suspicious license: +10 points
        
        Levels:
        - 0-20: Safe (green)
        - 21-40: Low (yellow)
        - 41-60: Medium (orange)
        - 61-80: High (red)
        - 81-100: Critical (block)
        """
        score = 0
        reasons = []
        
        # Check provenance
        if not result.has_provenance:
            score += 40
            reasons.append("No provenance/signatures - cannot verify authenticity")
        
        # Check commit gap
        if result.commit_to_publish_gap:
            gap_days = result.commit_to_publish_gap.days
            if gap_days > 7:
                score += 30
                reasons.append(f"Large commit-to-publish gap: {gap_days} days (expected <1 day)")
            elif gap_days > 1:
                score += 15
                reasons.append(f"Moderate commit-to-publish gap: {gap_days} days")
        
        # Check typosquatting
        if result.is_typosquatting:
            score += 50
            reasons.append(f"Possible typosquatting - similar to: {', '.join(result.similar_packages)}")
        
        # Check downloads
        if result.download_count < 100:
            score += 20
            reasons.append(f"Very low downloads: {result.download_count}")
        elif result.download_count < 1000:
            score += 10
            reasons.append(f"Low downloads: {result.download_count}")
        
        # Check repository
        if not result.repository:
            score += 10
            reasons.append("No repository link - cannot verify source code")
        
        # Check license
        if result.license in [None, 'UNLICENSED', 'SEE LICENSE IN LICENSE']:
            score += 10
            reasons.append("No standard license")
        
        # Determine risk level
        if score >= 81:
            level = "critical"
        elif score >= 61:
            level = "high"
        elif score >= 41:
            level = "medium"
        elif score >= 21:
            level = "low"
        else:
            level = "safe"
        
        return level, score, reasons
    
    def verify_package(self, package_name: str, version: Optional[str] = None) -> ProvenanceResult:
        """
        Verify package provenance
        
        Args:
            package_name: Name of package to verify
            version: Specific version (default: latest)
            
        Returns:
            ProvenanceResult with verification details
        """
        result = ProvenanceResult(
            package_name=package_name,
            version=version or "latest"
        )
        
        # Get package info
        package_info = self._get_package_info(package_name, version)
        
        if not package_info:
            result.risk_level = "high"
            result.risk_score = 70
            result.reasons.append("Cannot fetch package information from npm registry")
            return result
        
        # Extract version if not specified
        if not version:
            result.version = package_info.get('version', 'unknown')
        
        # Check provenance
        has_sigs, has_att, has_prov = self._check_provenance(package_info)
        result.has_signatures = has_sigs
        result.has_attestations = has_att
        result.has_provenance = has_prov
        
        # Extract metadata
        result.author = package_info.get('author', {}).get('name') if isinstance(
            package_info.get('author'), dict) else package_info.get('author')
        
        repo = package_info.get('repository', {})
        if isinstance(repo, dict):
            result.repository = repo.get('url')
        elif isinstance(repo, str):
            result.repository = repo
        
        result.license = package_info.get('license')
        
        # Get download stats (if available)
        # This would require additional API call to npm download stats
        # For now, use placeholder
        result.download_count = 0  # Would need npm download-counts API
        
        # Parse timestamps
        times = package_info.get('time', {})
        version_time = times.get(result.version) or times.get('modified')
        result.publish_time = self._parse_timestamp(version_time)
        
        # Calculate commit gap
        result.commit_to_publish_gap = self._calculate_commit_gap(package_info)
        
        # Check for typosquatting
        result.is_typosquatting, result.similar_packages = self._detect_typosquatting(package_name)
        
        # Calculate final risk score
        level, score, reasons = self._calculate_risk_score(result)
        result.risk_level = level
        result.risk_score = score
        result.reasons = reasons
        
        # Add warnings for medium risk
        if result.risk_level in ["medium", "high", "critical"]:
            if not result.has_provenance:
                result.warnings.append("⚠️  Verify package source manually before using")
            if result.is_typosquatting:
                result.warnings.append("🚨 Possible typosquatting - verify package name carefully")
        
        return result
    
    def verify_policy(
        self,
        package_name: str,
        version: Optional[str] = None,
        entropy_high: bool = False
    ) -> Tuple[str, str]:
        """
        Apply verification policy combining provenance + entropy
        
        Policy:
        - GREEN: Verified provenance + No high entropy
        - YELLOW: Verified provenance + High entropy (needs manual review)
        - RED: No provenance + High entropy (BLOCK)
        
        Args:
            package_name: Package to verify
            version: Package version
            entropy_high: Whether entropy scan detected high entropy
            
        Returns:
            (status, message) where status is "green", "yellow", or "red"
        """
        result = self.verify_package(package_name, version)
        
        # RED: No provenance + high entropy = BLOCK
        if not result.has_provenance and entropy_high:
            return "red", f"🚨 BLOCK: No provenance + high entropy code detected"
        
        # RED: Critical risk score
        if result.risk_level == "critical":
            return "red", f"🚨 BLOCK: Critical risk score ({result.risk_score}/100)"
        
        # YELLOW: Has provenance but high entropy
        if result.has_provenance and entropy_high:
            return "yellow", f"⚠️  REVIEW: Verified provenance but high entropy code needs AST scan"
        
        # YELLOW: High risk score but has some provenance
        if result.risk_level == "high" and result.has_provenance:
            return "yellow", f"⚠️  REVIEW: High risk score ({result.risk_score}/100)"
        
        # YELLOW: Medium risk
        if result.risk_level == "medium":
            return "yellow", f"⚠️  CAUTION: Medium risk ({result.risk_score}/100)"
        
        # GREEN: Has provenance and no high entropy
        if result.has_provenance and not entropy_high:
            return "green", f"✅ SAFE: Verified provenance, no high entropy"
        
        # YELLOW: Default for anything else
        return "yellow", f"⚠️  REVIEW: {', '.join(result.reasons[:2])}"

def main():
    """CLI entry point"""
    import sys
    if len(sys.argv) < 2:
        logger.info("Usage: python provenance_verifier.py <package>[@version]")
        logger.info("\nExamples:")
        logger.info("  python provenance_verifier.py express")
        logger.info("  python provenance_verifier.py express@4.18.2")
        logger.info("  python provenance_verifier.py suspicious-package")
        sys.exit(1)
    
    # Parse package spec
    package_spec = sys.argv[1]
    if '@' in package_spec and not package_spec.startswith('@'):
        package_name, version = package_spec.rsplit('@', 1)
    else:
        package_name = package_spec
        version = None
    
    # Verify package
    verifier = ProvenanceVerifier()
    result = verifier.verify_package(package_name, version)
    
    # Print report
    print("=" * 70)
    logger.info(f"NPM PROVENANCE VERIFICATION: {package_name}@{result.version}")
    print("=" * 70)
    print()
    
    logger.info("PROVENANCE STATUS:")
    logger.info(f"  Signatures: {'✅' if result.has_signatures else '❌'} {result.has_signatures}")
    logger.info(f"  Attestations: {'✅' if result.has_attestations else '❌'} {result.has_attestations}")
    logger.info(f"  Overall: {'✅' if result.has_provenance else '❌'} {'Verified' if result.has_provenance else 'NOT VERIFIED'}")
    print()
    
    if result.publish_time:
        logger.info("TIMESTAMPS:")
        logger.info(f"  Published: {result.publish_time.strftime('%Y-%m-%d %H:%M:%S UTC')}")
        if result.commit_to_publish_gap:
            logger.info(f"  Commit Gap: {result.commit_to_publish_gap}")
        print()
    
    logger.info("METADATA:")
    logger.info(f"  Author: {result.author or 'Unknown'}")
    logger.info(f"  Repository: {result.repository or 'None'}")
    logger.info(f"  License: {result.license or 'None'}")
    print()
    
    if result.is_typosquatting:
        logger.info("⚠️  TYPOSQUATTING ALERT:")
        logger.info(f"  Similar to: {', '.join(result.similar_packages)}")
        print()
    
    logger.info("RISK ASSESSMENT:")
    risk_emoji = {
        "safe": "✅",
        "low": "ℹ️",
        "medium": "⚠️",
        "high": "🚨",
        "critical": "💀"
    }
    emoji = risk_emoji.get(result.risk_level, "?")
    logger.info(f"  Level: {emoji} {result.risk_level.upper()}")
    logger.info(f"  Score: {result.risk_score}/100")
    print()
    
    if result.reasons:
        logger.info("ISSUES:")
        for reason in result.reasons:
            logger.info(f"  • {reason}")
        print()
    
    if result.warnings:
        logger.info("WARNINGS:")
        for warning in result.warnings:
            logger.info(f"  {warning}")
        print()
    
    print("=" * 70)
    
    # Exit code based on risk
    if result.risk_level in ["high", "critical"]:
        sys.exit(1)
    elif result.risk_level == "medium":
        sys.exit(2)
    else:
        sys.exit(0)

if __name__ == '__main__':
    main()
