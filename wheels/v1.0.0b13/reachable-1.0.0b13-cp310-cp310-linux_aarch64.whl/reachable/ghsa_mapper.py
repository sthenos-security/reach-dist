#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.

"""
GHSA to CVE Mapper

Maps GitHub Security Advisory (GHSA) IDs to CVE IDs using the GitHub API.
This enables threat intelligence lookups for GHSA-identified vulnerabilities.
"""

import requests
import json
from pathlib import Path
from typing import Optional, Dict, List
from datetime import datetime, timedelta
import logging

# Initialize module-level logger
logger = logging.getLogger(__name__)

class GHSAMapper:
    """Maps GHSA IDs to CVE IDs using GitHub GraphQL API"""
    
    GITHUB_API = "https://api.github.com/graphql"
    
    def __init__(self, cache_dir: Optional[Path] = None, cache_duration_hours: int = 168):
        """
        Initialize GHSA mapper
        
        Args:
            cache_dir: Directory to cache mappings (None = no caching)
            cache_duration_hours: Cache duration (default 7 days = 168 hours)
        """
        self.cache_dir = Path(cache_dir) if cache_dir else None
        if self.cache_dir:
            self.cache_dir.mkdir(parents=True, exist_ok=True)
        
        self.cache_duration = timedelta(hours=cache_duration_hours)
        self._cache: Dict[str, Optional[str]] = {}
        
        # Load cache from disk
        self._load_cache()
    
    def _load_cache(self):
        """Load GHSA→CVE mappings from disk cache"""
        if not self.cache_dir:
            return
        
        cache_file = self.cache_dir / "ghsa_cve_map.json"
        if not cache_file.exists():
            return
        
        # Check cache age
        cache_age = datetime.now() - datetime.fromtimestamp(cache_file.stat().st_mtime)
        if cache_age > self.cache_duration:
            return
        
        try:
            with open(cache_file) as f:
                self._cache = json.load(f)
        except Exception as e:
            logger.info(f"   ⚠️  Failed to load GHSA cache: {e}")
    
    def _save_cache(self):
        """Save GHSA→CVE mappings to disk cache"""
        if not self.cache_dir:
            return
        
        cache_file = self.cache_dir / "ghsa_cve_map.json"
        try:
            with open(cache_file, 'w') as f:
                json.dump(self._cache, f, indent=2)
        except Exception as e:
            logger.info(f"   ⚠️  Failed to save GHSA cache: {e}")
    
    def get_cve_id(self, ghsa_id: str) -> Optional[str]:
        """
        Get CVE ID for a GHSA ID
        
        Args:
            ghsa_id: GHSA identifier (e.g., GHSA-xxxx-xxxx-xxxx)
            
        Returns:
            CVE ID if found, None otherwise
        """
        # Check cache first
        if ghsa_id in self._cache:
            return self._cache[ghsa_id]
        
        # Try GitHub API (no auth required, public data)
        cve_id = self._fetch_from_github(ghsa_id)
        
        # Cache result (even if None to avoid repeated lookups)
        self._cache[ghsa_id] = cve_id
        self._save_cache()
        
        return cve_id
    
    def get_cve_ids_batch(self, ghsa_ids: List[str]) -> Dict[str, Optional[str]]:
        """
        Get CVE IDs for multiple GHSA IDs
        
        Args:
            ghsa_ids: List of GHSA identifiers
            
        Returns:
            Dict mapping GHSA ID → CVE ID (or None)
        """
        results = {}
        to_fetch = []
        
        # Check cache first
        for ghsa_id in ghsa_ids:
            if ghsa_id in self._cache:
                results[ghsa_id] = self._cache[ghsa_id]
            else:
                to_fetch.append(ghsa_id)
        
        # Fetch uncached ones
        if to_fetch:
            logger.info(f"   📡 Mapping {len(to_fetch)} GHSA IDs to CVE IDs...")
            for ghsa_id in to_fetch:
                cve_id = self._fetch_from_github(ghsa_id)
                results[ghsa_id] = cve_id
                self._cache[ghsa_id] = cve_id
            
            self._save_cache()
            
            found = sum(1 for v in results.values() if v is not None)
            logger.info(f"   ✓ Mapped {found}/{len(to_fetch)} GHSA IDs to CVE IDs")
        
        return results
    
    def _fetch_from_github(self, ghsa_id: str) -> Optional[str]:
        """
        Fetch CVE ID from GitHub Security Advisory
        
        Uses public GitHub GraphQL API (no auth required)
        """
        # GitHub GraphQL query
        query = """
        query($ghsaId: String!) {
          securityAdvisory(ghsaId: $ghsaId) {
            identifiers {
              type
              value
            }
          }
        }
        """
        
        try:
            response = requests.post(
                self.GITHUB_API,
                json={
                    'query': query,
                    'variables': {'ghsaId': ghsa_id}
                },
                headers={'Content-Type': 'application/json'},
                timeout=10
            )
            
            if response.status_code != 200:
                return None
            
            data = response.json()
            
            # Extract CVE from identifiers
            advisory = data.get('data', {}).get('securityAdvisory')
            if not advisory:
                return None
            
            for identifier in advisory.get('identifiers', []):
                if identifier.get('type') == 'CVE':
                    return identifier.get('value')
            
            return None
            
        except Exception as e:
            # Silent failure - many GHSA IDs won't have CVEs
            return None

if __name__ == '__main__':
    # Test the mapper
    mapper = GHSAMapper()
    
    test_ids = [
        'GHSA-v845-jxx5-vc9f',  # urllib3
        'GHSA-j8r2-6x86-q33q',  # requests
        'GHSA-invalid-test',     # Should return None
    ]
    
    logger.info("Testing GHSA → CVE mapper:")
    for ghsa_id in test_ids:
        cve_id = mapper.get_cve_id(ghsa_id)
        logger.info(f"  {ghsa_id} → {cve_id or 'No CVE'}")
