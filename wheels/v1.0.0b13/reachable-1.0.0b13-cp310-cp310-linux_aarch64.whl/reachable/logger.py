#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.

"""
Centralized Logger Module for REACHABLE

This module provides a consistent logging interface across all REACHABLE components.

Usage:
    from reachable.logger import logger
    
    logger.info("Starting scan...")
    logger.warning("Configuration issue detected")
    logger.error("Failed to connect")
    logger.debug("Detailed debug information")

Or for module-specific loggers:
    from reachable.logger import get_logger
    
    logger = get_logger(__name__)
    logger.info("Module-specific log")

Configuration:
    The logger respects the REACHABLE_DEBUG environment variable
    and can be configured via setup_logger() in cli.py
"""

import logging
import sys
from typing import Optional


# Global logger instance
_logger: Optional[logging.Logger] = None
_debug_mode: bool = False


def setup_logger(debug: bool = False, quiet: bool = False) -> logging.Logger:
    """
    Configure the global logger.
    
    Args:
        debug: Enable debug-level logging
        quiet: Suppress info-level messages
    
    Returns:
        Configured logger instance
    """
    global _logger, _debug_mode
    
    _debug_mode = debug
    
    # Create logger if it doesn't exist
    if _logger is None:
        _logger = logging.getLogger('reachable')
    
    # Clear existing handlers
    _logger.handlers.clear()
    
    # Set level
    if debug:
        _logger.setLevel(logging.DEBUG)
    elif quiet:
        _logger.setLevel(logging.WARNING)
    else:
        _logger.setLevel(logging.INFO)
    
    # Create console handler
    handler = logging.StreamHandler(sys.stderr)
    
    # Set format
    if debug:
        # Detailed format for debugging
        formatter = logging.Formatter(
            '%(asctime)s %(levelname)-8s [%(name)s:%(lineno)d] %(message)s',
            datefmt='%Y-%m-%d %H:%M:%S'
        )
    else:
        # Simple format for normal operation
        formatter = logging.Formatter(
            '%(asctime)s %(levelname)-8s %(message)s',
            datefmt='%Y-%m-%dT%H:%M:%S'
        )
    
    handler.setFormatter(formatter)
    _logger.addHandler(handler)
    
    # Don't propagate to root logger
    _logger.propagate = False
    
    return _logger


def get_logger(name: Optional[str] = None) -> logging.Logger:
    """
    Get a logger instance.
    
    Args:
        name: Logger name (typically __name__ of the calling module)
    
    Returns:
        Logger instance
    
    Example:
        logger = get_logger(__name__)
        logger.info("Starting process")
    """
    global _logger
    
    # Ensure global logger is initialized
    if _logger is None:
        setup_logger()
    
    # Return module-specific logger if name provided
    if name and name != 'reachable':
        # Create child logger
        child_logger = logging.getLogger(f'reachable.{name}')
        child_logger.setLevel(_logger.level)
        return child_logger
    
    return _logger


# Default logger instance for simple imports
logger = get_logger()


def is_debug() -> bool:
    """Check if debug mode is enabled"""
    return _debug_mode


def set_debug(enabled: bool) -> None:
    """Enable or disable debug mode"""
    global _debug_mode
    _debug_mode = enabled
    if _logger:
        _logger.setLevel(logging.DEBUG if enabled else logging.INFO)


# Convenience functions for common logging patterns
def log_step(step: str, message: str) -> None:
    """Log a scan step with consistent formatting"""
    logger.info(f"   {step}: {message}")


def log_error(context: str, error: Exception) -> None:
    """Log an error with context"""
    logger.error(f"❌ {context}: {type(error).__name__}: {error}")


def log_warning(message: str) -> None:
    """Log a warning with emoji"""
    logger.warning(f"⚠️  {message}")


def log_success(message: str) -> None:
    """Log a success message with emoji"""
    logger.info(f"✅ {message}")


__all__ = [
    'logger',
    'get_logger',
    'setup_logger',
    'is_debug',
    'set_debug',
    'log_step',
    'log_error',
    'log_warning',
    'log_success',
]
