#!/usr/bin/env python3
# REACHABLE Git Repository Detection
# Copyright (c) 2026 Sthenos Security. All rights reserved.

"""
Detect Git repository characteristics for scan capabilities.

Used to determine:
- Whether target is a Git repository
- Whether it's a shallow clone
- Whether history-dependent scans are possible
"""

from pathlib import Path
from typing import Dict, Optional


def detect_repo_depth(repo_path: Path) -> Dict:
    """
    Detect Git repository depth and capabilities.
    
    Args:
        repo_path: Path to repository root
        
    Returns:
        {
            'is_git': bool,              # Is this a Git repository
            'is_shallow': bool,          # Is it shallow cloned (depth limited)
            'can_scan_history': bool,    # Can perform history-dependent scans
            'warning': str or None,      # Warning message if shallow
        }
    """
    git_dir = repo_path / '.git'
    
    if not git_dir.exists():
        return {
            'is_git': False,
            'is_shallow': False,
            'can_scan_history': False,
            'warning': None,
        }
    
    # Check for shallow file (indicates depth-limited clone)
    shallow_file = git_dir / 'shallow'
    is_shallow = shallow_file.exists()
    
    warning = None
    if is_shallow:
        warning = (
            "Shallow clone detected - secrets scanning limited to current tree.\n"
            "   Deep history scanning (for removed/rotated secrets) requires full clone.\n"
            "   This is intentional: history scans are expensive and may show inactive secrets.\n"
            "   To enable deep scanning: git fetch --unshallow (then re-scan)"
        )
    
    return {
        'is_git': True,
        'is_shallow': is_shallow,
        'can_scan_history': not is_shallow,
        'warning': warning,
    }


def get_repo_info_summary(repo_path: Path) -> str:
    """
    Get human-readable summary of repository status.
    
    Returns:
        String suitable for printing to console
    """
    info = detect_repo_depth(repo_path)
    
    if not info['is_git']:
        return "   Repository Type:  Not a Git repository"
    
    clone_type = "shallow (depth-limited)" if info['is_shallow'] else "full"
    history_status = "limited to current tree" if info['is_shallow'] else "available"
    
    return f"""   Repository Type:  Git repository ({clone_type})
   History Scans:    {history_status}"""
