#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.

"""
Automatic maintenance for REACHABLE databases and storage.

Handles:
- WAL checkpoint after scans
- VACUUM when bloat exceeds threshold
- Pruning old scans based on retention policy
"""

import logging
import sqlite3
from pathlib import Path
from datetime import datetime, timedelta
from typing import Dict, Any, Optional, List

logger = logging.getLogger(__name__)


def run_auto_maintenance(repo_db: Path, config: Dict[str, Any]) -> Dict[str, Any]:
    """
    Run automatic maintenance tasks after a scan.
    
    This is called automatically after each scan completes if auto-maintenance
    is enabled in config.
    
    Args:
        repo_db: Path to repo.db database
        config: Configuration dictionary from config_manager
        
    Returns:
        Dictionary with maintenance results:
        {
            'checkpointed': bool,
            'vacuumed': bool,
            'pruned': int,
            'errors': List[str],
            'skipped': bool (if disabled),
            'reason': str (if skipped)
        }
    """
    # Get auto-maintenance config
    auto_config = config.get('auto_maintenance', {})
    enabled = auto_config.get('enabled', True)
    
    if not enabled:
        logger.debug("Auto-maintenance disabled, skipping")
        return {
            'skipped': True,
            'reason': 'auto-maintenance disabled'
        }
    
    result = {
        'checkpointed': False,
        'vacuumed': False,
        'pruned': 0,
        'errors': []
    }
    
    if not repo_db.exists():
        result['errors'].append(f"Database not found: {repo_db}")
        return result
    
    # 1. WAL Checkpoint (fast, always safe)
    if auto_config.get('wal_checkpoint', True):
        try:
            checkpoint_wal(repo_db)
            result['checkpointed'] = True
            logger.debug(f"✓ WAL checkpoint completed for {repo_db.name}")
        except Exception as e:
            result['errors'].append(f"Checkpoint failed: {e}")
            logger.debug(f"WAL checkpoint failed: {e}")
    
    # 2. Vacuum if bloat exceeds threshold
    if auto_config.get('vacuum_enabled', True):
        threshold = auto_config.get('vacuum_threshold_pct', 30)
        try:
            stats = get_db_stats(repo_db)
            bloat_pct = stats.get('bloat_ratio', 0) * 100
            
            if bloat_pct >= threshold:
                vacuum_database(repo_db)
                result['vacuumed'] = True
                logger.debug(f"✓ VACUUM completed (bloat was {bloat_pct:.1f}%)")
        except Exception as e:
            result['errors'].append(f"Vacuum failed: {e}")
            logger.debug(f"Vacuum failed: {e}")
    
    # 3. Capture trends snapshot (BEFORE pruning) - OPTIONAL
    if auto_config.get('trends_enabled', True):
        try:
            from .trends import TrendsTracker
            tracker = TrendsTracker(repo_db)
            tracker.capture_snapshot()
            tracker.close()
            logger.debug("✓ Trends snapshot captured")
        except ImportError:
            # Trends module not available (not yet installed)
            pass
        except Exception as e:
            # Other errors - log but don't fail
            logger.debug(f"Trends capture failed: {e}")
    
    # 4. Prune old scans
    if auto_config.get('prune_enabled', True):
        max_scans = auto_config.get('max_scans_per_branch', 50)
        max_age = auto_config.get('max_age_days', 30)
        
        try:
            repo_root = repo_db.parent
            pruned = prune_old_scans(repo_root, max_scans, max_age)
            result['pruned'] = pruned
            if pruned > 0:
                logger.debug(f"✓ Pruned {pruned} old scans")
        except Exception as e:
            result['errors'].append(f"Pruning failed: {e}")
            logger.debug(f"Pruning failed: {e}")
    
    return result


def checkpoint_wal(db_path: Path) -> None:
    """
    Checkpoint WAL file into main database.
    
    This is a fast, safe operation that should run after every scan.
    It prevents WAL files from growing unbounded.
    
    Args:
        db_path: Path to database file
    """
    conn = sqlite3.connect(str(db_path))
    try:
        # PASSIVE mode: checkpoint if no other connections are using DB
        # This is safe and won't block
        conn.execute("PRAGMA wal_checkpoint(PASSIVE)")
        conn.commit()
    finally:
        conn.close()


def vacuum_database(db_path: Path, force: bool = False) -> Dict[str, Any]:
    """
    VACUUM database to reclaim space from deleted records.
    
    This is a heavier operation that should only run when bloat is high.
    
    Args:
        db_path: Path to database file
        force: If True, vacuum even if bloat is low
        
    Returns:
        Dictionary with vacuum results
    """
    stats_before = get_db_stats(db_path)
    
    conn = sqlite3.connect(str(db_path))
    try:
        # Run VACUUM
        conn.execute("VACUUM")
        conn.commit()
    finally:
        conn.close()
    
    stats_after = get_db_stats(db_path)
    
    return {
        'size_before': stats_before.get('db_size_bytes', 0),
        'size_after': stats_after.get('db_size_bytes', 0),
        'space_reclaimed': stats_before.get('db_size_bytes', 0) - stats_after.get('db_size_bytes', 0),
    }


def get_db_stats(db_path: Path) -> Dict[str, Any]:
    """
    Get database statistics for maintenance decisions.
    
    Args:
        db_path: Path to database file
        
    Returns:
        Dictionary with stats:
        {
            'db_size_bytes': int,
            'wal_size_bytes': int,
            'page_count': int,
            'freelist_count': int,
            'bloat_ratio': float  # 0.0-1.0
        }
    """
    stats = {
        'db_size_bytes': 0,
        'wal_size_bytes': 0,
        'page_count': 0,
        'freelist_count': 0,
        'bloat_ratio': 0.0
    }
    
    if not db_path.exists():
        return stats
    
    # Get file sizes
    stats['db_size_bytes'] = db_path.stat().st_size
    
    wal_path = db_path.with_suffix('.db-wal')
    if wal_path.exists():
        stats['wal_size_bytes'] = wal_path.stat().st_size
    
    # Get page counts
    try:
        conn = sqlite3.connect(str(db_path))
        cursor = conn.cursor()
        
        cursor.execute("PRAGMA page_count")
        stats['page_count'] = cursor.fetchone()[0]
        
        cursor.execute("PRAGMA freelist_count")
        stats['freelist_count'] = cursor.fetchone()[0]
        
        conn.close()
        
        # Calculate bloat ratio
        if stats['page_count'] > 0:
            stats['bloat_ratio'] = stats['freelist_count'] / stats['page_count']
    except Exception:
        pass
    
    return stats


def prune_old_scans(repo_root: Path, max_scans_per_branch: int, max_age_days: int, dry_run: bool = False) -> int:
    """
    Prune old scans based on retention policy.
    
    For each branch:
    - Keep most recent max_scans_per_branch scans
    - Delete scans older than max_age_days
    
    Args:
        repo_root: Repository root directory (.../scans/<repo-hash>/)
        max_scans_per_branch: Maximum scans to keep per branch
        max_age_days: Maximum age in days
        dry_run: If True, count scans to delete but don't actually delete them
        
    Returns:
        Number of scans deleted (or would be deleted if dry_run=True)
    """
    deleted_count = 0
    cutoff_date = datetime.now() - timedelta(days=max_age_days)
    
    # Iterate through branches
    for branch_dir in repo_root.iterdir():
        if not branch_dir.is_dir() or branch_dir.name.startswith('.'):
            continue
        
        # Get all scan directories (timestamp-based names)
        scan_dirs = []
        for scan_dir in branch_dir.iterdir():
            if not scan_dir.is_dir():
                continue
            
            # Parse timestamp from directory name (YYYYMMDD-HHMMSS-hash)
            try:
                timestamp_str = scan_dir.name[:15]  # YYYYMMDD-HHMMSS
                scan_date = datetime.strptime(timestamp_str, '%Y%m%d-%H%M%S')
                scan_dirs.append((scan_date, scan_dir))
            except (ValueError, IndexError):
                continue
        
        # Sort by date (newest first)
        scan_dirs.sort(key=lambda x: x[0], reverse=True)
        
        # Determine which scans to delete
        scans_to_delete = []
        
        for i, (scan_date, scan_dir) in enumerate(scan_dirs):
            # Keep if within max_scans limit
            if i < max_scans_per_branch:
                continue
            
            # Delete if older than max_age
            if scan_date < cutoff_date:
                scans_to_delete.append(scan_dir)
        
        # Delete old scans
        for scan_dir in scans_to_delete:
            if dry_run:
                # Count but don't delete
                deleted_count += 1
                logger.debug(f"Would delete old scan: {scan_dir}")
            else:
                try:
                    import shutil
                    shutil.rmtree(scan_dir)
                    deleted_count += 1
                    logger.debug(f"Deleted old scan: {scan_dir}")
                except Exception as e:
                    logger.debug(f"Failed to delete {scan_dir}: {e}")
    
    return deleted_count


def run_emergency_fix(repo_root: Optional[Path] = None) -> Dict[str, Any]:
    """
    Emergency maintenance - run all maintenance tasks with force flags.
    
    This is the "fix everything" command for when things go wrong:
    - Checkpoints all WAL files
    - Vacuums all databases (even if bloat is low)
    - Prunes old scans aggressively
    - Verifies database integrity
    
    Args:
        repo_root: Repository root (defaults to ~/.reachable/scans/)
        
    Returns:
        Dictionary with fix results
    """
    if repo_root is None:
        repo_root = Path.home() / '.reachable' / 'scans'
    
    result = {
        'databases_fixed': 0,
        'scans_pruned': 0,
        'space_reclaimed': 0,
        'errors': []
    }
    
    if not repo_root.exists():
        result['errors'].append(f"Scans directory not found: {repo_root}")
        return result
    
    # Find all repo.db files
    for repo_dir in repo_root.iterdir():
        if not repo_dir.is_dir() or repo_dir.name.startswith('.'):
            continue
        
        repo_db = repo_dir / 'repo.db'
        if not repo_db.exists():
            continue
        
        try:
            # 1. Checkpoint WAL
            checkpoint_wal(repo_db)
            
            # 2. Force vacuum
            vacuum_result = vacuum_database(repo_db, force=True)
            result['space_reclaimed'] += vacuum_result['space_reclaimed']
            
            # 3. Verify integrity
            if not verify_database(repo_db):
                result['errors'].append(f"Integrity check failed: {repo_db}")
            
            result['databases_fixed'] += 1
            
        except Exception as e:
            result['errors'].append(f"Failed to fix {repo_db}: {e}")
    
    # 4. Aggressive pruning (keep 30 scans, 21 days)
    try:
        for repo_dir in repo_root.iterdir():
            if not repo_dir.is_dir() or repo_dir.name.startswith('.'):
                continue
            
            pruned = prune_old_scans(repo_dir, max_scans_per_branch=30, max_age_days=21)
            result['scans_pruned'] += pruned
    except Exception as e:
        result['errors'].append(f"Pruning failed: {e}")
    
    return result


def verify_database(db_path: Path) -> bool:
    """
    Verify database integrity.
    
    Args:
        db_path: Path to database file
        
    Returns:
        True if integrity check passes, False otherwise
    """
    try:
        conn = sqlite3.connect(str(db_path))
        cursor = conn.cursor()
        
        cursor.execute("PRAGMA integrity_check")
        result = cursor.fetchone()[0]
        
        conn.close()
        
        return result == 'ok'
    except Exception:
        return False


def calculate_bloat_ratio(db_path: Path) -> float:
    """
    Calculate database bloat ratio.
    
    Args:
        db_path: Path to database file
        
    Returns:
        Float between 0.0 and 1.0 representing bloat ratio
        (0.0 = no bloat, 1.0 = 100% bloat)
    """
    stats = get_db_stats(db_path)
    return stats.get('bloat_ratio', 0.0)


def run_cleanup(dry_run: bool = False, verbose: bool = False, force: bool = False) -> Dict[str, Any]:
    """
    Run cleanup/maintenance on all repositories.
    
    This is the CLI cleanup command that processes all repos.
    
    Args:
        dry_run: If True, show what would be done without actually doing it
        verbose: If True, show detailed output
        force: If True, force vacuum even if bloat is low
        
    Returns:
        Dictionary with cleanup results:
        {
            'repos_processed': int,
            'total_checkpointed': int,
            'total_vacuumed': int,
            'total_pruned': int,
            'errors': List[str]
        }
        Or {'error': str} if scans directory doesn't exist
    """
    from reachable.config_manager import load_config
    
    scans_dir = Path.home() / '.reachable' / 'scans'
    
    if not scans_dir.exists():
        return {'error': f"Scans directory not found: {scans_dir}"}
    
    config = load_config()
    
    result = {
        'repos_processed': 0,
        'total_checkpointed': 0,
        'total_vacuumed': 0,
        'total_pruned': 0,
        'space_reclaimed_mb': 0,
        'errors': []
    }
    
    # Find all repo.db files
    for repo_dir in scans_dir.iterdir():
        if not repo_dir.is_dir() or repo_dir.name.startswith('.'):
            continue
        
        repo_db = repo_dir / 'repo.db'
        if not repo_db.exists():
            continue
        
        try:
            if verbose:
                logger.info(f"Processing {repo_dir.name}...")
            
            if not dry_run:
                # Override config vacuum threshold if force=True
                if force:
                    # Force vacuum even if bloat is low
                    checkpoint_wal(repo_db)
                    vacuum_result = vacuum_database(repo_db, force=True)
                    result['total_checkpointed'] += 1
                    result['total_vacuumed'] += 1
                    result['space_reclaimed_mb'] += vacuum_result.get('space_reclaimed', 0) / (1024 * 1024)
                    
                    # Also run pruning
                    from .database_storage import RepoDatabase
                    db = RepoDatabase(repo_db)
                    prune_result = db.cleanup_old_scans()
                    result['total_pruned'] += prune_result.get('scans_deleted', 0)
                    db.close()
                else:
                    # Normal auto-maintenance (respects config)
                    maint_result = run_auto_maintenance(repo_db, config)
                    
                    if maint_result.get('checkpointed'):
                        result['total_checkpointed'] += 1
                    if maint_result.get('vacuumed'):
                        result['total_vacuumed'] += 1
                    result['total_pruned'] += maint_result.get('pruned', 0)
                    result['errors'].extend(maint_result.get('errors', []))
            else:
                # Dry run: just count
                result['total_checkpointed'] += 1
            
            result['repos_processed'] += 1
            
        except Exception as e:
            error_msg = f"Failed to process {repo_dir.name}: {e}"
            result['errors'].append(error_msg)
            if verbose:
                logger.error(error_msg)
    
    return result


def format_size(bytes_count: int) -> str:
    """Format byte count to human-readable string."""
    for unit in ['B', 'KB', 'MB', 'GB']:
        if bytes_count < 1024:
            return f"{bytes_count:.1f} {unit}"
        bytes_count /= 1024
    return f"{bytes_count:.1f} TB"
