#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.

"""
REACHABLE Pipeline Message Bus
Treats metadata directory as a message bus for decoupled, stateless execution

Philosophy:
- Each scan step is a STATELESS function
- Inputs come from message bus (metadata dir)
- Outputs go to message bus (metadata dir)
- Steps don't know/care about execution environment
- Can run on laptop, CI/CD, containers, distributed workers

Message Bus Structure:
  .metadata/
  ├── 00-init.json           # Pipeline initialization
  ├── 01-sbom.json           # SBOM generation results
  ├── 02-vulns.json          # Vulnerability scan results
  ├── 03-libs.json           # Library cloning results
  ├── 04-security_findings.json        # Secrets detection results
  ├── 05-malware.json        # Malware detection results
  ├── 06-reachable.json      # Reachability analysis results
  ├── 07-correlation.json    # Correlation results
  └── 99-final.json          # Final aggregation

Each message is:
  {
    "step": "sbom-generation",
    "status": "success|failed|running",
    "timestamp": "2025-12-27T00:30:00",
    "input": {...},           # What this step received
    "output": {...},          # What this step produced
    "artifacts": {...},       # File paths created
    "error": "...",           # If failed
    "next_step": "..."        # Suggested next step
  }
"""

import json
import os
import time
from datetime import datetime
from pathlib import Path
from typing import Dict, Optional, Any, Callable
from enum import Enum
import logging

# Initialize module-level logger
logger = logging.getLogger(__name__)

class PipelineStep(Enum):
    """Pipeline steps in execution order"""
    INIT = "00-init"
    SBOM = "01-sbom"
    VULNS = "02-vulns"
    LIBS = "03-libs"
    SECRETS = "04-secrets"
    MALWARE = "05-malware"
    REACHABLE = "06-reachable"
    CORRELATION = "07-correlation"
    FINAL = "99-final"

class PipelineStatus(Enum):
    """Status of a pipeline step"""
    PENDING = "pending"
    RUNNING = "running"
    SUCCESS = "success"
    FAILED = "failed"
    SKIPPED = "skipped"

class MessageBus:
    """
    Message bus for pipeline communication via metadata directory.
    
    Each step:
    1. Reads message from previous step
    2. Executes its task (stateless)
    3. Writes message for next step
    
    Benefits:
    - Stateless execution (can restart any step)
    - Environment agnostic (laptop, CI/CD, containers)
    - Debuggable (all messages persisted)
    - Resumable (restart from any step)
    - Parallelizable (steps with no dependencies can run in parallel)
    """
    
    def __init__(self, metadata_dir: Path):
        """
        Initialize message bus.
        
        Args:
            metadata_dir: Directory for message passing
        """
        self.metadata_dir = Path(metadata_dir)
        self.metadata_dir.mkdir(parents=True, exist_ok=True)
    
    def _get_message_path(self, step: PipelineStep) -> Path:
        """Get path to message file for a step."""
        return self.metadata_dir / f"{step.value}.json"
    
    def write_message(self, step: PipelineStep, status: PipelineStatus, 
                     input_data: Optional[Dict] = None,
                     output_data: Optional[Dict] = None,
                     artifacts: Optional[Dict] = None,
                     error: Optional[str] = None,
                     next_step: Optional[PipelineStep] = None,
                     **metadata):
        """
        Write a message to the bus.
        
        This is how a step communicates its results to the next step.
        
        Args:
            step: Which step is writing
            status: Status of the step
            input_data: What this step received as input
            output_data: What this step produced
            artifacts: Paths to files created
            error: Error message if failed
            next_step: Suggested next step
            **metadata: Additional metadata
        """
        message = {
            "step": step.name.lower(),
            "status": status.value,
            "timestamp": datetime.now().isoformat(),
            "input": input_data or {},
            "output": output_data or {},
            "artifacts": artifacts or {},
            **metadata
        }
        
        if error:
            message["error"] = error
        
        if next_step:
            message["next_step"] = next_step.name.lower()
        
        message_path = self._get_message_path(step)
        with open(message_path, 'w') as f:
            json.dump(message, f, indent=2)
    
    def read_message(self, step: PipelineStep) -> Optional[Dict]:
        """
        Read a message from the bus.
        
        This is how a step gets input from the previous step.
        
        Returns:
            Message dictionary, or None if not exists
        """
        message_path = self._get_message_path(step)
        if message_path.exists():
            with open(message_path, 'r') as f:
                return json.load(f)
        return None
    
    def get_latest_completed_step(self) -> Optional[PipelineStep]:
        """
        Find the latest successfully completed step.
        
        Useful for resuming pipeline from last checkpoint.
        """
        for step in reversed(list(PipelineStep)):
            message = self.read_message(step)
            if message and message.get('status') == 'success':
                return step
        return None
    
    def get_pipeline_state(self) -> Dict:
        """
        Get complete state of the pipeline.
        
        Returns all messages in order.
        """
        state = {
            "metadata_dir": str(self.metadata_dir),
            "steps": {}
        }
        
        for step in PipelineStep:
            message = self.read_message(step)
            if message:
                state["steps"][step.name.lower()] = message
        
        return state
    
    def can_execute_step(self, step: PipelineStep) -> tuple[bool, Optional[str]]:
        """
        Check if a step can be executed.
        
        Returns:
            (can_execute, reason_if_not)
        """
        # INIT can always run
        if step == PipelineStep.INIT:
            return (True, None)
        
        # Check if previous steps are complete
        step_order = list(PipelineStep)
        current_index = step_order.index(step)
        
        # Check all previous steps
        for prev_step in step_order[:current_index]:
            # Special case: some steps are optional
            if prev_step in [PipelineStep.LIBS, PipelineStep.SECRETS, PipelineStep.MALWARE]:
                continue
            
            message = self.read_message(prev_step)
            if not message:
                return (False, f"Previous step '{prev_step.name}' not run")
            
            if message.get('status') != 'success':
                return (False, f"Previous step '{prev_step.name}' not successful")
        
        return (True, None)
    
    def clear_from_step(self, step: PipelineStep):
        """
        Clear all messages from a step onwards.
        
        Useful for re-running pipeline from a specific point.
        """
        step_order = list(PipelineStep)
        current_index = step_order.index(step)
        
        for clear_step in step_order[current_index:]:
            message_path = self._get_message_path(clear_step)
            if message_path.exists():
                message_path.unlink()

class StatelessPipelineExecutor:
    """
    Executes pipeline steps in a stateless manner.
    
    Each step is a pure function:
    - Reads input from message bus
    - Produces output to message bus
    - No shared state
    - Can run anywhere (laptop, CI/CD, container)
    """
    
    def __init__(self, metadata_dir: Path):
        """
        Initialize pipeline executor.
        
        Args:
            metadata_dir: Message bus directory
        """
        self.bus = MessageBus(metadata_dir)
    
    def execute_step(self, step: PipelineStep, step_function: Callable[[Dict], Dict],
                    skip_if_exists: bool = True) -> bool:
        """
        Execute a single pipeline step in a stateless manner.
        
        Args:
            step: Which step to execute
            step_function: Function to run (takes input dict, returns output dict)
            skip_if_exists: Skip if step already completed successfully
        
        Returns:
            True if successful, False otherwise
        
        Example:
            def run_sbom(input_data):
                # Read from input
                app_dir = input_data['app_dir']
                
                # Do work
                sbom_path = generate_sbom(app_dir)
                
                # Return output for next step
                return {
                    'sbom_path': sbom_path,
                    'packages_found': 25
                }
            
            executor.execute_step(PipelineStep.SBOM, run_sbom)
        """
        # Check if can execute
        can_run, reason = self.bus.can_execute_step(step)
        if not can_run:
            logger.info(f"❌ Cannot execute {step.name}: {reason}")
            return False
        
        # Check if already completed
        if skip_if_exists:
            existing = self.bus.read_message(step)
            if existing and existing.get('status') == 'success':
                logger.info(f"⏭️  Skipping {step.name} (already completed)")
                return True
        
        # Mark as running
        self.bus.write_message(step, PipelineStatus.RUNNING)
        
        try:
            logger.info(f"🔄 Executing {step.name}...")
            
            # Get input from previous step
            input_data = self._get_step_input(step)
            
            # Execute step function (STATELESS)
            start_time = time.time()
            output_data = step_function(input_data)
            duration = time.time() - start_time
            
            # Write success message
            self.bus.write_message(
                step=step,
                status=PipelineStatus.SUCCESS,
                input_data=input_data,
                output_data=output_data,
                artifacts=output_data.get('artifacts', {}),
                duration_seconds=duration
            )
            
            logger.info(f"✅ {step.name} completed ({duration:.1f}s)")
            return True
            
        except Exception as e:
            # Write failure message
            self.bus.write_message(
                step=step,
                status=PipelineStatus.FAILED,
                error=str(e)
            )
            
            logger.info(f"❌ {step.name} failed: {e}")
            return False
    
    def _get_step_input(self, step: PipelineStep) -> Dict:
        """
        Gather input for a step from previous steps.
        
        Reads from message bus to get outputs from previous steps.
        """
        input_data = {}
        
        # Add INIT data
        init_msg = self.bus.read_message(PipelineStep.INIT)
        if init_msg:
            input_data.update(init_msg.get('output', {}))
        
        # Add outputs from previous steps
        step_order = list(PipelineStep)
        current_index = step_order.index(step)
        
        for prev_step in step_order[:current_index]:
            msg = self.bus.read_message(prev_step)
            if msg and msg.get('status') == 'success':
                # Merge outputs from previous step
                input_data.update(msg.get('output', {}))
                
                # Also include artifacts
                artifacts = msg.get('artifacts', {})
                for key, value in artifacts.items():
                    input_data[f"{prev_step.name.lower()}_{key}"] = value
        
        return input_data
    
    def resume_pipeline(self) -> Optional[PipelineStep]:
        """
        Resume pipeline from last successful checkpoint.
        
        Returns:
            Next step to execute, or None if pipeline complete
        """
        last_completed = self.bus.get_latest_completed_step()
        
        if last_completed is None:
            logger.info("📍 No previous progress, starting from INIT")
            return PipelineStep.INIT
        
        logger.info(f"📍 Resuming from checkpoint: {last_completed.name}")
        
        # Find next step
        step_order = list(PipelineStep)
        current_index = step_order.index(last_completed)
        
        if current_index + 1 < len(step_order):
            next_step = step_order[current_index + 1]
            logger.info(f"▶️  Next step: {next_step.name}")
            return next_step
        else:
            logger.info("✅ Pipeline complete")
            return None

# Example: Complete stateless pipeline
def example_stateless_pipeline():
    """
    Example showing completely stateless execution.
    
    Can run on laptop, then continue on CI/CD, then finish on another laptop.
    """
    
    bus_dir = Path("demo-pipeline/.metadata")
    executor = StatelessPipelineExecutor(bus_dir)
    
    # Step 1: Init (define what we're scanning)
    def init_step(input_data):
        return {
            "project_name": "user-api",
            "language": "python",
            "app_dir": "/services/user-api",
            "manifest": "requirements.txt"
        }
    
    executor.execute_step(PipelineStep.INIT, init_step)
    
    # === STOP HERE, move to CI/CD === #
    
    # Step 2: SBOM (reads from INIT message)
    def sbom_step(input_data):
        app_dir = input_data['app_dir']
        # run syft...
        return {
            "sbom_path": "output/sbom.json",
            "packages_found": 25,
            "artifacts": {"sbom": "output/sbom.json"}
        }
    
    executor.execute_step(PipelineStep.SBOM, sbom_step)
    
    # === STOP HERE, move to different machine === #
    
    # Step 3: Vulns (reads from SBOM message)
    def vulns_step(input_data):
        sbom_path = input_data['sbom_path']
        # run grype...
        return {
            "vulns_path": "output/vulns.json",
            "cves_found": 15,
            "artifacts": {"vulns": "output/vulns.json"}
        }
    
    executor.execute_step(PipelineStep.VULNS, vulns_step)
    
    # All state is in .metadata/ directory
    # No in-memory state
    # Can resume from any point

if __name__ == "__main__":
    # Demo
    bus = MessageBus(Path("demo-bus"))
    
    # Simulate pipeline execution
    bus.write_message(
        PipelineStep.INIT,
        PipelineStatus.SUCCESS,
        output_data={"app_dir": "/test/app"}
    )
    
    bus.write_message(
        PipelineStep.SBOM,
        PipelineStatus.SUCCESS,
        input_data={"app_dir": "/test/app"},
        output_data={"sbom_path": "output/sbom.json", "packages": 10}
    )
    
    # Check state
    print(json.dumps(bus.get_pipeline_state(), indent=2))
    
    # Find what to do next
    latest = bus.get_latest_completed_step()
    logger.info(f"\nLatest completed: {latest.name if latest else 'None'}")
