#!/usr/bin/env python3
"""
Admin CLI - Hidden/debugging commands for REACHABLE

All non-user-facing commands should be under 'reachctl admin <command>'.
This keeps the main CLI clean while providing advanced debugging tools.

Commands:
    network-config    Display network timeout configurations
    audit            Audit scan metrics for consistency
    test             Run test suite (dev builds only)
    
Usage:
    reachctl admin network-config
    reachctl admin audit [--scan-path PATH] [--json]
    reachctl admin test [--verbose] [--quick]
"""

import argparse
import sys
import logging
from pathlib import Path

# Initialize module-level logger
logger = logging.getLogger(__name__)


def network_config_command(args):
    """
    Display network timeout configurations used by REACHABLE.
    
    Shows all network timeouts documented in TIMEOUTS.md
    """
    print("=" * 70)
    logger.info("REACHABLE NETWORK TIMEOUT CONFIGURATION")
    print("=" * 70)
    print()
    
    # Network timeout categories from TIMEOUTS.md
    timeouts = {
        "API Calls": {
            "description": "Quick lookups (EPSS, KEV, ExploitDB, Metasploit)",
            "connect": 10,
            "read": 30,
            "total": 40,
            "locations": [
                "epss_enrichment.py",
                "kev_enrichment.py", 
                "exploitdb_enrichment.py",
                "metasploit_enrichment.py"
            ]
        },
        "Downloads": {
            "description": "Large file downloads (vulnerability DB, YARA rules)",
            "connect": 20,
            "read": 120,
            "total": 140,
            "locations": [
                "vulndb.py (grype DB download)",
                "yara_rules_manager.py"
            ]
        },
        "Health Checks": {
            "description": "Fast pings (GitHub, PyPI, npm)",
            "connect": 5,
            "read": 10,
            "total": 15,
            "locations": [
                "health_metrics.py"
            ]
        },
        "Enrichment": {
            "description": "Multi-step enrichment (GHSA API with rate limits)",
            "connect": 15,
            "read": 45,
            "total": 60,
            "locations": [
                "ghsa_enrichment.py"
            ]
        }
    }
    
    # Display each category
    for category, config in timeouts.items():
        logger.info(f"{category}")
        print("-" * 70)
        logger.info(f"  Purpose:      {config['description']}")
        logger.info(f"  Connect:      {config['connect']}s")
        logger.info(f"  Read:         {config['read']}s")
        logger.info(f"  Total:        {config['total']}s")
        logger.info(f"  Used in:")
        for location in config['locations']:
            logger.info(f"    - {location}")
        print()
    
    # Summary
    print("=" * 70)
    logger.info("TIMEOUT PRINCIPLES")
    print("=" * 70)
    print()
    logger.info("1. Connect timeout < Read timeout")
    logger.info("   - Quick failure on unreachable hosts")
    logger.info("   - Generous time for slow responses")
    print()
    logger.info("2. Total timeout = Connect + Read")
    logger.info("   - Prevents indefinite hangs")
    logger.info("   - Predictable scan duration")
    print()
    logger.info("3. Category-specific tuning")
    logger.info("   - Fast health checks (15s)")
    logger.info("   - Quick API calls (40s)")
    logger.info("   - Patient downloads (140s)")
    print()
    
    return 0


def audit_command(args):
    """
    Audit scan metrics for consistency.
    
    Validates data consistency across:
    - Raw JSON files
    - Database records
    - Dashboard display
    """
    from .audit import ComprehensiveAuditor, find_latest_scan
    
    # Get scan path
    scan_path = Path(args.scan_path) if args.scan_path else None
    
    if not scan_path:
        scan_path = find_latest_scan()
        if not scan_path:
            logger.info("Error: No scans found. Run a scan first or specify --scan-path")
            return 1
    
    if not scan_path.exists():
        logger.info(f"Error: Scan directory not found: {scan_path}")
        return 1
    
    # Run comprehensive audit
    auditor = ComprehensiveAuditor(scan_path)
    
    raw = auditor.audit_raw()
    db = auditor.audit_database()
    dash = auditor.audit_dashboard()
    
    issues = auditor.compare_stages(raw, db, dash)
    
    passed = auditor.print_report(raw, db, dash, issues)
    
    return 0 if passed else 1


def test_command(args):
    """
    Run test suite (dev builds only).
    
    Requires pytest to be installed.
    """
    import subprocess
    
    print("=" * 60)
    logger.info("REACHABLE TEST SUITE")
    print("=" * 60)
    
    test_dir = Path(__file__).parent.parent / 'tests'
    if not test_dir.exists():
        test_dir = Path(__file__).parent / 'tests'
    
    if not test_dir.exists():
        logger.info("Test directory not found")
        logger.info("Tests are only available in the development distribution")
        return 1
    
    cmd = ['python', '-m', 'pytest', str(test_dir)]
    
    if args.verbose:
        cmd.append('-v')
    if args.quick:
        cmd.extend(['-m', 'not slow and not network'])
    if args.coverage:
        cmd.extend(['--cov=reachable', '--cov-report=html', '--cov-report=term'])
    if args.filter:
        cmd.extend(['-k', args.filter])
    
    logger.info(f"Command: {' '.join(cmd)}")
    print("-" * 60)
    
    try:
        result = subprocess.run(cmd, cwd=Path(__file__).parent.parent)
        return result.returncode
    except FileNotFoundError:
        logger.info("pytest not installed. Install with: pip install pytest pytest-cov")
        return 1


def cache_command(args):
    """Cache management placeholder - delegates to main CLI"""
    logger.info("Use: reachctl cache [--status|--clear]")
    return 0


def version_command(args):
    """Version info placeholder - delegates to main CLI"""
    logger.info("Use: reachctl version")
    return 0


def main():
    """
    Admin CLI entry point.
    
    Called from main reachctl as: reachctl admin <command>
    """
    parser = argparse.ArgumentParser(
        prog='reachctl admin',
        description='REACHABLE Admin Commands (hidden/debugging)',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  reachctl admin network-config
  reachctl admin audit
  reachctl admin test --quick

Note: These commands are for debugging and advanced use.
Regular users should use the main reachctl commands.
        """
    )
    
    subparsers = parser.add_subparsers(dest='command', metavar='COMMAND')
    
    # ==========================================================================
    # network-config - Display timeout configurations
    # ==========================================================================
    network_parser = subparsers.add_parser(
        'network-config',
        help='Display network timeout configurations',
        description='Show all network timeouts used by REACHABLE'
    )
    
    # ==========================================================================
    # audit - Comprehensive metrics audit
    # ==========================================================================
    audit_parser = subparsers.add_parser(
        'audit',
        help='Audit scan metrics for consistency',
        description='Validate data consistency across raw JSON, database, and dashboard'
    )
    audit_parser.add_argument(
        '--scan-path',
        metavar='PATH',
        help='Path to scan directory (auto-detect latest if not specified)'
    )
    audit_parser.add_argument(
        '--json',
        action='store_true',
        help='Output as JSON'
    )
    
    # ==========================================================================
    # test - Run test suite (dev builds only)
    # ==========================================================================
    test_parser = subparsers.add_parser(
        'test',
        help='Run test suite (dev builds only)',
        description='Execute pytest test suite with common configurations'
    )
    test_parser.add_argument('--verbose', '-v', action='store_true',
                            help='Verbose test output')
    test_parser.add_argument('--quick', '-q', action='store_true',
                            help='Skip slow/network tests')
    test_parser.add_argument('--coverage', '-c', action='store_true',
                            help='Generate coverage report')
    test_parser.add_argument('--filter', '-k', metavar='PATTERN',
                            help='Run tests matching pattern')
    
    # ==========================================================================
    # cache - Cache management
    # ==========================================================================
    cache_parser = subparsers.add_parser(
        'cache',
        help='Cache management',
        description='View, clear, or manage REACHABLE caches'
    )
    cache_parser.add_argument('--status', action='store_true',
                             help='Show cache status')
    cache_parser.add_argument('--clear', action='store_true',
                             help='Clear caches')
    
    # ==========================================================================
    # version - Detailed version info
    # ==========================================================================
    version_parser = subparsers.add_parser(
        'version',
        help='Detailed version information',
        description='Show REACHABLE version, tools, and system info'
    )
    
    # Parse and route
    # Strip 'admin' from sys.argv if present (cli.py sets argv to ['reachctl', 'admin', 'network-config'])
    args_to_parse = sys.argv[1:]
    if args_to_parse and args_to_parse[0] == 'admin':
        args_to_parse = args_to_parse[1:]
    
    args = parser.parse_args(args_to_parse)
    
    if not args.command:
        parser.print_help()
        return 0
    
    # Route to command handlers
    if args.command == 'network-config':
        return network_config_command(args)
    elif args.command == 'audit':
        return audit_command(args)
    elif args.command == 'test':
        return test_command(args)
    elif args.command == 'cache':
        return cache_command(args)
    elif args.command == 'version':
        return version_command(args)
    else:
        parser.print_help()
        return 1


if __name__ == '__main__':
    sys.exit(main())
