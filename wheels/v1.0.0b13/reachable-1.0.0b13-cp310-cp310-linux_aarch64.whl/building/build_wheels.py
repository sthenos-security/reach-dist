#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.

"""
REACHABLE Multi-Platform Build Script

Builds platform-specific wheels with:
1. C license extension (time bomb)
2. Optional Cython compilation for IP protection
3. Cross-platform support (macOS, Linux)

Usage:
    python build_wheels.py                    # Build for current platform
    python build_wheels.py --all              # Build for all platforms (requires Docker)
    python build_wheels.py --cython           # Include Cython compilation
    python build_wheels.py --clean            # Clean before build

Output:
    release/
        reachable-{version}-cp39-cp39-macosx_11_0_arm64.whl
        reachable-{version}-cp39-cp39-macosx_10_9_x86_64.whl
        reachable-{version}-cp39-cp39-manylinux_2_17_x86_64.whl
        reachable-{version}-cp39-cp39-manylinux_2_17_aarch64.whl
        ...
"""

import os
import sys
import shutil
import subprocess
import platform
from pathlib import Path
from typing import List, Optional
import argparse

# Configuration
# Script is in building/, so go up one level for repo root
PROJECT_ROOT = Path(__file__).parent.parent
VERSION_FILE = PROJECT_ROOT / 'VERSION'
RELEASE_DIR = PROJECT_ROOT / 'release'
BUILD_DIR = PROJECT_ROOT / 'build'

# Supported Python versions
PYTHON_VERSIONS = ['3.9', '3.10', '3.11', '3.12']

# Platform targets
PLATFORMS = {
    'macos_arm64': {
        'os': 'macosx',
        'arch': 'arm64',
        'tag': 'macosx_11_0_arm64',
    },
    'macos_x86_64': {
        'os': 'macosx',
        'arch': 'x86_64',
        'tag': 'macosx_10_9_x86_64',
    },
    'linux_x86_64': {
        'os': 'linux',
        'arch': 'x86_64',
        'tag': 'manylinux_2_17_x86_64',
    },
    'linux_aarch64': {
        'os': 'linux',
        'arch': 'aarch64',
        'tag': 'manylinux_2_17_aarch64',
    },
}

def get_version() -> str:
    """Read version from VERSION file"""
    if VERSION_FILE.exists():
        return VERSION_FILE.read_text().strip()
    return '0.0.0'

def get_current_platform() -> str:
    """Detect current platform"""
    system = platform.system().lower()
    machine = platform.machine().lower()
    
    if system == 'darwin':
        if machine in ('arm64', 'aarch64'):
            return 'macos_arm64'
        return 'macos_x86_64'
    elif system == 'linux':
        if machine in ('arm64', 'aarch64'):
            return 'linux_aarch64'
        return 'linux_x86_64'
    else:
        raise RuntimeError(f"Unsupported platform: {system} {machine}")

def clean():
    """Clean build artifacts"""
    print("🧹 Cleaning build artifacts...")
    
    dirs_to_clean = [
        BUILD_DIR,
        RELEASE_DIR,
        PROJECT_ROOT / 'reachable.egg-info',
        PROJECT_ROOT / '.eggs',
    ]
    
    for d in dirs_to_clean:
        if d.exists():
            shutil.rmtree(d)
            print(f"   Removed {d}")
    
    # Clean .so/.pyd files
    for ext in ['*.so', '*.pyd', '*.c']:
        for f in PROJECT_ROOT.rglob(f'reachable/**/{ext}'):
            if f.name != '_license.c':  # Keep source
                f.unlink()
                print(f"   Removed {f}")
    
    # Clean __pycache__
    for pycache in PROJECT_ROOT.rglob('__pycache__'):
        shutil.rmtree(pycache)

def check_dependencies():
    """Check build dependencies"""
    print("🔍 Checking dependencies...")
    
    required = ['wheel', 'setuptools', 'build']
    missing = []
    
    for pkg in required:
        try:
            __import__(pkg)
        except ImportError:
            missing.append(pkg)
    
    if missing:
        print(f"   Installing: {', '.join(missing)}")
        subprocess.run([sys.executable, '-m', 'pip', 'install'] + missing, check=True)
    
    print("   ✅ Dependencies ready")

def build_wheel(use_cython: bool = False, target_platform: str = None):
    """Build wheel for current/specified platform"""
    version = get_version()
    current = get_current_platform()
    target = target_platform or current
    
    print(f"📦 Building wheel v{version} for {target}")
    
    # Set environment for Cython
    env = os.environ.copy()
    if use_cython:
        env['REACHABLE_USE_CYTHON'] = '1'
        print("   Cython: Enabled (IP protection)")
    
    # Build
    cmd = [sys.executable, '-m', 'build', '--wheel', '--outdir', str(RELEASE_DIR)]
    
    result = subprocess.run(cmd, env=env, capture_output=True, text=True)
    
    if result.returncode != 0:
        print(f"❌ Build failed:\n{result.stderr}")
        return None
    
    # Find built wheel
    wheels = list(RELEASE_DIR.glob('*.whl'))
    if wheels:
        wheel = wheels[-1]
        print(f"   ✅ Built: {wheel.name}")
        return wheel
    
    return None

def build_manylinux(python_version: str = '3.11', arch: str = 'x86_64'):
    """Build manylinux wheel using Docker"""
    print(f"🐳 Building manylinux wheel (Python {python_version}, {arch})")
    
    # Use manylinux image
    if arch == 'aarch64':
        image = 'quay.io/pypa/manylinux_2_28_aarch64'
    else:
        image = 'quay.io/pypa/manylinux_2_28_x86_64'
    
    py_tag = f"cp{python_version.replace('.', '')}"
    
    cmd = [
        'docker', 'run', '--rm',
        '-v', f'{PROJECT_ROOT}:/io',
        '-w', '/io',
        image,
        'bash', '-c',
        f'/opt/python/{py_tag}-{py_tag}/bin/pip wheel . -w /io/dist/ --no-deps && '
        f'auditwheel repair /io/dist/*.whl -w /io/dist/'
    ]
    
    result = subprocess.run(cmd, capture_output=True, text=True)
    
    if result.returncode != 0:
        print(f"❌ Docker build failed:\n{result.stderr}")
        return None
    
    print(f"   ✅ Built manylinux wheel")
    return True

def build_all(use_cython: bool = False):
    """Build wheels for all platforms"""
    print("=" * 60)
    print("REACHABLE - Multi-Platform Build")
    print("=" * 60)
    print()
    
    version = get_version()
    current = get_current_platform()
    
    print(f"Version: {version}")
    print(f"Current platform: {current}")
    print(f"Cython: {'Enabled' if use_cython else 'Disabled'}")
    print()
    
    # Check if Docker is available for cross-platform builds
    docker_available = shutil.which('docker') is not None
    
    # Build for current platform
    print("-" * 60)
    wheel = build_wheel(use_cython)
    
    if not wheel:
        print("❌ Build failed")
        return False
    
    # Cross-platform builds require Docker
    if docker_available:
        print()
        print("-" * 60)
        print("Cross-platform builds (Docker):")
        
        # Build Linux wheels
        for arch in ['x86_64', 'aarch64']:
            for py in ['3.9', '3.10', '3.11', '3.12']:
                build_manylinux(py, arch)
    else:
        print()
        print("ℹ️  Docker not available - skipping cross-platform builds")
        print("   To build for all platforms, install Docker")
    
    print()
    print("=" * 60)
    print("Build complete!")
    print()
    print("Output:")
    for wheel in sorted(RELEASE_DIR.glob('*.whl')):
        size_mb = wheel.stat().st_size / (1024 * 1024)
        print(f"  {wheel.name} ({size_mb:.2f} MB)")
    
    return True

def main():
    parser = argparse.ArgumentParser(description='Build REACHABLE wheels')
    parser.add_argument('--all', action='store_true', help='Build for all platforms')
    parser.add_argument('--cython', action='store_true', help='Enable Cython compilation')
    parser.add_argument('--clean', action='store_true', help='Clean before build')
    parser.add_argument('--platform', choices=list(PLATFORMS.keys()), help='Target platform')
    
    args = parser.parse_args()
    
    os.chdir(PROJECT_ROOT)
    
    if args.clean:
        clean()
    
    check_dependencies()
    
    RELEASE_DIR.mkdir(exist_ok=True)
    
    if args.all:
        success = build_all(args.cython)
    else:
        wheel = build_wheel(args.cython, args.platform)
        success = wheel is not None
    
    sys.exit(0 if success else 1)

if __name__ == '__main__':
    main()
