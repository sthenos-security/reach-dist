#!/usr/bin/env python3
"""
Automatically fix missing logger imports in all reachable/*.py files

This script:
1. Finds all .py files that use 'logger' but don't import it
2. Adds the import statement automatically
3. Verifies the fix

Usage:
    python3 scripts/fix-logger-imports.py
    python3 scripts/fix-logger-imports.py --dry-run  # Preview only
"""

import sys
import re
from pathlib import Path
from typing import List, Tuple


def has_logger_usage(content: str) -> bool:
    """Check if file uses logger"""
    return bool(re.search(r'\blogger\s*\.', content) or re.search(r'\blogger\s*\(', content))


def has_logger_import(content: str) -> bool:
    """Check if file already imports logger"""
    patterns = [
        r'from reachable\.logger import',
        r'import reachable\.logger',
        r'from \.logger import',
        r'logger\s*=\s*logging\.getLogger',
        r'logger\s*=\s*get_logger',
    ]
    return any(re.search(pattern, content) for pattern in patterns)


def add_logger_import(content: str) -> str:
    """Add logger import to file"""
    
    # Find the last import statement
    lines = content.split('\n')
    last_import_idx = -1
    
    for i, line in enumerate(lines):
        stripped = line.strip()
        if stripped.startswith('import ') or stripped.startswith('from '):
            last_import_idx = i
        elif stripped and not stripped.startswith('#') and last_import_idx != -1:
            # Found first non-import, non-comment line
            break
    
    # If no imports found, add after module docstring
    if last_import_idx == -1:
        # Find end of docstring
        in_docstring = False
        docstring_end = 0
        
        for i, line in enumerate(lines):
            if '"""' in line or "'''" in line:
                if in_docstring:
                    docstring_end = i
                    break
                else:
                    in_docstring = True
        
        if docstring_end > 0:
            last_import_idx = docstring_end
        else:
            # No docstring, add at top
            last_import_idx = 0
    
    # Insert the import
    import_line = 'from reachable.logger import logger'
    
    # Add blank line before import if needed
    if last_import_idx > 0 and lines[last_import_idx].strip():
        lines.insert(last_import_idx + 1, '')
        lines.insert(last_import_idx + 2, import_line)
    else:
        lines.insert(last_import_idx + 1, import_line)
    
    return '\n'.join(lines)


def fix_file(filepath: Path, dry_run: bool = False) -> Tuple[bool, str]:
    """
    Fix a single file.
    
    Returns:
        (changed, message)
    """
    
    try:
        with open(filepath, 'r', encoding='utf-8') as f:
            content = f.read()
    except Exception as e:
        return False, f"Error reading: {e}"
    
    # Check if needs fixing
    if not has_logger_usage(content):
        return False, "No logger usage"
    
    if has_logger_import(content):
        return False, "Already has logger import"
    
    # Add import
    new_content = add_logger_import(content)
    
    if dry_run:
        return True, "Would add import (dry-run)"
    
    # Write back
    try:
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(new_content)
        return True, "✅ Added logger import"
    except Exception as e:
        return False, f"Error writing: {e}"


def main():
    import argparse
    
    parser = argparse.ArgumentParser(description='Fix missing logger imports')
    parser.add_argument('--dry-run', action='store_true', help='Preview changes without modifying files')
    parser.add_argument('--path', default='reachable', help='Path to scan (default: reachable)')
    args = parser.parse_args()
    
    # Find repo root
    script_dir = Path(__file__).parent
    repo_root = script_dir.parent
    target_dir = repo_root / args.path
    
    if not target_dir.exists():
        print(f"❌ Directory not found: {target_dir}")
        return 1
    
    print("=" * 70)
    print("FIXING MISSING LOGGER IMPORTS")
    print("=" * 70)
    print()
    
    if args.dry_run:
        print("🔍 DRY RUN MODE - No files will be modified")
        print()
    
    # Find all Python files
    python_files = list(target_dir.glob('**/*.py'))
    
    print(f"Scanning {len(python_files)} Python files in {target_dir}...")
    print()
    
    fixed = []
    skipped = []
    errors = []
    
    for py_file in python_files:
        # Skip __pycache__
        if '__pycache__' in str(py_file):
            continue
        
        # Skip logger.py itself
        if py_file.name == 'logger.py':
            continue
        
        changed, message = fix_file(py_file, dry_run=args.dry_run)
        
        relative_path = py_file.relative_to(repo_root)
        
        if changed:
            fixed.append(relative_path)
            print(f"✅ {relative_path}: {message}")
        elif 'Error' in message:
            errors.append(relative_path)
            print(f"❌ {relative_path}: {message}")
        else:
            skipped.append(relative_path)
            # Don't print skipped files (too noisy)
    
    print()
    print("=" * 70)
    print("SUMMARY")
    print("=" * 70)
    print(f"Files fixed:   {len(fixed)}")
    print(f"Files skipped: {len(skipped)}")
    print(f"Errors:        {len(errors)}")
    print()
    
    if fixed:
        print("Fixed files:")
        for f in fixed:
            print(f"  • {f}")
        print()
    
    if errors:
        print("Errors:")
        for f in errors:
            print(f"  • {f}")
        print()
    
    if args.dry_run and fixed:
        print("⚠️  DRY RUN: No files were actually modified")
        print("   Run without --dry-run to apply changes")
    elif fixed:
        print("✅ All imports added successfully!")
        print()
        print("Next steps:")
        print("  1. Review changes: git diff reachable/")
        print("  2. Test imports: python3 tests/test_module_imports.py")
        print("  3. Commit changes: git add reachable/ && git commit -m 'Fix missing logger imports'")
    
    return 0 if len(errors) == 0 else 1


if __name__ == '__main__':
    sys.exit(main())
