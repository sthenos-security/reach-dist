#!/usr/bin/env python3
# =============================================================================
# update_copyright.py - Update copyright headers in all source files
# Copyright © 2026 Sthenos Security. All rights reserved.
# =============================================================================

"""
Update all Python files to use standard Sthenos Security copyright header.

Usage:
    python scripts/update_copyright.py
"""

import re
from pathlib import Path

REPO_ROOT = Path(__file__).parent.parent

PYTHON_HEADER = "# Copyright © 2026 Sthenos Security. All rights reserved."

BASH_HEADER = """# =============================================================================
# Copyright © 2026 Sthenos Security. All rights reserved.
# ============================================================================="""


def update_python_file(filepath: Path) -> bool:
    """Update a Python file's copyright header."""
    try:
        content = filepath.read_text()
    except Exception as e:
        print(f"  ✗ Cannot read {filepath}: {e}")
        return False
    
    original = content
    
    # Skip if already has correct header
    if PYTHON_HEADER in content:
        return False
    
    lines = content.split('\n')
    new_lines = []
    inserted = False
    
    for i, line in enumerate(lines):
        # Keep shebang at top
        if i == 0 and line.startswith('#!'):
            new_lines.append(line)
            new_lines.append(PYTHON_HEADER)
            inserted = True
            continue
        
        # Skip old copyright lines
        if 'Copyright' in line and '2026' in line:
            continue
        if line.strip() == '# See LICENSE':
            continue
        if 'Sthenos Security' in line and line.startswith('#'):
            continue
            
        new_lines.append(line)
    
    # If no shebang, add header at top
    if not inserted:
        new_lines.insert(0, PYTHON_HEADER)
    
    content = '\n'.join(new_lines)
    
    # Clean up excessive newlines
    content = re.sub(r'\n{3,}', '\n\n', content)
    
    if content != original:
        filepath.write_text(content)
        return True
    return False


def update_bash_file(filepath: Path) -> bool:
    """Update a Bash file's copyright header."""
    try:
        content = filepath.read_text()
    except Exception as e:
        print(f"  ✗ Cannot read {filepath}: {e}")
        return False
    
    # Skip if already has copyright
    if "Copyright © 2026 Sthenos Security" in content:
        return False
    
    original = content
    lines = content.split('\n')
    
    # Find where to insert (after shebang and any existing header block)
    insert_idx = 0
    if lines and lines[0].startswith('#!'):
        insert_idx = 1
    
    # Skip existing header block
    while insert_idx < len(lines) and lines[insert_idx].startswith('# ==='):
        insert_idx += 1
        while insert_idx < len(lines) and lines[insert_idx].startswith('#'):
            if lines[insert_idx].startswith('# ==='):
                insert_idx += 1
                break
            insert_idx += 1
    
    # Already has a header block, skip
    if insert_idx > 2:
        return False
    
    # Insert after shebang
    if lines[0].startswith('#!'):
        new_content = lines[0] + '\n' + BASH_HEADER + '\n' + '\n'.join(lines[1:])
    else:
        new_content = BASH_HEADER + '\n' + content
    
    if new_content != original:
        filepath.write_text(new_content)
        return True
    return False


def main():
    print("=" * 60)
    print("STHENOS SECURITY - Copyright Header Update")
    print("=" * 60)
    
    updated = 0
    skipped = 0
    
    # Update Python files
    print("\n📄 Python files:")
    for py_file in REPO_ROOT.rglob("*.py"):
        skip_patterns = ['__pycache__', '.venv', 'venv', 'node_modules', '.git', 
                        'build-venv', 'test-venv', 'egg-info']
        if any(x in str(py_file) for x in skip_patterns):
            continue
        
        rel_path = py_file.relative_to(REPO_ROOT)
        if update_python_file(py_file):
            print(f"  ✓ {rel_path}")
            updated += 1
        else:
            skipped += 1
    
    # Update Bash files
    print("\n📜 Bash scripts:")
    for sh_file in REPO_ROOT.rglob("*.sh"):
        skip_patterns = ['.venv', 'venv', 'node_modules', '.git', 'build-venv']
        if any(x in str(sh_file) for x in skip_patterns):
            continue
        
        rel_path = sh_file.relative_to(REPO_ROOT)
        if update_bash_file(sh_file):
            print(f"  ✓ {rel_path}")
            updated += 1
        else:
            skipped += 1
    
    print("\n" + "=" * 60)
    print(f"Updated: {updated} files")
    print(f"Skipped: {skipped} files (already have copyright)")
    print("=" * 60)


if __name__ == "__main__":
    main()
