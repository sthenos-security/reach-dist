#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.

"""
REACHABLE P6.13: Garak Rule Extraction
======================================
Converts NVIDIA Garak LLM vulnerability probes into Semgrep rules.

Rule ID Format: garak-{probe_name}-{number}
Examples:
  - garak-promptinject-001
  - garak-dan-003
  - garak-encoding-007

Policy Mapping (from RISK_SCORING_MODEL.md):
  - garak-promptinject-* → AI-001 (Direct Prompt Injection) → LLM01
  - garak-dan-* → AI-001 (Direct Prompt Injection) → LLM01
  - garak-encoding-* → AI-001 (Prompt Injection Evasion) → LLM01
  - garak-continuation-* → AI-001 (Prompt Injection) → LLM01
  - garak-knownbadsignatures-* → AI-001 (Known Jailbreaks) → LLM01
  - garak-leakreplay-* → AI-003 (Sensitive Disclosure) → LLM02
  - garak-realtoxic-* → AI-003 (Toxic Content) → LLM02
  - garak-xss-* → AI-005 (Output Handling) → LLM05
  - garak-malwaregen-* → AI-005 (Output Handling) → LLM05
  - garak-packagehallucination-* → AI-004 (Supply Chain) → LLM03

Usage:
    # Clone Garak first:
    git clone https://github.com/NVIDIA/garak.git /tmp/garak
    
    # Run extraction:
    python scripts/ai_rules/garak_to_semgrep.py --garak-path /tmp/garak
    
    # Or download and extract in one step:
    python scripts/ai_rules/garak_to_semgrep.py --download

Output:
    reachable/ai/detectors/semgrep/garak_derived/garak-rules.yaml
    reachable/ai/detectors/semgrep/garak_derived/MANIFEST.yaml

Copyright (c) 2026 Sthenos Security. All rights reserved.
"""

import argparse
import ast
import os
import re
import subprocess
import sys
from collections import defaultdict
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Set

# ════════════════════════════════════════════════════════════════════════════════
# CONFIGURATION
# ════════════════════════════════════════════════════════════════════════════════

SCRIPT_DIR = Path(__file__).parent
REPO_ROOT = SCRIPT_DIR.parent.parent
OUTPUT_DIR = REPO_ROOT / "reachable" / "ai" / "detectors" / "semgrep" / "garak_derived"

# Garak probe to REACHABLE policy mapping
PROBE_CONFIG = {
    'promptinject': {
        'policy_id': 'AI-001',
        'owasp_llm': 'LLM01',
        'cwe': 'CWE-77',
        'description': 'Prompt injection instruction override',
        'severity': 'WARNING',
    },
    'encoding': {
        'policy_id': 'AI-001',
        'owasp_llm': 'LLM01',
        'cwe': 'CWE-77',
        'description': 'Encoded prompt injection evasion',
        'severity': 'WARNING',
    },
    'dan': {
        'policy_id': 'AI-001',
        'owasp_llm': 'LLM01',
        'cwe': 'CWE-77',
        'description': 'DAN jailbreak attempt',
        'severity': 'WARNING',
    },
    'continuation': {
        'policy_id': 'AI-001',
        'owasp_llm': 'LLM01',
        'cwe': 'CWE-77',
        'description': 'Continuation-based prompt manipulation',
        'severity': 'INFO',
    },
    'knownbadsignatures': {
        'policy_id': 'AI-001',
        'owasp_llm': 'LLM01',
        'cwe': 'CWE-77',
        'description': 'Known jailbreak signature',
        'severity': 'WARNING',
    },
    'realtoxicprompts': {
        'policy_id': 'AI-003',
        'owasp_llm': 'LLM02',
        'cwe': 'CWE-1021',
        'description': 'Toxic content generation',
        'severity': 'INFO',
    },
    'packagehallucination': {
        'policy_id': 'AI-004',
        'owasp_llm': 'LLM03',
        'cwe': 'CWE-1021',
        'description': 'Package hallucination trigger',
        'severity': 'INFO',
    },
    'leakreplay': {
        'policy_id': 'AI-003',
        'owasp_llm': 'LLM02',
        'cwe': 'CWE-200',
        'description': 'Training data extraction attempt',
        'severity': 'WARNING',
    },
    'xss': {
        'policy_id': 'AI-005',
        'owasp_llm': 'LLM05',
        'cwe': 'CWE-79',
        'description': 'XSS payload via LLM output',
        'severity': 'WARNING',
    },
    'snowball': {
        'policy_id': 'AI-001',
        'owasp_llm': 'LLM01',
        'cwe': 'CWE-77',
        'description': 'Snowball manipulation',
        'severity': 'INFO',
    },
    'misleading': {
        'policy_id': 'AI-003',
        'owasp_llm': 'LLM09',
        'cwe': 'CWE-1021',
        'description': 'Misinformation generation',
        'severity': 'INFO',
    },
    'lmrc': {
        'policy_id': 'AI-001',
        'owasp_llm': 'LLM01',
        'cwe': 'CWE-77',
        'description': 'Language Model Risk Cards pattern',
        'severity': 'INFO',
    },
    'gcg': {
        'policy_id': 'AI-001',
        'owasp_llm': 'LLM01',
        'cwe': 'CWE-77',
        'description': 'GCG adversarial suffix attack',
        'severity': 'WARNING',
    },
    'malwaregen': {
        'policy_id': 'AI-005',
        'owasp_llm': 'LLM05',
        'cwe': 'CWE-94',
        'description': 'Malware generation attempt',
        'severity': 'ERROR',
    },
}

# Keywords indicating attack patterns
ATTACK_KEYWORDS = [
    'ignore', 'disregard', 'forget', 'pretend', 'roleplay',
    'jailbreak', 'bypass', 'override', 'you are now', 'act as',
    'new instructions', 'system:', 'developer mode', 'DAN',
    'do anything', 'no restrictions', 'unlimited', 'uncensored',
    'ignore previous', 'forget everything', 'you must', 'always respond',
]

MIN_PATTERN_LENGTH = 15
MAX_PATTERNS_PER_PROBE = 30


# ════════════════════════════════════════════════════════════════════════════════
# DATA CLASSES
# ════════════════════════════════════════════════════════════════════════════════

@dataclass
class ExtractedPattern:
    """A pattern extracted from a Garak probe."""
    text: str
    probe_name: str
    source_file: str
    line_number: int = 0


@dataclass 
class GeneratedRule:
    """A Semgrep rule generated from extracted patterns."""
    rule_id: str
    probe_name: str
    pattern_regex: str
    policy_id: str
    owasp_llm: str
    cwe: str
    description: str
    severity: str
    source_patterns: List[str] = field(default_factory=list)


# ════════════════════════════════════════════════════════════════════════════════
# PATTERN EXTRACTION
# ════════════════════════════════════════════════════════════════════════════════

class GarakExtractor:
    """Extracts attack patterns from Garak probe source files."""
    
    def __init__(self, garak_path: Path):
        self.garak_path = garak_path
        self.probes_dir = garak_path / "garak" / "probes"
        self.patterns: Dict[str, List[ExtractedPattern]] = defaultdict(list)
        self.seen_patterns: Set[str] = set()
        self.stats = {'files_parsed': 0, 'patterns_extracted': 0}
    
    def extract_all(self) -> Dict[str, List[ExtractedPattern]]:
        """Extract patterns from all configured probe files."""
        if not self.probes_dir.exists():
            raise FileNotFoundError(f"Garak probes directory not found: {self.probes_dir}")
        
        print(f"Extracting patterns from: {self.probes_dir}")
        
        for probe_name in PROBE_CONFIG.keys():
            probe_file = self.probes_dir / f"{probe_name}.py"
            if probe_file.exists():
                self._extract_from_file(probe_file, probe_name)
            else:
                print(f"  ⚠️  Probe file not found: {probe_name}.py")
        
        print(f"\n  Parsed {self.stats['files_parsed']} files")
        print(f"  Extracted {self.stats['patterns_extracted']} unique patterns")
        
        return dict(self.patterns)
    
    def _extract_from_file(self, filepath: Path, probe_name: str):
        """Extract patterns from a single probe file."""
        try:
            with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
                content = f.read()
            
            tree = ast.parse(content)
            patterns = []
            
            for node in ast.walk(tree):
                # Extract string literals
                if isinstance(node, ast.Constant) and isinstance(node.value, str):
                    pattern = node.value.strip()
                    if self._is_valid_pattern(pattern):
                        patterns.append(ExtractedPattern(
                            text=pattern,
                            probe_name=probe_name,
                            source_file=str(filepath),
                            line_number=getattr(node, 'lineno', 0)
                        ))
                
                # Extract from list assignments (prompts = [...], triggers = [...])
                if isinstance(node, ast.Assign):
                    for target in node.targets:
                        if isinstance(target, ast.Name) and target.id in ['prompts', 'triggers', 'payloads', 'prefixes', 'suffixes']:
                            if isinstance(node.value, ast.List):
                                for elt in node.value.elts:
                                    if isinstance(elt, ast.Constant) and isinstance(elt.value, str):
                                        pattern = elt.value.strip()
                                        if self._is_valid_pattern(pattern):
                                            patterns.append(ExtractedPattern(
                                                text=pattern,
                                                probe_name=probe_name,
                                                source_file=str(filepath),
                                                line_number=getattr(elt, 'lineno', 0)
                                            ))
            
            # Deduplicate and limit
            for pattern in patterns[:MAX_PATTERNS_PER_PROBE]:
                pattern_hash = pattern.text.lower()[:50]  # Use prefix for dedup
                if pattern_hash not in self.seen_patterns:
                    self.seen_patterns.add(pattern_hash)
                    self.patterns[probe_name].append(pattern)
                    self.stats['patterns_extracted'] += 1
            
            self.stats['files_parsed'] += 1
            print(f"  ✓ {probe_name}.py: {len(self.patterns[probe_name])} patterns")
            
        except SyntaxError as e:
            print(f"  ✗ {probe_name}.py: Syntax error - {e}")
        except Exception as e:
            print(f"  ✗ {probe_name}.py: Error - {e}")
    
    def _is_valid_pattern(self, text: str) -> bool:
        """Check if a string is likely an attack pattern."""
        if len(text) < MIN_PATTERN_LENGTH:
            return False
        if len(text) > 500:  # Too long, probably not a pattern
            return False
        if text.startswith('#') or text.startswith('//'):  # Comment
            return False
        if '\n' in text and text.count('\n') > 5:  # Multi-line, probably not
            return False
        
        # Must contain attack-related keywords
        text_lower = text.lower()
        return any(kw in text_lower for kw in ATTACK_KEYWORDS)


# ════════════════════════════════════════════════════════════════════════════════
# RULE GENERATION
# ════════════════════════════════════════════════════════════════════════════════

class RuleGenerator:
    """Generates Semgrep rules from extracted patterns."""
    
    def __init__(self):
        self.rules: List[GeneratedRule] = []
    
    def generate_rules(self, patterns: Dict[str, List[ExtractedPattern]]) -> List[GeneratedRule]:
        """Generate Semgrep rules from extracted patterns."""
        
        for probe_name, probe_patterns in patterns.items():
            config = PROBE_CONFIG.get(probe_name)
            if not config:
                continue
            
            for i, pattern in enumerate(probe_patterns):
                # Create regex from pattern
                regex = self._pattern_to_regex(pattern.text)
                if not regex:
                    continue
                
                rule = GeneratedRule(
                    rule_id=f"garak-{probe_name}-{i+1:03d}",
                    probe_name=probe_name,
                    pattern_regex=regex,
                    policy_id=config['policy_id'],
                    owasp_llm=config['owasp_llm'],
                    cwe=config['cwe'],
                    description=f"{config['description']}: {pattern.text[:50]}...",
                    severity=config['severity'],
                    source_patterns=[pattern.text]
                )
                self.rules.append(rule)
        
        return self.rules
    
    def _pattern_to_regex(self, text: str) -> Optional[str]:
        """Convert a text pattern to a regex suitable for Semgrep."""
        # Escape regex special characters
        escaped = re.escape(text)
        
        # Make whitespace flexible
        flexible = re.sub(r'\\ +', r'\\s+', escaped)
        
        # Limit length to avoid overly specific patterns
        if len(flexible) > 200:
            # Take first meaningful part
            words = text.split()[:10]
            if len(words) < 3:
                return None
            shortened = ' '.join(words)
            flexible = re.sub(r'\\ +', r'\\s+', re.escape(shortened))
        
        return flexible


# ════════════════════════════════════════════════════════════════════════════════
# OUTPUT GENERATION
# ════════════════════════════════════════════════════════════════════════════════

def write_semgrep_rules(rules: List[GeneratedRule], output_dir: Path):
    """Write rules to Semgrep YAML file."""
    output_dir.mkdir(parents=True, exist_ok=True)
    
    yaml_content = """# REACHABLE AI Security Module - Garak-Derived Rules
# Generated from NVIDIA Garak LLM vulnerability probes
# Copyright (c) 2026 Sthenos Security. All rights reserved.
#
# Source: https://github.com/NVIDIA/garak
# Generated: {timestamp}
#
# Policy Mapping:
#   - AI-001: Prompt Injection (Direct) → OWASP LLM01
#   - AI-003: Sensitive Disclosure → OWASP LLM02
#   - AI-004: AI Supply Chain → OWASP LLM03
#   - AI-005: Output Handling → OWASP LLM05

rules:
""".format(timestamp=datetime.now().isoformat())
    
    for rule in rules:
        yaml_content += f"""
  - id: {rule.rule_id}
    languages: [python, javascript, typescript, go]
    message: "{rule.description}"
    severity: {rule.severity}
    pattern-regex: "{rule.pattern_regex}"
    metadata:
      policy_id: {rule.policy_id}
      owasp_llm: {rule.owasp_llm}
      cwe: {rule.cwe}
      source: garak
      source_probe: {rule.probe_name}
      category: ai-security
      confidence: medium
"""
    
    output_file = output_dir / "garak-rules.yaml"
    with open(output_file, 'w') as f:
        f.write(yaml_content)
    
    print(f"\n✓ Wrote {len(rules)} rules to {output_file}")
    return output_file


def write_manifest(rules: List[GeneratedRule], output_dir: Path):
    """Write MANIFEST.yaml with rule→policy mappings."""
    
    manifest_content = """# REACHABLE AI Security Module - Garak Rules Manifest
# Maps rule IDs to security policies
#
# Generated: {timestamp}

manifest_version: "1.0"
source: garak
source_url: https://github.com/NVIDIA/garak
generated_at: "{timestamp}"
generator: "scripts/ai_rules/garak_to_semgrep.py"
generator_version: "1.0.0"

# Statistics
stats:
  total_rules: {total_rules}
  by_policy:
{by_policy}
  by_owasp_llm:
{by_owasp}

# Rule Mappings
rules:
""".format(
        timestamp=datetime.now().isoformat(),
        total_rules=len(rules),
        by_policy=_count_by_field(rules, 'policy_id'),
        by_owasp=_count_by_field(rules, 'owasp_llm'),
    )
    
    for rule in rules:
        manifest_content += f"""  - id: "{rule.rule_id}"
    policy_id: {rule.policy_id}
    owasp_llm: {rule.owasp_llm}
    cwe: {rule.cwe}
    source_probe: {rule.probe_name}
    description: "{rule.description[:80]}"
"""
    
    output_file = output_dir / "MANIFEST.yaml"
    with open(output_file, 'w') as f:
        f.write(manifest_content)
    
    print(f"✓ Wrote manifest to {output_file}")
    return output_file


def _count_by_field(rules: List[GeneratedRule], field: str) -> str:
    """Count rules by a field and format as YAML."""
    counts = defaultdict(int)
    for rule in rules:
        counts[getattr(rule, field)] += 1
    
    lines = []
    for key, count in sorted(counts.items()):
        lines.append(f"    {key}: {count}")
    return '\n'.join(lines)


# ════════════════════════════════════════════════════════════════════════════════
# MAIN
# ════════════════════════════════════════════════════════════════════════════════

def download_garak(target_dir: Path) -> Path:
    """Clone Garak repository."""
    print("Downloading Garak repository...")
    
    if target_dir.exists():
        print(f"  Using existing: {target_dir}")
        return target_dir
    
    subprocess.run([
        'git', 'clone', '--depth', '1',
        'https://github.com/NVIDIA/garak.git',
        str(target_dir)
    ], check=True)
    
    print(f"  ✓ Cloned to {target_dir}")
    return target_dir


def main():
    parser = argparse.ArgumentParser(
        description="Extract NVIDIA Garak probes and convert to Semgrep rules"
    )
    parser.add_argument(
        '--garak-path',
        type=Path,
        help='Path to existing Garak repository'
    )
    parser.add_argument(
        '--download',
        action='store_true',
        help='Download Garak to /tmp/garak'
    )
    parser.add_argument(
        '--output-dir',
        type=Path,
        default=OUTPUT_DIR,
        help='Output directory for rules'
    )
    
    args = parser.parse_args()
    
    print("=" * 60)
    print("REACHABLE P6.13: Garak Rule Extraction")
    print("=" * 60)
    
    # Get Garak path
    if args.download:
        garak_path = download_garak(Path('/tmp/garak'))
    elif args.garak_path:
        garak_path = args.garak_path
    else:
        # Check common locations
        for path in [Path('/tmp/garak'), Path.home() / 'garak', Path('./garak')]:
            if path.exists():
                garak_path = path
                break
        else:
            print("\nError: Garak not found. Use --download or --garak-path")
            sys.exit(1)
    
    print(f"\nUsing Garak from: {garak_path}")
    
    # Extract patterns
    print("\n[1/3] Extracting patterns from Garak probes...")
    extractor = GarakExtractor(garak_path)
    patterns = extractor.extract_all()
    
    if not patterns:
        print("No patterns extracted!")
        sys.exit(1)
    
    # Generate rules
    print("\n[2/3] Generating Semgrep rules...")
    generator = RuleGenerator()
    rules = generator.generate_rules(patterns)
    print(f"  Generated {len(rules)} rules")
    
    # Write output
    print("\n[3/3] Writing output files...")
    write_semgrep_rules(rules, args.output_dir)
    write_manifest(rules, args.output_dir)
    
    print("\n" + "=" * 60)
    print("COMPLETE")
    print("=" * 60)
    print(f"\nOutput: {args.output_dir}")
    print("\nNext steps:")
    print("  1. Review generated rules for false positives")
    print("  2. Run: reachctl scan <repo> --enable-ai --debug")
    print("  3. Add to CI/CD pipeline")


if __name__ == '__main__':
    main()
