#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.

"""
Cleanup script for bloated libs directory.
Removes unnecessary files/dirs that aren't needed for reachability analysis.
"""
import shutil
from pathlib import Path

# Directories to remove
CLEANUP_DIRS = {
    '.git', '.github', '.vscode', '.idea', 'docs', 'doc', 'documentation',
    'examples', 'example', 'test', 'tests', '__tests__', 'spec', 'specs',
    'benchmark', 'benchmarks', 'bench', 'fixtures', 'testdata', 'test-data',
    'coverage', '.nyc_output', 'node_modules', 'vendor', 'e2e', 'integration',
    'scripts', 'tools', '.circleci', '.travis', '.gitlab', 'demo', 'demos',
}

# Files to remove
CLEANUP_FILES = {
    'yarn.lock', 'package-lock.json', 'pnpm-lock.yaml', 'Gemfile.lock',
    'poetry.lock', 'Cargo.lock', '.gitignore', '.gitattributes', '.editorconfig',
    '.prettierrc', '.prettierrc.json', '.prettierrc.yaml', '.eslintrc',
    '.eslintrc.json', '.eslintrc.js', '.eslintignore', 'tsconfig.json',
    'tsconfig.build.json', 'jest.config.js', 'jest.config.ts', 'vitest.config.js',
    'vitest.config.ts', 'karma.conf.js', 'Makefile', 'Dockerfile',
    'docker-compose.yml', 'docker-compose.yaml', '.dockerignore', 'LICENSE',
    'LICENSE.md', 'LICENSE.txt', 'CONTRIBUTING.md', 'CHANGELOG.md', 'HISTORY.md',
    'CODE_OF_CONDUCT.md', 'SECURITY.md', '.npmignore', '.npmrc', 'renovate.json',
    'dependabot.yml',
}

def cleanup_libs(libs_dir: Path) -> dict:
    """Clean up the libs directory"""
    if not libs_dir.exists():
        print(f"❌ Directory not found: {libs_dir}")
        return {'removed_dirs': 0, 'removed_files': 0, 'bytes_freed': 0}
    
    removed_dirs = 0
    removed_files = 0
    bytes_freed = 0
    
    # Process each library directory
    for lib_path in libs_dir.iterdir():
        if not lib_path.is_dir() or lib_path.name == '.metadata':
            continue
        
        print(f"\n📦 Cleaning {lib_path.name}...")
        
        # Remove directories (recursive walk)
        for item in list(lib_path.rglob('*')):
            if item.is_dir() and item.name.lower() in {d.lower() for d in CLEANUP_DIRS}:
                try:
                    dir_size = sum(f.stat().st_size for f in item.rglob('*') if f.is_file())
                    bytes_freed += dir_size
                    print(f"   🗑️  Removing dir: {item.relative_to(lib_path)} ({dir_size/1024:.1f}KB)")
                    shutil.rmtree(item, ignore_errors=True)
                    removed_dirs += 1
                except Exception as e:
                    print(f"   ⚠️  Failed to remove {item}: {e}")
        
        # Remove files at any level
        for item in list(lib_path.rglob('*')):
            if item.is_file() and item.name in CLEANUP_FILES:
                try:
                    file_size = item.stat().st_size
                    bytes_freed += file_size
                    print(f"   🗑️  Removing file: {item.relative_to(lib_path)} ({file_size/1024:.1f}KB)")
                    item.unlink()
                    removed_files += 1
                except Exception as e:
                    print(f"   ⚠️  Failed to remove {item}: {e}")
        
        # Remove remaining dotfiles/dotdirs at root level
        for item in list(lib_path.iterdir()):
            if item.name.startswith('.') and item.name not in {'.dev'}:
                try:
                    if item.is_dir():
                        dir_size = sum(f.stat().st_size for f in item.rglob('*') if f.is_file())
                        bytes_freed += dir_size
                        print(f"   🗑️  Removing dotdir: {item.name} ({dir_size/1024:.1f}KB)")
                        shutil.rmtree(item, ignore_errors=True)
                        removed_dirs += 1
                    else:
                        file_size = item.stat().st_size
                        bytes_freed += file_size
                        print(f"   🗑️  Removing dotfile: {item.name} ({file_size/1024:.1f}KB)")
                        item.unlink()
                        removed_files += 1
                except Exception:
                    pass
    
    return {
        'removed_dirs': removed_dirs,
        'removed_files': removed_files,
        'bytes_freed': bytes_freed
    }

if __name__ == '__main__':
    libs_dir = Path('/Users/alaindazzi/.reachable/scans/nexee-dev-63dfdf93/main/20260107-193813-faeb1e/libs')
    
    print("🧹 REACHABLE Libs Cleanup Script")
    print("=" * 60)
    print(f"Target: {libs_dir}")
    
    result = cleanup_libs(libs_dir)
    
    print("\n" + "=" * 60)
    print("📊 CLEANUP SUMMARY")
    print("=" * 60)
    print(f"   Directories removed: {result['removed_dirs']}")
    print(f"   Files removed:       {result['removed_files']}")
    print(f"   Disk space freed:    {result['bytes_freed'] / (1024*1024):.2f} MB")
    print("=" * 60)
    print("✅ Done!")
