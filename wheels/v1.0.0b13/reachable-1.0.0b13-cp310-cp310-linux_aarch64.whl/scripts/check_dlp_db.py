#!/usr/bin/env python3
"""Check DLP findings in database"""
import sqlite3
import json

db_path = '/Users/alaindazzi/.reachable/scans/reach-testbed-2943c74e/repo.db'
conn = sqlite3.connect(db_path)
conn.row_factory = sqlite3.Row
cursor = conn.cursor()

# Check table schema
print("=== DLP_FINDINGS TABLE SCHEMA ===")
cursor.execute("PRAGMA table_info(dlp_findings)")
for col in cursor.fetchall():
    print(f"  {col['cid']:2d}: {col['name']:30s} {col['type']}")

# Check sample data
print("\n=== SAMPLE DLP FINDINGS (first 3) ===")
cursor.execute("SELECT * FROM dlp_findings LIMIT 3")
for row in cursor.fetchall():
    print(f"\n--- Finding ---")
    for key in row.keys():
        val = row[key]
        if val and len(str(val)) > 100:
            val = str(val)[:100] + "..."
        print(f"  {key}: {val}")

conn.close()
