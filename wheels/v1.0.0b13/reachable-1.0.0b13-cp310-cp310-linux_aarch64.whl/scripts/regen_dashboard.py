#!/usr/bin/env python3
"""
v4.6.3 Dashboard Regenerator
Run: python scripts/regen_dashboard.py
"""
import sys
sys.path.insert(0, '/Users/alaindazzi/src/reach-core')

from pathlib import Path
from reachable.dashboard_v2.generator import generate_dashboard

# Latest scan directory
scan_dir = Path('/Users/alaindazzi/.reachable/scans/reach-testbed-2943c74e/main/20260122-095718-eb5ee4')

print("🔄 Regenerating dashboard with v4.6.3 fixes...")
print()
print("v4.6.3 Changes:")
print("  - DLP table: file_path/line_start now used (was file/line)")
print("  - DLP table: 'Direct reference' → 'Confirmed flow (pii → sink)'")
print("  - DLP table: Location column shows actual file paths")
print()
print("v4.6.2 Changes:")
print("  - Fix column shows actions for ALL types (not just CVE)")
print("  - Better description fallbacks for each type")
print("  - Location column shows meaningful data")
print()

dashboard_dir = generate_dashboard(scan_dir)

print(f"✅ Dashboard regenerated: {dashboard_dir}")
print(f"   Open: file://{dashboard_dir / 'index.html'}")
