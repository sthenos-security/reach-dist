#!/usr/bin/env python3
"""
Fix Grype DB Cache - Apply patch to use shared ~/.reachable/cache/grype-db/

This script fixes the bug where Grype downloads its 200MB database to /tmp 
instead of using the shared cache at ~/.reachable/cache/grype-db/.

Root cause: subprocess.run() calls to grype don't include GRYPE_DB_CACHE_DIR env var.
Solution: Import get_grype_env() from vulndb.py and pass env= to all subprocess calls.
"""

import os
import sys
from pathlib import Path

FIXES = [
    {
        'file': 'reachable/monorepo_orchestrator.py',
        'function': '_scan_vulnerabilities',
        'line_approx': 121,
        'old_import': None,  # Add new import
        'new_import': 'from .vulndb import get_grype_env',
        'old_code': '''        with open(vulns_path, 'w') as f:
            result = subprocess.run(cmd, stdout=f, stderr=subprocess.PIPE, timeout=300)''',
        'new_code': '''        with open(vulns_path, 'w') as f:
            result = subprocess.run(
                cmd, 
                stdout=f, 
                stderr=subprocess.PIPE, 
                timeout=300,
                env=get_grype_env()  # Use shared cache at ~/.reachable/cache/grype-db/
            )'''
    },
    # Add more fixes here as we find them
]


def apply_fix(fix_spec: dict, dry_run: bool = False) -> bool:
    """Apply a single fix to a file."""
    file_path = Path(__file__).parent / fix_spec['file']
    
    if not file_path.exists():
        print(f"❌ File not found: {file_path}")
        return False
    
    print(f"\n📝 Patching: {fix_spec['file']}")
    print(f"   Function: {fix_spec['function']} (line ~{fix_spec['line_approx']})")
    
    content = file_path.read_text()
    
    # Add import if needed
    if fix_spec['new_import']:
        if fix_spec['new_import'] not in content:
            # Find the function and add import at top of function
            func_start = f"def {fix_spec['function']}("
            if func_start in content:
                # Find the first line after the docstring
                func_idx = content.index(func_start)
                # Find end of function signature (closing paren + colon)
                sig_end = content.index('):', func_idx) + 2
                # Find the docstring end
                next_triple_quote = content.find('"""', sig_end + 10)
                if next_triple_quote > 0:
                    insert_pos = next_triple_quote + 3
                else:
                    insert_pos = sig_end
                
                # Insert import after docstring
                lines = content[:insert_pos].split('\n')
                indent = '    '  # Standard 4-space indent for function body
                lines.append(f"{indent}{fix_spec['new_import']}")
                content = '\n'.join(lines) + content[insert_pos:]
                print(f"   ✅ Added import: {fix_spec['new_import']}")
    
    # Apply code change
    if fix_spec['old_code'] in content:
        content = content.replace(fix_spec['old_code'], fix_spec['new_code'])
        print(f"   ✅ Updated subprocess.run() call")
    else:
        print(f"   ⚠️  Old code pattern not found - may already be patched or file changed")
        print(f"   Looking for:")
        print(f"   {fix_spec['old_code'][:100]}...")
        return False
    
    if not dry_run:
        file_path.write_text(content)
        print(f"   💾 Saved changes")
    else:
        print(f"   🔍 DRY RUN - no changes made")
    
    return True


def main():
    dry_run = '--dry-run' in sys.argv
    
    print("="*70)
    print("REACHABLE Grype Cache Fix")
    print("="*70)
    print()
    print("Problem: Grype downloads 200MB DB to /tmp instead of shared cache")
    print("Solution: Pass env=get_grype_env() to all subprocess.run(grype) calls")
    print()
    
    if dry_run:
        print("🔍 DRY RUN MODE - No files will be modified")
        print()
    
    success_count = 0
    fail_count = 0
    
    for fix in FIXES:
        if apply_fix(fix, dry_run=dry_run):
            success_count += 1
        else:
            fail_count += 1
    
    print()
    print("="*70)
    print(f"✅ Applied: {success_count} fixes")
    if fail_count > 0:
        print(f"❌ Failed: {fail_count} fixes")
    print("="*70)
    
    if not dry_run:
        print()
        print("Next steps:")
        print("  1. Delete old cache: rm -rf ~/.reachable/cache/grype-db/")
        print("  2. Run scan: ./reachctl scan ~/src/reach-testbed --debug")
        print("  3. Verify: ls -lh ~/.reachable/cache/grype-db/")
        print("     Should see ~200MB grype DB")
        print("  4. Second scan should skip download (DB is fresh)")
    
    return 0 if fail_count == 0 else 1


if __name__ == '__main__':
    sys.exit(main())
