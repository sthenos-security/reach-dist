#!/usr/bin/env python3
"""Check DLP data in database"""
import sqlite3
import json

db_path = '/Users/alaindazzi/.reachable/scans/reach-testbed-2943c74e/repo.db'
conn = sqlite3.connect(db_path)
conn.row_factory = sqlite3.Row
cursor = conn.cursor()

cursor.execute("SELECT file_path, line_start, call_path, pii_type, sink_type FROM dlp_findings LIMIT 5")
rows = cursor.fetchall()

print("DLP Findings Sample:")
print("-" * 80)
for row in rows:
    print(f"  file_path: {row['file_path']}")
    print(f"  line_start: {row['line_start']}")
    print(f"  call_path: {row['call_path']}")
    print(f"  pii_type: {row['pii_type']}")
    print(f"  sink_type: {row['sink_type']}")
    print("-" * 40)

conn.close()
