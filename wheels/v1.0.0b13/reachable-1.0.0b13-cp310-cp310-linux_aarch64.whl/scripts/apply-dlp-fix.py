#!/usr/bin/env python3
"""Apply DLP null check fixes to template-shell-compiled.html"""

import sys
from pathlib import Path

TEMPLATE_PATH = Path(__file__).parent.parent / 'reachable/dashboard_v2/split/template-shell-compiled.html'

def apply_fixes():
    """Apply the three DLP null check fixes"""
    
    if not TEMPLATE_PATH.exists():
        print(f"❌ Template not found: {TEMPLATE_PATH}")
        sys.exit(1)
    
    print(f"📄 Reading template: {TEMPLATE_PATH}")
    content = TEMPLATE_PATH.read_text()
    
    # Backup
    backup_path = TEMPLATE_PATH.with_suffix('.html.backup-dlp-fix')
    print(f"💾 Creating backup: {backup_path}")
    backup_path.write_text(content)
    
    # Apply fixes
    print("🔧 Applying fixes...")
    
    # Fix 1: typeMount null check
    content = content.replace(
        '    typeMount.innerHTML = `',
        '    if(typeMount) typeMount.innerHTML = `'
    )
    
    # Fix 2: complianceMount null check
    content = content.replace(
        '    complianceMount.innerHTML = compHtml ? `',
        '    if(complianceMount) complianceMount.innerHTML = compHtml ? `'
    )
    
    # Fix 3: tableMount null check
    content = content.replace(
        '    tableMount.innerHTML = `',
        '    if(tableMount) tableMount.innerHTML = `'
    )
    
    # Write back
    print(f"💾 Writing fixed template...")
    TEMPLATE_PATH.write_text(content)
    
    # Verify
    print("✅ Verifying fixes...")
    fixed_content = TEMPLATE_PATH.read_text()
    
    checks = [
        ('if(typeMount) typeMount.innerHTML', 'typeMount null check'),
        ('if(complianceMount) complianceMount.innerHTML', 'complianceMount null check'),
        ('if(tableMount) tableMount.innerHTML', 'tableMount null check'),
    ]
    
    all_good = True
    for pattern, name in checks:
        if pattern in fixed_content:
            print(f"  ✅ {name}")
        else:
            print(f"  ❌ {name} FAILED")
            all_good = False
    
    if all_good:
        print("\n✅ ALL FIXES APPLIED SUCCESSFULLY")
        print("\nNext step:")
        print("  cd ~/src/reach-core")
        print("  ./reachctl-dev.sh ~/src/reach-testbed")
    else:
        print("\n❌ SOME FIXES FAILED - check the file manually")
        sys.exit(1)

if __name__ == '__main__':
    apply_fixes()
