#!/usr/bin/env python3
"""Check what data is in the dashboard data.json"""
import json
from pathlib import Path

data_path = Path('/Users/alaindazzi/.reachable/scans/reach-testbed-2943c74e/main/20260122-095718-eb5ee4/dashboard/data.json')

with open(data_path) as f:
    data = json.load(f)

print("=" * 80)
print("SAMPLE CVE FINDINGS")
print("=" * 80)

cves = [i for i in data.get('issues', []) if i.get('type') == 'CVE'][:3]

for i, cve in enumerate(cves, 1):
    print(f"\nCVE {i}:")
    print(f"  id: '{cve.get('id', 'MISSING')}'")
    print(f"  type: '{cve.get('type', 'MISSING')}'")
    print(f"  title: '{cve.get('title', 'MISSING')[:50]}...'")
    print(f"  description: '{cve.get('description', 'MISSING')[:50] if cve.get('description') else 'EMPTY'}...'")
    print(f"  package: '{cve.get('package', 'MISSING')}'")
    print(f"  file_path: '{cve.get('file_path', 'MISSING')}'")
    print(f"  severity: '{cve.get('severity', 'MISSING')}'")
    print(f"  fix_status: '{cve.get('fix_status', 'MISSING')}'")
    print(f"  fix_version: '{cve.get('fix_version', 'MISSING')}'")

print("\n")
print("=" * 80)
print("SAMPLE CWE FINDINGS")
print("=" * 80)

cwes = [i for i in data.get('issues', []) if i.get('type') == 'CWE'][:3]

for i, cwe in enumerate(cwes, 1):
    print(f"\nCWE {i}:")
    print(f"  id: '{cwe.get('id', 'MISSING')}'")
    print(f"  title: '{cwe.get('title', 'MISSING')[:50] if cwe.get('title') else 'EMPTY'}...'")
    print(f"  description: '{cwe.get('description', 'MISSING')[:50] if cwe.get('description') else 'EMPTY'}...'")
    print(f"  file_path: '{cwe.get('file_path', 'MISSING')}'")
    print(f"  severity: '{cwe.get('severity', 'MISSING')}'")

print("\n✅ Done")
