#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.
"""
REACHABLE Test Runner
=====================

Three-tier testing architecture:

Tier 1: Selftest (reachctl selftest)
    - Quick sanity check (~10-30 seconds)
    - Module imports, tool availability, basic instantiation
    - NO pytest required, NO network, NO real scans
    - Purpose: Verify installation works

Tier 2: Unit Tests (reachctl selftest --unit)
    - Comprehensive unit tests for all modules
    - Mocked external dependencies (no network, no tools)
    - Requires pytest
    - Purpose: Verify code correctness

Tier 3: Integration Tests (reachctl selftest --integration)
    - Real scans against reach-testbed fixtures
    - Compare results to expected-results/*.json
    - Requires reach-testbed repo alongside reach-core
    - Purpose: End-to-end validation

Usage:
    reachctl selftest                    # Tier 1: Quick check (no pytest)
    reachctl selftest --unit             # Tier 2: Unit tests (requires pytest)
    reachctl selftest --integration      # Tier 3: Integration (requires pytest + testbed)
    
Direct pytest usage:
    pytest tests/ -v                     # Unit tests
    pytest tests/ -v -m integration      # Integration tests
    pytest tests/ -v --cov=reachable     # With coverage
"""

import sys
import subprocess
import time
from pathlib import Path
from typing import Optional


class SelfTest:
    """
    Tier 1: Quick sanity check for installation validation.
    
    This is what runs when user does `reachctl selftest` (without --unit or --integration).
    Should complete in 10-30 seconds with no external dependencies like pytest.
    """
    
    # Core modules that MUST import (installation is broken if these fail)
    REQUIRED_MODULES = [
        ('reachable.cli', 'main'),
        ('reachable.reachable', 'ReachabilityAnalyzer'),
        ('reachable.semgrep_scanner', 'SemgrepScanner'),
        ('reachable.correlation_engine', 'ComprehensiveCorrelationEngine'),
        ('reachable.database_storage', 'RepoDatabase'),
    ]
    
    # Optional modules (warnings if missing, not failures)
    OPTIONAL_MODULES = [
        ('reachable.ai', 'AISecurityScanner'),
        ('reachable.dlp', 'DLPScanner'),
        ('reachable.guarddog_scanner', 'GuardDogScanner'),
        ('reachable.trufflehog_scanner', 'TruffleHogScanner'),
    ]
    
    # Required external tools
    REQUIRED_TOOLS = ['syft', 'grype', 'semgrep']
    
    # Optional external tools  
    OPTIONAL_TOOLS = ['guarddog', 'trufflehog']
    
    def __init__(self, verbose: bool = True):
        self.verbose = verbose
        self.passed = 0
        self.failed = 0
        self.warnings = 0
        
    def log(self, msg: str, level: str = "info"):
        if self.verbose:
            icons = {"ok": "✅", "fail": "❌", "warn": "⚠️", "info": "  "}
            print(f"  {icons.get(level, '  ')} {msg}")
    
    def run(self) -> int:
        """Run all selftest checks. Returns exit code (0=pass, 1=fail)."""
        print("=" * 60)
        print("REACHABLE SELFTEST")
        print("=" * 60)
        print()
        
        start = time.time()
        
        # Phase 1: Module imports
        print("Phase 1: Module Imports")
        print("-" * 40)
        self._check_modules()
        print()
        
        # Phase 2: Tool availability
        print("Phase 2: External Tools")
        print("-" * 40)
        self._check_tools()
        print()
        
        # Phase 3: Basic instantiation
        print("Phase 3: Component Instantiation")
        print("-" * 40)
        self._check_instantiation()
        print()
        
        # Summary
        elapsed = time.time() - start
        print("=" * 60)
        print(f"SELFTEST COMPLETE ({elapsed:.1f}s)")
        print("=" * 60)
        print()
        print(f"  Passed:   {self.passed}")
        print(f"  Failed:   {self.failed}")
        print(f"  Warnings: {self.warnings}")
        print()
        
        if self.failed > 0:
            print("❌ SELFTEST FAILED")
            print("   Run 'reachctl doctor' to diagnose and fix issues.")
            return 1
        elif self.warnings > 0:
            print("✅ SELFTEST PASSED (with warnings)")
            print("   Some optional components missing - core functionality works.")
            print()
            print("Next steps:")
            print("   reachctl scan /path/to/repo    # Run a scan")
            print("   reachctl selftest --unit       # Run unit tests (requires pytest)")
            return 0
        else:
            print("✅ SELFTEST PASSED")
            print("   REACHABLE is ready to use: reachctl scan /path/to/repo")
            return 0
    
    def _check_modules(self):
        """Check required and optional module imports."""
        for module_name, attr_name in self.REQUIRED_MODULES:
            try:
                module = __import__(module_name, fromlist=[attr_name])
                if hasattr(module, attr_name):
                    self.log(f"{module_name}.{attr_name}", "ok")
                    self.passed += 1
                else:
                    self.log(f"{module_name} missing {attr_name}", "fail")
                    self.failed += 1
            except Exception as e:
                self.log(f"{module_name}: {e}", "fail")
                self.failed += 1
        
        for module_name, attr_name in self.OPTIONAL_MODULES:
            try:
                module = __import__(module_name, fromlist=[attr_name])
                if hasattr(module, attr_name):
                    self.log(f"{module_name}.{attr_name}", "ok")
                    self.passed += 1
                else:
                    self.log(f"{module_name} (optional, missing {attr_name})", "warn")
                    self.warnings += 1
            except Exception as e:
                self.log(f"{module_name} (optional): {e}", "warn")
                self.warnings += 1
    
    def _check_tools(self):
        """Check external tool availability."""
        import shutil
        
        # Check in REACHABLE managed locations first
        reachable_home = Path.home() / '.reachable'
        tool_locations = {
            'syft': reachable_home / 'tools' / 'bin' / 'syft',
            'grype': reachable_home / 'tools' / 'bin' / 'grype',
            'semgrep': reachable_home / 'venv' / 'bin' / 'semgrep',
            'guarddog': reachable_home / 'guarddog-venv' / 'bin' / 'guarddog',
            'trufflehog': None,  # System PATH only
        }
        
        for tool in self.REQUIRED_TOOLS:
            found = False
            location = tool_locations.get(tool)
            if location and location.exists():
                found = True
                self.log(f"{tool} (managed)", "ok")
            elif shutil.which(tool):
                found = True
                self.log(f"{tool} (system)", "ok")
            
            if found:
                self.passed += 1
            else:
                self.log(f"{tool} NOT FOUND", "fail")
                self.failed += 1
        
        for tool in self.OPTIONAL_TOOLS:
            found = False
            location = tool_locations.get(tool)
            if location and location.exists():
                found = True
                self.log(f"{tool} (managed)", "ok")
            elif shutil.which(tool):
                found = True
                self.log(f"{tool} (system)", "ok")
            
            if found:
                self.passed += 1
            else:
                self.log(f"{tool} (optional)", "warn")
                self.warnings += 1
    
    def _check_instantiation(self):
        """Check that key components can be instantiated."""
        checks = [
            ("ReachabilityAnalyzer", self._check_reachability_analyzer),
            ("Database", self._check_database),
            ("DashboardGenerator", self._check_dashboard),
        ]
        
        for name, check_fn in checks:
            try:
                if check_fn():
                    self.log(f"{name} ready", "ok")
                    self.passed += 1
                else:
                    self.log(f"{name} check failed", "fail")
                    self.failed += 1
            except Exception as e:
                self.log(f"{name}: {e}", "fail")
                self.failed += 1
    
    def _check_reachability_analyzer(self) -> bool:
        """Verify ReachabilityAnalyzer can be imported (not instantiated - needs files)."""
        from reachable.reachable import ReachabilityAnalyzer
        return True  # Import success is enough
    
    def _check_database(self) -> bool:
        """Verify database module works."""
        from reachable.database_storage import RepoDatabase
        import tempfile
        with tempfile.TemporaryDirectory() as tmpdir:
            db_path = Path(tmpdir) / "test.db"
            db = RepoDatabase(db_path)
            db.close()
        return True
    
    def _check_dashboard(self) -> bool:
        """Verify dashboard generator can be imported."""
        from reachable.dashboard_v2.generator import DashboardV2Generator
        return True


class TestRunner:
    """
    Orchestrates pytest-based unit and integration tests.
    
    Called by `reachctl selftest --unit` or `reachctl selftest --integration`.
    Also provides run_all() for compatibility with cli.py.
    """
    
    def __init__(self, verbose: bool = True):
        self.verbose = verbose
        self.project_root = Path(__file__).parent.parent
        self.tests_dir = Path(__file__).parent
    
    def run_all(self, integration: bool = False, coverage: bool = False, unit: bool = False) -> int:
        """
        Main entry point called by cli.py selftest command.
        
        By default (no flags): runs quick SelfTest only (no pytest needed)
        With unit=True: runs unit tests (requires pytest)
        With integration=True: runs integration tests (requires pytest + testbed)
        With coverage=True: adds coverage report to unit tests
        """
        if integration:
            return self.run_integration_tests()
        elif unit:
            return self.run_unit_tests(coverage=coverage)
        else:
            # Default: Quick selftest (no pytest)
            test = SelfTest(verbose=self.verbose)
            return test.run()
    
    def run_unit_tests(self, coverage: bool = False) -> int:
        """Run Tier 2 unit tests via pytest using the reachable venv."""
        python_path = self._ensure_pytest()
        if not python_path:
            print()
            print("   Or run quick selftest instead: reachctl selftest")
            return 1
        
        cmd = [python_path, '-m', 'pytest', str(self.tests_dir)]
        cmd.extend(['-v', '--tb=short'])
        cmd.extend(['-m', 'not integration'])  # Exclude integration tests
        
        if coverage:
            cmd.extend(['--cov=reachable', '--cov-report=term-missing'])
        
        print("=" * 60)
        print("REACHABLE UNIT TESTS")
        print("=" * 60)
        print()
        print(f"Running: {' '.join(cmd)}")
        print()
        
        result = subprocess.run(cmd, cwd=self.project_root)
        return result.returncode
    
    def run_all_tests(self, coverage: bool = False) -> int:
        """Run all tests (unit + integration) via pytest using the reachable venv."""
        python_path = self._ensure_pytest()
        if not python_path:
            print()
            print("   Or run quick selftest instead: reachctl selftest --quick")
            return 1
        
        testbed = self._find_testbed()
        if not testbed:
            print("⚠️  Warning: reach-testbed not found, some integration tests may fail")
            print("   Clone it alongside reach-core:")
            print("   cd ~/src && git clone https://github.com/sthenos-security/reach-testbed.git")
            print()
        
        import os
        env = os.environ.copy()
        if testbed:
            env['TESTBED_PATH'] = str(testbed)
        
        cmd = [python_path, '-m', 'pytest', str(self.tests_dir)]
        cmd.extend(['-v', '--tb=short'])
        # No marker filter - run all tests
        
        if coverage:
            cmd.extend(['--cov=reachable', '--cov-report=term-missing'])
        
        print("=" * 60)
        print("REACHABLE ALL TESTS (UNIT + INTEGRATION)")
        print("=" * 60)
        print()
        print(f"Running: {' '.join(cmd)}")
        if testbed:
            print(f"Testbed: {testbed}")
        print()
        
        result = subprocess.run(cmd, cwd=self.project_root, env=env if testbed else None)
        return result.returncode
    
    def run_integration_tests(self) -> int:
        """Run Tier 3 integration tests via pytest using the reachable venv."""
        python_path = self._ensure_pytest()
        if not python_path:
            return 1
        
        testbed = self._find_testbed()
        if not testbed:
            print("❌ reach-testbed not found")
            print("   Clone it alongside reach-core:")
            print("   cd ~/src && git clone https://github.com/sthenos-security/reach-testbed.git")
            return 1
        
        import os
        env = os.environ.copy()
        env['TESTBED_PATH'] = str(testbed)
        
        cmd = [python_path, '-m', 'pytest', str(self.tests_dir)]
        cmd.extend(['-v', '--tb=short'])
        cmd.extend(['-m', 'integration'])
        
        print("=" * 60)
        print("REACHABLE INTEGRATION TESTS")
        print("=" * 60)
        print()
        print(f"Running: {' '.join(cmd)}")
        print(f"Testbed: {testbed}")
        print()
        
        result = subprocess.run(cmd, cwd=self.project_root, env=env)
        return result.returncode
    
    def _get_venv_python(self) -> Optional[Path]:
        """Get the reachable venv Python path."""
        reachable_venv = Path.home() / '.reachable' / 'venv'
        venv_python = reachable_venv / 'bin' / 'python'
        if venv_python.exists():
            return venv_python
        return None
    
    def _ensure_pytest(self) -> Optional[str]:
        """
        Ensure pytest is available in the reachable venv, installing if needed.
        
        Returns:
            Path to venv Python executable with pytest, or None if failed.
        """
        venv_python = self._get_venv_python()
        if not venv_python:
            print("❌ REACHABLE venv not found at ~/.reachable/venv")
            print("   Run 'reachctl doctor' to set up the environment.")
            return None
        
        # Check if pytest is already installed in venv
        try:
            result = subprocess.run(
                [str(venv_python), '-c', 'import pytest; print(pytest.__version__)'],
                capture_output=True,
                text=True,
                timeout=10
            )
            if result.returncode == 0:
                return str(venv_python)
        except:
            pass
        
        # pytest not available - install it into the venv
        print("📦 pytest not found in venv - installing...")
        
        pip_path = venv_python.parent / 'pip'
        if not pip_path.exists():
            print("❌ pip not found in venv")
            return None
        
        try:
            result = subprocess.run(
                [str(pip_path), 'install', 'pytest', 'pytest-cov'],
                capture_output=True,
                text=True,
                timeout=120
            )
            if result.returncode == 0:
                print("✅ pytest installed into reachable venv")
                print()
                return str(venv_python)
            else:
                print(f"❌ pip install failed: {result.stderr[:300]}")
        except subprocess.TimeoutExpired:
            print("❌ pip install timed out")
        except Exception as e:
            print(f"❌ Error installing pytest: {e}")
        
        return None
    
    def _find_testbed(self) -> Optional[Path]:
        import os
        
        # Check environment variable
        if os.environ.get('TESTBED_PATH'):
            p = Path(os.environ['TESTBED_PATH'])
            if p.exists():
                return p
        
        # Check common locations
        candidates = [
            self.project_root.parent / "reach-testbed",
            Path.home() / "src" / "reach-testbed",
        ]
        for p in candidates:
            if p.exists() and (p / "expected-results").exists():
                return p
        return None


def selftest(args=None) -> int:
    """
    Entry point for `reachctl selftest`.
    
    By default, runs quick Tier 1 selftest (no pytest needed).
    With --unit, runs Tier 2 unit tests (requires pytest).
    With --integration, runs Tier 3 integration tests (requires pytest + testbed).
    """
    quiet = getattr(args, 'quiet', False) if args else False
    
    # Check for extended test modes
    if args:
        if getattr(args, 'unit', False):
            runner = TestRunner(verbose=not quiet)
            return runner.run_unit_tests(coverage=getattr(args, 'coverage', False))
        
        if getattr(args, 'integration', False):
            runner = TestRunner(verbose=not quiet)
            return runner.run_integration_tests()
    
    # Default: Quick selftest (no pytest)
    test = SelfTest(verbose=not quiet)
    return test.run()


def main():
    """CLI entry point for direct execution."""
    import argparse
    
    parser = argparse.ArgumentParser(
        description='REACHABLE Test Runner',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog='''
Examples:
  python run_tests.py              # Quick selftest (no pytest)
  python run_tests.py --unit       # Run unit tests (requires pytest)
  python run_tests.py --integration # Run integration tests
  python run_tests.py --unit --coverage  # Unit tests with coverage
'''
    )
    parser.add_argument('--unit', '-u', action='store_true',
                        help='Run unit tests (Tier 2, requires pytest)')
    parser.add_argument('--integration', '-i', action='store_true',
                        help='Run integration tests (Tier 3, requires pytest + testbed)')
    parser.add_argument('--coverage', '-c', action='store_true',
                        help='Generate coverage report (with --unit)')
    parser.add_argument('--quiet', '-q', action='store_true',
                        help='Minimal output')
    
    args = parser.parse_args()
    sys.exit(selftest(args))


if __name__ == '__main__':
    main()
