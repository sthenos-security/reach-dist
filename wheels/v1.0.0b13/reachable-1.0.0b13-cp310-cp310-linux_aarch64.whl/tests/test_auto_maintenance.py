#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.

"""
Unit tests for auto-maintenance functionality.

Tests:
- Configuration management (load, save, get, set)
- Auto-maintenance operations (checkpoint, vacuum, prune)
- Cleanup command functionality
"""

import unittest
import tempfile
import shutil
import json
import sqlite3
from pathlib import Path
from datetime import datetime, timedelta
from unittest.mock import patch


class TestConfigManager(unittest.TestCase):
    """Test configuration management"""
    
    def setUp(self):
        """Setup temp directory for config"""
        self.temp_dir = Path(tempfile.mkdtemp())
        self.config_path = self.temp_dir / 'config.json'
        
        # Patch CONFIG_PATH
        import reachable.config_manager as cm
        self.original_config_path = cm.CONFIG_PATH
        cm.CONFIG_PATH = self.config_path
    
    def tearDown(self):
        """Cleanup temp directory"""
        shutil.rmtree(self.temp_dir)
        
        # Restore original CONFIG_PATH
        import reachable.config_manager as cm
        cm.CONFIG_PATH = self.original_config_path
    
    def test_default_config_creation(self):
        """Test that default config is created if missing"""
        from reachable.config_manager import load_config
        
        config = load_config()
        
        # Check default values
        self.assertTrue(config['auto_maintenance']['enabled'])
        self.assertEqual(config['auto_maintenance']['max_scans_per_branch'], 50)
        self.assertEqual(config['auto_maintenance']['max_age_days'], 30)
        self.assertEqual(config['auto_maintenance']['vacuum_threshold_pct'], 30)
        
        # Check file was created
        self.assertTrue(self.config_path.exists())
    
    def test_config_persistence(self):
        """Test config persists across loads"""
        from reachable.config_manager import load_config, set_config_value
        
        # Set a value
        set_config_value('auto_maintenance.max_scans_per_branch', 100)
        
        # Load again
        config = load_config()
        self.assertEqual(config['auto_maintenance']['max_scans_per_branch'], 100)
    
    def test_get_config_value(self):
        """Test getting config values with dot notation"""
        from reachable.config_manager import load_config, get_config_value
        
        # Load default config first
        load_config()
        
        # Get values
        value = get_config_value('auto_maintenance.enabled')
        self.assertTrue(value)
        
        value = get_config_value('auto_maintenance.max_scans_per_branch')
        self.assertEqual(value, 50)
        
        # Non-existent key
        value = get_config_value('nonexistent.key')
        self.assertIsNone(value)
    
    def test_set_config_value(self):
        """Test setting config values with dot notation"""
        from reachable.config_manager import set_config_value, get_config_value
        
        # Set values
        set_config_value('auto_maintenance.max_age_days', 60)
        set_config_value('auto_maintenance.enabled', False)
        
        # Verify
        self.assertEqual(get_config_value('auto_maintenance.max_age_days'), 60)
        self.assertFalse(get_config_value('auto_maintenance.enabled'))
    
    def test_is_auto_maintenance_enabled(self):
        """Test auto-maintenance enabled check"""
        from reachable.config_manager import is_auto_maintenance_enabled, set_config_value
        
        # Default should be enabled
        self.assertTrue(is_auto_maintenance_enabled())
        
        # Disable
        set_config_value('auto_maintenance.enabled', False)
        self.assertFalse(is_auto_maintenance_enabled())
        
        # Re-enable
        set_config_value('auto_maintenance.enabled', True)
        self.assertTrue(is_auto_maintenance_enabled())


class TestAutoMaintenance(unittest.TestCase):
    """Test auto-maintenance operations"""
    
    def setUp(self):
        """Setup temp database"""
        self.temp_dir = Path(tempfile.mkdtemp())
        self.db_path = self.temp_dir / 'test.db'
        
        # Create test database with WAL mode
        conn = sqlite3.connect(str(self.db_path))
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("CREATE TABLE test (id INTEGER PRIMARY KEY, data TEXT)")
        
        # Insert test data
        for i in range(1000):
            conn.execute("INSERT INTO test VALUES (?, ?)", (i, f"data{i}"))
        conn.commit()
        conn.close()
    
    def tearDown(self):
        """Cleanup temp directory"""
        shutil.rmtree(self.temp_dir)
    
    def test_checkpoint_wal(self):
        """Test WAL checkpoint"""
        from reachable.auto_maintenance import checkpoint_wal
        
        # WAL file should exist after writes
        wal_file = Path(str(self.db_path) + '-wal')
        
        # Checkpoint (may not remove WAL completely with PASSIVE)
        checkpoint_wal(self.db_path)
        
        # Should not raise exception
        self.assertTrue(True)
    
    def test_vacuum_database(self):
        """Test database vacuum"""
        from reachable.auto_maintenance import vacuum_database
        
        # Delete some rows to create freelist
        conn = sqlite3.connect(str(self.db_path))
        conn.execute("DELETE FROM test WHERE id < 500")
        conn.commit()
        conn.close()
        
        initial_size = self.db_path.stat().st_size
        
        # Vacuum
        vacuum_database(self.db_path)
        
        final_size = self.db_path.stat().st_size
        
        # Size should be smaller
        self.assertLessEqual(final_size, initial_size)
    
    def test_calculate_bloat_ratio(self):
        """Test bloat calculation"""
        from reachable.auto_maintenance import calculate_bloat_ratio
        
        # Fresh database should have low bloat
        bloat = calculate_bloat_ratio(self.db_path)
        self.assertGreaterEqual(bloat, 0.0)
        self.assertLessEqual(bloat, 1.0)
        
        # Delete data and check bloat increases
        conn = sqlite3.connect(str(self.db_path))
        conn.execute("DELETE FROM test WHERE id < 900")
        conn.commit()
        conn.close()
        
        bloat_after = calculate_bloat_ratio(self.db_path)
        self.assertGreater(bloat_after, bloat)
    
    def test_prune_old_scans_dry_run(self):
        """Test pruning in dry-run mode"""
        from reachable.auto_maintenance import prune_old_scans
        
        # Create mock scan structure
        repo_root = self.temp_dir / 'repo'
        branch_dir = repo_root / 'main'
        branch_dir.mkdir(parents=True)
        
        # Create 60 scan dirs with different timestamps
        now = datetime.now()
        for i in range(60):
            scan_time = now - timedelta(days=i)
            scan_name = scan_time.strftime('%Y%m%d-%H%M%S') + '-abc123'
            scan_dir = branch_dir / scan_name
            scan_dir.mkdir()
            (scan_dir / 'test.txt').write_text('test')
        
        # Dry run - should count but not remove
        removed = prune_old_scans(
            repo_root,
            max_scans_per_branch=50,
            max_age_days=30,
            dry_run=True
        )
        
        # Should identify scans to remove
        self.assertGreater(removed, 0)
        
        # But all directories should still exist
        remaining = len(list(branch_dir.iterdir()))
        self.assertEqual(remaining, 60)
    
    def test_prune_old_scans_actual(self):
        """Test actual pruning"""
        from reachable.auto_maintenance import prune_old_scans
        
        # Create mock scan structure
        repo_root = self.temp_dir / 'repo'
        branch_dir = repo_root / 'main'
        branch_dir.mkdir(parents=True)
        
        # Create 60 scan dirs
        now = datetime.now()
        for i in range(60):
            scan_time = now - timedelta(days=i)
            scan_name = scan_time.strftime('%Y%m%d-%H%M%S') + '-abc123'
            scan_dir = branch_dir / scan_name
            scan_dir.mkdir()
            (scan_dir / 'test.txt').write_text('test')
        
        # Actual prune
        removed = prune_old_scans(
            repo_root,
            max_scans_per_branch=50,
            max_age_days=30,
            dry_run=False
        )
        
        # Should have removed some
        self.assertGreater(removed, 0)
        
        # Remaining should be <= 50 (or <= 30 days old)
        remaining = len(list(branch_dir.iterdir()))
        self.assertLessEqual(remaining, 50)
    
    def test_run_auto_maintenance(self):
        """Test full auto-maintenance run"""
        from reachable.auto_maintenance import run_auto_maintenance
        
        config = {
            'auto_maintenance': {
                'enabled': True,
                'wal_checkpoint': True,
                'vacuum_threshold_pct': 0,  # Force vacuum
                'prune_enabled': False,  # Skip pruning for this test
                'max_scans_per_branch': 50,
                'max_age_days': 30,
            }
        }
        
        results = run_auto_maintenance(self.db_path, config)
        
        # Check results
        self.assertTrue(results['checkpointed'])
        self.assertTrue(results['vacuumed'])  # Should vacuum since threshold=0
        self.assertEqual(results['pruned'], 0)  # Pruning disabled
        self.assertEqual(len(results['errors']), 0)
    
    def test_run_auto_maintenance_disabled(self):
        """Test auto-maintenance when disabled"""
        from reachable.auto_maintenance import run_auto_maintenance
        
        config = {
            'auto_maintenance': {
                'enabled': False,
            }
        }
        
        results = run_auto_maintenance(self.db_path, config)
        
        # Should be skipped
        self.assertTrue(results.get('skipped'))
        self.assertEqual(results.get('reason'), 'auto-maintenance disabled')


class TestCleanupCommand(unittest.TestCase):
    """Test cleanup command functionality"""
    
    def setUp(self):
        """Setup mock REACHABLE directory"""
        self.temp_dir = Path(tempfile.mkdtemp())
        self.reachable_home = self.temp_dir / '.reachable'
        self.scans_dir = self.reachable_home / 'scans'
        self.scans_dir.mkdir(parents=True)
        
        # Patch Path.home()
        self.patcher = patch('pathlib.Path.home', return_value=self.temp_dir)
        self.patcher.start()
    
    def tearDown(self):
        """Cleanup"""
        self.patcher.stop()
        shutil.rmtree(self.temp_dir)
    
    def test_run_cleanup_no_repos(self):
        """Test cleanup when no repos exist"""
        from reachable.auto_maintenance import run_cleanup
        
        # Remove scans dir
        shutil.rmtree(self.scans_dir)
        
        results = run_cleanup(dry_run=True, verbose=False)
        
        # Should return error
        self.assertIn('error', results)
    
    def test_run_cleanup_dry_run(self):
        """Test cleanup in dry-run mode"""
        from reachable.auto_maintenance import run_cleanup
        
        # Create mock repo with database
        repo_dir = self.scans_dir / 'test-repo'
        repo_dir.mkdir()
        repo_db = repo_dir / 'repo.db'
        
        # Create minimal database
        conn = sqlite3.connect(str(repo_db))
        conn.execute("CREATE TABLE test (id INTEGER)")
        conn.commit()
        conn.close()
        
        results = run_cleanup(dry_run=True, verbose=False)
        
        # Should process repo without errors
        self.assertEqual(results['repos_processed'], 1)
        self.assertGreaterEqual(results['total_checkpointed'], 1)


def run_tests():
    """Run all tests"""
    # Create test suite
    loader = unittest.TestLoader()
    suite = unittest.TestSuite()
    
    # Add test classes
    suite.addTests(loader.loadTestsFromTestCase(TestConfigManager))
    suite.addTests(loader.loadTestsFromTestCase(TestAutoMaintenance))
    suite.addTests(loader.loadTestsFromTestCase(TestCleanupCommand))
    
    # Run tests
    runner = unittest.TextTestRunner(verbosity=2)
    result = runner.run(suite)
    
    # Return exit code
    return 0 if result.wasSuccessful() else 1


if __name__ == '__main__':
    import sys
    sys.exit(run_tests())
