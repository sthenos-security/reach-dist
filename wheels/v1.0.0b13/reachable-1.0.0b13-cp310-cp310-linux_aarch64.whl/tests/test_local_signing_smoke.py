#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.

"""
Local Wheel Signing Smoke Test

Tests that wheel signing and verification works locally (development mode).

Run with:
    pytest tests/test_local_signing_smoke.py -v
"""

import sys
import subprocess
import shutil
from pathlib import Path
import unittest

sys.path.insert(0, str(Path(__file__).parent.parent))


class TestLocalSigning(unittest.TestCase):
    """Test local wheel signing and verification"""
    
    @classmethod
    def setUpClass(cls):
        """Check prerequisites"""
        cls.script = Path(__file__).parent.parent / 'scripts' / 'test-local-signing.sh'
        cls.cosign_installed = shutil.which('cosign') is not None
    
    def test_signing_script_exists(self):
        """Signing script should exist"""
        self.assertTrue(self.script.exists())
    
    @unittest.skipUnless(shutil.which('cosign'), "cosign not installed")
    def test_local_signing_workflow(self):
        """Complete local signing workflow should work"""
        
        print("\n" + "=" * 70)
        print("RUNNING LOCAL SIGNING SMOKE TEST")
        print("=" * 70)
        
        result = subprocess.run(
            ['bash', str(self.script)],
            capture_output=True,
            text=True,
            timeout=120
        )
        
        print("\n--- Script Output ---")
        print(result.stdout)
        if result.stderr:
            print("--- Script Errors ---")
            print(result.stderr)
        print("=" * 70)
        
        self.assertEqual(result.returncode, 0)
        
        output = result.stdout + result.stderr
        self.assertIn('Built:', output)
        self.assertIn('Signed:', output)
        # Don't check for specific cosign output - just check SUCCESS which means verify returned 0
        self.assertIn('SUCCESS', output)
        self.assertIn('COMPLETE WORKFLOW VERIFIED', output)


if __name__ == '__main__':
    unittest.main()
