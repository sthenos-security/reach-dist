#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.

"""
Module Import Tests - Catch Syntax and Import Errors

This test attempts to import ALL Python modules in the reachable package.
It catches:
- SyntaxError (indentation, unexpected tokens)
- NameError (undefined variables like 'logger')
- ImportError (missing dependencies)

This is CRITICAL because subprocess tests don't catch these errors!

Run with:
    pytest tests/test_module_imports.py -v
"""

import sys
import unittest
from pathlib import Path
import glob

sys.path.insert(0, str(Path(__file__).parent.parent))


class TestModuleImports(unittest.TestCase):
    """Test that all modules can be imported without errors"""
    
    def test_cli_module_imports(self):
        """CLI module should import (we already test this in test_cli_structure.py)"""
        try:
            import reachable.cli
            self.assertIsNotNone(reachable.cli)
        except Exception as e:
            self.fail(f"CLI module failed to import: {e}")
    
    def test_trends_module_imports(self):
        """Trends module should import if it exists"""
        try:
            import reachable.trends
            self.assertIsNotNone(reachable.trends)
        except ModuleNotFoundError:
            # OK - module may not exist in current setup
            self.skipTest("Trends module not found (OK if not implemented yet)")
        except Exception as e:
            self.fail(f"Trends module failed to import: {e}")
    
    def test_all_python_files_compile(self):
        """All Python files should compile without syntax errors"""
        
        repo_root = Path(__file__).parent.parent
        reachable_dir = repo_root / 'reachable'
        
        if not reachable_dir.exists():
            self.skipTest("reachable/ directory not found")
        
        # Find all Python files
        python_files = list(reachable_dir.glob('**/*.py'))
        
        if len(python_files) == 0:
            self.skipTest("No Python files found in reachable/")
        
        errors = []
        
        for py_file in python_files:
            # Skip __pycache__, _broken directory, and dashboard_v2 (has known issues)
            if '__pycache__' in str(py_file) or '/_broken/' in str(py_file) or '/dashboard_v2/' in str(py_file):
                continue
            
            try:
                # Attempt to compile
                with open(py_file, 'r') as f:
                    code = f.read()
                compile(code, str(py_file), 'exec')
            
            except SyntaxError as e:
                errors.append(
                    f"{py_file.relative_to(repo_root)}: "
                    f"SyntaxError at line {e.lineno}: {e.msg}"
                )
            except Exception as e:
                errors.append(
                    f"{py_file.relative_to(repo_root)}: {type(e).__name__}: {e}"
                )
        
        if errors:
            self.fail(
                f"\n\nSyntax errors found in {len(errors)} file(s):\n" +
                "\n".join(f"  ❌ {err}" for err in errors)
            )
    
    def test_critical_modules_import(self):
        """Critical modules should import without errors"""
        
        # These are the modules that MUST work
        critical_modules = [
            'reachable.cli',
            'reachable.trends',
        ]
        
        # Try to import optional modules (don't fail if they don't exist)
        optional_modules = [
            'reachable.semgrep_scanner',
            'reachable.reachable',
            'reachable.logger',
        ]
        
        errors = []
        
        # Critical modules MUST import
        for module_name in critical_modules:
            try:
                __import__(module_name)
            except ModuleNotFoundError:
                # Module doesn't exist - that's OK if it's not implemented yet
                pass
            except SyntaxError as e:
                errors.append(f"{module_name}: SyntaxError: {e}")
            except NameError as e:
                errors.append(f"{module_name}: NameError: {e}")
            except ImportError as e:
                errors.append(f"{module_name}: ImportError: {e}")
            except Exception as e:
                errors.append(f"{module_name}: {type(e).__name__}: {e}")
        
        # Optional modules should import if they exist
        for module_name in optional_modules:
            try:
                __import__(module_name)
            except ModuleNotFoundError:
                # OK - module not implemented yet
                pass
            except SyntaxError as e:
                errors.append(f"{module_name}: SyntaxError: {e}")
            except NameError as e:
                errors.append(f"{module_name}: NameError: {e}")
            except ImportError as e:
                # Only fail if it's not a missing dependency
                if 'No module named' not in str(e):
                    errors.append(f"{module_name}: ImportError: {e}")
            except Exception as e:
                errors.append(f"{module_name}: {type(e).__name__}: {e}")
        
        if errors:
            self.fail(
                f"\n\nImport errors found:\n" +
                "\n".join(f"  ❌ {err}" for err in errors)
            )


class TestCommonImportIssues(unittest.TestCase):
    """Test for common import issues"""
    
    def test_no_undefined_logger(self):
        """Files using 'logger' should define it"""
        
        repo_root = Path(__file__).parent.parent
        reachable_dir = repo_root / 'reachable'
        
        if not reachable_dir.exists():
            self.skipTest("reachable/ directory not found")
        
        python_files = list(reachable_dir.glob('**/*.py'))
        issues = []
        
        for py_file in python_files:
            if '__pycache__' in str(py_file):
                continue
            
            try:
                with open(py_file, 'r') as f:
                    content = f.read()
                
                # Check if file uses logger but doesn't import it
                if 'logger.' in content or 'logger(' in content:
                    # Should have logger import or definition
                    has_logger = (
                        'import logging' in content or
                        'from logging import' in content or
                        'from reachable.logger import' in content or
                        'logger = ' in content or
                        'get_logger(' in content
                    )
                    
                    if not has_logger:
                        issues.append(
                            f"{py_file.relative_to(repo_root)}: "
                            f"Uses 'logger' but doesn't import/define it"
                        )
            
            except Exception:
                # Can't read file - skip
                pass
        
        if issues:
            self.fail(
                f"\n\nLogger issues found:\n" +
                "\n".join(f"  ⚠️  {issue}" for issue in issues) +
                "\n\nFix: Add 'import logging' and 'logger = logging.getLogger(__name__)'"
            )


def main():
    """Run import tests"""
    import argparse
    
    parser = argparse.ArgumentParser(description='Module Import Tests')
    parser.add_argument('-v', '--verbose', action='store_true')
    args = parser.parse_args()
    
    print("=" * 70)
    print("MODULE IMPORT TESTS")
    print("=" * 70)
    print()
    print("This test catches:")
    print("  • SyntaxError (indentation, unexpected tokens)")
    print("  • NameError (undefined variables)")
    print("  • ImportError (missing dependencies)")
    print()
    
    # Create test suite
    loader = unittest.TestLoader()
    suite = unittest.TestSuite()
    
    for test_class in [
        TestModuleImports,
        TestCommonImportIssues,
    ]:
        suite.addTests(loader.loadTestsFromTestCase(test_class))
    
    # Run tests
    runner = unittest.TextTestRunner(verbosity=2 if args.verbose else 1)
    result = runner.run(suite)
    
    passed = result.testsRun - len(result.failures) - len(result.errors)
    failed = len(result.failures) + len(result.errors)
    
    print()
    print("=" * 70)
    print(f"Results: {passed} passed, {failed} failed")
    
    if failed > 0:
        print()
        print("❌ CRITICAL: Import/syntax errors found!")
        print("   These bugs would NOT be caught by subprocess tests.")
        print("   Fix before deploying!")
    
    print("=" * 70)
    
    return 0 if failed == 0 else 1


if __name__ == '__main__':
    sys.exit(main())
