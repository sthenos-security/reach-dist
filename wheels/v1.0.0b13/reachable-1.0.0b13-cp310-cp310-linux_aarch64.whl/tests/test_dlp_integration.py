#!/usr/bin/env python3
# REACHABLE DLP Module - Integration Tests
# Copyright (c) 2026 Sthenos Security. All rights reserved.

"""
DLP Integration Tests - Test end-to-end DLP scanning.

Run with:
    pytest tests/test_dlp_integration.py -v
    reachctl selftest --integration
"""

import pytest
import sys
import tempfile
import shutil
from pathlib import Path

# Add parent to path for imports
sys.path.insert(0, str(Path(__file__).parent.parent))


@pytest.fixture
def test_repo():
    """Create a temporary test repository with sample PII."""
    temp_dir = tempfile.mkdtemp(prefix="dlp_test_")
    repo_path = Path(temp_dir)
    
    # Create source directory
    src_dir = repo_path / "src"
    src_dir.mkdir()
    
    # Create fixture directory
    fixtures_dir = repo_path / "fixtures"
    fixtures_dir.mkdir()
    
    # Create a Python file with hardcoded PII (discovery)
    (src_dir / "config.py").write_text("""
# Bad practice: hardcoded secrets
DEFAULT_SSN = "489-36-8350"
TEST_EMAIL = "admin@example.com"
TEST_CARD = "4929-3813-3266-4295"
""")
    
    # Create a Python file with PII flowing to sinks (taint)
    (src_dir / "api.py").write_text("""
import logging
import openai

logger = logging.getLogger(__name__)

def process_user(request):
    # PII source
    user_ssn = request.json.get('ssn')
    user_email = request.json.get('email')
    
    # BAD: PII to log (taint sink)
    logger.info(f"Processing user with SSN: {user_ssn}")
    
    # BAD: PII to external API (taint sink)
    openai.chat.completions.create(
        model="gpt-4",
        messages=[{"role": "user", "content": f"User SSN is {user_ssn}"}]
    )
    
    return {"status": "ok"}
""")
    
    # Create a Python file with sanitizers
    (src_dir / "safe_api.py").write_text("""
import logging
from presidio_anonymizer import AnonymizerEngine

logger = logging.getLogger(__name__)
anonymizer = AnonymizerEngine()

def process_user_safe(request):
    user_ssn = request.json.get('ssn')
    
    # GOOD: Sanitize before logging
    sanitized = anonymizer.anonymize(user_ssn)
    logger.info(f"Processing user: {sanitized}")
    
    return {"status": "ok"}
""")
    
    # Create fixture file (should have reduced severity)
    (fixtures_dir / "test_users.json").write_text("""
{
    "users": [
        {"ssn": "078-05-1120", "email": "test@example.com"},
        {"ssn": "219-09-9999", "email": "user@test.com"}
    ]
}
""")
    
    # Create JavaScript file for cross-language testing
    (src_dir / "handler.js").write_text("""
const fetch = require('node-fetch');

async function handleUser(req) {
    const ssn = req.body.ssn;
    const email = req.body.email;
    
    // BAD: PII to console
    console.log(`User SSN: ${ssn}`);
    
    // BAD: PII to external API
    await fetch('https://api.example.com/track', {
        method: 'POST',
        body: JSON.stringify({ ssn, email })
    });
}
""")
    
    yield repo_path
    
    # Cleanup
    shutil.rmtree(temp_dir)


class TestDLPScannerIntegration:
    """Integration tests for DLP scanner."""
    
    @pytest.mark.skip(reason="Regex-based PII discovery removed in P2.45 - now using Semgrep taint analysis only")
    def test_scan_discovers_hardcoded_pii(self, test_repo):
        """Test scanner discovers hardcoded PII in source files."""
        from reachable.dlp import DLPScanner, DLPScanConfig
        from reachable.dlp.schema import PIIEntityType, DLPFindingType
        
        scanner = DLPScanner(config=DLPScanConfig.full())
        findings = scanner.scan(test_repo)
        
        # Should find SSN, email, credit card
        pii_types_found = {f.pii_type for f in findings if f.pii_type}
        
        assert PIIEntityType.SSN in pii_types_found, "Should find SSN"
        assert PIIEntityType.EMAIL in pii_types_found, "Should find email"
        
        # Should have discovery findings
        discovery_findings = [f for f in findings if f.finding_type == DLPFindingType.PII_DISCOVERY]
        assert len(discovery_findings) > 0, "Should have discovery findings"
    
    def test_scan_detects_taint_flows(self, test_repo):
        """Test scanner detects PII flowing to sinks."""
        from reachable.dlp import DLPScanner, DLPScanConfig
        from reachable.dlp.schema import DLPFindingType, SinkType
        
        config = DLPScanConfig.full()
        scanner = DLPScanner(config=config)
        findings = scanner.scan(test_repo)
        
        # Should have taint findings
        taint_findings = [f for f in findings 
                         if f.finding_type in (DLPFindingType.PII_TAINT, DLPFindingType.PII_AI)]
        
        # Check for expected sinks
        sink_types = {f.sink_type for f in taint_findings if f.sink_type}
        
        # Note: Taint analysis may or may not find all flows depending on heuristics
    
    def test_fixture_files_have_lower_severity(self, test_repo):
        """Test that PII in fixture files has lower severity."""
        from reachable.dlp import DLPScanner, DLPScanConfig
        from reachable.dlp.schema import FileClass
        
        scanner = DLPScanner(config=DLPScanConfig.full())
        findings = scanner.scan(test_repo)
        
        # Get fixture vs source findings
        fixture_findings = [f for f in findings if f.file_class == FileClass.FIXTURE]
        source_findings = [f for f in findings if f.file_class == FileClass.SOURCE]
        
        if fixture_findings and source_findings:
            # Average risk should be lower for fixtures
            avg_fixture_risk = sum(f.risk_score for f in fixture_findings) / len(fixture_findings)
            avg_source_risk = sum(f.risk_score for f in source_findings) / len(source_findings)
            
            assert avg_fixture_risk < avg_source_risk, \
                f"Fixture risk ({avg_fixture_risk:.1f}) should be less than source ({avg_source_risk:.1f})"
    
    def test_quick_scan_finds_critical_only(self, test_repo):
        """Test quick scan only finds critical PII types."""
        from reachable.dlp import DLPScanner, DLPScanConfig
        from reachable.dlp.schema import PIIEntityType
        
        scanner = DLPScanner(config=DLPScanConfig.quick())
        findings = scanner.scan(test_repo)
        
        # Quick scan should focus on critical PII
        pii_types = {f.pii_type for f in findings if f.pii_type}
        
        # Should include SSN, credit card
        critical_types = {PIIEntityType.SSN, PIIEntityType.CREDIT_CARD}
        # At least some critical types should be found if present
    
    def test_statistics_tracking(self, test_repo):
        """Test scan statistics are tracked correctly."""
        from reachable.dlp import DLPScanner, DLPScanConfig
        
        scanner = DLPScanner(config=DLPScanConfig.full())
        findings = scanner.scan(test_repo)
        
        stats = scanner.statistics
        
        assert stats['files_scanned'] > 0, "Should scan files"
        assert stats['total_findings'] == len(findings), "Stats should match findings"
        assert 'by_pii_type' in stats
        assert 'by_severity' in stats
        assert 'scan_start' is not None
        assert 'scan_end' is not None
    
    def test_json_export(self, test_repo):
        """Test JSON export of findings."""
        import json
        from reachable.dlp import DLPScanner, DLPScanConfig
        
        scanner = DLPScanner(config=DLPScanConfig.full())
        findings = scanner.scan(test_repo)
        
        json_output = scanner.to_json()
        
        # Should be valid JSON
        data = json.loads(json_output)
        
        assert 'summary' in data
        assert 'findings' in data
        assert len(data['findings']) == len(findings)
    
    def test_correlation_format(self, test_repo):
        """Test findings convert to correlation engine format."""
        from reachable.dlp import DLPScanner, DLPScanConfig
        
        scanner = DLPScanner(config=DLPScanConfig.full())
        findings = scanner.scan(test_repo)
        
        corr_format = scanner.to_correlation_format()
        
        assert len(corr_format) == len(findings)
        
        for item in corr_format:
            assert 'rule_id' in item
            assert 'file_path' in item
            assert 'severity' in item
            assert 'dlp_type' in item


class TestTaintFlowAnalyzer:
    """Integration tests for taint flow analyzer."""
    
    def test_analyze_directory(self, test_repo):
        """Test analyzing a directory for taint flows."""
        from reachable.dlp.taint import analyze_dlp_flows
        
        results = analyze_dlp_flows(test_repo)
        
        assert results['files_analyzed'] > 0
        assert 'summary' in results
        assert 'flows' in results
    
    def test_flow_summary_statistics(self, test_repo):
        """Test flow analysis provides correct statistics."""
        from reachable.dlp.taint import analyze_dlp_flows
        
        results = analyze_dlp_flows(test_repo)
        summary = results['summary']
        
        assert 'total_flows' in summary
        assert 'sanitized_flows' in summary
        assert 'unsanitized_flows' in summary
        assert summary['sanitized_flows'] + summary['unsanitized_flows'] == summary['total_flows']


class TestDLPCLI:
    """Integration tests for DLP CLI."""
    
    def test_cli_scan_command(self, test_repo):
        """Test CLI scan command."""
        import subprocess
        
        result = subprocess.run(
            ['python', '-m', 'reachable.dlp.cli', 'scan', str(test_repo), '--quiet'],
            capture_output=True,
            text=True,
            cwd=str(Path(__file__).parent.parent),
        )
        
        # Should complete successfully
        assert result.returncode == 0, f"CLI failed: {result.stderr}"
    
    def test_cli_json_output(self, test_repo):
        """Test CLI JSON output."""
        import subprocess
        import json
        
        result = subprocess.run(
            ['python', '-m', 'reachable.dlp.cli', 'scan', str(test_repo), '--json', '--quiet'],
            capture_output=True,
            text=True,
            cwd=str(Path(__file__).parent.parent),
        )
        
        if result.returncode == 0:
            # Should be valid JSON somewhere in output
            try:
                # Find JSON in output (may be mixed with other output)
                for line in result.stdout.split('\n'):
                    if line.strip().startswith('{'):
                        data = json.loads(line)
                        assert 'summary' in data or 'findings' in data
                        break
            except json.JSONDecodeError:
                pass  # JSON might not be on its own line
    
    def test_cli_test_command(self):
        """Test CLI test command (P2.45: now shows taint guidance, no regex tests)."""
        import subprocess
        
        result = subprocess.run(
            ['python', '-m', 'reachable.dlp.cli', 'test'],
            capture_output=True,
            text=True,
            cwd=str(Path(__file__).parent.parent),
        )
        
        assert result.returncode == 0, f"Test command failed: {result.stderr}"
        # P2.45: regex tests removed, now outputs taint analysis guidance
        assert "Semgrep taint" in result.stderr or "Semgrep taint" in result.stdout


class TestDLPWithCallGraph:
    """Integration tests with call graph integration."""
    
    def test_scanner_with_call_graph(self, test_repo):
        """Test scanner with call graph for reachability."""
        from reachable.dlp import DLPScanner, DLPScanConfig
        
        # Simulate a call graph
        call_graph = {
            'src.api.process_user': {'src.api.helper', 'logging.info'},
            'src.safe_api.process_user_safe': {'logging.info'},
        }
        
        reachable_functions = {
            'src.api.process_user',
            'src.safe_api.process_user_safe',
        }
        
        scanner = DLPScanner(
            config=DLPScanConfig.full(),
            call_graph=call_graph,
            reachable_functions=reachable_functions,
        )
        
        findings = scanner.scan(test_repo)
        
        # Scanner should still work with call graph
        assert len(findings) >= 0


# Run tests if executed directly
if __name__ == '__main__':
    pytest.main([__file__, '-v'])
