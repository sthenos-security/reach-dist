#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.
"""
Pytest Configuration for REACHABLE Tests
=========================================

Defines markers, fixtures, and configuration for the test suite.
"""

import pytest
import sys
from pathlib import Path

# Add project root to path for imports
project_root = Path(__file__).parent.parent
sys.path.insert(0, str(project_root))


def pytest_configure(config):
    """Configure custom pytest markers."""
    config.addinivalue_line(
        "markers", "unit: Unit tests (fast, mocked dependencies)"
    )
    config.addinivalue_line(
        "markers", "integration: Integration tests (require reach-testbed, slower)"
    )
    config.addinivalue_line(
        "markers", "slow: Slow tests (>10 seconds)"
    )


def pytest_collection_modifyitems(config, items):
    """
    Auto-mark tests based on location and content.
    
    - Tests in test_integration.py get @integration marker
    - Tests in test_unit.py or without marker get @unit marker
    """
    for item in items:
        # Skip if already has markers
        if 'integration' in [m.name for m in item.iter_markers()]:
            continue
        if 'unit' in [m.name for m in item.iter_markers()]:
            continue
        
        # Auto-mark based on file
        if 'integration' in str(item.fspath):
            item.add_marker(pytest.mark.integration)
        else:
            item.add_marker(pytest.mark.unit)


@pytest.fixture(scope="session")
def project_root():
    """Return the project root directory."""
    return Path(__file__).parent.parent


@pytest.fixture(scope="session")
def reachable_version():
    """Return the current REACHABLE version."""
    try:
        from reachable import __version__
        return __version__
    except ImportError:
        return "unknown"
