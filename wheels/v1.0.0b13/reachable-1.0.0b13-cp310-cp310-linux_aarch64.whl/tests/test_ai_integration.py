#!/usr/bin/env python3
"""
Test AI Security Integration with Correlation Engine
=====================================================

Tests internal AI security modules without external dependencies.
"""

import sys
import json
import pytest
from pathlib import Path

# Add the reach-core directory to path
REACH_CORE = Path(__file__).parent.parent
sys.path.insert(0, str(REACH_CORE))


@pytest.mark.integration
def test_ai_reachability():
    """Test the AI reachability analyzer imports and basic functionality."""
    from reachable.ai.ai_reachability import (
        AIReachabilityAnalyzer,
        analyze_ai_reachability,
    )
    
    # Just verify imports work
    analyzer = AIReachabilityAnalyzer()
    assert analyzer is not None


@pytest.mark.integration
def test_correlation_engine():
    """Test the correlation engine with AI findings."""
    from reachable.correlation_engine import (
        ComprehensiveCorrelationEngine,
        correlate_all_signals,
    )
    
    # Create sample AI findings
    ai_findings = [
        {
            'rule_id': 'owasp-llm01-prompt-injection',
            'file_path': 'test.py',
            'line_start': 25,
            'message': 'Test finding',
            'severity': 'ERROR',
            'owasp_llm': 'LLM01',
            'policy_id': 'AI-001',
            'is_reachable': True,
            'guards': [],
            'risk_weight': 150,
        },
    ]
    
    # Run correlation
    result = correlate_all_signals(ai_findings=ai_findings, verbose=False)
    
    assert 'summary' in result
    assert 'total_entities' in result['summary']


@pytest.mark.integration
def test_signal_type():
    """Verify SignalType.AI_SECURITY exists."""
    from reachable.correlation_engine import SignalType, ComprehensiveCorrelationEngine
    
    assert SignalType.AI_SECURITY.value == 'ai_security'
    
    weight = ComprehensiveCorrelationEngine.SIGNAL_WEIGHTS.get(SignalType.AI_SECURITY)
    assert weight is not None
    
    ai_weights = ComprehensiveCorrelationEngine.AI_RISK_WEIGHTS
    assert 'LLM01' in ai_weights


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
