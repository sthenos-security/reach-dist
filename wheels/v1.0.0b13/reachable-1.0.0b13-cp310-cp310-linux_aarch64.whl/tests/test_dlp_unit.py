#!/usr/bin/env python3
# REACHABLE DLP Module - Unit Tests
# Copyright (c) 2026 Sthenos Security. All rights reserved.

"""
DLP Unit Tests - Test core DLP functionality.

Run with:
    pytest tests/test_dlp_unit.py -v
    reachctl selftest --unit
"""

import pytest
import sys
from pathlib import Path

# Add parent to path for imports
sys.path.insert(0, str(Path(__file__).parent.parent))


@pytest.mark.skip(reason="P2.45: Regex-based PII patterns removed - PII detection via Semgrep taint only")
class TestPIIPatterns:
    """Test PII pattern detection. DEPRECATED: P2.45 removed regex discovery."""
    
    def test_ssn_valid_format(self):
        """Test SSN pattern matches valid formats."""
        from reachable.dlp.discovery.entity_patterns import PIIPatternMatcher, PIIEntityType
        
        matcher = PIIPatternMatcher()
        
        valid_ssns = [
            "489-36-8350",
            "078-05-1120",
            "219-09-9999",
            "ssn: 489-36-8350",
            "Social Security: 078 05 1120",
        ]
        
        for text in valid_ssns:
            matches = matcher.match_all(text)
            ssn_matches = [m for m in matches if m.pii_type == PIIEntityType.SSN]
            assert len(ssn_matches) >= 1, f"Should match SSN in: {text}"
    
    def test_ssn_invalid_area(self):
        """Test SSN pattern rejects invalid area codes."""
        from reachable.dlp.discovery.entity_patterns import PIIPatternMatcher, PIIEntityType, validate_ssn
        
        invalid_ssns = [
            "000-12-3456",  # Area 000 invalid
            "666-12-3456",  # Area 666 invalid
            "900-12-3456",  # Area 9xx invalid
        ]
        
        for ssn in invalid_ssns:
            assert not validate_ssn(ssn), f"Should reject invalid SSN: {ssn}"
    
    def test_credit_card_valid_luhn(self):
        """Test credit card Luhn validation."""
        from reachable.dlp.discovery.entity_patterns import validate_credit_card
        
        valid_cards = [
            "4929381332664295",    # Visa
            "5425233430109903",    # Mastercard
            "374245455400126",     # AMEX
            "6011000990139424",    # Discover
        ]
        
        for card in valid_cards:
            clean = ''.join(c for c in card if c.isdigit())
            assert validate_credit_card(clean), f"Should validate card: {card}"
    
    def test_credit_card_invalid_luhn(self):
        """Test credit card rejects invalid Luhn."""
        from reachable.dlp.discovery.entity_patterns import validate_credit_card
        
        invalid_cards = [
            "4111111111111112",    # Invalid Luhn
            "1234567890123456",    # Invalid
        ]
        
        for card in invalid_cards:
            clean = ''.join(c for c in card if c.isdigit())
            assert not validate_credit_card(clean), f"Should reject invalid card: {card}"
    
    def test_email_detection(self):
        """Test email pattern detection."""
        from reachable.dlp.discovery.entity_patterns import PIIPatternMatcher, PIIEntityType
        
        matcher = PIIPatternMatcher()
        
        emails = [
            "test@dlptest.com",
            "john.doe@example.com",
            "user+tag@domain.co.uk",
        ]
        
        for email in emails:
            matches = matcher.match_all(f"Contact: {email}")
            email_matches = [m for m in matches if m.pii_type == PIIEntityType.EMAIL]
            assert len(email_matches) >= 1, f"Should match email: {email}"
    
    def test_phone_detection(self):
        """Test phone number pattern detection."""
        from reachable.dlp.discovery.entity_patterns import PIIPatternMatcher, PIIEntityType
        
        matcher = PIIPatternMatcher()
        
        phones = [
            "(555) 123-4567",
            "555-867-5309",
            "1-800-555-1234",
        ]
        
        for phone in phones:
            matches = matcher.match_all(f"Call: {phone}")
            phone_matches = [m for m in matches if m.pii_type == PIIEntityType.PHONE]
            assert len(phone_matches) >= 1, f"Should match phone: {phone}"


class TestFileClassifier:
    """Test file classification."""
    
    def test_fixture_detection(self):
        """Test fixture files are classified correctly."""
        from reachable.dlp.discovery.file_classifier import FileClassifier, FileClass
        
        classifier = FileClassifier()
        
        fixture_paths = [
            Path("/app/fixtures/users.json"),
            Path("/app/testdata/sample.csv"),
            Path("/app/__mocks__/api.js"),
            Path("/app/seed/data.sql"),
        ]
        
        for path in fixture_paths:
            result = classifier.classify(path)
            assert result.file_class == FileClass.FIXTURE, f"Should be FIXTURE: {path}"
            assert result.risk_modifier < 1.0, f"Fixture should have reduced risk: {path}"
    
    def test_source_detection(self):
        """Test source files are classified correctly."""
        from reachable.dlp.discovery.file_classifier import FileClassifier, FileClass
        
        classifier = FileClassifier()
        
        source_paths = [
            Path("/app/src/main.py"),
            Path("/app/api/handler.js"),
            Path("/app/service.go"),
        ]
        
        for path in source_paths:
            result = classifier.classify(path)
            assert result.file_class == FileClass.SOURCE, f"Should be SOURCE: {path}"
    
    def test_generated_detection(self):
        """Test generated directories are classified correctly."""
        from reachable.dlp.discovery.file_classifier import FileClassifier, FileClass
        
        classifier = FileClassifier()
        
        generated_paths = [
            Path("/app/node_modules/lodash/index.js"),
            Path("/app/.venv/lib/python3.9/site.py"),
            Path("/app/vendor/github.com/pkg/file.go"),
            Path("/app/__pycache__/module.pyc"),
        ]
        
        for path in generated_paths:
            result = classifier.classify(path)
            assert result.file_class == FileClass.GENERATED, f"Should be GENERATED: {path}"
            assert result.risk_modifier < 0.5, f"Generated should have very low risk: {path}"


class TestDLPFinding:
    """Test DLPFinding dataclass."""
    
    def test_discovery_finding_creation(self):
        """Test creating a discovery finding."""
        from reachable.dlp.schema import DLPFinding, PIIEntityType, DLPFindingType, FileClass
        
        finding = DLPFinding.create_discovery(
            file_path="/app/config.py",
            line_start=42,
            pii_type=PIIEntityType.SSN,
            pii_sample="***-**-8350",
            file_class=FileClass.SOURCE,
        )
        
        assert finding.finding_type == DLPFindingType.PII_DISCOVERY
        assert finding.pii_type == PIIEntityType.SSN
        assert finding.file_path == "/app/config.py"
        assert finding.line_start == 42
        assert len(finding.finding_id) > 0
        assert "GDPR" in finding.regulations or "CCPA" in finding.regulations
    
    def test_taint_finding_creation(self):
        """Test creating a taint finding."""
        from reachable.dlp.schema import DLPFinding, PIIEntityType, DLPFindingType, SinkType
        
        finding = DLPFinding.create_taint(
            file_path="/app/api.py",
            line_start=100,
            pii_type=PIIEntityType.EMAIL,
            source="user_email",
            sink="openai.chat.completions.create",
            sink_type=SinkType.LLM_API,
        )
        
        assert finding.finding_type == DLPFindingType.PII_AI  # LLM sink → PII_AI
        assert finding.pii_type == PIIEntityType.EMAIL
        assert finding.sink_type == SinkType.LLM_API
        assert finding.risk_score > 50  # LLM sink is high risk
    
    def test_risk_score_calculation(self):
        """Test risk score calculation with modifiers."""
        from reachable.dlp.schema import DLPFinding, PIIEntityType, FileClass
        
        # High risk: SSN in source code (RESTRICTED tier + REACHABLE)
        # Expected: base=90, no modifiers → risk_score=90
        high_risk = DLPFinding.create_discovery(
            file_path="/app/handler.py",
            line_start=10,
            pii_type=PIIEntityType.SSN,
            file_class=FileClass.SOURCE,
            reachability_state="REACHABLE",
        )
        
        # Low risk: Same SSN in fixture (RESTRICTED tier + NOT_REACHABLE)
        # Expected: base=90, NOT_REACHABLE=-20 → risk_score=70
        low_risk = DLPFinding.create_discovery(
            file_path="/app/fixtures/test.json",
            line_start=10,
            pii_type=PIIEntityType.SSN,
            file_class=FileClass.FIXTURE,
            reachability_state="NOT_REACHABLE",
        )
        
        assert high_risk.risk_score > low_risk.risk_score
        assert high_risk.risk_score == 90  # RESTRICTED tier base
        assert low_risk.risk_score == 70   # Base 90 - 20 for NOT_REACHABLE
        
        # Verify severity changed even though risk_score is similar
        assert high_risk.adjusted_severity == "CRITICAL"  # REACHABLE
        assert low_risk.adjusted_severity == "MEDIUM"     # NOT_REACHABLE
    
    def test_sanitizer_reduces_risk(self):
        """Test that sanitizer presence reduces risk score (v2.0.0: metadata only, -5 points)."""
        from reachable.dlp.schema import DLPFinding, PIIEntityType, SinkType
        
        unsanitized = DLPFinding.create_taint(
            file_path="/app/api.py",
            line_start=100,
            pii_type=PIIEntityType.SSN,
            source="user_ssn",
            sink="logger.info",
            sink_type=SinkType.LOG,
            sanitizer_present=False,
        )
        
        sanitized = DLPFinding.create_taint(
            file_path="/app/api.py",
            line_start=100,
            pii_type=PIIEntityType.SSN,
            source="user_ssn",
            sink="logger.info",
            sink_type=SinkType.LOG,
            sanitizer_present=True,
        )
        
        # v2.0.0: Sanitizers reduce risk_score by 5 points (for sorting priority)
        # They do NOT change severity (both remain CRITICAL)
        assert sanitized.risk_score < unsanitized.risk_score
        assert unsanitized.risk_score - sanitized.risk_score == 5  # Exactly 5 points
        assert sanitized.adjusted_severity == unsanitized.adjusted_severity  # Same severity


class TestDLPScanConfig:
    """Test DLP scan configuration."""
    
    def test_full_config(self):
        """Test full configuration enables all features."""
        from reachable.dlp.config import DLPScanConfig
        
        config = DLPScanConfig.full()
        
        # P2.45: enable_discovery removed - Semgrep taint only
        assert not hasattr(config, 'enable_discovery')
        assert config.enable_taint == True
        assert config.enable_ai_sinks == True
        # preset_name should be "full" if attribute exists
        if hasattr(config, 'preset_name'):
            assert config.preset_name == "full"
    
    def test_quick_config(self):
        """Test quick configuration for fast scans."""
        from reachable.dlp.config import DLPScanConfig
        
        config = DLPScanConfig.quick()
        
        # Should only scan critical PII
        pii_types = config.get_pii_types()
        assert len(pii_types) < 10  # Limited PII types
    
    def test_pci_config(self):
        """Test PCI-DSS focused configuration."""
        from reachable.dlp.config import DLPScanConfig
        from reachable.dlp.schema import PIIEntityType
        
        config = DLPScanConfig.pci()
        
        pii_types = config.get_pii_types()
        assert PIIEntityType.CREDIT_CARD in pii_types
        assert PIIEntityType.CVV in pii_types


class TestTaintSources:
    """Test taint source detection."""
    
    def test_http_sources(self):
        """Test HTTP input sources are detected."""
        from reachable.dlp.taint.sources import PYTHON_PII_SOURCES, PIISourceType
        import re
        
        http_code = [
            "data = request.json",
            "email = request.form['email']",
            "user_id = request.args.get('id')",
        ]
        
        for line in http_code:
            found = False
            for source_type, patterns in PYTHON_PII_SOURCES.items():
                for pattern in patterns:
                    if re.search(pattern, line, re.IGNORECASE):
                        found = True
                        break
            assert found, f"Should detect source in: {line}"
    
    def test_pii_attribute_sources(self):
        """Test PII attribute access is detected."""
        from reachable.dlp.taint.sources import PYTHON_PII_SOURCES, PIISourceType
        import re
        
        pii_code = [
            "ssn = user.ssn",
            "card = data['credit_card']",
            "email = customer.email_address",
        ]
        
        for line in pii_code:
            found = False
            for source_type, patterns in PYTHON_PII_SOURCES.items():
                for pattern in patterns:
                    if re.search(pattern, line, re.IGNORECASE):
                        found = True
                        break
            assert found, f"Should detect PII attribute in: {line}"


class TestTaintSinks:
    """Test taint sink detection."""
    
    def test_llm_sinks(self):
        """Test LLM API sinks are detected."""
        from reachable.dlp.taint.sinks import PYTHON_DLP_SINKS, DLPSinkType, is_llm_sink
        import re
        
        llm_code = [
            "openai.chat.completions.create(messages=data)",
            "client.messages.create(messages=[msg])",
            "chain.invoke(user_input)",
        ]
        
        for line in llm_code:
            found = False
            for sink_type, patterns in PYTHON_DLP_SINKS.items():
                for pattern in patterns:
                    if re.search(pattern, line, re.IGNORECASE):
                        found = True
                        assert is_llm_sink(sink_type) or sink_type == DLPSinkType.LLM_API
                        break
    
    def test_log_sinks(self):
        """Test logging sinks are detected."""
        from reachable.dlp.taint.sinks import PYTHON_DLP_SINKS, DLPSinkType
        import re
        
        log_code = [
            "logger.info(f'User: {user_email}')",
            "logging.debug(data)",
            "print(user_ssn)",
        ]
        
        for line in log_code:
            found = False
            for sink_type, patterns in PYTHON_DLP_SINKS.items():
                for pattern in patterns:
                    if re.search(pattern, line, re.IGNORECASE):
                        found = True
                        break
            assert found, f"Should detect log sink in: {line}"


class TestTaintSanitizers:
    """Test sanitizer detection."""
    
    def test_presidio_sanitizers(self):
        """Test Presidio sanitizer detection."""
        from reachable.dlp.taint.sanitizers import PYTHON_SANITIZERS, SanitizerType
        import re
        
        presidio_code = [
            "from presidio_anonymizer import AnonymizerEngine",
            "anonymizer = AnonymizerEngine()",
            "result = anonymizer.anonymize(text)",
        ]
        
        for line in presidio_code:
            found = False
            for san_type, patterns in PYTHON_SANITIZERS.items():
                for pattern, effectiveness in patterns:
                    if re.search(pattern, line, re.IGNORECASE):
                        found = True
                        if san_type == SanitizerType.PRESIDIO:
                            assert effectiveness >= 0.9
                        break
            # At least some should match
    
    def test_sanitizer_effectiveness(self):
        """Test sanitizer effectiveness calculation."""
        from reachable.dlp.taint.sanitizers import (
            Sanitizer, SanitizerType, calculate_combined_effectiveness
        )
        
        # Single sanitizer with moderate effectiveness
        sanitizers = [
            Sanitizer(
                sanitizer_type=SanitizerType.MASK,
                location="test.py:10",
                function="mask",
                effectiveness=0.70,
            )
        ]
        
        combined = calculate_combined_effectiveness(sanitizers)
        assert combined == 0.70
        
        # Multiple sanitizers (compounding)
        sanitizers.append(
            Sanitizer(
                sanitizer_type=SanitizerType.HASH,
                location="test.py:15",
                function="sha256",
                effectiveness=0.50,
            )
        )
        
        # Combined: 1 - (0.30 * 0.50) = 1 - 0.15 = 0.85
        combined = calculate_combined_effectiveness(sanitizers)
        assert combined > 0.70  # Should be higher with two sanitizers
        assert combined <= 0.95  # But capped at 0.95


class TestCorrelationIntegration:
    """Test correlation engine integration."""
    
    def test_dlp_to_correlation_dict(self):
        """Test DLPFinding converts to correlation format."""
        from reachable.dlp.schema import DLPFinding, PIIEntityType, SinkType
        
        finding = DLPFinding.create_taint(
            file_path="/app/api.py",
            line_start=100,
            pii_type=PIIEntityType.SSN,
            source="user_ssn",
            sink="openai.create",
            sink_type=SinkType.LLM_API,
        )
        
        corr_dict = finding.to_correlation_dict()
        
        assert 'rule_id' in corr_dict
        assert 'file_path' in corr_dict
        assert 'severity' in corr_dict
        assert 'is_reachable' in corr_dict
        assert 'dlp_type' in corr_dict
        assert 'pii_type' in corr_dict
        assert corr_dict['pii_type'] == 'ssn'


# Run tests if executed directly
if __name__ == '__main__':
    pytest.main([__file__, '-v'])
