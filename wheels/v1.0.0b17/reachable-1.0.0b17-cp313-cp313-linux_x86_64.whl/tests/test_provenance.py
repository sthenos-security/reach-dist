#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.
"""
Tests for RADR build provenance collection (v5.3).

Tests cover:
- Git source provenance (commit, branch, tag, remote, dirty)
- CI/CD environment detection (GitHub Actions, GitLab, Jenkins, etc.)
- Image provenance (refs, digests)
- CLI override merging
- Graceful failures (no git, no CI)
"""

import os
from unittest.mock import MagicMock, patch

import pytest

from reachable.core.provenance import (
    _collect_build_provenance,
    _collect_image_provenance,
    _collect_source_provenance,
    _git,
    _normalize_repo_url,
    collect_provenance,
)

# =============================================================================
# FIXTURES
# =============================================================================


@pytest.fixture
def fake_repo(tmp_path):
    """A temporary directory acting as a git repo."""
    return tmp_path


@pytest.fixture
def clean_env():
    """Remove all CI env vars for isolated tests."""
    ci_vars = [
        "GITHUB_ACTIONS",
        "GITHUB_REF_NAME",
        "GITHUB_RUN_ID",
        "GITHUB_REPOSITORY",
        "GITHUB_SERVER_URL",
        "GITHUB_JOB",
        "GITLAB_CI",
        "CI_PIPELINE_ID",
        "CI_PIPELINE_URL",
        "CI_JOB_NAME",
        "CI_COMMIT_BRANCH",
        "JENKINS_URL",
        "BUILD_NUMBER",
        "BUILD_URL",
        "JOB_NAME",
        "BRANCH_NAME",
        "CIRCLECI",
        "CIRCLE_BUILD_NUM",
        "CIRCLE_BUILD_URL",
        "CIRCLE_JOB",
        "CIRCLE_BRANCH",
        "BUILDKITE",
        "BUILDKITE_BUILD_NUMBER",
        "BUILDKITE_BUILD_URL",
        "BUILDKITE_PIPELINE_SLUG",
        "BUILDKITE_BRANCH",
        "TRAVIS",
        "TRAVIS_BUILD_ID",
        "TRAVIS_BUILD_WEB_URL",
        "TRAVIS_JOB_NAME",
        "TRAVIS_BRANCH",
        "TF_BUILD",
        "SYSTEM_TEAMFOUNDATIONSERVERURI",
        "SYSTEM_TEAMPROJECT",
        "BUILD_BUILDID",
        "AGENT_JOBNAME",
        "CI",
        "REACHABLE_IMAGE",
        "IMAGE_NAME",
    ]
    saved = {}
    for var in ci_vars:
        if var in os.environ:
            saved[var] = os.environ.pop(var)
    yield
    # Restore
    for var, val in saved.items():
        os.environ[var] = val


# =============================================================================
# URL NORMALIZATION
# =============================================================================


class TestNormalizeRepoUrl:
    def test_ssh_url(self):
        assert _normalize_repo_url("git@github.com:acme/backend.git") == "github.com/acme/backend"

    def test_https_url(self):
        assert _normalize_repo_url("https://github.com/acme/backend.git") == "github.com/acme/backend"

    def test_http_url(self):
        assert _normalize_repo_url("http://gitlab.com/team/repo.git") == "gitlab.com/team/repo"

    def test_no_dot_git(self):
        assert _normalize_repo_url("https://github.com/acme/backend") == "github.com/acme/backend"

    def test_trailing_slash(self):
        assert _normalize_repo_url("https://github.com/acme/backend/") == "github.com/acme/backend"


# =============================================================================
# GIT HELPER
# =============================================================================


class TestGitHelper:
    def test_git_success(self, fake_repo):
        with patch("subprocess.run") as mock_run:
            mock_run.return_value = MagicMock(returncode=0, stdout="abc123\n")
            result = _git(fake_repo, "rev-parse", "HEAD")
            assert result == "abc123"

    def test_git_failure(self, fake_repo):
        with patch("subprocess.run") as mock_run:
            mock_run.return_value = MagicMock(returncode=128, stdout="")
            result = _git(fake_repo, "rev-parse", "HEAD")
            assert result is None

    def test_git_not_installed(self, fake_repo):
        with patch("subprocess.run", side_effect=FileNotFoundError):
            result = _git(fake_repo, "rev-parse", "HEAD")
            assert result is None


# =============================================================================
# SOURCE PROVENANCE
# =============================================================================


class TestSourceProvenance:
    def test_full_git_info(self, fake_repo, clean_env):
        """Collect all git metadata when git is available."""

        def mock_git(cmd, **kwargs):
            responses = {
                ("git", "rev-parse", "HEAD"): "abc123def456789012345678901234567890abcd",
                ("git", "log", "-1", "--format=%aI"): "2026-02-06T10:30:00-08:00",
                ("git", "rev-parse", "--abbrev-ref", "HEAD"): "main",
                ("git", "describe", "--tags", "--exact-match", "HEAD"): "v1.2.3",
                ("git", "status", "--porcelain"): "",
                ("git", "remote", "get-url", "origin"): "git@github.com:acme/backend.git",
            }
            key = tuple(cmd)
            if key in responses:
                return MagicMock(returncode=0, stdout=responses[key] + "\n")
            return MagicMock(returncode=128, stdout="")

        with patch("subprocess.run", side_effect=mock_git):
            prov = _collect_source_provenance(fake_repo, {})

        assert prov["commit_sha"] == "abc123def456789012345678901234567890abcd"
        assert prov["commit_sha_short"] == "abc123de"
        assert prov["branch"] == "main"
        assert prov["tag"] == "v1.2.3"
        assert prov["dirty"] is False
        assert prov["remote_url"] == "git@github.com:acme/backend.git"
        assert prov["repository"] == "github.com/acme/backend"

    def test_dirty_repo(self, fake_repo, clean_env):
        """Detect dirty working tree."""

        def mock_git(cmd, **kwargs):
            key = tuple(cmd)
            if key == ("git", "status", "--porcelain"):
                return MagicMock(returncode=0, stdout=" M src/main.py\n")
            return MagicMock(returncode=128, stdout="")

        with patch("subprocess.run", side_effect=mock_git):
            prov = _collect_source_provenance(fake_repo, {})

        assert prov["dirty"] is True

    def test_cli_overrides(self, fake_repo, clean_env):
        """CLI overrides take precedence over git."""
        with patch("subprocess.run", return_value=MagicMock(returncode=128, stdout="")):
            prov = _collect_source_provenance(
                fake_repo,
                {
                    "commit": "override123",
                    "branch": "release/v2",
                    "tag": "v2.0.0",
                },
            )

        assert prov["commit_sha"] == "override123"
        assert prov["commit_sha_short"] == "override"  # [:8] of 'override123'
        assert prov["branch"] == "release/v2"
        assert prov["tag"] == "v2.0.0"


# =============================================================================
# CI/CD DETECTION
# =============================================================================


class TestBuildProvenance:
    def test_github_actions(self, clean_env):
        with patch.dict(
            os.environ,
            {
                "GITHUB_ACTIONS": "true",
                "GITHUB_RUN_ID": "12345",
                "GITHUB_REPOSITORY": "acme/backend",
                "GITHUB_SERVER_URL": "https://github.com",
                "GITHUB_JOB": "build",
            },
        ):
            prov = _collect_build_provenance()
        assert prov["ci_provider"] == "github-actions"
        assert prov["ci_run_id"] == "12345"
        assert "actions/runs/12345" in prov["ci_run_url"]
        assert prov["is_ci"] is True

    def test_gitlab_ci(self, clean_env):
        with patch.dict(
            os.environ,
            {
                "GITLAB_CI": "true",
                "CI_PIPELINE_ID": "9876",
                "CI_PIPELINE_URL": "https://gitlab.com/acme/backend/-/pipelines/9876",
                "CI_JOB_NAME": "test",
            },
        ):
            prov = _collect_build_provenance()
        assert prov["ci_provider"] == "gitlab-ci"
        assert prov["ci_run_id"] == "9876"
        assert prov["is_ci"] is True

    def test_jenkins(self, clean_env):
        with patch.dict(
            os.environ,
            {
                "JENKINS_URL": "https://jenkins.internal.com",
                "BUILD_NUMBER": "42",
                "BUILD_URL": "https://jenkins.internal.com/job/backend/42/",
                "JOB_NAME": "backend",
            },
        ):
            prov = _collect_build_provenance()
        assert prov["ci_provider"] == "jenkins"
        assert prov["ci_run_id"] == "42"

    def test_circleci(self, clean_env):
        with patch.dict(
            os.environ,
            {
                "CIRCLECI": "true",
                "CIRCLE_BUILD_NUM": "77",
                "CIRCLE_BUILD_URL": "https://circleci.com/build/77",
            },
        ):
            prov = _collect_build_provenance()
        assert prov["ci_provider"] == "circleci"

    def test_azure_devops(self, clean_env):
        with patch.dict(
            os.environ,
            {
                "TF_BUILD": "True",
                "SYSTEM_TEAMFOUNDATIONSERVERURI": "https://dev.azure.com/acme/",
                "SYSTEM_TEAMPROJECT": "backend",
                "BUILD_BUILDID": "555",
            },
        ):
            prov = _collect_build_provenance()
        assert prov["ci_provider"] == "azure-devops"
        assert prov["ci_run_id"] == "555"

    def test_no_ci(self, clean_env):
        prov = _collect_build_provenance()
        assert prov["ci_provider"] is None
        assert prov["is_ci"] is False

    def test_generic_ci(self, clean_env):
        with patch.dict(os.environ, {"CI": "true"}):
            prov = _collect_build_provenance()
        assert prov["ci_provider"] == "unknown"
        assert prov["is_ci"] is True


# =============================================================================
# IMAGE PROVENANCE
# =============================================================================


class TestImageProvenance:
    def test_from_cli_flag(self, clean_env):
        prov = _collect_image_provenance({"image": "ghcr.io/acme/app:v1.2.3"})
        assert prov["image_tag"] == "ghcr.io/acme/app:v1.2.3"
        assert prov["image_digest"] is None

    def test_with_digest_in_ref(self, clean_env):
        prov = _collect_image_provenance({"image": "ghcr.io/acme/app@sha256:abc123def456"})
        assert prov["image_tag"] == "ghcr.io/acme/app"
        assert prov["image_digest"] == "sha256:abc123def456"

    def test_no_image(self, clean_env):
        prov = _collect_image_provenance({})
        assert prov is None

    def test_from_env_var(self, clean_env):
        with patch.dict(os.environ, {"REACHABLE_IMAGE": "myapp:latest"}):
            prov = _collect_image_provenance({})
        assert prov["image_tag"] == "myapp:latest"


# =============================================================================
# FULL collect_provenance
# =============================================================================


class TestCollectProvenance:
    def test_returns_all_sections(self, fake_repo, clean_env):
        """collect_provenance always returns source + build provenance."""
        with patch("subprocess.run", return_value=MagicMock(returncode=128, stdout="")):
            result = collect_provenance(fake_repo)

        assert "source_provenance" in result
        assert "build_provenance" in result
        # No image section when no image provided
        assert "image_provenance" not in result

    def test_with_image_includes_image_section(self, fake_repo, clean_env):
        with patch("subprocess.run", return_value=MagicMock(returncode=128, stdout="")):
            result = collect_provenance(fake_repo, cli_overrides={"image": "ghcr.io/acme/app:v1"})

        assert "image_provenance" in result
        assert result["image_provenance"]["image_tag"] == "ghcr.io/acme/app:v1"

    def test_no_git_no_crash(self, fake_repo, clean_env):
        """Gracefully handle no git installed."""
        with patch("subprocess.run", side_effect=FileNotFoundError):
            result = collect_provenance(fake_repo)

        assert result["source_provenance"]["commit_sha"] is None
        assert result["source_provenance"]["branch"] is None
