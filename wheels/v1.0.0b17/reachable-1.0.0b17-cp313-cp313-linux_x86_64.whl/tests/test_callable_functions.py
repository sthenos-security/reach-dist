#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.
"""
Tests for RADR callable functions registry (v5.4).

Tests cover:
- App→lib edge extraction
- Package grouping
- Reachability propagation
- CVE association
- Edge cases (no lib calls, large graphs, empty graphs)
"""

from collections import defaultdict

from reachable.core.callable_functions import (
    _get_function_short_name,
    _get_lib_package_name,
    _reconstruct_call_path,
    extract_callable_functions,
)

# =============================================================================
# HELPERS
# =============================================================================


class TestGetLibPackageName:
    def test_standard_lib_func(self):
        assert _get_lib_package_name("lib.requests.api.get") == "requests"

    def test_nested_lib_func(self):
        assert _get_lib_package_name("lib.urllib3.poolmanager.Pool") == "urllib3"

    def test_not_lib(self):
        assert _get_lib_package_name("app.handlers.create_user") is None

    def test_too_short(self):
        assert _get_lib_package_name("lib.x") is None

    def test_plain_function(self):
        assert _get_lib_package_name("main") is None


class TestGetFunctionShortName:
    def test_lib_prefix(self):
        assert _get_function_short_name("lib.requests.api.get") == "requests.api.get"

    def test_app_prefix(self):
        assert _get_function_short_name("app.handlers.create") == "handlers.create"

    def test_no_prefix(self):
        assert _get_function_short_name("main") == "main"


class TestReconstructCallPath:
    def test_simple_path(self):
        parents = {
            "app.handlers.create": "app.main.main",
            "app.main.main": None,
        }
        path = _reconstruct_call_path("app.handlers.create", parents)
        assert path == ["app.main.main", "app.handlers.create"]

    def test_no_parent(self):
        path = _reconstruct_call_path("app.main.main", {"app.main.main": None})
        assert path == ["app.main.main"]

    def test_missing_entry(self):
        path = _reconstruct_call_path("unknown_func", {})
        assert path == ["unknown_func"]


# =============================================================================
# FULL EXTRACTION
# =============================================================================


def _make_graph():
    """Build a realistic call graph for testing."""
    graph = defaultdict(set)
    # App functions
    graph["app.main.main"] = {"app.handlers.create_user", "app.utils.validate"}
    graph["app.handlers.create_user"] = {"lib.requests.api.post", "lib.flask.jsonify", "app.utils.validate"}
    graph["app.utils.validate"] = {"lib.pydantic.validate_model"}
    # Lib-to-lib calls (should be ignored for callable registry)
    graph["lib.requests.api.post"] = {"lib.urllib3.poolmanager.urlopen"}

    all_functions = {
        "app.main.main",
        "app.handlers.create_user",
        "app.utils.validate",
        "lib.requests.api.post",
        "lib.flask.jsonify",
        "lib.pydantic.validate_model",
        "lib.urllib3.poolmanager.urlopen",
    }

    reachable = {
        "app.main.main",
        "app.handlers.create_user",
        "app.utils.validate",
        "lib.requests.api.post",
        "lib.flask.jsonify",
        "lib.pydantic.validate_model",
    }

    entrypoints = {"app.main.main"}

    parents = {
        "app.main.main": None,
        "app.handlers.create_user": "app.main.main",
        "app.utils.validate": "app.main.main",
    }

    metadata = {
        "app.main.main": {"file_path": "main.py", "line_number": 10},
        "app.handlers.create_user": {"file_path": "handlers.py", "line_number": 25},
        "app.utils.validate": {"file_path": "utils.py", "line_number": 5},
    }

    return graph, all_functions, reachable, entrypoints, parents, metadata


class TestExtractCallableFunctions:
    def test_basic_extraction(self):
        graph, all_funcs, reachable, eps, parents, meta = _make_graph()
        result = extract_callable_functions(
            call_graph=graph,
            all_functions=all_funcs,
            reachable_functions=reachable,
            entrypoints=eps,
            function_metadata=meta,
            call_parents=parents,
        )

        assert result["schema_version"] == "1.0"
        assert result["statistics"]["total_packages"] == 3  # requests, flask, pydantic
        assert result["statistics"]["total_lib_functions_called"] == 3
        assert result["statistics"]["reachable_lib_functions"] == 3

    def test_packages_contain_correct_functions(self):
        graph, all_funcs, reachable, eps, parents, meta = _make_graph()
        result = extract_callable_functions(
            call_graph=graph,
            all_functions=all_funcs,
            reachable_functions=reachable,
            entrypoints=eps,
            function_metadata=meta,
            call_parents=parents,
        )

        assert "requests" in result["packages"]
        assert "requests.api.post" in result["packages"]["requests"]["functions"]
        assert "flask" in result["packages"]
        assert "flask.jsonify" in result["packages"]["flask"]["functions"]
        assert "pydantic" in result["packages"]

    def test_callers_tracked(self):
        graph, all_funcs, reachable, eps, parents, meta = _make_graph()
        result = extract_callable_functions(
            call_graph=graph,
            all_functions=all_funcs,
            reachable_functions=reachable,
            entrypoints=eps,
            function_metadata=meta,
            call_parents=parents,
        )

        requests_post = result["packages"]["requests"]["functions"]["requests.api.post"]
        caller_funcs = [c["function"] for c in requests_post["callers"]]
        assert "handlers.create_user" in caller_funcs

    def test_reachability_propagated(self):
        graph, all_funcs, reachable, eps, parents, meta = _make_graph()
        result = extract_callable_functions(
            call_graph=graph,
            all_functions=all_funcs,
            reachable_functions=reachable,
            entrypoints=eps,
            function_metadata=meta,
            call_parents=parents,
        )

        for pkg in result["packages"].values():
            for func in pkg["functions"].values():
                assert func["is_reachable"] is True

    def test_unreachable_caller(self):
        """Lib function called only by unreachable app code."""
        graph = defaultdict(set)
        graph["app.dead_code.foo"] = {"lib.requests.api.get"}

        result = extract_callable_functions(
            call_graph=graph,
            all_functions={"app.dead_code.foo", "lib.requests.api.get"},
            reachable_functions=set(),  # Nothing reachable
            entrypoints=set(),
            function_metadata={},
        )

        assert result["statistics"]["total_lib_functions_called"] == 1
        assert result["statistics"]["reachable_lib_functions"] == 0
        func = result["packages"]["requests"]["functions"]["requests.api.get"]
        assert func["is_reachable"] is False

    def test_empty_graph(self):
        result = extract_callable_functions(
            call_graph={},
            all_functions=set(),
            reachable_functions=set(),
            entrypoints=set(),
            function_metadata={},
        )

        assert result["statistics"]["total_packages"] == 0
        assert result["statistics"]["total_lib_functions_called"] == 0
        assert result["packages"] == {}

    def test_no_lib_calls(self):
        """App code that never calls library functions."""
        graph = defaultdict(set)
        graph["app.main.main"] = {"app.utils.helper"}
        graph["app.utils.helper"] = set()

        result = extract_callable_functions(
            call_graph=graph,
            all_functions={"app.main.main", "app.utils.helper"},
            reachable_functions={"app.main.main", "app.utils.helper"},
            entrypoints={"app.main.main"},
            function_metadata={},
        )

        assert result["statistics"]["total_packages"] == 0
        assert result["packages"] == {}

    def test_cve_association(self):
        graph = defaultdict(set)
        graph["app.main.main"] = {"lib.requests.api.get"}

        result = extract_callable_functions(
            call_graph=graph,
            all_functions={"app.main.main", "lib.requests.api.get"},
            reachable_functions={"app.main.main"},
            entrypoints={"app.main.main"},
            function_metadata={},
            cve_functions={"requests.api.get": ["CVE-2023-32681"]},
        )

        func = result["packages"]["requests"]["functions"]["requests.api.get"]
        assert "CVE-2023-32681" in func["cves"]

    def test_lib_to_lib_edges_ignored(self):
        """Only app→lib edges should appear, not lib→lib."""
        graph = defaultdict(set)
        graph["app.main.main"] = {"lib.requests.api.get"}
        graph["lib.requests.api.get"] = {"lib.urllib3.poolmanager.urlopen"}

        result = extract_callable_functions(
            call_graph=graph,
            all_functions={"app.main.main", "lib.requests.api.get", "lib.urllib3.poolmanager.urlopen"},
            reachable_functions={"app.main.main"},
            entrypoints={"app.main.main"},
            function_metadata={},
        )

        # Only requests should appear (direct app→lib), not urllib3 (lib→lib)
        assert "requests" in result["packages"]
        assert "urllib3" not in result["packages"]
        assert result["statistics"]["total_packages"] == 1
