#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.
"""
REACHABLE Comprehensive Unit Tests
==================================

Unit tests covering ALL core features. These tests:
- Use mocks for external dependencies (no network, no real tools)
- Are fast and deterministic
- Run via: pytest tests/test_unit.py -v

Feature Coverage:
- CVE Analysis (SBOM, Grype, Reachability)
- Secrets Detection (Semgrep, TruffleHog, Loader Detection)
- CWE/SAST (Semgrep rules, reachability)
- Malware Detection (GuardDog, YARA)
- AI Security (OWASP LLM Top 10, Taint Analysis)
- Health Metrics (Package health scoring)
- Correlation Engine (Multi-signal analysis)
- Dashboard Generation
- Database Storage
- CLI Commands
"""

import tempfile
from datetime import datetime
from pathlib import Path

import pytest

# =============================================================================
# FIXTURES
# =============================================================================


@pytest.fixture
def temp_dir():
    """Create a temporary directory for test files."""
    with tempfile.TemporaryDirectory() as tmpdir:
        yield Path(tmpdir)


@pytest.fixture
def mock_sbom():
    """Mock SBOM data (Syft format)."""
    return {
        "artifacts": [
            {"name": "requests", "version": "2.25.0", "type": "python", "purl": "pkg:pypi/requests@2.25.0"},
            {"name": "lodash", "version": "4.17.15", "type": "npm", "purl": "pkg:npm/lodash@4.17.15"},
            {
                "name": "log4j-core",
                "version": "2.14.0",
                "type": "java-archive",
                "purl": "pkg:maven/org.apache.logging.log4j/log4j-core@2.14.0",
            },
        ]
    }


@pytest.fixture
def mock_vulns():
    """Mock vulnerability data (Grype format)."""
    return {
        "matches": [
            {
                "vulnerability": {
                    "id": "CVE-2021-44228",
                    "severity": "Critical",
                    "description": "Log4Shell RCE",
                    "fix": {"versions": ["2.17.0"]},
                },
                "artifact": {"name": "log4j-core", "version": "2.14.0", "type": "java-archive"},
            },
            {
                "vulnerability": {"id": "CVE-2021-33503", "severity": "High", "description": "urllib3 ReDoS"},
                "artifact": {"name": "urllib3", "version": "1.25.0", "type": "python"},
            },
        ]
    }


@pytest.fixture
def sample_python_repo(temp_dir):
    """Create a sample Python repository with various security issues."""
    # Main app file (entry point)
    (temp_dir / "app.py").write_text("""
from flask import Flask, request
from src.handler import process_data
from src.secrets import get_api_key

app = Flask(__name__)

@app.route("/process", methods=["POST"])
def handle():
    data = request.json
    return process_data(data)

if __name__ == "__main__":
    app.run()
""")

    # Source directory
    src = temp_dir / "src"
    src.mkdir()
    (src / "__init__.py").write_text("")

    # Handler with CWE issues
    (src / "handler.py").write_text("""
import subprocess
import pickle

def process_data(data):
    # CWE-78: Command injection (REACHABLE from app.py)
    subprocess.call(f"echo {data['cmd']}", shell=True)

    # CWE-502: Unsafe deserialization
    return pickle.loads(data['payload'])
""")

    # Secrets file
    (src / "secrets.py").write_text("""
# Hardcoded secret (REACHABLE from app.py)
API_KEY = "sk-proj-abc123secret456"

def get_api_key():
    return API_KEY
""")

    # Dead code (not reachable)
    (src / "unused.py").write_text("""
# This file is never imported
DEAD_SECRET = "ghp_deadcode123"

def never_called():
    subprocess.call("rm -rf /", shell=True)
""")

    # Requirements with vulnerable packages
    (temp_dir / "requirements.txt").write_text("""
flask==2.0.0
requests==2.25.0
pyyaml==5.3.1
""")

    return temp_dir


# =============================================================================
# TEST: CVE ANALYSIS
# =============================================================================


class TestCVEAnalysis:
    """Tests for CVE detection and reachability analysis."""

    @pytest.mark.unit
    def test_sbom_parsing(self, mock_sbom):
        """Verify SBOM artifact extraction."""
        artifacts = mock_sbom.get("artifacts", [])
        assert len(artifacts) == 3

        # Check package types
        types = {a["type"] for a in artifacts}
        assert "python" in types
        assert "npm" in types
        assert "java-archive" in types

    @pytest.mark.unit
    def test_vulnerability_matching(self, mock_vulns):
        """Verify CVE matching from Grype output."""
        matches = mock_vulns.get("matches", [])
        assert len(matches) == 2

        cve_ids = {m["vulnerability"]["id"] for m in matches}
        assert "CVE-2021-44228" in cve_ids  # Log4Shell

    @pytest.mark.unit
    def test_severity_classification(self, mock_vulns):
        """Verify severity levels are correctly parsed."""
        severities = {m["vulnerability"]["id"]: m["vulnerability"]["severity"] for m in mock_vulns["matches"]}
        assert severities["CVE-2021-44228"] == "Critical"
        assert severities["CVE-2021-33503"] == "High"

    @pytest.mark.unit
    def test_fix_version_extraction(self, mock_vulns):
        """Verify fix versions are extracted when available."""
        log4shell = next(m for m in mock_vulns["matches"] if m["vulnerability"]["id"] == "CVE-2021-44228")
        fix_versions = log4shell["vulnerability"].get("fix", {}).get("versions", [])
        assert "2.17.0" in fix_versions


# =============================================================================
# TEST: SECRETS DETECTION
# =============================================================================


class TestSecretsDetection:
    """Tests for secret detection and loader analysis."""

    @pytest.mark.unit
    def test_hardcoded_secret_pattern(self):
        """Verify hardcoded secret patterns are detected."""
        patterns = [
            ("sk-proj-abc123def456ghi789jkl012mno", True),  # OpenAI key (longer)
            ("ghp_abc123def456xyz789abc123def456xyz789", True),  # GitHub PAT (longer)
            ("AKIAIOSFODNN7EXAMPLE", True),  # AWS key
            ("password123", False),  # Not a secret pattern
            ("hello world", False),
        ]

        # Simple pattern check (real implementation uses semgrep)
        import re

        secret_patterns = [
            r"sk-proj-[a-zA-Z0-9]{20,}",
            r"ghp_[a-zA-Z0-9]{36,}",
            r"AKIA[A-Z0-9]{16}",
        ]

        for value, should_match in patterns:
            matched = any(re.search(p, value) for p in secret_patterns)
            assert matched == should_match, f"Pattern mismatch for: {value}"

    @pytest.mark.unit
    def test_secret_loader_detection(self, sample_python_repo):
        """Verify secret loader detection (reachability)."""
        from reachable.collectors.secrets.loader import SecretLoaderDetector

        detector = SecretLoaderDetector(verbose=False)

        # Scan the entire repo for secret loaders
        result = detector.scan(sample_python_repo)

        # Should find some loader patterns in the repo
        assert result is not None
        # Check that we got a SecretLoaderResult back
        assert hasattr(result, "loaders")

    @pytest.mark.unit
    def test_secret_reachability_states(self):
        """Verify secret reachability state classification."""
        # REACHABLE: Has confirmed loader
        # UNKNOWN: In config file or no loader analysis possible
        # NOT_REACHABLE: Code analysis shows no path to entry point

        states = ["REACHABLE", "UNKNOWN", "NOT_REACHABLE"]
        for state in states:
            assert state in ["REACHABLE", "UNKNOWN", "NOT_REACHABLE"]


# =============================================================================
# TEST: CWE/SAST ANALYSIS
# =============================================================================


class TestCWEAnalysis:
    """Tests for CWE detection and classification."""

    @pytest.mark.unit
    def test_cwe_id_extraction(self):
        """Verify CWE IDs are properly extracted from findings."""
        # Mock semgrep finding
        finding = {
            "check_id": "python.lang.security.audit.subprocess-shell-true",
            "extra": {"metadata": {"cwe": ["CWE-78: OS Command Injection"], "owasp": ["A03:2021 - Injection"]}},
        }

        cwe_raw = finding["extra"]["metadata"].get("cwe", [])
        # Extract numeric CWE ID
        import re

        cwe_ids = []
        for cwe in cwe_raw:
            match = re.search(r"CWE-(\d+)", cwe)
            if match:
                cwe_ids.append(int(match.group(1)))

        assert 78 in cwe_ids

    @pytest.mark.unit
    def test_config_vs_code_classification(self):
        """Verify findings are classified as config vs code correctly."""
        from reachable.correlation.cwe_reachability import FindingCategory, categorize_finding

        def is_config_file(path: str) -> bool:
            """Helper: check if a path is classified as config."""
            finding = {"file": path, "rule_id": "test"}
            return categorize_finding(finding) == FindingCategory.CONFIG_CWE

        # Code files - should NOT be config
        assert not is_config_file("src/handler.py")
        assert not is_config_file("lib/utils.js")
        assert not is_config_file("Main.java")

        # Config files - should BE config
        assert is_config_file("docker-compose.yaml")
        assert is_config_file("k8s/deployment.yml")
        assert is_config_file("terraform/main.tf")
        assert is_config_file(".github/workflows/ci.yaml")


# =============================================================================
# TEST: AI SECURITY
# =============================================================================


class TestAISecurity:
    """Tests for AI/LLM security analysis (OWASP LLM Top 10)."""

    @pytest.mark.unit
    def test_ai_finding_creation(self):
        """Verify AIFinding dataclass creation."""
        try:
            from reachable.ai.schemas.ai_finding import AIFinding

            finding = AIFinding(
                rule_id="llm01-prompt-injection",
                message="User input directly passed to LLM",
                file_path="app.py",  # NOTE: file_path, not file
                line_start=10,
                line_end=15,
                severity="ERROR",
                owasp_category="LLM01",
            )

            assert finding.rule_id == "llm01-prompt-injection"
            assert finding.owasp_category == "LLM01"
            assert finding.severity == "ERROR"
            assert finding.file_path == "app.py"
        except ImportError:
            pytest.skip("AI module not available")

    @pytest.mark.unit
    def test_owasp_category_classification(self):
        """Verify OWASP LLM category classification."""
        try:
            from reachable.standards.owasp_llm import classify_ai_finding

            # Test various rule patterns - these must match RULE_PATTERNS in classifier
            test_cases = [
                ("llm01-prompt-injection", "Prompt Injection"),
                ("llm02-sensitive-disclosure", "Sensitive Information"),
                ("llm05-output-handling", "Output Handling"),
                ("llm06-excessive-agency", "Excessive Agency"),
            ]

            for rule_id, expected_substring in test_cases:
                result = classify_ai_finding(rule_id, "", None)
                # Result is an AISecurityClassification object
                # Check that the owasp_llm_name contains the expected substring
                assert expected_substring in result.owasp_llm_name, (
                    f"Expected '{expected_substring}' in '{result.owasp_llm_name}' for rule '{rule_id}'"
                )
        except ImportError:
            pytest.skip("AI classifier not available")

    @pytest.mark.unit
    def test_taint_deduplication_by_source(self):
        """Verify taint findings are deduplicated by SOURCE line (v4.5.40 fix)."""
        # Same source (line 26) flowing to different sinks should be ONE finding
        flows = [
            {"source_line": 26, "sink_line": 29, "file": "test.py"},
            {"source_line": 26, "sink_line": 45, "file": "test.py"},
            {"source_line": 26, "sink_line": 66, "file": "test.py"},
            {"source_line": 50, "sink_line": 55, "file": "test.py"},  # Different source
        ]

        # Deduplicate by source
        seen_sources = set()
        deduplicated = []
        for flow in flows:
            key = f"{flow['file']}:{flow['source_line']}"
            if key not in seen_sources:
                seen_sources.add(key)
                deduplicated.append(flow)

        # Should have 2 unique sources: line 26 and line 50
        assert len(deduplicated) == 2
        assert deduplicated[0]["source_line"] == 26
        assert deduplicated[1]["source_line"] == 50


# =============================================================================
# TEST: MALWARE DETECTION
# =============================================================================


class TestMalwareDetection:
    """Tests for malware detection (GuardDog, YARA)."""

    @pytest.mark.unit
    def test_yara_rule_loading(self):
        """Verify YARA rules can be loaded."""
        try:
            from reachable.collectors.malware.yara_rules import YaraRulesManager

            manager = YaraRulesManager()
            status = manager.get_cache_status()

            # Should have some rules cached
            assert "total_rules" in status
        except ImportError:
            pytest.skip("YARA module not available")

    @pytest.mark.unit
    def test_malware_severity_mapping(self):
        """Verify malware severity is mapped correctly."""
        # GuardDog severity mapping
        severity_map = {
            "critical": "CRITICAL",
            "high": "HIGH",
            "medium": "MEDIUM",
            "low": "LOW",
        }

        for guarddog_sev, expected in severity_map.items():
            assert severity_map[guarddog_sev] == expected


# =============================================================================
# TEST: HEALTH METRICS
# =============================================================================


class TestHealthMetrics:
    """Tests for package health scoring."""

    @pytest.mark.unit
    def test_health_score_calculation(self):
        """Verify health metrics dataclass creation."""
        try:
            from reachable.metrics.health import HealthMetrics

            # HealthMetrics is a dataclass with required args
            metrics = HealthMetrics(package_name="requests", package_version="2.28.0", ecosystem="pypi")

            # Verify instance created correctly
            assert metrics.package_name == "requests"
            assert metrics.package_version == "2.28.0"
            assert metrics.ecosystem == "pypi"
            # Health penalty should default to 0
            assert metrics.health_penalty == 0.0
        except ImportError:
            pytest.skip("Health metrics module not available")

    @pytest.mark.unit
    def test_unmaintained_package_detection(self):
        """Verify unmaintained packages are flagged."""
        # Package last updated > 2 years ago should be flagged
        from datetime import timedelta

        last_update = datetime.now() - timedelta(days=800)  # ~2.2 years
        threshold_days = 730  # 2 years

        days_since_update = (datetime.now() - last_update).days
        is_unmaintained = days_since_update > threshold_days

        assert is_unmaintained


# =============================================================================
# TEST: CORRELATION ENGINE
# =============================================================================


class TestCorrelationEngine:
    """Tests for multi-signal correlation."""

    @pytest.mark.unit
    def test_correlation_engine_init(self):
        """Verify correlation engine can be initialized."""
        from reachable.correlation.engine import ComprehensiveCorrelationEngine

        engine = ComprehensiveCorrelationEngine()
        assert engine is not None

    @pytest.mark.unit
    def test_risk_score_calculation(self):
        """Verify risk score bounds and calculation."""

        # Risk score should be 0-100
        def calculate_risk(cves_reachable, secrets_reachable, malware):
            base = 0
            base += min(cves_reachable * 10, 40)
            base += min(secrets_reachable * 15, 30)
            base += min(malware * 25, 30)
            return min(base, 100)

        # No findings = 0 risk
        assert calculate_risk(0, 0, 0) == 0

        # Some findings
        assert 0 < calculate_risk(2, 1, 0) < 100

        # Max out
        assert calculate_risk(10, 10, 10) == 100


# =============================================================================
# TEST: DATABASE STORAGE
# =============================================================================


class TestDatabaseStorage:
    """Tests for scan result persistence."""

    @pytest.mark.unit
    def test_database_creation(self, temp_dir):
        """Verify database is created correctly."""
        from reachable.database.storage import RepoDatabase

        db_path = temp_dir / "repo.db"
        db = RepoDatabase(db_path)

        assert db_path.exists()
        db.close()

    @pytest.mark.unit
    def test_scan_storage(self, temp_dir):
        """Verify scan results can be stored and retrieved."""
        from reachable.database.storage import RepoDatabase

        db_path = temp_dir / "repo.db"
        db = RepoDatabase(db_path)

        # Start a scan
        scan_id = db.start_scan(branch="main", commit_hash="abc123", scan_dir="/tmp/test", version="4.5.40")

        assert scan_id > 0

        # Store a finding
        findings = [
            {
                "id": "CVE-2021-44228",
                "severity": "CRITICAL",
                "title": "Log4Shell",
                "description": "RCE via JNDI",
                "package": "log4j-core",
                "version": "2.14.0",
                "app_reachability": "REACHABLE",
                "scanner": "grype",  # REQUIRED: All findings must have scanner field
            }
        ]
        db.store_findings(findings, "cve")

        # Complete scan
        db.complete_scan(duration_seconds=10, risk_score=85, risk_level="CRITICAL")

        db.close()


# =============================================================================
# TEST: CLI
# =============================================================================


class TestCLI:
    """Tests for CLI commands."""

    @pytest.mark.unit
    def test_cli_import(self):
        """Verify CLI module imports correctly."""
        from reachable.cli import main

        assert callable(main)

    @pytest.mark.unit
    def test_version_format(self):
        """Verify version string format."""
        # Version can be:
        # - Simple: 1.0.0
        # - With suffix: 1.0.0b12
        # - Dev version: 1.0.0b12.dev0+dirty.username
        import re

        from reachable import __version__

        # Match X.Y.Z with optional suffixes (beta, dev, etc.)
        pattern = r"^\d+\.\d+\.\d+"
        assert re.match(pattern, __version__), f"Invalid version format: {__version__}"


# =============================================================================
# RUN TESTS
# =============================================================================

if __name__ == "__main__":
    pytest.main([__file__, "-v"])
