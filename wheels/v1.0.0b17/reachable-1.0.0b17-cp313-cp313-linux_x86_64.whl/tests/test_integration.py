#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.
"""
REACHABLE Integration Tests - DEPRECATED

Integration tests should be run directly via:
    reachctl scan /path/to/reach-testbed

This file is kept as a placeholder to avoid pytest collection errors.
"""

import pytest

pytestmark = pytest.mark.skip(reason="Integration tests run via: reachctl scan <testbed-path>")
