#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.
"""
T-GRC02: GRC Page Counter & Rendering Validation
==================================================

Focused unit tests for the GRC dashboard page:
  - Counter math: by_owasp sums, actionable vs total, ASI fan-out
  - JS rendering: fwDefs ↔ fwSizes consistency, ASI_DEFS completeness
  - HTML structure: filter dropdowns, mount points
  - Data flow: data.json → JS rendering pipeline

Complements test_grc_compliance_agentic.py (which covers compliance tags,
STRIDE mappings, and crosswalk structural validation).

Run:
    pytest tests/test_grc_agentic_counters.py -v
"""

import json
import re
from pathlib import Path

import pytest

# ---------------------------------------------------------------------------
# Constants — OWASP ASI v1.1, T1-T17 notation
# ---------------------------------------------------------------------------

VALID_LLM_CODES = {f"LLM{i:02d}" for i in range(1, 11)}
VALID_ASI_CODES = {f"T{i}" for i in range(1, 18)}

# Canonical LLM→ASI crosswalk (must match owasp-cards.js)
LLM_TO_ASI = {
    "LLM01": ["T6", "T1"],  # Prompt Injection → Goal Manipulation, Memory Poisoning
    "LLM02": ["T15", "T8"],  # Sensitive Disclosure → Human Manipulation, Repudiation
    "LLM03": ["T17", "T16"],  # Supply Chain → Supply Chain, Protocol Abuse
    "LLM04": ["T1", "T5"],  # Data Poisoning → Memory Poisoning, Cascading Hallucination
    "LLM05": ["T11", "T2"],  # Insecure Output → RCE, Tool Misuse
    "LLM06": ["T2", "T3"],  # Excessive Agency → Tool Misuse, Privilege Compromise
    "LLM07": ["T2", "T11"],  # Insecure Plugin → Tool Misuse, RCE
    "LLM08": ["T1", "T5"],  # Vector Weakness → Memory Poisoning, Cascading Hallucination
    "LLM09": ["T5", "T15"],  # Misinformation → Cascading Hallucination, Human Manipulation
    "LLM10": ["T4", "T10"],  # Unbounded Consumption → Resource Overload, Overwhelming HITL
}

# 12 of 17 ASI codes reachable from LLM01-LLM10.
# T7 (Misaligned), T9 (Identity Spoofing), T12-T14 (multi-agent) have no LLM parent.
EXPECTED_CROSSWALK_COVERAGE = {
    "T1",
    "T2",
    "T3",
    "T4",
    "T5",
    "T6",
    "T8",
    "T10",
    "T11",
    "T15",
    "T16",
    "T17",
}

# GRC frameworks expected in JS fwDefs (NOT ASI threat categories)
EXPECTED_FWDEFS = {
    "OWASP",
    "CWE",
    "OWASP_LLM",
    "PCI-DSS",
    "HIPAA",
    "SOC2",
    "ISO27001",
    "NIST-800-53",
    "NIST-800-171",
    "FEDRAMP",
    "CMMC",
    "DISA-STIG",
    "FISMA",
    "STRIDE",
}

# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture(scope="session")
def data_json():
    """Load most recent data.json from scan output."""
    base = Path.home() / ".reachable" / "scans"
    if not base.exists():
        pytest.skip("~/.reachable/scans/ does not exist")
    candidates = list(base.rglob("dashboard/data.json"))
    if not candidates:
        pytest.skip("No data.json found")
    path = max(candidates, key=lambda p: p.stat().st_mtime)
    with open(path) as f:
        return json.load(f)


@pytest.fixture(scope="session")
def owasp_js():
    """Load owasp-cards.js source."""
    js_path = (
        Path(__file__).parent.parent
        / "reachable"
        / "dashboard_v2"
        / "split"
        / "components"
        / "scripts"
        / "owasp-cards.js"
    )
    if not js_path.exists():
        pytest.skip("owasp-cards.js not found")
    return js_path.read_text(encoding="utf-8")


@pytest.fixture(scope="session")
def dashboard_body_html():
    """Load dashboard-body.html source."""
    html_path = (
        Path(__file__).parent.parent / "reachable" / "dashboard_v2" / "split" / "components" / "dashboard-body.html"
    )
    if not html_path.exists():
        pytest.skip("dashboard-body.html not found")
    return html_path.read_text(encoding="utf-8")


@pytest.fixture(scope="session")
def ai_security(data_json):
    """Extract ai_security section from data.json."""
    ai_sec = data_json.get("ai_security") or {}
    if not ai_sec.get("total"):
        pytest.skip("No AI findings in data.json")
    return ai_sec


# ---------------------------------------------------------------------------
# GRC Counter Math (data.json validation)
# ---------------------------------------------------------------------------


class TestGRCCounterMath:
    """Validate counter arithmetic in data.json ai_security section."""

    def test_by_owasp_keys_valid(self, ai_security):
        """by_owasp keys must be LLM01-LLM10 or NONE."""
        by_owasp = ai_security.get("by_owasp", {})
        invalid = {k for k in by_owasp if k not in VALID_LLM_CODES and k != "NONE"}
        assert not invalid, f"Invalid by_owasp keys: {invalid}"

    def test_by_owasp_nonnegative(self, ai_security):
        """All by_owasp counts must be >= 0."""
        by_owasp = ai_security.get("by_owasp", {})
        neg = {k: v for k, v in by_owasp.items() if v < 0}
        assert not neg, f"Negative counts: {neg}"

    def test_by_owasp_sum_matches_total(self, ai_security):
        """Sum of by_owasp counts must equal ai_security.total within tolerance.

        Tolerance: max(3, 15% of total) — small scans may have rounding/
        classification edge cases (e.g. findings mapped to NONE that shift
        between scan runs).
        """
        by_owasp = ai_security.get("by_owasp", {})
        total = ai_security.get("total", 0)
        owasp_sum = sum(by_owasp.values())
        tolerance = max(3, int(total * 0.15))
        assert (
            abs(owasp_sum - total) <= tolerance
        ), f"by_owasp sum ({owasp_sum}) vs total ({total}) — >{tolerance} tolerance. Breakdown: {dict(by_owasp)}"

    def test_total_actionable_excludes_none(self, ai_security):
        """total_actionable = total - NONE count."""
        total = ai_security.get("total", 0)
        total_act = ai_security.get("total_actionable")
        if total_act is None:
            pytest.skip("total_actionable not in data.json — re-scan needed")
        none_count = ai_security.get("by_owasp", {}).get("NONE", 0)
        assert (
            total_act == total - none_count
        ), f"total_actionable ({total_act}) != total ({total}) - NONE ({none_count})"

    def test_asi_fanout_per_category_lte_total(self, ai_security):
        """Each ASI category count (via crosswalk fan-out) must be <= total.

        LLM06→[T2,T3] means both T2 and T3 get LLM06's full count.
        This is correct fan-out, but no single T category should exceed total.
        """
        by_owasp = ai_security.get("by_owasp", {})
        total = ai_security.get("total", 0)
        asi_counts = {code: 0 for code in VALID_ASI_CODES}
        for llm, count in by_owasp.items():
            for asi in LLM_TO_ASI.get(llm, []):
                asi_counts[asi] += count
        violations = {c: n for c, n in asi_counts.items() if n > total}
        assert not violations, f"ASI counts exceed total ({total}): {violations}"

    def test_banner_uses_total_not_asi_sum(self, ai_security):
        """Banner must show total finding count, NOT inflated ASI sum."""
        by_owasp = ai_security.get("by_owasp", {})
        total = ai_security.get("total", 0)
        asi_counts = {code: 0 for code in VALID_ASI_CODES}
        for llm, count in by_owasp.items():
            for asi in LLM_TO_ASI.get(llm, []):
                asi_counts[asi] += count
        asi_sum = sum(asi_counts.values())
        assert "total" in ai_security, "ai_security must have 'total' for banner"
        if asi_sum > total:
            ratio = asi_sum / total
            print(
                f"\n  [crosswalk fan-out] total={total}, asi_sum={asi_sum}, "
                f"ratio={ratio:.1f}x — expected for multi-mapped LLM codes"
            )


# ---------------------------------------------------------------------------
# Crosswalk Structural Validation (pure logic, no scan data)
# ---------------------------------------------------------------------------


class TestCrosswalkStructure:
    """Validate LLM→ASI crosswalk constants match JS."""

    def test_every_llm_has_mapping(self):
        """All LLM01-LLM10 must have at least one ASI target."""
        for llm in VALID_LLM_CODES:
            assert llm in LLM_TO_ASI, f"{llm} missing from crosswalk"
            assert len(LLM_TO_ASI[llm]) >= 1, f"{llm} maps to empty list"

    def test_all_targets_are_valid_t_codes(self):
        """Every crosswalk target must be a valid T1-T17 code."""
        for llm, targets in LLM_TO_ASI.items():
            for t in targets:
                assert t in VALID_ASI_CODES, f"{llm}->{t} not in T1-T17"

    def test_expected_coverage(self):
        """Crosswalk must cover 12 expected ASI codes.

        T7, T9, T12-T14 are autonomous/multi-agent threats without LLM parents.
        """
        covered = set()
        for targets in LLM_TO_ASI.values():
            covered.update(targets)
        missing = EXPECTED_CROSSWALK_COVERAGE - covered
        assert not missing, f"Expected codes unreachable: {missing}"
        assert len(covered) >= 12, f"Only {len(covered)} codes covered"

    def test_crosswalk_matches_js(self, owasp_js):
        """Python crosswalk must match JS LLM_TO_ASI exactly."""
        js_crosswalk = {}
        for m in re.finditer(r"(LLM\d{2})\s*:\s*\[([^\]]+)\]", owasp_js):
            llm = m.group(1)
            targets = re.findall(r"'(T\d+)'", m.group(2))
            if llm not in js_crosswalk:
                js_crosswalk[llm] = sorted(targets)
        for llm in VALID_LLM_CODES:
            py = sorted(LLM_TO_ASI.get(llm, []))
            js = sorted(js_crosswalk.get(llm, []))
            assert py == js, f"{llm} mismatch: py={py} js={js}"


# ---------------------------------------------------------------------------
# JS Rendering Validation (owasp-cards.js)
# ---------------------------------------------------------------------------


class TestGRCJSRendering:
    """Validate GRC-related JS rendering logic in owasp-cards.js."""

    def test_all_17_asi_defs_in_js(self, owasp_js):
        """All T1-T17 must be defined as quoted keys in asiDefs/ASI_DEFS."""
        for code in VALID_ASI_CODES:
            assert f"'{code}'" in owasp_js, f"{code} missing from owasp-cards.js"

    def test_fwdefs_have_fwsizes(self, owasp_js):
        """Every GRC framework in fwDefs must have a fwSizes entry.

        The regex also matches ASI_DEFS entries (T1-T17) because they use
        the same '{name:...}' pattern — those are excluded since they are
        threat categories, not compliance frameworks.
        """
        fwdefs_matches = re.findall(r"'([A-Z][A-Z0-9_-]+)'\s*:\s*\{[^}]*name:", owasp_js)
        fwsizes_match = re.search(r"var fwSizes\s*=\s*\{([^}]+)\}", owasp_js)
        if not fwsizes_match:
            pytest.skip("fwSizes not found in owasp-cards.js")
        fwsizes_text = fwsizes_match.group(1)
        unquoted = set(re.findall(r"(?<!['\"])([A-Za-z0-9_]+)\s*:", fwsizes_text))
        quoted = set(re.findall(r"'([A-Za-z0-9_-]+)'\s*:", fwsizes_text))
        fwsizes_keys = unquoted | quoted
        # Exclude: T1-T17 are ASI threat categories, CWE-TOP-25 is an alias
        excluded = VALID_ASI_CODES | {"CWE-TOP-25"}
        missing = [fw for fw in fwdefs_matches if fw not in fwsizes_keys and fw not in excluded]
        assert (
            not missing
        ), f"Frameworks in fwDefs without fwSizes entry: {missing}. fwSizes keys: {sorted(fwsizes_keys)}"

    def test_fwsizes_has_stride_19(self, owasp_js):
        """fwSizes must have STRIDE:19 (matching stride.py 19 controls)."""
        assert "STRIDE:19" in owasp_js, "fwSizes missing STRIDE:19"

    def test_fwdefs_covers_expected_frameworks(self, owasp_js):
        """fwDefs must contain all expected GRC frameworks."""
        for fw in EXPECTED_FWDEFS:
            assert f"'{fw}'" in owasp_js, f"{fw} missing from fwDefs"

    def test_pipeline_count_in_js(self, owasp_js):
        """JS must compute pipelineCount (actionable, excluding NONE)."""
        assert "pipelineCount" in owasp_js, "pipelineCount missing"
        assert "_noneCount" in owasp_js, "_noneCount missing"

    def test_agentic_mount_points(self, owasp_js):
        """JS must reference all 3 agentic mount divs."""
        assert "attackSurfaceBanner" in owasp_js
        assert "agenticSurfaceFlow" in owasp_js
        assert "agenticSurfaceLabel" in owasp_js

    def test_stage_detail_uses_parent_llm(self, owasp_js):
        """showStageDetail must use parentLlm, not a stale local crosswalk."""
        assert "parentLlm" in owasp_js, "Missing parentLlm in stage objects"
        assert "isAgentic" in owasp_js, "Missing isAgentic check"
        # showStageDetail must NOT have its own LLM_TO_ASI declaration
        detail_start = owasp_js.find("window.showStageDetail")
        if detail_start != -1:
            chunk = owasp_js[detail_start : detail_start + 3000]
            stale = re.findall(r"var\s+_?LLM_TO_ASI\s*=", chunk)
            assert len(stale) == 0, f"Found {len(stale)} stale LLM_TO_ASI in showStageDetail"

    def test_none_not_remapped_to_llm06(self, owasp_js):
        """NONE/PRIMITIVE must not be remapped to LLM06 (old inflation bug)."""
        bad_remap = re.findall(r"cat\s*===\s*'NONE'.*cat\s*=\s*'LLM06'", owasp_js)
        assert len(bad_remap) == 0, "NONE still remapped to LLM06"

    def test_agentic_click_uses_llm_code(self, owasp_js):
        """Agentic stage click must filter by parent LLM code."""
        assert "matchLlmCodes[0]" in owasp_js

    def test_blue_count_styles_consistent(self, owasp_js):
        """Both pipeline and agentic panels must use same count styling."""
        styles = re.findall(r"font-size:14px;font-weight:700;color:#42A5F5", owasp_js)
        assert len(styles) >= 2, f"Found {len(styles)} blue count styles, expected >= 2"


# ---------------------------------------------------------------------------
# HTML Structure Validation (dashboard-body.html)
# ---------------------------------------------------------------------------


class TestGRCHTMLStructure:
    """Validate GRC filter dropdowns and mount divs in HTML."""

    def test_agentic_mount_divs(self, dashboard_body_html):
        """HTML must have all 3 agentic mount points."""
        assert 'id="attackSurfaceBanner"' in dashboard_body_html
        assert 'id="agenticSurfaceFlow"' in dashboard_body_html
        assert 'id="agenticSurfaceLabel"' in dashboard_body_html

    def test_stride_filter_option(self, dashboard_body_html):
        """GRC filter dropdown must include STRIDE."""
        assert 'value="STRIDE"' in dashboard_body_html

    def test_llm_filter_options(self, dashboard_body_html):
        """GRC filter must have OWASP-LLM01 through OWASP-LLM10 options."""
        for i in range(1, 11):
            code = f"LLM{i:02d}"
            assert f"OWASP-{code}" in dashboard_body_html, f"{code} missing from filter options"

    def test_no_stale_asi_filter_options(self, dashboard_body_html):
        """Filter dropdown must NOT have old OWASP-ASI01..ASI10 values."""
        for i in range(1, 11):
            old_code = f"OWASP-ASI{i:02d}"
            assert old_code not in dashboard_body_html, f"Stale {old_code} still in filter dropdown"

    def test_owasp_web_filter_options(self, dashboard_body_html):
        """GRC filter must have OWASP-A01 through OWASP-A10."""
        for i in range(1, 11):
            code = f"A{i:02d}"
            assert f"OWASP-{code}" in dashboard_body_html, f"{code} missing from OWASP Top 10 filter"


# ---------------------------------------------------------------------------
# Data Flow Validation (data.json → JS pipeline)
# ---------------------------------------------------------------------------


class TestGRCDataFlow:
    """Validate data.json has fields JS rendering expects."""

    def test_ai_security_has_required_keys(self, ai_security):
        """ai_security must have total, by_owasp, total_actionable."""
        assert "total" in ai_security
        assert "by_owasp" in ai_security
        # total_actionable may be absent in older scans
        if "total_actionable" not in ai_security:
            import warnings

            warnings.warn("total_actionable missing — re-scan recommended")

    def test_issues_have_ai_type(self, data_json):
        """issues[] must contain findings with type=AI matching total."""
        ai_sec = data_json.get("ai_security") or {}
        total = ai_sec.get("total", 0)
        if total == 0:
            pytest.skip("No AI findings")
        issues = data_json.get("issues", [])
        ai_issues = [f for f in issues if (f.get("type") or "").upper() == "AI"]
        tolerance = max(2, int(total * 0.1))
        assert abs(len(ai_issues) - total) <= tolerance, f"issues[] has {len(ai_issues)} AI findings vs total={total}"

    def test_owasp_web_section_present(self, data_json):
        """data.json should have owasp_web section for GRC page."""
        owasp_web = data_json.get("owasp_web")
        if owasp_web is None:
            pytest.skip("owasp_web not in data.json — re-scan needed")
        assert "by_category" in owasp_web
        assert "total" in owasp_web

    def test_compliance_mapping_in_issues(self, data_json):
        """At least some issues should have compliance_mapping for GRC."""
        issues = data_json.get("issues", [])
        if not issues:
            pytest.skip("No issues in data.json")
        with_mapping = sum(1 for f in issues if f.get("compliance_mapping"))
        ratio = with_mapping / len(issues)
        assert (
            ratio >= 0.3
        ), f"Only {with_mapping}/{len(issues)} ({ratio:.0%}) issues have compliance_mapping — GRC page will be sparse"
