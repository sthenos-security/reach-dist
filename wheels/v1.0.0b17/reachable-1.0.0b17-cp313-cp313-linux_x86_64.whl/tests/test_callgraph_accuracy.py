#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.
"""
T-CG19: Callgraph Accuracy Regression Suite
============================================

Tests covering:
  - T-CG7:  HCR registry — typed hop classification
  - T-CG8:  CWE containing function + entrypoint BFS
  - T-CG9:  Secret Level 1 — file-read confirmation
  - T-CG12: Secret Level 2-3 — source→transformer→sink chain
  - T-CG14: JS dev/runtime split from package-lock.json
  - T-CG16: Go boundary nodes (syscall, CGO) in registry
  - T-CG17: DLP path construction input→PII→sink 3-node chain
  - T-CG18: JS HCR rules in registry
"""

import json
import tempfile
from pathlib import Path

# ===========================================================================
# T-CG7: HCR registry
# ===========================================================================


class TestCG7_HCRRegistry:
    """T-CG7: hop_registry.py typed HCR — classify_hop returns correct NodeKind."""

    def test_llm_sink_classified_sink_danger(self):
        from reachable.engine.hop_registry import HopPosition, NodeKind, classify_hop

        decision = classify_hop("openai.chat.completions.create", "AI", HopPosition.LAST)
        assert decision.kind == NodeKind.SINK_DANGER

    def test_anthropic_classified_sink_danger(self):
        from reachable.engine.hop_registry import HopPosition, NodeKind, classify_hop

        decision = classify_hop("anthropic.messages.create", "AI", HopPosition.LAST)
        assert decision.kind == NodeKind.SINK_DANGER

    def test_subprocess_classified_sink_danger(self):
        from reachable.engine.hop_registry import HopPosition, NodeKind, classify_hop

        decision = classify_hop("subprocess.run", "CWE", HopPosition.LAST)
        assert decision.kind == NodeKind.SINK_DANGER

    def test_fmt_classified_stdlib_for_cve(self):
        from reachable.engine.hop_registry import HopPosition, NodeKind, classify_hop

        decision = classify_hop("fmt.Println", "CVE", HopPosition.MIDDLE)
        assert decision.kind == NodeKind.STDLIB
        assert decision.display_action == "strip"

    def test_database_sql_classified_sink_danger(self):
        from reachable.engine.hop_registry import HopPosition, NodeKind, classify_hop

        decision = classify_hop("database/sql.Query", "CWE", HopPosition.LAST)
        assert decision.kind == NodeKind.SINK_DANGER

    def test_pii_source_email_classified(self):
        from reachable.engine.hop_registry import HopPosition, NodeKind, classify_hop

        decision = classify_hop("request.json['email']", "DLP", HopPosition.FIRST)
        assert decision.kind == NodeKind.SOURCE_PII

    def test_registry_is_non_empty(self):
        from reachable.engine.hop_registry import REGISTRY

        assert len(REGISTRY) > 20, "Registry must have enough rules to be useful"


# ===========================================================================
# T-CG8: CWE containing function + entrypoint BFS
# ===========================================================================


class TestCG8_CWEContainingFunction:
    """T-CG8: _find_containing_function + _trace_to_entrypoint."""

    def test_find_containing_function_from_source(self):
        from reachable.database.normalizers.semgrep import _find_containing_function

        with tempfile.TemporaryDirectory() as tmp:
            src = Path(tmp) / "handlers.py"
            src.write_text(
                "def HandleLogin(req):\n"
                "    user = req.body['user']\n"
                '    query = f"SELECT * FROM users WHERE name = {user}"\n'  # line 3
                "    return db.execute(query)\n"
            )
            result = _find_containing_function({}, str(src), 3, tmp)
            assert result == "HandleLogin", f"Expected HandleLogin, got {result}"

    def test_trace_to_entrypoint_finds_handler(self):
        from reachable.database.normalizers.semgrep import _trace_to_entrypoint

        cg = {
            "handlers.HandleLogin": ["db.execute"],
            "db.execute": [],
        }
        path = _trace_to_entrypoint(cg, "db.execute", max_depth=5)
        # The path should include HandleLogin since it matches Handle[A-Z] pattern
        assert "handlers.HandleLogin" in path, f"Entrypoint not in path: {path}"

    def test_trace_returns_just_start_for_no_callers(self):
        from reachable.database.normalizers.semgrep import _trace_to_entrypoint

        path = _trace_to_entrypoint({}, "some.func", max_depth=3)
        assert path == ["some.func"]

    def test_enrich_cwe_attaches_containing_function(self):
        from reachable.database.normalizers.semgrep import enrich_cwe_with_containing_function

        with tempfile.TemporaryDirectory() as tmp:
            src = Path(tmp) / "main.go"
            src.write_text(
                "func HandleCreate(w http.ResponseWriter, r *http.Request) {\n"
                '    id := r.URL.Query().Get("id")\n'
                '    row := db.QueryRow("SELECT * FROM items WHERE id = " + id)\n'
                "    w.Write(row)\n"
                "}\n"
            )
            findings = [
                {
                    "file_path": str(src),
                    "line": 3,
                    "app_reachability": "UNKNOWN",
                    "call_path": [],
                }
            ]
            enriched = enrich_cwe_with_containing_function(findings, {}, tmp)
            assert (
                enriched[0].get("containing_function") == "HandleCreate"
            ), f"Expected HandleCreate, got {enriched[0].get('containing_function')}"


# ===========================================================================
# T-CG9: Secret Level 1 — file-read confirmation
# ===========================================================================


class TestCG9_SecretFileRead:
    """T-CG9: _check_file_is_read demotes NOT_REACHABLE when no ReadFile found."""

    def test_file_read_confirmed(self):
        from reachable.database.normalizers.semgrep import _check_file_is_read

        with tempfile.TemporaryDirectory() as tmp:
            # Create a secret config file
            cfg = Path(tmp) / "config.yaml"
            cfg.write_text("api_key: supersecret\n")

            # Create Go source that reads it
            src = Path(tmp) / "main.go"
            src.write_text(
                "package main\n\n"
                'import "os"\n\n'
                "func loadConfig() {\n"
                '    data, _ := os.ReadFile("config.yaml")\n'
                "    _ = data\n"
                "}\n"
            )
            assert _check_file_is_read(str(cfg), tmp) is True

    def test_file_not_read_returns_false(self):
        from reachable.database.normalizers.semgrep import _check_file_is_read

        with tempfile.TemporaryDirectory() as tmp:
            cfg = Path(tmp) / "forgotten.pem"
            cfg.write_text("-----BEGIN RSA PRIVATE KEY-----\nABC\n-----END RSA PRIVATE KEY-----\n")
            # No source file reads it
            assert _check_file_is_read(str(cfg), tmp) is False

    def test_enrich_secret_reachability_demotes_unread_secrets(self):
        from reachable.database.normalizers.semgrep import enrich_secret_reachability

        with tempfile.TemporaryDirectory() as tmp:
            # A config file that NO source reads
            cfg = Path(tmp) / "dead_secret.yaml"
            cfg.write_text("password: hunter2\n")

            findings = [
                {
                    "file_path": str(cfg),
                    "app_reachability": "UNKNOWN",
                    "finding_type": "secret",
                    "secret_type": "password",
                    "call_path": [],
                }
            ]
            enriched = enrich_secret_reachability(findings, tmp)
            assert enriched[0]["app_reachability"] == "NOT_REACHABLE"
            assert enriched[0]["reachability_reason"] == "file_not_read"

    def test_enrich_secret_promotes_read_secrets(self):
        from reachable.database.normalizers.semgrep import enrich_secret_reachability

        with tempfile.TemporaryDirectory() as tmp:
            cfg = Path(tmp) / "secrets.yaml"
            cfg.write_text("api_token: abc123\n")

            # Python file that reads it
            src = Path(tmp) / "loader.py"
            src.write_text("with open('secrets.yaml') as f:\n    data = f.read()\n")

            findings = [
                {
                    "file_path": str(cfg),
                    "app_reachability": "UNKNOWN",
                    "finding_type": "secret",
                    "secret_type": "api_key",
                    "call_path": [],
                }
            ]
            enriched = enrich_secret_reachability(findings, tmp)
            assert enriched[0]["app_reachability"] == "REACHABLE"
            assert enriched[0].get("reachability_reason") == "file_read_confirmed"


# ===========================================================================
# T-CG12/13: Secret Level 2-3 — transformer + sink chain
# ===========================================================================


class TestCG12_SecretChain:
    """T-CG12: _build_secret_chain_level2 finds transformer+sink after ReadFile."""

    def test_chain_with_transformer(self):
        from reachable.database.normalizers.semgrep import _build_secret_chain_level2

        with tempfile.TemporaryDirectory() as tmp:
            cfg = Path(tmp) / "config.yaml"
            cfg.write_text("token: mysecret\n")

            src = Path(tmp) / "auth.go"
            src.write_text(
                "package main\n\n"
                "import (\n"
                '    "os"\n'
                '    "gopkg.in/yaml.v2"\n'
                '    "net/http"\n'
                ")\n\n"
                "func loadAuth() {\n"
                '    data, _ := os.ReadFile("config.yaml")\n'
                "    yaml.Unmarshal(data, &cfg)\n"
                '    req.Header.Set("Authorization", "Bearer "+cfg.Token)\n'
                "}\n"
            )
            chain = _build_secret_chain_level2(str(cfg), tmp, "api_token")
            assert len(chain) >= 2, f"Expected chain len >= 2, got {chain}"
            # First node should be the ReadFile call
            labels = [n["function"] for n in chain]
            assert any("ReadFile" in lbl or "open" in lbl for lbl in labels), f"ReadFile call not in chain: {labels}"

    def test_chain_empty_when_no_reader(self):
        from reachable.database.normalizers.semgrep import _build_secret_chain_level2

        with tempfile.TemporaryDirectory() as tmp:
            cfg = Path(tmp) / "orphan.pem"
            cfg.write_text("-----BEGIN RSA PRIVATE KEY-----\n")
            chain = _build_secret_chain_level2(str(cfg), tmp, "rsa_key")
            assert chain == []


# ===========================================================================
# T-CG14: JS dev/runtime split
# ===========================================================================


class TestCG14_JSDevRuntimeSplit:
    """T-CG14: parse_package_lock correctly splits dev and runtime packages."""

    def test_lockfile_v2_dev_detection(self):
        from reachable.collectors.callgraph.javascript import parse_package_lock

        with tempfile.TemporaryDirectory() as tmp:
            lock = {
                "lockfileVersion": 2,
                "packages": {
                    "": {},  # root
                    "node_modules/express": {"version": "4.18.0"},  # runtime
                    "node_modules/jest": {"version": "29.0.0", "dev": True},
                    "node_modules/typescript": {"version": "5.0.0", "dev": True},
                    "node_modules/axios": {"version": "1.4.0"},  # runtime
                },
            }
            lock_path = Path(tmp) / "package-lock.json"
            lock_path.write_text(json.dumps(lock))

            mapping = parse_package_lock(lock_path)
            assert mapping.get("express") == "runtime"
            assert mapping.get("jest") == "dev"
            assert mapping.get("typescript") == "dev"
            assert mapping.get("axios") == "runtime"

    def test_lockfile_v1_fallback(self):
        from reachable.collectors.callgraph.javascript import parse_package_lock

        with tempfile.TemporaryDirectory() as tmp:
            lock = {
                "lockfileVersion": 1,
                "dependencies": {
                    "lodash": {"version": "4.17.21"},
                    "mocha": {"version": "10.0.0", "dev": True},
                },
            }
            lock_path = Path(tmp) / "package-lock.json"
            lock_path.write_text(json.dumps(lock))

            mapping = parse_package_lock(lock_path)
            assert mapping.get("lodash") == "runtime"
            assert mapping.get("mocha") == "dev"

    def test_get_dev_packages_from_lockfile(self):
        from reachable.collectors.callgraph.javascript import get_dev_packages

        with tempfile.TemporaryDirectory() as tmp:
            lock = {
                "lockfileVersion": 2,
                "packages": {
                    "": {},
                    "node_modules/react": {"version": "18.0.0"},
                    "node_modules/eslint": {"version": "8.0.0", "dev": True},
                    "node_modules/webpack": {"version": "5.0.0", "dev": True},
                },
            }
            (Path(tmp) / "package-lock.json").write_text(json.dumps(lock))

            dev_pkgs = get_dev_packages(Path(tmp))
            assert "eslint" in dev_pkgs
            assert "webpack" in dev_pkgs
            assert "react" not in dev_pkgs

    def test_get_dev_packages_falls_back_to_package_json(self):
        from reachable.collectors.callgraph.javascript import get_dev_packages

        with tempfile.TemporaryDirectory() as tmp:
            pkg = {
                "name": "myapp",
                "dependencies": {"express": "^4.0.0"},
                "devDependencies": {"jest": "^29.0.0", "ts-jest": "^29.0.0"},
            }
            (Path(tmp) / "package.json").write_text(json.dumps(pkg))

            dev_pkgs = get_dev_packages(Path(tmp))
            assert "jest" in dev_pkgs
            assert "ts-jest" in dev_pkgs
            assert "express" not in dev_pkgs

    def test_empty_dir_returns_empty_set(self):
        from reachable.collectors.callgraph.javascript import get_dev_packages

        with tempfile.TemporaryDirectory() as tmp:
            result = get_dev_packages(Path(tmp))
            assert result == set()


# ===========================================================================
# T-CG16: Go boundary nodes in registry
# ===========================================================================


class TestCG16_BoundaryNodes:
    """T-CG16: syscall and CGO boundary nodes are in HCR registry."""

    def test_syscall_classified_boundary(self):
        from reachable.engine.hop_registry import HopPosition, NodeKind, classify_hop

        decision = classify_hop("syscall.RawSyscall", "CWE", HopPosition.LAST)
        assert decision.kind == NodeKind.BOUNDARY

    def test_cgo_classified_boundary(self):
        from reachable.engine.hop_registry import HopPosition, NodeKind, classify_hop

        decision = classify_hop("C.malloc", "CVE", HopPosition.MIDDLE)
        assert decision.kind == NodeKind.BOUNDARY

    def test_boundary_taint_exits_is_none(self):
        """Boundary nodes have taint_exits=None (unknown propagation)."""
        from reachable.engine.hop_registry import HopPosition, classify_hop

        decision = classify_hop("syscall.Getpid", "CWE", HopPosition.MIDDLE)
        assert decision.taint_exits is None


# ===========================================================================
# T-CG17: DLP path construction
# ===========================================================================


class TestCG17_DLPPathConstruction:
    """T-CG17: _build_dlp_path_nodes emits 3-node input→PII→sink chain."""

    def _make_source(self, variable, location, context=""):
        """Minimal PIISource stub."""

        class S:
            pass

        s = S()
        s.variable = variable
        s.location = location
        s.context = context
        s.pii_type = "email"
        return s

    def _make_sink(self, function, location, sink_type_val="log"):
        """Minimal DLPSink stub."""

        class St:
            def __init__(self, v):
                self.value = v

        class Sk:
            pass

        sk = Sk()
        sk.function = function
        sk.location = location
        sk.sink_type = St(sink_type_val)
        return sk

    def test_three_node_chain_when_pii_field_in_context(self):
        from reachable.dlp.taint.flow_analyzer import _build_dlp_path_nodes
        from reachable.engine.hop_registry import NodeKind

        source = self._make_source(
            variable="user",
            location="handlers.py:10",
            context="user.email",
        )
        sink = self._make_sink("logger.info", "handlers.py:12", "log")
        nodes = _build_dlp_path_nodes(source, sink)

        assert len(nodes) == 3, f"Expected 3 nodes, got {len(nodes)}: {[n.kind for n in nodes]}"
        assert nodes[0].kind == NodeKind.ENTRY
        assert nodes[1].kind == NodeKind.SOURCE_PII
        assert nodes[2].kind == NodeKind.SINK_DATA

    def test_two_node_chain_when_no_pii_field(self):
        from reachable.dlp.taint.flow_analyzer import _build_dlp_path_nodes
        from reachable.engine.hop_registry import NodeKind

        source = self._make_source("msg", "api.py:5", context="request.body")
        sink = self._make_sink("log.Write", "api.py:8", "log")
        nodes = _build_dlp_path_nodes(source, sink)

        assert len(nodes) == 2
        assert nodes[0].kind == NodeKind.ENTRY
        assert nodes[1].kind == NodeKind.SINK_DATA

    def test_llm_sink_escalates_to_sink_danger(self):
        from reachable.dlp.taint.flow_analyzer import _build_dlp_path_nodes
        from reachable.engine.hop_registry import NodeKind

        source = self._make_source("user", "chat.py:5", context="user.email")
        sink = self._make_sink("openai.create", "chat.py:8", "llm_api")
        nodes = _build_dlp_path_nodes(source, sink)

        sink_node = nodes[-1]
        assert sink_node.kind == NodeKind.SINK_DANGER, f"LLM API sink should be SINK_DANGER, got {sink_node.kind}"

    def test_pii_label_extracted_from_context(self):
        from reachable.dlp.taint.flow_analyzer import _build_dlp_path_nodes
        from reachable.engine.hop_registry import NodeKind

        source = self._make_source("payload", "api.py:10", context="payload.email + data")
        sink = self._make_sink("segment.track", "api.py:15", "analytics")
        nodes = _build_dlp_path_nodes(source, sink)

        pii_node = next((n for n in nodes if n.kind == NodeKind.SOURCE_PII), None)
        assert pii_node is not None
        assert "email" in pii_node.label.lower(), f"PII label should contain 'email': {pii_node.label}"


# ===========================================================================
# T-CG18: JS HCR rules
# ===========================================================================


class TestCG18_JSHCRRules:
    """T-CG18: JS-specific hop rules are present in the registry."""

    def test_innerHTML_classified_sink_danger(self):
        from reachable.engine.hop_registry import HopPosition, NodeKind, classify_hop

        decision = classify_hop(".innerHTML =", "CWE", HopPosition.LAST)
        assert decision.kind == NodeKind.SINK_DANGER

    def test_dangerouslySetInnerHTML_classified_sink_danger(self):
        from reachable.engine.hop_registry import HopPosition, NodeKind, classify_hop

        decision = classify_hop("dangerouslySetInnerHTML", "CWE", HopPosition.LAST)
        assert decision.kind == NodeKind.SINK_DANGER

    def test_axios_classified_sink_secret(self):
        from reachable.engine.hop_registry import HopPosition, NodeKind, classify_hop

        decision = classify_hop("axios.post", "SECRET", HopPosition.LAST)
        assert decision.kind == NodeKind.SINK_SECRET

    def test_jest_classified_boundary(self):
        from reachable.engine.hop_registry import HopPosition, NodeKind, classify_hop

        decision = classify_hop("jest.fn", "CVE", HopPosition.MIDDLE)
        assert decision.kind == NodeKind.BOUNDARY

    def test_json_parse_classified_stdlib(self):
        from reachable.engine.hop_registry import HopPosition, NodeKind, classify_hop

        decision = classify_hop("JSON.parse", "CVE", HopPosition.MIDDLE)
        assert decision.kind == NodeKind.STDLIB

    def test_fs_writefile_classified_sink_danger(self):
        from reachable.engine.hop_registry import HopPosition, NodeKind, classify_hop

        decision = classify_hop("fs.writeFile", "CWE", HopPosition.LAST)
        assert decision.kind == NodeKind.SINK_DANGER

    def test_express_route_classified_entry(self):
        from reachable.engine.hop_registry import HopPosition, NodeKind, classify_hop

        decision = classify_hop("app.post('/api/users')", "CWE", HopPosition.FIRST)
        assert decision.kind == NodeKind.ENTRY

    def test_js_rules_exported_from_registry(self):
        from reachable.engine.hop_registry import JS_RULES

        assert len(JS_RULES) > 5, "JS_RULES must have at least 5 rules"


class TestCG10_CallPathsV2Pipeline:
    """T-CG10: End-to-end call_paths_v2 population.

    These tests verify the FULL pipeline:
      normalizer sets call_paths_v2  → storage stores it → loader reads it back.
    Previously all T-CG tasks passed but call_paths_v2 was ALWAYS [] in the DB
    because no normalizer ever called upgrade_v1_path.
    """

    def test_cve_normalizer_sets_call_paths_v2(self):
        """T-CG10: normalize_cves must produce call_paths_v2 on REACHABLE findings."""
        from reachable.database.normalizers.cve import normalize_cves

        report = {
            "reachable": {
                "CVE-2024-0001": {
                    "cve": "CVE-2024-0001",
                    "cve_id": "CVE-2024-0001",
                    "ghsa_id": None,
                    "display_id": "CVE-2024-0001",
                    "package": "github.com/gin-gonic/gin",
                    "version": "v1.9.0",
                    "severity": "HIGH",
                    "app_reachability": "REACHABLE",
                    "call_paths": [
                        ["app.main.ServeHTTP", "github.com/gin-gonic/gin", "github.com/gin-gonic/gin"],
                        ["app.api.handler", "github.com/gin-gonic/gin"],
                    ],
                }
            },
            "unreachable": {},
        }
        result = normalize_cves({"cve-analyzed.json": report})
        findings = result["cve"]
        assert len(findings) == 1
        f = findings[0]
        v2 = f.get("call_paths_v2")
        assert v2 is not None, "call_paths_v2 must be set by cve normalizer"
        assert isinstance(v2, list), "call_paths_v2 must be a list"
        assert len(v2) == 2, f"Expected 2 paths, got {len(v2)}"
        # Each path is a list of PathNode dicts
        path0 = v2[0]
        assert isinstance(path0, list), "each path must be a list of PathNode dicts"
        assert len(path0) == 3
        node0 = path0[0]
        assert "kind" in node0, "PathNode dict must have 'kind'"
        assert "label" in node0, "PathNode dict must have 'label'"
        # First node should be ENTRY or APP
        assert node0["kind"] in ("entry", "app"), f"First node kind wrong: {node0['kind']}"

    def test_cve_normalizer_v2_nodes_are_classified(self):
        """T-CG10: PathNode kinds must be set by HCR, not all 'app'."""
        from reachable.database.normalizers.cve import normalize_cves

        report = {
            "reachable": {
                "CVE-2024-0002": {
                    "cve": "CVE-2024-0002",
                    "cve_id": "CVE-2024-0002",
                    "ghsa_id": None,
                    "display_id": "CVE-2024-0002",
                    "package": "golang.org/x/crypto",
                    "version": "v0.0.1",
                    "severity": "CRITICAL",
                    "app_reachability": "REACHABLE",
                    "call_paths": [
                        [
                            "app.main.handleAuth",
                            "database/sql",
                            "golang.org/x/crypto",
                        ]
                    ],
                }
            },
            "unreachable": {},
        }
        result = normalize_cves({"cve-analyzed.json": report})
        f = result["cve"][0]
        path = f["call_paths_v2"][0]
        kinds = [n["kind"] for n in path]
        # database/sql is a SINK_DANGER or stripped; crypto pkg is boundary/sink
        # Regardless, they must NOT all be 'app'
        non_app = [k for k in kinds if k != "app"]
        assert len(non_app) > 0, f"Expected at least one non-app node, got all 'app': {kinds}"

    def test_semgrep_normalizer_cwe_sets_call_paths_v2(self):
        """T-CG10: CWE findings from semgrep must have call_paths_v2 set."""
        from pathlib import Path

        from reachable.database.normalizers.semgrep import normalize_semgrep

        raw_finding = {
            "check_id": "python.flask.security.xss.reflected-xss-all-config",
            "path": "app/routes.py",
            "start": {"line": 42},
            "end": {"line": 42},
            "extra": {
                "message": "Reflected XSS vulnerability",
                "severity": "ERROR",
                "metadata": {"cwe": ["CWE-79"]},
                "is_reachable": True,
            },
        }
        raw_files = {"security-findings.json": {"results": [raw_finding]}}
        result = normalize_semgrep(raw_files, scan_dir=Path("/tmp"))
        cwes = result.get("cwe", [])
        assert len(cwes) == 1, f"Expected 1 CWE finding, got {len(cwes)}"
        f = cwes[0]
        v2 = f.get("call_paths_v2")
        assert v2 is not None, "call_paths_v2 must be set by semgrep normalizer for CWE"
        assert isinstance(v2, list)
        # May be empty list if call_path was empty, but must exist as key
        # If call_path was built, v2 must be non-empty
        call_path = f.get("call_path", [])
        if call_path:
            assert len(v2) > 0, "call_paths_v2 must be non-empty when call_path is set"
            path0 = v2[0]
            assert isinstance(path0, list)
            assert all("kind" in n and "label" in n for n in path0), "Each PathNode must have 'kind' and 'label'"

    def test_loaders_reads_call_paths_v2_from_db(self):
        """T-CG10: loaders._get_all_issues must SELECT and parse call_paths_v2."""
        import json
        import sqlite3
        import tempfile

        # Build a minimal in-memory DB with a finding that has call_paths_v2
        with tempfile.NamedTemporaryFile(suffix=".db", delete=False) as f:
            db_path = f.name

        conn = sqlite3.connect(db_path)
        conn.execute("""CREATE TABLE scans (
            id INTEGER PRIMARY KEY, repo_path TEXT, scan_time TEXT,
            status TEXT DEFAULT 'complete', risk_level TEXT
        )""")
        conn.execute("INSERT INTO scans VALUES (1, '/repo', '2026-01-01', 'complete', 'HIGH')")
        conn.execute("""CREATE TABLE findings (
            id INTEGER PRIMARY KEY, scan_id INTEGER, finding_type TEXT,
            finding_id TEXT, display_id TEXT, ghsa_id TEXT, id_note TEXT,
            severity TEXT, title TEXT, description TEXT,
            file_path TEXT, line_number INTEGER,
            package_name TEXT, package_version TEXT,
            app_reachability TEXT, app_reachability_confidence TEXT,
            app_reachability_path TEXT, cwe_id TEXT,
            fix_status TEXT, fix_version TEXT,
            call_paths TEXT DEFAULT '[]',
            call_paths_v2 TEXT DEFAULT '[]',
            reachability_reason TEXT,
            containing_function TEXT,
            via_package TEXT,
            dependency_chain TEXT DEFAULT '[]',
            is_transitive INTEGER DEFAULT 0
        )""")

        v2_data = json.dumps(
            [
                [
                    {"kind": "entry", "label": "main.Handler", "file": "main.go", "line": 10},
                    {"kind": "sink_danger", "label": "database/sql", "file": "", "line": 0},
                ]
            ]
        )
        conn.execute(
            """INSERT INTO findings VALUES
            (1, 1, 'cve', 'CVE-2024-X', 'CVE-2024-X', NULL, NULL,
             'HIGH', 'Test CVE', 'desc', NULL, NULL,
             'github.com/some/pkg', 'v1.0.0',
             'REACHABLE', 'HIGH', NULL, NULL,
             NULL, 'v1.1.0',
             '[]', ?, 'file_read_confirmed', 'main.Handler',
             'github.com/dep', '[]', 0)
        """,
            (v2_data,),
        )
        conn.commit()
        conn.close()

        # Call _get_all_issues directly to avoid load_from_database's
        # unrelated top-level import dependencies (reachable.metrics, etc.)
        conn2 = sqlite3.connect(db_path)
        conn2.row_factory = sqlite3.Row
        cursor = conn2.cursor()
        from reachable.dashboard_v2.loaders import _get_all_issues

        issues = _get_all_issues(cursor, scan_id=1)
        conn2.close()
        cve_issues = [i for i in issues if i.get("type") == "CVE"]
        assert len(cve_issues) == 1, f"Expected 1 CVE issue, got {len(cve_issues)}"
        issue = cve_issues[0]

        # call_paths_v2 must be present and non-empty
        v2 = issue.get("call_paths_v2")
        assert v2 is not None, "loaders must pass call_paths_v2 through to issue dict"
        assert isinstance(v2, list) and len(v2) > 0, f"call_paths_v2 must be non-empty list, got: {v2}"
        path0 = v2[0]
        assert isinstance(path0, list) and len(path0) == 2
        assert path0[0]["kind"] == "entry"
        assert path0[0]["label"] == "main.Handler"

        # reachability_reason and containing_function must also be loaded
        assert issue.get("reachability_reason") == "file_read_confirmed"
        assert issue.get("containing_function") == "main.Handler"

    def test_loaders_no_v1_fallback(self):
        """T-CG28: loader does NOT attempt v1 upgrade — call_paths_v2 is the only path column."""
        from reachable.engine import hop_registry

        # upgrade_v1_path must not exist
        assert not hasattr(hop_registry, "upgrade_v1_path"), "upgrade_v1_path must be deleted — v1 is gone"
