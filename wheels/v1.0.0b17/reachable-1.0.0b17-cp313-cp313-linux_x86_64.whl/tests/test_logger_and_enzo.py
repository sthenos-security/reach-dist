#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.
"""
Test suite: Logger fixes + Enzo CLI integration.

Validates:
  - ANSI escape codes stripped from log file output
  - All log-file lines include [LEVEL] tags
  - _write_log_only writes [DEBUG] tag (not bare)
  - Quiet-mode log writes include [INFO] tag
  - _AnsiStrippingFormatter works on Python logging file handler
  - Enzo subcommand registers into reachctl argparser
  - Enzo CLI dispatch works via args.func binding

Run:  python tests/test_logger_and_enzo.py
"""

from __future__ import annotations

import argparse
import io
import json
import logging
import os
import re
import sys
import tempfile
import traceback
from pathlib import Path
from typing import List

# Ensure package is importable
_tests_dir = os.path.dirname(os.path.abspath(__file__))
_project_root = os.path.dirname(_tests_dir)
if _project_root not in sys.path:
    sys.path.insert(0, _project_root)

# ═══════════════════════════════════════════════════════════════════════════
#  Minimal test framework (matches enzo test style — no external deps)
# ═══════════════════════════════════════════════════════════════════════════

_PASS = 0
_FAIL = 0
_SKIP = 0
_ERRORS: List[str] = []


def test(name):
    """Decorator for test functions."""

    def decorator(func):
        func._test_name = name
        return func

    return decorator


def run_test(func):
    global _PASS, _FAIL, _SKIP
    name = getattr(func, "_test_name", func.__name__)
    try:
        func()
        _PASS += 1
        print(f"  ✓ {name}")
    except AssertionError as e:
        _FAIL += 1
        _ERRORS.append(f"  FAIL: {name}\n    {e}")
        print(f"  ✗ {name}: {e}")
    except Exception as e:
        _FAIL += 1
        tb = traceback.format_exc()
        _ERRORS.append(f"  ERROR: {name}\n    {e}\n{tb}")
        print(f"  ✗ {name}: {e}")


def assert_true(cond, msg=""):
    if not cond:
        raise AssertionError(msg or "Expected True")


def assert_eq(a, b, msg=""):
    if a != b:
        raise AssertionError(msg or f"Expected {a!r} == {b!r}")


def assert_in(needle, haystack, msg=""):
    if needle not in haystack:
        raise AssertionError(msg or f"Expected {needle!r} in {haystack!r}")


def assert_not_in(needle, haystack, msg=""):
    if needle in haystack:
        raise AssertionError(msg or f"Expected {needle!r} NOT in {haystack!r}")


# ═══════════════════════════════════════════════════════════════════════════
#  Helper: fresh logger instance (bypass singleton for testing)
# ═══════════════════════════════════════════════════════════════════════════


def _make_fresh_logger():
    """Create a fresh ReachableLogger with singleton bypassed."""
    from reachable.core.logger import ReachableLogger

    # Reset singleton
    ReachableLogger._instance = None
    inst = ReachableLogger()
    return inst


# ═══════════════════════════════════════════════════════════════════════════
#  Logger tests
# ═══════════════════════════════════════════════════════════════════════════


@test("Logger: ANSI stripped from log file via _write()")
def test_ansi_stripped_write():
    logger = _make_fresh_logger()
    with tempfile.NamedTemporaryFile(mode="w", suffix=".log", delete=False) as f:
        tmp = Path(f.name)
    try:
        logger.configure(log_file=tmp)
        # Write message with ANSI codes
        logger.info("\033[91m5 Critical\033[0m, \033[93m3 Medium\033[0m")
        logger.close()
        content = tmp.read_text()
        assert_not_in("\033[", content, "ANSI escape codes found in log file")
        assert_not_in("\x1b[", content, "ANSI escape codes found in log file (hex)")
        assert_in("5 Critical", content, "Stripped message content missing")
        assert_in("3 Medium", content, "Stripped message content missing")
        assert_in("[INFO]", content, "Missing [INFO] level tag")
    finally:
        tmp.unlink(missing_ok=True)


@test("Logger: ANSI stripped from log file via _write_log_only()")
def test_ansi_stripped_write_log_only():
    logger = _make_fresh_logger()
    with tempfile.NamedTemporaryFile(mode="w", suffix=".log", delete=False) as f:
        tmp = Path(f.name)
    try:
        logger.configure(log_file=tmp, debug=True)
        logger._write_log_only("severity: \033[38;5;208m10 High\033[0m done")
        logger.close()
        content = tmp.read_text()
        assert_not_in("\033[", content, "ANSI found in _write_log_only output")
        assert_in("10 High", content, "Content missing after ANSI strip")
    finally:
        tmp.unlink(missing_ok=True)


@test("Logger: _write_log_only includes [DEBUG] level tag")
def test_write_log_only_has_level_tag():
    logger = _make_fresh_logger()
    with tempfile.NamedTemporaryFile(mode="w", suffix=".log", delete=False) as f:
        tmp = Path(f.name)
    try:
        logger.configure(log_file=tmp, debug=True)
        logger._write_log_only("SCANNER EXECUTION")
        logger._write_log_only("POLICY COVERAGE")
        logger.close()
        content = tmp.read_text()
        lines = [l for l in content.strip().split("\n") if l.strip()]
        for line in lines:
            assert_in("[DEBUG]", line, f"Missing [DEBUG] tag in line: {line!r}")
    finally:
        tmp.unlink(missing_ok=True)


@test("Logger: _write_log_only accepts custom level")
def test_write_log_only_custom_level():
    logger = _make_fresh_logger()
    with tempfile.NamedTemporaryFile(mode="w", suffix=".log", delete=False) as f:
        tmp = Path(f.name)
    try:
        logger.configure(log_file=tmp)
        logger._write_log_only("test message", level="INFO")
        logger.close()
        content = tmp.read_text()
        assert_in("[INFO]", content, "Custom level not applied")
    finally:
        tmp.unlink(missing_ok=True)


@test("Logger: quiet mode still writes [INFO] tag to log file")
def test_quiet_mode_log_has_level_tag():
    logger = _make_fresh_logger()
    with tempfile.NamedTemporaryFile(mode="w", suffix=".log", delete=False) as f:
        tmp = Path(f.name)
    try:
        logger.configure(log_file=tmp, quiet=True)
        logger.info("suppressed on console but in log file")
        logger.close()
        content = tmp.read_text()
        assert_in("[INFO]", content, "Missing [INFO] tag in quiet-mode log")
        assert_in("suppressed on console", content, "Message missing from log")
    finally:
        tmp.unlink(missing_ok=True)


@test("Logger: quiet mode strips ANSI from log file")
def test_quiet_mode_strips_ansi():
    logger = _make_fresh_logger()
    with tempfile.NamedTemporaryFile(mode="w", suffix=".log", delete=False) as f:
        tmp = Path(f.name)
    try:
        logger.configure(log_file=tmp, quiet=True)
        logger.info("\033[91mRED\033[0m text")
        logger.close()
        content = tmp.read_text()
        assert_not_in("\033[", content, "ANSI found in quiet-mode log")
        assert_in("RED text", content, "Content missing")
    finally:
        tmp.unlink(missing_ok=True)


@test("Logger: debug() writes [DEBUG] tag to log file even when debug=False")
def test_debug_logonly_has_tag():
    logger = _make_fresh_logger()
    with tempfile.NamedTemporaryFile(mode="w", suffix=".log", delete=False) as f:
        tmp = Path(f.name)
    try:
        logger.configure(log_file=tmp, debug=False)
        logger.debug("detail info")
        logger.close()
        content = tmp.read_text()
        assert_in("[DEBUG]", content, "Missing [DEBUG] tag")
        assert_in("detail info", content, "Message missing")
    finally:
        tmp.unlink(missing_ok=True)


@test("Logger: _AnsiStrippingFormatter strips ANSI from Python logging")
def test_ansi_stripping_formatter():
    from reachable.core.logger import _AnsiStrippingFormatter

    formatter = _AnsiStrippingFormatter("%(message)s")
    record = logging.LogRecord(
        name="test",
        level=logging.INFO,
        pathname="",
        lineno=0,
        msg="\033[91mCritical\033[0m and \033[93mMedium\033[0m",
        args=(),
        exc_info=None,
    )
    result = formatter.format(record)
    assert_not_in("\033[", result, "ANSI not stripped by formatter")
    assert_in("Critical and Medium", result, "Content lost after stripping")


@test("Logger: _ANSI_RE regex covers common escape patterns")
def test_ansi_regex_patterns():
    from reachable.core.logger import _ANSI_RE

    test_cases = [
        ("\033[91mred\033[0m", "red"),
        ("\033[38;5;208morange\033[0m", "orange"),
        ("\033[93myellow\033[0m", "yellow"),
        ("\x1b[94mblue\x1b[0m", "blue"),
        ("no ansi here", "no ansi here"),
        ("\033[1;31mbold red\033[0m", "bold red"),
    ]
    for raw, expected in test_cases:
        result = _ANSI_RE.sub("", raw)
        assert_eq(result, expected, f"ANSI strip failed: {raw!r} → {result!r}, expected {expected!r}")


@test("Logger: _write_stderr strips ANSI in log file")
def test_write_stderr_strips_ansi():
    logger = _make_fresh_logger()
    with tempfile.NamedTemporaryFile(mode="w", suffix=".log", delete=False) as f:
        tmp = Path(f.name)
    try:
        logger.configure(log_file=tmp)
        logger._write_stderr("\033[91mERROR\033[0m something broke")
        logger.close()
        content = tmp.read_text()
        assert_not_in("\033[", content, "ANSI found in _write_stderr log output")
        assert_in("[ERROR]", content, "Missing [ERROR] tag")
        assert_in("something broke", content, "Content missing")
    finally:
        tmp.unlink(missing_ok=True)


@test("Logger: every log-file write path includes level tag")
def test_all_paths_have_level_tags():
    """Comprehensive: write all paths and verify every line has a level tag."""
    logger = _make_fresh_logger()
    with tempfile.NamedTemporaryFile(mode="w", suffix=".log", delete=False) as f:
        tmp = Path(f.name)
    try:
        logger.configure(log_file=tmp, debug=True)
        logger.info("info msg")
        logger.debug("debug msg")
        logger.warning("warn msg")
        logger.error("error msg")
        logger._write_log_only("log-only msg")
        logger._write_log_only("custom-level msg", level="INFO")
        logger.close()

        content = tmp.read_text()
        level_re = re.compile(r"\[(DEBUG|INFO|WARN|ERROR)\]")
        lines = [l for l in content.strip().split("\n") if l.strip()]
        assert_true(len(lines) >= 6, f"Expected ≥6 lines, got {len(lines)}")
        for line in lines:
            assert_true(level_re.search(line) is not None, f"Missing level tag in line: {line!r}")
    finally:
        tmp.unlink(missing_ok=True)


# ═══════════════════════════════════════════════════════════════════════════
#  JSONL mode tests (--log-format jsonl)
# ═══════════════════════════════════════════════════════════════════════════


@test("JSONL: _write produces valid JSON lines")
def test_jsonl_write_valid():
    from reachable.core.logger import OutputMode

    logger = _make_fresh_logger()
    with tempfile.NamedTemporaryFile(mode="w", suffix=".log", delete=False) as f:
        tmp = Path(f.name)
    try:
        logger.configure(mode=OutputMode.JSON, log_file=tmp)
        old_stdout = logger._stdout
        capture = io.StringIO()
        logger._stdout = capture
        logger.info("test message")
        logger.warning("warn message")
        logger._stdout = old_stdout
        output = capture.getvalue()
        lines = [l for l in output.strip().split("\n") if l.strip()]
        assert_eq(len(lines), 2, f"Expected 2 JSONL lines, got {len(lines)}")
        for line in lines:
            parsed = json.loads(line)  # Raises on invalid JSON
            assert_in("level", parsed, "Missing level field")
            assert_in("msg", parsed, "Missing msg field")
        # Check levels
        info_line = json.loads(lines[0])
        warn_line = json.loads(lines[1])
        assert_eq(info_line["level"], "INFO")
        assert_eq(warn_line["level"], "WARN")
        assert_eq(info_line["msg"], "test message")
    finally:
        logger._stdout = old_stdout if "old_stdout" in dir() else sys.stdout
        tmp.unlink(missing_ok=True)


@test("JSONL: _write_event produces valid JSON without double-encoding")
def test_jsonl_write_event_no_double_encode():
    from reachable.core.logger import OutputMode

    logger = _make_fresh_logger()
    with tempfile.NamedTemporaryFile(mode="w", suffix=".log", delete=False) as f:
        tmp = Path(f.name)
    try:
        logger.configure(mode=OutputMode.JSON, log_file=tmp, timestamps=True)
        old_stdout = logger._stdout
        capture = io.StringIO()
        logger._stdout = capture
        logger._write_event({"event": "test", "count": 42, "nested": {"a": 1}})
        logger._stdout = old_stdout
        output = capture.getvalue().strip()
        parsed = json.loads(output)
        # event fields should be at top level, not nested in "msg"
        assert_eq(parsed["event"], "test", "Event field not at top level")
        assert_eq(parsed["count"], 42, "Count field wrong")
        assert_eq(parsed["nested"]["a"], 1, "Nested dict not preserved")
        assert_in("ts", parsed, "Timestamp missing")
        assert_in("level", parsed, "Level missing")
        # Crucially: no "msg" field wrapping serialized JSON
        assert_true("msg" not in parsed, f"msg field found — double encoding! keys: {list(parsed.keys())}")
    finally:
        logger._stdout = old_stdout if "old_stdout" in dir() else sys.stdout
        tmp.unlink(missing_ok=True)


@test("JSONL: phase_start uses _write_event (no double-encoding)")
def test_jsonl_phase_start():
    from reachable.core.logger import OutputMode

    logger = _make_fresh_logger()
    with tempfile.NamedTemporaryFile(mode="w", suffix=".log", delete=False) as f:
        tmp = Path(f.name)
    try:
        logger.configure(mode=OutputMode.JSON, log_file=tmp)
        logger.scan_start("1.0.0", "test-repo", Path("/tmp/test"))
        old_stdout = logger._stdout
        capture = io.StringIO()
        logger._stdout = capture
        logger.phase_start(1, "SBOM Generation", "Syft", total_phases=5)
        logger._stdout = old_stdout
        output = capture.getvalue().strip()
        parsed = json.loads(output)
        assert_eq(parsed["event"], "phase_start")
        assert_eq(parsed["phase"], 1)
        assert_eq(parsed["name"], "SBOM Generation")
        assert_eq(parsed["scanner"], "Syft")
        assert_true("msg" not in parsed, "Double-encoded: msg field present")
    finally:
        logger._stdout = old_stdout if "old_stdout" in dir() else sys.stdout
        tmp.unlink(missing_ok=True)


@test("JSONL: phase_end uses _write_event")
def test_jsonl_phase_end():
    import time as _time

    from reachable.core.logger import OutputMode

    logger = _make_fresh_logger()
    with tempfile.NamedTemporaryFile(mode="w", suffix=".log", delete=False) as f:
        tmp = Path(f.name)
    try:
        logger.configure(mode=OutputMode.JSON, log_file=tmp)
        logger.scan_start("1.0.0", "test-repo", Path("/tmp/test"))
        logger.phase_start(1, "Test Phase", total_phases=1)
        _time.sleep(0.05)
        old_stdout = logger._stdout
        capture = io.StringIO()
        logger._stdout = capture
        logger.phase_end(1, "done")
        logger._stdout = old_stdout
        output = capture.getvalue().strip()
        parsed = json.loads(output)
        assert_eq(parsed["event"], "phase_end")
        assert_eq(parsed["phase"], 1)
        assert_in("elapsed_sec", parsed, "Missing elapsed_sec")
        assert_true(parsed["elapsed_sec"] >= 0.04, f"Elapsed too small: {parsed['elapsed_sec']}")
    finally:
        logger._stdout = old_stdout if "old_stdout" in dir() else sys.stdout
        tmp.unlink(missing_ok=True)


@test("JSONL: print_timing_summary emits structured timing event")
def test_jsonl_timing_summary():
    import time as _time

    from reachable.core.logger import OutputMode

    logger = _make_fresh_logger()
    with tempfile.NamedTemporaryFile(mode="w", suffix=".log", delete=False) as f:
        tmp = Path(f.name)
    try:
        logger.configure(mode=OutputMode.JSON, log_file=tmp)
        logger.scan_start("1.0.0", "test-repo", Path("/tmp/test"))
        logger.phase_start(1, "Phase A", total_phases=2)
        _time.sleep(0.05)
        logger.phase_end(1, "ok")
        logger.phase_start(2, "Phase B", "Scanner", total_phases=2)
        _time.sleep(0.05)
        logger.phase_end(2, "ok")
        # Capture timing summary
        old_stdout = logger._stdout
        capture = io.StringIO()
        logger._stdout = capture
        logger.print_timing_summary()
        logger._stdout = old_stdout
        output = capture.getvalue().strip()
        parsed = json.loads(output)
        assert_eq(parsed["event"], "timing")
        assert_true(len(parsed["phases"]) == 2, f"Expected 2 phases, got {len(parsed['phases'])}")
        assert_in("total_sec", parsed, "Missing total_sec")
        # Check phase structure
        p1 = parsed["phases"][0]
        assert_eq(p1["phase"], 1)
        assert_eq(p1["name"], "Phase A")
        assert_in("elapsed_sec", p1, "Missing elapsed_sec in phase")
    finally:
        logger._stdout = old_stdout if "old_stdout" in dir() else sys.stdout
        tmp.unlink(missing_ok=True)


@test("JSONL: print_results_summary emits structured results event")
def test_jsonl_results_summary():
    from reachable.core.logger import OutputMode

    logger = _make_fresh_logger()
    with tempfile.NamedTemporaryFile(mode="w", suffix=".log", delete=False) as f:
        tmp = Path(f.name)
    try:
        logger.configure(mode=OutputMode.JSON, log_file=tmp)
        logger.scan_start("1.0.0", "test-repo", Path("/tmp/test"))
        logger.set_counts(
            cves_total=10,
            cves_reachable=3,
            cves_unknown=2,
            secrets_total=5,
            secrets_reachable=1,
            secrets_unknown=1,
            cwe_total=7,
            cwe_reachable=2,
            cwe_unknown=0,
            malware_count=1,
            malware_reachable=1,
        )
        old_stdout = logger._stdout
        capture = io.StringIO()
        logger._stdout = capture
        logger.print_results_summary()
        logger._stdout = old_stdout
        output = capture.getvalue().strip()
        parsed = json.loads(output)
        assert_eq(parsed["event"], "results_summary")
        assert_eq(parsed["cves"]["total"], 10)
        assert_eq(parsed["cves"]["reachable"], 3)
        assert_eq(parsed["secrets"]["total"], 5)
        assert_eq(parsed["cwe"]["total"], 7)
        assert_in("totals", parsed, "Missing totals")
        assert_eq(parsed["totals"]["all"], 10 + 5 + 7 + 1)  # cves + secrets + cwe + malware
    finally:
        logger._stdout = old_stdout if "old_stdout" in dir() else sys.stdout
        tmp.unlink(missing_ok=True)


@test("JSONL: scan_complete emits structured event")
def test_jsonl_scan_complete():
    from reachable.core.logger import OutputMode

    logger = _make_fresh_logger()
    with tempfile.NamedTemporaryFile(mode="w", suffix=".log", delete=False) as f:
        tmp = Path(f.name)
    try:
        logger.configure(mode=OutputMode.JSON, log_file=tmp)
        logger.scan_start("1.0.0", "test-repo", Path("/tmp/test"))
        old_stdout = logger._stdout
        capture = io.StringIO()
        logger._stdout = capture
        logger.scan_complete(750, "HIGH", Path("/tmp/output"))
        logger._stdout = old_stdout
        output = capture.getvalue().strip()
        parsed = json.loads(output)
        assert_eq(parsed["event"], "scan_complete")
        assert_eq(parsed["risk_score"], 750)
        assert_eq(parsed["risk_level"], "HIGH")
    finally:
        logger._stdout = old_stdout if "old_stdout" in dir() else sys.stdout
        tmp.unlink(missing_ok=True)


@test("JSONL: quiet mode does NOT suppress structured events")
def test_jsonl_quiet_events_survive():
    import time as _time

    from reachable.core.logger import OutputMode

    logger = _make_fresh_logger()
    with tempfile.NamedTemporaryFile(mode="w", suffix=".log", delete=False) as f:
        tmp = Path(f.name)
    try:
        logger.configure(mode=OutputMode.JSON, quiet=True, log_file=tmp)
        logger.scan_start("1.0.0", "test-repo", Path("/tmp/test"))
        logger.phase_start(1, "Test", total_phases=1)
        _time.sleep(0.02)
        logger.phase_end(1, "ok")
        old_stdout = logger._stdout
        capture = io.StringIO()
        logger._stdout = capture
        # These should all produce output despite quiet=True
        logger.info("plain info")  # This SHOULD appear (JSON mode ignores quiet)
        logger.print_timing_summary()
        logger._stdout = old_stdout
        output = capture.getvalue()
        lines = [l for l in output.strip().split("\n") if l.strip()]
        assert_true(len(lines) >= 2, f"Expected ≥2 JSONL lines in quiet+JSON mode, got {len(lines)}")
        events = [json.loads(l) for l in lines]
        event_types = [e.get("event") for e in events if "event" in e]
        assert_in("timing", event_types, "timing event suppressed by quiet mode")
    finally:
        logger._stdout = old_stdout if "old_stdout" in dir() else sys.stdout
        tmp.unlink(missing_ok=True)


@test("JSONL: --no-timestamps respected (ts field absent)")
def test_jsonl_no_timestamps():
    from reachable.core.logger import OutputMode

    logger = _make_fresh_logger()
    with tempfile.NamedTemporaryFile(mode="w", suffix=".log", delete=False) as f:
        tmp = Path(f.name)
    try:
        logger.configure(mode=OutputMode.JSON, log_file=tmp, timestamps=False)
        old_stdout = logger._stdout
        capture = io.StringIO()
        logger._stdout = capture
        logger.info("no ts")
        logger._write_event({"event": "test"})
        logger._stdout = old_stdout
        output = capture.getvalue()
        lines = [l for l in output.strip().split("\n") if l.strip()]
        for line in lines:
            parsed = json.loads(line)
            assert_true("ts" not in parsed, f"ts present despite timestamps=False: {parsed}")
    finally:
        logger._stdout = old_stdout if "old_stdout" in dir() else sys.stdout
        tmp.unlink(missing_ok=True)


@test("JSONL: --log-format jsonl overrides --ci in scan.py")
def test_jsonl_overrides_ci():
    scan_path = Path(_project_root) / "reachable" / "cli" / "scan.py"
    content = scan_path.read_text()
    # Verify precedence: jsonl > ci > HUMAN
    assert_in('log_format == "jsonl"', content, "JSONL precedence check missing")
    assert_in("OutputMode.JSON", content, "OutputMode.JSON not used")
    # The if/elif chain should check jsonl FIRST, then ci
    jsonl_pos = content.find('log_format == "jsonl"')
    ci_pos = content.find("elif ci_mode:")
    assert_true(jsonl_pos < ci_pos, f"JSONL check (pos {jsonl_pos}) must come before CI check (pos {ci_pos})")


@test("JSONL: full scan event stream is valid JSONL")
def test_jsonl_full_stream():
    """Simulate a complete scan lifecycle and verify all output is valid JSONL."""
    import time as _time

    from reachable.core.logger import OutputMode

    logger = _make_fresh_logger()
    with tempfile.NamedTemporaryFile(mode="w", suffix=".log", delete=False) as f:
        tmp = Path(f.name)
    try:
        logger.configure(mode=OutputMode.JSON, log_file=tmp, timestamps=True)

        old_stdout = logger._stdout
        old_stderr = logger._stderr
        stdout_cap = io.StringIO()
        stderr_cap = io.StringIO()
        logger._stdout = stdout_cap
        logger._stderr = stderr_cap

        # Full lifecycle
        logger.scan_start("1.0.0b16", "myrepo", Path("/tmp/myrepo"))
        logger.phase_start(1, "SBOM", "Syft", total_phases=3)
        logger.info("Generating SBOM...")
        _time.sleep(0.02)
        logger.phase_end(1, "sbom.json")
        logger.phase_start(2, "Vuln Scan", "Grype", total_phases=3)
        logger.warning("DB outdated")
        _time.sleep(0.02)
        logger.phase_end(2, "42 CVEs")
        logger.phase_start(3, "Analysis", total_phases=3)
        logger.error("Callgraph timeout on module X")
        _time.sleep(0.02)
        logger.phase_end(3, "Complete")
        logger.set_counts(
            cves_total=42,
            cves_reachable=5,
            cves_unknown=10,
            secrets_total=3,
            secrets_reachable=1,
            secrets_unknown=0,
            cwe_total=8,
            cwe_reachable=2,
            cwe_unknown=1,
            malware_count=0,
            malware_reachable=0,
        )
        logger.print_timing_summary()
        logger.print_results_summary()
        logger.scan_complete(650, "MEDIUM", Path("/tmp/output"))

        logger._stdout = old_stdout
        logger._stderr = old_stderr

        # Validate stdout: every line must be valid JSON
        stdout_lines = [l for l in stdout_cap.getvalue().strip().split("\n") if l.strip()]
        stderr_lines = [l for l in stderr_cap.getvalue().strip().split("\n") if l.strip()]
        all_lines = stdout_lines + stderr_lines

        assert_true(len(all_lines) >= 8, f"Expected ≥8 JSONL lines for full lifecycle, got {len(all_lines)}")

        for i, line in enumerate(all_lines):
            try:
                parsed = json.loads(line)
                assert_in("level", parsed, f"Line {i} missing level: {line[:80]}")
            except json.JSONDecodeError as e:
                raise AssertionError(f"Line {i} invalid JSON: {line[:80]}... Error: {e}")

        # Check we got all expected structured events
        events = []
        for line in stdout_lines:
            p = json.loads(line)
            if "event" in p:
                events.append(p["event"])

        assert_in("scan_start", events, "Missing scan_start event")
        assert_in("phase_start", events, "Missing phase_start event")
        assert_in("phase_end", events, "Missing phase_end event")
        assert_in("timing", events, "Missing timing event")
        assert_in("results_summary", events, "Missing results_summary event")
        assert_in("scan_complete", events, "Missing scan_complete event")

    finally:
        logger._stdout = old_stdout if "old_stdout" in dir() else sys.stdout
        logger._stderr = old_stderr if "old_stderr" in dir() else sys.stderr
        tmp.unlink(missing_ok=True)


# ═══════════════════════════════════════════════════════════════════════════
#  CI mode + quiet mode wiring tests
# ═══════════════════════════════════════════════════════════════════════════


@test("Logger: CI mode uses [ERROR] prefix instead of emoji")
def test_ci_mode_no_emojis():
    from reachable.core.logger import OutputMode

    logger = _make_fresh_logger()
    with tempfile.NamedTemporaryFile(mode="w", suffix=".log", delete=False) as f:
        tmp = Path(f.name)
    try:
        logger.configure(mode=OutputMode.CI, log_file=tmp)
        old_stderr = logger._stderr
        capture = io.StringIO()
        logger._stderr = capture
        logger.error("test error")
        logger._stderr = old_stderr
        output = capture.getvalue()
        assert_in("[ERROR]", output, "CI mode should use [ERROR] prefix")
    finally:
        logger._stderr = old_stderr if "old_stderr" in dir() else sys.stderr
        tmp.unlink(missing_ok=True)


@test("Logger: quiet+CI mode writes to log but not console")
def test_quiet_ci_mode():
    from reachable.core.logger import OutputMode

    logger = _make_fresh_logger()
    with tempfile.NamedTemporaryFile(mode="w", suffix=".log", delete=False) as f:
        tmp = Path(f.name)
    try:
        logger.configure(mode=OutputMode.CI, quiet=True, log_file=tmp)
        old_stdout = logger._stdout
        capture = io.StringIO()
        logger._stdout = capture
        logger.info("should not appear on console")
        logger._stdout = old_stdout
        console_output = capture.getvalue()
        logger.close()
        log_content = tmp.read_text()
        assert_eq(console_output, "", "Quiet mode should suppress console INFO")
        assert_in("should not appear on console", log_content, "Quiet mode should still write to log file")
        assert_in("[INFO]", log_content, "Log file should have level tag")
    finally:
        logger._stdout = old_stdout if "old_stdout" in dir() else sys.stdout
        tmp.unlink(missing_ok=True)


@test("Logger: HUMAN mode uses emoji prefixes (not CI)")
def test_human_mode_has_emojis():
    from reachable.core.logger import OutputMode

    logger = _make_fresh_logger()
    with tempfile.NamedTemporaryFile(mode="w", suffix=".log", delete=False) as f:
        tmp = Path(f.name)
    try:
        logger.configure(mode=OutputMode.HUMAN, log_file=tmp)
        old_stderr = logger._stderr
        capture = io.StringIO()
        logger._stderr = capture
        logger.error("test error")
        logger._stderr = old_stderr
        output = capture.getvalue()
        # HUMAN mode should NOT have [ERROR] prefix (uses emoji instead)
        assert_not_in("[ERROR]", output, "HUMAN mode should use emoji, not [ERROR] text prefix")
    finally:
        logger._stderr = old_stderr if "old_stderr" in dir() else sys.stderr
        tmp.unlink(missing_ok=True)


# ═══════════════════════════════════════════════════════════════════════════
#  JSONL mode tests — structured output for log aggregators
# ═══════════════════════════════════════════════════════════════════════════


@test("JSONL: _write_event produces valid single-encoded JSONL")
def test_jsonl_write_event_single_encoding():
    from reachable.core.logger import OutputMode

    logger = _make_fresh_logger()
    with tempfile.NamedTemporaryFile(mode="w", suffix=".log", delete=False) as f:
        tmp = Path(f.name)
    try:
        logger.configure(mode=OutputMode.JSON, log_file=tmp)
        old_stdout = logger._stdout
        capture = io.StringIO()
        logger._stdout = capture
        logger._write_event({"event": "phase_start", "phase": 1, "name": "SBOM"}, level="INFO")
        logger._stdout = old_stdout
        line = capture.getvalue().strip()
        parsed = json.loads(line)
        # Key test: event fields are top-level dict keys, NOT a nested string
        assert_eq(parsed["event"], "phase_start", "event should be a top-level key")
        assert_eq(parsed["phase"], 1, "phase should be a top-level int, not nested in msg")
        assert_eq(parsed["name"], "SBOM", "name should be a top-level string")
        assert_eq(parsed["level"], "INFO", "level should be in envelope")
        assert_true("ts" in parsed, "timestamp should be present by default")
    finally:
        logger._stdout = old_stdout if "old_stdout" in dir() else sys.stdout
        tmp.unlink(missing_ok=True)


@test("JSONL: _write_event with timestamps=False omits ts field")
def test_jsonl_write_event_no_timestamps():
    from reachable.core.logger import OutputMode

    logger = _make_fresh_logger()
    with tempfile.NamedTemporaryFile(mode="w", suffix=".log", delete=False) as f:
        tmp = Path(f.name)
    try:
        logger.configure(mode=OutputMode.JSON, log_file=tmp, timestamps=False)
        old_stdout = logger._stdout
        capture = io.StringIO()
        logger._stdout = capture
        logger._write_event({"event": "test"}, level="INFO")
        logger._stdout = old_stdout
        parsed = json.loads(capture.getvalue().strip())
        assert_true("ts" not in parsed, "ts should be omitted when timestamps=False")
        assert_eq(parsed["event"], "test", "event field should still be present")
    finally:
        logger._stdout = old_stdout if "old_stdout" in dir() else sys.stdout
        tmp.unlink(missing_ok=True)


@test("JSONL: _write() in JSON mode produces valid JSONL with msg field")
def test_jsonl_write_plain_message():
    from reachable.core.logger import OutputMode

    logger = _make_fresh_logger()
    with tempfile.NamedTemporaryFile(mode="w", suffix=".log", delete=False) as f:
        tmp = Path(f.name)
    try:
        logger.configure(mode=OutputMode.JSON, log_file=tmp)
        old_stdout = logger._stdout
        capture = io.StringIO()
        logger._stdout = capture
        logger.info("plain text message")
        logger._stdout = old_stdout
        parsed = json.loads(capture.getvalue().strip())
        assert_eq(parsed["msg"], "plain text message", "msg should be a plain string")
        assert_eq(parsed["level"], "INFO", "level should be INFO")
    finally:
        logger._stdout = old_stdout if "old_stdout" in dir() else sys.stdout
        tmp.unlink(missing_ok=True)


@test("JSONL: _write_stderr in JSON mode produces valid JSONL")
def test_jsonl_write_stderr():
    from reachable.core.logger import OutputMode

    logger = _make_fresh_logger()
    with tempfile.NamedTemporaryFile(mode="w", suffix=".log", delete=False) as f:
        tmp = Path(f.name)
    try:
        logger.configure(mode=OutputMode.JSON, log_file=tmp)
        old_stderr = logger._stderr
        capture = io.StringIO()
        logger._stderr = capture
        logger.error("something broke")
        logger._stderr = old_stderr
        parsed = json.loads(capture.getvalue().strip())
        assert_in("something broke", parsed["msg"], "msg should contain error text")
        assert_eq(parsed["level"], "ERROR", "level should be ERROR")
    finally:
        logger._stderr = old_stderr if "old_stderr" in dir() else sys.stderr
        tmp.unlink(missing_ok=True)


@test("JSONL: quiet mode does NOT suppress structured events via _write_event")
def test_jsonl_quiet_does_not_kill_events():
    from reachable.core.logger import OutputMode

    logger = _make_fresh_logger()
    with tempfile.NamedTemporaryFile(mode="w", suffix=".log", delete=False) as f:
        tmp = Path(f.name)
    try:
        logger.configure(mode=OutputMode.JSON, quiet=True, log_file=tmp)
        old_stdout = logger._stdout
        capture = io.StringIO()
        logger._stdout = capture
        # Structured event via _write_event — should NOT be suppressed
        logger._write_event({"event": "phase_start", "phase": 1, "name": "Test"}, level="INFO")
        logger._stdout = old_stdout
        output = capture.getvalue()
        assert_true(len(output.strip()) > 0, "Structured event should NOT be suppressed by quiet")
        parsed = json.loads(output.strip())
        assert_eq(parsed["event"], "phase_start", "Event should be intact")
    finally:
        logger._stdout = old_stdout if "old_stdout" in dir() else sys.stdout
        tmp.unlink(missing_ok=True)


@test("JSONL: quiet+JSON plain messages still emit (JSON bypasses quiet)")
def test_jsonl_quiet_plain_messages():
    from reachable.core.logger import OutputMode

    logger = _make_fresh_logger()
    with tempfile.NamedTemporaryFile(mode="w", suffix=".log", delete=False) as f:
        tmp = Path(f.name)
    try:
        logger.configure(mode=OutputMode.JSON, quiet=True, log_file=tmp)
        old_stdout = logger._stdout
        capture = io.StringIO()
        logger._stdout = capture
        logger.info("json message in quiet mode")
        logger._stdout = old_stdout
        output = capture.getvalue()
        # In JSON mode, even quiet=True should not suppress — consumer filters by level
        assert_true(len(output.strip()) > 0, "JSON mode should bypass quiet for all messages")
    finally:
        logger._stdout = old_stdout if "old_stdout" in dir() else sys.stdout
        tmp.unlink(missing_ok=True)


@test("JSONL: phase lifecycle produces correct event sequence")
def test_jsonl_phase_lifecycle():
    from reachable.core.logger import OutputMode

    logger = _make_fresh_logger()
    with tempfile.NamedTemporaryFile(mode="w", suffix=".log", delete=False) as f:
        tmp = Path(f.name)
    try:
        logger.configure(mode=OutputMode.JSON, log_file=tmp)
        old_stdout = logger._stdout
        capture = io.StringIO()
        logger._stdout = capture
        logger.phase_start(1, "SBOM Generation", "syft", total_phases=5)
        import time as _time

        _time.sleep(0.01)
        logger.phase_end(1, "247 packages")
        logger._stdout = old_stdout
        lines = [l for l in capture.getvalue().strip().split("\n") if l.strip()]
        assert_eq(len(lines), 2, f"Expected 2 JSONL lines, got {len(lines)}")
        start = json.loads(lines[0])
        end = json.loads(lines[1])
        assert_eq(start["event"], "phase_start")
        assert_eq(start["phase"], 1)
        assert_eq(start["name"], "SBOM Generation")
        assert_eq(start["scanner"], "syft")
        assert_eq(end["event"], "phase_end")
        assert_eq(end["phase"], 1)
        assert_true(end["elapsed_sec"] >= 0, "elapsed_sec should be non-negative")
        assert_eq(end["result"], "247 packages")
    finally:
        logger._stdout = old_stdout if "old_stdout" in dir() else sys.stdout
        tmp.unlink(missing_ok=True)


@test("JSONL: no double-encoding — event fields are not strings")
def test_jsonl_no_double_encoding():
    """Regression test: ensure event dicts aren't string-escaped inside msg."""
    from reachable.core.logger import OutputMode

    logger = _make_fresh_logger()
    with tempfile.NamedTemporaryFile(mode="w", suffix=".log", delete=False) as f:
        tmp = Path(f.name)
    try:
        logger.configure(mode=OutputMode.JSON, log_file=tmp)
        old_stdout = logger._stdout
        capture = io.StringIO()
        logger._stdout = capture
        logger._write_event(
            {"event": "scan_complete", "risk_score": 450, "risk_level": "moderate"},
            level="INFO",
        )
        logger._stdout = old_stdout
        parsed = json.loads(capture.getvalue().strip())
        # If double-encoded, risk_score would be a string or nested in "msg"
        assert_true(
            isinstance(parsed.get("risk_score"), int), f"risk_score should be int, got {type(parsed.get('risk_score'))}"
        )
        assert_true("msg" not in parsed, "Structured events should NOT have a 'msg' wrapper field")
        assert_eq(parsed["event"], "scan_complete")
    finally:
        logger._stdout = old_stdout if "old_stdout" in dir() else sys.stdout
        tmp.unlink(missing_ok=True)


@test("JSONL: _write_event also writes to log file")
def test_jsonl_write_event_logs_to_file():
    from reachable.core.logger import OutputMode

    logger = _make_fresh_logger()
    with tempfile.NamedTemporaryFile(mode="w", suffix=".log", delete=False) as f:
        tmp = Path(f.name)
    try:
        logger.configure(mode=OutputMode.JSON, log_file=tmp)
        old_stdout = logger._stdout
        logger._stdout = io.StringIO()  # discard stdout
        logger._write_event({"event": "test_event", "data": 42}, level="INFO")
        logger._stdout = old_stdout
        logger.close()
        log_content = tmp.read_text()
        parsed = json.loads(log_content.strip())
        assert_eq(parsed["event"], "test_event", "Log file should contain JSON event")
        assert_eq(parsed["data"], 42, "Log file should have correct data")
    finally:
        logger._stdout = old_stdout if "old_stdout" in dir() else sys.stdout
        tmp.unlink(missing_ok=True)


@test("JSONL: _write() timestamps respected in JSON mode")
def test_jsonl_write_timestamps():
    from reachable.core.logger import OutputMode

    logger = _make_fresh_logger()
    with tempfile.NamedTemporaryFile(mode="w", suffix=".log", delete=False) as f:
        tmp = Path(f.name)
    try:
        # With timestamps
        logger.configure(mode=OutputMode.JSON, log_file=tmp, timestamps=True)
        old_stdout = logger._stdout
        capture = io.StringIO()
        logger._stdout = capture
        logger.info("with ts")
        logger._stdout = old_stdout
        parsed = json.loads(capture.getvalue().strip())
        assert_true("ts" in parsed, "ts should be present when timestamps=True")

        # Without timestamps
        logger = _make_fresh_logger()
        logger.configure(mode=OutputMode.JSON, log_file=tmp, timestamps=False)
        capture2 = io.StringIO()
        logger._stdout = capture2
        logger.info("without ts")
        logger._stdout = old_stdout
        parsed2 = json.loads(capture2.getvalue().strip())
        assert_true("ts" not in parsed2, "ts should be absent when timestamps=False")
    finally:
        logger._stdout = old_stdout if "old_stdout" in dir() else sys.stdout
        tmp.unlink(missing_ok=True)


# ═══════════════════════════════════════════════════════════════════════════
#  CLI flag tests — --log-format
# ═══════════════════════════════════════════════════════════════════════════


@test("CLI: --log-format flag defined on scan parser")
def test_cli_log_format_flag():
    main_path = Path(_project_root) / "reachable" / "cli" / "main.py"
    content = main_path.read_text()
    assert_in("--log-format", content, "--log-format flag missing from main.py")
    assert_in('"jsonl"', content, "jsonl choice missing from --log-format")
    assert_in('"text"', content, "text choice missing from --log-format")


@test("CLI: --log-format jsonl precedence over --ci in scan.py")
def test_cli_log_format_precedence():
    scan_path = Path(_project_root) / "reachable" / "cli" / "scan.py"
    content = scan_path.read_text()
    # Verify precedence logic exists
    assert_in('log_format == "jsonl"', content, "jsonl precedence check missing")
    # jsonl should be checked BEFORE ci_mode
    jsonl_pos = content.index('log_format == "jsonl"')
    ci_pos = content.index("elif ci_mode:", jsonl_pos - 200)
    assert_true(jsonl_pos < ci_pos, "--log-format jsonl should be checked before --ci")


@test("CLI: all 23 subcommands registered in reachctl")
def test_all_subcommands_registered():
    """Verify every expected subcommand is registered via add_parser() in main.py."""
    import re as _re

    main_path = Path(_project_root) / "reachable" / "cli" / "main.py"
    content = main_path.read_text()

    # Remove commented lines
    active = "\n".join(l for l in content.split("\n") if not l.strip().startswith("#"))

    # Extract all add_parser("name") calls
    registered = set(_re.findall(r'add_parser\(\s*["\'](\w+)["\']', active))

    # Also check for setup_*_parser(subparsers) patterns that register indirectly
    # These are: manifest, pipeline, registries, aliases, export, enzo
    indirect_setups = {
        "manifest": "setup_manifest_parser",
        "pipeline": "setup_pipeline_parser",
        "registries": "add_registries_parser",
        "aliases": "add_aliases_parser",
        "export": "register_export_command",
        "enzo": "register_enzo_subcommand",
    }
    for cmd, func in indirect_setups.items():
        if func in active:
            registered.add(cmd)

    expected_commands = [
        "scan",
        "dashboard",
        "selftest",
        "doctor",
        "cache",
        "db",
        "primer",
        "sandbox",
        "vulndb",
        "manifest",
        "pipeline",
        "system",
        "config",
        "cleanup",
        "version",
        "top10size",
        "license",
        "admin",
        "audit",
        "registries",
        "aliases",
        "export",
        "enzo",
    ]
    missing = [cmd for cmd in expected_commands if cmd not in registered]
    assert_eq(len(missing), 0, f"Missing subcommands in main.py: {missing} (found: {sorted(registered)})")


@test("CLI: scan parser defines all expected flags")
def test_scan_parser_flags():
    """Verify scan subcommand source contains all expected flag definitions."""
    main_path = Path(_project_root) / "reachable" / "cli" / "main.py"
    content = main_path.read_text()

    # Find the scan_parser section (between scan_parser = and next top-level parser)
    scan_start = content.find("scan_parser = subparsers.add_parser")
    scan_end = content.find("dashboard_parser = subparsers.add_parser")
    scan_section = content[scan_start:scan_end] if scan_start > 0 and scan_end > 0 else content

    expected_flags = [
        "--debug",
        "--quiet",
        "--ci",
        "--no-timestamp",
        "--log-format",
        "--sarif",
        "--fail-on",
        "--output",
        "--force-rebuild",
        "--no-dashboard",
    ]
    missing = [f for f in expected_flags if f not in scan_section]
    assert_eq(len(missing), 0, f"Missing flags in scan parser: {missing}")


@test("CLI: scan flag dests match scan.py reads")
def test_scan_flag_dests():
    """Verify argparse dest names match what scan.py reads via getattr(args, ...)."""
    main_path = Path(_project_root) / "reachable" / "cli" / "main.py"
    scan_path = Path(_project_root) / "reachable" / "cli" / "scan.py"
    main_src = main_path.read_text()
    scan_src = scan_path.read_text()

    # Flag dests defined in main.py, read in scan.py
    required_dests = {
        "log_format": "--log-format",
        "no_timestamps": "--no-timestamps",
        "quiet": "--quiet",
        "ci": "--ci",
        "debug": "--debug",
    }
    for dest, flag in required_dests.items():
        # Must exist in main.py (as dest= or as the flag itself)
        assert_in(flag, main_src, f"{flag} not in main.py")
        # Must be read in scan.py
        assert_in(f'"{dest}"', scan_src, f'scan.py never reads dest="{dest}" for {flag}')

    # Verify --log-format choices
    assert_in('"text"', main_src, "text choice missing")
    assert_in('"jsonl"', main_src, "jsonl choice missing")


# ═══════════════════════════════════════════════════════════════════════════
#  lib_manager ANSI tty-guard tests
# ═══════════════════════════════════════════════════════════════════════════


@test("lib_manager: unfixable status uses _tty guard (no hardcoded ANSI)")
def test_lib_manager_no_hardcoded_ansi():
    """Verify no raw \\033 outside of _tty-guarded blocks in lib_manager."""
    lib_path = Path(_project_root) / "reachable" / "integrations" / "lib_manager.py"
    content = lib_path.read_text()

    # Find all \033 occurrences — each should be on a line that contains _tty
    # or is in a block guarded by `if _tty`
    raw_ansi_lines = []
    for i, line in enumerate(content.split("\n"), 1):
        if "\\033[" in line or "\033[" in repr(line):
            # Check if it's tty-guarded (same line or nearby)
            if "_tty" not in line and "if _tty" not in line:
                raw_ansi_lines.append((i, line.strip()))

    # Allow the _tty assignment lines themselves
    unguarded = [
        (n, l) for n, l in raw_ansi_lines if "if _tty" not in l and "_tty =" not in l and 'if _tty else ""' not in l
    ]

    assert_eq(len(unguarded), 0, f"Found {len(unguarded)} unguarded ANSI lines: {unguarded[:3]}")


# ═══════════════════════════════════════════════════════════════════════════
#  Enzo CLI integration tests
# ═══════════════════════════════════════════════════════════════════════════


@test("Enzo: register_enzo_subcommand adds 'enzo' parser")
def test_enzo_register():
    from enzo.cli import register_enzo_subcommand

    parser = argparse.ArgumentParser()
    subs = parser.add_subparsers(dest="command")
    register_enzo_subcommand(subs)

    # Parse 'enzo' — should not fail
    args = parser.parse_args(["enzo"])
    assert_eq(args.command, "enzo", "enzo command not recognized")


@test("Enzo: enzo subcommands parse correctly")
def test_enzo_subcommands():
    from enzo.cli import register_enzo_subcommand

    parser = argparse.ArgumentParser()
    subs = parser.add_subparsers(dest="command")
    register_enzo_subcommand(subs)

    # enzo scan /tmp/repo
    args = parser.parse_args(["enzo", "scan", "/tmp/repo"])
    assert_eq(args.command, "enzo")
    assert_eq(args.enzo_command, "scan")
    assert_eq(args.repo, "/tmp/repo")
    assert_true(hasattr(args, "func"), "func not bound for enzo scan")

    # enzo run /tmp/repo --dry-run
    args = parser.parse_args(["enzo", "run", "/tmp/repo", "--dry-run"])
    assert_eq(args.enzo_command, "run")
    assert_true(args.dry_run, "dry_run flag not set")

    # enzo status /tmp/repo
    args = parser.parse_args(["enzo", "status", "/tmp/repo"])
    assert_eq(args.enzo_command, "status")

    # enzo knowledge
    args = parser.parse_args(["enzo", "knowledge"])
    assert_eq(args.enzo_command, "knowledge")

    # enzo setup
    args = parser.parse_args(["enzo", "setup"])
    assert_eq(args.enzo_command, "setup")

    # enzo fix /tmp/repo --finding-id abc123
    args = parser.parse_args(["enzo", "fix", "/tmp/repo", "--finding-id", "abc123"])
    assert_eq(args.enzo_command, "fix")
    assert_eq(args.finding_id, "abc123")


@test("Enzo: reachctl main.py registers enzo (import path)")
def test_reachctl_enzo_import_path():
    """Verify the import path in cli/main.py is correct."""
    main_path = Path(_project_root) / "reachable" / "cli" / "main.py"
    content = main_path.read_text()
    assert_in(
        "from enzo.cli import register_enzo_subcommand", content, "enzo registration import missing from cli/main.py"
    )
    assert_in("register_enzo_subcommand(subparsers)", content, "enzo registration call missing from cli/main.py")
    assert_in('args.command == "enzo"', content, "enzo dispatch missing from cli/main.py")


@test("Enzo: reachctl.py includes enzo in data_commands")
def test_reachctl_enzo_data_commands():
    reachctl_path = Path(_project_root) / "reachctl"
    content = reachctl_path.read_text()
    assert_in("'enzo'", content, "enzo missing from data_commands in reachctl.py")
    assert_in("enzo run", content, "enzo run missing from reachctl banner")


@test("Enzo: standalone CLI main() parses correctly")
def test_enzo_standalone_cli():
    """Verify enzo.cli.main is callable and sets up argparse."""
    from enzo.cli import main as enzo_main

    # Just check it's callable — actually calling it would sys.exit
    assert_true(callable(enzo_main), "enzo.cli.main is not callable")


@test("Enzo: _build_subparsers defines all expected commands")
def test_enzo_subparsers_complete():
    from enzo.cli import _build_subparsers

    parser = argparse.ArgumentParser()
    sub = parser.add_subparsers(dest="cmd")
    _build_subparsers(sub)

    expected = {"setup", "scan", "fix", "run", "status", "knowledge"}
    # Parse each to verify they exist
    for cmd in expected:
        if cmd in ("setup", "knowledge"):
            args = parser.parse_args([cmd])
        elif cmd == "fix":
            args = parser.parse_args([cmd, "/tmp/repo", "--finding-id", "x"])
        else:
            args = parser.parse_args([cmd, "/tmp/repo"])
        assert_eq(args.cmd, cmd, f"Subcommand {cmd} not parsed")


# ═══════════════════════════════════════════════════════════════════════════
#  verbose/debug consistency test
# ═══════════════════════════════════════════════════════════════════════════


@test("scan.py: verbose/debug mapping documented")
def test_verbose_debug_documented():
    scan_path = Path(_project_root) / "reachable" / "cli" / "scan.py"
    content = scan_path.read_text()
    assert_in("verbose=debug_mode", content, "verbose=debug_mode aliasing not found in scan.py")
    assert_in("verbose: bool", content, "verbose parameter not found (function signatures)")
    # Check documentation comment exists
    assert_in("Historical naming inconsistency", content, "verbose/debug documentation comment missing")


@test("scan.py: configure() receives quiet, mode, and log-format parameters")
def test_scan_configure_wired():
    scan_path = Path(_project_root) / "reachable" / "cli" / "scan.py"
    content = scan_path.read_text()
    assert_in("quiet=quiet_mode", content, "quiet=quiet_mode not passed to configure()")
    assert_in("mode=output_mode", content, "mode=output_mode not passed to configure()")
    assert_in("from reachable.core.logger import OutputMode", content, "OutputMode not imported in scan.py")
    # Precedence: --log-format jsonl > --ci > HUMAN
    assert_in("OutputMode.JSON", content, "OutputMode.JSON not referenced for jsonl format")
    assert_in("OutputMode.CI", content, "OutputMode.CI not referenced for ci mode")
    assert_in('log_format == "jsonl"', content, "--log-format jsonl precedence logic missing")


@test("Output: every flag combo produces console output > 5 lines")
def test_output_all_combos():
    """Simulate scan lifecycle with every flag combo and verify output."""
    import time as _time

    from reachable.core.logger import OutputMode

    def _run(mode, quiet, timestamps, debug):
        logger = _make_fresh_logger()
        with tempfile.NamedTemporaryFile(mode="w", suffix=".log", delete=False) as f:
            tmp = Path(f.name)
        try:
            logger.configure(mode=mode, quiet=quiet, timestamps=timestamps, debug=debug, log_file=tmp)
            old_out = logger._stdout
            old_err = logger._stderr
            out_cap = io.StringIO()
            err_cap = io.StringIO()
            logger._stdout = out_cap
            logger._stderr = err_cap

            logger.scan_start("test-app", Path("/tmp/repo"), "1.0.0")
            logger.phase_start(1, "SBOM", "Syft", total_phases=3)
            logger.info("Processing...")
            _time.sleep(0.01)
            logger.phase_end(1, "done")
            logger.phase_start(2, "Scan", "Grype", total_phases=3)
            logger.warning("DB outdated")
            _time.sleep(0.01)
            logger.phase_end(2, "5 CVEs")
            logger.phase_start(3, "Analysis", total_phases=3)
            _time.sleep(0.01)
            logger.phase_end(3, "complete")
            logger.set_counts(
                cves_total=10,
                cves_reachable=3,
                cves_unknown=2,
                secrets_total=2,
                secrets_reachable=1,
                secrets_unknown=0,
                cwe_total=5,
                cwe_reachable=1,
                cwe_unknown=1,
                malware_count=0,
                malware_reachable=0,
            )
            logger.print_timing_summary()
            logger.print_results_summary()
            logger.scan_complete(450, "MEDIUM", Path("/tmp/output"))

            logger._stdout = old_out
            logger._stderr = old_err
            console = out_cap.getvalue() + err_cap.getvalue()
            logfile = tmp.read_text()
            logger.close()
            return (
                len([l for l in console.split("\n") if l.strip()]),
                len([l for l in logfile.split("\n") if l.strip()]),
                "SCAN COMPLETE" in console
                or "scan_complete" in console
                or "Risk Score" in console
                or "risk_score" in console,
            )
        finally:
            tmp.unlink(missing_ok=True)

    combos = [
        (OutputMode.HUMAN, False, True, False, "default"),
        (OutputMode.HUMAN, False, True, True, "--debug"),
        (OutputMode.HUMAN, True, True, False, "--quiet"),
        (OutputMode.CI, True, True, False, "--ci"),
        (OutputMode.HUMAN, False, False, False, "--no-timestamps"),
        (OutputMode.CI, True, False, False, "--ci --no-timestamps"),
        (OutputMode.HUMAN, True, False, False, "--quiet --no-timestamps"),
        (OutputMode.JSON, False, True, False, "--log-format jsonl"),
        (OutputMode.JSON, True, True, False, "--ci --log-format jsonl"),
        (OutputMode.HUMAN, True, True, True, "--debug --quiet"),
    ]

    failures = []
    for mode, quiet, ts, debug, label in combos:
        con, log, has_results = _run(mode, quiet, ts, debug)
        if con < 5:
            failures.append(f"{label}: only {con} console lines")
        if log < 5:
            failures.append(f"{label}: only {log} log lines")
        if not has_results:
            failures.append(f"{label}: missing results/risk output")

    assert_eq(len(failures), 0, f"Output validation failures: {'; '.join(failures)}")


@test("Output: quiet mode suppresses progress but shows results")
def test_quiet_suppresses_progress_shows_results():
    """Quiet should hide phases/info but show timing, results, risk."""
    import time as _time

    from reachable.core.logger import OutputMode

    logger = _make_fresh_logger()
    with tempfile.NamedTemporaryFile(mode="w", suffix=".log", delete=False) as f:
        tmp = Path(f.name)
    try:
        logger.configure(mode=OutputMode.HUMAN, quiet=True, log_file=tmp)
        old_out = logger._stdout
        out_cap = io.StringIO()
        logger._stdout = out_cap

        logger.scan_start("app", Path("/tmp/r"), "1.0.0")
        logger.phase_start(1, "SBOM", total_phases=1)
        logger.info("progress info that should be suppressed")
        _time.sleep(0.01)
        logger.phase_end(1, "done")
        logger.set_counts(
            cves_total=5,
            cves_reachable=2,
            cves_unknown=1,
            secrets_total=0,
            secrets_reachable=0,
            secrets_unknown=0,
            cwe_total=0,
            cwe_reachable=0,
            cwe_unknown=0,
            malware_count=0,
            malware_reachable=0,
        )
        logger.print_timing_summary()
        logger.print_results_summary()
        logger.scan_complete(300, "LOW", Path("/tmp/out"))

        logger._stdout = old_out
        console = out_cap.getvalue()

        # Progress should be suppressed
        assert_not_in("progress info that should be suppressed", console, "Quiet mode should suppress info messages")
        assert_not_in("╭", console, "Quiet mode should suppress banner")

        # Results should be present
        assert_in("TIMING", console, "Quiet mode should show timing")
        assert_in("Risk Score", console, "Quiet mode should show risk score")
        assert_in("SCAN COMPLETE", console, "Quiet mode should show results")
    finally:
        tmp.unlink(missing_ok=True)


# ═══════════════════════════════════════════════════════════════════════════
#  Main
# ═══════════════════════════════════════════════════════════════════════════


def main():
    print()
    print("LOGGER FIXES + ENZO INTEGRATION TEST SUITE")
    print("=" * 70)

    tests = [v for v in globals().values() if callable(v) and hasattr(v, "_test_name")]

    # Group by prefix
    sections = {}
    for t in tests:
        name = t._test_name
        section = name.split(":")[0] if ":" in name else "Other"
        sections.setdefault(section, []).append(t)

    for section, funcs in sorted(sections.items()):
        print(f"\n── {section} ──")
        for func in funcs:
            run_test(func)

    print(f"\n{'=' * 70}")
    print(f"Results:  {_PASS} passed, {_FAIL} failed, {_SKIP} skipped")
    if _ERRORS:
        print("\nFailures:")
        for e in _ERRORS:
            print(e)
    print(f"{'=' * 70}")

    return 0 if _FAIL == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
