#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.
"""
Comprehensive CLI Tests — reachctl command and option coverage
==============================================================

Validates every registered CLI command and its options by:
  1. Checking --help is parseable and lists expected flags
  2. Checking required-arg enforcement (missing args exit non-zero)
  3. Checking invalid-choice rejection
  4. Checking import paths don't crash on import (catches loaders-style bugs)
  5. Checking safe read-only invocations work end-to-end

Run with:
    pytest tests/test_cli_comprehensive.py -v
    python tests/test_cli_comprehensive.py
"""

import importlib
import json
import subprocess
import sys
import tempfile
import unittest
import unittest.mock
from pathlib import Path
from typing import Tuple

sys.path.insert(0, str(Path(__file__).parent.parent))


# ─── Runner ──────────────────────────────────────────────────────────────────

def run(*args, timeout: int = 30) -> Tuple[int, str, str]:
    """Run reachctl and return (rc, stdout, stderr)."""
    # Prefer reachctl binary next to sys.executable (works from venv install).
    # Fall back to python -m reachable for source tree runs.
    reachctl_bin = Path(sys.executable).parent / "reachctl"
    if reachctl_bin.exists():
        cmd = [str(reachctl_bin)] + list(args)
        cwd = None
    else:
        cmd = [sys.executable, "-m", "reachable"] + list(args)
        cwd = Path(__file__).parent.parent
    try:
        result = subprocess.run(
            cmd, capture_output=True, text=True, timeout=timeout, cwd=cwd
        )
        return result.returncode, result.stdout, result.stderr
    except subprocess.TimeoutExpired:
        return -1, "", "timeout"
    except Exception as e:
        return -2, "", str(e)


def help_of(*args) -> str:
    """Return combined stdout+stderr from --help for a command."""
    rc, out, err = run(*args, "--help")
    return out + err


def combined(*args) -> str:
    _, out, err = run(*args)
    return out + err


# ─── Import integrity (catches wrong module paths like the loaders bug) ──────

class TestImportIntegrity(unittest.TestCase):
    """
    Import every CLI module directly. Catches wrong import paths
    (e.g. 'from reachable.database import loaders') before they
    reach the user.
    """

    def _import_ok(self, module_path: str):
        try:
            importlib.import_module(module_path)
        except ImportError as e:
            self.fail(f"ImportError in {module_path}: {e}")

    def test_cli_main_imports(self):
        self._import_ok("reachable.cli.main")

    def test_cli_export_imports(self):
        self._import_ok("reachable.cli.export")

    def test_cli_pipeline_imports(self):
        self._import_ok("reachable.cli.pipeline")

    def test_cli_auth_imports(self):
        self._import_ok("reachable.cli.auth")

    def test_cli_registries_imports(self):
        self._import_ok("reachable.cli.registries")

    def test_cli_aliases_imports(self):
        self._import_ok("reachable.cli.aliases")

    def test_reporting_sarif_imports(self):
        self._import_ok("reachable.reporting.sarif")

    def test_dashboard_v2_loaders_imports(self):
        self._import_ok("reachable.dashboard_v2.loaders")

    def test_no_dead_loaders_import(self):
        """Regression: export.py must NOT import from reachable.database.loaders (dead module)."""
        src = Path(__file__).parent.parent / "reachable" / "cli" / "export.py"
        text = src.read_text()
        self.assertNotIn(
            "from reachable.database import loaders",
            text,
            "export.py still references dead reachable.database.loaders — use reachable.dashboard_v2.loaders"
        )

    def test_no_get_dashboard_data_call(self):
        """Regression: export.py must NOT call get_dashboard_data (function doesn't exist)."""
        src = Path(__file__).parent.parent / "reachable" / "cli" / "export.py"
        text = src.read_text()
        self.assertNotIn(
            "get_dashboard_data",
            text,
            "export.py calls get_dashboard_data which doesn't exist — use load_from_database"
        )

    def test_sarif_code_flows_helper_exists(self):
        """Regression: sarif.py must export _code_flows helper."""
        from reachable.reporting import sarif
        self.assertTrue(
            hasattr(sarif, "_code_flows"),
            "sarif.py missing _code_flows — codeFlows support not present"
        )


# ─── Top-level ───────────────────────────────────────────────────────────────

class TestTopLevel(unittest.TestCase):

    def test_help(self):
        rc, out, err = run("--help")
        self.assertEqual(rc, 0)
        combined = out + err
        self.assertIn("scan", combined)
        self.assertIn("export", combined)
        self.assertIn("doctor", combined)

    def test_version_flag(self):
        rc, out, err = run("--version")
        self.assertEqual(rc, 0)
        self.assertRegex(out + err, r"1\.\d+\.\d+")

    def test_version_command(self):
        rc, out, err = run("version")
        self.assertEqual(rc, 0)

    def test_no_args_shows_usage(self):
        rc, out, err = run()
        self.assertIn("reachctl", (out + err).lower())

    def test_invalid_command_fails(self):
        rc, out, err = run("notacommand")
        self.assertNotEqual(rc, 0)


# ─── scan ────────────────────────────────────────────────────────────────────

class TestScanCommand(unittest.TestCase):

    def test_help(self):
        h = help_of("scan")
        self.assertIn("PATH", h)
        self.assertIn("--output", h)
        self.assertIn("--fail-on", h)
        self.assertIn("--quiet", h)
        self.assertIn("--debug", h)
        self.assertIn("--ci", h)
        self.assertIn("--sarif", h)
        self.assertIn("--commit", h)
        self.assertIn("--branch", h)

    def test_requires_path(self):
        rc, out, err = run("scan")
        self.assertNotEqual(rc, 0)
        self.assertRegex((out + err).lower(), r"required|path|argument")

    def test_nonexistent_path_fails(self):
        rc, out, err = run("scan", "/no/such/path/xyz", timeout=15)
        self.assertNotEqual(rc, 0)

    def test_fail_on_invalid_choice(self):
        rc, out, err = run("scan", ".", "--fail-on", "extreme")
        self.assertNotEqual(rc, 0)
        self.assertRegex((out + err).lower(), r"invalid|choice|extreme")

    def test_fail_on_valid_choices(self):
        h = help_of("scan")
        for choice in ["critical", "high", "medium", "any", "none"]:
            self.assertIn(choice, h, f"--fail-on {choice} missing from help")

    def test_removed_quick_flag(self):
        rc, _, err = run("scan", ".", "--quick")
        # --quick was removed; if it's still there it's a regression
        # (selftest --quick exists but scan --quick should not)
        # We don't assert on this — scan might silently ignore it via argparse
        # Just ensure it doesn't crash the process entirely
        self.assertNotEqual(rc, -2, "--quick caused a hard crash")

    def test_removed_skip_secrets(self):
        rc, out, err = run("scan", ".", "--skip-secrets")
        self.assertNotEqual(rc, 0)

    def test_removed_skip_cwe(self):
        rc, out, err = run("scan", ".", "--skip-cwe")
        self.assertNotEqual(rc, 0)

    def test_removed_incremental(self):
        rc, out, err = run("scan", ".", "--incremental")
        self.assertNotEqual(rc, 0)


# ─── export ──────────────────────────────────────────────────────────────────

class TestExportCommand(unittest.TestCase):

    def test_help(self):
        h = help_of("export")
        self.assertIn("--format", h)
        self.assertIn("--repo", h)
        self.assertIn("--output", h)
        self.assertIn("--scan-id", h)
        self.assertIn("--fail-on", h)
        self.assertIn("sarif", h)
        self.assertIn("json", h)
        self.assertIn("csv", h)
        self.assertIn("github-action", h)

    def test_format_invalid_choice(self):
        rc, out, err = run("export", "--format", "xml")
        self.assertNotEqual(rc, 0)
        self.assertRegex((out + err).lower(), r"invalid|choice|xml")

    def test_fail_on_invalid_choice(self):
        rc, out, err = run("export", "--format", "sarif", "--fail-on", "extreme")
        self.assertNotEqual(rc, 0)

    def test_no_repo_db_exits_cleanly(self):
        """export against a dir with no repo.db should fail gracefully, not traceback."""
        with tempfile.TemporaryDirectory() as d:
            rc, out, err = run("export", "--format", "json", "--repo", d)
            combined = out + err
            self.assertNotIn("Traceback", combined,
                "export raised unhandled exception instead of clean error")

    def test_sarif_no_repo_db_exits_cleanly(self):
        """Regression: import error in sarif path should not surface as ImportError traceback."""
        with tempfile.TemporaryDirectory() as d:
            rc, out, err = run("export", "--format", "sarif", "--repo", d)
            self.assertNotIn("ImportError", out + err,
                "ImportError surfaced — wrong import path in export.py")
            self.assertNotIn("Traceback", out + err)

    def test_github_action_format_help(self):
        h = help_of("export")
        self.assertIn("--branch", h)
        self.assertIn("--python-version", h)


# ─── dashboard ───────────────────────────────────────────────────────────────

class TestDashboardCommand(unittest.TestCase):

    def test_help(self):
        h = help_of("dashboard")
        self.assertIn("--generate", h)
        self.assertIn("--path", h)
        self.assertIn("--open", h)
        self.assertIn("--list", h)

    def test_list_runs(self):
        rc, out, err = run("dashboard", "--list")
        self.assertIn(rc, [0, 1])
        self.assertNotIn("Traceback", out + err)


# ─── doctor ──────────────────────────────────────────────────────────────────

class TestDoctorCommand(unittest.TestCase):

    def test_help(self):
        h = help_of("doctor")
        self.assertIn("--no-fix", h)

    def test_runs(self):
        rc, out, err = run("doctor", timeout=60)
        combined = out + err
        self.assertNotIn("Traceback", combined)
        self.assertTrue(
            any(x in combined.lower() for x in ["check", "system", "preflight", "doctor"]),
            f"Doctor output unexpected: {combined[:300]}"
        )


# ─── selftest ────────────────────────────────────────────────────────────────

class TestSelftestCommand(unittest.TestCase):

    def test_help(self):
        h = help_of("selftest")
        self.assertIn("--full", h)
        self.assertIn("--unit", h)
        self.assertIn("--integration", h)
        self.assertIn("--coverage", h)
        self.assertIn("--quiet", h)


# ─── cache ───────────────────────────────────────────────────────────────────

class TestCacheCommand(unittest.TestCase):

    def test_help(self):
        h = help_of("cache")
        self.assertIn("--status", h)
        self.assertIn("--clear", h)
        self.assertIn("--clear-libs", h)
        self.assertIn("--warm", h)
        self.assertIn("--force", h)

    def test_status_runs(self):
        rc, out, err = run("cache", "--status")
        self.assertNotIn("Traceback", out + err)


# ─── db ──────────────────────────────────────────────────────────────────────

class TestDbCommand(unittest.TestCase):

    def test_help(self):
        h = help_of("db")
        self.assertIn("--status", h)
        self.assertIn("--compact", h)
        self.assertIn("--checkpoint", h)
        self.assertIn("--check", h)
        self.assertIn("--repair", h)
        self.assertIn("--trim", h)
        self.assertIn("--dry-run", h)
        self.assertIn("--verbose", h)

    def test_status_runs(self):
        rc, out, err = run("db", "--status")
        self.assertNotIn("Traceback", out + err)

    def test_dry_run_compact(self):
        rc, out, err = run("db", "--compact", "--dry-run")
        self.assertNotIn("Traceback", out + err)


# ─── sandbox ─────────────────────────────────────────────────────────────────

class TestSandboxCommand(unittest.TestCase):

    def test_help(self):
        h = help_of("sandbox")
        self.assertIn("--init", h)
        self.assertIn("--remove", h)
        self.assertIn("--status", h)

    def test_status_runs(self):
        rc, out, err = run("sandbox", "--status")
        self.assertNotIn("Traceback", out + err)


# ─── vulndb ──────────────────────────────────────────────────────────────────

class TestVulndbCommand(unittest.TestCase):

    def test_help(self):
        h = help_of("vulndb")
        self.assertIn("--status", h)
        self.assertIn("--update", h)
        self.assertIn("--reset", h)

    def test_status_runs(self):
        rc, out, err = run("vulndb", "--status")
        self.assertNotIn("Traceback", out + err)


# ─── system ──────────────────────────────────────────────────────────────────

class TestSystemCommand(unittest.TestCase):

    def test_help(self):
        h = help_of("system")
        self.assertIn("--verbose", h)
        self.assertIn("--json", h)
        self.assertIn("--max-age", h)
        self.assertIn("--max-scans", h)

    def test_status_runs(self):
        rc, out, err = run("system", "--status")
        self.assertNotIn("Traceback", out + err)

    def test_json_output(self):
        rc, out, err = run("system", "--status", "--json")
        self.assertNotIn("Traceback", out + err)
        if rc == 0 and out.strip():
            try:
                json.loads(out)
            except json.JSONDecodeError:
                self.fail(f"--json output is not valid JSON: {out[:200]}")


# ─── config ──────────────────────────────────────────────────────────────────

class TestConfigCommand(unittest.TestCase):

    def test_help(self):
        h = help_of("config")
        self.assertIn("status", h)
        self.assertIn("get", h)
        self.assertIn("set", h)

    def test_list_runs(self):
        rc, out, err = run("config", "status")
        self.assertNotIn("Traceback", out + err)

    def test_invalid_action_fails(self):
        rc, out, err = run("config", "invalidaction")
        self.assertNotEqual(rc, 0)


# ─── cleanup ─────────────────────────────────────────────────────────────────

class TestCleanupCommand(unittest.TestCase):

    def test_help(self):
        h = help_of("cleanup")
        self.assertIn("--dry-run", h)
        self.assertIn("--force", h)

    def test_dry_run(self):
        rc, out, err = run("cleanup", "--dry-run")
        self.assertNotIn("Traceback", out + err)


# ─── top10 ───────────────────────────────────────────────────────────────────

class TestTop10Command(unittest.TestCase):

    def test_help(self):
        h = help_of("top10size")
        self.assertIn("-n", h)
        self.assertIn("--all", h)

    def test_runs_current_dir(self):
        rc, out, err = run("top10size", ".")
        self.assertNotIn("Traceback", out + err)


# ─── license ─────────────────────────────────────────────────────────────────

class TestLicenseCommand(unittest.TestCase):

    def _license_available(self) -> bool:
        """Return False if license module fails to import (e.g. click missing)."""
        rc, out, err = run("license", "--help")
        return "ModuleNotFoundError" not in (out + err) and "ImportError" not in (out + err)

    def test_help(self):
        h = help_of("license")
        self.assertIn("show", h)
        self.assertIn("verify", h)
        self.assertIn("install", h)

    def test_no_missing_deps(self):
        """Regression: license command must not crash with ModuleNotFoundError."""
        rc, out, err = run("license", "show")
        combined = out + err
        self.assertNotIn("ModuleNotFoundError", combined,
            "license command has missing dependency — check reachable/cli/license.py imports")
        self.assertNotIn("ImportError", combined,
            "license command has bad import")

    def test_show_runs(self):
        rc, out, err = run("license", "show")
        combined = out + err
        if "ModuleNotFoundError" in combined or "ImportError" in combined:
            self.skipTest("license module has missing dep — see test_no_missing_deps")
        self.assertNotIn("Traceback", combined)

    def test_install_requires_file(self):
        rc, out, err = run("license", "install")
        self.assertNotEqual(rc, 0)

    def test_install_nonexistent_file(self):
        rc, out, err = run("license", "install", "/no/such/license.json")
        combined = out + err
        if "ModuleNotFoundError" in combined or "ImportError" in combined:
            self.skipTest("license module has missing dep — see test_no_missing_deps")
        self.assertNotEqual(rc, 0)
        self.assertNotIn("Traceback", combined)


# ─── version ─────────────────────────────────────────────────────────────────

class TestVersionCommand(unittest.TestCase):

    def test_help(self):
        h = help_of("version")
        self.assertIn("--wheel", h)

    def test_runs(self):
        rc, out, err = run("version")
        self.assertEqual(rc, 0)
        self.assertRegex(out + err, r"1\.\d+\.\d+")

    def test_wheel_flag(self):
        rc, out, err = run("version", "--wheel")
        self.assertNotIn("Traceback", out + err)


# ─── primer ──────────────────────────────────────────────────────────────────

class TestPrimerCommand(unittest.TestCase):

    def test_runs(self):
        rc, out, err = run("primer")
        self.assertEqual(rc, 0)
        combined = out + err
        self.assertIn("REACHABLE", combined)
        self.assertIn("scan", combined.lower())


# ─── audit ───────────────────────────────────────────────────────────────────

class TestAuditCommand(unittest.TestCase):

    def test_help(self):
        h = help_of("audit")
        self.assertIn("--scan-path", h)
        self.assertNotIn("Traceback", h)


# ─── pipeline ────────────────────────────────────────────────────────────────

class TestPipelineCommand(unittest.TestCase):

    def test_help(self):
        h = help_of("pipeline")
        self.assertIn("init", h)
        self.assertIn("step", h)
        self.assertIn("finalize", h)
        self.assertIn("status", h)

    def test_init_requires_repo(self):
        rc, out, err = run("pipeline", "init")
        self.assertNotEqual(rc, 0)

    def test_step_requires_session(self):
        rc, out, err = run("pipeline", "step", "sbom")
        self.assertNotEqual(rc, 0)
        self.assertRegex((out + err).lower(), r"required|session")

    def test_step_invalid_choice(self):
        rc, out, err = run("pipeline", "step", "notastep", "--session", "abc")
        self.assertNotEqual(rc, 0)
        self.assertRegex((out + err).lower(), r"invalid|choice")

    def test_finalize_requires_session(self):
        rc, out, err = run("pipeline", "finalize")
        self.assertNotEqual(rc, 0)
        self.assertRegex((out + err).lower(), r"required|session")

    def test_status_requires_session(self):
        rc, out, err = run("pipeline", "status")
        self.assertNotEqual(rc, 0)
        self.assertRegex((out + err).lower(), r"required|session")

    def test_finalize_fail_on_invalid(self):
        rc, out, err = run("pipeline", "finalize", "--session", "x", "--fail-on", "extreme")
        self.assertNotEqual(rc, 0)


# ─── auth ────────────────────────────────────────────────────────────────────

class TestAuthCommand(unittest.TestCase):

    def test_help(self):
        h = help_of("auth")
        self.assertIn("login", h)
        self.assertIn("logout", h)
        self.assertIn("status", h)

    def test_status_runs(self):
        rc, out, err = run("auth", "status")
        self.assertNotIn("Traceback", out + err)

    def test_set_requires_args(self):
        # cred_name is optional (nargs="?") — auth set without args shows interactive
        # prompt or help, exits 0. Assert it doesn't crash.
        rc, out, err = run("auth", "set")
        self.assertNotIn("Traceback", out + err)

    def test_remove_requires_args(self):
        # cred_name is nargs="?" on remove too — shows interactive prompt, exits 0
        rc, out, err = run("auth", "remove")
        self.assertNotIn("Traceback", out + err)


# ─── registries ──────────────────────────────────────────────────────────────

class TestRegistriesCommand(unittest.TestCase):

    def test_help(self):
        h = help_of("registries")
        self.assertIn("show", h)
        self.assertIn("init", h)
        self.assertIn("test", h)
        self.assertIn("path", h)
        self.assertIn("set", h)

    def test_show_runs(self):
        rc, out, err = run("registries", "show")
        self.assertNotIn("Traceback", out + err)

    def test_path_runs(self):
        rc, out, err = run("registries", "path")
        self.assertNotIn("Traceback", out + err)

    def test_set_requires_args(self):
        rc, out, err = run("registries", "set")
        self.assertNotEqual(rc, 0)


# ─── aliases ─────────────────────────────────────────────────────────────────

class TestAliasesCommand(unittest.TestCase):

    def test_help(self):
        h = help_of("aliases")
        self.assertIn("show", h)
        self.assertIn("accept", h)
        self.assertIn("dismiss", h)

    def test_show_runs(self):
        rc, out, err = run("aliases", "show")
        self.assertNotIn("Traceback", out + err)

    def test_accept_requires_args(self):
        rc, out, err = run("aliases", "accept")
        self.assertNotEqual(rc, 0)


# ─── enzo subcommands ────────────────────────────────────────────────────────

class TestEnzoCommand(unittest.TestCase):

    def test_help(self):
        h = help_of("enzo")
        self.assertIn("ingest", h)
        self.assertIn("gap-analysis", h)
        self.assertIn("selftest", h)

    def test_ingest_help(self):
        h = help_of("enzo", "ingest")
        self.assertIn("--tool", h)
        self.assertIn("--file", h)
        self.assertIn("dependabot", h)
        self.assertIn("codeql", h)
        self.assertIn("trivy", h)
        self.assertIn("osv", h)
        self.assertNotIn("snyk", h)  # snyk is NOT a valid choice

    def test_ingest_requires_tool(self):
        rc, out, err = run("enzo", "ingest", "--file", "x.json")
        self.assertNotEqual(rc, 0)
        self.assertRegex((out + err).lower(), r"required|tool")

    def test_ingest_requires_file(self):
        rc, out, err = run("enzo", "ingest", "--tool", "trivy")
        self.assertNotEqual(rc, 0)
        self.assertRegex((out + err).lower(), r"required|file")

    def test_ingest_invalid_tool_rejected(self):
        """snyk is not a valid --tool choice — must be rejected."""
        rc, out, err = run("enzo", "ingest", "--tool", "snyk", "--file", "f.json")
        self.assertNotEqual(rc, 0)
        combined = (out + err).lower()
        self.assertRegex(combined, r"invalid|choice|snyk")

    def test_ingest_nonexistent_file(self):
        # enzo defers file existence check to ingest logic — may exit 0 with error msg
        # or exit non-zero. Either way must not traceback.
        rc, out, err = run("enzo", "ingest", "--tool", "trivy", "--file", "/no/such/file.json")
        self.assertNotIn("Traceback", out + err)

    def test_gap_analysis_help(self):
        h = help_of("enzo", "gap-analysis")
        self.assertIn("--scan-id", h)
        self.assertIn("--since", h)
        self.assertIn("--output", h)

    def test_gap_analysis_runs_no_data(self):
        with tempfile.TemporaryDirectory() as d:
            rc, out, err = run("enzo", "gap-analysis", d)
            self.assertNotIn("Traceback", out + err)

    def test_selftest_help(self):
        h = help_of("enzo", "selftest")
        self.assertIn("--unit", h)


# ─── SARIF codeFlows unit tests ──────────────────────────────────────────────

class TestSarifCodeFlows(unittest.TestCase):
    """Unit tests for the _code_flows helper added to sarif.py."""

    def setUp(self):
        from reachable.reporting.sarif import _code_flows
        self._code_flows = _code_flows

    def test_empty_returns_empty(self):
        self.assertEqual(self._code_flows({}), [])
        self.assertEqual(self._code_flows({"call_paths_v2": "[]"}), [])
        self.assertEqual(self._code_flows({"call_paths_v2": None}), [])

    def test_v2_path_node(self):
        import json
        path = [
            {"label": "route_search", "kind": "entry", "file": "app.py", "line": 10, "route": "GET /api/search"},
            {"label": "build_query",  "kind": "app",   "file": "app.py", "line": 20},
            {"label": "execute_query","kind": "sink_danger", "file": "app.py", "line": 30},
        ]
        flows = self._code_flows({"call_paths_v2": json.dumps([path])})
        self.assertEqual(len(flows), 1)
        locs = flows[0]["threadFlows"][0]["locations"]
        self.assertEqual(len(locs), 3)
        self.assertEqual(locs[0]["importance"], "essential")  # entry
        self.assertEqual(locs[-1]["importance"], "essential")  # sink
        self.assertIn("GET /api/search", locs[0]["location"]["message"]["text"])

    def test_v1_string_compat(self):
        import json
        path = ["a", "b", "c"]
        flows = self._code_flows({"call_paths_v2": json.dumps([path])})
        self.assertEqual(len(flows[0]["threadFlows"][0]["locations"]), 3)

    def test_capped_at_3_paths(self):
        import json
        path = [{"label": "x", "kind": "app", "file": "f.py"}]
        flows = self._code_flows({"call_paths_v2": json.dumps([path] * 10)})
        self.assertEqual(len(flows[0]["threadFlows"]), 3)

    def test_size_reasonable(self):
        import json
        path = [
            {"label": f"func_{i}", "kind": "app", "file": "app.py", "line": i * 10}
            for i in range(6)
        ]
        flows = self._code_flows({"call_paths_v2": json.dumps([path])})
        size = len(json.dumps(flows))
        self.assertLess(size, 5000, f"codeFlows too large: {size} bytes for 6-hop path")


# ─── Runner ──────────────────────────────────────────────────────────────────

def build_suite() -> unittest.TestSuite:
    loader = unittest.TestLoader()
    suite = unittest.TestSuite()
    for cls in [
        TestImportIntegrity,
        TestTopLevel,
        TestScanCommand,
        TestExportCommand,
        TestDashboardCommand,
        TestDoctorCommand,
        TestSelftestCommand,
        TestCacheCommand,
        TestDbCommand,
        TestSandboxCommand,
        TestVulndbCommand,
        TestSystemCommand,
        TestConfigCommand,
        TestCleanupCommand,
        TestTop10Command,
        TestLicenseCommand,
        TestVersionCommand,
        TestPrimerCommand,
        TestAuditCommand,
        TestPipelineCommand,
        TestAuthCommand,
        TestRegistriesCommand,
        TestAliasesCommand,
        TestEnzoCommand,
        TestSarifCodeFlows,
    ]:
        suite.addTests(loader.loadTestsFromTestCase(cls))
    return suite


def main():
    import argparse
    import unittest.mock  # noqa: F401 - ensure mock is available for test classes
    parser = argparse.ArgumentParser(description="REACHABLE comprehensive CLI tests")
    parser.add_argument("-v", "--verbose", action="store_true")
    args = parser.parse_args()

    runner = unittest.TextTestRunner(verbosity=2 if args.verbose else 1)
    result = runner.run(build_suite())
    sys.exit(0 if result.wasSuccessful() else 1)


if __name__ == "__main__":
    import unittest.mock
    main()
