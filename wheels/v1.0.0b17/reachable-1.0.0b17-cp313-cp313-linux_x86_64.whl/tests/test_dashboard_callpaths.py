#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.
"""
T-CG33: Dashboard Call Path / Graph / Dependency Path Accuracy Suite
=====================================================================

Validates the FULL pipeline: DB → data.json → dashboard HTML rendering
for every signal type's call graph / flow visualization.

Coverage:
  Layer 1 — Data Pipeline (DB → data.json)
    - call_paths_v2 structure per signal type
    - PathNode schema: {kind, label|function} minimum required fields
    - Multi-path shape: List[List[PathNode]]
    - Reachability state consistency with call_path presence
    - data.json ↔ DB count consistency

  Layer 2 — JS Rendering Correctness
    - All flows render in LEFT panel (Remediation)
    - Accordion IDs are globally unique (no collision)
    - Fallback flow renders for findings without call_paths_v2
    - Each signal type has correct flow header/icon

  Layer 3 — Integration (run against real scan)
    - End-to-end: scan → DB → data.json → dashboard HTML

Run:
    pytest tests/test_dashboard_callpaths.py -v                    # all
    pytest tests/test_dashboard_callpaths.py -k "Layer1" -v        # data only
    pytest tests/test_dashboard_callpaths.py -k "Layer2" -v        # JS only
    pytest tests/test_dashboard_callpaths.py -k "Layer3" -v        # integration
"""

import json
import re
import sqlite3
import sys
from pathlib import Path

import pytest

# ---------------------------------------------------------------------------
# Helpers & Constants
# ---------------------------------------------------------------------------

SIGNAL_TYPES = ["CVE", "CWE", "SECRET", "DLP", "AI", "MALWARE", "SUSPICIOUS", "CONFIG"]

VALID_NODE_KINDS = {
    "entry",
    "app",
    "transformer",
    "sink_vuln",
    "sink_danger",
    "sink_secret",
    "sink_data",
    "source_pii",
    "guard",
    "stdlib",
    "boundary",
    "via",
    "llm_output",
    "agent",
    "mcp_server",
    "mcp_tool",
}

# Flow header text expected per signal type (in left panel)
FLOW_HEADERS = {
    "CVE": "Transitive Dependency Path",  # for transitive CVEs
    "CWE": "Code Weakness Flow",
    "AI": "AI Attack Flow",
    "SECRET": "Secret Exposure Path",
    "DLP": "Data Flow Path",
}

# ---------------------------------------------------------------------------
# dashboard_html read cap
# ---------------------------------------------------------------------------

# The compiled index.html embeds window.dashboardData inline at the END of the
# file.  For real scans with hundreds of findings + call paths that blob can be
# 10-50 MB.  All JS structure markers (flow headers, accordion IDs, T-CG31
# fallback, etc.) live in the <script> template block near the TOP — well inside
# the first 768 KB.  Reading the full file caused test_no_unscoped_accordion_ids
# to re.findall() across 50 MB which hung for minutes / OOM'd.
_DASHBOARD_HTML_READ_LIMIT = 768 * 1024  # 768 KB


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture(scope="session")
def scan_root():
    """Locate the most recent scan root (directory containing repo.db).

    Single source of truth for the entire session — all other fixtures derive
    from this so scan_db, data_json, and dashboard_html are guaranteed to come
    from the SAME scan.  Sorted by repo.db mtime so it always picks the latest.
    """
    base = Path.home() / ".reachable" / "scans"
    if not base.exists():
        pytest.skip("~/.reachable/scans/ does not exist — run a scan first")
    candidates = list(base.rglob("repo.db"))
    if not candidates:
        pytest.skip("No repo.db found in ~/.reachable/scans/ — run a scan first")
    latest = max(candidates, key=lambda p: p.stat().st_mtime)
    root = latest.parent
    print(f"\n  [scan_root] {root}  (db mtime: {latest.stat().st_mtime:.0f})")
    return root


@pytest.fixture(scope="session")
def scan_db(scan_root):
    """Path to repo.db from the latest scan. Skips if DB is empty or corrupt."""
    path = scan_root / "repo.db"
    try:
        conn = sqlite3.connect(str(path))
        count = conn.execute("SELECT COUNT(*) FROM findings").fetchone()[0]
        conn.close()
        if count == 0:
            pytest.skip(f"repo.db in {scan_root} has 0 findings — run a scan first")
    except sqlite3.OperationalError as e:
        pytest.skip(f"repo.db in {scan_root} is invalid: {e}")
    return path


@pytest.fixture(scope="session")
def latest_scan_id(scan_db):
    """The most recent scan_id in repo.db.

    repo.db accumulates findings across multiple scans but data.json is
    generated from the latest scan only.  Every DB query in the test suite
    MUST filter by this scan_id to avoid double-counting.
    """
    conn = sqlite3.connect(str(scan_db))
    try:
        row = conn.execute("SELECT id FROM scans WHERE status = 'complete' ORDER BY id DESC LIMIT 1").fetchone()
    except sqlite3.OperationalError:
        row = None
    if not row:
        row = conn.execute("SELECT MAX(id) FROM scans").fetchone()
    conn.close()
    if not row or not row[0]:
        pytest.skip("No completed scans found in repo.db")
    return row[0]


@pytest.fixture(scope="session")
def data_json(scan_root):
    """Parsed data.json — searches under scan_root at any depth."""
    candidates = list(scan_root.rglob("dashboard/data.json"))
    if not candidates:
        pytest.skip(f"No dashboard/data.json found under {scan_root}")
    path = max(candidates, key=lambda p: p.stat().st_mtime)
    with open(path) as f:
        return json.load(f)


@pytest.fixture(scope="session")
def dashboard_html(scan_root):
    """First 768 KB of index.html — searches under scan_root at any depth.

    PERFORMANCE FIX (T-CG33-PERF): The compiled dashboard embeds
    window.dashboardData inline at the END of the file (10-50 MB for real
    scans).  All JS structure markers live in the <script> template block
    near the TOP — well inside the 768 KB cap.  Use data_json for finding
    counts.
    """
    candidates = list(scan_root.rglob("dashboard/index.html"))
    if not candidates:
        pytest.skip(f"No dashboard/index.html found under {scan_root}")
    path = max(candidates, key=lambda p: p.stat().st_mtime)
    with open(path, encoding="utf-8", errors="replace") as f:
        return f.read(_DASHBOARD_HTML_READ_LIMIT)


@pytest.fixture(scope="session")
def main_js():
    """main.js from the dashboard split components (source tree, not scan output)."""
    js_path = (
        Path(__file__).parent.parent / "reachable" / "dashboard_v2" / "split" / "components" / "scripts" / "main.js"
    )
    if not js_path.exists():
        pytest.skip("main.js not found")
    return js_path.read_text(encoding="utf-8")


# ---------------------------------------------------------------------------
# Test Fixtures: Synthetic findings for each signal type
# ---------------------------------------------------------------------------


def _make_cve_finding(with_paths=True, transitive=False):
    finding = {
        "type": "CVE",
        "id": "CVE-2024-12345",
        "package": "flask",
        "version": "2.2.0",
        "severity": "HIGH",
        "is_reachable": True,
        "file_path": "requirements.txt",
        "reachability_state": "reachable",
        "is_transitive": transitive,
        "via_package": "some-wrapper" if transitive else None,
        "dependency_chain": ["some-wrapper", "flask"] if transitive else [],
    }
    if with_paths:
        finding["call_paths_v2"] = [
            [
                {"kind": "entry", "label": "Server.HandleLogin()"},
                {"kind": "app", "label": "auth.validate()"},
                {"kind": "sink_vuln", "label": "flask.request.get_json()"},
            ]
        ]
    return finding


def _make_cwe_finding(with_paths=True):
    finding = {
        "type": "CWE",
        "id": "CWE-89",
        "cwe_id": "CWE-89",
        "file_path": "api/routes.go",
        "line": 42,
        "severity": "CRITICAL",
        "is_reachable": True,
        "reachability_state": "reachable",
        "description": "SQL injection via string concatenation",
    }
    if with_paths:
        finding["call_paths_v2"] = [
            [
                {"kind": "entry", "label": "HTTP /api/users"},
                {"kind": "sink_danger", "label": "db.Query(user_input)"},
            ]
        ]
    return finding


def _make_secret_finding(with_paths=True):
    finding = {
        "type": "SECRET",
        "id": "generic_secret",
        "secret_type": "API Key",
        "detector": "trufflehog",
        "file_path": "config/.env",
        "line": 7,
        "severity": "HIGH",
        "is_reachable": True,
        "reachability_state": "reachable",
    }
    if with_paths:
        finding["call_paths_v2"] = [
            [
                {"kind": "app", "label": "config/loader.py:load_env"},
                {"kind": "sink_secret", "label": "os.environ[API_KEY]"},
            ]
        ]
    return finding


def _make_dlp_finding(with_paths=True):
    finding = {
        "type": "DLP",
        "id": "dlp-taint-ssn-to-log",
        "pii_type": "SSN",
        "sink_type": "LOG",
        "file_path": "services/payment.py",
        "line": 88,
        "severity": "CRITICAL",
        "is_reachable": True,
        "reachability_state": "reachable",
        "sink_function": "logger.info()",
    }
    if with_paths:
        finding["call_paths_v2"] = [
            [
                {"kind": "source_pii", "label": "user.ssn"},
                {"kind": "app", "label": "process_payment()"},
                {"kind": "sink_data", "label": "logger.info()"},
            ]
        ]
    return finding


def _make_ai_finding(with_paths=True):
    finding = {
        "type": "AI",
        "id": "owasp-llm01",
        "owasp_llm": "LLM01",
        "llm_category": "LLM01",
        "file_path": "api/chat.py",
        "line": 55,
        "severity": "HIGH",
        "is_reachable": True,
        "reachability_state": "reachable",
    }
    if with_paths:
        finding["call_paths_v2"] = [
            [
                {"kind": "entry", "label": "POST /api/chat"},
                {"kind": "llm_output", "label": "openai.chat.create()"},
                {"kind": "sink_danger", "label": "eval(response)"},
            ]
        ]
    return finding


def _make_malware_finding():
    return {
        "type": "MALWARE",
        "id": "malware-detect-1",
        "package": "evil-pkg",
        "version": "1.0.0",
        "severity": "CRITICAL",
        "is_reachable": True,
        "reachability_state": "reachable",
        "file_path": "node_modules/evil-pkg/index.js",
        "call_paths_v2": [],  # Malware typically no call path
    }


def _make_config_finding():
    return {
        "type": "CONFIG",
        "id": "config-issue-1",
        "rule_id": "docker-no-root",
        "title": "Container runs as root",
        "file_path": "Dockerfile",
        "line": 1,
        "severity": "MEDIUM",
        "reachability_state": "unknown",
        "call_paths_v2": [],  # Config typically no call path
    }


SYNTHETIC_FINDINGS = {
    "CVE": _make_cve_finding,
    "CVE_TRANSITIVE": lambda: _make_cve_finding(transitive=True),
    "CWE": _make_cwe_finding,
    "SECRET": _make_secret_finding,
    "DLP": _make_dlp_finding,
    "AI": _make_ai_finding,
    "MALWARE": _make_malware_finding,
    "CONFIG": _make_config_finding,
}


# ===========================================================================
# LAYER 1: Data Pipeline Tests (DB → data.json)
# ===========================================================================


class TestLayer1_CallPathsV2Schema:
    """Validate call_paths_v2 structure for each signal type."""

    def _validate_path_node(self, node: dict, context: str = ""):
        """Assert a single PathNode has required fields."""
        assert isinstance(node, dict), f"{context}: PathNode must be dict, got {type(node)}"
        assert "kind" in node, f"{context}: PathNode missing 'kind': {node}"
        # Accept 'label' or 'function' — docker-compose scanner uses 'function'
        # as the display field; both are valid for rendering.
        has_label = "label" in node or "function" in node
        assert has_label, f"{context}: PathNode missing 'label' (or 'function'): {node}"
        display = node.get("label") or node.get("function", "")
        assert isinstance(display, str), f"{context}: label/function must be str"
        assert len(display) > 0, f"{context}: label/function must not be empty"
        if node["kind"] not in VALID_NODE_KINDS:
            import warnings

            warnings.warn(f"{context}: Unknown node kind '{node['kind']}'")

    def _validate_call_paths_v2(self, paths: list, finding_id: str = ""):
        """Validate the full call_paths_v2 structure."""
        assert isinstance(paths, list), f"{finding_id}: call_paths_v2 must be list"
        if len(paths) == 0:
            return  # Empty is valid (no paths found)

        first = paths[0]
        if isinstance(first, dict):
            for i, node in enumerate(paths):
                self._validate_path_node(node, f"{finding_id} path[0] node[{i}]")
        elif isinstance(first, list):
            for pidx, path in enumerate(paths):
                assert isinstance(path, list), f"{finding_id}: path[{pidx}] must be list"
                assert len(path) > 0, f"{finding_id}: path[{pidx}] must not be empty"
                for i, node in enumerate(path):
                    self._validate_path_node(node, f"{finding_id} path[{pidx}] node[{i}]")
        else:
            pytest.fail(f"{finding_id}: call_paths_v2[0] is neither dict nor list: {type(first)}")

    @pytest.mark.parametrize("signal_type", ["CVE", "CWE", "SECRET", "DLP", "AI"])
    def test_synthetic_finding_has_valid_paths(self, signal_type):
        """Synthetic findings with paths must pass schema validation."""
        maker = SYNTHETIC_FINDINGS[signal_type]
        finding = maker(with_paths=True) if "with_paths" in maker.__code__.co_varnames else maker()
        paths = finding.get("call_paths_v2", [])
        if paths:
            self._validate_call_paths_v2(paths, finding["id"])

    @pytest.mark.parametrize("signal_type", ["MALWARE", "CONFIG"])
    def test_signal_types_without_paths_are_valid(self, signal_type):
        """MALWARE and CONFIG typically have empty call_paths_v2."""
        finding = SYNTHETIC_FINDINGS[signal_type]()
        paths = finding.get("call_paths_v2", [])
        assert isinstance(paths, list)

    def test_cve_transitive_has_dependency_chain(self):
        finding = _make_cve_finding(transitive=True)
        assert finding["is_transitive"] is True
        assert finding["via_package"] is not None
        assert len(finding["dependency_chain"]) >= 2

    def test_dlp_finding_has_pii_and_sink(self):
        finding = _make_dlp_finding()
        assert finding["pii_type"] is not None
        assert finding["sink_type"] is not None

    def test_ai_finding_has_owasp_llm(self):
        finding = _make_ai_finding()
        assert finding.get("owasp_llm") or finding.get("llm_category")

    def test_multipath_cve_unique_entry_points(self):
        finding = _make_cve_finding()
        finding["call_paths_v2"] = [
            [{"kind": "entry", "label": "Server.HandleLogin()"}, {"kind": "sink_vuln", "label": "crypto"}],
            [{"kind": "entry", "label": "Server.HandlePutUser()"}, {"kind": "sink_vuln", "label": "crypto"}],
            [
                {"kind": "entry", "label": "idp.main"},
                {"kind": "via", "label": "samlidp"},
                {"kind": "sink_vuln", "label": "crypto"},
            ],
        ]
        self._validate_call_paths_v2(finding["call_paths_v2"], "CVE-multi")
        entries = [p[0]["label"] for p in finding["call_paths_v2"]]
        assert len(entries) == len(set(entries)), "Multi-path should have unique entry points"


class TestLayer1_DataJsonIntegrity:
    """Validate data.json has correct structure for dashboard consumption."""

    def test_issues_array_exists(self, data_json):
        assert "issues" in data_json, "data.json missing 'issues' key"
        assert isinstance(data_json["issues"], list)

    def test_all_issues_have_type(self, data_json):
        for i, issue in enumerate(data_json["issues"]):
            assert "type" in issue, f"Issue #{i} missing 'type': {issue.get('id', '?')}"
            assert issue["type"] in SIGNAL_TYPES, f"Issue #{i} unknown type: {issue['type']}"

    def test_reachable_issues_have_paths_or_fallback(self, data_json):
        path_types = {"CVE", "CWE", "AI", "DLP", "SECRET"}
        issues = [i for i in data_json["issues"] if i.get("type") in path_types and i.get("is_reachable")]
        missing = []
        for issue in issues:
            has_v2 = issue.get("call_paths_v2") and len(issue["call_paths_v2"]) > 0
            has_fallback = bool(issue.get("file_path") or issue.get("package"))
            if not has_v2 and not has_fallback:
                missing.append(issue.get("id", "?"))
        if missing:
            pytest.fail(
                f"{len(missing)} reachable issues have neither call_paths_v2 nor file_path/package: {missing[:5]}"
            )

    @pytest.mark.parametrize("signal_type", ["CVE", "CWE", "SECRET", "DLP", "AI"])
    def test_call_paths_v2_schema_in_data_json(self, data_json, signal_type):
        validator = TestLayer1_CallPathsV2Schema()
        issues = [i for i in data_json["issues"] if i.get("type") == signal_type]
        if not issues:
            pytest.skip(f"No {signal_type} findings in data.json")
        checked = 0
        for issue in issues[:20]:
            paths = issue.get("call_paths_v2", [])
            if paths:
                validator._validate_call_paths_v2(paths, issue.get("id", "?"))
                checked += 1
        if checked == 0:
            pytest.skip(f"No {signal_type} findings had call_paths_v2 data — skipping")


class TestLayer1_DBtoDataJsonConsistency:
    """Validate DB finding counts match data.json counts."""

    def test_total_count_matches(self, scan_db, data_json, latest_scan_id):
        # data.json issues[] is built from THREE tables:
        #   findings     = CVE/CWE/SECRET/MALWARE/CONFIG
        #   ai_findings  = AI security (added v4.5.28, separate table)
        #   dlp_findings = DLP/PII    (added v4.5.40, separate table)
        conn = sqlite3.connect(str(scan_db))
        c = conn.cursor()
        sid = latest_scan_id
        findings_count = c.execute("SELECT COUNT(*) FROM findings WHERE scan_id = ?", (sid,)).fetchone()[0]
        ai_count = c.execute("SELECT COUNT(*) FROM ai_findings WHERE scan_id = ?", (sid,)).fetchone()[0]
        dlp_count = c.execute("SELECT COUNT(*) FROM dlp_findings WHERE scan_id = ?", (sid,)).fetchone()[0]
        conn.close()

        db_count = findings_count + ai_count + dlp_count
        dj_count = len(data_json.get("issues", []))
        assert abs(db_count - dj_count) <= max(5, db_count * 0.05), (
            f"DB total {db_count} (findings={findings_count} + AI={ai_count} + DLP={dlp_count}) "
            f"vs data.json {dj_count} — >5% mismatch (scan_id={sid})"
        )

    def test_per_type_counts_match(self, scan_db, data_json, latest_scan_id):
        conn = sqlite3.connect(str(scan_db))
        c = conn.cursor()
        c.execute(
            "SELECT finding_type, COUNT(*) FROM findings WHERE scan_id = ? GROUP BY finding_type", (latest_scan_id,)
        )
        db_counts = {row[0].upper(): row[1] for row in c.fetchall()}
        conn.close()

        dj_counts = {}
        for issue in data_json.get("issues", []):
            t = (issue.get("type") or "").upper()
            dj_counts[t] = dj_counts.get(t, 0) + 1

        for ftype in set(list(db_counts.keys()) + list(dj_counts.keys())):
            db_n = db_counts.get(ftype, 0)
            dj_n = dj_counts.get(ftype, 0)
            if db_n > 0:
                diff_pct = abs(db_n - dj_n) / max(db_n, 1) * 100
                assert diff_pct <= 10, f"{ftype}: DB={db_n}, data.json={dj_n} — {diff_pct:.0f}% mismatch"

    def test_call_paths_not_lost_in_pipeline(self, scan_db, data_json, latest_scan_id):
        conn = sqlite3.connect(str(scan_db))
        c = conn.cursor()
        try:
            # T-CG10: call_paths_v2 is the authoritative column (call_path is deprecated)
            c.execute(
                """
                SELECT finding_id FROM findings
                WHERE call_paths_v2 IS NOT NULL AND call_paths_v2 != '' AND call_paths_v2 != '[]'
                AND scan_id = ?
            """,
                (latest_scan_id,),
            )
            db_ids_with_paths = {row[0] for row in c.fetchall()}
        except sqlite3.OperationalError:
            pytest.skip("findings table doesn't have call_paths_v2 column")
        finally:
            conn.close()

        if not db_ids_with_paths:
            pytest.skip("No findings in DB have call_path data")

        dj_ids_with_paths = set()
        for issue in data_json.get("issues", []):
            if issue.get("call_paths_v2") and len(issue["call_paths_v2"]) > 0:
                dj_ids_with_paths.add(issue.get("finding_id") or issue.get("id"))

        lost = db_ids_with_paths - dj_ids_with_paths
        if lost:
            loss_pct = len(lost) / len(db_ids_with_paths) * 100
            assert (
                loss_pct <= 5
            ), f"{len(lost)}/{len(db_ids_with_paths)} findings lost call_path in pipeline ({loss_pct:.0f}%)"


# ===========================================================================
# LAYER 2: JS Rendering Correctness
# ===========================================================================


class TestLayer2_FlowGraphPanelPlacement:
    """All flow graphs must render in the LEFT (Remediation) panel."""

    def test_cwe_flow_in_left_panel(self, main_js):
        cwe_flow_pos = main_js.find("Code Weakness Flow")
        details_pos = main_js.find("Details & References")
        assert cwe_flow_pos != -1, "CWE Code Weakness Flow not found in main.js"
        assert details_pos != -1, "Details & References not found in main.js"
        assert cwe_flow_pos < details_pos, f"CWE flow at pos {cwe_flow_pos} is AFTER Details panel at {details_pos}"

    def test_ai_flow_in_left_panel(self, main_js):
        ai_flow_pos = main_js.find("AI Attack Flow")
        details_pos = main_js.find("Details & References")
        assert ai_flow_pos != -1, "AI Attack Flow not found in main.js"
        assert ai_flow_pos < details_pos, "AI flow should be in left panel"

    def test_secret_flow_in_left_panel(self, main_js):
        sec_flow_pos = main_js.find("Secret Exposure Path")
        details_pos = main_js.find("Details & References")
        assert sec_flow_pos != -1, "Secret Exposure Path not found in main.js"
        assert sec_flow_pos < details_pos, "Secret flow should be in left panel"

    def test_dlp_flow_in_left_panel(self, main_js):
        dlp_flow_pos = main_js.find("Data Flow Path")
        details_pos = main_js.find("Details & References")
        assert dlp_flow_pos != -1, "Data Flow Path not found in main.js"
        assert dlp_flow_pos < details_pos, "DLP flow should be in left panel"

    def test_transitive_dep_path_in_left_panel(self, main_js):
        trans_pos = main_js.find("Transitive Dependency Path")
        details_pos = main_js.find("Details & References")
        assert trans_pos != -1, "Transitive Dependency Path not found in main.js"
        assert trans_pos < details_pos, "Transitive dep path should be in left panel"


class TestLayer2_AccordionIDUniqueness:
    """P1/P2/P3 accordion IDs must be scoped per finding (no collisions)."""

    def test_accordion_ids_use_uid_prefix(self, main_js):
        assert "cpv2_b'" not in main_js, "Found old unscoped cpv2_b IDs"
        assert "cpv2_a'" not in main_js, "Found old unscoped cpv2_a IDs"
        assert (
            "_uid + '_b'" in main_js or "_uid + '_a'" in main_js
        ), "Accordion IDs should use _uid prefix for per-finding scoping"

    def test_counter_is_declared(self, main_js):
        assert "_cgVizCounter" in main_js, "_cgVizCounter not declared"

    def test_counter_resets_on_render(self, main_js):
        assert "_cgVizCounter = 0" in main_js, "_cgVizCounter not reset on re-render"

    def test_counter_increments_per_finding(self, main_js):
        assert "_cgVizCounter++" in main_js, "_cgVizCounter never incremented"


class TestLayer2_FallbackFlowRenderer:
    """Findings without call_paths_v2 should get a universal fallback flow graph."""

    def test_fallback_renderer_exists(self, main_js):
        assert "Finding Flow" in main_js, "Universal fallback 'Finding Flow' renderer not found"
        assert "T-CG31" in main_js, "T-CG31 fallback comment marker not found"

    def test_fallback_skips_when_v2_present(self, main_js):
        assert (
            "f.call_paths_v2 && Array.isArray(f.call_paths_v2) && f.call_paths_v2.length > 0" in main_js
        ), "Fallback must skip when call_paths_v2 is populated"

    def test_fallback_covers_all_signal_types(self, main_js):
        for signal_type in ["CVE", "CWE", "SECRET", "DLP", "AI", "MALWARE", "CONFIG"]:
            assert (
                f"'{signal_type}'" in main_js or f'"{signal_type}"' in main_js
            ), f"Signal type {signal_type} not found in main.js"

    def test_fallback_needs_minimum_two_nodes(self, main_js):
        assert "_fbNodes.length < 2" in main_js, "Fallback should check for minimum 2 nodes before rendering"


class TestLayer2_FlowRendererPerType:
    """Each signal type has a dedicated flow renderer with correct header."""

    def test_cwe_flow_has_weakness_header(self, main_js):
        assert "Code Weakness Flow" in main_js

    def test_ai_flow_has_attack_header(self, main_js):
        assert "AI Attack Flow" in main_js

    def test_secret_flow_has_exposure_header(self, main_js):
        assert "Secret Exposure Path" in main_js

    def test_dlp_flow_has_data_path_header(self, main_js):
        assert "Data Flow Path" in main_js

    def test_cve_transitive_has_dependency_path_header(self, main_js):
        assert "Transitive Dependency Path" in main_js

    def test_all_renderers_use_consistent_node_cards(self, main_js):
        assert main_js.count("font-size:13px") >= 5, "Expected multiple node card renderers with icon styling"


class TestLayer2_ReachableBadgeCSS:
    """Reachable badge must show white text on blue background."""

    def test_css_file_has_white_text(self):
        css_path = (
            Path(__file__).parent.parent
            / "reachable"
            / "dashboard_v2"
            / "split"
            / "components"
            / "styles"
            / "dashboard-styles.css"
        )
        if not css_path.exists():
            pytest.skip("CSS file not found")
        css = css_path.read_text()
        match = re.search(r"\.reachable-status\.reachable-yes\s*\{([^}]+)\}", css)
        assert match, "CSS rule .reachable-status.reachable-yes not found"
        rule_body = match.group(1)
        assert (
            "#fff" in rule_body or "#FFF" in rule_body or "white" in rule_body
        ), f"Reachable badge text should be white, got: {rule_body}"


# ===========================================================================
# LAYER 3: Integration Tests (require real scan data)
# ===========================================================================


class TestLayer3_EndToEnd:
    """Integration tests against real scan output.

    dashboard_html reads only the first 512 KB — all JS structure markers
    are in the template block at the top.  Finding-count tests use data_json.
    """

    def test_dashboard_has_call_path_section(self, dashboard_html):
        """Dashboard HTML JS block must contain call path rendering code."""
        assert (
            "CALL PATHS" in dashboard_html or "Call Paths" in dashboard_html or "call_paths_v2" in dashboard_html
        ), "Dashboard HTML (first 768 KB) missing call path rendering"

    def test_dashboard_has_finding_flow_fallback(self, dashboard_html):
        """Dashboard HTML JS block must include fallback Finding Flow renderer.

        If the compiled template is stale, auto-rebuilds via build.py and
        re-reads the dashboard HTML before asserting.
        """
        if "Finding Flow" in dashboard_html:
            return

        # Stale build — try to rebuild and re-read
        build_script = (
            Path(__file__).parent.parent
            / "reachable" / "dashboard_v2" / "split" / "build.py"
        )
        if build_script.exists():
            import subprocess as _sp
            result = _sp.run(
                [sys.executable, str(build_script)],
                capture_output=True, text=True, timeout=30,
                cwd=str(Path(__file__).parent.parent),
            )
            if result.returncode == 0:
                # Rebuild succeeded — verify the compiled template has the string
                compiled = (
                    Path(__file__).parent.parent
                    / "reachable" / "dashboard_v2" / "split" / "template-shell-compiled.html"
                )
                if compiled.exists() and "Finding Flow" in compiled.read_text(encoding="utf-8"):
                    return  # passes — next scan will produce correct HTML
                pytest.fail(
                    "build.py succeeded but 'Finding Flow' still missing from compiled template. "
                    "Check main.js for T-CG31 fallback renderer."
                )

        # build.py not present or rebuild failed — check main.js to give useful message
        js_path = (
            Path(__file__).parent.parent
            / "reachable" / "dashboard_v2" / "split" / "components" / "scripts" / "main.js"
        )
        if js_path.exists() and "Finding Flow" in js_path.read_text(encoding="utf-8"):
            pytest.fail(
                "Compiled dashboard missing 'Finding Flow' but main.js has it. "
                "Run: python3 reachable/dashboard_v2/split/build.py"
            )
        else:
            pytest.fail(
                "Dashboard HTML (first 768 KB) missing fallback 'Finding Flow' renderer (T-CG31). "
                "Add it to main.js then run: python3 reachable/dashboard_v2/split/build.py"
            )

    def test_no_unscoped_accordion_ids_in_html(self, dashboard_html):
        """Dashboard JS template must not contain old unscoped cpv2_b IDs.

        PERF NOTE: This regex runs on the first 768 KB only (not the full HTML
        blob), so it completes in <100ms regardless of scan size.
        Old pattern: id="cpv2_b0" — new scoped pattern: id="cpv2_0_b0".
        """
        old_pattern = re.findall(r'id=["\']cpv2_[ab]\d+["\']', dashboard_html)
        assert len(old_pattern) == 0, f"Found {len(old_pattern)} old unscoped accordion IDs: {old_pattern[:5]}"

    def test_each_signal_type_has_findings(self, data_json):
        """Scan should produce findings for multiple signal types."""
        types_found = {i.get("type") for i in data_json.get("issues", [])}
        assert (
            "CVE" in types_found or "CWE" in types_found
        ), f"Expected at least CVE or CWE findings, got types: {types_found}"

    def test_reachable_cves_have_paths(self, data_json):
        """Reachable CVEs should have call_paths_v2 data."""
        reachable_cves = [i for i in data_json.get("issues", []) if i.get("type") == "CVE" and i.get("is_reachable")]
        if not reachable_cves:
            pytest.skip("No reachable CVEs in scan")
        with_paths = sum(1 for c in reachable_cves if c.get("call_paths_v2") and len(c["call_paths_v2"]) > 0)
        pct = with_paths / len(reachable_cves) * 100
        assert pct >= 50, f"Only {with_paths}/{len(reachable_cves)} ({pct:.0f}%) reachable CVEs have call_paths_v2"

    def test_multipath_findings_have_distinct_entries(self, data_json):
        """Multi-path findings should have distinct entry points per path."""
        issues = data_json.get("issues", [])
        violations = []
        for issue in issues:
            paths = issue.get("call_paths_v2", [])
            if not paths or not isinstance(paths[0], list) or len(paths) < 2:
                continue
            entries = []
            for p in paths:
                if p and isinstance(p[0], dict):
                    entries.append(p[0].get("label", ""))
            if len(entries) != len(set(entries)):
                violations.append(issue.get("id", "?"))
        if violations:
            import warnings

            warnings.warn(f"{len(violations)} findings have duplicate entry points: {violations[:3]}")


# ===========================================================================
# Quick smoke test — run standalone
# ===========================================================================


def _find_latest_data_json():
    """Find the most recent data.json in .reachable scan dirs."""
    import glob

    candidates = sorted(
        glob.glob(str(Path.home() / ".reachable" / "*" / "data.json")),
        key=lambda p: Path(p).stat().st_mtime,
        reverse=True,
    )
    return candidates[0] if candidates else None


if __name__ == "__main__":
    print("=" * 70)
    print("T-CG33: Dashboard Call Path Accuracy — Quick Smoke Test")
    print("=" * 70)

    # Test synthetic finding schemas
    print("\n[1/3] Validating synthetic finding schemas...")
    validator = TestLayer1_CallPathsV2Schema()
    for name, maker in SYNTHETIC_FINDINGS.items():
        try:
            finding = maker() if "with_paths" not in str(maker.__code__.co_varnames) else maker(with_paths=True)
            paths = finding.get("call_paths_v2", [])
            if paths:
                validator._validate_call_paths_v2(paths, name)
            print(f"  ✅ {name}: valid ({len(paths)} paths)")
        except Exception as e:
            print(f"  ❌ {name}: {e}")

    # Test data.json if available
    print("\n[2/3] Checking latest data.json...")
    dj_path = _find_latest_data_json()
    if dj_path:
        with open(dj_path) as f:
            dj = json.load(f)
        issues = dj.get("issues", [])
        type_counts = {}
        type_with_paths = {}
        for issue in issues:
            t = issue.get("type", "?")
            type_counts[t] = type_counts.get(t, 0) + 1
            if issue.get("call_paths_v2") and len(issue.get("call_paths_v2", [])) > 0:
                type_with_paths[t] = type_with_paths.get(t, 0) + 1
        for t in sorted(type_counts):
            total = type_counts[t]
            wp = type_with_paths.get(t, 0)
            pct = wp / total * 100 if total > 0 else 0
            status = "✅" if pct > 0 or t in ("CONFIG", "MALWARE", "SUSPICIOUS") else "⚠️"
            print(f"  {status} {t:12s}: {total:4d} total, {wp:4d} with call_paths_v2 ({pct:.0f}%)")
    else:
        print("  ⚠️ No data.json found — run a scan first")

    # Test main.js structure
    print("\n[3/3] Checking main.js structure...")
    js_path = (
        Path(__file__).parent.parent / "reachable" / "dashboard_v2" / "split" / "components" / "scripts" / "main.js"
    )
    if js_path.exists():
        js = js_path.read_text()
        checks = {
            "_cgVizCounter declared": "_cgVizCounter" in js,
            "_cgVizCounter resets": "_cgVizCounter = 0" in js,
            "Scoped accordion IDs": "_uid + '_b'" in js,
            "No old unscoped IDs": "cpv2_b'" not in js,
            "Fallback flow (T-CG31)": "Finding Flow" in js,
            "CWE flow in left panel": js.find("Code Weakness Flow") < js.find("Details & References"),
            "AI flow in left panel": js.find("AI Attack Flow") < js.find("Details & References"),
            "SECRET flow in left panel": js.find("Secret Exposure Path") < js.find("Details & References"),
            "DLP flow in left panel": js.find("Data Flow Path") < js.find("Details & References"),
        }
        for check, passed in checks.items():
            print(f"  {'✅' if passed else '❌'} {check}")
    else:
        print("  ⚠️ main.js not found")

    print("\n" + "=" * 70)
    print("Run full suite: pytest tests/test_dashboard_callpaths.py -v")
    print("=" * 70)
