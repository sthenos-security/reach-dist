#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.
"""
Unit tests for LibraryManager private registry integration (Phase 1).

Tests the wiring between PURLResolver output and lib_manager:
  - _resolve_canonical() lookup with ecosystem aliases
  - _clone_library_as() saves under original name
  - clone_library() PURL resolution path (step 0)
  - should_clone_library() with PURL fallback
  - call_graph_gaps tracking for failed/unresolvable packages

All tests use mocked subprocess/network — no Docker, no real git clones.

Run:
    pytest tests/unit/test_lib_manager_resolution.py -v
"""

import json
from unittest.mock import patch

import pytest

from reachable.integrations.lib_manager import LibraryManager, RepoInfo

# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture
def libs_dir(tmp_path):
    d = tmp_path / "libs"
    d.mkdir()
    return d


@pytest.fixture
def metadata_dir(tmp_path):
    d = tmp_path / "metadata"
    d.mkdir()
    return d


@pytest.fixture
def resolution_map():
    """Standard resolution map as PURLResolver.get_resolution_map() returns."""
    return {
        ("python", "company-auth"): {
            "canonical_name": "authlib",
            "canonical_version": "1.3.0",
            "canonical_purl": "pkg:pypi/authlib@1.3.0",
            "method": "hash_match",
        },
        ("pypi", "jinja2-mirror"): {
            "canonical_name": "jinja2",
            "canonical_version": "2.11.2",
            "canonical_purl": "pkg:pypi/jinja2@2.11.2",
            "method": "alias",
        },
        ("npm", "@company/logger"): {
            "canonical_name": "winston",
            "canonical_version": "3.11.0",
            "canonical_purl": "pkg:npm/winston@3.11.0",
            "method": "alias",
        },
        ("go", "go.company.com/mirror/golang.org/x/crypto"): {
            "canonical_name": "golang.org/x/crypto",
            "canonical_version": "v0.21.0",
            "canonical_purl": "pkg:golang/golang.org/x/crypto@v0.21.0",
            "method": "hash_match",
        },
        ("maven", "com.company.internal/h2"): {
            "canonical_name": "com.h2database/h2",
            "canonical_version": "1.4.197",
            "canonical_purl": "pkg:maven/com.h2database/h2@1.4.197",
            "method": "hash_match",
        },
    }


@pytest.fixture
def manager(libs_dir, metadata_dir, resolution_map):
    return LibraryManager(
        libs_dir=libs_dir,
        verbose=False,
        use_global_cache=False,
        metadata_dir=metadata_dir,
        purl_resolutions=resolution_map,
    )


@pytest.fixture
def manager_no_resolutions(libs_dir, metadata_dir):
    return LibraryManager(
        libs_dir=libs_dir,
        verbose=False,
        use_global_cache=False,
        metadata_dir=metadata_dir,
        purl_resolutions={},
    )


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _fake_repo_info(url="https://github.com/org/repo.git"):
    return RepoInfo(url=url, source="pypi", is_github=True)


def _make_vulns(packages: list) -> dict:
    """Build minimal Grype vulns.json from a list of (name, version, ecosystem) tuples."""
    matches = []
    for name, version, ecosystem in packages:
        pkg_type = {
            "python": "python",
            "pypi": "python",
            "npm": "npm",
            "go": "go-module",
            "maven": "java-archive",
        }.get(ecosystem, "unknown")
        matches.append(
            {
                "artifact": {
                    "name": name,
                    "version": version,
                    "type": pkg_type,
                    "metadata": {},
                },
                "vulnerability": {
                    "id": f"CVE-2024-{hash(name) % 9999:04d}",
                    "severity": "HIGH",
                    "fix": {"state": "fixed"},
                },
            }
        )
    return {"matches": matches}


# ===================================================================
# _resolve_canonical()
# ===================================================================


class TestResolveCanonical:
    """Tests the resolution map lookup with ecosystem alias fallback."""

    def test_exact_ecosystem_match_python(self, manager):
        res = manager._resolve_canonical("company-auth", "python")
        assert res is not None
        assert res["canonical_name"] == "authlib"
        assert res["canonical_version"] == "1.3.0"
        assert res["method"] == "hash_match"

    def test_ecosystem_alias_pypi_to_python(self, manager):
        """Map keyed as ('python', name) should be found via ecosystem='pypi'."""
        res = manager._resolve_canonical("company-auth", "pypi")
        assert res is not None
        assert res["canonical_name"] == "authlib"

    def test_ecosystem_alias_python_to_pypi(self, manager):
        """Map keyed as ('pypi', name) should be found via ecosystem='python'."""
        res = manager._resolve_canonical("jinja2-mirror", "python")
        assert res is not None
        assert res["canonical_name"] == "jinja2"

    def test_ecosystem_alias_go_to_golang(self, manager):
        res = manager._resolve_canonical("go.company.com/mirror/golang.org/x/crypto", "golang")
        assert res is not None
        assert res["canonical_name"] == "golang.org/x/crypto"

    def test_npm_exact_match(self, manager):
        res = manager._resolve_canonical("@company/logger", "npm")
        assert res is not None
        assert res["canonical_name"] == "winston"

    def test_maven_exact_match(self, manager):
        res = manager._resolve_canonical("com.company.internal/h2", "maven")
        assert res is not None
        assert res["canonical_name"] == "com.h2database/h2"

    def test_unknown_package_returns_none(self, manager):
        assert manager._resolve_canonical("never-heard-of-this", "python") is None

    def test_empty_resolution_map_returns_none(self, manager_no_resolutions):
        assert manager_no_resolutions._resolve_canonical("company-auth", "python") is None


# ===================================================================
# should_clone_library() with PURL fallback
# ===================================================================


class TestShouldCloneWithResolution:
    """Validates PURL resolution fallback in should_clone_library()."""

    def test_public_package_normal_discovery(self, manager):
        """Public package found via get_repo_info → should clone."""
        vulnerable = {
            "requests": {"versions": {"2.31.0"}, "ecosystem": "python"},
        }
        with patch.object(manager, "get_repo_info", return_value=_fake_repo_info()):
            assert manager.should_clone_library("requests", vulnerable) is True

    def test_private_package_purl_fallback(self, manager):
        """Private package not in PyPI, but PURL resolves to authlib → should clone."""
        vulnerable = {
            "company-auth": {"versions": {"1.0.0"}, "ecosystem": "python"},
        }

        def repo_info_side_effect(name, eco):
            if name == "authlib":
                return _fake_repo_info("https://github.com/lepture/authlib.git")
            return None  # company-auth not found directly

        with patch.object(manager, "get_repo_info", side_effect=repo_info_side_effect):
            assert manager.should_clone_library("company-auth", vulnerable) is True

    def test_private_package_no_resolution_no_repo(self, manager_no_resolutions):
        """Private package with no resolution and no repo → should NOT clone."""
        vulnerable = {
            "internal-sdk": {"versions": {"0.5.0"}, "ecosystem": "python"},
        }
        with patch.object(manager_no_resolutions, "get_repo_info", return_value=None):
            assert manager_no_resolutions.should_clone_library("internal-sdk", vulnerable) is False

    def test_already_cloned_skipped(self, manager):
        """Package directory already exists → skip regardless of resolution."""
        (manager.libs_dir / "company-auth").mkdir()
        vulnerable = {
            "company-auth": {"versions": {"1.0.0"}, "ecosystem": "python"},
        }
        assert manager.should_clone_library("company-auth", vulnerable) is False

    def test_not_in_vulnerable_returns_false(self, manager):
        assert manager.should_clone_library("not-vulnerable", {}) is False


# ===================================================================
# _clone_library_as()
# ===================================================================


class TestCloneLibraryAs:
    """Tests the canonical-name-clone + save-as-original-name helper."""

    def test_saves_under_original_name(self, manager):
        """Cloning authlib should create libs/company-auth/ not libs/authlib/."""

        def fake_clone_git(url, target, version, eco, pkg):
            target.mkdir(parents=True, exist_ok=True)
            (target / "setup.py").write_text("# authlib")
            return True

        with patch.object(
            manager, "get_repo_info", return_value=_fake_repo_info("https://github.com/lepture/authlib.git")
        ):
            with patch.object(manager, "_clone_with_mcp", return_value=False):
                with patch.object(manager, "_clone_with_git", side_effect=fake_clone_git):
                    result = manager._clone_library_as(
                        clone_name="authlib",
                        clone_version="1.3.0",
                        save_as="company-auth",
                        ecosystem="python",
                    )

        assert result is not None
        assert result == manager.libs_dir / "company-auth"
        assert (manager.libs_dir / "company-auth" / "setup.py").exists()
        # libs/authlib/ should NOT exist
        assert not (manager.libs_dir / "authlib").exists()

    def test_returns_existing_if_already_present(self, manager):
        """If save_as/ dir already exists, return it immediately."""
        (manager.libs_dir / "company-auth").mkdir()
        result = manager._clone_library_as(
            clone_name="authlib",
            clone_version="1.3.0",
            save_as="company-auth",
            ecosystem="python",
        )
        assert result == manager.libs_dir / "company-auth"

    def test_returns_none_if_no_repo_found(self, manager):
        with patch.object(manager, "get_repo_info", return_value=None):
            result = manager._clone_library_as(
                clone_name="nonexistent-canonical",
                clone_version="1.0.0",
                save_as="company-pkg",
                ecosystem="python",
            )
        assert result is None
        assert manager.metrics["total_failed"] >= 1

    def test_metrics_tracked_for_purl_resolve(self, manager):
        def fake_clone_git(url, target, version, eco, pkg):
            target.mkdir(parents=True, exist_ok=True)
            (target / "src.py").write_text("# source")
            return True

        with patch.object(manager, "get_repo_info", return_value=_fake_repo_info()):
            with patch.object(manager, "_clone_with_mcp", return_value=False):
                with patch.object(manager, "_clone_with_git", side_effect=fake_clone_git):
                    manager._clone_library_as(
                        clone_name="authlib",
                        clone_version="1.3.0",
                        save_as="company-auth",
                        ecosystem="python",
                    )

        methods = manager.metrics["clone_methods"]
        assert any(pkg == "company-auth" and method == "purl-resolve" for pkg, method, success in methods)


# ===================================================================
# clone_library() PURL resolution path
# ===================================================================


class TestCloneLibraryPurlResolution:
    """Tests clone_library() step 0: PURL resolution redirect."""

    def test_resolved_package_clones_canonical(self, manager):
        """company-auth → authlib: clone_library must call _clone_library_as."""

        def fake_clone_as(clone_name, clone_version, save_as, ecosystem):
            target = manager.libs_dir / save_as
            target.mkdir(parents=True, exist_ok=True)
            (target / "main.py").write_text("# authlib")
            return target

        with patch.object(manager, "_clone_library_as", side_effect=fake_clone_as) as mock_cas:
            result = manager.clone_library("company-auth", "1.0.0", "python")

        assert result is not None
        assert result.name == "company-auth"
        mock_cas.assert_called_once_with(
            clone_name="authlib",
            clone_version="1.3.0",
            save_as="company-auth",
            ecosystem="python",
        )

    def test_unresolved_package_falls_through_to_normal(self, manager_no_resolutions):
        """Package with no resolution → normal clone path."""

        def fake_clone_git(url, target, version, eco, pkg):
            target.mkdir(parents=True, exist_ok=True)
            (target / "src.py").write_text("# source")
            return True

        with patch.object(manager_no_resolutions, "get_repo_info", return_value=_fake_repo_info()):
            with patch.object(manager_no_resolutions, "_clone_with_mcp", return_value=False):
                with patch.object(manager_no_resolutions, "_clone_with_git", side_effect=fake_clone_git):
                    result = manager_no_resolutions.clone_library("requests", "2.31.0", "python")

        assert result is not None
        assert result.name == "requests"

    def test_resolution_prevents_infinite_loop(self, manager):
        """
        When cloning canonical name, purl_resolutions must be temporarily cleared
        to prevent authlib from re-resolving to itself.
        """
        call_log = []

        original_clone_as = manager._clone_library_as

        def tracked_clone_as(clone_name, clone_version, save_as, ecosystem):
            # During _clone_library_as, resolution map should be empty
            call_log.append(("clone_as", clone_name, dict(manager.purl_resolutions)))
            target = manager.libs_dir / save_as
            target.mkdir(parents=True, exist_ok=True)
            return target

        with patch.object(manager, "_clone_library_as", side_effect=tracked_clone_as):
            manager.clone_library("company-auth", "1.0.0", "python")

        # During _clone_library_as, purl_resolutions should have been empty
        assert len(call_log) == 1
        assert call_log[0][1] == "authlib"
        assert call_log[0][2] == {}  # resolutions cleared

        # After clone_library returns, resolutions should be restored
        assert len(manager.purl_resolutions) > 0

    def test_canonical_clone_failure_falls_through(self, manager):
        """If canonical clone fails, fall through to try original name."""

        def fake_clone_git(url, target, version, eco, pkg):
            target.mkdir(parents=True, exist_ok=True)
            (target / "src.py").write_text("# direct")
            return True

        with patch.object(manager, "_clone_library_as", return_value=None):
            with patch.object(manager, "get_repo_info", return_value=_fake_repo_info()):
                with patch.object(manager, "_clone_with_mcp", return_value=False):
                    with patch.object(manager, "_clone_with_git", side_effect=fake_clone_git):
                        result = manager.clone_library("company-auth", "1.0.0", "python")

        # Should have succeeded via the normal path
        assert result is not None
        assert result.name == "company-auth"


# ===================================================================
# call_graph_gaps Tracking
# ===================================================================


class TestCallGraphGaps:
    """Validates that failed clones produce explicit gap records."""

    def test_failed_clone_recorded_as_gap(self, manager):
        """Packages that fail to clone must appear in call_graph_gaps."""
        vulns = _make_vulns(
            [
                ("internal-sdk", "0.5.0", "python"),
            ]
        )

        with patch.object(manager, "get_repo_info", return_value=None):
            manager.clone_vulnerable_libraries(vulns, verbose=False)

        # internal-sdk should be in call_graph_gaps
        gap_names = [g["name"] for g in manager.call_graph_gaps]
        assert "internal-sdk" in gap_names

        gap = next(g for g in manager.call_graph_gaps if g["name"] == "internal-sdk")
        assert gap["reason"] == "no_source_repository"
        assert gap["ecosystem"] == "python"

    def test_resolved_package_no_gap(self, manager):
        """Successfully resolved+cloned package must NOT be in gaps."""
        vulns = _make_vulns(
            [
                ("company-auth", "1.0.0", "python"),
            ]
        )

        def fake_clone_as(clone_name, clone_version, save_as, ecosystem):
            target = manager.libs_dir / save_as
            target.mkdir(parents=True, exist_ok=True)
            (target / "src.py").write_text("# authlib")
            return target

        with patch.object(manager, "_clone_library_as", side_effect=fake_clone_as):
            manager.clone_vulnerable_libraries(vulns, verbose=False)

        gap_names = [g["name"] for g in manager.call_graph_gaps]
        assert "company-auth" not in gap_names

    def test_gaps_saved_to_metrics_json(self, manager):
        """call_graph_gaps must appear in lib-cloning-metrics.json."""
        vulns = _make_vulns(
            [
                ("internal-sdk", "0.5.0", "python"),
            ]
        )

        with patch.object(manager, "get_repo_info", return_value=None):
            manager.clone_vulnerable_libraries(vulns, verbose=False)

        # Trigger metrics save
        manager._save_cloning_metrics()
        metrics_file = manager.metadata_dir / "lib-cloning-metrics.json"
        assert metrics_file.exists()

        data = json.loads(metrics_file.read_text())
        assert "call_graph_gaps" in data
        assert len(data["call_graph_gaps"]) >= 1


# ===================================================================
# Multi-Language Resolution (all 4 ecosystems in one pass)
# ===================================================================


class TestMultiLanguageResolution:
    """
    End-to-end: vulns from Python, npm, Go, Maven — each with a resolved
    private package — all handled in a single clone_vulnerable_libraries() call.
    """

    def test_polyglot_resolution(self, manager):
        vulns = _make_vulns(
            [
                # Public (normal clone)
                ("requests", "2.31.0", "python"),
                ("lodash", "4.17.21", "npm"),
                # Private resolved (PURL → canonical)
                ("company-auth", "1.0.0", "python"),
                ("@company/logger", "2.0.0", "npm"),
                # Genuine private (gap)
                ("internal-sdk", "0.5.0", "python"),
            ]
        )

        clone_log = []

        def fake_clone_as(clone_name, clone_version, save_as, ecosystem):
            clone_log.append(("resolve", clone_name, save_as))
            # Use _pkg_dir so scoped npm names like @company/logger are
            # stored as @company__logger (not split across two path components)
            target = manager._pkg_dir(save_as)
            target.mkdir(parents=True, exist_ok=True)
            (target / "src.py").write_text(f"# {clone_name}")
            return target

        def repo_info_side_effect(name, eco):
            # Public packages discoverable
            if name in ("requests", "lodash"):
                return _fake_repo_info(f"https://github.com/org/{name}.git")
            return None

        def fake_clone_git(url, target, version, eco, pkg):
            target.mkdir(parents=True, exist_ok=True)
            (target / "src.py").write_text(f"# {pkg}")
            return True

        with patch.object(manager, "_clone_library_as", side_effect=fake_clone_as):
            with patch.object(manager, "get_repo_info", side_effect=repo_info_side_effect):
                with patch.object(manager, "_clone_with_mcp", return_value=False):
                    with patch.object(manager, "_clone_with_git", side_effect=fake_clone_git):
                        paths = manager.clone_vulnerable_libraries(vulns, verbose=False)

        cloned_names = {p.name for p in paths}

        # Public packages cloned normally
        assert "requests" in cloned_names
        assert "lodash" in cloned_names

        # Resolved private packages cloned via _clone_library_as
        # Scoped npm names (@scope/pkg) are stored on disk as @scope__pkg
        assert "company-auth" in cloned_names
        assert "@company__logger" in cloned_names

        # Verify _clone_library_as was called with correct canonical names
        resolve_calls = {(cn, sa) for op, cn, sa in clone_log if op == "resolve"}
        assert ("authlib", "company-auth") in resolve_calls
        assert ("winston", "@company/logger") in resolve_calls

        # Genuine private → gap
        gap_names = [g["name"] for g in manager.call_graph_gaps]
        assert "internal-sdk" in gap_names

        # Resolved packages must NOT be in gaps
        assert "company-auth" not in gap_names
        assert "@company/logger" not in gap_names


# ===================================================================
# Ecosystem Alias Edge Cases
# ===================================================================


class TestEcosystemAliasEdgeCases:
    """Tests edge cases in ecosystem key lookup."""

    def test_go_golang_bidirectional(self, libs_dir, metadata_dir):
        """Resolution stored as ('go', name) should be found via 'golang' and vice versa."""
        mgr = LibraryManager(
            libs_dir=libs_dir,
            verbose=False,
            use_global_cache=False,
            metadata_dir=metadata_dir,
            purl_resolutions={
                ("go", "go.corp.com/pkg"): {
                    "canonical_name": "github.com/org/pkg",
                    "canonical_version": "v1.0.0",
                    "method": "hash_match",
                },
                ("golang", "go.corp.com/other"): {
                    "canonical_name": "github.com/org/other",
                    "canonical_version": "v2.0.0",
                    "method": "alias",
                },
            },
        )

        # Stored as 'go', queried as 'golang'
        r1 = mgr._resolve_canonical("go.corp.com/pkg", "golang")
        assert r1 is not None
        assert r1["canonical_name"] == "github.com/org/pkg"

        # Stored as 'golang', queried as 'go'
        r2 = mgr._resolve_canonical("go.corp.com/other", "go")
        assert r2 is not None
        assert r2["canonical_name"] == "github.com/org/other"

    def test_unknown_ecosystem_no_crash(self, manager):
        """Unknown ecosystem ('ruby', 'rust') shouldn't crash, just return None."""
        assert manager._resolve_canonical("some-gem", "ruby") is None
        assert manager._resolve_canonical("some-crate", "rust") is None
