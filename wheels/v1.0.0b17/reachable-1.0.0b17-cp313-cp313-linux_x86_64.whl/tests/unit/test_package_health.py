#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.
"""
Package Health (T7) — pytest wrapper.

Pulls the full test suite from its canonical location so pytest
discovers it when running from tests/.

Canonical suite: reachable/collectors/health/tests/test_package_health.py
"""
