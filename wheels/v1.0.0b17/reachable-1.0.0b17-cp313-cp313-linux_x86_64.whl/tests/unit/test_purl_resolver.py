#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.
"""
Unit tests for PURLResolver — synthetic SBOMs, mocked HTTP, no Docker.

Covers:
  - PURL parsing for all 4 ecosystems (Python, npm, Go, Maven)
  - Per-artifact resolution: canonical / internal / alias / hash_match / unresolved
  - enrich_sbom() end-to-end with synthetic SBOMs
  - get_resolution_map() output shape
  - Cache prevents redundant API calls
  - Offline mode leaves PURLs unchanged
  - Mixed-registry single-pass correctness

Run:
    pytest tests/unit/test_purl_resolver.py -v
"""

import gzip
import json
from pathlib import Path
from typing import Dict
from unittest.mock import patch

import pytest

# ---------------------------------------------------------------------------
# Module under test
# ---------------------------------------------------------------------------
from reachable.collectors.vulns.purl_resolver import PURLResolver, _purl_parts, _resolve_artifact

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_artifact(name: str, version: str, purl: str, **extra) -> Dict:
    """Build a minimal Syft-style artifact dict."""
    art = {
        "name": name,
        "version": version,
        "purl": purl,
        "type": extra.pop("type", "python"),
        "metadata": extra.pop("metadata", {}),
        "locations": extra.pop("locations", []),
    }
    art.update(extra)
    return art


def _make_sbom(*artifacts) -> Dict:
    """Wrap artifacts in a minimal Syft SBOM envelope."""
    return {
        "artifacts": list(artifacts),
        "source": {"type": "directory", "target": "/app"},
        "descriptor": {"name": "syft", "version": "0.100.0"},
    }


def _write_sbom(sbom: Dict, directory: Path, gz: bool = False) -> Path:
    """Write sbom to a file, optionally gzipped."""
    if gz:
        p = directory / "sbom.json.gz"
        with gzip.open(p, "wt") as f:
            json.dump(sbom, f)
    else:
        p = directory / "sbom.json"
        p.write_text(json.dumps(sbom))
    return p


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture
def tmpdir_path(tmp_path):
    return tmp_path


@pytest.fixture
def resolver():
    return PURLResolver(offline=False)


@pytest.fixture
def offline_resolver():
    return PURLResolver(offline=True)


@pytest.fixture
def sample_public_artifact():
    return _make_artifact("requests", "2.31.0", "pkg:pypi/requests@2.31.0")


@pytest.fixture
def sample_private_python_artifact():
    return _make_artifact(
        "company-auth",
        "1.0.0",
        "pkg:pypi/company-auth@1.0.0",
        metadata={"sha256": "abc123deadbeef"},
    )


@pytest.fixture
def sample_private_npm_artifact():
    return _make_artifact(
        "@company/logger",
        "2.0.0",
        "pkg:npm/%40company/logger@2.0.0",
        type="npm",
        metadata={"integrity": "sha512-AAAA=="},
    )


@pytest.fixture
def sample_private_go_artifact():
    return _make_artifact(
        "go.company.com/mirror/golang.org/x/crypto",
        "v0.21.0",
        "pkg:golang/go.company.com/mirror/golang.org/x/crypto@v0.21.0",
        type="go-module",
    )


@pytest.fixture
def sample_private_maven_artifact():
    return _make_artifact(
        "h2",
        "1.4.197",
        "pkg:maven/com.company.internal/h2@1.4.197",
        type="java-archive",
        locations=["/app/.m2/repository/com/company/internal/h2/1.4.197/h2-1.4.197.jar"],
    )


@pytest.fixture
def sample_genuine_private():
    """A package with no public upstream — should stay unresolved."""
    return _make_artifact(
        "internal-sdk",
        "0.5.0",
        "pkg:pypi/internal-sdk@0.5.0",
    )


@pytest.fixture
def mixed_sbom(
    sample_public_artifact,
    sample_private_python_artifact,
    sample_private_npm_artifact,
    sample_genuine_private,
):
    """Mixed public + private + genuine-private in one SBOM."""
    return _make_sbom(
        sample_public_artifact,
        sample_private_python_artifact,
        sample_private_npm_artifact,
        sample_genuine_private,
    )


# ===================================================================
# PURL Parsing
# ===================================================================


class TestPurlParts:
    """Validates _purl_parts() across all ecosystems."""

    def test_pypi_standard(self):
        eco, name, ver = _purl_parts("pkg:pypi/requests@2.31.0")
        assert eco == "pypi"
        assert name == "requests"
        assert ver == "2.31.0"

    def test_npm_scoped_url_encoded(self):
        eco, name, ver = _purl_parts("pkg:npm/%40company/logger@2.0.0")
        assert eco == "npm"
        assert name == "@company/logger"
        assert ver == "2.0.0"

    def test_npm_unscoped(self):
        eco, name, ver = _purl_parts("pkg:npm/lodash@4.17.21")
        assert eco == "npm"
        assert name == "lodash"
        assert ver == "4.17.21"

    def test_golang_nested_path(self):
        eco, name, ver = _purl_parts("pkg:golang/golang.org/x/net@v0.23.0")
        assert eco == "golang"
        assert name == "golang.org/x/net"
        assert ver == "v0.23.0"

    def test_golang_private_mirror(self):
        eco, name, ver = _purl_parts("pkg:golang/go.company.com/mirror/golang.org/x/crypto@v0.21.0")
        assert eco == "golang"
        assert name == "go.company.com/mirror/golang.org/x/crypto"
        assert ver == "v0.21.0"

    def test_maven_group_artifact(self):
        eco, name, ver = _purl_parts("pkg:maven/com.h2database/h2@1.4.197")
        assert eco == "maven"
        assert name == "com.h2database/h2"
        assert ver == "1.4.197"

    def test_empty_purl(self):
        assert _purl_parts("") == ("", "", "")

    def test_none_purl(self):
        assert _purl_parts(None) == ("", "", "")

    def test_no_version(self):
        eco, name, ver = _purl_parts("pkg:pypi/requests")
        assert eco == "pypi"
        assert name == "requests"
        assert ver == ""


# ===================================================================
# Per-Artifact Resolution
# ===================================================================


class TestResolveArtifact:
    """Tests the _resolve_artifact() function in isolation."""

    def test_canonical_public_package_passthrough(self, sample_public_artifact):
        """Public packages with recognizable names pass through unchanged."""
        art, reason = _resolve_artifact(sample_public_artifact, offline=True)
        assert reason == "canonical"
        assert art["purl"] == "pkg:pypi/requests@2.31.0"
        assert "_reachable_registry" not in art

    def test_no_purl_returns_no_purl_reason(self):
        art = _make_artifact("something", "1.0", "")
        result, reason = _resolve_artifact(art)
        assert reason == "no_purl"

    @patch("reachable.collectors.vulns.purl_resolver.is_internal_package")
    def test_internal_namespace_detected(self, mock_internal, sample_private_python_artifact):
        mock_internal.return_value = True
        art, reason = _resolve_artifact(sample_private_python_artifact)
        assert reason == "internal"
        assert art["_reachable_registry"]["resolution"] == "internal"
        assert art["_reachable_registry"]["original_purl"] == "pkg:pypi/company-auth@1.0.0"

    @patch("reachable.collectors.vulns.purl_resolver.resolve_alias")
    @patch("reachable.collectors.vulns.purl_resolver.is_internal_package")
    def test_alias_rewrite(self, mock_internal, mock_alias, sample_private_python_artifact):
        mock_internal.return_value = False
        mock_alias.return_value = "pkg:pypi/authlib@1.0.0"
        art, reason = _resolve_artifact(sample_private_python_artifact)
        assert reason == "alias"
        assert art["purl"] == "pkg:pypi/authlib@1.0.0"
        assert art["_reachable_registry"]["original_purl"] == "pkg:pypi/company-auth@1.0.0"

    @patch("reachable.collectors.vulns.purl_resolver.resolve_alias")
    @patch("reachable.collectors.vulns.purl_resolver.is_internal_package")
    def test_offline_skips_hash_lookup(self, mock_internal, mock_alias, sample_private_python_artifact):
        mock_internal.return_value = False
        mock_alias.return_value = None
        art, reason = _resolve_artifact(sample_private_python_artifact, offline=True)
        # Should return 'canonical' since offline mode skips hash lookup
        assert reason == "canonical"
        assert art["purl"] == "pkg:pypi/company-auth@1.0.0"  # unchanged


# ===================================================================
# enrich_sbom() End-to-End
# ===================================================================


class TestEnrichSbom:
    """Tests PURLResolver.enrich_sbom() with full synthetic SBOMs."""

    @patch("reachable.collectors.vulns.purl_resolver.resolve_alias")
    @patch("reachable.collectors.vulns.purl_resolver.is_internal_package")
    def test_json_file(self, mock_internal, mock_alias, resolver, mixed_sbom, tmpdir_path):
        mock_internal.return_value = False
        mock_alias.return_value = None
        sbom_path = _write_sbom(mixed_sbom, tmpdir_path, gz=False)
        result_path = resolver.enrich_sbom(sbom_path)
        # When no rewrites happen, returns original path
        assert result_path.exists()

    @patch("reachable.collectors.vulns.purl_resolver.resolve_alias")
    @patch("reachable.collectors.vulns.purl_resolver.is_internal_package")
    def test_gzip_file(self, mock_internal, mock_alias, resolver, mixed_sbom, tmpdir_path):
        mock_internal.return_value = False
        mock_alias.return_value = None
        sbom_path = _write_sbom(mixed_sbom, tmpdir_path, gz=True)
        result_path = resolver.enrich_sbom(sbom_path)
        assert result_path.exists()

    @patch("reachable.collectors.vulns.purl_resolver.resolve_alias")
    @patch("reachable.collectors.vulns.purl_resolver.is_internal_package")
    def test_alias_rewrite_produces_enriched_file(
        self,
        mock_internal,
        mock_alias,
        resolver,
        tmpdir_path,
    ):
        mock_internal.return_value = False

        def alias_side_effect(purl):
            if "company-auth" in purl:
                return "pkg:pypi/authlib@1.3.0"
            return None

        mock_alias.side_effect = alias_side_effect

        sbom = _make_sbom(
            _make_artifact("requests", "2.31.0", "pkg:pypi/requests@2.31.0"),
            _make_artifact("company-auth", "1.0.0", "pkg:pypi/company-auth@1.0.0"),
        )
        sbom_path = _write_sbom(sbom, tmpdir_path)
        result_path = resolver.enrich_sbom(sbom_path)

        # Should produce a .enriched.json file
        assert result_path != sbom_path
        assert ".enriched" in result_path.name

        enriched = json.loads(result_path.read_text())

        # Public package unchanged
        pub = next(a for a in enriched["artifacts"] if a["name"] == "requests")
        assert pub["purl"] == "pkg:pypi/requests@2.31.0"

        # Private package rewritten
        priv = next(a for a in enriched["artifacts"] if a["name"] == "company-auth")
        assert priv["purl"] == "pkg:pypi/authlib@1.3.0"
        assert priv["_reachable_registry"]["resolution"] == "alias"
        assert priv["_reachable_registry"]["original_purl"] == "pkg:pypi/company-auth@1.0.0"

    @patch("reachable.collectors.vulns.purl_resolver.resolve_alias")
    @patch("reachable.collectors.vulns.purl_resolver.is_internal_package")
    def test_coverage_metadata_attached(
        self,
        mock_internal,
        mock_alias,
        resolver,
        tmpdir_path,
    ):
        mock_internal.return_value = False

        def alias_side_effect(purl):
            if "company-auth" in purl:
                return "pkg:pypi/authlib@1.3.0"
            return None

        mock_alias.side_effect = alias_side_effect

        sbom = _make_sbom(
            _make_artifact("requests", "2.31.0", "pkg:pypi/requests@2.31.0"),
            _make_artifact("company-auth", "1.0.0", "pkg:pypi/company-auth@1.0.0"),
        )
        result_path = resolver.enrich_sbom(_write_sbom(sbom, tmpdir_path))
        enriched = json.loads(result_path.read_text())

        coverage = enriched["_reachable_registry_coverage"]
        assert coverage["total_packages"] == 2
        assert coverage["alias"] == 1

    def test_offline_mode_no_rewrites(self, offline_resolver, mixed_sbom, tmpdir_path):
        """Offline mode must never call external APIs or rewrite PURLs."""
        sbom_path = _write_sbom(mixed_sbom, tmpdir_path)
        result_path = offline_resolver.enrich_sbom(sbom_path)
        # Should return original path (no changes)
        assert result_path == sbom_path

    def test_empty_artifacts_returns_original_path(self, resolver, tmpdir_path):
        sbom = {"artifacts": [], "source": {}}
        sbom_path = _write_sbom(sbom, tmpdir_path)
        assert resolver.enrich_sbom(sbom_path) == sbom_path


# ===================================================================
# get_resolution_map()
# ===================================================================


class TestGetResolutionMap:
    """Validates the resolution map shape used by lib_manager."""

    def test_alias_resolution_produces_map_entry(self, tmpdir_path):
        """An alias-resolved artifact must appear in the resolution map."""
        sbom = _make_sbom(
            _make_artifact("requests", "2.31.0", "pkg:pypi/requests@2.31.0"),
        )
        # Manually add enrichment metadata (simulating post-resolve SBOM)
        sbom["artifacts"].append(
            {
                "name": "company-auth",
                "version": "1.0.0",
                "purl": "pkg:pypi/authlib@1.3.0",
                "_reachable_registry": {
                    "resolution": "alias",
                    "original_purl": "pkg:pypi/company-auth@1.0.0",
                },
            }
        )

        sbom_path = _write_sbom(sbom, tmpdir_path)
        resolver = PURLResolver()
        rmap = resolver.get_resolution_map(sbom_path)

        assert ("python", "company-auth") in rmap
        entry = rmap[("python", "company-auth")]
        assert entry["canonical_name"] == "authlib"
        assert entry["canonical_version"] == "1.3.0"
        assert entry["canonical_purl"] == "pkg:pypi/authlib@1.3.0"
        assert entry["method"] == "alias"

    def test_hash_match_produces_map_entry(self, tmpdir_path):
        sbom = _make_sbom()
        sbom["artifacts"] = [
            {
                "name": "jinja2-mirror",
                "version": "2.11.2",
                "purl": "pkg:pypi/jinja2@2.11.2",
                "_reachable_registry": {
                    "resolution": "hash_match",
                    "original_purl": "pkg:pypi/jinja2-mirror@2.11.2",
                },
            }
        ]
        sbom_path = _write_sbom(sbom, tmpdir_path)
        rmap = PURLResolver().get_resolution_map(sbom_path)

        assert ("python", "jinja2-mirror") in rmap
        entry = rmap[("python", "jinja2-mirror")]
        assert entry["canonical_name"] == "jinja2"
        assert entry["method"] == "hash_match"

    def test_canonical_does_not_appear_in_map(self, tmpdir_path):
        """Packages that were already canonical should NOT be in the map."""
        sbom = _make_sbom(
            _make_artifact("requests", "2.31.0", "pkg:pypi/requests@2.31.0"),
        )
        sbom_path = _write_sbom(sbom, tmpdir_path)
        rmap = PURLResolver().get_resolution_map(sbom_path)
        assert len(rmap) == 0

    def test_npm_scoped_map_entry(self, tmpdir_path):
        sbom = _make_sbom()
        sbom["artifacts"] = [
            {
                "name": "@company/logger",
                "version": "2.0.0",
                "purl": "pkg:npm/winston@3.11.0",
                "_reachable_registry": {
                    "resolution": "alias",
                    "original_purl": "pkg:npm/%40company/logger@2.0.0",
                },
            }
        ]
        sbom_path = _write_sbom(sbom, tmpdir_path)
        rmap = PURLResolver().get_resolution_map(sbom_path)

        assert ("npm", "@company/logger") in rmap
        assert rmap[("npm", "@company/logger")]["canonical_name"] == "winston"

    def test_go_mirror_map_entry(self, tmpdir_path):
        sbom = _make_sbom()
        sbom["artifacts"] = [
            {
                "name": "go.company.com/mirror/golang.org/x/crypto",
                "version": "v0.21.0",
                "purl": "pkg:golang/golang.org/x/crypto@v0.21.0",
                "_reachable_registry": {
                    "resolution": "hash_match",
                    "original_purl": "pkg:golang/go.company.com/mirror/golang.org/x/crypto@v0.21.0",
                },
            }
        ]
        sbom_path = _write_sbom(sbom, tmpdir_path)
        rmap = PURLResolver().get_resolution_map(sbom_path)

        assert ("go", "go.company.com/mirror/golang.org/x/crypto") in rmap
        entry = rmap[("go", "go.company.com/mirror/golang.org/x/crypto")]
        assert entry["canonical_name"] == "golang.org/x/crypto"

    def test_maven_map_entry(self, tmpdir_path):
        sbom = _make_sbom()
        sbom["artifacts"] = [
            {
                "name": "h2",
                "version": "1.4.197",
                "purl": "pkg:maven/com.h2database/h2@1.4.197",
                "_reachable_registry": {
                    "resolution": "hash_match",
                    "original_purl": "pkg:maven/com.company.internal/h2@1.4.197",
                },
            }
        ]
        sbom_path = _write_sbom(sbom, tmpdir_path)
        rmap = PURLResolver().get_resolution_map(sbom_path)

        assert ("maven", "com.company.internal/h2") in rmap
        entry = rmap[("maven", "com.company.internal/h2")]
        assert entry["canonical_name"] == "com.h2database/h2"

    def test_gzip_input(self, tmpdir_path):
        sbom = _make_sbom()
        sbom["artifacts"] = [
            {
                "name": "company-auth",
                "version": "1.0.0",
                "purl": "pkg:pypi/authlib@1.3.0",
                "_reachable_registry": {
                    "resolution": "alias",
                    "original_purl": "pkg:pypi/company-auth@1.0.0",
                },
            }
        ]
        sbom_path = _write_sbom(sbom, tmpdir_path, gz=True)
        rmap = PURLResolver().get_resolution_map(sbom_path)
        assert ("python", "company-auth") in rmap


# ===================================================================
# Mixed-Registry Single-Pass
# ===================================================================


class TestMixedRegistrySinglePass:
    """
    Validates that a single enrich_sbom() call correctly handles a mix
    of public, alias-resolved, hash-matched, and unresolved packages.
    """

    @patch("reachable.collectors.vulns.purl_resolver.resolve_alias")
    @patch("reachable.collectors.vulns.purl_resolver.is_internal_package")
    def test_mixed_python_npm_go_maven(
        self,
        mock_internal,
        mock_alias,
        resolver,
        tmpdir_path,
    ):
        """
        4-language mixed SBOM: public + alias-resolved + genuine private.
        Alias resolver handles Python and npm; Go and Maven fall through.
        """

        def internal_side_effect(eco, name):
            return name == "internal-sdk"

        def alias_side_effect(purl):
            if "company-auth" in purl:
                return "pkg:pypi/authlib@1.3.0"
            if "%40company/logger" in purl or "@company/logger" in purl:
                return "pkg:npm/winston@3.11.0"
            return None

        mock_internal.side_effect = internal_side_effect
        mock_alias.side_effect = alias_side_effect

        sbom = _make_sbom(
            # Python public
            _make_artifact("requests", "2.31.0", "pkg:pypi/requests@2.31.0"),
            # Python private (alias → authlib)
            _make_artifact("company-auth", "1.0.0", "pkg:pypi/company-auth@1.0.0"),
            # Python genuine private (internal)
            _make_artifact("internal-sdk", "0.5.0", "pkg:pypi/internal-sdk@0.5.0"),
            # npm public
            _make_artifact("lodash", "4.17.21", "pkg:npm/lodash@4.17.21", type="npm"),
            # npm private (alias → winston)
            _make_artifact("@company/logger", "2.0.0", "pkg:npm/%40company/logger@2.0.0", type="npm"),
            # Go public
            _make_artifact("golang.org/x/net", "v0.23.0", "pkg:golang/golang.org/x/net@v0.23.0", type="go-module"),
        )

        sbom_path = _write_sbom(sbom, tmpdir_path)
        result_path = resolver.enrich_sbom(sbom_path)
        enriched = json.loads(result_path.read_text())

        arts = {a["name"]: a for a in enriched["artifacts"]}

        # Public: unchanged
        assert arts["requests"]["purl"] == "pkg:pypi/requests@2.31.0"
        assert arts["lodash"]["purl"] == "pkg:npm/lodash@4.17.21"
        assert arts["golang.org/x/net"]["purl"] == "pkg:golang/golang.org/x/net@v0.23.0"

        # Alias-resolved
        assert arts["company-auth"]["purl"] == "pkg:pypi/authlib@1.3.0"
        assert arts["@company/logger"]["purl"] == "pkg:npm/winston@3.11.0"

        # Internal
        assert arts["internal-sdk"]["_reachable_registry"]["resolution"] == "internal"

        # Coverage stats
        cov = enriched["_reachable_registry_coverage"]
        assert cov["total_packages"] == 6
        assert cov["alias"] == 2
        assert cov["internal"] == 1


# ===================================================================
# Coverage Summary (dry-run)
# ===================================================================


class TestCoverageSummary:
    @patch("reachable.collectors.vulns.purl_resolver.resolve_alias")
    @patch("reachable.collectors.vulns.purl_resolver.is_internal_package")
    def test_returns_count_by_reason(self, mock_internal, mock_alias, tmpdir_path):
        mock_internal.return_value = False
        mock_alias.return_value = None

        sbom = _make_sbom(
            _make_artifact("requests", "2.31.0", "pkg:pypi/requests@2.31.0"),
            _make_artifact("flask", "2.0.3", "pkg:pypi/flask@2.0.3"),
        )
        sbom_path = _write_sbom(sbom, tmpdir_path)
        summary = PURLResolver().get_coverage_summary(sbom_path)

        assert summary["total"] == 2
        assert summary["by_reason"].get("canonical", 0) == 2
        assert len(summary["unresolved"]) == 0
