#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.
"""
Unit tests for Phase 5: Unresolved Package Tracking.

Covers:
  - fuzzy_match module (name normalization, similarity, matching, best_guess)
  - DB operations (store, upsert, query, mark resolved)
  - PURLResolver.persist_unresolved() flow
  - CLI aliases module (show/accept/dismiss)
"""

import json
from unittest.mock import MagicMock, patch

import pytest

# ═══════════════════════════════════════════════════════════════════════════
# 1. FUZZY MATCH MODULE
# ═══════════════════════════════════════════════════════════════════════════


class TestNameNormalization:
    """Test _normalize_name stripping of private prefixes/suffixes."""

    def test_strips_scoped_prefix(self):
        from reachable.collectors.vulns.fuzzy_match import _normalize_name

        assert _normalize_name("@company/flask") == "flask"

    def test_strips_company_prefix(self):
        from reachable.collectors.vulns.fuzzy_match import _normalize_name

        assert _normalize_name("company-requests") == "requests"

    def test_strips_internal_suffix(self):
        from reachable.collectors.vulns.fuzzy_match import _normalize_name

        assert _normalize_name("redis-internal") == "redis"

    def test_strips_mirror_suffix(self):
        from reachable.collectors.vulns.fuzzy_match import _normalize_name

        assert _normalize_name("boto3-mirror") == "boto3"

    def test_strips_wrapper_suffix(self):
        from reachable.collectors.vulns.fuzzy_match import _normalize_name

        assert _normalize_name("pandas-wrapper") == "pandas"

    def test_normalizes_underscores(self):
        from reachable.collectors.vulns.fuzzy_match import _normalize_name

        assert _normalize_name("my_package") == "my-package"

    def test_normalizes_dots(self):
        from reachable.collectors.vulns.fuzzy_match import _normalize_name

        assert _normalize_name("my.package") == "my-package"

    def test_lowercases(self):
        from reachable.collectors.vulns.fuzzy_match import _normalize_name

        assert _normalize_name("MyPackage") == "mypackage"

    def test_strips_prefix_and_suffix(self):
        from reachable.collectors.vulns.fuzzy_match import _normalize_name

        assert _normalize_name("internal-flask-wrapper") == "flask"

    def test_preserves_clean_name(self):
        from reachable.collectors.vulns.fuzzy_match import _normalize_name

        assert _normalize_name("flask") == "flask"

    def test_handles_empty(self):
        from reachable.collectors.vulns.fuzzy_match import _normalize_name

        assert _normalize_name("") == ""


class TestNameSimilarity:
    """Test _name_similarity scoring."""

    def test_exact_match_returns_1(self):
        from reachable.collectors.vulns.fuzzy_match import _name_similarity

        assert _name_similarity("flask", "flask") == 1.0

    def test_exact_after_normalization(self):
        from reachable.collectors.vulns.fuzzy_match import _name_similarity

        assert _name_similarity("@corp/requests", "requests") == 1.0

    def test_substring_returns_high(self):
        from reachable.collectors.vulns.fuzzy_match import _name_similarity

        score = _name_similarity("auth", "authlib")
        assert score >= 0.8

    def test_completely_different_returns_low(self):
        from reachable.collectors.vulns.fuzzy_match import _name_similarity

        score = _name_similarity("xyzabc123", "flask")
        assert score < 0.4

    def test_go_path_last_segment(self):
        """Go packages use full paths; similarity should compare last segment."""
        from reachable.collectors.vulns.fuzzy_match import _name_similarity

        score = _name_similarity("mux", "github.com/gorilla/mux")
        assert score >= 0.8


class TestFuzzyMatch:
    """Test fuzzy_match() candidate generation."""

    def test_returns_candidates_above_threshold(self):
        from reachable.collectors.vulns.fuzzy_match import fuzzy_match

        results = fuzzy_match("company-flask", "2.0.0", "python")
        assert len(results) > 0
        assert results[0]["name"] == "flask"
        assert results[0]["confidence"] >= 0.65

    def test_returns_empty_for_garbage(self):
        from reachable.collectors.vulns.fuzzy_match import fuzzy_match

        results = fuzzy_match("xyzqwerty99999", "1.0", "python")
        assert results == []

    def test_returns_max_3_candidates(self):
        from reachable.collectors.vulns.fuzzy_match import fuzzy_match

        results = fuzzy_match("request", "1.0", "python")
        assert len(results) <= 3

    def test_sorted_by_confidence_desc(self):
        from reachable.collectors.vulns.fuzzy_match import fuzzy_match

        results = fuzzy_match("request", "1.0", "python")
        if len(results) >= 2:
            assert results[0]["confidence"] >= results[1]["confidence"]

    def test_purl_format_correct(self):
        from reachable.collectors.vulns.fuzzy_match import fuzzy_match

        results = fuzzy_match("company-flask", "2.0.0", "python")
        assert results[0]["purl"].startswith("pkg:pypi/")
        assert "@2.0.0" in results[0]["purl"]

    def test_npm_ecosystem(self):
        from reachable.collectors.vulns.fuzzy_match import fuzzy_match

        results = fuzzy_match("internal-express", "4.18.0", "npm")
        assert len(results) > 0
        assert results[0]["purl"].startswith("pkg:npm/")

    def test_custom_known_packages(self):
        from reachable.collectors.vulns.fuzzy_match import fuzzy_match

        results = fuzzy_match("my-custom", "1.0", "python", known_packages=["custom", "flask", "django"])
        # 'custom' should match 'my-custom' after normalization
        found = [r for r in results if r["name"] == "custom"]
        assert len(found) > 0

    def test_empty_ecosystem_returns_empty(self):
        from reachable.collectors.vulns.fuzzy_match import fuzzy_match

        results = fuzzy_match("something", "1.0", "nonexistent_eco")
        assert results == []


class TestBestGuess:
    """Test best_guess() single-result wrapper."""

    def test_returns_dict_for_good_match(self):
        from reachable.collectors.vulns.fuzzy_match import best_guess

        result = best_guess("company-flask", "2.0.0", "python")
        assert result is not None
        assert result["name"] == "flask"

    def test_returns_none_for_no_match(self):
        from reachable.collectors.vulns.fuzzy_match import best_guess

        result = best_guess("xyzqwerty99999", "1.0", "python")
        assert result is None


# ═══════════════════════════════════════════════════════════════════════════
# 2. DB OPERATIONS
# ═══════════════════════════════════════════════════════════════════════════


@pytest.fixture
def tmp_db(tmp_path):
    """Create a temporary RepoDatabase for testing."""
    from reachable.database.storage import RepoDatabase

    db_path = tmp_path / "test_repo.db"
    db = RepoDatabase(db_path)
    # Start a scan so _current_scan_id is set
    scan_id = db.start_scan(branch="main", commit_hash="abc123", scan_dir=str(tmp_path), version="1.0.0-test")
    return db


class TestStoreUnresolvedPackages:
    """Test RepoDatabase.store_unresolved_packages()."""

    def test_stores_packages(self, tmp_db):
        unresolved = [
            {
                "name": "company-flask",
                "version": "2.0.0",
                "ecosystem": "python",
                "purl": "pkg:pypi/company-flask@2.0.0",
                "reason": "no_hash_match",
                "fuzzy_candidates": [
                    {
                        "name": "flask",
                        "confidence": 0.95,
                        "purl": "pkg:pypi/flask@2.0.0",
                        "method": "name_similarity+version",
                    }
                ],
                "best_guess_purl": "pkg:pypi/flask@2.0.0",
                "best_guess_confidence": 0.95,
            },
        ]
        count = tmp_db.store_unresolved_packages(unresolved)
        assert count == 1

    def test_stores_multiple_packages(self, tmp_db):
        unresolved = [
            {
                "name": "pkg-a",
                "version": "1.0",
                "ecosystem": "python",
                "purl": "",
                "reason": "no_hash_match",
                "fuzzy_candidates": [],
                "best_guess_purl": None,
                "best_guess_confidence": None,
            },
            {
                "name": "pkg-b",
                "version": "2.0",
                "ecosystem": "npm",
                "purl": "",
                "reason": "no_hash_match",
                "fuzzy_candidates": [],
                "best_guess_purl": None,
                "best_guess_confidence": None,
            },
            {
                "name": "pkg-c",
                "version": "3.0",
                "ecosystem": "go",
                "purl": "",
                "reason": "alias_missing",
                "fuzzy_candidates": [],
                "best_guess_purl": None,
                "best_guess_confidence": None,
            },
        ]
        count = tmp_db.store_unresolved_packages(unresolved)
        assert count == 3

    def test_empty_list_returns_zero(self, tmp_db):
        count = tmp_db.store_unresolved_packages([])
        assert count == 0

    def test_upserts_aggregate_stats(self, tmp_db):
        pkg = {
            "name": "company-flask",
            "version": "2.0.0",
            "ecosystem": "python",
            "purl": "",
            "reason": "no_hash_match",
            "fuzzy_candidates": [],
            "best_guess_purl": "pkg:pypi/flask@2.0.0",
            "best_guess_confidence": 0.95,
        }

        # First insert
        tmp_db.store_unresolved_packages([pkg])

        # Second scan → should increment occurrence_count
        tmp_db.complete_scan(duration_seconds=1, risk_score=0, risk_level="LOW")
        scan2 = tmp_db.start_scan(branch="main", commit_hash="def456", scan_dir="/tmp/test2", version="1.0.0-test")
        tmp_db.store_unresolved_packages([pkg])

        stats = tmp_db.get_unresolved_stats()
        assert len(stats) == 1
        assert stats[0]["occurrence_count"] == 2


class TestGetUnresolvedStats:
    """Test RepoDatabase.get_unresolved_stats()."""

    def test_returns_ranked_by_occurrence(self, tmp_db):
        pkgs = [
            {
                "name": "pkg-a",
                "version": "1.0",
                "ecosystem": "python",
                "purl": "",
                "reason": "no_hash_match",
                "fuzzy_candidates": [],
                "best_guess_purl": None,
                "best_guess_confidence": None,
            },
            {
                "name": "pkg-b",
                "version": "1.0",
                "ecosystem": "python",
                "purl": "",
                "reason": "no_hash_match",
                "fuzzy_candidates": [],
                "best_guess_purl": None,
                "best_guess_confidence": None,
            },
        ]
        tmp_db.store_unresolved_packages(pkgs)
        stats = tmp_db.get_unresolved_stats()
        assert len(stats) == 2

    def test_excludes_resolved_by_default(self, tmp_db):
        pkgs = [
            {
                "name": "resolved-pkg",
                "version": "1.0",
                "ecosystem": "python",
                "purl": "",
                "reason": "no_hash_match",
                "fuzzy_candidates": [],
                "best_guess_purl": None,
                "best_guess_confidence": None,
            },
        ]
        tmp_db.store_unresolved_packages(pkgs)
        tmp_db.mark_unresolved_resolved("resolved-pkg", "1.0", "python", resolved_by="alias")

        stats = tmp_db.get_unresolved_stats(resolved=False)
        assert len(stats) == 0

    def test_includes_resolved_when_flag_set(self, tmp_db):
        pkgs = [
            {
                "name": "resolved-pkg",
                "version": "1.0",
                "ecosystem": "python",
                "purl": "",
                "reason": "no_hash_match",
                "fuzzy_candidates": [],
                "best_guess_purl": None,
                "best_guess_confidence": None,
            },
        ]
        tmp_db.store_unresolved_packages(pkgs)
        tmp_db.mark_unresolved_resolved("resolved-pkg", "1.0", "python", resolved_by="alias")

        stats = tmp_db.get_unresolved_stats(resolved=True)
        assert len(stats) == 1
        assert stats[0]["resolved"] == 1


class TestMarkUnresolvedResolved:
    """Test RepoDatabase.mark_unresolved_resolved()."""

    def test_marks_existing_package(self, tmp_db):
        pkgs = [
            {
                "name": "my-pkg",
                "version": "1.0",
                "ecosystem": "python",
                "purl": "",
                "reason": "no_hash_match",
                "fuzzy_candidates": [],
                "best_guess_purl": None,
                "best_guess_confidence": None,
            },
        ]
        tmp_db.store_unresolved_packages(pkgs)
        ok = tmp_db.mark_unresolved_resolved("my-pkg", "1.0", "python", resolved_by="alias")
        assert ok is True

    def test_returns_false_for_nonexistent(self, tmp_db):
        ok = tmp_db.mark_unresolved_resolved("ghost-pkg", "1.0", "python")
        assert ok is False

    def test_idempotent_mark(self, tmp_db):
        pkgs = [
            {
                "name": "my-pkg",
                "version": "1.0",
                "ecosystem": "python",
                "purl": "",
                "reason": "no_hash_match",
                "fuzzy_candidates": [],
                "best_guess_purl": None,
                "best_guess_confidence": None,
            },
        ]
        tmp_db.store_unresolved_packages(pkgs)
        tmp_db.mark_unresolved_resolved("my-pkg", "1.0", "python")
        # Second mark should return False (already resolved)
        ok = tmp_db.mark_unresolved_resolved("my-pkg", "1.0", "python")
        assert ok is False


class TestGetUnresolvedForScan:
    """Test RepoDatabase.get_unresolved_for_scan()."""

    def test_returns_packages_for_current_scan(self, tmp_db):
        pkgs = [
            {
                "name": "pkg-x",
                "version": "1.0",
                "ecosystem": "npm",
                "purl": "pkg:npm/pkg-x@1.0",
                "reason": "no_hash_match",
                "fuzzy_candidates": [{"name": "x", "confidence": 0.8}],
                "best_guess_purl": "pkg:npm/x@1.0",
                "best_guess_confidence": 0.8,
            },
        ]
        tmp_db.store_unresolved_packages(pkgs)
        results = tmp_db.get_unresolved_for_scan()
        assert len(results) == 1
        assert results[0]["name"] == "pkg-x"
        assert results[0]["ecosystem"] == "npm"
        assert isinstance(results[0]["fuzzy_candidates"], list)


# ═══════════════════════════════════════════════════════════════════════════
# 3. PURLResolver.persist_unresolved() FLOW
# ═══════════════════════════════════════════════════════════════════════════


class TestPersistUnresolved:
    """Test PURLResolver.persist_unresolved() end-to-end."""

    @pytest.fixture
    def enriched_sbom(self, tmp_path):
        """Create a fake enriched SBOM with unresolved packages."""
        sbom = {
            "artifacts": [],
            "_reachable_registry_coverage": {
                "total_packages": 10,
                "resolved": 8,
                "unresolved_packages": [
                    {"name": "company-flask", "version": "2.0.0", "purl": "pkg:pypi/company-flask@2.0.0"},
                    {"name": "@acme/express", "version": "4.18.0", "purl": "pkg:npm/%40acme/express@4.18.0"},
                ],
            },
        }
        sbom_path = tmp_path / "sbom-enriched.json"
        sbom_path.write_text(json.dumps(sbom))
        return sbom_path

    @pytest.fixture
    def enriched_sbom_gz(self, tmp_path):
        """Create a gzip-compressed enriched SBOM."""
        import gzip

        sbom = {
            "artifacts": [],
            "_reachable_registry_coverage": {
                "total_packages": 5,
                "resolved": 4,
                "unresolved_packages": [
                    {"name": "mirror-redis", "version": "4.0.0", "purl": "pkg:pypi/mirror-redis@4.0.0"},
                ],
            },
        }
        sbom_path = tmp_path / "sbom-enriched.json.gz"
        with gzip.open(sbom_path, "wt") as f:
            json.dump(sbom, f)
        return sbom_path

    def test_persist_returns_enriched_list(self, enriched_sbom):
        from reachable.collectors.vulns.purl_resolver import PURLResolver

        resolver = PURLResolver()
        result = resolver.persist_unresolved(enriched_sbom)
        assert isinstance(result, list)
        assert len(result) == 2
        assert result[0]["name"] == "company-flask"
        assert result[0]["ecosystem"] in ("python", "pypi")

    def test_persist_includes_fuzzy_candidates(self, enriched_sbom):
        from reachable.collectors.vulns.purl_resolver import PURLResolver

        resolver = PURLResolver()
        result = resolver.persist_unresolved(enriched_sbom)
        # company-flask should fuzzy-match to flask
        flask_entry = [r for r in result if r["name"] == "company-flask"][0]
        assert "fuzzy_candidates" in flask_entry
        assert flask_entry["best_guess_purl"] is not None
        assert flask_entry["best_guess_confidence"] is not None
        assert flask_entry["best_guess_confidence"] >= 0.65

    def test_persist_handles_gz(self, enriched_sbom_gz):
        from reachable.collectors.vulns.purl_resolver import PURLResolver

        resolver = PURLResolver()
        result = resolver.persist_unresolved(enriched_sbom_gz)
        assert len(result) == 1
        assert result[0]["name"] == "mirror-redis"

    def test_persist_writes_to_db(self, enriched_sbom, tmp_db):
        from reachable.collectors.vulns.purl_resolver import PURLResolver

        resolver = PURLResolver()
        result = resolver.persist_unresolved(enriched_sbom, db=tmp_db)
        assert len(result) == 2

        # Verify DB has the data
        stored = tmp_db.get_unresolved_for_scan()
        assert len(stored) == 2

    def test_persist_writes_json_log(self, enriched_sbom):
        from reachable.collectors.vulns.purl_resolver import PURLResolver

        resolver = PURLResolver()
        resolver.persist_unresolved(enriched_sbom)

        log_path = enriched_sbom.parent / "unresolved-packages.json"
        assert log_path.exists()
        log_data = json.loads(log_path.read_text())
        assert log_data["unresolved"] == 2
        assert log_data["total_packages"] == 10
        assert log_data["coverage_pct"] == 80.0

    def test_persist_no_unresolved_returns_empty(self, tmp_path):
        """SBOM with no unresolved packages → empty result."""
        from reachable.collectors.vulns.purl_resolver import PURLResolver

        sbom = {
            "artifacts": [],
            "_reachable_registry_coverage": {
                "total_packages": 5,
                "resolved": 5,
                "unresolved_packages": [],
            },
        }
        sbom_path = tmp_path / "sbom-clean.json"
        sbom_path.write_text(json.dumps(sbom))

        resolver = PURLResolver()
        result = resolver.persist_unresolved(sbom_path)
        assert result == []

    def test_persist_no_coverage_key_returns_empty(self, tmp_path):
        """SBOM without _reachable_registry_coverage → empty result."""
        from reachable.collectors.vulns.purl_resolver import PURLResolver

        sbom = {"artifacts": []}
        sbom_path = tmp_path / "sbom-no-coverage.json"
        sbom_path.write_text(json.dumps(sbom))

        resolver = PURLResolver()
        result = resolver.persist_unresolved(sbom_path)
        assert result == []


# ═══════════════════════════════════════════════════════════════════════════
# 4. CLI ALIASES MODULE
# ═══════════════════════════════════════════════════════════════════════════


class TestAliasesShow:
    """Test reachctl aliases show output."""

    @patch("reachable.cli.aliases._get_db")
    def test_show_prints_unresolved(self, mock_get_db, capsys):
        from reachable.cli.aliases import _cmd_show

        mock_db = MagicMock()
        mock_db.get_unresolved_stats.return_value = [
            {
                "name": "company-flask",
                "version": "2.0.0",
                "ecosystem": "python",
                "occurrence_count": 5,
                "best_guess_purl": "pkg:pypi/flask@2.0.0",
                "best_guess_confidence": 0.95,
                "fuzzy_candidates": [],
                "resolved": 0,
                "first_seen": "2026-01-01",
                "last_seen": "2026-02-26",
            },
        ]
        mock_get_db.return_value = mock_db

        _cmd_show()
        captured = capsys.readouterr()
        assert "company-flask" in captured.out
        assert "2.0.0" in captured.out

    @patch("reachable.cli.aliases._get_db")
    def test_show_empty_prints_message(self, mock_get_db, capsys):
        from reachable.cli.aliases import _cmd_show

        mock_db = MagicMock()
        mock_db.get_unresolved_stats.return_value = []
        mock_get_db.return_value = mock_db

        _cmd_show()
        captured = capsys.readouterr()
        # Should indicate no unresolved packages
        assert "unresolved" in captured.out.lower() or "no " in captured.out.lower() or "clean" in captured.out.lower()
