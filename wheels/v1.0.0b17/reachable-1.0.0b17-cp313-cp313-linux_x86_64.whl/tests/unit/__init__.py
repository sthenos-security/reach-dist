# Unit tests — synthetic data, mocked APIs, no Docker required
