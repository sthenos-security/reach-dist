#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.

"""
Local Wheel Signing Smoke Test

Tests that wheel signing and verification works locally (development mode).
Skips gracefully when running from an installed wheel (scripts/ not present).

Run with:
    pytest tests/test_local_signing_smoke.py -v
"""

import shutil
import subprocess
import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))


class TestLocalSigning(unittest.TestCase):
    """Test local wheel signing and verification"""

    @classmethod
    def setUpClass(cls):
        """Check prerequisites"""
        cls.script = Path(__file__).parent.parent / "scripts" / "test-local-signing.sh"
        cls.cosign_installed = shutil.which("cosign") is not None

    @unittest.skipUnless(
        (Path(__file__).parent.parent / "scripts" / "test-local-signing.sh").exists(),
        "scripts/ not present (installed wheel — not a source checkout)",
    )
    def test_signing_script_exists(self):
        """Signing script should exist in source checkout"""
        self.assertTrue(self.script.exists())

    @unittest.skipUnless(
        (Path(__file__).parent.parent / "scripts" / "test-local-signing.sh").exists(),
        "scripts/ not present (installed wheel — not a source checkout)",
    )
    @unittest.skipUnless(shutil.which("cosign"), "cosign not installed")
    def test_local_signing_workflow(self):
        """Complete local signing workflow should work"""

        print("\n" + "=" * 70)
        print("RUNNING LOCAL SIGNING SMOKE TEST")
        print("=" * 70)

        result = subprocess.run(["bash", str(self.script)], capture_output=True, text=True, timeout=120)

        print("\n--- Script Output ---")
        print(result.stdout)
        if result.stderr:
            print("--- Script Errors ---")
            print(result.stderr)
        print("=" * 70)

        self.assertEqual(result.returncode, 0)

        output = result.stdout + result.stderr
        self.assertIn("Built:", output)
        self.assertIn("Signed:", output)
        self.assertIn("SUCCESS", output)
        self.assertIn("COMPLETE WORKFLOW VERIFIED", output)


if __name__ == "__main__":
    unittest.main()
