#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.

"""
Tests for Secret Loader Detector (Policy SECRET-REACH-001)

Tests detection of:
1. Explicit env loaders (os.getenv, process.env, os.Getenv, etc.)
2. SDK implicit loaders (boto3, google-auth, azure-identity, stripe, etc.)
3. Config file loaders (yaml, json, ConfigParser, viper)
4. Private key loaders (crypto libraries, jwt signing)
5. Database URL loaders

Reference: secret_risk_classification.txt
"""

import tempfile
from pathlib import Path

import pytest

from reachable.collectors.secrets.loader import LoadableStatus, LoaderType, SecretLoaderDetector, normalize_secret_name

# =============================================================================
# FIXTURES - Test code samples for each language
# =============================================================================

PYTHON_TEST_CODE = '''
import os
import boto3
from google.cloud import storage
from azure.identity import DefaultAzureCredential
import stripe
import openai
from dotenv import load_dotenv

# Module-level (import-time) loaders
DATABASE_URL = os.getenv("DATABASE_URL")
API_KEY = os.environ.get("API_KEY")
JWT_SECRET = os.environ["JWT_SECRET"]

# Load dotenv
load_dotenv()

def load_config():
    """Function-level loaders"""
    password = os.getenv("DB_PASSWORD")
    aws_key = os.environ.get("AWS_SECRET_ACCESS_KEY")
    return password

class ConfigManager:
    def __init__(self):
        self.secret = os.getenv("CLASS_SECRET")

# SDK implicit loaders
def upload_to_s3():
    """boto3 auto-loads AWS_ACCESS_KEY_ID, AWS_SECRET_ACCESS_KEY"""
    client = boto3.client("s3")

def gcp_upload():
    """google.auth.default auto-loads GOOGLE_APPLICATION_CREDENTIALS"""
    import google.auth
    creds, project = google.auth.default()

def azure_auth():
    """DefaultAzureCredential auto-loads AZURE_CLIENT_ID, AZURE_CLIENT_SECRET, AZURE_TENANT_ID"""
    credential = DefaultAzureCredential()

# Stripe SDK
stripe.api_key = os.getenv("STRIPE_SECRET_KEY")

# OpenAI SDK
def get_openai():
    openai.api_key = os.getenv("OPENAI_API_KEY")
    client = openai.OpenAI()

# Private key loading
def load_private_key():
    with open("private_key.pem") as f:
        key = f.read()
    from cryptography.hazmat.primitives.serialization import load_pem_private_key
    return load_pem_private_key(key, password=None)

# JWT signing
import jwt
def sign_token(data, secret_key):
    return jwt.encode(data, key=secret_key, algorithm="RS256")

# Database
from sqlalchemy import create_engine
def get_db():
    return create_engine(os.getenv("DATABASE_URL"))
'''

JAVASCRIPT_TEST_CODE = """
require('dotenv').config();

// Explicit env loaders
const db_url = process.env.DATABASE_URL;
const api_key = process.env.API_KEY;
const jwt_secret = process.env['JWT_SECRET'];

// Destructuring
const { STRIPE_KEY, GITHUB_TOKEN, SLACK_TOKEN } = process.env;

// Stripe SDK
const stripe = require('stripe')(process.env.STRIPE_SECRET_KEY);

// Private key loading
const fs = require('fs');
const privateKey = fs.readFileSync('private_key.pem');

// Crypto
const crypto = require('crypto');
const key = crypto.createPrivateKey(privateKey);

function getConfig() {
    return process.env.CONFIG_SECRET;
}

class ConfigManager {
    constructor() {
        this.secret = process.env.CLASS_SECRET;
    }
}
"""

GO_TEST_CODE = """
package main

import (
    "os"
    "io/ioutil"
    "github.com/spf13/viper"
    "crypto/x509"
)

func main() {
    // Explicit env loaders
    dbUrl := os.Getenv("DATABASE_URL")
    apiKey, _ := os.LookupEnv("API_KEY")

    // Viper config
    viper.AutomaticEnv()
    viper.BindEnv("JWT_SECRET")
    secret := viper.GetString("jwt_secret")

    // Private key loading
    keyData, _ := ioutil.ReadFile("private_key.pem")
    key, _ := x509.ParsePKCS8PrivateKey(keyData)
}

func loadConfig() string {
    return os.Getenv("CONFIG_SECRET")
}
"""

JAVA_TEST_CODE = """
import java.util.Properties;

public class App {
    // Class-level
    private static String DB_URL = System.getenv("DATABASE_URL");

    public static void main(String[] args) {
        String apiKey = System.getenv("API_KEY");
        String jwtSecret = System.getProperty("jwt.secret");
    }

    public String getConfig() {
        return System.getenv("CONFIG_SECRET");
    }
}
"""

RUBY_TEST_CODE = """
# Explicit env loaders
db_url = ENV['DATABASE_URL']
api_key = ENV.fetch('API_KEY')
jwt_secret = ENV.fetch('JWT_SECRET', 'default')

def load_config
  ENV['CONFIG_SECRET']
end

class ConfigManager
  def initialize
    @secret = ENV['CLASS_SECRET']
  end
end
"""

RUST_TEST_CODE = """
use std::env;

fn main() {
    let db_url = std::env::var("DATABASE_URL").unwrap();
    let api_key = env::var("API_KEY").unwrap_or_default();
}

fn load_config() -> String {
    std::env::var("CONFIG_SECRET").unwrap()
}
"""

CSHARP_TEST_CODE = """
using System;
using Microsoft.Extensions.Configuration;

public class App
{
    private static string DbUrl = Environment.GetEnvironmentVariable("DATABASE_URL");

    public static void Main(string[] args)
    {
        var apiKey = Environment.GetEnvironmentVariable("API_KEY");
        var config = Configuration["JWT_SECRET"];
    }

    public string GetConfig()
    {
        return Environment.GetEnvironmentVariable("CONFIG_SECRET");
    }
}
"""


# =============================================================================
# TEST HELPERS
# =============================================================================


@pytest.fixture
def temp_project():
    """Create a temporary project with test files"""
    with tempfile.TemporaryDirectory() as tmpdir:
        tmpdir = Path(tmpdir)

        # Create test files
        (tmpdir / "app.py").write_text(PYTHON_TEST_CODE)
        (tmpdir / "server.js").write_text(JAVASCRIPT_TEST_CODE)
        (tmpdir / "main.go").write_text(GO_TEST_CODE)
        (tmpdir / "App.java").write_text(JAVA_TEST_CODE)
        (tmpdir / "config.rb").write_text(RUBY_TEST_CODE)
        (tmpdir / "main.rs").write_text(RUST_TEST_CODE)
        (tmpdir / "App.cs").write_text(CSHARP_TEST_CODE)

        yield tmpdir


@pytest.fixture
def detector():
    """Create a detector instance"""
    return SecretLoaderDetector(verbose=False)


# =============================================================================
# UNIT TESTS
# =============================================================================


class TestNormalizeSecretName:
    """Test secret name normalization"""

    def test_uppercase(self):
        assert normalize_secret_name("database_url") == "DATABASE_URL"

    def test_hyphens_to_underscores(self):
        assert normalize_secret_name("api-key") == "API_KEY"

    def test_strip_whitespace(self):
        assert normalize_secret_name("  SECRET  ") == "SECRET"

    def test_already_normalized(self):
        assert normalize_secret_name("DATABASE_URL") == "DATABASE_URL"


class TestPythonLoaderDetection:
    """Test Python loader pattern detection"""

    def test_os_getenv(self, detector, temp_project):
        result = detector.scan(temp_project)

        # Should find DATABASE_URL from os.getenv
        assert "DATABASE_URL" in result.secrets_with_loaders
        loaders = result.secrets_with_loaders["DATABASE_URL"]
        assert any(l.pattern_matched == "os.getenv" for l in loaders)

    def test_os_environ_get(self, detector, temp_project):
        result = detector.scan(temp_project)

        # Should find API_KEY from os.environ.get
        assert "API_KEY" in result.secrets_with_loaders
        loaders = result.secrets_with_loaders["API_KEY"]
        assert any(l.pattern_matched == "os.environ.get" for l in loaders)

    def test_os_environ_bracket(self, detector, temp_project):
        result = detector.scan(temp_project)

        # Should find JWT_SECRET from os.environ[]
        assert "JWT_SECRET" in result.secrets_with_loaders
        loaders = result.secrets_with_loaders["JWT_SECRET"]
        assert any(l.pattern_matched == "os.environ[]" for l in loaders)

    def test_dotenv_load(self, detector, temp_project):
        result = detector.scan(temp_project)

        # Should detect load_dotenv()
        dotenv_loaders = [l for l in result.loaders if l.loader_type == LoaderType.DOTENV]
        assert len(dotenv_loaders) > 0

    def test_function_extraction(self, detector, temp_project):
        result = detector.scan(temp_project)

        # DB_PASSWORD should be in load_config function
        assert "DB_PASSWORD" in result.secrets_with_loaders
        loaders = result.secrets_with_loaders["DB_PASSWORD"]
        assert any(l.function_name == "load_config" for l in loaders)

    def test_class_extraction(self, detector, temp_project):
        result = detector.scan(temp_project)

        # CLASS_SECRET should be in ConfigManager class
        assert "CLASS_SECRET" in result.secrets_with_loaders
        loaders = result.secrets_with_loaders["CLASS_SECRET"]
        assert any(l.class_name == "ConfigManager" for l in loaders)

    def test_import_time_detection(self, detector, temp_project):
        result = detector.scan(temp_project)

        # DATABASE_URL is at module level (import-time)
        loaders = result.secrets_with_loaders.get("DATABASE_URL", [])
        module_level = [l for l in loaders if l.is_import_time]
        assert len(module_level) > 0


class TestSDKImplicitLoaders:
    """Test SDK implicit loader detection"""

    def test_boto3_aws(self, detector, temp_project):
        result = detector.scan(temp_project)

        # Should detect boto3 and its implicit secrets
        aws_loaders = [l for l in result.loaders if l.loader_type == LoaderType.SDK_AWS]
        assert len(aws_loaders) > 0

        # Should have AWS implicit secrets
        assert any("AWS_ACCESS_KEY_ID" in l.sdk_secrets for l in aws_loaders)
        assert any("AWS_SECRET_ACCESS_KEY" in l.sdk_secrets for l in aws_loaders)

    def test_google_auth_gcp(self, detector, temp_project):
        result = detector.scan(temp_project)

        # Should detect google.auth.default
        gcp_loaders = [l for l in result.loaders if l.loader_type == LoaderType.SDK_GCP]
        assert len(gcp_loaders) > 0

        # Should have GCP implicit secrets
        assert any("GOOGLE_APPLICATION_CREDENTIALS" in l.sdk_secrets for l in gcp_loaders)

    def test_azure_identity(self, detector, temp_project):
        result = detector.scan(temp_project)

        # Should detect DefaultAzureCredential
        azure_loaders = [l for l in result.loaders if l.loader_type == LoaderType.SDK_AZURE]
        assert len(azure_loaders) > 0

        # Should have Azure implicit secrets
        assert any("AZURE_CLIENT_ID" in l.sdk_secrets for l in azure_loaders)
        assert any("AZURE_CLIENT_SECRET" in l.sdk_secrets for l in azure_loaders)

    def test_stripe_sdk(self, detector, temp_project):
        result = detector.scan(temp_project)

        # Should detect stripe.api_key
        stripe_loaders = [l for l in result.loaders if l.loader_type == LoaderType.SDK_STRIPE]
        assert len(stripe_loaders) > 0

    def test_openai_sdk(self, detector, temp_project):
        result = detector.scan(temp_project)

        # Should detect openai usage
        openai_loaders = [l for l in result.loaders if l.loader_type == LoaderType.SDK_OPENAI]
        assert len(openai_loaders) > 0

        # Should have OpenAI implicit secrets
        assert any("OPENAI_API_KEY" in l.sdk_secrets for l in openai_loaders)

    def test_sdk_implicit_secrets_index(self, detector, temp_project):
        result = detector.scan(temp_project)

        # SDK implicit secrets should be indexed
        assert len(result.sdk_implicit_secrets) > 0
        assert "sdk_aws" in result.sdk_implicit_secrets


class TestPrivateKeyLoaders:
    """Test private key loader detection"""

    def test_open_pem_file(self, detector, temp_project):
        result = detector.scan(temp_project)

        # Should detect open("private_key.pem")
        key_loaders = [l for l in result.loaders if l.loader_type == LoaderType.PRIVATE_KEY_FILE]
        assert len(key_loaders) > 0

    def test_jwt_encode(self, detector, temp_project):
        result = detector.scan(temp_project)

        # Should detect jwt.encode with key=
        jwt_loaders = [l for l in result.loaders if l.loader_type == LoaderType.JWT_SIGNING]
        assert len(jwt_loaders) > 0


class TestJavaScriptLoaderDetection:
    """Test JavaScript/TypeScript loader detection"""

    def test_process_env_dot(self, detector, temp_project):
        result = detector.scan(temp_project)

        # Should find DATABASE_URL from process.env.DATABASE_URL
        assert "DATABASE_URL" in result.secrets_with_loaders

    def test_process_env_bracket(self, detector, temp_project):
        result = detector.scan(temp_project)

        # Should find JWT_SECRET from process.env['JWT_SECRET']
        assert "JWT_SECRET" in result.secrets_with_loaders

    def test_destructuring(self, detector, temp_project):
        result = detector.scan(temp_project)

        # Should find destructured vars
        assert "STRIPE_KEY" in result.secrets_with_loaders
        assert "GITHUB_TOKEN" in result.secrets_with_loaders

    @pytest.mark.skip(reason="JavaScript dotenv detection not yet implemented - pattern is in Python section")
    def test_dotenv_config(self, detector, temp_project):
        result = detector.scan(temp_project)

        # Should detect require('dotenv').config()
        # NOTE: Currently the dotenv pattern for JS is in PYTHON_DOTENV_PATTERNS
        # but only JAVASCRIPT_ENV_PATTERNS is scanned for JS files
        dotenv_loaders = [
            l for l in result.loaders if l.loader_type == LoaderType.DOTENV and l.language == "javascript"
        ]
        assert len(dotenv_loaders) > 0

    def test_fs_readfilesync(self, detector, temp_project):
        result = detector.scan(temp_project)

        # Should detect fs.readFileSync for key files
        key_loaders = [
            l for l in result.loaders if l.loader_type == LoaderType.PRIVATE_KEY_FILE and l.language == "javascript"
        ]
        assert len(key_loaders) > 0


class TestGoLoaderDetection:
    """Test Go loader detection"""

    def test_os_getenv(self, detector, temp_project):
        result = detector.scan(temp_project)

        # Should find DATABASE_URL from os.Getenv
        assert "DATABASE_URL" in result.secrets_with_loaders
        go_loaders = [l for l in result.secrets_with_loaders["DATABASE_URL"] if l.language == "go"]
        assert len(go_loaders) > 0

    def test_os_lookupenv(self, detector, temp_project):
        result = detector.scan(temp_project)

        # Should find API_KEY from os.LookupEnv
        assert "API_KEY" in result.secrets_with_loaders

    def test_viper_getstring(self, detector, temp_project):
        result = detector.scan(temp_project)

        # Should detect viper.GetString
        viper_loaders = [l for l in result.loaders if l.loader_type == LoaderType.VIPER]
        assert len(viper_loaders) > 0

    def test_viper_automaticenv(self, detector, temp_project):
        result = detector.scan(temp_project)

        # Should detect viper.AutomaticEnv()
        auto_env_loaders = [l for l in result.loaders if l.pattern_matched == "viper.AutomaticEnv"]
        assert len(auto_env_loaders) > 0

    def test_viper_bindenv(self, detector, temp_project):
        result = detector.scan(temp_project)

        # Should detect viper.BindEnv
        bind_loaders = [l for l in result.loaders if l.pattern_matched == "viper.BindEnv"]
        assert len(bind_loaders) > 0


class TestJavaLoaderDetection:
    """Test Java loader detection"""

    def test_system_getenv(self, detector, temp_project):
        result = detector.scan(temp_project)

        # Should find DATABASE_URL, API_KEY from System.getenv
        java_loaders = [l for l in result.loaders if l.language == "java"]
        env_loaders = [l for l in java_loaders if l.pattern_matched == "System.getenv"]
        assert len(env_loaders) > 0

    def test_system_getproperty(self, detector, temp_project):
        result = detector.scan(temp_project)

        # Should detect System.getProperty
        java_loaders = [l for l in result.loaders if l.language == "java"]
        prop_loaders = [l for l in java_loaders if l.pattern_matched == "System.getProperty"]
        assert len(prop_loaders) > 0


class TestRubyLoaderDetection:
    """Test Ruby loader detection"""

    def test_env_bracket(self, detector, temp_project):
        result = detector.scan(temp_project)

        # Should find DATABASE_URL from ENV[]
        ruby_loaders = [l for l in result.loaders if l.language == "ruby"]
        bracket_loaders = [l for l in ruby_loaders if l.pattern_matched == "ENV[]"]
        assert len(bracket_loaders) > 0

    def test_env_fetch(self, detector, temp_project):
        result = detector.scan(temp_project)

        # Should detect ENV.fetch
        ruby_loaders = [l for l in result.loaders if l.language == "ruby"]
        fetch_loaders = [l for l in ruby_loaders if l.pattern_matched == "ENV.fetch"]
        assert len(fetch_loaders) > 0


class TestRustLoaderDetection:
    """Test Rust loader detection"""

    def test_std_env_var(self, detector, temp_project):
        result = detector.scan(temp_project)

        # Should find DATABASE_URL from std::env::var
        rust_loaders = [l for l in result.loaders if l.language == "rust"]
        env_loaders = [l for l in rust_loaders if "env::var" in l.pattern_matched]
        assert len(env_loaders) > 0


class TestCSharpLoaderDetection:
    """Test C# loader detection"""

    def test_getenvironmentvariable(self, detector, temp_project):
        result = detector.scan(temp_project)

        # Should detect Environment.GetEnvironmentVariable
        csharp_loaders = [l for l in result.loaders if l.language == "csharp"]
        env_loaders = [l for l in csharp_loaders if l.pattern_matched == "GetEnvironmentVariable"]
        assert len(env_loaders) > 0

    def test_configuration_bracket(self, detector, temp_project):
        result = detector.scan(temp_project)

        # Should detect Configuration[]
        csharp_loaders = [l for l in result.loaders if l.language == "csharp"]
        config_loaders = [l for l in csharp_loaders if l.pattern_matched == "Configuration[]"]
        assert len(config_loaders) > 0


class TestReachabilityAnalysis:
    """Test reachability analysis with call graph"""

    def test_analyze_with_empty_call_graph(self, detector, temp_project):
        result = detector.scan(temp_project)

        # Analyze with empty call graph
        result = detector.analyze_reachability(result, call_graph={}, reachable_functions=set(), entrypoints=set())

        # Import-time loaders should be marked reachable
        import_time_loaders = [l for l in result.loaders if l.is_import_time]
        for loader in import_time_loaders:
            assert loader.is_reachable == True

    def test_analyze_with_reachable_function(self, detector, temp_project):
        result = detector.scan(temp_project)

        # Analyze with load_config in reachable set
        result = detector.analyze_reachability(
            result, call_graph={}, reachable_functions={"load_config", "app.load_config"}, entrypoints={"main"}
        )

        # DB_PASSWORD loader should be reachable
        if "DB_PASSWORD" in result.secrets_with_loaders:
            assert "DB_PASSWORD" in result.reachable_secrets

    def test_secret_status_aggregation(self, detector, temp_project):
        result = detector.scan(temp_project)

        # Analyze
        result = detector.analyze_reachability(result, call_graph={}, reachable_functions=set(), entrypoints=set())

        # Check status aggregation
        for secret_name, loaders in result.secrets_with_loaders.items():
            # Should have loadable status = YES
            assert result.secret_loadable_status.get(secret_name) == LoadableStatus.YES


class TestApplyToSecrets:
    """Test applying loader results to secret findings"""

    def test_apply_loadable_status(self, detector, temp_project):
        result = detector.scan(temp_project)

        # Mock secret findings
        secret_findings = [
            {"key": "DATABASE_URL", "is_actual_secret": True},
            {"key": "UNKNOWN_SECRET", "is_actual_secret": True},
        ]

        # Apply
        updated = detector.apply_to_secrets(result, secret_findings)

        # DATABASE_URL should be marked loadable
        db_finding = next(f for f in updated if f["key"] == "DATABASE_URL")
        assert db_finding["loadable"] == "yes"

        # UNKNOWN_SECRET should not be loadable
        unknown_finding = next(f for f in updated if f["key"] == "UNKNOWN_SECRET")
        assert unknown_finding["loadable"] == "no"

    def test_apply_sdk_implicit_secrets(self, detector, temp_project):
        result = detector.scan(temp_project)

        # Mock secret findings for SDK secrets
        secret_findings = [
            {"key": "AWS_ACCESS_KEY_ID", "is_actual_secret": True},
            {"key": "AWS_SECRET_ACCESS_KEY", "is_actual_secret": True},
        ]

        # Apply
        updated = detector.apply_to_secrets(result, secret_findings)

        # AWS secrets should be marked loadable via SDK
        aws_finding = next(f for f in updated if f["key"] == "AWS_ACCESS_KEY_ID")
        assert aws_finding["loadable"] == "yes"


class TestResultSerialization:
    """Test result serialization"""

    def test_to_dict(self, detector, temp_project):
        result = detector.scan(temp_project)

        data = result.to_dict()

        assert "policy" in data
        assert data["policy"] == "SECRET-REACH-001"
        assert "total_files_scanned" in data
        assert "total_loaders_found" in data
        assert "loaders" in data
        assert "secrets_with_loaders" in data
        assert "summary" in data

    def test_loader_finding_to_dict(self, detector, temp_project):
        result = detector.scan(temp_project)

        if result.loaders:
            loader_dict = result.loaders[0].to_dict()

            assert "file" in loader_dict
            assert "line" in loader_dict
            assert "loader_type" in loader_dict
            assert "secret_names" in loader_dict
            assert "pattern" in loader_dict
            assert "language" in loader_dict


# =============================================================================
# SMOKE TESTS
# =============================================================================


class TestSmokeTests:
    """Quick smoke tests for basic functionality"""

    def test_detector_instantiation(self):
        detector = SecretLoaderDetector(verbose=False)
        assert detector is not None

    def test_scan_empty_directory(self, detector):
        with tempfile.TemporaryDirectory() as tmpdir:
            result = detector.scan(Path(tmpdir))
            assert result.total_files_scanned == 0
            assert result.total_loaders_found == 0

    def test_scan_nonexistent_directory(self, detector):
        result = detector.scan(Path("/nonexistent/path"))
        assert len(result.errors) > 0

    def test_all_loader_types_defined(self):
        # Ensure all expected loader types exist
        expected_types = [
            "ENV_VAR",
            "DOTENV",
            "CONFIG_FILE",
            "SDK_AWS",
            "SDK_GCP",
            "SDK_AZURE",
            "SDK_STRIPE",
            "SDK_TWILIO",
            "SDK_SENDGRID",
            "SDK_OPENAI",
            "SDK_GITHUB",
            "SDK_SLACK",
            "PRIVATE_KEY_FILE",
            "JWT_SIGNING",
            "SSH_KEY",
            "DATABASE_URL",
            "VIPER",
            "SPRING",
            "UNKNOWN",
        ]
        for type_name in expected_types:
            assert hasattr(LoaderType, type_name), f"Missing LoaderType: {type_name}"

    def test_scan_performance(self, detector, temp_project):
        """Ensure scan completes in reasonable time"""
        result = detector.scan(temp_project)
        assert result.scan_time_ms < 5000  # Should complete in < 5 seconds


# =============================================================================
# INTEGRATION TESTS
# =============================================================================


class TestSecretClassificationIntegration:
    """
    Integration tests verifying we can detect all secret types from
    secret_risk_classification.txt
    """

    def test_private_key_detection(self, detector, temp_project):
        """Private key / Signing key detection"""
        result = detector.scan(temp_project)

        # Should detect private key loaders
        key_loaders = [
            l
            for l in result.loaders
            if l.loader_type in (LoaderType.PRIVATE_KEY_FILE, LoaderType.JWT_SIGNING, LoaderType.SSH_KEY)
        ]
        assert len(key_loaders) > 0, "Should detect private key loaders"

    def test_cloud_credentials_detection(self, detector, temp_project):
        """Cloud credentials (AWS/GCP/Azure) detection"""
        result = detector.scan(temp_project)

        # Should detect cloud SDK usage
        cloud_loaders = [
            l for l in result.loaders if l.loader_type in (LoaderType.SDK_AWS, LoaderType.SDK_GCP, LoaderType.SDK_AZURE)
        ]
        assert len(cloud_loaders) > 0, "Should detect cloud SDK loaders"

        # Should have implicit secrets
        cloud_secrets = []
        for l in cloud_loaders:
            cloud_secrets.extend(l.sdk_secrets)

        assert (
            "AWS_ACCESS_KEY_ID" in cloud_secrets
            or "GOOGLE_APPLICATION_CREDENTIALS" in cloud_secrets
            or "AZURE_CLIENT_ID" in cloud_secrets
        )

    def test_password_db_jwt_detection(self, detector, temp_project):
        """Password / DB password / JWT signing secret detection"""
        result = detector.scan(temp_project)

        # Should detect password-related secrets
        password_secrets = ["DB_PASSWORD", "JWT_SECRET", "DATABASE_URL"]
        detected = set(result.secrets_with_loaders.keys())

        found_any = any(s in detected for s in password_secrets)
        assert found_any, f"Should detect password secrets. Found: {detected}"

    def test_service_api_key_detection(self, detector, temp_project):
        """Service API key (Stripe, Twilio, etc.) detection"""
        result = detector.scan(temp_project)

        # Should detect service SDK usage
        service_loaders = [
            l
            for l in result.loaders
            if l.loader_type
            in (LoaderType.SDK_STRIPE, LoaderType.SDK_TWILIO, LoaderType.SDK_SENDGRID, LoaderType.SDK_OPENAI)
        ]
        assert len(service_loaders) > 0, "Should detect service API SDK loaders"


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
