#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.
"""
T-GRC01: GRC Compliance & Agentic Security Validation Suite
============================================================

Validates:
  Layer 1 — Compliance Tags (unit)
    - STRIDE mapping present for every finding type
    - All compliance_tags keys are valid framework identifiers
    - STRIDE control IDs match stride.py definitions

  Layer 2 — Agentic Crosswalk Counters (data.json)
    - LLM→ASI crosswalk fan-out: individual ASI count ≤ total AI findings
    - Sum-of-ASI ≥ total AI (crosswalk expands, never drops findings)
    - Banner total reflects actual AI finding count, not inflated ASI sum
    - by_owasp keys are valid LLM01–LLM10 codes

  Layer 3 — GRC Dashboard Integrity (data.json + JS)
    - STRIDE appears in compliance_mapping for at least 1 finding
    - All fwDefs frameworks have matching fwSizes entry
    - JS counter logic: agentic counts are crosswalk-derived, not double-counted
    - STRIDE in GRC filter dropdown (dashboard-body.html)

Run:
    pytest tests/test_grc_compliance_agentic.py -v                  # all
    pytest tests/test_grc_compliance_agentic.py -k "Layer1" -v      # compliance unit
    pytest tests/test_grc_compliance_agentic.py -k "Layer2" -v      # agentic counters
    pytest tests/test_grc_compliance_agentic.py -k "Layer3" -v      # GRC dashboard
"""

import json
import re
import sqlite3
from pathlib import Path

import pytest

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

FINDING_TYPES = ["cve", "cwe", "secret", "malware", "ai", "dlp"]

VALID_LLM_CODES = {f"LLM{i:02d}" for i in range(1, 11)}

# OWASP ASI v1.1 uses T1-T17 notation (not ASI01-ASI10)
VALID_ASI_CODES = {f"T{i}" for i in range(1, 18)}

# LLM→ASI crosswalk (must match owasp-cards.js — OWASP ASI v1.1, T1-T17)
LLM_TO_ASI = {
    "LLM01": ["T6", "T1"],  # Prompt Injection → Goal Manipulation, Memory Poisoning
    "LLM02": ["T15", "T8"],  # Sensitive Disclosure → Human Manipulation, Repudiation
    "LLM03": ["T17", "T16"],  # Supply Chain → Supply Chain, Protocol Abuse
    "LLM04": ["T1", "T5"],  # Data Poisoning → Memory Poisoning, Cascading Hallucination
    "LLM05": ["T11", "T2"],  # Insecure Output → RCE, Tool Misuse
    "LLM06": ["T2", "T3"],  # Excessive Agency → Tool Misuse, Privilege Compromise
    "LLM07": ["T2", "T11"],  # Insecure Plugin → Tool Misuse, RCE
    "LLM08": ["T1", "T5"],  # Vector Weakness → Memory Poisoning, Cascading Hallucination
    "LLM09": ["T5", "T15"],  # Misinformation → Cascading Hallucination, Human Manipulation
    "LLM10": ["T4", "T10"],  # Unbounded Consumption → Resource Overload, Overwhelming HITL
}

# Expected STRIDE control ID prefixes per finding type
STRIDE_CONTROLS_BY_TYPE = {
    "cve": ["T-1", "E-1"],
    "cwe": ["T-1", "E-2", "I-1"],
    "secret": ["S-1", "I-1", "I-2"],
    "malware": ["T-1", "T-2", "E-3"],
    "ai": ["S-1", "T-1", "I-3", "E-2"],
    "dlp": ["I-1", "I-2", "R-1"],
}

# All 19 STRIDE control IDs from stride.py
ALL_STRIDE_IDS = {
    "S-1",
    "S-2",
    "S-3",
    "T-1",
    "T-2",
    "T-3",
    "R-1",
    "R-2",
    "R-3",
    "I-1",
    "I-2",
    "I-3",
    "D-1",
    "D-2",
    "D-3",
    "E-1",
    "E-2",
    "E-3",
    "E-4",
}

# GRC frameworks expected in JS fwDefs
EXPECTED_FWDEFS = {
    "OWASP",
    "CWE",
    "OWASP_LLM",
    "PCI-DSS",
    "HIPAA",
    "SOC2",
    "ISO27001",
    "NIST-800-53",
    "NIST-800-171",
    "FEDRAMP",
    "CMMC",
    "DISA-STIG",
    "FISMA",
    "STRIDE",
}


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture(scope="session")
def scan_root():
    base = Path.home() / ".reachable" / "scans"
    if not base.exists():
        pytest.skip("~/.reachable/scans/ does not exist")
    candidates = list(base.rglob("repo.db"))
    if not candidates:
        pytest.skip("No repo.db found")
    latest = max(candidates, key=lambda p: p.stat().st_mtime)
    return latest.parent


@pytest.fixture(scope="session")
def scan_db(scan_root):
    path = scan_root / "repo.db"
    try:
        conn = sqlite3.connect(str(path))
        count = conn.execute("SELECT COUNT(*) FROM findings").fetchone()[0]
        conn.close()
        if count == 0:
            pytest.skip("repo.db has 0 findings")
    except sqlite3.OperationalError as e:
        pytest.skip(f"repo.db invalid: {e}")
    return path


@pytest.fixture(scope="session")
def latest_scan_id(scan_db):
    conn = sqlite3.connect(str(scan_db))
    try:
        row = conn.execute("SELECT id FROM scans WHERE status = 'complete' ORDER BY id DESC LIMIT 1").fetchone()
    except sqlite3.OperationalError:
        row = None
    if not row:
        row = conn.execute("SELECT MAX(id) FROM scans").fetchone()
    conn.close()
    if not row or not row[0]:
        pytest.skip("No completed scans")
    return row[0]


@pytest.fixture(scope="session")
def data_json(scan_root):
    candidates = list(scan_root.rglob("dashboard/data.json"))
    if not candidates:
        pytest.skip("No data.json found")
    path = max(candidates, key=lambda p: p.stat().st_mtime)
    with open(path) as f:
        return json.load(f)


@pytest.fixture(scope="session")
def owasp_js():
    js_path = (
        Path(__file__).parent.parent
        / "reachable"
        / "dashboard_v2"
        / "split"
        / "components"
        / "scripts"
        / "owasp-cards.js"
    )
    if not js_path.exists():
        pytest.skip("owasp-cards.js not found")
    return js_path.read_text(encoding="utf-8")


@pytest.fixture(scope="session")
def dashboard_body_html():
    html_path = (
        Path(__file__).parent.parent / "reachable" / "dashboard_v2" / "split" / "components" / "dashboard-body.html"
    )
    if not html_path.exists():
        pytest.skip("dashboard-body.html not found")
    return html_path.read_text(encoding="utf-8")


# ---------------------------------------------------------------------------
# Layer 1: Compliance Tags Unit Tests
# ---------------------------------------------------------------------------


class TestLayer1_StrideComplianceTags:
    """Validate STRIDE mappings in compliance_tags.py."""

    def test_stride_module_imports(self):
        from reachable.database.normalizers.compliance_tags import get_compliance_mapping

        assert callable(get_compliance_mapping)

    @pytest.mark.parametrize("finding_type", FINDING_TYPES)
    def test_stride_present_for_all_finding_types(self, finding_type):
        """Every finding type must produce a STRIDE key in compliance_mapping."""
        from reachable.database.normalizers.compliance_tags import get_compliance_mapping

        mapping = get_compliance_mapping(finding_type)
        assert (
            "STRIDE" in mapping
        ), f"get_compliance_mapping('{finding_type}') missing STRIDE key. Got keys: {sorted(mapping.keys())}"

    @pytest.mark.parametrize("finding_type", FINDING_TYPES)
    def test_stride_controls_are_valid_ids(self, finding_type):
        """STRIDE control IDs must match the S-N/T-N/R-N/I-N/D-N/E-N format."""
        from reachable.database.normalizers.compliance_tags import get_compliance_mapping

        mapping = get_compliance_mapping(finding_type)
        stride_val = mapping.get("STRIDE", [])
        if isinstance(stride_val, str):
            stride_val = [stride_val]

        for ctrl in stride_val:
            ctrl_id = ctrl.replace("STRIDE ", "")
            assert (
                ctrl_id in ALL_STRIDE_IDS
            ), f"Invalid STRIDE control '{ctrl_id}' for {finding_type}. Valid IDs: {sorted(ALL_STRIDE_IDS)}"

    @pytest.mark.parametrize("finding_type", list(STRIDE_CONTROLS_BY_TYPE.keys()))
    def test_stride_controls_match_expected(self, finding_type):
        """Each finding type maps to its expected STRIDE controls."""
        from reachable.database.normalizers.compliance_tags import get_compliance_mapping

        mapping = get_compliance_mapping(finding_type)
        stride_val = mapping.get("STRIDE", [])
        if isinstance(stride_val, str):
            stride_val = [stride_val]

        actual_ids = sorted(ctrl.replace("STRIDE ", "") for ctrl in stride_val)
        expected_ids = sorted(STRIDE_CONTROLS_BY_TYPE[finding_type])
        assert (
            actual_ids == expected_ids
        ), f"STRIDE controls for '{finding_type}': expected {expected_ids}, got {actual_ids}"

    def test_existing_mapping_merges_stride(self):
        """Scanner-provided tags merge with STRIDE base without clobbering."""
        from reachable.database.normalizers.compliance_tags import get_compliance_mapping

        existing = {"OWASP": "OWASP A01:2021", "custom_tag": "custom_value"}
        result = get_compliance_mapping("cve", existing)
        assert "STRIDE" in result, "STRIDE lost during merge"
        assert result["OWASP"] == "OWASP A01:2021", "Scanner OWASP clobbered"
        assert result["custom_tag"] == "custom_value", "Custom tag lost"

    def test_stride_py_has_19_controls(self):
        """stride.py must define exactly 19 controls."""
        from reachable.compliance.stride import STRIDE_CONTROLS

        assert len(STRIDE_CONTROLS) == 19, f"Expected 19 STRIDE controls, got {len(STRIDE_CONTROLS)}"

    def test_stride_categories_cover_all_six(self):
        """STRIDE controls must cover all 6 threat categories."""
        from reachable.compliance.stride import STRIDE_CONTROLS

        categories = {c.category for c in STRIDE_CONTROLS}
        expected = {
            "Spoofing",
            "Tampering",
            "Repudiation",
            "Information Disclosure",
            "Denial of Service",
            "Elevation of Privilege",
        }
        assert categories == expected, f"Missing STRIDE categories: {expected - categories}"


# ---------------------------------------------------------------------------
# Layer 2: Agentic Crosswalk Counter Validation (data.json)
# ---------------------------------------------------------------------------


class TestLayer2_AgenticCrosswalkCounters:
    """Validate LLM->ASI crosswalk counter logic in data.json."""

    def test_by_owasp_keys_are_valid(self, data_json):
        """ai_security.by_owasp keys must be valid LLM01-LLM10 or NONE."""
        ai_sec = data_json.get("ai_security") or {}
        by_owasp = ai_sec.get("by_owasp", {})
        if not by_owasp:
            pytest.skip("No by_owasp data")
        invalid = {k for k in by_owasp if k not in VALID_LLM_CODES and k != "NONE"}
        assert not invalid, f"Invalid by_owasp keys: {invalid}"

    def test_by_owasp_counts_nonnegative(self, data_json):
        """by_owasp counts must all be >= 0."""
        ai_sec = data_json.get("ai_security") or {}
        by_owasp = ai_sec.get("by_owasp", {})
        if not by_owasp:
            pytest.skip("No by_owasp data")
        neg = {k: v for k, v in by_owasp.items() if v < 0}
        assert not neg, f"Negative by_owasp counts: {neg}"

    def test_by_owasp_sum_matches_total(self, data_json):
        """Sum of by_owasp counts should equal ai_security.total (+/- tolerance).

        by_owasp includes NONE (informational). Full total includes NONE too.
        """
        ai_sec = data_json.get("ai_security") or {}
        by_owasp = ai_sec.get("by_owasp", {})
        total = ai_sec.get("total", 0)
        if total == 0:
            pytest.skip("No AI findings")
        owasp_sum = sum(by_owasp.values())
        assert abs(owasp_sum - total) <= max(
            3, total * 0.15
        ), f"by_owasp sum ({owasp_sum}) vs total ({total}) mismatch. Breakdown: {dict(by_owasp)}"

    def test_total_actionable_excludes_none(self, data_json):
        """total_actionable must equal total minus NONE count."""
        ai_sec = data_json.get("ai_security") or {}
        total = ai_sec.get("total", 0)
        total_act = ai_sec.get("total_actionable")
        if total_act is None:
            pytest.skip("total_actionable not in data.json — re-scan needed")
        none_count = ai_sec.get("by_owasp", {}).get("NONE", 0)
        assert (
            total_act == total - none_count
        ), f"total_actionable ({total_act}) != total ({total}) - NONE ({none_count})"

    def test_asi_crosswalk_per_category_lte_total(self, data_json):
        """Each ASI category count (via crosswalk) must be <= total AI findings.

        The crosswalk fans out: LLM06->[T2,T3] means
        each of those ASI categories gets the FULL LLM06 count. This is correct
        -- but each individual ASI count must not exceed total AI findings.
        """
        ai_sec = data_json.get("ai_security") or {}
        by_owasp = ai_sec.get("by_owasp", {})
        total = ai_sec.get("total", 0)
        if total == 0:
            pytest.skip("No AI findings")

        asi_counts = {code: 0 for code in VALID_ASI_CODES}
        for llm, count in by_owasp.items():
            for asi in LLM_TO_ASI.get(llm, []):
                asi_counts[asi] += count

        violations = {code: cnt for code, cnt in asi_counts.items() if cnt > total}
        assert not violations, (
            f"ASI counts exceed total AI findings ({total}): {violations}. "
            f"This means a single LLM finding is being counted multiple times "
            f"within one ASI category -- likely a by_owasp aggregation bug."
        )

    def test_asi_crosswalk_is_complete(self):
        """Every LLM code must have at least one ASI mapping."""
        for llm in VALID_LLM_CODES:
            assert llm in LLM_TO_ASI, f"{llm} missing from LLM_TO_ASI crosswalk"
            assert len(LLM_TO_ASI[llm]) >= 1, f"{llm} maps to empty ASI list"

    def test_asi_crosswalk_targets_valid(self):
        """All ASI targets in crosswalk must be valid T1-T17 codes."""
        for llm, targets in LLM_TO_ASI.items():
            for asi in targets:
                assert asi in VALID_ASI_CODES, f"{llm}->{asi} is not a valid ASI code (T1-T17)"

    def test_all_asi_codes_reachable(self):
        """ASI codes reachable via LLM crosswalk must cover expected set.

        Not all 17 ASI threat categories (T1-T17) map from LLM01-LLM10.
        T7 (Misaligned), T9 (Identity Spoofing), T12-T14 (multi-agent)
        are autonomous/multi-agent threats without direct LLM parents.
        We verify the crosswalk covers at least the 12 expected codes.
        """
        covered = set()
        for targets in LLM_TO_ASI.values():
            covered.update(targets)
        # 12 of 17 ASI codes are reachable from LLM01-LLM10
        expected_covered = {
            "T1",
            "T2",
            "T3",
            "T4",
            "T5",
            "T6",
            "T8",
            "T10",
            "T11",
            "T15",
            "T16",
            "T17",
        }
        missing = expected_covered - covered
        assert not missing, f"Expected ASI codes unreachable via crosswalk: {missing}"
        assert len(covered) >= 12, f"Crosswalk covers only {len(covered)} ASI codes, expected >= 12"

    def test_ai_issues_count_matches_total(self, data_json):
        """issues[] AI-type count must match ai_security.total."""
        ai_sec = data_json.get("ai_security") or {}
        total = ai_sec.get("total", 0)
        issues = data_json.get("issues", [])
        ai_issues = [f for f in issues if (f.get("type") or "").upper() == "AI"]
        if total == 0 and len(ai_issues) == 0:
            pytest.skip("No AI findings")
        assert abs(len(ai_issues) - total) <= max(
            2, total * 0.1
        ), f"issues[] has {len(ai_issues)} AI findings vs ai_security.total={total}"

    def test_crosswalk_fanout_documented_in_banner(self, data_json):
        """Banner should use actionable count, NOT sum of ASI counts.

        The ASI sum can exceed total due to fan-out (one finding -> multiple
        ASI categories). The banner must show the actual finding count.
        """
        ai_sec = data_json.get("ai_security") or {}
        total = ai_sec.get("total", 0)
        by_owasp = ai_sec.get("by_owasp", {})
        if total == 0:
            pytest.skip("No AI findings")

        asi_counts = {code: 0 for code in VALID_ASI_CODES}
        for llm, count in by_owasp.items():
            for asi in LLM_TO_ASI.get(llm, []):
                asi_counts[asi] += count

        asi_sum = sum(asi_counts.values())
        assert total > 0, "ai_security.total must be populated for banner"
        assert "total" in ai_sec, "ai_security must have 'total' field for banner"
        if asi_sum > total:
            ratio = asi_sum / total
            print(
                f"\n  [crosswalk fan-out] total={total}, asi_sum={asi_sum}, "
                f"ratio={ratio:.1f}x -- expected for multi-mapped LLM codes"
            )


# ---------------------------------------------------------------------------
# Layer 3: GRC Dashboard JS Validation
# ---------------------------------------------------------------------------


class TestLayer3_GRCDashboardJS:
    """Validate GRC / STRIDE / Agentic wiring in dashboard JS and HTML."""

    def test_fwdefs_contains_stride(self, owasp_js):
        """STRIDE must be in the fwDefs object."""
        assert "'STRIDE'" in owasp_js or '"STRIDE"' in owasp_js, "STRIDE not found in owasp-cards.js fwDefs"

    def test_fwdefs_stride_has_name(self, owasp_js):
        """STRIDE fwDef must have a display name."""
        assert "STRIDE Threat Model" in owasp_js

    def test_fw_canonical_has_stride(self, owasp_js):
        """FW_CANONICAL must normalize STRIDE variants."""
        assert "'STRIDE':'STRIDE'" in owasp_js or '"STRIDE":"STRIDE"' in owasp_js

    def test_fw_sizes_has_stride(self, owasp_js):
        """fwSizes must have STRIDE:19 (matching 19 controls in stride.py)."""
        assert "STRIDE:19" in owasp_js, "fwSizes missing STRIDE:19 in owasp-cards.js"

    def test_all_fwdefs_have_fwsizes(self, owasp_js):
        """Every framework in fwDefs must have a corresponding fwSizes entry."""
        fwdefs_matches = re.findall(r"'([A-Z][A-Z0-9_-]+)'\s*:\s*\{[^}]*name:", owasp_js)
        fwsizes_match = re.search(r"var fwSizes\s*=\s*\{([^}]+)\}", owasp_js)
        if not fwsizes_match:
            pytest.skip("fwSizes not found in owasp-cards.js")
        fwsizes_text = fwsizes_match.group(1)
        unquoted = set(re.findall(r"(?<!['\"])([A-Za-z0-9_]+)\s*:", fwsizes_text))
        quoted = set(re.findall(r"'([A-Za-z0-9_-]+)'\s*:", fwsizes_text))
        fwsizes_keys = unquoted | quoted
        # Exclude non-framework keys: CWE-TOP-25 is an alias, T1-T17 are ASI
        # agentic threat categories (not GRC frameworks) that also match the
        # regex because asiDefs uses the same '{name:...}' object pattern.
        asi_codes = {f"T{i}" for i in range(1, 18)}
        excluded = {"CWE-TOP-25"} | asi_codes
        missing = []
        for fw in fwdefs_matches:
            if fw not in fwsizes_keys and fw not in excluded:
                missing.append(fw)
        assert (
            not missing
        ), f"Frameworks in fwDefs without fwSizes entry: {missing}. fwSizes keys found: {sorted(fwsizes_keys)}"

    def test_agentic_crosswalk_in_js(self, owasp_js):
        """owasp-cards.js must contain the LLM_TO_ASI crosswalk."""
        assert "LLM_TO_ASI" in owasp_js, "LLM_TO_ASI crosswalk missing"

    def test_all_asi_defs_in_js(self, owasp_js):
        """All 17 ASI threat categories (T1-T17) must be defined in asiDefs."""
        for code in VALID_ASI_CODES:
            assert code in owasp_js, f"{code} missing from owasp-cards.js"

    def test_agentic_flow_mount_exists(self, owasp_js):
        """JS must look for agenticSurfaceFlow mount."""
        assert "agenticSurfaceFlow" in owasp_js

    def test_agentic_label_mount_exists(self, owasp_js):
        """JS must look for agenticSurfaceLabel mount."""
        assert "agenticSurfaceLabel" in owasp_js

    def test_attack_surface_banner_mount(self, owasp_js):
        """JS must look for attackSurfaceBanner mount."""
        assert "attackSurfaceBanner" in owasp_js

    def test_show_stage_detail_handles_agentic(self, owasp_js):
        """showStageDetail must check stage.isAgentic for reverse-map."""
        assert "isAgentic" in owasp_js, "showStageDetail missing isAgentic check"

    def test_agentic_reverse_map_in_detail(self, owasp_js):
        """Detail panel must reverse-map ASI->LLM for agentic stages."""
        assert "matchLlmCodes" in owasp_js or "reverse-map" in owasp_js

    def test_html_has_agentic_divs(self, dashboard_body_html):
        """dashboard-body.html must have all 3 agentic mount divs."""
        assert 'id="attackSurfaceBanner"' in dashboard_body_html
        assert 'id="agenticSurfaceFlow"' in dashboard_body_html
        assert 'id="agenticSurfaceLabel"' in dashboard_body_html

    def test_html_has_stride_filter(self, dashboard_body_html):
        """GRC filter dropdown must include STRIDE option."""
        assert 'value="STRIDE"' in dashboard_body_html, "STRIDE missing from GRC compliance filter dropdown"

    def test_html_agentic_filter_options(self, dashboard_body_html):
        """GRC filter must have LLM01-LLM10 agentic options (ASI uses T notation internally)."""
        # Dashboard HTML filter uses LLM codes (OWASP-LLM01..LLM10) for
        # compliance filter navigation. ASI T1-T17 are rendered dynamically
        # by JS from the LLM_TO_ASI crosswalk, not as static HTML options.
        for i in range(1, 11):
            code = f"LLM{i:02d}"
            assert f"OWASP-{code}" in dashboard_body_html, f"{code} missing from agentic filter options"

    def test_stride_in_data_json_compliance(self, data_json):
        """At least one finding in data.json should have STRIDE in compliance_mapping.

        NOTE: This test requires a scan AFTER the STRIDE compliance_tags update.
        """
        issues = data_json.get("issues", [])
        has_stride = any("STRIDE" in (f.get("compliance_mapping") or {}) for f in issues)
        if not has_stride:
            pytest.skip("No findings with STRIDE compliance_mapping -- re-scan after compliance_tags.py update")
        assert has_stride

    def test_banner_shows_pipeline_count(self, owasp_js):
        """Banner must show pipelineCount (excluding NONE) separately from total."""
        assert "pipelineCount" in owasp_js, "owasp-cards.js missing pipelineCount for banner"
        assert "_noneCount" in owasp_js, "owasp-cards.js missing _noneCount for informational display"

    def test_no_stale_crosswalk_in_detail(self, owasp_js):
        """showStageDetail must NOT have its own _LLM_TO_ASI copy (use parentLlm)."""
        # The old code had a stale duplicate crosswalk inside showStageDetail.
        # After fix, it uses stage.parentLlm pre-computed from the canonical crosswalk.
        assert "parentLlm" in owasp_js, "Missing parentLlm in stage objects"
        # Should NOT have a second var _LLM_TO_ASI in showStageDetail
        import re

        # Count declarations inside showStageDetail specifically
        # (there are 3 total in the file: renderAIAttackSurface, renderLlmTop10, renderGRC)
        # showStageDetail should NOT have its own — it uses stage.parentLlm
        detail_fn = owasp_js[owasp_js.find("window.showStageDetail") :]
        detail_fn = detail_fn[: detail_fn.find("\nfunction ")] if "\nfunction " in detail_fn else detail_fn[:3000]
        matches_in_detail = re.findall(r"var\s+_?LLM_TO_ASI\s*=", detail_fn)
        assert len(matches_in_detail) == 0, (
            f"Found {len(matches_in_detail)} LLM_TO_ASI in showStageDetail — "
            f"it should use stage.parentLlm from the canonical crosswalk."
        )

    def test_none_excluded_from_agentic_filter(self, owasp_js):
        """Agentic detail filter must NOT remap NONE/PRIMITIVE to LLM06."""
        # The old code had: if (cat === 'NONE' || cat === '') cat = 'LLM06'
        # which inflated agentic counts from 5 to 21.
        # After fix: NONE/PRIMITIVE return false (excluded).
        assert "return false" in owasp_js, "Missing early return for NONE/PRIMITIVE"
        # Verify NONE is not remapped to LLM06 anywhere in the agentic filter
        import re

        # Should NOT match: NONE...LLM06 remap pattern
        bad_remap = re.findall(r"cat\s*===\s*'NONE'.*cat\s*=\s*'LLM06'", owasp_js)
        assert len(bad_remap) == 0, "NONE is still being remapped to LLM06 in agentic filter — this inflates counts"

    def test_agentic_click_uses_llm_code(self, owasp_js):
        """Agentic stage click must filter by parent LLM code, not ASI code."""
        assert "matchLlmCodes[0]" in owasp_js, "Agentic stageComp not using parent LLM code for click filter"

    def test_agentic_boxes_same_style_as_pipeline(self, owasp_js):
        """Agentic boxes must use same v2-attack-stage class with identical styling."""
        import re

        # Both panels should use font-size:14px for count display
        count_styles = re.findall(r"font-size:14px;font-weight:700;color:#42A5F5", owasp_js)
        assert (
            len(count_styles) >= 2
        ), f"Found {len(count_styles)} blue count styles — expected ≥2 (one for LLM pipeline, one for agentic panel)"


class TestLayer3_GRCCounterConsistency:
    """Validate GRC counter logic: framework finding counts must be consistent."""

    def test_grc_total_lte_issues(self, data_json):
        """Each individual framework count must <= total issues."""
        issues = data_json.get("issues", [])
        total = len(issues)
        if total == 0:
            pytest.skip("No findings")

        fw_counts = {}
        for f in issues:
            cm = f.get("compliance_mapping") or {}
            for fw in cm:
                fw_counts[fw] = fw_counts.get(fw, 0) + 1

        violations = {fw: cnt for fw, cnt in fw_counts.items() if cnt > total}
        assert not violations, f"Framework counts exceed total issues ({total}): {violations}"

    def test_stride_count_plausible(self, data_json):
        """If STRIDE is in compliance_mapping, its count should be plausible."""
        issues = data_json.get("issues", [])
        stride_count = sum(1 for f in issues if "STRIDE" in (f.get("compliance_mapping") or {}))
        if stride_count == 0:
            pytest.skip("No STRIDE-tagged findings -- re-scan needed")
        total = len(issues)
        ratio = stride_count / total if total > 0 else 0
        assert ratio >= 0.5, (
            f"STRIDE only on {stride_count}/{total} findings ({ratio:.0%}) -- "
            f"expected >=50% coverage after compliance_tags update"
        )
