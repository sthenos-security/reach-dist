#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.
"""
Tests for RADR internal entrypoint detection (v5.5).

Tests cover:
- Timer/scheduler detection (Python, JS, Go, Java)
- Message queue detection (Kafka, RabbitMQ, Celery)
- Thread/async detection (threading, asyncio, goroutine patterns)
- Signal handler detection
- Startup hook detection
- Import-based detection
- Deduplication and confidence ranking
- Edge cases
"""

from collections import defaultdict

from reachable.core.internal_entrypoints import detect_internal_entrypoints

# =============================================================================
# PYTHON PATTERNS
# =============================================================================


class TestPythonCallPatterns:
    def test_threading_thread(self):
        graph = defaultdict(set)
        graph["app.worker.start_bg"] = {"threading.Thread"}

        result = detect_internal_entrypoints(
            call_graph=graph,
            all_functions={"app.worker.start_bg", "threading.Thread"},
        )

        eps = result["entrypoints"]
        assert len(eps) >= 1
        thread_ep = next(e for e in eps if e["type"] == "thread")
        assert thread_ep["framework"] == "threading"
        assert thread_ep["function"] == "app.worker.start_bg"

    def test_celery_task(self):
        graph = defaultdict(set)
        graph["app.tasks.send_email"] = {"celery.task"}

        result = detect_internal_entrypoints(
            call_graph=graph,
            all_functions={"app.tasks.send_email"},
        )

        eps = result["entrypoints"]
        assert any(e["type"] == "queue" and e["framework"] == "celery" for e in eps)

    def test_asyncio_create_task(self):
        graph = defaultdict(set)
        graph["app.service.fetch_data"] = {"asyncio.create_task"}

        result = detect_internal_entrypoints(
            call_graph=graph,
            all_functions={"app.service.fetch_data"},
        )

        eps = result["entrypoints"]
        assert any(e["type"] == "thread" and e["framework"] == "asyncio" for e in eps)

    def test_signal_handler(self):
        graph = defaultdict(set)
        graph["app.main.setup_signals"] = {"signal.signal"}

        result = detect_internal_entrypoints(
            call_graph=graph,
            all_functions={"app.main.setup_signals"},
        )

        eps = result["entrypoints"]
        assert any(e["type"] == "signal" for e in eps)

    def test_schedule_library(self):
        graph = defaultdict(set)
        graph["app.cron.setup_jobs"] = {"schedule.every"}

        result = detect_internal_entrypoints(
            call_graph=graph,
            all_functions={"app.cron.setup_jobs"},
        )

        eps = result["entrypoints"]
        assert any(e["type"] == "timer" and e["framework"] == "schedule" for e in eps)


# =============================================================================
# JAVASCRIPT PATTERNS
# =============================================================================


class TestJavaScriptPatterns:
    def test_setinterval(self):
        graph = defaultdict(set)
        graph["app.poller.start"] = {"setInterval"}

        result = detect_internal_entrypoints(
            call_graph=graph,
            all_functions={"app.poller.start"},
        )

        eps = result["entrypoints"]
        assert any(e["type"] == "timer" and e["framework"] == "node" for e in eps)

    def test_process_on(self):
        graph = defaultdict(set)
        graph["app.main.setup"] = {"process.on"}

        result = detect_internal_entrypoints(
            call_graph=graph,
            all_functions={"app.main.setup"},
        )

        eps = result["entrypoints"]
        assert any(e["type"] == "signal" and e["framework"] == "node" for e in eps)


# =============================================================================
# GO PATTERNS
# =============================================================================


class TestGoPatterns:
    def test_init_function(self):
        """Go init() functions are startup entrypoints."""
        result = detect_internal_entrypoints(
            call_graph={},
            all_functions={"app.config.init"},
        )

        eps = result["entrypoints"]
        assert any(e["type"] == "startup" and e["framework"] == "go-init" for e in eps)

    def test_signal_notify(self):
        graph = defaultdict(set)
        graph["app.main.graceful_shutdown"] = {"signal.Notify"}

        result = detect_internal_entrypoints(
            call_graph=graph,
            all_functions={"app.main.graceful_shutdown"},
        )

        eps = result["entrypoints"]
        assert any(e["type"] == "signal" and e["framework"] == "os/signal" for e in eps)

    def test_time_afterfunc(self):
        graph = defaultdict(set)
        graph["app.cache.schedule_cleanup"] = {"time.AfterFunc"}

        result = detect_internal_entrypoints(
            call_graph=graph,
            all_functions={"app.cache.schedule_cleanup"},
        )

        eps = result["entrypoints"]
        assert any(e["type"] == "timer" for e in eps)


# =============================================================================
# JAVA PATTERNS
# =============================================================================


class TestJavaPatterns:
    def test_scheduled_annotation(self):
        """Java @Scheduled detected by function name pattern."""
        result = detect_internal_entrypoints(
            call_graph={},
            all_functions={"app.jobs.scheduledCleanup"},
        )

        eps = result["entrypoints"]
        assert any(e["type"] == "timer" and e["framework"] == "spring" for e in eps)

    def test_kafka_listener(self):
        result = detect_internal_entrypoints(
            call_graph={},
            all_functions={"app.consumers.kafkaListener"},
        )

        eps = result["entrypoints"]
        assert any(e["type"] == "queue" and "kafka" in e["framework"] for e in eps)

    def test_postconstruct(self):
        result = detect_internal_entrypoints(
            call_graph={},
            all_functions={"app.service.postConstruct"},
        )

        eps = result["entrypoints"]
        assert any(e["type"] == "startup" and e["framework"] == "spring" for e in eps)


# =============================================================================
# IMPORT-BASED DETECTION
# =============================================================================


class TestImportBasedDetection:
    def test_celery_import(self):
        result = detect_internal_entrypoints(
            call_graph={},
            all_functions={"app.tasks.process_order"},
            function_imports={"app.tasks.process_order": {"celery"}},
        )

        eps = result["entrypoints"]
        assert any(e["framework"] == "celery" for e in eps)

    def test_kafka_import(self):
        result = detect_internal_entrypoints(
            call_graph={},
            all_functions={"app.consumer.listen"},
            function_imports={"app.consumer.listen": {"kafka"}},
        )

        eps = result["entrypoints"]
        assert any(e["type"] == "queue" and e["framework"] == "kafka" for e in eps)


# =============================================================================
# DEDUPLICATION AND EDGE CASES
# =============================================================================


class TestDeduplication:
    def test_higher_confidence_wins(self):
        """When same function detected via call pattern (HIGH) and name pattern (LOW),
        HIGH confidence should win."""
        graph = defaultdict(set)
        graph["app.worker.background_task"] = {"threading.Thread"}

        result = detect_internal_entrypoints(
            call_graph=graph,
            all_functions={"app.worker.background_task"},
        )

        thread_eps = [e for e in result["entrypoints"] if e["type"] == "thread"]
        # Should have the HIGH confidence one from call pattern
        assert any(e["confidence"] == "HIGH" for e in thread_eps)

    def test_empty_graph(self):
        result = detect_internal_entrypoints(
            call_graph={},
            all_functions=set(),
        )

        assert result["statistics"]["total"] == 0
        assert result["entrypoints"] == []

    def test_lib_functions_ignored(self):
        """Library functions should not be detected as entrypoints."""
        graph = defaultdict(set)
        graph["lib.internal.thread_pool"] = {"threading.Thread"}

        result = detect_internal_entrypoints(
            call_graph=graph,
            all_functions={"lib.internal.thread_pool"},
        )

        # lib. functions should be skipped
        assert result["statistics"]["total"] == 0

    def test_statistics_structure(self):
        graph = defaultdict(set)
        graph["app.worker.run"] = {"threading.Thread"}
        graph["app.cron.setup"] = {"schedule.every"}
        graph["app.signals.handle"] = {"signal.signal"}

        result = detect_internal_entrypoints(
            call_graph=graph,
            all_functions={"app.worker.run", "app.cron.setup", "app.signals.handle"},
        )

        stats = result["statistics"]
        assert stats["total"] >= 3
        assert "thread" in stats["by_type"]
        assert "timer" in stats["by_type"]
        assert "signal" in stats["by_type"]
