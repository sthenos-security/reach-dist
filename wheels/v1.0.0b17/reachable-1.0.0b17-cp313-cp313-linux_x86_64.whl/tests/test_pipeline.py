"""
REACHABLE Pipeline Tests
========================

Tests for the distributed CI/CD pipeline (reachctl pipeline).

Architecture being tested (7-step model):
  scan     - Syft + Grype combined; temp SBOM file; SBOM cached in DB
  secrets  - Semgrep secrets + CWE merged into one security-findings.json
  malware  - GuardDog; reads SBOM from DB cache
  iac      - K8s + Docker Compose scanners
  health   - Registry health; reads SBOM from DB cache
  ai       - AI/LLM security analysis (OWASP LLM Top 10)
  dlp      - DLP/PII data exposure (taint analysis)

  finalize - RA(grype-vulns.json) → ingest() → complete_scan() → dashboard

Design axioms verified:
  - DB is source of truth (finalize calls generate_from_scan_dir, not from JSON)
  - No sbom step, no vulns step, no cwe step as independent steps
  - Syft + Grype share a temp file deleted after use
  - SBOM cached in DB; malware + health read from DB cache
  - secrets + CWE merged into single security-findings.json
  - No store_scan_to_database call (was deleted from scan.py)
  - No reachable-report.json.gz write
  - raw/ file names match RAW_FILE_REGISTRY exactly
"""

import json
import multiprocessing
import os
import sys
import tempfile
import types
import unittest
from datetime import datetime
from pathlib import Path
from unittest.mock import MagicMock, patch

# ---------------------------------------------------------------------------
# Path setup
# ---------------------------------------------------------------------------
_REPO_ROOT = Path(__file__).parent.parent
if str(_REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(_REPO_ROOT))

from reachable.cli.pipeline import (
    PARALLEL_STEPS,
    PIPELINE_STEPS,
    STEP_DEPENDENCIES,
    _count_by_severity,
    _get_sbom_from_db,
    _resolve_session_dir,
    load_pipeline_state,
    pipeline_step,
    save_pipeline_state,
    save_step_state,
)

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _args(**kwargs):
    defaults = dict(session=None, step=None, json=False, verbose=False,
                     fail_on="none", skip_iac=False)
    defaults.update(kwargs)
    return types.SimpleNamespace(**defaults)


def _minimal_sbom():
    return {
        "artifacts": [
            {"name": "flask", "version": "2.3.0", "type": "python",
             "language": "python", "purl": "pkg:pypi/flask@2.3.0",
             "locations": [{"path": "requirements.txt"}], "metadata": {}},
            {"name": "requests", "version": "2.31.0", "type": "python",
             "language": "python", "purl": "pkg:pypi/requests@2.31.0",
             "locations": [{"path": "requirements.txt"}], "metadata": {}},
        ],
        "schema": {"version": "16.0.0"},
        "artifactRelationships": [],
    }


def _minimal_grype_vulns():
    return {
        "matches": [
            {"vulnerability": {"id": "CVE-2023-1234", "severity": "HIGH"},
             "artifact": {"name": "flask", "version": "2.3.0"}},
            {"vulnerability": {"id": "CVE-2023-5678", "severity": "CRITICAL"},
             "artifact": {"name": "requests", "version": "2.31.0"}},
        ]
    }


def _init_session(session_dir: Path, repo_path: Path,
                  db_path: str = "/fake/repo.db",
                  scan_id: int = 42,
                  commit: str = "abc123def456",
                  extra_steps: dict = None) -> dict:
    """Write a minimal .pipeline-state.json and return the state dict."""
    state = {
        "session_id": "20260304-000000-test01",
        "repo_path": str(repo_path),
        "repo_name": "test-repo",
        "session_dir": str(session_dir),
        "db_path": db_path,
        "scan_id": scan_id,
        "commit": commit,
        "branch": "main",
        "created_at": datetime.now().isoformat(),
        "version": "1.0.0",
        "status": "initialized",
        "steps": {step: {"status": "pending"} for step in PIPELINE_STEPS},
    }
    if extra_steps:
        state["steps"].update(extra_steps)
    save_pipeline_state(session_dir, state)
    return state


# ===========================================================================
# 1. Step registry contracts
# ===========================================================================

class TestNewPipelineSteps(unittest.TestCase):
    """Verify the 7-step model is correctly configured."""

    def test_exactly_seven_steps(self):
        self.assertEqual(len(PIPELINE_STEPS), 7,
            f"Expected 7 steps, got {len(PIPELINE_STEPS)}: {list(PIPELINE_STEPS)}")

    def test_expected_step_names(self):
        self.assertSetEqual(set(PIPELINE_STEPS.keys()),
                            {"scan", "secrets", "malware", "iac", "health", "ai", "dlp"})

    def test_no_sbom_step(self):
        self.assertNotIn("sbom", PIPELINE_STEPS, "sbom is now part of the 'scan' step")

    def test_no_vulns_step(self):
        self.assertNotIn("vulns", PIPELINE_STEPS, "vulns is now part of the 'scan' step")

    def test_no_cwe_step(self):
        self.assertNotIn("cwe", PIPELINE_STEPS, "cwe is now merged into 'secrets' step")

    def test_scan_has_no_dependencies(self):
        self.assertEqual(STEP_DEPENDENCIES.get("scan", []), [],
            "scan step is first — must have no dependencies")

    def test_secrets_has_no_dependencies(self):
        self.assertEqual(STEP_DEPENDENCIES.get("secrets", []), [],
            "secrets/CWE is pure code scan — no dependency on scan step")

    def test_malware_depends_on_scan(self):
        self.assertIn("scan", STEP_DEPENDENCIES.get("malware", []),
            "malware reads SBOM from DB cache set by scan step")

    def test_health_depends_on_scan(self):
        self.assertIn("scan", STEP_DEPENDENCIES.get("health", []),
            "health reads SBOM from DB cache set by scan step")

    def test_iac_has_no_dependencies(self):
        self.assertEqual(STEP_DEPENDENCIES.get("iac", []), [],
            "iac is pure filesystem scan — no SBOM needed")

    def test_all_dep_keys_are_valid_steps(self):
        for step, deps in STEP_DEPENDENCIES.items():
            self.assertIn(step, PIPELINE_STEPS)
            for dep in deps:
                self.assertIn(dep, PIPELINE_STEPS,
                    f"Dependency '{dep}' of step '{step}' is not a valid step")

    def test_parallel_steps_correct(self):
        self.assertSetEqual(set(PARALLEL_STEPS), {"secrets", "malware", "iac", "health", "ai", "dlp"})

    def test_parallel_steps_no_inter_deps(self):
        """Parallel steps must not depend on each other."""
        for step in PARALLEL_STEPS:
            for dep in STEP_DEPENDENCIES.get(step, []):
                self.assertNotIn(dep, PARALLEL_STEPS,
                    f"Parallel step '{step}' depends on parallel step '{dep}' — deadlock")

    def test_step_descriptions_nonempty(self):
        for step, desc in PIPELINE_STEPS.items():
            self.assertTrue(desc, f"Step '{step}' has empty description")


# ===========================================================================
# 2. State management (sidecar architecture)
# ===========================================================================

class TestPipelineState(unittest.TestCase):

    def test_save_and_load_roundtrip(self):
        with tempfile.TemporaryDirectory() as tmp:
            sd = Path(tmp)
            save_pipeline_state(sd, {"session_id": "abc", "steps": {}, "status": "initialized"})
            loaded = load_pipeline_state(sd)
            self.assertEqual(loaded["session_id"], "abc")
            self.assertIn("updated_at", loaded)

    def test_load_missing_returns_empty(self):
        with tempfile.TemporaryDirectory() as tmp:
            self.assertEqual(load_pipeline_state(Path(tmp)), {})

    def test_updated_at_is_iso(self):
        with tempfile.TemporaryDirectory() as tmp:
            sd = Path(tmp)
            save_pipeline_state(sd, {})
            state = load_pipeline_state(sd)
            datetime.fromisoformat(state["updated_at"])  # must not raise

    def test_save_overwrites_previous(self):
        with tempfile.TemporaryDirectory() as tmp:
            sd = Path(tmp)
            save_pipeline_state(sd, {"v": 1})
            save_pipeline_state(sd, {"v": 2})
            self.assertEqual(load_pipeline_state(sd)["v"], 2)

    def test_sidecar_overlays_init_state(self):
        """Step sidecar should overlay the base step skeleton."""
        with tempfile.TemporaryDirectory() as tmp:
            sd = Path(tmp)
            with tempfile.TemporaryDirectory() as repo_tmp:
                _init_session(sd, Path(repo_tmp))
                save_step_state(sd, "scan", {"status": "complete", "duration_seconds": 12.3})
                state = load_pipeline_state(sd)
                self.assertEqual(state["steps"]["scan"]["status"], "complete")
                self.assertEqual(state["steps"]["scan"]["duration_seconds"], 12.3)
                # Other steps still pending
                self.assertEqual(state["steps"]["secrets"]["status"], "pending")

    def test_multiple_sidecars_merged(self):
        with tempfile.TemporaryDirectory() as tmp:
            sd = Path(tmp)
            with tempfile.TemporaryDirectory() as repo_tmp:
                _init_session(sd, Path(repo_tmp))
                save_step_state(sd, "scan",    {"status": "complete"})
                save_step_state(sd, "secrets", {"status": "complete"})
                save_step_state(sd, "malware", {"status": "running"})
                state = load_pipeline_state(sd)
                self.assertEqual(state["steps"]["scan"]["status"],    "complete")
                self.assertEqual(state["steps"]["secrets"]["status"], "complete")
                self.assertEqual(state["steps"]["malware"]["status"], "running")
                self.assertEqual(state["steps"]["iac"]["status"],     "pending")

    def test_atomic_write_no_partial_reads(self):
        """After a write, reading must return valid JSON — never partial data."""
        with tempfile.TemporaryDirectory() as tmp:
            sd = Path(tmp)
            for i in range(50):
                save_pipeline_state(sd, {"i": i, "data": "x" * 1000})
            state = load_pipeline_state(sd)
            self.assertIn("i", state)


# ===========================================================================
# 3. Dependency enforcement
# ===========================================================================

class TestStepDependencyEnforcement(unittest.TestCase):

    def setUp(self):
        self._tmp = tempfile.TemporaryDirectory()
        self._repo = tempfile.TemporaryDirectory()
        self.sd = Path(self._tmp.name)
        self.repo = Path(self._repo.name)

    def tearDown(self):
        self._tmp.cleanup()
        self._repo.cleanup()

    def test_malware_blocked_when_scan_not_complete(self):
        _init_session(self.sd, self.repo, extra_steps={"scan": {"status": "pending"}})
        rc = pipeline_step(_args(step="malware", session=str(self.sd)))
        self.assertEqual(rc, 1)

    def test_health_blocked_when_scan_not_complete(self):
        _init_session(self.sd, self.repo, extra_steps={"scan": {"status": "running"}})
        rc = pipeline_step(_args(step="health", session=str(self.sd)))
        self.assertEqual(rc, 1)

    def test_secrets_runs_without_scan(self):
        """secrets has no dependency on scan — must be able to start immediately."""
        _init_session(self.sd, self.repo)
        with patch("reachable.cli.pipeline._step_secrets") as mock_fn:
            mock_fn.return_value = {"total": 0}
            rc = pipeline_step(_args(step="secrets", session=str(self.sd)))
            self.assertEqual(rc, 0)

    def test_iac_runs_without_scan(self):
        _init_session(self.sd, self.repo)
        with patch("reachable.cli.pipeline._step_iac") as mock_fn:
            mock_fn.return_value = {"total": 0}
            rc = pipeline_step(_args(step="iac", session=str(self.sd)))
            self.assertEqual(rc, 0)

    def test_malware_runs_after_scan(self):
        _init_session(self.sd, self.repo, extra_steps={"scan": {"status": "complete"}})
        with patch("reachable.cli.pipeline._step_malware") as mock_fn:
            mock_fn.return_value = {"malicious": 0}
            rc = pipeline_step(_args(step="malware", session=str(self.sd)))
            self.assertEqual(rc, 0)

    def test_unknown_step_returns_error(self):
        _init_session(self.sd, self.repo)
        rc = pipeline_step(_args(step="nonexistent", session=str(self.sd)))
        self.assertEqual(rc, 1)

    def test_missing_session_returns_error(self):
        rc = pipeline_step(_args(step="scan", session="/nonexistent/session/path"))
        self.assertEqual(rc, 1)


# ===========================================================================
# 4. scan step: Syft + Grype combined, temp file deleted
# ===========================================================================

class TestScanStepMerge(unittest.TestCase):

    def setUp(self):
        self._tmp = tempfile.TemporaryDirectory()
        self._repo = tempfile.TemporaryDirectory()
        self.sd = Path(self._tmp.name)
        self.repo = Path(self._repo.name)

    def tearDown(self):
        self._tmp.cleanup()
        self._repo.cleanup()

    def test_scan_writes_grype_vulns_not_sbom(self):
        """scan step output must be raw/grype-vulns.json — NOT sbom.json.gz."""
        from reachable.cli.pipeline import _step_scan

        sbom = _minimal_sbom()
        vulns = _minimal_grype_vulns()
        state = _init_session(self.sd, self.repo, commit="abc123")

        with patch("reachable.collectors.vulns.grype.get_syft_path") as mock_syft_p, \
             patch("reachable.collectors.vulns.grype.get_grype_path") as mock_grype_p, \
             patch("reachable.collectors.vulns.grype.VulnDBManager") as mock_db_mgr, \
             patch("subprocess.run") as mock_run, \
             patch("reachable.cli.pipeline._get_sbom_from_db"), \
             patch("reachable.database.storage.RepoDatabase"):

            mock_syft_p.return_value = Path("/fake/syft")
            mock_grype_p.return_value = Path("/fake/grype")
            mock_db_mgr.return_value.ensure_fresh.return_value = None
            mock_db_mgr.return_value.get_grype_env.return_value = {}

            syft_r = MagicMock(returncode=0, stdout=json.dumps(sbom))
            grype_r = MagicMock(returncode=0, stdout=json.dumps(vulns))
            mock_run.side_effect = [syft_r, grype_r]

            result = _step_scan(self.repo, self.sd, state, _args())

        # Output must be grype-vulns.json
        self.assertIn("grype-vulns.json", result.get("file", ""))
        self.assertTrue((self.sd / "raw" / "grype-vulns.json").exists())

    def test_scan_no_sbom_json_gz_artifact(self):
        """sbom.json.gz must NOT be written — it's a temp file only."""
        from reachable.cli.pipeline import _step_scan

        sbom = _minimal_sbom()
        vulns = _minimal_grype_vulns()
        state = _init_session(self.sd, self.repo, commit="abc123")

        with patch("reachable.collectors.vulns.grype.get_syft_path") as mock_syft_p, \
             patch("reachable.collectors.vulns.grype.get_grype_path") as mock_grype_p, \
             patch("reachable.collectors.vulns.grype.VulnDBManager") as mock_db_mgr, \
             patch("subprocess.run") as mock_run, \
             patch("reachable.database.storage.RepoDatabase"):

            mock_syft_p.return_value = Path("/fake/syft")
            mock_grype_p.return_value = Path("/fake/grype")
            mock_db_mgr.return_value.ensure_fresh.return_value = None
            mock_db_mgr.return_value.get_grype_env.return_value = {}

            syft_r = MagicMock(returncode=0, stdout=json.dumps(sbom))
            grype_r = MagicMock(returncode=0, stdout=json.dumps(vulns))
            mock_run.side_effect = [syft_r, grype_r]

            _step_scan(self.repo, self.sd, state, _args())

        self.assertFalse((self.sd / "sbom.json.gz").exists(),
            "sbom.json.gz must not be written — it's a temp file only")
        self.assertFalse((self.sd / "sbom.json").exists(),
            "sbom.json must not be written as a persistent artifact")

    def test_scan_caches_sbom_in_db(self):
        """SBOM dict must be cached in DB after scan step."""
        from reachable.cli.pipeline import _step_scan

        sbom = _minimal_sbom()
        vulns = _minimal_grype_vulns()

        with tempfile.NamedTemporaryFile(suffix=".db", delete=False) as f:
            fake_db = f.name

        try:
            state = _init_session(self.sd, self.repo, db_path=fake_db, commit="abc123def")

            with patch("reachable.collectors.vulns.grype.get_syft_path") as mock_syft_p, \
                 patch("reachable.collectors.vulns.grype.get_grype_path") as mock_grype_p, \
                 patch("reachable.collectors.vulns.grype.VulnDBManager") as mock_db_mgr, \
                 patch("subprocess.run") as mock_run, \
                 patch("reachable.database.storage.RepoDatabase") as mock_db_cls:

                mock_syft_p.return_value = Path("/fake/syft")
                mock_grype_p.return_value = Path("/fake/grype")
                mock_db_mgr.return_value.ensure_fresh.return_value = None
                mock_db_mgr.return_value.get_grype_env.return_value = {}
                mock_run.side_effect = [
                    MagicMock(returncode=0, stdout=json.dumps(sbom)),
                    MagicMock(returncode=0, stdout=json.dumps(vulns)),
                ]

                # Make db_path appear to exist
                Path(fake_db).touch()
                _step_scan(self.repo, self.sd, state, _args())

                # cache_sbom must have been called
                mock_db_instance = mock_db_cls.return_value
                self.assertTrue(mock_db_instance.cache_sbom.called,
                    "db.cache_sbom() must be called after scan step")

        finally:
            try:
                os.unlink(fake_db)
            except OSError:
                pass

    def test_temp_sbom_file_deleted(self):
        """The temp SBOM file must be deleted even if Grype fails."""
        from reachable.cli.pipeline import _step_scan

        sbom = _minimal_sbom()
        state = _init_session(self.sd, self.repo, commit="abc123")
        deleted_paths = []

        original_unlink = Path.unlink
        def track_unlink(self_p, **kw):
            deleted_paths.append(str(self_p))
            return original_unlink(self_p, **kw)

        with patch("reachable.collectors.vulns.grype.get_syft_path") as mock_syft_p, \
             patch("reachable.collectors.vulns.grype.get_grype_path") as mock_grype_p, \
             patch("reachable.collectors.vulns.grype.VulnDBManager") as mock_db_mgr, \
             patch("subprocess.run") as mock_run, \
             patch.object(Path, "unlink", track_unlink), \
             patch("reachable.database.storage.RepoDatabase"):

            mock_syft_p.return_value = Path("/fake/syft")
            mock_grype_p.return_value = Path("/fake/grype")
            mock_db_mgr.return_value.ensure_fresh.return_value = None
            mock_db_mgr.return_value.get_grype_env.return_value = {}

            # Grype fails — temp file must still be deleted
            mock_run.side_effect = [
                MagicMock(returncode=0, stdout=json.dumps(sbom)),
                MagicMock(returncode=1, stderr="grype error", stdout="{}"),
            ]

            with self.assertRaises(RuntimeError):
                _step_scan(self.repo, self.sd, state, _args())

        # At least one unlink was called (the temp sbom file)
        self.assertTrue(any("sbom-" in p for p in deleted_paths),
            f"Temp SBOM file was not deleted. Unlinked: {deleted_paths}")


# ===========================================================================
# 5. secrets step: secrets + CWE merged into one file
# ===========================================================================

class TestSecretsStepMerge(unittest.TestCase):

    def setUp(self):
        self._tmp = tempfile.TemporaryDirectory()
        self._repo = tempfile.TemporaryDirectory()
        self.sd = Path(self._tmp.name)
        self.repo = Path(self._repo.name)

    def tearDown(self):
        self._tmp.cleanup()
        self._repo.cleanup()

    def test_secrets_and_cwe_both_called(self):
        from reachable.cli.pipeline import _step_secrets

        mock_scanner = MagicMock()
        mock_scanner.scan_secrets.return_value = {"findings": [{"id": "s1"}]}
        mock_scanner.scan_cwe.return_value = {"findings": [{"id": "c1"}, {"id": "c2"}]}

        with patch("reachable.collectors.secrets.semgrep.SemgrepScanner", return_value=mock_scanner):
            result = _step_secrets(self.repo, self.sd, _args())

        mock_scanner.scan_secrets.assert_called_once()
        mock_scanner.scan_cwe.assert_called_once()
        self.assertEqual(result["secrets"], 1)
        self.assertEqual(result["cwe"], 2)
        self.assertEqual(result["total"], 3)

    def test_output_is_security_findings_json(self):
        from reachable.cli.pipeline import _step_secrets

        mock_scanner = MagicMock()
        mock_scanner.scan_secrets.return_value = {"findings": []}
        mock_scanner.scan_cwe.return_value = {"findings": []}

        with patch("reachable.collectors.secrets.semgrep.SemgrepScanner", return_value=mock_scanner):
            _step_secrets(self.repo, self.sd, _args())

        out = self.sd / "raw" / "security-findings.json"
        self.assertTrue(out.exists(), "raw/security-findings.json must exist")
        data = json.loads(out.read_text())
        self.assertIn("findings", data)

    def test_no_separate_cwe_json(self):
        """cwe.json must NOT be written — findings are merged into security-findings.json."""
        from reachable.cli.pipeline import _step_secrets

        mock_scanner = MagicMock()
        mock_scanner.scan_secrets.return_value = {"findings": []}
        mock_scanner.scan_cwe.return_value = {"findings": [{"id": "cwe1"}]}

        with patch("reachable.collectors.secrets.semgrep.SemgrepScanner", return_value=mock_scanner):
            _step_secrets(self.repo, self.sd, _args())

        self.assertFalse((self.sd / "raw" / "cwe.json").exists(),
            "cwe.json must not be written — merged into security-findings.json")

    def test_merged_findings_contain_both(self):
        from reachable.cli.pipeline import _step_secrets

        mock_scanner = MagicMock()
        mock_scanner.scan_secrets.return_value = {"findings": [{"id": "secret1", "type": "secret"}]}
        mock_scanner.scan_cwe.return_value = {"findings": [{"id": "cwe1", "type": "cwe"}]}

        with patch("reachable.collectors.secrets.semgrep.SemgrepScanner", return_value=mock_scanner):
            _step_secrets(self.repo, self.sd, _args())

        data = json.loads((self.sd / "raw" / "security-findings.json").read_text())
        ids = {f["id"] for f in data["findings"]}
        self.assertIn("secret1", ids)
        self.assertIn("cwe1", ids)


# ===========================================================================
# 6. malware step: reads SBOM from DB, no file read
# ===========================================================================

class TestMalwareDBFetch(unittest.TestCase):

    def setUp(self):
        self._tmp = tempfile.TemporaryDirectory()
        self._repo = tempfile.TemporaryDirectory()
        self.sd = Path(self._tmp.name)
        self.repo = Path(self._repo.name)

    def tearDown(self):
        self._tmp.cleanup()
        self._repo.cleanup()

    def test_malware_uses_db_not_file(self):
        from reachable.cli.pipeline import _step_malware

        sbom = _minimal_sbom()
        state = _init_session(self.sd, self.repo, commit="abc123")

        mock_scanner = MagicMock()
        mock_scanner.scan_from_sbom.return_value = {
            "packages_scanned": 2, "malicious_count": 0, "findings": []
        }

        with patch("reachable.cli.pipeline._get_sbom_from_db", return_value=sbom) as mock_db_fetch, \
             patch("reachable.collectors.malware.guarddog.GuardDogScanner", return_value=mock_scanner):

            result = _step_malware(self.repo, self.sd, state, _args())

        mock_db_fetch.assert_called_once_with(state)
        # scan_from_sbom called with the dict (not a file path)
        mock_scanner.scan_from_sbom.assert_called_once_with(sbom)
        self.assertEqual(result["packages_scanned"], 2)

    def test_malware_no_sbom_file_opened(self):
        """Malware step must not open any sbom file — reads from DB only."""
        from reachable.cli.pipeline import _step_malware

        sbom = _minimal_sbom()
        state = _init_session(self.sd, self.repo)

        mock_scanner = MagicMock()
        mock_scanner.scan_from_sbom.return_value = {
            "packages_scanned": 0, "malicious_count": 0, "findings": []
        }

        opened_files = []
        real_open = open
        def tracking_open(path, *a, **kw):
            opened_files.append(str(path))
            return real_open(path, *a, **kw)

        with patch("reachable.cli.pipeline._get_sbom_from_db", return_value=sbom), \
             patch("reachable.collectors.malware.guarddog.GuardDogScanner", return_value=mock_scanner), \
             patch("builtins.open", side_effect=tracking_open):

            _step_malware(self.repo, self.sd, state, _args())

        sbom_opens = [f for f in opened_files if "sbom" in f.lower()]
        self.assertEqual(len(sbom_opens), 0,
            f"Malware step opened SBOM file(s) — should read from DB: {sbom_opens}")

    def test_malware_fails_without_sbom_in_db(self):
        """Malware step must raise an error if SBOM not in DB cache."""
        from reachable.cli.pipeline import _step_malware

        state = _init_session(self.sd, self.repo)
        with patch("reachable.cli.pipeline._get_sbom_from_db", return_value=None):
            with self.assertRaises(RuntimeError):
                _step_malware(self.repo, self.sd, state, _args())


# ===========================================================================
# 7. health step: reads SBOM from DB
# ===========================================================================

class TestHealthDBFetch(unittest.TestCase):

    def setUp(self):
        self._tmp = tempfile.TemporaryDirectory()
        self._repo = tempfile.TemporaryDirectory()
        self.sd = Path(self._tmp.name)
        self.repo = Path(self._repo.name)

    def tearDown(self):
        self._tmp.cleanup()
        self._repo.cleanup()

    def test_health_uses_sbom_data_kwarg(self):
        """PackageHealthCollector must be instantiated with sbom_data= not sbom_path=."""
        from reachable.cli.pipeline import _step_health

        sbom = _minimal_sbom()
        state = _init_session(self.sd, self.repo)

        mock_collector = MagicMock()
        mock_report = MagicMock()
        mock_report.to_dict.return_value = {"total_packages": 2}
        mock_collector.collect.return_value = mock_report

        with patch("reachable.cli.pipeline._get_sbom_from_db", return_value=sbom), \
             patch("reachable.collectors.health.collector.PackageHealthCollector",
                   return_value=mock_collector) as mock_cls:

            result = _step_health(self.repo, self.sd, state, _args())

        # Must be called with sbom_data= kwarg
        call_kwargs = mock_cls.call_args[1] if mock_cls.call_args[1] else {}
        call_positional = mock_cls.call_args[0] if mock_cls.call_args else ()
        self.assertIn("sbom_data", call_kwargs,
            f"PackageHealthCollector not called with sbom_data= kwarg. "
            f"Called with: args={call_positional}, kwargs={call_kwargs}")
        self.assertEqual(call_kwargs["sbom_data"], sbom)
        self.assertEqual(result["packages_analyzed"], 2)

    def test_health_fails_without_sbom_in_db(self):
        from reachable.cli.pipeline import _step_health

        state = _init_session(self.sd, self.repo)
        with patch("reachable.cli.pipeline._get_sbom_from_db", return_value=None):
            with self.assertRaises(RuntimeError):
                _step_health(self.repo, self.sd, state, _args())


# ===========================================================================
# 8. finalize flow
# ===========================================================================

class TestFinalizeFlow(unittest.TestCase):

    def setUp(self):
        self._tmp = tempfile.TemporaryDirectory()
        self._repo = tempfile.TemporaryDirectory()
        self.sd = Path(self._tmp.name)
        self.repo = Path(self._repo.name)

    def tearDown(self):
        self._tmp.cleanup()
        self._repo.cleanup()

    def _make_finalize_state(self):
        import tempfile as tf
        db_fd, db_path = tf.mkstemp(suffix=".db")
        os.close(db_fd)
        state = _init_session(self.sd, self.repo, db_path=db_path, scan_id=99,
                              commit="abc123", extra_steps={"scan": {"status": "complete"}})
        # Write required raw/grype-vulns.json
        raw_dir = self.sd / "raw"
        raw_dir.mkdir(exist_ok=True)
        vulns = _minimal_grype_vulns()
        (raw_dir / "grype-vulns.json").write_text(json.dumps(vulns))
        return state, db_path

    def test_finalize_calls_reachability_then_ingest_then_dashboard(self):
        from reachable.cli.pipeline import pipeline_finalize

        state, db_path = self._make_finalize_state()
        call_order = []

        mock_ra = MagicMock()
        mock_ra.return_value.analyze.return_value = {"matches": []}

        mock_ingest = MagicMock()
        mock_ingest.return_value.total = 0
        mock_ingest.return_value.cve_count = 0
        mock_ingest.return_value.cwe_count = 0
        mock_ingest.return_value.secret_count = 0
        mock_ingest.return_value.malware_count = 0
        mock_ingest.return_value.suspicious_count = 0

        mock_db = MagicMock()
        mock_dashboard = MagicMock()
        mock_dashboard.return_value.generate_from_scan_dir.return_value = self.sd / "dashboard"

        def track_ra(*a, **kw): call_order.append("ra"); return mock_ra(*a, **kw)
        def track_ingest(*a, **kw): call_order.append("ingest"); return mock_ingest(*a, **kw)
        def track_dashboard(*a, **kw): call_order.append("dashboard"); return mock_dashboard(*a, **kw)

        with patch("reachable.engine.reachability.ReachabilityAnalyzer", side_effect=track_ra), \
             patch("reachable.database.ingester.ingest", side_effect=track_ingest), \
             patch("reachable.database.storage.RepoDatabase", return_value=mock_db), \
             patch("reachable.dashboard_v2.generator.DashboardV2Generator", side_effect=track_dashboard), \
             patch("reachable.cli.pipeline._get_sbom_from_db", return_value=_minimal_sbom()), \
             patch("reachable.collectors.vulns.purl_resolver.PURLResolver", MagicMock()):

            rc = pipeline_finalize(_args(session=str(self.sd)))

        self.assertEqual(rc, 0)
        self.assertEqual(call_order, ["ra", "ingest", "dashboard"],
            f"Wrong call order: {call_order}")

    def test_finalize_writes_cve_analyzed_json(self):
        from reachable.cli.pipeline import pipeline_finalize

        state, db_path = self._make_finalize_state()

        mock_ra = MagicMock()
        mock_ra.return_value.analyze.return_value = {"vulnerabilities": []}

        mock_ingest_r = MagicMock(total=0, cve_count=0, cwe_count=0,
                                  secret_count=0, malware_count=0, suspicious_count=0)

        with patch("reachable.engine.reachability.ReachabilityAnalyzer", mock_ra), \
             patch("reachable.database.ingester.ingest", return_value=mock_ingest_r), \
             patch("reachable.database.storage.RepoDatabase", MagicMock()), \
             patch("reachable.dashboard_v2.generator.DashboardV2Generator", MagicMock()), \
             patch("reachable.cli.pipeline._get_sbom_from_db", return_value=_minimal_sbom()), \
             patch("reachable.collectors.vulns.purl_resolver.PURLResolver", MagicMock()):

            pipeline_finalize(_args(session=str(self.sd)))

        cve_file = self.sd / "raw" / "cve-analyzed.json"
        self.assertTrue(cve_file.exists(), "raw/cve-analyzed.json must be written by finalize")

    def test_finalize_no_reachable_report_json(self):
        """reachable-report.json.gz must NOT be written — DB is source of truth."""
        from reachable.cli.pipeline import pipeline_finalize

        state, db_path = self._make_finalize_state()

        mock_ingest_r = MagicMock(total=0, cve_count=0, cwe_count=0,
                                  secret_count=0, malware_count=0, suspicious_count=0)

        with patch("reachable.engine.reachability.ReachabilityAnalyzer", MagicMock()), \
             patch("reachable.database.ingester.ingest", return_value=mock_ingest_r), \
             patch("reachable.database.storage.RepoDatabase", MagicMock()), \
             patch("reachable.dashboard_v2.generator.DashboardV2Generator", MagicMock()), \
             patch("reachable.cli.pipeline._get_sbom_from_db", return_value=_minimal_sbom()), \
             patch("reachable.collectors.vulns.purl_resolver.PURLResolver", MagicMock()):

            pipeline_finalize(_args(session=str(self.sd)))

        for dead_file in ["reachable-report.json", "reachable-report.json.gz",
                          "reachable-report_json.gz"]:
            self.assertFalse((self.sd / dead_file).exists(),
                f"{dead_file} must not be written — it is dead code")

    def test_finalize_no_store_scan_to_database(self):
        """store_scan_to_database must not exist in pipeline.py — it was deleted."""
        import reachable.cli.pipeline as pipeline_mod
        self.assertFalse(hasattr(pipeline_mod, "store_scan_to_database"),
            "store_scan_to_database was deleted from scan.py but still referenced in pipeline")

    def test_finalize_fails_when_scan_not_complete(self):
        from reachable.cli.pipeline import pipeline_finalize

        _init_session(self.sd, self.repo, extra_steps={"scan": {"status": "pending"}})
        (self.sd / "raw").mkdir(exist_ok=True)
        rc = pipeline_finalize(_args(session=str(self.sd)))
        self.assertEqual(rc, 1)

    def test_finalize_fails_when_grype_vulns_missing(self):
        from reachable.cli.pipeline import pipeline_finalize

        with tempfile.NamedTemporaryFile(suffix=".db") as f:
            state = _init_session(self.sd, self.repo, db_path=f.name, scan_id=1,
                                  extra_steps={"scan": {"status": "complete"}})
            # Do NOT write grype-vulns.json
            rc = pipeline_finalize(_args(session=str(self.sd)))
        self.assertEqual(rc, 1)


# ===========================================================================
# 9. Canonical file names match ingester RAW_FILE_REGISTRY
# ===========================================================================

class TestCanonicalFileNames(unittest.TestCase):
    """Verify that pipeline step output file names match what the ingester expects."""

    def _get_ingester_files(self):
        from reachable.database.ingester import RAW_FILE_REGISTRY
        files = set()
        for entry in RAW_FILE_REGISTRY:
            files.update(entry["files"])
        return files

    def test_security_findings_json_matches_ingester(self):
        ingester_files = self._get_ingester_files()
        self.assertIn("security-findings.json", ingester_files,
            "Ingester does not expect security-findings.json")

    def test_malware_json_matches_ingester(self):
        ingester_files = self._get_ingester_files()
        self.assertIn("malware.json", ingester_files)

    def test_cve_analyzed_json_matches_ingester(self):
        ingester_files = self._get_ingester_files()
        self.assertIn("cve-analyzed.json", ingester_files,
            "Ingester expects cve-analyzed.json — not grype-vulns.json (that's the RA input)")

    def test_grype_vulns_not_ingested(self):
        """grype-vulns.json is input to ReachabilityAnalyzer, NOT ingested directly."""
        ingester_files = self._get_ingester_files()
        self.assertNotIn("grype-vulns.json", ingester_files,
            "grype-vulns.json should NOT be in ingester — it feeds RA which produces cve-analyzed.json")

    def test_no_separate_cwe_json_in_ingester(self):
        """cwe.json is not a valid ingester file — findings must be in security-findings.json."""
        ingester_files = self._get_ingester_files()
        # If cwe.json is somehow in the registry, findings would be double-ingested
        # The correct behavior is: cwe findings are in security-findings.json
        for fname in ingester_files:
            self.assertNotEqual(fname, "cwe.json",
                "cwe.json should not be a standalone ingester file — merged into security-findings.json")


# ===========================================================================
# 10. pipeline init creates scan_id in DB
# ===========================================================================

class TestPipelineInitDB(unittest.TestCase):

    def test_init_stores_scan_id_in_state(self):
        from reachable.cli.pipeline import pipeline_init

        with tempfile.TemporaryDirectory() as repo_tmp, \
             tempfile.TemporaryDirectory() as scan_tmp:

            repo_path = Path(repo_tmp)
            mock_db = MagicMock()
            mock_db.start_scan.return_value = 42

            mock_output_mgr = MagicMock()
            mock_output_mgr.scan_dir = Path(scan_tmp)
            mock_output_mgr.timestamp = "20260304-120000-abc123"
            mock_output_mgr.repo_name = "test-repo"

            with patch("reachable.output.manager.OutputManager", return_value=mock_output_mgr), \
                 patch("reachable.database.storage.RepoDatabase", return_value=mock_db), \
                 patch("reachable.database.storage.get_repo_db_path",
                       return_value=Path(scan_tmp) / "repo.db"), \
                 patch("reachable.cli.pipeline._get_git_context", return_value=("main", "abc123")), \
                 patch("reachable.core.context.ScanContext", MagicMock()):

                rc = pipeline_init(_args(repo=str(repo_path)))

            self.assertEqual(rc, 0)
            mock_db.start_scan.assert_called_once()

            state = load_pipeline_state(Path(scan_tmp))
            self.assertEqual(state.get("scan_id"), 42)
            self.assertIn("db_path", state)

    def test_init_state_has_all_steps(self):
        from reachable.cli.pipeline import pipeline_init

        with tempfile.TemporaryDirectory() as repo_tmp, \
             tempfile.TemporaryDirectory() as scan_tmp:

            mock_db = MagicMock()
            mock_db.start_scan.return_value = 1
            mock_output_mgr = MagicMock()
            mock_output_mgr.scan_dir = Path(scan_tmp)
            mock_output_mgr.timestamp = "test-session"
            mock_output_mgr.repo_name = "repo"

            with patch("reachable.output.manager.OutputManager", return_value=mock_output_mgr), \
                 patch("reachable.database.storage.RepoDatabase", return_value=mock_db), \
                 patch("reachable.database.storage.get_repo_db_path",
                       return_value=Path(scan_tmp) / "repo.db"), \
                 patch("reachable.cli.pipeline._get_git_context", return_value=("main", "abc")), \
                 patch("reachable.core.context.ScanContext", MagicMock()):

                pipeline_init(_args(repo=str(Path(repo_tmp))))

            state = load_pipeline_state(Path(scan_tmp))
            self.assertSetEqual(set(state["steps"].keys()), set(PIPELINE_STEPS.keys()))


# ===========================================================================
# 11. SBOM cache roundtrip
# ===========================================================================

class TestSBOMCacheRoundtrip(unittest.TestCase):

    def test_sbom_from_db_returns_none_without_commit(self):
        state = {"db_path": "/fake/path", "commit": ""}
        result = _get_sbom_from_db(state)
        self.assertIsNone(result)

    def test_sbom_from_db_returns_none_without_db_path(self):
        state = {"db_path": "", "commit": "abc123"}
        result = _get_sbom_from_db(state)
        self.assertIsNone(result)

    def test_sbom_from_db_returns_none_when_db_missing(self):
        state = {"db_path": "/nonexistent/repo.db", "commit": "abc123"}
        result = _get_sbom_from_db(state)
        self.assertIsNone(result)

    def test_sbom_from_db_calls_get_cached_sbom(self):
        sbom = _minimal_sbom()
        mock_db = MagicMock()
        mock_db.get_cached_sbom.return_value = sbom

        with tempfile.NamedTemporaryFile(suffix=".db") as f:
            state = {"db_path": f.name, "commit": "abc123def456"}
            with patch("reachable.database.storage.RepoDatabase", return_value=mock_db):
                result = _get_sbom_from_db(state)

        mock_db.get_cached_sbom.assert_called_once_with("abc123def456")
        self.assertEqual(result, sbom)


# ===========================================================================
# 12. collector.py: parse_sbom_packages_from_dict
# ===========================================================================

class TestCollectorDictPath(unittest.TestCase):

    def test_parse_sbom_packages_from_dict_exists(self):
        from reachable.collectors.health.collector import parse_sbom_packages_from_dict
        self.assertTrue(callable(parse_sbom_packages_from_dict))

    def test_file_and_dict_paths_identical_output(self):
        from reachable.collectors.health.collector import (
            parse_sbom_packages,
            parse_sbom_packages_from_dict,
        )
        sbom = _minimal_sbom()
        with tempfile.NamedTemporaryFile(suffix=".json", mode="w", delete=False) as f:
            json.dump(sbom, f)
            tmp_path = Path(f.name)
        try:
            from_file = parse_sbom_packages(tmp_path)
            from_dict = parse_sbom_packages_from_dict(sbom)
            self.assertEqual(from_file, from_dict,
                "parse_sbom_packages_from_dict must produce identical output to parse_sbom_packages")
        finally:
            tmp_path.unlink()

    def test_package_health_collector_accepts_sbom_data(self):
        import inspect

        from reachable.collectors.health.collector import PackageHealthCollector
        sig = inspect.signature(PackageHealthCollector.__init__)
        self.assertIn("sbom_data", sig.parameters,
            "PackageHealthCollector.__init__ must accept sbom_data= kwarg")

    def test_package_health_collector_sbom_data_kwarg(self):
        """PackageHealthCollector(sbom_data=...) must not try to open a file."""
        from reachable.collectors.health.collector import PackageHealthCollector

        sbom = _minimal_sbom()
        collector = PackageHealthCollector(sbom_data=sbom)
        self.assertIsNotNone(collector._sbom_data)
        self.assertEqual(collector._sbom_data, sbom)


# ===========================================================================
# 13. Concurrent sidecar safety (regression for BUG-RACE)
# ===========================================================================

def _worker_write_sidecar(args):
    """Worker: write running then complete sidecar for a step."""
    session_dir, step_name = args
    from reachable.cli.pipeline import save_step_state
    save_step_state(session_dir, step_name, {"status": "running", "pid": os.getpid()})
    import time
    time.sleep(0.02)
    save_step_state(session_dir, step_name, {"status": "complete", "pid": os.getpid()})


class TestConcurrentStateSafety(unittest.TestCase):

    def test_parallel_sidecars_no_corruption(self):
        """All 4 parallel steps writing sidecars concurrently must produce valid JSON."""
        with tempfile.TemporaryDirectory() as tmp:
            sd = Path(tmp)
            with tempfile.TemporaryDirectory() as repo_tmp:
                _init_session(sd, Path(repo_tmp))

            pool_args = [(sd, step) for step in PARALLEL_STEPS]
            with multiprocessing.Pool(len(PARALLEL_STEPS)) as pool:
                pool.map(_worker_write_sidecar, pool_args)

            from reachable.cli.pipeline import load_pipeline_state
            state = load_pipeline_state(sd)
            for step in PARALLEL_STEPS:
                step_state = state["steps"][step]
                self.assertEqual(step_state.get("status"), "complete",
                    f"Step '{step}' sidecar corrupted or missing after concurrent writes")

    def test_sidecar_files_are_independent(self):
        """Each step writes its own file — no file is shared between steps."""
        with tempfile.TemporaryDirectory() as tmp:
            sd = Path(tmp)
            with tempfile.TemporaryDirectory() as repo_tmp:
                _init_session(sd, Path(repo_tmp))

            from reachable.cli.pipeline import _get_step_state_path
            paths = [str(_get_step_state_path(sd, step)) for step in PIPELINE_STEPS]
            self.assertEqual(len(set(paths)), len(paths),
                "All step sidecar paths must be unique")


# ===========================================================================
# 14. _count_by_severity
# ===========================================================================

class TestCountBySeverity(unittest.TestCase):

    def test_empty_matches(self):
        self.assertEqual(_count_by_severity([]), {"CRITICAL": 0, "HIGH": 0, "MEDIUM": 0, "LOW": 0, "UNKNOWN": 0})

    def test_counts_correctly(self):
        matches = [
            {"vulnerability": {"severity": "CRITICAL"}},
            {"vulnerability": {"severity": "HIGH"}},
            {"vulnerability": {"severity": "HIGH"}},
            {"vulnerability": {"severity": "MEDIUM"}},
        ]
        result = _count_by_severity(matches)
        self.assertEqual(result["CRITICAL"], 1)
        self.assertEqual(result["HIGH"], 2)
        self.assertEqual(result["MEDIUM"], 1)

    def test_case_insensitive(self):
        matches = [
            {"vulnerability": {"severity": "critical"}},
            {"vulnerability": {"severity": "High"}},
        ]
        result = _count_by_severity(matches)
        self.assertEqual(result["CRITICAL"], 1)
        self.assertEqual(result["HIGH"], 1)

    def test_missing_severity_is_unknown(self):
        matches = [{"vulnerability": {}}]
        result = _count_by_severity(matches)
        self.assertEqual(result["UNKNOWN"], 1)


# ===========================================================================
# 15. _resolve_session_dir
# ===========================================================================

class TestResolveSessionDir(unittest.TestCase):

    def test_direct_path(self):
        with tempfile.TemporaryDirectory() as tmp:
            result = _resolve_session_dir(tmp)
            self.assertEqual(result, Path(tmp))

    def test_none_input(self):
        self.assertIsNone(_resolve_session_dir(None))

    def test_nonexistent_path(self):
        self.assertIsNone(_resolve_session_dir("/this/does/not/exist/abc123"))

    def test_empty_string(self):
        self.assertIsNone(_resolve_session_dir(""))


# ===========================================================================
# Main
# ===========================================================================

if __name__ == "__main__":
    unittest.main(verbosity=2)
