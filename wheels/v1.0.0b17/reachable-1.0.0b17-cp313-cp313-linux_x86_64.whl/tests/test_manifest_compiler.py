#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.

"""Tests for RADR manifest compiler (v5.6)."""

import json
import os
import tempfile
import unittest

from reachable.core.manifest_compiler import (
    _build_active_findings,
    _build_baseline_profile,
    _build_correlated_signals,
    _build_entrypoints,
    _build_probe_targets,
    _build_radr_capabilities,
    _compute_digest,
    _looks_like_go,
    _looks_like_java,
    _looks_like_node,
    _split_java_method,
    compile_manifest,
)


def _make_scan_dir(provenance=None, callable_funcs=None, internal_eps=None, report=None, scan_manifest=None):
    """Create a temp scan directory with the given JSON files."""
    tmpdir = tempfile.mkdtemp()

    if provenance is not None:
        with open(os.path.join(tmpdir, "provenance.json"), "w") as f:
            json.dump(provenance, f)

    if callable_funcs is not None:
        with open(os.path.join(tmpdir, "callable-functions.json"), "w") as f:
            json.dump(callable_funcs, f)

    if internal_eps is not None:
        with open(os.path.join(tmpdir, "internal-entrypoints.json"), "w") as f:
            json.dump(internal_eps, f)

    if report is not None:
        with open(os.path.join(tmpdir, "reachable-report.json"), "w") as f:
            json.dump(report, f)

    if scan_manifest is not None:
        with open(os.path.join(tmpdir, "scan-manifest.json"), "w") as f:
            json.dump(scan_manifest, f)

    return tmpdir


# Sample data fixtures
SAMPLE_PROVENANCE = {
    "source": {
        "commit_sha": "abc123def456",
        "branch": "main",
        "tag": "v1.2.3",
        "remote_url": "github.com/acme/backend",
        "dirty": False,
    },
    "ci": {
        "ci_provider": "github-actions",
        "ci_run_id": "12345678",
        "ci_run_url": "https://github.com/acme/backend/actions/runs/12345678",
    },
    "image": {
        "image_tag": "ghcr.io/acme/backend:v1.2.3",
        "image_digest": "sha256:abcdef1234567890",
    },
}

SAMPLE_CALLABLE_FUNCS = {
    "schema_version": "1.0",
    "statistics": {
        "total_packages": 2,
        "total_lib_functions_called": 4,
        "reachable_lib_functions": 3,
        "total_app_to_lib_edges": 6,
    },
    "packages": {
        "requests": {
            "function_count": 2,
            "functions": {
                "requests.api.get": {
                    "callers": [{"function": "app.api.fetch_data", "file": "app/api.py", "line": 42}],
                    "entrypoints": ["app.main.Flask.route./api/data"],
                    "call_depth": 2,
                    "is_reachable": True,
                    "cves": [],
                },
                "requests.adapters.HTTPAdapter.send": {
                    "callers": [{"function": "app.api.fetch_data", "file": "app/api.py", "line": 42}],
                    "entrypoints": ["app.main.Flask.route./api/data"],
                    "call_depth": 3,
                    "is_reachable": True,
                    "cves": ["CVE-2023-32681"],
                },
            },
        },
        "yaml": {
            "function_count": 2,
            "functions": {
                "yaml.safe_load": {
                    "callers": [{"function": "app.config.load", "file": "app/config.py", "line": 18}],
                    "entrypoints": [],
                    "call_depth": 1,
                    "is_reachable": True,
                    "cves": [],
                },
                "yaml.load": {
                    "callers": [{"function": "app.config.load_unsafe", "file": "app/config.py", "line": 25}],
                    "entrypoints": [],
                    "call_depth": 1,
                    "is_reachable": False,
                    "cves": ["CVE-2020-14343"],
                },
            },
        },
    },
}

SAMPLE_INTERNAL_EPS = {
    "schema_version": "1.0",
    "statistics": {
        "total": 3,
        "by_type": {"timer": 1, "queue": 1, "thread": 1},
    },
    "entrypoints": [
        {
            "function": "app.tasks.send_email",
            "type": "queue",
            "framework": "celery",
            "handler": "send_email",
            "confidence": "HIGH",
        },
        {
            "function": "app.jobs.daily_report",
            "type": "timer",
            "framework": "schedule",
            "handler": "daily_report",
            "schedule": 'every().day.at("00:00")',
            "confidence": "HIGH",
        },
        {
            "function": "app.workers.bg_sync",
            "type": "thread",
            "framework": "threading",
            "handler": "bg_sync",
            "confidence": "MEDIUM",
        },
    ],
}

SAMPLE_REPORT = {
    "metadata": {
        "entrypoints": [
            "app.main.Flask.route./api/data",
            "app.main.Flask.route./api/users",
        ],
    },
    "reachable": {
        "CVE-2023-32681": {
            "package": "requests",
            "version": "2.28.0",
            "vulnerable_function": "requests.adapters.HTTPAdapter.send",
            "severity": "HIGH",
            "epss_score": 0.45,
        },
        "CVE-2020-14343": {
            "package": "pyyaml",
            "version": "5.4.1",
            "vulnerable_function": "yaml.load",
            "severity": "CRITICAL",
            "epss_score": 0.87,
        },
    },
    "detailed_findings": {
        "secrets": {"findings": [{"type": "api_key", "file": "config.py"}]},
        "cwe": {"findings": [{"cwe_id": "CWE-79"}]},
        "malware": {"findings": []},
    },
}


class TestLanguageDetection(unittest.TestCase):
    """Test language detection heuristics."""

    def test_go_detection(self):
        self.assertTrue(_looks_like_go("net/http.(*Client).Do"))
        self.assertTrue(_looks_like_go("github.com/jackc/pgx/v5.(*Conn).Query"))
        self.assertFalse(_looks_like_go("requests.get"))

    def test_java_detection(self):
        self.assertTrue(_looks_like_java("org.apache.http.impl.client.CloseableHttpClient.execute"))
        self.assertTrue(_looks_like_java("com.fasterxml.jackson.databind.ObjectMapper.readValue"))
        self.assertFalse(_looks_like_java("requests.get"))

    def test_node_detection(self):
        self.assertTrue(_looks_like_node("express.Router.get", "express"))
        self.assertTrue(_looks_like_node("something", "@scope/pkg"))
        self.assertFalse(_looks_like_node("requests.get", "requests"))

    def test_java_method_split(self):
        cls, method = _split_java_method("org.apache.http.Client.execute")
        self.assertEqual(cls, "org.apache.http.Client")
        self.assertEqual(method, "execute")

    def test_java_method_split_no_dot(self):
        cls, method = _split_java_method("SomeClass")
        self.assertEqual(cls, "SomeClass")
        self.assertEqual(method, "")


class TestProbeTargets(unittest.TestCase):
    """Test probe target generation."""

    def test_python_probes(self):
        result = _build_probe_targets(SAMPLE_CALLABLE_FUNCS, SAMPLE_REPORT)
        self.assertIn("interpreter_probes", result)
        python_probe = result["interpreter_probes"][0]
        self.assertEqual(python_probe["language"], "python")
        self.assertEqual(python_probe["probe_type"], "uprobe")
        self.assertIn("requests", python_probe["monitored_modules"])
        self.assertIn("yaml", python_probe["monitored_modules"])

    def test_cve_risk_propagation(self):
        result = _build_probe_targets(SAMPLE_CALLABLE_FUNCS, SAMPLE_REPORT)
        python_probe = result["interpreter_probes"][0]
        # requests.adapters.HTTPAdapter.send should have HIGH risk
        req_funcs = python_probe["monitored_modules"]["requests"]["functions"]
        send_entry = req_funcs.get("requests.adapters.HTTPAdapter.send", {})
        self.assertGreater(send_entry.get("risk", 0), 0)

    def test_go_probes(self):
        go_callable = {
            "packages": {
                "net/http": {
                    "functions": {
                        "net/http.(*Client).Do": {
                            "callers": [],
                            "entrypoints": [],
                            "is_reachable": True,
                            "cves": [],
                        },
                    },
                },
            },
            "statistics": {},
        }
        result = _build_probe_targets(go_callable, None)
        self.assertIn("binary_probes", result)
        self.assertEqual(result["binary_probes"][0]["language"], "go")

    def test_java_probes(self):
        java_callable = {
            "packages": {
                "apache-http": {
                    "functions": {
                        "org.apache.http.Client.execute": {
                            "callers": [],
                            "entrypoints": [],
                            "is_reachable": True,
                            "cves": [],
                        },
                    },
                },
            },
            "statistics": {},
        }
        result = _build_probe_targets(java_callable, None)
        self.assertIn("jvm_probes", result)
        self.assertEqual(result["jvm_probes"][0]["language"], "java")
        self.assertIn("org.apache.http.Client", result["jvm_probes"][0]["classes"])

    def test_empty_callable(self):
        result = _build_probe_targets({"packages": {}, "statistics": {}}, None)
        self.assertEqual(result, {})


class TestEntrypoints(unittest.TestCase):
    """Test entrypoint compilation."""

    def test_http_plus_internal(self):
        eps = _build_entrypoints(SAMPLE_INTERNAL_EPS, SAMPLE_REPORT)
        # 2 HTTP + 3 internal = 5
        self.assertEqual(len(eps), 5)
        # First two should be HTTP
        self.assertEqual(eps[0]["type"], "http_handler")
        self.assertEqual(eps[1]["type"], "http_handler")
        # Internal ones
        types = [ep["type"] for ep in eps[2:]]
        self.assertIn("queue", types)
        self.assertIn("timer", types)
        self.assertIn("thread", types)

    def test_unique_ids(self):
        eps = _build_entrypoints(SAMPLE_INTERNAL_EPS, SAMPLE_REPORT)
        ids = [ep["id"] for ep in eps]
        self.assertEqual(len(ids), len(set(ids)))

    def test_schedule_preserved(self):
        eps = _build_entrypoints(SAMPLE_INTERNAL_EPS, None)
        timer_eps = [ep for ep in eps if ep["type"] == "timer"]
        self.assertEqual(len(timer_eps), 1)
        self.assertIn("schedule", timer_eps[0])

    def test_no_inputs(self):
        eps = _build_entrypoints(None, None)
        self.assertEqual(eps, [])


class TestActiveFindings(unittest.TestCase):
    """Test active findings generation."""

    def test_findings_from_report(self):
        findings = _build_active_findings(SAMPLE_CALLABLE_FUNCS, SAMPLE_REPORT)
        self.assertEqual(len(findings), 2)

    def test_called_function_detection(self):
        findings = _build_active_findings(SAMPLE_CALLABLE_FUNCS, SAMPLE_REPORT)
        # requests.adapters.HTTPAdapter.send IS in callable functions
        http_finding = next(f for f in findings if f["cve_id"] == "CVE-2023-32681")
        self.assertTrue(http_finding["is_called"])
        self.assertEqual(http_finding["reachability_status"], "confirmed_callable")

    def test_uncalled_function(self):
        # yaml.load IS in callable functions (so it should be called)
        findings = _build_active_findings(SAMPLE_CALLABLE_FUNCS, SAMPLE_REPORT)
        yaml_finding = next(f for f in findings if f["cve_id"] == "CVE-2020-14343")
        self.assertTrue(yaml_finding["is_called"])

    def test_severity_ordering(self):
        findings = _build_active_findings(SAMPLE_CALLABLE_FUNCS, SAMPLE_REPORT)
        # CRITICAL should come before HIGH
        self.assertEqual(findings[0]["severity"], "CRITICAL")
        self.assertEqual(findings[1]["severity"], "HIGH")

    def test_no_report(self):
        findings = _build_active_findings(SAMPLE_CALLABLE_FUNCS, None)
        self.assertEqual(findings, [])


class TestBaselineProfile(unittest.TestCase):
    """Test baseline profile generation."""

    def test_baseline_functions(self):
        eps = _build_entrypoints(SAMPLE_INTERNAL_EPS, SAMPLE_REPORT)
        baseline = _build_baseline_profile(SAMPLE_CALLABLE_FUNCS, eps)
        # 3 reachable functions (yaml.load is not reachable)
        self.assertEqual(baseline["function_count"], 3)
        self.assertIn("requests.api.get", baseline["expected_functions"])
        self.assertNotIn("yaml.load", baseline["expected_functions"])

    def test_baseline_entrypoints(self):
        eps = _build_entrypoints(SAMPLE_INTERNAL_EPS, SAMPLE_REPORT)
        baseline = _build_baseline_profile(SAMPLE_CALLABLE_FUNCS, eps)
        self.assertEqual(baseline["entrypoint_count"], 5)
        self.assertGreater(len(baseline["expected_entrypoints"]), 0)


class TestRadrCapabilities(unittest.TestCase):
    """Test RADR capabilities section."""

    def test_coverage_flags(self):
        caps = _build_radr_capabilities(SAMPLE_INTERNAL_EPS, SAMPLE_CALLABLE_FUNCS)
        coverage = caps["entrypoint_coverage"]
        self.assertTrue(coverage["http_handlers"])
        self.assertTrue(coverage["queue_consumers"])
        self.assertTrue(coverage["schedulers"])
        self.assertTrue(coverage["background_threads"])

    def test_no_internal_eps(self):
        caps = _build_radr_capabilities(None, SAMPLE_CALLABLE_FUNCS)
        coverage = caps["entrypoint_coverage"]
        self.assertTrue(coverage["http_handlers"])
        self.assertFalse(coverage["queue_consumers"])

    def test_call_graph_stats(self):
        caps = _build_radr_capabilities(SAMPLE_INTERNAL_EPS, SAMPLE_CALLABLE_FUNCS)
        cg = caps["call_graph_confidence"]
        self.assertEqual(cg["static_edges"], 6)
        self.assertEqual(cg["lib_functions_tracked"], 4)


class TestCorrelatedSignals(unittest.TestCase):
    """Test correlated signal extraction."""

    def test_signals_from_report(self):
        signals = _build_correlated_signals(SAMPLE_REPORT)
        types = [s["signal_type"] for s in signals]
        self.assertIn("secrets", types)
        self.assertIn("code_weaknesses", types)
        # malware has empty findings, should not appear
        self.assertNotIn("malware", types)

    def test_no_report(self):
        signals = _build_correlated_signals(None)
        self.assertEqual(signals, [])


class TestCompileManifest(unittest.TestCase):
    """Integration tests for full manifest compilation."""

    def test_full_compilation(self):
        scan_dir = _make_scan_dir(
            provenance=SAMPLE_PROVENANCE,
            callable_funcs=SAMPLE_CALLABLE_FUNCS,
            internal_eps=SAMPLE_INTERNAL_EPS,
            report=SAMPLE_REPORT,
        )
        manifest = compile_manifest(scan_dir)

        # Top-level structure
        self.assertEqual(manifest["manifest_version"], "1.0.0")
        self.assertIn("generated_at", manifest)
        self.assertEqual(manifest["commit"], "abc123def456")
        self.assertEqual(manifest["branch"], "main")
        self.assertEqual(manifest["image_tag"], "ghcr.io/acme/backend:v1.2.3")

        # Sections exist
        self.assertIn("probe_targets", manifest)
        self.assertIn("entrypoints", manifest)
        self.assertIn("active_findings", manifest)
        self.assertIn("baseline_profile", manifest)
        self.assertIn("radr_capabilities", manifest)
        self.assertIn("anomaly_detection", manifest)
        self.assertIn("digest", manifest)

    def test_cli_image_override(self):
        scan_dir = _make_scan_dir(
            provenance=SAMPLE_PROVENANCE,
            callable_funcs=SAMPLE_CALLABLE_FUNCS,
        )
        manifest = compile_manifest(
            scan_dir,
            image_tag="custom:latest",
            image_digest="sha256:override",
        )
        self.assertEqual(manifest["image_tag"], "custom:latest")
        self.assertEqual(manifest["image_digest"], "sha256:override")

    def test_output_file_written(self):
        scan_dir = _make_scan_dir(
            provenance=SAMPLE_PROVENANCE,
            callable_funcs=SAMPLE_CALLABLE_FUNCS,
        )
        output = os.path.join(scan_dir, "manifest.json")
        compile_manifest(scan_dir, output_path=output)
        self.assertTrue(os.path.exists(output))
        with open(output) as f:
            written = json.load(f)
        self.assertEqual(written["manifest_version"], "1.0.0")

    def test_empty_scan_dir(self):
        scan_dir = _make_scan_dir()
        manifest = compile_manifest(scan_dir)
        # Should still produce a valid manifest
        self.assertEqual(manifest["manifest_version"], "1.0.0")
        self.assertEqual(manifest["entrypoints"], [])
        self.assertEqual(manifest["active_findings"], [])
        self.assertEqual(manifest["probe_targets"], {})

    def test_digest_computed(self):
        scan_dir = _make_scan_dir(callable_funcs=SAMPLE_CALLABLE_FUNCS)
        manifest = compile_manifest(scan_dir)
        self.assertTrue(manifest["digest"].startswith("sha256:"))
        self.assertEqual(len(manifest["digest"]), 71)  # sha256: + 64 hex chars

    def test_provenance_only(self):
        scan_dir = _make_scan_dir(provenance=SAMPLE_PROVENANCE)
        manifest = compile_manifest(scan_dir)
        self.assertEqual(manifest["repo"], "github.com/acme/backend")
        self.assertEqual(manifest["tag"], "v1.2.3")
        self.assertEqual(manifest["build"]["ci_provider"], "github-actions")

    def test_anomaly_detection_config(self):
        scan_dir = _make_scan_dir()
        manifest = compile_manifest(scan_dir)
        ad = manifest["anomaly_detection"]
        self.assertEqual(ad["mode"], "observe_and_compare")
        self.assertIn("impossible", ad["alert_on"])
        self.assertEqual(ad["baseline_window_days"], 7)


class TestComputeDigest(unittest.TestCase):
    """Test digest computation."""

    def test_deterministic(self):
        data = b"test data"
        d1 = _compute_digest(data)
        d2 = _compute_digest(data)
        self.assertEqual(d1, d2)

    def test_format(self):
        d = _compute_digest(b"hello")
        self.assertTrue(d.startswith("sha256:"))


if __name__ == "__main__":
    unittest.main()
