#!/usr/bin/env python3
# REACHABLE DLP Module - Unit Tests
# Copyright (c) 2026 Sthenos Security. All rights reserved.

"""
DLP Unit Tests - Test core DLP functionality.

Run with:
    pytest tests/test_dlp_unit.py -v
    reachctl selftest --unit
"""

import sys
from pathlib import Path

import pytest

# Add parent to path for imports
sys.path.insert(0, str(Path(__file__).parent.parent))


class TestFileClassifier:
    """Test file classification."""

    def test_fixture_detection(self):
        """Test fixture files are classified correctly."""
        from reachable.dlp.discovery.file_classifier import FileClass, FileClassifier

        classifier = FileClassifier()

        fixture_paths = [
            Path("/app/fixtures/users.json"),
            Path("/app/testdata/sample.csv"),
            Path("/app/__mocks__/api.js"),
            Path("/app/seed/data.sql"),
        ]

        for path in fixture_paths:
            result = classifier.classify(path)
            assert result.file_class == FileClass.FIXTURE, f"Should be FIXTURE: {path}"
            assert result.risk_modifier < 1.0, f"Fixture should have reduced risk: {path}"

    def test_source_detection(self):
        """Test source files are classified correctly."""
        from reachable.dlp.discovery.file_classifier import FileClass, FileClassifier

        classifier = FileClassifier()

        source_paths = [
            Path("/app/src/main.py"),
            Path("/app/api/handler.js"),
            Path("/app/service.go"),
        ]

        for path in source_paths:
            result = classifier.classify(path)
            assert result.file_class == FileClass.SOURCE, f"Should be SOURCE: {path}"

    def test_generated_detection(self):
        """Test generated directories are classified correctly."""
        from reachable.dlp.discovery.file_classifier import FileClass, FileClassifier

        classifier = FileClassifier()

        generated_paths = [
            Path("/app/node_modules/lodash/index.js"),
            Path("/app/.venv/lib/python3.9/site.py"),
            Path("/app/vendor/github.com/pkg/file.go"),
            Path("/app/__pycache__/module.pyc"),
        ]

        for path in generated_paths:
            result = classifier.classify(path)
            assert result.file_class == FileClass.GENERATED, f"Should be GENERATED: {path}"
            assert result.risk_modifier < 0.5, f"Generated should have very low risk: {path}"


class TestDLPFinding:
    """Test DLPFinding dataclass."""

    def test_discovery_finding_creation(self):
        """Test creating a discovery finding."""
        from reachable.dlp.schema import DLPFinding, DLPFindingType, FileClass, PIIEntityType

        finding = DLPFinding.create_discovery(
            file_path="/app/config.py",
            line_start=42,
            pii_type=PIIEntityType.SSN,
            pii_sample="***-**-8350",
            file_class=FileClass.SOURCE,
        )

        assert finding.finding_type == DLPFindingType.PII_DISCOVERY
        assert finding.pii_type == PIIEntityType.SSN
        assert finding.file_path == "/app/config.py"
        assert finding.line_start == 42
        assert len(finding.finding_id) > 0
        assert "GDPR" in finding.regulations or "CCPA" in finding.regulations

    def test_taint_finding_creation(self):
        """Test creating a taint finding."""
        from reachable.dlp.schema import DLPFinding, DLPFindingType, PIIEntityType, SinkType

        finding = DLPFinding.create_taint(
            file_path="/app/api.py",
            line_start=100,
            pii_type=PIIEntityType.EMAIL,
            source="user_email",
            sink="openai.chat.completions.create",
            sink_type=SinkType.LLM_API,
        )

        assert finding.finding_type == DLPFindingType.PII_AI  # LLM sink → PII_AI
        assert finding.pii_type == PIIEntityType.EMAIL
        assert finding.sink_type == SinkType.LLM_API
        assert finding.risk_score > 50  # LLM sink is high risk

    def test_risk_score_calculation(self):
        """Test risk score calculation with modifiers."""
        from reachable.dlp.schema import DLPFinding, FileClass, PIIEntityType

        # High risk: SSN in source code (RESTRICTED tier + REACHABLE)
        # Expected: base=90, no modifiers → risk_score=90
        high_risk = DLPFinding.create_discovery(
            file_path="/app/handler.py",
            line_start=10,
            pii_type=PIIEntityType.SSN,
            file_class=FileClass.SOURCE,
            reachability_state="REACHABLE",
        )

        # Low risk: Same SSN in fixture (RESTRICTED tier + NOT_REACHABLE)
        # Expected: base=90, NOT_REACHABLE=-20 → risk_score=70
        low_risk = DLPFinding.create_discovery(
            file_path="/app/fixtures/test.json",
            line_start=10,
            pii_type=PIIEntityType.SSN,
            file_class=FileClass.FIXTURE,
            reachability_state="NOT_REACHABLE",
        )

        assert high_risk.risk_score > low_risk.risk_score
        assert high_risk.risk_score == 90  # RESTRICTED tier base
        assert low_risk.risk_score == 70  # Base 90 - 20 for NOT_REACHABLE

        # Verify severity changed even though risk_score is similar
        assert high_risk.adjusted_severity == "CRITICAL"  # REACHABLE
        assert low_risk.adjusted_severity == "MEDIUM"  # NOT_REACHABLE

    def test_sanitizer_reduces_risk(self):
        """Test that sanitizer presence reduces risk score (v2.0.0: metadata only, -5 points)."""
        from reachable.dlp.schema import DLPFinding, PIIEntityType, SinkType

        unsanitized = DLPFinding.create_taint(
            file_path="/app/api.py",
            line_start=100,
            pii_type=PIIEntityType.SSN,
            source="user_ssn",
            sink="logger.info",
            sink_type=SinkType.LOG,
            sanitizer_present=False,
        )

        sanitized = DLPFinding.create_taint(
            file_path="/app/api.py",
            line_start=100,
            pii_type=PIIEntityType.SSN,
            source="user_ssn",
            sink="logger.info",
            sink_type=SinkType.LOG,
            sanitizer_present=True,
        )

        # v2.0.0: Sanitizers reduce risk_score by 5 points (for sorting priority)
        # They do NOT change severity (both remain CRITICAL)
        assert sanitized.risk_score < unsanitized.risk_score
        assert unsanitized.risk_score - sanitized.risk_score == 5  # Exactly 5 points
        assert sanitized.adjusted_severity == unsanitized.adjusted_severity  # Same severity


class TestDLPScanConfig:
    """Test DLP scan configuration."""

    def test_full_config(self):
        """Test full configuration enables all features."""
        from reachable.dlp.config import DLPScanConfig

        config = DLPScanConfig.full()

        # P2.45: enable_discovery removed - Semgrep taint only
        assert not hasattr(config, "enable_discovery")
        assert config.enable_taint == True
        assert config.enable_ai_sinks == True
        # preset_name should be "full" if attribute exists
        if hasattr(config, "preset_name"):
            assert config.preset_name == "full"

    def test_quick_config(self):
        """Test quick configuration for fast scans."""
        from reachable.dlp.config import DLPScanConfig

        config = DLPScanConfig.quick()

        # Should only scan critical PII
        pii_types = config.get_pii_types()
        assert len(pii_types) < 10  # Limited PII types

    def test_pci_config(self):
        """Test PCI-DSS focused configuration."""
        from reachable.dlp.config import DLPScanConfig
        from reachable.dlp.schema import PIIEntityType

        config = DLPScanConfig.pci()

        pii_types = config.get_pii_types()
        assert PIIEntityType.CREDIT_CARD in pii_types
        assert PIIEntityType.CVV in pii_types


class TestTaintSources:
    """Test taint source detection."""

    def test_http_sources(self):
        """Test HTTP input sources are detected."""
        import re

        from reachable.dlp.taint.sources import PYTHON_PII_SOURCES

        http_code = [
            "data = request.json",
            "email = request.form['email']",
            "user_id = request.args.get('id')",
        ]

        for line in http_code:
            found = False
            for source_type, patterns in PYTHON_PII_SOURCES.items():
                for pattern in patterns:
                    if re.search(pattern, line, re.IGNORECASE):
                        found = True
                        break
            assert found, f"Should detect source in: {line}"

    def test_pii_attribute_sources(self):
        """Test PII attribute access is detected."""
        import re

        from reachable.dlp.taint.sources import PYTHON_PII_SOURCES

        pii_code = [
            "ssn = user.ssn",
            "card = data['credit_card']",
            "email = customer.email_address",
        ]

        for line in pii_code:
            found = False
            for source_type, patterns in PYTHON_PII_SOURCES.items():
                for pattern in patterns:
                    if re.search(pattern, line, re.IGNORECASE):
                        found = True
                        break
            assert found, f"Should detect PII attribute in: {line}"


class TestTaintSinks:
    """Test taint sink detection."""

    def test_llm_sinks(self):
        """Test LLM API sinks are detected."""
        import re

        from reachable.dlp.taint.sinks import PYTHON_DLP_SINKS, DLPSinkType, is_llm_sink

        llm_code = [
            "openai.chat.completions.create(messages=data)",
            "client.messages.create(messages=[msg])",
            "chain.invoke(user_input)",
        ]

        for line in llm_code:
            found = False
            for sink_type, patterns in PYTHON_DLP_SINKS.items():
                for pattern in patterns:
                    if re.search(pattern, line, re.IGNORECASE):
                        found = True
                        assert is_llm_sink(sink_type) or sink_type == DLPSinkType.LLM_API
                        break

    def test_log_sinks(self):
        """Test logging sinks are detected."""
        import re

        from reachable.dlp.taint.sinks import PYTHON_DLP_SINKS

        log_code = [
            "logger.info(f'User: {user_email}')",
            "logging.debug(data)",
            "print(user_ssn)",
        ]

        for line in log_code:
            found = False
            for sink_type, patterns in PYTHON_DLP_SINKS.items():
                for pattern in patterns:
                    if re.search(pattern, line, re.IGNORECASE):
                        found = True
                        break
            assert found, f"Should detect log sink in: {line}"


class TestTaintSanitizers:
    """Test sanitizer detection."""

    def test_presidio_sanitizers(self):
        """Test Presidio sanitizer detection."""
        import re

        from reachable.dlp.taint.sanitizers import PYTHON_SANITIZERS, SanitizerType

        presidio_code = [
            "from presidio_anonymizer import AnonymizerEngine",
            "anonymizer = AnonymizerEngine()",
            "result = anonymizer.anonymize(text)",
        ]

        for line in presidio_code:
            found = False
            for san_type, patterns in PYTHON_SANITIZERS.items():
                for pattern, effectiveness in patterns:
                    if re.search(pattern, line, re.IGNORECASE):
                        found = True
                        if san_type == SanitizerType.PRESIDIO:
                            assert effectiveness >= 0.9
                        break
            # At least some should match

    def test_sanitizer_effectiveness(self):
        """Test sanitizer effectiveness calculation."""
        from reachable.dlp.taint.sanitizers import Sanitizer, SanitizerType, calculate_combined_effectiveness

        # Single sanitizer with moderate effectiveness
        sanitizers = [
            Sanitizer(
                sanitizer_type=SanitizerType.MASK,
                location="test.py:10",
                function="mask",
                effectiveness=0.70,
            )
        ]

        combined = calculate_combined_effectiveness(sanitizers)
        assert combined == 0.70

        # Multiple sanitizers (compounding)
        sanitizers.append(
            Sanitizer(
                sanitizer_type=SanitizerType.HASH,
                location="test.py:15",
                function="sha256",
                effectiveness=0.50,
            )
        )

        # Combined: 1 - (0.30 * 0.50) = 1 - 0.15 = 0.85
        combined = calculate_combined_effectiveness(sanitizers)
        assert combined > 0.70  # Should be higher with two sanitizers
        assert combined <= 0.95  # But capped at 0.95


class TestCorrelationIntegration:
    """Test correlation engine integration."""

    def test_dlp_to_correlation_dict(self):
        """Test DLPFinding converts to correlation format."""
        from reachable.dlp.schema import DLPFinding, PIIEntityType, SinkType

        finding = DLPFinding.create_taint(
            file_path="/app/api.py",
            line_start=100,
            pii_type=PIIEntityType.SSN,
            source="user_ssn",
            sink="openai.create",
            sink_type=SinkType.LLM_API,
        )

        corr_dict = finding.to_correlation_dict()

        assert "rule_id" in corr_dict
        assert "file_path" in corr_dict
        assert "severity" in corr_dict
        assert "is_reachable" in corr_dict
        assert "dlp_type" in corr_dict
        assert "pii_type" in corr_dict
        assert corr_dict["pii_type"] == "ssn"


class TestP255BooleanValueFilter:
    """P2.55: Test that PII keywords with boolean/null/trivial values are filtered."""

    def test_mobile_false_not_phone(self):
        """mobile: false is a config flag (CDP viewport), not a phone number."""
        from reachable.dlp.taint.sources import infer_pii_type_from_source

        result = infer_pii_type_from_source("      mobile: false")
        assert result != "phone", f"'mobile: false' should NOT be classified as phone, got {result}"

    def test_mobile_true_not_phone(self):
        """mobile: true is a config flag, not a phone number."""
        from reachable.dlp.taint.sources import infer_pii_type_from_source

        result = infer_pii_type_from_source("      mobile: true,")
        assert result != "phone"

    def test_phone_none_not_phone(self):
        """phone = None is a null assignment, not a phone number."""
        from reachable.dlp.taint.sources import infer_pii_type_from_source

        result = infer_pii_type_from_source("      phone = None")
        assert result != "phone"

    def test_address_null_not_address(self):
        """address: null is a null assignment, not an address."""
        from reachable.dlp.taint.sources import infer_pii_type_from_source

        result = infer_pii_type_from_source("    address: null,")
        assert result != "address"

    def test_email_enabled_not_email(self):
        """email_enabled: true is a feature flag, not an email."""
        from reachable.dlp.taint.sources import infer_pii_type_from_source

        result = infer_pii_type_from_source("    email_enabled = True")
        assert result != "email"

    def test_is_mobile_not_phone(self):
        """is_mobile is a boolean check, not a phone number."""
        from reachable.dlp.taint.sources import infer_pii_type_from_source

        result = infer_pii_type_from_source("    is_mobile = detect_mobile(ua)")
        assert result != "phone"

    def test_phone_verified_not_phone(self):
        """phone_verified: false is a status flag, not a phone number."""
        from reachable.dlp.taint.sources import infer_pii_type_from_source

        result = infer_pii_type_from_source("    phone_verified: false")
        assert result != "phone"

    def test_ssn_required_zero_not_ssn(self):
        """ssn_required = 0 is a config flag, not an SSN."""
        from reachable.dlp.taint.sources import infer_pii_type_from_source

        result = infer_pii_type_from_source("    ssn_required = 0")
        assert result != "ssn"

    def test_real_mobile_is_phone(self):
        """mobile = '+1-555-0123' IS a real phone number."""
        from reachable.dlp.taint.sources import infer_pii_type_from_source

        result = infer_pii_type_from_source('    mobile = "+1-555-0123"')
        assert result == "phone"

    def test_real_email_is_email(self):
        """email = user.email IS a real email."""
        from reachable.dlp.taint.sources import infer_pii_type_from_source

        result = infer_pii_type_from_source("    email = user.email")
        assert result == "email"

    def test_real_phone_from_form_is_phone(self):
        """phone = request.form['phone'] IS a real phone number."""
        from reachable.dlp.taint.sources import infer_pii_type_from_source

        result = infer_pii_type_from_source('    phone = request.form["phone"]')
        assert result == "phone"

    def test_real_ssn_from_row_is_ssn(self):
        """ssn = row['ssn'] IS a real SSN."""
        from reachable.dlp.taint.sources import infer_pii_type_from_source

        result = infer_pii_type_from_source('    ssn = row["ssn"]')
        assert result == "ssn"

    def test_has_non_sensitive_value_direct(self):
        """Test _has_non_sensitive_value helper directly."""
        from reachable.dlp.taint.sources import _has_non_sensitive_value

        # Should return True (non-sensitive)
        assert _has_non_sensitive_value("mobile: false", "mobile") is True
        assert _has_non_sensitive_value("phone = None", "phone") is True
        assert _has_non_sensitive_value("address: null,", "address") is True
        assert _has_non_sensitive_value("is_mobile = check()", "mobile") is True
        assert _has_non_sensitive_value("email_enabled = True", "email") is True
        assert _has_non_sensitive_value("phone_verified: false", "phone") is True
        # Should return False (real PII)
        assert _has_non_sensitive_value('mobile = "+1-555-0123"', "mobile") is False
        assert _has_non_sensitive_value("email = user.email", "email") is False
        assert _has_non_sensitive_value('ssn = row["ssn"]', "ssn") is False

    def test_compound_expression_fallback_not_filtered(self):
        """P2.55b: null/false as fallback default should NOT filter the line."""
        from reachable.dlp.taint.sources import _has_non_sensitive_value

        # false/null is just a default — real value follows via ||, ??, &&
        assert _has_non_sensitive_value("const phone = null || getUserPhone()", "phone") is False
        assert _has_non_sensitive_value("const email = false || req.body.email", "email") is False
        assert _has_non_sensitive_value("let address = null ?? getAddress()", "address") is False

    def test_compound_expression_with_boolean_cast_filtered(self):
        """P2.55b: boolean type signals should still filter even in compound expressions."""
        from reachable.dlp.taint.sources import _has_non_sensitive_value

        # 'as boolean' cast means this IS a boolean flag
        assert _has_non_sensitive_value("const mobile = false || (params.mobile as boolean)", "mobile") is True
        # ': boolean' type annotation
        assert _has_non_sensitive_value("let phone: boolean = config.phone ?? true", "phone") is True
        # Boolean() cast
        assert _has_non_sensitive_value("const email = Boolean(opts.email)", "email") is True


# =========================================================================
# P2.56: CONTEXT PROPAGATION WARNING TESTS
# =========================================================================


class TestP256ContextPropagation:
    """P2.56: Detect PII propagation into framework request context.

    When PII is stored in a framework context object (c.set, req.user,
    ctx.state), it escapes the function boundary. The actual exposure
    depends on downstream consumers we can't see yet.

    These should produce WARNING-level findings, not HIGH.
    """

    def test_context_propagation_sink_type_exists(self):
        """P2.56: CONTEXT_PROPAGATION sink type is defined."""
        from reachable.dlp.taint.sinks import SINK_RISK_SCORES, DLPSinkType

        assert hasattr(DLPSinkType, "CONTEXT_PROPAGATION")
        # Risk score = 25 → WARNING severity when combined with email PII
        assert SINK_RISK_SCORES[DLPSinkType.CONTEXT_PROPAGATION] == 25

    def test_hono_c_set_pattern_matches(self):
        """P2.56: Hono c.set('accessUser', ...) matches context propagation sink."""
        import re

        from reachable.dlp.taint.sinks import TYPESCRIPT_DLP_SINKS, DLPSinkType

        patterns = TYPESCRIPT_DLP_SINKS[DLPSinkType.CONTEXT_PROPAGATION]
        line = "c.set('accessUser', { email: payload.email, name: payload.name });"
        matched = any(re.search(p, line, re.IGNORECASE) for p in patterns)
        assert matched, f"No pattern matched: {line}"

    def test_express_req_user_pattern_matches(self):
        """P2.56: Express req.user = ... matches context propagation sink."""
        import re

        from reachable.dlp.taint.sinks import TYPESCRIPT_DLP_SINKS, DLPSinkType

        patterns = TYPESCRIPT_DLP_SINKS[DLPSinkType.CONTEXT_PROPAGATION]
        line = "req.user = { email: decoded.email, name: decoded.name };"
        matched = any(re.search(p, line, re.IGNORECASE) for p in patterns)
        assert matched, f"No pattern matched: {line}"

    def test_koa_ctx_state_pattern_matches(self):
        """P2.56: Koa ctx.state.user = ... matches context propagation sink."""
        import re

        from reachable.dlp.taint.sinks import TYPESCRIPT_DLP_SINKS, DLPSinkType

        patterns = TYPESCRIPT_DLP_SINKS[DLPSinkType.CONTEXT_PROPAGATION]
        line = "ctx.state.user = { email: jwtPayload.email };"
        matched = any(re.search(p, line, re.IGNORECASE) for p in patterns)
        assert matched, f"No pattern matched: {line}"

    def test_flask_g_user_pattern_matches(self):
        """P2.56: Flask g.user_email = ... matches context propagation sink."""
        import re

        from reachable.dlp.taint.sinks import PYTHON_DLP_SINKS, DLPSinkType

        patterns = PYTHON_DLP_SINKS[DLPSinkType.CONTEXT_PROPAGATION]
        line = "g.user_email = decoded['email']"
        matched = any(re.search(p, line, re.IGNORECASE) for p in patterns)
        assert matched, f"No pattern matched: {line}"

    def test_fastapi_request_state_pattern_matches(self):
        """P2.56: FastAPI request.state.user = ... matches context propagation sink."""
        import re

        from reachable.dlp.taint.sinks import PYTHON_DLP_SINKS, DLPSinkType

        patterns = PYTHON_DLP_SINKS[DLPSinkType.CONTEXT_PROPAGATION]
        line = "request.state.user_email = token_data.email"
        matched = any(re.search(p, line, re.IGNORECASE) for p in patterns)
        assert matched, f"No pattern matched: {line}"

    def test_context_propagation_schema_sink_type(self):
        """P2.56: Schema SinkType.CONTEXT exists and rule_id is correct."""
        from reachable.dlp.schema import DLPFinding, PIIEntityType, SinkType

        assert hasattr(SinkType, "CONTEXT")
        # Verify create_taint generates correct rule_id and message
        finding = DLPFinding.create_taint(
            file_path="auth/middleware.ts",
            line_start=102,
            pii_type=PIIEntityType.EMAIL,
            source="email",
            sink="set",
            sink_type=SinkType.CONTEXT,
        )
        assert finding.rule_id == "dlp-taint-email-to-context"
        assert "propagated to request context" in finding.message
        assert "audit downstream consumers" in finding.message

    def test_context_propagation_severity_is_warning(self):
        """P2.56: Context propagation + email PII = WARNING severity."""
        from reachable.dlp.schema import PII_SENSITIVITY_TIER, TIER_BASE_RISK, PIIEntityType
        from reachable.dlp.taint.sinks import SINK_RISK_SCORES, DLPSinkType

        # Context propagation risk
        sink_risk = SINK_RISK_SCORES[DLPSinkType.CONTEXT_PROPAGATION]  # 25
        # Email PII risk
        tier = PII_SENSITIVITY_TIER.get(PIIEntityType.EMAIL)
        pii_risk = TIER_BASE_RISK.get(tier, 50)
        # Combined base risk
        base_risk = (sink_risk + pii_risk) / 2
        # Should be in WARNING/MEDIUM range (25-50), NOT HIGH (>=50)
        # SENSITIVE tier = 60, context sink = 25 → (25+60)/2 = 42.5
        assert 25 <= base_risk < 50, f"Expected WARNING/MEDIUM range, got base_risk={base_risk}"

    def test_non_pii_context_set_not_matched(self):
        """P2.56: c.set('theme', 'dark') should NOT match (no PII keyword in key)."""
        import re

        from reachable.dlp.taint.sinks import TYPESCRIPT_DLP_SINKS, DLPSinkType

        patterns = TYPESCRIPT_DLP_SINKS[DLPSinkType.CONTEXT_PROPAGATION]
        line = "c.set('theme', 'dark');"
        matched = any(re.search(p, line, re.IGNORECASE) for p in patterns)
        assert not matched, f"Should not match non-PII context: {line}"


# Run tests if executed directly
if __name__ == "__main__":
    pytest.main([__file__, "-v"])
