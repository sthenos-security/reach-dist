#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.

"""
CLI Smoke Tests - Verify all reachctl commands are functional

This test validates that:
1. All CLI commands can be invoked
2. Help text is displayed correctly
3. Commands don't crash on basic invocations
4. Required arguments are enforced

Run with:
    python tests/test_cli_smoke.py
    pytest tests/test_cli_smoke.py -v
"""

import subprocess
import sys
import unittest
from pathlib import Path
from typing import Tuple

# Add parent to path for imports
sys.path.insert(0, str(Path(__file__).parent.parent))


def run_reachctl(*args, timeout: int = 30) -> Tuple[int, str, str]:
    """Run reachctl command and return (returncode, stdout, stderr)"""
    cmd = [sys.executable, "-m", "reachable"] + list(args)
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout, cwd=Path(__file__).parent.parent)
        return result.returncode, result.stdout, result.stderr
    except subprocess.TimeoutExpired:
        return -1, "", "Command timed out"
    except Exception as e:
        return -2, "", str(e)


class TestCLIBasics(unittest.TestCase):
    """Basic CLI functionality tests"""

    def test_help_main(self):
        """reachctl --help shows main help"""
        rc, out, err = run_reachctl("--help")
        self.assertEqual(rc, 0, f"Help failed: {err}")
        self.assertIn("REACHABLE", out + err)
        self.assertIn("scan", out)
        self.assertIn("doctor", out)

    def test_version(self):
        """reachctl version shows version info"""
        rc, out, err = run_reachctl("version")
        self.assertEqual(rc, 0, f"Version failed: {err}")
        # Should contain version number
        combined = out + err
        self.assertTrue(
            any(x in combined for x in ["1.0.0", "4.", "Version", "version"]), f"Version not found in: {combined}"
        )

    def test_no_args_shows_help(self):
        """reachctl with no args shows help or usage"""
        rc, out, err = run_reachctl()
        # Should show help/usage, exit code 0 or 1 is acceptable
        self.assertIn("reachctl", (out + err).lower())


class TestCLICommands(unittest.TestCase):
    """Test each CLI command works"""

    @classmethod
    def setUpClass(cls):
        """Ensure ~/.reachable exists for data commands"""
        reachable_home = Path.home() / ".reachable"
        reachable_home.mkdir(parents=True, exist_ok=True)

    def test_scan_help(self):
        """reachctl scan --help works"""
        rc, out, err = run_reachctl("scan", "--help")
        self.assertEqual(rc, 0, f"scan --help failed: {err}")
        self.assertIn("PATH", out)
        self.assertIn("--output", out)
        self.assertIn("--fail-on", out)

    def test_scan_requires_path(self):
        """reachctl scan without path shows error"""
        rc, out, err = run_reachctl("scan")
        self.assertNotEqual(rc, 0, "scan without path should fail")
        # Should mention missing argument
        combined = (out + err).lower()
        self.assertTrue(
            "required" in combined or "path" in combined or "argument" in combined,
            f"Error message unclear: {out + err}",
        )

    def test_dashboard_help(self):
        """reachctl dashboard --help works"""
        rc, out, err = run_reachctl("dashboard", "--help")
        self.assertEqual(rc, 0, f"dashboard --help failed: {err}")
        self.assertIn("--generate", out)
        self.assertIn("--path", out)

    def test_dashboard_list(self):
        """reachctl dashboard --list works"""
        rc, out, err = run_reachctl("dashboard", "--list")
        # Should succeed even if no dashboards exist
        self.assertIn(rc, [0, 1], f"dashboard --list unexpected: {err}")

    def test_doctor_help(self):
        """reachctl doctor --help works"""
        rc, out, err = run_reachctl("doctor", "--help")
        self.assertEqual(rc, 0, f"doctor --help failed: {err}")
        self.assertIn("--no-fix", out)

    def test_doctor_runs(self):
        """reachctl doctor runs and checks dependencies"""
        rc, out, err = run_reachctl("doctor", timeout=60)
        # May return 0 or 1 depending on system state
        combined = out + err
        self.assertTrue(
            "SYSTEM CHECK" in combined or "Preflight" in combined or "check" in combined.lower(),
            f"Doctor output unexpected: {combined}",
        )

    def test_selftest_help(self):
        """reachctl selftest --help works"""
        rc, out, err = run_reachctl("selftest", "--help")
        self.assertEqual(rc, 0, f"selftest --help failed: {err}")
        self.assertIn("--full", out)
        self.assertIn("--unit", out)
        self.assertIn("--integration", out)
        self.assertIn("--coverage", out)

    def test_cache_help(self):
        """reachctl cache --help works"""
        rc, out, err = run_reachctl("cache", "--help")
        self.assertEqual(rc, 0, f"cache --help failed: {err}")
        self.assertIn("--status", out)
        self.assertIn("--clear", out)

    def test_cache_status(self):
        """reachctl cache --status works"""
        rc, out, err = run_reachctl("cache", "--status")
        self.assertEqual(rc, 0, f"cache --status failed: {err}")
        combined = out + err
        self.assertTrue("cache" in combined.lower() or "Cache" in combined, f"Cache output unexpected: {combined}")

    def test_primer_runs(self):
        """reachctl primer shows quick-start guide"""
        rc, out, err = run_reachctl("primer")
        self.assertEqual(rc, 0, f"primer failed: {err}")
        combined = out + err
        self.assertIn("REACHABLE", combined)
        self.assertIn("scan", combined.lower())

    def test_vulndb_help(self):
        """reachctl vulndb --help works"""
        rc, out, err = run_reachctl("vulndb", "--help")
        self.assertEqual(rc, 0, f"vulndb --help failed: {err}")
        self.assertIn("--status", out)

    def test_vulndb_status(self):
        """reachctl vulndb --status works"""
        rc, out, err = run_reachctl("vulndb", "--status")
        # May fail if grype not installed, but shouldn't crash
        self.assertIn(rc, [0, 1], f"vulndb --status crashed: {err}")

    def test_db_help(self):
        """reachctl db --help works"""
        rc, out, err = run_reachctl("db", "--help")
        self.assertEqual(rc, 0, f"db --help failed: {err}")
        self.assertIn("--status", out)


class TestCLIRemovedFlags(unittest.TestCase):
    """Verify removed flags are actually removed"""

    def test_quick_flag_removed(self):
        """--quick flag should not be recognized"""
        rc, out, err = run_reachctl("scan", ".", "--quick")
        # Should fail with unrecognized argument
        combined = (out + err).lower()
        self.assertTrue(
            "unrecognized" in combined or "error" in combined or rc != 0,
            f"--quick should be removed but got: rc={rc}, {out + err}",
        )

    def test_skip_secrets_removed(self):
        """--skip-secrets flag should not be recognized"""
        rc, out, err = run_reachctl("scan", ".", "--skip-secrets")
        combined = (out + err).lower()
        self.assertTrue(
            "unrecognized" in combined or "error" in combined or rc != 0, "--skip-secrets should be removed"
        )

    def test_skip_cwe_removed(self):
        """--skip-cwe flag should not be recognized"""
        rc, out, err = run_reachctl("scan", ".", "--skip-cwe")
        combined = (out + err).lower()
        self.assertTrue("unrecognized" in combined or "error" in combined or rc != 0, "--skip-cwe should be removed")

    def test_incremental_removed(self):
        """--incremental flag should not be recognized"""
        rc, out, err = run_reachctl("scan", ".", "--incremental")
        combined = (out + err).lower()
        self.assertTrue("unrecognized" in combined or "error" in combined or rc != 0, "--incremental should be removed")


class TestCLIValidFlags(unittest.TestCase):
    """Verify valid flags are still present"""

    def test_scan_debug_flag(self):
        """--debug flag should be recognized"""
        rc, out, err = run_reachctl("scan", "--help")
        self.assertIn("--debug", out, "--debug should be in help")

    def test_scan_quiet_flag(self):
        """--quiet flag should be recognized"""
        rc, out, err = run_reachctl("scan", "--help")
        self.assertIn("--quiet", out, "--quiet should be in help")

    def test_scan_fail_on_flag(self):
        """--fail-on flag should be recognized"""
        rc, out, err = run_reachctl("scan", "--help")
        self.assertIn("--fail-on", out, "--fail-on should be in help")

    def test_scan_output_flag(self):
        """--output flag should be recognized"""
        rc, out, err = run_reachctl("scan", "--help")
        self.assertIn("--output", out, "--output should be in help")


class TestCLIDataCommandsNoEnv(unittest.TestCase):
    """Test data commands when ~/.reachable doesn't exist"""

    def test_cache_no_env(self):
        """cache --status exits gracefully when env missing"""
        # This test uses reachctl wrapper behavior
        # When run via python -m, cli.py also has this check
        rc, out, err = run_reachctl("cache", "--status")
        combined = out + err
        # Either works normally OR says env not initialized
        self.assertTrue(
            rc == 0 and ("cache" in combined.lower() or "not initialized" in combined.lower()),
            f"Unexpected: rc={rc}, {combined}",
        )


class TestCLIErrorHandling(unittest.TestCase):
    """Test error handling"""

    def test_scan_nonexistent_path(self):
        """Scan of nonexistent path gives clear error or fails preflight"""
        rc, out, err = run_reachctl("scan", "/nonexistent/path/that/does/not/exist", timeout=15)
        # Should fail - either path not found, preflight failure, or timeout
        self.assertNotEqual(rc, 0, "Should fail for nonexistent path")
        combined = (out + err).lower()
        # Accept various failure modes:
        # - Path not found/does not exist
        # - Preflight/dependency failure
        # - General error
        # - Timeout
        self.assertTrue(
            "not found" in combined
            or "does not exist" in combined
            or "error" in combined
            or "failed" in combined
            or "timeout" in combined
            or "cannot" in combined
            or rc == -1,
            f"Error message unclear: {out + err}",
        )

    def test_invalid_command(self):
        """Invalid command gives helpful error"""
        rc, out, err = run_reachctl("notarealcommand")
        self.assertNotEqual(rc, 0, "Invalid command should fail")
        combined = (out + err).lower()
        self.assertTrue(
            "invalid" in combined or "unknown" in combined or "error" in combined or "usage" in combined,
            f"Error message unclear: {out + err}",
        )


def run_smoke_tests(verbose: bool = True) -> Tuple[int, int]:
    """
    Run CLI smoke tests and return (passed, failed) counts.

    This can be called from selftest or other test runners.
    """
    # Create test suite
    loader = unittest.TestLoader()
    suite = unittest.TestSuite()

    # Add all test classes
    for test_class in [
        TestCLIBasics,
        TestCLICommands,
        TestCLIRemovedFlags,
        TestCLIValidFlags,
        TestCLIDataCommandsNoEnv,
        TestCLIErrorHandling,
    ]:
        suite.addTests(loader.loadTestsFromTestCase(test_class))

    # Run tests
    if verbose:
        runner = unittest.TextTestRunner(verbosity=2)
    else:
        runner = unittest.TextTestRunner(verbosity=0)

    result = runner.run(suite)

    passed = result.testsRun - len(result.failures) - len(result.errors)
    failed = len(result.failures) + len(result.errors)

    return passed, failed


def main():
    """Run tests directly"""
    import argparse

    parser = argparse.ArgumentParser(description="REACHABLE CLI Smoke Tests")
    parser.add_argument("-v", "--verbose", action="store_true", help="Verbose output")
    parser.add_argument("-q", "--quiet", action="store_true", help="Minimal output")
    args = parser.parse_args()

    print("=" * 70)
    print("REACHABLE CLI SMOKE TESTS")
    print("=" * 70)
    print()

    passed, failed = run_smoke_tests(verbose=not args.quiet)

    print()
    print("=" * 70)
    print(f"Results: {passed} passed, {failed} failed")
    print("=" * 70)

    return 0 if failed == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
