#!/usr/bin/env python3
# REACHABLE Database Deduplication Tests
# Copyright (c) 2026 Sthenos Security. All rights reserved.

"""
P2.44: Comprehensive deduplication tests for all finding types.

Tests UNIQUE constraint behavior:
- CVEs: Same ID → deduplicate
- Secrets/CWEs/Config: Same location → keep separate
- AI/DLP: Same rule+location → deduplicate

All tests use realistic data that matches production pipelines.
"""

import sys
import tempfile
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).parent.parent))

from reachable.database.storage import RepoDatabase


class TestCVEDeduplication:
    """CVEs should deduplicate by ID (location doesn't matter)."""

    def test_same_cve_multiple_times_deduplicates(self):
        """Same CVE-ID should deduplicate (keep only 1 - last insert wins)."""
        with tempfile.TemporaryDirectory() as tmpdir:
            db = RepoDatabase(Path(tmpdir) / "test.db")
            scan_id = db.start_scan("main", "abc123", "/tmp/test", "1.0.0")

            cves = [
                {
                    "id": "CVE-2024-1234",
                    "severity": "HIGH",
                    "package": "requests",
                    "version": "2.0.0",
                    "message": "Test vuln",  # NEW: Required field
                    "scanner": "grype",
                },
                {
                    "id": "CVE-2024-1234",  # Same ID
                    "severity": "HIGH",
                    "package": "requests",
                    "version": "2.0.0",
                    "message": "Test vuln - updated",
                    "scanner": "grype",
                },
                {
                    "id": "CVE-2024-1234",  # Same ID again
                    "severity": "CRITICAL",
                    "package": "requests",
                    "version": "2.0.0",
                    "message": "Test vuln - final",
                    "scanner": "grype",
                },
            ]

            db.store_findings(cves, "cve")

            stored = db.get_findings(finding_type="cve")
            assert len(stored) == 1, f"Expected 1 CVE, got {len(stored)}"
            assert stored[0]["finding_id"] == "CVE-2024-1234"

    def test_different_cves_all_stored(self):
        """Different CVE-IDs should all be stored."""
        with tempfile.TemporaryDirectory() as tmpdir:
            db = RepoDatabase(Path(tmpdir) / "test.db")
            scan_id = db.start_scan("main", "abc123", "/tmp/test", "1.0.0")

            cves = [
                {
                    "id": "CVE-2024-1234",
                    "severity": "HIGH",
                    "package": "pkg1",
                    "version": "1.0",
                    "message": "Vuln 1",
                    "scanner": "grype",
                },
                {
                    "id": "CVE-2024-5678",
                    "severity": "HIGH",
                    "package": "pkg2",
                    "version": "1.0",
                    "message": "Vuln 2",
                    "scanner": "grype",
                },
                {
                    "id": "CVE-2024-9999",
                    "severity": "HIGH",
                    "package": "pkg3",
                    "version": "1.0",
                    "message": "Vuln 3",
                    "scanner": "grype",
                },
            ]

            db.store_findings(cves, "cve")

            stored = db.get_findings(finding_type="cve")
            assert len(stored) == 3, f"Expected 3 CVEs, got {len(stored)}"


class TestSecretDeduplication:
    """Secrets at different locations should NOT deduplicate."""

    def test_same_secret_type_different_locations_all_stored(self):
        """Same secret type at different locations should ALL be stored."""
        with tempfile.TemporaryDirectory() as tmpdir:
            db = RepoDatabase(Path(tmpdir) / "test.db")
            scan_id = db.start_scan("main", "abc123", "/tmp/test", "1.0.0")

            # Replicate real pipeline: NO 'id' field (will be generated)
            secrets = [
                {
                    "type": "api_key",
                    "secret_type": "api_key",
                    "file": "/app/config.py",
                    "line": 10,
                    "severity": "HIGH",
                    "message": "API key detected",
                    "scanner": "semgrep",
                },
                {
                    "type": "api_key",
                    "secret_type": "api_key",
                    "file": "/app/config.py",
                    "line": 50,  # Different line
                    "severity": "HIGH",
                    "message": "API key detected",
                    "scanner": "semgrep",
                },
                {
                    "type": "api_key",
                    "secret_type": "api_key",
                    "file": "/app/settings.py",  # Different file
                    "line": 10,
                    "severity": "HIGH",
                    "message": "API key detected",
                    "scanner": "semgrep",
                },
            ]

            db.store_findings(secrets, "secret")

            stored = db.get_findings(finding_type="secret")
            assert len(stored) == 3, f"Expected 3 secrets, got {len(stored)}"

            # Verify locations
            locations = [(s["file_path"], s["line_number"]) for s in stored]
            assert ("/app/config.py", 10) in locations
            assert ("/app/config.py", 50) in locations
            assert ("/app/settings.py", 10) in locations

    def test_different_secret_types_all_stored(self):
        """Different secret types should all be stored."""
        with tempfile.TemporaryDirectory() as tmpdir:
            db = RepoDatabase(Path(tmpdir) / "test.db")
            scan_id = db.start_scan("main", "abc123", "/tmp/test", "1.0.0")

            secrets = [
                {
                    "type": "api_key",
                    "secret_type": "api_key",
                    "file": "/app/config.py",
                    "line": 10,
                    "severity": "HIGH",
                    "message": "Secret",
                    "scanner": "semgrep",
                },
                {
                    "type": "password",
                    "secret_type": "password",
                    "file": "/app/config.py",
                    "line": 20,
                    "severity": "HIGH",
                    "message": "Secret",
                    "scanner": "semgrep",
                },
                {
                    "type": "token",
                    "secret_type": "token",
                    "file": "/app/config.py",
                    "line": 30,
                    "severity": "HIGH",
                    "message": "Secret",
                    "scanner": "semgrep",
                },
            ]

            db.store_findings(secrets, "secret")

            stored = db.get_findings(finding_type="secret")
            assert len(stored) == 3, f"Expected 3 secrets, got {len(stored)}"


class TestCWEDeduplication:
    """CWEs at different locations should NOT deduplicate."""

    def test_same_cwe_different_locations_all_stored(self):
        """Same CWE-ID at different locations should ALL be stored."""
        with tempfile.TemporaryDirectory() as tmpdir:
            db = RepoDatabase(Path(tmpdir) / "test.db")
            scan_id = db.start_scan("main", "abc123", "/tmp/test", "1.0.0")

            # CWE findings need 'type' field for reclassification logic
            cwes = [
                {
                    "type": "unknown",  # NEW: Required for _reclassify_secret_findings
                    "cwe_id": "CWE-250",
                    "file": "/app/Dockerfile",
                    "line": 18,
                    "severity": "ERROR",
                    "message": "Missing USER directive",
                    "scanner": "semgrep",
                },
                {
                    "type": "unknown",
                    "cwe_id": "CWE-250",
                    "file": "/app/Dockerfile",
                    "line": 43,  # Different line
                    "severity": "ERROR",
                    "message": "Missing USER directive",
                    "scanner": "semgrep",
                },
                {
                    "type": "unknown",
                    "cwe_id": "CWE-250",
                    "file": "/app/other.Dockerfile",  # Different file
                    "line": 18,
                    "severity": "ERROR",
                    "message": "Missing USER directive",
                    "scanner": "semgrep",
                },
            ]

            db.store_findings(cwes, "cwe")

            stored = db.get_findings(finding_type="cwe")
            assert len(stored) == 3, f"Expected 3 CWEs, got {len(stored)}"

            locations = [(s["file_path"], s["line_number"]) for s in stored]
            assert ("/app/Dockerfile", 18) in locations
            assert ("/app/Dockerfile", 43) in locations
            assert ("/app/other.Dockerfile", 18) in locations


class TestConfigDeduplication:
    """Config issues at different locations should NOT deduplicate."""

    def test_same_config_issue_different_locations_all_stored(self):
        """Same config issue type at different locations should ALL be stored."""
        with tempfile.TemporaryDirectory() as tmpdir:
            db = RepoDatabase(Path(tmpdir) / "test.db")
            scan_id = db.start_scan("main", "abc123", "/tmp/test", "1.0.0")

            # Config findings also need complete data
            configs = [
                {
                    "type": "unknown",  # Required
                    "cwe_id": "CWE-022",
                    "file": "/app/k8s/deployment1.yaml",
                    "line": 15,
                    "severity": "MEDIUM",
                    "message": "Path traversal risk",
                    "scanner": "semgrep",
                },
                {
                    "type": "unknown",
                    "cwe_id": "CWE-022",
                    "file": "/app/k8s/deployment2.yaml",  # Different file
                    "line": 15,
                    "severity": "MEDIUM",
                    "message": "Path traversal risk",
                    "scanner": "semgrep",
                },
            ]

            db.store_findings(configs, "config")

            stored = db.get_findings(finding_type="config")
            assert len(stored) == 2, f"Expected 2 config issues, got {len(stored)}"


class TestMalwareDeduplication:
    """Malware in different packages should NOT deduplicate."""

    def test_same_malware_different_packages_all_stored(self):
        """Same malware pattern in different packages should ALL be stored."""
        with tempfile.TemporaryDirectory() as tmpdir:
            db = RepoDatabase(Path(tmpdir) / "test.db")
            scan_id = db.start_scan("main", "abc123", "/tmp/test", "1.0.0")

            # Malware findings with IDs
            malware = [
                {
                    "id": "malware_pkg1",
                    "package": "evil-package-1",
                    "version": "1.0.0",
                    "severity": "CRITICAL",
                    "message": "Malicious code detected",
                    "scanner": "guarddog",
                },
                {
                    "id": "malware_pkg2",
                    "package": "evil-package-2",  # Different package
                    "version": "1.0.0",
                    "severity": "CRITICAL",
                    "message": "Malicious code detected",
                    "scanner": "guarddog",
                },
            ]

            db.store_findings(malware, "malware")

            stored = db.get_findings(finding_type="malware")
            assert len(stored) == 2, f"Expected 2 malware findings, got {len(stored)}"


class TestMixedDeduplication:
    """Mixed scenarios with multiple finding types."""

    def test_realistic_scan_deduplication(self):
        """Realistic scan: CVEs dedupe, secrets/CWEs don't."""
        with tempfile.TemporaryDirectory() as tmpdir:
            db = RepoDatabase(Path(tmpdir) / "test.db")
            scan_id = db.start_scan("main", "abc123", "/tmp/test", "1.0.0")

            # CVEs - same CVE twice (should dedupe to 1)
            cves = [
                {
                    "id": "CVE-2024-1234",
                    "severity": "HIGH",
                    "package": "requests",
                    "version": "2.0",
                    "message": "Vuln",
                    "scanner": "grype",
                },
                {
                    "id": "CVE-2024-1234",
                    "severity": "HIGH",
                    "package": "requests",
                    "version": "2.0",
                    "message": "Vuln",
                    "scanner": "grype",
                },
            ]
            db.store_findings(cves, "cve")

            # Secrets - 3 api_keys at different locations (keep all 3)
            secrets = [
                {
                    "type": "api_key",
                    "secret_type": "api_key",
                    "file": "/app/a.py",
                    "line": 10,
                    "severity": "HIGH",
                    "message": "Secret",
                    "scanner": "semgrep",
                },
                {
                    "type": "api_key",
                    "secret_type": "api_key",
                    "file": "/app/a.py",
                    "line": 20,
                    "severity": "HIGH",
                    "message": "Secret",
                    "scanner": "semgrep",
                },
                {
                    "type": "api_key",
                    "secret_type": "api_key",
                    "file": "/app/b.py",
                    "line": 10,
                    "severity": "HIGH",
                    "message": "Secret",
                    "scanner": "semgrep",
                },
            ]
            db.store_findings(secrets, "secret")

            # CWEs - same CWE at 2 locations (keep both)
            cwes = [
                {
                    "type": "unknown",
                    "cwe_id": "CWE-250",
                    "file": "/app/Dockerfile",
                    "line": 18,
                    "severity": "ERROR",
                    "message": "Issue",
                    "scanner": "semgrep",
                },
                {
                    "type": "unknown",
                    "cwe_id": "CWE-250",
                    "file": "/app/Dockerfile",
                    "line": 43,
                    "severity": "ERROR",
                    "message": "Issue",
                    "scanner": "semgrep",
                },
            ]
            db.store_findings(cwes, "cwe")

            # Verify
            assert len(db.get_findings(finding_type="cve")) == 1, "CVEs should deduplicate"
            assert len(db.get_findings(finding_type="secret")) == 3, "Secrets should NOT deduplicate"
            assert len(db.get_findings(finding_type="cwe")) == 2, "CWEs should NOT deduplicate"


class TestAIFindingsDeduplication:
    """AI findings should deduplicate by rule+location."""

    def test_ai_findings_different_locations_all_stored(self):
        """Same OWASP rule at different locations should NOT deduplicate."""
        with tempfile.TemporaryDirectory() as tmpdir:
            db = RepoDatabase(Path(tmpdir) / "test.db")
            scan_id = db.start_scan("main", "abc123", "/tmp/test", "1.0.0")

            # AI findings - LLM01 at 3 locations
            ai_findings = [
                {
                    "rule_id": "llm-prompt-injection",
                    "file_path": "/app/ai.py",
                    "line_start": 45,
                    "severity": "HIGH",
                    "owasp_category": "LLM01",
                    "message": "Prompt injection risk",
                },
                {
                    "rule_id": "llm-prompt-injection",
                    "file_path": "/app/ai.py",
                    "line_start": 78,  # Different line
                    "severity": "HIGH",
                    "owasp_category": "LLM01",
                    "message": "Prompt injection risk",
                },
                {
                    "rule_id": "llm-prompt-injection",
                    "file_path": "/app/chat.py",  # Different file
                    "line_start": 45,
                    "severity": "HIGH",
                    "owasp_category": "LLM01",
                    "message": "Prompt injection risk",
                },
            ]

            db.store_ai_findings(ai_findings)

            # Query AI findings table
            cursor = db.conn.execute("SELECT * FROM ai_findings WHERE scan_id=?", (scan_id,))
            stored = cursor.fetchall()

            assert len(stored) == 3, f"Expected 3 AI findings, got {len(stored)}"


class TestDLPFindingsDeduplication:
    """DLP findings should deduplicate by PII type+location+sink."""

    def test_dlp_findings_different_locations_all_stored(self):
        """Same PII type at different locations should NOT deduplicate."""
        with tempfile.TemporaryDirectory() as tmpdir:
            db = RepoDatabase(Path(tmpdir) / "test.db")
            scan_id = db.start_scan("main", "abc123", "/tmp/test", "1.0.0")

            # DLP findings - SSN at 3 locations
            dlp_findings = [
                {
                    "pii_type": "ssn",
                    "file_path": "/app/user.py",
                    "line_start": 10,  # NOTE: line_start not line_number!
                    "severity": "CRITICAL",
                    "sink_type": "log",
                    "message": "SSN in logs",
                },
                {
                    "pii_type": "ssn",
                    "file_path": "/app/user.py",
                    "line_start": 25,  # Different line
                    "severity": "CRITICAL",
                    "sink_type": "log",
                    "message": "SSN in logs",
                },
                {
                    "pii_type": "ssn",
                    "file_path": "/app/admin.py",  # Different file
                    "line_start": 10,
                    "severity": "CRITICAL",
                    "sink_type": "database",  # Different sink
                    "message": "SSN in database",
                },
            ]

            db.store_dlp_findings(dlp_findings)

            # Query DLP findings table
            cursor = db.conn.execute("SELECT * FROM dlp_findings WHERE scan_id=?", (scan_id,))
            stored = cursor.fetchall()

            assert len(stored) == 3, f"Expected 3 DLP findings, got {len(stored)}"


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
