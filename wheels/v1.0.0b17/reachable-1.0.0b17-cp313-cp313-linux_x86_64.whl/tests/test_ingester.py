#!/usr/bin/env python3
"""
v5.1.3 Ingester Tests

Run: python -m pytest tests/test_ingester.py -v
Or:  python tests/test_ingester.py  (standalone)

Tests all normalizers with fixture data and verifies round-trip
through DB matches expected counts.
"""

import json
import shutil
import tempfile
import unittest
from pathlib import Path

# ==========================================================================
# FIXTURE DATA - Minimal raw scanner outputs for testing
# ==========================================================================

# CVE fixture: cve-analyzed.json format (reachable/unreachable dicts)
# This is the output of the correlation engine, NOT raw Grype output.
CVE_ANALYZED_FIXTURE = {
    "reachable": {
        "CVE-2024-1234": {
            "severity": "CRITICAL",
            "description": "Test CVE critical - reachable",
            "package": "requests",
            "version": "2.25.0",
            "is_fixable": True,
            "fix_versions": ["2.25.1"],
            "cvss_score": 9.8,
            "ghsa_id": "GHSA-xxxx-yyyy-zzzz",
            "call_paths": [["app.py:10", "requests/api.py:42"]],
            "reachable_via": "Direct import in app.py",
        },
    },
    "unreachable": {
        "CVE-2024-5678": {
            "severity": "HIGH",
            "description": "Test CVE high - unreachable",
            "package": "flask",
            "version": "2.0.0",
            "cvss_score": 7.5,
        },
    },
}

SEMGREP_FIXTURE = {
    "results": [
        {
            "check_id": "python.security.injection.sql-injection",
            "path": "app/db.py",
            "start": {"line": 42},
            "extra": {
                "severity": "ERROR",
                "message": "SQL injection vulnerability",
                "metadata": {"cwe": ["CWE-89: SQL Injection"]},
            },
            "is_reachable": True,
        },
        {
            "check_id": "generic.secrets.hardcoded-password",
            "path": "config/settings.py",
            "start": {"line": 10},
            "extra": {
                "severity": "WARNING",
                "message": "Hardcoded password detected",
                "metadata": {"cwe": []},
            },
            "is_actual_secret": True,
        },
        {
            "check_id": "dockerfile.security.missing-user",
            "path": "Dockerfile",
            "start": {"line": 1},
            "extra": {
                "severity": "WARNING",
                "message": "Missing USER directive",
                "metadata": {"cwe": []},
            },
        },
        {
            "check_id": "yaml.kubernetes.security.privileged-container",
            "path": "config/deploy.yaml",
            "start": {"line": 5},
            "extra": {
                "severity": "ERROR",
                "message": "Privileged container detected",
                "metadata": {"cwe": []},
            },
        },
    ]
}

GUARDDOG_FIXTURE = {
    "packages": {
        "evil-pkg": {
            "issues": [
                {
                    "rule": "shady-links",
                    "severity": "CRITICAL",
                    "message": "Detected suspicious URLs in package",
                    "file": "evil_pkg/setup.py",
                    "line": 5,
                }
            ]
        }
    }
}

YARA_FIXTURE = {
    "matches": [
        {
            "rule": "base64_payload",
            "file": "node_modules/sketchy/index.js",
            "severity": "MEDIUM",
            "message": "Base64 encoded payload detected",
            "line": 12,
            "package": "sketchy",
        }
    ]
}

AI_FIXTURE = {
    "findings": [
        {
            "rule_id": "ai-prompt-injection-1",
            "severity": "HIGH",
            "title": "Prompt Injection Risk",
            "owasp_category": "LLM01",
            "message": "User input passed directly to LLM",
            "file_path": "app/chat.py",
            "line_start": 25,
            "is_reachable": True,
        }
    ]
}

DLP_FIXTURE = {
    "findings": [
        {
            "id": "dlp-ssn-exposure-1",
            "severity": "CRITICAL",
            "pii_type": "ssn",
            "title": "SSN exposed in logs",
            "description": "Social security number logged without masking",
            "file": "app/user.py",
            "line": 88,
            "is_reachable": True,
        }
    ]
}

SANDBOX_FIXTURE = {
    "results": [
        {
            "package": "evil-pkg",
            "version": "1.0.0",
            "verdict": "CRITICAL",
            "behaviors": [
                {
                    "type": "network_access",
                    "severity": "CRITICAL",
                    "message": "Connects to C2 server",
                    "file": "evil_pkg/__init__.py",
                    "line": 1,
                }
            ],
        }
    ]
}

# Pre-normalized malware format (static-malware-extracted.json)
# This is what scan.py writes after processing GuardDog/YARA results
MALWARE_EXTRACTED_FIXTURE = {
    "findings": [
        {
            "id": "gd-evil-pkg-shady-links",
            "finding_type": "malware",
            "severity": "CRITICAL",
            "risk_level": "CRITICAL",
            "title": "[GuardDog] shady-links: Detected suspicious URLs",
            "description": "Rule: shady-links. Package: evil-pkg. File: evil_pkg/setup.py",
            "package": "evil-pkg",
            "package_name": "evil-pkg",
            "scanner": "guarddog",
            "file": "evil_pkg/setup.py",
            "file_path": "evil_pkg/setup.py",
            "line": 5,
            "line_number": 5,
            "app_reachability": "REACHABLE",
            "reachability_confidence": "HIGH",
        }
    ]
}


class TestCVENormalizer(unittest.TestCase):
    def test_normalize_cves(self):
        from reachable.database.normalizers.cve import normalize_cves

        result = normalize_cves({"cve-analyzed.json": CVE_ANALYZED_FIXTURE})

        cves = result["cve"]
        self.assertEqual(len(cves), 2)

        # Find by display_id (falls back to dict key from cve-analyzed.json)
        cve_map = {c["display_id"]: c for c in cves}

        # Reachable CVE
        cve1 = cve_map["CVE-2024-1234"]
        self.assertEqual(cve1["severity"], "CRITICAL")
        self.assertEqual(cve1["package"], "requests")
        self.assertEqual(cve1["fix_status"], "fix_available")
        self.assertEqual(cve1["ghsa_id"], "GHSA-xxxx-yyyy-zzzz")
        self.assertEqual(cve1["app_reachability"], "REACHABLE")
        self.assertEqual(cve1["scanner"], "grype")

        # Unreachable CVE
        cve2 = cve_map["CVE-2024-5678"]
        self.assertEqual(cve2["severity"], "HIGH")
        self.assertEqual(cve2["app_reachability"], "NOT_REACHABLE")

    def test_empty_input(self):
        from reachable.database.normalizers.cve import normalize_cves

        result = normalize_cves({})
        self.assertEqual(result, {"cve": []})

    def test_deduplication(self):
        from reachable.database.normalizers.cve import normalize_cves

        # Same CVE IDs in both reachable and unreachable — should dedup
        data = {
            "cve-analyzed.json": {
                "reachable": {
                    "CVE-2024-1234": CVE_ANALYZED_FIXTURE["reachable"]["CVE-2024-1234"],
                    "CVE-2024-5678": CVE_ANALYZED_FIXTURE["unreachable"]["CVE-2024-5678"],
                },
                "unreachable": {
                    "CVE-2024-1234": CVE_ANALYZED_FIXTURE["reachable"]["CVE-2024-1234"],
                    "CVE-2024-5678": CVE_ANALYZED_FIXTURE["unreachable"]["CVE-2024-5678"],
                },
            }
        }
        result = normalize_cves(data)
        self.assertEqual(len(result["cve"]), 2)  # Still 2, not 4


class TestSemgrepNormalizer(unittest.TestCase):
    def test_reclassification(self):
        from reachable.database.normalizers.semgrep import normalize_semgrep

        result = normalize_semgrep({"security-findings.json": SEMGREP_FIXTURE})

        # SQL injection in code file -> CWE
        self.assertEqual(len(result["cwe"]), 1)
        self.assertEqual(result["cwe"][0]["severity"], "CRITICAL")  # ERROR -> CRITICAL
        self.assertEqual(result["cwe"][0]["app_reachability"], "REACHABLE")

        # Hardcoded password -> SECRET
        self.assertEqual(len(result["secret"]), 1)
        self.assertEqual(result["secret"][0]["secret_type"], "hardcoded-password")

        # Dockerfile + yaml config -> CONFIG
        self.assertEqual(len(result["config"]), 2)

        # Config reachability must be NOT_APPLICABLE (config plane — reachability analysis does not apply)
        for cfg in result["config"]:
            self.assertEqual(cfg["app_reachability"], "NOT_APPLICABLE")
            self.assertNotIn("is_reachable", cfg)  # Must NOT leak through

    def test_iac_severity(self):
        """IaC severity is risk-based, not Semgrep taint-based."""
        from reachable.database.normalizers.semgrep import normalize_semgrep

        result = normalize_semgrep({"security-findings.json": SEMGREP_FIXTURE})

        config_map = {c["rule_id"]: c for c in result["config"]}

        # missing-user -> LOW (often false positive — K8s securityContext overrides)
        self.assertEqual(config_map["dockerfile.security.missing-user"]["severity"], "LOW")
        # privileged-container -> HIGH (container escape risk)
        self.assertEqual(config_map["yaml.kubernetes.security.privileged-container"]["severity"], "HIGH")

    def test_skip_iac(self):
        """--skip-iac drops all config findings."""
        from reachable.database.normalizers.semgrep import normalize_semgrep

        result = normalize_semgrep({"security-findings.json": SEMGREP_FIXTURE}, skip_iac=True)
        self.assertEqual(len(result["config"]), 0)
        # CWE and secrets unaffected
        self.assertEqual(len(result["cwe"]), 1)
        self.assertEqual(len(result["secret"]), 1)

    def test_secret_in_config_file(self):
        """BUG 7: Secrets in .env files must be SECRET, not CONFIG."""
        from reachable.database.normalizers.semgrep import normalize_semgrep

        fixture = {
            "findings": [
                {
                    "rule_id": "env-cloud_access_key",
                    "file": "secret-tests/docker-compose.env",
                    "line": 5,
                    "severity": "CRITICAL",
                    "message": "Secret detected: AWS_ACCESS_KEY_ID (cloud_access_key)",
                    "is_actual_secret": False,
                    "is_reachable": True,
                },
                {
                    "rule_id": "env-generic_secret",
                    "file": "config/.env",
                    "line": 10,
                    "severity": "CRITICAL",
                    "message": "Secret detected: GENERIC_SECRET",
                    "is_actual_secret": True,
                    "is_reachable": True,
                },
                {
                    "rule_id": "yaml.kubernetes.security.privileged-container",
                    "file": "config/deploy.yaml",
                    "line": 5,
                    "severity": "WARNING",
                    "message": "Privileged container detected",
                },
            ]
        }
        result = normalize_semgrep({"security-findings.json": fixture})
        # cloud_access_key in .env → SECRET (not CONFIG) via rule pattern match
        self.assertEqual(len(result["secret"]), 2)
        self.assertEqual(len(result["config"]), 1)  # only privileged-container
        # Secrets get UNKNOWN reachability (not REACHABLE from Semgrep taint)
        for s in result["secret"]:
            if "access_key" in s.get("id", s.get("finding_id", "")):
                self.assertEqual(s["app_reachability"], "UNKNOWN")

    def test_secret_message_detection(self):
        """BUG 7: 'Secret detected:' message overrides config file classification."""
        from reachable.database.normalizers.semgrep import _classify_finding

        # access_key pattern in rule ID
        f1 = {
            "rule_id": "env-cloud_access_key",
            "is_actual_secret": False,
            "message": "Secret detected: AWS_ACCESS_KEY_ID",
        }
        self.assertEqual(_classify_finding(f1, "docker-compose.env", "env-cloud_access_key"), "secret")
        # message-based detection
        f2 = {"rule_id": "custom-rule-123", "is_actual_secret": False, "message": "Secret detected: some credential"}
        self.assertEqual(_classify_finding(f2, "config/app.env", "custom-rule-123"), "secret")
        # Non-secret config stays config
        f3 = {"rule_id": "dockerfile.security.missing-user", "message": "Missing USER directive"}
        self.assertEqual(_classify_finding(f3, "Dockerfile", "dockerfile.security.missing-user"), "config")

    def test_config_file_detection(self):
        from reachable.database.normalizers.semgrep import _is_config_file

        self.assertTrue(_is_config_file("Dockerfile"))
        self.assertTrue(_is_config_file("config/deploy.yaml"))
        self.assertTrue(_is_config_file(".github/workflows/ci.yml"))
        self.assertFalse(_is_config_file("app/main.py"))
        self.assertFalse(_is_config_file("src/handler.go"))


class TestMalwareNormalizer(unittest.TestCase):
    def test_guarddog_and_yara(self):
        """v5.2.0: 'suspicious' type retired — all findings go into malware list."""
        from reachable.database.normalizers.malware import normalize_malware

        result = normalize_malware(
            {
                "guarddog-output.json": GUARDDOG_FIXTURE,
                "yara-matches.json": YARA_FIXTURE,
            }
        )

        # Both guarddog + yara go into malware (suspicious retired per design doc v5.2.0)
        self.assertEqual(len(result["malware"]), 2)
        scanners = {f["scanner"] for f in result["malware"]}
        self.assertIn("guarddog", scanners)
        self.assertIn("yara", scanners)

        # GuardDog finding: setup.py = REACHABLE
        gd = next(f for f in result["malware"] if f["scanner"] == "guarddog")
        self.assertEqual(gd["app_reachability"], "REACHABLE")

        # suspicious always empty (compat stub)
        self.assertEqual(len(result["suspicious"]), 0)

    def test_pre_normalized(self):
        """Pre-normalized format (static-malware-extracted.json) from scan.py."""
        from reachable.database.normalizers.malware import normalize_malware

        result = normalize_malware(
            {
                "static-malware-extracted.json": MALWARE_EXTRACTED_FIXTURE,
            }
        )
        self.assertEqual(len(result["malware"]), 1)
        self.assertEqual(result["malware"][0]["app_reachability"], "REACHABLE")


class TestAINormalizer(unittest.TestCase):
    def test_normalize_ai(self):
        from reachable.database.normalizers.ai import normalize_ai

        result = normalize_ai({"ai-security.json": AI_FIXTURE})

        self.assertEqual(len(result["ai"]), 1)
        self.assertEqual(result["ai"][0]["severity"], "HIGH")
        self.assertEqual(result["ai"][0]["owasp_category"], "LLM01")


class TestDLPNormalizer(unittest.TestCase):
    def test_normalize_dlp(self):
        from reachable.database.normalizers.dlp import normalize_dlp

        result = normalize_dlp({"dlp-security.json": DLP_FIXTURE})

        self.assertEqual(len(result["dlp"]), 1)
        self.assertEqual(result["dlp"][0]["pii_type"], "ssn")
        self.assertEqual(result["dlp"][0]["severity"], "CRITICAL")


class TestSandboxNormalizer(unittest.TestCase):
    def test_normalize_sandbox(self):
        from reachable.database.normalizers.sandbox import normalize_sandbox

        result = normalize_sandbox({"sandbox-results.json": SANDBOX_FIXTURE})

        self.assertEqual(len(result["malware"]), 1)
        self.assertEqual(result["malware"][0]["app_reachability"], "REACHABLE")
        self.assertEqual(len(result["suspicious"]), 0)


class TestIngesterIntegration(unittest.TestCase):
    """
    Integration test: write fixtures to disk, run ingester, verify DB.
    Requires reachable.database.storage to be importable.
    """

    def setUp(self):
        self.tmpdir = Path(tempfile.mkdtemp())
        self.raw_dir = self.tmpdir / "raw"
        self.raw_dir.mkdir()

        # Write fixture files — names MUST match RAW_FILE_REGISTRY in ingester.py
        (self.raw_dir / "cve-analyzed.json").write_text(json.dumps(CVE_ANALYZED_FIXTURE))
        (self.raw_dir / "security-findings.json").write_text(json.dumps(SEMGREP_FIXTURE))
        (self.raw_dir / "static-malware-extracted.json").write_text(json.dumps(MALWARE_EXTRACTED_FIXTURE))
        (self.raw_dir / "ai-security.json").write_text(json.dumps(AI_FIXTURE))
        (self.raw_dir / "dlp-security.json").write_text(json.dumps(DLP_FIXTURE))
        (self.raw_dir / "sandbox.json").write_text(json.dumps(SANDBOX_FIXTURE))

    def tearDown(self):
        shutil.rmtree(self.tmpdir)

    def test_full_ingest(self):
        try:
            from reachable.database.ingester import ingest
            from reachable.database.storage import RepoDatabase
        except ImportError:
            self.skipTest("reachable package not importable")

        db_path = self.tmpdir / "test.db"
        db = RepoDatabase(db_path)
        scan_id = db.start_scan(branch="main", commit_hash="abc123", scan_dir=str(self.tmpdir), version="5.1.3")

        result = ingest(self.tmpdir, db, scan_id=scan_id)

        # Verify counts
        self.assertEqual(result.cve_count, 2)
        self.assertEqual(result.cwe_count, 1)
        self.assertEqual(result.secret_count, 1)
        self.assertEqual(result.config_count, 2)
        self.assertGreaterEqual(result.malware_count, 1)  # Pre-normalized + sandbox
        self.assertEqual(result.ai_count, 1)
        self.assertEqual(result.dlp_count, 1)
        self.assertTrue(result.ok)

        # Verify DB directly
        cursor = db.conn.cursor()

        # Total findings in findings table
        total = cursor.execute("SELECT COUNT(*) FROM findings WHERE scan_id = ?", (scan_id,)).fetchone()[0]
        self.assertGreater(total, 0)

        # CVEs stored correctly
        cves = cursor.execute(
            "SELECT COUNT(*) FROM findings WHERE scan_id = ? AND finding_type = 'cve'", (scan_id,)
        ).fetchone()[0]
        self.assertEqual(cves, 2)

        # Config findings all have UNKNOWN reachability
        config_reach = cursor.execute(
            "SELECT DISTINCT app_reachability FROM findings WHERE scan_id = ? AND finding_type = 'config'", (scan_id,)
        ).fetchall()
        reach_values = [r[0] for r in config_reach]
        self.assertEqual(
            reach_values, ["NOT_APPLICABLE"], f"Config reachability should be NOT_APPLICABLE, got {reach_values}"
        )

        # AI findings in separate table
        ai = cursor.execute("SELECT COUNT(*) FROM ai_findings WHERE scan_id = ?", (scan_id,)).fetchone()[0]
        self.assertEqual(ai, 1)

        # DLP findings in separate table
        dlp = cursor.execute("SELECT COUNT(*) FROM dlp_findings WHERE scan_id = ?", (scan_id,)).fetchone()[0]
        self.assertEqual(dlp, 1)

        db.close()

    def test_skip_iac(self):
        """--skip-iac flag drops config findings from ingestion."""
        try:
            from reachable.database.ingester import ingest
            from reachable.database.storage import RepoDatabase
        except ImportError:
            self.skipTest("reachable package not importable")

        db_path = self.tmpdir / "test.db"
        db = RepoDatabase(db_path)
        scan_id = db.start_scan(branch="main", commit_hash="abc123", scan_dir=str(self.tmpdir), version="5.1.3")

        result = ingest(self.tmpdir, db, scan_id=scan_id, skip_iac=True)

        self.assertEqual(result.config_count, 0)
        # Other signals unaffected
        self.assertEqual(result.cve_count, 2)
        self.assertEqual(result.cwe_count, 1)

        db.close()

    def test_reingest(self):
        """Test re-ingestion clears old findings and re-ingests."""
        try:
            from reachable.database.ingester import ingest, reingest
            from reachable.database.storage import RepoDatabase
        except ImportError:
            self.skipTest("reachable package not importable")

        db_path = self.tmpdir / "test.db"
        db = RepoDatabase(db_path)
        scan_id = db.start_scan(branch="main", commit_hash="abc123", scan_dir=str(self.tmpdir), version="5.1.3")

        # First ingest
        result1 = ingest(self.tmpdir, db, scan_id=scan_id)
        db.close()

        # Re-ingest
        result2 = reingest(self.tmpdir, db_path, scan_id=scan_id)

        # Counts should match
        self.assertEqual(result1.cve_count, result2.cve_count)
        self.assertEqual(result1.total, result2.total)


if __name__ == "__main__":
    unittest.main()
