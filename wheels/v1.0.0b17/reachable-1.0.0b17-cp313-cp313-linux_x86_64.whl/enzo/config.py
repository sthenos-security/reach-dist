#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.
"""
Enzo configuration.

Reads ``enzo:`` section from .reachable.yml, merges with env vars + CLI overrides.
"""

from __future__ import annotations

import logging
import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Optional

logger = logging.getLogger(__name__)

try:
    import yaml  # type: ignore
    _HAS_YAML = True
except ImportError:
    _HAS_YAML = False

_SEVERITY_ORDER = {"CRITICAL": 4, "HIGH": 3, "MEDIUM": 2, "LOW": 1, "INFO": 0}


@dataclass
class EnzoConfig:

    # ── Models ────────────────────────────────────────────────────────────
    local_model: str = "qwen2.5-coder:32b"
    local_endpoint: str = "http://localhost:11434"
    groq_api_key: str = ""
    groq_model: str = "llama-3.3-70b-versatile"  # qwen-2.5-coder-32b decommissioned Apr 2025
    groq_endpoint: str = "https://api.groq.com/openai"
    mode: str = "local"      # "local" | "cloud" | "fallback"
    provider: str = "claude"  # "claude" | "groq"  (only for mode=cloud)                        # local | cloud | both
    cloud_enabled: bool = False                # DEPRECATED — derived from mode
    cloud_model: str = "claude-sonnet-4-5-20250929"
    cloud_api_key: Optional[str] = None
    cloud_code_consent: bool = False           # user accepted code-to-cloud

    # ── Pipeline ──────────────────────────────────────────────────────────
    severity_threshold: str = "HIGH"
    reachable_only: bool = False
    fix_types: List[str] = field(default_factory=lambda: [
        "dependency_upgrade", "config_change", "secret_rotation", "code_patch",
    ])
    max_retries: int = 2
    auto_pr: bool = True

    # ── Build overrides ───────────────────────────────────────────────────
    build_command: Optional[str] = None
    test_command: Optional[str] = None

    # ── Policy ────────────────────────────────────────────────────────────
    require_tests_pass: bool = True
    require_no_new_findings: bool = True
    coverage_threshold: Optional[float] = None

    # ── Privacy ───────────────────────────────────────────────────────────
    metadata_sensitivity: str = "standard"   # standard | strict

    # ── Git ────────────────────────────────────────────────────────────────
    branch_prefix: str = "reachable/fix"
    commit_signing: bool = False

    # ── Hallucination detection ───────────────────────────────────────────
    verify_tokens: bool = False  # inject+verify request_id/HMAC tokens (cloud recommended)

    # ── Resolved at load ──────────────────────────────────────────────────
    repo_path: Optional[str] = None

    # ──────────────────────────────────────────────────────────────────────

    def __post_init__(self):
        """Sync cloud_enabled ↔ mode for backward compat."""
        # Old-style: cloud_enabled=True without mode set → treat as "both"
        if self.cloud_enabled and self.mode == "local":
            self.mode = "both"
        # Always derive cloud_enabled from mode
        self._sync_cloud_enabled()

    def _sync_cloud_enabled(self):
        """Keep cloud_enabled in sync with mode."""
        self.cloud_enabled = self.mode in ("cloud", "both") and bool(self.cloud_api_key)

    @property
    def needs_groq(self) -> bool:
        return self.mode == "cloud" and self.provider == "groq"

    @property
    def needs_local(self) -> bool:
        """Local model needed in 'local' or 'fallback' modes."""
        return self.mode in ("local", "fallback")

    @property
    def cloud_generates_code(self) -> bool:
        """In 'cloud' mode, Claude/Groq generates diffs directly (source code sent)."""
        return self.mode == "cloud"

    @property
    def fallback_to_cloud(self) -> bool:
        """In 'fallback' mode, try local first; escalate to cloud if all candidates fail."""
        return self.mode == "fallback"

    def severity_meets_threshold(self, severity: str) -> bool:
        return _SEVERITY_ORDER.get(severity.upper(), 0) >= _SEVERITY_ORDER.get(
            self.severity_threshold.upper(), 3
        )

    @classmethod
    def load(cls, repo_path: str, overrides: Optional[Dict] = None) -> "EnzoConfig":
        cfg = cls(repo_path=repo_path)

        # 1. .reachable.yml
        yml = Path(repo_path) / ".reachable.yml"
        if yml.exists() and _HAS_YAML:
            try:
                with open(yml) as f:
                    data = yaml.safe_load(f) or {}
                enzo_cfg = data.get("enzo") or {}
                # Backward compat: cloud_enabled → mode
                if enzo_cfg.pop("cloud_enabled", None):
                    enzo_cfg.setdefault("mode", "both")
                for k, v in enzo_cfg.items():
                    if hasattr(cfg, k) and not k.startswith("_"):
                        setattr(cfg, k, v)
            except Exception as exc:
                logger.warning("Failed to parse .reachable.yml enzo section: %s", exc)

        # 2. Global enzo config (~/.reachable/enzo/config.yml written by enzo setup)
        _enzo_cfg_path = Path.home() / ".reachable" / "enzo" / "config.yml"
        if _enzo_cfg_path.exists() and _HAS_YAML:
            try:
                with open(_enzo_cfg_path) as f:
                    _gcfg = yaml.safe_load(f) or {}
                for _k in ("local_model", "local_endpoint"):
                    if _k in _gcfg and _gcfg[_k]:
                        setattr(cfg, _k, _gcfg[_k])
            except Exception as exc:
                logger.debug("Could not load enzo global config: %s", exc)

        # 3. Env vars (take precedence over config file)
        cfg.cloud_api_key = os.environ.get("ANTHROPIC_API_KEY", cfg.cloud_api_key)
        cfg.groq_api_key  = os.environ.get("GROQ_API_KEY", cfg.groq_api_key)
        if os.environ.get("ENZO_LOCAL_MODEL"):
            cfg.local_model = os.environ["ENZO_LOCAL_MODEL"]
        if os.environ.get("ENZO_LOCAL_ENDPOINT"):
            cfg.local_endpoint = os.environ["ENZO_LOCAL_ENDPOINT"]

        # 3. Credential store fallback (macOS Keychain / Linux encrypted file)
        if not cfg.cloud_api_key:
            try:
                from reachable.core.credentials import get_credential
                cfg.cloud_api_key = get_credential("anthropic-api-key")
            except Exception as exc:
                logger.debug("Credential store unavailable: %s", exc)

        if not cfg.groq_api_key:
            try:
                from reachable.core.credentials import get_credential
                cfg.groq_api_key = get_credential("groq-api-key") or ""
            except Exception as exc:
                logger.debug("Credential store unavailable for groq: %s", exc)

        if cfg.cloud_api_key:
            pass  # key available; mode still set by CLI --mode flag

        # 5. Global config — consent flag
        try:
            from reachable.core.config import load_config as _load_global
            gcfg = _load_global()
            if gcfg.get("enzo", {}).get("cloud_code_consent"):
                cfg.cloud_code_consent = True
        except Exception as exc:
            logger.debug("Could not load global config for consent flag: %s", exc)

        # 6. CLI overrides
        if overrides:
            # Backward compat: cloud_enabled=True → mode="both"
            if overrides.pop("cloud_enabled", None):
                overrides.setdefault("mode", "both")
            for k, v in overrides.items():
                if v is not None and hasattr(cfg, k) and not k.startswith("_"):
                    setattr(cfg, k, v)

        # Final: sync cloud_enabled from mode + api_key
        cfg._sync_cloud_enabled()

        return cfg
