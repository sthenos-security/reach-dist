#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.
"""Enzo patcher — generates patches using local/cloud models."""
