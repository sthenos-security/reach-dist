#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.
"""
Local model interface — Ollama or compatible OpenAI-style API.

Sees: full source code, call graphs, AST, file contents.
Produces: concrete patch diff.
"""

from __future__ import annotations

import json
import logging
import os
import time
from typing import Any, Dict

logger = logging.getLogger(__name__)

try:
    import urllib.error
    import urllib.request
    _HAS_URLLIB = True
except ImportError:
    _HAS_URLLIB = False



def _http_post_with_retry(
    url: str,
    payload: dict,
    headers: dict,
    timeout: int,
    max_retries: int = 3,
    retryable_codes: tuple = (429, 500, 502, 503, 529),
):
    """POST with exponential backoff retry for transient errors.

    Retries on:
      - HTTP 429/529 (rate limit) — honours Retry-After header if present
      - HTTP 5xx (server error)
      - Transient URLError: RemoteDisconnected, IncompleteRead, connection reset
    Raises immediately on permanent errors (4xx other than 429).
    """
    import time as _time
    data = json.dumps(payload).encode("utf-8")
    for attempt in range(max_retries):
        req = urllib.request.Request(url, data=data, headers=headers, method="POST")
        try:
            return urllib.request.urlopen(req, timeout=timeout)
        except urllib.error.HTTPError as exc:
            if exc.code in retryable_codes:
                # Detect TPD (tokens per day) exhaustion — distinct from burst 429.
                # TPD errors need minutes to recover; retrying burns remaining quota.
                body_text = ""
                try:
                    body_text = exc.read().decode(errors="replace")
                except Exception:
                    pass
                if exc.code == 429 and "tokens per day" in body_text.lower():
                    # Parse "try again in Xm Ys" from error message
                    import re as _re
                    secs = 0
                    m = _re.search(r"try again in\s+(\d+)m([\d.]+)s", body_text)
                    if m:
                        secs = int(m.group(1)) * 60 + int(float(m.group(2)))
                    raise GroqTPDExhausted(
                        f"Groq daily token limit (TPD) exhausted. "
                        f"Retry in {secs // 60}m {secs % 60}s.",
                        retry_after_seconds=secs,
                    ) from exc
                wait = 2 ** attempt
                try:
                    ra = exc.headers.get("Retry-After")
                    if ra:
                        wait = min(int(ra), 60)
                except Exception:
                    pass
                if attempt < max_retries - 1:
                    logger.debug("HTTP %d — retrying in %ds (attempt %d/%d)",
                                 exc.code, wait, attempt + 1, max_retries)
                    _time.sleep(wait)
                    continue
            raise
        except urllib.error.URLError as exc:
            reason = str(exc.reason)
            transient = any(k in reason for k in (
                "RemoteDisconnected", "ConnectionReset", "IncompleteRead",
                "Connection refused", "Broken pipe",
            ))
            if transient and attempt < max_retries - 1:
                wait = 2 ** attempt
                logger.debug("Transient URLError (%s) — retrying in %ds (attempt %d/%d)",
                             reason, wait, attempt + 1, max_retries)
                _time.sleep(wait)
                continue
            raise
    raise RuntimeError("_http_post_with_retry: exceeded max_retries without result")


class GroqTPDExhausted(Exception):
    """Raised when Groq daily token quota (TPD) is exhausted.

    Carries the retry_after_seconds so the pipeline can show a clear message.
    """
    def __init__(self, message: str, retry_after_seconds: int = 0):
        super().__init__(message)
        self.retry_after_seconds = retry_after_seconds


class LocalModel:
    """Interface to a local Ollama or OpenAI-compatible endpoint."""

    def __init__(self, model: str = "qwen2.5-coder:32b", endpoint: str = "http://localhost:11434", api_key: str = ""):
        self.model = model
        self.endpoint = endpoint.rstrip("/")
        self.api_key = api_key or ""
        self._is_groq = "groq.com" in endpoint.lower()
        self._is_ollama = (
            not self._is_groq
            and ("11434" in endpoint or "ollama" in endpoint.lower())
        )

    def generate(self, prompt: str, system: str = "", temperature: float = 0.1) -> Dict[str, Any]:
        """
        Send a prompt to the local model and return the response.

        Returns:
            {"text": str, "model": str, "latency_ms": float, "error": Optional[str]}
        """
        start = time.time()

        if self._is_ollama:
            return self._ollama_generate(prompt, system, temperature, start)
        elif self._is_groq:
            return self._groq_generate(prompt, system, temperature, start)
        else:
            return self._openai_generate(prompt, system, temperature, start)

    def _ollama_generate(self, prompt: str, system: str, temperature: float, start: float) -> Dict[str, Any]:
        url = f"{self.endpoint}/api/generate"
        payload = {
            "model": self.model,
            "prompt": prompt,
            "system": system,
            "stream": False,
            "options": {"temperature": temperature},
        }

        try:
            with _http_post_with_retry(
                url,
                payload,
                headers={"Content-Type": "application/json"},
                timeout=300,
                max_retries=3,
            ) as resp:
                data = json.loads(resp.read())
                return {
                    "text": data.get("response", ""),
                    "model": f"local:{self.model}",
                    "latency_ms": (time.time() - start) * 1000,
                    "error": None,
                }
        except urllib.error.HTTPError as exc:
            if exc.code == 404:
                # Model not found — likely OLLAMA_MODELS points somewhere else
                # or the model was never pulled in this Ollama instance.
                error_msg = (
                    f"ollama_unreachable: Model '{self.model}' not found (HTTP 404). "
                    f"Run: ollama list — if missing, run: ollama pull {self.model}"
                )
            else:
                body = ""
                try:
                    body = exc.read().decode(errors="replace")[:200]
                except Exception:
                    pass
                error_msg = f"ollama_unreachable: HTTP {exc.code} from Ollama: {body or exc.reason}"
            return {
                "text": "",
                "model": f"local:{self.model}",
                "latency_ms": (time.time() - start) * 1000,
                "error": error_msg,
            }
        except urllib.error.URLError as exc:
            # Prefix with "ollama_unreachable:" so _is_fatal_error() can
            # detect this and abort the pipeline immediately — no point
            # retrying 3 times if the server isn't running.
            return {
                "text": "",
                "model": f"local:{self.model}",
                "latency_ms": (time.time() - start) * 1000,
                "error": f"ollama_unreachable: Connection failed: {exc.reason}. Is Ollama running at {self.endpoint}?",
            }
        except Exception as exc:
            # RemoteDisconnected / IncompleteRead / BadStatusLine all land here.
            # Usually means Ollama ran out of memory mid-generation.
            _err = str(exc) or type(exc).__name__
            if any(k in _err.lower() for k in ("remote", "incomplete", "badstatus", "reset", "eof")):
                _err = (
                    f"ollama_unreachable: Ollama dropped the connection mid-response ({_err}). "
                    f"Possible OOM — try a smaller model or run: reachctl enzo setup"
                )
            return {
                "text": "",
                "model": f"local:{self.model}",
                "latency_ms": (time.time() - start) * 1000,
                "error": _err,
            }

    def _groq_generate(self, prompt: str, system: str, temperature: float, start: float) -> Dict[str, Any]:
        """Groq Cloud API — OpenAI-compatible but requires Bearer auth and has
        its own base URL (https://api.groq.com/openai/v1)."""
        url = f"{self.endpoint}/v1/chat/completions"
        messages = []
        if system:
            messages.append({"role": "system", "content": system})
        messages.append({"role": "user", "content": prompt})

        payload = {
            "model": self.model,
            "messages": messages,
            "temperature": temperature,
            "max_tokens": 4096,
        }

        key = self.api_key or os.environ.get("GROQ_API_KEY", "")
        if not key:
            return {
                "text": "",
                "model": f"groq:{self.model}",
                "latency_ms": 0,
                "error": "groq_unreachable: No GROQ_API_KEY set. Export it or add to keychain.",
            }

        _headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {key}",
            # User-Agent required — Cloudflare blocks headless urllib (error 1010)
            "User-Agent": "enzo-patcher/1.0 (python-urllib)",
        }
        try:
            with _http_post_with_retry(
                url, payload, headers=_headers,
                timeout=120, max_retries=3,
                # 403 from Groq is usually Cloudflare transient — retry it
                retryable_codes=(429, 500, 502, 503, 529, 403),
            ) as resp:
                data = json.loads(resp.read())
                _choice = data.get("choices", [{}])[0]
                text = _choice.get("message", {}).get("content", "")
                finish_reason = _choice.get("finish_reason", "")
                return {
                    "text": text,
                    "model": f"groq:{self.model}",
                    "latency_ms": (time.time() - start) * 1000,
                    "error": None,
                    "finish_reason": finish_reason,
                }
        except urllib.error.HTTPError as exc:
            body = ""
            try:
                body = exc.read().decode(errors="replace")[:300]
                import json as _j
                msg = _j.loads(body).get("error", {}).get("message", body)
            except Exception:
                msg = body or exc.reason
            fatal = "groq_unreachable" if exc.code in (401, 403) else ""
            prefix = f"{fatal}: " if fatal else ""
            return {
                "text": "",
                "model": f"groq:{self.model}",
                "latency_ms": (time.time() - start) * 1000,
                "error": f"{prefix}Groq HTTP {exc.code}: {msg}",
            }
        except urllib.error.URLError as exc:
            return {
                "text": "",
                "model": f"groq:{self.model}",
                "latency_ms": (time.time() - start) * 1000,
                "error": f"groq_unreachable: Connection failed: {exc.reason}",
            }
        except Exception as exc:
            return {
                "text": "",
                "model": f"groq:{self.model}",
                "latency_ms": (time.time() - start) * 1000,
                "error": str(exc),
            }

    def _openai_generate(self, prompt: str, system: str, temperature: float, start: float) -> Dict[str, Any]:
        """OpenAI-compatible endpoint (vLLM, text-generation-inference, etc.)"""
        url = f"{self.endpoint}/v1/chat/completions"
        messages = []
        if system:
            messages.append({"role": "system", "content": system})
        messages.append({"role": "user", "content": prompt})

        payload = {
            "model": self.model,
            "messages": messages,
            "temperature": temperature,
            "max_tokens": 4096,
        }

        try:
            with _http_post_with_retry(
                url,
                payload,
                headers={"Content-Type": "application/json"},
                timeout=300,
                max_retries=3,
            ) as resp:
                data = json.loads(resp.read())
                text = data.get("choices", [{}])[0].get("message", {}).get("content", "")
                return {
                    "text": text,
                    "model": f"local:{self.model}",
                    "latency_ms": (time.time() - start) * 1000,
                    "error": None,
                }
        except Exception as exc:
            return {
                "text": "",
                "model": f"local:{self.model}",
                "latency_ms": (time.time() - start) * 1000,
                "error": str(exc),
            }

    def is_available(self) -> bool:
        """Quick health check."""
        try:
            if self._is_ollama:
                url = f"{self.endpoint}/api/tags"
            elif self._is_groq:
                url = f"{self.endpoint}/v1/models"
            else:
                url = f"{self.endpoint}/v1/models"
            req = urllib.request.Request(url, method="GET")
            with urllib.request.urlopen(req, timeout=5):
                return True
        except Exception:
            return False
