#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.
"""
Code Reducer — Snyk-style minimal snippet extraction.

Before sending source code to a model, reduce the file to the smallest
slice that still gives the model everything it needs to generate a correct fix:

  1. Find the function/method containing the vulnerable line
  2. Include its full body (so the model understands what it does)
  3. Include N lines of caller context above (import lines, class header,
     adjacent function that provides the input)
  4. Include any imports referenced by the function
  5. Annotate the vulnerable line clearly

Why this matters:
  - A 2000-line Django views.py sent to Ollama buries the relevant 30 lines
  - LLMs degrade on long context — the fix quality drops measurably
  - Reduces token cost and latency in cloud mode
  - Reduces IP exposure (less code sent when in cloud mode)

Snyk's internal measurements show ~60% reduction in context size with no
accuracy loss when the slice is well-chosen.
"""

from __future__ import annotations

import logging
import re
from dataclasses import dataclass
from pathlib import Path
from typing import List, Optional, Tuple

logger = logging.getLogger(__name__)

# Lines of context to include above/below the target function
_CONTEXT_ABOVE = 10   # caller setup, class definition, decorator
_CONTEXT_BELOW = 5    # return statement, exception handling after the sink
_MAX_SNIPPET_LINES = 200  # safety cap — if function is huge, truncate with note
_IMPORT_LINES_CAP = 30    # max import lines to prepend


@dataclass
class CodeSlice:
    """The reduced snippet ready for the model prompt."""
    file_path: str
    language: str
    full_line_count: int        # original file size, so model knows what it's seeing
    slice_line_start: int       # 1-based line where snippet starts in original file
    slice_line_end: int
    vulnerable_line: int        # 1-based, within the original file
    vulnerable_line_in_slice: int  # 1-based, within this snippet
    content: str                # the actual snippet text with annotation injected
    imports: str                # relevant import block (may be empty)
    reduction_ratio: float      # 0.0–1.0, lower = more reduced

    def to_prompt_block(self) -> str:
        """Format for insertion into LLM prompt.

        Lines are prefixed with their real file line numbers so the model
        generates diff @@ headers that match the full file, not the slice.
        """
        parts = []
        if self.imports:
            parts.append(f"# --- Relevant imports from {self.file_path} ---")
            parts.append(self.imports)
            parts.append("")
        parts.append(
            f"# --- {self.file_path} "
            f"(lines {self.slice_line_start}–{self.slice_line_end} "
            f"of {self.full_line_count} total) ---"
        )
        # Prefix each line with its real line number so the model emits
        # correct @@ offsets relative to the full file.
        numbered_lines = []
        for i, line in enumerate(self.content.splitlines()):
            lineno = self.slice_line_start + i
            numbered_lines.append(f"{lineno:4d} | {line}")
        parts.append("\n".join(numbered_lines))
        parts.append(
            f"# Note: line numbers above are for context only "
            f"(slice starts at line {self.slice_line_start}). Do NOT include line numbers in your output."
        )
        return "\n".join(parts)


def reduce_for_finding(
    file_path: str,
    repo_path: str,
    line_number: int,
    language: Optional[str] = None,
) -> Optional[CodeSlice]:
    """
    Main entry point. Reduce a source file to a minimal snippet centered
    on the vulnerable line.

    Returns None if the file cannot be read or the line is out of range.
    Falls back to a raw line window if function extraction fails.
    """
    full_path = Path(repo_path) / file_path
    if not full_path.exists():
        logger.warning("Code reducer: file not found: %s", full_path)
        return None

    try:
        source = full_path.read_text(errors="replace")
    except OSError as exc:
        logger.warning("Code reducer: cannot read %s: %s", full_path, exc)
        return None

    lines = source.splitlines()
    total = len(lines)

    if line_number < 1 or line_number > total:
        logger.warning("Code reducer: line %d out of range (file has %d lines)", line_number, total)
        return None

    lang = language or _detect_language(file_path)

    # Try structured extraction first
    func_start, func_end = _find_function_bounds(lines, line_number, lang)

    if func_start is not None:
        start = max(0, func_start - _CONTEXT_ABOVE)
        end   = min(total, func_end + _CONTEXT_BELOW)
    else:
        # Fallback: raw window around the vulnerable line
        start = max(0, line_number - 1 - 30)
        end   = min(total, line_number - 1 + 30)

    # Cap at max snippet size
    if (end - start) > _MAX_SNIPPET_LINES:
        # Keep more above the vulnerable line than below
        half = _MAX_SNIPPET_LINES // 2
        start = max(0, (line_number - 1) - half)
        end   = min(total, start + _MAX_SNIPPET_LINES)

    snippet_lines = lines[start:end]
    vuln_in_slice = (line_number - 1) - start + 1  # 1-based within slice

    # Annotate the vulnerable line
    annotated = _annotate_vulnerable_line(snippet_lines, vuln_in_slice, lang)

    # Extract relevant imports
    imports = _extract_relevant_imports(lines, snippet_lines, lang)

    content = "\n".join(annotated)
    reduction = len(snippet_lines) / max(total, 1)

    logger.debug(
        "Code reducer: %s  %d→%d lines (%.0f%% of file, lang=%s)",
        file_path, total, len(snippet_lines), reduction * 100, lang,
    )

    return CodeSlice(
        file_path=file_path,
        language=lang,
        full_line_count=total,
        slice_line_start=start + 1,
        slice_line_end=end,
        vulnerable_line=line_number,
        vulnerable_line_in_slice=vuln_in_slice,
        content=content,
        imports=imports,
        reduction_ratio=reduction,
    )


# ───────────────────────────────────────────────────────────────────────────
#  Language detection
# ───────────────────────────────────────────────────────────────────────────

def _detect_language(file_path: str) -> str:
    ext = Path(file_path).suffix.lower()
    return {
        ".py": "python",
        ".js": "javascript", ".jsx": "javascript",
        ".ts": "javascript", ".tsx": "javascript",
        ".go": "go",
        ".java": "java",
        ".rb": "ruby",
        ".rs": "rust",
        ".php": "php",
    }.get(ext, "unknown")


# ───────────────────────────────────────────────────────────────────────────
#  Function boundary detection
# ───────────────────────────────────────────────────────────────────────────

def _find_function_bounds(
    lines: List[str], target_line: int, language: str,
) -> Tuple[Optional[int], Optional[int]]:
    """
    Return (start_idx, end_idx) — 0-based indices into `lines`.
    target_line is 1-based.
    Returns (None, None) if no function is found.
    """
    if language == "python":
        return _python_bounds(lines, target_line)
    elif language in ("javascript",):
        return _js_bounds(lines, target_line)
    elif language == "go":
        return _go_bounds(lines, target_line)
    elif language == "java":
        return _java_bounds(lines, target_line)
    return None, None


def _python_bounds(lines: List[str], target_line: int) -> Tuple[Optional[int], Optional[int]]:
    target_idx = target_line - 1

    # Walk backward to find def/async def
    func_idx = None
    func_indent = 0
    for i in range(target_idx, -1, -1):
        stripped = lines[i].lstrip()
        if stripped.startswith("def ") or stripped.startswith("async def "):
            func_idx = i
            func_indent = len(lines[i]) - len(stripped)
            break

    if func_idx is None:
        return None, None

    # Walk forward to find end of function (next def/class at same or lesser indent)
    end_idx = len(lines) - 1
    for i in range(func_idx + 1, len(lines)):
        stripped = lines[i].lstrip()
        if not stripped or stripped.startswith("#"):
            continue
        line_indent = len(lines[i]) - len(stripped)
        if line_indent <= func_indent and (
            stripped.startswith("def ") or stripped.startswith("async def ")
            or stripped.startswith("class ") or stripped.startswith("@")
        ):
            end_idx = i - 1
            break

    return func_idx, end_idx


def _js_bounds(lines: List[str], target_line: int) -> Tuple[Optional[int], Optional[int]]:
    target_idx = target_line - 1

    # Walk backward for function keyword or arrow function assignment
    func_idx = None
    for i in range(target_idx, max(-1, target_idx - 60), -1):
        line = lines[i].strip()
        _js_func_re = (
            r"(?:export\s+)?(?:async\s+)?"
            r"(?:function\s+\w+|(?:const|let|var)\s+\w+\s*=\s*(?:async\s+)?(?:function|\()"
            r")"
        )
        if re.search(_js_func_re, line):
            func_idx = i
            break

    if func_idx is None:
        return None, None

    # Balance braces from func_idx to find closing }
    depth = 0
    end_idx = func_idx
    for i in range(func_idx, min(len(lines), func_idx + 500)):
        depth += lines[i].count("{") - lines[i].count("}")
        if depth <= 0 and i > func_idx:
            end_idx = i
            break

    return func_idx, end_idx


def _go_bounds(lines: List[str], target_line: int) -> Tuple[Optional[int], Optional[int]]:
    target_idx = target_line - 1

    func_idx = None
    for i in range(target_idx, max(-1, target_idx - 60), -1):
        if re.match(r"\s*func\s+", lines[i]):
            func_idx = i
            break

    if func_idx is None:
        return None, None

    depth = 0
    end_idx = func_idx
    for i in range(func_idx, min(len(lines), func_idx + 500)):
        depth += lines[i].count("{") - lines[i].count("}")
        if depth <= 0 and i > func_idx:
            end_idx = i
            break

    return func_idx, end_idx


def _java_bounds(lines: List[str], target_line: int) -> Tuple[Optional[int], Optional[int]]:
    target_idx = target_line - 1

    func_idx = None
    for i in range(target_idx, max(-1, target_idx - 80), -1):
        line = lines[i].strip()
        # Method signature: visibility modifier + return type + name + (
        if re.search(r"(?:public|private|protected|static|void|\w+)\s+\w+\s*\(", line) and "{" in lines[i]:
            func_idx = i
            break

    if func_idx is None:
        return None, None

    depth = 0
    end_idx = func_idx
    for i in range(func_idx, min(len(lines), func_idx + 500)):
        depth += lines[i].count("{") - lines[i].count("}")
        if depth <= 0 and i > func_idx:
            end_idx = i
            break

    return func_idx, end_idx


# ───────────────────────────────────────────────────────────────────────────
#  Annotation
# ───────────────────────────────────────────────────────────────────────────

_VULN_MARKERS = {
    "python":     ("# ← VULNERABLE LINE (Enzo target)", "#"),
    "javascript": ("// ← VULNERABLE LINE (Enzo target)", "//"),
    "go":         ("// ← VULNERABLE LINE (Enzo target)", "//"),
    "java":       ("// ← VULNERABLE LINE (Enzo target)", "//"),
    "ruby":       ("# ← VULNERABLE LINE (Enzo target)", "#"),
    "rust":       ("// ← VULNERABLE LINE (Enzo target)", "//"),
    "php":        ("// ← VULNERABLE LINE (Enzo target)", "//"),
    "unknown":    ("# ← VULNERABLE LINE (Enzo target)", "#"),
}


def _annotate_vulnerable_line(lines: List[str], vuln_in_slice: int, language: str) -> List[str]:
    """Append an annotation comment to the vulnerable line."""
    result = list(lines)
    marker, _ = _VULN_MARKERS.get(language, _VULN_MARKERS["unknown"])
    idx = vuln_in_slice - 1
    if 0 <= idx < len(result):
        result[idx] = result[idx].rstrip() + "  " + marker
    return result


# ───────────────────────────────────────────────────────────────────────────
#  Import extraction
# ───────────────────────────────────────────────────────────────────────────

_IMPORT_PATTERNS = {
    "python": re.compile(r"^\s*(?:import |from \S+ import)"),
    "javascript": re.compile(r"^\s*(?:import |const .+ = require\()"),
    "go": re.compile(r"^\s*import\b"),
    "java": re.compile(r"^\s*import "),
}


def _extract_relevant_imports(
    all_lines: List[str],
    snippet_lines: List[str],
    language: str,
) -> str:
    """
    Extract import lines from the file that are referenced by identifiers
    in the snippet. Caps at _IMPORT_LINES_CAP to avoid bloat.
    """
    pattern = _IMPORT_PATTERNS.get(language)
    if not pattern:
        return ""

    # Collect all import lines from the file
    all_imports = [ln for ln in all_lines if pattern.match(ln)]
    if not all_imports:
        return ""

    # Filter to imports whose module/symbol appears in the snippet text
    snippet_text = "\n".join(snippet_lines)
    relevant = []
    for imp in all_imports:
        # Extract the module/symbol name from the import statement
        tokens = re.findall(r"[\w]+", imp)
        # Skip generic keywords
        meaningful = [t for t in tokens if t not in (
            "import", "from", "require", "as", "const", "let", "var", "default",
        )]
        if any(t in snippet_text for t in meaningful if len(t) > 2):
            relevant.append(imp)

    return "\n".join(relevant[:_IMPORT_LINES_CAP])
