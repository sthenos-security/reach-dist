#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.
"""
Deterministic patcher — zero-AI, zero-token-cost fixes.

Handles fix types where the remediation is a mechanical transformation,
not a reasoning task. Called by the engine BEFORE the LLM path.

Dispatch:
  secret_rotation    → AST (Python) or regex (other langs)
  dependency_upgrade → regex version bump in manifest
  malware (known)    → import removal + call-site stub

Debug log prefix: [DETERMINISTIC]
"""
from __future__ import annotations

import ast
import logging
import re
from dataclasses import dataclass

logger = logging.getLogger(__name__)

_PLACEHOLDER = "REACHABLE_SECRET_CHANGE_ME"

_ENV_VAR_NAMES = {
    "api_key": "API_KEY", "api key": "API_KEY",
    "secret_key": "SECRET_KEY", "secret key": "SECRET_KEY",
    "password": "PASSWORD", "db_password": "DB_PASSWORD",
    "database_password": "DB_PASSWORD", "token": "TOKEN",
    "access_token": "ACCESS_TOKEN", "auth_token": "AUTH_TOKEN",
    "private_key": "PRIVATE_KEY", "jwt_secret": "JWT_SECRET",
    "webhook_secret": "WEBHOOK_SECRET",
}


@dataclass
class DeterministicResult:
    success: bool
    patched_content: str = ""
    method: str = ""
    error: str = ""
    tokens_used: int = 0
    cost_usd: float = 0.0

    def log(self, finding_id: str) -> None:
        if self.success:
            logger.debug("[DETERMINISTIC] ✓ %s — %s (no AI used)", finding_id, self.method)
        else:
            logger.debug("[DETERMINISTIC] ✗ %s — fell through to AI (%s)",
                         finding_id, self.error or "no deterministic rule matched")


def try_deterministic(
    fix_type: str,
    file_path: str,
    file_content: str,
    line_number: int,
    finding_metadata: dict,
) -> DeterministicResult:
    """Attempt a deterministic fix. Caller falls through to AI on success=False."""
    ft = fix_type.lower()
    logger.debug("[DETERMINISTIC] attempting %s for fix_type=%s", file_path, ft)

    if ft == "secret_rotation":
        return _patch_secret(file_path, file_content, line_number, finding_metadata)
    if ft == "dependency_upgrade":
        return _patch_dependency(file_path, file_content, finding_metadata)
    if ft in ("malware", "suspicious"):
        return _patch_malware(file_path, file_content, line_number, finding_metadata)

    return DeterministicResult(success=False, error=f"fix_type '{ft}' has no deterministic rule")


# ── Secret rotation ───────────────────────────────────────────────────────────

def _env_var_name(secret_type: str) -> str:
    key = secret_type.lower().strip()
    if key in _ENV_VAR_NAMES:
        return _ENV_VAR_NAMES[key]
    return re.sub(r"[^a-zA-Z0-9]+", "_", secret_type).upper().strip("_") or "SECRET"


def _patch_secret(file_path, file_content, line_number, meta):
    secret_type  = meta.get("secret_type", "SECRET")
    secret_value = meta.get("secret_value", "")
    env_var      = _env_var_name(secret_type)

    fp = file_path.lower()
    is_python = fp.endswith(".py")
    is_js_ts  = any(fp.endswith(e) for e in (".js",".jsx",".ts",".tsx",".mjs",".cjs"))
    is_go     = fp.endswith(".go")

    lines = file_content.splitlines(keepends=True)
    if line_number < 1 or line_number > len(lines):
        return DeterministicResult(success=False,
            error=f"line_number {line_number} out of range ({len(lines)} lines)")

    # Try Python AST first
    if is_python:
        r = _python_secret_replace(file_content, line_number, env_var, secret_value)
        if r.success:
            return r
        logger.debug("[DETERMINISTIC] Python AST failed (%s), trying regex", r.error)

    # Build replacement expression per language
    if is_python:
        replacement = f'os.environ.get("{env_var}", "{_PLACEHOLDER}")'
        import_line = "import os"
    elif is_js_ts:
        replacement = f'process.env.{env_var} || "{_PLACEHOLDER}"'
        import_line = None
    elif is_go:
        replacement = f'os.Getenv("{env_var}") // default: {_PLACEHOLDER}'
        import_line = None
    else:
        replacement = f'"{_PLACEHOLDER}"'
        import_line = None

    target = lines[line_number - 1]
    patched = _replace_string_literal_on_line(target, secret_value, replacement)
    if patched is None:
        patched = _replace_assignment_rhs(target, replacement, is_python, is_js_ts)
    if patched is None:
        return DeterministicResult(success=False,
            error=f"could not locate secret literal on line {line_number}")

    lines[line_number - 1] = patched
    content = "".join(lines)
    if import_line and import_line not in content:
        content = import_line + "\n" + content

    return DeterministicResult(
        success=True, patched_content=content,
        method=f"secret_rotation: replaced {secret_type} at line {line_number} with {env_var} env var",
    )


def _python_secret_replace(source, line_number, env_var, secret_value):
    try:
        tree = ast.parse(source)
    except SyntaxError as e:
        return DeterministicResult(success=False, error=f"ast.parse: {e}")

    replaced = [False]

    class Replacer(ast.NodeTransformer):
        def visit_Assign(self, node):
            if node.lineno == line_number and isinstance(node.value, ast.Constant):
                node.value = ast.parse(
                    f'os.environ.get("{env_var}", "{_PLACEHOLDER}")', mode="eval"
                ).body
                replaced[0] = True
            return node

    new_tree = Replacer().visit(tree)
    if not replaced[0]:
        return DeterministicResult(success=False, error=f"no Assign at line {line_number}")

    try:
        new_source = ast.unparse(new_tree)
    except AttributeError:
        return DeterministicResult(success=False, error="ast.unparse needs Python 3.9+")

    return DeterministicResult(
        success=True, patched_content=new_source,
        method=f"secret_rotation: AST replaced at line {line_number}",
    )


def _replace_string_literal_on_line(line, secret_value, replacement):
    if not secret_value:
        return None
    for q in ('"""', "'''", '"', "'"):
        lit = f"{q}{secret_value}{q}"
        if lit in line:
            return line.replace(lit, replacement, 1)
    return None


def _replace_assignment_rhs(line, replacement, is_python, is_js_ts):
    if is_python:
        m = re.match(r'^(\s*\w[\w.]*\s*(?::\s*\w+\s*)?=\s*)(["\'].*["\'])(.*)', line)
        if m:
            return m.group(1) + replacement + m.group(3) + "\n"
    if is_js_ts:
        m = re.match(r'^(\s*(?:const|let|var)?\s*\w[\w.]*\s*=\s*)(["\'].*["\'])(.*)', line)
        if m:
            return m.group(1) + replacement + m.group(3) + "\n"
    return None


# ── Dependency upgrade ────────────────────────────────────────────────────────

def _patch_dependency(file_path, file_content, meta):
    if not file_content:
        return DeterministicResult(success=False,
            error=f"could not read file: {file_path}")

    package_name = meta.get("package_name", "")
    current_ver  = meta.get("current_version", "")
    fix_ver      = meta.get("fix_version", "")

    if not package_name or not fix_ver:
        return DeterministicResult(success=False,
            error="missing package_name or fix_version")

    fname = file_path.lower().split("/")[-1]

    if "pom.xml" in fname:
        r = _patch_pom_xml(file_content, package_name, current_ver, fix_ver)
        if r.success:
            r.method = f"dependency_upgrade: {package_name} {current_ver}→{fix_ver} in pom.xml"
        return r

    # Simple string replacement patterns
    if current_ver:
        candidates = [
            f"{package_name}=={current_ver}",
            f"{package_name}>={current_ver}",
            f'"{package_name}": "{current_ver}"',
            f'"{package_name}": "^{current_ver}"',
            f'"{package_name}": "~{current_ver}"',
            f"{package_name} = \"{current_ver}\"",
            f"{package_name} v{current_ver}",
            f"{package_name} {current_ver}",
        ]
        for old in candidates:
            if old in file_content:
                new = old.replace(current_ver, fix_ver)
                return DeterministicResult(
                    success=True,
                    patched_content=file_content.replace(old, new, 1),
                    method=f"dependency_upgrade: {package_name} {current_ver}→{fix_ver} in {fname}",
                )

    return DeterministicResult(success=False,
        error=f"could not locate {package_name} {current_ver} in {fname}")


def _patch_pom_xml(content, package_name, current_ver, fix_ver):
    if not current_ver:
        return DeterministicResult(success=False, error="current_version required for pom.xml")
    pat = (r'(<artifactId>' + re.escape(package_name) + r'</artifactId>\s*'
           r'<version>)' + re.escape(current_ver) + r'(</version>)')
    new_content, count = re.subn(pat, r'\g<1>' + fix_ver + r'\2', content)
    if count > 0:
        return DeterministicResult(success=True, patched_content=new_content)
    return DeterministicResult(success=False, error="artifactId/version block not found")


# ── Malware stub ──────────────────────────────────────────────────────────────

def _patch_malware(file_path, file_content, line_number, meta):
    package_name = meta.get("package_name", "")
    guarddog_sig = meta.get("guarddog_sig", "")

    if not package_name:
        return DeterministicResult(success=False,
            error="no package_name — cannot deterministically remove malware")

    logger.debug("[DETERMINISTIC] malware: removing %s (sig: %s) from %s",
                 package_name, guarddog_sig or "unknown", file_path)

    lines = file_content.splitlines(keepends=True)
    new_lines = []
    removed_imports = []
    stubbed_calls   = []
    pkg_re = re.escape(package_name)

    for line in lines:
        ln = line.rstrip("\n\r")
        is_import = bool(
            re.match(rf'^\s*import\s+{pkg_re}', ln) or
            re.match(rf'^\s*from\s+{pkg_re}\s+import', ln) or
            re.match(rf'^\s*(const|let|var)\s+\w+\s*=\s*require\([\'\"]{pkg_re}[\'\"]', ln) or
            re.match(rf'^\s*import\s+.*\s+from\s+[\'\"]{pkg_re}[\'\"]', ln)
        )
        if is_import:
            removed_imports.append(ln.strip())
            sig = f" ({guarddog_sig})" if guarddog_sig else ""
            new_lines.append(f"# REACHABLE_REMOVED: {ln.strip()} — malicious package{sig}\n")
            continue
        if re.search(rf'\b{pkg_re}\b', ln):
            stubbed_calls.append(ln.strip())
            new_lines.append(
                f"# REACHABLE_STUB: {ln.strip()} — removed (malicious: {package_name})\n"
                f"# TODO: manual review required — verify no legitimate functionality lost\n"
            )
            continue
        new_lines.append(line)

    if not removed_imports and not stubbed_calls:
        return DeterministicResult(success=False,
            error=f"no import/call sites found for {package_name}")

    sig_note = f" sig={guarddog_sig}" if guarddog_sig else ""
    return DeterministicResult(
        success=True,
        patched_content="".join(new_lines),
        method=(f"malware_stub: removed {package_name}{sig_note} "
                f"({len(removed_imports)} imports, {len(stubbed_calls)} call sites)"),
    )
