#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.
"""
Cloud model interface — Anthropic Claude API.

Two modes:
  get_strategy()  — sends RemediationContext (metadata only, NO source code)
                    returns fix strategy JSON for hybrid mode
  generate()      — sends source code + prompt, returns unified diff (cloud mode)

repo.db upload (cloud mode only):
  When available, the last scan's repo.db is compressed and uploaded via the
  Anthropic Files API before the session starts. Claude then gets the full
  scan context — call graphs, all findings, EPSS scores, dependency chains —
  without us having to manually serialize it into the prompt.

  The file_id is cached for the duration of the EnzoPipeline session so we
  upload once and reference it for every finding in the same run.
"""

from __future__ import annotations

import gzip
import io
import json
import logging
import os
import sqlite3
import time
from pathlib import Path
from typing import Any, Dict, Optional

from ..models import RemediationContext

logger = logging.getLogger(__name__)

try:
    import urllib.error
    import urllib.request
except ImportError:
    pass

_SYSTEM_PROMPT = """\
You are a security remediation advisor for the REACHABLE vulnerability scanner.
You receive METADATA ONLY about security findings — never source code.

Your job: provide a concrete fix STRATEGY that a code-generation model can execute.

Output JSON with these fields:
{
  "approach": "short name for the strategy",
  "description": "1-2 sentence explanation",
  "safe_apis": ["list", "of", "recommended", "safe", "APIs"],
  "unsafe_patterns": ["patterns", "to", "avoid"],
  "edge_cases": ["things", "to", "watch", "for"],
  "test_hints": ["what", "to", "test", "after", "patching"],
  "confidence": "high|medium|low"
}

Respond with ONLY the JSON object, no markdown fences or preamble.
"""

_SYSTEM_PROMPT_WITH_DB = """\
You are a security remediation advisor for the REACHABLE vulnerability scanner.

You have been given the full scan database (repo.db) as an attached document.
It contains all findings, call graphs, reachability paths, EPSS scores,
dependency chains, and scan metadata for this repository.

Use this rich context to advise on the best fix strategy.

Your job: provide a concrete fix STRATEGY that a code-generation model can execute.

Output JSON with these fields:
{
  "approach": "short name for the strategy",
  "description": "1-2 sentence explanation",
  "safe_apis": ["list", "of", "recommended", "safe", "APIs"],
  "unsafe_patterns": ["patterns", "to", "avoid"],
  "edge_cases": ["things", "to", "watch", "for"],
  "test_hints": ["what", "to", "test", "after", "patching"],
  "confidence": "high|medium|low",
  "related_findings": ["other finding_ids from the DB that share the same root cause"]
}

Respond with ONLY the JSON object, no markdown fences or preamble.
"""

# Max compressed repo.db size we'll upload (bytes). Scans are typically <5MB compressed.
_MAX_DB_UPLOAD_BYTES = 20 * 1024 * 1024   # 20 MB



def _http_post_with_retry(
    url: str,
    payload: dict,
    headers: dict,
    timeout: int,
    max_retries: int = 3,
    retryable_codes: tuple = (429, 500, 502, 503, 529),
):
    """POST with exponential backoff retry for transient errors.

    Retries on 429/529 (rate limit, honours Retry-After), 5xx (server error),
    and transient URLError (RemoteDisconnected, IncompleteRead, etc.).
    Raises immediately on permanent 4xx errors.
    """
    import time as _time
    data = json.dumps(payload).encode("utf-8")
    for attempt in range(max_retries):
        req = urllib.request.Request(url, data=data, headers=headers, method="POST")
        try:
            return urllib.request.urlopen(req, timeout=timeout)
        except urllib.error.HTTPError as exc:
            if exc.code in retryable_codes:
                wait = 2 ** attempt
                try:
                    ra = exc.headers.get("Retry-After")
                    if ra:
                        wait = min(int(ra), 60)
                except Exception:
                    pass
                if attempt < max_retries - 1:
                    logger.debug("HTTP %d — retrying in %ds (attempt %d/%d)",
                                 exc.code, wait, attempt + 1, max_retries)
                    _time.sleep(wait)
                    continue
            raise
        except urllib.error.URLError as exc:
            reason = str(exc.reason)
            transient = any(k in reason for k in (
                "RemoteDisconnected", "ConnectionReset", "IncompleteRead",
                "Connection refused", "Broken pipe",
            ))
            if transient and attempt < max_retries - 1:
                wait = 2 ** attempt
                logger.debug("Transient URLError (%s) — retrying in %ds (attempt %d/%d)",
                             reason, wait, attempt + 1, max_retries)
                _time.sleep(wait)
                continue
            raise
    raise RuntimeError("_http_post_with_retry: exceeded max_retries")


class CloudModel:
    """Interface to Anthropic Claude API."""

    API_URL      = "https://api.anthropic.com/v1/messages"
    FILES_URL    = "https://api.anthropic.com/v1/files"
    BETA_HEADER  = "files-api-2025-04-14"

    def __init__(self, model: str = "claude-sonnet-4-6", api_key: Optional[str] = None):
        self.model = model
        self.api_key = api_key or os.environ.get("ANTHROPIC_API_KEY", "")
        # Session-scoped cache: repo_db_path → file_id
        # Uploaded once per EnzoPipeline run, reused for every finding.
        self._db_file_id: Optional[str] = None
        self._db_file_path: Optional[str] = None   # path we uploaded

    # ─────────────────────────────────────────────────────────────────────
    #  repo.db upload
    # ─────────────────────────────────────────────────────────────────────

    def upload_scan_db(self, db_path: str) -> Optional[str]:
        """
        Compress and upload repo.db to the Anthropic Files API.

        Returns the file_id on success, None on failure.
        The file_id is cached so subsequent calls with the same path are free.

        Compression: we dump only the tables Claude needs (findings, scans,
        call_paths) into a fresh SQLite, then gzip it.  This avoids sending
        internal Enzo audit tables and keeps the upload small.
        """
        if not self.api_key:
            return None

        # Cache hit
        if self._db_file_id and self._db_file_path == db_path:
            logger.debug("Using cached repo.db file_id: %s", self._db_file_id)
            return self._db_file_id

        path = Path(db_path)
        if not path.exists():
            logger.warning("upload_scan_db: db not found: %s", db_path)
            return None

        try:
            compressed = self._compress_scan_db(db_path)
        except Exception as exc:
            logger.warning("upload_scan_db: compression failed: %s", exc)
            return None

        if len(compressed) > _MAX_DB_UPLOAD_BYTES:
            logger.warning(
                "upload_scan_db: compressed db too large (%d MB), skipping upload",
                len(compressed) // (1024 * 1024),
            )
            return None

        file_id = self._upload_bytes(compressed, filename="scan.db.gz", content_type="application/gzip")
        if file_id:
            self._db_file_id = file_id
            self._db_file_path = db_path
            logger.info("Uploaded repo.db as file_id=%s (%.1f KB compressed)", file_id, len(compressed) / 1024)
        return file_id

    def _compress_scan_db(self, db_path: str) -> bytes:
        """
        Extract the REACHABLE scan tables from repo.db into a minimal
        SQLite in memory, then gzip it.

        Tables included: scans, findings, call_paths (if present).
        Tables excluded: enzo_attempts and any other internal tables.
        """
        src = sqlite3.connect(f"file:{db_path}?mode=ro", uri=True)
        src.row_factory = sqlite3.Row

        # List tables we want to keep
        wanted = {"scans", "findings", "call_paths", "packages", "dependency_graph"}
        existing = {
            row[0] for row in src.execute("SELECT name FROM sqlite_master WHERE type='table'")
        }
        to_copy = wanted & existing

        # Build minimal db in memory
        dst = sqlite3.connect(":memory:")
        for table in to_copy:
            # Copy schema
            schema_row = src.execute(
                "SELECT sql FROM sqlite_master WHERE type='table' AND name=?", (table,)
            ).fetchone()
            if schema_row and schema_row[0]:
                dst.execute(schema_row[0])
            # Copy rows (cap at 50k rows per table to stay sane)
            rows = src.execute(f"SELECT * FROM {table} LIMIT 50000").fetchall()  # noqa: S608
            if rows:
                placeholders = ",".join("?" * len(rows[0]))
                dst.executemany(f"INSERT OR IGNORE INTO {table} VALUES ({placeholders})", rows)  # noqa: S608
        dst.commit()

        # Dump to bytes
        buf = io.BytesIO()
        for chunk in dst.iterdump():
            buf.write((chunk + "\n").encode())

        src.close()
        dst.close()

        # Gzip compress
        gz_buf = io.BytesIO()
        with gzip.GzipFile(fileobj=gz_buf, mode="wb", compresslevel=9) as gz:
            gz.write(buf.getvalue())
        return gz_buf.getvalue()

    def _upload_bytes(self, data: bytes, filename: str, content_type: str) -> Optional[str]:
        """POST to Files API, return file_id."""
        boundary = "EnzoUpload" + str(int(time.time()))
        body_parts = [
            f"--{boundary}\r\n".encode(),
            f'Content-Disposition: form-data; name="file"; filename="{filename}"\r\n'.encode(),
            f"Content-Type: {content_type}\r\n\r\n".encode(),
            data,
            f"\r\n--{boundary}--\r\n".encode(),
        ]
        body = b"".join(body_parts)

        try:
            req = urllib.request.Request(
                self.FILES_URL,
                data=body,
                headers={
                    "x-api-key": self.api_key,
                    "anthropic-version": "2023-06-01",
                    "anthropic-beta": self.BETA_HEADER,
                    "Content-Type": f"multipart/form-data; boundary={boundary}",
                },
                method="POST",
            )
            with urllib.request.urlopen(req, timeout=120) as resp:
                result = json.loads(resp.read())
            file_id = result.get("id")
            if not file_id:
                logger.warning("Files API returned no id: %s", result)
            return file_id
        except Exception as exc:
            logger.warning("Files API upload failed: %s", exc)
            return None

    def delete_uploaded_db(self):
        """Clean up the uploaded file after the pipeline run completes."""
        if not self._db_file_id or not self.api_key:
            return
        try:
            req = urllib.request.Request(
                f"{self.FILES_URL}/{self._db_file_id}",
                headers={
                    "x-api-key": self.api_key,
                    "anthropic-version": "2023-06-01",
                    "anthropic-beta": self.BETA_HEADER,
                },
                method="DELETE",
            )
            urllib.request.urlopen(req, timeout=30)
            logger.info("Deleted uploaded repo.db file_id=%s", self._db_file_id)
        except Exception as exc:
            logger.debug("Failed to delete uploaded file: %s", exc)
        finally:
            self._db_file_id = None
            self._db_file_path = None

    # ─────────────────────────────────────────────────────────────────────
    #  Strategy (metadata-only, hybrid mode)
    # ─────────────────────────────────────────────────────────────────────

    def get_strategy(self, context: RemediationContext) -> Dict[str, Any]:
        """
        Send metadata envelope to Claude, get back a fix strategy.
        If a repo.db file_id is cached, attach it for richer context.
        """
        if not self.api_key:
            return {"strategy": None, "model": f"cloud:{self.model}", "latency_ms": 0,
                    "error": "No ANTHROPIC_API_KEY set"}

        prompt = context.to_prompt_block()
        start = time.time()

        # Build message content — attach DB file if we have it
        if self._db_file_id:
            system = _SYSTEM_PROMPT_WITH_DB
            user_content = [
                {
                    "type": "document",
                    "source": {
                        "type": "file",
                        "file_id": self._db_file_id,
                    },
                    "title": "REACHABLE scan database (repo.db)",
                    "context": "Full scan results including all findings, call graphs, and reachability data.",
                },
                {"type": "text", "text": f"Finding to advise on:\n\n{prompt}"},
            ]
        else:
            system = _SYSTEM_PROMPT
            user_content = prompt

        payload = {
            "model": self.model,
            "max_tokens": 1024,
            "system": system,
            "messages": [{"role": "user", "content": user_content}],
        }
        if self._db_file_id:
            payload["betas"] = [self.BETA_HEADER]

        return self._post_and_parse_json(payload, start)

    # ─────────────────────────────────────────────────────────────────────
    #  Direct generation (cloud mode — sends source code)
    # ─────────────────────────────────────────────────────────────────────

    def generate(self, prompt: str, system: str = "", temperature: float = 0.1) -> Dict[str, Any]:
        """
        Send source code + prompt to Claude, get back a unified diff.
        ⚠ This sends actual file contents to the Anthropic API.
        Only used in --mode cloud with user consent.

        If a repo.db has been uploaded this session (_db_file_id is set),
        the scan database is attached to the request for richer context —
        Claude can cross-reference the finding against call graphs and
        related findings without us having to serialize everything into
        the prompt.
        """
        if not self.api_key:
            return {"text": "", "model": f"cloud:{self.model}", "latency_ms": 0,
                    "error": "No ANTHROPIC_API_KEY set"}

        start = time.time()

        # Attach the scan DB if we have it — same pattern as get_strategy().
        # This gives Claude the full call graph / reachability context when
        # generating the actual diff, not just the strategy advisory.
        if self._db_file_id:
            user_content = [
                {
                    "type": "document",
                    "source": {
                        "type": "file",
                        "file_id": self._db_file_id,
                    },
                    "title": "REACHABLE scan database (repo.db)",
                    "context": "Full scan results: findings, call graphs, reachability paths, EPSS scores.",
                },
                {"type": "text", "text": prompt},
            ]
        else:
            user_content = prompt

        payload: Dict[str, Any] = {
            "model": self.model,
            "max_tokens": 4096,
            "messages": [{"role": "user", "content": user_content}],
        }
        if system:
            payload["system"] = system
        if self._db_file_id:
            payload["betas"] = [self.BETA_HEADER]

        try:
            headers = {
                "Content-Type": "application/json",
                "x-api-key": self.api_key,
                "anthropic-version": "2023-06-01",
            }
            if self._db_file_id:
                headers["anthropic-beta"] = self.BETA_HEADER
            with _http_post_with_retry(
                self.API_URL, payload, headers=headers,
                timeout=120, max_retries=3,
            ) as resp:
                data = json.loads(resp.read())
            text = "".join(b.get("text", "") for b in data.get("content", []) if b.get("type") == "text")
            return {"text": text, "model": f"cloud:{self.model}",
                    "latency_ms": (time.time() - start) * 1000, "error": None}

        except urllib.error.HTTPError as exc:
            # Read the response body — the API always returns a JSON error
            # object with a specific reason, e.g. invalid model name,
            # content policy, context limit exceeded, etc.
            # Without this we only see "HTTP Error 400: Bad Request".
            try:
                body = exc.read().decode("utf-8", errors="replace")
                try:
                    err_detail = json.loads(body).get("error", {}).get("message", body[:500])
                except json.JSONDecodeError:
                    err_detail = body[:500]
            except Exception:
                err_detail = f"HTTP {exc.code}"
            error_msg = f"HTTP Error {exc.code}: {err_detail}"
            logger.error("Cloud API error in generate(): %s", error_msg)
            return {"text": "", "model": f"cloud:{self.model}",
                    "latency_ms": (time.time() - start) * 1000, "error": error_msg}
        except Exception as exc:
            return {"text": "", "model": f"cloud:{self.model}",
                    "latency_ms": (time.time() - start) * 1000, "error": str(exc)}

    def is_available(self) -> bool:
        return bool(self.api_key)

    # ─────────────────────────────────────────────────────────────────────
    #  Internal helpers
    # ─────────────────────────────────────────────────────────────────────

    def _post_and_parse_json(self, payload: Dict, start: float) -> Dict[str, Any]:
        """POST to messages API, parse JSON response."""
        try:
            _headers = {
                "Content-Type": "application/json",
                "x-api-key": self.api_key,
                "anthropic-version": "2023-06-01",
            }
            if payload.get("betas"):
                _headers["anthropic-beta"] = ",".join(payload["betas"])
            with _http_post_with_retry(
                self.API_URL, payload, headers=_headers,
                timeout=60, max_retries=3,
            ) as resp:
                data = json.loads(resp.read())

            text = "".join(b.get("text", "") for b in data.get("content", []) if b.get("type") == "text").strip()
            if text.startswith("```"):
                text = text.split("\n", 1)[-1].rsplit("```", 1)[0]
            strategy = json.loads(text)

            return {"strategy": strategy, "model": f"cloud:{self.model}",
                    "latency_ms": (time.time() - start) * 1000, "error": None}

        except urllib.error.HTTPError as exc:
            try:
                body = exc.read().decode("utf-8", errors="replace")
                try:
                    err_detail = json.loads(body).get("error", {}).get("message", body[:500])
                except json.JSONDecodeError:
                    err_detail = body[:500]
            except Exception:
                err_detail = f"HTTP {exc.code}"
            error_msg = f"HTTP Error {exc.code}: {err_detail}"
            logger.error("Cloud API error in _post_and_parse_json(): %s", error_msg)
            return {"strategy": None, "model": f"cloud:{self.model}",
                    "latency_ms": (time.time() - start) * 1000, "error": error_msg}
        except json.JSONDecodeError as exc:
            return {"strategy": None, "model": f"cloud:{self.model}",
                    "latency_ms": (time.time() - start) * 1000,
                    "error": f"Failed to parse cloud response as JSON: {exc}"}
        except Exception as exc:
            return {"strategy": None, "model": f"cloud:{self.model}",
                    "latency_ms": (time.time() - start) * 1000, "error": str(exc)}

