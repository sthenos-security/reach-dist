#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.
"""
Patcher engine — routes to local, cloud, or hybrid model pipeline.
"""

from __future__ import annotations

import json
import logging
import time
from pathlib import Path
from typing import Dict, List, Optional

from ..config import EnzoConfig
from ..knowledge import EnzoKnowledgeDB
from ..models import EnzoFinding, FixType, PatchResult, RemediationContext
from .cloud_model import CloudModel
from .code_reducer import reduce_for_finding
from .deterministic import try_deterministic
from .local_model import LocalModel
from .prompts import (
    code_patch_prompt,
    config_fix_prompt,
    dependency_upgrade_prompt,
    dlp_fix_prompt,
    inject_tokens,
    make_request_token,
    retry_prompt,
    secret_rotation_prompt,
    verify_tokens,
)

logger = logging.getLogger(__name__)

# Number of candidate patches to generate in parallel on attempt 1.
# Each uses a slightly different strategy hint in the prompt.
# All are validated; first to pass wins.  On retries we fall back to 1.
_CANDIDATES = 3
_CANDIDATE_STRATEGIES = [
    "minimal — change only the vulnerable line/call",
    "idiomatic — use the standard safe API for this language/framework",
    "defensive — add input validation + the safe API",
]

_MANIFEST_FILES = {
    "npm":     ("package.json", "package-lock.json"),
    "yarn":    ("package.json", "yarn.lock"),
    "pnpm":    ("package.json", "pnpm-lock.yaml"),
    "pip":     ("requirements.txt", None),
    "pipenv":  ("Pipfile", "Pipfile.lock"),
    "go":      ("go.mod", "go.sum"),
    "maven":   ("pom.xml", None),
    "gradle":  ("build.gradle", None),
    "cargo":   ("Cargo.toml", "Cargo.lock"),
    "bundler": ("Gemfile", "Gemfile.lock"),
    "composer":("composer.json", "composer.lock"),
}


def _dbg(config, *parts, sep=" "):
    """Print debug trace to console when --debug is set."""
    if getattr(config, "debug", False):
        print("  [enzo]", sep.join(str(p) for p in parts))


def _rel_path(repo_path: str, file_path: str) -> str:
    """
    Return file_path relative to repo_path.
    If the model returns an absolute path (e.g. /Users/.../repo/src/foo.py),
    strip the repo prefix so git apply gets a repo-relative path (src/foo.py).
    """
    try:
        return str(Path(file_path).relative_to(repo_path))
    except ValueError:
        # Already relative, or on a different drive — return as-is
        return file_path


def _read_file(repo_path: str, rel_path: str, max_bytes: int = 100_000) -> Optional[str]:
    try:
        fp = Path(repo_path) / rel_path
        if fp.exists() and fp.stat().st_size <= max_bytes:
            return fp.read_text(errors="replace")
    except OSError as exc:
        logger.debug("Cannot read %s: %s", rel_path, exc)
    return None


def _find_manifest(repo_path: str, ecosystem: str):
    """Locate manifest file for the given ecosystem.
    If ecosystem is unknown/empty, probe the repo for known manifest files.
    """
    manifest_name, lock_name = _MANIFEST_FILES.get(ecosystem or "", (None, None))
    if not manifest_name:
        # Auto-detect: walk all ecosystems and return the first manifest found
        for _eco, (mf, lf) in _MANIFEST_FILES.items():
            if _read_file(repo_path, mf):
                manifest_name, lock_name = mf, lf
                logger.info("Auto-detected ecosystem=%s (no build_system in context)", _eco)
                break
    if not manifest_name:
        return None, None, None, None
    m_content = _read_file(repo_path, manifest_name)
    if not m_content:
        return None, None, None, None
    l_content = _read_file(repo_path, lock_name) if lock_name else None
    return manifest_name, m_content, lock_name, l_content


# Keywords indicating a fatal API error — mirrors pipeline._FATAL_ERROR_KEYWORDS.
# Inlined here so engine.py doesn't need to import from pipeline (circular).
_FATAL_CANDIDATE_KEYWORDS = (
    "credit", "balance", "billing", "unauthorized", "forbidden",
    "authentication", "api key", "invalid_api_key", "permission denied",
    "tokens per day", "tpd exhausted",
)

def _is_fatal_candidate_error(error: str) -> bool:
    """True if this error means the entire pipeline should stop."""
    low = error.lower()
    return any(kw in low for kw in _FATAL_CANDIDATE_KEYWORDS)


def extract_diff(model_output: str) -> str:
    """Extract unified diff from model output, stripping preamble and code fences."""
    # Strip markdown code fences the model wraps around the diff
    # e.g. ```diff\n...\n``` or ```\n...\n```
    text = model_output.strip()
    if text.startswith("```"):
        # Remove opening fence (```diff, ```patch, ``` etc.)
        text = text.split("\n", 1)[1] if "\n" in text else text
        # Remove closing fence
        if text.rstrip().endswith("```"):
            text = text.rstrip()[:-3].rstrip()

    import re as _re2
    _num = _re2.compile(r"^\d+\s*\|\s?")
    lines = text.split("\n")
    diff_lines: list[str] = []
    in_diff = False
    for line in lines:
        if line.strip() == "```":
            break
        if line.startswith("---") or line.startswith("diff --git"):
            in_diff = True
        if in_diff:
            if line and line[0] in ("+", "-", " "):
                diff_lines.append(line[0] + _num.sub("", line[1:]))
            else:
                diff_lines.append(line)
    return "\n".join(diff_lines).strip() if diff_lines else text.strip()


def files_from_diff(diff: str) -> List[str]:
    """Extract modified file paths from a unified diff."""
    files = []
    for line in diff.split("\n"):
        if line.startswith("+++ b/"):
            files.append(line[6:])
        elif line.startswith("+++ ") and "/dev/null" not in line:
            files.append(line[4:].strip())
    return files


def _strip_code_fences(text: str) -> str:
    """Strip markdown fences and line-number prefixes from model output.

    The code reducer injects "NNNN | " prefixes so the model knows real line
    numbers for diff offsets. Models often echo these prefixes back verbatim,
    which breaks ast.parse() and diff application. Strip them here so the
    rest of the pipeline always sees clean source.
    """
    import re as _re
    t = text.strip()
    if t.startswith("```"):
        t = t.split("\n", 1)[1] if "\n" in t else ""
        if t.rstrip().endswith("```"):
            t = t.rstrip()[:-3].rstrip("\n")
    # Strip "NNNN | " line-number prefixes added by the code reducer for context.
    # Only strip if >=50% of lines carry them to avoid false-positives on
    # legitimate code that happens to start with digits.
    lines = t.splitlines()
    prefix_re = _re.compile(r"^\s*\d{1,6}\s*\|\s?")
    prefixed = sum(1 for ln in lines if prefix_re.match(ln))
    if lines and prefixed / len(lines) >= 0.5:
        lines = [prefix_re.sub("", ln, count=1) for ln in lines]
        t = "\n".join(lines)
    return t


def _make_diff(file_path: str, original_content: str, patched_content: str) -> str:
    """Produce a unified diff string between original and patched content."""
    import difflib
    original_lines = original_content.splitlines(keepends=True)
    patched_lines = patched_content.splitlines(keepends=True)
    diff = difflib.unified_diff(original_lines, patched_lines, fromfile=file_path, tofile=file_path)
    return "".join(diff)


def _code_to_diff(
    repo_path: str,
    rel_path: str,
    original_content: str,
    new_slice: str,
    slice_start: int,
    slice_end: int,
) -> tuple[bool, str]:
    """Splice corrected code into full file, produce diff via git diff --no-index."""
    import re as _r2
    import subprocess as _sp
    import tempfile as _tmp
    from pathlib import Path as _P
    orig_lines = original_content.splitlines(keepends=True)
    new_lines  = new_slice.splitlines(keepends=True)
    if new_lines and not new_lines[-1].endswith("\n"):
        new_lines[-1] += "\n"
    patched = orig_lines[:slice_start - 1] + new_lines + orig_lines[slice_end:]
    patched_content = "".join(patched)
    if patched_content == original_content:
        return False, "Model returned identical code"
    with _tmp.TemporaryDirectory() as tmp:
        orig_f = _P(tmp) / "original"
        new_f  = _P(tmp) / "patched"
        orig_f.write_text(original_content)
        new_f.write_text(patched_content)
        r = _sp.run(["git", "diff", "--no-index", str(orig_f), str(new_f)],
                    capture_output=True, text=True)
        if r.returncode == 2:
            return False, f"git diff --no-index failed: {r.stderr.strip()}"
        if r.returncode == 0:
            return False, "Model produced no changes"
        diff = r.stdout
        diff = _r2.sub(r"^--- .+", f"--- a/{rel_path}", diff, count=1, flags=_r2.MULTILINE)
        diff = _r2.sub(r"^\+\+\+ .+", f"+++ b/{rel_path}", diff, count=1, flags=_r2.MULTILINE)
        if not diff.endswith("\n"):
            diff += "\n"
        return True, diff


def _validate_code_output(
    corrected: str,
    original: str,
    language: str = "",
    finding_line: int = 0,
) -> tuple[bool, str]:
    """Hallucination detector.

    Three reliable layers only — structural similarity was dropped because
    a security fix (e.g. os.system → subprocess.run) legitimately produces
    0% line overlap with the original. git apply is the real structural validator.

    Layers:
      1. Prose/JSON  — model returned explanations, pentest steps, or JSON
      2. Token budget — output massively larger than input
      3. Syntax check — ast.parse() for Python
    """
    import re as _rn
    t = corrected.strip()
    if not t:
        return False, "empty output"

    lines = t.splitlines()

    # ── Layer 1a: JSON blob ───────────────────────────────────────────────────
    if t.startswith("{") and t.endswith("}"):
        try:
            import json as _j
            _j.loads(t)
            return False, "model returned JSON object instead of source code"
        except Exception:
            pass

    # ── Layer 1b: prose / pentest content ────────────────────────────────────
    # Two independent signals required to avoid false positives on code
    # that happens to contain a comment like "# Step 1: validate input".
    # Lines that are definitely code comments in any supported language — skip them
    # so Python `# comment`, Go `// comment`, JS `// comment` don't trigger prose
    # patterns that look for markdown `# Heading` or prose `## Section`.
    def _is_code_comment(ln: str) -> bool:
        s = ln.strip()
        return (s.startswith("//") or s.startswith("/*") or s.startswith("*")
                or (s.startswith("#") and not _rn.match(r"^#{2,}", s)))

    prose_patterns = [
        r"^#{2,4} \w",            # markdown headers ONLY (## or ###, not # which is Python comment)
        r"^\*\*\w",               # bold text (**Word) — not a code comment
        r"^Step \d+[.:]",         # "Step 1:" / "Step 1."
        r"^\d+\. [A-Z][a-z]",     # "1. Do something" (sentence case)
        r"^(nmap|hydra|metasploit|msfconsole|sqlmap) ",  # known attack tools
        r"^```(bash|sh|zsh|fish|powershell)$",           # shell code blocks
        r"^(Objective|Action|Expected Output|Prerequisites):",
        r"^\*\s+\*\*",            # bullet + bold "* **Term**"
    ]
    prose_hits = sum(
        1 for ln in lines[:40]
        if not _is_code_comment(ln)
        and any(_rn.match(pat, ln.strip()) for pat in prose_patterns)
    )
    if prose_hits >= 2:
        return False, f"prose/instructions detected ({prose_hits} markers)"

    # ── Layer 1c: must contain at least one code-like line ───────────────────
    code_signals = [
        r"import ", r"from .* import", r"def ", r"class ", r" = ", r"\+=|-=",
        r"return ", r"raise ", r"yield ",
        r"if .+:", r"for .+:", r"while .+:", r"with .+:",
        r"require\(", r"func ", r"var ", r"const ", r"let ",
        r"\w+\(.*\)",   # function call with parens
        r"^    \S", r"^	\S",  # non-empty indented line
    ]
    code_hits = sum(1 for ln in lines[:40] if any(_rn.search(sig, ln) for sig in code_signals))
    if code_hits == 0 and len(lines) > 3:
        return False, "no code-like lines detected in output"

    # ── Layer 2: token budget ─────────────────────────────────────────────────
    orig_lines = len(original.splitlines())
    out_lines  = len(lines)
    if orig_lines > 5 and out_lines > orig_lines * 4:
        return False, (
            f"output ({out_lines} lines) is {out_lines // orig_lines}x larger than "
            f"input ({orig_lines} lines)"
        )

    # ── Layer 3: Python syntax check (Python files only) ─────────────────────
    lang = (language or "").lower()
    # Explicitly non-Python languages — never run ast.parse on these
    _NON_PYTHON_LANGS = {
        "javascript", "typescript", "js", "ts", "tsx", "jsx",
        "go", "java", "ruby", "rust", "c", "cpp", "csharp",
        "swift", "kotlin", "php", "bash", "sh",
    }
    _NON_PYTHON_EXTS = {
        ".ts", ".tsx", ".js", ".jsx", ".mjs", ".cjs",
        ".go", ".java", ".rb", ".rs", ".c", ".cpp", ".cs",
        ".swift", ".kt", ".php", ".sh", ".bash",
    }
    import os as _os
    _ext = _os.path.splitext(lang)[1].lower() if "." in lang else ""
    is_explicitly_non_python = lang in _NON_PYTHON_LANGS or _ext in _NON_PYTHON_EXTS
    is_python = (
        not is_explicitly_non_python
        and (
            lang in ("python", "py")
            or (lang == "" and bool(_rn.search(r"^(def |import |class |\s+return )", t, _rn.M)))
        )
    )
    if is_python:
        try:
            import ast as _a
            _a.parse(t)
        except SyntaxError as e:
            return False, f"Python syntax error: {e}"

    return True, ""


def _is_nonsense_output(text: str, original: str = "", language: str = "") -> bool:
    """Backward-compatible wrapper around _validate_code_output."""
    ok, _ = _validate_code_output(text, original or text, language)
    return not ok


class PatchEngine:
    """Orchestrates patch generation across local and cloud models."""

    def __init__(self, config: EnzoConfig, knowledge: Optional[EnzoKnowledgeDB] = None):
        self.config = config
        self.knowledge = knowledge
        # Local/Groq model: 'local', 'both', and 'groq' modes
        if getattr(config, "mode", "local") == "groq":
            self.local = LocalModel(
                model=getattr(config, "groq_model", "qwen-2.5-coder-32b"),
                endpoint=getattr(config, "groq_endpoint", "https://api.groq.com/openai"),
                api_key=getattr(config, "groq_api_key", ""),
            )
        elif config.needs_local:
            self.local = LocalModel(
                model=config.local_model,
                endpoint=config.local_endpoint,
            )
        else:
            self.local = None
        # Cloud model — groq provider reuses LocalModel with Groq endpoint
        _prov = getattr(config, "provider", "claude")
        if config.cloud_enabled and _prov == "groq":
            self.cloud = None
            if self.local is None:
                self.local = LocalModel(
                    model=getattr(config, "groq_model", "qwen-2.5-coder-32b"),
                    endpoint=getattr(config, "groq_endpoint", "https://api.groq.com/openai"),
                    api_key=getattr(config, "groq_api_key", ""),
                )
        else:
            self.cloud = (
                CloudModel(model=config.cloud_model, api_key=config.cloud_api_key)
                if config.cloud_enabled else None
            )

    def generate_patch(
        self,
        finding: EnzoFinding,
        context: RemediationContext,
        repo_path: str,
        attempt_number: int = 1,
        prior_error: Optional[str] = None,
        prior_error_stage: Optional[str] = None,
    ) -> PatchResult:
        fix_type = finding.fix_type

        # Cloud strategy step (metadata-only — no source code sent).
        # Not used in cloud or fallback modes where the model generates diffs directly.
        cloud_strategy = None

        # Knowledge hints
        upgrade_safety = None
        error_hint = None
        if self.knowledge:
            if fix_type == FixType.DEPENDENCY_UPGRADE and finding.package_name:
                upgrade_safety = self.knowledge.get_upgrade_safety(
                    finding.package_name, context.build_system or "",
                    finding.package_version, finding.fix_version,
                )
            if prior_error:
                eh = self.knowledge.get_error_hints(
                    prior_error,
                    stage=prior_error_stage or "",
                    language=context.language,
                )
                if eh:
                    error_hint = eh.get("resolution")

        # ── Deterministic path (zero AI, zero tokens) ────────────────────────
        # Attempt mechanical transformation before ever calling the LLM.
        # Only fires on attempt 1 — retries go straight to AI.
        if attempt_number == 1 and fix_type.value in ("secret_rotation", "dependency_upgrade", "malware", "suspicious"):
            _det_meta = {
                "secret_type":      getattr(finding, "finding_type", ""),
                "secret_value":     getattr(finding, "secret_value", ""),
                "package_name":     getattr(finding, "package_name", ""),
                "current_version":  getattr(finding, "package_version", ""),
                "fix_version":      getattr(finding, "fix_version", ""),
                "ecosystem":        getattr(finding, "ecosystem", ""),
                "guarddog_sig":     getattr(finding, "guarddog_sig", ""),
            }
            _file_path = getattr(finding, "file_path", "") or ""
            _file_content = _read_file(repo_path, _file_path) if _file_path else ""
            _det = try_deterministic(
                fix_type=fix_type.value,
                file_path=_file_path,
                file_content=_file_content,
                line_number=getattr(finding, "line_number", 0) or 0,
                finding_metadata=_det_meta,
            )
            _det.log(finding.finding_id)
            if _det.success:
                return PatchResult(
                    success=True,
                    diff=_make_diff(_file_path, _file_content, _det.patched_content),
                    patched_content=_det.patched_content,
                    strategy_used=_det.method,
                    model_used="deterministic",
                    tokens_used=0,
                )
            # Log that we fell through to AI
            logger.debug("[AI] → %s attempt %d — %s",
                         finding.finding_id, attempt_number,
                         getattr(self.local, "model", "unknown"))

        try:
            dispatch = {
                FixType.DEPENDENCY_UPGRADE: self._patch_dependency,
                FixType.CODE_PATCH: self._patch_code,
                FixType.CONFIG_CHANGE: self._patch_config,
                FixType.SECRET_ROTATION: self._patch_secret,
                FixType.DLP_PATCH: self._patch_dlp,
            }
            handler = dispatch.get(fix_type)
            if not handler:
                return PatchResult(success=False, error=f"Fix type {fix_type} requires manual remediation")
            result = handler(
                finding, context, repo_path, cloud_strategy,
                upgrade_safety, attempt_number, prior_error, prior_error_stage, error_hint,
            )
            # Fallback mode: if local failed all candidates, escalate to cloud
            if (
                not result.success
                and self.config.fallback_to_cloud
                and self.cloud
                and self.cloud.is_available()
                and attempt_number == 1  # only escalate on first attempt
            ):
                logger.info(
                    "Local failed for %s — escalating to cloud (%s)",
                    finding.finding_id[:12], self.config.provider,
                )
                # Temporarily switch to cloud mode for this finding
                _saved_mode = self.config.mode
                self.config.mode = "cloud"
                try:
                    result = handler(
                        finding, context, repo_path, cloud_strategy,
                        upgrade_safety, attempt_number, prior_error,
                        prior_error_stage, error_hint,
                    )
                    if result.success:
                        logger.info("Cloud fallback succeeded for %s", finding.finding_id[:12])
                finally:
                    self.config.mode = _saved_mode
            return result
        except Exception as exc:
            logger.error("Patch generation failed: %s", exc, exc_info=True)
            return PatchResult(success=False, error=str(exc))

    def _get_cloud_strategy(self, context: RemediationContext) -> Optional[Dict]:
        prompt_block = context.to_prompt_block()
        if self.knowledge:
            cached = self.knowledge.get_cached_strategy(prompt_block)
            if cached:
                try:
                    logger.info("Using cached cloud strategy")
                    return json.loads(cached)
                except json.JSONDecodeError as exc:
                    logger.warning("Cached strategy is corrupt JSON, ignoring: %s", exc)

        result = self.cloud.get_strategy(context)
        if result.get("error"):
            logger.warning("Cloud strategy failed: %s", result["error"])
            return None

        strategy = result.get("strategy")
        if strategy and self.knowledge:
            self.knowledge.cache_strategy(
                prompt_block, json.dumps(strategy),
                fix_type=context.fix_type, cwe_id=context.cwe_id,
                language=context.language, model_used=result.get("model"),
            )
        return strategy

    def _is_groq_mode(self) -> bool:
        """True when the active model is Groq (rate limits apply)."""
        return (
            self.local is not None
            and getattr(self.local, "_is_groq", False)
        )

    def _call_local(self, system: str, prompt: str) -> PatchResult:
        if not self.local:
            return PatchResult(success=False, error="Local model not available (mode=cloud)")
        result = self.local.generate(prompt=prompt, system=system)
        if result.get("error"):
            return PatchResult(success=False, model_used=result["model"], error=result["error"])
        # DEBUG: log raw model output to help diagnose extract_diff issues
        _raw = result["text"]
        import os as _os
        if _os.environ.get("ENZO_DEBUG_DIFF"):
            _dbg = _os.path.expanduser("~/.reachable/enzo_debug_diff.txt")
            open(_dbg, "w").write(_raw)
            print(f"  [debug] raw model output saved to {_dbg}")
        diff = extract_diff(_raw)
        if not diff or len(diff) < 10:
            return PatchResult(success=False, model_used=result["model"], error="Model produced empty or invalid diff")
        return PatchResult(success=True, diff=diff, files_modified=files_from_diff(diff), model_used=result["model"])

    def _call_cloud(self, system: str, prompt: str) -> PatchResult:
        """Send prompt (with source code) to Claude API for patch generation."""
        if not self.cloud:
            return PatchResult(success=False, error="Cloud model not configured")
        result = self.cloud.generate(prompt=prompt, system=system)
        if result.get("error"):
            return PatchResult(success=False, model_used=result["model"], error=result["error"])
        diff = extract_diff(result["text"])
        if not diff or len(diff) < 10:
            return PatchResult(
                success=False,
                model_used=result["model"],
                error="Cloud model produced empty or invalid diff",
            )
        return PatchResult(success=True, diff=diff, files_modified=files_from_diff(diff), model_used=result["model"])

    def _call_model(self, system: str, prompt: str) -> PatchResult:
        """Route to local or cloud based on config.mode."""
        if self.config.cloud_generates_code:
            return self._call_cloud(system, prompt)
        return self._call_local(system, prompt)

    def _call_model_raw(
        self,
        system: str,
        prompt: str,
        finding_id: str = "",
        file_path: str = "",
        line: int = 0,
        file_content: str = "",
    ):
        """Return (text, model_name, error). No diff extraction.

        When finding_id is provided, injects a request_id + HMAC signature
        into the system prompt and verifies the model echoed them back.
        request_id  -- random per call, detects timeouts/empty responses.
        signature   -- HMAC of (finding_id:file_path:line:file_hash).
                       file_hash ties signature to actual file state — replaying
                       a response from a prior run where the file differed will
                       fail even if finding_id/line are the same.
                       Reliable for local models; advisory for remote.
        """
        # Local models (qwen/ollama) often ignore the echo requirement.
        # Enable via config.verify_tokens; recommended for cloud only.
        use_tokens = bool(finding_id) and getattr(self.config, "verify_tokens", False)
        request_id = sig = ""
        if use_tokens:
            request_id, sig = make_request_token(finding_id, file_path, line, file_content)
            system = inject_tokens(system, request_id, sig)

        is_local = not (self.config.cloud_generates_code and self.cloud)
        if self.config.cloud_generates_code and self.cloud:
            r = self.cloud.generate(prompt=prompt, system=system)
        elif self.local:
            r = self.local.generate(prompt=prompt, system=system)
        else:
            return "", "none", "No model available"

        text  = r.get("text", "")
        model = r.get("model", "")
        err   = r.get("error")
        if err:
            return text, model, err

        if use_tokens:
            valid, text, reason = verify_tokens(text, request_id, sig, is_local=is_local)
            if not valid:
                logger.debug("Token verification failed: %s", reason)
                return "", model, f"Token verification failed: {reason}"

        return text, model, None

    def _patch_dependency(self, finding, context, repo_path, cloud_strategy, upgrade_safety, attempt, prior_error, prior_stage, error_hint):
        manifest_name, m_content, lock_name, l_content = _find_manifest(repo_path, context.build_system)
        if not manifest_name or not m_content:
            return PatchResult(success=False, error=f"Cannot find manifest for {context.build_system}")
        system, prompt = dependency_upgrade_prompt(
            package_name=finding.package_name or "", current_version=finding.package_version or "",
            fix_version=finding.fix_version or "", ecosystem=context.build_system,
            manifest_path=manifest_name, manifest_content=m_content,
            lockfile_path=lock_name, lockfile_content=l_content,
            cloud_strategy=cloud_strategy, upgrade_safety=upgrade_safety,
        )
        if attempt > 1 and prior_error:
            system, prompt = retry_prompt(
                original_prompt=prompt,
                error_message=prior_error,
                error_stage=prior_stage or "build",
                error_hint=error_hint,
            )
        result = self._call_model(system, prompt)
        result.strategy_used = "dependency_upgrade"
        if cloud_strategy:
            result.cloud_strategy = json.dumps(cloud_strategy)
        return result

    def _patch_code(self, finding, context, repo_path, cloud_strategy, upgrade_safety, attempt, prior_error, prior_stage, error_hint):
        if not finding.file_path:
            return PatchResult(success=False, error="No file path for code finding")

        rel_file_path = _rel_path(repo_path, finding.file_path)

        # Always read full file -- needed for _code_to_diff splice.
        full_file_content = _read_file(repo_path, finding.file_path)
        if not full_file_content:
            return PatchResult(success=False, error=f"Cannot read source: {finding.file_path}")

        # Code reducer: send focused slice to model (saves tokens).
        # Model returns plain corrected code; _code_to_diff splices it back.
        code_slice = reduce_for_finding(
            file_path=finding.file_path,
            repo_path=repo_path,
            line_number=finding.line_number or 1,
            language=context.language or None,
        )
        if code_slice:
            prompt_content = code_slice.to_prompt_block()
            _slice_start = code_slice.slice_line_start
            _slice_end   = code_slice.slice_line_end
            logger.info(
                "Code reducer: %s %.0f%% of file (%d→%d lines)",
                rel_file_path, code_slice.reduction_ratio * 100,
                code_slice.full_line_count,
                code_slice.slice_line_end - code_slice.slice_line_start + 1,
            )
        else:
            prompt_content = full_file_content
            _slice_start = 1
            _slice_end   = full_file_content.count(chr(10)) + 1
            logger.info("Code patch (full file): %s (%d lines)", rel_file_path, full_file_content.count(chr(10)))

        # -- Attempt 1: multi-candidate generation ----------------------
        if attempt == 1 and not prior_error:
            return self._patch_code_multicand(
                finding, context, repo_path,
                prompt_content=prompt_content,
                full_file_content=full_file_content,
                slice_start=_slice_start,
                slice_end=_slice_end,
                cloud_strategy=cloud_strategy,
                error_hint=error_hint,
                rel_file_path=rel_file_path,
            )

        # -- Retry: single patch with prior error context ---------------
        system, prompt = code_patch_prompt(
            cwe_id=finding.cwe_id or "unknown",
            file_path=rel_file_path,
            file_content=prompt_content,
            line_number=finding.line_number or 0,
            finding_description=finding.description or finding.title or "",
            call_path=finding.call_paths_v2,
            cloud_strategy=cloud_strategy,
            known_pattern=context.known_fix_pattern,
        )
        system, prompt = retry_prompt(
            original_prompt=prompt,
            error_message=prior_error,
            error_stage=prior_stage or "apply",
            error_hint=error_hint,
        )
        raw_text, model_name, err = self._call_model_raw(
            system, prompt,
            finding_id=finding.finding_id or "",
            file_path=rel_file_path,
            line=finding.line_number or 0,
            file_content=full_file_content,
        )
        if err:
            return PatchResult(success=False, model_used=model_name, error=err)
        corrected = _strip_code_fences(raw_text)
        if not corrected.strip():
            return PatchResult(success=False, model_used=model_name, error="Model returned empty output on retry")
        ok, diff_or_err = _code_to_diff(repo_path, rel_file_path, full_file_content, corrected, _slice_start, _slice_end)
        if not ok:
            return PatchResult(success=False, model_used=model_name, error=diff_or_err)
        result = PatchResult(success=True, diff=diff_or_err, files_modified=[rel_file_path], model_used=model_name)
        result.strategy_used = cloud_strategy.get("approach", "code_patch") if cloud_strategy else "code_patch"
        if cloud_strategy:
            result.cloud_strategy = json.dumps(cloud_strategy)
        return result

    def _patch_code_multicand(
        self, finding, context, repo_path, *,
        prompt_content: str,
        full_file_content: str,
        slice_start: int,
        slice_end: int,
        cloud_strategy,
        error_hint,
        rel_file_path: str = "",
    ) -> PatchResult:
        """
        Generate _CANDIDATES patches with different strategy biases.
        Model returns plain corrected code -> _strip_code_fences ->
        _code_to_diff (git diff --no-index) -> valid unified diff.
        """
        if not rel_file_path:
            rel_file_path = _rel_path(repo_path, finding.file_path or "")
        candidates: list[PatchResult] = []

        for i, strategy_hint in enumerate(_CANDIDATE_STRATEGIES):
            augmented_strategy = dict(cloud_strategy or {})
            augmented_strategy["approach"] = strategy_hint

            system, prompt = code_patch_prompt(
                cwe_id=finding.cwe_id or "unknown",
                file_path=rel_file_path,
                file_content=prompt_content,
                line_number=finding.line_number or 0,
                finding_description=finding.description or finding.title or "",
                call_path=finding.call_paths_v2,
                cloud_strategy=augmented_strategy if cloud_strategy else None,
                known_pattern=context.known_fix_pattern,
                strategy_hint=strategy_hint,
            )
            try:
                raw_text, model_name, err = self._call_model_raw(
                    system, prompt,
                    finding_id=finding.finding_id or "",
                    file_path=rel_file_path,
                    line=finding.line_number or 0,
                    file_content=full_file_content,
                )
            except Exception as _api_exc:
                from .local_model import GroqTPDExhausted
                if isinstance(_api_exc, GroqTPDExhausted):
                    secs = _api_exc.retry_after_seconds
                    msg = (
                        f"groq_tpd_exhausted: Daily token limit reached. "
                        f"Retry in {secs // 60}m {secs % 60}s."
                    )
                    fatal = PatchResult(success=False, error=msg)
                    fatal.candidates = candidates
                    return fatal
                raise
            if err:
                result = PatchResult(success=False, model_used=model_name, error=err)
            else:
                # Detect Groq output-token truncation before stripping/validating
                _finish = ""
                if hasattr(self, "_last_finish_reason"):
                    _finish = self._last_finish_reason
                corrected = _strip_code_fences(raw_text)
                if not corrected.strip():
                    result = PatchResult(success=False, model_used=model_name, error="Model returned empty output")
                else:
                    # Compare against prompt_content (the slice the model saw),
                    # not full_file_content — model output will match the slice,
                    # not the whole 750-line file.
                    _ok_out, _reason = _validate_code_output(
                        corrected, prompt_content, language=context.language or "")
                    if not _ok_out:
                        logger.warning("cand %d hallucination: %s", i + 1, _reason)
                        # If syntax error on first candidate, shrink slice for remaining candidates
                        if i == 0 and "syntax error" in _reason.lower() and len(prompt_content.splitlines()) > 60:
                            from .code_reducer import reduce_for_finding
                            _tight = reduce_for_finding(
                                file_path=finding.file_path,
                                repo_path=repo_path,
                                line_number=finding.line_number or 1,
                                language=context.language or None,
                            )
                            if _tight:
                                # Override to minimal window: just 30 lines around vuln line
                                from pathlib import Path as _P2
                                _all = (_P2(repo_path) / finding.file_path).read_text(errors="replace").splitlines()
                                _ln = finding.line_number or 1
                                _ws = max(0, _ln - 15)
                                _we = min(len(_all), _ln + 15)
                                _window = _all[_ws:_we]
                                _vuln_in_win = (_ln - 1) - _ws + 1
                                from .code_reducer import _annotate_vulnerable_line, _detect_language
                                _lang = _detect_language(finding.file_path)
                                _window = _annotate_vulnerable_line(_window, _vuln_in_win, _lang)
                                prompt_content = "\n".join(_window)
                                slice_start = _ws + 1
                                slice_end = _we
                                logger.info(
                                    "Syntax error on cand 1 — shrinking slice to %d-line window for cand %d+",
                                    len(_window), i + 2,
                                )
                        result = PatchResult(success=False, model_used=model_name,
                                            error=f"Model output rejected: {_reason}")
                    else:
                        ok, diff_or_err = _code_to_diff(
                            repo_path, rel_file_path, full_file_content,
                            corrected, slice_start, slice_end,
                        )
                        if ok:
                            result = PatchResult(success=True, diff=diff_or_err,
                                                files_modified=[rel_file_path], model_used=model_name)
                            _dbg(self.config, f"cand {i+1} ok")
                        else:
                            result = PatchResult(success=False, model_used=model_name, error=diff_or_err)
            result.strategy_used = strategy_hint
            if cloud_strategy:
                result.cloud_strategy = json.dumps(augmented_strategy)
            candidates.append(result)
            logger.debug(
                "Candidate %d/%d: success=%s strategy=%s",
                i + 1, len(_CANDIDATE_STRATEGIES), result.success, strategy_hint,
            )

            if not result.success and result.error and _is_fatal_candidate_error(result.error):
                logger.error("Fatal error during candidate generation: %s", result.error)
                fatal = PatchResult(success=False, error=result.error)
                fatal.candidates = candidates
                return fatal

            # Brief inter-candidate pause to avoid Groq 429 bursts
            if i < len(_CANDIDATE_STRATEGIES) - 1 and self._is_groq_mode():
                time.sleep(1.5)

        successful = [c for c in candidates if c.success]
        primary = successful[0] if successful else candidates[0]
        primary.candidates = candidates
        return primary

    def _patch_config(self, finding, context, repo_path, cloud_strategy, upgrade_safety, attempt, prior_error, prior_stage, error_hint):
        if not finding.file_path:
            return PatchResult(success=False, error="No file path for config finding")
        rel_file_path = _rel_path(repo_path, finding.file_path)
        file_content = _read_file(repo_path, finding.file_path)
        if not file_content:
            return PatchResult(success=False, error=f"Cannot read config: {finding.file_path}")
        system, prompt = config_fix_prompt(
            cwe_id=finding.cwe_id or "unknown", file_path=rel_file_path,
            file_content=file_content, line_number=finding.line_number or 0,
            finding_description=finding.description or finding.title or "",
            cloud_strategy=cloud_strategy,
        )
        if attempt > 1 and prior_error:
            system, prompt = retry_prompt(
                original_prompt=prompt,
                error_message=prior_error,
                error_stage=prior_stage or "apply",
                error_hint=error_hint,
            )
        raw_text, model_name, err = self._call_model_raw(system, prompt)
        if err:
            return PatchResult(success=False, model_used=model_name, error=err)
        corrected = _strip_code_fences(raw_text)
        if not corrected.strip():
            return PatchResult(success=False, model_used=model_name, error="Model returned empty output")
        ok, diff_or_err = _code_to_diff(repo_path, rel_file_path, file_content, corrected, 1, file_content.count(chr(10)) + 1)
        if not ok:
            return PatchResult(success=False, model_used=model_name, error=diff_or_err)
        result = PatchResult(success=True, diff=diff_or_err, files_modified=[rel_file_path], model_used=model_name)
        result.strategy_used = "config_change"
        return result

    def _patch_secret(self, finding, context, repo_path, cloud_strategy, upgrade_safety, attempt, prior_error, prior_stage, error_hint):
        if not finding.file_path:
            return PatchResult(success=False, error="No file path for secret finding")
        rel_file_path = _rel_path(repo_path, finding.file_path)
        file_content = _read_file(repo_path, finding.file_path)
        if not file_content:
            return PatchResult(success=False, error=f"Cannot read source: {finding.file_path}")
        system, prompt = secret_rotation_prompt(
            secret_type=finding.secret_type or "unknown", file_path=rel_file_path,
            file_content=file_content, line_number=finding.line_number or 0,
            cloud_strategy=cloud_strategy,
        )
        if attempt > 1 and prior_error:
            system, prompt = retry_prompt(
                original_prompt=prompt,
                error_message=prior_error,
                error_stage=prior_stage or "apply",
                error_hint=error_hint,
            )
        raw_text, model_name, err = self._call_model_raw(system, prompt)
        if err:
            return PatchResult(success=False, model_used=model_name, error=err)
        corrected = _strip_code_fences(raw_text)
        if not corrected.strip():
            return PatchResult(success=False, model_used=model_name, error="Model returned empty output")
        # Sanity check: model should return source code, not prose/JSON/pentest content
        _ok_out, _reason = _validate_code_output(
            corrected, file_content, language=context.language or "")
        if not _ok_out:
            logger.warning("secret_rotation hallucination: %s", _reason)
            return PatchResult(success=False, model_used=model_name,
                               error=f"Model output rejected: {_reason}")
        ok, diff_or_err = _code_to_diff(repo_path, rel_file_path, file_content, corrected, 1, file_content.count(chr(10)) + 1)
        if not ok:
            return PatchResult(success=False, model_used=model_name, error=diff_or_err)
        result = PatchResult(success=True, diff=diff_or_err, files_modified=[rel_file_path], model_used=model_name)
        result.strategy_used = "secret_rotation"
        return result

    def _patch_dlp(self, finding, context, repo_path, cloud_strategy, upgrade_safety, attempt, prior_error, prior_stage, error_hint):
        """
        DLP/PII remediation handler.

        Uses AI (never deterministic) because PII fixes require understanding
        data flow context: where the value came from, where it's going, and
        which masking approach is appropriate for that specific exposure.

        Metadata expected in finding (from reachable via semgrep/AST/tree-sitter):
          pii_type:    email | phone | ssn | credit_card | name | address |
                       dob | health | ip_address | password | token | custom
          pii_field:   variable/attribute path, e.g. "user.email"
          flow_type:   logging | storage | transmission | processing
          masking_apis: list of project-local masking functions (if detected)
        """
        if not finding.file_path:
            return PatchResult(success=False, error="No file path for DLP finding")

        file_path = Path(finding.file_path)
        rel_file_path = str(file_path.relative_to(repo_path)) if file_path.is_absolute() else str(file_path)
        if not file_path.exists():
            return PatchResult(success=False, error=f"File not found: {file_path}")

        file_content = file_path.read_text(encoding="utf-8", errors="replace")

        # Pull DLP metadata from finding — reachable populates these
        meta = getattr(finding, "finding_metadata", {}) or {}
        pii_type   = (getattr(finding, "pii_type", None)
                      or meta.get("pii_type", "custom"))
        pii_field  = (getattr(finding, "pii_field", None)
                      or meta.get("pii_field", "")
                      or _infer_pii_field(file_content, finding.line_number))
        flow_type  = (getattr(finding, "flow_type", None)
                      or meta.get("flow_type", "")
                      or _infer_flow_type(file_content, finding.line_number))
        masking_apis = (getattr(finding, "masking_apis", None)
                        or meta.get("masking_apis", []))

        # Code reducer — same as code_patch, slice around the exposure point
        from .code_reducer import CodeReducer
        reducer = CodeReducer()
        sliced = reducer.reduce(
            file_content=file_content,
            file_path=str(file_path),
            line_number=finding.line_number,
            language=context.language or _ext_to_lang(str(file_path)),
        )

        system, prompt = dlp_fix_prompt(
            file_path=rel_file_path,
            file_content=sliced or file_content,
            line_number=finding.line_number,
            pii_type=pii_type,
            pii_field=pii_field,
            flow_type=flow_type,
            finding_description=getattr(finding, "description", "") or f"PII exposure: {pii_type}",
            language=context.language or _ext_to_lang(str(file_path)),
            masking_apis=masking_apis or None,
            cloud_strategy=cloud_strategy,
            attempt_number=attempt,
            prior_error=prior_error,
        )

        result = self._call_model(system, prompt)
        if not result.success:
            return result

        corrected = result.diff  # raw model output before diff

        # Validate: must not still contain the raw PII exposure pattern
        ok_output, reason = _validate_code_output(
            corrected, sliced or file_content,
            language=context.language or "",
            finding_line=finding.line_number,
        )
        if not ok_output:
            result.success = False
            result.error = f"Model output rejected: {reason}"
            return result

        # Additional DLP-specific check: verify the original PII exposure is gone
        # (only if we have enough signal to check)
        if pii_field and flow_type:
            exposure_still_present = _check_dlp_exposure_remains(
                corrected, pii_field, flow_type, finding.line_number
            )
            if exposure_still_present:
                result.success = False
                result.error = f"DLP fix incomplete: {pii_field} still exposed in {flow_type} context"
                return result

        ok_diff, diff_or_err = _code_to_diff(
            repo_path, rel_file_path,
            file_content, corrected,
            1, file_content.count("\n") + 1,
        )
        if not ok_diff:
            return PatchResult(success=False, model_used=result.model_used, error=diff_or_err)

        out = PatchResult(
            success=True, diff=diff_or_err,
            files_modified=[rel_file_path],
            model_used=result.model_used,
        )
        out.strategy_used = f"dlp_patch:{flow_type}:{pii_type}"
        return out


# ── DLP helpers ───────────────────────────────────────────────────────────────

def _infer_pii_field(file_content: str, line_number: int) -> str:
    """
    Best-effort inference of the PII field name from the source line.
    Used when reachable doesn't populate pii_field.
    Returns empty string if inference fails — prompt still works without it.
    """
    import re
    lines = file_content.splitlines()
    if line_number < 1 or line_number > len(lines):
        return ""
    line = lines[line_number - 1]

    # Common PII attribute patterns: user.email, req.body.phone, self.ssn, etc.
    patterns = [
        r'\b\w+\.(email|phone|ssn|credit_card|card_number|password|token|'
         r'first_name|last_name|full_name|dob|date_of_birth|address|ip|'
         r'ip_address|health|diagnosis|medical)\b',
        r'\b(email|phone_number|ssn|credit_card|password|auth_token|'
         r'first_name|last_name|full_name|date_of_birth|street_address)\b',
    ]
    for pat in patterns:
        m = re.search(pat, line, re.IGNORECASE)
        if m:
            return m.group(0)
    return ""


def _infer_flow_type(file_content: str, line_number: int) -> str:
    """
    Infer flow type (logging/storage/transmission/processing) from source line.
    Used when reachable doesn't populate flow_type.
    """
    import re
    lines = file_content.splitlines()
    if line_number < 1 or line_number > len(lines):
        return "processing"
    line = lines[line_number - 1].lower()

    if re.search(r'\b(log|logger|logging|print|console\.log|fmt\.print|println)\b', line):
        return "logging"
    if re.search(r'\b(execute|query|insert|update|save|write|store|persist|db\.|conn\.)\b', line):
        return "storage"
    if re.search(r'\b(response|res\.json|res\.send|json\.dumps|render|return.*json|'
                 r'jsonify|marshal|serialize|header|redirect)\b', line):
        return "transmission"
    return "processing"


def _check_dlp_exposure_remains(
    corrected: str,
    pii_field: str,
    flow_type: str,
    line_number: int,
) -> bool:
    """
    Check whether the PII field still appears in a dangerous context
    in the corrected code around the original line.

    Returns True if the exposure appears to remain (fix incomplete).
    Only used as a soft signal — false negatives acceptable, false positives
    cause unnecessary retries so we keep the check conservative.
    """
    import re

    lines = corrected.splitlines()
    # Check a window of ±3 lines around the original finding line
    start = max(0, line_number - 4)
    end   = min(len(lines), line_number + 3)
    window = "\n".join(lines[start:end])

    # Build a regex for the raw field access
    field_re = re.escape(pii_field.split(".")[-1])  # "email" from "user.email"

    if flow_type == "logging":
        # If the field still appears in a log call without masking, flag it
        log_re = (r'\b(?:log|logger|logging|print|console\.log|fmt\.print)\s*'
                  r'[\.(].*\b' + field_re + r'\b')
        if re.search(log_re, window, re.IGNORECASE):
            # But allow it if a masking call wraps it
            mask_re = r'\b(?:mask|redact|hash|anonymize|sanitize)[\w_]*\s*\('
            if not re.search(mask_re, window, re.IGNORECASE):
                return True

    elif flow_type == "transmission":
        # If the field still appears directly in a response/return without masking
        resp_re = (r'\b(?:json|response|res\.json|res\.send|return|jsonify|render)\b'
                   r'.*\b' + field_re + r'\b')
        if re.search(resp_re, window, re.IGNORECASE | re.DOTALL):
            mask_re = r'\b(?:mask|redact|hash|anonymize|sanitize)[\w_]*\s*\(|(?:slice|substr|replace)\s*\('
            if not re.search(mask_re, window, re.IGNORECASE):
                return True

    # storage and processing: harder to check without semantic analysis, skip
    return False


def _ext_to_lang(file_path: str) -> str:
    """Map file extension to language string."""
    ext = file_path.rsplit(".", 1)[-1].lower() if "." in file_path else ""
    return {
        "py": "python", "go": "go", "ts": "typescript", "tsx": "typescript",
        "js": "javascript", "jsx": "javascript", "java": "java",
        "rb": "ruby", "cs": "csharp", "cpp": "cpp", "c": "c",
    }.get(ext, ext)
