#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.
"""
Prompt templates for each fix type.

Each function returns (system_prompt, user_prompt) for the local model.
The local model sees FULL source code — these prompts include file contents.
"""

from __future__ import annotations

import hashlib
import hmac
import os
import uuid
from typing import Dict, List, Optional

# Secret used for per-finding HMAC signatures.
# Loaded once from env; falls back to a process-local random value.
# Remote models get the same challenge but cannot be forced to sign correctly.
_SIGNING_SECRET = os.environb.get(b"ENZO_SIGNING_SECRET") or os.urandom(32)


def make_request_token(
    finding_id: str,
    file_path: str,
    line: int,
    file_content: str = "",
) -> tuple[str, str]:
    """Return (request_id, signature).

    request_id  -- random UUID hex, unique per call. Model must echo it.
                   Detects: timeouts, empty responses, cached non-responses.

    signature   -- HMAC-SHA256(finding_id:file_path:line:file_hash).
                   file_hash = SHA256[:16] of the actual file content at
                   the time of the call. Ties the signature to the file
                   state, not just the finding identity.
                   Detects: cross-contamination, AND replay of a response
                   from a prior run where the file was in a different state.
                   Only reliable for local models (remote cannot be forced
                   to compute your HMAC).
    """
    request_id = uuid.uuid4().hex[:12]
    file_hash = hashlib.sha256(file_content.encode()).hexdigest()[:16] if file_content else ""
    payload = f"{finding_id}:{file_path}:{line}:{file_hash}".encode()
    signature = hmac.new(_SIGNING_SECRET, payload, hashlib.sha256).hexdigest()[:16]
    return request_id, signature


def inject_tokens(system: str, request_id: str, signature: str) -> str:
    """Append token echo requirement to the system prompt."""
    token_line = f"ENZO:{request_id}:{signature}"
    instruction = (
        "\n\nREQUIRED: The very first line of your response must be exactly:\n"
        + token_line
        + "\n(Copy it verbatim. Then a blank line. Then your code.)"
    )
    return system + instruction


def verify_tokens(
    text: str,
    request_id: str,
    signature: str,
    is_local: bool = True,
) -> tuple[bool, str, str]:
    """Verify token echo and strip the token line from output.

    Returns (valid, stripped_text, reason).
    For remote models, only request_id is checked (signature is advisory).
    """
    lines = text.strip().splitlines()
    if not lines:
        return False, text, "empty output"
    first = lines[0].strip()
    expected = f"ENZO:{request_id}:{signature}"
    rest = "\n".join(lines[1:]).lstrip("\n")

    if first == expected:
        return True, rest, ""

    # Partial: request_id present but signature wrong
    if first.startswith(f"ENZO:{request_id}:"):
        if is_local:
            return False, text, f"signature mismatch (cross-contamination?): {first!r}"
        # Remote: request_id match sufficient
        return True, rest, ""

    # Token missing entirely — model ignored the instruction
    return False, text, f"ENZO token missing (first line: {first[:80]!r})"




def dependency_upgrade_prompt(
    *,
    package_name: str,
    current_version: str,
    fix_version: str,
    ecosystem: str,
    manifest_path: str,
    manifest_content: str,
    lockfile_path: Optional[str] = None,
    lockfile_content: Optional[str] = None,
    cloud_strategy: Optional[Dict] = None,
    upgrade_safety: Optional[Dict] = None,
) -> tuple[str, str]:
    """Generate prompt for dependency version bump."""

    system = (
        "You are a dependency upgrade assistant. Generate a minimal, correct patch "
        "to upgrade a vulnerable dependency to a safe version.\n\n"
        "Output ONLY a unified diff (--- a/... +++ b/...) that can be applied with `git apply`.\n"
        "Do not include any explanation, just the diff.\n"
        "Only modify the version specifier — do not change any other dependencies."
    )

    user_parts = [
        f"Upgrade {package_name} from {current_version} to {fix_version} ({ecosystem})",
        f"\n--- Manifest file: {manifest_path} ---\n{manifest_content}",
    ]

    if lockfile_path and lockfile_content:
        user_parts.append(f"\n--- Lockfile: {lockfile_path} ---\n{lockfile_content[:5000]}")

    if cloud_strategy:
        # Constraint only — no narrative
        edge = cloud_strategy.get("edge_cases", [])
        if edge:
            user_parts.append(f"\nConstraint: avoid {', '.join(edge)}")

    if upgrade_safety:
        rate = upgrade_safety.get("build_success_rate")
        if rate is not None:
            user_parts.append(f"Historical: {rate:.0%} build success for this upgrade across repos")
        issues = upgrade_safety.get("known_issues", [])
        if issues:
            user_parts.append(f"Known issues: {'; '.join(issues[:3])}")

    return system, "\n".join(user_parts)


def code_patch_prompt(
    *,
    cwe_id: str,
    file_path: str,
    file_content: str,
    line_number: int,
    finding_description: str,
    call_path: Optional[List[Dict]] = None,
    cloud_strategy: Optional[Dict] = None,
    known_pattern: Optional[str] = None,
    strategy_hint: Optional[str] = None
) -> tuple[str, str]:
    """Generate prompt for SAST/CWE code fix."""

    system = (
        "You are a security code remediation assistant. Fix the vulnerability "
        "indicated in the source code.\n\n"
        "Output ONLY the corrected source code. No explanations, no diffs, no markdown fences.\n"
        "The input shows line numbers as '  104 | code' -- do NOT include these in your output.\n"
        "Return the same code block you were shown, with only the security fix applied.\n"
        "Preserve all indentation, logic, and comments exactly.\n"
        "Your output will be diffed against the original automatically -- just return the code."
    )

    user_parts = [
        f"Fix {cwe_id}: {finding_description}",
        f"File: {file_path} (line {line_number})",
        f"\n--- Source: {file_path} ---\n{file_content}",
    ]

    if call_path:
        # call_path may be nested [[{node}, ...], ...] or flat [{node}, ...]
        nodes = call_path
        if nodes and isinstance(nodes[0], list):
            nodes = nodes[0]  # use first path
        path_str = " → ".join(n.get("label", "?") for n in nodes if isinstance(n, dict))
        if path_str:
            user_parts.append(f"\nCall path: {path_str}")

    if cloud_strategy:
        # Feed constraints not narrative — model is a transformer not a policy reader
        approach = cloud_strategy.get("approach", "")
        if approach:
            user_parts.append(f"\nConstraint: {approach}")
        safe = cloud_strategy.get("safe_apis", [])
        if safe:
            user_parts.append(f"Use: {', '.join(safe)}")
        unsafe = cloud_strategy.get("unsafe_patterns", [])
        if unsafe:
            user_parts.append(f"Avoid: {', '.join(unsafe)}")

    if strategy_hint:
        user_parts.append(f"\nFix strategy: {strategy_hint}")

    if known_pattern:
        user_parts.append(f"\nHistorically successful approach: {known_pattern}")

    return system, "\n".join(user_parts)


def config_fix_prompt(
    *,
    cwe_id: str,
    file_path: str,
    file_content: str,
    line_number: int,
    finding_description: str,
    cloud_strategy: Optional[Dict] = None,
) -> tuple[str, str]:
    """Generate prompt for config/infrastructure fix."""

    system = (
        "You are a security configuration editor. Fix the misconfiguration indicated below.\n\n"
        "Output ONLY the corrected file content. No diffs, no markdown fences, no explanations.\n"
        "Preserve all existing non-security configuration exactly.\n"
        "Your output will be diffed against the original automatically -- just return the fixed file."
    )

    user_parts = [
        f"Fix {cwe_id}: {finding_description}",
        f"File: {file_path} (line {line_number})",
        f"\n--- Config: {file_path} ---\n{file_content}",
    ]

    if cloud_strategy:
        user_parts.append(f"\nRecommended: {cloud_strategy.get('description', '')}")

    return system, "\n".join(user_parts)


def secret_rotation_prompt(
    *,
    secret_type: str,
    file_path: str,
    file_content: str,
    line_number: int,
    cloud_strategy: Optional[Dict] = None,
) -> tuple[str, str]:
    """Generate prompt for hardcoded secret remediation."""

    system = (
        "You are a source code transformer. Replace the hardcoded secret with an env var reference.\n\n"
        "CRITICAL: Output ONLY the transformed file content. No prose, no steps, no explanations,\n"
        "no markdown, no diffs, no introductory sentences. JUST THE FILE CONTENT.\n\n"
        "Transformation rules:\n"
        "  Python: os.environ.get('VAR_NAME', 'REACHABLE_SECRET_CHANGE_ME')\n"
        "  JS/TS:  process.env.VAR_NAME || 'REACHABLE_SECRET_CHANGE_ME'\n"
        "  YAML/docker-compose: ${VAR_NAME:-REACHABLE_SECRET_CHANGE_ME}\n"
        "  Shell/env file: VAR_NAME=${VAR_NAME:-REACHABLE_SECRET_CHANGE_ME}\n\n"
        "Use a descriptive env var name from context. Remove the original secret value.\n"
        "Preserve all other content exactly. Your output will be diffed automatically."
    )

    user_parts = [
        f"Constraint: replace hardcoded {secret_type} at line {line_number} with env var + placeholder.",
        f"File: {file_path}",
        f"\n--- Source: {file_path} ---\n{file_content}",
    ]

    return system, "\n".join(user_parts)


def retry_prompt(
    *,
    original_prompt: str,
    error_message: str,
    error_stage: str,
    error_hint: Optional[str] = None,
) -> tuple[str, str]:
    """Wrap a failed attempt with error context for retry."""

    system = (
        "Your previous attempt failed during validation. "
        "Analyse the error carefully and return a corrected version.\n\n"
        "Output ONLY the corrected source code. No diffs, no markdown fences, no line-number prefixes.\n"
        "Your output will be diffed against the original automatically."
    )


    user_parts = [
        original_prompt,
        "\n--- PREVIOUS ATTEMPT FAILED ---",
        f"Stage: {error_stage}",
        f"Error:\n{error_message[:2000]}",
    ]

    if error_hint:
        user_parts.append(f"\nKnown resolution for this error class: {error_hint}")

    return system, "\n".join(user_parts)


# ── DLP / PII remediation prompts ─────────────────────────────────────────────

def dlp_fix_prompt(
    *,
    file_path: str,
    file_content: str,
    line_number: int,
    pii_type: str,
    pii_field: str,
    flow_type: str,
    finding_description: str,
    language: str,
    masking_apis: Optional[List[str]] = None,
    cloud_strategy: Optional[Dict] = None,
    attempt_number: int = 1,
    prior_error: Optional[str] = None,
) -> tuple[str, str]:
    """
    Generate prompt for DLP/PII remediation.

    flow_type controls which surgery pattern the model applies:
      "logging"      — PII appears in a log statement
      "storage"      — PII written to DB / file / cache without masking
      "transmission" — PII in API response / HTTP header / URL parameter
      "processing"   — PII used in computation without need for raw value

    pii_type: email | phone | ssn | credit_card | name | address | dob |
              health | ip_address | user_id | password | token | custom
    pii_field: the variable/attribute name containing PII (e.g. "user.email")
    """
    # Language-specific masking patterns as concrete examples
    lang_examples = _dlp_language_examples(language, pii_type, pii_field, masking_apis)

    system = (
        "You are a privacy-aware security engineer performing PII remediation.\n\n"
        "Your task: modify the code so the identified PII field is no longer "
        "exposed in the specified context (log/storage/transmission/processing).\n\n"
        "Output ONLY the corrected source code. No explanations, no diffs, no markdown fences.\n"
        "Preserve all existing logic, indentation, and comments exactly.\n\n"
        "RULES:\n"
        "1. Do NOT remove the PII field from the data model or function signature.\n"
        "2. Do NOT break existing functionality — only change how the PII is handled "
        "at the specific exposure point.\n"
        "3. Prefer the project's existing masking/redaction utilities if visible in the code.\n"
        "4. If no masking utility exists, use a minimal inline implementation.\n"
        "5. The fix must be targeted — change as few lines as possible.\n"
        "6. Do NOT add import statements unless strictly necessary for the fix.\n\n"
        f"Masking approach for {flow_type} exposure:\n"
        f"{lang_examples}"
    )

    user_parts = [
        f"PII exposure: {pii_type} ({pii_field}) in {flow_type} context",
        f"File: {file_path} (line {line_number})",
        f"Finding: {finding_description}",
        f"\n--- Source: {file_path} ---\n{file_content}",
    ]

    if cloud_strategy:
        approach = cloud_strategy.get("approach", "")
        safe = cloud_strategy.get("safe_apis", [])
        if approach:
            user_parts.append(f"\nApproach: {approach}")
        if safe:
            user_parts.append(f"Use: {', '.join(safe)}")

    if attempt_number > 1 and prior_error:
        user_parts.append(
            f"\n--- PREVIOUS ATTEMPT FAILED ---\n"
            f"Error: {prior_error[:1000]}\n"
            f"Analyse the error and correct your approach."
        )

    return system, "\n".join(user_parts)


def _dlp_language_examples(
    language: str,
    pii_type: str,
    pii_field: str,
    masking_apis: Optional[List[str]] = None,
) -> str:
    """
    Return concrete, language-specific masking examples for the prompt.
    Concrete examples dramatically outperform abstract instructions.
    """
    field = pii_field or "user.email"
    short = field.split(".")[-1]  # "email" from "user.email"

    # If the project already has masking APIs, prefer them
    if masking_apis:
        api_list = ", ".join(masking_apis[:3])
        return f"Use the project's existing masking utilities: {api_list}\n"

    lang = language.lower()

    if lang == "python":
        if pii_type in ("email", "custom"):
            return (
                f"Logging:      logger.info('user=%s', _mask_email({field}))\n"
                f"              def _mask_email(v): p=v.split('@'); return p[0][:2]+'***@'+p[-1] if '@' in v else '***'\n"
                f"Storage:      db.execute(q, (_mask_email({field}),))\n"
                f"Response:     data['{short}'] = _mask_email({field})\n"
            )
        elif pii_type in ("phone",):
            return (
                f"Logging:      logger.info('phone=%s', {field}[-4:].rjust(10,'*'))\n"
                f"Storage:      db.execute(q, ({field}[-4:].rjust(len({field}),'*'),))\n"
            )
        elif pii_type in ("ssn", "credit_card"):
            return (
                f"Logging:      logger.info('{short}=***-**-%s', {field}[-4:])\n"
                f"Storage:      db.execute(q, ('***-**-'+{field}[-4:],))\n"
                f"Transmission: resp['{short}'] = '***-**-' + {field}[-4:]\n"
            )
        elif pii_type in ("password", "token"):
            return (
                f"Logging:      # Never log passwords/tokens — omit the field entirely\n"
                f"              logger.info('auth=<redacted>')  # do not include {field}\n"
                f"Transmission: resp.pop('{short}', None)  # strip from response dict\n"
            )
        else:
            return (
                f"Logging:      logger.info('{short}=<redacted>')  # omit {field}\n"
                f"Storage:      # hash or mask {field} before persisting\n"
                f"              import hashlib\n"
                f"              _hashed = hashlib.sha256({field}.encode()).hexdigest()[:16]\n"
            )

    elif lang in ("typescript", "javascript"):
        if pii_type in ("email", "custom"):
            return (
                f"Logging:      console.log('user=' + {field}.replace(/(.).*@/, '$1***@'))\n"
                f"Response:     res.json({{ ...user, {short}: {field}.replace(/(.).*@/, '$1***@') }})\n"
                f"Storage:      await db.query(q, [{field}.replace(/(.).*@/, '$1***@')])\n"
            )
        elif pii_type in ("password", "token"):
            return (
                f"Logging:      // Never include {field} in logs\n"
                f"              console.log({{ ...data, {short}: '[REDACTED]' }})\n"
                f"Response:     const {{ {short}, ...safeUser }} = user; res.json(safeUser)\n"
            )
        elif pii_type in ("ssn", "credit_card"):
            return (
                f"Logging:      console.log('{short}=***-**-' + {field}.slice(-4))\n"
                f"Response:     res.json({{ ...data, {short}: '***-**-' + {field}.slice(-4) }})\n"
            )
        else:
            return (
                f"Logging:      // Omit or redact {field}\n"
                f"Response:     const {{ {short}: _omitted, ...safe }} = payload; res.json(safe)\n"
            )

    elif lang == "go":
        if pii_type in ("email", "custom"):
            return (
                f"Logging:      log.Printf('user=%s', maskEmail({field}))\n"
                f"              func maskEmail(e string) string {{ ... }}\n"
                f"Response:     resp.{short.title()} = maskEmail({field})\n"
            )
        elif pii_type in ("password", "token"):
            return (
                f"Logging:      log.Printf('auth=<redacted>')  // never log {field}\n"
                f"Response:     resp.{short.title()} = \"\"  // strip from response struct\n"
            )
        else:
            return (
                f"Logging:      log.Printf('{short}=<redacted>')  // omit {field}\n"
            )

    elif lang == "java":
        if pii_type in ("email", "custom"):
            return (
                f"Logging:      log.info('user={{}}', maskEmail({field}))\n"
                f"              private String maskEmail(String e) {{ ... }}\n"
                f"Response:     user.set{short.title()}(maskEmail({field}))\n"
            )
        elif pii_type in ("password", "token"):
            return (
                f"Logging:      log.info('auth=<redacted>')  // never log {field}\n"
                f"Response:     userDto.set{short.title()}(null)  // strip from DTO\n"
            )
        else:
            return (
                f"Logging:      log.info('{short}=<redacted>')  // omit {field}\n"
            )

    # Generic fallback
    return (
        f"Mask or redact {field} at the point of {pii_type} exposure.\n"
        f"Prefer the project's existing utility functions for masking.\n"
        f"If none exist, use a minimal inline implementation that preserves "
        f"the last 4 characters and replaces the rest with asterisks.\n"
    )
