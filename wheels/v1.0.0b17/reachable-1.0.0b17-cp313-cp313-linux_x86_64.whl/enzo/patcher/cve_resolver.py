#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.
"""
CveResolver — version constraint algebra for multi-CVE dependency findings.

Reads the `cve_group` block from a finding's raw_data (populated by reachable
once R-1 ships) and computes a single resolved fix version.

Falls back gracefully when cve_group is absent: uses the top-level
`fix_version` field directly.

Resolution algorithm:
  1. Clean (80–90% of cases)
     Collect all >=X lower-bound constraints.
     resolved = max(fix_versions).
     If no upper-bound conflicts exist → clean fix.

  2. Conflict (rare: mutually incompatible constraints, e.g. >=3.0 vs <3.0)
     Call AI with structured prompt → parse JSON recommendation.
     Action: upgrade | pin | replace | accept.

  3. No-fix (one or more CVEs have no upstream fix)
     Emit REACHABLE_NO_FIX_UNAVAILABLE annotation comment.
     Mark finding as `manual`.

Resolution result:

  @dataclass ResolvedDependency:
    package:            str
    ecosystem:          str
    installed_version:  str
    resolved_fix:       str | None
    resolution_status:  "clean" | "conflict" | "no_fix" | "partial" | "fallback"
    action:             "upgrade" | "pin" | "replace" | "accept" | "manual"
    annotation:         str | None   # comment to insert above dep line
    conflict_reason:    str | None
    ai_rationale:       str | None
    cve_ids:            list[str]
"""
from __future__ import annotations

import json
import logging
import re
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple

logger = logging.getLogger(__name__)

# ── Result dataclass ──────────────────────────────────────────────────────

@dataclass
class ResolvedDependency:
    package:           str
    ecosystem:         str
    installed_version: str
    resolved_fix:      Optional[str]
    resolution_status: str          # clean | conflict | no_fix | partial | fallback
    action:            str          # upgrade | pin | replace | accept | manual
    annotation:        Optional[str] = None
    conflict_reason:   Optional[str] = None
    ai_rationale:      Optional[str] = None
    cve_ids:           List[str] = field(default_factory=list)

    @property
    def is_actionable(self) -> bool:
        return self.action in ("upgrade", "pin")

    @property
    def needs_human(self) -> bool:
        return self.action in ("replace", "manual")


# ── Public API ────────────────────────────────────────────────────────────

class CveResolver:
    """
    Resolves multi-CVE conflicts for a single package dependency.

    model_caller: optional callable(system: str, prompt: str) -> str
                  Must return the model's raw text response.
                  When None, AI fallback is disabled — conflicts stay as
                  `conflict` status with action `manual`.
    """

    def __init__(self, model_caller=None):
        self._call = model_caller

    # ── Entry points ──────────────────────────────────────────────────────

    def from_finding(self, finding) -> ResolvedDependency:
        """
        Resolve from a repo.db finding object.

        Reads cve_group from raw_data when available (R-1).
        Falls back to top-level fix_version field.
        """
        raw = {}
        if hasattr(finding, "raw_data") and finding.raw_data:
            try:
                raw = (json.loads(finding.raw_data)
                       if isinstance(finding.raw_data, str)
                       else finding.raw_data)
            except Exception:
                pass

        cve_group = raw.get("cve_group") if raw else None

        if cve_group:
            return self.resolve_group(cve_group)

        # Fallback: single fix_version from finding
        return ResolvedDependency(
            package=getattr(finding, "package_name", "") or "",
            ecosystem=getattr(finding, "ecosystem", "") or "",
            installed_version=getattr(finding, "package_version", "") or "",
            resolved_fix=getattr(finding, "fix_version", None),
            resolution_status="fallback",
            action="upgrade" if getattr(finding, "fix_version", None) else "manual",
            cve_ids=([getattr(finding, "cve_id", "")] if getattr(finding, "cve_id", "") else []),
        )

    def resolve_group(self, cve_group: Dict[str, Any]) -> ResolvedDependency:
        """
        Resolve from a cve_group dict (as defined in the integration spec §2.3).
        """
        package   = cve_group.get("package", "")
        ecosystem = cve_group.get("ecosystem", "")
        installed = cve_group.get("installed_version", "")
        cves      = cve_group.get("cves") or []

        # Use pre-computed status when reachable has already done the algebra
        precomputed_status = cve_group.get("resolution_status")
        if precomputed_status in ("clean", "partial") and cve_group.get("resolved_fix"):
            return self._build_from_precomputed(cve_group)

        # Otherwise compute ourselves
        return self._compute_resolution(package, ecosystem, installed, cves)

    # ── Core algorithm ────────────────────────────────────────────────────

    def _compute_resolution(
        self,
        package:   str,
        ecosystem: str,
        installed: str,
        cves:      List[Dict],
    ) -> ResolvedDependency:

        if not cves:
            return ResolvedDependency(
                package=package, ecosystem=ecosystem, installed_version=installed,
                resolved_fix=None, resolution_status="no_fix", action="manual",
            )

        all_ids = [c.get("id", "") for c in cves]

        # Separate CVEs with/without fix
        fixable   = [c for c in cves if not c.get("no_fix") and c.get("fix_version")]
        unfixable = [c for c in cves if c.get("no_fix") or not c.get("fix_version")]

        if unfixable and not fixable:
            annotation = _no_fix_annotation(package, installed, all_ids)
            return ResolvedDependency(
                package=package, ecosystem=ecosystem, installed_version=installed,
                resolved_fix=None, resolution_status="no_fix", action="manual",
                annotation=annotation, cve_ids=all_ids,
            )

        # Compute greatest lower bound from fixable constraints
        fix_versions  = [c["fix_version"] for c in fixable]
        operators     = {c["fix_version"]: c.get("operator", ">=") for c in fixable}
        resolved, conflict_info = _greatest_lower_bound(fix_versions, operators, installed)

        if conflict_info:
            # Genuine conflict — try AI, else manual
            result = self._resolve_conflict_ai(
                package, ecosystem, installed, cves, conflict_info
            )
            if unfixable:
                result.resolution_status = "partial"
                partial_ann = _partial_annotation(
                    package, [c.get("id","") for c in unfixable]
                )
                result.annotation = (result.annotation or "") + "\n" + partial_ann
            return result

        # Clean (or partial with unfixable subset)
        status = "partial" if unfixable else "clean"
        annotation = None
        if unfixable:
            annotation = _partial_annotation(
                package, [c.get("id","") for c in unfixable]
            )

        return ResolvedDependency(
            package=package, ecosystem=ecosystem, installed_version=installed,
            resolved_fix=resolved, resolution_status=status, action="upgrade",
            annotation=annotation, cve_ids=all_ids,
        )

    # ── AI conflict fallback ──────────────────────────────────────────────

    def _resolve_conflict_ai(
        self,
        package:       str,
        ecosystem:     str,
        installed:     str,
        cves:          List[Dict],
        conflict_info: str,
    ) -> ResolvedDependency:

        all_ids = [c.get("id", "") for c in cves]

        if self._call is None:
            logger.warning("cve_resolver: AI fallback unavailable, marking manual: %s", package)
            return ResolvedDependency(
                package=package, ecosystem=ecosystem, installed_version=installed,
                resolved_fix=None, resolution_status="conflict", action="manual",
                conflict_reason=conflict_info, cve_ids=all_ids,
            )

        system = (
            "You are a dependency security engineer. "
            "Analyse the version conflict and output ONLY a JSON object with keys: "
            '{"recommendation": str, "action": "upgrade|pin|replace|accept", '
            '"version": "X.Y.Z or null", "rationale": str}. '
            "No other text, no markdown fences."
        )

        cve_lines = "\n".join(
            f"  {c.get('id','?')}: fix requires {c.get('operator','>=')} "
            f"{c.get('fix_version','?')}  (CVSS {c.get('cvss','?')})"
            for c in cves
        )

        prompt = (
            f"Package: {package} ({ecosystem})\n"
            f"Installed: {installed}\n"
            f"Conflict:\n{cve_lines}\n"
            f"Conflict reason: {conflict_info}\n\n"
            "Recommend: upgrade to a specific version, pin with comment, "
            "replace with an alternative package, or accept risk with documented rationale."
        )

        try:
            raw = self._call(system, prompt)
            rec = _parse_ai_recommendation(raw)
        except Exception as e:
            logger.error("cve_resolver: AI call failed: %s", e)
            return ResolvedDependency(
                package=package, ecosystem=ecosystem, installed_version=installed,
                resolved_fix=None, resolution_status="conflict", action="manual",
                conflict_reason=conflict_info, cve_ids=all_ids,
            )

        action   = rec.get("action", "manual")
        version  = rec.get("version")
        rationale = rec.get("rationale", "")

        annotation = None
        if action == "pin":
            annotation = (
                f"# REACHABLE_REVIEW_REQUIRED: {package} version conflict\n"
                f"# {rationale}"
            )
        elif action == "replace":
            annotation = (
                f"# REACHABLE_REPLACE_PACKAGE: {package}\n"
                f"# {rationale}"
            )

        return ResolvedDependency(
            package=package, ecosystem=ecosystem, installed_version=installed,
            resolved_fix=version, resolution_status="conflict",
            action=action if action in ("upgrade","pin","replace","accept") else "manual",
            annotation=annotation, conflict_reason=conflict_info,
            ai_rationale=rationale, cve_ids=all_ids,
        )

    # ── Helpers ───────────────────────────────────────────────────────────

    def _build_from_precomputed(self, cve_group: Dict) -> ResolvedDependency:
        all_ids = [c.get("id","") for c in (cve_group.get("cves") or [])]
        return ResolvedDependency(
            package=cve_group.get("package",""),
            ecosystem=cve_group.get("ecosystem",""),
            installed_version=cve_group.get("installed_version",""),
            resolved_fix=cve_group.get("resolved_fix"),
            resolution_status=cve_group.get("resolution_status","clean"),
            action="upgrade",
            cve_ids=all_ids,
        )


# ── Version algebra ───────────────────────────────────────────────────────

def _greatest_lower_bound(
    fix_versions: List[str],
    operators: Dict[str, str],
    installed: str,
) -> Tuple[Optional[str], Optional[str]]:
    """
    Compute the greatest lower bound from a list of fix version constraints.

    Returns (resolved_version, conflict_info_or_None).
    conflict_info is set when upper-bound constraints make resolution impossible.
    """
    if not fix_versions:
        return None, "no fix versions available"

    # Sort descending; pick max as the lower bound
    try:
        from packaging.version import Version
        versions_parsed = [(Version(v), v) for v in fix_versions]
        versions_parsed.sort(reverse=True)
        resolved_parsed, resolved_str = versions_parsed[0]
    except Exception:
        # packaging unavailable — lexicographic fallback
        fix_sorted = sorted(fix_versions, reverse=True)
        resolved_str = fix_sorted[0]
        resolved_parsed = None

    # Check for upper-bound conflicts
    for ver_str, op in operators.items():
        if op.startswith("<") and resolved_parsed is not None:
            try:
                from packaging.version import Version
                bound = Version(ver_str)
                if resolved_parsed >= bound:
                    return None, (
                        f"constraint '{op}{ver_str}' conflicts with "
                        f"resolved fix >= {resolved_str}"
                    )
            except Exception:
                pass

    return resolved_str, None


# ── Annotation builders ───────────────────────────────────────────────────

def _no_fix_annotation(package: str, version: str, cve_ids: List[str]) -> str:
    ids_str = ", ".join(cve_ids) if cve_ids else "unknown"
    return (
        f"# REACHABLE_NO_FIX_UNAVAILABLE: {package}=={version}\n"
        f"# CVE(s): {ids_str}  |  No upstream fix available\n"
        f"# Recommended: evaluate replacement or document accepted risk\n"
        f"# See: https://osv.dev/list?q={cve_ids[0] if cve_ids else package}"
    )


def _partial_annotation(package: str, unfixable_ids: List[str]) -> str:
    ids_str = ", ".join(unfixable_ids)
    return (
        f"# REACHABLE_PARTIAL_FIX: {package}\n"
        f"# No fix for: {ids_str}  |  upgrade applied for other CVEs\n"
        f"# Manual review required for unfixed vulnerabilities"
    )


def _parse_ai_recommendation(raw: str) -> Dict[str, Any]:
    """Parse AI JSON recommendation, stripping markdown fences if present."""
    text = raw.strip()
    # Strip markdown fences
    text = re.sub(r"^```(?:json)?\s*", "", text, flags=re.MULTILINE)
    text = re.sub(r"\s*```\s*$", "", text, flags=re.MULTILINE)
    text = text.strip()

    try:
        return json.loads(text)
    except json.JSONDecodeError:
        # Best-effort extraction
        m = re.search(r'"action"\s*:\s*"(\w+)"', text)
        action = m.group(1) if m else "manual"
        m = re.search(r'"version"\s*:\s*"([\d.]+)"', text)
        version = m.group(1) if m else None
        m = re.search(r'"rationale"\s*:\s*"([^"]+)"', text)
        rationale = m.group(1) if m else "AI response unparseable"
        return {"action": action, "version": version, "rationale": rationale}
