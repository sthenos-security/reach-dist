#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.
"""
Enzo Metrics Engine — surfaces pipeline performance data from enzo.db.

Queries: remediation_attempts, benchmark_runs, benchmark_results.
Output: formatted terminal block + optional JSON.

Usage:
    reachctl enzo metrics [--since Nd|YYYY-MM-DD] [--json]
"""
from __future__ import annotations

import json
import logging
import sqlite3
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Dict, Optional

logger = logging.getLogger(__name__)


@dataclass
class MetricsSummary:
    """Aggregated metrics for a time window."""
    period_days: int = 0
    period_label: str = ""
    runs: int = 0
    findings_processed: int = 0
    attempted: int = 0
    succeeded: int = 0
    failed: int = 0
    manual: int = 0
    deterministic_count: int = 0
    ai_count: int = 0
    total_tokens_in: int = 0
    total_tokens_out: int = 0
    total_cost_usd: float = 0.0
    total_duration_ms: int = 0
    # Per fix type
    by_fix_type: Dict[str, Dict] = field(default_factory=dict)
    # Per language (from benchmark_results if available)
    by_language: Dict[str, Dict] = field(default_factory=dict)
    # Hallucination stats (from hallucinations.jsonl)
    hallucination_total: int = 0
    candidate_total: int = 0
    hallucination_recovered: int = 0
    # Comparison to previous period
    prev_fix_rate: Optional[float] = None
    prev_halluc_rate: Optional[float] = None
    prev_cost_per_fix: Optional[float] = None
    prev_avg_attempts: Optional[float] = None

    @property
    def fix_rate(self) -> float:
        return self.succeeded / self.attempted if self.attempted else 0.0

    @property
    def hallucination_rate(self) -> float:
        return self.hallucination_total / self.candidate_total if self.candidate_total else 0.0

    @property
    def avg_cost_per_fix(self) -> float:
        return self.total_cost_usd / self.succeeded if self.succeeded else 0.0

    @property
    def avg_duration_s(self) -> float:
        return (self.total_duration_ms / self.attempted / 1000) if self.attempted else 0.0


def collect(db_path: str, since_days: int = 30,
            hallucinations_jsonl: str = None) -> MetricsSummary:
    """
    Query enzo.db and return a MetricsSummary for the given window.
    """
    m = MetricsSummary(period_days=since_days,
                       period_label=f"last {since_days} days")
    if not Path(db_path).exists():
        logger.debug("enzo.db not found: %s", db_path)
        return m

    cutoff = (datetime.now(timezone.utc) - timedelta(days=since_days)).isoformat()
    con = sqlite3.connect(db_path)
    con.row_factory = sqlite3.Row

    # ── Pipeline-level metrics ────────────────────────────────────────────────
    row = con.execute("""
        SELECT COUNT(DISTINCT scan_id) as runs,
               COUNT(*) as attempted,
               SUM(CASE WHEN status='success' THEN 1 ELSE 0 END) as succeeded,
               SUM(CASE WHEN status='failed'  THEN 1 ELSE 0 END) as failed,
               SUM(CASE WHEN status='manual'  THEN 1 ELSE 0 END) as manual
        FROM remediation_attempts
        WHERE created_at >= ?
    """, (cutoff,)).fetchone()
    if row:
        m.runs       = row["runs"] or 0
        m.attempted  = row["attempted"] or 0
        m.succeeded  = row["succeeded"] or 0
        m.failed     = row["failed"] or 0
        m.manual     = row["manual"] or 0

    # ── Cost + timing (from attestation JSON if stored) ───────────────────────
    # tokens/cost are in attestation JSON blob for now; extract what we can
    rows = con.execute("""
        SELECT attestation FROM remediation_attempts
        WHERE status='success' AND attestation IS NOT NULL AND created_at >= ?
    """, (cutoff,)).fetchall()
    for r in rows:
        try:
            att = json.loads(r["attestation"])
            m.total_tokens_in  += att.get("tokens_in", 0) or 0
            m.total_tokens_out += att.get("tokens_out", 0) or 0
            m.total_cost_usd   += att.get("cost_usd", 0.0) or 0.0
            m.total_duration_ms += att.get("duration_ms", 0) or 0
            method = att.get("patcher_method", "ai")
            if method == "deterministic":
                m.deterministic_count += 1
            else:
                m.ai_count += 1
        except Exception:
            pass

    # ── Per fix type breakdown ────────────────────────────────────────────────
    rows = con.execute("""
        SELECT fix_type,
               COUNT(*) as total,
               SUM(CASE WHEN status='success' THEN 1 ELSE 0 END) as succeeded,
               AVG(attempt_number) as avg_attempts
        FROM remediation_attempts
        WHERE created_at >= ?
        GROUP BY fix_type
    """, (cutoff,)).fetchall()
    for r in rows:
        ft = r["fix_type"] or "unknown"
        total = r["total"] or 0
        succ = r["succeeded"] or 0
        m.by_fix_type[ft] = {
            "total": total,
            "succeeded": succ,
            "rate": succ / total if total else 0.0,
            "avg_attempts": round(r["avg_attempts"] or 1.0, 1),
        }

    # ── Hallucination data (from .reachable/hallucinations.jsonl) ────────────
    if hallucinations_jsonl and Path(hallucinations_jsonl).exists():
        entries = []
        with open(hallucinations_jsonl) as f:
            for line in f:
                try:
                    entries.append(json.loads(line.strip()))
                except Exception:
                    pass
        # Filter to window
        for e in entries:
            ts = e.get("ts", "")
            if ts >= cutoff:
                m.hallucination_total += 1
                if e.get("attempt", 1) < 3:
                    m.candidate_total += 1

    # ── Benchmark data for language breakdown ─────────────────────────────────
    try:
        rows = con.execute("""
            SELECT language,
                   COUNT(*) as total,
                   SUM(CASE WHEN success=1 THEN 1 ELSE 0 END) as succeeded
            FROM benchmark_results
            GROUP BY language
        """).fetchall()
        for r in rows:
            lang = r["language"] or "unknown"
            total = r["total"] or 0
            succ = r["succeeded"] or 0
            m.by_language[lang] = {
                "total": total,
                "succeeded": succ,
                "rate": succ / total if total else 0.0,
            }
    except sqlite3.OperationalError:
        pass  # benchmark_results table may not exist yet

    # ── Previous period comparison ────────────────────────────────────────────
    prev_cutoff = (datetime.now(timezone.utc) - timedelta(days=since_days * 2)).isoformat()
    prev_row = con.execute("""
        SELECT COUNT(*) as attempted,
               SUM(CASE WHEN status='success' THEN 1 ELSE 0 END) as succeeded,
               AVG(attempt_number) as avg_attempts
        FROM remediation_attempts
        WHERE created_at >= ? AND created_at < ?
    """, (prev_cutoff, cutoff)).fetchone()
    if prev_row and prev_row["attempted"]:
        m.prev_fix_rate = (prev_row["succeeded"] or 0) / prev_row["attempted"]
        m.prev_avg_attempts = round(prev_row["avg_attempts"] or 1.0, 2)

    con.close()
    return m


def format_metrics(m: MetricsSummary, repo_name: str = "") -> str:
    """Format MetricsSummary as a terminal-friendly block."""
    W = 50
    label = f"{repo_name}  ·  " if repo_name else ""
    lines = [
        f"{'━'*W}",
        f"ENZO METRICS  ·  {label}{m.period_label}",
        f"{'━'*W}",
    ]

    if m.attempted == 0:
        lines.append("  No pipeline runs found in this period.")
        lines.append(f"{'━'*W}")
        return "\n".join(lines)

    lines += [
        f"  Pipeline runs:       {m.runs}",
        f"  Findings processed:  {m.attempted}",
        f"  Fix rate:            {m.fix_rate*100:.1f}%  ({m.succeeded}/{m.attempted})",
    ]
    if m.manual:
        lines.append(f"  Manual required:     {m.manual}")

    lines.append("")
    lines.append("  Patcher split:")
    if m.deterministic_count:
        lines.append(f"    Deterministic:  {m.deterministic_count} fixes  ·  $0.00  ·  ~0s")
    if m.ai_count:
        ai_cost = m.total_cost_usd
        ai_dur  = m.total_duration_ms / 1000
        lines.append(f"    AI:             {m.ai_count} fixes  ·  ${ai_cost:.4f}  ·  {ai_dur:.1f}s")
    if m.total_cost_usd:
        cpf = m.avg_cost_per_fix
        lines.append(f"    Total cost:     ${m.total_cost_usd:.4f}  ·  avg ${cpf:.4f}/fix")

    if m.by_fix_type:
        lines.append("")
        lines.append("  By fix type:")
        for ft, d in sorted(m.by_fix_type.items()):
            rate = f"{d['rate']*100:.1f}%"
            atts = f"avg {d['avg_attempts']} attempts"
            lines.append(f"    {ft:<22} {rate:<8} {atts}")

    if m.by_language:
        lines.append("")
        lines.append("  By language (benchmark):")
        pairs = sorted(m.by_language.items(), key=lambda x: -x[1]['rate'])
        row = []
        for lang, d in pairs:
            row.append(f"{lang}: {d['rate']*100:.1f}%")
        # print two per line
        for i in range(0, len(row), 2):
            pair = row[i:i+2]
            lines.append("    " + "   ".join(f"{p:<22}" for p in pair))

    if m.hallucination_total or m.candidate_total:
        lines.append("")
        lines.append("  Hallucinations:")
        lines.append(f"    Total (attempt 1):  {m.hallucination_total}"
                     f"  ({m.hallucination_rate*100:.1f}% of candidates)")
        if m.hallucination_recovered:
            lines.append(f"    Recovered on retry: {m.hallucination_recovered}")

    if m.avg_duration_s:
        lines.append("")
        lines.append(f"  Avg time/fix:  {m.avg_duration_s:.1f}s")

    # Trends
    trends = []
    if m.prev_fix_rate is not None:
        delta = (m.fix_rate - m.prev_fix_rate) * 100
        arrow = "↑" if delta > 0 else "↓" if delta < 0 else "→"
        trends.append(f"    Fix rate:      {arrow} {abs(delta):.1f}pp  "
                      f"({m.prev_fix_rate*100:.1f}% → {m.fix_rate*100:.1f}%)")
    if trends:
        lines.append("")
        lines.append(f"  vs previous {m.period_days} days:")
        lines.extend(trends)

    lines.append(f"{'━'*W}")
    return "\n".join(lines)


# ── Compatibility aliases for CLI (0.6.0) ─────────────────────────────────────

def parse_since(since_str: str) -> int:
    """Parse '30d', '7d', 'YYYY-MM-DD' → days int."""
    s = since_str.strip()
    if s.endswith("d"):
        return int(s[:-1])
    # Date string: compute delta from today
    return (__import__("datetime").date.today() - __import__("datetime").date.fromisoformat(s)).days


class MetricsCollector:
    """Thin wrapper around collect() for CLI compatibility."""

    def __init__(self, enzo_db_path: str, repo_path: str = ""):
        self.db_path = enzo_db_path
        self.repo_path = repo_path

    def collect_days(self, days: int) -> MetricsSummary:
        hall_jsonl = str(Path(self.repo_path) / ".reachable" / "hallucinations.jsonl") \
                     if self.repo_path else None
        m = collect(self.db_path, since_days=days, hallucinations_jsonl=hall_jsonl)
        m.repo_name = Path(self.repo_path).name if self.repo_path else ""
        return m
