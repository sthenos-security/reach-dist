#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.
"""
Gap analysis engine.

Compares ExternalFinding objects (from third-party tools) against findings
stored in reachable's repo.db.  Produces a GapReport with TWO distinct
buckets: ACTIONABLE and RAW.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  BUCKET DEFINITIONS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

  ACTIONABLE — findings that require a decision (fix, accept, or escalate):
    • REACHABLE  — call graph confirmed an executable path to the vulnerable
                   code.  These are high-confidence, must act.
    • UNKNOWN    — reachable could not establish reachability (e.g. dynamic
                   dispatch, reflection, missing call graph coverage, or the
                   scanner didn't emit enough context).  Severity is kept as-is
                   and a human review flag is set.  Better safe than sorry.

  RAW — everything including UNREACHABLE:
    + UNREACHABLE — call graph proved no executable path exists.  These
                    inflate external tool counts but do NOT need fixing.
                    Their presence in RAW explains why external tools look
                    noisier than reachable.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  FALSE POSITIVES / FALSE NEGATIVES
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

  False positives from noisy external tools:
    Appear in RAW  → external tool flagged, reachable says UNREACHABLE.
    Absent from ACTIONABLE → filtered out because call graph disproves reach.
    The delta (raw_noise_count) shows how much signal/noise a given tool has.

  False negatives in external tools (reachable found it, tool missed it):
    Appear in BOTH buckets as "reachable-only" findings.

  False negatives in reachable (external found it, reachable missed it):
    Appear in BOTH buckets as "external-only" findings.
    These are genuine scanner coverage gaps to investigate.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Usage:
    from enzo.gap import GapAnalyser

    analyser = GapAnalyser(db_path=".reachable/scans/myrepo/repo.db")
    analyser.load_reachable_findings()
    analyser.add_external(external_findings)
    report = analyser.analyse()
    print(report.to_markdown())
"""
from __future__ import annotations

import datetime
import logging
import sqlite3
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Optional

from .ingest.models import ExternalFinding

logger = logging.getLogger(__name__)


# ── Reachability constants ────────────────────────────────────────────────

REACHABLE   = "REACHABLE"
UNREACHABLE = "UNREACHABLE"
UNKNOWN     = "UNKNOWN"

# Findings in these states go into the ACTIONABLE bucket.
ACTIONABLE_STATES = {REACHABLE, UNKNOWN}

_UNKNOWN_EXPLANATION = (
    "**What UNKNOWN means:** Reachable could not establish whether an executable "
    "path to this code exists. Causes include dynamic dispatch, reflection, "
    "incomplete call graph coverage, or the scanner not emitting enough context. "
    "Severity is preserved unchanged. These findings require human review — "
    "treat them as potentially exploitable until proven otherwise."
)


# ── Data structures ───────────────────────────────────────────────────────

@dataclass
class ReachableFinding:
    finding_id:       str
    finding_type:     str
    severity:         str
    package_name:     Optional[str] = None
    package_version:  Optional[str] = None
    fix_version:      Optional[str] = None
    cve_id:           Optional[str] = None
    cwe_id:           Optional[str] = None
    file_path:        Optional[str] = None
    line_number:      Optional[int] = None
    app_reachability: str = UNKNOWN
    description:      str = ""
    fix_status:       str = "fix_available"
    ecosystem:        Optional[str] = None

    @property
    def is_actionable(self) -> bool:
        return self.app_reachability in ACTIONABLE_STATES

    @property
    def needs_human_reachability_review(self) -> bool:
        return self.app_reachability == UNKNOWN


@dataclass
class MatchResult:
    external:   ExternalFinding
    reachable:  Optional[ReachableFinding]
    confidence: float = 0.0
    method:     str   = "none"


# ── Section item: external + reachable pair with annotation ──────────────

@dataclass
class GapItem:
    external:   ExternalFinding
    reachable:  ReachableFinding
    note:       str = ""    # human-readable annotation for this specific item


# ── Bucket ────────────────────────────────────────────────────────────────

@dataclass
class GapBucket:
    """
    One analysis bucket (ACTIONABLE or RAW).

    Sections mirror the integration spec §6.4 but with reachability
    state explicitly carried through every item.
    """
    name: str   # "actionable" | "raw"

    # External found + reachable matched
    auto_fixed:                  List[GapItem]            = field(default_factory=list)
    confirmed_open:              List[GapItem]            = field(default_factory=list)  # REACHABLE
    unknown_open:                List[GapItem]            = field(default_factory=list)  # UNKNOWN → human review
    severity_disagreements:      List[GapItem]            = field(default_factory=list)
    noise:                       List[GapItem]            = field(default_factory=list)  # RAW only: UNREACHABLE matches

    # Unmatched
    reachable_only:              List[ReachableFinding]   = field(default_factory=list)
    external_only:               List[ExternalFinding]    = field(default_factory=list)

    @property
    def total_actionable_open(self) -> int:
        return len(self.confirmed_open) + len(self.unknown_open)

    @property
    def total_matched(self) -> int:
        return (len(self.auto_fixed) + len(self.confirmed_open) +
                len(self.unknown_open) + len(self.severity_disagreements) +
                len(self.noise))

    @property
    def noise_count(self) -> int:
        return len(self.noise)


# ── Gap report ────────────────────────────────────────────────────────────

@dataclass
class GapReport:
    generated_at: str = field(default_factory=lambda: datetime.datetime.now(datetime.timezone.utc).isoformat().replace("+00:00", "Z"))
    tool_names:   List[str] = field(default_factory=list)

    actionable: GapBucket = field(default_factory=lambda: GapBucket("actionable"))
    raw:        GapBucket = field(default_factory=lambda: GapBucket("raw"))

    def to_markdown(self) -> str:
        lines = [
            "# Reachable Gap Analysis Report",
            "",
            f"**Generated:** {self.generated_at}  ",
            f"**External tools:** {', '.join(self.tool_names) or 'none'}  ",
            "",
        ]

        # ── Noise summary banner ──────────────────────────────────────────
        raw_noise = self.raw.noise_count
        if raw_noise > 0:
            actionable_open = self.actionable.total_actionable_open
            pct = int(100 * raw_noise / max(1, self.raw.total_matched + len(self.raw.external_only)))
            lines += [
                f"> **Tool noise summary:** External tools produced {raw_noise} finding(s) "
                f"that reachable's call graph determined UNREACHABLE (~{pct}% noise rate). "
                f"These appear in the Raw section but are excluded from Actionable. "
                f"{actionable_open} open finding(s) require action.",
                "",
            ]

        lines += _render_bucket(self.actionable, is_actionable=True)
        lines += ["---", ""]
        lines += _render_bucket(self.raw, is_actionable=False)

        return "\n".join(lines)


# ── Markdown rendering helpers ────────────────────────────────────────────

def _render_bucket(bucket: GapBucket, is_actionable: bool) -> List[str]:
    label = "## 🎯 ACTIONABLE" if is_actionable else "## 📋 RAW (full picture)"
    desc = (
        "Findings that require a decision. REACHABLE = confirmed executable path. "
        "UNKNOWN = could not establish reachability — kept in scope, human review required."
    ) if is_actionable else (
        "All findings including UNREACHABLE. Use this to assess tool noise and "
        "scanner coverage gaps. False positives from external tools appear here as noise."
    )

    has_unknown = any(
        item.reachable.app_reachability == UNKNOWN
        for section in [bucket.confirmed_open, bucket.unknown_open,
                        bucket.severity_disagreements, bucket.auto_fixed]
        for item in section
    )

    lines = [label, "", desc, ""]

    if is_actionable and has_unknown:
        lines += [f"> ℹ️  {_UNKNOWN_EXPLANATION}", ""]

    # Auto-fixed
    if bucket.auto_fixed:
        lines += [
            f"### ✅ Auto-fixed by Enzo ({len(bucket.auto_fixed)})",
            "",
            "External tool open; Enzo applied a patch.",
            "",
        ]
        for item in bucket.auto_fixed:
            r = item.reachable
            reach_badge = _reach_badge(r.app_reachability)
            lines.append(
                f"- {reach_badge} **{item.external.primary_cve or item.external.title}** — "
                f"{item.external.tool}: {item.external.severity} | "
                f"reachable: {r.severity} | {r.app_reachability}"
            )
        lines.append("")

    # Confirmed open (REACHABLE)
    if bucket.confirmed_open:
        lines += [
            f"### 🔴 Confirmed Open — REACHABLE ({len(bucket.confirmed_open)})",
            "",
            "Both tools agree. Call graph confirms an executable path. Highest priority.",
            "",
        ]
        for item in bucket.confirmed_open:
            r = item.reachable
            vid = item.external.primary_cve or item.external.primary_cwe or item.external.title
            lines.append(
                f"- 🟢 **{vid}** — {item.external.tool}: {item.external.severity} | "
                f"reachable: {r.severity} | fix: {r.fix_version or 'none'}"
            )
        lines.append("")

    # Unknown open — human review
    if bucket.unknown_open:
        lines += [
            f"### 🟡 Open — UNKNOWN reachability ({len(bucket.unknown_open)}) — Human review required",
            "",
            "Both tools agree this finding exists. Reachable could not determine "
            "whether an executable path exists. Severity is unchanged. "
            "Treat as potentially exploitable until a human confirms otherwise.",
            "",
        ]
        for item in bucket.unknown_open:
            r = item.reachable
            vid = item.external.primary_cve or item.external.primary_cwe or item.external.title
            lines.append(
                f"- ⚪ **{vid}** — {item.external.tool}: {item.external.severity} | "
                f"reachable: {r.severity} | ⚠ reachability unconfirmed"
            )
        lines.append("")

    # Severity disagreements
    if bucket.severity_disagreements:
        lines += [
            f"### ⚠️ Severity Disagreements ({len(bucket.severity_disagreements)})",
            "",
            "Both tools found this finding but rated it differently. "
            "Reachability context explains why reachable's rating may differ.",
            "",
            "| Finding | Tool | External Sev | Reachable Sev | Reachability | Note |",
            "|---------|------|-------------|---------------|--------------|------|",
        ]
        for item in bucket.severity_disagreements:
            r = item.reachable
            vid = item.external.primary_cve or item.external.title or item.external.rule_id or "?"
            note = item.note or _severity_note(item.external.severity, r.severity, r.app_reachability)
            lines.append(
                f"| {vid} | {item.external.tool} | {item.external.severity} | "
                f"{r.severity} | {r.app_reachability} | {note} |"
            )
        lines.append("")

    # Noise (RAW only)
    if bucket.noise:
        lines += [
            f"### 🔇 Tool Noise — UNREACHABLE ({len(bucket.noise)})",
            "",
            "External tool flagged these findings. Reachable's call graph determined "
            "no executable path exists. These are likely false positives from the "
            "external tool. They are **excluded from the Actionable bucket**.",
            "",
        ]
        for item in bucket.noise:
            r = item.reachable
            vid = item.external.primary_cve or item.external.title or "?"
            lines.append(
                f"- ⛔ **{vid}** — {item.external.tool}: {item.external.severity} | "
                f"reachable: UNREACHABLE (call graph disproves reach)"
            )
        lines.append("")

    # External-only
    if bucket.external_only:
        lines += [
            f"### 🔎 External-Only ({len(bucket.external_only)}) — Potential reachable scanner gap",
            "",
            "Found by external tool, not in reachable scan results. May indicate "
            "a scanner coverage gap in reachable, an out-of-scope dependency, "
            "or a false positive from the external tool.",
            "",
        ]
        for ext in bucket.external_only:
            vid = ext.primary_cve or ext.title or "?"
            loc = ext.package_name or ext.file_path or "?"
            lines.append(
                f"- **{vid}** — {ext.tool}: {ext.severity} | {loc}"
            )
        lines.append("")

    # Reachable-only
    if bucket.reachable_only:
        label_reach = (
            "🔵 Reachable-Only — Actionable, external tool missed"
            if is_actionable else
            "🔵 Reachable-Only (all states)"
        )
        lines += [
            f"### {label_reach} ({len(bucket.reachable_only)})",
            "",
            "Found by reachable, not flagged by any ingested external tool. "
            "These are false negatives in the external tools. "
            + ("Reachability context confirms their relevance." if is_actionable else ""),
            "",
        ]
        for r in bucket.reachable_only:
            reach_badge = _reach_badge(r.app_reachability)
            vid = r.cve_id or r.cwe_id or r.finding_id[:8]
            loc = r.package_name or r.file_path or "?"
            human_flag = " ⚠ human review" if r.app_reachability == UNKNOWN else ""
            lines.append(
                f"- {reach_badge} **{vid}** — {r.severity} | "
                f"{r.app_reachability}{human_flag} | {loc}"
            )
        lines.append("")

    if not any([bucket.auto_fixed, bucket.confirmed_open, bucket.unknown_open,
                bucket.severity_disagreements, bucket.noise,
                bucket.external_only, bucket.reachable_only]):
        lines += ["*No findings in this bucket.*", ""]

    return lines


def _reach_badge(state: str) -> str:
    return {"REACHABLE": "🟢", "UNKNOWN": "⚪", "UNREACHABLE": "⛔"}.get(state, "⚪")


def _severity_note(ext_sev: str, reach_sev: str, reachability: str) -> str:
    """Generate a short note explaining a severity disagreement."""
    _order = {"CRITICAL": 4, "HIGH": 3, "MEDIUM": 2, "LOW": 1, "INFO": 0}
    ext_n   = _order.get(ext_sev, 2)
    reach_n = _order.get(reach_sev, 2)
    if reachability == REACHABLE and reach_n > ext_n:
        return "reachable upgraded: confirmed executable path"
    if reachability == UNREACHABLE and reach_n < ext_n:
        return "reachable downgraded: call graph disproves reach"
    if reachability == UNKNOWN:
        return "reachability unknown — use reachable severity conservatively"
    if reach_n > ext_n:
        return "reachable higher — review"
    return "external tool higher — review"


# ── Gap analyser ──────────────────────────────────────────────────────────

class GapAnalyser:
    """
    Matches external findings against reachable findings and populates
    both ACTIONABLE and RAW buckets in a GapReport.
    """

    def __init__(self, db_path: Optional[str] = None):
        self._db_path = db_path
        self._reachable: List[ReachableFinding] = []
        self._external:  List[ExternalFinding]  = []
        self._enzo_fixed: Dict[str, bool] = {}

    # ── Data loading ──────────────────────────────────────────────────────

    def load_reachable_findings(self) -> int:
        if not self._db_path:
            raise ValueError("db_path required to load from database")
        conn = None
        try:
            conn = sqlite3.connect(self._db_path)
            conn.row_factory = sqlite3.Row
            rows = conn.execute("""
                SELECT finding_id, finding_type, severity,
                       package_name, package_version, fix_version,
                       cve_id, cwe_id, file_path, line_number,
                       app_reachability, description, fix_status, ecosystem
                FROM findings
            """).fetchall()
        except (sqlite3.OperationalError, sqlite3.DatabaseError) as e:
            logger.error("gap_analyser: failed to read repo.db: %s", e)
            return 0
        finally:
            if conn:
                conn.close()

        self._reachable = [
            ReachableFinding(
                finding_id       = r["finding_id"],
                finding_type     = r["finding_type"] or "",
                severity         = r["severity"] or "MEDIUM",
                package_name     = r["package_name"],
                package_version  = r["package_version"],
                fix_version      = r["fix_version"],
                cve_id           = r["cve_id"],
                cwe_id           = r["cwe_id"],
                file_path        = r["file_path"],
                line_number      = r["line_number"],
                app_reachability = r["app_reachability"] or UNKNOWN,
                description      = r["description"] or "",
                fix_status       = r["fix_status"] or "fix_available",
                ecosystem        = r["ecosystem"],
            )
            for r in rows
        ]
        logger.info("gap_analyser: loaded %d reachable findings", len(self._reachable))
        return len(self._reachable)

    def set_reachable_findings(self, findings: List[ReachableFinding]) -> None:
        self._reachable = list(findings)

    def add_external(self, findings: List[ExternalFinding]) -> None:
        self._external.extend(findings)

    def set_enzo_fixed(self, fixed_ids: List[str]) -> None:
        self._enzo_fixed = {fid: True for fid in fixed_ids}

    # ── Analysis ──────────────────────────────────────────────────────────

    def analyse(self) -> GapReport:
        report = GapReport(
            tool_names=sorted({f.tool for f in self._external})
        )

        matches = [self._match(ext) for ext in self._external]
        matched_reachable_ids: set = set()

        for m in matches:
            ext   = m.external
            reach = m.reachable

            if reach is None:
                # No match in reachable — external-only in both buckets
                report.actionable.external_only.append(ext)
                report.raw.external_only.append(ext)
                continue

            matched_reachable_ids.add(reach.finding_id)
            ext.reachable_finding_id = reach.finding_id
            ext.match_confidence     = m.confidence
            ext.match_method         = m.method

            enzo_fixed = self._enzo_fixed.get(reach.finding_id, False)

            # ── RAW bucket: all states ────────────────────────────────────
            _classify_into(report.raw, ext, reach, enzo_fixed)

            # ── ACTIONABLE bucket: REACHABLE + UNKNOWN only ───────────────
            if reach.is_actionable:
                _classify_into(report.actionable, ext, reach, enzo_fixed)
            # else UNREACHABLE: appears only in raw.noise (handled inside _classify_into)

        # Reachable-only: unmatched
        for reach in self._reachable:
            if reach.finding_id not in matched_reachable_ids:
                report.raw.reachable_only.append(reach)
                if reach.is_actionable:
                    report.actionable.reachable_only.append(reach)

        return report

    # ── Matching ──────────────────────────────────────────────────────────

    def _match(self, ext: ExternalFinding) -> MatchResult:
        best: Optional[MatchResult] = None
        for reach in self._reachable:
            r = self._score(ext, reach)
            if r.confidence > (best.confidence if best else 0):
                best = r
        return best or MatchResult(external=ext, reachable=None)

    def _score(self, ext: ExternalFinding, reach: ReachableFinding) -> MatchResult:
        # 1. Exact CVE / alias match
        if ext.cve_ids and reach.cve_id:
            if _normalise_vuln_id(reach.cve_id) in {_normalise_vuln_id(i) for i in ext.cve_ids}:
                return MatchResult(ext, reach, 1.0, "exact_cve")

        # 2. Same package + installed version
        if (ext.package_name and reach.package_name and
                ext.package_name.lower() == reach.package_name.lower()):
            if (ext.package_version and reach.package_version and
                    ext.package_version == reach.package_version):
                return MatchResult(ext, reach, 0.9, "package_version")
            return MatchResult(ext, reach, 0.5, "package_name_only")

        # 3. CWE + file + line proximity
        if (ext.cwe_ids and reach.cwe_id and
                _normalise_cwe(reach.cwe_id) in {_normalise_cwe(c) for c in ext.cwe_ids}):
            if (ext.file_path and reach.file_path and
                    _paths_match(ext.file_path, reach.file_path)):
                if ext.line_number and reach.line_number:
                    if abs(ext.line_number - reach.line_number) <= 5:
                        return MatchResult(ext, reach, 0.8, "cwe_file_line")
                    # Both known but too far apart — not a match
                else:
                    return MatchResult(ext, reach, 0.6, "cwe_file")

        return MatchResult(ext, reach, 0.0, "none")


# ── Classification helper (shared by both buckets) ────────────────────────

def _classify_into(
    bucket: GapBucket,
    ext: ExternalFinding,
    reach: ReachableFinding,
    enzo_fixed: bool,
) -> None:
    """Place a matched (ext, reach) pair into the correct bucket section."""

    # UNREACHABLE in an actionable-bucket call should never reach here
    # (caller checks reach.is_actionable before calling for actionable bucket).
    # In the raw bucket, UNREACHABLE matches go to noise.
    if reach.app_reachability == UNREACHABLE:
        bucket.noise.append(GapItem(external=ext, reachable=reach))
        return

    if enzo_fixed:
        bucket.auto_fixed.append(GapItem(external=ext, reachable=reach))
        return

    sev_match = (ext.severity == reach.severity)

    if not sev_match:
        note = _severity_note(ext.severity, reach.severity, reach.app_reachability)
        bucket.severity_disagreements.append(
            GapItem(external=ext, reachable=reach, note=note)
        )
        # Also put in the appropriate open bucket so severity context is visible
        # (disagreement doesn't mean it doesn't need action)

    if reach.app_reachability == REACHABLE:
        bucket.confirmed_open.append(GapItem(external=ext, reachable=reach))
    else:
        # UNKNOWN
        bucket.unknown_open.append(GapItem(
            external=ext, reachable=reach,
            note="reachability unconfirmed — human review required"
        ))


# ── Utilities ─────────────────────────────────────────────────────────────

def _normalise_vuln_id(vid: str) -> str:
    return vid.upper().strip()

def _normalise_cwe(cwe: str) -> str:
    import re
    m = re.search(r"\d+", cwe)
    return f"CWE-{int(m.group(0))}" if m else cwe.upper()

def _paths_match(a: str, b: str) -> bool:
    a = a.replace("\\", "/").lstrip("/")
    b = b.replace("\\", "/").lstrip("/")
    if a == b: return True
    if b.endswith(a) or a.endswith(b): return True
    return Path(a).name == Path(b).name
