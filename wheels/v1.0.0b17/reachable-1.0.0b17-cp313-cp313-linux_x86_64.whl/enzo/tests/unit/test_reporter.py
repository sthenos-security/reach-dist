#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.
"""
Tests for enzo/reporter/ — ReportConfig, ReportResult, _load_findings,
_enzo_summary, _load_attempts, _render_risk_report, _render_grc_report,
generate_risk_report, generate_grc_report, generate_executive_summary,
frameworks, hasher, and the CLI report subcommand.
"""
from __future__ import annotations

import argparse
import os
import sqlite3
import sys
import tempfile
import unittest
from datetime import datetime, timezone
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from enzo.reporter.frameworks import (
    FRAMEWORK_NAMES,
    all_controls_for_findings,
    describe_control,
    get_controls,
    resolve_framework,
)
from enzo.reporter.hasher import hash_db, write_manifest
from enzo.reporter.report import (
    ReportConfig,
    ReportResult,
    _enzo_summary,
    _load_attempts,
    _load_findings,
    _render_risk_report,
    _safe_finding,
    _summarise_findings,
    generate_executive_summary,
    generate_grc_report,
    generate_risk_report,
)

_NOW = datetime.now(timezone.utc).isoformat()

_FINDINGS_SCHEMA = """
CREATE TABLE IF NOT EXISTS findings (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    finding_id TEXT, scan_id INTEGER DEFAULT 1,
    finding_type TEXT DEFAULT 'cwe', severity TEXT DEFAULT 'HIGH',
    reachability_state TEXT DEFAULT 'REACHABLE',
    cwe_id TEXT DEFAULT 'CWE-89', cve_id TEXT,
    file_path TEXT DEFAULT 'app.py', line_number INTEGER DEFAULT 10,
    description TEXT DEFAULT 'test finding', title TEXT DEFAULT 'SQL Injection',
    package_name TEXT, package_version TEXT,
    fix_type TEXT DEFAULT 'code_patch', fix_status TEXT DEFAULT 'fix_available'
);
"""

_ATTEMPTS_SCHEMA = """
CREATE TABLE IF NOT EXISTS remediation_attempts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    finding_id TEXT, scan_id INTEGER DEFAULT 1,
    fix_type TEXT DEFAULT 'code_patch', status TEXT DEFAULT 'success',
    attempt_number INTEGER DEFAULT 1, patcher_method TEXT DEFAULT 'ai',
    cost_usd REAL DEFAULT 0.01, completed_at TEXT,
    attestation TEXT, patch_diff TEXT, created_at TEXT
);
"""


def _make_repo_db(findings=None):
    fd, path = tempfile.mkstemp(suffix=".db")
    os.close(fd)
    con = sqlite3.connect(path)
    con.executescript(_FINDINGS_SCHEMA)
    for f in (findings or []):
        con.execute(
            "INSERT INTO findings (finding_id, finding_type, severity, "
            "reachability_state, cwe_id, file_path, line_number, title, "
            "fix_type, fix_status) VALUES (?,?,?,?,?,?,?,?,?,?)",
            (f.get("finding_id","f1"), f.get("finding_type","cwe"),
             f.get("severity","HIGH"), f.get("reachability_state","REACHABLE"),
             f.get("cwe_id","CWE-89"), f.get("file_path","app.py"),
             f.get("line_number",10), f.get("title","SQL Injection"),
             f.get("fix_type","code_patch"), f.get("fix_status","fix_available")),
        )
    con.commit()
    con.close()
    return path


def _make_enzo_db(attempts=None):
    fd, path = tempfile.mkstemp(suffix=".db")
    os.close(fd)
    con = sqlite3.connect(path)
    con.executescript(_ATTEMPTS_SCHEMA)
    for a in (attempts or []):
        con.execute(
            "INSERT INTO remediation_attempts "
            "(finding_id, fix_type, status, patcher_method, cost_usd, completed_at, created_at) "
            "VALUES (?,?,?,?,?,?,?)",
            (a.get("finding_id","f1"), a.get("fix_type","code_patch"),
             a.get("status","success"), a.get("patcher_method","ai"),
             a.get("cost_usd",0.01), _NOW, _NOW),
        )
    con.commit()
    con.close()
    return path


# ── ReportConfig ──────────────────────────────────────────────────────────────

class TestReportConfig(unittest.TestCase):
    def setUp(self):
        self.tmpdir = tempfile.mkdtemp()
    def tearDown(self):
        import shutil  # noqa: E402
        shutil.rmtree(self.tmpdir, ignore_errors=True)

    def test_app_name_is_repo_dir_name(self):
        cfg = ReportConfig(repo_path=os.path.join(self.tmpdir,"myapp"),
                           enzo_db_path="/x/e.db", repo_db_path="/x/r.db")
        self.assertEqual(cfg.app_name, "myapp")

    def test_report_period_uses_today(self):
        cfg = ReportConfig(repo_path=self.tmpdir, enzo_db_path="/x/e.db",
                           repo_db_path="/x/r.db")
        today = datetime.now(timezone.utc).strftime("%Y-%m-%d")
        self.assertIn(today, cfg.report_period)

    def test_framework_name_empty_when_not_set(self):
        cfg = ReportConfig(repo_path=self.tmpdir, enzo_db_path="/x/e.db",
                           repo_db_path="/x/r.db")
        self.assertEqual(cfg.framework_name, "")

    def test_framework_name_soc2(self):
        cfg = ReportConfig(repo_path=self.tmpdir, enzo_db_path="/x/e.db",
                           repo_db_path="/x/r.db", framework="soc2")
        self.assertIn("SOC", cfg.framework_name)

    def test_org_name_default(self):
        cfg = ReportConfig(repo_path=self.tmpdir, enzo_db_path="/x/e.db",
                           repo_db_path="/x/r.db")
        self.assertEqual(cfg.org_name, "Organisation")


# ── ReportResult ──────────────────────────────────────────────────────────────

class TestReportResult(unittest.TestCase):
    def test_success_field(self):
        self.assertTrue(ReportResult(success=True).success)
    def test_error_field(self):
        self.assertEqual(ReportResult(success=False, error="nope").error, "nope")
    def test_word_count_default(self):
        self.assertEqual(ReportResult(success=True).word_count, 0)


# ── _load_findings ────────────────────────────────────────────────────────────

class TestLoadFindings(unittest.TestCase):
    def setUp(self):
        self.repo_db = _make_repo_db([
            {"finding_id":"abc","severity":"CRITICAL","reachability_state":"REACHABLE"},
            {"finding_id":"def","severity":"HIGH","reachability_state":"UNKNOWN"},
        ])
        self.enzo_db = _make_enzo_db([{"finding_id":"abc","status":"success"}])
    def tearDown(self):
        os.unlink(self.repo_db)
        os.unlink(self.enzo_db)

    def test_returns_two_findings(self):
        self.assertEqual(len(_load_findings(self.enzo_db, self.repo_db)), 2)

    def test_enriched_with_enzo_status(self):
        result = _load_findings(self.enzo_db, self.repo_db)
        abc = next(f for f in result if f["finding_id"]=="abc")
        self.assertEqual(abc.get("enzo_status"), "success")

    def test_unenriched_has_no_enzo_status(self):
        result = _load_findings(self.enzo_db, self.repo_db)
        d = next(f for f in result if f["finding_id"]=="def")
        self.assertIsNone(d.get("enzo_status"))

    def test_missing_repo_db_returns_empty(self):
        self.assertEqual(_load_findings(self.enzo_db, "/nope.db"), [])

    def test_scan_id_filter_no_match(self):
        self.assertEqual(_load_findings(self.enzo_db, self.repo_db, scan_id=99), [])


# ── _enzo_summary ─────────────────────────────────────────────────────────────

class TestEnzoSummary(unittest.TestCase):
    def test_counts_fixed(self):
        db = _make_enzo_db([{"status":"success"},{"status":"success"},{"status":"failed"}])
        try:
            self.assertEqual(_enzo_summary(db).get("fixed"), 2)
        finally:
            os.unlink(db)

    def test_sums_cost(self):
        db = _make_enzo_db([{"status":"success","cost_usd":0.05},
                             {"status":"success","cost_usd":0.03}])
        try:
            self.assertAlmostEqual(_enzo_summary(db).get("total_cost",0), 0.08, places=4)
        finally:
            os.unlink(db)

    def test_missing_db_returns_empty(self):
        self.assertEqual(_enzo_summary("/nope.db"), {})


# ── _load_attempts ────────────────────────────────────────────────────────────

class TestLoadAttempts(unittest.TestCase):
    def test_returns_attempts(self):
        db = _make_enzo_db([{"finding_id":"x","status":"success"},
                             {"finding_id":"x","status":"failed"}])
        try:
            self.assertEqual(len(_load_attempts(db,"x")), 2)
        finally:
            os.unlink(db)

    def test_empty_for_unknown(self):
        db = _make_enzo_db()
        try:
            self.assertEqual(_load_attempts(db,"nope"), [])
        finally:
            os.unlink(db)


# ── Helpers ───────────────────────────────────────────────────────────────────

class TestHelpers(unittest.TestCase):
    def test_safe_finding_passthrough(self):
        f = {"finding_id":"abc","severity":"HIGH","file_path":"a.py"}
        self.assertEqual(_safe_finding(f)["finding_id"], "abc")

    def test_summarise_findings_returns_str(self):
        result = _summarise_findings([
            {"severity":"CRITICAL","finding_type":"cwe","cwe_id":"CWE-89"},
            {"severity":"HIGH","finding_type":"cve","cwe_id":None},
        ])
        self.assertIsInstance(result, str)
        self.assertGreater(len(result), 0)

    def test_summarise_empty_returns_str(self):
        self.assertIsInstance(_summarise_findings([]), str)


# ── _render_risk_report ───────────────────────────────────────────────────────

class TestRenderRiskReport(unittest.TestCase):
    def _cfg(self):
        return ReportConfig(repo_path="/tmp/myapp", enzo_db_path="/tmp/e.db",
                            repo_db_path="/tmp/r.db", org_name="Acme")

    def _finding(self, enzo_status="success"):
        return {"finding_id":"abc123def456","severity":"CRITICAL",
                "reachability_state":"REACHABLE","cwe_id":"CWE-89",
                "file_path":"api/users.py","line_number":47,
                "enzo_status":enzo_status,"enzo_patcher":"ai"}

    def _render(self, finding=None, **kw):
        f = finding or self._finding()
        return _render_risk_report(
            self._cfg(), "2026-01-01", "abc123hash",
            [f], {"fixed":1,"total_cost":0.01},
            "Executive summary.", [(f, "Analysis.")],
            "Pattern analysis.", "0.6.3", "claude",
        )

    def test_contains_app_name(self):
        self.assertIn("myapp", self._render())
    def test_contains_org_name(self):
        self.assertIn("Acme", self._render())
    def test_contains_cwe(self):
        self.assertIn("CWE-89", self._render())
    def test_contains_hash(self):
        self.assertIn("abc123hash", self._render())
    def test_fixed_shown(self):
        self.assertIn("✓ Fixed", self._render())
    def test_open_shown(self):
        f = self._finding(enzo_status=None)
        self.assertIn("⚠ Open", self._render(finding=f))
    def test_remediation_summary_present(self):
        self.assertIn("Remediation Summary", self._render())


# ── Frameworks ────────────────────────────────────────────────────────────────

class TestFrameworks(unittest.TestCase):
    def test_resolve_soc2(self):
        self.assertIn("soc2", resolve_framework("soc2").lower())
    def test_resolve_pci(self):
        self.assertIn("pci", resolve_framework("pci").lower())
    def test_framework_names_has_entries(self):
        self.assertGreater(len(FRAMEWORK_NAMES), 0)
    def test_get_controls_returns_list(self):
        self.assertIsInstance(get_controls("soc2","CWE-89"), list)
    def test_describe_control_returns_str(self):
        controls = get_controls("soc2","CWE-89")
        if controls:
            self.assertIsInstance(describe_control("soc2", controls[0]), str)
    def test_all_controls_for_findings_returns_dict(self):
        findings = [{"cwe_id":"CWE-89","finding_type":"cwe"},
                    {"cwe_id":"CWE-79","finding_type":"cwe"}]
        self.assertIsInstance(all_controls_for_findings("soc2", findings), dict)


# ── Hasher ────────────────────────────────────────────────────────────────────

class TestHasher(unittest.TestCase):
    def test_hash_db_returns_str(self):
        fd, path = tempfile.mkstemp(suffix=".db")
        os.close(fd)
        try:
            self.assertIsInstance(hash_db(path), str)
        finally:
            os.unlink(path)

    def test_hash_db_deterministic(self):
        fd, path = tempfile.mkstemp(suffix=".db")
        os.write(fd, b"stable")
        os.close(fd)
        try:
            self.assertEqual(hash_db(path), hash_db(path))
        finally:
            os.unlink(path)

    def test_write_manifest_creates_file(self):
        tmpdir = tempfile.mkdtemp()
        try:
            fd, db_path = tempfile.mkstemp(suffix=".db", dir=tmpdir)
            os.close(fd)
            mdir = Path(tmpdir) / "reports"
            mdir.mkdir()
            write_manifest(
                repo_path=tmpdir,
                report_type="risk",
                report_path=str(mdir/"report.md"),
                db_hash="abc123",
            )
            self.assertTrue((Path(tmpdir)/".reachable"/"report-manifests.jsonl").exists())
        finally:
            import shutil  # noqa: E402
            shutil.rmtree(tmpdir, ignore_errors=True)


# ── generate_risk_report ──────────────────────────────────────────────────────

class TestGenerateRiskReport(unittest.TestCase):
    def setUp(self):
        self.tmpdir = tempfile.mkdtemp()
        self.repo_db = _make_repo_db([{"finding_id":"r1","severity":"CRITICAL"},
                                       {"finding_id":"r2","severity":"HIGH"}])
        self.enzo_db = _make_enzo_db([{"finding_id":"r1","status":"success","cost_usd":0.02}])
    def tearDown(self):
        import shutil  # noqa: E402
        shutil.rmtree(self.tmpdir, ignore_errors=True)
        os.unlink(self.repo_db)
        os.unlink(self.enzo_db)

    def _cfg(self, output_path=None):
        return ReportConfig(repo_path=self.tmpdir, enzo_db_path=self.enzo_db,
                            repo_db_path=self.repo_db, org_name="TestCorp",
                            model="test", output_format="markdown",
                            output_path=output_path)

    def test_no_findings_fails(self):
        empty = _make_repo_db([])
        try:
            cfg = ReportConfig(repo_path=self.tmpdir, enzo_db_path=self.enzo_db,
                               repo_db_path=empty, org_name="T")
            self.assertFalse(generate_risk_report(cfg).success)
        finally:
            os.unlink(empty)

    def test_returns_report_result(self):
        with patch("enzo.reporter.report._call_model", return_value="AI analysis"):
            result = generate_risk_report(self._cfg())
        self.assertIsInstance(result, ReportResult)

    def test_success_when_ai_responds(self):
        with patch("enzo.reporter.report._call_model", return_value="AI analysis"):
            self.assertTrue(generate_risk_report(self._cfg()).success)

    def test_db_hash_set_on_success(self):
        with patch("enzo.reporter.report._call_model", return_value="Summary"):
            result = generate_risk_report(self._cfg())
        if result.success:
            self.assertGreater(len(result.db_hash), 0)


# ── generate_executive_summary ────────────────────────────────────────────────

class TestGenerateExecutiveSummary(unittest.TestCase):
    def setUp(self):
        self.tmpdir = tempfile.mkdtemp()
        self.repo_db = _make_repo_db([{"finding_id":"ex1","severity":"HIGH"}])
        self.enzo_db = _make_enzo_db([{"finding_id":"ex1","status":"success"}])
    def tearDown(self):
        import shutil  # noqa: E402
        shutil.rmtree(self.tmpdir, ignore_errors=True)
        os.unlink(self.repo_db)
        os.unlink(self.enzo_db)

    def test_returns_report_result(self):
        cfg = ReportConfig(repo_path=self.tmpdir, enzo_db_path=self.enzo_db,
                           repo_db_path=self.repo_db, org_name="T")
        with patch("enzo.reporter.report._call_model", return_value="200-word summary."):
            self.assertIsInstance(generate_executive_summary(cfg), ReportResult)

    def test_no_findings_fails(self):
        empty = _make_repo_db([])
        cfg = ReportConfig(repo_path=self.tmpdir, enzo_db_path=self.enzo_db,
                           repo_db_path=empty)
        try:
            self.assertFalse(generate_executive_summary(cfg).success)
        finally:
            os.unlink(empty)


# ── generate_grc_report ───────────────────────────────────────────────────────

class TestGenerateGrcReport(unittest.TestCase):
    def setUp(self):
        self.tmpdir = tempfile.mkdtemp()
        self.repo_db = _make_repo_db([{"finding_id":"g1","severity":"CRITICAL","cwe_id":"CWE-89"},
                                       {"finding_id":"g2","severity":"HIGH","cwe_id":"CWE-79"}])
        self.enzo_db = _make_enzo_db([{"finding_id":"g1","status":"success"}])
    def tearDown(self):
        import shutil  # noqa: E402
        shutil.rmtree(self.tmpdir, ignore_errors=True)
        os.unlink(self.repo_db)
        os.unlink(self.enzo_db)

    def _cfg(self, fw="soc2"):
        return ReportConfig(repo_path=self.tmpdir, enzo_db_path=self.enzo_db,
                            repo_db_path=self.repo_db, org_name="FinCorp", framework=fw)

    def test_no_framework_fails(self):
        cfg = ReportConfig(repo_path=self.tmpdir, enzo_db_path=self.enzo_db,
                           repo_db_path=self.repo_db, framework="")
        result = generate_grc_report(cfg)
        self.assertFalse(result.success)
        self.assertIn("framework", result.error.lower())

    def test_no_findings_fails(self):
        empty = _make_repo_db([])
        cfg = ReportConfig(repo_path=self.tmpdir, enzo_db_path=self.enzo_db,
                           repo_db_path=empty, framework="soc2")
        try:
            self.assertFalse(generate_grc_report(cfg).success)
        finally:
            os.unlink(empty)

    def test_soc2_succeeds(self):
        with patch("enzo.reporter.report._call_model", return_value="SOC2 evidence"):
            self.assertTrue(generate_grc_report(self._cfg("soc2")).success)

    def test_pci_succeeds(self):
        with patch("enzo.reporter.report._call_model", return_value="PCI evidence"):
            self.assertTrue(generate_grc_report(self._cfg("pci")).success)

    def test_returns_report_result(self):
        with patch("enzo.reporter.report._call_model", return_value="analysis"):
            self.assertIsInstance(generate_grc_report(self._cfg()), ReportResult)


# ── CLI: report subcommand parse ─────────────────────────────────────────────

class TestCLIReportSubcommand(unittest.TestCase):
    def setUp(self):
        from enzo.cli import _build_subparsers
        self.parser = argparse.ArgumentParser()
        sub = self.parser.add_subparsers(dest="command")
        _build_subparsers(sub)

    def test_repo_defaults_to_dot(self):
        self.assertEqual(self.parser.parse_args(["report"]).repo, ".")
    def test_framework_flag(self):
        self.assertEqual(self.parser.parse_args(["report","--framework","soc2"]).framework, "soc2")
    def test_executive_flag(self):
        self.assertTrue(self.parser.parse_args(["report","--executive"]).executive)
    def test_finding_flag(self):
        self.assertEqual(self.parser.parse_args(["report","--finding","abc123"]).finding, "abc123")
    def test_output_default_markdown(self):
        self.assertEqual(self.parser.parse_args(["report"]).output, "markdown")
    def test_output_pdf(self):
        self.assertEqual(self.parser.parse_args(["report","--output","pdf"]).output, "pdf")
    def test_org_default(self):
        self.assertEqual(self.parser.parse_args(["report"]).org, "Organisation")
    def test_org_flag(self):
        self.assertEqual(self.parser.parse_args(["report","--org","Sthenos"]).org, "Sthenos")
    def test_scan_id_flag(self):
        self.assertEqual(self.parser.parse_args(["report","--scan-id","42"]).scan_id, 42)
    def test_func_registered(self):
        from enzo.cli import _cmd_report
        self.assertEqual(self.parser.parse_args(["report"]).func, _cmd_report)
    def test_accepted_risks_flag(self):
        self.assertTrue(self.parser.parse_args(["report","--accepted-risks"]).accepted_risks)


# ── _cmd_report body ──────────────────────────────────────────────────────────

class TestCmdReportBody(unittest.TestCase):
    def setUp(self):
        self.tmpdir = tempfile.mkdtemp()
        self.repo_db = _make_repo_db([{"finding_id":"cmd1","severity":"HIGH"}])
        self.enzo_db = _make_enzo_db([{"finding_id":"cmd1","status":"success"}])
        self.fake_repo_db = Path(self.tmpdir) / "repo.db"
        self.fake_enzo_db = Path(self.tmpdir) / "enzo.db"
        import shutil  # noqa: E402
        shutil.copy(self.repo_db, str(self.fake_repo_db))
        shutil.copy(self.enzo_db, str(self.fake_enzo_db))

    def tearDown(self):
        import shutil  # noqa: E402
        shutil.rmtree(self.tmpdir, ignore_errors=True)
        for p in (self.repo_db, self.enzo_db):
            try: os.unlink(p)
            except FileNotFoundError: pass

    def _args(self, **kw):
        class Args:
            repo = self.tmpdir
            framework = None
            executive = False
            finding = None
            accepted_risks = False
            org = "TestOrg"
            model = None
            output = "markdown"
            output_path = None
            scan_id = None
            period_start = None
            period_end = None
            debug = False
        for k, v in kw.items():
            setattr(Args, k, v)
        return Args()

    def test_risk_report_runs_without_crash(self):
        from enzo.cli import _cmd_report
        with patch("builtins.print"):
            with patch("enzo.query.get_repo_db_path", return_value=self.fake_repo_db):
                with patch("enzo.reporter.report._call_model", return_value="AI mock"):
                    _cmd_report(self._args())

    def test_framework_dispatches_grc(self):
        from enzo.cli import _cmd_report
        with patch("builtins.print"):
            with patch("enzo.query.get_repo_db_path", return_value=self.fake_repo_db):
                with patch("enzo.reporter.report.generate_grc_report",
                           return_value=ReportResult(success=True)) as mock_grc:
                    _cmd_report(self._args(framework="soc2"))
        mock_grc.assert_called_once()

    def test_executive_flag_dispatches_exec_summary(self):
        from enzo.cli import _cmd_report
        with patch("builtins.print"):
            with patch("enzo.query.get_repo_db_path", return_value=self.fake_repo_db):
                with patch("enzo.reporter.report.generate_executive_summary",
                           return_value=ReportResult(success=True)) as mock_exec:
                    _cmd_report(self._args(executive=True))
        mock_exec.assert_called_once()


if __name__ == "__main__":
    unittest.main()
