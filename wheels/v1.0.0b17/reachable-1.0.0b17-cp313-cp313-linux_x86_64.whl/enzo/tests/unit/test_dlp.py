#!/usr/bin/env python3
"""
Unit tests for DLP/PII remediation.

Tests:
  - dlp_fix_prompt generates correct system + user prompt for each flow_type
  - _infer_pii_field correctly identifies PII fields from source lines
  - _infer_flow_type correctly identifies logging/storage/transmission
  - _check_dlp_exposure_remains detects unfixed exposures
  - FixType.DLP_PATCH exists and routes correctly

No model required. Always fast.
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent.parent.parent))

import unittest

FIXTURES = Path(__file__).parent.parent / "fixtures" / "dlp"


class TestDlpPromptGeneration(unittest.TestCase):
    """dlp_fix_prompt builds correctly structured prompts."""

    def _make_prompt(self, flow_type, pii_type="email", pii_field="user.email",
                     language="python", attempt=1, prior_error=None):
        from enzo.patcher.prompts import dlp_fix_prompt
        content = f"def process(user):\n    log(user.{pii_field.split('.')[-1]})\n"
        return dlp_fix_prompt(
            file_path="app/users.py",
            file_content=content,
            line_number=2,
            pii_type=pii_type,
            pii_field=pii_field,
            flow_type=flow_type,
            finding_description=f"PII exposure: {pii_type} in {flow_type}",
            language=language,
            attempt_number=attempt,
            prior_error=prior_error,
        )

    def test_logging_prompt_contains_masking_instruction(self):
        system, user = self._make_prompt("logging")
        self.assertIn("mask", system.lower())
        self.assertIn("logging", system.lower() + user.lower())

    def test_transmission_prompt_contains_strip_instruction(self):
        system, user = self._make_prompt("transmission")
        self.assertIn("transmission", system.lower() + user.lower())

    def test_storage_prompt_structure(self):
        system, user = self._make_prompt("storage", pii_type="credit_card",
                                         pii_field="payment.card_number")
        # System must have the no-remove-field rule
        self.assertIn("Do NOT remove the PII field", system)
        # User must contain the file content
        self.assertIn("app/users.py", user)

    def test_password_prompt_emphasises_omission(self):
        """Passwords should be omitted from logs/responses, not just masked."""
        system, user = self._make_prompt("logging", pii_type="password",
                                         pii_field="user.password")
        self.assertIn("password", user.lower())

    def test_retry_prompt_includes_prior_error(self):
        system, user = self._make_prompt("logging", attempt=2,
                                         prior_error="Syntax error at line 3")
        self.assertIn("PREVIOUS ATTEMPT FAILED", user)
        self.assertIn("Syntax error at line 3", user)

    def test_prompt_contains_output_only_rule(self):
        """System prompt must instruct model to output only code."""
        system, _ = self._make_prompt("logging")
        self.assertIn("Output ONLY", system)

    def test_masking_apis_passed_through(self):
        from enzo.patcher.prompts import dlp_fix_prompt
        content = "def f(user): log(user.email)\n"
        system, user = dlp_fix_prompt(
            file_path="f.py", file_content=content, line_number=1,
            pii_type="email", pii_field="user.email", flow_type="logging",
            finding_description="PII", language="python",
            masking_apis=["utils.mask_email", "pii.redact"],
        )
        self.assertIn("utils.mask_email", system)

    def test_golang_prompt_uses_go_idioms(self):
        system, user = self._make_prompt("logging", language="go",
                                         pii_field="user.Email")
        self.assertIn("log.Printf", system)

    def test_typescript_prompt_uses_ts_idioms(self):
        system, user = self._make_prompt("transmission", language="typescript",
                                         pii_field="user.email")
        self.assertIn("res.json", system)


class TestDlpInferHelpers(unittest.TestCase):
    """_infer_pii_field and _infer_flow_type work on fixture source."""

    def test_infer_email_field(self):
        from enzo.patcher.engine import _infer_pii_field
        content = '    logger.info("user=%s", user.email)\n'
        result = _infer_pii_field(content, 1)
        self.assertIn("email", result.lower())

    def test_infer_ssn_field(self):
        from enzo.patcher.engine import _infer_pii_field
        content = '    logger.debug("SSN: %s", record.ssn)\n'
        result = _infer_pii_field(content, 1)
        self.assertIn("ssn", result.lower())

    def test_infer_credit_card_field(self):
        from enzo.patcher.engine import _infer_pii_field
        content = '    conn.execute(q, (payment.card_number, amount))\n'
        result = _infer_pii_field(content, 1)
        self.assertIn("card", result.lower())

    def test_infer_unknown_returns_empty(self):
        from enzo.patcher.engine import _infer_pii_field
        content = '    x = compute(a, b)\n'
        result = _infer_pii_field(content, 1)
        self.assertEqual(result, "")

    def test_infer_out_of_range_returns_empty(self):
        from enzo.patcher.engine import _infer_pii_field
        result = _infer_pii_field("one line\n", 999)
        self.assertEqual(result, "")

    def test_infer_logging_flow(self):
        from enzo.patcher.engine import _infer_flow_type
        content = '    logger.info("user email: %s", email)\n'
        self.assertEqual(_infer_flow_type(content, 1), "logging")

    def test_infer_storage_flow(self):
        from enzo.patcher.engine import _infer_flow_type
        content = '    db.execute("INSERT INTO users ...", (email,))\n'
        self.assertEqual(_infer_flow_type(content, 1), "storage")

    def test_infer_transmission_flow_json(self):
        from enzo.patcher.engine import _infer_flow_type
        content = '    return jsonify({"email": user.email})\n'
        self.assertEqual(_infer_flow_type(content, 1), "transmission")

    def test_infer_transmission_flow_res(self):
        from enzo.patcher.engine import _infer_flow_type
        content = '    res.json({ email: user.email })\n'
        self.assertEqual(_infer_flow_type(content, 1), "transmission")

    def test_infer_unknown_defaults_processing(self):
        from enzo.patcher.engine import _infer_flow_type
        content = '    x = transform(y)\n'
        self.assertEqual(_infer_flow_type(content, 1), "processing")


class TestDlpExposureCheck(unittest.TestCase):
    """_check_dlp_exposure_remains detects unfixed code."""

    def _check(self, code, pii_field, flow_type, line=2):
        from enzo.patcher.engine import _check_dlp_exposure_remains
        return _check_dlp_exposure_remains(code, pii_field, flow_type, line)

    def test_unfixed_logging_detected(self):
        """Raw email still in log call should be detected."""
        code = 'def f(user):\n    logger.info("email=%s", user.email)\n'
        self.assertTrue(self._check(code, "user.email", "logging"))

    def test_fixed_logging_with_mask_not_detected(self):
        """Masked email in log should not be flagged."""
        code = 'def f(user):\n    logger.info("email=%s", mask_email(user.email))\n'
        self.assertFalse(self._check(code, "user.email", "logging"))

    def test_unfixed_transmission_detected(self):
        """Raw email in jsonify should be detected."""
        code = 'def f(user):\n    return jsonify({"email": user.email})\n'
        self.assertTrue(self._check(code, "user.email", "transmission"))

    def test_fixed_transmission_not_detected(self):
        """Masked email in jsonify should not be flagged."""
        code = 'def f(user):\n    return jsonify({"email": mask_email(user.email)})\n'
        self.assertFalse(self._check(code, "user.email", "transmission"))

    def test_storage_always_passes(self):
        """Storage flow check is conservative — should not false positive."""
        code = 'def f(payment):\n    db.execute(q, (payment.card_number,))\n'
        # Storage check is intentionally skipped (hard without semantic analysis)
        self.assertFalse(self._check(code, "payment.card_number", "storage"))


class TestDlpFixType(unittest.TestCase):
    """FixType.DLP_PATCH exists and is distinct."""

    def test_dlp_patch_in_fixtype_enum(self):
        from enzo.models import FixType
        self.assertIn("dlp_patch", [ft.value for ft in FixType])

    def test_dlp_patch_is_distinct(self):
        from enzo.models import FixType
        self.assertNotEqual(FixType.DLP_PATCH, FixType.CODE_PATCH)

    def test_dlp_patch_in_engine_dispatch(self):
        """DLP_PATCH must have a handler in the engine dispatch table."""
        import inspect

        from enzo.patcher import engine as eng
        src = inspect.getsource(eng.PatchEngine.generate_patch
                                if hasattr(eng.PatchEngine, 'generate_patch')
                                else eng.PatchEngine)
        # Just verify the method exists
        self.assertTrue(hasattr(eng.PatchEngine, '_patch_dlp'),
                        "PatchEngine must have _patch_dlp method")

    def test_dlp_patch_handler_exists(self):
        from enzo.patcher.engine import PatchEngine
        self.assertTrue(callable(getattr(PatchEngine, '_patch_dlp', None)))


class TestDlpFixtureFiles(unittest.TestCase):
    """Verify all DLP fixture files exist and are valid code."""

    def test_python_fixtures_exist(self):
        for fname in ("logging_email.py", "logging_ssn.py",
                      "transmission_email.py", "storage_credit_card.py"):
            p = FIXTURES / fname
            self.assertTrue(p.exists(), f"Missing fixture: {fname}")
            # Must be valid Python
            import ast
            try:
                ast.parse(p.read_text())
            except SyntaxError as e:
                self.fail(f"Syntax error in {fname}: {e}")

    def test_typescript_fixtures_exist(self):
        for fname in ("logging_email.ts", "transmission_password.ts"):
            p = FIXTURES / fname
            self.assertTrue(p.exists(), f"Missing fixture: {fname}")
            # Must be non-empty
            self.assertGreater(len(p.read_text().strip()), 0)

    def test_fixtures_have_vulnerability_marker(self):
        """Each fixture should mark the vulnerable line."""
        for fpath in FIXTURES.glob("*.py"):
            content = fpath.read_text()
            self.assertIn("VULNERABLE", content,
                          f"{fpath.name} missing VULNERABLE marker")
        for fpath in FIXTURES.glob("*.ts"):
            content = fpath.read_text()
            self.assertIn("VULNERABLE", content,
                          f"{fpath.name} missing VULNERABLE marker")


if __name__ == "__main__":
    unittest.main(verbosity=2)
