#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.
"""
Tests for enzo/metrics.py — MetricsSummary, collect(), format_metrics(),
parse_since(), MetricsCollector, and the CLI metrics/benchmark subcommands.
"""
from __future__ import annotations

import argparse
import json
import os
import sqlite3
import sys
import tempfile
import unittest
from datetime import datetime, timedelta, timezone
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from enzo.metrics import (
    MetricsCollector,
    MetricsSummary,
    collect,
    format_metrics,
    parse_since,
)

# ── Helpers ───────────────────────────────────────────────────────────────────

_SCHEMA = """
CREATE TABLE IF NOT EXISTS remediation_attempts (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    scan_id         INTEGER DEFAULT 1,
    finding_id      TEXT,
    fix_type        TEXT,
    status          TEXT,
    attempt_number  INTEGER DEFAULT 1,
    attestation     TEXT,
    created_at      TEXT
);
CREATE TABLE IF NOT EXISTS benchmark_results (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    run_id      TEXT,
    fixture_id  TEXT,
    language    TEXT,
    fix_type    TEXT,
    success     INTEGER,
    duration_ms INTEGER,
    tokens_in   INTEGER DEFAULT 0,
    tokens_out  INTEGER DEFAULT 0,
    cost_usd    REAL DEFAULT 0.0,
    error       TEXT
);
CREATE TABLE IF NOT EXISTS benchmark_runs (
    run_id      TEXT PRIMARY KEY,
    created_at  TEXT,
    model       TEXT,
    provider    TEXT,
    enzo_version TEXT
);
"""


def _make_db(rows: list | None = None) -> str:
    """Create a temp enzo.db with schema + optional rows. Returns path."""
    fd, path = tempfile.mkstemp(suffix=".db")
    os.close(fd)
    con = sqlite3.connect(path)
    con.executescript(_SCHEMA)
    now = datetime.now(timezone.utc).isoformat()
    if rows:
        for r in rows:
            con.execute(
                """INSERT INTO remediation_attempts
                   (scan_id, finding_id, fix_type, status, attempt_number,
                    attestation, created_at)
                   VALUES (?,?,?,?,?,?,?)""",
                (
                    r.get("scan_id", 1),
                    r.get("finding_id", "f1"),
                    r.get("fix_type", "code_patch"),
                    r.get("status", "success"),
                    r.get("attempt_number", 1),
                    json.dumps(r.get("attestation", {})),
                    r.get("created_at", now),
                ),
            )
    con.commit()
    con.close()
    return path


def _recent() -> str:
    return datetime.now(timezone.utc).isoformat()


def _old(days: int = 60) -> str:
    return (datetime.now(timezone.utc) - timedelta(days=days)).isoformat()


# ── MetricsSummary properties ─────────────────────────────────────────────────

class TestMetricsSummaryProperties(unittest.TestCase):

    def test_fix_rate_zero_when_no_attempts(self):
        m = MetricsSummary()
        self.assertEqual(m.fix_rate, 0.0)

    def test_fix_rate_computed(self):
        m = MetricsSummary(attempted=10, succeeded=8)
        self.assertAlmostEqual(m.fix_rate, 0.8)

    def test_avg_cost_per_fix_zero_when_no_fixes(self):
        m = MetricsSummary(ai_count=0, total_cost_usd=0.0)
        self.assertEqual(m.avg_cost_per_fix, 0.0)

    def test_avg_cost_per_fix_computed(self):
        # avg_cost_per_fix = total_cost / succeeded
        m = MetricsSummary(succeeded=4, total_cost_usd=0.08)
        self.assertAlmostEqual(m.avg_cost_per_fix, 0.02)

    def test_avg_duration_zero_when_no_attempts(self):
        m = MetricsSummary(attempted=0, total_duration_ms=0)
        self.assertEqual(m.avg_duration_s, 0.0)

    def test_avg_duration_computed(self):
        m = MetricsSummary(attempted=2, total_duration_ms=4000)
        self.assertAlmostEqual(m.avg_duration_s, 2.0)

    def test_hallucination_rate_zero_when_no_candidates(self):
        m = MetricsSummary(hallucination_total=5, candidate_total=0)
        self.assertEqual(m.hallucination_rate, 0.0)

    def test_hallucination_rate_computed(self):
        m = MetricsSummary(hallucination_total=2, candidate_total=10)
        self.assertAlmostEqual(m.hallucination_rate, 0.2)

    def test_period_label_set_from_collect(self):
        m = MetricsSummary(period_days=7, period_label="last 7 days")
        self.assertEqual(m.period_label, "last 7 days")


# ── collect() function ────────────────────────────────────────────────────────

class TestCollectEmpty(unittest.TestCase):

    def test_missing_db_returns_empty_summary(self):
        m = collect("/nonexistent/path/enzo.db", since_days=30)
        self.assertEqual(m.attempted, 0)
        self.assertEqual(m.succeeded, 0)
        self.assertEqual(m.runs, 0)

    def test_empty_db_returns_zeros(self):
        path = _make_db()
        try:
            m = collect(path, since_days=30)
            self.assertEqual(m.attempted, 0)
            self.assertEqual(m.fix_rate, 0.0)
        finally:
            os.unlink(path)


class TestCollectWithData(unittest.TestCase):

    def setUp(self):
        now = _recent()
        self.path = _make_db([
            {"fix_type": "code_patch", "status": "success", "attempt_number": 1,
             "attestation": {"patcher_method": "ai", "cost_usd": 0.02,
                             "tokens_in": 400, "tokens_out": 200, "duration_ms": 2000},
             "created_at": now},
            {"fix_type": "secret_rotation", "status": "success", "attempt_number": 1,
             "attestation": {"patcher_method": "deterministic", "cost_usd": 0.0,
                             "duration_ms": 10},
             "created_at": now},
            {"fix_type": "code_patch", "status": "failed", "attempt_number": 2,
             "created_at": now},
            {"fix_type": "dependency_upgrade", "status": "manual", "attempt_number": 1,
             "created_at": now},
        ])

    def tearDown(self):
        os.unlink(self.path)

    def test_attempted_count(self):
        m = collect(self.path, since_days=30)
        self.assertEqual(m.attempted, 4)

    def test_succeeded_count(self):
        m = collect(self.path, since_days=30)
        self.assertEqual(m.succeeded, 2)

    def test_failed_count(self):
        m = collect(self.path, since_days=30)
        self.assertEqual(m.failed, 1)

    def test_manual_count(self):
        m = collect(self.path, since_days=30)
        self.assertEqual(m.manual, 1)

    def test_fix_rate(self):
        m = collect(self.path, since_days=30)
        self.assertAlmostEqual(m.fix_rate, 0.5)

    def test_deterministic_vs_ai_split(self):
        m = collect(self.path, since_days=30)
        self.assertEqual(m.ai_count, 1)
        self.assertEqual(m.deterministic_count, 1)

    def test_cost_accumulated(self):
        m = collect(self.path, since_days=30)
        self.assertAlmostEqual(m.total_cost_usd, 0.02)

    def test_tokens_accumulated(self):
        m = collect(self.path, since_days=30)
        self.assertEqual(m.total_tokens_in, 400)
        self.assertEqual(m.total_tokens_out, 200)

    def test_by_fix_type_keys(self):
        m = collect(self.path, since_days=30)
        self.assertIn("code_patch", m.by_fix_type)
        self.assertIn("secret_rotation", m.by_fix_type)
        self.assertIn("dependency_upgrade", m.by_fix_type)

    def test_by_fix_type_rate(self):
        m = collect(self.path, since_days=30)
        # 1 success out of 2 code_patch attempts
        self.assertAlmostEqual(m.by_fix_type["code_patch"]["rate"], 0.5)
        # 1 success out of 1
        self.assertAlmostEqual(m.by_fix_type["secret_rotation"]["rate"], 1.0)

    def test_dlp_patch_appears_in_by_fix_type(self):
        """dlp_patch fix type is tracked dynamically — no hardcoding."""
        extra_path = _make_db([
            {"fix_type": "dlp_patch", "status": "success",
             "created_at": _recent()},
        ])
        try:
            m = collect(extra_path, since_days=30)
            self.assertIn("dlp_patch", m.by_fix_type)
            self.assertEqual(m.by_fix_type["dlp_patch"]["rate"], 1.0)
        finally:
            os.unlink(extra_path)


class TestCollectWindowFiltering(unittest.TestCase):

    def test_old_rows_excluded_by_window(self):
        path = _make_db([
            {"status": "success", "created_at": _recent()},
            {"status": "success", "created_at": _old(60)},  # outside 30d window
        ])
        try:
            m = collect(path, since_days=30)
            self.assertEqual(m.attempted, 1)
        finally:
            os.unlink(path)

    def test_all_rows_included_with_wide_window(self):
        path = _make_db([
            {"status": "success", "created_at": _recent()},
            {"status": "success", "created_at": _old(60)},
        ])
        try:
            m = collect(path, since_days=90)
            self.assertEqual(m.attempted, 2)
        finally:
            os.unlink(path)

    def test_previous_period_comparison(self):
        now = _recent()
        old = _old(45)  # within 90d window but outside 30d
        path = _make_db([
            {"status": "success", "created_at": now},
            {"status": "success", "created_at": old},
            {"status": "failed",  "created_at": old},
        ])
        try:
            m = collect(path, since_days=30)
            # prev_fix_rate should be computed from the older window
            self.assertIsNotNone(m.prev_fix_rate)
            self.assertAlmostEqual(m.prev_fix_rate, 0.5)  # 1 success / 2 total
        finally:
            os.unlink(path)


class TestCollectBenchmarkLanguages(unittest.TestCase):

    def test_language_breakdown_populated(self):
        path = _make_db()
        con = sqlite3.connect(path)
        con.execute(
            "INSERT INTO benchmark_results (run_id, fixture_id, language, fix_type, "
            "success) VALUES (?,?,?,?,?)",
            ("bm_1", "python/sqli", "python", "code_patch", 1),
        )
        con.execute(
            "INSERT INTO benchmark_results (run_id, fixture_id, language, fix_type, "
            "success) VALUES (?,?,?,?,?)",
            ("bm_1", "go/sqli", "go", "code_patch", 0),
        )
        con.commit()
        con.close()
        try:
            m = collect(path, since_days=30)
            self.assertIn("python", m.by_language)
            self.assertIn("go", m.by_language)
            self.assertAlmostEqual(m.by_language["python"]["rate"], 1.0)
            self.assertAlmostEqual(m.by_language["go"]["rate"], 0.0)
        finally:
            os.unlink(path)

    def test_no_benchmark_table_handled_gracefully(self):
        """If benchmark_results table is missing, collect() should not crash."""
        fd, path = tempfile.mkstemp(suffix=".db")
        os.close(fd)
        con = sqlite3.connect(path)
        con.executescript("""
            CREATE TABLE remediation_attempts (
                id INTEGER PRIMARY KEY, scan_id INTEGER DEFAULT 1,
                finding_id TEXT, fix_type TEXT, status TEXT,
                attempt_number INTEGER DEFAULT 1, attestation TEXT, created_at TEXT
            );
        """)
        con.commit()
        con.close()
        try:
            m = collect(path, since_days=30)
            self.assertEqual(m.by_language, {})
        finally:
            os.unlink(path)


class TestCollectHallucinationJsonl(unittest.TestCase):

    def test_hallucination_jsonl_counted(self):
        path = _make_db()
        fd, jsonl_path = tempfile.mkstemp(suffix=".jsonl")
        os.close(fd)
        now = datetime.now(timezone.utc).isoformat()
        with open(jsonl_path, "w") as f:
            f.write(json.dumps({"ts": now, "attempt": 1, "finding_id": "f1"}) + "\n")
            f.write(json.dumps({"ts": now, "attempt": 2, "finding_id": "f2"}) + "\n")
        try:
            m = collect(path, since_days=30, hallucinations_jsonl=jsonl_path)
            self.assertEqual(m.hallucination_total, 2)
            # attempt < 3 → both count as candidates
            self.assertEqual(m.candidate_total, 2)
        finally:
            os.unlink(path)
            os.unlink(jsonl_path)

    def test_missing_jsonl_does_not_crash(self):
        path = _make_db()
        try:
            m = collect(path, since_days=30, hallucinations_jsonl="/nonexistent.jsonl")
            self.assertEqual(m.hallucination_total, 0)
        finally:
            os.unlink(path)


# ── format_metrics() ──────────────────────────────────────────────────────────

class TestFormatMetrics(unittest.TestCase):

    def _basic(self, **kw) -> MetricsSummary:
        defaults = dict(
            attempted=10, succeeded=9, failed=1, manual=0,
            runs=3, period_days=30, period_label="last 30 days",
            ai_count=6, deterministic_count=3, total_cost_usd=0.12,
            total_duration_ms=60000,
        )
        defaults.update(kw)
        return MetricsSummary(**defaults)

    def test_output_contains_header(self):
        out = format_metrics(self._basic(), repo_name="myrepo")
        self.assertIn("ENZO METRICS", out)
        self.assertIn("myrepo", out)

    def test_fix_rate_shown(self):
        out = format_metrics(self._basic())
        self.assertIn("90.0%", out)

    def test_pipeline_runs_shown(self):
        out = format_metrics(self._basic())
        self.assertIn("3", out)

    def test_patcher_split_ai(self):
        out = format_metrics(self._basic())
        self.assertIn("AI:", out)

    def test_patcher_split_deterministic(self):
        out = format_metrics(self._basic())
        self.assertIn("Deterministic:", out)

    def test_cost_shown(self):
        out = format_metrics(self._basic())
        self.assertIn("0.12", out)

    def test_by_fix_type_shown(self):
        m = self._basic()
        m.by_fix_type = {
            "code_patch": {"total": 5, "succeeded": 4, "rate": 0.8, "avg_attempts": 1.4},
            "dlp_patch":  {"total": 2, "succeeded": 2, "rate": 1.0, "avg_attempts": 1.0},
        }
        out = format_metrics(m)
        self.assertIn("code_patch", out)
        self.assertIn("dlp_patch", out)
        self.assertIn("80.0%", out)
        self.assertIn("100.0%", out)

    def test_by_language_shown(self):
        m = self._basic()
        m.by_language = {
            "python": {"total": 4, "succeeded": 4, "rate": 1.0},
            "go":     {"total": 3, "succeeded": 2, "rate": 0.667},
        }
        out = format_metrics(m)
        self.assertIn("python", out)
        self.assertIn("go", out)

    def test_hallucination_block_shown_when_nonzero(self):
        m = self._basic(hallucination_total=5, candidate_total=30)
        out = format_metrics(m)
        self.assertIn("Hallucination", out)

    def test_no_hallucination_block_when_zero(self):
        m = self._basic(hallucination_total=0, candidate_total=0)
        out = format_metrics(m)
        self.assertNotIn("Hallucination", out)

    def test_trend_shown_when_prev_available(self):
        m = self._basic(prev_fix_rate=0.80)
        out = format_metrics(m)
        self.assertIn("↑", out)

    def test_empty_db_message_when_no_attempts(self):
        m = MetricsSummary(period_days=30, period_label="last 30 days")
        out = format_metrics(m)
        self.assertIn("No pipeline runs", out)

    def test_separator_lines_present(self):
        out = format_metrics(self._basic())
        self.assertIn("━" * 10, out)

    def test_manual_line_shown_when_nonzero(self):
        m = self._basic(manual=3)
        out = format_metrics(m)
        self.assertIn("Manual required", out)

    def test_avg_timing_shown(self):
        m = self._basic(total_duration_ms=20000, attempted=4)
        out = format_metrics(m)
        self.assertIn("time/fix", out)


# ── parse_since() ─────────────────────────────────────────────────────────────

class TestParseSince(unittest.TestCase):

    def test_days_integer_string(self):
        self.assertEqual(parse_since("30d"), 30)

    def test_days_no_suffix_raises(self):
        # "30" without 'd' suffix hits the date branch and raises
        with self.assertRaises((ValueError, Exception)):
            parse_since("30")

    def test_seven_days(self):
        self.assertEqual(parse_since("7d"), 7)

    def test_date_string_gives_positive_days(self):
        last_week = (datetime.now(timezone.utc) - timedelta(days=7)).strftime("%Y-%m-%d")
        days = parse_since(last_week)
        self.assertGreater(days, 0)
        self.assertLessEqual(days, 10)  # approximately 7 days

    def test_invalid_raises(self):
        """Unrecognised format raises ValueError."""
        with self.assertRaises((ValueError, Exception)):
            parse_since("gibberish")


# ── MetricsCollector ──────────────────────────────────────────────────────────

class TestMetricsCollector(unittest.TestCase):

    def setUp(self):
        self.tmpdir = tempfile.mkdtemp()
        # Create a fake scan dir with enzo.db
        scan_dir = Path(self.tmpdir) / ".reachable" / "scans" / "testrepo"
        scan_dir.mkdir(parents=True)
        self.enzo_db = str(scan_dir / "enzo.db")
        path = _make_db([
            {"status": "success", "created_at": _recent()},
            {"status": "failed",  "created_at": _recent()},
        ])
        import shutil
        shutil.copy(path, self.enzo_db)
        os.unlink(path)

    def tearDown(self):
        import shutil
        shutil.rmtree(self.tmpdir, ignore_errors=True)

    def test_collect_days_returns_summary(self):
        mc = MetricsCollector(self.enzo_db, repo_path=self.tmpdir)
        m = mc.collect_days(30)
        self.assertIsInstance(m, MetricsSummary)
        self.assertEqual(m.attempted, 2)

    def test_collect_days_zero_for_empty(self):
        empty_db = str(Path(self.tmpdir) / "empty.db")
        mc = MetricsCollector(empty_db, repo_path=self.tmpdir)
        m = mc.collect_days(30)
        self.assertEqual(m.attempted, 0)

    def test_hallucinations_jsonl_picked_up(self):
        jsonl = Path(self.tmpdir) / ".reachable" / "hallucinations.jsonl"
        jsonl.parent.mkdir(parents=True, exist_ok=True)
        now = datetime.now(timezone.utc).isoformat()
        jsonl.write_text(json.dumps({"ts": now, "attempt": 1}) + "\n")
        mc = MetricsCollector(self.enzo_db, repo_path=self.tmpdir)
        m = mc.collect_days(30)
        self.assertEqual(m.hallucination_total, 1)


# ── CLI: metrics subcommand parse ─────────────────────────────────────────────

class TestCLIMetricsSubcommand(unittest.TestCase):

    def setUp(self):
        from enzo.cli import _build_subparsers
        self.parser = argparse.ArgumentParser()
        sub = self.parser.add_subparsers(dest="command")
        _build_subparsers(sub)

    def test_metrics_defaults(self):
        args = self.parser.parse_args(["metrics"])
        self.assertEqual(args.since, "30d")
        self.assertFalse(args.json_output)

    def test_metrics_since_flag(self):
        args = self.parser.parse_args(["metrics", "--since", "7d"])
        self.assertEqual(args.since, "7d")

    def test_metrics_json_flag(self):
        args = self.parser.parse_args(["metrics", "--json"])
        self.assertTrue(args.json_output)

    def test_metrics_func_registered(self):
        from enzo.cli import _cmd_metrics
        args = self.parser.parse_args(["metrics"])
        self.assertEqual(args.func, _cmd_metrics)

    def test_metrics_repo_is_positional(self):
        # repo is positional, not --repo flag
        args = self.parser.parse_args(["metrics", "/myrepo"])
        self.assertEqual(args.repo, "/myrepo")

    def test_metrics_repo_defaults_to_dot(self):
        args = self.parser.parse_args(["metrics"])
        self.assertEqual(args.repo, ".")


# ── _cmd_metrics body ─────────────────────────────────────────────────────────

class TestCmdMetricsBody(unittest.TestCase):

    def setUp(self):
        self.tmpdir = tempfile.mkdtemp()
        self.fake_repo_db = Path(self.tmpdir) / "repo.db"
        self.fake_enzo_db = Path(self.tmpdir) / "enzo.db"
        src = _make_db([
            {"fix_type": "code_patch", "status": "success", "created_at": _recent()},
            {"fix_type": "dlp_patch",  "status": "success", "created_at": _recent()},
            {"fix_type": "code_patch", "status": "failed",  "created_at": _recent()},
        ])
        import shutil
        shutil.copy(src, str(self.fake_enzo_db))
        os.unlink(src)

    def tearDown(self):
        import shutil
        shutil.rmtree(self.tmpdir, ignore_errors=True)

    def _run(self, json_output: bool = False) -> str:
        from unittest.mock import patch

        from enzo.cli import _cmd_metrics

        class Args:
            repo = self.tmpdir
            since = "30d"
        Args.json_output = json_output

        lines = []
        with patch("builtins.print", side_effect=lambda *a: lines.append(" ".join(str(x) for x in a))):
            with patch("enzo.query.get_repo_db_path", return_value=self.fake_repo_db):
                _cmd_metrics(Args())
        return "\n".join(lines)

    def test_prints_metrics_header(self):
        self.assertIn("ENZO METRICS", self._run())

    def test_shows_fix_rate(self):
        # 2 success / 3 total = 66.7%
        self.assertIn("66.7%", self._run())

    def test_json_output_has_attempted_key(self):
        self.assertIn("attempted", self._run(json_output=True))

    def test_json_output_is_valid_json(self):
        output = self._run(json_output=True)
        data = json.loads(output)
        self.assertEqual(data["attempted"], 3)
        self.assertEqual(data["succeeded"], 2)

    def test_no_db_prints_guidance_not_metrics(self):
        from unittest.mock import patch

        from enzo.cli import _cmd_metrics

        class Args:
            repo = self.tmpdir
            since = "30d"
            json_output = False

        missing = Path(self.tmpdir) / "missing" / "repo.db"
        lines = []
        with patch("builtins.print", side_effect=lambda *a: lines.append(" ".join(str(x) for x in a))):
            with patch("enzo.query.get_repo_db_path", return_value=missing):
                _cmd_metrics(Args())
        output = "\n".join(lines)
        self.assertTrue(len(output) > 0)
        self.assertNotIn("ENZO METRICS", output)


if __name__ == "__main__":
    unittest.main()
