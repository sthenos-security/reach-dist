#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.
"""
Tests for enzo/benchmark.py — Fixture, BenchmarkResult, BenchmarkRunner,
_ensure_schema, _write_db, _print_result, _print_summary, FIXTURES list,
and the CLI benchmark subcommand.
"""
from __future__ import annotations

import argparse
import os
import sqlite3
import sys
import tempfile
import time
import unittest
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from enzo.benchmark import (
    FIXTURES,
    FIXTURES_DIR,
    BenchmarkResult,
    BenchmarkRunner,
    Fixture,
)

# ── Helpers ───────────────────────────────────────────────────────────────────

def _tmp_db() -> str:
    fd, path = tempfile.mkstemp(suffix=".db")
    os.close(fd)
    return path


def _det_fixture(fixture_id: str = "python/secret_api_key") -> Fixture:
    """Return the first deterministic fixture matching fixture_id from FIXTURES."""
    for fx in FIXTURES:
        if fx.fixture_id == fixture_id:
            return fx
    raise ValueError(f"fixture not found: {fixture_id}")


def _minimal_fixture(**kw) -> Fixture:
    defaults = dict(
        fixture_id="test/dummy",
        language="python",
        fix_type="code_patch",
        file_path="python/cwe89_sqli.py",
        line_number=14,
        patcher="ai",
    )
    defaults.update(kw)
    return Fixture(**defaults)


def _mock_result(fx: Fixture, success: bool = True, patcher_method: str = "deterministic") -> BenchmarkResult:
    return BenchmarkResult(
        fixture=fx,
        success=success,
        patcher_method=patcher_method,
        duration_ms=42,
        tokens_in=100,
        tokens_out=80,
        cost_usd=0.001,
    )


# ── Fixture dataclass ─────────────────────────────────────────────────────────

class TestFixtureDataclass(unittest.TestCase):

    def test_fixture_id_set(self):
        fx = _minimal_fixture()
        self.assertEqual(fx.fixture_id, "test/dummy")

    def test_patcher_default_is_ai(self):
        fx = _minimal_fixture()
        self.assertEqual(fx.patcher, "ai")

    def test_deterministic_fixture_flag(self):
        fx = _det_fixture("python/secret_api_key")
        self.assertEqual(fx.patcher, "deterministic")

    def test_max_lines_changed_default(self):
        fx = _minimal_fixture()
        self.assertEqual(fx.max_lines_changed, 8)

    def test_optional_fields_default_none(self):
        fx = _minimal_fixture()
        self.assertIsNone(fx.cwe_id)
        self.assertIsNone(fx.package_name)
        self.assertIsNone(fx.secret_type)


# ── FIXTURES list ─────────────────────────────────────────────────────────────

class TestFixturesList(unittest.TestCase):

    def test_fixtures_not_empty(self):
        self.assertGreater(len(FIXTURES), 0)

    def test_all_fixtures_have_fixture_id(self):
        for fx in FIXTURES:
            self.assertTrue(fx.fixture_id, f"fixture_id empty on {fx}")

    def test_all_fixtures_have_language(self):
        for fx in FIXTURES:
            self.assertTrue(fx.language, f"language empty on {fx.fixture_id}")

    def test_all_fixtures_have_fix_type(self):
        for fx in FIXTURES:
            self.assertIn(
                fx.fix_type,
                ("code_patch", "secret_rotation", "dependency_upgrade",
                 "malware", "config_change", "dlp_patch"),
                f"unrecognised fix_type on {fx.fixture_id}",
            )

    def test_deterministic_fixtures_have_patcher_field(self):
        det = [fx for fx in FIXTURES if fx.patcher == "deterministic"]
        self.assertGreater(len(det), 0)

    def test_fixture_files_exist(self):
        """Every fixture file_path must resolve under FIXTURES_DIR."""
        missing = []
        for fx in FIXTURES:
            p = FIXTURES_DIR / fx.file_path
            if not p.exists():
                missing.append(str(p))
        self.assertEqual(missing, [], f"Missing fixture files: {missing}")

    def test_no_duplicate_fixture_ids(self):
        ids = [fx.fixture_id for fx in FIXTURES]
        self.assertEqual(len(ids), len(set(ids)), "Duplicate fixture_ids found")

    def test_secret_fixtures_have_secret_value(self):
        secrets = [fx for fx in FIXTURES if fx.fix_type == "secret_rotation"]
        for fx in secrets:
            self.assertTrue(fx.secret_value,
                            f"secret_rotation fixture missing secret_value: {fx.fixture_id}")

    def test_dep_fixtures_have_versions(self):
        deps = [fx for fx in FIXTURES if fx.fix_type == "dependency_upgrade"]
        for fx in deps:
            self.assertTrue(fx.current_version and fx.fix_version,
                            f"dep fixture missing versions: {fx.fixture_id}")


# ── BenchmarkResult dataclass ─────────────────────────────────────────────────

class TestBenchmarkResult(unittest.TestCase):

    def test_success_field(self):
        fx = _minimal_fixture()
        br = BenchmarkResult(fixture=fx, success=True)
        self.assertTrue(br.success)

    def test_error_defaults_empty(self):
        br = BenchmarkResult(fixture=_minimal_fixture(), success=False)
        self.assertEqual(br.error, "")

    def test_patcher_method_default_ai(self):
        br = BenchmarkResult(fixture=_minimal_fixture(), success=True)
        self.assertEqual(br.patcher_method, "ai")

    def test_hallucination_count_default_zero(self):
        br = BenchmarkResult(fixture=_minimal_fixture(), success=True)
        self.assertEqual(br.hallucination_count, 0)


# ── BenchmarkRunner._ensure_schema ───────────────────────────────────────────

class TestBenchmarkRunnerSchema(unittest.TestCase):

    def test_schema_creates_tables(self):
        path = _tmp_db()
        try:
            runner = BenchmarkRunner("m", "groq", path)
            con = sqlite3.connect(path)
            tables = {r[0] for r in con.execute(
                "SELECT name FROM sqlite_master WHERE type='table'"
            ).fetchall()}
            con.close()
            self.assertIn("benchmark_runs", tables)
            self.assertIn("benchmark_results", tables)
        finally:
            os.unlink(path)

    def test_schema_idempotent(self):
        """Creating runner twice should not raise."""
        path = _tmp_db()
        try:
            BenchmarkRunner("m", "groq", path)
            BenchmarkRunner("m", "groq", path)
        finally:
            os.unlink(path)


# ── BenchmarkRunner.run with only_deterministic ───────────────────────────────

class TestBenchmarkRunnerDeterministic(unittest.TestCase):

    def setUp(self):
        self.path = _tmp_db()
        self.runner = BenchmarkRunner(
            model="n/a", provider="groq", db_path=self.path,
            only_deterministic=True,
        )

    def tearDown(self):
        os.unlink(self.path)

    def test_only_deterministic_filters_fixtures(self):
        det = [fx for fx in FIXTURES if fx.patcher == "deterministic"]
        with patch.object(self.runner, "_run_one", wraps=self.runner._run_one) as mock_run:
            with patch("builtins.print"):
                results = self.runner.run()
        self.assertEqual(len(results), len(det))

    def test_results_list_returned(self):
        with patch("builtins.print"):
            results = self.runner.run()
        self.assertIsInstance(results, list)

    def test_all_deterministic_fixtures_succeed(self):
        """All bundled deterministic fixtures should succeed (no AI needed)."""
        with patch("builtins.print"):
            results = self.runner.run()
        failures = [(r.fixture.fixture_id, r.error) for r in results if not r.success]
        self.assertEqual(failures, [])

    def test_patcher_method_recorded(self):
        with patch("builtins.print"):
            results = self.runner.run()
        for r in results:
            self.assertEqual(r.patcher_method, "deterministic")

    def test_duration_ms_set(self):
        with patch("builtins.print"):
            results = self.runner.run()
        for r in results:
            self.assertGreaterEqual(r.duration_ms, 0)

    def test_results_written_to_db(self):
        with patch("builtins.print"):
            self.runner.run()
        con = sqlite3.connect(self.path)
        rows = con.execute("SELECT * FROM benchmark_results").fetchall()
        runs = con.execute("SELECT * FROM benchmark_runs").fetchall()
        con.close()
        self.assertGreater(len(rows), 0)
        self.assertEqual(len(runs), 1)

    def test_run_id_format(self):
        with patch("builtins.print"):
            self.runner.run()
        con = sqlite3.connect(self.path)
        run_id = con.execute("SELECT run_id FROM benchmark_runs").fetchone()[0]
        con.close()
        self.assertTrue(run_id.startswith("bm_"))

    def test_run_twice_creates_two_run_rows(self):
        with patch("builtins.print"):
            self.runner.run()
            time.sleep(1.1)  # ensure distinct timestamp in run_id
            self.runner.run()
        con = sqlite3.connect(self.path)
        count = con.execute("SELECT COUNT(*) FROM benchmark_runs").fetchone()[0]
        con.close()
        self.assertEqual(count, 2)


# ── BenchmarkRunner._run_one exception handling ───────────────────────────────

class TestBenchmarkRunnerRunOne(unittest.TestCase):

    def setUp(self):
        self.path = _tmp_db()
        self.runner = BenchmarkRunner("m", "groq", self.path, only_deterministic=True)

    def tearDown(self):
        os.unlink(self.path)

    def test_exception_in_run_deterministic_returns_failure(self):
        fx = _det_fixture("python/secret_api_key")
        with patch.object(self.runner, "_run_deterministic", side_effect=RuntimeError("boom")):
            result = self.runner._run_one(fx)
        self.assertFalse(result.success)
        self.assertIn("boom", result.error)

    def test_failed_result_has_duration(self):
        fx = _det_fixture("python/secret_api_key")
        with patch.object(self.runner, "_run_deterministic", side_effect=RuntimeError("err")):
            result = self.runner._run_one(fx)
        self.assertGreaterEqual(result.duration_ms, 0)


# ── BenchmarkRunner._print_result / _print_summary ───────────────────────────

class TestBenchmarkRunnerPrint(unittest.TestCase):

    def setUp(self):
        self.path = _tmp_db()
        self.runner = BenchmarkRunner("m", "groq", self.path)
        self.fx = _minimal_fixture(fixture_id="test/demo", patcher="deterministic")

    def tearDown(self):
        os.unlink(self.path)

    def test_print_result_success_shows_tick(self):
        br = _mock_result(self.fx, success=True, patcher_method="deterministic")
        with patch("builtins.print") as mock_print:
            self.runner._print_result(br)
        output = " ".join(str(c) for c in mock_print.call_args_list)
        self.assertIn("✓", output)

    def test_print_result_failure_shows_cross(self):
        br = _mock_result(self.fx, success=False)
        br.error = "syntax error at line 5"
        with patch("builtins.print") as mock_print:
            self.runner._print_result(br)
        output = " ".join(str(c) for c in mock_print.call_args_list)
        self.assertIn("✗", output)

    def test_print_summary_shows_pass_rate(self):
        results = [
            _mock_result(self.fx, success=True),
            _mock_result(self.fx, success=False),
        ]
        with patch("builtins.print") as mock_print:
            self.runner._print_summary("bm_test123", results)
        output = " ".join(str(c) for c in mock_print.call_args_list)
        self.assertIn("1/2", output)

    def test_print_summary_shows_run_id(self):
        results = [_mock_result(self.fx, success=True)]
        with patch("builtins.print") as mock_print:
            self.runner._print_summary("bm_run_xyz", results)
        output = " ".join(str(c) for c in mock_print.call_args_list)
        self.assertIn("bm_run_xyz", output)

    def test_print_result_shows_hallucination_warning(self):
        br = _mock_result(self.fx, success=True, patcher_method="ai")
        br.hallucination_count = 2
        with patch("builtins.print") as mock_print:
            self.runner._print_result(br)
        output = " ".join(str(c) for c in mock_print.call_args_list)
        self.assertIn("hall", output)


# ── BenchmarkRunner._write_db ─────────────────────────────────────────────────

class TestBenchmarkWriteDb(unittest.TestCase):

    def setUp(self):
        self.path = _tmp_db()
        self.runner = BenchmarkRunner("claude-sonnet-4-6", "anthropic", self.path)
        self.fx = _minimal_fixture(fixture_id="test/write_db", patcher="deterministic")

    def tearDown(self):
        os.unlink(self.path)

    def test_write_db_inserts_run(self):
        results = [_mock_result(self.fx, success=True, patcher_method="deterministic")]
        self.runner._write_db("bm_test001", results)
        con = sqlite3.connect(self.path)
        row = con.execute("SELECT * FROM benchmark_runs WHERE run_id='bm_test001'").fetchone()
        con.close()
        self.assertIsNotNone(row)

    def test_write_db_inserts_result_rows(self):
        results = [
            _mock_result(self.fx, success=True, patcher_method="deterministic"),
            _mock_result(self.fx, success=False, patcher_method="ai"),
        ]
        self.runner._write_db("bm_test002", results)
        con = sqlite3.connect(self.path)
        count = con.execute(
            "SELECT COUNT(*) FROM benchmark_results WHERE run_id='bm_test002'"
        ).fetchone()[0]
        con.close()
        self.assertEqual(count, 2)

    def test_write_db_records_model(self):
        results = [_mock_result(self.fx, success=True)]
        self.runner._write_db("bm_test003", results)
        con = sqlite3.connect(self.path)
        row = con.execute(
            "SELECT model FROM benchmark_runs WHERE run_id='bm_test003'"
        ).fetchone()
        con.close()
        self.assertEqual(row[0], "claude-sonnet-4-6")

    def test_write_db_records_pass_count(self):
        results = [
            _mock_result(self.fx, success=True),
            _mock_result(self.fx, success=True),
            _mock_result(self.fx, success=False),
        ]
        self.runner._write_db("bm_test004", results)
        con = sqlite3.connect(self.path)
        row = con.execute(
            "SELECT pass_count, fail_count FROM benchmark_runs WHERE run_id='bm_test004'"
        ).fetchone()
        con.close()
        self.assertEqual(row[0], 2)
        self.assertEqual(row[1], 1)


# ── CLI: benchmark subcommand parse ──────────────────────────────────────────

class TestCLIBenchmarkSubcommand(unittest.TestCase):

    def setUp(self):
        from enzo.cli import _build_subparsers
        self.parser = argparse.ArgumentParser()
        sub = self.parser.add_subparsers(dest="command")
        _build_subparsers(sub)

    def test_benchmark_repo_defaults_to_dot(self):
        args = self.parser.parse_args(["benchmark"])
        self.assertEqual(args.repo, ".")

    def test_benchmark_model_default_is_none(self):
        args = self.parser.parse_args(["benchmark"])
        # model defaults to None; user provides --model or relies on env
        self.assertIsNone(args.model)

    def test_benchmark_only_det_flag(self):
        args = self.parser.parse_args(["benchmark", "--deterministic-only"])
        self.assertTrue(args.deterministic_only)

    def test_benchmark_custom_repo(self):
        args = self.parser.parse_args(["benchmark", "/myrepo"])
        self.assertEqual(args.repo, "/myrepo")

    def test_benchmark_func_registered(self):
        from enzo.cli import _cmd_benchmark
        args = self.parser.parse_args(["benchmark"])
        self.assertEqual(args.func, _cmd_benchmark)

    def test_benchmark_compare_flag(self):
        args = self.parser.parse_args(["benchmark", "--compare", "bm_20260301_120000"])
        self.assertEqual(args.compare, "bm_20260301_120000")


# ── _cmd_benchmark body ───────────────────────────────────────────────────────

class TestCmdBenchmarkBody(unittest.TestCase):

    def setUp(self):
        self.tmpdir = tempfile.mkdtemp()
        self.fake_repo_db = Path(self.tmpdir) / "repo.db"
        self.fake_enzo_db = Path(self.tmpdir) / "enzo.db"

    def tearDown(self):
        import shutil
        shutil.rmtree(self.tmpdir, ignore_errors=True)

    def test_benchmark_runs_deterministic_fixtures(self):
        from enzo.cli import _cmd_benchmark

        class Args:
            repo              = self.tmpdir
            model             = "n/a"
            provider          = "groq"
            api_key           = ""
            deterministic_only = True
            compare           = None
            debug             = False

        printed = []
        with patch("builtins.print", side_effect=lambda *a: printed.append(str(a))):
            with patch("enzo.query.get_repo_db_path", return_value=self.fake_repo_db):
                _cmd_benchmark(Args())

        output = " ".join(printed)
        self.assertIn("SUMMARY", output)

    def test_benchmark_creates_enzo_db(self):
        from enzo.cli import _cmd_benchmark

        class Args:
            repo              = self.tmpdir
            model             = "n/a"
            provider          = "groq"
            api_key           = ""
            deterministic_only = True
            compare           = None
            debug             = False

        with patch("builtins.print"):
            with patch("enzo.query.get_repo_db_path", return_value=self.fake_repo_db):
                _cmd_benchmark(Args())

        self.assertTrue(self.fake_enzo_db.exists())

    def test_benchmark_all_deterministic_pass(self):
        from enzo.cli import _cmd_benchmark

        class Args:
            repo              = self.tmpdir
            model             = "n/a"
            provider          = "groq"
            api_key           = ""
            deterministic_only = True
            compare           = None
            debug             = False

        printed = []
        with patch("builtins.print", side_effect=lambda *a: printed.append(" ".join(str(x) for x in a))):
            with patch("enzo.query.get_repo_db_path", return_value=self.fake_repo_db):
                _cmd_benchmark(Args())

        output = "\n".join(printed)
        # Should show no failures in deterministic-only run
        self.assertNotIn("✗", output)


if __name__ == "__main__":
    unittest.main()
