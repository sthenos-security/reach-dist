#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.
"""Unit tests for enzo.patcher.cve_resolver."""

import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from enzo.patcher.cve_resolver import (
    CveResolver,
    _greatest_lower_bound,
    _no_fix_annotation,
    _parse_ai_recommendation,
    _partial_annotation,
)

# ── Fixtures ──────────────────────────────────────────────────────────────

CLEAN_GROUP = {
    "package": "requests",
    "ecosystem": "PyPI",
    "installed_version": "2.28.0",
    "cves": [
        {"id": "CVE-2023-32681", "fix_version": "2.31.0", "operator": ">=", "cvss": 6.1, "no_fix": False},
        {"id": "CVE-2024-35195", "fix_version": "2.32.2", "operator": ">=", "cvss": 5.6, "no_fix": False},
    ],
}

PRECOMPUTED_CLEAN = {
    **CLEAN_GROUP,
    "resolved_fix": "2.32.2",
    "resolution_status": "clean",
    "conflict_reason": None,
}

NO_FIX_GROUP = {
    "package": "abandoned-pkg",
    "ecosystem": "PyPI",
    "installed_version": "1.0.0",
    "cves": [
        {"id": "CVE-2020-99999", "fix_version": None, "operator": ">=", "cvss": 9.8, "no_fix": True},
    ],
}

PARTIAL_GROUP = {
    "package": "mixed-pkg",
    "ecosystem": "PyPI",
    "installed_version": "1.5.0",
    "cves": [
        {"id": "CVE-2023-FIXED",   "fix_version": "2.0.0",  "operator": ">=", "cvss": 7.0, "no_fix": False},
        {"id": "CVE-2024-UNFIXED", "fix_version": None,     "operator": ">=", "cvss": 5.0, "no_fix": True},
    ],
}


# ── Tests: greatest_lower_bound ───────────────────────────────────────────

class TestGreatestLowerBound(unittest.TestCase):
    def test_single_version(self):
        resolved, conflict = _greatest_lower_bound(
            ["2.31.0"], {"2.31.0": ">="}, "2.28.0"
        )
        self.assertEqual(resolved, "2.31.0")
        self.assertIsNone(conflict)

    def test_picks_max(self):
        resolved, conflict = _greatest_lower_bound(
            ["2.31.0", "2.32.2", "2.30.0"],
            {"2.31.0": ">=", "2.32.2": ">=", "2.30.0": ">="},
            "2.28.0"
        )
        self.assertEqual(resolved, "2.32.2")
        self.assertIsNone(conflict)

    def test_upper_bound_conflict(self):
        # >=3.0 conflicts with <3.0
        resolved, conflict = _greatest_lower_bound(
            ["3.0.0", "2.9.9"],
            {"3.0.0": ">=", "2.9.9": "<"},
            "2.8.0"
        )
        self.assertIsNone(resolved)
        self.assertIsNotNone(conflict)
        self.assertIn("conflict", conflict.lower())

    def test_empty_versions(self):
        resolved, conflict = _greatest_lower_bound([], {}, "1.0.0")
        self.assertIsNone(resolved)
        self.assertIsNotNone(conflict)

    def test_lexicographic_fallback(self):
        # packaging not available → lexicographic sort
        resolved, conflict = _greatest_lower_bound(
            ["1.10.0", "1.9.0"],
            {"1.10.0": ">=", "1.9.0": ">="},
            "1.0.0"
        )
        # Should pick 1.10.0 (lexicographic desc might give wrong result,
        # but packaging.version.Version will give correct semver order)
        self.assertIsNotNone(resolved)


# ── Tests: CveResolver.resolve_group ─────────────────────────────────────

class TestCveResolverResolveGroup(unittest.TestCase):
    def setUp(self):
        self.resolver = CveResolver()  # no AI caller

    def test_clean_resolution(self):
        result = self.resolver.resolve_group(CLEAN_GROUP)
        self.assertEqual(result.package, "requests")
        self.assertEqual(result.resolved_fix, "2.32.2")
        self.assertIn(result.resolution_status, ("clean",))
        self.assertEqual(result.action, "upgrade")

    def test_precomputed_clean_passthrough(self):
        result = self.resolver.resolve_group(PRECOMPUTED_CLEAN)
        self.assertEqual(result.resolved_fix, "2.32.2")
        self.assertEqual(result.resolution_status, "clean")

    def test_no_fix_status(self):
        result = self.resolver.resolve_group(NO_FIX_GROUP)
        self.assertEqual(result.resolution_status, "no_fix")
        self.assertEqual(result.action, "manual")
        self.assertIsNone(result.resolved_fix)

    def test_no_fix_annotation_present(self):
        result = self.resolver.resolve_group(NO_FIX_GROUP)
        self.assertIsNotNone(result.annotation)
        self.assertIn("REACHABLE_NO_FIX_UNAVAILABLE", result.annotation)

    def test_partial_fix(self):
        result = self.resolver.resolve_group(PARTIAL_GROUP)
        self.assertEqual(result.resolution_status, "partial")
        self.assertEqual(result.resolved_fix, "2.0.0")  # fixed the fixable one
        self.assertIn("REACHABLE_PARTIAL_FIX", result.annotation)

    def test_conflict_without_ai_is_manual(self):
        conflict_group = {
            "package": "tricky",
            "ecosystem": "PyPI",
            "installed_version": "2.8.0",
            "cves": [
                {"id": "CVE-A", "fix_version": "3.0.0", "operator": ">=", "cvss": 8.0, "no_fix": False},
                {"id": "CVE-B", "fix_version": "3.0.0", "operator": "<",  "cvss": 7.0, "no_fix": False},
            ],
        }
        result = self.resolver.resolve_group(conflict_group)
        self.assertEqual(result.resolution_status, "conflict")
        self.assertEqual(result.action, "manual")

    def test_cve_ids_preserved(self):
        result = self.resolver.resolve_group(CLEAN_GROUP)
        self.assertIn("CVE-2023-32681", result.cve_ids)
        self.assertIn("CVE-2024-35195", result.cve_ids)

    def test_empty_cves(self):
        group = {"package": "p", "ecosystem": "PyPI", "installed_version": "1.0", "cves": []}
        result = self.resolver.resolve_group(group)
        self.assertEqual(result.resolution_status, "no_fix")

    def test_is_actionable_clean(self):
        result = self.resolver.resolve_group(CLEAN_GROUP)
        self.assertTrue(result.is_actionable)

    def test_needs_human_no_fix(self):
        result = self.resolver.resolve_group(NO_FIX_GROUP)
        self.assertTrue(result.needs_human)


# ── Tests: AI fallback ────────────────────────────────────────────────────

class TestCveResolverAIFallback(unittest.TestCase):
    def _make_resolver(self, ai_response: str) -> CveResolver:
        def caller(system, prompt):
            return ai_response
        return CveResolver(model_caller=caller)

    def test_ai_upgrade_recommendation(self):
        resolver = self._make_resolver(
            '{"recommendation": "upgrade", "action": "upgrade", '
            '"version": "3.1.0", "rationale": "3.1 resolves both CVEs"}'
        )
        conflict_group = {
            "package": "pkg",
            "ecosystem": "PyPI",
            "installed_version": "2.0.0",
            "cves": [
                {"id": "CVE-A", "fix_version": "3.0.0", "operator": ">=", "cvss": 8.0, "no_fix": False},
                {"id": "CVE-B", "fix_version": "3.0.0", "operator": "<",  "cvss": 7.0, "no_fix": False},
            ],
        }
        result = resolver.resolve_group(conflict_group)
        self.assertEqual(result.action, "upgrade")
        self.assertEqual(result.resolved_fix, "3.1.0")
        self.assertIn("3.1 resolves", result.ai_rationale)

    def test_ai_replace_recommendation(self):
        resolver = self._make_resolver(
            '{"recommendation": "replace", "action": "replace", '
            '"version": null, "rationale": "use safe-pkg instead"}'
        )
        conflict_group = {
            "package": "pkg",
            "ecosystem": "PyPI",
            "installed_version": "1.0.0",
            "cves": [
                {"id": "CVE-A", "fix_version": "3.0.0", "operator": ">=", "cvss": 9.0, "no_fix": False},
                {"id": "CVE-B", "fix_version": "3.0.0", "operator": "<",  "cvss": 8.0, "no_fix": False},
            ],
        }
        result = resolver.resolve_group(conflict_group)
        self.assertEqual(result.action, "replace")
        self.assertIn("REACHABLE_REPLACE_PACKAGE", result.annotation)

    def test_ai_failure_falls_back_to_manual(self):
        def bad_caller(system, prompt):
            raise RuntimeError("network error")
        resolver = CveResolver(model_caller=bad_caller)
        conflict_group = {
            "package": "p", "ecosystem": "PyPI", "installed_version": "1.0",
            "cves": [
                {"id": "CVE-A", "fix_version": "3.0.0", "operator": ">=", "cvss": 8.0, "no_fix": False},
                {"id": "CVE-B", "fix_version": "3.0.0", "operator": "<",  "cvss": 7.0, "no_fix": False},
            ],
        }
        result = resolver.resolve_group(conflict_group)
        self.assertEqual(result.action, "manual")

    def test_ai_pin_adds_annotation(self):
        resolver = self._make_resolver(
            '{"recommendation": "pin", "action": "pin", '
            '"version": null, "rationale": "no safe upgrade path"}'
        )
        conflict_group = {
            "package": "p", "ecosystem": "PyPI", "installed_version": "1.0",
            "cves": [
                {"id": "CVE-A", "fix_version": "3.0.0", "operator": ">=", "cvss": 8.0, "no_fix": False},
                {"id": "CVE-B", "fix_version": "3.0.0", "operator": "<",  "cvss": 7.0, "no_fix": False},
            ],
        }
        result = resolver.resolve_group(conflict_group)
        self.assertEqual(result.action, "pin")
        self.assertIn("REACHABLE_REVIEW_REQUIRED", result.annotation)

    def test_ai_markdown_stripped(self):
        rec = _parse_ai_recommendation(
            '```json\n{"action": "upgrade", "version": "2.0.0", '
            '"rationale": "safe", "recommendation": "upgrade"}\n```'
        )
        self.assertEqual(rec["action"], "upgrade")


# ── Tests: from_finding fallback ─────────────────────────────────────────

class TestCveResolverFromFinding(unittest.TestCase):
    def test_fallback_with_fix_version(self):
        class MockFinding:
            package_name = "requests"
            package_version = "2.28.0"
            fix_version = "2.31.0"
            cve_id = "CVE-2023-32681"
            ecosystem = "PyPI"
            raw_data = None

        resolver = CveResolver()
        result = resolver.from_finding(MockFinding())
        self.assertEqual(result.resolution_status, "fallback")
        self.assertEqual(result.resolved_fix, "2.31.0")
        self.assertEqual(result.action, "upgrade")

    def test_fallback_no_fix_version(self):
        class MockFinding:
            package_name = "old-pkg"
            package_version = "0.1.0"
            fix_version = None
            cve_id = "CVE-2020-1"
            ecosystem = "PyPI"
            raw_data = None

        resolver = CveResolver()
        result = resolver.from_finding(MockFinding())
        self.assertEqual(result.action, "manual")

    def test_uses_cve_group_when_present(self):
        import json as _json
        class MockFinding:
            package_name = "requests"
            package_version = "2.28.0"
            fix_version = "2.31.0"
            cve_id = "CVE-2023-32681"
            ecosystem = "PyPI"
            raw_data = _json.dumps({"cve_group": PRECOMPUTED_CLEAN})

        resolver = CveResolver()
        result = resolver.from_finding(MockFinding())
        self.assertEqual(result.resolved_fix, "2.32.2")
        self.assertEqual(result.resolution_status, "clean")


# ── Tests: annotation builders ────────────────────────────────────────────

class TestAnnotationBuilders(unittest.TestCase):
    def test_no_fix_annotation_contains_pkg(self):
        ann = _no_fix_annotation("requests", "2.28.0", ["CVE-2023-99999"])
        self.assertIn("requests", ann)
        self.assertIn("CVE-2023-99999", ann)
        self.assertIn("REACHABLE_NO_FIX_UNAVAILABLE", ann)

    def test_no_fix_annotation_has_osv_link(self):
        ann = _no_fix_annotation("pkg", "1.0", ["CVE-2020-1"])
        self.assertIn("osv.dev", ann)

    def test_partial_annotation_contains_unfixed_ids(self):
        ann = _partial_annotation("pkg", ["CVE-2024-UNFIXED"])
        self.assertIn("CVE-2024-UNFIXED", ann)
        self.assertIn("REACHABLE_PARTIAL_FIX", ann)


if __name__ == "__main__":
    unittest.main()
