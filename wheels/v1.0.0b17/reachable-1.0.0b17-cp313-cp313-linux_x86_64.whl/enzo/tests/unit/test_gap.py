#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.
"""Unit tests for enzo.gap — two-bucket gap analysis engine."""

import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from enzo.gap import (
    REACHABLE,
    UNKNOWN,
    UNREACHABLE,
    GapAnalyser,
    ReachableFinding,
    _normalise_cwe,
    _paths_match,
    _severity_note,
)
from enzo.ingest.models import ExternalFinding

# ── Fixtures ──────────────────────────────────────────────────────────────

def make_reachable(
    finding_id="r1", finding_type="cve", severity="HIGH",
    package_name="requests", package_version="2.28.0",
    fix_version="2.31.0", cve_id="CVE-2023-32681", cwe_id=None,
    file_path=None, line_number=None,
    app_reachability=REACHABLE,
    fix_status="fix_available", ecosystem="PyPI",
) -> ReachableFinding:
    return ReachableFinding(
        finding_id=finding_id, finding_type=finding_type, severity=severity,
        package_name=package_name, package_version=package_version,
        fix_version=fix_version, cve_id=cve_id, cwe_id=cwe_id,
        file_path=file_path, line_number=line_number,
        app_reachability=app_reachability, fix_status=fix_status,
        ecosystem=ecosystem,
    )


def make_external(
    tool="dependabot", tool_finding_id="e1",
    finding_type="cve", severity="HIGH",
    package_name="requests", package_version="2.28.0",
    cve_ids=None, fix_version="2.31.0",
    cwe_ids=None, file_path=None, line_number=None,
) -> ExternalFinding:
    return ExternalFinding(
        tool=tool, tool_finding_id=tool_finding_id,
        finding_type=finding_type, severity=severity,
        package_name=package_name, package_version=package_version,
        cve_ids=cve_ids or ["CVE-2023-32681"],
        fix_version=fix_version, cwe_ids=cwe_ids or [],
        file_path=file_path, line_number=line_number,
    )


def run_analysis(reachable, external, enzo_fixed=None):
    a = GapAnalyser()
    a.set_reachable_findings(reachable)
    a.add_external(external)
    if enzo_fixed:
        a.set_enzo_fixed(enzo_fixed)
    return a.analyse()


# ── Tests: ReachableFinding.is_actionable ─────────────────────────────────

class TestReachableFindingActionable(unittest.TestCase):
    def test_reachable_is_actionable(self):
        r = make_reachable(app_reachability=REACHABLE)
        self.assertTrue(r.is_actionable)

    def test_unknown_is_actionable(self):
        r = make_reachable(app_reachability=UNKNOWN)
        self.assertTrue(r.is_actionable)

    def test_unreachable_not_actionable(self):
        r = make_reachable(app_reachability=UNREACHABLE)
        self.assertFalse(r.is_actionable)

    def test_unknown_needs_human_review(self):
        r = make_reachable(app_reachability=UNKNOWN)
        self.assertTrue(r.needs_human_reachability_review)

    def test_reachable_no_human_review(self):
        r = make_reachable(app_reachability=REACHABLE)
        self.assertFalse(r.needs_human_reachability_review)


# ── Tests: utility helpers ────────────────────────────────────────────────

class TestHelpers(unittest.TestCase):
    def test_normalise_cwe_with_prefix(self):
        self.assertEqual(_normalise_cwe("CWE-89"), "CWE-89")
        self.assertEqual(_normalise_cwe("cwe-089"), "CWE-89")
        self.assertEqual(_normalise_cwe("89"), "CWE-89")

    def test_paths_match_exact(self):
        self.assertTrue(_paths_match("api/users.py", "api/users.py"))

    def test_paths_match_absolute_vs_relative(self):
        self.assertTrue(_paths_match("api/users.py", "/home/al/repo/api/users.py"))

    def test_paths_match_basename(self):
        self.assertTrue(_paths_match("users.py", "/home/al/repo/api/users.py"))

    def test_paths_no_match(self):
        self.assertFalse(_paths_match("models.py", "views.py"))

    def test_paths_backslash_normalised(self):
        self.assertTrue(_paths_match("api\\users.py", "api/users.py"))

    def test_severity_note_reachable_upgraded(self):
        note = _severity_note("MEDIUM", "CRITICAL", REACHABLE)
        self.assertIn("confirmed executable", note)

    def test_severity_note_unknown(self):
        note = _severity_note("HIGH", "MEDIUM", UNKNOWN)
        self.assertIn("unknown", note)

    def test_severity_note_unreachable_downgraded(self):
        note = _severity_note("HIGH", "LOW", UNREACHABLE)
        self.assertIn("disproves reach", note)


# ── Tests: two-bucket routing ─────────────────────────────────────────────

class TestTwoBucketRouting(unittest.TestCase):
    """Core invariant: REACHABLE and UNKNOWN go into both buckets;
    UNREACHABLE goes only into raw (as noise)."""

    def test_reachable_in_both_buckets(self):
        r = make_reachable(app_reachability=REACHABLE)
        report = run_analysis([r], [make_external()])
        # actionable confirmed_open
        self.assertEqual(len(report.actionable.confirmed_open), 1)
        # raw confirmed_open too
        self.assertEqual(len(report.raw.confirmed_open), 1)
        # noise is empty in both
        self.assertEqual(len(report.actionable.noise), 0)
        self.assertEqual(len(report.raw.noise), 0)

    def test_unknown_in_both_buckets_as_unknown_open(self):
        r = make_reachable(app_reachability=UNKNOWN)
        report = run_analysis([r], [make_external()])
        self.assertEqual(len(report.actionable.unknown_open), 1)
        self.assertEqual(len(report.raw.unknown_open), 1)
        self.assertEqual(len(report.actionable.confirmed_open), 0)

    def test_unreachable_only_in_raw_noise(self):
        r = make_reachable(app_reachability=UNREACHABLE)
        report = run_analysis([r], [make_external()])
        # UNREACHABLE match → raw noise only; absent from actionable entirely
        # (actionable bucket has zero entries — the finding is excluded, not reclassified)
        self.assertEqual(len(report.actionable.noise), 0)
        self.assertEqual(len(report.actionable.external_only), 0)
        self.assertEqual(len(report.actionable.confirmed_open), 0)
        self.assertEqual(len(report.actionable.unknown_open), 0)
        # raw: noise
        self.assertEqual(len(report.raw.noise), 1)
        self.assertEqual(len(report.raw.external_only), 0)

    def test_unreachable_not_in_actionable_open(self):
        r = make_reachable(app_reachability=UNREACHABLE)
        report = run_analysis([r], [make_external()])
        self.assertEqual(len(report.actionable.confirmed_open), 0)
        self.assertEqual(len(report.actionable.unknown_open), 0)

    def test_unmatched_external_in_both_external_only(self):
        r = make_reachable(package_name="flask")
        ext = make_external(package_name="django", cve_ids=["CVE-2024-99999"])
        report = run_analysis([r], [ext])
        self.assertEqual(len(report.actionable.external_only), 1)
        self.assertEqual(len(report.raw.external_only), 1)

    def test_reachable_only_in_both_when_actionable(self):
        r = make_reachable(app_reachability=REACHABLE)
        report = run_analysis([r], [])
        self.assertEqual(len(report.actionable.reachable_only), 1)
        self.assertEqual(len(report.raw.reachable_only), 1)

    def test_unreachable_reachable_only_only_in_raw(self):
        r = make_reachable(app_reachability=UNREACHABLE)
        report = run_analysis([r], [])
        self.assertEqual(len(report.raw.reachable_only), 1)
        self.assertEqual(len(report.actionable.reachable_only), 0)

    def test_unknown_reachable_only_in_both(self):
        r = make_reachable(app_reachability=UNKNOWN)
        report = run_analysis([r], [])
        self.assertEqual(len(report.actionable.reachable_only), 1)
        self.assertEqual(len(report.raw.reachable_only), 1)


# ── Tests: enzo_fixed routing ─────────────────────────────────────────────

class TestEnzoFixed(unittest.TestCase):
    def test_reachable_fixed_in_both_auto_fixed(self):
        r = make_reachable(app_reachability=REACHABLE)
        report = run_analysis([r], [make_external()], enzo_fixed=["r1"])
        self.assertEqual(len(report.actionable.auto_fixed), 1)
        self.assertEqual(len(report.raw.auto_fixed), 1)
        self.assertEqual(len(report.actionable.confirmed_open), 0)

    def test_unknown_fixed_in_both_auto_fixed(self):
        r = make_reachable(app_reachability=UNKNOWN)
        report = run_analysis([r], [make_external()], enzo_fixed=["r1"])
        self.assertEqual(len(report.actionable.auto_fixed), 1)
        self.assertEqual(len(report.raw.auto_fixed), 1)

    def test_unreachable_fixed_only_in_raw_noise(self):
        # UNREACHABLE finding that enzo somehow patched → noise in raw, absent from actionable
        r = make_reachable(app_reachability=UNREACHABLE)
        report = run_analysis([r], [make_external()], enzo_fixed=["r1"])
        # UNREACHABLE routes to noise before enzo_fixed check in actionable path
        self.assertEqual(len(report.actionable.auto_fixed), 0)
        self.assertEqual(len(report.raw.noise), 1)  # UNREACHABLE → noise regardless


# ── Tests: severity disagreements ────────────────────────────────────────

class TestSeverityDisagreements(unittest.TestCase):
    def test_disagreement_in_both_buckets_for_reachable(self):
        r = make_reachable(severity="CRITICAL", app_reachability=REACHABLE)
        ext = make_external(severity="MEDIUM")
        report = run_analysis([r], [ext])
        self.assertEqual(len(report.actionable.severity_disagreements), 1)
        self.assertEqual(len(report.raw.severity_disagreements), 1)

    def test_disagreement_for_unknown(self):
        r = make_reachable(severity="HIGH", app_reachability=UNKNOWN)
        ext = make_external(severity="LOW")
        report = run_analysis([r], [ext])
        self.assertEqual(len(report.actionable.severity_disagreements), 1)

    def test_disagreement_note_populated(self):
        r = make_reachable(severity="CRITICAL", app_reachability=REACHABLE)
        ext = make_external(severity="MEDIUM")
        report = run_analysis([r], [ext])
        item = report.actionable.severity_disagreements[0]
        self.assertNotEqual(item.note, "")

    def test_disagreement_also_in_confirmed_open(self):
        # A severity disagreement is still an open finding — appears in confirmed_open too
        r = make_reachable(severity="CRITICAL", app_reachability=REACHABLE)
        ext = make_external(severity="MEDIUM")
        report = run_analysis([r], [ext])
        # Should appear in both severity_disagreements AND confirmed_open
        self.assertEqual(len(report.actionable.confirmed_open), 1)
        self.assertEqual(len(report.actionable.severity_disagreements), 1)

    def test_no_disagreement_when_severity_matches(self):
        r = make_reachable(severity="HIGH", app_reachability=REACHABLE)
        ext = make_external(severity="HIGH")
        report = run_analysis([r], [ext])
        self.assertEqual(len(report.actionable.severity_disagreements), 0)


# ── Tests: noise counting ─────────────────────────────────────────────────

class TestNoiseCounting(unittest.TestCase):
    def test_noise_count_on_bucket(self):
        r = make_reachable(app_reachability=UNREACHABLE)
        report = run_analysis([r], [make_external()])
        self.assertEqual(report.raw.noise_count, 1)
        self.assertEqual(report.actionable.noise_count, 0)

    def test_multiple_unreachable_noise(self):
        findings = [
            make_reachable(finding_id="r1", cve_id="CVE-1", app_reachability=UNREACHABLE),
            make_reachable(finding_id="r2", cve_id="CVE-2", app_reachability=UNREACHABLE),
            make_reachable(finding_id="r3", cve_id="CVE-3", app_reachability=REACHABLE),
        ]
        externals = [
            make_external(tool_finding_id="e1", cve_ids=["CVE-1"]),
            make_external(tool_finding_id="e2", cve_ids=["CVE-2"]),
            make_external(tool_finding_id="e3", cve_ids=["CVE-3"]),
        ]
        report = run_analysis(findings, externals)
        self.assertEqual(report.raw.noise_count, 2)
        self.assertEqual(report.actionable.noise_count, 0)
        self.assertEqual(len(report.actionable.confirmed_open), 1)


# ── Tests: tool_names ────────────────────────────────────────────────────

class TestToolNames(unittest.TestCase):
    def test_tool_names_collected(self):
        report = run_analysis(
            [make_reachable()],
            [make_external(tool="trivy"), make_external(tool_finding_id="e2", tool="dependabot")]
        )
        self.assertIn("trivy", report.tool_names)
        self.assertIn("dependabot", report.tool_names)

    def test_tool_names_sorted(self):
        report = run_analysis(
            [make_reachable()],
            [make_external(tool="trivy"), make_external(tool_finding_id="e2", tool="dependabot")]
        )
        self.assertEqual(report.tool_names, sorted(report.tool_names))


# ── Tests: GapReport.to_markdown ─────────────────────────────────────────

class TestMarkdown(unittest.TestCase):
    def test_has_both_bucket_headers(self):
        report = run_analysis([make_reachable()], [make_external()])
        md = report.to_markdown()
        self.assertIn("ACTIONABLE", md)
        self.assertIn("RAW", md)

    def test_unknown_explanation_present_when_unknown(self):
        r = make_reachable(app_reachability=UNKNOWN)
        report = run_analysis([r], [make_external()])
        md = report.to_markdown()
        self.assertIn("UNKNOWN", md)
        self.assertIn("human review", md.lower())

    def test_no_unknown_explanation_when_all_reachable(self):
        r = make_reachable(app_reachability=REACHABLE)
        report = run_analysis([r], [make_external()])
        md = report.to_markdown()
        # UNKNOWN explanation block should not appear when no UNKNOWN findings
        self.assertNotIn("What UNKNOWN means", md)

    def test_noise_banner_present_when_unreachable(self):
        r = make_reachable(app_reachability=UNREACHABLE)
        report = run_analysis([r], [make_external()])
        md = report.to_markdown()
        self.assertIn("noise", md.lower())

    def test_noise_section_in_raw_not_actionable(self):
        r = make_reachable(app_reachability=UNREACHABLE)
        report = run_analysis([r], [make_external()])
        md = report.to_markdown()
        self.assertIn("UNREACHABLE", md)
        self.assertIn("excluded from the Actionable", md)

    def test_empty_report_no_crash(self):
        report = run_analysis([], [])
        md = report.to_markdown()
        self.assertIsInstance(md, str)

    def test_auto_fixed_section_present(self):
        r = make_reachable(app_reachability=REACHABLE)
        report = run_analysis([r], [make_external()], enzo_fixed=["r1"])
        md = report.to_markdown()
        self.assertIn("Auto-fixed by Enzo", md)

    def test_external_only_mentions_scanner_gap(self):
        r = make_reachable(package_name="flask")
        ext = make_external(package_name="django", cve_ids=["CVE-2024-x"])
        report = run_analysis([r], [ext])
        md = report.to_markdown()
        self.assertIn("scanner gap", md.lower())

    def test_reachable_only_mentions_false_negative(self):
        report = run_analysis([make_reachable()], [])
        md = report.to_markdown()
        self.assertIn("false negative", md.lower())

    def test_matching_annotates_external_finding(self):
        r = make_reachable(app_reachability=REACHABLE)
        ext = make_external()
        report = run_analysis([r], [ext])
        # After analysis, ext should have been annotated
        all_ext = (
            [i.external for i in report.actionable.confirmed_open] +
            [i.external for i in report.raw.confirmed_open]
        )
        self.assertTrue(any(e.reachable_finding_id == "r1" for e in all_ext))

    def test_unknown_open_section_header(self):
        r = make_reachable(app_reachability=UNKNOWN)
        report = run_analysis([r], [make_external()])
        md = report.to_markdown()
        self.assertIn("UNKNOWN reachability", md)


if __name__ == "__main__":
    unittest.main()
