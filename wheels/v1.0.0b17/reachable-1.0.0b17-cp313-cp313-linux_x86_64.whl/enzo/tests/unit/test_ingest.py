#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.
"""Unit tests for enzo.ingest — all four normalizers + ExternalFinding model."""

import json
import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from enzo.ingest import ExternalFinding, load_tool, normalise_severity
from enzo.ingest import codeql as _codeql
from enzo.ingest import dependabot as _dep
from enzo.ingest import osv_scanner as _osv
from enzo.ingest import trivy as _trivy

# ── Fixtures ──────────────────────────────────────────────────────────────

DEPENDABOT_ALERT = {
    "number": 42,
    "state": "open",
    "security_advisory": {
        "ghsa_id": "GHSA-j8r2-6x86-q33q",
        "cve_id": "CVE-2023-32681",
        "summary": "Requests forwards proxy-auth to destination servers",
        "description": "Since Requests 2.3.0, Proxies-Authorization header is not stripped.",
        "severity": "medium",
        "cvss": {"score": 6.1, "vector_string": "CVSS:3.1/AV:N/AC:H/PR:N/UI:N/S:C/C:H/I:N/A:N"},
        "cwes": [{"cwe_id": "CWE-601", "name": "URL Redirection to Untrusted Site"}],
    },
    "security_vulnerability": {
        "package": {"ecosystem": "pip", "name": "requests"},
        "severity": "medium",
        "vulnerable_version_range": ">= 2.3.0, < 2.31.0",
        "first_patched_version": {"identifier": "2.31.0"},
    },
}

DEPENDABOT_DISMISSED = {**DEPENDABOT_ALERT, "number": 43, "state": "dismissed"}

SARIF_CODEQL = {
    "$schema": "https://json.schemastore.org/sarif-2.1.0.json",
    "version": "2.1.0",
    "runs": [{
        "tool": {
            "driver": {
                "name": "CodeQL",
                "version": "2.15.0",
                "rules": [{
                    "id": "py/sql-injection",
                    "name": "SqlInjection",
                    "shortDescription": {"text": "SQL injection"},
                    "properties": {
                        "id": "py/sql-injection",
                        "kind": "path-problem",
                        "problem.severity": "error",
                        "security-severity": "8.8",
                        "precision": "high",
                        "tags": ["security", "external/cwe/cwe-089", "external/cwe/cwe-943"],
                    }
                }]
            }
        },
        "results": [{
            "ruleId": "py/sql-injection",
            "message": {"text": "User-controlled input flows to SQL query."},
            "level": "error",
            "locations": [{
                "physicalLocation": {
                    "artifactLocation": {"uri": "api/users.py", "uriBaseId": "%SRCROOT%"},
                    "region": {"startLine": 47, "startColumn": 5, "endColumn": 42},
                }
            }],
            "partialFingerprints": {"primaryLocationLineHash": "a3f9e2b1:1"},
        }]
    }]
}

TRIVY_NATIVE_JSON = {
    "Results": [{
        "Target": "requirements.txt",
        "Type": "pip",
        "Vulnerabilities": [{
            "VulnerabilityID": "CVE-2023-32681",
            "PkgName": "requests",
            "InstalledVersion": "2.28.0",
            "FixedVersion": "2.31.0",
            "Severity": "MEDIUM",
            "Title": "Requests forwards proxy-auth",
            "Description": "Proxy-Authorization not stripped.",
            "CVSS": {
                "nvd": {"V3Score": 6.1},
            },
        }],
    }]
}

TRIVY_WITH_MISCONF = {
    "Results": [{
        "Target": "Dockerfile",
        "Type": "dockerfile",
        "Class": "config",
        "Misconfigurations": [{
            "ID": "DS002",
            "Title": "Image user should not be 'root'",
            "Description": "Running containers as root is a security risk.",
            "Severity": "HIGH",
            "References": ["https://cwe.mitre.org/data/definitions/CWE-250.html"],
        }]
    }]
}

OSV_JSON = {
    "results": [{
        "source": {"path": "requirements.txt", "type": "lockfile"},
        "packages": [{
            "package": {"name": "requests", "version": "2.28.0", "ecosystem": "PyPI"},
            "vulnerabilities": [{
                "id": "GHSA-j8r2-6x86-q33q",
                "aliases": ["CVE-2023-32681"],
                "summary": "Requests forwards proxy-auth",
                "details": "Proxy-Authorization header is not stripped on redirect.",
                "severity": [{"type": "CVSS_V3", "score": "6.1"}],
                "affected": [{
                    "package": {"name": "requests", "ecosystem": "PyPI"},
                    "ranges": [{
                        "type": "ECOSYSTEM",
                        "events": [{"introduced": "2.3.0"}, {"fixed": "2.31.0"}],
                    }],
                    "versions": ["2.28.0"],
                }],
            }],
            "groups": [{
                "ids": ["GHSA-j8r2-6x86-q33q"],
                "aliases": ["CVE-2023-32681"],
                "max_severity": "6.1",
            }],
        }]
    }]
}


# ── Tests: ExternalFinding model ──────────────────────────────────────────

class TestExternalFindingModel(unittest.TestCase):
    def test_basic_construction(self):
        f = ExternalFinding(
            tool="test", tool_finding_id="t1",
            finding_type="cve", severity="HIGH",
            cve_ids=["CVE-2023-1234"],
        )
        self.assertEqual(f.primary_cve, "CVE-2023-1234")
        self.assertIsNone(f.primary_cwe)

    def test_primary_cwe(self):
        f = ExternalFinding(
            tool="test", tool_finding_id="t2",
            finding_type="cwe", severity="MEDIUM",
            cwe_ids=["CWE-89", "CWE-943"],
        )
        self.assertEqual(f.primary_cwe, "CWE-89")

    def test_to_dict_keys(self):
        f = ExternalFinding(
            tool="t", tool_finding_id="x",
            finding_type="cve", severity="LOW",
        )
        d = f.to_dict()
        required_keys = {"tool", "tool_finding_id", "finding_type", "severity",
                         "cve_ids", "cwe_ids", "match_confidence", "match_method"}
        self.assertTrue(required_keys.issubset(d.keys()))

    def test_to_dict_no_raw(self):
        f = ExternalFinding(tool="t", tool_finding_id="x",
                            finding_type="cve", severity="LOW", raw={"big": "object"})
        d = f.to_dict()
        self.assertNotIn("raw", d)  # raw not exported


class TestNormaliseSeverity(unittest.TestCase):
    def test_canonical_strings(self):
        self.assertEqual(normalise_severity("critical"), "CRITICAL")
        self.assertEqual(normalise_severity("HIGH"), "HIGH")
        self.assertEqual(normalise_severity("medium"), "MEDIUM")
        self.assertEqual(normalise_severity("moderate"), "MEDIUM")
        self.assertEqual(normalise_severity("low"), "LOW")
        self.assertEqual(normalise_severity("info"), "INFO")

    def test_cvss_bands(self):
        self.assertEqual(normalise_severity("", 9.8), "CRITICAL")
        self.assertEqual(normalise_severity("", 7.5), "HIGH")
        self.assertEqual(normalise_severity("", 5.3), "MEDIUM")
        self.assertEqual(normalise_severity("", 2.1), "LOW")
        self.assertEqual(normalise_severity("", 0.0), "INFO")

    def test_cvss_overrides_string(self):
        # CVSS score provided: string says "unknown", score says CRITICAL
        self.assertEqual(normalise_severity("unknown", 9.5), "CRITICAL")

    def test_fallback(self):
        self.assertEqual(normalise_severity(""), "MEDIUM")
        self.assertEqual(normalise_severity("garbage"), "MEDIUM")


# ── Tests: Dependabot ─────────────────────────────────────────────────────

class TestDependabotNormalizer(unittest.TestCase):
    def setUp(self):
        self.findings = _dep.load([DEPENDABOT_ALERT])

    def test_loads_open_alert(self):
        self.assertEqual(len(self.findings), 1)

    def test_skips_dismissed(self):
        findings = _dep.load([DEPENDABOT_DISMISSED])
        self.assertEqual(len(findings), 0)

    def test_tool_name(self):
        self.assertEqual(self.findings[0].tool, "dependabot")

    def test_finding_type_is_cve(self):
        self.assertEqual(self.findings[0].finding_type, "cve")

    def test_cve_ids_extracted(self):
        f = self.findings[0]
        self.assertIn("CVE-2023-32681", f.cve_ids)

    def test_ghsa_alias_included(self):
        f = self.findings[0]
        self.assertIn("GHSA-j8r2-6x86-q33q", f.cve_ids)

    def test_package_name(self):
        self.assertEqual(self.findings[0].package_name, "requests")

    def test_fix_version(self):
        self.assertEqual(self.findings[0].fix_version, "2.31.0")

    def test_ecosystem_normalised(self):
        self.assertEqual(self.findings[0].ecosystem, "PyPI")

    def test_cwe_extracted(self):
        f = self.findings[0]
        self.assertTrue(any("601" in c for c in f.cwe_ids))

    def test_severity_medium(self):
        self.assertEqual(self.findings[0].severity, "MEDIUM")

    def test_title_not_empty(self):
        self.assertTrue(len(self.findings[0].title) > 0)

    def test_load_single_dict(self):
        findings = _dep.load(DEPENDABOT_ALERT)
        self.assertEqual(len(findings), 1)

    def test_load_from_json_string(self):
        findings = _dep.load(json.dumps([DEPENDABOT_ALERT]))
        self.assertEqual(len(findings), 1)


# ── Tests: CodeQL SARIF ───────────────────────────────────────────────────

class TestCodeQLNormalizer(unittest.TestCase):
    def setUp(self):
        self.findings = _codeql.load(SARIF_CODEQL)

    def test_loads_one_finding(self):
        self.assertEqual(len(self.findings), 1)

    def test_tool_set_to_codeql(self):
        self.assertEqual(self.findings[0].tool, "codeql")

    def test_finding_type_cwe(self):
        self.assertEqual(self.findings[0].finding_type, "cwe")

    def test_cwe_ids_from_tags(self):
        f = self.findings[0]
        self.assertIn("CWE-89", f.cwe_ids)
        self.assertIn("CWE-943", f.cwe_ids)

    def test_file_path(self):
        self.assertEqual(self.findings[0].file_path, "api/users.py")

    def test_line_number(self):
        self.assertEqual(self.findings[0].line_number, 47)

    def test_severity_high_from_cvss(self):
        # security-severity: 8.8 → HIGH
        self.assertEqual(self.findings[0].severity, "HIGH")

    def test_rule_id(self):
        self.assertEqual(self.findings[0].rule_id, "py/sql-injection")

    def test_title_from_shortdesc(self):
        self.assertEqual(self.findings[0].title, "SQL injection")

    def test_fingerprint_as_finding_id(self):
        self.assertIn("a3f9e2b1", self.findings[0].tool_finding_id)

    def test_empty_sarif(self):
        findings = _codeql.load({"version": "2.1.0", "runs": []})
        self.assertEqual(len(findings), 0)

    def test_sarif_with_no_rules(self):
        sarif = {
            "version": "2.1.0",
            "runs": [{
                "tool": {"driver": {"name": "test", "rules": []}},
                "results": [{
                    "ruleId": "UNKNOWN-001",
                    "message": {"text": "something"},
                    "level": "warning",
                    "locations": [{
                        "physicalLocation": {
                            "artifactLocation": {"uri": "app.py"},
                            "region": {"startLine": 10},
                        }
                    }],
                }]
            }]
        }
        findings = _codeql.load(sarif)
        self.assertEqual(len(findings), 1)
        self.assertEqual(findings[0].severity, "MEDIUM")  # level=warning


# ── Tests: Trivy ──────────────────────────────────────────────────────────

class TestTrivyNormalizer(unittest.TestCase):
    def test_native_json_cve(self):
        findings = _trivy.load(TRIVY_NATIVE_JSON, fmt="json")
        self.assertEqual(len(findings), 1)
        f = findings[0]
        self.assertEqual(f.tool, "trivy")
        self.assertEqual(f.package_name, "requests")
        self.assertEqual(f.package_version, "2.28.0")
        self.assertEqual(f.fix_version, "2.31.0")
        self.assertIn("CVE-2023-32681", f.cve_ids)
        self.assertEqual(f.finding_type, "cve")

    def test_native_json_misconf(self):
        findings = _trivy.load(TRIVY_WITH_MISCONF, fmt="json")
        self.assertEqual(len(findings), 1)
        f = findings[0]
        self.assertEqual(f.finding_type, "config")
        self.assertEqual(f.severity, "HIGH")
        self.assertIn("CWE-250", f.cwe_ids)

    def test_sarif_format(self):
        findings = _trivy.load(SARIF_CODEQL, fmt="sarif")
        self.assertEqual(len(findings), 1)
        self.assertEqual(findings[0].tool, "trivy")

    def test_auto_detect_native(self):
        findings = _trivy.load(TRIVY_NATIVE_JSON)
        self.assertEqual(len(findings), 1)

    def test_auto_detect_sarif(self):
        findings = _trivy.load(SARIF_CODEQL)
        self.assertEqual(len(findings), 1)
        self.assertEqual(findings[0].tool, "trivy")

    def test_ecosystem_from_type(self):
        findings = _trivy.load(TRIVY_NATIVE_JSON, fmt="json")
        self.assertEqual(findings[0].ecosystem, "PyPI")

    def test_cvss_extracted(self):
        findings = _trivy.load(TRIVY_NATIVE_JSON, fmt="json")
        self.assertEqual(findings[0].severity, "MEDIUM")

    def test_empty_results(self):
        findings = _trivy.load({"Results": []})
        self.assertEqual(len(findings), 0)


# ── Tests: OSV-Scanner ────────────────────────────────────────────────────

class TestOSVScannerNormalizer(unittest.TestCase):
    def setUp(self):
        self.findings = _osv.load(OSV_JSON)

    def test_loads_one_finding(self):
        self.assertEqual(len(self.findings), 1)

    def test_tool_name(self):
        self.assertEqual(self.findings[0].tool, "osv")

    def test_package_name(self):
        self.assertEqual(self.findings[0].package_name, "requests")

    def test_package_version(self):
        self.assertEqual(self.findings[0].package_version, "2.28.0")

    def test_ecosystem(self):
        self.assertEqual(self.findings[0].ecosystem, "PyPI")

    def test_cve_ids_include_alias(self):
        f = self.findings[0]
        all_ids = f.cve_ids
        self.assertTrue(any("GHSA" in i or "CVE" in i for i in all_ids))

    def test_fix_version_extracted(self):
        self.assertEqual(self.findings[0].fix_version, "2.31.0")

    def test_severity_from_score(self):
        # 6.1 CVSS → MEDIUM
        self.assertEqual(self.findings[0].severity, "MEDIUM")

    def test_alias_deduplication(self):
        # GHSA + CVE alias should appear, not duplicated
        f = self.findings[0]
        self.assertEqual(len(set(f.cve_ids)), len(f.cve_ids))

    def test_no_groups_fallback(self):
        data = {
            "results": [{
                "source": {"path": "requirements.txt", "type": "lockfile"},
                "packages": [{
                    "package": {"name": "flask", "version": "1.0.0", "ecosystem": "PyPI"},
                    "vulnerabilities": [{
                        "id": "GHSA-abc-123",
                        "aliases": ["CVE-2021-12345"],
                        "summary": "Flask XSS",
                        "severity": [{"type": "CVSS_V3", "score": "7.5"}],
                        "affected": [{
                            "package": {"name": "flask", "ecosystem": "PyPI"},
                            "ranges": [{"type": "ECOSYSTEM",
                                        "events": [{"introduced": "0"}, {"fixed": "2.0.0"}]}],
                        }],
                    }],
                    # No "groups" key
                }]
            }]
        }
        findings = _osv.load(data)
        self.assertEqual(len(findings), 1)
        self.assertEqual(findings[0].package_name, "flask")

    def test_load_from_json_string(self):
        findings = _osv.load(json.dumps(OSV_JSON))
        self.assertEqual(len(findings), 1)


# ── Tests: load_tool dispatch ─────────────────────────────────────────────

class TestLoadToolDispatch(unittest.TestCase):
    def test_dependabot_dispatch(self):
        findings = load_tool("dependabot", [DEPENDABOT_ALERT])
        self.assertEqual(len(findings), 1)
        self.assertEqual(findings[0].tool, "dependabot")

    def test_codeql_dispatch(self):
        findings = load_tool("codeql", SARIF_CODEQL)
        self.assertEqual(len(findings), 1)

    def test_trivy_dispatch(self):
        findings = load_tool("trivy", TRIVY_NATIVE_JSON, fmt="json")
        self.assertEqual(len(findings), 1)

    def test_osv_dispatch(self):
        findings = load_tool("osv", OSV_JSON)
        self.assertEqual(len(findings), 1)

    def test_semgrep_alias(self):
        findings = load_tool("semgrep", SARIF_CODEQL)
        self.assertEqual(len(findings), 1)

    def test_unknown_tool_raises(self):
        with self.assertRaises(ValueError) as ctx:
            load_tool("snyk", {})
        self.assertIn("snyk", str(ctx.exception))


if __name__ == "__main__":
    unittest.main()
