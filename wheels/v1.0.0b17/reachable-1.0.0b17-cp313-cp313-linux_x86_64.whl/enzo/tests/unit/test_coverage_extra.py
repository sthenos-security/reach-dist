#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.
"""
Additional coverage tests for:
  - gap.GapAnalyser.load_reachable_findings() (SQL path with real sqlite3 DB)
  - _cmd_ingest and _cmd_gap_analysis body logic (temp file I/O)
  - CLI subcommand parse coverage (new commands + dlp_patch filter)
  - Ingest edge cases (Trivy CVSS extraction, OSV multi-range, Dependabot version range)
  - CodeQL CWE extraction from rule ID
  - CveResolver packaging version algebra edge cases
  - Gap _classify_into combined severity disagreement + open bucket
"""
from __future__ import annotations

import argparse
import json
import os
import sqlite3
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from enzo.gap import (
    REACHABLE,
    UNKNOWN,
    UNREACHABLE,
    GapAnalyser,
    GapBucket,
    ReachableFinding,
    _classify_into,
)
from enzo.ingest import codeql as _codeql
from enzo.ingest import trivy as _trivy
from enzo.ingest.models import ExternalFinding
from enzo.patcher.cve_resolver import (
    CveResolver,
    _greatest_lower_bound,
)

# ── Helpers ───────────────────────────────────────────────────────────────

def make_reachable(finding_id="r1", severity="HIGH",
                   cve_id="CVE-2023-1", package_name="pkg",
                   package_version="1.0.0", fix_version="2.0.0",
                   app_reachability=REACHABLE) -> ReachableFinding:
    return ReachableFinding(
        finding_id=finding_id, finding_type="cve", severity=severity,
        package_name=package_name, package_version=package_version,
        fix_version=fix_version, cve_id=cve_id,
        app_reachability=app_reachability,
    )


def make_external(tool_finding_id="e1", severity="HIGH",
                  cve_ids=None, package_name="pkg",
                  package_version="1.0.0") -> ExternalFinding:
    return ExternalFinding(
        tool="trivy", tool_finding_id=tool_finding_id,
        finding_type="cve", severity=severity,
        cve_ids=cve_ids or ["CVE-2023-1"],
        package_name=package_name, package_version=package_version,
    )


def _make_repo_db(findings: list) -> str:
    """Create a temp repo.db with a findings table. Returns path."""
    fd, path = tempfile.mkstemp(suffix=".db")
    os.close(fd)
    conn = sqlite3.connect(path)
    conn.execute("""
        CREATE TABLE findings (
            finding_id TEXT, finding_type TEXT, severity TEXT,
            package_name TEXT, package_version TEXT, fix_version TEXT,
            cve_id TEXT, cwe_id TEXT, file_path TEXT, line_number INTEGER,
            app_reachability TEXT, description TEXT, fix_status TEXT, ecosystem TEXT
        )
    """)
    for f in findings:
        conn.execute(
            "INSERT INTO findings VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
            (f.finding_id, f.finding_type, f.severity,
             f.package_name, f.package_version, f.fix_version,
             f.cve_id, f.cwe_id, f.file_path, f.line_number,
             f.app_reachability, f.description, f.fix_status, f.ecosystem)
        )
    conn.commit()
    conn.close()
    return path


# ── Tests: GapAnalyser.load_reachable_findings() SQL path ────────────────

class TestGapAnalyserDB(unittest.TestCase):
    def setUp(self):
        self.findings = [
            make_reachable("r1", app_reachability=REACHABLE),
            make_reachable("r2", cve_id="CVE-2024-2", package_name="flask",
                           app_reachability=UNKNOWN),
            make_reachable("r3", cve_id="CVE-2025-3", package_name="django",
                           app_reachability=UNREACHABLE),
        ]
        self.db_path = _make_repo_db(self.findings)

    def tearDown(self):
        os.unlink(self.db_path)

    def test_loads_all_findings(self):
        a = GapAnalyser(db_path=self.db_path)
        count = a.load_reachable_findings()
        self.assertEqual(count, 3)

    def test_reachability_preserved(self):
        a = GapAnalyser(db_path=self.db_path)
        a.load_reachable_findings()
        states = {f.finding_id: f.app_reachability for f in a._reachable}
        self.assertEqual(states["r1"], REACHABLE)
        self.assertEqual(states["r2"], UNKNOWN)
        self.assertEqual(states["r3"], UNREACHABLE)

    def test_no_db_path_raises(self):
        a = GapAnalyser()
        with self.assertRaises(ValueError):
            a.load_reachable_findings()

    def test_missing_db_returns_zero(self):
        # Use a path inside a nonexistent directory to trigger OperationalError at connect()
        import os
        import tempfile
        bad_path = os.path.join(tempfile.gettempdir(),
                                "enzo_test_nonexistent_dir_xyz", "repo.db")
        a = GapAnalyser(db_path=bad_path)
        count = a.load_reachable_findings()
        self.assertEqual(count, 0)

    def test_full_analysis_via_db(self):
        """End-to-end: load from DB, add external, analyse."""
        a = GapAnalyser(db_path=self.db_path)
        a.load_reachable_findings()
        a.add_external([
            make_external("e1", cve_ids=["CVE-2023-1"]),   # matches r1 REACHABLE
            make_external("e2", cve_ids=["CVE-2024-2"], package_name="flask"),  # matches r2 UNKNOWN
            make_external("e3", cve_ids=["CVE-2025-3"], package_name="django"), # matches r3 UNREACHABLE
        ])
        report = a.analyse()
        self.assertEqual(len(report.actionable.confirmed_open), 1)
        self.assertEqual(len(report.actionable.unknown_open), 1)
        self.assertEqual(len(report.raw.noise), 1)
        self.assertEqual(len(report.actionable.noise), 0)

    def test_enzo_fixed_loaded_from_enzo_db(self):
        """Simulate enzo.db existing alongside repo.db with fixed findings."""
        enzo_db_path = self.db_path.replace(".db", "_enzo.db")
        conn = sqlite3.connect(enzo_db_path)
        conn.execute("""CREATE TABLE remediation_attempts
                        (finding_id TEXT, status TEXT)""")
        conn.execute("INSERT INTO remediation_attempts VALUES ('r1', 'success')")
        conn.commit()
        conn.close()

        try:
            a = GapAnalyser(db_path=self.db_path)
            a.load_reachable_findings()
            a.set_enzo_fixed(["r1"])
            a.add_external([make_external("e1", cve_ids=["CVE-2023-1"])])
            report = a.analyse()
            self.assertEqual(len(report.actionable.auto_fixed), 1)
            self.assertEqual(len(report.actionable.confirmed_open), 0)
        finally:
            os.unlink(enzo_db_path)


# ── Tests: _cmd_ingest body ───────────────────────────────────────────────

class TestCmdIngestBody(unittest.TestCase):
    """Test _cmd_ingest with real temp files."""

    DEPENDABOT_DATA = [{
        "number": 1, "state": "open",
        "security_advisory": {
            "ghsa_id": "GHSA-test-0001",
            "cve_id": "CVE-2023-32681",
            "summary": "Test advisory",
            "severity": "high",
            "cwes": [],
        },
        "security_vulnerability": {
            "package": {"ecosystem": "pip", "name": "requests"},
            "severity": "high",
            "vulnerable_version_range": ">= 2.0.0, < 2.31.0",
            "first_patched_version": {"identifier": "2.31.0"},
        },
    }]

    def setUp(self):
        self.tmpdir = tempfile.mkdtemp()
        self.input_file = os.path.join(self.tmpdir, "alerts.json")
        Path(self.input_file).write_text(json.dumps(self.DEPENDABOT_DATA))

    def tearDown(self):
        import shutil
        shutil.rmtree(self.tmpdir, ignore_errors=True)

    def test_ingest_loads_and_prints(self):
        from enzo.cli import _cmd_ingest

        class Args:
            repo = self.tmpdir
            tool = "dependabot"
            file = self.input_file
            fmt  = None

        with patch('builtins.print') as mock_print:
            _cmd_ingest(Args())

        output = " ".join(str(c) for c in mock_print.call_args_list)
        self.assertIn("1 findings", output)
        self.assertIn("dependabot", output)

    def test_ingest_saves_raw_file(self):
        from enzo.cli import _cmd_ingest

        class Args:
            repo = self.tmpdir
            tool = "dependabot"
            file = self.input_file
            fmt  = None

        with patch('builtins.print'):
            _cmd_ingest(Args())

        ingest_dir = Path(self.tmpdir) / ".reachable" / "ingest"
        self.assertTrue(ingest_dir.exists())
        saved = list(ingest_dir.iterdir())
        self.assertEqual(len(saved), 1)
        self.assertTrue(saved[0].name.startswith("dependabot-"))

    def test_ingest_bad_file_prints_error(self):
        from enzo.cli import _cmd_ingest

        class Args:
            repo = self.tmpdir
            tool = "dependabot"
            file = "/nonexistent/file.json"
            fmt  = None

        printed = []
        with patch('builtins.print', side_effect=lambda *a: printed.append(str(a))):
            _cmd_ingest(Args())

        self.assertTrue(any("Failed" in p or "Error" in p or "error" in p.lower()
                            for p in printed))

    def test_ingest_empty_findings_prints_message(self):
        from enzo.cli import _cmd_ingest
        # All dismissed → no open findings
        dismissed = [{**self.DEPENDABOT_DATA[0], "state": "dismissed"}]
        empty_file = os.path.join(self.tmpdir, "empty.json")
        Path(empty_file).write_text(json.dumps(dismissed))

        class Args:
            repo = self.tmpdir
            tool = "dependabot"
            file = empty_file
            fmt  = None

        printed = []
        with patch('builtins.print', side_effect=lambda *a: printed.append(str(a))):
            _cmd_ingest(Args())

        self.assertTrue(any("No actionable" in p for p in printed))


# ── Tests: _cmd_gap_analysis body ────────────────────────────────────────

class TestCmdGapAnalysisBody(unittest.TestCase):
    def setUp(self):
        self.tmpdir = tempfile.mkdtemp()
        self.db_path = _make_repo_db([
            make_reachable("r1", app_reachability=REACHABLE)
        ])
        # Copy to expected location inside tmpdir
        import shutil
        scan_dir = Path(self.tmpdir) / ".reachable" / "scans" / Path(self.tmpdir).name
        scan_dir.mkdir(parents=True)
        self.repo_db = str(scan_dir / "repo.db")
        shutil.copy(self.db_path, self.repo_db)

        # Write a dependabot ingest file
        alert = [{
            "number": 1, "state": "open",
            "security_advisory": {
                "ghsa_id": "GHSA-x", "cve_id": "CVE-2023-1",
                "summary": "test", "severity": "high", "cwes": [],
            },
            "security_vulnerability": {
                "package": {"ecosystem": "pip", "name": "pkg"},
                "severity": "high",
                "vulnerable_version_range": "< 2.0.0",
                "first_patched_version": {"identifier": "2.0.0"},
            },
        }]
        ingest_dir = Path(self.tmpdir) / ".reachable" / "ingest"
        ingest_dir.mkdir(parents=True)
        (ingest_dir / "dependabot-20260304.json").write_text(json.dumps(alert))

    def tearDown(self):
        import shutil
        shutil.rmtree(self.tmpdir, ignore_errors=True)
        os.unlink(self.db_path)

    def test_gap_analysis_to_stdout(self):
        from enzo.cli import _cmd_gap_analysis

        class Args:
            repo    = self.tmpdir
            scan_id = None
            since   = None
            output  = None

        printed = []
        with patch('builtins.print', side_effect=lambda *a: printed.append(str(a))):
            # Patch get_repo_db_path to return our db
            with patch('enzo.query.get_repo_db_path', return_value=Path(self.repo_db)):
                _cmd_gap_analysis(Args())

        output = " ".join(printed)
        # Should have produced gap report content
        self.assertTrue(
            any(kw in output for kw in
                ["ACTIONABLE", "RAW", "Gap Analysis", "No ingested", "scanner gap"])
        )

    def test_gap_analysis_to_file(self):
        from enzo.cli import _cmd_gap_analysis
        out_file = os.path.join(self.tmpdir, "report.md")

        class Args:
            repo    = self.tmpdir
            scan_id = None
            since   = None
            output  = out_file

        with patch('builtins.print'):
            with patch('enzo.query.get_repo_db_path', return_value=Path(self.repo_db)):
                _cmd_gap_analysis(Args())

        self.assertTrue(Path(out_file).exists())
        content = Path(out_file).read_text()
        self.assertIn("Gap Analysis", content)

    def test_gap_analysis_no_db(self):
        from enzo.cli import _cmd_gap_analysis

        class Args:
            repo    = self.tmpdir
            scan_id = None
            since   = None
            output  = None

        printed = []
        with patch('builtins.print', side_effect=lambda *a: printed.append(str(a))):
            with patch('enzo.query.get_repo_db_path',
                       return_value=Path(self.tmpdir) / "nonexistent.db"):
                _cmd_gap_analysis(Args())

        self.assertTrue(any("No scan data" in p or "scan" in p.lower()
                            for p in printed))

    def test_gap_analysis_no_ingest_files(self):
        import shutil

        from enzo.cli import _cmd_gap_analysis
        ingest_dir = Path(self.tmpdir) / ".reachable" / "ingest"
        shutil.rmtree(ingest_dir)

        class Args:
            repo    = self.tmpdir
            scan_id = None
            since   = None
            output  = None

        printed = []
        with patch('builtins.print', side_effect=lambda *a: printed.append(str(a))):
            with patch('enzo.query.get_repo_db_path', return_value=Path(self.repo_db)):
                _cmd_gap_analysis(Args())

        self.assertTrue(any("No ingested" in p for p in printed))


# ── Tests: CLI parse coverage ─────────────────────────────────────────────

class TestCLIParseNewCommands(unittest.TestCase):
    def setUp(self):
        from enzo.cli import _build_subparsers
        self.parser = argparse.ArgumentParser()
        sub = self.parser.add_subparsers(dest="command")
        _build_subparsers(sub)

    def test_ingest_required_args(self):
        args = self.parser.parse_args([
            "ingest", "--tool", "codeql", "--file", "results.sarif"
        ])
        self.assertEqual(args.tool, "codeql")
        self.assertEqual(args.file, "results.sarif")
        self.assertIsNone(args.fmt)

    def test_ingest_with_fmt(self):
        args = self.parser.parse_args([
            "ingest", "--tool", "trivy", "--file", "trivy.json", "--fmt", "json"
        ])
        self.assertEqual(args.fmt, "json")

    def test_ingest_all_tool_choices(self):
        for tool in ["dependabot", "codeql", "semgrep", "bandit", "trivy", "osv"]:
            args = self.parser.parse_args(["ingest", "--tool", tool, "--file", "f"])
            self.assertEqual(args.tool, tool)

    def test_ingest_invalid_tool_rejected(self):
        import io
        with self.assertRaises(SystemExit), \
             patch("sys.stderr", io.StringIO()):
            self.parser.parse_args(["ingest", "--tool", "snyk", "--file", "f"])

    def test_gap_analysis_defaults(self):
        args = self.parser.parse_args(["gap-analysis"])
        self.assertIsNone(args.since)
        self.assertIsNone(args.output)
        self.assertIsNone(args.scan_id)

    def test_gap_analysis_all_args(self):
        args = self.parser.parse_args([
            "gap-analysis", "/repo", "--scan-id", "5",
            "--since", "14d", "--output", "out.md"
        ])
        self.assertEqual(args.scan_id, 5)
        self.assertEqual(args.since, "14d")
        self.assertEqual(args.output, "out.md")

    def test_scan_dlp_patch_filter(self):
        args = self.parser.parse_args(["scan", "--fix-type", "dlp_patch"])
        self.assertEqual(args.fix_type, "dlp_patch")

    def test_all_subcommands_registered(self):
        # Verify no command was accidentally dropped during edits
        from enzo.cli import _build_subparsers
        p2 = argparse.ArgumentParser()
        sub2 = p2.add_subparsers(dest="command")
        _build_subparsers(sub2)
        cmds = set(sub2.choices.keys())
        expected = {
            "setup", "scan", "fix", "run", "status", "pentest",
            "metrics", "benchmark", "report", "ingest", "gap-analysis", "knowledge",
            "selftest"
        }
        self.assertEqual(cmds, expected)

    def test_ingest_func_is_cmd_ingest(self):
        args = self.parser.parse_args(["ingest", "--tool", "osv", "--file", "f"])
        from enzo.cli import _cmd_ingest
        self.assertEqual(args.func, _cmd_ingest)

    def test_gap_analysis_func_is_cmd_gap_analysis(self):
        args = self.parser.parse_args(["gap-analysis"])
        from enzo.cli import _cmd_gap_analysis
        self.assertEqual(args.func, _cmd_gap_analysis)


# ── Tests: ingest edge cases ──────────────────────────────────────────────

class TestTrivyCVSSExtraction(unittest.TestCase):
    def test_v3_preferred_over_v2(self):
        vuln = {
            "VulnerabilityID": "CVE-2023-1",
            "PkgName": "pkg", "InstalledVersion": "1.0",
            "Severity": "HIGH",
            "CVSS": {
                "nvd": {"V2Score": 5.0, "V3Score": 8.5},
            }
        }
        data = {"Results": [{"Target": "req.txt", "Type": "pip",
                              "Vulnerabilities": [vuln]}]}
        findings = _trivy.load(data, fmt="json")
        # 8.5 → HIGH (not MEDIUM from V2 5.0)
        self.assertEqual(findings[0].severity, "HIGH")

    def test_missing_cvss_uses_severity_string(self):
        vuln = {
            "VulnerabilityID": "CVE-2023-2",
            "PkgName": "pkg", "InstalledVersion": "1.0",
            "Severity": "CRITICAL",
        }
        data = {"Results": [{"Target": "req.txt", "Type": "pip",
                              "Vulnerabilities": [vuln]}]}
        findings = _trivy.load(data, fmt="json")
        self.assertEqual(findings[0].severity, "CRITICAL")

    def test_empty_cvss_block_falls_back(self):
        vuln = {
            "VulnerabilityID": "CVE-2023-3",
            "PkgName": "pkg", "InstalledVersion": "1.0",
            "Severity": "MEDIUM",
            "CVSS": {}
        }
        data = {"Results": [{"Target": "req.txt", "Type": "pip",
                              "Vulnerabilities": [vuln]}]}
        findings = _trivy.load(data, fmt="json")
        self.assertEqual(findings[0].severity, "MEDIUM")

    def test_no_fix_version_is_none(self):
        vuln = {
            "VulnerabilityID": "CVE-2023-4",
            "PkgName": "pkg", "InstalledVersion": "1.0",
            "Severity": "HIGH",
            # No FixedVersion key
        }
        data = {"Results": [{"Target": "req.txt", "Type": "pip",
                              "Vulnerabilities": [vuln]}]}
        findings = _trivy.load(data, fmt="json")
        self.assertIsNone(findings[0].fix_version)


class TestOSVFixVersionExtraction(unittest.TestCase):
    def test_single_range(self):
        from enzo.ingest.osv_scanner import _extract_fix_version
        vuln = {"affected": [{"package": {"ecosystem": "PyPI"},
                               "ranges": [{"type": "ECOSYSTEM",
                                           "events": [{"introduced": "0"},
                                                      {"fixed": "2.31.0"}]}]}]}
        self.assertEqual(_extract_fix_version(vuln, "2.28.0", "PyPI"), "2.31.0")

    def test_multiple_ranges_picks_min_above_installed(self):
        from enzo.ingest.osv_scanner import _extract_fix_version
        vuln = {"affected": [{"package": {"ecosystem": "PyPI"},
                               "ranges": [{"type": "ECOSYSTEM",
                                           "events": [{"introduced": "1.0"},
                                                      {"fixed": "1.5.0"},
                                                      {"introduced": "2.0"},
                                                      {"fixed": "2.3.0"}]}]}]}
        # installed 2.1.0 → min fix above it is 2.3.0
        result = _extract_fix_version(vuln, "2.1.0", "PyPI")
        self.assertEqual(result, "2.3.0")

    def test_git_range_ignored(self):
        from enzo.ingest.osv_scanner import _extract_fix_version
        vuln = {"affected": [{"package": {"ecosystem": "Go"},
                               "ranges": [{"type": "GIT",
                                           "events": [{"introduced": "abc"},
                                                      {"fixed": "def"}]}]}]}
        # GIT ranges should be ignored; no ECOSYSTEM/SEMVER range → None
        result = _extract_fix_version(vuln, "1.0.0", "Go")
        self.assertIsNone(result)

    def test_no_ranges_returns_none(self):
        from enzo.ingest.osv_scanner import _extract_fix_version
        vuln = {"affected": [{"package": {}}]}
        self.assertIsNone(_extract_fix_version(vuln, "1.0.0", "PyPI"))


class TestDependabotVersionRangeExtraction(unittest.TestCase):
    def test_equality_range_extracted(self):
        from enzo.ingest.dependabot import _extract_installed_version
        alert = {}
        self.assertEqual(_extract_installed_version(alert, "= 2.28.0"), "2.28.0")

    def test_inequality_range_returns_none(self):
        from enzo.ingest.dependabot import _extract_installed_version
        alert = {}
        self.assertIsNone(_extract_installed_version(alert, ">= 2.0.0, < 2.31.0"))

    def test_empty_range_returns_none(self):
        from enzo.ingest.dependabot import _extract_installed_version
        self.assertIsNone(_extract_installed_version({}, ""))


class TestCodeQLCWEFromRuleID(unittest.TestCase):
    def test_cwe_extracted_from_rule_id(self):
        """Rule ID contains CWE — should extract even with no tags."""
        rule = {"id": "CWE-089-sql-injection", "properties": {"tags": []}}
        cwe_ids = _codeql._extract_cwe_ids(rule)
        self.assertIn("CWE-89", cwe_ids)

    def test_cwe_from_tags_takes_priority(self):
        rule = {
            "id": "py/sql-injection",
            "properties": {"tags": ["external/cwe/cwe-089", "external/cwe/cwe-943"]}
        }
        cwe_ids = _codeql._extract_cwe_ids(rule)
        self.assertIn("CWE-89", cwe_ids)
        self.assertIn("CWE-943", cwe_ids)

    def test_no_cwe_returns_empty(self):
        rule = {"id": "py/unused-variable", "properties": {"tags": ["maintainability"]}}
        self.assertEqual(_codeql._extract_cwe_ids(rule), [])

    def test_no_duplicate_when_id_and_tag_agree(self):
        rule = {
            "id": "CWE-089-sqli",
            "properties": {"tags": ["external/cwe/cwe-089"]}
        }
        cwe_ids = _codeql._extract_cwe_ids(rule)
        self.assertEqual(cwe_ids.count("CWE-89"), 1)


# ── Tests: CveResolver version algebra edge cases ─────────────────────────

class TestVersionAlgebraEdgeCases(unittest.TestCase):
    def test_three_cves_picks_max(self):
        resolved, conflict = _greatest_lower_bound(
            ["2.31.0", "2.32.2", "2.30.0"],
            {"2.31.0": ">=", "2.32.2": ">=", "2.30.0": ">="},
            "2.28.0"
        )
        self.assertEqual(resolved, "2.32.2")
        self.assertIsNone(conflict)

    def test_installed_equals_fix_still_resolves(self):
        # installed == fix_version → upgrade is technically "to latest patch"
        resolved, conflict = _greatest_lower_bound(
            ["2.31.0"], {"2.31.0": ">="}, "2.31.0"
        )
        self.assertEqual(resolved, "2.31.0")
        self.assertIsNone(conflict)

    def test_prerelease_versions_handled(self):
        # packaging handles pre-releases; shouldn't crash
        resolved, conflict = _greatest_lower_bound(
            ["2.0.0rc1", "1.9.9"],
            {"2.0.0rc1": ">=", "1.9.9": ">="},
            "1.8.0"
        )
        self.assertIsNotNone(resolved)

    def test_conflict_string_describes_constraint(self):
        _, conflict = _greatest_lower_bound(
            ["3.0.0", "3.0.0"],
            {"3.0.0": ">=", "3.0.0": "<"},  # noqa: F601
            "2.0.0"
        )
        # Upper bound conflicts with lower bound
        self.assertIsNotNone(conflict)

    def test_resolver_clean_group_multiple_cves(self):
        group = {
            "package": "urllib3",
            "ecosystem": "PyPI",
            "installed_version": "1.26.0",
            "cves": [
                {"id": "CVE-A", "fix_version": "1.26.5", "operator": ">=",
                 "cvss": 7.5, "no_fix": False},
                {"id": "CVE-B", "fix_version": "1.26.7", "operator": ">=",
                 "cvss": 6.1, "no_fix": False},
                {"id": "CVE-C", "fix_version": "1.26.4", "operator": ">=",
                 "cvss": 5.0, "no_fix": False},
            ]
        }
        result = CveResolver().resolve_group(group)
        self.assertEqual(result.resolved_fix, "1.26.7")
        self.assertEqual(result.resolution_status, "clean")
        self.assertEqual(result.action, "upgrade")
        self.assertEqual(len(result.cve_ids), 3)

    def test_resolver_partial_all_unfixable(self):
        group = {
            "package": "abandoned",
            "ecosystem": "PyPI",
            "installed_version": "0.1.0",
            "cves": [
                {"id": "CVE-X", "fix_version": None, "operator": ">=",
                 "cvss": 9.8, "no_fix": True},
                {"id": "CVE-Y", "fix_version": None, "operator": ">=",
                 "cvss": 8.0, "no_fix": True},
            ]
        }
        result = CveResolver().resolve_group(group)
        self.assertEqual(result.resolution_status, "no_fix")
        self.assertIsNone(result.resolved_fix)
        ann = result.annotation
        self.assertIn("CVE-X", ann)
        self.assertIn("CVE-Y", ann)


# ── Tests: _classify_into combined sections ───────────────────────────────

class TestClassifyIntoCombined(unittest.TestCase):
    """Verify _classify_into puts disagreements in BOTH the severity
    table AND the appropriate open section simultaneously."""

    def _bucket(self) -> GapBucket:
        return GapBucket("test")

    def test_sev_disagreement_reachable_also_in_confirmed_open(self):
        bucket = self._bucket()
        reach = make_reachable("r1", severity="CRITICAL",
                               app_reachability=REACHABLE)
        ext   = make_external("e1", severity="MEDIUM")
        _classify_into(bucket, ext, reach, enzo_fixed=False)
        self.assertEqual(len(bucket.severity_disagreements), 1)
        self.assertEqual(len(bucket.confirmed_open), 1)
        self.assertEqual(len(bucket.unknown_open), 0)

    def test_sev_disagreement_unknown_also_in_unknown_open(self):
        bucket = self._bucket()
        reach = make_reachable("r1", severity="HIGH",
                               app_reachability=UNKNOWN)
        ext   = make_external("e1", severity="LOW")
        _classify_into(bucket, ext, reach, enzo_fixed=False)
        self.assertEqual(len(bucket.severity_disagreements), 1)
        self.assertEqual(len(bucket.unknown_open), 1)
        self.assertEqual(len(bucket.confirmed_open), 0)

    def test_no_disagreement_not_in_severity_table(self):
        bucket = self._bucket()
        reach = make_reachable("r1", severity="HIGH",
                               app_reachability=REACHABLE)
        ext   = make_external("e1", severity="HIGH")
        _classify_into(bucket, ext, reach, enzo_fixed=False)
        self.assertEqual(len(bucket.severity_disagreements), 0)
        self.assertEqual(len(bucket.confirmed_open), 1)

    def test_unreachable_goes_to_noise_not_open(self):
        bucket = self._bucket()
        reach = make_reachable("r1", app_reachability=UNREACHABLE)
        ext   = make_external("e1")
        _classify_into(bucket, ext, reach, enzo_fixed=False)
        self.assertEqual(len(bucket.noise), 1)
        self.assertEqual(len(bucket.confirmed_open), 0)
        self.assertEqual(len(bucket.unknown_open), 0)
        self.assertEqual(len(bucket.severity_disagreements), 0)

    def test_enzo_fixed_skips_open_buckets(self):
        bucket = self._bucket()
        reach = make_reachable("r1", severity="CRITICAL",
                               app_reachability=REACHABLE)
        ext   = make_external("e1", severity="HIGH")
        _classify_into(bucket, ext, reach, enzo_fixed=True)
        self.assertEqual(len(bucket.auto_fixed), 1)
        self.assertEqual(len(bucket.confirmed_open), 0)
        self.assertEqual(len(bucket.severity_disagreements), 0)


# ── Tests: GapReport markdown edge cases ─────────────────────────────────

class TestGapReportMarkdownEdgeCases(unittest.TestCase):
    def _run(self, reachable, external, enzo_fixed=None):
        a = GapAnalyser()
        a.set_reachable_findings(reachable)
        a.add_external(external)
        if enzo_fixed:
            a.set_enzo_fixed(enzo_fixed)
        return a.analyse()

    def test_noise_banner_shows_percentage(self):
        findings = [
            make_reachable("r1", cve_id="CVE-1", app_reachability=UNREACHABLE),
            make_reachable("r2", cve_id="CVE-2", app_reachability=REACHABLE),
        ]
        externals = [
            make_external("e1", cve_ids=["CVE-1"]),
            make_external("e2", cve_ids=["CVE-2"]),
        ]
        report = self._run(findings, externals)
        md = report.to_markdown()
        self.assertIn("noise rate", md)
        self.assertIn("%", md)

    def test_unknown_explanation_only_once(self):
        findings = [
            make_reachable("r1", cve_id="CVE-1", app_reachability=UNKNOWN),
            make_reachable("r2", cve_id="CVE-2", app_reachability=UNKNOWN),
        ]
        externals = [
            make_external("e1", cve_ids=["CVE-1"]),
            make_external("e2", cve_ids=["CVE-2"]),
        ]
        report = self._run(findings, externals)
        md = report.to_markdown()
        # Explanation text should appear (at least once)
        self.assertIn("What UNKNOWN means", md)

    def test_multiple_tools_all_in_tool_names(self):
        report = self._run(
            [make_reachable()],
            [
                make_external(tool_finding_id="e1"),
                ExternalFinding(tool="osv", tool_finding_id="e2",
                                finding_type="cve", severity="HIGH",
                                cve_ids=["CVE-9999"], package_name="other"),
            ]
        )
        self.assertIn("trivy", report.tool_names)
        self.assertIn("osv", report.tool_names)

    def test_separator_between_buckets(self):
        report = self._run([make_reachable()], [make_external()])
        md = report.to_markdown()
        self.assertIn("---", md)


if __name__ == "__main__":
    unittest.main()
