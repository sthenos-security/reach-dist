#!/usr/bin/env python3
"""
Unit tests for deterministic patcher.
No model required. Always fast. Run on every PR.

Tests:
  - secret_rotation: Python AST path
  - secret_rotation: Python regex fallback
  - secret_rotation: Go
  - secret_rotation: TypeScript/JavaScript
  - dependency_upgrade: requirements.txt
  - dependency_upgrade: package.json
  - dependency_upgrade: go.mod
  - dependency_upgrade: pom.xml
  - malware_stub: Python import removal
  - malware_stub: JavaScript require removal
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent.parent.parent))

import ast as pyast
import unittest

from enzo.patcher.deterministic import try_deterministic

FIXTURES = Path(__file__).parent.parent / "fixtures"


class TestSecretRotationPython(unittest.TestCase):

    def _run(self, fixture_file: str, line: int, secret_type: str,
             secret_value: str = "") -> object:
        content = (FIXTURES / fixture_file).read_text()
        return try_deterministic(
            fix_type="secret_rotation",
            file_path=fixture_file,
            file_content=content,
            line_number=line,
            finding_metadata={"secret_type": secret_type, "secret_value": secret_value},
        )

    def test_python_ast_api_key(self):
        """Python AST path: API_KEY = 'hardcoded' → os.environ.get(...)"""
        r = self._run(
            "python/secret_api_key.py", line=9,
            secret_type="api_key",
            secret_value="sk-prod-a3f7c9d2e1b4f8a2c6d9e3b7f1a4c8d2e5f"
        )
        self.assertTrue(r.success, f"Failed: {r.error}")
        self.assertIn("os.environ.get", r.patched_content)
        self.assertNotIn("sk-prod-a3f7c9d2e1b4f8a2c6d9e3b7f1a4c8d2e5f", r.patched_content)
        self.assertIn("REACHABLE_SECRET_CHANGE_ME", r.patched_content)
        self.assertIn("API_KEY", r.patched_content)
        self.assertEqual(r.tokens_used, 0)
        self.assertEqual(r.cost_usd, 0.0)
        # Patched file must still parse
        pyast.parse(r.patched_content)

    def test_python_db_password(self):
        """Python regex path: DB_PASSWORD = 'hardcoded' → os.environ.get(...)"""
        r = self._run(
            "python/secret_db_password.py", line=6,
            secret_type="db_password",
            secret_value="prod-db-p@ssw0rd-2026"
        )
        self.assertTrue(r.success, f"Failed: {r.error}")
        self.assertIn("os.environ.get", r.patched_content)
        self.assertNotIn("prod-db-p@ssw0rd-2026", r.patched_content)
        self.assertIn("REACHABLE_SECRET_CHANGE_ME", r.patched_content)
        self.assertIn("DB_PASSWORD", r.patched_content)

    def test_python_secret_not_on_wrong_line(self):
        """Should fail gracefully on wrong line number."""
        content = (FIXTURES / "python/secret_api_key.py").read_text()
        r = try_deterministic(
            fix_type="secret_rotation",
            file_path="secret_api_key.py",
            file_content=content,
            line_number=999,
            finding_metadata={"secret_type": "api_key"},
        )
        self.assertFalse(r.success)


class TestSecretRotationGo(unittest.TestCase):

    def test_go_bearer_token(self):
        """Go: const bearerToken = 'hardcoded' → os.Getenv(...)"""
        content = (FIXTURES / "go/secret_token.go").read_text()
        r = try_deterministic(
            fix_type="secret_rotation",
            file_path="secret_token.go",
            file_content=content,
            line_number=8,
            finding_metadata={
                "secret_type": "token",
                "secret_value": "ghp_a3f7c9d2e1b4f8a2c6d9e3b7f1a4c8d2e5f"
            },
        )
        self.assertTrue(r.success, f"Failed: {r.error}")
        self.assertIn("os.Getenv", r.patched_content)
        self.assertNotIn("ghp_a3f7c9d2e1b4f8a2c6d9e3b7f1a4c8d2e5f", r.patched_content)
        self.assertIn("REACHABLE_SECRET_CHANGE_ME", r.patched_content)
        self.assertEqual(r.tokens_used, 0)


class TestSecretRotationTypeScript(unittest.TestCase):

    def test_ts_jwt_secret(self):
        """TypeScript: const JWT_SECRET = 'hardcoded' → process.env.JWT_SECRET || placeholder"""
        content = (FIXTURES / "typescript/secret_jwt.ts").read_text()
        r = try_deterministic(
            fix_type="secret_rotation",
            file_path="secret_jwt.ts",
            file_content=content,
            line_number=6,
            finding_metadata={
                "secret_type": "jwt_secret",
                "secret_value": "my-super-secret-jwt-key-do-not-share"
            },
        )
        self.assertTrue(r.success, f"Failed: {r.error}")
        self.assertIn("process.env", r.patched_content)
        self.assertNotIn("my-super-secret-jwt-key-do-not-share", r.patched_content)
        self.assertIn("REACHABLE_SECRET_CHANGE_ME", r.patched_content)
        self.assertEqual(r.tokens_used, 0)


class TestDependencyUpgrade(unittest.TestCase):

    def test_requirements_txt(self):
        """requirements.txt: requests==2.28.0 → requests==2.32.3"""
        content = (FIXTURES / "python/requirements.txt").read_text()
        r = try_deterministic(
            fix_type="dependency_upgrade",
            file_path="requirements.txt",
            file_content=content,
            line_number=2,
            finding_metadata={
                "package_name": "requests",
                "current_version": "2.28.0",
                "fix_version": "2.32.3",
                "ecosystem": "pip",
            },
        )
        self.assertTrue(r.success, f"Failed: {r.error}")
        self.assertIn("requests==2.32.3", r.patched_content)
        self.assertNotIn("requests==2.28.0", r.patched_content)
        # Other deps unchanged
        self.assertIn("flask==2.3.2", r.patched_content)
        self.assertEqual(r.tokens_used, 0)

    def test_package_json(self):
        """package.json: lodash 4.17.20 → 4.17.21"""
        content = (FIXTURES / "typescript/package.json").read_text()
        r = try_deterministic(
            fix_type="dependency_upgrade",
            file_path="package.json",
            file_content=content,
            line_number=6,
            finding_metadata={
                "package_name": "lodash",
                "current_version": "4.17.20",
                "fix_version": "4.17.21",
                "ecosystem": "npm",
            },
        )
        self.assertTrue(r.success, f"Failed: {r.error}")
        self.assertIn("4.17.21", r.patched_content)
        self.assertNotIn("4.17.20", r.patched_content)
        # Other deps unchanged
        self.assertIn("express", r.patched_content)
        self.assertEqual(r.tokens_used, 0)

    def test_pom_xml(self):
        """pom.xml: commons-collections 3.2.1 → 3.2.2"""
        content = (FIXTURES / "java/pom.xml").read_text()
        r = try_deterministic(
            fix_type="dependency_upgrade",
            file_path="pom.xml",
            file_content=content,
            line_number=0,
            finding_metadata={
                "package_name": "commons-collections",
                "current_version": "3.2.1",
                "fix_version": "3.2.2",
                "ecosystem": "maven",
            },
        )
        self.assertTrue(r.success, f"Failed: {r.error}")
        self.assertIn("3.2.2", r.patched_content)
        self.assertNotIn("<version>3.2.1</version>", r.patched_content)
        # Other deps unchanged
        self.assertIn("spring-core", r.patched_content)

    def test_go_mod(self):
        """go.mod: golang.org/x/crypto version bump"""
        content = (FIXTURES / "go/go.mod").read_text()
        r = try_deterministic(
            fix_type="dependency_upgrade",
            file_path="go.mod",
            file_content=content,
            line_number=0,
            finding_metadata={
                "package_name": "golang.org/x/crypto",
                "current_version": "v0.0.0-20220214200702-86341886e292",
                "fix_version": "v0.17.0",
                "ecosystem": "go",
            },
        )
        self.assertTrue(r.success, f"Failed: {r.error}")
        self.assertIn("v0.17.0", r.patched_content)
        self.assertNotIn("v0.0.0-20220214200702-86341886e292", r.patched_content)


class TestMalwareStub(unittest.TestCase):

    def test_python_import_removal(self):
        """Python: remove malicious import + stub call sites"""
        content = (FIXTURES / "malware/cryptominer.py").read_text()
        r = try_deterministic(
            fix_type="malware",
            file_path="cryptominer.py",
            file_content=content,
            line_number=4,
            finding_metadata={
                "package_name": "colourama",
                "guarddog_sig": "typosquatting:colorama",
            },
        )
        self.assertTrue(r.success, f"Failed: {r.error}")
        # Import must be gone (replaced with comment)
        # import line becomes a REACHABLE_REMOVED comment — check it is gone as active code
        self.assertNotIn("\nimport colourama\n", r.patched_content)
        self.assertIn("REACHABLE_REMOVED", r.patched_content)
        # Call sites stubbed
        self.assertIn("REACHABLE_STUB", r.patched_content)
        self.assertEqual(r.tokens_used, 0)

    def test_js_require_removal(self):
        """JavaScript: remove malicious require + stub call sites"""
        content = (FIXTURES / "malware/exfil.js").read_text()
        r = try_deterministic(
            fix_type="malware",
            file_path="exfil.js",
            file_content=content,
            line_number=4,
            finding_metadata={
                "package_name": "telnets",
                "guarddog_sig": "exfiltration:network",
            },
        )
        self.assertTrue(r.success, f"Failed: {r.error}")
        # require line becomes a REACHABLE_REMOVED comment
        self.assertNotIn("\nconst telnets = require(", r.patched_content)
        self.assertIn("REACHABLE_REMOVED", r.patched_content)
        self.assertEqual(r.tokens_used, 0)

    def test_malware_no_package_name_fails_gracefully(self):
        """Should fail gracefully when package_name is missing."""
        r = try_deterministic(
            fix_type="malware",
            file_path="any.py",
            file_content="import something\n",
            line_number=1,
            finding_metadata={},
        )
        self.assertFalse(r.success)
        self.assertIn("no package_name", r.error)


class TestDeterministicLogMethod(unittest.TestCase):
    """verify DeterministicResult.log() doesn't raise"""

    def test_success_log(self):
        from enzo.patcher.deterministic import DeterministicResult
        r = DeterministicResult(success=True, method="test method")
        r.log("test-finding-id")  # should not raise

    def test_failure_log(self):
        from enzo.patcher.deterministic import DeterministicResult
        r = DeterministicResult(success=False, error="test error")
        r.log("test-finding-id")  # should not raise


if __name__ == "__main__":
    unittest.main(verbosity=2)
