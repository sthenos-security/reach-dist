#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.
"""
Smoke test for EnzoKnowledgeDB.

Exercises: learn → query → cache → export → import → stats
"""

import json
import os
import sys
import tempfile
from pathlib import Path

# Ensure enzo package is importable when run from any directory
_tests_dir = os.path.dirname(os.path.abspath(__file__))
_enzo_root = os.path.dirname(os.path.dirname(_tests_dir))
if _enzo_root not in sys.path:
    sys.path.insert(0, _enzo_root)

from enzo.knowledge import EnzoKnowledgeDB, _normalise_error, _normalise_version  # noqa: E402


def main():
    with tempfile.TemporaryDirectory() as tmpdir:
        db_path = Path(tmpdir) / "knowledge.db"
        kb = EnzoKnowledgeDB(db_path)

        print("=" * 70)
        print("ENZO KNOWLEDGE DB — SMOKE TEST")
        print("=" * 70)

        # ── 1. Learn from attempts ───────────────────────────────────

        print("\n1. Learning from remediation attempts...")

        # Successful CWE-89 fix in Flask
        for i in range(12):
            kb.learn_from_attempt(
                finding_type="cwe", cwe_id="CWE-89",
                language="python", framework="flask", ecosystem="pip",
                fix_type="code_patch", strategy="parameterized_query",
                strategy_detail="Use sqlalchemy.text() with bound parameters",
                success=True, attempts_taken=1,
                rescan_passed=True, build_passed=True, test_passed=True,
                model_name="qwen2.5-coder:32b", model_role="local",
                latency_ms=2500.0,
            )

        # 2 failures for same pattern
        for i in range(2):
            kb.learn_from_attempt(
                finding_type="cwe", cwe_id="CWE-89",
                language="python", framework="flask", ecosystem="pip",
                fix_type="code_patch", strategy="parameterized_query",
                success=False, attempts_taken=2,
                rescan_passed=True, build_passed=True, test_passed=False,
                test_error="AssertionError: expected 3 rows, got 0 — query changed behavior",
                model_name="qwen2.5-coder:32b", model_role="local",
            )

        # Successful lodash upgrade
        for i in range(8):
            kb.learn_from_attempt(
                finding_type="cve", language="javascript", ecosystem="npm",
                fix_type="dependency_upgrade", strategy="version_bump",
                success=True, attempts_taken=1,
                package_name="lodash", from_version="4.17.15", to_version="4.17.21",
                rescan_passed=True, build_passed=True, test_passed=True,
                model_name="deterministic", model_role="local",
                latency_ms=100.0,
            )

        # Failed urllib3 major upgrade
        kb.learn_from_attempt(
            finding_type="cve", language="python", ecosystem="pip",
            fix_type="dependency_upgrade", strategy="version_bump",
            success=False, attempts_taken=2,
            package_name="urllib3", from_version="1.26.18", to_version="2.0.7",
            rescan_passed=True, build_passed=False, test_passed=None,
            build_error="ImportError: cannot import name 'HTTPResponse' from 'urllib3.response' "
                       "(/home/user/venv/lib/python3.11/site-packages/urllib3/response.py)",
            model_name="qwen2.5-coder:32b", model_role="local",
        )

        # Successful React XSS fix
        for i in range(23):
            kb.learn_from_attempt(
                finding_type="cwe", cwe_id="CWE-79",
                language="javascript", framework="react", ecosystem="npm",
                fix_type="code_patch", strategy="dompurify_sanitize",
                strategy_detail="Wrap dangerouslySetInnerHTML with DOMPurify.sanitize()",
                success=True, attempts_taken=1,
                model_name="qwen2.5-coder:32b", model_role="local",
            )
        for i in range(2):
            kb.learn_from_attempt(
                finding_type="cwe", cwe_id="CWE-79",
                language="javascript", framework="react", ecosystem="npm",
                fix_type="code_patch", strategy="dompurify_sanitize",
                success=False, attempts_taken=1,
                build_error="Module not found: Error: Can't resolve 'dompurify'",
                model_name="qwen2.5-coder:32b", model_role="local",
            )

        # Cloud model hybrid success
        for i in range(5):
            kb.learn_from_attempt(
                finding_type="cwe", cwe_id="CWE-502",
                language="python", framework="django", ecosystem="pip",
                fix_type="code_patch", strategy="safe_deserialization",
                strategy_detail="Replace pickle.loads with json.loads; use hmac for signed data",
                success=True, attempts_taken=1,
                model_name="claude-sonnet-4-5", model_role="cloud",
            )

        print("   ✓ Recorded 53 attempts across 5 patterns")

        # ── 2. Query fix hints ───────────────────────────────────────

        print("\n2. Querying fix hints...")

        hints = kb.get_fix_hints(cwe_id="CWE-89", language="python", framework="flask")
        assert len(hints) > 0, "Should find CWE-89 hints"
        h = hints[0]
        total = h["success_count"] + h["failure_count"]
        rate = h["success_count"] / total if total > 0 else 0
        print(f"   CWE-89/python/flask: '{h['strategy']}' — {h['success_count']}/{total} ({rate:.0%})")
        print(f"   Avg attempts to success: {h['avg_attempts']}")
        assert h["success_count"] == 12
        assert h["failure_count"] == 2
        print("   ✓ Fix pattern counters correct")

        best = kb.get_best_strategy(cwe_id="CWE-79", language="javascript", framework="react")
        assert best is not None
        _ratio = f"{best['success_count']}/{best['success_count']+best['failure_count']}"
        print(f"   CWE-79/react best: '{best['strategy']}' — {_ratio}")
        print("   ✓ Best strategy lookup works")

        # ── 3. Query upgrade safety ──────────────────────────────────

        print("\n3. Querying upgrade intelligence...")

        safe = kb.get_upgrade_safety("lodash", "npm", "4.17.15", "4.17.21")
        assert safe is not None
        print(f"   lodash 4.17.15→4.17.21: {safe['attempt_count']} attempts, "
              f"build success: {safe['build_success_rate']:.0%}, major bump: {bool(safe['is_major_bump'])}")
        assert safe["build_success_rate"] == 1.0
        assert safe["is_major_bump"] == 0
        print("   ✓ lodash upgrade is safe")

        risky = kb.get_upgrade_safety("urllib3", "pip", "1.26.18", "2.0.7")
        assert risky is not None
        print(f"   urllib3 1.26.18→2.0.7: {risky['attempt_count']} attempts, "
              f"build success: {risky['build_success_rate']:.0%}, major bump: {bool(risky['is_major_bump'])}, "
              f"known issues: {len(risky['known_issues'])}")
        assert risky["build_success_rate"] == 0.0
        assert risky["is_major_bump"] == 1
        assert len(risky["known_issues"]) > 0
        print("   ✓ urllib3 major upgrade flagged as risky")

        # ── 4. Query build error hints ───────────────────────────────

        print("\n4. Querying build error hints...")

        # Record a resolution for the urllib3 error
        kb.record_error_resolution(
            raw_error="ImportError: cannot import name 'HTTPResponse' from 'urllib3.response' "
                     "/some/other/path/urllib3/response.py",  # different path, same signature
            stage="build", language="python", ecosystem="pip",
            resolution="urllib3 2.x removed HTTPResponse from response module. "
                      "Pin urllib3<2.0 or update imports to urllib3._collections_abc",
        )

        # Now query with yet another path variant
        hint = kb.get_error_hints(
            raw_error="ImportError: cannot import name 'HTTPResponse' from 'urllib3.response' "
                     "/totally/different/path/site-packages/urllib3/response.py",
            stage="build", language="python",
        )
        assert hint is not None
        print("   Error signature match: ✓")
        print(f"   Resolution: {hint['resolution'][:80]}...")
        assert "urllib3 2.x" in hint["resolution"]
        print("   ✓ Error normalisation produces stable signatures across paths")

        # ── 5. Model performance ─────────────────────────────────────

        print("\n5. Querying model performance...")

        rec = kb.get_model_recommendation("code_patch", "python")
        assert rec is not None
        rate = rec["success_count"] / (rec["success_count"] + rec["failure_count"])
        print(f"   Best for code_patch/python: {rec['model_name']} ({rate:.0%} success, "
              f"{rec['total_runs']} runs, avg {rec['avg_latency_ms']:.0f}ms)")
        print("   ✓ Model recommendation works")

        # ── 6. Strategy cache ────────────────────────────────────────

        print("\n6. Testing strategy cache...")

        ctx = "Finding: cwe | Severity: HIGH | CWE: CWE-89 | Language: python"
        response = json.dumps({"approach": "parameterized_query", "safe_apis": ["sqlalchemy.text"]})

        kb.cache_strategy(ctx, response, fix_type="code_patch", cwe_id="CWE-89", language="python")
        cached = kb.get_cached_strategy(ctx)
        assert cached is not None
        assert json.loads(cached)["approach"] == "parameterized_query"
        print("   ✓ Cache hit on exact context match")

        # Different context should miss
        miss = kb.get_cached_strategy("Finding: cwe | Severity: LOW | CWE: CWE-79")
        assert miss is None
        print("   ✓ Cache miss on different context")

        # ── 7. Export anonymized ─────────────────────────────────────

        print("\n7. Testing export/import for reach-cloud...")

        export = kb.export_anonymized()
        print(f"   Exported: {len(export['fix_patterns'])} patterns, "
              f"{len(export['upgrade_intel'])} upgrades, "
              f"{len(export['build_errors'])} errors")

        # Patterns need >=3 attempts to export
        for fp in export["fix_patterns"]:
            total = fp["success_count"] + fp["failure_count"]
            assert total >= 3, f"Should not export pattern with <3 attempts: {fp}"
        print("   ✓ Export filters low-evidence patterns")

        # Verify no file paths, repo names in export
        export_str = json.dumps(export)
        assert "/home/" not in export_str
        assert "repo" not in export_str.lower() or "from_version" in export_str
        print("   ✓ No file paths in export")

        # Import into fresh DB as community
        db2_path = Path(tmpdir) / "knowledge2.db"
        kb2 = EnzoKnowledgeDB(db2_path)
        kb2.import_community(export)

        # Verify community data arrived
        hints2 = kb2.get_fix_hints(cwe_id="CWE-89", language="python")
        assert len(hints2) > 0
        assert hints2[0]["source"] == "community"
        print("   ✓ Community import works, tagged as source='community'")

        # Now add local knowledge — should take precedence
        kb2.learn_from_attempt(
            finding_type="cwe", cwe_id="CWE-89",
            language="python", framework="flask", ecosystem="pip",
            fix_type="code_patch", strategy="parameterized_query",
            success=True, attempts_taken=1,
        )

        # Re-import community — should NOT overwrite local
        kb2.import_community(export)
        hints2 = kb2.get_fix_hints(cwe_id="CWE-89", language="python", framework="flask")
        local_rows = [h for h in hints2 if h["source"] == "local"]
        assert len(local_rows) > 0, "Local knowledge should exist"
        print("   ✓ Local knowledge takes precedence over community")

        kb2.close()

        # ── 8. Stats ─────────────────────────────────────────────────

        print("\n8. Knowledge DB stats...")

        stats = kb.get_stats()
        print(f"   Fix patterns:    {stats['fix_patterns']['local']} local, "
              f"{stats['fix_patterns']['community']} community")
        print(f"   Upgrade intel:   {stats['upgrade_intel']}")
        print(f"   Build errors:    {stats['build_errors']}")
        print(f"   Model perf:      {stats['model_performance']}")
        print(f"   Strategy cache:  {stats['strategy_cache']}")
        if stats["best_pattern"]:
            bp = stats["best_pattern"]
            total = bp["success_count"] + bp["failure_count"]
            print(f"   Best pattern:    {bp['strategy']} for {bp['cwe_id']}/{bp['language']}"
                  f" ({bp['success_count']}/{total})")
        print(f"   DB path:         {stats['db_path']}")

        # ── 9. Error normalisation unit tests ────────────────────────

        print("\n9. Error normalisation tests...")

        # Same error, different paths → same signature
        e1 = "ImportError: cannot import name 'Foo' from 'bar.baz' (/home/alice/project/venv/lib/bar/baz.py)"
        e2 = "ImportError: cannot import name 'Foo' from 'bar.baz' (/home/bob/other/venv/lib/bar/baz.py)"
        assert _normalise_error(e1) == _normalise_error(e2)
        print("   ✓ Different paths → same signature")

        # Same error, different versions → same signature
        e3 = "pkg_resources.DistributionNotFound: foo==1.2.3"
        e4 = "pkg_resources.DistributionNotFound: foo==4.5.6"
        assert _normalise_error(e3) == _normalise_error(e4)
        print("   ✓ Different versions → same signature")

        # Version normalisation
        assert _normalise_version("v4.17.21") == "4.17.21"
        assert _normalise_version("2.0.7-beta.1") == "2.0.7"
        assert _normalise_version("1.26.18") == "1.26.18"
        print("   ✓ Version normalisation correct")

        # ── Done ─────────────────────────────────────────────────────

        kb.close()

        print("\n" + "=" * 70)
        print("ALL TESTS PASSED ✓")
        print("=" * 70)


if __name__ == "__main__":
    main()
