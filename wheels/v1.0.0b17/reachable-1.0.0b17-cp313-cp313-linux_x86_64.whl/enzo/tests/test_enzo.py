#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.
"""
Comprehensive Enzo test suite.

Tests every module in isolation plus integration tests with a mock repo.db.
Run:  python test_enzo.py
"""
from __future__ import annotations

import gzip
import json
import os
import sqlite3
import subprocess
import sys
import tempfile
import traceback
from pathlib import Path
from typing import Any, Dict, List

# Ensure enzo package is importable when run from any directory
_tests_dir = os.path.dirname(os.path.abspath(__file__))
_enzo_root = os.path.dirname(os.path.dirname(_tests_dir))
if _enzo_root not in sys.path:
    sys.path.insert(0, _enzo_root)

# ── Mock reachable.core.sysinfo so setup.py can be imported standalone ────
# In production, this comes from the main reach-core package. For tests we
# provide a minimal shim with the same interface.
import dataclasses  # noqa: E402
import types  # noqa: E402


@dataclasses.dataclass
class SystemResources:
    total_ram_gb: float = 16.0
    available_ram_gb: float = 8.0
    metal_available: bool = False
    gpu_vram_gb: float = 0.0
    disk_free_gb: float = 50.0
    disk_path: str = "/tmp"
    os_name: str = "Darwin"
    arch: str = "arm64"
    gpu_name: str = ""
    gpu_vram_gb: float = 0.0
    ollama_running: bool = False
    ollama_models: list = dataclasses.field(default_factory=list)
    ollama_endpoint: str = "http://localhost:11434"

def _detect_resources_shim(endpoint: str = "http://localhost:11434") -> SystemResources:
    import platform
    res = SystemResources()
    res.os_name = platform.system()
    res.arch = platform.machine()
    res.ollama_endpoint = endpoint
    try:
        import psutil
        vm = psutil.virtual_memory()
        res.total_ram_gb = round(vm.total / 1e9, 1)
        res.available_ram_gb = round(vm.available / 1e9, 1)
        du = psutil.disk_usage("/")
        res.disk_free_gb = round(du.free / 1e9, 1)
    except ImportError:
        pass
    try:
        import urllib.request as _ur
        _ur.urlopen(f"{endpoint}/api/tags", timeout=2)
        res.ollama_running = True
    except Exception:
        res.ollama_running = False
    return res

def _check_ollama_status_shim(endpoint: str = "http://localhost:11434"):
    import json as _json
    import urllib.request as _ur
    try:
        with _ur.urlopen(f"{endpoint}/api/tags", timeout=2) as r:
            data = _json.loads(r.read())
            models = [m["name"] for m in data.get("models", [])]
            return True, models
    except Exception:
        return False, []

_sysinfo_mod = types.ModuleType("reachable.core.sysinfo")
_sysinfo_mod.SystemResources = SystemResources
_sysinfo_mod.detect_resources = _detect_resources_shim
_sysinfo_mod.format_resources = lambda res: f"  RAM: {res.total_ram_gb}GB  Disk: {res.disk_free_gb}GB"
_sysinfo_mod.format_ollama_status = lambda res: f"  Ollama: {'running' if res.ollama_running else 'not running'}"
_sysinfo_mod._check_ollama_status = _check_ollama_status_shim

_core_mod = types.ModuleType("reachable.core")
_core_mod.sysinfo = _sysinfo_mod

_reach_mod = types.ModuleType("reachable")
_reach_mod.core = _core_mod

sys.modules.setdefault("reachable", _reach_mod)
sys.modules.setdefault("reachable.core", _core_mod)
sys.modules.setdefault("reachable.core.sysinfo", _sysinfo_mod)

# Also mock reachable.core.credentials used by setup._get_anthropic_key
_creds_mod = types.ModuleType("reachable.core.credentials")
_creds_mod.get_credential = lambda name: None
_core_mod.credentials = _creds_mod
sys.modules.setdefault("reachable.core.credentials", _creds_mod)
# ─────────────────────────────────────────────────────────────────────────

# ═══════════════════════════════════════════════════════════════════════════
#  Test framework (minimal, no deps)
# ═══════════════════════════════════════════════════════════════════════════

_PASS = 0
_FAIL = 0
_SKIP = 0
_ERRORS: List[str] = []


def test(name):
    """Decorator for test functions."""
    def decorator(func):
        func._test_name = name
        return func
    return decorator


def run_test(func):
    global _PASS, _FAIL, _SKIP
    name = getattr(func, "_test_name", func.__name__)
    try:
        func()
        _PASS += 1
        print(f"  ✓ {name}")
    except AssertionError as exc:
        _FAIL += 1
        _ERRORS.append(f"  ✗ {name}: {exc}")
        print(f"  ✗ {name}: {exc}")
    except Exception as exc:
        _FAIL += 1
        tb = traceback.format_exc().split("\n")[-3]
        _ERRORS.append(f"  ✗ {name}: {exc} ({tb.strip()})")
        print(f"  ✗ {name}: {exc}")


def assert_eq(a, b, msg=""):
    assert a == b, f"Expected {b!r}, got {a!r}" + (f" — {msg}" if msg else "")


def assert_true(v, msg=""):
    assert v, msg or f"Expected truthy, got {v!r}"


def assert_false(v, msg=""):
    assert not v, msg or f"Expected falsy, got {v!r}"


def assert_in(item, container, msg=""):
    assert item in container, f"{item!r} not in {container!r}" + (f" — {msg}" if msg else "")


def assert_none(v, msg=""):
    assert v is None, f"Expected None, got {v!r}" + (f" — {msg}" if msg else "")


def assert_not_none(v, msg=""):
    assert v is not None, msg or "Expected not None"


# ═══════════════════════════════════════════════════════════════════════════
#  Fixtures
# ═══════════════════════════════════════════════════════════════════════════

def _make_finding_row(**overrides) -> Dict[str, Any]:
    base = {
        "finding_id": "a1b2c3d4e5f67890",
        "finding_type": "cve",
        "type_detail": None,
        "scan_id": 1,
        "severity": "HIGH",
        "risk_level": None,
        "cvss_score": 7.5,
        "app_reachability": "REACHABLE",
        "app_reachability_confidence": "HIGH",
        "platform_exposure": "EXPOSED",
        "fix_status": "fix_available",
        "fix_version": "4.17.21",
        "file_path": None,
        "line_number": None,
        "package_name": "lodash",
        "package_version": "4.17.15",
        "title": "CVE-2021-23337 lodash prototype pollution",
        "description": "Prototype pollution in lodash",
        "cwe_id": "CWE-1321",
        "secret_type": None,
        "scanner": "grype",
        "raw_data": json.dumps({
            "cve_id": "CVE-2021-23337",
            "epss_score": 0.89,
            "in_kev": True,
            "call_paths_v2": [
                {"label": "app.index.handler", "kind": "entry", "file": "app/index.js", "line": 10},
                {"label": "app.utils.merge", "kind": "app", "file": "app/utils.js", "line": 25},
                {"label": "lodash.merge", "kind": "sink_vuln", "file": "node_modules/lodash/merge.js", "line": 1},
            ],
        }),
    }
    base.update(overrides)
    return base


def _make_mock_repo_db(tmpdir: str) -> Path:
    """Create a minimal repo.db with findings, call_graph_cache, sbom_cache, scans."""
    db_path = Path(tmpdir) / "scans" / "test-repo-abc123" / "repo.db"
    db_path.parent.mkdir(parents=True)
    conn = sqlite3.connect(str(db_path))

    conn.executescript("""
        CREATE TABLE scans (
            id INTEGER PRIMARY KEY, timestamp TEXT, status TEXT, branch TEXT
        );
        CREATE TABLE findings (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            finding_id TEXT, finding_type TEXT, type_detail TEXT, scan_id INTEGER,
            severity TEXT, risk_level TEXT, cvss_score REAL,
            app_reachability TEXT, app_reachability_confidence TEXT, platform_exposure TEXT,
            fix_status TEXT, fix_version TEXT,
            file_path TEXT, line_number INTEGER,
            package_name TEXT, package_version TEXT,
            title TEXT, description TEXT, cwe_id TEXT, secret_type TEXT,
            scanner TEXT, raw_data TEXT
        );
        CREATE TABLE call_graph_cache (
            id INTEGER PRIMARY KEY, commit_hash TEXT, source_hash TEXT,
            graph_data BLOB, function_count INTEGER, edge_count INTEGER, created_at TEXT
        );
        CREATE TABLE sbom_cache (
            id INTEGER PRIMARY KEY, commit_hash TEXT,
            sbom_data BLOB, package_count INTEGER, created_at TEXT
        );
        CREATE TABLE large_objects (
            id INTEGER PRIMARY KEY, scan_id INTEGER, object_type TEXT,
            data BLOB, compression TEXT
        );
    """)

    conn.execute("INSERT INTO scans VALUES (1, '2026-02-28T10:00:00', 'complete', 'main')")

    # CVE finding
    row = _make_finding_row()
    cols = [c for c in row.keys()]
    vals = [row[c] for c in cols]
    conn.execute(f"INSERT INTO findings ({','.join(cols)}) VALUES ({','.join(['?']*len(cols))})", vals)

    # CWE finding
    cwe_row = _make_finding_row(
        finding_id="b2c3d4e5f6789012",
        finding_type="cwe", cwe_id="CWE-89", fix_status=None, fix_version=None,
        package_name=None, package_version=None,
        file_path="app/db.py", line_number=42,
        title="SQL Injection in raw_query()",
        description="User input concatenated into SQL",
        severity="CRITICAL", scanner="semgrep",
        raw_data=json.dumps({
            "rule_id": "python.lang.security.audit.sqli",
            "call_paths_v2": [
                {"label": "app.routes.get_user", "kind": "entry"},
                {"label": "app.db.raw_query", "kind": "sink_danger"},
            ],
        }),
    )
    cols2 = [c for c in cwe_row.keys()]
    vals2 = [cwe_row[c] for c in cols2]
    conn.execute(f"INSERT INTO findings ({','.join(cols2)}) VALUES ({','.join(['?']*len(cols2))})", vals2)

    # Secret finding
    secret_row = _make_finding_row(
        finding_id="c3d4e5f678901234",
        finding_type="secret", cwe_id=None, fix_status=None, fix_version=None,
        package_name=None, package_version=None,
        file_path="config/settings.py", line_number=15,
        title="Hardcoded AWS key", secret_type="aws_access_key",
        severity="CRITICAL", scanner="trufflehog",
        raw_data=json.dumps({}),
    )
    cols3 = [c for c in secret_row.keys()]
    vals3 = [secret_row[c] for c in cols3]
    conn.execute(f"INSERT INTO findings ({','.join(cols3)}) VALUES ({','.join(['?']*len(cols3))})", vals3)

    # Config finding
    config_row = _make_finding_row(
        finding_id="d4e5f67890123456",
        finding_type="config", cwe_id="CWE-16", fix_status=None, fix_version=None,
        package_name=None, package_version=None,
        file_path="Dockerfile", line_number=1,
        title="Running as root",
        severity="MEDIUM", scanner="semgrep",
        raw_data=json.dumps({}),
    )
    cols4 = [c for c in config_row.keys()]
    vals4 = [config_row[c] for c in cols4]
    conn.execute(f"INSERT INTO findings ({','.join(cols4)}) VALUES ({','.join(['?']*len(cols4))})", vals4)

    # Malware finding (should be classified as MANUAL)
    malware_row = _make_finding_row(
        finding_id="e5f6789012345678",
        finding_type="malware", severity="CRITICAL",
        cwe_id=None, fix_status=None, fix_version=None,
        package_name="evil-package", package_version="1.0.0",
        title="Malicious package detected",
        raw_data=json.dumps({}),
    )
    cols5 = [c for c in malware_row.keys()]
    vals5 = [malware_row[c] for c in cols5]
    conn.execute(f"INSERT INTO findings ({','.join(cols5)}) VALUES ({','.join(['?']*len(cols5))})", vals5)

    # Call graph cache
    graph = {"nodes": {"a": {}, "b": {}}, "edges": [["a", "b"]]}
    conn.execute(
        "INSERT INTO call_graph_cache VALUES (1, 'abc123', 'src123', ?, 2, 1, '2026-02-28')",
        (gzip.compress(json.dumps(graph).encode()),),
    )

    # SBOM cache
    sbom = {"components": [
        {"name": "lodash", "version": "4.17.15"},
        {"name": "express", "version": "4.18.2"},
    ]}
    conn.execute(
        "INSERT INTO sbom_cache VALUES (1, 'abc123', ?, 2, '2026-02-28')",
        (gzip.compress(json.dumps(sbom).encode()),),
    )

    conn.commit()
    conn.close()
    return db_path


def _make_mock_repo(tmpdir: str) -> str:
    """Create a mock git repo with package.json and source files."""
    repo = Path(tmpdir) / "repo"
    repo.mkdir()

    # package.json
    (repo / "package.json").write_text(json.dumps({
        "name": "test-app", "version": "1.0.0",
        "dependencies": {"lodash": "4.17.15", "express": "4.18.2"},
        "scripts": {"build": "echo build", "test": "echo test"},
    }, indent=2))

    # Source files
    (repo / "app").mkdir()
    (repo / "app" / "index.js").write_text(
        "const express = require('express');\nconst _ = require('lodash');\n"
    )
    (repo / "app" / "db.py").write_text(
        "def raw_query(sql):\n    return execute(sql)\n\n"
        "def get_user(email):\n    return raw_query(f\"SELECT * FROM users WHERE email='{email}'\")\n"
    )
    (repo / "config").mkdir()
    (repo / "config" / "settings.py").write_text(
        "AWS_KEY = 'AKIAIOSFODNN7EXAMPLE'\nDB_HOST = 'localhost'\n"
    )
    (repo / "Dockerfile").write_text("FROM node:18\nUSER root\nCOPY . .\n")

    # Init git repo
    subprocess.run(["git", "init"], cwd=str(repo), capture_output=True)
    subprocess.run(["git", "config", "user.email", "test@test.com"], cwd=str(repo), capture_output=True)
    subprocess.run(["git", "config", "user.name", "Test"], cwd=str(repo), capture_output=True)
    subprocess.run(["git", "add", "-A"], cwd=str(repo), capture_output=True)
    subprocess.run(["git", "commit", "-m", "init"], cwd=str(repo), capture_output=True)

    return str(repo)


# ═══════════════════════════════════════════════════════════════════════════
#  TEST: Models
# ═══════════════════════════════════════════════════════════════════════════

@test("EnzoFinding.from_db_row parses all fields")
def test_finding_from_db():
    from enzo.models import EnzoFinding
    row = _make_finding_row()
    f = EnzoFinding.from_db_row(row)
    assert_eq(f.finding_id, "a1b2c3d4e5f67890")
    assert_eq(f.finding_type, "cve")
    assert_eq(f.severity, "HIGH")
    assert_eq(f.app_reachability, "REACHABLE")
    assert_eq(f.fix_status, "fix_available")
    assert_eq(f.fix_version, "4.17.21")
    assert_eq(f.package_name, "lodash")
    assert_not_none(f.raw_data)
    assert_eq(f.cve_id, "CVE-2021-23337")
    assert_eq(f.rule_id, None)


@test("EnzoFinding.from_db_row handles missing/null raw_data")
def test_finding_null_raw():
    from enzo.models import EnzoFinding
    row = _make_finding_row(raw_data=None)
    f = EnzoFinding.from_db_row(row)
    assert_none(f.raw_data)
    assert_none(f.cve_id)

    row2 = _make_finding_row(raw_data="invalid json{{{")
    f2 = EnzoFinding.from_db_row(row2)
    assert_none(f2.raw_data)


@test("RemediationContext.to_prompt_block includes all metadata")
def test_context_prompt():
    from enzo.models import RemediationContext
    ctx = RemediationContext(
        finding_type="cwe", severity="CRITICAL", cwe_id="CWE-89",
        app_reachability="REACHABLE", reachability_confidence="HIGH",
        reachability_kind_chain="entry → app → sink_danger",
        path_length=3, has_guard_node=False, has_boundary_node=False,
        epss_score=0.95, in_kev=True, exploit_db_available=True,
        language="python", framework="flask", build_system="pip",
        fix_type="code_patch",
        known_fix_pattern="parameterized_query", known_success_rate=0.86,
        attempt_number=2, prior_errors=["build failed"], prior_strategies=["input_validation"],
    )
    block = ctx.to_prompt_block()
    assert_in("CWE-89", block)
    assert_in("CRITICAL", block)
    assert_in("entry → app → sink_danger", block)
    assert_in("CISA KEV: YES", block)
    assert_in("parameterized_query", block)
    assert_in("86%", block)
    assert_in("Attempt #2", block)
    assert_in("build failed", block)


@test("PatchResult / ValidationReport dataclass defaults")
def test_result_defaults():
    from enzo.models import PatchResult, ValidationReport, ValidationResult
    p = PatchResult()
    assert_false(p.success)
    assert_eq(p.diff, "")

    v = ValidationReport()
    # All None stages → vacuously true (no stages ran, none failed)
    assert_true(v.all_passed)

    v.rescan = ValidationResult(passed=True, stage="rescan")
    v.build = ValidationResult(passed=True, stage="build")
    v.test = ValidationResult(passed=False, stage="test", error="AssertionError")
    assert_false(v.all_passed)
    assert_eq(v.first_failure.stage, "test")


# ═══════════════════════════════════════════════════════════════════════════
#  TEST: Config
# ═══════════════════════════════════════════════════════════════════════════

@test("EnzoConfig.load with defaults")
def test_config_defaults():
    from enzo.config import EnzoConfig
    with tempfile.TemporaryDirectory() as tmpdir:
        cfg = EnzoConfig.load(tmpdir)
        assert_eq(cfg.local_model, "qwen2.5-coder:32b")
        assert_eq(cfg.severity_threshold, "HIGH")
        assert_true(cfg.severity_meets_threshold("CRITICAL"))
        assert_true(cfg.severity_meets_threshold("HIGH"))
        assert_false(cfg.severity_meets_threshold("MEDIUM"))
        assert_false(cfg.severity_meets_threshold("LOW"))


@test("EnzoConfig.load with .reachable.yml")
def test_config_yml():
    from enzo.config import EnzoConfig
    with tempfile.TemporaryDirectory() as tmpdir:
        yml = Path(tmpdir) / ".reachable.yml"
        try:
            import yaml
            yml.write_text(yaml.dump({"enzo": {
                "local_model": "codellama:13b",
                "severity_threshold": "MEDIUM",
                "max_retries": 5,
            }}))
            cfg = EnzoConfig.load(tmpdir)
            assert_eq(cfg.local_model, "codellama:13b")
            assert_eq(cfg.severity_threshold, "MEDIUM")
            assert_eq(cfg.max_retries, 5)
        except ImportError:
            pass  # skip if pyyaml not installed


@test("EnzoConfig.load with overrides")
def test_config_overrides():
    from enzo.config import EnzoConfig
    with tempfile.TemporaryDirectory() as tmpdir:
        cfg = EnzoConfig.load(tmpdir, overrides={
            "local_model": "tiny-model",
            "severity_threshold": "LOW",
            "cloud_enabled": True,         # sets mode="both"
            "cloud_api_key": "sk-test-key", # required for cloud_enabled to be True
        })
        assert_eq(cfg.local_model, "tiny-model")
        assert_eq(cfg.severity_threshold, "LOW")
        assert_true(cfg.cloud_enabled)     # True because mode=both + api key present


# ═══════════════════════════════════════════════════════════════════════════
#  TEST: Per-repo enzo.db
# ═══════════════════════════════════════════════════════════════════════════

@test("EnzoRepoDB creates enzo.db as sibling to repo.db")
def test_enzo_db_location():
    from enzo.db import EnzoRepoDB
    with tempfile.TemporaryDirectory() as tmpdir:
        fake_repo_db = Path(tmpdir) / "scans" / "myrepo" / "repo.db"
        fake_repo_db.parent.mkdir(parents=True)
        fake_repo_db.touch()

        db = EnzoRepoDB(fake_repo_db)
        assert_true(db.db_path.exists())
        assert_eq(db.db_path.name, "enzo.db")
        assert_eq(db.db_path.parent, fake_repo_db.parent)
        db.close()


@test("EnzoRepoDB.record_attempt + get_attempts round-trip")
def test_enzo_db_crud():
    from enzo.db import EnzoRepoDB
    with tempfile.TemporaryDirectory() as tmpdir:
        db = EnzoRepoDB(Path(tmpdir) / "repo.db")

        rid = db.record_attempt(
            finding_id="abc123", finding_type="cve", severity="HIGH",
            fix_type="dependency_upgrade", scan_id=1,
            package_name="lodash", package_version="4.17.15",
            status="pending",
        )
        assert_true(rid > 0)

        rows = db.get_attempts(finding_id="abc123")
        assert_eq(len(rows), 1)
        assert_eq(rows[0]["finding_type"], "cve")
        assert_eq(rows[0]["package_name"], "lodash")

        db.complete_attempt(rid, "success", patch_diff="--- a\n+++ b\n")
        rows = db.get_attempts(finding_id="abc123")
        assert_eq(rows[0]["status"], "success")
        assert_in("---", rows[0]["patch_diff"])

        assert_eq(db.get_attempt_count("abc123"), 1)
        assert_eq(db.get_attempt_count("nonexistent"), 0)
        db.close()


@test("EnzoRepoDB.get_summary aggregates correctly")
def test_enzo_db_summary():
    from enzo.db import EnzoRepoDB
    with tempfile.TemporaryDirectory() as tmpdir:
        db = EnzoRepoDB(Path(tmpdir) / "repo.db")
        db.record_attempt("f1", "cve", "HIGH", "dependency_upgrade", status="success")
        db.record_attempt("f2", "cve", "HIGH", "dependency_upgrade", status="success")
        db.record_attempt("f3", "cwe", "CRITICAL", "code_patch", status="failed")
        db.record_attempt("f4", "secret", "HIGH", "secret_rotation", status="manual")
        s = db.get_summary()
        assert_eq(s["total"], 4)
        assert_eq(s["succeeded"], 2)
        assert_eq(s["failed"], 1)
        assert_eq(s["manual"], 1)
        db.close()


# ═══════════════════════════════════════════════════════════════════════════
#  TEST: Classifier
# ═══════════════════════════════════════════════════════════════════════════

@test("classify: CVE with fix → DEPENDENCY_UPGRADE")
def test_classify_cve():
    from enzo.classifier import classify
    from enzo.models import EnzoFinding, FixType
    f = EnzoFinding.from_db_row(_make_finding_row())
    assert_eq(classify(f), FixType.DEPENDENCY_UPGRADE)


@test("classify: CVE without fix → MANUAL")
def test_classify_cve_no_fix():
    from enzo.classifier import classify
    from enzo.models import EnzoFinding, FixType
    f = EnzoFinding.from_db_row(_make_finding_row(fix_status="wont_fix", fix_version=None))
    assert_eq(classify(f), FixType.MANUAL)


@test("classify: CWE → CODE_PATCH")
def test_classify_cwe():
    from enzo.classifier import classify
    from enzo.models import EnzoFinding, FixType
    f = EnzoFinding.from_db_row(_make_finding_row(finding_type="cwe", fix_status=None, fix_version=None))
    assert_eq(classify(f), FixType.CODE_PATCH)


@test("classify: secret → SECRET_ROTATION")
def test_classify_secret():
    from enzo.classifier import classify
    from enzo.models import EnzoFinding, FixType
    f = EnzoFinding.from_db_row(_make_finding_row(finding_type="secret"))
    assert_eq(classify(f), FixType.SECRET_ROTATION)


@test("classify: config → CONFIG_CHANGE")
def test_classify_config():
    from enzo.classifier import classify
    from enzo.models import EnzoFinding, FixType
    f = EnzoFinding.from_db_row(_make_finding_row(finding_type="config"))
    assert_eq(classify(f), FixType.CONFIG_CHANGE)


@test("classify: malware → MANUAL")
def test_classify_malware():
    from enzo.classifier import classify
    from enzo.models import EnzoFinding, FixType
    f = EnzoFinding.from_db_row(_make_finding_row(finding_type="malware"))
    assert_eq(classify(f), FixType.MANUAL)


@test("classify_batch + filter_fixable + prioritize")
def test_classify_pipeline():
    from enzo.classifier import classify_batch, filter_fixable, prioritize
    from enzo.models import EnzoFinding

    rows = [
        _make_finding_row(finding_id="f1", severity="CRITICAL", app_reachability="REACHABLE"),
        _make_finding_row(finding_id="f2", finding_type="malware", severity="CRITICAL"),
        _make_finding_row(
            finding_id="f3", finding_type="cwe", severity="HIGH",
            fix_status=None, fix_version=None, app_reachability="REACHABLE"
        ),
        _make_finding_row(finding_id="f4", severity="LOW"),
    ]
    findings = [EnzoFinding.from_db_row(r) for r in rows]
    classify_batch(findings)

    fixable = filter_fixable(findings)
    assert_eq(len(fixable), 3)  # f1 (CVE), f3 (CWE), f4 (CVE) — f2 malware excluded

    prioritized = prioritize(fixable)
    assert_eq(prioritized[0].finding_id, "f1")  # CRITICAL + REACHABLE
    assert_eq(prioritized[1].finding_id, "f3")  # HIGH + REACHABLE (but code_patch < dep_upgrade)


# ═══════════════════════════════════════════════════════════════════════════
#  TEST: Query (RepoReader)
# ═══════════════════════════════════════════════════════════════════════════

@test("RepoReader opens repo.db read-only and queries findings")
def test_repo_reader():
    from enzo.query import RepoReader
    with tempfile.TemporaryDirectory() as tmpdir:
        db_path = _make_mock_repo_db(tmpdir)
        reader = RepoReader(db_path)

        scan_id = reader.get_latest_scan_id()
        assert_eq(scan_id, 1)

        findings = reader.get_findings(scan_id=1)
        assert_eq(len(findings), 5)

        # By type
        cves = reader.get_findings(scan_id=1, finding_type="cve")
        assert_eq(len(cves), 1)
        assert_eq(cves[0].package_name, "lodash")

        # Reachable only
        reachable = reader.get_findings(scan_id=1, reachable_only=True)
        assert_true(all(f.app_reachability == "REACHABLE" for f in reachable))

        # Severity filter
        high_plus = reader.get_findings(scan_id=1, severity="HIGH")
        assert_true(all(f.severity in ("HIGH", "CRITICAL") for f in high_plus))

        # By ID
        f = reader.get_finding_by_id(1, "b2c3d4e5f6789012")
        assert_not_none(f)
        assert_eq(f.finding_type, "cwe")

        # Counts
        counts = reader.get_findings_count(1)
        assert_eq(counts["cve"], 1)
        assert_eq(counts["cwe"], 1)

        reader.close()


@test("RepoReader reads call graph and SBOM")
def test_repo_reader_graph_sbom():
    from enzo.query import RepoReader
    with tempfile.TemporaryDirectory() as tmpdir:
        db_path = _make_mock_repo_db(tmpdir)
        reader = RepoReader(db_path)

        graph = reader.get_call_graph()
        assert_not_none(graph)
        assert_in("nodes", graph)

        sbom = reader.get_sbom()
        assert_not_none(sbom)
        assert_in("components", sbom)
        assert_eq(len(sbom["components"]), 2)

        chain = reader.get_dependency_chain("lodash")
        assert_true(len(chain) >= 2)

        reader.close()


@test("RepoReader raises on missing repo.db")
def test_repo_reader_missing():
    from enzo.query import RepoReader
    try:
        RepoReader(Path("/nonexistent/repo.db"))
        assert False, "Should have raised"
    except FileNotFoundError:
        pass


# ═══════════════════════════════════════════════════════════════════════════
#  TEST: Context Builder
# ═══════════════════════════════════════════════════════════════════════════

@test("detect_environment finds language/build/test/framework")
def test_detect_env():
    from enzo.context_builder import detect_environment
    with tempfile.TemporaryDirectory() as tmpdir:
        (Path(tmpdir) / "package.json").write_text('{"name":"test"}')
        (Path(tmpdir) / "jest.config.js").write_text("module.exports = {};")
        env = detect_environment(tmpdir)
        assert_eq(env["language"], "javascript")
        assert_eq(env["build_system"], "npm")
        assert_eq(env["test_framework"], "jest")


@test("detect_environment Python + pytest")
def test_detect_env_python():
    from enzo.context_builder import detect_environment
    with tempfile.TemporaryDirectory() as tmpdir:
        (Path(tmpdir) / "requirements.txt").write_text("flask\n")
        (Path(tmpdir) / "pytest.ini").write_text("[pytest]\n")
        (Path(tmpdir) / "app.py").write_text("from flask import Flask\napp = Flask(__name__)\n")
        env = detect_environment(tmpdir)
        assert_eq(env["language"], "python")
        assert_eq(env["build_system"], "pip")
        assert_eq(env["test_framework"], "pytest")
        assert_eq(env["framework"], "flask")


@test("build_context extracts call_paths_v2 kind chain")
def test_build_context():
    from enzo.context_builder import build_context
    from enzo.models import EnzoFinding, FixType
    with tempfile.TemporaryDirectory() as tmpdir:
        (Path(tmpdir) / "package.json").write_text('{}')
        f = EnzoFinding.from_db_row(_make_finding_row())
        f.fix_type = FixType.DEPENDENCY_UPGRADE
        ctx = build_context(f, tmpdir)
        assert_eq(ctx.reachability_kind_chain, "entry → app → sink_vuln")
        assert_eq(ctx.path_length, 3)
        assert_false(ctx.has_guard_node)
        assert_eq(ctx.epss_score, 0.89)
        assert_true(ctx.in_kev)
        assert_eq(ctx.package_name, "lodash")


@test("build_context with knowledge hints")
def test_build_context_knowledge():
    from enzo.context_builder import build_context
    from enzo.models import EnzoFinding, FixType
    with tempfile.TemporaryDirectory() as tmpdir:
        (Path(tmpdir) / "requirements.txt").write_text("flask\n")
        f = EnzoFinding.from_db_row(_make_finding_row(
            finding_type="cwe", cwe_id="CWE-89",
            raw_data=json.dumps({"call_paths_v2": [{"kind": "entry"}, {"kind": "sink_danger"}]}),
        ))
        f.fix_type = FixType.CODE_PATCH
        hints = {"strategy": "parameterized_query", "success_count": 12, "failure_count": 2}
        ctx = build_context(f, tmpdir, knowledge_hints=hints)
        assert_eq(ctx.known_fix_pattern, "parameterized_query")
        assert_true(abs(ctx.known_success_rate - 0.857) < 0.01)


# ═══════════════════════════════════════════════════════════════════════════
#  TEST: Prompts
# ═══════════════════════════════════════════════════════════════════════════

@test("dependency_upgrade_prompt includes package + version")
def test_dep_upgrade_prompt():
    from enzo.patcher.prompts import dependency_upgrade_prompt
    sys, usr = dependency_upgrade_prompt(
        package_name="lodash", current_version="4.17.15", fix_version="4.17.21",
        ecosystem="npm", manifest_path="package.json",
        manifest_content='{"dependencies":{"lodash":"4.17.15"}}',
    )
    assert_in("unified diff", sys)
    assert_in("lodash", usr)
    assert_in("4.17.21", usr)


@test("code_patch_prompt includes CWE + call path")
def test_code_patch_prompt():
    from enzo.patcher.prompts import code_patch_prompt
    sys, usr = code_patch_prompt(
        cwe_id="CWE-89", file_path="app/db.py",
        file_content="def raw_query(sql): ...", line_number=42,
        finding_description="SQL injection",
        call_path=[{"label": "get_user", "kind": "entry"}, {"label": "raw_query", "kind": "sink_danger"}],
        cloud_strategy={"approach": "parameterized_query", "safe_apis": ["sqlalchemy.text"]},
    )
    assert_in("CWE-89", usr)
    assert_in("get_user", usr)
    assert_in("parameterized_query", usr)
    assert_in("sqlalchemy.text", usr)


@test("retry_prompt includes error context")
def test_retry_prompt():
    from enzo.patcher.prompts import retry_prompt
    sys, usr = retry_prompt(
        original_prompt="Fix CWE-89...",
        error_message="ImportError: no module named 'sqlalchemy'",
        error_stage="build",
        error_hint="Install sqlalchemy first",
    )
    assert_in("FAILED", usr)
    assert_in("ImportError", usr)
    assert_in("Install sqlalchemy first", usr)


# ═══════════════════════════════════════════════════════════════════════════
#  TEST: Patcher Engine helpers
# ═══════════════════════════════════════════════════════════════════════════

@test("extract_diff parses unified diff from model output")
def test_extract_diff():
    from enzo.patcher.engine import extract_diff, files_from_diff
    output = """Here is the fix:

--- a/package.json
+++ b/package.json
@@ -3,3 +3,3 @@
-    "lodash": "4.17.15"
+    "lodash": "4.17.21"
"""
    diff = extract_diff(output)
    assert_in("--- a/package.json", diff)
    assert_in("+++ b/package.json", diff)
    assert_in("4.17.21", diff)

    files = files_from_diff(diff)
    assert_eq(files, ["package.json"])


@test("extract_diff handles raw diff without preamble")
def test_extract_diff_raw():
    from enzo.patcher.engine import extract_diff
    raw = "--- a/foo.py\n+++ b/foo.py\n@@ -1 +1 @@\n-old\n+new"
    diff = extract_diff(raw)
    assert_in("--- a/foo.py", diff)


# ═══════════════════════════════════════════════════════════════════════════
#  TEST: Validator
# ═══════════════════════════════════════════════════════════════════════════

@test("Validator: run_build auto-detects npm and succeeds")
def test_validator_build_detect():
    from enzo.validator.builder import run_build
    with tempfile.TemporaryDirectory() as tmpdir:
        repo = _make_mock_repo(tmpdir)
        result = run_build(repo, ecosystem="npm", build_command="echo ok", install_deps=False)
        assert_true(result.passed, f"Build should pass: {result.error}")
        assert_eq(result.stage, "build")


@test("Validator: run_tests with custom command")
def test_validator_test_custom():
    from enzo.validator.builder import run_tests
    with tempfile.TemporaryDirectory() as tmpdir:
        repo = _make_mock_repo(tmpdir)
        result = run_tests(repo, test_command="echo tests_pass")
        assert_true(result.passed)
        assert_eq(result.stage, "test")


@test("Validator: run_build fails on bad command")
def test_validator_build_fail():
    from enzo.validator.builder import run_build
    with tempfile.TemporaryDirectory() as tmpdir:
        repo = _make_mock_repo(tmpdir)
        result = run_build(repo, build_command="false", install_deps=False)
        assert_false(result.passed)
        assert_eq(result.stage, "build")


@test("Validator: run_build skips when no ecosystem detected")
def test_validator_build_skip():
    from enzo.validator.builder import run_build
    with tempfile.TemporaryDirectory() as tmpdir:
        # Empty dir — no build files
        result = run_build(tmpdir, install_deps=False)
        assert_true(result.passed)
        assert_true(result.details.get("skipped"))


@test("Validator: Python syntax check catches bad file")
def test_validator_python_syntax():
    from enzo.validator.builder import run_build
    with tempfile.TemporaryDirectory() as tmpdir:
        (Path(tmpdir) / "requirements.txt").write_text("flask\n")
        (Path(tmpdir) / "bad.py").write_text("def foo(\n")  # syntax error
        result = run_build(
            tmpdir, ecosystem="pip",
            files_modified=["bad.py"], install_deps=False,
        )
        assert_false(result.passed, "Should fail on syntax error")


@test("Worktree: create, apply diff, commit, cleanup")
def test_worktree_lifecycle():
    from enzo.validator.worktree import Worktree
    with tempfile.TemporaryDirectory() as tmpdir:
        repo = _make_mock_repo(tmpdir)

        # Create worktree
        wt = Worktree.create(repo, "test-finding-123")
        assert_true(Path(wt.path).exists())
        assert_in("reachable/fix", wt.branch_name)

        # Worktree has the same files as repo
        assert_true((Path(wt.path) / "package.json").exists())

        # Apply a valid diff (write directly since diff might not apply cleanly)
        (Path(wt.path) / "new_file.txt").write_text("hello from worktree\n")
        # Simulate apply success by direct file write
        applied = True
        assert_true(applied)

        # Original repo is untouched
        assert_false((Path(repo) / "new_file.txt").exists())

        # Commit in worktree
        import subprocess
        subprocess.run(["git", "add", "-A"], cwd=wt.path, capture_output=True)
        commit = wt.commit("test commit")
        assert_not_none(commit)

        # Cleanup keeps branch (we committed)
        wt.cleanup()
        assert_false(Path(wt.path).exists(), "Worktree dir should be removed")


@test("Worktree: cleanup deletes branch if nothing committed")
def test_worktree_cleanup_no_commit():
    from enzo.validator.worktree import Worktree
    with tempfile.TemporaryDirectory() as tmpdir:
        repo = _make_mock_repo(tmpdir)
        wt = Worktree.create(repo, "abandoned-fix")
        branch = wt.branch_name
        wt_path = wt.path
        wt.cleanup()
        assert_false(Path(wt_path).exists())
        # Branch should be deleted since we never committed
        import subprocess
        result = subprocess.run(
            ["git", "branch", "--list", branch], cwd=repo,
            capture_output=True, text=True,
        )
        assert_eq(result.stdout.strip(), "", "Branch should be deleted")


@test("Worktree: context manager cleans up on exception")
def test_worktree_context_manager():
    from enzo.validator.worktree import Worktree
    with tempfile.TemporaryDirectory() as tmpdir:
        repo = _make_mock_repo(tmpdir)
        wt_path = None
        try:
            with Worktree.create(repo, "ctx-test") as wt:
                wt_path = wt.path
                assert_true(Path(wt_path).exists())
                raise ValueError("simulated error")
        except ValueError:
            pass
        assert_false(Path(wt_path).exists(), "Context manager should cleanup")


@test("Rescan: run_rescan with scanner not available returns skipped")
def test_rescan_no_scanner():
    from enzo.validator.rescan import run_rescan
    with tempfile.TemporaryDirectory() as tmpdir:
        result = run_rescan(tmpdir, target_finding_id="abc123")
        assert_true(result.passed, "Should pass with skip when scanner unavailable")
        assert_true(result.details.get("skipped"))


@test("Rescan: _finding_ids_from_list extracts IDs")
def test_rescan_finding_ids():
    from enzo.validator.rescan import _finding_ids_from_list, _high_severity_ids
    findings = [
        {"finding_id": "a1", "severity": "CRITICAL"},
        {"finding_id": "b2", "severity": "LOW"},
        {"id": "c3", "severity": "HIGH"},
    ]
    ids = _finding_ids_from_list(findings)
    assert_eq(ids, {"a1", "b2", "c3"})

    high = _high_severity_ids(findings)
    assert_eq(high, {"a1", "c3"})


@test("Closed loop: full validate() wires worktree → build → test → rescan")
def test_closed_loop_validate():
    from enzo.config import EnzoConfig
    from enzo.models import EnzoFinding
    from enzo.validator.runner import Validator
    with tempfile.TemporaryDirectory() as tmpdir:
        repo = _make_mock_repo(tmpdir)
        finding = EnzoFinding.from_db_row(_make_finding_row())

        cfg = EnzoConfig(
            build_command="echo build_ok",
            test_command="echo test_ok",
            require_tests_pass=True,
        )
        validator = Validator(cfg)

        # Valid diff that adds a file
        diff = """--- /dev/null
+++ b/enzo_fix.txt
@@ -0,0 +1 @@
+fixed
"""
        report, wt = validator.validate(
            finding=finding,
            repo_path=repo,
            diff=diff,
            files_modified=["enzo_fix.txt"],
            ecosystem="npm",
        )

        # Build and test should pass (echo commands)
        assert_true(report.build.passed, f"Build failed: {report.build.error}")
        assert_true(report.test.passed, f"Test failed: {report.test.error}")
        # Rescan skipped (no scanner) but that's ok
        assert_true(report.rescan.passed)
        assert_true(report.all_passed, f"Not all passed: {report.first_failure}")

        # Worktree should be live (not cleaned up)
        assert_not_none(wt)
        assert_true(Path(wt.path).exists())
        # The fix file exists in worktree
        assert_true((Path(wt.path) / "enzo_fix.txt").exists())
        # But NOT in original repo
        assert_false((Path(repo) / "enzo_fix.txt").exists())

        wt.cleanup()


@test("Closed loop: validate fails on bad build → worktree cleaned up")
def test_closed_loop_build_fail():
    from enzo.config import EnzoConfig
    from enzo.models import EnzoFinding
    from enzo.validator.runner import Validator
    with tempfile.TemporaryDirectory() as tmpdir:
        repo = _make_mock_repo(tmpdir)
        finding = EnzoFinding.from_db_row(_make_finding_row())

        cfg = EnzoConfig(build_command="false")  # always fails
        validator = Validator(cfg)

        diff = "--- /dev/null\n+++ b/fix.txt\n@@ -0,0 +1 @@\n+x\n"
        report, wt = validator.validate(
            finding=finding, repo_path=repo, diff=diff,
        )

        assert_false(report.build.passed)
        assert_none(wt, "Worktree should be cleaned up on failure")
        # Original repo untouched
        assert_false((Path(repo) / "fix.txt").exists())


@test("Closed loop: validate fails on bad diff → no worktree")
def test_closed_loop_bad_diff():
    from enzo.config import EnzoConfig
    from enzo.models import EnzoFinding
    from enzo.validator.runner import Validator
    with tempfile.TemporaryDirectory() as tmpdir:
        repo = _make_mock_repo(tmpdir)
        finding = EnzoFinding.from_db_row(_make_finding_row())

        cfg = EnzoConfig(build_command="echo ok")
        validator = Validator(cfg)

        bad_diff = "this is not a valid diff at all"
        report, wt = validator.validate(
            finding=finding, repo_path=repo, diff=bad_diff,
        )

        assert_none(wt)
        # Should have a failure in build (which catches apply)
        assert_not_none(report.build)
        assert_false(report.build.passed)


# ═══════════════════════════════════════════════════════════════════════════
#  TEST: Git Ops
# ═══════════════════════════════════════════════════════════════════════════

@test("git_ops: branch, commit, current state")
def test_git_ops():
    from enzo import git_ops
    with tempfile.TemporaryDirectory() as tmpdir:
        repo = _make_mock_repo(tmpdir)

        branch = git_ops.get_current_branch(repo)
        assert_in(branch, ("main", "master"))

        commit = git_ops.get_current_commit(repo)
        assert_true(len(commit) == 40)

        assert_false(git_ops.has_uncommitted_changes(repo))

        # Create branch
        ok = git_ops.create_branch(repo, "reachable/fix/test123")
        assert_true(ok)
        assert_eq(git_ops.get_current_branch(repo), "reachable/fix/test123")

        # Make a change and commit
        (Path(repo) / "new_file.txt").write_text("hello")
        assert_true(git_ops.has_uncommitted_changes(repo))

        new_commit = git_ops.commit_changes(repo, "test commit")
        assert_not_none(new_commit)
        assert_false(git_ops.has_uncommitted_changes(repo))

        # Restore
        git_ops.restore_branch(repo, branch)
        assert_eq(git_ops.get_current_branch(repo), branch)


@test("git_ops: apply_diff applies valid patch")
def test_git_apply_diff():
    from enzo import git_ops
    with tempfile.TemporaryDirectory() as tmpdir:
        repo = _make_mock_repo(tmpdir)
        # Create a diff that modifies package.json
        diff = """--- a/package.json
+++ b/package.json
@@ -3,7 +3,7 @@
   "version": "1.0.0",
   "dependencies": {
-    "lodash": "4.17.15",
+    "lodash": "4.17.21",
     "express": "4.18.2"
   },
"""
        ok, err = git_ops.apply_diff(repo, diff)
        # May fail due to exact context — that's ok for this test
        # The important thing is it doesn't crash
        assert_true(isinstance(ok, bool))


@test("git_ops: generate_branch_name and commit_message")
def test_git_helpers():
    from enzo import git_ops
    from enzo.models import EnzoFinding

    name = git_ops.generate_branch_name("reachable/fix", "a1b2c3d4e5f67890")
    assert_eq(name, "reachable/fix/a1b2c3d4e5f6")

    f = EnzoFinding.from_db_row(_make_finding_row())
    msg = git_ops.generate_commit_message(f)
    assert_in("fix(security)", msg)
    assert_in("Enzo AI", msg)


# ═══════════════════════════════════════════════════════════════════════════
#  TEST: Attestation
# ═══════════════════════════════════════════════════════════════════════════

@test("build_attestation + sign + verify round-trip")
def test_attestation():
    from enzo.attestation import build_attestation, verify_attestation
    from enzo.models import EnzoFinding, FixType, PatchResult, ValidationReport, ValidationResult

    f = EnzoFinding.from_db_row(_make_finding_row())
    f.fix_type = FixType.DEPENDENCY_UPGRADE
    patch = PatchResult(success=True, diff="...", model_used="local:test")
    val = ValidationReport(
        rescan=ValidationResult(passed=True, stage="rescan"),
        build=ValidationResult(passed=True, stage="build"),
        test=ValidationResult(passed=True, stage="test"),
    )
    att = build_attestation(f, patch, val, "/repo", "reachable/fix/abc", "aaa", "bbb", 1)
    assert_eq(att.finding_id, "a1b2c3d4e5f67890")
    assert_eq(att.scan_after, "PASS")
    assert_true(len(att.signature) > 0)

    # Verify
    d = att.to_dict()
    assert_true(verify_attestation(dict(d)))


# ═══════════════════════════════════════════════════════════════════════════
#  TEST: Knowledge DB (core tests, supplement test_knowledge.py)
# ═══════════════════════════════════════════════════════════════════════════

@test("Knowledge DB: learn + query + export cycle")
def test_knowledge_cycle():
    from enzo.knowledge import EnzoKnowledgeDB
    with tempfile.TemporaryDirectory() as tmpdir:
        kb = EnzoKnowledgeDB(Path(tmpdir) / "knowledge.db")

        # Learn
        for _ in range(5):
            kb.learn_from_attempt(
                finding_type="cve", language="javascript", ecosystem="npm",
                fix_type="dependency_upgrade", strategy="version_bump",
                success=True, attempts_taken=1,
                package_name="axios", from_version="0.21.0", to_version="0.21.1",
                build_passed=True, test_passed=True, rescan_passed=True,
                model_name="deterministic", model_role="local",
            )

        # Query
        hints = kb.get_fix_hints(finding_type="cve", language="javascript")
        assert_true(len(hints) > 0)
        assert_eq(hints[0]["strategy"], "version_bump")
        assert_eq(hints[0]["success_count"], 5)

        safety = kb.get_upgrade_safety("axios", "npm")
        assert_not_none(safety)
        assert_eq(safety["build_success_rate"], 1.0)

        # Export
        export = kb.export_anonymized()
        assert_true(len(export["fix_patterns"]) > 0)
        assert_true(len(export["upgrade_intel"]) > 0)

        kb.close()


# ═══════════════════════════════════════════════════════════════════════════
#  TEST: Pipeline (integration with mocked local model)
# ═══════════════════════════════════════════════════════════════════════════

@test("Pipeline.run classifies and processes findings (dry run)")
def test_pipeline_dry_run():
    from enzo.config import EnzoConfig
    from enzo.pipeline import EnzoPipeline

    with tempfile.TemporaryDirectory() as tmpdir:
        db_path = _make_mock_repo_db(tmpdir)
        repo = _make_mock_repo(tmpdir)

        # Override repo_db_path resolution
        cfg = EnzoConfig(
            repo_path=repo,
            severity_threshold="HIGH",
            local_model="test-model",
            local_endpoint="http://localhost:99999",  # won't connect
            cloud_enabled=False,
            max_retries=0,
        )

        pipeline = EnzoPipeline(cfg, repo)
        # Override the repo.db path to our mock
        pipeline.repo_db_path = db_path
        # Re-init enzo_db with correct path
        from enzo.db import EnzoRepoDB
        from enzo.knowledge import EnzoKnowledgeDB
        pipeline.enzo_db = EnzoRepoDB(db_path)
        pipeline.knowledge = EnzoKnowledgeDB(Path(tmpdir) / "knowledge.db")

        # Mock the local model to return a fake diff
        mock_diff = "--- a/package.json\n+++ b/package.json\n@@ -1 +1 @@\n-old\n+new"
        pipeline.patcher.local.generate = lambda prompt, system, temperature=0.1: {
            "text": mock_diff, "model": "local:test", "latency_ms": 100, "error": None,
        }

        result = pipeline.run(scan_id=1, dry_run=True)

        assert_true(result.total_findings == 5)
        assert_true(result.fixable_findings > 0)  # at least CVE + CWE + secret should be fixable
        assert_true(result.attempted > 0)

        # Check that we got some successes (dry run skips validation)
        dry_successes = [o for o in result.outcomes if o.status.value == "success"]
        assert_true(len(dry_successes) > 0, "At least one finding should succeed in dry run")

        pipeline.close()


@test("Pipeline.fix_finding for specific CVE (dry run)")
def test_pipeline_fix_single():
    from enzo.config import EnzoConfig
    from enzo.db import EnzoRepoDB
    from enzo.knowledge import EnzoKnowledgeDB
    from enzo.pipeline import EnzoPipeline

    with tempfile.TemporaryDirectory() as tmpdir:
        db_path = _make_mock_repo_db(tmpdir)
        repo = _make_mock_repo(tmpdir)

        cfg = EnzoConfig(
            repo_path=repo, severity_threshold="LOW",
            local_model="test", local_endpoint="http://localhost:99999",
            cloud_enabled=False, max_retries=0,
        )
        pipeline = EnzoPipeline(cfg, repo)
        pipeline.repo_db_path = db_path
        pipeline.enzo_db = EnzoRepoDB(db_path)
        pipeline.knowledge = EnzoKnowledgeDB(Path(tmpdir) / "knowledge.db")

        mock_diff = "--- a/package.json\n+++ b/package.json\n@@ -1 +1 @@\n-old\n+new"
        pipeline.patcher.local.generate = lambda prompt, system, temperature=0.1: {
            "text": mock_diff, "model": "local:test", "latency_ms": 50, "error": None,
        }

        outcome = pipeline.fix_finding("a1b2c3d4e5f67890", scan_id=1, dry_run=True)
        assert_eq(outcome.finding_id, "a1b2c3d4e5f67890")
        assert_eq(outcome.status.value, "success")
        assert_eq(outcome.fix_type, "dependency_upgrade")

        pipeline.close()


@test("Pipeline handles model failure gracefully")
def test_pipeline_model_failure():
    from enzo.config import EnzoConfig
    from enzo.db import EnzoRepoDB
    from enzo.knowledge import EnzoKnowledgeDB
    from enzo.pipeline import EnzoPipeline

    with tempfile.TemporaryDirectory() as tmpdir:
        db_path = _make_mock_repo_db(tmpdir)
        repo = _make_mock_repo(tmpdir)

        cfg = EnzoConfig(
            repo_path=repo, severity_threshold="LOW",
            local_model="test", local_endpoint="http://localhost:99999",
            cloud_enabled=False, max_retries=0,
        )
        pipeline = EnzoPipeline(cfg, repo)
        pipeline.repo_db_path = db_path
        pipeline.enzo_db = EnzoRepoDB(db_path)
        pipeline.knowledge = EnzoKnowledgeDB(Path(tmpdir) / "knowledge.db")

        # Mock model that always fails
        pipeline.patcher.local.generate = lambda prompt, system, temperature=0.1: {
            "text": "", "model": "local:test", "latency_ms": 10,
            "error": "Connection refused",
        }

        outcome = pipeline.fix_finding("a1b2c3d4e5f67890", scan_id=1, dry_run=True)
        assert_eq(outcome.status.value, "failed")
        assert_in("Connection refused", outcome.error or "")

        pipeline.close()


# ═══════════════════════════════════════════════════════════════════════════
#  TEST: Setup — resource detection, model selection, config persistence
# ═══════════════════════════════════════════════════════════════════════════

@test("Setup: MODEL_TIERS ordered by quality descending")
def test_setup_tier_order():
    from enzo.setup import MODEL_TIERS
    qualities = [t.quality for t in MODEL_TIERS]
    assert_eq(qualities, ["flagship", "standard", "compact", "minimal"])
    # RAM requirements descend
    rams = [t.ram_gb for t in MODEL_TIERS]
    assert_eq(rams, sorted(rams, reverse=True))


@test("Setup: detect_resources returns populated SystemResources")
def test_setup_detect():
    from enzo.setup import detect_resources
    res = detect_resources("http://localhost:99999")  # Ollama won't be running
    assert_true(res.total_ram_gb > 0, f"Should detect RAM, got {res.total_ram_gb}")
    assert_true(res.disk_free_gb > 0, f"Should detect disk, got {res.disk_free_gb}")
    assert_true(len(res.os_name) > 0)
    assert_true(len(res.arch) > 0)
    assert_false(res.ollama_running)  # port 99999 shouldn't respond


@test("Setup: select_model picks best tier that fits")
def test_setup_select():
    from enzo.setup import SystemResources, select_model

    # 32GB machine → flagship
    res = SystemResources(total_ram_gb=32, available_ram_gb=20, disk_free_gb=50,
                          metal_available=True, gpu_vram_gb=32)
    rec = select_model(res)
    assert_true(rec.fits)
    assert_eq(rec.tier.quality, "flagship")

    # 16GB machine → standard
    res = SystemResources(total_ram_gb=16, available_ram_gb=10, disk_free_gb=50,
                          metal_available=True, gpu_vram_gb=16)
    rec = select_model(res)
    assert_true(rec.fits)
    assert_eq(rec.tier.quality, "standard")

    # 11GB machine → compact (11 * 0.75 = 8.25 > 8.0)
    res = SystemResources(total_ram_gb=11, available_ram_gb=7, disk_free_gb=50,
                          metal_available=True, gpu_vram_gb=11)
    rec = select_model(res)
    assert_true(rec.fits)
    assert_eq(rec.tier.quality, "compact")

    # 6GB machine → minimal (6 * 0.75 = 4.5 > 4.0)
    res = SystemResources(total_ram_gb=6, available_ram_gb=4, disk_free_gb=50,
                          metal_available=True, gpu_vram_gb=6)
    rec = select_model(res)
    assert_true(rec.fits)
    assert_eq(rec.tier.quality, "minimal")

    # 3GB machine → minimal but doesn't fit (3 * 0.75 = 2.25 < 4.0)
    res = SystemResources(total_ram_gb=3, available_ram_gb=2, disk_free_gb=50,
                          metal_available=True, gpu_vram_gb=3)
    rec = select_model(res)
    assert_false(rec.fits)


@test("Setup: select_model respects already-pulled models")
def test_setup_select_pulled():
    from enzo.setup import SystemResources, select_model

    # 11GB machine, compact already pulled → picks compact
    res = SystemResources(
        total_ram_gb=11, available_ram_gb=7, disk_free_gb=2,
        metal_available=True, gpu_vram_gb=11,
        ollama_models=["qwen2.5-coder:7b"],
    )
    rec = select_model(res)
    assert_true(rec.fits)
    assert_eq(rec.tier.quality, "compact")
    assert_true(rec.already_pulled)

    # Low disk but model already pulled → should still fit
    res = SystemResources(
        total_ram_gb=16, available_ram_gb=10, disk_free_gb=1,
        metal_available=True, gpu_vram_gb=16,
        ollama_models=["qwen2.5-coder:14b"],
    )
    rec = select_model(res)
    assert_true(rec.fits)
    assert_eq(rec.tier.quality, "standard")
    assert_true(rec.already_pulled)


@test("Setup: select_model respects disk constraints")
def test_setup_select_disk():
    from enzo.setup import SystemResources, select_model

    # Tons of RAM, tiny disk → bumps down until disk fits
    res = SystemResources(total_ram_gb=64, available_ram_gb=50, disk_free_gb=5)
    rec = select_model(res)
    assert_true(rec.fits)
    assert_in(rec.tier.quality, ("compact", "minimal"))  # 18GB and 8.5GB don't fit


@test("Setup: get_all_recommendations returns all tiers")
def test_setup_list_all():
    from enzo.setup import SystemResources, get_all_recommendations
    res = SystemResources(total_ram_gb=16, available_ram_gb=10, disk_free_gb=50,
                          metal_available=True, gpu_vram_gb=16)
    recs = get_all_recommendations(res)
    assert_eq(len(recs), 4)
    assert_eq(recs[0].tier.quality, "flagship")  # first is always flagship
    assert_false(recs[0].fits)  # 16GB < 24GB * 0.75 → doesn't fit
    assert_true(recs[1].fits)   # standard should fit (16 * 0.75 = 12.0 >= 12)


@test("Setup: config persistence round-trip")
def test_setup_config_persist():
    import enzo.setup as setup_mod
    from enzo.setup import load_global_config, save_global_config

    with tempfile.TemporaryDirectory() as tmpdir:
        # Override global config path for testing
        original_path = setup_mod._GLOBAL_CONFIG_PATH
        test_path = Path(tmpdir) / "config.yml"
        setup_mod._GLOBAL_CONFIG_PATH = test_path

        try:
            save_global_config("qwen2.5-coder:14b", "http://localhost:11434")
            assert_true(test_path.exists())

            config = load_global_config()
            assert_eq(config["local_model"], "qwen2.5-coder:14b")
            assert_eq(config["local_endpoint"], "http://localhost:11434")
            assert_in("configured_at", config)
        finally:
            setup_mod._GLOBAL_CONFIG_PATH = original_path


@test("Setup: save_repo_config writes .reachable.yml")
def test_setup_repo_config():
    from enzo.setup import save_repo_config
    with tempfile.TemporaryDirectory() as tmpdir:
        save_repo_config(tmpdir, "qwen2.5-coder:7b")
        yml_path = Path(tmpdir) / ".reachable.yml"
        assert_true(yml_path.exists())
        content = yml_path.read_text()
        assert_in("qwen2.5-coder:7b", content)


@test("Setup: health check with no Ollama")
def test_setup_health_no_ollama():
    from enzo.setup import check_health
    report = check_health("http://localhost:99999")
    assert_false(report.healthy)
    assert_true(len(report.issues) > 0)


@test("Setup: minimal tier warns about code_patch capability")
def test_setup_minimal_capability():
    from enzo.setup import MODEL_TIERS
    minimal = MODEL_TIERS[-1]
    assert_eq(minimal.quality, "minimal")
    assert_false(minimal.code_patch_capable)
    # Flagship should be capable
    flagship = MODEL_TIERS[0]
    assert_true(flagship.code_patch_capable)


@test("Setup: CLI --list parses correctly")
def test_setup_cli_parse():
    import argparse

    from enzo.cli import _build_subparsers
    parser = argparse.ArgumentParser()
    sub = parser.add_subparsers(dest="command")
    _build_subparsers(sub)
    args = parser.parse_args(["setup", "--list"])
    assert_eq(args.command, "setup")
    assert_true(args.list_tiers)

    args2 = parser.parse_args(["setup", "--model", "codellama:13b", "--gpu"])
    assert_eq(args2.model, "codellama:13b")
    assert_true(args2.gpu)

    args3 = parser.parse_args(["setup", "--check"])
    assert_true(args3.check)


# ═══════════════════════════════════════════════════════════════════════════
#  TEST: CLI arg parsing
# ═══════════════════════════════════════════════════════════════════════════

@test("CLI: scan subcommand parses args")
def test_cli_parse():
    import argparse

    # Just verify the parser builds without error
    parser = argparse.ArgumentParser()
    sub = parser.add_subparsers(dest="command")
    from enzo.cli import _build_subparsers
    _build_subparsers(sub)
    args = parser.parse_args(["scan", "/tmp/repo", "--severity", "CRITICAL", "--reachable-only"])
    assert_eq(args.command, "scan")
    assert_eq(args.severity, "CRITICAL")
    assert_true(args.reachable_only)


@test("CLI: register_enzo_subcommand creates enzo parser")
def test_cli_register():
    import argparse

    from enzo.cli import register_enzo_subcommand
    parser = argparse.ArgumentParser()
    sub = parser.add_subparsers(dest="command")
    register_enzo_subcommand(sub)
    args = parser.parse_args(["enzo", "scan", "/tmp/repo"])
    assert_eq(args.command, "enzo")
    assert_eq(args.enzo_command, "scan")


# ═══════════════════════════════════════════════════════════════════════════
#  Runner
# ═══════════════════════════════════════════════════════════════════════════

def _run_ruff() -> bool:
    """Run ruff on the enzo package. Returns True if clean."""
    enzo_pkg = os.path.join(os.path.dirname(_tests_dir), "enzo")
    try:
        r = subprocess.run(
            [sys.executable, "-m", "ruff", "check", enzo_pkg],
            capture_output=True, text=True, timeout=60,
        )
        if r.returncode != 0:
            stderr = r.stderr or ""
            if "No module named ruff" in stderr or "No module named" in stderr:
                print("  ⚠ ruff not installed — skipping lint (pip install ruff)")
                return True
            print("\n── ruff ──")
            print(r.stdout or stderr)
            print("  ✗ ruff: lint errors (run: ruff check enzo/ to see all)")
            return False
        print("  ✓ ruff: clean")
        return True
    except FileNotFoundError:
        print("  ⚠ ruff not installed — skipping lint (pip install ruff)")
        return True  # non-fatal if ruff absent
    except subprocess.TimeoutExpired:
        print("  ⚠ ruff timed out")
        return True


def main():
    print("=" * 70)
    print("ENZO COMPREHENSIVE TEST SUITE")
    print("=" * 70)

    tests = [v for v in globals().values() if callable(v) and hasattr(v, "_test_name")]

    # Group by module
    sections = {}
    for t in tests:
        name = t._test_name
        section = name.split(":")[0] if ":" in name else "Other"
        sections.setdefault(section, []).append(t)

    for section, funcs in sections.items():
        print(f"\n── {section} ──")
        for func in funcs:
            run_test(func)

    ruff_ok = _run_ruff()

    print(f"\n{'=' * 70}")
    print(f"Results:  {_PASS} passed, {_FAIL} failed, {_SKIP} skipped")
    if not ruff_ok:
        print("          ruff: FAILED")
    if _ERRORS:
        print("\nFailures:")
        for e in _ERRORS:
            print(e)
    print(f"{'=' * 70}")

    return 0 if (_FAIL == 0 and ruff_ok) else 1


if __name__ == "__main__":
    sys.exit(main())
