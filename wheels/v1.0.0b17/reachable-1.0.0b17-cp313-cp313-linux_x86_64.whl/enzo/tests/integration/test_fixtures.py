#!/usr/bin/env python3
"""
Integration test suite — AI-powered fixture fixing.

Requires: GROQ_API_KEY environment variable.
Skip unless ENZO_INTEGRATION=1.

Each test:
  1. Loads a fixture file
  2. Creates a synthetic EnzoFinding
  3. Runs through the full patch engine (real LLM)
  4. Asserts: success, no hallucination, code parses, minimal diff
  5. Writes result to benchmark DB

Run:
    ENZO_INTEGRATION=1 GROQ_API_KEY=gsk_... python3 -m pytest tests/integration/ -v
    or:
    make test-integration
"""
import os
import sys
import time
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent.parent.parent))

SKIP_REASON = "ENZO_INTEGRATION=1 required (also needs GROQ_API_KEY)"
INTEGRATION = os.environ.get("ENZO_INTEGRATION") == "1"

FIXTURES = Path(__file__).parent.parent / "fixtures"


# ── Helpers ───────────────────────────────────────────────────────────────────

def _load_fixture(rel_path: str) -> str:
    return (FIXTURES / rel_path).read_text()


def _make_finding(
    finding_id: str,
    fix_type: str,
    language: str,
    file_path: str,
    line_number: int,
    cwe_id: str = None,
    cve_id: str = None,
    rule_id: str = None,
    package_name: str = None,
    package_version: str = None,
    fix_version: str = None,
    description: str = "",
):
    """Build a synthetic EnzoFinding for testing."""
    from enzo.models import EnzoFinding, FindingSeverity, FixType
    ft_map = {
        "code_patch": FixType.CODE_PATCH,
        "secret_rotation": FixType.SECRET_ROTATION,
        "dependency_upgrade": FixType.DEPENDENCY_UPGRADE,
        "malware": FixType.MALWARE,
    }
    f = EnzoFinding(
        finding_id=finding_id,
        finding_type=fix_type,
        severity=FindingSeverity.CRITICAL,
        fix_type=ft_map[fix_type],
        language=language,
        file_path=str(FIXTURES / file_path),
        line_number=line_number,
        cwe_id=cwe_id,
        cve_id=cve_id,
        rule_id=rule_id or (cwe_id or "").lower().replace("-", "_"),
        package_name=package_name,
        package_version=package_version,
        fix_version=fix_version,
        description=description or f"{fix_type} in {file_path}",
        title=f"Test: {fix_type} {language}",
    )
    return f


def _make_config():
    """Build test EnzoConfig pointing at Groq."""
    from enzo.config import EnzoConfig
    cfg = EnzoConfig()
    cfg.provider = "groq"
    cfg.cloud_enabled = True
    cfg.groq_api_key = os.environ.get("GROQ_API_KEY", "")
    cfg.groq_model = "llama-3.3-70b-versatile"
    cfg.groq_endpoint = "https://api.groq.com/openai"
    cfg.max_attempts = 2
    cfg.candidates_per_attempt = 3
    return cfg


def _make_context(finding, language: str):
    """Build RemediationContext for the finding."""
    from enzo.models import RemediationContext
    content = Path(finding.file_path).read_text() if finding.file_path else ""
    ctx = RemediationContext(
        finding_type=finding.finding_type,
        severity=finding.severity.value if hasattr(finding.severity, 'value') else finding.severity,
        cwe_id=finding.cwe_id,
        cve_id=finding.cve_id,
        language=language,
        fix_type=finding.fix_type.value,
        rule_id=finding.rule_id,
        package_name=finding.package_name,
        package_version=finding.package_version,
        fix_version=finding.fix_version,
    )
    return ctx


class FixtureTestResult:
    """Holds result of one fixture test for benchmark reporting."""
    def __init__(self, fixture_id: str, language: str, fix_type: str):
        self.fixture_id = fixture_id
        self.language = language
        self.fix_type = fix_type
        self.success = False
        self.attempt = 0
        self.hallucination_count = 0
        self.semgrep_verified = None
        self.new_findings = 0
        self.ast_valid = False
        self.lines_changed = 0
        self.tokens_in = 0
        self.tokens_out = 0
        self.cost_usd = 0.0
        self.duration_ms = 0
        self.error = ""
        self.patcher_method = "ai"

    def assert_all(self, test_case: unittest.TestCase):
        test_case.assertTrue(self.success,
            f"[{self.fixture_id}] Patch failed: {self.error}")
        test_case.assertEqual(self.hallucination_count, 0,
            f"[{self.fixture_id}] Hallucinated on final attempt")
        test_case.assertTrue(self.ast_valid,
            f"[{self.fixture_id}] Patched code does not parse")
        test_case.assertLessEqual(self.attempt, 2,
            f"[{self.fixture_id}] Needed {self.attempt} attempts (max 2)")


def _run_patch(finding, config, language: str) -> FixtureTestResult:
    """Run patch engine against a fixture finding. Returns FixtureTestResult."""
    import ast as pyast

    from enzo.patcher.engine import PatchEngine

    ftr = FixtureTestResult(
        fixture_id=finding.finding_id,
        language=language,
        fix_type=finding.fix_type.value,
    )

    ctx = _make_context(finding, language)
    engine = PatchEngine(config)
    repo_path = str(FIXTURES.parent.parent)  # enzo root as fake repo

    t0 = time.monotonic()
    try:
        result = engine.generate_patch(finding, ctx, repo_path, attempt_number=1)
        ftr.attempt = 1
        if not result.success:
            # Try attempt 2
            result = engine.generate_patch(finding, ctx, repo_path, attempt_number=2,
                                           prior_error=result.error)
            ftr.attempt = 2

        ftr.success = result.success
        ftr.error = result.error or ""
        ftr.patcher_method = result.model_used or "ai"
        ftr.tokens_in = getattr(result, 'tokens_in', 0) or 0
        ftr.tokens_out = getattr(result, 'tokens_out', 0) or 0
        ftr.cost_usd = getattr(result, 'cost_usd', 0.0) or 0.0

        if result.success and result.patched_content:
            # Count lines changed
            orig = Path(finding.file_path).read_text() if finding.file_path else ""
            orig_lines = set(orig.splitlines())
            new_lines = set(result.patched_content.splitlines())
            ftr.lines_changed = len(orig_lines.symmetric_difference(new_lines))

            # AST validity check for Python
            if language == "python":
                try:
                    pyast.parse(result.patched_content)
                    ftr.ast_valid = True
                except SyntaxError:
                    ftr.ast_valid = False
            else:
                ftr.ast_valid = True  # non-Python: trust the patch

        elif result.success:
            ftr.ast_valid = True

    except Exception as e:
        ftr.success = False
        ftr.error = str(e)

    ftr.duration_ms = int((time.monotonic() - t0) * 1000)
    return ftr


# ── Test Cases ────────────────────────────────────────────────────────────────

@unittest.skipUnless(INTEGRATION, SKIP_REASON)
class TestCWE89SQLInjection(unittest.TestCase):
    """CWE-89 SQL Injection across Python, Go, Java, TypeScript."""

    def _test_sqli(self, language: str, fixture: str, line: int):
        finding = _make_finding(
            finding_id=f"test_{language}_cwe89",
            fix_type="code_patch", language=language,
            file_path=fixture, line_number=line,
            cwe_id="CWE-89", rule_id="cwe89_sqli",
            description="SQL injection via string concatenation",
        )
        config = _make_config()
        ftr = _run_patch(finding, config, language)
        ftr.assert_all(self)

    def test_python_sqli(self):
        self._test_sqli("python", "python/cwe89_sqli.py", line=14)

    def test_go_sqli(self):
        self._test_sqli("go", "go/cwe89_sqli.go", line=14)

    def test_java_sqli(self):
        self._test_sqli("java", "java/cwe89_sqli.java", line=14)

    def test_typescript_sqli(self):
        self._test_sqli("typescript", "typescript/cwe89_sqli.ts", line=10)


@unittest.skipUnless(INTEGRATION, SKIP_REASON)
class TestCWE78CommandInjection(unittest.TestCase):
    """CWE-78 Command Injection across Python, Go, TypeScript."""

    def _test_cmdi(self, language: str, fixture: str, line: int):
        finding = _make_finding(
            finding_id=f"test_{language}_cwe78",
            fix_type="code_patch", language=language,
            file_path=fixture, line_number=line,
            cwe_id="CWE-78", rule_id="cwe78_cmdi",
            description="Command injection via user-controlled input",
        )
        ftr = _run_patch(finding, _make_config(), language)
        ftr.assert_all(self)

    def test_python_cmdi(self):
        self._test_cmdi("python", "python/cwe78_cmdi.py", line=10)

    def test_go_cmdi(self):
        self._test_cmdi("go", "go/cwe78_cmdi.go", line=12)

    def test_typescript_cmdi(self):
        self._test_cmdi("typescript", "typescript/cwe78_cmdi.ts", line=9)


@unittest.skipUnless(INTEGRATION, SKIP_REASON)
class TestCWE22PathTraversal(unittest.TestCase):
    """CWE-22 Path Traversal across Python, Go, TypeScript."""

    def _test_traversal(self, language: str, fixture: str, line: int):
        finding = _make_finding(
            finding_id=f"test_{language}_cwe22",
            fix_type="code_patch", language=language,
            file_path=fixture, line_number=line,
            cwe_id="CWE-22", rule_id="cwe22_traversal",
            description="Path traversal via unsanitized user input",
        )
        ftr = _run_patch(finding, _make_config(), language)
        ftr.assert_all(self)

    def test_python_traversal(self):
        self._test_traversal("python", "python/cwe22_traversal.py", line=10)

    def test_go_traversal(self):
        self._test_traversal("go", "go/cwe22_traversal.go", line=13)

    def test_typescript_traversal(self):
        self._test_traversal("typescript", "typescript/cwe79_xss.ts", line=10)


@unittest.skipUnless(INTEGRATION, SKIP_REASON)
class TestCWE326WeakCrypto(unittest.TestCase):
    """CWE-326 Weak Cryptography across Python, Java."""

    def _test_crypto(self, language: str, fixture: str, line: int):
        finding = _make_finding(
            finding_id=f"test_{language}_cwe326",
            fix_type="code_patch", language=language,
            file_path=fixture, line_number=line,
            cwe_id="CWE-326", rule_id="cwe326_weak_crypto",
            description="Weak cryptographic algorithm used for password hashing",
        )
        ftr = _run_patch(finding, _make_config(), language)
        ftr.assert_all(self)

    def test_python_weak_crypto(self):
        self._test_crypto("python", "python/cwe326_weak_crypto.py", line=8)

    def test_java_weak_crypto(self):
        self._test_crypto("java", "java/cwe326_weak_crypto.java", line=12)


@unittest.skipUnless(INTEGRATION, SKIP_REASON)
class TestCWE79XSS(unittest.TestCase):
    """CWE-79 XSS — TypeScript/Express."""

    def test_typescript_xss(self):
        finding = _make_finding(
            finding_id="test_ts_cwe79",
            fix_type="code_patch", language="typescript",
            file_path="typescript/cwe79_xss.ts", line_number=10,
            cwe_id="CWE-79", rule_id="cwe79_xss",
            description="XSS via unsanitized user input in HTML response",
        )
        ftr = _run_patch(finding, _make_config(), "typescript")
        ftr.assert_all(self)


if __name__ == "__main__":
    unittest.main(verbosity=2)
