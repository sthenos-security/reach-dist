# Fixture: dlp_patch · Python · PII in logging (SSN)
# pii_type=ssn  pii_field=record.ssn  flow_type=logging
import logging

logger = logging.getLogger(__name__)

def process_claim(record):
    # VULNERABLE: CWE-359 · line 8 — raw SSN in log
    logger.debug("Processing claim for SSN: %s", record.ssn)
    record.processed = True
    return record
