# Fixture: dlp_patch · Python · PII in logging (email)
# pii_type=email  pii_field=user.email  flow_type=logging
import logging

logger = logging.getLogger(__name__)

def process_signup(user):
    # VULNERABLE: CWE-359 · line 9 — raw email in log
    logger.info("New signup: user=%s email=%s", user.username, user.email)
    user.activated = True
    return user
