# Fixture: dlp_patch · Python · PII in DB storage (credit card)
# pii_type=credit_card  pii_field=payment.card_number  flow_type=storage
import sqlite3


def save_payment(db_path, payment):
    conn = sqlite3.connect(db_path)
    # VULNERABLE: CWE-359 · line 8 — raw card number stored in DB
    conn.execute(
        "INSERT INTO payments (order_id, card_number, amount) VALUES (?, ?, ?)",
        (payment.order_id, payment.card_number, payment.amount)
    )
    conn.commit()
    conn.close()
