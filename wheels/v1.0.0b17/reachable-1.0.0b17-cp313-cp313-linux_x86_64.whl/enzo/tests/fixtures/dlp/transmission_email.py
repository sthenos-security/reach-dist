# Fixture: dlp_patch · Python · PII in API response (email)
# pii_type=email  pii_field=user.email  flow_type=transmission
from flask import jsonify


def get_user_profile(user):
    # VULNERABLE: CWE-359 · line 8 — raw email in API response
    return jsonify({
        "id": user.id,
        "username": user.username,
        "email": user.email,
        "created_at": user.created_at.isoformat(),
    })
