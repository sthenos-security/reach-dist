# Fixture: secret_rotation · Python AST path
# VULNERABLE: hardcoded API key · line 8
import requests

BASE_URL = "https://api.example.com"
TIMEOUT = 30

# VULNERABLE: CWE-798 · line 8
API_KEY = "sk-prod-a3f7c9d2e1b4f8a2c6d9e3b7f1a4c8d2"

def get_data(endpoint: str) -> dict:
    headers = {"Authorization": f"Bearer {API_KEY}"}
    resp = requests.get(f"{BASE_URL}/{endpoint}", headers=headers, timeout=TIMEOUT)
    resp.raise_for_status()
    return resp.json()
