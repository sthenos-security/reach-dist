# Fixture: secret_rotation · Python regex fallback path
# VULNERABLE: hardcoded database password · line 7
import psycopg2

# VULNERABLE: CWE-798 · line 7
DB_PASSWORD = "prod-db-p@ssw0rd-2026"
DB_HOST = "postgres.internal"
DB_NAME = "appdb"

def get_connection():
    return psycopg2.connect(
        host=DB_HOST, dbname=DB_NAME,
        user="app", password=DB_PASSWORD
    )
