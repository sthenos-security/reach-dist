# Fixture: code_patch · CWE-89 SQL Injection · Python
# VULNERABLE: string concatenation in SQL query · line 14
import sqlite3


def get_user(db_path: str, username: str) -> dict:
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    # VULNERABLE: CWE-89 · line 14
    query = "SELECT * FROM users WHERE username = '" + username + "'"
    cursor.execute(query)
    row = cursor.fetchone()
    conn.close()
    if row:
        return {"id": row[0], "username": row[1], "email": row[2]}
    return {}
