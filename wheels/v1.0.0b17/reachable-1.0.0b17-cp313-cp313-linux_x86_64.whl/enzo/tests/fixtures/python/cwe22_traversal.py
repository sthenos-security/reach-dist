# Fixture: code_patch · CWE-22 Path Traversal · Python
# VULNERABLE: unsanitized user path used in file open · line 10
import os

BASE_DIR = "/app/reports"

def read_report(filename: str) -> str:
    """Read a report file by name."""
    # VULNERABLE: CWE-22 · line 10
    file_path = os.path.join(BASE_DIR, filename)
    with open(file_path, "r") as f:
        return f.read()
