# Fixture: code_patch · CWE-78 Command Injection · Python
# VULNERABLE: shell=True with user-controlled input · line 10
import subprocess


def run_scan(target: str) -> str:
    """Run nmap scan against a user-supplied target."""
    # VULNERABLE: CWE-78 · line 10
    result = subprocess.run(
        f"nmap -sV {target}", shell=True,
        capture_output=True, text=True, timeout=30
    )
    return result.stdout

