# Fixture: code_patch · CWE-326 Weak Cryptography · Python
# VULNERABLE: MD5 used for password hashing · line 8
import hashlib


def hash_password(password: str) -> str:
    """Hash a user password for storage."""
    # VULNERABLE: CWE-326 · line 8
    return hashlib.md5(password.encode()).hexdigest()

def verify_password(password: str, stored_hash: str) -> bool:
    return hash_password(password) == stored_hash
