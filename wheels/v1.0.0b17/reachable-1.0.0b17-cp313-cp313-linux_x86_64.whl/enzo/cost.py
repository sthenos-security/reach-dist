"""
Token and cost estimation for cloud provider runs.

Estimates before the pipeline starts, based on:
  - Number of fixable findings
  - Average code slice size (sampled or estimated)
  - Candidates per attempt × max attempts
  - System + prompt overhead
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

# ── Pricing table (per million tokens) ────────────────────────────────────────
# Update when providers change pricing.
_PRICING: dict[str, dict[str, float]] = {
    # Groq — https://console.groq.com/docs/pricing
    "groq:llama-3.3-70b-versatile":      {"input": 0.59, "output": 0.99},
    "groq:llama-3.1-8b-instant":         {"input": 0.05, "output": 0.08},
    "groq:qwen/qwen3-32b":               {"input": 0.29, "output": 0.59},
    # Anthropic — https://www.anthropic.com/pricing
    "claude:claude-sonnet-4-5":          {"input": 3.00, "output": 15.00},
    "claude:claude-opus-4-5":            {"input": 15.00, "output": 75.00},
    "claude:claude-haiku-4-5-20251001":  {"input": 0.80, "output": 4.00},
    # Fallback for unknown models
    "groq:*":   {"input": 0.59, "output": 0.99},
    "claude:*": {"input": 3.00, "output": 15.00},
}

# ── Per-call overhead constants (tokens) ──────────────────────────────────────
_SYSTEM_PROMPT_TOKENS  = 350   # system prompt overhead
_PROMPT_OVERHEAD_TOKENS = 200  # instruction framing around the code slice
_OUTPUT_TOKENS_PER_CAND = 512  # typical diff output per candidate
_CHARS_PER_TOKEN        = 3.8  # rough chars-per-token for code


@dataclass
class CostEstimate:
    provider: str
    model: str
    findings: int
    candidates_per_attempt: int
    max_attempts: int
    avg_slice_chars: int

    # Derived
    total_calls: int = 0
    input_tokens: int = 0
    output_tokens: int = 0
    cost_usd_low: float = 0.0
    cost_usd_high: float = 0.0

    def __post_init__(self):
        # Worst case: all attempts used, all candidates generated each attempt
        self.total_calls = (
            self.findings
            * self.max_attempts
            * self.candidates_per_attempt
        )
        tokens_per_call = (
            _SYSTEM_PROMPT_TOKENS
            + _PROMPT_OVERHEAD_TOKENS
            + int(self.avg_slice_chars / _CHARS_PER_TOKEN)
        )
        self.input_tokens  = self.total_calls * tokens_per_call
        self.output_tokens = self.total_calls * _OUTPUT_TOKENS_PER_CAND

        pricing = self._get_pricing()
        input_cost  = (self.input_tokens  / 1_000_000) * pricing["input"]
        output_cost = (self.output_tokens / 1_000_000) * pricing["output"]
        self.cost_usd_high = input_cost + output_cost

        # Optimistic: ~30% of calls succeed on attempt 1 (no retry)
        # and hallucinations short-circuit candidate loop
        self.cost_usd_low = self.cost_usd_high * 0.25

    def _get_pricing(self) -> dict[str, float]:
        key = f"{self.provider}:{self.model}"
        if key in _PRICING:
            return _PRICING[key]
        wildcard = f"{self.provider}:*"
        return _PRICING.get(wildcard, {"input": 1.0, "output": 5.0})

    @property
    def total_tokens(self) -> int:
        return self.input_tokens + self.output_tokens

    def format(self) -> str:
        lines = []
        lines.append(f"\n  {'─' * 56}")
        lines.append(f"  COST ESTIMATE  ({self.provider} / {self.model})")
        lines.append(f"  {'─' * 56}")
        lines.append(f"  Findings to fix:     {self.findings}")
        lines.append(
            f"  Max API calls:       {self.total_calls}"
            f"  ({self.findings} × {self.max_attempts} attempts × "
            f"{self.candidates_per_attempt} candidates)"
        )
        lines.append(
            f"  Input tokens (max):  {self.input_tokens:,}"
            f"  (~{self.avg_slice_chars} chars/slice)"
        )
        lines.append(f"  Output tokens (max): {self.output_tokens:,}")
        lines.append(
            f"  Estimated cost:      "
            f"${self.cost_usd_low:.3f} – ${self.cost_usd_high:.3f}"
            f"  (best–worst case)"
        )
        # Warn if Groq free tier TPD limit likely exceeded
        if self.provider == "groq":
            groq_free_tpd = 100_000
            if self.input_tokens > groq_free_tpd:
                lines.append(
                    f"  ⚠  WARNING: worst-case {self.input_tokens:,} tokens exceeds"
                    f" Groq free tier ({groq_free_tpd:,}/day)"
                )
                lines.append(
                    "     Consider: fewer findings, --mode local, or upgrade Groq tier"
                )
        lines.append(f"  {'─' * 56}")
        return "\n".join(lines)


def estimate_run_cost(
    config,
    fixable_findings: list,
    repo_path: str,
) -> Optional[CostEstimate]:
    """
    Build a cost estimate for a cloud run before it starts.
    Returns None if cost estimation is not applicable (local mode).
    """
    from .classifier import FixType

    provider = getattr(config, "provider", "claude")
    if config.mode not in ("cloud", "fallback"):
        return None
    if provider == "groq" and not getattr(config, "groq_api_key", ""):
        return None

    model = (
        getattr(config, "groq_model", "llama-3.3-70b-versatile")
        if provider == "groq"
        else getattr(config, "cloud_model", "claude-sonnet-4-5")
    )

    # Sample up to 5 code findings to get avg slice size
    import os
    code_findings = [
        f for f in fixable_findings
        if getattr(f, "fix_type", None)
        and f.fix_type in (FixType.CODE_PATCH,)
        and f.file_path
    ]
    slice_chars = 2000  # default if no files to sample
    if code_findings:
        sample = code_findings[:5]
        sizes = []
        for f in sample:
            fp = (
                f.file_path if os.path.isabs(f.file_path)
                else os.path.join(repo_path, f.file_path)
            )
            try:
                size = os.path.getsize(fp)
                # Code reducer brings it to ~15% of file on average
                sizes.append(int(size * 0.15))
            except OSError:
                sizes.append(2000)
        slice_chars = int(sum(sizes) / len(sizes))
        slice_chars = max(500, min(slice_chars, 8000))

    return CostEstimate(
        provider=provider,
        model=model,
        findings=len(fixable_findings),
        candidates_per_attempt=3,
        max_attempts=getattr(config, "max_retries", 3),
        avg_slice_chars=slice_chars,
    )
