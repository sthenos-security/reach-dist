#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.
"""
Enzo context builder.

Constructs RemediationContext (metadata envelope) from:
  - EnzoFinding (from repo.db)
  - Call graph / call_paths_v2 (from repo.db raw_data)
  - Knowledge DB hints
  - Project environment detection

The output is safe to send to the cloud model — no source code.
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any, Dict, List, Optional

from .models import EnzoFinding, RemediationContext

logger = logging.getLogger(__name__)

# Optional: NodeKind for interpreting call_paths_v2
try:
    from reachable.engine.hop_registry import NodeKind
    _HAS_HOP_REGISTRY = True
except ImportError:
    _HAS_HOP_REGISTRY = False
    NodeKind = None


# ═══════════════════════════════════════════════════════════════════════════
#  Project environment detection
# ═══════════════════════════════════════════════════════════════════════════

_BUILD_INDICATORS = {
    "package.json":       ("javascript", "npm"),
    "yarn.lock":          ("javascript", "yarn"),
    "pnpm-lock.yaml":     ("javascript", "pnpm"),
    "requirements.txt":   ("python", "pip"),
    "pyproject.toml":     ("python", "pip"),
    "Pipfile":            ("python", "pipenv"),
    "setup.py":           ("python", "pip"),
    "go.mod":             ("go", "go"),
    "pom.xml":            ("java", "maven"),
    "build.gradle":       ("java", "gradle"),
    "build.gradle.kts":   ("java", "gradle"),
    "Cargo.toml":         ("rust", "cargo"),
    "Gemfile":            ("ruby", "bundler"),
    "composer.json":      ("php", "composer"),
}

_TEST_INDICATORS = {
    "python": [
        ("pytest.ini", "pytest"), ("pyproject.toml", "pytest"), ("setup.cfg", "pytest"),
        ("tox.ini", "tox"),
    ],
    "javascript": [
        ("jest.config.js", "jest"), ("jest.config.ts", "jest"),
        (".mocharc.yml", "mocha"), ("vitest.config.ts", "vitest"),
    ],
    "go": [("go.mod", "go test")],
    "java": [("pom.xml", "maven"), ("build.gradle", "gradle")],
    "rust": [("Cargo.toml", "cargo test")],
}

_FRAMEWORK_INDICATORS = {
    "python": {
        "flask": ["from flask", "import flask", "Flask("],
        "django": ["from django", "import django", "DJANGO_SETTINGS"],
        "fastapi": ["from fastapi", "import fastapi", "FastAPI("],
    },
    "javascript": {
        "react": ["from 'react'", "from \"react\"", "require('react')"],
        "express": ["from 'express'", "require('express')"],
        "next": ["from 'next'", "next.config"],
        "vue": ["from 'vue'", "createApp"],
    },
    "go": {
        "gin": ["github.com/gin-gonic/gin"],
        "echo": ["github.com/labstack/echo"],
        "fiber": ["github.com/gofiber/fiber"],
    },
    "java": {
        "spring": ["org.springframework", "SpringBootApplication"],
    },
}


def detect_environment(repo_path: str) -> Dict[str, Optional[str]]:
    """Detect language, build system, test framework, and framework from project files."""
    repo = Path(repo_path)
    result: Dict[str, Optional[str]] = {
        "language": None,
        "build_system": None,
        "test_framework": None,
        "framework": None,
    }

    # Detect language + build system
    for indicator, (lang, build) in _BUILD_INDICATORS.items():
        if (repo / indicator).exists():
            result["language"] = lang
            result["build_system"] = build
            break

    if not result["language"]:
        return result

    lang = result["language"]

    # Detect test framework
    for indicator, test_fw in _TEST_INDICATORS.get(lang, []):
        if (repo / indicator).exists():
            result["test_framework"] = test_fw
            break

    # Detect framework (quick scan of key files)
    framework_patterns = _FRAMEWORK_INDICATORS.get(lang, {})
    if framework_patterns:
        # Check common entry points
        candidates = []
        for ext in {"*.py", "*.js", "*.ts", "*.go", "*.java"}:
            candidates.extend(repo.glob(ext))
            candidates.extend((repo / "src").glob(f"**/{ext}") if (repo / "src").is_dir() else [])
            candidates.extend((repo / "app").glob(f"**/{ext}") if (repo / "app").is_dir() else [])
        candidates = candidates[:50]  # cap scan

        for fpath in candidates:
            try:
                content = fpath.read_text(errors="replace")[:5000]
                for fw_name, patterns in framework_patterns.items():
                    if any(p in content for p in patterns):
                        result["framework"] = fw_name
                        break
                if result["framework"]:
                    break
            except OSError:
                continue

    return result


# ═══════════════════════════════════════════════════════════════════════════
#  Call path analysis
# ═══════════════════════════════════════════════════════════════════════════

def _extract_call_paths_v2(finding: EnzoFinding) -> Optional[List[Dict]]:
    """Extract call_paths_v2 from finding's raw_data."""
    if not finding.raw_data:
        return None
    # Try direct field
    paths = finding.raw_data.get("call_paths_v2")
    if paths and isinstance(paths, list):
        return paths
    # Try nested in reachability data
    reach = finding.raw_data.get("reachability", {})
    if isinstance(reach, dict):
        paths = reach.get("call_paths_v2")
        if paths and isinstance(paths, list):
            return paths
    return None


def _build_kind_chain(call_paths: List) -> str:
    """
    Build abstracted NodeKind chain from call_paths_v2.
    e.g. "entry → app → app → sink_vuln"

    call_paths_v2 is a list of paths, each path is a list of node dicts.
    Uses the first (shortest/primary) path.
    This is SAFE to send to cloud — no function names, only semantic roles.
    """
    if not call_paths:
        return ""
    # call_paths_v2 = [[{node}, {node}], [{node}, ...]] — take first path
    first_path = call_paths[0]
    if isinstance(first_path, list):
        kinds = [n.get("kind", "app") for n in first_path if isinstance(n, dict)]
    elif isinstance(first_path, dict):
        # Flat list of nodes (legacy format)
        kinds = [n.get("kind", "app") for n in call_paths if isinstance(n, dict)]
    else:
        return ""
    return " → ".join(kinds)


def _has_kind(call_paths: List, target_kind: str) -> bool:
    for item in call_paths:
        if isinstance(item, list):
            # Nested: list of paths
            if any(isinstance(n, dict) and n.get("kind") == target_kind for n in item):
                return True
        elif isinstance(item, dict):
            # Flat: list of nodes
            if item.get("kind") == target_kind:
                return True
    return False


# ═══════════════════════════════════════════════════════════════════════════
#  Build RemediationContext
# ═══════════════════════════════════════════════════════════════════════════

def build_context(
    finding: EnzoFinding,
    repo_path: str,
    dependency_chain: Optional[List[str]] = None,
    knowledge_hints: Optional[Dict[str, Any]] = None,
    attempt_number: int = 1,
    prior_errors: Optional[List[str]] = None,
    prior_strategies: Optional[List[str]] = None,
) -> RemediationContext:
    """
    Build a RemediationContext from finding + environment.

    This is the metadata envelope — safe to send to cloud model.
    """
    env = detect_environment(repo_path)

    # Extract call paths
    call_paths = _extract_call_paths_v2(finding)
    kind_chain = None
    path_length = None
    has_guard = False
    has_boundary = False

    if call_paths:
        kind_chain = _build_kind_chain(call_paths)
        first = call_paths[0]
        path_length = len(first) if isinstance(first, list) else len(call_paths)
        has_guard = _has_kind(call_paths, "guard")
        has_boundary = _has_kind(call_paths, "boundary")
        # Store on finding for local model use
        finding.call_paths_v2 = call_paths

    # Exploitability from raw_data
    epss_score = None
    epss_percentile = None
    in_kev = False
    exploit_db = False
    metasploit = False
    osv_aliases: list = []
    osv_summary = None
    osv_cwes: list = []
    osv_withdrawn = None
    if finding.raw_data:
        epss_score = finding.raw_data.get("epss_score")
        epss_percentile = finding.raw_data.get("epss_percentile")
        in_kev = bool(finding.raw_data.get("in_kev") or finding.raw_data.get("in_cisa_kev"))
        exploit_db = bool(finding.raw_data.get("exploit_db_available"))
        metasploit = bool(finding.raw_data.get("metasploit_module") or finding.raw_data.get("metasploit_available"))
        # OSV package group enrichment
        osv_aliases  = list(finding.raw_data.get("osv_aliases") or [])
        osv_summary  = finding.raw_data.get("osv_summary")
        osv_cwes     = list(finding.raw_data.get("osv_cwes") or [])
        osv_withdrawn = finding.raw_data.get("osv_withdrawn")

    # Knowledge hints
    known_pattern = None
    known_rate = None
    if knowledge_hints:
        known_pattern = knowledge_hints.get("strategy")
        sc = knowledge_hints.get("success_count", 0)
        fc = knowledge_hints.get("failure_count", 0)
        if (sc + fc) > 0:
            known_rate = sc / (sc + fc)

    ctx = RemediationContext(
        finding_type=finding.finding_type,
        severity=finding.severity,
        cwe_id=finding.cwe_id,
        cve_id=finding.cve_id,
        fix_status=finding.fix_status,
        fix_version=finding.fix_version,
        package_name=finding.package_name,
        package_version=finding.package_version,
        rule_id=finding.rule_id,

        app_reachability=finding.app_reachability,
        reachability_confidence=finding.app_reachability_confidence,
        platform_exposure=finding.platform_exposure,

        reachability_kind_chain=kind_chain,
        path_length=path_length,
        has_guard_node=has_guard,
        has_boundary_node=has_boundary,

        epss_score=epss_score,
        epss_percentile=epss_percentile,
        in_kev=in_kev,
        exploit_db_available=exploit_db,
        metasploit_available=metasploit,
        osv_aliases=osv_aliases,
        osv_summary=osv_summary,
        osv_cwes=osv_cwes,
        osv_withdrawn=osv_withdrawn,

        language=env.get("language") or "",
        framework=env.get("framework"),
        build_system=env.get("build_system") or "",
        test_framework=env.get("test_framework"),

        dependency_chain=dependency_chain or [],
        fix_type=finding.fix_type.value,

        known_fix_pattern=known_pattern,
        known_success_rate=known_rate,

        attempt_number=attempt_number,
        prior_errors=prior_errors or [],
        prior_strategies=prior_strategies or [],
    )
    return ctx
