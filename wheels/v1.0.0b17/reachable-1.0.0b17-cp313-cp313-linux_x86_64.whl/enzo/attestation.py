#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.
"""
Remediation attestation — signed proof of verified fix.

v1: HMAC-SHA256 with local key.
v2: Sigstore / cosign integration.
"""

from __future__ import annotations

import hashlib
import hmac
import json
import os
from datetime import datetime

from .models import EnzoFinding, PatchResult, RemediationAttestation, ValidationReport


def _get_signing_key() -> bytes:
    """Get or generate signing key."""
    key = os.environ.get("ENZO_SIGNING_KEY", "")
    if key:
        return key.encode("utf-8")
    # Deterministic fallback — machine-specific
    import platform
    seed = f"enzo-{platform.node()}-{os.getuid() if hasattr(os, 'getuid') else 'win'}"
    return hashlib.sha256(seed.encode()).digest()


def build_attestation(
    finding: EnzoFinding,
    patch: PatchResult,
    validation: ValidationReport,
    repo_path: str,
    branch: str,
    original_commit: str,
    remediation_commit: str,
    attempts: int = 1,
) -> RemediationAttestation:
    """Build an attestation from remediation results."""
    att = RemediationAttestation(
        finding_id=finding.finding_id,
        finding_type=finding.finding_type,
        cve_id=finding.cve_id,
        cwe_id=finding.cwe_id,
        severity=finding.severity,
        app_reachability=finding.app_reachability,
        repository=repo_path,
        branch=branch,
        original_commit=original_commit,
        remediation_commit=remediation_commit,
        fix_type=finding.fix_type.value,
        model_used=patch.model_used,
        cloud_strategy_used=patch.cloud_strategy is not None,
        scan_before="FAIL",
        scan_after="PASS" if validation.rescan and validation.rescan.passed else "UNKNOWN",
        build_status="PASS" if validation.build and validation.build.passed else "UNKNOWN",
        test_status="PASS" if validation.test and validation.test.passed else "UNKNOWN",
        attempts=attempts,
        epss_score=finding.raw_data.get("epss_score") if finding.raw_data else None,
        in_kev=bool(finding.raw_data.get("in_kev")) if finding.raw_data else False,
        timestamp=datetime.now().isoformat(),
    )
    # Sign
    att.signature = sign_attestation(att)
    return att


def sign_attestation(att: RemediationAttestation) -> str:
    """HMAC-SHA256 sign the attestation payload."""
    d = att.to_dict()
    d.pop("signature", None)  # exclude signature from signed payload
    payload = json.dumps(d, sort_keys=True, default=str)
    key = _get_signing_key()
    sig = hmac.new(key, payload.encode("utf-8"), hashlib.sha256).hexdigest()
    return sig


def verify_attestation(att_dict: dict) -> bool:
    """Verify attestation signature."""
    sig = att_dict.pop("signature", "")
    payload = json.dumps(att_dict, sort_keys=True, default=str)
    key = _get_signing_key()
    expected = hmac.new(key, payload.encode("utf-8"), hashlib.sha256).hexdigest()
    return hmac.compare_digest(sig, expected)
