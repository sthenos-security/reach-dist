#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.
"""
Enzo fixability classifier.

Maps a finding's DB fields to a FixType.  Pure logic, no I/O.
"""

from __future__ import annotations

import logging
from typing import List

from .models import EnzoFinding, FixType

logger = logging.getLogger(__name__)


def classify(finding: EnzoFinding) -> FixType:
    """
    Determine the remediation strategy for a finding based on its DB fields.

    Decision tree:
      1. CVE with fix_version available          → DEPENDENCY_UPGRADE
      2. Config finding (Dockerfile, K8s, CI/CD)  → CONFIG_CHANGE
      3. Secret finding                            → SECRET_ROTATION
      4. CWE with REACHABLE status                → CODE_PATCH
      5. CWE with UNKNOWN/NOT_REACHABLE           → CODE_PATCH (lower priority)
      6. Malware / suspicious                      → MANUAL
      7. CVE with no fix / won't fix               → MANUAL
    """
    ftype = finding.finding_type
    fix_status = finding.fix_status or ""
    fix_version = finding.fix_version or ""

    # ── CVE with available fix → dependency upgrade ───────────────────
    if ftype == "cve":
        if fix_status == "fix_available" and fix_version:
            return FixType.DEPENDENCY_UPGRADE
        # No fix available — manual
        return FixType.MANUAL

    # ── Config findings → config change ───────────────────────────────
    if ftype == "config":
        return FixType.CONFIG_CHANGE

    # ── Secret findings → secret rotation ─────────────────────────────
    if ftype == "secret":
        return FixType.SECRET_ROTATION

    # ── CWE (SAST) findings → code patch ──────────────────────────────
    if ftype == "cwe":
        return FixType.CODE_PATCH

    # ── Malware / suspicious → always manual ──────────────────────────
    if ftype in ("malware", "suspicious"):
        return FixType.MANUAL

    return FixType.MANUAL


def classify_batch(findings: List[EnzoFinding]) -> List[EnzoFinding]:
    """Classify a list of findings in-place and return them."""
    for f in findings:
        f.fix_type = classify(f)
    return findings


def filter_fixable(
    findings: List[EnzoFinding],
    allowed_types: List[str] | None = None,
) -> List[EnzoFinding]:
    """
    Return only findings with an automated fix type.

    Args:
        allowed_types: If set, only include these FixType values.
                       e.g. ["dependency_upgrade", "code_patch"]
    """
    result = []
    for f in findings:
        if f.fix_type == FixType.MANUAL:
            continue
        if allowed_types and f.fix_type.value not in allowed_types:
            continue
        result.append(f)
    return result


def prioritize(findings: List[EnzoFinding]) -> List[EnzoFinding]:
    """
    Sort findings by remediation priority.

    Priority order:
      1. REACHABLE + CRITICAL/HIGH severity
      2. Fix confidence (dependency_upgrade > config > secret > code_patch)
      3. EPSS score (from raw_data if available)
      4. KEV status
    """
    _SEV = {"CRITICAL": 4, "HIGH": 3, "MEDIUM": 2, "LOW": 1, "INFO": 0}
    _FIX_CONFIDENCE = {
        FixType.DEPENDENCY_UPGRADE: 4,
        FixType.CONFIG_CHANGE: 3,
        FixType.SECRET_ROTATION: 2,
        FixType.CODE_PATCH: 1,
        FixType.PACKAGE_REMOVAL: 0,
        FixType.MANUAL: -1,
    }

    def _sort_key(f: EnzoFinding):
        reachable = 1 if f.app_reachability == "REACHABLE" else 0
        sev = _SEV.get(f.severity, 0)
        fix_conf = _FIX_CONFIDENCE.get(f.fix_type, -1)
        epss = 0.0
        in_kev = 0
        if f.raw_data:
            epss = f.raw_data.get("epss_score", 0.0) or 0.0
            in_kev = 1 if f.raw_data.get("in_kev") else 0
        return (-reachable, -sev, -fix_conf, -in_kev, -epss)

    return sorted(findings, key=_sort_key)
