#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.
"""
Enzo data models.

All dataclasses used across the module.  No external deps beyond stdlib.
Imports from reachable.* are OPTIONAL and guarded.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional

# ═══════════════════════════════════════════════════════════════════════════
#  Enums
# ═══════════════════════════════════════════════════════════════════════════

class FixType(str, Enum):
    DEPENDENCY_UPGRADE = "dependency_upgrade"
    CONFIG_CHANGE      = "config_change"
    SECRET_ROTATION    = "secret_rotation"
    CODE_PATCH         = "code_patch"
    DLP_PATCH          = "dlp_patch"
    PACKAGE_REMOVAL    = "package_removal"
    MANUAL             = "manual"


class RemediationStatus(str, Enum):
    PENDING    = "pending"
    PATCHING   = "patching"
    VALIDATING = "validating"
    SUCCESS    = "success"
    FAILED     = "failed"
    ABORTED    = "aborted"
    MANUAL     = "manual"


# ═══════════════════════════════════════════════════════════════════════════
#  EnzoFinding — thin wrapper over a findings table row
# ═══════════════════════════════════════════════════════════════════════════

@dataclass
class EnzoFinding:
    """Wraps a row from repo.db findings table with Enzo helpers."""

    # Identity
    finding_id: str = ""
    finding_type: str = ""          # cve | cwe | config | secret | malware | suspicious
    type_detail: Optional[str] = None
    scan_id: Optional[int] = None

    # Severity / risk
    severity: str = "MEDIUM"
    risk_level: Optional[str] = None
    cvss_score: Optional[float] = None

    # Reachability (two-dimensional)
    app_reachability: str = "UNKNOWN"
    app_reachability_confidence: str = "LOW"
    platform_exposure: str = "UNKNOWN"

    # Fix availability (CVEs)
    fix_status: Optional[str] = None        # fix_available | wont_fix | no_fix
    fix_version: Optional[str] = None

    # Location
    file_path: Optional[str] = None
    line_number: Optional[int] = None

    # Package
    package_name: Optional[str] = None
    package_version: Optional[str] = None

    # Details
    title: Optional[str] = None
    description: Optional[str] = None
    cwe_id: Optional[str] = None
    secret_type: Optional[str] = None
    scanner: Optional[str] = None

    # Raw finding (full JSON from scanner)
    raw_data: Optional[Dict[str, Any]] = None

    # Enzo classification (set by classifier)
    fix_type: FixType = FixType.MANUAL

    # Call path (extracted from raw_data by context_builder)
    call_paths_v2: Optional[List[Dict]] = None

    @classmethod
    def from_db_row(cls, row: Dict[str, Any]) -> "EnzoFinding":
        raw = None
        raw_str = row.get("raw_data")
        if raw_str:
            try:
                raw = json.loads(raw_str) if isinstance(raw_str, str) else raw_str
            except (json.JSONDecodeError, TypeError):
                raw = None

        return cls(
            finding_id=row.get("finding_id", ""),
            finding_type=row.get("finding_type", ""),
            type_detail=row.get("type_detail"),
            scan_id=row.get("scan_id"),
            severity=row.get("severity", "MEDIUM"),
            risk_level=row.get("risk_level"),
            cvss_score=row.get("cvss_score"),
            app_reachability=row.get("app_reachability", "UNKNOWN"),
            app_reachability_confidence=row.get("app_reachability_confidence", "LOW"),
            platform_exposure=row.get("platform_exposure", "UNKNOWN"),
            fix_status=row.get("fix_status"),
            fix_version=row.get("fix_version"),
            file_path=row.get("file_path"),
            line_number=row.get("line_number"),
            package_name=row.get("package_name"),
            package_version=row.get("package_version"),
            title=row.get("title"),
            description=row.get("description"),
            cwe_id=row.get("cwe_id"),
            secret_type=row.get("secret_type"),
            scanner=row.get("scanner"),
            raw_data=raw,
        )

    @property
    def cve_id(self) -> Optional[str]:
        if self.finding_type == "cve" and self.raw_data:
            return self.raw_data.get("cve_id") or self.raw_data.get("id")
        return None

    @property
    def rule_id(self) -> Optional[str]:
        if self.raw_data:
            return self.raw_data.get("rule_id") or self.raw_data.get("check_id")
        return None


# ═══════════════════════════════════════════════════════════════════════════
#  RemediationContext — metadata envelope safe for cloud model
# ═══════════════════════════════════════════════════════════════════════════

@dataclass
class RemediationContext:
    """
    Safe to transmit to cloud model.  NO source code, NO function names,
    NO full file paths, NO raw_data blob.

    Every field maps to an actual DB column or a safe derivation.
    """

    # From findings table
    finding_type: str = ""
    severity: str = "MEDIUM"
    cwe_id: Optional[str] = None
    cve_id: Optional[str] = None
    fix_status: Optional[str] = None
    fix_version: Optional[str] = None
    package_name: Optional[str] = None
    package_version: Optional[str] = None
    rule_id: Optional[str] = None

    # Reachability (state only — no function names)
    app_reachability: str = "UNKNOWN"
    reachability_confidence: str = "LOW"
    platform_exposure: str = "UNKNOWN"

    # Abstracted call path: NodeKind chain only
    # e.g. "entry → app → sink_vuln"
    reachability_kind_chain: Optional[str] = None
    path_length: Optional[int] = None
    has_guard_node: bool = False
    has_boundary_node: bool = False

    # Exploitability signals
    epss_score: Optional[float] = None
    epss_percentile: Optional[float] = None
    in_kev: bool = False
    exploit_db_available: bool = False
    metasploit_available: bool = False

    # OSV package group fields (populated after threat_intel enrichment)
    osv_aliases: List[str] = field(default_factory=list)   # CVE↔GHSA↔GO-↔PYSEC- cross-IDs
    osv_summary: Optional[str] = None                      # OSV one-liner (clearer than NVD)
    osv_cwes: List[str] = field(default_factory=list)      # CWE IDs from OSV affected groups
    osv_withdrawn: Optional[str] = None                    # ISO date if vuln was retracted

    # Environment
    language: str = ""
    framework: Optional[str] = None
    build_system: str = ""
    test_framework: Optional[str] = None

    # Dependency chain (package names + versions only)
    dependency_chain: List[str] = field(default_factory=list)

    # Fix classification
    fix_type: str = ""

    # Retry context (sanitised)
    attempt_number: int = 1
    prior_errors: List[str] = field(default_factory=list)
    prior_strategies: List[str] = field(default_factory=list)

    # Knowledge hint (from knowledge.db)
    known_fix_pattern: Optional[str] = None
    known_success_rate: Optional[float] = None

    def to_prompt_block(self) -> str:
        """Serialise as text block for LLM system prompt."""
        lines = [
            f"Finding: {self.finding_type} | Severity: {self.severity} | Fix type: {self.fix_type}",
        ]
        if self.cve_id:
            lines.append(f"CVE: {self.cve_id}")
        if self.cwe_id:
            lines.append(f"CWE: {self.cwe_id}")
        if self.package_name:
            pkg = f"{self.package_name}@{self.package_version or '?'}"
            lines.append(f"Package: {pkg}")
        if self.fix_version:
            lines.append(f"Fix version: {self.fix_version}")
        lines.append(f"Reachability: {self.app_reachability} (confidence: {self.reachability_confidence})")
        if self.reachability_kind_chain:
            lines.append(f"Call path shape: {self.reachability_kind_chain}")
            lines.append(
                f"Path length: {self.path_length} | "
                f"Guard present: {self.has_guard_node} | "
                f"Boundary: {self.has_boundary_node}"
            )
        if self.epss_score is not None:
            lines.append(f"EPSS: {self.epss_score:.4f} (percentile {self.epss_percentile or 0:.2f})")
        if self.in_kev:
            lines.append("CISA KEV: YES — actively exploited")
        if self.osv_summary:
            lines.append(f"OSV summary: {self.osv_summary}")
        if self.osv_aliases:
            lines.append(f"Also known as: {', '.join(self.osv_aliases[:5])}")
        if self.osv_cwes:
            lines.append(f"CWEs (OSV): {', '.join(self.osv_cwes)}")
        if self.osv_withdrawn:
            lines.append(f"NOTE: Advisory withdrawn/retracted {self.osv_withdrawn}")
        if self.exploit_db_available:
            lines.append("ExploitDB: public exploit available")
        if self.language:
            lines.append(f"Language: {self.language} | Framework: {self.framework or 'unknown'}")
        if self.build_system:
            lines.append(f"Build: {self.build_system} | Tests: {self.test_framework or 'unknown'}")
        if self.dependency_chain:
            lines.append(f"Dep chain: {' → '.join(self.dependency_chain[:10])}")
        if self.known_fix_pattern:
            rate = f" ({self.known_success_rate:.0%} success)" if self.known_success_rate else ""
            lines.append(f"Known fix pattern{rate}: {self.known_fix_pattern}")
        if self.attempt_number > 1:
            lines.append(f"Attempt #{self.attempt_number}")
            if self.prior_errors:
                lines.append(f"Prior errors: {'; '.join(self.prior_errors[-3:])}")
            if self.prior_strategies:
                lines.append(f"Tried: {'; '.join(self.prior_strategies[-3:])}")
        return "\n".join(lines)


# ═══════════════════════════════════════════════════════════════════════════
#  Patch / Validation / Attestation results
# ═══════════════════════════════════════════════════════════════════════════

@dataclass
class PatchResult:
    success: bool = False
    diff: str = ""
    files_modified: List[str] = field(default_factory=list)
    strategy_used: str = ""
    model_used: str = ""
    cloud_strategy: Optional[str] = None
    error: Optional[str] = None
    # Multi-candidate generation: populated on attempt 1 for code_patch.
    # Validator tries each in order; first to pass wins.
    candidates: List["PatchResult"] = field(default_factory=list)


@dataclass
class ValidationResult:
    passed: bool = False
    stage: str = ""             # rescan | build | test | policy
    error: Optional[str] = None
    details: Dict[str, Any] = field(default_factory=dict)


@dataclass
class ValidationReport:
    rescan: Optional[ValidationResult] = None
    build: Optional[ValidationResult] = None
    test: Optional[ValidationResult] = None
    policy: Optional[ValidationResult] = None

    @property
    def all_passed(self) -> bool:
        return all(
            s.passed for s in [self.rescan, self.build, self.test, self.policy]
            if s is not None
        )

    @property
    def first_failure(self) -> Optional[ValidationResult]:
        for s in [self.rescan, self.build, self.test, self.policy]:
            if s is not None and not s.passed:
                return s
        return None


@dataclass
class RemediationAttestation:
    schema_version: str = "1.0"
    finding_id: str = ""
    finding_type: str = ""
    cve_id: Optional[str] = None
    cwe_id: Optional[str] = None
    severity: str = ""
    app_reachability: str = ""
    repository: str = ""
    branch: str = ""
    original_commit: str = ""
    remediation_commit: str = ""
    fix_type: str = ""
    model_used: str = ""
    cloud_strategy_used: bool = False
    scan_before: str = "FAIL"
    scan_after: str = "PASS"
    build_status: str = "SUCCESS"
    test_status: str = "PASS"
    attempts: int = 1
    epss_score: Optional[float] = None
    in_kev: bool = False
    timestamp: str = ""
    signature: str = ""

    def to_dict(self) -> Dict[str, Any]:
        from dataclasses import asdict
        return {k: v for k, v in asdict(self).items() if v is not None}
