# Copyright © 2026 Sthenos Security. All rights reserved.
"""
GRC control framework mapping tables.

Maps CWE IDs, CVE categories, and finding types to control IDs
across SOC2, PCI-DSS 4.0, NIST 800-53, OWASP ASVS 4.0,
ISO 27001:2022, and HIPAA.

Usage:
    from enzo.reporter.frameworks import get_controls, FRAMEWORK_NAMES
    controls = get_controls("soc2", "CWE-89")
    # → ["CC6.1", "CC6.6", "CC7.1"]
"""
from __future__ import annotations

from typing import Dict, List

# ── Framework metadata ────────────────────────────────────────────────────────

FRAMEWORK_NAMES: Dict[str, str] = {
    "soc2":       "SOC 2 Type II (AICPA TSC 2017)",
    "pci":        "PCI-DSS 4.0",
    "nist":       "NIST SP 800-53 Rev 5",
    "owasp_asvs": "OWASP ASVS 4.0",
    "iso27001":   "ISO/IEC 27001:2022",
    "hipaa":      "HIPAA Security Rule (45 CFR Part 164)",
}

FRAMEWORK_ALIASES: Dict[str, str] = {
    "pci-dss": "pci",
    "pci_dss": "pci",
    "nist800": "nist",
    "nist-800-53": "nist",
    "asvs": "owasp_asvs",
    "owasp": "owasp_asvs",
    "iso": "iso27001",
    "27001": "iso27001",
}

# ── Control descriptions ───────────────────────────────────────────────────────

CONTROL_DESCRIPTIONS: Dict[str, Dict[str, str]] = {
    "soc2": {
        "CC6.1":  "Logical access security software, infrastructure, and architectures",
        "CC6.2":  "Prior to issuing system credentials, the entity registers users",
        "CC6.3":  "The entity authorizes, modifies, or removes access",
        "CC6.6":  "Logical access security measures to protect against threats from sources outside system boundaries",
        "CC6.7":  "The entity restricts the transmission, movement, and removal of information",
        "CC6.8":  "The entity implements controls to prevent or detect and act upon the introduction of unauthorized or malicious software",
        "CC7.1":  "The entity uses detection and monitoring procedures to identify changes to configurations or the environment",
        "CC7.2":  "The entity monitors system components and the operation of those components for anomalies",
        "CC9.1":  "The entity identifies, selects, and develops risk mitigation activities for risks arising from potential business disruptions",
    },
    "pci": {
        "6.2.4":  "Software development practices prevent introduction of common software vulnerabilities",
        "6.3.1":  "Security vulnerabilities are identified and managed",
        "6.3.2":  "An inventory of bespoke and custom software is maintained",
        "6.3.3":  "All system components are protected from known vulnerabilities by installing applicable security patches/updates",
        "6.4.1":  "Web-facing applications are protected against attacks",
        "4.2.1":  "Strong cryptography is used to safeguard PAN during transmission",
        "8.3.1":  "All user IDs and authentication factors for users and administrators are strictly managed",
        "3.4.1":  "Primary account numbers (PAN) are secured wherever stored",
        "5.2.1":  "An anti-malware solution(s) is deployed on all system components",
        "5.3.1":  "The anti-malware solution(s) is kept current",
        "11.3.2": "All other applicable vulnerabilities are managed",
    },
    "nist": {
        "SI-10":  "Information Input Validation",
        "SI-3":   "Malicious Code Protection",
        "SI-7":   "Software, Firmware, and Information Integrity",
        "SI-2":   "Flaw Remediation",
        "SI-15":  "Information Output Filtering",
        "SA-11":  "Developer Testing and Evaluation",
        "SA-15":  "Development Process, Standards, and Tools",
        "SA-10":  "Developer Configuration Management",
        "AC-3":   "Access Enforcement",
        "SC-12":  "Cryptographic Key Establishment and Management",
        "SC-13":  "Cryptographic Protection",
        "SC-18":  "Mobile Code",
        "SC-28":  "Protection of Information at Rest",
        "IA-5":   "Authenticator Management",
        "RA-5":   "Vulnerability Monitoring and Scanning",
    },
    "owasp_asvs": {
        "V5.3.4": "Verify that data selection or database queries use parameterized queries",
        "V5.3.5": "Verify that where parameterized or safer mechanisms are not present, context-specific output encoding is used",
        "V5.3.8": "Verify that the application does not pass user-controllable data to OS commands",
        "V5.3.9": "Verify that the application protects against local file inclusion (LFI) or remote file inclusion (RFI) attacks",
        "V5.3.3": "Verify that context-aware, preferably automated, output escaping is in place",
        "V12.3.1":"Verify that user-submitted filenames are not used directly by file system APIs",
        "V12.3.2":"Verify that user-submitted filenames are validated to prevent path traversal",
        "V6.2.2": "Verify that industry proven or government approved cryptographic algorithms are used",
        "V6.2.3": "Verify that encryption initialization vector, cipher configuration, and block modes are configured securely",
        "V2.10.1":"Verify that integration secrets do not rely on unchanging passwords",
        "V6.4.1": "Verify that a key management solution is used",
        "V10.2.1":"Verify that the application source code and third party libraries do not contain unauthorized phone home or data collection capabilities",
        "V10.2.3":"Verify that the application source code and third party libraries do not contain back doors",
        "V1.14.6":"Verify that third party components come from pre-defined, trusted repositories",
        "V14.2.1":"Verify that all components are up to date",
        "V14.4.1":"Verify that HTTP response contains a safe character set",
    },
    "iso27001": {
        "A.8.24": "Use of cryptography",
        "A.8.25": "Secure development life cycle",
        "A.8.26": "Application security requirements",
        "A.8.28": "Secure coding",
        "A.8.29": "Security testing in development and acceptance",
        "A.8.7":  "Protection against malware",
        "A.8.8":  "Management of technical vulnerabilities",
        "A.5.14": "Information transfer",
        "A.8.20": "Networks security",
        "A.8.3":  "Information access restriction",
    },
    "hipaa": {
        "164.312(a)(2)(i)":   "Unique user identification",
        "164.312(a)(2)(iii)": "Automatic logoff",
        "164.312(b)":         "Audit controls",
        "164.312(c)(1)":      "Integrity controls",
        "164.312(e)(1)":      "Transmission security",
        "164.312(e)(2)(ii)":  "Encryption and decryption of ePHI",
        "164.308(a)(1)(ii)(B)":"Risk management",
        "164.308(a)(5)(ii)(B)":"Protection from malicious software",
    },
}

# ── Mapping tables ────────────────────────────────────────────────────────────
# Key: CWE ID (e.g. "CWE-89"), finding type (e.g. "secret"), or "CVE"
# Value: list of control IDs per framework

MAPPINGS: Dict[str, Dict[str, List[str]]] = {
    "soc2": {
        "CWE-89":  ["CC6.1", "CC6.6", "CC7.1"],
        "CWE-78":  ["CC6.1", "CC6.6"],
        "CWE-22":  ["CC6.1", "CC6.3"],
        "CWE-79":  ["CC6.1", "CC6.6"],
        "CWE-326": ["CC6.7", "CC9.1"],
        "CWE-798": ["CC6.2", "CC6.7"],
        "CWE-502": ["CC6.1", "CC6.8"],
        "CWE-611": ["CC6.1", "CC6.6"],
        "CWE-918": ["CC6.1", "CC6.6"],
        "CWE-1321":["CC6.1", "CC6.6"],
        "secret":  ["CC6.2", "CC6.7"],
        "malware": ["CC6.8", "CC7.1", "CC7.2"],
        "CVE":     ["CC7.1", "CC9.1"],
    },
    "pci": {
        "CWE-89":  ["6.3.1", "6.4.1", "6.2.4"],
        "CWE-78":  ["6.3.1", "6.2.4"],
        "CWE-22":  ["6.3.1", "6.4.1"],
        "CWE-79":  ["6.3.1", "6.4.1"],
        "CWE-326": ["4.2.1", "8.3.1"],
        "CWE-798": ["3.4.1", "8.3.1"],
        "CWE-502": ["6.3.1", "6.2.4"],
        "CWE-611": ["6.3.1", "6.4.1"],
        "CWE-918": ["6.3.1", "6.4.1"],
        "CWE-1321":["6.3.1", "6.4.1"],
        "secret":  ["3.4.1", "8.3.1"],
        "malware": ["5.2.1", "5.3.1"],
        "CVE":     ["6.3.3", "6.3.1", "11.3.2"],
    },
    "nist": {
        "CWE-89":  ["SI-10", "SA-11", "SA-15"],
        "CWE-78":  ["SI-10", "SI-3"],
        "CWE-22":  ["AC-3",  "SI-10"],
        "CWE-79":  ["SI-10", "SI-15"],
        "CWE-326": ["SC-12", "SC-13", "IA-5"],
        "CWE-798": ["IA-5",  "SC-12", "SC-28"],
        "CWE-502": ["SI-10", "SA-11"],
        "CWE-611": ["SI-10", "SC-28"],
        "CWE-918": ["SI-10", "AC-3"],
        "CWE-1321":["SI-10", "SA-11"],
        "secret":  ["IA-5",  "SC-12", "SC-28"],
        "malware": ["SI-3",  "SI-7",  "SC-18"],
        "CVE":     ["SI-2",  "RA-5",  "SA-10"],
    },
    "owasp_asvs": {
        "CWE-89":  ["V5.3.4", "V5.3.5"],
        "CWE-78":  ["V5.3.8", "V5.3.9"],
        "CWE-22":  ["V12.3.1","V12.3.2"],
        "CWE-79":  ["V5.3.3", "V14.4.1"],
        "CWE-326": ["V6.2.2", "V6.2.3"],
        "CWE-798": ["V2.10.1","V6.4.1"],
        "CWE-502": ["V5.3.4", "V5.3.5"],
        "CWE-1321":["V5.3.4", "V5.3.5"],
        "secret":  ["V2.10.1","V6.4.1"],
        "malware": ["V10.2.1","V10.2.3"],
        "CVE":     ["V1.14.6","V14.2.1"],
    },
    "iso27001": {
        "CWE-89":  ["A.8.26", "A.8.28", "A.8.29"],
        "CWE-78":  ["A.8.26", "A.8.28"],
        "CWE-22":  ["A.8.3",  "A.8.26"],
        "CWE-79":  ["A.8.26", "A.8.28"],
        "CWE-326": ["A.8.24", "A.8.25"],
        "CWE-798": ["A.8.24", "A.5.14"],
        "secret":  ["A.8.24", "A.5.14"],
        "malware": ["A.8.7",  "A.8.8"],
        "CVE":     ["A.8.8",  "A.8.25"],
    },
    "hipaa": {
        "CWE-89":  ["164.312(c)(1)", "164.308(a)(1)(ii)(B)"],
        "CWE-78":  ["164.312(c)(1)", "164.308(a)(1)(ii)(B)"],
        "CWE-22":  ["164.312(a)(2)(i)", "164.308(a)(1)(ii)(B)"],
        "CWE-326": ["164.312(e)(2)(ii)", "164.312(e)(1)"],
        "CWE-798": ["164.312(a)(2)(i)", "164.312(e)(2)(ii)"],
        "secret":  ["164.312(a)(2)(i)", "164.312(e)(2)(ii)"],
        "malware": ["164.308(a)(5)(ii)(B)", "164.308(a)(1)(ii)(B)"],
        "CVE":     ["164.308(a)(1)(ii)(B)", "164.308(a)(5)(ii)(B)"],
    },
}


def resolve_framework(name: str) -> str:
    """Normalise framework alias → canonical key."""
    key = name.lower().strip()
    return FRAMEWORK_ALIASES.get(key, key)


def get_controls(framework: str, cwe_or_type: str) -> List[str]:
    """Return control IDs for a finding in the given framework."""
    fw = resolve_framework(framework)
    mapping = MAPPINGS.get(fw, {})
    # Try exact CWE, then finding category
    controls = mapping.get(cwe_or_type, [])
    if not controls and cwe_or_type.startswith("CWE-"):
        pass  # No mapping — return empty
    return list(dict.fromkeys(controls))  # dedup, preserve order


def describe_control(framework: str, control_id: str) -> str:
    """Return human description of a control ID."""
    fw = resolve_framework(framework)
    return CONTROL_DESCRIPTIONS.get(fw, {}).get(control_id, control_id)


def all_controls_for_findings(framework: str, findings: list) -> Dict[str, List]:
    """
    Given a list of finding dicts (with cwe_id, finding_type fields),
    return a dict mapping control_id → [finding_dicts].
    """
    fw = resolve_framework(framework)
    result: Dict[str, List] = {}
    for f in findings:
        cwe = f.get("cwe_id") or ""
        ftype = f.get("finding_type") or f.get("fix_type") or ""
        keys = []
        if cwe:
            keys.append(cwe)
        if "secret" in ftype.lower():
            keys.append("secret")
        elif "malware" in ftype.lower():
            keys.append("malware")
        elif "cve" in ftype.lower() or "dependency" in ftype.lower():
            keys.append("CVE")
        for k in keys:
            for ctrl in get_controls(fw, k):
                result.setdefault(ctrl, []).append(f)
    return result
