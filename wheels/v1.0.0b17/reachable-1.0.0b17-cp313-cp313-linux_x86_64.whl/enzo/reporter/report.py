#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.
"""
Enzo Reporter — orchestration layer.

Queries enzo.db + repo.db, builds context, calls local model,
renders markdown (and optionally PDF).

Entry points:
    generate_risk_report(...)
    generate_grc_report(...)
    generate_deep_dive(...)
    generate_executive_summary(...)
    run_accepted_risk_workflow(...)

All report types write a manifest entry for tamper-evidence.

Model resolution order:
  1. model= argument (explicit)
  2. ENZO_REPORT_MODEL env var
  3. Ollama auto-detect (localhost:11434)
  4. Groq cloud (with data-egress warning)
  5. Error
"""
from __future__ import annotations

import json
import logging
import os
import sqlite3
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

from .frameworks import (
    FRAMEWORK_NAMES,
    all_controls_for_findings,
    describe_control,
    get_controls,
    resolve_framework,
)
from .hasher import hash_db, write_manifest
from .prompts import (
    FINDING_DEEP_DIVE_PROMPT,
    GRC_ACCEPTED_RISK_PROMPT,
    GRC_ATTESTATION_PROMPT,
    GRC_CONTROL_SUMMARY_PROMPT,
    GRC_FINDING_NARRATIVE_PROMPT,
    RISK_EXEC_SUMMARY_PROMPT,
    RISK_FINDING_ANALYSIS_PROMPT,
    RISK_PATTERN_ANALYSIS_PROMPT,
    RISK_REPORT_SYSTEM,
)

logger = logging.getLogger(__name__)

# ── Model caller ──────────────────────────────────────────────────────────────

def _call_model(
    prompt: str,
    system: str = "",
    model: str = "",
    max_tokens: int = 1024,
) -> str:
    """
    Call local (Ollama) or cloud (Groq) model.
    Returns the text response.
    """
    model = model or os.environ.get("ENZO_REPORT_MODEL", "")

    # ── Try Ollama ────────────────────────────────────────────────────────
    if not model or model.startswith("ollama/"):
        ollama_model = model.replace("ollama/", "") if model else _detect_ollama()
        if ollama_model:
            return _call_ollama(ollama_model, prompt, system, max_tokens)

    # ── Try Groq ──────────────────────────────────────────────────────────
    if model.startswith("groq/") or not model:
        groq_key = os.environ.get("GROQ_API_KEY", "")
        if groq_key:
            logger.warning(
                "[REPORTER] Using Groq cloud model — findings data will leave this machine. "
                "Set ENZO_REPORT_MODEL=ollama/<model> for local-only processing."
            )
            groq_model = model.replace("groq/", "") if model.startswith("groq/") \
                        else "llama-3.3-70b-versatile"
            return _call_groq(groq_model, prompt, system, groq_key, max_tokens)

    raise RuntimeError(
        "No model available for report generation.\n"
        "Options:\n"
        "  1. Install Ollama: https://ollama.ai  →  ollama pull deepseek-r1:7b\n"
        "  2. Set GROQ_API_KEY for cloud fallback (findings leave machine)\n"
        "  3. Pass --model ollama/<model> or --model groq/<model>"
    )


def _detect_ollama() -> Optional[str]:
    """Return first available Ollama model, or None."""
    try:
        import urllib.request
        with urllib.request.urlopen("http://localhost:11434/api/tags", timeout=2) as r:
            data = json.loads(r.read())
        models = [m["name"] for m in data.get("models", [])]
        # Prefer reasoning models
        for preferred in ("deepseek-r1", "qwen2.5", "llama3.2", "mistral"):
            for m in models:
                if preferred in m:
                    return m
        return models[0] if models else None
    except Exception:
        return None


def _call_ollama(model: str, prompt: str, system: str, max_tokens: int) -> str:
    import urllib.error
    import urllib.request
    payload = json.dumps({
        "model": model,
        "prompt": f"{system}\n\n{prompt}" if system else prompt,
        "stream": False,
        "options": {"num_predict": max_tokens, "temperature": 0.2},
    }).encode()
    try:
        req = urllib.request.Request(
            "http://localhost:11434/api/generate",
            data=payload, method="POST",
            headers={"Content-Type": "application/json"},
        )
        with urllib.request.urlopen(req, timeout=120) as r:
            data = json.loads(r.read())
        return data.get("response", "").strip()
    except Exception as e:
        raise RuntimeError(f"Ollama error ({model}): {e}") from e


def _call_groq(model: str, prompt: str, system: str, api_key: str, max_tokens: int) -> str:
    import urllib.request
    messages = []
    if system:
        messages.append({"role": "system", "content": system})
    messages.append({"role": "user", "content": prompt})
    payload = json.dumps({
        "model": model,
        "messages": messages,
        "max_tokens": max_tokens,
        "temperature": 0.2,
    }).encode()
    req = urllib.request.Request(
        "https://api.groq.com/openai/v1/chat/completions",
        data=payload, method="POST",
        headers={
            "Content-Type": "application/json",
            "Authorization": f"Bearer {api_key}",
        },
    )
    try:
        with urllib.request.urlopen(req, timeout=60) as r:
            data = json.loads(r.read())
        return data["choices"][0]["message"]["content"].strip()
    except Exception as e:
        raise RuntimeError(f"Groq error: {e}") from e


# ── DB helpers ────────────────────────────────────────────────────────────────

def _load_findings(enzo_db: str, repo_db: str, scan_id: Optional[int] = None) -> List[Dict]:
    """Load findings from repo.db joined with enzo outcome from enzo.db."""
    findings = []
    try:
        con = sqlite3.connect(repo_db)
        con.row_factory = sqlite3.Row
        q = "SELECT * FROM findings WHERE 1=1"
        params = []
        if scan_id:
            q += " AND scan_id = ?"
            params.append(scan_id)
        q += " ORDER BY severity DESC, reachability_state ASC LIMIT 200"
        findings = [dict(r) for r in con.execute(q, params).fetchall()]
        con.close()
    except Exception as e:
        logger.debug("Could not load repo.db findings: %s", e)

    # Enrich with enzo outcome
    try:
        econ = sqlite3.connect(enzo_db)
        econ.row_factory = sqlite3.Row
        for f in findings:
            fid = f.get("finding_id") or f.get("id") or ""
            row = econ.execute(
                "SELECT status, patch_diff, patcher_method, cost_usd, completed_at "
                "FROM remediation_attempts WHERE finding_id = ? ORDER BY created_at DESC LIMIT 1",
                (fid,)
            ).fetchone()
            if row:
                f["enzo_status"] = row["status"]
                f["enzo_patched_at"] = row["completed_at"]
                f["enzo_patcher"] = row["patcher_method"]
                f["enzo_cost"] = row["cost_usd"]
        econ.close()
    except Exception as e:
        logger.debug("Could not enrich with enzo.db: %s", e)

    return findings


def _load_attempts(enzo_db: str, finding_id: str) -> List[Dict]:
    try:
        con = sqlite3.connect(enzo_db)
        con.row_factory = sqlite3.Row
        rows = con.execute(
            "SELECT * FROM remediation_attempts WHERE finding_id = ? ORDER BY created_at DESC",
            (finding_id,)
        ).fetchall()
        con.close()
        return [dict(r) for r in rows]
    except Exception:
        return []


def _enzo_summary(enzo_db: str) -> Dict[str, Any]:
    """High-level enzo stats for report headers."""
    try:
        con = sqlite3.connect(enzo_db)
        con.row_factory = sqlite3.Row
        row = con.execute("""
            SELECT
                COUNT(*) as total,
                SUM(CASE WHEN status='success' THEN 1 ELSE 0 END) as fixed,
                SUM(CASE WHEN status='failed'  THEN 1 ELSE 0 END) as failed,
                SUM(CASE WHEN status='manual'  THEN 1 ELSE 0 END) as manual,
                SUM(cost_usd) as total_cost,
                MIN(created_at) as first_at,
                MAX(created_at) as last_at
            FROM remediation_attempts
        """).fetchone()
        con.close()
        return dict(row) if row else {}
    except Exception:
        return {}


# ── Report dataclass ──────────────────────────────────────────────────────────

@dataclass
class ReportConfig:
    repo_path: str
    enzo_db_path: str
    repo_db_path: str
    org_name: str = "Organisation"
    model: str = ""
    scan_id: Optional[int] = None
    framework: str = ""
    output_format: str = "markdown"   # "markdown" | "pdf"
    output_path: Optional[str] = None
    period_start: Optional[str] = None
    period_end: Optional[str] = None

    @property
    def app_name(self) -> str:
        return Path(self.repo_path).name

    @property
    def framework_name(self) -> str:
        if not self.framework:
            return ""
        fw = resolve_framework(self.framework)
        return FRAMEWORK_NAMES.get(fw, fw.upper())

    @property
    def report_period(self) -> str:
        now = datetime.now(timezone.utc).strftime("%Y-%m-%d")
        start = self.period_start or now
        end = self.period_end or now
        return f"{start} → {end}"


@dataclass
class ReportResult:
    success: bool
    report_path: str = ""
    db_hash: str = ""
    error: str = ""
    word_count: int = 0


# ── Risk report ───────────────────────────────────────────────────────────────

def generate_risk_report(cfg: ReportConfig) -> ReportResult:
    """Full risk report with executive summary + finding analysis + patterns."""
    from enzo import __version__

    logger.info("[REPORTER] Generating risk report for %s", cfg.app_name)
    findings = _load_findings(cfg.enzo_db_path, cfg.repo_db_path, cfg.scan_id)
    if not findings:
        return ReportResult(success=False, error="No findings found in scan data")

    summary = _enzo_summary(cfg.enzo_db_path)
    db_hash = hash_db(cfg.enzo_db_path)
    now_str = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")

    # Build context blobs for prompts
    findings_summary = _summarise_findings(findings[:30])
    attack_surface = _attack_surface_block(findings)
    fix_status = _fix_status_block(summary, findings)
    top5 = sorted(findings, key=lambda f: (
        0 if f.get("reachability_state", "").upper() in ("REACHABLE", "CONFIRMED") else 1,
        0 if (f.get("severity") or "").upper() == "CRITICAL" else 1,
    ))[:5]

    # Generate sections
    exec_summary = _call_model(
        RISK_EXEC_SUMMARY_PROMPT.format(
            findings_summary=findings_summary,
            attack_surface=attack_surface,
            fix_status=fix_status,
        ),
        system=RISK_REPORT_SYSTEM,
        model=cfg.model, max_tokens=400,
    )

    finding_analyses = []
    for f in top5:
        analysis = _call_model(
            RISK_FINDING_ANALYSIS_PROMPT.format(
                finding_json=json.dumps(_safe_finding(f), indent=2),
                call_path=f.get("call_path") or f.get("reachability_path") or "Not available",
                similar_findings=_similar_findings_block(f, findings),
            ),
            system=RISK_REPORT_SYSTEM,
            model=cfg.model, max_tokens=300,
        )
        finding_analyses.append((f, analysis))

    pattern_analysis = _call_model(
        RISK_PATTERN_ANALYSIS_PROMPT.format(
            all_findings_summary=findings_summary,
        ),
        system=RISK_REPORT_SYSTEM,
        model=cfg.model, max_tokens=300,
    )

    # Render markdown
    model_used = cfg.model or _detect_ollama() or "groq/llama-3.3-70b-versatile"
    md = _render_risk_report(
        cfg=cfg, now_str=now_str, db_hash=db_hash,
        findings=findings, summary=summary,
        exec_summary=exec_summary,
        finding_analyses=finding_analyses,
        pattern_analysis=pattern_analysis,
        enzo_version=__version__,
        model_used=model_used,
    )

    result = _write_report(cfg, md, "risk", db_hash, now_str, model_used, __version__)
    return result


def generate_executive_summary(cfg: ReportConfig) -> ReportResult:
    """200-word executive summary only."""
    from enzo import __version__
    findings = _load_findings(cfg.enzo_db_path, cfg.repo_db_path, cfg.scan_id)
    if not findings:
        return ReportResult(success=False, error="No findings found in scan data")
    summary = _enzo_summary(cfg.enzo_db_path)
    db_hash = hash_db(cfg.enzo_db_path)
    now_str = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    model_used = cfg.model or _detect_ollama() or "groq/llama-3.3-70b-versatile"

    text = _call_model(
        RISK_EXEC_SUMMARY_PROMPT.format(
            findings_summary=_summarise_findings(findings[:20]),
            attack_surface=_attack_surface_block(findings),
            fix_status=_fix_status_block(summary, findings),
        ),
        system=RISK_REPORT_SYSTEM,
        model=cfg.model, max_tokens=400,
    )

    md = f"""# Security Executive Summary — {cfg.app_name}
**Generated:** {now_str}  ·  **Model:** {model_used} (local)  ·  **DB hash:** SHA256:{db_hash[:16]}...

---

{text}
"""
    return _write_report(cfg, md, "executive", db_hash, now_str, model_used, __version__)


# ── GRC compliance report ─────────────────────────────────────────────────────

def generate_grc_report(cfg: ReportConfig) -> ReportResult:
    """Full GRC compliance evidence report."""
    from enzo import __version__

    if not cfg.framework:
        return ReportResult(success=False, error="framework is required for grc report")

    fw = resolve_framework(cfg.framework)
    fw_name = FRAMEWORK_NAMES.get(fw, fw.upper())
    logger.info("[REPORTER] Generating %s compliance report for %s", fw_name, cfg.app_name)

    findings = _load_findings(cfg.enzo_db_path, cfg.repo_db_path, cfg.scan_id)
    if not findings:
        return ReportResult(success=False, error="No findings found in scan data")
    summary = _enzo_summary(cfg.enzo_db_path)
    db_hash = hash_db(cfg.enzo_db_path)
    now_str = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    model_used = cfg.model or _detect_ollama() or "groq/llama-3.3-70b-versatile"

    # Map all findings to controls
    ctrl_map = all_controls_for_findings(fw, findings)
    all_controls = sorted(ctrl_map.keys())

    # Generate attestation
    top_controls = ", ".join(all_controls[:6]) + ("..." if len(all_controls) > 6 else "")
    attestation = _call_model(
        GRC_ATTESTATION_PROMPT.format(
            framework_name=fw_name,
            org_name=cfg.org_name,
            app_name=cfg.app_name,
            period_start=cfg.period_start or now_str[:10],
            period_end=cfg.period_end or now_str[:10],
            reachable_version=__version__,
            total_findings=len(findings),
            remediated=summary.get("fixed", 0),
            open_count=summary.get("manual", 0) + summary.get("failed", 0),
            scan_frequency="On-demand + CI",
            controls=top_controls,
        ),
        system="You are a compliance writer producing formal audit evidence. "
               "Be precise, formal, and factual. No bullet points.",
        model=cfg.model, max_tokens=300,
    )

    # Generate per-control sections
    control_sections = []
    for ctrl_id in all_controls:
        ctrl_findings = ctrl_map[ctrl_id]
        ctrl_desc = describe_control(fw, ctrl_id)

        ctrl_summary = _call_model(
            GRC_CONTROL_SUMMARY_PROMPT.format(
                control_id=ctrl_id,
                control_desc=ctrl_desc,
                framework_name=fw_name,
                findings_for_control=json.dumps(
                    [_safe_finding(f) for f in ctrl_findings[:5]], indent=2
                ),
            ),
            model=cfg.model, max_tokens=200,
        )

        # Per-finding narratives for remediated findings
        narratives = []
        for f in ctrl_findings:
            if f.get("enzo_status") == "success":
                attempt = _load_attempts(cfg.enzo_db_path, f.get("finding_id", ""))
                fix_data = attempt[0] if attempt else {}
                narrative = _call_model(
                    GRC_FINDING_NARRATIVE_PROMPT.format(
                        framework_name=fw_name,
                        finding_json=json.dumps(_safe_finding(f), indent=2),
                        controls=", ".join(get_controls(fw, f.get("cwe_id") or "")),
                        fix_json=json.dumps({
                            "status": fix_data.get("status"),
                            "patcher_method": fix_data.get("patcher_method"),
                            "completed_at": fix_data.get("completed_at"),
                            "verified": fix_data.get("rescan_result") == "PASS",
                        }, indent=2),
                    ),
                    model=cfg.model, max_tokens=200,
                )
                narratives.append((f, narrative))

        # Accepted risks
        open_findings = [f for f in ctrl_findings
                        if f.get("enzo_status") not in ("success",)]
        accepted_risks = []
        for f in open_findings:
            ar_text = _call_model(
                GRC_ACCEPTED_RISK_PROMPT.format(
                    finding_json=json.dumps(_safe_finding(f), indent=2),
                    controls=", ".join(get_controls(fw, f.get("cwe_id") or "")),
                ),
                model=cfg.model, max_tokens=250,
            )
            accepted_risks.append((f, ar_text))

        control_sections.append({
            "ctrl_id": ctrl_id,
            "ctrl_desc": ctrl_desc,
            "summary": ctrl_summary,
            "narratives": narratives,
            "accepted_risks": accepted_risks,
        })

    md = _render_grc_report(
        cfg=cfg, fw=fw, fw_name=fw_name,
        now_str=now_str, db_hash=db_hash,
        findings=findings, summary=summary,
        attestation=attestation,
        control_sections=control_sections,
        enzo_version=__version__,
        model_used=model_used,
    )

    return _write_report(cfg, md, "grc", db_hash, now_str, model_used, __version__,
                         framework=fw)


# ── Deep-dive report ──────────────────────────────────────────────────────────

def generate_deep_dive(cfg: ReportConfig, finding_id: str) -> ReportResult:
    """Detailed analysis of a single finding."""
    from enzo import __version__

    findings = _load_findings(cfg.enzo_db_path, cfg.repo_db_path, cfg.scan_id)
    finding = next((f for f in findings
                    if (f.get("finding_id") or f.get("id") or "").startswith(finding_id)), None)
    if not finding:
        return ReportResult(success=False, error=f"Finding {finding_id} not found")

    attempts = _load_attempts(cfg.enzo_db_path, finding.get("finding_id", ""))
    latest_attempt = attempts[0] if attempts else {}
    db_hash = hash_db(cfg.enzo_db_path)
    now_str = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    model_used = cfg.model or _detect_ollama() or "groq/llama-3.3-70b-versatile"

    # Load code slice if file exists
    code_slice = "Not available"
    file_path = finding.get("file_path") or ""
    line = finding.get("line_number") or 0
    if file_path and Path(file_path).exists():
        lines = Path(file_path).read_text().splitlines()
        start = max(0, line - 8)
        end = min(len(lines), line + 8)
        code_slice = "\n".join(
            f"{'→' if i+1 == line else ' '} {i+start+1:4}: {lines[i+start]}"
            for i in range(end - start)
        )

    text = _call_model(
        FINDING_DEEP_DIVE_PROMPT.format(
            finding_json=json.dumps(_safe_finding(finding), indent=2),
            code_slice=code_slice,
            call_path=finding.get("call_path") or finding.get("reachability_path") or "Not available",
            fix_diff=latest_attempt.get("patch_diff") or "No fix applied",
        ),
        system=RISK_REPORT_SYSTEM,
        model=cfg.model, max_tokens=600,
    )

    md = f"""# Finding Deep-Dive — {finding.get("finding_id", finding_id)[:12]}
**Generated:** {now_str}  ·  **Model:** {model_used} (local)
**Finding:** {finding.get("cwe_id") or finding.get("cve_id") or "Unknown"}  ·  {finding.get("file_path", "")}:{line}
**DB hash:** SHA256:{db_hash[:16]}...

---

{text}
"""
    return _write_report(cfg, md, "deep_dive", db_hash, now_str, model_used, __version__)


# ── Accepted risk workflow ────────────────────────────────────────────────────

def run_accepted_risk_workflow(cfg: ReportConfig) -> None:
    """Interactive CLI workflow for documenting accepted risks."""
    findings = _load_findings(cfg.enzo_db_path, cfg.repo_db_path, cfg.scan_id)
    open_findings = [f for f in findings if f.get("enzo_status") not in ("success",)
                     and (f.get("severity") or "").upper() in ("CRITICAL", "HIGH")]

    if not open_findings:
        print("  No open CRITICAL/HIGH findings requiring acceptance.")
        return

    fw = resolve_framework(cfg.framework) if cfg.framework else ""
    print(f"\n  ┌{'─'*55}┐")
    print(f"  │ ACCEPTED RISK WORKFLOW  ({len(open_findings)} findings){'':>16}│")
    print(f"  └{'─'*55}┘\n")

    accepted = []
    for f in open_findings:
        fid = (f.get("finding_id") or "")[:12]
        ftype = f.get("cwe_id") or f.get("cve_id") or f.get("finding_type") or "unknown"
        ffile = f.get("file_path") or ""
        fline = f.get("line_number") or ""
        print(f"  Finding: {fid}  ·  {ftype}  ·  {ffile}:{fline}")
        print(f"  {'─'*55}")

        # Pre-fill context with model
        try:
            controls = get_controls(fw, f.get("cwe_id") or "") if fw else []
            pre_fill = _call_model(
                GRC_ACCEPTED_RISK_PROMPT.format(
                    finding_json=json.dumps(_safe_finding(f), indent=2),
                    controls=", ".join(controls) or "N/A",
                ),
                model=cfg.model, max_tokens=250,
            )
            print("  Pre-filled context:\n")
            for line in pre_fill.splitlines():
                print(f"    {line}")
            print()
        except Exception as e:
            logger.debug("Could not pre-fill: %s", e)

        try:
            acceptor = input("  Accepted by (name · role): ").strip()
            if not acceptor:
                print("  Skipped.\n")
                continue
            justification = input("  Business justification:    ").strip()
            compensating  = input("  Compensating control:      ").strip()
            review_date   = input("  Review date (YYYY-MM-DD):  ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\n  Workflow interrupted.")
            break

        accepted.append({
            "finding_id": f.get("finding_id"),
            "cwe_id": f.get("cwe_id"),
            "file": ffile, "line": fline,
            "accepted_by": acceptor,
            "justification": justification,
            "compensating_control": compensating,
            "review_date": review_date,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        })
        print("  ✓ Recorded.\n")

    if accepted:
        out = Path(cfg.repo_path) / ".reachable" / "accepted-risks.jsonl"
        out.parent.mkdir(parents=True, exist_ok=True)
        with open(out, "a") as fh:
            for entry in accepted:
                fh.write(json.dumps(entry) + "\n")
        print(f"  Accepted risks written to: {out}")


# ── Renderers ─────────────────────────────────────────────────────────────────

def _render_risk_report(
    cfg, now_str, db_hash, findings, summary,
    exec_summary, finding_analyses, pattern_analysis,
    enzo_version, model_used,
) -> str:
    total = len(findings)
    fixed = summary.get("fixed", 0)
    open_c = total - fixed
    reachable = sum(1 for f in findings
                    if (f.get("reachability_state") or "").upper() in ("REACHABLE", "CONFIRMED"))

    lines = [
        f"# Security Risk Report — {cfg.app_name}",
        "",
        "| | |",
        "|---|---|",
        f"| **Generated** | {now_str} (UTC) |",
        f"| **Organisation** | {cfg.org_name} |",
        f"| **Enzo version** | {enzo_version} |",
        f"| **Model** | {model_used} (local) |",
        f"| **DB state hash** | SHA256:{db_hash} |",
        "",
        "---",
        "",
        "## Executive Summary",
        "",
        exec_summary,
        "",
        "---",
        "",
        "## Attack Surface",
        "",
        "| Metric | Value |",
        "|--------|-------|",
        f"| Total findings | {total} |",
        f"| Reachable (confirmed path) | {reachable} |",
        f"| Auto-remediated | {fixed} |",
        f"| Require manual action | {open_c} |",
        f"| Total cost of automated fixes | ${summary.get('total_cost', 0.0):.4f} |",
        "",
        "---",
        "",
        "## Top Priority Findings",
        "",
    ]

    for i, (f, analysis) in enumerate(finding_analyses, 1):
        fid = (f.get("finding_id") or "")[:12]
        cwe = f.get("cwe_id") or f.get("cve_id") or "Unknown"
        sev = f.get("severity") or "UNKNOWN"
        reach = f.get("reachability_state") or "UNKNOWN"
        ffile = f.get("file_path") or ""
        fline = f.get("line_number") or ""
        status = "✓ Fixed" if f.get("enzo_status") == "success" else "⚠ Open"

        lines += [
            f"### {i}. {fid} — {cwe}",
            "",
            f"**Severity:** {sev}  ·  **Reachability:** {reach}  ·  **Status:** {status}",
            f"**File:** `{ffile}:{fline}`",
            "",
            analysis,
            "",
        ]

    lines += [
        "---",
        "",
        "## Pattern Analysis",
        "",
        pattern_analysis,
        "",
        "---",
        "",
        "## Remediation Summary",
        "",
        "| Method | Count | Cost | Verification |",
        "|--------|-------|------|--------------|",
    ]

    det_count = sum(1 for f in findings if f.get("enzo_patcher") == "deterministic"
                    and f.get("enzo_status") == "success")
    ai_count  = fixed - det_count
    lines += [
        f"| Deterministic | {det_count} | $0.00 | Self-verifying |",
        f"| AI (verified) | {ai_count} | ${summary.get('total_cost', 0.0):.4f} | Semgrep/grype confirmed |",
        f"| Manual required | {open_c} | — | — |",
        "",
        "---",
        "",
        f"*Generated by Enzo v{enzo_version} · {model_used} · Sthenos Security*",
    ]
    return "\n".join(lines)


def _render_grc_report(
    cfg, fw, fw_name, now_str, db_hash,
    findings, summary, attestation, control_sections,
    enzo_version, model_used,
) -> str:
    lines = [
        f"# Compliance Evidence Report — {fw_name}",
        "",
        "| | |",
        "|---|---|",
        f"| **Organisation** | {cfg.org_name} |",
        f"| **Application** | {cfg.app_name} |",
        f"| **Report period** | {cfg.report_period} |",
        f"| **Generated** | {now_str} (UTC) |",
        f"| **Generated by** | Enzo v{enzo_version} · {model_used} (local, on-device) |",
        f"| **DB state hash** | SHA256:{db_hash} |",
        "",
        "---",
        "",
        "## Attestation",
        "",
        attestation,
        "",
        "---",
        "",
        "## Control Coverage Summary",
        "",
        "| Control | Description | Findings | Status |",
        "|---------|-------------|----------|--------|",
    ]

    for cs in control_sections:
        remediated = len(cs["narratives"])
        open_c = len(cs["accepted_risks"])
        total_c = remediated + open_c
        status = f"✓ {remediated}/{total_c} remediated" if open_c == 0 \
                 else f"⚠ {remediated}/{total_c} remediated"
        lines.append(
            f"| {cs['ctrl_id']} | {cs['ctrl_desc'][:50]} | {total_c} | {status} |"
        )

    lines += ["", "---", ""]

    for cs in control_sections:
        lines += [
            f"## {cs['ctrl_id']} — {cs['ctrl_desc']}",
            "",
            cs["summary"],
            "",
        ]

        if cs["narratives"]:
            lines += ["### Remediated Findings", ""]
            for f, narrative in cs["narratives"]:
                fid = (f.get("finding_id") or "")[:12]
                cwe = f.get("cwe_id") or f.get("cve_id") or ""
                ffile = f.get("file_path") or ""
                fline = f.get("line_number") or ""
                lines += [
                    f"**{fid}** · {cwe} · `{ffile}:{fline}`",
                    f"- **Detected:** {f.get('created_at') or 'unknown'}",
                    f"- **Severity:** {f.get('severity') or 'unknown'}",
                    f"- **Remediated:** {f.get('enzo_patched_at') or 'pending'}",
                    f"- **Method:** {f.get('enzo_patcher') or 'unknown'}",
                    "",
                    "*Evidence narrative:*",
                    f"> {narrative.replace(chr(10), chr(10) + '> ')}",
                    "",
                ]

        if cs["accepted_risks"]:
            lines += ["### Accepted / Residual Risks", ""]
            for f, ar_text in cs["accepted_risks"]:
                fid = (f.get("finding_id") or "")[:12]
                cwe = f.get("cwe_id") or f.get("cve_id") or ""
                lines += [
                    f"**{fid}** · {cwe} · Status: Open",
                    "",
                    ar_text,
                    "",
                    "- **Accepted by:** *(requires signature)*",
                    "- **Business justification:** *(requires input)*",
                    "- **Compensating control:** *(requires input)*",
                    "- **Review date:** *(requires input)*",
                    "",
                ]

        lines += ["---", ""]

    lines += [
        "## Appendix A — Scan Methodology",
        "",
        f"Scanning performed by REACHABLE v{enzo_version} using Semgrep SAST, "
        f"Grype SCA, GuardDog malware detection, Syft SBOM generation, "
        f"and custom reachability analysis (entry point → sink call graph).",
        "",
        "## Appendix B — Full Finding Index",
        "",
        "| ID | Type | Severity | Status | Date |",
        "|----|------|----------|--------|------|",
    ]
    for f in findings:
        fid = (f.get("finding_id") or "")[:12]
        ftype = f.get("cwe_id") or f.get("cve_id") or f.get("finding_type") or ""
        sev = f.get("severity") or ""
        status = f.get("enzo_status") or "open"
        date = (f.get("created_at") or "")[:10]
        lines.append(f"| {fid} | {ftype} | {sev} | {status} | {date} |")

    lines += [
        "",
        "---",
        "",
        f"*Generated by Enzo v{enzo_version} · {model_used} · Sthenos Security*",
    ]
    return "\n".join(lines)


# ── Writer ────────────────────────────────────────────────────────────────────

def _write_report(
    cfg: ReportConfig, md: str, report_type: str,
    db_hash: str, now_str: str, model_used: str, enzo_version: str,
    framework: str = "",
) -> ReportResult:
    # Determine output path
    ts = now_str.replace(":", "").replace("-", "")[:15]
    fw_suffix = f"-{framework}" if framework else ""
    filename = f"enzo-{report_type}{fw_suffix}-{ts}.md"
    out_path = cfg.output_path or str(Path(cfg.repo_path) / ".reachable" / "reports" / filename)
    Path(out_path).parent.mkdir(parents=True, exist_ok=True)

    Path(out_path).write_text(md, encoding="utf-8")
    logger.info("[REPORTER] Report written: %s", out_path)

    # PDF render if requested
    if cfg.output_format == "pdf":
        pdf_path = out_path.replace(".md", ".pdf")
        _render_pdf(md, pdf_path)
        out_path = pdf_path

    # Manifest entry for tamper-evidence
    write_manifest(
        repo_path=cfg.repo_path,
        report_type=report_type,
        report_path=out_path,
        db_hash=db_hash,
        framework=framework or None,
        enzo_version=enzo_version,
        model=model_used,
    )

    return ReportResult(
        success=True,
        report_path=out_path,
        db_hash=db_hash,
        word_count=len(md.split()),
    )


def _render_pdf(md: str, pdf_path: str) -> None:
    """Convert markdown to PDF via pandoc (preferred) or weasyprint."""
    try:
        import subprocess
        result = subprocess.run(
            ["pandoc", "-f", "markdown", "-o", pdf_path,
             "--pdf-engine=weasyprint"],
            input=md.encode(), capture_output=True, timeout=60,
        )
        if result.returncode == 0:
            logger.info("[REPORTER] PDF written: %s", pdf_path)
            return
    except (FileNotFoundError, subprocess.TimeoutExpired):
        pass
    try:
        import markdown as md_lib  # type: ignore
        import weasyprint  # type: ignore
        html = md_lib.markdown(md, extensions=["tables", "fenced_code"])
        html = f"<html><body style='font-family:sans-serif;max-width:900px;margin:2em auto'>{html}</body></html>"
        weasyprint.HTML(string=html).write_pdf(pdf_path)
        logger.info("[REPORTER] PDF written via weasyprint: %s", pdf_path)
    except ImportError:
        logger.warning("[REPORTER] PDF render failed — install pandoc or weasyprint")


# ── Context helpers ───────────────────────────────────────────────────────────

def _safe_finding(f: Dict) -> Dict:
    """Strip large/binary fields before passing to model."""
    return {k: v for k, v in f.items()
            if k not in ("patch_diff", "call_path_raw", "sbom_data")
            and v is not None and v != ""}


def _summarise_findings(findings: List[Dict]) -> str:
    lines = []
    for f in findings:
        fid = (f.get("finding_id") or "")[:12]
        cwe = f.get("cwe_id") or f.get("cve_id") or "unknown"
        sev = f.get("severity") or "unknown"
        reach = f.get("reachability_state") or "unknown"
        ffile = f.get("file_path") or ""
        fline = f.get("line_number") or ""
        status = f.get("enzo_status") or "open"
        lines.append(f"  {fid}  {cwe:<12}  {sev:<8}  {reach:<12}  {ffile}:{fline}  [{status}]")
    return "\n".join(lines)


def _attack_surface_block(findings: List[Dict]) -> str:
    reachable = [f for f in findings
                 if (f.get("reachability_state") or "").upper() in ("REACHABLE", "CONFIRMED")]
    entry_points = set()
    for f in reachable:
        ep = f.get("entry_point") or f.get("call_path_entry") or ""
        if ep:
            entry_points.add(ep)
    return (
        f"Reachable findings: {len(reachable)}/{len(findings)}\n"
        f"Entry points: {', '.join(sorted(entry_points)[:5]) or 'not recorded'}"
    )


def _fix_status_block(summary: Dict, findings: List[Dict]) -> str:
    fixed = summary.get("fixed", 0)
    total = len(findings)
    cost = summary.get("total_cost", 0.0) or 0.0
    return (
        f"Auto-fixed: {fixed}/{total}  "
        f"Cost: ${cost:.4f}  "
        f"Manual required: {total - fixed}"
    )


def _similar_findings_block(f: Dict, all_findings: List[Dict]) -> str:
    cwe = f.get("cwe_id") or ""
    fid = f.get("finding_id") or ""
    similar = [x for x in all_findings
               if x.get("cwe_id") == cwe and x.get("finding_id") != fid][:3]
    if not similar:
        return "None"
    return "\n".join(
        f"  {(x.get('finding_id') or '')[:12]}  {x.get('file_path') or ''}:{x.get('line_number') or ''}"
        for x in similar
    )
