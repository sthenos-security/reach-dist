# Copyright © 2026 Sthenos Security. All rights reserved.
"""
Prompt templates for Enzo Reporter.

Design principle: feed structured context, ask for structured output.
The model reasons over data — it does not invent findings.

All prompts include explicit constraints:
  - Never invent findings not in the data
  - Cite findings by ID
  - Distinguish confirmed vs theoretical reachability
  - Be specific: file names, line numbers, entry points
"""

# ── System prompts ────────────────────────────────────────────────────────────

RISK_REPORT_SYSTEM = """You are a senior application security analyst.
You are reviewing automated SAST/SCA scan results enriched with reachability analysis.

Reachability context: findings marked REACHABLE have a confirmed call path from an
application entry point (HTTP handler, CLI entrypoint, message queue consumer) through
to the vulnerable sink. This means the vulnerability is exploitable without further
preconditions. Findings marked UNREACHABLE or UNKNOWN are lower practical priority.

Your output will be read by engineering leadership and used to make fix prioritisation
decisions. Be direct and specific. No padding, no generic caveats.

STRICT CONSTRAINTS:
- Never mention findings not present in the provided data
- Always cite finding IDs (e.g. finding_id: abc123) when making claims
- Distinguish REACHABLE (confirmed) from THEORETICAL (static only)
- State reachability status and entry point for every top finding
- Do not speculate about business context not provided
- Output plain prose, no markdown headers, no bullet points
- Avoid security jargon that a non-specialist VP cannot act on"""

RISK_EXEC_SUMMARY_PROMPT = """Findings summary:
{findings_summary}

Attack surface:
{attack_surface}

Fix status:
{fix_status}

Write a 150-200 word executive summary for engineering leadership.
Cover: what the most serious exposure is, whether it is reachable from the public surface,
what has been fixed automatically, and what requires human action.
Mention specific files and entry points. Do not use bullet points. Plain prose only."""

RISK_FINDING_ANALYSIS_PROMPT = """Analyse this security finding and provide a verdict.

Finding:
{finding_json}

Call path (if available):
{call_path}

Similar findings in this codebase:
{similar_findings}

Provide:
1. VERDICT: Confirmed exploitable / Requires further investigation / False positive risk
2. PRACTICAL RISK: One sentence on what an attacker actually does with this
3. PRIORITY RELATIVE TO OTHER FINDINGS: Why this ranks where it does
4. FIX ASSESSMENT: Is the automated fix sufficient, or does it need review

Be specific. Cite the finding_id, file, line, and entry point.
No markdown. Plain prose. 3-5 sentences total."""

RISK_PATTERN_ANALYSIS_PROMPT = """Here are all findings from this scan:
{all_findings_summary}

Identify any patterns:
- Same CWE appearing in multiple files (systemic issue vs one-off)
- Same developer/component introducing vulnerabilities
- Same framework API being misused across the codebase
- Any finding that appears to be a canary for a deeper architecture problem

State each pattern in one sentence with specific file/finding references.
If no meaningful patterns, say so. No markdown. Plain prose."""

# ── GRC compliance prompts ────────────────────────────────────────────────────

GRC_ATTESTATION_PROMPT = """Write a formal attestation paragraph for a {framework_name} audit.

Context:
- Organisation: {org_name}
- Application: {app_name}
- Report period: {period_start} to {period_end}
- Scan tool: REACHABLE v{reachable_version} with reachability analysis
- Findings detected: {total_findings}
- Findings remediated: {remediated}
- Findings accepted/open: {open_count}
- Scan frequency: {scan_frequency}

The paragraph should:
- State that automated security scanning was performed
- Reference the specific controls being addressed ({controls})
- Note that remediation was performed and verified
- Be formal but not verbose — 80-120 words
- Suitable for inclusion in a {framework_name} audit package

Output: the attestation paragraph only. No preamble."""

GRC_FINDING_NARRATIVE_PROMPT = """Write an evidence narrative for one security finding for a {framework_name} audit.

Finding data:
{finding_json}

Controls addressed: {controls}
Fix data: {fix_json}

The narrative should:
- State what was found, where, and when
- Confirm the fix was applied and verified
- Reference the specific control requirement(s) addressed
- Be suitable for an auditor reading an evidence package
- 60-90 words, past tense, formal register

Output: the narrative only. No preamble or heading."""

GRC_ACCEPTED_RISK_PROMPT = """Pre-fill an accepted risk statement for an auditor.

Finding data:
{finding_json}

Controls affected: {controls}

Provide:
1. A one-paragraph description of the vulnerability and its potential business impact
   (what data or system could be affected, what conditions would allow exploitation)
2. A suggested compensating control that would reduce risk while the finding remains open

The risk owner will add their name, justification, and sign-off date.
Be specific about the finding. No markdown. Plain prose."""

GRC_CONTROL_SUMMARY_PROMPT = """Summarise the compliance status for control {control_id} ({control_desc}).

Framework: {framework_name}
Findings affecting this control:
{findings_for_control}

Provide a 2-3 sentence status statement suitable for a control testing evidence package.
State: how many findings were identified, how many were remediated, and any residual risk.
Be factual. No embellishment. Past tense."""

# ── Deep-dive prompt ──────────────────────────────────────────────────────────

FINDING_DEEP_DIVE_PROMPT = """Provide a detailed analysis of this security finding.

Finding:
{finding_json}

Code context (vulnerable region):
{code_slice}

Call path:
{call_path}

Fix applied:
{fix_diff}

Provide:

VERDICT: [Confirmed exploitable / Lower risk than scored / Requires investigation]

EXPLOIT SCENARIO:
One paragraph describing exactly what an attacker does. Be specific:
HTTP method, endpoint, payload format, what data or capability they gain.

REACHABILITY:
Confirm or qualify the reachability analysis. Is the entry point public or
authenticated? How many hops from the entry point to the sink?

FIX ASSESSMENT:
Is the applied fix correct and complete? Any edge cases the fix might miss?

RESIDUAL RISK:
What risk remains after the fix? Any related patterns to look for?

No markdown headers. Plain prose under each label. Total 200-300 words."""
