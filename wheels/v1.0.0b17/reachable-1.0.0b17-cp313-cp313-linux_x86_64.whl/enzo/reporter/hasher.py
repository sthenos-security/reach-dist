# Copyright © 2026 Sthenos Security. All rights reserved.
"""
Tamper-evident report hashing.

Each generated report embeds a SHA-256 hash of the enzo.db file at
generation time, plus a manifest entry written to
.reachable/report-manifests.jsonl.

An auditor can recompute the hash against a DB backup to verify the
report was not altered after generation.
"""
from __future__ import annotations

import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional


def hash_db(db_path: str) -> str:
    """Return hex SHA-256 of db_path contents."""
    h = hashlib.sha256()
    with open(db_path, "rb") as f:
        while chunk := f.read(65536):
            h.update(chunk)
    return h.hexdigest()


def write_manifest(
    repo_path: str,
    report_type: str,
    report_path: str,
    db_hash: str,
    framework: Optional[str] = None,
    enzo_version: str = "",
    model: str = "",
) -> None:
    """
    Append an entry to .reachable/report-manifests.jsonl.

    Each line is a JSON object:
    {
      "timestamp": "2026-03-03T18:42:11Z",
      "report_type": "risk" | "grc" | "executive" | "deep_dive",
      "framework": "soc2" | null,
      "report_path": "/abs/path/to/report.md",
      "db_hash": "sha256:abc123...",
      "enzo_version": "0.6.0",
      "model": "ollama/deepseek-r1:7b"
    }
    """
    manifest_dir = Path(repo_path) / ".reachable"
    manifest_dir.mkdir(parents=True, exist_ok=True)
    manifest_file = manifest_dir / "report-manifests.jsonl"

    entry = {
        "timestamp":    datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
        "report_type":  report_type,
        "framework":    framework,
        "report_path":  str(Path(report_path).resolve()),
        "db_hash":      f"sha256:{db_hash}",
        "enzo_version": enzo_version,
        "model":        model,
    }
    with open(manifest_file, "a") as f:
        f.write(json.dumps(entry) + "\n")


def verify_report(
    report_path: str,
    db_path: str,
    manifest_path: Optional[str] = None,
) -> tuple[bool, str]:
    """
    Verify a report's DB hash against the current DB file.

    Returns (ok, message).
    """
    # Extract hash from report header
    report_text = Path(report_path).read_text()
    db_hash_in_report = None
    for line in report_text.splitlines()[:20]:
        if "DB state hash" in line or "db_hash" in line.lower():
            parts = line.split("SHA256:", 1) if "SHA256:" in line else line.split("sha256:", 1)
            if len(parts) == 2:
                db_hash_in_report = parts[1].strip().split()[0]
                break

    if not db_hash_in_report:
        return False, "No DB hash found in report header"

    current_hash = hash_db(db_path)
    if current_hash == db_hash_in_report:
        return True, f"✓ DB hash verified: sha256:{current_hash[:16]}..."
    else:
        return False, (
            f"✗ Hash mismatch — DB may have changed since report was generated\n"
            f"  Report hash: sha256:{db_hash_in_report[:16]}...\n"
            f"  Current DB:  sha256:{current_hash[:16]}..."
        )
