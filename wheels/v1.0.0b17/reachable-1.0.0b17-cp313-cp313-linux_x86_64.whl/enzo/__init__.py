#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.
"""
Enzo — AI Remediation Engine for REACHABLE

Self-contained module.  Drop reachable/enzo/ into the source tree.

    Reads from:   repo.db  (findings, call_graph_cache, sbom_cache)  — NEVER WRITES
    Writes to:    enzo.db  (per-repo, sibling to repo.db)
    Writes to:    ~/.reachable/enzo/knowledge.db  (global cross-repo intelligence)
    Modifies:     NOTHING in the existing codebase

Standalone:   python -m enzo run /path/to/repo
Integrated:   reachctl enzo run /path/to/repo   (see INTEGRATION.md)
"""

__version__ = "0.6.4"
