#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.
"""
Enzo pipeline — orchestrates the full remediation flow.

    query → classify → [for each finding] → patch → validate → commit → report
"""

from __future__ import annotations

import json
import logging
import sys
import threading
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Optional

# ── Spinner ──────────────────────────────────────────────────────────────

class _Spinner:
    """Simple TTY spinner shown during long model generation."""
    _FRAMES = ("⠋", "⠙", "⠹", "⠸", "⠼", "⠴", "⠦", "⠧", "⠇", "⠏")

    def __init__(self, label: str = "Generating patch"):
        self._label = label
        self._stop = threading.Event()
        self._thread = threading.Thread(target=self._spin, daemon=True)

    def _spin(self):
        i = 0
        while not self._stop.is_set():
            frame = self._FRAMES[i % len(self._FRAMES)]
            sys.stdout.write(f"\r  {frame} {self._label}...")
            sys.stdout.flush()
            time.sleep(0.1)
            i += 1

    def start(self):
        if sys.stdout.isatty():
            self._thread.start()

    def stop(self, clear: bool = True):
        self._stop.set()
        if self._thread.is_alive():
            self._thread.join(timeout=0.5)
        if clear and sys.stdout.isatty():
            sys.stdout.write("\r" + " " * (len(self._label) + 10) + "\r")
            sys.stdout.flush()


from . import git_ops  # noqa: E402
from .attestation import build_attestation  # noqa: E402
from .classifier import classify_batch, filter_fixable, prioritize  # noqa: E402
from .config import EnzoConfig  # noqa: E402
from .consolidator import consolidate  # noqa: E402
from .context_builder import build_context, detect_environment  # noqa: E402
from .db import EnzoRepoDB  # noqa: E402
from .knowledge import EnzoKnowledgeDB  # noqa: E402
from .models import EnzoFinding, FixType, PatchResult, RemediationStatus, ValidationReport  # noqa: E402
from .patcher.engine import PatchEngine  # noqa: E402
from .validator.runner import Validator  # noqa: E402
from .verifier import verify_fix  # noqa: E402

logger = logging.getLogger(__name__)


@dataclass
class RemediationOutcome:
    """Result for a single finding remediation."""
    finding_id: str = ""
    finding_type: str = ""
    severity: str = ""
    fix_type: str = ""
    status: RemediationStatus = RemediationStatus.PENDING
    attempts: int = 0
    branch: Optional[str] = None
    patcher_method: str = "ai"         # "deterministic" | "ai"
    file_path: Optional[str] = None    # for semgrep verify
    rule_id: Optional[str] = None      # for semgrep verify
    package_name: Optional[str] = None # for grype verify
    fix_version: Optional[str] = None  # for grype verify
    pr_url: Optional[str] = None
    patch: Optional[PatchResult] = None
    validation: Optional[ValidationReport] = None
    error: Optional[str] = None
    attestation: Optional[Dict] = None
    # Set True for errors that mean the entire pipeline must stop (billing, auth).
    # Distinct from a per-finding failure where we should keep processing others.
    fatal: bool = False


# Keywords in an error message that mean "stop everything, no point continuing"
_FATAL_ERROR_KEYWORDS = (
    # Cloud API billing / auth — no point retrying
    "credit", "balance", "billing", "unauthorized", "forbidden",
    "authentication", "api key", "invalid_api_key", "permission denied",
    # Local model unreachable — Ollama not running, retrying is pointless
    "ollama_unreachable",
    "groq_unreachable",
    # Groq daily token quota — pipeline should stop, not hammer for more tokens
    "groq_tpd_exhausted",
    "tokens per day",
)


def _is_fatal_error(error: Optional[str]) -> bool:
    if not error:
        return False
    low = error.lower()
    return any(kw in low for kw in _FATAL_ERROR_KEYWORDS)


@dataclass
class PipelineResult:
    """Aggregate result for a full pipeline run."""
    total_findings: int = 0
    fixable_findings: int = 0
    attempted: int = 0
    succeeded: int = 0
    failed: int = 0
    manual: int = 0
    aborted: int = 0
    abort_reason: Optional[str] = None
    outcomes: List[RemediationOutcome] = field(default_factory=list)
    # Post-run consolidation + verification
    batch_branch: Optional[str] = None
    verified: int = 0
    verify_failed: int = 0
    consolidation_conflicts: List[str] = field(default_factory=list)


class EnzoPipeline:
    """
    Full remediation pipeline.

    Usage::

        pipeline = EnzoPipeline(config, repo_path)
        result = pipeline.run()
        # or for a single finding:
        outcome = pipeline.fix_finding(finding_id)
    """

    def __init__(self, config: EnzoConfig, repo_path: str):
        self.config = config
        self.repo_path = str(Path(repo_path).resolve())

        # Locate repo.db
        from .query import RepoReader, get_repo_db_path  # noqa: E402
        self.repo_db_path = get_repo_db_path(self.repo_path)
        self.reader: Optional[RepoReader] = None

        # Own databases
        self.enzo_db = EnzoRepoDB(self.repo_db_path)
        self.knowledge = EnzoKnowledgeDB()

        # Subsystems
        self.patcher = PatchEngine(config, self.knowledge)
        self.validator = Validator(config)

        # Environment
        self.env = detect_environment(self.repo_path)
        logger.info(
            "Enzo pipeline init: language=%s build=%s test=%s framework=%s",
            self.env.get("language"), self.env.get("build_system"),
            self.env.get("test_framework"), self.env.get("framework"),
        )

        # Upload repo.db snapshot for cloud/both modes (once per pipeline session)
        if config.cloud_enabled and self.patcher.cloud:
            self._upload_scan_db_if_cloud()

    def run(
        self,
        scan_id: Optional[int] = None,
        finding_ids: Optional[List[str]] = None,
        dry_run: bool = False,
        fail_fast: bool = False,
        consolidate_branch: bool = True,
    ) -> PipelineResult:
        """
        Full pipeline: query → classify → prioritize → patch → validate → commit.

        Args:
            scan_id: Specific scan ID (default: latest).
            finding_ids: Specific finding IDs to fix (default: all fixable).
            dry_run: Generate patches but don't commit/push.
            fail_fast: Stop after the first failed finding instead of
                       continuing to the next one.  Useful during initial
                       setup / debugging to avoid a wall of errors.
        """
        result = PipelineResult()

        # Open repo.db reader
        self._open_reader()
        if not self.reader:
            return result

        # Get scan
        if scan_id is None:
            scan_id = self.reader.get_latest_scan_id()
        if scan_id is None:
            logger.error("No completed scans found")
            return result

        # Query findings
        findings = self.reader.get_findings(
            scan_id=scan_id,
            reachable_only=self.config.reachable_only,
        )
        result.total_findings = len(findings)

        # Classify
        classify_batch(findings)

        # Filter to fixable
        fixable = filter_fixable(findings, self.config.fix_types)

        # Apply severity threshold
        fixable = [f for f in fixable if self.config.severity_meets_threshold(f.severity)]

        # Filter to specific IDs if requested
        if finding_ids:
            fixable = [f for f in fixable if f.finding_id in finding_ids]

        result.fixable_findings = len(fixable)

        # Prioritize
        fixable = prioritize(fixable)

        # Cost estimate for cloud runs
        if fixable and self.config.mode in ("cloud", "fallback"):
            try:
                from .cost import estimate_run_cost
                estimate = estimate_run_cost(self.config, fixable, self.repo_path)
                if estimate:
                    print(estimate.format())
            except Exception as _ce:
                logger.debug("Cost estimate failed: %s", _ce)

        # Process each finding
        for idx, finding in enumerate(fixable):
            try:
                outcome = self._remediate_finding(finding, scan_id, dry_run)
            except Exception as exc:
                import traceback
                logger.error(
                    "Unexpected crash on finding %s: %s\n%s",
                    finding.finding_id[:12], exc, traceback.format_exc(),
                )
                outcome = RemediationOutcome(
                    finding_id=finding.finding_id,
                    finding_type=finding.finding_type,
                    severity=finding.severity,
                    fix_type=finding.fix_type.value,
                    status=RemediationStatus.FAILED,
                    error=f"Internal error: {exc}",
                )
            result.outcomes.append(outcome)
            result.attempted += 1
            if outcome.status == RemediationStatus.SUCCESS:
                result.succeeded += 1
            elif outcome.status == RemediationStatus.MANUAL:
                result.manual += 1
            elif outcome.status == RemediationStatus.ABORTED:
                result.aborted += 1
                result.abort_reason = outcome.error
                # Mark all remaining findings as aborted without attempting them
                remaining = fixable[idx + 1:]
                for skipped in remaining:
                    skipped_outcome = RemediationOutcome(
                        finding_id=skipped.finding_id,
                        finding_type=skipped.finding_type,
                        severity=skipped.severity,
                        fix_type=skipped.fix_type.value,
                        status=RemediationStatus.ABORTED,
                        error="Pipeline aborted by earlier fatal error",
                    )
                    result.outcomes.append(skipped_outcome)
                    result.aborted += 1
                logger.error("Pipeline aborted: %s — %d findings skipped", outcome.error, len(remaining))
                break
            else:
                result.failed += 1
                if fail_fast:
                    # Stop immediately — don't attempt remaining findings.
                    remaining = fixable[idx + 1:]
                    for skipped in remaining:
                        skipped_outcome = RemediationOutcome(
                            finding_id=skipped.finding_id,
                            finding_type=skipped.finding_type,
                            severity=skipped.severity,
                            fix_type=skipped.fix_type.value,
                            status=RemediationStatus.ABORTED,
                            error="Skipped (--fail-fast: earlier finding failed)",
                        )
                        result.outcomes.append(skipped_outcome)
                        result.aborted += 1
                    if remaining:
                        logger.info("--fail-fast: stopping after first failure (%d findings skipped)", len(remaining))
                    break

        self._close_reader()

        # ── Consolidation + targeted verification ────────────────────────────
        if not dry_run and consolidate_branch and result.succeeded > 0:
            fix_branches = [
                o.branch for o in result.outcomes
                if o.status.value == "success" and o.branch
            ]
            if fix_branches:
                logger.info("[CONSOLIDATE] merging %d fix branches", len(fix_branches))
                con = consolidate(self.repo_path, fix_branches)
                if con.success:
                    result.batch_branch = con.batch_branch
                    result.consolidation_conflicts = con.conflicts
                    logger.info("[CONSOLIDATE] batch branch: %s", con.batch_branch)
                    # Targeted verification against outcomes
                    for outcome in result.outcomes:
                        if outcome.status.value != "success":
                            continue
                        next(  # noqa: F841 — side-effect check only
                        (
                            (f for f in result.outcomes if f.finding_id == outcome.finding_id),
                            None
                        ))
                        vr = verify_fix(
                            finding_id=outcome.finding_id,
                            fix_type=outcome.fix_type,
                            method=getattr(outcome, "patcher_method", "ai"),
                            file_path=getattr(outcome, "file_path", "") or "",
                            rule_id=getattr(outcome, "rule_id", None),
                            package_name=getattr(outcome, "package_name", None),
                            fix_version=getattr(outcome, "fix_version", None),
                            repo_path=self.repo_path,
                        )
                        if vr.verified:
                            result.verified += 1
                        else:
                            result.verify_failed += 1
                            logger.warning("[VERIFY] ✗ %s — %s", outcome.finding_id, vr.detail)
                else:
                    logger.warning("[CONSOLIDATE] failed: %s", con.error)

        return result

    def fix_finding(
        self, finding_id: str, scan_id: Optional[int] = None, dry_run: bool = False,
    ) -> RemediationOutcome:
        """Fix a single finding by ID."""
        self._open_reader()
        if not self.reader:
            return RemediationOutcome(
                finding_id=finding_id,
                status=RemediationStatus.FAILED,
                error="Cannot open repo.db",
            )

        if scan_id is None:
            scan_id = self.reader.get_latest_scan_id()
        if scan_id is None:
            return RemediationOutcome(
                finding_id=finding_id,
                status=RemediationStatus.FAILED,
                error="No completed scans",
            )

        finding = self.reader.get_finding_by_id(scan_id, finding_id)
        if not finding:
            return RemediationOutcome(finding_id=finding_id, status=RemediationStatus.FAILED, error="Finding not found")

        from .classifier import classify  # noqa: E402
        finding.fix_type = classify(finding)

        outcome = self._remediate_finding(finding, scan_id, dry_run)
        self._close_reader()
        return outcome

    def _remediate_finding(
        self, finding: EnzoFinding, scan_id: int, dry_run: bool,
    ) -> RemediationOutcome:
        """
        Core remediation loop for a single finding with retry.

        Closed loop:
            generate patch → validate in worktree (build + test + rescan)
            → if all pass → commit in worktree → done
            → if fail → discard worktree → retry with error feedback
        """
        outcome = RemediationOutcome(
            finding_id=finding.finding_id,
            finding_type=finding.finding_type,
            severity=finding.severity,
            fix_type=finding.fix_type.value,
        )

        if finding.fix_type == FixType.MANUAL:
            outcome.status = RemediationStatus.MANUAL
            outcome.error = "Requires manual remediation"
            return outcome

        # Check prior attempts
        prior_count = self.enzo_db.get_attempt_count(finding.finding_id)

        # Original commit for attestation
        original_commit = git_ops.get_current_commit(self.repo_path)

        # Knowledge hints
        knowledge_hints = self.knowledge.get_best_strategy(
            cwe_id=finding.cwe_id,
            finding_type=finding.finding_type,
            language=self.env.get("language", ""),
            framework=self.env.get("framework", ""),
        )

        # Dependency chain
        dep_chain = []
        if self.reader and finding.package_name:
            dep_chain = self.reader.get_dependency_chain(finding.package_name)

        # Collect original finding IDs for rescan diff
        original_finding_ids = None
        if self.reader:
            try:
                all_findings = self.reader.get_findings(scan_id=scan_id)
                original_finding_ids = {f.finding_id for f in all_findings}
            except Exception as exc:
                logger.warning("Could not load original findings for rescan diff (rescan will be blind): %s", exc)
                original_finding_ids = set()

        max_attempts = self.config.max_retries + 1
        prior_error = None
        prior_error_stage = None

        for attempt in range(1, max_attempts + 1):
            outcome.attempts = attempt
            logger.info(
                "Attempt %d/%d for %s (%s, %s)",
                attempt, max_attempts, finding.finding_id[:12],
                finding.fix_type.value, finding.severity,
            )

            # Record attempt in enzo.db
            attempt_id = self.enzo_db.record_attempt(
                finding_id=finding.finding_id,
                finding_type=finding.finding_type,
                severity=finding.severity,
                fix_type=finding.fix_type.value,
                scan_id=scan_id,
                package_name=finding.package_name,
                package_version=finding.package_version,
                cwe_id=finding.cwe_id,
                cve_id=finding.cve_id,
                app_reachability=finding.app_reachability,
                attempt_number=prior_count + attempt,
                status="patching",
                model_local=self.config.local_model,
                model_cloud=self.config.cloud_model if self.config.cloud_enabled else None,
            )

            # Build context
            context = build_context(
                finding, self.repo_path,
                dependency_chain=dep_chain,
                knowledge_hints=knowledge_hints,
                attempt_number=attempt,
                prior_errors=[prior_error] if prior_error else [],
                prior_strategies=[],
            )

            # ── Generate patch ────────────────────────────────────────
            _spinner = _Spinner(f"Generating patch (attempt {attempt}/{max_attempts})")
            _spinner.start()
            try:
                patch = self.patcher.generate_patch(
                    finding, context, self.repo_path,
                    attempt_number=attempt,
                    prior_error=prior_error,
                    prior_error_stage=prior_error_stage,
                )
            finally:
                _spinner.stop()
            outcome.patch = patch

            if not patch.success:
                prior_error = patch.error
                prior_error_stage = "patch"
                self.enzo_db.complete_attempt(attempt_id, "failed", patch_diff=patch.diff, build_error=patch.error)
                logger.warning("Patch generation failed: %s", patch.error)
                print(f"  ✗ {patch.error}")
                # Fatal errors — abort the entire pipeline, no point retrying
                if _is_fatal_error(patch.error):
                    if "ollama_unreachable" in (patch.error or ""):
                        print("  ⛔ Ollama is not reachable — aborting pipeline.")
                        print("     Start it with: ollama serve")
                        print("     Or:            brew services start ollama")
                    elif "groq_tpd_exhausted" in (patch.error or ""):
                        logger.error(
                            "⛔ Groq daily token limit (TPD) exhausted — "
                            "aborting pipeline. %s", patch.error,
                        )
                        result.abort_reason = patch.error  # noqa: F821
                        break
                    elif "groq_unreachable" in (patch.error or ""):
                        print("  ⛔ Groq is not reachable — aborting pipeline.")
                        print("     Set your key:  export GROQ_API_KEY=gsk_...")
                        print("     Get a key at:  https://console.groq.com/keys")
                    else:
                        print("  ⛔ Billing/auth error — aborting pipeline.")
                        print("     Go to: console.anthropic.com/settings/billing")
                    outcome.status = RemediationStatus.ABORTED
                    outcome.error = patch.error
                    outcome.fatal = True
                    return outcome
                continue

            # ── Dry run: just record patch, skip validation ───────────
            if dry_run:
                self.enzo_db.complete_attempt(
                    attempt_id, "success",
                    patch_diff=patch.diff,
                    files_modified=patch.files_modified,
                )
                outcome.status = RemediationStatus.SUCCESS
                return outcome

            # ── Closed-loop validation in isolated worktree ───────────
            #
            #  worktree created → diff applied → build → test → rescan
            #  nothing touches the user's checkout until proven
            #
            self.enzo_db.update_attempt(attempt_id, status="validating")

            validation, worktree = self.validator.validate(
                finding=finding,
                repo_path=self.repo_path,
                diff=patch.diff,
                files_modified=patch.files_modified,
                ecosystem=self.env.get("build_system"),
                test_framework=self.env.get("test_framework"),
                original_finding_ids=original_finding_ids,
            )
            outcome.validation = validation

            if not validation.all_passed or worktree is None:
                # Validation failed — worktree already cleaned up
                failure = validation.first_failure
                prior_error = failure.error if failure else "Validation failed"
                prior_error_stage = failure.stage if failure else "unknown"

                self.enzo_db.complete_attempt(
                    attempt_id, "failed",
                    patch_diff=patch.diff,
                    files_modified=patch.files_modified,
                    rescan_result="PASS" if validation.rescan and validation.rescan.passed else "FAIL",
                    build_result="PASS" if validation.build and validation.build.passed else "FAIL",
                    test_result="PASS" if validation.test and validation.test.passed else "FAIL",
                    build_error=validation.build.error if validation.build and not validation.build.passed else None,
                    test_error=validation.test.error if validation.test and not validation.test.passed else None,
                )

                # Learn from failure
                self._learn(finding, patch, False, attempt, validation)
                logger.warning("Validation failed at %s: %s", prior_error_stage, prior_error)
                continue

            # ── ALL PASSED — commit in worktree ───────────────────────
            commit_msg = git_ops.generate_commit_message(finding)
            remediation_commit = worktree.commit(commit_msg, sign=self.config.commit_signing)
            outcome.branch = worktree.branch_name
            # Populate fields used by post-run targeted verifier
            outcome.patcher_method = patch.model_used if patch.model_used == "deterministic" else "ai"
            outcome.file_path = getattr(finding, "file_path", None)
            outcome.rule_id = getattr(finding, "rule_id", None)
            outcome.package_name = getattr(finding, "package_name", None)
            outcome.fix_version = getattr(finding, "fix_version", None)

            # Attestation
            att = build_attestation(
                finding, patch, validation, self.repo_path,
                worktree.branch_name, original_commit,
                remediation_commit or "", attempt,
            )
            outcome.attestation = att.to_dict()

            self.enzo_db.complete_attempt(
                attempt_id, "success",
                patch_diff=patch.diff,
                files_modified=patch.files_modified,
                cloud_strategy=patch.cloud_strategy,
                rescan_result="PASS", build_result="PASS", test_result="PASS",
                attestation=json.dumps(att.to_dict()),
                tokens_in=getattr(patch, "tokens_in", 0) or 0,
                tokens_out=getattr(patch, "tokens_out", 0) or 0,
                cost_usd=getattr(patch, "cost_usd", 0.0) or 0.0,
                patcher_method=outcome.patcher_method,
            )

            # Learn from success
            self._learn(finding, patch, True, attempt, validation)

            outcome.status = RemediationStatus.SUCCESS
            logger.info(
                "✓ Remediated %s (%s) on attempt %d — branch: %s",
                finding.finding_id[:12], finding.fix_type.value,
                attempt, worktree.branch_name,
            )

            # Cleanup worktree; branch remains for PR
            worktree.cleanup()
            return outcome

        # All attempts exhausted
        outcome.status = RemediationStatus.FAILED
        outcome.error = f"Failed after {max_attempts} attempts. Last error: {prior_error}"
        return outcome


    def _learn(self, finding, patch, success, attempts, validation):
        """Record outcome in knowledge DB."""
        try:
            self.knowledge.learn_from_attempt(
                finding_type=finding.finding_type,
                cwe_id=finding.cwe_id,
                language=self.env.get("language", ""),
                framework=self.env.get("framework", ""),
                ecosystem=self.env.get("build_system", ""),
                fix_type=finding.fix_type.value,
                strategy=patch.strategy_used or "unknown",
                success=success,
                attempts_taken=attempts,
                rescan_passed=validation.rescan.passed if validation.rescan else None,
                build_passed=validation.build.passed if validation.build else None,
                test_passed=validation.test.passed if validation.test else None,
                build_error=validation.build.error if validation.build and not validation.build.passed else None,
                test_error=validation.test.error if validation.test and not validation.test.passed else None,
                package_name=finding.package_name,
                from_version=finding.package_version,
                to_version=finding.fix_version,
                model_name=patch.model_used,
                model_role="hybrid" if patch.cloud_strategy else "local",
            )
        except Exception as exc:
            logger.warning("Knowledge learning failed: %s", exc)

    def _upload_scan_db_if_cloud(self):
        """
        In cloud or both mode: compress and upload the last scan's repo.db
        to the Anthropic Files API so Claude has full scan context.

        Runs once at pipeline init. The file_id is cached on the CloudModel
        instance and attached to every strategy request in this session.
        Deleted automatically when pipeline.close() is called.
        """
        try:
            file_id = self.patcher.cloud.upload_scan_db(str(self.repo_db_path))
            if file_id:
                print(f"  ✓ Uploaded scan snapshot to cloud context (file_id={file_id[:12]}…)")
            else:
                logger.info("repo.db upload skipped (not available or too large)")
        except Exception as exc:
            logger.warning("repo.db upload failed: %s — continuing without it", exc)

    def _open_reader(self):
        if self.reader is None:
            from .query import RepoReader  # noqa: E402
            try:
                self.reader = RepoReader(self.repo_db_path)
            except FileNotFoundError:
                logger.error("repo.db not found: %s", self.repo_db_path)
                self.reader = None

    def _close_reader(self):
        if self.reader:
            self.reader.close()
            self.reader = None

    def close(self):
        self._close_reader()
        self.enzo_db.close()
        self.knowledge.close()
        # Clean up uploaded scan snapshot from Anthropic Files API
        if self.patcher.cloud:
            self.patcher.cloud.delete_uploaded_db()
