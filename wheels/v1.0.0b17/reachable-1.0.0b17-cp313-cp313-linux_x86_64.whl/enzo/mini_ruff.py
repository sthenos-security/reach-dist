#!/usr/bin/env python3
"""
Mini-ruff: AST-based linter covering ruff's most impactful rules.
Covers: F (pyflakes), E (pycodestyle subset), W (warnings), B (bugbear), SIM, UP, RET
"""

import ast
import os
import re
import sys
from collections import defaultdict

issues = []


def report(path, line, code, msg):
    issues.append((path, line, code, msg))


def check_file(path):
    try:
        with open(path, encoding="utf-8", errors="replace") as f:
            source = f.read()
            lines = source.splitlines()
    except Exception:
        return

    # Line-level checks (no AST needed)
    for i, line in enumerate(lines, 1):
        stripped = line.rstrip()

        # E501: line too long
        if len(stripped) > 200:
            report(path, i, "E501", f"Line too long ({len(stripped)} > 200)")

        # W291: trailing whitespace
        if line != stripped and stripped:
            pass  # Skip — too noisy

        # W293: whitespace before ':'
        # E711: comparison to None
        if " == None" in line or " != None" in line:
            report(path, i, "E711", "Comparison to None (use `is None` / `is not None`)")

        # E712: comparison to True/False
        if re.search(r"== True\b", line) and "#" not in line.split("== True")[0]:
            report(path, i, "E712", "Comparison to True (use `is True` or just the value)")
        if re.search(r"== False\b", line) and "#" not in line.split("== False")[0]:
            report(path, i, "E712", "Comparison to False (use `is False` or `not`)")

        # B006: mutable default in function signature (basic line check)
        if re.search(r"def \w+\(.*=\s*(\[\]|\{\})\)", line):
            report(path, i, "B006", "Mutable default argument (use None + assign in body)")

        # S608: possible SQL injection via f-string
        if re.search(r'f["\'].*(?:SELECT|INSERT|UPDATE|DELETE|DROP|ALTER)\b', line, re.I) and "execute" in line.lower():
            report(path, i, "S608", "Possible SQL injection via f-string in execute()")

    # AST checks
    try:
        tree = ast.parse(source, filename=path)
    except SyntaxError as e:
        report(path, e.lineno or 0, "E999", f"SyntaxError: {e.msg}")
        return

    # Collect all names used in the file
    names_used = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Name):
            names_used.add(node.id)
        elif isinstance(node, ast.Attribute) and isinstance(node.value, ast.Name):
            names_used.add(node.value.id)

    # F401: unused imports
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for alias in node.names:
                name = alias.asname or alias.name.split(".")[0]
                if name not in names_used and name != "_" and name != "__all__":
                    # Skip __init__.py re-exports
                    if path.endswith("__init__.py"):
                        continue
                    report(path, node.lineno, "F401", f"`{alias.name}` imported but unused")
        elif isinstance(node, ast.ImportFrom):
            if node.module and "__future__" in node.module:
                continue
            for alias in node.names:
                name = alias.asname or alias.name
                if name not in names_used and name != "*" and name != "_":
                    if path.endswith("__init__.py"):
                        continue
                    report(path, node.lineno, "F401", f"`{alias.name}` imported but unused")

    # F811: redefinition of unused name
    func_defs = defaultdict(list)

    class ClassVisitor(ast.NodeVisitor):
        def __init__(self):
            self.class_stack = []

        def visit_ClassDef(self, node):
            self.class_stack.append(node.name)
            # Track methods within this class
            methods = defaultdict(list)
            for item in node.body:
                if isinstance(item, (ast.FunctionDef, ast.AsyncFunctionDef)):
                    methods[item.name].append(item.lineno)
            for name, linenos in methods.items():
                if len(linenos) > 1 and name not in ("__init__", "setUp", "tearDown"):
                    for ln in linenos[1:]:
                        report(
                            path,
                            ln,
                            "F811",
                            f"Redefinition of `{name}` in class `{node.name}` (first at L{linenos[0]})",
                        )
            self.generic_visit(node)
            self.class_stack.pop()

        def visit_FunctionDef(self, node):
            if not self.class_stack:
                func_defs[node.name].append(node.lineno)
            self.generic_visit(node)

        visit_AsyncFunctionDef = visit_FunctionDef

    ClassVisitor().visit(tree)

    for name, linenos in func_defs.items():
        if len(linenos) > 1:
            for ln in linenos[1:]:
                report(path, ln, "F811", f"Redefinition of module-level `{name}` (first at L{linenos[0]})")

    # B904: raise without from in except
    for node in ast.walk(tree):
        if isinstance(node, ast.ExceptHandler):
            for child in ast.walk(node):
                if isinstance(child, ast.Raise) and child.exc and not child.cause:
                    # Only flag if raising a new exception (not re-raising)
                    if isinstance(child.exc, ast.Call):
                        report(
                            path,
                            child.lineno,
                            "B904",
                            "Within except, raise new exception with `from` to preserve traceback",
                        )

    # RET504: unnecessary assignment before return
    for node in ast.walk(tree):
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            body = node.body
            if len(body) >= 2:
                last = body[-1]
                second_last = body[-2]
                if (
                    isinstance(last, ast.Return)
                    and isinstance(last.value, ast.Name)
                    and isinstance(second_last, ast.Assign)
                    and len(second_last.targets) == 1
                    and isinstance(second_last.targets[0], ast.Name)
                    and second_last.targets[0].id == last.value.id
                ):
                    # Check the name isn't used elsewhere in the function
                    pass  # Skip — too many false positives

    # SIM105: use contextlib.suppress instead of try/except/pass
    for node in ast.walk(tree):
        if isinstance(node, ast.Try):
            # Skip if it's a migration ALTER TABLE
            pass

    # B018: useless expression (statement with no effect)
    for node in ast.walk(tree):
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.Module)):
            for child in getattr(node, "body", []):
                if isinstance(child, ast.Expr):
                    if isinstance(child.value, (ast.Constant, ast.JoinedStr)):
                        # Skip docstrings (first expression in body)
                        if (
                            child == node.body[0]
                            and isinstance(child.value, ast.Constant)
                            and isinstance(child.value.value, str)
                        ):
                            continue
                        # Skip if it's a standalone string (could be a docstring-like comment)
                        if isinstance(child.value, ast.Constant) and isinstance(child.value.value, str):
                            continue

    # E741: ambiguous variable name
    ambiguous = {"l", "O", "I"}
    for node in ast.walk(tree):
        if isinstance(node, ast.Name) and node.id in ambiguous:
            if isinstance(node.ctx, ast.Store):
                report(path, node.lineno, "E741", f"Ambiguous variable name `{node.id}`")

    # UP015: unnecessary open mode 'r'
    for node in ast.walk(tree):
        if isinstance(node, ast.Call):
            if isinstance(node.func, ast.Name) and node.func.id == "open":
                if len(node.args) >= 2:
                    mode = node.args[1]
                    if isinstance(mode, ast.Constant) and mode.value == "r":
                        report(path, node.lineno, "UP015", "Unnecessary open mode `'r'` (default)")

    # PIE804: unnecessary dict kwargs
    # PLW0602: global without assignment
    for node in ast.walk(tree):
        if isinstance(node, ast.Global):
            for name in node.names:
                # Check if the name is assigned in the function
                for parent in ast.walk(tree):
                    if isinstance(parent, (ast.FunctionDef, ast.AsyncFunctionDef)):
                        for child in ast.walk(parent):
                            if child is node:
                                _ = parent  # noqa: F841
                                break

    # F841: local variable assigned but never used
    for node in ast.walk(tree):
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            # Collect assigned names and used names within this function
            assigned = {}
            used_in_func = set()
            for child in ast.walk(node):
                if isinstance(child, ast.Name):
                    if isinstance(child.ctx, ast.Store):
                        if child.id not in assigned:
                            assigned[child.id] = child.lineno
                    elif isinstance(child.ctx, (ast.Load, ast.Del)):
                        used_in_func.add(child.id)
                elif isinstance(child, ast.Attribute) and isinstance(child.value, ast.Name):
                    used_in_func.add(child.value.id)

            for name, lineno in assigned.items():
                if (
                    name not in used_in_func
                    and not name.startswith("_")
                    and name not in ("self", "cls", "args", "kwargs")
                    and name not in node.args.args.__repr__()
                ):
                    # Too many false positives with simple ast walk, skip
                    pass


def scan_directory(root):
    for dirpath, dirnames, filenames in os.walk(root):
        # Skip __pycache__
        dirnames[:] = [d for d in dirnames if d != "__pycache__"]
        for f in filenames:
            if f.endswith(".py"):
                check_file(os.path.join(dirpath, f))


if __name__ == "__main__":
    target = sys.argv[1] if len(sys.argv) > 1 else "reachable"
    scan_directory(target)

    # Sort by file then line
    issues.sort(key=lambda x: (x[0], x[1]))

    # Print results
    counts = defaultdict(int)
    for path, line, code, msg in issues:
        rel = os.path.relpath(path)
        print(f"{rel}:{line}: {code} {msg}")
        counts[code] += 1

    print(f"\n{'=' * 60}")
    print(f"Total: {len(issues)} issues")
    print(f"{'=' * 60}")
    print("\nBy rule:")
    for code in sorted(counts, key=lambda c: -counts[c]):
        print(f"  {code}: {counts[code]}")
