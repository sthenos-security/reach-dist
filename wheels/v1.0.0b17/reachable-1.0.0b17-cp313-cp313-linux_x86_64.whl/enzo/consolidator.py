#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.
"""
Consolidator — merges all reachable/fix/* branches into a single
batch branch after a pipeline run completes.

Branch naming: reachable/batch/YYYY-MM-DD[-N]
  N is appended if the date branch already exists.

The individual fix branches are kept — consolidation is additive.
"""
from __future__ import annotations

import logging
import subprocess
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import List, Optional

logger = logging.getLogger(__name__)


@dataclass
class ConsolidationResult:
    success: bool
    batch_branch: str = ""
    merged: List[str] = field(default_factory=list)
    skipped: List[str] = field(default_factory=list)
    conflicts: List[str] = field(default_factory=list)
    error: str = ""


def _git(cwd: str, *args, check: bool = True) -> subprocess.CompletedProcess:
    return subprocess.run(
        ["git", *args], cwd=cwd,
        capture_output=True, text=True, check=check,
    )


def _batch_branch_name(repo_path: str) -> str:
    """Return an unused reachable/batch/YYYY-MM-DD[-N] branch name."""
    date_str = datetime.now(timezone.utc).strftime("%Y-%m-%d")
    base = f"reachable/batch/{date_str}"
    r = _git(repo_path, "branch", "--list", f"{base}*", check=False)
    existing = [ln.strip().lstrip("* ") for ln in r.stdout.splitlines() if ln.strip()]
    if base not in existing:
        return base
    for i in range(2, 100):
        candidate = f"{base}-{i}"
        if candidate not in existing:
            return candidate
    return f"{base}-{datetime.now(timezone.utc).strftime('%H%M%S')}"


def consolidate(
    repo_path: str,
    fix_branches: List[str],
    base_branch: Optional[str] = None,
) -> ConsolidationResult:
    """
    Merge all fix_branches into a new batch branch off base_branch (default: HEAD).

    Strategy: --no-ff merge each branch in sequence.
    On conflict: skip that branch, record it, continue with rest.
    """
    if not fix_branches:
        return ConsolidationResult(success=False, error="no fix branches to consolidate")

    # Filter out detached/invalid
    valid = [b for b in fix_branches if b and b != "(detached)"]
    if not valid:
        return ConsolidationResult(success=False, error="no valid branches to consolidate")

    # Determine base
    if base_branch is None:
        r = _git(repo_path, "rev-parse", "--abbrev-ref", "HEAD", check=False)
        base_branch = r.stdout.strip() or "main"

    batch = _batch_branch_name(repo_path)
    logger.info("[CONSOLIDATE] Creating %s from %s (%d branches)", batch, base_branch, len(valid))

    # Create batch branch from base
    try:
        _git(repo_path, "checkout", "-b", batch, base_branch)
    except subprocess.CalledProcessError as e:
        return ConsolidationResult(
            success=False, error=f"could not create {batch}: {e.stderr.strip()}"
        )

    result = ConsolidationResult(success=True, batch_branch=batch)

    for branch in valid:
        try:
            _git(repo_path, "merge", "--no-ff", "--no-edit", branch)
            result.merged.append(branch)
            logger.debug("[CONSOLIDATE] ✓ merged %s", branch)
        except subprocess.CalledProcessError:
            # Abort the failed merge and continue
            _git(repo_path, "merge", "--abort", check=False)
            result.conflicts.append(branch)
            logger.warning("[CONSOLIDATE] ✗ conflict merging %s — skipped", branch)

    # Return to base branch
    _git(repo_path, "checkout", base_branch, check=False)

    logger.info(
        "[CONSOLIDATE] Done: %s — %d merged, %d conflicts",
        batch, len(result.merged), len(result.conflicts),
    )
    return result
