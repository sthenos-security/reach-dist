#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.
"""
Enzo Benchmark Runner.

Runs all fixtures through the patch engine, records results in enzo.db,
and prints a formatted matrix.

Usage:
    reachctl enzo benchmark [--model MODEL] [--provider PROVIDER]
    reachctl enzo benchmark --compare <run_id_1> <run_id_2>
"""
from __future__ import annotations

import ast as pyast
import logging
import sqlite3
import time
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import List, Optional

logger = logging.getLogger(__name__)

FIXTURES_DIR = Path(__file__).parent / "tests" / "fixtures"

# ── Fixture registry ──────────────────────────────────────────────────────────

@dataclass
class Fixture:
    fixture_id: str       # e.g. "python/cwe89_sqli"
    language: str
    fix_type: str         # "code_patch" | "secret_rotation" | "dependency_upgrade" | "malware"
    file_path: str        # relative to FIXTURES_DIR
    line_number: int
    cwe_id: Optional[str] = None
    rule_id: Optional[str] = None
    package_name: Optional[str] = None
    current_version: Optional[str] = None
    fix_version: Optional[str] = None
    secret_type: Optional[str] = None
    secret_value: Optional[str] = None
    guarddog_sig: Optional[str] = None
    max_lines_changed: int = 8
    patcher: str = "ai"   # "deterministic" | "ai"
    description: str = ""


FIXTURES: List[Fixture] = [
    # ── Deterministic: secrets ──────────────────────────────────────────
    Fixture("python/secret_api_key", "python", "secret_rotation",
            "python/secret_api_key.py", 9,
            secret_type="api_key",
            secret_value="sk-prod-a3f7c9d2e1b4f8a2c6d9e3b7f1a4c8d2e5f",
            patcher="deterministic", max_lines_changed=2),
    Fixture("python/secret_db_password", "python", "secret_rotation",
            "python/secret_db_password.py", 7,
            secret_type="db_password",
            secret_value="prod-db-p@ssw0rd-2026",
            patcher="deterministic", max_lines_changed=2),
    Fixture("go/secret_token", "go", "secret_rotation",
            "go/secret_token.go", 8,
            secret_type="token",
            secret_value="ghp_a3f7c9d2e1b4f8a2c6d9e3b7f1a4c8d2e5f",
            patcher="deterministic", max_lines_changed=2),
    Fixture("typescript/secret_jwt", "typescript", "secret_rotation",
            "typescript/secret_jwt.ts", 6,
            secret_type="jwt_secret",
            secret_value="my-super-secret-jwt-key-do-not-share",
            patcher="deterministic", max_lines_changed=2),

    # ── Deterministic: dependency upgrades ──────────────────────────────
    Fixture("python/dep_requests", "python", "dependency_upgrade",
            "python/requirements.txt", 2,
            package_name="requests", current_version="2.28.0", fix_version="2.32.3",
            patcher="deterministic", max_lines_changed=1),
    Fixture("typescript/dep_lodash", "typescript", "dependency_upgrade",
            "typescript/package.json", 6,
            package_name="lodash", current_version="4.17.20", fix_version="4.17.21",
            patcher="deterministic", max_lines_changed=1),
    Fixture("java/dep_commons", "java", "dependency_upgrade",
            "java/pom.xml", 0,
            package_name="commons-collections",
            current_version="3.2.1", fix_version="3.2.2",
            patcher="deterministic", max_lines_changed=1),

    # ── Deterministic: malware ───────────────────────────────────────────
    Fixture("malware/python_cryptominer", "python", "malware",
            "malware/cryptominer.py", 4,
            package_name="colourama", guarddog_sig="typosquatting:colorama",
            patcher="deterministic", max_lines_changed=4),
    Fixture("malware/js_exfil", "javascript", "malware",
            "malware/exfil.js", 4,
            package_name="telnets", guarddog_sig="exfiltration:network",
            patcher="deterministic", max_lines_changed=4),

    # ── AI: CWE-89 SQL Injection ─────────────────────────────────────────
    Fixture("python/cwe89_sqli", "python", "code_patch",
            "python/cwe89_sqli.py", 14,
            cwe_id="CWE-89", rule_id="cwe89_sqli",
            description="SQL injection via string concatenation"),
    Fixture("go/cwe89_sqli", "go", "code_patch",
            "go/cwe89_sqli.go", 14,
            cwe_id="CWE-89", rule_id="cwe89_sqli",
            description="SQL injection via string concatenation"),
    Fixture("java/cwe89_sqli", "java", "code_patch",
            "java/cwe89_sqli.java", 14,
            cwe_id="CWE-89", rule_id="cwe89_sqli",
            description="SQL injection via string concatenation"),
    Fixture("typescript/cwe89_sqli", "typescript", "code_patch",
            "typescript/cwe89_sqli.ts", 10,
            cwe_id="CWE-89", rule_id="cwe89_sqli",
            description="SQL injection via template literal"),

    # ── AI: CWE-78 Command Injection ─────────────────────────────────────
    Fixture("python/cwe78_cmdi", "python", "code_patch",
            "python/cwe78_cmdi.py", 10,
            cwe_id="CWE-78", rule_id="cwe78_cmdi",
            description="Command injection via shell=True"),
    Fixture("go/cwe78_cmdi", "go", "code_patch",
            "go/cwe78_cmdi.go", 12,
            cwe_id="CWE-78", rule_id="cwe78_cmdi",
            description="Command injection via shell command concat"),
    Fixture("typescript/cwe78_cmdi", "typescript", "code_patch",
            "typescript/cwe78_cmdi.ts", 9,
            cwe_id="CWE-78", rule_id="cwe78_cmdi",
            description="Command injection via exec with user input"),

    # ── AI: CWE-22 Path Traversal ─────────────────────────────────────────
    Fixture("python/cwe22_traversal", "python", "code_patch",
            "python/cwe22_traversal.py", 10,
            cwe_id="CWE-22", rule_id="cwe22_traversal",
            description="Path traversal via unsanitized file path"),
    Fixture("go/cwe22_traversal", "go", "code_patch",
            "go/cwe22_traversal.go", 13,
            cwe_id="CWE-22", rule_id="cwe22_traversal",
            description="Path traversal via string concatenation"),

    # ── AI: CWE-326 Weak Crypto ───────────────────────────────────────────
    Fixture("python/cwe326_crypto", "python", "code_patch",
            "python/cwe326_weak_crypto.py", 8,
            cwe_id="CWE-326", rule_id="cwe326_weak_crypto",
            description="MD5 used for password hashing"),
    Fixture("java/cwe326_crypto", "java", "code_patch",
            "java/cwe326_weak_crypto.java", 12,
            cwe_id="CWE-326", rule_id="cwe326_weak_crypto",
            description="MD5 used for password hashing"),

    # ── AI: CWE-79 XSS ───────────────────────────────────────────────────
    Fixture("typescript/cwe79_xss", "typescript", "code_patch",
            "typescript/cwe79_xss.ts", 10,
            cwe_id="CWE-79", rule_id="cwe79_xss",
            description="XSS via unsanitized user input"),
]


# ── DB schema ─────────────────────────────────────────────────────────────────

SCHEMA = """
CREATE TABLE IF NOT EXISTS benchmark_runs (
    run_id              TEXT PRIMARY KEY,
    timestamp           TEXT NOT NULL,
    enzo_version        TEXT,
    model               TEXT,
    provider            TEXT,
    fixture_count       INTEGER,
    pass_count          INTEGER,
    fail_count          INTEGER,
    hallucination_total INTEGER DEFAULT 0,
    candidate_total     INTEGER DEFAULT 0,
    avg_attempts        REAL,
    avg_tokens          REAL,
    total_cost_usd      REAL DEFAULT 0.0,
    total_duration_ms   INTEGER
);

CREATE TABLE IF NOT EXISTS benchmark_results (
    id                      INTEGER PRIMARY KEY AUTOINCREMENT,
    run_id                  TEXT REFERENCES benchmark_runs(run_id),
    fixture_id              TEXT NOT NULL,
    language                TEXT,
    cwe_id                  TEXT,
    fix_type                TEXT,
    patcher                 TEXT,
    success                 INTEGER NOT NULL,
    attempt                 INTEGER,
    hallucination_count     INTEGER DEFAULT 0,
    semgrep_verified        INTEGER,
    new_findings_introduced INTEGER DEFAULT 0,
    ast_valid               INTEGER DEFAULT 1,
    lines_changed           INTEGER DEFAULT 0,
    tokens_in               INTEGER DEFAULT 0,
    tokens_out              INTEGER DEFAULT 0,
    cost_usd                REAL DEFAULT 0.0,
    duration_ms             INTEGER,
    error                   TEXT
);
"""


@dataclass
class BenchmarkResult:
    fixture: Fixture
    success: bool
    attempt: int = 1
    hallucination_count: int = 0
    ast_valid: bool = True
    lines_changed: int = 0
    tokens_in: int = 0
    tokens_out: int = 0
    cost_usd: float = 0.0
    duration_ms: int = 0
    error: str = ""
    patcher_method: str = "ai"


# ── Runner ────────────────────────────────────────────────────────────────────

class BenchmarkRunner:

    def __init__(self, model: str, provider: str, db_path: str,
                 api_key: str = "", only_deterministic: bool = False):
        self.model = model
        self.provider = provider
        self.db_path = db_path
        self.api_key = api_key
        self.only_deterministic = only_deterministic
        self._ensure_schema()

    def _ensure_schema(self):
        con = sqlite3.connect(self.db_path)
        con.executescript(SCHEMA)
        con.commit()
        con.close()

    def run(self, fixtures: List[Fixture] = None) -> List[BenchmarkResult]:
        if fixtures is None:
            fixtures = FIXTURES
        if self.only_deterministic:
            fixtures = [f for f in fixtures if f.patcher == "deterministic"]

        run_id = f"bm_{datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S')}"
        results: List[BenchmarkResult] = []

        for fx in fixtures:
            br = self._run_one(fx)
            results.append(br)
            self._print_result(br)

        self._write_db(run_id, results)
        self._print_summary(run_id, results)
        return results

    def _run_one(self, fx: Fixture) -> BenchmarkResult:
        t0 = time.monotonic()
        try:
            if fx.patcher == "deterministic":
                return self._run_deterministic(fx, t0)
            else:
                return self._run_ai(fx, t0)
        except Exception as e:
            return BenchmarkResult(
                fixture=fx, success=False, error=str(e),
                duration_ms=int((time.monotonic() - t0) * 1000),
            )

    def _run_deterministic(self, fx: Fixture, t0: float) -> BenchmarkResult:
        from enzo.patcher.deterministic import try_deterministic
        content = (FIXTURES_DIR / fx.file_path).read_text()
        meta = {
            "secret_type":      fx.secret_type or "",
            "secret_value":     fx.secret_value or "",
            "package_name":     fx.package_name or "",
            "current_version":  fx.current_version or "",
            "fix_version":      fx.fix_version or "",
            "guarddog_sig":     fx.guarddog_sig or "",
        }
        r = try_deterministic(
            fix_type=fx.fix_type,
            file_path=fx.file_path,
            file_content=content,
            line_number=fx.line_number,
            finding_metadata=meta,
        )
        ast_valid = True
        lines_changed = 0
        if r.success and r.patched_content:
            if fx.language == "python":
                try:
                    pyast.parse(r.patched_content)
                except SyntaxError:
                    ast_valid = False
            orig_lines = set(content.splitlines())
            new_lines = set(r.patched_content.splitlines())
            lines_changed = len(orig_lines.symmetric_difference(new_lines))

        return BenchmarkResult(
            fixture=fx, success=r.success, attempt=1,
            ast_valid=ast_valid, lines_changed=lines_changed,
            duration_ms=int((time.monotonic() - t0) * 1000),
            error=r.error, patcher_method="deterministic",
        )

    def _run_ai(self, fx: Fixture, t0: float) -> BenchmarkResult:
        from enzo.config import EnzoConfig
        from enzo.models import EnzoFinding, FixType, RemediationContext
        from enzo.patcher.engine import PatchEngine

        cfg = EnzoConfig()
        cfg.provider = self.provider
        cfg.cloud_enabled = True
        cfg.groq_api_key = self.api_key
        cfg.groq_model = self.model
        cfg.groq_endpoint = "https://api.groq.com/openai"
        cfg.max_attempts = 2
        cfg.candidates_per_attempt = 3

        ft_map = {
            "code_patch": FixType.CODE_PATCH,
            "secret_rotation": FixType.SECRET_ROTATION,
            "dependency_upgrade": FixType.DEPENDENCY_UPGRADE,
            "malware": FixType.MALWARE,
        }
        finding = EnzoFinding(
            finding_id=f"bm_{fx.fixture_id.replace('/', '_')}",
            finding_type=fx.fix_type,
            severity="CRITICAL",
            fix_type=ft_map[fx.fix_type],
            language=fx.language,
            file_path=str(FIXTURES_DIR / fx.file_path),
            line_number=fx.line_number,
            cwe_id=fx.cwe_id,
            rule_id=fx.rule_id or (fx.cwe_id or "").lower().replace("-", "_"),
            description=fx.description,
            title=f"Benchmark: {fx.fixture_id}",
        )
        ctx = RemediationContext(
            finding_type=fx.fix_type,
            severity="CRITICAL",
            cwe_id=fx.cwe_id,
            language=fx.language,
            fix_type=fx.fix_type,
            rule_id=fx.rule_id,
        )

        engine = PatchEngine(cfg)
        repo_path = str(FIXTURES_DIR.parent.parent)

        result = engine.generate_patch(finding, ctx, repo_path, attempt_number=1)
        attempt = 1
        if not result.success:
            result = engine.generate_patch(finding, ctx, repo_path,
                                           attempt_number=2, prior_error=result.error)
            attempt = 2

        ast_valid = True
        lines_changed = 0
        if result.success and result.patched_content:
            if fx.language == "python":
                try:
                    pyast.parse(result.patched_content)
                except SyntaxError:
                    ast_valid = False
            orig = (FIXTURES_DIR / fx.file_path).read_text()
            orig_set = set(orig.splitlines())
            new_set = set(result.patched_content.splitlines())
            lines_changed = len(orig_set.symmetric_difference(new_set))

        return BenchmarkResult(
            fixture=fx, success=result.success, attempt=attempt,
            ast_valid=ast_valid, lines_changed=lines_changed,
            tokens_in=getattr(result, 'tokens_in', 0) or 0,
            tokens_out=getattr(result, 'tokens_out', 0) or 0,
            cost_usd=getattr(result, 'cost_usd', 0.0) or 0.0,
            duration_ms=int((time.monotonic() - t0) * 1000),
            error=result.error or "",
            patcher_method=result.model_used or "ai",
        )

    def _print_result(self, br: BenchmarkResult):
        fx = br.fixture
        status = "✓" if br.success else "✗"
        method = "det" if br.patcher_method == "deterministic" else f"AI·a{br.attempt}"
        tokens = f"{br.tokens_in}tok" if br.tokens_in else "0tok"
        dur = f"{br.duration_ms}ms" if br.duration_ms < 1000 else f"{br.duration_ms/1000:.1f}s"
        hall = f"  ⚠{br.hallucination_count}hall" if br.hallucination_count else ""
        print(f"  {status} {fx.fixture_id:<35} {method:<8} {tokens:<8} {dur:<6}{hall}")
        if not br.success:
            print(f"    ✗ {br.error[:80]}")

    def _print_summary(self, run_id: str, results: List[BenchmarkResult]):
        passed = sum(1 for r in results if r.success)
        failed = len(results) - passed
        det = [r for r in results if r.patcher_method == "deterministic"]
        ai = [r for r in results if r.patcher_method != "deterministic"]
        hall_total = sum(r.hallucination_count for r in results)
        total_tokens = sum(r.tokens_in for r in results)
        total_cost = sum(r.cost_usd for r in results)
        total_dur = sum(r.duration_ms for r in results)
        avg_attempt = (sum(r.attempt for r in ai) / len(ai)) if ai else 0

        W = 61
        print(f"\n  {'━'*W}")
        print("  SUMMARY")
        print(f"  {'━'*W}")
        print(f"  Total fixtures:   {len(results)}")
        print(f"  Pass rate:        {passed}/{len(results)}  ({100*passed//len(results)}%)")
        if failed:
            print(f"  Failed:           {failed}")
        if hall_total:
            cands = len(ai) * 3
            print(f"  Hallucinations:   {hall_total}/{cands}  ({100*hall_total//cands if cands else 0}% of candidates, all caught+retried)")
        else:
            print("  Hallucinations:   0  (0%)")
        if ai:
            print(f"  Avg attempts(AI): {avg_attempt:.1f}")
            print(f"  Avg tokens/fix:   {total_tokens//len(ai) if ai else 0}")
        print(f"  Total cost (AI):  ${total_cost:.4f}")
        print(f"  Total time:       {total_dur/1000:.1f}s")
        print()
        if det:
            det_passed = sum(1 for r in det if r.success)
            print(f"  Deterministic:    {det_passed}/{len(det)} fixes · $0.00 · {sum(r.duration_ms for r in det)/1000:.1f}s")
        if ai:
            ai_passed = sum(1 for r in ai if r.success)
            print(f"  AI:               {ai_passed}/{len(ai)} fixes · ${total_cost:.4f} · {sum(r.duration_ms for r in ai)/1000:.1f}s")
        print(f"  {'━'*W}")
        print(f"  Run ID: {run_id}  (saved to enzo.db)")
        print(f"  {'━'*W}\n")

    def _write_db(self, run_id: str, results: List[BenchmarkResult]):
        from enzo import __version__
        passed = sum(1 for r in results if r.success)
        ai_r = [r for r in results if r.patcher_method != "deterministic"]
        con = sqlite3.connect(self.db_path)
        con.execute("""
            INSERT INTO benchmark_runs VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)
        """, (
            run_id,
            datetime.now(timezone.utc).isoformat(),
            __version__,
            self.model, self.provider,
            len(results), passed, len(results) - passed,
            sum(r.hallucination_count for r in results),
            len(ai_r) * 3,
            sum(r.attempt for r in ai_r) / len(ai_r) if ai_r else 0,
            sum(r.tokens_in for r in ai_r) / len(ai_r) if ai_r else 0,
            sum(r.cost_usd for r in results),
            sum(r.duration_ms for r in results),
        ))
        for r in results:
            con.execute("""
                INSERT INTO benchmark_results
                (run_id,fixture_id,language,cwe_id,fix_type,patcher,
                 success,attempt,hallucination_count,ast_valid,lines_changed,
                 tokens_in,tokens_out,cost_usd,duration_ms,error)
                VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
            """, (
                run_id, r.fixture.fixture_id, r.fixture.language,
                r.fixture.cwe_id, r.fixture.fix_type, r.patcher_method,
                int(r.success), r.attempt, r.hallucination_count,
                int(r.ast_valid), r.lines_changed,
                r.tokens_in, r.tokens_out, r.cost_usd, r.duration_ms,
                r.error or None,
            ))
        con.commit()
        con.close()
