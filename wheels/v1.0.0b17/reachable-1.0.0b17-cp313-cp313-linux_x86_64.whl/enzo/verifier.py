#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.
"""
Targeted post-patch verifier.

Runs the minimum verification needed per fix type using tools
already installed by reachable. No new config, no new DB downloads,
no full rescan.

Verification matrix:
  secret_rotation    → SKIP  (deterministic, self-verifying)
  malware (det.)     → SKIP  (deterministic, self-verifying)
  dependency_upgrade → grype  <pkg>@<fix_ver>  --use-cache
  cwe_code_patch     → semgrep --config <rule_id> <file>
  config_change      → semgrep --config <rule_id> <file>
  malware (AI)       → semgrep --config semgrep-rules-malware.yaml <file>

All tools are resolved from ~/.reachable/venv/bin/ first, then PATH.
Cached DBs are reused — no network calls.

Debug log prefix: [VERIFY]
"""
from __future__ import annotations

import json
import logging
import subprocess
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

logger = logging.getLogger(__name__)

# ── Tool resolution ───────────────────────────────────────────────────────────

_TOOL_CACHE: dict[str, Optional[str]] = {}

def _resolve_tool(name: str) -> Optional[str]:
    """Find tool in reachable venv first, then PATH."""
    if name in _TOOL_CACHE:
        return _TOOL_CACHE[name]
    candidates = [
        str(Path.home() / ".reachable" / "venv" / "bin" / name),
        str(Path.home() / ".local" / "bin" / name),
        name,  # PATH fallback
    ]
    for c in candidates:
        subprocess.run(["which" if c == name else "test", "-x", c] if c != name
                          else ["which", name],
                          capture_output=True)
        if c != name:
            result = subprocess.run(["test", "-x", c], capture_output=True)
            if result.returncode == 0:
                _TOOL_CACHE[name] = c
                return c
        else:
            result = subprocess.run(["which", name], capture_output=True, text=True)
            if result.returncode == 0:
                found = result.stdout.strip()
                _TOOL_CACHE[name] = found
                return found
    _TOOL_CACHE[name] = None
    return None


def _semgrep_rules_dir() -> Optional[str]:
    """Find reachable's semgrep rules directory."""
    candidates = [
        Path.home() / ".reachable" / "rules",
        Path.home() / ".reachable" / "semgrep-rules",
        Path(__file__).parent.parent / "reachable" / "scanners" / "rules",
    ]
    for c in candidates:
        if c.exists():
            return str(c)
    return None


# ── Result ────────────────────────────────────────────────────────────────────

@dataclass
class VerifyResult:
    finding_id: str
    fix_type: str
    verified: bool
    method: str = ""      # "skipped_deterministic" | "semgrep" | "grype" | "skipped_no_tool"
    detail: str = ""
    error: str = ""

    def log(self) -> None:
        if self.method == "skipped_deterministic":
            logger.debug("[VERIFY] ⊘ %s — deterministic fix, self-verifying", self.finding_id)
        elif self.verified:
            logger.debug("[VERIFY] ✓ %s — %s confirmed fix", self.finding_id, self.method)
        else:
            logger.warning("[VERIFY] ✗ %s — %s finding still present: %s",
                           self.finding_id, self.method, self.detail or self.error)


# ── Entry point ───────────────────────────────────────────────────────────────

def verify_fix(
    finding_id: str,
    fix_type: str,
    method: str,           # "deterministic" or "ai"
    file_path: str,        # absolute path in the consolidated branch checkout
    rule_id: Optional[str] = None,
    package_name: Optional[str] = None,
    fix_version: Optional[str] = None,
    repo_path: Optional[str] = None,
) -> VerifyResult:
    """
    Verify a single fix. Called against the consolidated branch checkout.

    Returns VerifyResult with verified=True if the fix is confirmed.
    """
    ft = fix_type.lower()

    # ── Deterministic fixes are self-verifying ────────────────────────────────
    if method == "deterministic":
        r = VerifyResult(
            finding_id=finding_id, fix_type=ft,
            verified=True, method="skipped_deterministic",
            detail="deterministic transform — correctness guaranteed by construction",
        )
        r.log()
        return r

    # ── dep/CVE → grype ───────────────────────────────────────────────────────
    if ft == "dependency_upgrade" and package_name and fix_version:
        return _verify_grype(finding_id, ft, package_name, fix_version, repo_path or "")

    # ── CWE/malware/config → semgrep ─────────────────────────────────────────
    if ft in ("code_patch", "config_change", "malware", "suspicious") and file_path:
        return _verify_semgrep(finding_id, ft, file_path, rule_id, repo_path or "")

    # ── No applicable verifier ────────────────────────────────────────────────
    r = VerifyResult(
        finding_id=finding_id, fix_type=ft,
        verified=True, method="skipped_no_verifier",
        detail=f"no targeted verifier for {ft}",
    )
    r.log()
    return r


# ── Semgrep verifier ──────────────────────────────────────────────────────────

def _verify_semgrep(
    finding_id: str, fix_type: str,
    file_path: str, rule_id: Optional[str], repo_path: str,
) -> VerifyResult:
    semgrep = _resolve_tool("semgrep")
    if not semgrep:
        logger.debug("[VERIFY] semgrep not found — skipping verification for %s", finding_id)
        return VerifyResult(finding_id=finding_id, fix_type=fix_type,
                            verified=True, method="skipped_no_tool",
                            detail="semgrep not available in reachable venv")

    # Determine config: specific rule or malware rules file
    config = None
    if rule_id:
        # Try to find the rule file in reachable's rules dir
        rules_dir = _semgrep_rules_dir()
        if rules_dir:
            rule_file = Path(rules_dir) / f"{rule_id}.yaml"
            if rule_file.exists():
                config = str(rule_file)
        if not config:
            config = rule_id  # use as registry ID
    elif fix_type in ("malware", "suspicious"):
        # Use reachable's malware rules
        candidates = [
            Path(__file__).parent.parent / "reachable" / "scanners" / "semgrep-rules-malware.yaml",
            Path.home() / ".reachable" / "semgrep-rules-malware.yaml",
        ]
        for c in candidates:
            if c.exists():
                config = str(c)
                break

    if not config:
        logger.debug("[VERIFY] no semgrep config for rule_id=%s fix_type=%s", rule_id, fix_type)
        return VerifyResult(finding_id=finding_id, fix_type=fix_type,
                            verified=True, method="skipped_no_rule",
                            detail=f"no semgrep rule found for {rule_id or fix_type}")

    if not Path(file_path).exists():
        return VerifyResult(finding_id=finding_id, fix_type=fix_type,
                            verified=False, method="semgrep",
                            error=f"file not found: {file_path}")

    logger.debug("[VERIFY] semgrep --config %s %s", config, file_path)
    try:
        r = subprocess.run(
            [semgrep, "--config", config, "--json", "--quiet", file_path],
            capture_output=True, text=True, timeout=60,
            cwd=repo_path or None,
        )
        output = json.loads(r.stdout) if r.stdout.strip() else {"results": []}
        findings = output.get("results", [])
        still_present = [
            f for f in findings
            if f.get("check_id", "").endswith(rule_id or "") or not rule_id
        ]
        if still_present:
            return VerifyResult(
                finding_id=finding_id, fix_type=fix_type,
                verified=False, method="semgrep",
                detail=f"rule still matches: {still_present[0].get('check_id', '')} "
                       f"at line {still_present[0].get('start', {}).get('line', '?')}",
            )
        result = VerifyResult(finding_id=finding_id, fix_type=fix_type,
                              verified=True, method="semgrep",
                              detail=f"rule {rule_id or config} no longer matches")
        result.log()
        return result

    except subprocess.TimeoutExpired:
        return VerifyResult(finding_id=finding_id, fix_type=fix_type,
                            verified=True, method="semgrep",
                            detail="semgrep timed out — treated as passed")
    except Exception as e:
        return VerifyResult(finding_id=finding_id, fix_type=fix_type,
                            verified=True, method="semgrep",
                            error=f"semgrep error: {e} — treated as passed")


# ── Grype verifier ────────────────────────────────────────────────────────────

def _verify_grype(
    finding_id: str, fix_type: str,
    package_name: str, fix_version: str, repo_path: str,
) -> VerifyResult:
    grype = _resolve_tool("grype")
    if not grype:
        logger.debug("[VERIFY] grype not found — skipping for %s", finding_id)
        return VerifyResult(finding_id=finding_id, fix_type=fix_type,
                            verified=True, method="skipped_no_tool",
                            detail="grype not available in reachable venv")

    logger.debug("[VERIFY] grype %s@%s --only-fixed", package_name, fix_version)
    try:
        r = subprocess.run(
            [grype, f"{package_name}@{fix_version}", "--output", "json",
             "--only-fixed", "--quiet"],
            capture_output=True, text=True, timeout=30,
            env={**__import__("os").environ, "GRYPE_DB_UPDATE_URL": ""},  # no DB update
        )
        output = json.loads(r.stdout) if r.stdout.strip() else {"matches": []}
        matches = output.get("matches", [])
        if matches:
            cves = [m.get("vulnerability", {}).get("id", "?") for m in matches[:3]]
            return VerifyResult(
                finding_id=finding_id, fix_type=fix_type,
                verified=False, method="grype",
                detail=f"{package_name}@{fix_version} still has CVEs: {', '.join(cves)}",
            )
        result = VerifyResult(finding_id=finding_id, fix_type=fix_type,
                              verified=True, method="grype",
                              detail=f"{package_name}@{fix_version} — no CVEs in cached DB")
        result.log()
        return result

    except subprocess.TimeoutExpired:
        return VerifyResult(finding_id=finding_id, fix_type=fix_type,
                            verified=True, method="grype",
                            detail="grype timed out — treated as passed")
    except Exception as e:
        return VerifyResult(finding_id=finding_id, fix_type=fix_type,
                            verified=True, method="grype",
                            error=f"grype error: {e} — treated as passed")
