#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.
"""Git operations — branch, apply diff, commit, push."""

from __future__ import annotations

import logging
import os
import subprocess
import tempfile
from typing import Optional

logger = logging.getLogger(__name__)


def _git(repo_path: str, *args, check: bool = True) -> subprocess.CompletedProcess:
    return subprocess.run(
        ["git", *args], cwd=repo_path, capture_output=True,
        text=True, check=check, timeout=60,
    )


def get_current_branch(repo_path: str) -> str:
    return _git(repo_path, "rev-parse", "--abbrev-ref", "HEAD").stdout.strip()


def get_current_commit(repo_path: str) -> str:
    return _git(repo_path, "rev-parse", "HEAD").stdout.strip()


def has_uncommitted_changes(repo_path: str) -> bool:
    return bool(_git(repo_path, "status", "--porcelain", check=False).stdout.strip())


def create_branch(repo_path: str, branch_name: str) -> bool:
    try:
        _git(repo_path, "checkout", "-b", branch_name)
        return True
    except subprocess.CalledProcessError as exc:
        logger.error("Branch create failed: %s", exc.stderr)
        return False


def apply_diff(repo_path: str, diff: str) -> tuple[bool, str]:
    """Apply a unified diff.  Returns (success, error_message).

    Tries three strategies in order:
      1. git apply --ignore-whitespace
      2. git apply --ignore-whitespace --recount
      3. patch -p1 -F3 (fuzz tolerance)
    """
    with tempfile.NamedTemporaryFile(mode="w", suffix=".patch", delete=False) as f:
        f.write(diff)
        patch_path = f.name
    try:
        # 1. Standard with whitespace tolerance
        result = _git(repo_path, "apply", "--ignore-whitespace", patch_path, check=False)
        if result.returncode == 0:
            return True, ""

        # 2. Recount @@ line numbers
        result = _git(repo_path, "apply", "--ignore-whitespace", "--recount", patch_path, check=False)
        if result.returncode == 0:
            return True, ""

        # 3. GNU patch with fuzz
        patch_result = subprocess.run(
            ["patch", "-p1", "--no-backup-if-mismatch", "-F3", "-i", patch_path],
            cwd=repo_path, capture_output=True, text=True, timeout=30,
        )
        if patch_result.returncode == 0:
            return True, ""

        err = result.stderr.strip() or patch_result.stderr.strip() or "Diff does not apply"
        return False, err
    except subprocess.CalledProcessError as exc:
        return False, exc.stderr or str(exc)
    finally:
        os.unlink(patch_path)


def commit_changes(repo_path: str, message: str, sign: bool = False) -> Optional[str]:
    try:
        _git(repo_path, "add", "-A")
        cmd = ["commit", "-m", message]
        if sign:
            cmd.append("-S")
        _git(repo_path, *cmd)
        return get_current_commit(repo_path)
    except subprocess.CalledProcessError as exc:
        logger.error("Commit failed: %s", exc.stderr)
        return None


def push_branch(repo_path: str, branch_name: str, remote: str = "origin") -> tuple[bool, str]:
    try:
        _git(repo_path, "push", remote, branch_name)
        return True, ""
    except subprocess.CalledProcessError as exc:
        return False, exc.stderr or str(exc)


def restore_branch(repo_path: str, original_branch: str):
    try:
        _git(repo_path, "checkout", original_branch, check=False)
    except Exception as exc:
        logger.debug("Could not restore branch %s: %s", original_branch, exc)


def generate_branch_name(prefix: str, finding_id: str) -> str:
    short = finding_id[:12] if len(finding_id) > 12 else finding_id
    return f"{prefix}/{short}"


def generate_commit_message(finding) -> str:
    ftype = finding.finding_type
    sev = finding.severity
    title = finding.title or finding.cve_id or finding.cwe_id or finding.finding_id[:12]
    msgs = {
        "cve":    f"fix(security): remediate {title} [{sev}]",
        "cwe":    f"fix(security): patch {title} [{sev}]",
        "secret": f"fix(security): rotate hardcoded {finding.secret_type or 'secret'}",
        "config": f"fix(security): harden configuration [{sev}]",
    }
    header = msgs.get(ftype, f"fix(security): remediate {finding.finding_id[:12]} [{sev}]")
    return f"{header}\n\nAuto-remediated by Enzo AI"
