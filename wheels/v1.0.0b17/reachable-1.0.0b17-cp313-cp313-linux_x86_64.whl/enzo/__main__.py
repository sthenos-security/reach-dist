#!/usr/bin/env python3
"""python -m enzo entry point."""

from .cli import main

main()
