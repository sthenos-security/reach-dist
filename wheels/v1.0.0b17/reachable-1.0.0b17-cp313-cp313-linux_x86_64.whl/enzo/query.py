#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.
"""
Enzo query layer — reads from repo.db (NEVER writes).

Uses RepoDatabase from reachable.database.storage for finding queries.
Falls back to raw SQLite if RepoDatabase isn't importable (testing).
"""

from __future__ import annotations

import gzip
import json
import logging
import sqlite3
from pathlib import Path
from typing import Any, Dict, List, Optional

from .models import EnzoFinding

logger = logging.getLogger(__name__)

# ── Optional imports from reachable (graceful fallback) ──────────────
try:
    from reachable.database.storage import get_repo_db_path as _get_repo_db_path
    _HAS_STORAGE = True
except ImportError:
    _HAS_STORAGE = False
    _get_repo_db_path = None


def get_repo_db_path(repo_path: str) -> Path:
    """Locate repo.db for a repository, with fallback heuristics."""
    if _HAS_STORAGE and _get_repo_db_path is not None:
        return _get_repo_db_path(repo_path)

    # Fallback: replicate the path logic from storage.py
    import hashlib
    repo_abs = str(Path(repo_path).resolve())
    slug = Path(repo_abs).name
    h = hashlib.sha256(repo_abs.encode()).hexdigest()[:12]
    return Path.home() / ".reachable" / "scans" / f"{slug}-{h}" / "repo.db"


class RepoReader:
    """
    Read-only access to repo.db.

    Opens its own SQLite connection (not RepoDatabase) so we never
    risk accidentally calling a write method.
    """

    def __init__(self, repo_db_path: Path):
        self.db_path = Path(repo_db_path)
        if not self.db_path.exists():
            raise FileNotFoundError(f"repo.db not found: {self.db_path}")
        self.conn = sqlite3.connect(f"file:{self.db_path}?mode=ro", uri=True)
        self.conn.row_factory = sqlite3.Row

    # ── Scans ─────────────────────────────────────────────────────────

    def get_latest_scan_id(self, branch: Optional[str] = None) -> Optional[int]:
        """Get most recent completed scan ID."""
        q = "SELECT id FROM scans WHERE status = 'complete'"
        params: list = []
        if branch:
            q += " AND branch = ?"
            params.append(branch)
        q += " ORDER BY timestamp DESC LIMIT 1"
        row = self.conn.execute(q, params).fetchone()
        return row["id"] if row else None

    def get_scan_info(self, scan_id: int) -> Optional[Dict[str, Any]]:
        row = self.conn.execute("SELECT * FROM scans WHERE id = ?", (scan_id,)).fetchone()
        return dict(row) if row else None

    # ── Findings ──────────────────────────────────────────────────────

    def get_findings(
        self,
        scan_id: int,
        finding_type: Optional[str] = None,
        severity: Optional[str] = None,
        reachable_only: bool = False,
        fix_available_only: bool = False,
    ) -> List[EnzoFinding]:
        """
        Query findings from repo.db and wrap as EnzoFinding objects.
        """
        q = "SELECT * FROM findings WHERE scan_id = ?"
        params: List[Any] = [scan_id]

        if finding_type:
            q += " AND finding_type = ?"
            params.append(finding_type)

        if reachable_only:
            q += " AND app_reachability = 'REACHABLE'"

        if fix_available_only:
            q += " AND fix_status = 'fix_available'"

        rows = self.conn.execute(q, params).fetchall()
        findings = []
        for row in rows:
            ef = EnzoFinding.from_db_row(dict(row))
            # Severity filter (post-query for flexibility)
            if severity:
                _ORDER = {"CRITICAL": 4, "HIGH": 3, "MEDIUM": 2, "LOW": 1, "INFO": 0}
                if _ORDER.get(ef.severity, 0) < _ORDER.get(severity, 3):
                    continue
            findings.append(ef)
        return findings

    def get_finding_by_id(self, scan_id: int, finding_id: str) -> Optional[EnzoFinding]:
        """Get a specific finding by its fingerprint."""
        row = self.conn.execute(
            "SELECT * FROM findings WHERE scan_id = ? AND finding_id = ?",
            (scan_id, finding_id),
        ).fetchone()
        return EnzoFinding.from_db_row(dict(row)) if row else None

    def get_findings_count(self, scan_id: int) -> Dict[str, int]:
        """Summary counts by type."""
        rows = self.conn.execute(
            "SELECT finding_type, COUNT(*) as cnt FROM findings WHERE scan_id = ? GROUP BY finding_type",
            (scan_id,),
        ).fetchall()
        return {row["finding_type"]: row["cnt"] for row in rows}

    # ── Call Graph ────────────────────────────────────────────────────

    def get_call_graph(self, commit_hash: Optional[str] = None) -> Optional[Dict]:
        """
        Load cached call graph data.  Returns decompressed JSON or None.
        """
        q = "SELECT graph_data, function_count, edge_count FROM call_graph_cache"
        params: list = []
        if commit_hash:
            q += " WHERE commit_hash = ?"
            params.append(commit_hash)
        q += " ORDER BY created_at DESC LIMIT 1"

        row = self.conn.execute(q, params).fetchone()
        if not row or not row["graph_data"]:
            return None

        try:
            raw = gzip.decompress(row["graph_data"])
            data = json.loads(raw)
            data["_meta"] = {
                "function_count": row["function_count"],
                "edge_count": row["edge_count"],
            }
            return data
        except Exception as exc:
            logger.warning("Failed to decompress call graph: %s", exc)
            return None

    # ── SBOM ──────────────────────────────────────────────────────────

    def get_sbom(self, commit_hash: Optional[str] = None) -> Optional[Dict]:
        """Load cached SBOM.  Returns decompressed JSON or None."""
        q = "SELECT sbom_data, package_count FROM sbom_cache"
        params: list = []
        if commit_hash:
            q += " WHERE commit_hash = ?"
            params.append(commit_hash)
        q += " ORDER BY created_at DESC LIMIT 1"

        row = self.conn.execute(q, params).fetchone()
        if not row or not row["sbom_data"]:
            return None

        try:
            raw = gzip.decompress(row["sbom_data"])
            return json.loads(raw)
        except Exception as exc:
            logger.warning("Failed to decompress SBOM: %s", exc)
            return None

    # ── Correlation Data ──────────────────────────────────────────────

    def get_correlation_data(self, scan_id: int) -> Optional[Dict]:
        """Load correlation report from large_objects."""
        row = self.conn.execute(
            "SELECT data, compression FROM large_objects WHERE scan_id = ? AND object_type = 'correlation'",
            (scan_id,),
        ).fetchone()
        if not row or not row["data"]:
            return None
        try:
            raw = row["data"]
            if row["compression"] == "gzip":
                raw = gzip.decompress(raw)
            return json.loads(raw)
        except Exception as exc:
            logger.warning("Failed to load correlation data: %s", exc)
            return None

    # ── Dependency chain from SBOM ────────────────────────────────────

    def get_dependency_chain(self, package_name: str, commit_hash: Optional[str] = None) -> List[str]:
        """
        Extract dependency chain for a package from SBOM.
        Returns list of "name@version" strings.
        """
        sbom = self.get_sbom(commit_hash)
        if not sbom:
            return []

        # CycloneDX format
        components = sbom.get("components", [])
        chain = []
        for comp in components:
            name = comp.get("name", "")
            version = comp.get("version", "")
            if name:
                chain.append(f"{name}@{version}" if version else name)
        return chain

    # ── Lifecycle ─────────────────────────────────────────────────────

    def close(self):
        if self.conn:
            self.conn.close()
            self.conn = None
