#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.
"""
Dependabot normalizer.

Accepts GitHub Security Alerts API JSON.  Two input shapes:

  1. REST API list:  list of alert objects
     GET /repos/{owner}/{repo}/dependabot/alerts
     https://docs.github.com/en/rest/dependabot/alerts

  2. Single alert:   one alert object (useful for webhook payloads)

Key fields extracted:
  alert.security_advisory.cve_id
  alert.security_advisory.severity
  alert.security_advisory.summary
  alert.security_advisory.description
  alert.security_vulnerability.package.name
  alert.security_vulnerability.package.ecosystem
  alert.security_vulnerability.vulnerable_version_range
  alert.security_vulnerability.first_patched_version.identifier
  alert.number  (used as tool_finding_id)
  alert.state   (open | dismissed | fixed | auto_dismissed)
"""
from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Any, Dict, List, Optional, Union

from .models import ExternalFinding, normalise_severity

logger = logging.getLogger(__name__)


def load(source: Union[str, Path, List[Dict], Dict]) -> List[ExternalFinding]:
    """
    Load Dependabot alerts from a file path, raw JSON string, or pre-parsed dict/list.

    Only alerts with state == "open" are returned by default
    (dismissed/fixed alerts are not actionable).
    """
    data = _parse_input(source)

    # Accept both list-of-alerts and single alert
    if isinstance(data, dict):
        alerts = [data]
    elif isinstance(data, list):
        alerts = data
    else:
        raise ValueError(f"Expected list or dict, got {type(data)}")

    findings: List[ExternalFinding] = []
    for alert in alerts:
        f = _normalise_alert(alert)
        if f is not None:
            findings.append(f)

    logger.info("dependabot: loaded %d actionable findings from %d alerts",
                len(findings), len(alerts))
    return findings


def _parse_input(source) -> Any:
    if isinstance(source, (str, Path)):
        # Try as file path first (only if it looks like one)
        p = Path(source)
        try:
            if p.exists():
                return json.loads(p.read_text())
        except (OSError, ValueError):
            pass
        # Treat as raw JSON string
        return json.loads(source)
    return source  # already parsed


def _normalise_alert(alert: Dict) -> Optional[ExternalFinding]:
    """Return ExternalFinding or None if alert should be skipped."""
    state = alert.get("state", "open")
    if state not in ("open",):
        # dismissed / fixed / auto_dismissed — not actionable
        return None

    advisory = alert.get("security_advisory") or {}
    vuln     = alert.get("security_vulnerability") or {}
    pkg      = vuln.get("package") or {}
    patched  = vuln.get("first_patched_version") or {}

    alert_number = str(alert.get("number", alert.get("id", "unknown")))

    cve_id  = advisory.get("cve_id") or advisory.get("ghsa_id") or ""
    cve_ids = [cve_id] if cve_id else []

    ghsa_id = advisory.get("ghsa_id") or ""
    if ghsa_id and ghsa_id not in cve_ids:
        cve_ids.append(ghsa_id)

    severity_raw = (advisory.get("severity") or
                    vuln.get("severity") or
                    alert.get("severity") or "medium")
    cvss = None
    cvss_block = advisory.get("cvss") or {}
    if isinstance(cvss_block, dict):
        cvss = cvss_block.get("score")

    severity = normalise_severity(severity_raw, cvss)

    package_name    = pkg.get("name") or pkg.get("package_name") or ""
    ecosystem_raw   = pkg.get("ecosystem") or ""
    fix_version     = patched.get("identifier") or patched.get("version") or ""
    installed_range = vuln.get("vulnerable_version_range") or ""

    # Installed version: Dependabot doesn't always give exact installed version
    # in the alert object, but some endpoints include it via auto_dismissed_at context.
    # Best-effort: extract from vulnerable_version_range if it's an equality constraint.
    package_version = _extract_installed_version(alert, installed_range)

    title       = advisory.get("summary") or f"Dependabot: {cve_id or package_name}"
    description = advisory.get("description") or ""

    cwes = advisory.get("cwes") or advisory.get("cwe") or []
    cwe_ids = []
    if isinstance(cwes, list):
        for c in cwes:
            if isinstance(c, dict):
                cid = c.get("cwe_id") or c.get("id") or ""
            else:
                cid = str(c)
            if cid:
                cwe_ids.append(cid if cid.startswith("CWE-") else f"CWE-{cid}")

    return ExternalFinding(
        tool="dependabot",
        tool_finding_id=f"dependabot-{alert_number}",
        finding_type="cve",
        severity=severity,
        title=title,
        description=description[:2000],
        package_name=package_name,
        package_version=package_version,
        cve_ids=cve_ids,
        fix_version=fix_version,
        ecosystem=_normalise_ecosystem(ecosystem_raw),
        cwe_ids=cwe_ids,
        raw=alert,
    )


def _extract_installed_version(alert: Dict, vuln_range: str) -> Optional[str]:
    """Best-effort extraction of installed version from alert data."""
    # Some alert formats include dependency object
    dep = alert.get("dependency") or {}
    if dep.get("scope"):
        # manifest_path available but not version
        pass
    # Try manifest path context
    manifest = dep.get("manifest_path") or ""  # noqa: F841

    # Range like "= 2.28.0" → "2.28.0"
    if vuln_range:
        import re
        m = re.match(r"^=\s*([\d.]+)", vuln_range.strip())
        if m:
            return m.group(1)

    return None


def _normalise_ecosystem(raw: str) -> Optional[str]:
    """Map Dependabot ecosystem names to OSV ecosystem names."""
    mapping = {
        "pip":      "PyPI",
        "npm":      "npm",
        "maven":    "Maven",
        "rubygems": "RubyGems",
        "nuget":    "NuGet",
        "cargo":    "crates.io",
        "go":       "Go",
        "composer": "Packagist",
        "pub":      "Pub",
        "hex":      "Hex",
        "actions":  "GitHub Actions",
    }
    return mapping.get(raw.lower(), raw) if raw else None
