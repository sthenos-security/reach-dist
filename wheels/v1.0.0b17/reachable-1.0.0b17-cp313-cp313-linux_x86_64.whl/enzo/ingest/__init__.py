#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.
"""
Enzo ingest package — unified entry point for all tool normalizers.

    from enzo.ingest import load_tool, ExternalFinding

    findings = load_tool("dependabot", "github-alerts.json")
    findings = load_tool("codeql",     "results.sarif")
    findings = load_tool("trivy",      "trivy.sarif")
    findings = load_tool("trivy",      "trivy.json",  fmt="json")
    findings = load_tool("osv",        "osv-results.json")
"""
from __future__ import annotations

from pathlib import Path
from typing import List, Union

from . import codeql as _codeql
from . import dependabot as _dependabot
from . import osv_scanner as _osv
from . import trivy as _trivy
from .models import ExternalFinding, normalise_severity

__all__ = ["load_tool", "ExternalFinding", "normalise_severity"]

_LOADERS = {
    "dependabot":  _dependabot.load,
    "codeql":      _codeql.load,
    "semgrep":     _codeql.load,   # SARIF-compatible
    "bandit":      _codeql.load,   # SARIF-compatible
    "trivy":       _trivy.load,
    "osv":         _osv.load,
    "osv-scanner": _osv.load,
}


def load_tool(
    tool: str,
    source: Union[str, Path, dict, list],
    **kwargs,
) -> List[ExternalFinding]:
    """Load findings from a third-party tool output file or pre-parsed data."""
    key = tool.lower().strip()
    loader = _LOADERS.get(key)
    if loader is None:
        raise ValueError(f"Unknown tool '{tool}'. Supported: {sorted(_LOADERS)}")
    return loader(source, **kwargs)
