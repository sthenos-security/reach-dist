#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.
"""
CodeQL SARIF 2.1.0 normalizer.

Accepts SARIF files produced by:
  - github/codeql-action (GitHub Actions)
  - CodeQL CLI (codeql database analyze --format=sarif-latest)

Key SARIF paths extracted:
  runs[].tool.driver.rules[]          → rule metadata, CWE tags, security-severity
  runs[].results[]                    → individual findings
  result.ruleId                       → matches rule.id
  result.locations[0].physicalLocation → file + line
  result.message.text                 → finding description
  result.properties["security-severity"] → CVSS score
  rule.properties["tags"]             → ["security", "external/cwe/cwe-089"]

Works for any SARIF 2.1.0 producer, not just CodeQL — Semgrep, Bandit,
Trivy SARIF, etc. will all parse correctly. CodeQL-specific fields
(kind, precision, problem.severity) are extracted when present.
"""
from __future__ import annotations

import json
import logging
import re
from pathlib import Path
from typing import Dict, List, Optional, Union

from .models import ExternalFinding, normalise_severity

logger = logging.getLogger(__name__)

# CWE tag patterns used by CodeQL and others
_CWE_TAG_RE = re.compile(r"(?:external/cwe/cwe-|cwe-)(\d+)", re.IGNORECASE)


def load(source: Union[str, Path, Dict]) -> List[ExternalFinding]:
    """Load findings from a SARIF 2.1.0 file or pre-parsed dict."""
    data = _parse_input(source)

    findings: List[ExternalFinding] = []
    for run in data.get("runs") or []:
        findings.extend(_process_run(run))

    logger.info("codeql/sarif: loaded %d findings", len(findings))
    return findings


def _parse_input(source) -> Dict:
    if isinstance(source, (str, Path)):
        p = Path(source)
        try:
            if p.exists():
                return json.loads(p.read_text())
        except (OSError, ValueError):
            pass
        return json.loads(source)
    return source


def _process_run(run: Dict) -> List[ExternalFinding]:
    """Process one SARIF run object."""
    # Build rule lookup: id → rule metadata
    driver = (run.get("tool") or {}).get("driver") or {}
    tool_name = driver.get("name") or "sarif"
    rules_list = driver.get("rules") or []
    rules: Dict[str, Dict] = {r["id"]: r for r in rules_list if r.get("id")}

    findings: List[ExternalFinding] = []
    for result in run.get("results") or []:
        f = _normalise_result(result, rules, tool_name)
        if f is not None:
            findings.append(f)
    return findings


def _normalise_result(
    result: Dict,
    rules: Dict[str, Dict],
    tool_name: str,
) -> Optional[ExternalFinding]:
    rule_id = result.get("ruleId") or result.get("rule", {}).get("id") or ""
    rule    = rules.get(rule_id) or {}

    # Message
    msg = result.get("message") or {}
    description = msg.get("text") or msg.get("markdown") or ""

    # Title: rule short description or rule name
    short_desc = (rule.get("shortDescription") or {}).get("text") or ""
    title = short_desc or rule.get("name") or rule_id or "SARIF finding"

    # Severity: prefer result-level, fall back to rule properties
    result_props = result.get("properties") or {}
    rule_props   = rule.get("properties") or {}

    cvss_str = (result_props.get("security-severity") or
                rule_props.get("security-severity") or "")
    cvss = float(cvss_str) if cvss_str else None

    level_raw = result.get("level") or rule_props.get("problem.severity") or ""
    level_map = {"error": "HIGH", "warning": "MEDIUM", "note": "LOW", "none": "INFO"}
    level_sev = level_map.get(level_raw.lower(), "") if level_raw else ""

    severity = normalise_severity(level_sev, cvss) if cvss else (level_sev or "MEDIUM")

    # CWE extraction from rule tags
    cwe_ids = _extract_cwe_ids(rule)

    # Determine finding type
    finding_type = "cwe" if cwe_ids else "config"
    tags = rule_props.get("tags") or []
    if any("security" in t.lower() for t in tags):
        finding_type = "cwe" if cwe_ids else "cwe"

    # Location
    file_path: Optional[str] = None
    line_number: Optional[int] = None
    locs = result.get("locations") or []
    if locs:
        phys = (locs[0].get("physicalLocation") or {})
        artifact = phys.get("artifactLocation") or {}
        region   = phys.get("region") or {}
        file_path   = artifact.get("uri")
        line_number = region.get("startLine")

    # Fingerprint (preserve for dedup)
    fingerprints = result.get("partialFingerprints") or {}
    fp_hash = fingerprints.get("primaryLocationLineHash") or ""
    tool_finding_id = fp_hash or f"{tool_name}-{rule_id}-{file_path}-{line_number}"

    return ExternalFinding(
        tool="codeql",
        tool_finding_id=tool_finding_id,
        finding_type=finding_type,
        severity=severity,
        title=title,
        description=description[:2000],
        file_path=file_path,
        line_number=line_number,
        rule_id=rule_id,
        cwe_ids=cwe_ids,
        raw=result,
    )


def _extract_cwe_ids(rule: Dict) -> List[str]:
    """Extract CWE IDs from rule tags or properties."""
    cwe_ids: List[str] = []
    props = rule.get("properties") or {}
    tags  = props.get("tags") or []

    for tag in tags:
        m = _CWE_TAG_RE.search(str(tag))
        if m:
            cwe_ids.append(f"CWE-{int(m.group(1))}")

    # Also check rule.id itself (some tools embed CWE in rule ID)
    rule_id = rule.get("id") or ""
    m = re.search(r"CWE[-_](\d+)", rule_id, re.IGNORECASE)
    if m:
        cid = f"CWE-{int(m.group(1))}"
        if cid not in cwe_ids:
            cwe_ids.append(cid)

    return cwe_ids
