#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.
"""
Trivy normalizer — supports both SARIF and native JSON output.

SARIF mode (trivy image --format sarif):
  Delegates to the generic SARIF parser in codeql.py, then re-tags
  tool as "trivy" and enriches with any Trivy-specific extensions.

Native JSON mode (trivy image --format json):
  Richer CVE data: installed version, fixed version, CVSS vectors,
  vulnerability IDs, package type, layer digest.
  Schema: Results[].Vulnerabilities[]  (containers / OS packages)
          Results[].Misconfigurations[] (IaC / config findings)

Auto-detection: if top-level key "Results" is present → native JSON.
                if top-level key "runs" is present → SARIF.
"""
from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Dict, List, Optional, Union

from . import codeql as _sarif
from .models import ExternalFinding, normalise_severity

logger = logging.getLogger(__name__)


def load(
    source: Union[str, Path, Dict],
    fmt: str = "auto",
) -> List[ExternalFinding]:
    """
    Load Trivy findings.

    fmt: "auto" (default) | "sarif" | "json"
    """
    data = _parse_input(source)

    if fmt == "sarif" or (fmt == "auto" and "runs" in data):
        findings = _sarif.load(data)
        # Re-tag as trivy
        for f in findings:
            f.tool = "trivy"
        logger.info("trivy/sarif: loaded %d findings", len(findings))
        return findings

    if fmt == "json" or (fmt == "auto" and "Results" in data):
        return _load_native(data)

    logger.warning("trivy: could not detect format, trying native JSON")
    return _load_native(data)


def _parse_input(source) -> Dict:
    if isinstance(source, (str, Path)):
        p = Path(source)
        try:
            if p.exists():
                return json.loads(p.read_text())
        except (OSError, ValueError):
            pass
        return json.loads(source)
    return source


def _load_native(data: Dict) -> List[ExternalFinding]:
    """Parse Trivy native JSON format."""
    findings: List[ExternalFinding] = []
    results = data.get("Results") or data.get("results") or []

    for result in results:
        target   = result.get("Target") or result.get("target") or ""
        pkg_type = result.get("Type") or result.get("type") or ""

        # CVE / vulnerability findings
        for vuln in (result.get("Vulnerabilities") or result.get("vulnerabilities") or []):
            f = _normalise_vuln(vuln, target, pkg_type)
            if f:
                findings.append(f)

        # Misconfiguration findings
        for misconf in (result.get("Misconfigurations") or result.get("misconfigurations") or []):
            f = _normalise_misconf(misconf, target)
            if f:
                findings.append(f)

    logger.info("trivy/json: loaded %d findings", len(findings))
    return findings


def _normalise_vuln(vuln: Dict, target: str, pkg_type: str) -> Optional[ExternalFinding]:
    vuln_id       = vuln.get("VulnerabilityID") or vuln.get("vulnerability_id") or ""
    pkg_name      = vuln.get("PkgName") or vuln.get("pkg_name") or ""
    installed_ver = vuln.get("InstalledVersion") or vuln.get("installed_version") or ""
    fixed_ver     = vuln.get("FixedVersion") or vuln.get("fixed_version") or ""
    severity_raw  = vuln.get("Severity") or vuln.get("severity") or "UNKNOWN"
    title         = vuln.get("Title") or vuln.get("title") or vuln_id
    description   = vuln.get("Description") or vuln.get("description") or ""

    # CVSS score — prefer V3
    cvss = _extract_cvss(vuln)
    severity = normalise_severity(severity_raw, cvss)

    # CVE IDs — VulnerabilityID may be CVE-* or GHSA-* or vendor-specific
    cve_ids: List[str] = []
    if vuln_id:
        cve_ids.append(vuln_id)
    # References may contain additional CVE aliases
    for ref in (vuln.get("References") or []):
        if isinstance(ref, str) and "CVE-" in ref:
            import re
            m = re.search(r"CVE-\d{4}-\d+", ref)
            if m and m.group(0) not in cve_ids:
                cve_ids.append(m.group(0))

    ecosystem = _infer_ecosystem(pkg_type, target)

    return ExternalFinding(
        tool="trivy",
        tool_finding_id=f"trivy-{vuln_id}-{pkg_name}-{installed_ver}",
        finding_type="cve",
        severity=severity,
        title=title,
        description=description[:2000],
        package_name=pkg_name,
        package_version=installed_ver if installed_ver else None,
        cve_ids=cve_ids,
        fix_version=fixed_ver if fixed_ver else None,
        ecosystem=ecosystem,
        raw=vuln,
    )


def _normalise_misconf(misconf: Dict, target: str) -> Optional[ExternalFinding]:
    misconf_id  = misconf.get("ID") or misconf.get("id") or ""
    title       = misconf.get("Title") or misconf.get("title") or misconf_id
    description = misconf.get("Description") or misconf.get("description") or ""
    severity_raw = misconf.get("Severity") or misconf.get("severity") or "MEDIUM"
    severity    = normalise_severity(severity_raw)

    import re
    cwe_ids: List[str] = []
    for ref in (misconf.get("References") or []):
        m = re.search(r"CWE-(\d+)", str(ref), re.IGNORECASE)
        if m:
            cid = f"CWE-{m.group(1)}"
            if cid not in cwe_ids:
                cwe_ids.append(cid)

    return ExternalFinding(
        tool="trivy",
        tool_finding_id=f"trivy-misconf-{misconf_id}-{target}",
        finding_type="config",
        severity=severity,
        title=title,
        description=description[:2000],
        rule_id=misconf_id,
        cwe_ids=cwe_ids,
        file_path=target if target else None,
        raw=misconf,
    )


def _extract_cvss(vuln: Dict) -> Optional[float]:
    """Extract best available CVSS score (prefer V3)."""
    cvss_block = vuln.get("CVSS") or vuln.get("cvss") or {}
    for source in ("nvd", "redhat", "ghsa"):
        entry = cvss_block.get(source) or {}
        score = entry.get("V3Score") or entry.get("v3_score")
        if score is not None:
            return float(score)
    for source in ("nvd", "redhat", "ghsa"):
        entry = cvss_block.get(source) or {}
        score = entry.get("V2Score") or entry.get("v2_score")
        if score is not None:
            return float(score)
    return None


def _infer_ecosystem(pkg_type: str, target: str) -> Optional[str]:
    mapping = {
        "pip":       "PyPI",
        "pipenv":    "PyPI",
        "poetry":    "PyPI",
        "npm":       "npm",
        "yarn":      "npm",
        "pnpm":      "npm",
        "gem":       "RubyGems",
        "bundler":   "RubyGems",
        "cargo":     "crates.io",
        "nuget":     "NuGet",
        "composer":  "Packagist",
        "go":        "Go",
        "gomod":     "Go",
        "jar":       "Maven",
        "maven":     "Maven",
        "gradle":    "Maven",
        "apk":       "Alpine",
        "dpkg":      "Debian",
        "rpm":       "RedHat",
    }
    if pkg_type:
        eco = mapping.get(pkg_type.lower())
        if eco:
            return eco
    # Infer from target path
    target_lower = (target or "").lower()
    if "requirements" in target_lower or "pipfile" in target_lower:
        return "PyPI"
    if "package.json" in target_lower or "node_modules" in target_lower:
        return "npm"
    if "go.sum" in target_lower or "go.mod" in target_lower:
        return "Go"
    if "cargo.lock" in target_lower:
        return "crates.io"
    return None
