#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.
"""
Canonical ExternalFinding dataclass.

All tool normalizers (Dependabot, CodeQL, Trivy, OSV-Scanner) produce
ExternalFinding objects.  The gap analysis engine consumes them.

No external deps beyond stdlib.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

# ── Severity normalisation ────────────────────────────────────────────────

_SEV_MAP: Dict[str, str] = {
    # canonical
    "critical": "CRITICAL", "high": "HIGH",
    "medium":   "MEDIUM",   "moderate": "MEDIUM",
    "low":      "LOW",      "info": "INFO",
    "informational": "INFO", "none": "INFO",
    # CVSS bands (numeric string passed in)
}

# Strings that are too vague to use when a CVSS score is available
_WEAK_STRINGS = {"unknown", "unspecified", ""}

def normalise_severity(raw: str, cvss: Optional[float] = None) -> str:
    """Map any tool's severity string to CRITICAL/HIGH/MEDIUM/LOW/INFO.

    When both raw string and cvss are provided, CVSS takes precedence if the
    raw string is weak (unknown / empty).
    """
    raw_lower = (raw or "").lower().strip()
    # CVSS takes precedence over weak strings
    if cvss is not None and raw_lower in _WEAK_STRINGS:
        if cvss >= 9.0: return "CRITICAL"
        if cvss >= 7.0: return "HIGH"
        if cvss >= 4.0: return "MEDIUM"
        if cvss >  0.0: return "LOW"
        return "INFO"
    if raw_lower:
        s = _SEV_MAP.get(raw_lower)
        if s:
            return s
    if cvss is not None:
        if cvss >= 9.0: return "CRITICAL"
        if cvss >= 7.0: return "HIGH"
        if cvss >= 4.0: return "MEDIUM"
        if cvss >  0.0: return "LOW"
        return "INFO"
    return "MEDIUM"


# ── ExternalFinding ───────────────────────────────────────────────────────

@dataclass
class ExternalFinding:
    """
    Canonical representation of a finding from a third-party security tool.
    All normalizers produce this; the gap analysis engine consumes it.
    """
    # Source tool
    tool: str                           # "dependabot" | "codeql" | "trivy" | "osv"
    tool_finding_id: str                # tool's own stable identifier

    # Classification
    finding_type: str                   # "cve" | "cwe" | "secret" | "config"
    severity: str                       # CRITICAL | HIGH | MEDIUM | LOW | INFO

    # Human-readable
    title: str = ""
    description: str = ""

    # Code location (SAST / CWE findings)
    file_path: Optional[str] = None
    line_number: Optional[int] = None
    rule_id: Optional[str] = None
    cwe_ids: List[str] = field(default_factory=list)

    # Package (SCA / CVE findings)
    package_name: Optional[str] = None
    package_version: Optional[str] = None
    cve_ids: List[str] = field(default_factory=list)
    fix_version: Optional[str] = None
    ecosystem: Optional[str] = None    # "PyPI" | "npm" | "Go" | "Maven" | …

    # Raw tool data (for debugging / extended fields)
    raw: Optional[Dict[str, Any]] = None

    # Populated by gap analysis engine after matching
    reachable_finding_id: Optional[str] = None
    match_confidence: float = 0.0
    match_method: str = ""  # "exact_cve"|"package_version"|"cwe_file_line"|"none"

    def to_dict(self) -> Dict[str, Any]:
        return {
            "tool": self.tool,
            "tool_finding_id": self.tool_finding_id,
            "finding_type": self.finding_type,
            "severity": self.severity,
            "title": self.title,
            "file_path": self.file_path,
            "line_number": self.line_number,
            "rule_id": self.rule_id,
            "cwe_ids": self.cwe_ids,
            "package_name": self.package_name,
            "package_version": self.package_version,
            "cve_ids": self.cve_ids,
            "fix_version": self.fix_version,
            "ecosystem": self.ecosystem,
            "reachable_finding_id": self.reachable_finding_id,
            "match_confidence": self.match_confidence,
            "match_method": self.match_method,
        }

    @property
    def primary_cve(self) -> Optional[str]:
        return self.cve_ids[0] if self.cve_ids else None

    @property
    def primary_cwe(self) -> Optional[str]:
        return self.cwe_ids[0] if self.cwe_ids else None
