#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.
"""
OSV-Scanner normalizer (Google).

Accepts output from:
  osv-scanner --format json [--lockfile path/to/lockfile]
  osv-scanner --format json --sbom sbom.spdx.json

Native OSV JSON schema (v1.6+):
  {
    "results": [
      {
        "source": { "path": "requirements.txt", "type": "lockfile" },
        "packages": [
          {
            "package": { "name": "requests", "version": "2.28.0", "ecosystem": "PyPI" },
            "vulnerabilities": [
              {
                "id": "GHSA-j8r2-6x86-q33q",
                "aliases": ["CVE-2023-32681"],
                "summary": "...",
                "details": "...",
                "severity": [{"type": "CVSS_V3", "score": "CVSS:3.1/AV:N/..."}],
                "affected": [{
                  "package": {...},
                  "ranges": [{"type": "ECOSYSTEM", "events": [...]}],
                  "versions": ["2.0.0", ...]
                }]
              }
            ],
            "groups": [
              {
                "ids": ["GHSA-j8r2-6x86-q33q", "CVE-2023-32681"],
                "aliases": ["CVE-2023-32681"],
                "max_severity": "6.1"
              }
            ]
          }
        ]
      }
    ]
  }

The `groups` field is the key value of OSV-Scanner — it already deduplicates
aliases so we don't create multiple findings for the same vuln.
"""
from __future__ import annotations

import json
import logging
import re
from pathlib import Path
from typing import Dict, List, Optional, Union

from .models import ExternalFinding, normalise_severity

logger = logging.getLogger(__name__)

# CVSS score extraction from vector string
_CVSS_SCORE_RE = re.compile(r"CVSS:\S+/\S+", re.IGNORECASE)


def load(source: Union[str, Path, Dict]) -> List[ExternalFinding]:
    """Load OSV-Scanner JSON output."""
    data = _parse_input(source)

    findings: List[ExternalFinding] = []
    for result in (data.get("results") or []):
        source_path = (result.get("source") or {}).get("path") or ""
        for pkg_entry in (result.get("packages") or []):
            findings.extend(_process_package(pkg_entry, source_path))

    logger.info("osv-scanner: loaded %d findings", len(findings))
    return findings


def _parse_input(source) -> Dict:
    if isinstance(source, (str, Path)):
        p = Path(source)
        try:
            if p.exists():
                return json.loads(p.read_text())
        except (OSError, ValueError):
            pass
        return json.loads(source)
    return source


def _process_package(pkg_entry: Dict, manifest_path: str) -> List[ExternalFinding]:
    """
    Process one package entry.

    Prefer `groups` for deduplication — each group represents one unique
    vulnerability (collapsing CVE/GHSA aliases).  Fall back to iterating
    `vulnerabilities` directly when groups are absent.
    """
    pkg      = pkg_entry.get("package") or {}
    pkg_name = pkg.get("name") or ""
    pkg_ver  = pkg.get("version") or ""
    ecosystem = pkg.get("ecosystem") or ""

    # Build vuln lookup for fix-version extraction
    vuln_map: Dict[str, Dict] = {}
    for v in (pkg_entry.get("vulnerabilities") or []):
        vid = v.get("id") or ""
        if vid:
            vuln_map[vid] = v
        for alias in (v.get("aliases") or []):
            vuln_map[alias] = v

    findings: List[ExternalFinding] = []
    groups = pkg_entry.get("groups") or []

    if groups:
        for group in groups:
            f = _normalise_group(group, pkg_name, pkg_ver, ecosystem,
                                 manifest_path, vuln_map)
            if f:
                findings.append(f)
    else:
        # No groups — treat each vulnerability individually
        for vuln in (pkg_entry.get("vulnerabilities") or []):
            f = _normalise_vuln_direct(vuln, pkg_name, pkg_ver, ecosystem,
                                       manifest_path)
            if f:
                findings.append(f)

    return findings


def _normalise_group(
    group: Dict,
    pkg_name: str,
    pkg_ver: str,
    ecosystem: str,
    manifest_path: str,
    vuln_map: Dict[str, Dict],
) -> Optional[ExternalFinding]:
    """One group = one deduplicated vulnerability (possibly multiple CVE aliases)."""
    ids     = group.get("ids") or []
    aliases = group.get("aliases") or []

    # Collect all IDs — dedup across ids + aliases
    all_ids = list(dict.fromkeys(ids + aliases))  # preserves order, deduplicates
    if not all_ids:
        return None

    cve_ids = all_ids  # mix of CVE-* and GHSA-*; gap analysis handles both

    # Severity: prefer group max_severity, fall back to vuln CVSS
    cvss: Optional[float] = None
    max_sev = group.get("max_severity")
    if max_sev:
        try:
            cvss = float(max_sev)
        except (ValueError, TypeError):
            pass

    # Get fix version from the primary vuln in this group
    fix_version = None
    title = ""
    description = ""
    for vid in ids:
        vuln = vuln_map.get(vid)
        if vuln:
            if not fix_version:
                fix_version = _extract_fix_version(vuln, pkg_ver, ecosystem)
            if not cvss:
                cvss = _extract_cvss_score(vuln)
            if not title:
                title = vuln.get("summary") or ""
            if not description:
                description = vuln.get("details") or ""

    if not cvss:
        cvss = _extract_cvss_from_group_ids(ids, vuln_map)

    severity = normalise_severity("", cvss) if cvss else "MEDIUM"
    title = title or (ids[0] if ids else "OSV finding")

    return ExternalFinding(
        tool="osv",
        tool_finding_id=f"osv-{'-'.join(ids[:2])}-{pkg_name}-{pkg_ver}",
        finding_type="cve",
        severity=severity,
        title=title,
        description=description[:2000],
        package_name=pkg_name,
        package_version=pkg_ver if pkg_ver else None,
        cve_ids=cve_ids,
        fix_version=fix_version,
        ecosystem=ecosystem or None,
        raw=group,
    )


def _normalise_vuln_direct(
    vuln: Dict,
    pkg_name: str,
    pkg_ver: str,
    ecosystem: str,
    manifest_path: str,
) -> Optional[ExternalFinding]:
    """Fallback: no groups — normalise one vuln directly."""
    vid  = vuln.get("id") or ""
    all_ids = [vid] + (vuln.get("aliases") or [])
    all_ids = list(dict.fromkeys(filter(None, all_ids)))

    cvss = _extract_cvss_score(vuln)
    severity = normalise_severity("", cvss) if cvss else "MEDIUM"

    return ExternalFinding(
        tool="osv",
        tool_finding_id=f"osv-{vid}-{pkg_name}-{pkg_ver}",
        finding_type="cve",
        severity=severity,
        title=vuln.get("summary") or vid,
        description=(vuln.get("details") or "")[:2000],
        package_name=pkg_name,
        package_version=pkg_ver if pkg_ver else None,
        cve_ids=all_ids,
        fix_version=_extract_fix_version(vuln, pkg_ver, ecosystem),
        ecosystem=ecosystem or None,
        raw=vuln,
    )


def _extract_fix_version(
    vuln: Dict, installed_ver: str, ecosystem: str
) -> Optional[str]:
    """
    Extract fixed version from OSV affected[].ranges[].events.

    Events are ordered pairs: [{introduced: X}, {fixed: Y}, ...].
    We want the earliest `fixed` version that is > installed_ver.
    Falls back to the last `fixed` event if version comparison is unavailable.
    """
    fix_candidates: List[str] = []

    for affected in (vuln.get("affected") or []):
        for rng in (affected.get("ranges") or []):
            rng_type = rng.get("type") or ""
            if rng_type not in ("ECOSYSTEM", "SEMVER"):
                continue
            events = rng.get("events") or []
            for event in events:
                fv = event.get("fixed")
                if fv:
                    fix_candidates.append(fv)

    if not fix_candidates:
        return None

    # If only one, return it
    if len(fix_candidates) == 1:
        return fix_candidates[0]

    # Try semver comparison to return minimum fix > installed
    try:
        from packaging.version import Version
        inst = Version(installed_ver) if installed_ver else None
        eligible = [Version(v) for v in fix_candidates]
        if inst:
            eligible = [v for v in eligible if v > inst]
        if eligible:
            return str(min(eligible))
    except Exception:
        pass

    # Fallback: lexicographic last
    return sorted(fix_candidates)[-1]


def _extract_cvss_score(vuln: Dict) -> Optional[float]:
    """Extract CVSS float from OSV severity array."""
    for sev_entry in (vuln.get("severity") or []):
        stype = sev_entry.get("type") or ""
        score_str = sev_entry.get("score") or ""
        if "CVSS" in stype.upper() and score_str:
            # Some store "7.5", others store full vector "CVSS:3.1/AV:N/..."
            try:
                return float(score_str)
            except ValueError:
                # Parse base score from vector — last component after last /
                # e.g. CVSS:3.1/.../7.5 — not reliable; skip
                pass
    return None


def _extract_cvss_from_group_ids(ids: List[str], vuln_map: Dict) -> Optional[float]:
    """Try each vuln in the group for a CVSS score."""
    for vid in ids:
        vuln = vuln_map.get(vid)
        if vuln:
            score = _extract_cvss_score(vuln)
            if score is not None:
                return score
    return None
