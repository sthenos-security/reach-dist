#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.
"""
Language-aware build verification.

Two stages:
    1. dep_install — install/restore dependencies so the project is buildable
    2. build       — compile / transpile / whatever the project needs

Both run INSIDE the worktree, not the user's checkout.
"""

from __future__ import annotations

import logging
import os
import subprocess
from pathlib import Path
from typing import Any, Dict, List, Optional

from ..models import ValidationResult

logger = logging.getLogger(__name__)

# ── Commands per ecosystem ────────────────────────────────────────────

# dep_install restores the dependency tree so the build has everything it needs.
# build checks that the patched code compiles / transpiles cleanly.

_DEP_INSTALL: Dict[str, List[str]] = {
    "npm":      ["npm", "ci", "--ignore-scripts"],
    "yarn":     ["yarn", "install", "--frozen-lockfile", "--ignore-scripts"],
    "pnpm":     ["pnpm", "install", "--frozen-lockfile", "--ignore-scripts"],
    "pip":      ["pip", "install", "-r", "requirements.txt", "-q", "--break-system-packages"],
    "pipenv":   ["pipenv", "install", "--deploy"],
    "go":       ["go", "mod", "download"],
    "maven":    ["mvn", "dependency:resolve", "-q"],
    "gradle":   ["./gradlew", "dependencies", "--quiet"],
    "cargo":    ["cargo", "fetch"],
    "bundler":  ["bundle", "install", "--deployment"],
    "composer": ["composer", "install", "--no-scripts"],
}

_BUILD: Dict[str, List[str]] = {
    "npm":      ["npm", "run", "build", "--if-present"],
    "yarn":     ["yarn", "build"],
    "pnpm":     ["pnpm", "build"],
    "pip":      ["python", "-m", "py_compile"],     # overridden per-file below
    "go":       ["go", "build", "./..."],
    "maven":    ["mvn", "compile", "-q", "-DskipTests"],
    "gradle":   ["./gradlew", "compileJava", "-x", "test"],
    "cargo":    ["cargo", "build"],
}

# Files that indicate which ecosystem
_ECOSYSTEM_INDICATORS = [
    ("package-lock.json", "npm"),
    ("yarn.lock", "yarn"),
    ("pnpm-lock.yaml", "pnpm"),
    ("package.json", "npm"),       # fallback if no lockfile
    ("requirements.txt", "pip"),
    ("pyproject.toml", "pip"),
    ("Pipfile", "pipenv"),
    ("go.mod", "go"),
    ("pom.xml", "maven"),
    ("build.gradle", "gradle"),
    ("build.gradle.kts", "gradle"),
    ("Cargo.toml", "cargo"),
    ("Gemfile", "bundler"),
    ("composer.json", "composer"),
]


def _detect_ecosystem(worktree_path: str) -> Optional[str]:
    """Detect build ecosystem from project files."""
    wt = Path(worktree_path)
    for indicator, ecosystem in _ECOSYSTEM_INDICATORS:
        if (wt / indicator).exists():
            return ecosystem
    return None


def _run(cmd: List[str], cwd: str, timeout: int = 300, env_extra: Optional[Dict] = None) -> Dict[str, Any]:
    """Run a command, capture output, return structured result."""
    env = {**os.environ, **(env_extra or {})}
    cmd_str = " ".join(cmd)
    logger.debug("Running: %s (in %s)", cmd_str, cwd)
    try:
        proc = subprocess.run(
            cmd_str, shell=True, cwd=cwd,
            capture_output=True, text=True,
            timeout=timeout, env=env,
        )
        return {
            "returncode": proc.returncode,
            "stdout": (proc.stdout or "")[-5000:],
            "stderr": (proc.stderr or "")[-5000:],
        }
    except subprocess.TimeoutExpired:
        return {"returncode": -1, "stdout": "", "stderr": f"Timed out after {timeout}s"}
    except FileNotFoundError as exc:
        return {"returncode": -1, "stdout": "", "stderr": f"Command not found: {exc}"}


def _python_syntax_check(worktree_path: str, files_modified: List[str]) -> Dict[str, Any]:
    """
    For Python: syntax-check only the modified files.
    Much faster than a full build and catches the most common patch errors.
    """
    py_files = [f for f in files_modified if f.endswith(".py")]
    if not py_files:
        return {"returncode": 0, "stdout": "No Python files modified", "stderr": ""}

    cmd = ["python", "-m", "py_compile"] + [str(Path(worktree_path) / f) for f in py_files]
    return _run(cmd, worktree_path, timeout=30)


def run_build(
    worktree_path: str,
    ecosystem: Optional[str] = None,
    build_command: Optional[str] = None,
    files_modified: Optional[List[str]] = None,
    install_deps: bool = True,
    timeout: int = 300,
) -> ValidationResult:
    """
    Full build verification inside the worktree.

    Steps:
        1. Detect ecosystem (if not provided)
        2. Install dependencies (if lockfile present)
        3. Run build command
        4. For Python: also syntax-check modified files

    Returns ValidationResult with passed=True if build succeeds.
    """
    # Detect
    if not ecosystem:
        ecosystem = _detect_ecosystem(worktree_path)
    if not ecosystem:
        return ValidationResult(
            passed=True, stage="build",
            details={"skipped": True, "reason": "No build system detected"},
        )

    # Step 1: Install dependencies
    if install_deps:
        dep_cmd = _DEP_INSTALL.get(ecosystem)
        if dep_cmd:
            result = _run(dep_cmd, worktree_path, timeout=timeout)
            if result["returncode"] != 0:
                # Dep install failure is a warning, not a hard fail
                # (the worktree might already have deps from the main checkout)
                logger.warning("Dep install returned %d: %s", result["returncode"], result["stderr"][:200])

    # Step 2: Build
    if build_command:
        cmd = build_command.split()
    else:
        cmd = _BUILD.get(ecosystem)

    if cmd:
        # Special case: Python syntax check is per-file, faster
        if ecosystem in ("pip", "pipenv") and files_modified:
            result = _python_syntax_check(worktree_path, files_modified)
        else:
            result = _run(cmd, worktree_path, timeout=timeout)

        if result["returncode"] != 0:
            error_text = result["stderr"] or result["stdout"] or "Build failed"
            return ValidationResult(
                passed=False, stage="build",
                error=error_text,
                details={
                    "ecosystem": ecosystem,
                    "returncode": result["returncode"],
                    "command": " ".join(cmd) if isinstance(cmd, list) else build_command,
                },
            )

    return ValidationResult(
        passed=True, stage="build",
        details={"ecosystem": ecosystem},
    )


def run_tests(
    worktree_path: str,
    ecosystem: Optional[str] = None,
    test_command: Optional[str] = None,
    test_framework: Optional[str] = None,
    timeout: int = 600,
) -> ValidationResult:
    """
    Run test suite inside the worktree.

    Returns ValidationResult with passed=True if tests pass.
    """
    _TEST_COMMANDS: Dict[str, List[str]] = {
        "npm":      ["npm", "test", "--", "--ci"],
        "yarn":     ["yarn", "test", "--ci"],
        "pnpm":     ["pnpm", "test", "--ci"],
        "pip":      ["python", "-m", "pytest", "-x", "--tb=short", "-q"],
        "pytest":   ["python", "-m", "pytest", "-x", "--tb=short", "-q"],
        "go":       ["go", "test", "./..."],
        "go test":  ["go", "test", "./..."],
        "maven":    ["mvn", "test", "-q"],
        "gradle":   ["./gradlew", "test"],
        "cargo":    ["cargo", "test"],
        "jest":     ["npx", "jest", "--ci", "--bail"],
        "mocha":    ["npx", "mocha"],
        "vitest":   ["npx", "vitest", "run"],
        "tox":      ["tox"],
    }

    if not ecosystem:
        ecosystem = _detect_ecosystem(worktree_path)

    if test_command:
        cmd = test_command.split()
    elif test_framework and test_framework in _TEST_COMMANDS:
        cmd = _TEST_COMMANDS[test_framework]
    elif ecosystem and ecosystem in _TEST_COMMANDS:
        cmd = _TEST_COMMANDS[ecosystem]
    else:
        return ValidationResult(
            passed=True, stage="test",
            details={"skipped": True, "reason": "No test framework detected"},
        )

    result = _run(cmd, worktree_path, timeout=timeout)
    if result["returncode"] == 0:
        return ValidationResult(passed=True, stage="test", details={"ecosystem": ecosystem})

    return ValidationResult(
        passed=False, stage="test",
        error=result["stderr"] or result["stdout"] or "Tests failed",
        details={"returncode": result["returncode"]},
    )
