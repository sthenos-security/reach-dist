#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.
"""
Git worktree isolation.

Creates a throwaway worktree so the patch is validated without touching
the user's working directory.  If validation fails, the worktree is
discarded and the repo is exactly as it was before.

Flow:
    wt = Worktree.create(repo_path, finding_id)
    wt.apply_diff(diff)           # returns (success, error)
    ... build / test / rescan inside wt.path ...
    wt.commit(message)            # only if everything passed
    wt.cleanup()                  # always — removes worktree dir
"""

from __future__ import annotations

import logging
import shutil
import subprocess
import tempfile
from pathlib import Path
from typing import Optional

logger = logging.getLogger(__name__)


def _git(cwd: str, *args, check: bool = True) -> subprocess.CompletedProcess:
    return subprocess.run(
        ["git", *args], cwd=cwd, capture_output=True,
        text=True, check=check, timeout=60,
    )


class Worktree:
    """An isolated git worktree for patch validation."""

    def __init__(self, repo_path: str, worktree_path: str, branch_name: str):
        self.repo_path = str(Path(repo_path).resolve())
        self.path = worktree_path          # this is where build/test/rescan happen
        self.branch_name = branch_name
        self._committed = False

    @classmethod
    def create(cls, repo_path: str, finding_id: str, prefix: str = "reachable/fix") -> "Worktree":
        """
        Create an isolated worktree on a new branch.

        The worktree lives in a temp dir, not inside the repo, so it
        won't interfere with .gitignore, IDE indexing, etc.
        """
        repo = str(Path(repo_path).resolve())
        short_id = finding_id[:12] if len(finding_id) > 12 else finding_id
        branch_name = f"{prefix}/{short_id}"

        # Base worktree dir outside the repo
        wt_base = Path(tempfile.mkdtemp(prefix="enzo-wt-"))
        wt_path = str(wt_base / short_id)

        try:
            # Create branch + worktree in one shot
            _git(repo, "worktree", "add", "-b", branch_name, wt_path)
        except subprocess.CalledProcessError:
            # Branch or stale worktree ref may already exist from a prior run.
            # Prune stale worktree refs first, then delete branch, then retry.
            try:
                _git(repo, "worktree", "prune", check=False)
                _git(repo, "branch", "-D", branch_name, check=False)
                _git(repo, "worktree", "add", "-b", branch_name, wt_path)
            except subprocess.CalledProcessError:
                # Second fallback: unique timestamped branch to avoid name collision
                import time as _time
                unique_branch = f"{branch_name}-{int(_time.time()) % 10000}"
                try:
                    _git(repo, "worktree", "add", "-b", unique_branch, wt_path)
                    branch_name = unique_branch
                    logger.info(
                        "Used unique branch %s (original %s already exists)",
                        unique_branch, f"{prefix}/{short_id}",
                    )
                except subprocess.CalledProcessError:
                    # Last resort: detached HEAD
                    _git(repo, "worktree", "add", "--detach", wt_path)
                    branch_name = "(detached)"
                    logger.warning(
                        "Worktree created in detached HEAD — branch %s could not be created",
                        f"{prefix}/{short_id}",
                    )

        logger.info("Created worktree at %s (branch: %s)", wt_path, branch_name)
        return cls(repo, wt_path, branch_name)

    def apply_diff(self, diff: str) -> tuple[bool, str]:
        """Apply a unified diff in the worktree.  Returns (success, error).

        Strategy (each step only tried if the previous fails):
          1. git apply --ignore-whitespace          (cleanest)
          2. git apply --ignore-whitespace --recount (wrong @@ counts)
          3. patch -p1 --no-backup-if-mismatch -F3  (fuzz up to 3 lines)
        """
        patch_file = Path(self.path) / ".enzo-patch.tmp"
        try:
            patch_file.write_text(diff)

            # 1. Standard git apply with whitespace tolerance
            result = _git(
                self.path, "apply", "--ignore-whitespace", str(patch_file), check=False
            )
            if result.returncode == 0:
                return True, ""

            # 2. Recount @@ line numbers (model sometimes gets counts wrong)
            result = _git(
                self.path, "apply", "--ignore-whitespace", "--recount",
                str(patch_file), check=False,
            )
            if result.returncode == 0:
                return True, ""

            # 3. GNU patch with fuzz factor — tolerates shifted context lines
            patch_cmd = subprocess.run(
                ["patch", "-p1", "--no-backup-if-mismatch", "-F3",
                 "-i", str(patch_file)],
                cwd=self.path,
                capture_output=True,
                text=True,
                timeout=30,
            )
            if patch_cmd.returncode == 0:
                return True, ""

            # All strategies failed — report the git apply error (most readable)
            err = result.stderr.strip() or patch_cmd.stderr.strip() or "Diff does not apply"
            return False, err

        except subprocess.CalledProcessError as exc:
            return False, exc.stderr.strip() or str(exc)
        finally:
            patch_file.unlink(missing_ok=True)

    def get_current_commit(self) -> str:
        return _git(self.path, "rev-parse", "HEAD").stdout.strip()

    def commit(self, message: str, sign: bool = False) -> Optional[str]:
        """Stage all changes and commit.  Returns commit hash or None."""
        try:
            _git(self.path, "add", "-A")
            cmd = ["commit", "-m", message]
            if sign:
                cmd.append("-S")
            _git(self.path, *cmd)
            self._committed = True
            return self.get_current_commit()
        except subprocess.CalledProcessError as exc:
            logger.error("Commit failed in worktree: %s", exc.stderr)
            return None

    def push(self, remote: str = "origin") -> tuple[bool, str]:
        """Push the worktree branch to remote."""
        if self.branch_name == "(detached)":
            return False, "Cannot push detached worktree"
        try:
            _git(self.path, "push", remote, self.branch_name)
            return True, ""
        except subprocess.CalledProcessError as exc:
            return False, exc.stderr.strip() or str(exc)

    def cleanup(self):
        """
        Remove the worktree.

        If we committed, the branch remains (for PR).
        If we didn't commit, the branch is also deleted.
        """
        wt_path = self.path
        try:
            _git(self.repo_path, "worktree", "remove", "--force", wt_path, check=False)
        except Exception as exc:
            logger.debug("worktree remove failed (will still delete dir): %s", exc)

        if Path(wt_path).exists():
            shutil.rmtree(wt_path, ignore_errors=True)

        if not self._committed and self.branch_name != "(detached)":
            try:
                _git(self.repo_path, "branch", "-D", self.branch_name, check=False)
            except Exception as exc:
                logger.debug("Branch delete failed for %s: %s", self.branch_name, exc)

        logger.info("Cleaned up worktree %s", wt_path)

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.cleanup()
