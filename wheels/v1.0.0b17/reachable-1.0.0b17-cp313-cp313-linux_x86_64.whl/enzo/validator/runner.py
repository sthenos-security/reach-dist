#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.
"""
Validation runner — the closed proof loop.

    ┌─────────────────────────────────────────────────────────────┐
    │                                                             │
    │  1. git worktree add (isolated copy)                        │
    │  2. apply diff                                              │
    │  3. install deps + build   → proves code compiles           │
    │  4. run tests              → proves no regressions          │
    │  5. rescan with REACHABLE  → proves vuln is gone            │
    │  6. diff findings          → proves no new criticals        │
    │                                                             │
    │  ALL pass  →  commit in worktree  →  ready for PR           │
    │  ANY fail  →  discard worktree  →  feed error to retry      │
    │                                                             │
    └─────────────────────────────────────────────────────────────┘

Nothing touches the user's working directory until step 6 succeeds.
"""

from __future__ import annotations

import logging
from typing import List, Optional, Set

from ..config import EnzoConfig
from ..models import EnzoFinding, ValidationReport, ValidationResult
from .builder import run_build, run_tests
from .worktree import Worktree

logger = logging.getLogger(__name__)


class Validator:
    """Closed-loop validation in an isolated worktree."""

    def __init__(self, config: EnzoConfig):
        self.config = config

    def validate(
        self,
        finding: EnzoFinding,
        repo_path: str,
        diff: str,
        files_modified: Optional[List[str]] = None,
        ecosystem: Optional[str] = None,
        test_framework: Optional[str] = None,
        original_finding_ids: Optional[Set[str]] = None,
    ) -> tuple[ValidationReport, Optional[Worktree]]:
        """
        Full closed-loop validation.

        Creates an isolated worktree, applies the diff, builds, tests,
        and rescans.  If all stages pass, the worktree is returned
        (caller commits + pushes).  If any stage fails, the worktree
        is cleaned up and the report shows what broke.

        Returns:
            (report, worktree_or_none)
            worktree is None if validation failed (already cleaned up).
            worktree is live if validation passed (caller must cleanup after commit).
        """
        report = ValidationReport()
        wt = None

        try:
            # ── Step 1: Create isolated worktree ──────────────────────
            wt = Worktree.create(repo_path, finding.finding_id, prefix=self.config.branch_prefix)
            logger.info("Validating in worktree: %s", wt.path)

            # ── Step 2: Apply diff ────────────────────────────────────
            applied, apply_err = wt.apply_diff(diff)
            if not applied:
                report.rescan = None
                report.build = ValidationResult(
                    passed=False, stage="apply",
                    error=f"Diff does not apply: {apply_err}",
                )
                wt.cleanup()
                return report, None

            # ── Step 3: Build ─────────────────────────────────────────
            report.build = run_build(
                wt.path,
                ecosystem=ecosystem,
                build_command=self.config.build_command,
                files_modified=files_modified,
                install_deps=True,
            )
            if not report.build.passed:
                logger.warning("Build failed: %s", report.build.error)
                wt.cleanup()
                return report, None

            # ── Step 4: Test ──────────────────────────────────────────
            if self.config.require_tests_pass:
                report.test = run_tests(
                    wt.path,
                    ecosystem=ecosystem,
                    test_command=self.config.test_command,
                    test_framework=test_framework,
                )
                if not report.test.passed:
                    logger.warning("Tests failed: %s", report.test.error)
                    wt.cleanup()
                    return report, None
            else:
                report.test = ValidationResult(
                    passed=True, stage="test",
                    details={"skipped": True, "reason": "Tests not required by policy"},
                )

            # ── Step 5: Rescan — REMOVED ─────────────────────────────
            # Per-worktree rescan removed in 0.5.7.
            # Verification runs once against the consolidated batch branch
            # after all findings are patched. See pipeline.py consolidate().
            report.rescan = ValidationResult(
                passed=True, stage="rescan",
                details={"skipped": True, "reason": "post-run batch verification"},
            )

            # ── Step 6: Policy ────────────────────────────────────────
            report.policy = self._policy_check(finding, report)
            if not report.policy.passed:
                logger.warning("Policy check failed: %s", report.policy.error)
                wt.cleanup()
                return report, None

            # ── ALL PASSED ────────────────────────────────────────────
            logger.info("✓ All validation stages passed for %s", finding.finding_id[:12])
            return report, wt

        except Exception as exc:
            logger.error("Validation error for %s: %s", finding.finding_id[:12], exc, exc_info=True)
            if wt:
                wt.cleanup()
            # Assign the error to the first stage that hasn't been set yet,
            # so the caller sees accurate failure context (not a false build failure).
            if report.build is None or not report.build.passed:
                report.build = report.build or ValidationResult(
                    passed=False, stage="build", error=f"Unexpected error: {exc}",
                )
            elif report.test is None:
                report.test = ValidationResult(
                    passed=False, stage="test", error=f"Unexpected error: {exc}",
                )
            else:
                report.rescan = ValidationResult(
                    passed=False, stage="rescan", error=f"Unexpected error: {exc}",
                )
            return report, None

    def _policy_check(self, finding: EnzoFinding, report: ValidationReport) -> ValidationResult:
        """Check policy gates beyond build/test/rescan."""
        issues = []

        # Gate: rescan must have confirmed removal (not just skipped)
        if report.rescan and report.rescan.details:
            if report.rescan.details.get("skipped"):
                # Rescan was skipped (scanner not available) — that's ok
                # in local dev, CI will catch it
                pass
            elif not report.rescan.details.get("target_removed"):
                issues.append("Rescan did not confirm target vulnerability removal")

        # Gate: no new criticals (checked in rescan already, but double-check)
        if report.rescan and report.rescan.details:
            new_crits = report.rescan.details.get("new_criticals", 0)
            if new_crits > 0:
                issues.append(f"{new_crits} new CRITICAL/HIGH findings introduced")

        if issues:
            return ValidationResult(passed=False, stage="policy", error="; ".join(issues))
        return ValidationResult(passed=True, stage="policy")
