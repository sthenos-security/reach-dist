#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.
"""
Rescan verification.

Runs REACHABLE scan on the patched worktree and diffs against the
original scan to prove:
    1. The target vulnerability is GONE
    2. No new CRITICAL/HIGH findings were introduced

This is the closed-loop proof that Enzo's patch actually works.
"""

from __future__ import annotations

import json
import logging
import subprocess
from pathlib import Path
from typing import Any, Dict, List, Optional, Set

from ..models import ValidationResult

logger = logging.getLogger(__name__)


def _invoke_reachable(worktree_path: str, timeout: int = 600) -> tuple[bool, Optional[str]]:
    """
    Run REACHABLE scan on the worktree.

    Tries three methods in order:
        1. Python import (same process — fastest)
        2. Shell out to reachctl (installed CLI)
        3. Shell out to `python -m reachable` (dev mode)

    Returns (success, data_json_path or None).
    """
    # Method 1: Direct import
    try:
        from reachable.cli.main import run_scan  # type: ignore
        result = run_scan(worktree_path, temporary=True, quiet=True)
        if result and isinstance(result, str) and Path(result).exists():
            return True, result
        # run_scan might write to a known location
        data_json = Path(worktree_path) / ".reachable" / "data.json"
        if data_json.exists():
            return True, str(data_json)
    except ImportError:
        pass
    except Exception as exc:
        logger.debug("Direct import scan failed: %s", exc)

    # Method 2: reachctl CLI — check known install locations + PATH
    _reachctl_candidates = [
        "reachctl",                                          # on PATH
        str(Path.home() / ".reachable" / "venv" / "bin" / "reachctl"),  # standard install
        str(Path.home() / ".local" / "bin" / "reachctl"),    # pip install --user
        "/usr/local/bin/reachctl",                           # system install
    ]
    for _reachctl in _reachctl_candidates:
        try:
            result = subprocess.run(
                [_reachctl, "scan", worktree_path, "--quick", "--json"],
                capture_output=True, text=True, timeout=timeout,
            )
            if result.returncode == 0:
                data_json = _find_data_json(worktree_path, result.stdout)
                if data_json:
                    logger.debug("Scanner found via %s", _reachctl)
                    return True, data_json
            break  # found reachctl but scan failed — don't try other paths
        except FileNotFoundError:
            continue  # try next candidate
        except subprocess.TimeoutExpired as exc:
            logger.debug("Scanner method 2 timed out: %s", exc)
            break

    # Method 3: python -m reachable
    try:
        result = subprocess.run(
            ["python", "-m", "reachable", "scan", worktree_path, "--quick", "--json"],
            capture_output=True, text=True, timeout=timeout,
        )
        if result.returncode == 0:
            data_json = _find_data_json(worktree_path, result.stdout)
            if data_json:
                return True, data_json
    except (FileNotFoundError, subprocess.TimeoutExpired) as exc:
        logger.debug("Scanner method 3 unavailable: %s", exc)

    return False, None


def _find_data_json(worktree_path: str, stdout: str = "") -> Optional[str]:
    """Find the data.json output from a scan."""
    # Check common locations
    candidates = [
        Path(worktree_path) / ".reachable" / "data.json",
    ]
    # Also check if stdout contains a path
    for line in stdout.split("\n"):
        line = line.strip()
        if line.endswith("data.json") and Path(line).exists():
            return line

    for p in candidates:
        if p.exists():
            return str(p)
    return None


def _load_findings_from_data_json(path: str) -> List[Dict[str, Any]]:
    """Load findings array from data.json."""
    try:
        with open(path) as f:
            data = json.load(f)
        # data.json has findings at top level or under "findings"
        if isinstance(data, list):
            return data
        if isinstance(data, dict):
            return data.get("findings", data.get("cve_findings", []))
        return []
    except Exception as exc:
        logger.warning("Failed to load data.json: %s", exc)
        return []


def _finding_ids_from_list(findings: List[Dict]) -> Set[str]:
    """Extract finding_id set from a findings list."""
    ids = set()
    for f in findings:
        fid = f.get("finding_id") or f.get("id") or f.get("fingerprint")
        if fid:
            ids.add(str(fid))
    return ids


def _high_severity_ids(findings: List[Dict]) -> Set[str]:
    """Extract finding_ids of CRITICAL or HIGH severity findings."""
    ids = set()
    for f in findings:
        sev = (f.get("severity") or "").upper()
        if sev in ("CRITICAL", "HIGH"):
            fid = f.get("finding_id") or f.get("id") or f.get("fingerprint")
            if fid:
                ids.add(str(fid))
    return ids


def run_rescan(
    worktree_path: str,
    target_finding_id: str,
    original_finding_ids: Optional[Set[str]] = None,
    timeout: int = 600,
) -> ValidationResult:
    """
    Rescan the patched worktree and verify the fix.

    Checks:
        1. Target finding is GONE from the new scan
        2. No new CRITICAL/HIGH findings introduced

    Args:
        worktree_path: Path to the patched worktree
        target_finding_id: The finding_id we're trying to fix
        original_finding_ids: Set of finding_ids from original scan (for diff).
                             If None, only checks target is gone.
        timeout: Scan timeout in seconds

    Returns:
        ValidationResult with:
            passed=True if target vuln is gone and no new criticals
            details includes finding diff stats
    """
    # Run scan
    success, data_path = _invoke_reachable(worktree_path, timeout)

    if not success or not data_path:
        # Scanner not available — this is a degraded but acceptable state.
        # We still proved it builds and passes tests.
        logger.warning("Rescan could not run (scanner not available)")
        return ValidationResult(
            passed=True, stage="rescan",
            details={
                "skipped": True,
                "reason": "REACHABLE scanner not available in this environment. "
                          "Build and test passed. Rescan will run in CI.",
            },
        )

    # Load new findings
    new_findings = _load_findings_from_data_json(data_path)
    new_ids = _finding_ids_from_list(new_findings)

    # CHECK 1: Is the target finding gone?
    if target_finding_id in new_ids:
        return ValidationResult(
            passed=False, stage="rescan",
            error=f"Target finding {target_finding_id[:12]} still present after patch",
            details={
                "target_finding_id": target_finding_id,
                "still_present": True,
                "total_findings_after": len(new_findings),
            },
        )

    # CHECK 2: No new CRITICAL/HIGH findings
    new_high = set()
    if original_finding_ids is not None:
        new_high_ids = _high_severity_ids(new_findings)
        original_high_or_any = original_finding_ids  # all originals
        new_high = new_high_ids - original_high_or_any
        if new_high:
            return ValidationResult(
                passed=False, stage="rescan",
                error=f"Patch introduced {len(new_high)} new CRITICAL/HIGH finding(s)",
                details={
                    "new_findings": list(new_high),
                    "total_findings_before": len(original_finding_ids),
                    "total_findings_after": len(new_findings),
                },
            )

    # All clear
    removed_count = 0
    if original_finding_ids:
        removed_count = len(original_finding_ids - new_ids)

    return ValidationResult(
        passed=True, stage="rescan",
        details={
            "target_finding_id": target_finding_id,
            "target_removed": True,
            "findings_before": len(original_finding_ids) if original_finding_ids else "unknown",
            "findings_after": len(new_findings),
            "total_removed": removed_count,
            "new_criticals": 0,
        },
    )
