#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.
"""
Enzo Global Knowledge Database
═══════════════════════════════

Location:  ~/.reachable/enzo/knowledge.db
Scope:     ALL repositories — cross-repo intelligence
Owner:     Enzo (no other module reads or writes this)

╔══════════════════════════════════════════════════════════════════════╗
║                      KNOWLEDGE ARCHITECTURE                         ║
║                                                                     ║
║   Per-repo enzo.db        Global knowledge.db        reach-cloud    ║
║   ┌──────────────┐        ┌──────────────────┐       ┌──────────┐  ║
║   │ repo A       │───────▶│                  │──────▶│ Shared   │  ║
║   │ attempts     │  learn │  fix_patterns    │export │ patterns │  ║
║   └──────────────┘        │  upgrade_intel   │       │ across   │  ║
║   ┌──────────────┐        │  build_errors    │◀──────│ all      │  ║
║   │ repo B       │───────▶│  model_perf      │import │ customers│  ║
║   │ attempts     │  learn │  strategy_cache  │       └──────────┘  ║
║   └──────────────┘        └──────────────────┘          (v2)       ║
║   ┌──────────────┐              ▲                                   ║
║   │ repo C       │──────────────┘                                   ║
║   │ attempts     │  learn                                           ║
║   └──────────────┘                                                  ║
╚══════════════════════════════════════════════════════════════════════╝

TABLES
──────

1. fix_patterns
   What works for which vulnerability class.  The core intelligence table.

   "CWE-89 in Python/Flask → parameterized queries: 12/14 success"
   "CWE-79 in React → DOMPurify sanitization: 23/25 success"
   "CVE dependency upgrades in npm → lockfile rebuild: 98% success"

   Keyed on (cwe_id, language, framework, strategy).  Accumulated from
   every remediation attempt across all repos.  The LLM context builder
   queries this before generating a patch: "here is what has worked."

2. upgrade_intel
   Dependency version transition intelligence.

   "lodash 4.17.15 → 4.17.21: 8 repos, 0 build failures, 0 test failures"
   "urllib3 1.26.x → 2.0.x: 3 repos, 2 build failures (API change)"

   Keyed on (package_name, ecosystem, from_version, to_version).  Tells
   Enzo whether a specific version bump is safe or risky before attempting
   it.  Version ranges are normalised to major.minor for grouping.

3. build_errors
   Common build/test failure patterns and their resolutions.

   "ImportError: cannot import name 'X' from 'Y' → version mismatch,
    try pinning Y to compatible range"

   Keyed on (error_signature, language, ecosystem).  error_signature is
   a normalised fingerprint of the error message (strip paths, versions,
   keep structure).  When a patch fails validation, Enzo looks here
   before retrying — if we've seen this error before, inject the
   resolution hint into the retry prompt.

4. model_performance
   Which models succeed at which fix types.

   "qwen2.5-coder:32b + code_patch + python: 78% success"
   "claude-sonnet-4-5 strategy + local patch: 91% for dependency_upgrade"

   Drives model selection recommendations and auto-fallback.

5. strategy_cache
   Cloud model responses cached by context fingerprint.

   When the cloud model returns a fix strategy for "CWE-89 in Flask with
   entry→app→sink_danger path shape", cache it.  Next time we see the
   same context fingerprint, skip the API call.  TTL-based expiry.

   Keyed on context_hash (SHA-256 of RemediationContext.to_prompt_block()).
   This is NOT a semantic cache — it's exact-match on the metadata envelope.

LEARNING FLOW
─────────────

After every remediation attempt (success or failure), the pipeline calls:

    knowledge.learn_from_attempt(attempt_row, finding, validation_report)

This updates fix_patterns, upgrade_intel, build_errors, and model_performance
in a single transaction.  The knowledge DB gets smarter with every run.

QUERY FLOW
──────────

Before generating a patch, the context builder calls:

    hints = knowledge.get_hints(cwe_id, language, framework, package_name)

Returns: best known strategy, success rate, known-bad version transitions,
common build errors to watch for.  Injected into RemediationContext for
both local and cloud model prompts.

REACH-CLOUD (v2)
─────────────────

Export:  knowledge.export_anonymized() → JSON
  - Strips repo names, file paths, specific version numbers
  - Keeps: CWE ID, language, framework, strategy, success rate, error signatures

Import:  knowledge.import_community(data)
  - Merges community patterns with local knowledge
  - Local experience always takes precedence over community data
  - Community patterns flagged with source='community'
"""

from __future__ import annotations

import hashlib
import json
import logging
import re
import sqlite3
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)

_SCHEMA_VERSION = "1.0"
_DEFAULT_PATH = Path.home() / ".reachable" / "enzo" / "knowledge.db"
_STRATEGY_CACHE_TTL_DAYS = 30


# ═══════════════════════════════════════════════════════════════════════════
#  Schema
# ═══════════════════════════════════════════════════════════════════════════

_SCHEMA_SQL = """\
-- ═══════════════════════════════════════════════════════════════════
--  ENZO GLOBAL KNOWLEDGE SCHEMA v1.0
--  Location: ~/.reachable/enzo/knowledge.db
-- ═══════════════════════════════════════════════════════════════════

-- Meta
CREATE TABLE IF NOT EXISTS enzo_knowledge_meta (
    key   TEXT PRIMARY KEY,
    value TEXT
);

-- ─────────────────────────────────────────────────────────────────
--  1. FIX PATTERNS — what remediation strategies work
-- ─────────────────────────────────────────────────────────────────
--
--  One row per unique (cwe_id, language, framework, strategy) tuple.
--  Counters increment on every attempt.
--
--  Example row:
--    cwe_id=CWE-89, language=python, framework=flask,
--    strategy=parameterized_query, success_count=12, failure_count=2,
--    avg_attempts=1.3, last_success_at=2026-02-28

CREATE TABLE IF NOT EXISTS fix_patterns (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,

    -- Finding class
    finding_type    TEXT NOT NULL,           -- cve | cwe | config | secret
    cwe_id          TEXT,                    -- CWE-89  (NULL for CVEs without CWE)
    language        TEXT NOT NULL,           -- python | javascript | go | java
    framework       TEXT DEFAULT '',         -- flask | express | spring | ''
    ecosystem       TEXT DEFAULT '',         -- pip | npm | go | maven

    -- Strategy
    fix_type        TEXT NOT NULL,           -- dependency_upgrade | code_patch | ...
    strategy        TEXT NOT NULL,           -- human-readable: "parameterized_query"
    strategy_detail TEXT,                    -- longer description / prompt snippet

    -- Counters
    success_count   INTEGER DEFAULT 0,
    failure_count   INTEGER DEFAULT 0,
    avg_attempts    REAL    DEFAULT 0.0,     -- average attempts-to-success
    total_attempts  INTEGER DEFAULT 0,       -- raw attempt count for avg calc

    -- Timestamps
    first_seen_at   DATETIME DEFAULT CURRENT_TIMESTAMP,
    last_success_at DATETIME,
    last_failure_at DATETIME,
    last_used_at    DATETIME DEFAULT CURRENT_TIMESTAMP,

    -- Provenance
    source          TEXT DEFAULT 'local',    -- local | community (v2: reach-cloud)

    UNIQUE(finding_type, cwe_id, language, framework, ecosystem, fix_type, strategy)
);

CREATE INDEX IF NOT EXISTS idx_fp_lookup
    ON fix_patterns(cwe_id, language, framework);
CREATE INDEX IF NOT EXISTS idx_fp_success
    ON fix_patterns(success_count DESC);


-- ─────────────────────────────────────────────────────────────────
--  2. UPGRADE INTEL — dependency version transition safety data
-- ─────────────────────────────────────────────────────────────────
--
--  "lodash 4.17.15 → 4.17.21: 8 attempts, 0 build failures"
--  "urllib3 1.x → 2.x: 3 attempts, 2 build failures (breaking API)"
--
--  from_version / to_version are normalised (see _normalise_version).

CREATE TABLE IF NOT EXISTS upgrade_intel (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,

    package_name    TEXT NOT NULL,
    ecosystem       TEXT NOT NULL,           -- npm | pip | go | maven
    from_version    TEXT NOT NULL,           -- normalised: "4.17.15" or "4.17.x"
    to_version      TEXT NOT NULL,

    -- Outcomes
    attempt_count   INTEGER DEFAULT 0,
    build_pass      INTEGER DEFAULT 0,
    build_fail      INTEGER DEFAULT 0,
    test_pass       INTEGER DEFAULT 0,
    test_fail       INTEGER DEFAULT 0,
    rescan_pass     INTEGER DEFAULT 0,
    rescan_fail     INTEGER DEFAULT 0,

    -- Known issues (JSON array of error signatures seen)
    known_issues    TEXT DEFAULT '[]',

    -- Is this a major version bump with breaking changes?
    is_major_bump   INTEGER DEFAULT 0,
    breaking_notes  TEXT,                    -- human-readable notes

    first_seen_at   DATETIME DEFAULT CURRENT_TIMESTAMP,
    last_seen_at    DATETIME DEFAULT CURRENT_TIMESTAMP,

    source          TEXT DEFAULT 'local',

    UNIQUE(package_name, ecosystem, from_version, to_version)
);

CREATE INDEX IF NOT EXISTS idx_ui_pkg
    ON upgrade_intel(package_name, ecosystem);


-- ─────────────────────────────────────────────────────────────────
--  3. BUILD ERRORS — common failure patterns and resolutions
-- ─────────────────────────────────────────────────────────────────
--
--  error_signature: normalised fingerprint of the error
--    "ImportError: cannot import name {X} from {Y}"
--    "ERESOLVE unable to resolve dependency tree"
--
--  resolution: what fixed it (injected into retry prompt)

CREATE TABLE IF NOT EXISTS build_errors (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,

    error_signature TEXT NOT NULL,           -- normalised error pattern
    error_stage     TEXT NOT NULL,           -- build | test | rescan
    language        TEXT DEFAULT '',
    ecosystem       TEXT DEFAULT '',

    -- How often seen
    occurrence_count INTEGER DEFAULT 1,

    -- Resolution (if known)
    resolution       TEXT,                   -- human-readable fix hint
    resolution_count INTEGER DEFAULT 0,      -- how many times resolution worked

    -- Raw examples (JSON array, capped at 5)
    examples         TEXT DEFAULT '[]',

    first_seen_at    DATETIME DEFAULT CURRENT_TIMESTAMP,
    last_seen_at     DATETIME DEFAULT CURRENT_TIMESTAMP,

    source           TEXT DEFAULT 'local',

    UNIQUE(error_signature, error_stage, language, ecosystem)
);

CREATE INDEX IF NOT EXISTS idx_be_sig
    ON build_errors(error_signature);


-- ─────────────────────────────────────────────────────────────────
--  4. MODEL PERFORMANCE — which models succeed at which tasks
-- ─────────────────────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS model_performance (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,

    model_name      TEXT NOT NULL,           -- qwen2.5-coder:32b | claude-sonnet-4-5
    model_role      TEXT NOT NULL,           -- local | cloud | hybrid
    fix_type        TEXT NOT NULL,           -- dependency_upgrade | code_patch | ...
    language        TEXT DEFAULT '',

    success_count   INTEGER DEFAULT 0,
    failure_count   INTEGER DEFAULT 0,
    avg_latency_ms  REAL DEFAULT 0.0,
    total_runs      INTEGER DEFAULT 0,

    last_used_at    DATETIME DEFAULT CURRENT_TIMESTAMP,

    UNIQUE(model_name, model_role, fix_type, language)
);


-- ─────────────────────────────────────────────────────────────────
--  5. STRATEGY CACHE — cached cloud model responses
-- ─────────────────────────────────────────────────────────────────
--
--  Keyed on SHA-256 of the RemediationContext prompt block.
--  Exact-match, not semantic.  TTL-based expiry.

CREATE TABLE IF NOT EXISTS strategy_cache (
    context_hash    TEXT PRIMARY KEY,        -- SHA-256 of context prompt block
    fix_type        TEXT NOT NULL,
    cwe_id          TEXT,
    language        TEXT,

    -- Cached response
    strategy_json   TEXT NOT NULL,           -- full cloud model response

    -- Metadata
    model_used      TEXT,
    hit_count       INTEGER DEFAULT 0,

    created_at      DATETIME DEFAULT CURRENT_TIMESTAMP,
    expires_at      DATETIME NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_sc_expiry
    ON strategy_cache(expires_at);
"""


# ═══════════════════════════════════════════════════════════════════════════
#  Helpers
# ═══════════════════════════════════════════════════════════════════════════

def _normalise_error(raw_error: str) -> str:
    """
    Collapse a raw build/test error into a stable signature.

    Strips:
      - absolute paths                 /home/user/project/src/foo.py → {path}
      - version numbers                4.17.15 → {ver}
      - line numbers                   line 42 → line {n}
      - hex addresses                  0x7fff... → {addr}
      - timestamps                     2026-02-28T... → {ts}

    Keeps structure so the same class of error always produces the same sig.
    """
    s = raw_error.strip()
    if not s:
        return ""
    # Paths (unix + windows), then collapse parens around placeholder
    s = re.sub(r'(?:/[\w.\-]+){2,}', '{path}', s)
    s = re.sub(r'[A-Z]:\\(?:[\w.\-]+\\){1,}', '{path}', s)
    s = re.sub(r'\(\{path\}\)', '{path}', s)
    # Semver
    s = re.sub(r'\d+\.\d+\.\d+(?:[-+][\w.]+)?', '{ver}', s)
    # Line numbers
    s = re.sub(r'line \d+', 'line {n}', s, flags=re.IGNORECASE)
    # Hex addresses
    s = re.sub(r'0x[0-9a-fA-F]+', '{addr}', s)
    # ISO timestamps
    s = re.sub(r'\d{4}-\d{2}-\d{2}[T ]\d{2}:\d{2}[:\d.]*\w*', '{ts}', s)
    # Collapse whitespace
    s = re.sub(r'\s+', ' ', s).strip()
    # Take first 500 chars
    return s[:500]


def _normalise_version(version: str) -> str:
    """Normalise version for grouping.  Keep major.minor.patch if present."""
    if not version:
        return ""
    # Strip leading v
    v = version.lstrip("v").strip()
    # For pseudo-versions (Go), take first 3 segments
    parts = re.split(r'[.\-+]', v)
    # Return up to major.minor.patch
    return ".".join(parts[:3])


def _is_major_bump(from_v: str, to_v: str) -> bool:
    """Detect major version change."""
    try:
        f_major = int(from_v.split(".")[0])
        t_major = int(to_v.split(".")[0])
        return t_major > f_major
    except (ValueError, IndexError):
        return False


def _context_hash(prompt_block: str) -> str:
    return hashlib.sha256(prompt_block.encode("utf-8")).hexdigest()


# ═══════════════════════════════════════════════════════════════════════════
#  EnzoKnowledgeDB
# ═══════════════════════════════════════════════════════════════════════════

class EnzoKnowledgeDB:
    """
    Global knowledge database.  One instance shared across all repos.

    Usage::

        kb = EnzoKnowledgeDB()            # uses default path
        kb = EnzoKnowledgeDB(custom_path) # override for testing

        # Before patching — get hints
        hints = kb.get_hints(cwe_id="CWE-89", language="python", framework="flask")

        # After attempt — learn
        kb.learn_from_attempt(finding, fix_type, strategy, status, validation, model_info)

        # Cache cloud strategy
        kb.cache_strategy(context_prompt, response_json, ...)
        cached = kb.get_cached_strategy(context_prompt)
    """

    def __init__(self, db_path: Optional[Path] = None):
        self.db_path = Path(db_path) if db_path else _DEFAULT_PATH
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self.conn: Optional[sqlite3.Connection] = None
        self._init()

    def _init(self):
        self.conn = sqlite3.connect(str(self.db_path), timeout=30)
        self.conn.row_factory = sqlite3.Row
        self.conn.execute("PRAGMA journal_mode=WAL")
        self.conn.execute("PRAGMA busy_timeout=30000")
        self.conn.executescript(_SCHEMA_SQL)
        self.conn.execute(
            "INSERT OR REPLACE INTO enzo_knowledge_meta(key, value) VALUES (?, ?)",
            ("schema_version", _SCHEMA_VERSION),
        )
        self.conn.commit()

    # ═══════════════════════════════════════════════════════════════════
    #  LEARN — called after every remediation attempt
    # ═══════════════════════════════════════════════════════════════════

    def learn_from_attempt(
        self,
        *,
        # Finding identity
        finding_type: str,
        cwe_id: Optional[str] = None,
        language: str = "",
        framework: str = "",
        ecosystem: str = "",
        # Fix
        fix_type: str,
        strategy: str,
        strategy_detail: Optional[str] = None,
        # Outcome
        success: bool,
        attempts_taken: int = 1,
        # Validation detail
        rescan_passed: Optional[bool] = None,
        build_passed: Optional[bool] = None,
        test_passed: Optional[bool] = None,
        build_error: Optional[str] = None,
        test_error: Optional[str] = None,
        # Package (for upgrade_intel)
        package_name: Optional[str] = None,
        from_version: Optional[str] = None,
        to_version: Optional[str] = None,
        # Model
        model_name: Optional[str] = None,
        model_role: str = "local",
        latency_ms: Optional[float] = None,
    ):
        """
        Single call after every remediation attempt.  Updates all relevant
        knowledge tables in one transaction.
        """
        now = datetime.now().isoformat()

        try:
            with self.conn:
                # ── 1. fix_patterns ───────────────────────────────────
                self._upsert_fix_pattern(
                    finding_type=finding_type,
                    cwe_id=cwe_id or "",
                    language=language,
                    framework=framework or "",
                    ecosystem=ecosystem or "",
                    fix_type=fix_type,
                    strategy=strategy,
                    strategy_detail=strategy_detail,
                    success=success,
                    attempts_taken=attempts_taken,
                    now=now,
                )

                # ── 2. upgrade_intel (if dependency upgrade) ──────────
                if (
                    fix_type == "dependency_upgrade"
                    and package_name
                    and from_version
                    and to_version
                ):
                    self._upsert_upgrade_intel(
                        package_name=package_name,
                        ecosystem=ecosystem or "",
                        from_version=_normalise_version(from_version),
                        to_version=_normalise_version(to_version),
                        rescan_passed=rescan_passed,
                        build_passed=build_passed,
                        test_passed=test_passed,
                        build_error=build_error,
                        now=now,
                    )

                # ── 3. build_errors (if validation failed) ────────────
                if build_error and build_passed is not True:
                    self._record_build_error(
                        raw_error=build_error,
                        stage="build",
                        language=language,
                        ecosystem=ecosystem or "",
                        resolution=None,
                        now=now,
                    )
                if test_error and test_passed is not True:
                    self._record_build_error(
                        raw_error=test_error,
                        stage="test",
                        language=language,
                        ecosystem=ecosystem or "",
                        resolution=None,
                        now=now,
                    )

                # ── 4. model_performance ──────────────────────────────
                if model_name:
                    self._upsert_model_perf(
                        model_name=model_name,
                        model_role=model_role,
                        fix_type=fix_type,
                        language=language,
                        success=success,
                        latency_ms=latency_ms,
                        now=now,
                    )

        except Exception as exc:
            logger.error("Knowledge DB learn failed: %s", exc, exc_info=True)

    # ── Internal upserts ──────────────────────────────────────────────

    def _upsert_fix_pattern(
        self, *, finding_type, cwe_id, language, framework, ecosystem,
        fix_type, strategy, strategy_detail, success, attempts_taken, now,
    ):
        # Guard against NULL — fix_patterns.language has a NOT NULL constraint.
        language = language or "unknown"
        row = self.conn.execute(
            """SELECT id, success_count, failure_count, total_attempts, avg_attempts
               FROM fix_patterns
               WHERE finding_type=? AND cwe_id=? AND language=?
                 AND framework=? AND ecosystem=? AND fix_type=? AND strategy=?""",
            (finding_type, cwe_id, language, framework, ecosystem, fix_type, strategy),
        ).fetchone()

        if row:
            sc = row["success_count"] + (1 if success else 0)
            fc = row["failure_count"] + (0 if success else 1)
            ta = row["total_attempts"] + attempts_taken
            total_successes = sc
            avg = ta / max(total_successes, 1) if total_successes > 0 else 0
            updates = {
                "success_count": sc,
                "failure_count": fc,
                "total_attempts": ta,
                "avg_attempts": round(avg, 2),
                "last_used_at": now,
                "source": "local",  # always promote to local on real usage
            }
            if success:
                updates["last_success_at"] = now
            else:
                updates["last_failure_at"] = now
            if strategy_detail:
                updates["strategy_detail"] = strategy_detail
            set_clause = ", ".join(f"{k}=?" for k in updates)
            self.conn.execute(
                f"UPDATE fix_patterns SET {set_clause} WHERE id=?",
                [*updates.values(), row["id"]],
            )
        else:
            self.conn.execute(
                """INSERT INTO fix_patterns
                   (finding_type, cwe_id, language, framework, ecosystem,
                    fix_type, strategy, strategy_detail,
                    success_count, failure_count, total_attempts, avg_attempts,
                    first_seen_at, last_used_at, last_success_at, last_failure_at)
                   VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                (
                    finding_type, cwe_id, language, framework, ecosystem,
                    fix_type, strategy, strategy_detail,
                    1 if success else 0,
                    0 if success else 1,
                    attempts_taken,
                    float(attempts_taken) if success else 0.0,
                    now, now,
                    now if success else None,
                    None if success else now,
                ),
            )

    def _upsert_upgrade_intel(
        self, *, package_name, ecosystem, from_version, to_version,
        rescan_passed, build_passed, test_passed, build_error, now,
    ):
        row = self.conn.execute(
            """SELECT id, attempt_count, build_pass, build_fail,
                      test_pass, test_fail, rescan_pass, rescan_fail,
                      known_issues
               FROM upgrade_intel
               WHERE package_name=? AND ecosystem=? AND from_version=? AND to_version=?""",
            (package_name, ecosystem, from_version, to_version),
        ).fetchone()

        bp = 1 if build_passed else 0
        bf = 1 if build_passed is False else 0
        tp = 1 if test_passed else 0
        tf = 1 if test_passed is False else 0
        rp = 1 if rescan_passed else 0
        rf = 1 if rescan_passed is False else 0

        if row:
            try:
                known = json.loads(row["known_issues"] or "[]")
            except (json.JSONDecodeError, TypeError):
                known = []
            if build_error:
                sig = _normalise_error(build_error)
                if sig and sig not in known:
                    known.append(sig)
                    known = known[-10:]  # cap at 10

            self.conn.execute(
                """UPDATE upgrade_intel SET
                     attempt_count = attempt_count + 1,
                     build_pass  = build_pass  + ?,
                     build_fail  = build_fail  + ?,
                     test_pass   = test_pass   + ?,
                     test_fail   = test_fail   + ?,
                     rescan_pass = rescan_pass + ?,
                     rescan_fail = rescan_fail + ?,
                     known_issues = ?,
                     is_major_bump = ?,
                     last_seen_at = ?
                   WHERE id = ?""",
                (bp, bf, tp, tf, rp, rf,
                 json.dumps(known),
                 1 if _is_major_bump(from_version, to_version) else 0,
                 now, row["id"]),
            )
        else:
            known = []
            if build_error:
                sig = _normalise_error(build_error)
                if sig:
                    known.append(sig)
            self.conn.execute(
                """INSERT INTO upgrade_intel
                   (package_name, ecosystem, from_version, to_version,
                    attempt_count, build_pass, build_fail, test_pass, test_fail,
                    rescan_pass, rescan_fail, known_issues, is_major_bump,
                    first_seen_at, last_seen_at)
                   VALUES (?,?,?,?,1,?,?,?,?,?,?,?,?,?,?)""",
                (package_name, ecosystem, from_version, to_version,
                 bp, bf, tp, tf, rp, rf,
                 json.dumps(known),
                 1 if _is_major_bump(from_version, to_version) else 0,
                 now, now),
            )

    def _record_build_error(
        self, *, raw_error, stage, language, ecosystem, resolution, now,
    ):
        sig = _normalise_error(raw_error)
        if not sig:
            return

        row = self.conn.execute(
            """SELECT id, occurrence_count, examples
               FROM build_errors
               WHERE error_signature=? AND error_stage=?
                 AND language=? AND ecosystem=?""",
            (sig, stage, language, ecosystem),
        ).fetchone()

        if row:
            try:
                examples = json.loads(row["examples"] or "[]")
            except (json.JSONDecodeError, TypeError):
                examples = []
            # Keep up to 5 raw examples for debugging
            trimmed = raw_error.strip()[:1000]
            if trimmed not in examples:
                examples.append(trimmed)
                examples = examples[-5:]
            updates = {
                "occurrence_count": row["occurrence_count"] + 1,
                "examples": json.dumps(examples),
                "last_seen_at": now,
            }
            if resolution:
                updates["resolution"] = resolution
                updates["resolution_count"] = "(SELECT resolution_count + 1 FROM build_errors WHERE id=?)"
            set_clause = ", ".join(f"{k}=?" for k in updates)
            self.conn.execute(
                f"UPDATE build_errors SET {set_clause} WHERE id=?",
                [*updates.values(), row["id"]],
            )
        else:
            self.conn.execute(
                """INSERT INTO build_errors
                   (error_signature, error_stage, language, ecosystem,
                    occurrence_count, resolution, resolution_count,
                    examples, first_seen_at, last_seen_at)
                   VALUES (?,?,?,?,1,?,0,?,?,?)""",
                (sig, stage, language, ecosystem,
                 resolution,
                 json.dumps([raw_error.strip()[:1000]]),
                 now, now),
            )

    def _upsert_model_perf(
        self, *, model_name, model_role, fix_type, language, success, latency_ms, now,
    ):
        row = self.conn.execute(
            """SELECT id, success_count, failure_count, avg_latency_ms, total_runs
               FROM model_performance
               WHERE model_name=? AND model_role=? AND fix_type=? AND language=?""",
            (model_name, model_role, fix_type, language),
        ).fetchone()

        if row:
            sc = row["success_count"] + (1 if success else 0)
            fc = row["failure_count"] + (0 if success else 1)
            tr = row["total_runs"] + 1
            if latency_ms is not None:
                avg_lat = ((row["avg_latency_ms"] * row["total_runs"]) + latency_ms) / tr
            else:
                avg_lat = row["avg_latency_ms"]
            self.conn.execute(
                """UPDATE model_performance SET
                     success_count=?, failure_count=?, avg_latency_ms=?,
                     total_runs=?, last_used_at=?
                   WHERE id=?""",
                (sc, fc, round(avg_lat, 1), tr, now, row["id"]),
            )
        else:
            self.conn.execute(
                """INSERT INTO model_performance
                   (model_name, model_role, fix_type, language,
                    success_count, failure_count, avg_latency_ms, total_runs,
                    last_used_at)
                   VALUES (?,?,?,?,?,?,?,1,?)""",
                (model_name, model_role, fix_type, language,
                 1 if success else 0, 0 if success else 1,
                 latency_ms or 0.0, now),
            )

    # ═══════════════════════════════════════════════════════════════════
    #  LEARN — record that a resolution worked for a build error
    # ═══════════════════════════════════════════════════════════════════

    def record_error_resolution(
        self, raw_error: str, stage: str, language: str, ecosystem: str,
        resolution: str,
    ):
        """Call when a retry succeeds after a build/test error."""
        sig = _normalise_error(raw_error)
        if not sig:
            return
        self.conn.execute(
            """UPDATE build_errors
               SET resolution = ?, resolution_count = resolution_count + 1
               WHERE error_signature = ? AND error_stage = ?
                 AND language = ? AND ecosystem = ?""",
            (resolution, sig, stage, language, ecosystem),
        )
        self.conn.commit()

    # ═══════════════════════════════════════════════════════════════════
    #  QUERY — get hints before patching
    # ═══════════════════════════════════════════════════════════════════

    def get_fix_hints(
        self,
        cwe_id: Optional[str] = None,
        finding_type: str = "",
        language: str = "",
        framework: str = "",
        ecosystem: str = "",
        fix_type: Optional[str] = None,
        limit: int = 5,
    ) -> List[Dict[str, Any]]:
        """
        Get best known fix patterns for a vulnerability class.

        Returns rows ordered by success rate descending.
        """
        query = "SELECT * FROM fix_patterns WHERE 1=1"
        params: List[Any] = []

        if cwe_id:
            query += " AND cwe_id = ?"
            params.append(cwe_id)
        if finding_type:
            query += " AND finding_type = ?"
            params.append(finding_type)
        if language:
            query += " AND language = ?"
            params.append(language)
        if framework:
            query += " AND framework = ?"
            params.append(framework)
        if ecosystem:
            query += " AND ecosystem = ?"
            params.append(ecosystem)
        if fix_type:
            query += " AND fix_type = ?"
            params.append(fix_type)

        # Order by success rate (success / total), then recency
        query += """
            ORDER BY
                CASE WHEN (success_count + failure_count) > 0
                     THEN CAST(success_count AS REAL) / (success_count + failure_count)
                     ELSE 0 END DESC,
                last_used_at DESC
            LIMIT ?
        """
        params.append(limit)
        return [dict(r) for r in self.conn.execute(query, params).fetchall()]

    def get_best_strategy(
        self,
        cwe_id: Optional[str] = None,
        finding_type: str = "",
        language: str = "",
        framework: str = "",
    ) -> Optional[Dict[str, Any]]:
        """Get the single best-performing strategy, or None."""
        hits = self.get_fix_hints(
            cwe_id=cwe_id, finding_type=finding_type,
            language=language, framework=framework, limit=1,
        )
        return hits[0] if hits else None

    def get_upgrade_safety(
        self, package_name: str, ecosystem: str,
        from_version: Optional[str] = None, to_version: Optional[str] = None,
    ) -> Optional[Dict[str, Any]]:
        """
        Check if a specific version upgrade is known-safe.

        Returns upgrade_intel row with success rates, or None if unknown.
        """
        query = "SELECT * FROM upgrade_intel WHERE package_name=? AND ecosystem=?"
        params: List[Any] = [package_name, ecosystem]

        if from_version:
            query += " AND from_version=?"
            params.append(_normalise_version(from_version))
        if to_version:
            query += " AND to_version=?"
            params.append(_normalise_version(to_version))

        query += " ORDER BY attempt_count DESC LIMIT 1"
        row = self.conn.execute(query, params).fetchone()
        if row:
            d = dict(row)
            total = d["build_pass"] + d["build_fail"]
            d["build_success_rate"] = d["build_pass"] / total if total > 0 else None
            total_t = d["test_pass"] + d["test_fail"]
            d["test_success_rate"] = d["test_pass"] / total_t if total_t > 0 else None
            try:
                d["known_issues"] = json.loads(d["known_issues"] or "[]")
            except (json.JSONDecodeError, TypeError):
                d["known_issues"] = []
            return d
        return None

    def get_error_hints(
        self, raw_error: str, stage: str = "",
        language: str = "", ecosystem: str = "",
    ) -> Optional[Dict[str, Any]]:
        """
        Look up a build/test error to see if we have a known resolution.
        """
        sig = _normalise_error(raw_error)
        if not sig:
            return None

        query = "SELECT * FROM build_errors WHERE error_signature=?"
        params: List[Any] = [sig]
        if stage:
            query += " AND error_stage=?"
            params.append(stage)
        if language:
            query += " AND language=?"
            params.append(language)

        query += " ORDER BY resolution_count DESC LIMIT 1"
        row = self.conn.execute(query, params).fetchone()
        return dict(row) if row else None

    def get_model_recommendation(
        self, fix_type: str, language: str = "",
    ) -> Optional[Dict[str, Any]]:
        """
        Which model has the best track record for this fix type?
        """
        query = """
            SELECT *,
                   CASE WHEN (success_count + failure_count) > 0
                        THEN CAST(success_count AS REAL) / (success_count + failure_count)
                        ELSE 0 END as success_rate
            FROM model_performance
            WHERE fix_type = ?
        """
        params: List[Any] = [fix_type]
        if language:
            query += " AND language = ?"
            params.append(language)
        query += " ORDER BY success_rate DESC, total_runs DESC LIMIT 1"
        row = self.conn.execute(query, params).fetchone()
        return dict(row) if row else None

    # ═══════════════════════════════════════════════════════════════════
    #  STRATEGY CACHE — avoid repeat cloud API calls
    # ═══════════════════════════════════════════════════════════════════

    def cache_strategy(
        self, context_prompt: str, strategy_json: str,
        fix_type: str = "", cwe_id: Optional[str] = None,
        language: Optional[str] = None, model_used: Optional[str] = None,
        ttl_days: int = _STRATEGY_CACHE_TTL_DAYS,
    ):
        """Cache a cloud model strategy response."""
        h = _context_hash(context_prompt)
        expires = (datetime.now() + timedelta(days=ttl_days)).isoformat()
        self.conn.execute(
            """INSERT OR REPLACE INTO strategy_cache
               (context_hash, fix_type, cwe_id, language,
                strategy_json, model_used, hit_count, created_at, expires_at)
               VALUES (?,?,?,?,?,?,0,?,?)""",
            (h, fix_type, cwe_id, language, strategy_json, model_used,
             datetime.now().isoformat(), expires),
        )
        self.conn.commit()

    def get_cached_strategy(self, context_prompt: str) -> Optional[str]:
        """
        Look up cached cloud strategy.  Returns JSON string or None.
        Automatically skips expired entries.
        """
        h = _context_hash(context_prompt)
        row = self.conn.execute(
            """SELECT strategy_json FROM strategy_cache
               WHERE context_hash = ? AND expires_at > ?""",
            (h, datetime.now().isoformat()),
        ).fetchone()
        if row:
            self.conn.execute(
                "UPDATE strategy_cache SET hit_count = hit_count + 1 WHERE context_hash = ?",
                (h,),
            )
            self.conn.commit()
            return row["strategy_json"]
        return None

    def prune_expired_cache(self):
        """Remove expired strategy cache entries."""
        self.conn.execute(
            "DELETE FROM strategy_cache WHERE expires_at < ?",
            (datetime.now().isoformat(),),
        )
        self.conn.commit()

    # ═══════════════════════════════════════════════════════════════════
    #  EXPORT / IMPORT — reach-cloud (v2)
    # ═══════════════════════════════════════════════════════════════════

    def export_anonymized(self) -> Dict[str, Any]:
        """
        Export knowledge for reach-cloud sharing.

        Strips:
          - No repo names ever stored in knowledge.db
          - No file paths ever stored
          - raw error examples truncated
          - Package names preserved (public info)
          - CWE/CVE IDs preserved (public info)

        Returns a JSON-serialisable dict.
        """
        fix_patterns = [
            dict(r) for r in self.conn.execute(
                """SELECT finding_type, cwe_id, language, framework, ecosystem,
                          fix_type, strategy, strategy_detail,
                          success_count, failure_count, avg_attempts
                   FROM fix_patterns
                   WHERE source = 'local' AND (success_count + failure_count) >= 3"""
            ).fetchall()
        ]

        upgrade_intel = [
            dict(r) for r in self.conn.execute(
                """SELECT package_name, ecosystem, from_version, to_version,
                          attempt_count, build_pass, build_fail,
                          test_pass, test_fail, is_major_bump
                   FROM upgrade_intel
                   WHERE source = 'local' AND attempt_count >= 2"""
            ).fetchall()
        ]

        build_errors = [
            dict(r) for r in self.conn.execute(
                """SELECT error_signature, error_stage, language, ecosystem,
                          occurrence_count, resolution, resolution_count
                   FROM build_errors
                   WHERE source = 'local' AND resolution IS NOT NULL
                     AND resolution_count >= 2"""
            ).fetchall()
        ]

        return {
            "schema_version": _SCHEMA_VERSION,
            "exported_at": datetime.now().isoformat(),
            "fix_patterns": fix_patterns,
            "upgrade_intel": upgrade_intel,
            "build_errors": build_errors,
        }

    def import_community(self, data: Dict[str, Any]):
        """
        Import community patterns from reach-cloud.

        Community data never overwrites local data.
        Community rows are tagged source='community'.
        """
        now = datetime.now().isoformat()

        for fp in data.get("fix_patterns", []):
            # Only insert if we don't have a local entry
            existing = self.conn.execute(
                """SELECT id FROM fix_patterns
                   WHERE finding_type=? AND cwe_id=? AND language=?
                     AND framework=? AND ecosystem=? AND fix_type=? AND strategy=?
                     AND source='local'""",
                (fp["finding_type"], fp.get("cwe_id", ""),
                 fp["language"], fp.get("framework", ""),
                 fp.get("ecosystem", ""), fp["fix_type"], fp["strategy"]),
            ).fetchone()
            if existing:
                continue  # local knowledge takes precedence

            self.conn.execute(
                """INSERT OR REPLACE INTO fix_patterns
                   (finding_type, cwe_id, language, framework, ecosystem,
                    fix_type, strategy, strategy_detail,
                    success_count, failure_count, avg_attempts,
                    first_seen_at, last_used_at, source)
                   VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,'community')""",
                (fp["finding_type"], fp.get("cwe_id", ""),
                 fp["language"], fp.get("framework", ""),
                 fp.get("ecosystem", ""), fp["fix_type"], fp["strategy"],
                 fp.get("strategy_detail"),
                 fp.get("success_count", 0), fp.get("failure_count", 0),
                 fp.get("avg_attempts", 0), now, now),
            )

        for ui in data.get("upgrade_intel", []):
            existing = self.conn.execute(
                """SELECT id FROM upgrade_intel
                   WHERE package_name=? AND ecosystem=?
                     AND from_version=? AND to_version=?
                     AND source='local'""",
                (ui["package_name"], ui["ecosystem"],
                 ui["from_version"], ui["to_version"]),
            ).fetchone()
            if existing:
                continue

            self.conn.execute(
                """INSERT OR REPLACE INTO upgrade_intel
                   (package_name, ecosystem, from_version, to_version,
                    attempt_count, build_pass, build_fail,
                    test_pass, test_fail, is_major_bump,
                    first_seen_at, last_seen_at, source)
                   VALUES (?,?,?,?,?,?,?,?,?,?,?,?,'community')""",
                (ui["package_name"], ui["ecosystem"],
                 ui["from_version"], ui["to_version"],
                 ui.get("attempt_count", 0),
                 ui.get("build_pass", 0), ui.get("build_fail", 0),
                 ui.get("test_pass", 0), ui.get("test_fail", 0),
                 ui.get("is_major_bump", 0), now, now),
            )

        for be in data.get("build_errors", []):
            existing = self.conn.execute(
                """SELECT id FROM build_errors
                   WHERE error_signature=? AND error_stage=?
                     AND language=? AND ecosystem=?
                     AND source='local'""",
                (be["error_signature"], be["error_stage"],
                 be.get("language", ""), be.get("ecosystem", "")),
            ).fetchone()
            if existing:
                continue

            self.conn.execute(
                """INSERT OR REPLACE INTO build_errors
                   (error_signature, error_stage, language, ecosystem,
                    occurrence_count, resolution, resolution_count,
                    examples, first_seen_at, last_seen_at, source)
                   VALUES (?,?,?,?,?,?,?,?,?,?,'community')""",
                (be["error_signature"], be["error_stage"],
                 be.get("language", ""), be.get("ecosystem", ""),
                 be.get("occurrence_count", 0),
                 be.get("resolution"), be.get("resolution_count", 0),
                 "[]", now, now),
            )

        self.conn.commit()
        logger.info(
            "Imported community knowledge: %d patterns, %d upgrades, %d errors",
            len(data.get("fix_patterns", [])),
            len(data.get("upgrade_intel", [])),
            len(data.get("build_errors", [])),
        )

    # ═══════════════════════════════════════════════════════════════════
    #  STATS
    # ═══════════════════════════════════════════════════════════════════

    def get_stats(self) -> Dict[str, Any]:
        """Summary stats for CLI display."""
        def _count(table):
            return self.conn.execute(f"SELECT COUNT(*) as n FROM {table}").fetchone()["n"]  # noqa: S608

        fp_local = self.conn.execute(
            "SELECT COUNT(*) as n FROM fix_patterns WHERE source='local'"
        ).fetchone()["n"]
        fp_community = self.conn.execute(
            "SELECT COUNT(*) as n FROM fix_patterns WHERE source='community'"
        ).fetchone()["n"]

        # Best success rate
        best = self.conn.execute(
            """SELECT strategy, cwe_id, language, framework,
                      success_count, failure_count
               FROM fix_patterns
               WHERE (success_count + failure_count) >= 3
               ORDER BY CAST(success_count AS REAL) / (success_count + failure_count) DESC
               LIMIT 1"""
        ).fetchone()

        return {
            "fix_patterns": {"local": fp_local, "community": fp_community},
            "upgrade_intel": _count("upgrade_intel"),
            "build_errors": _count("build_errors"),
            "model_performance": _count("model_performance"),
            "strategy_cache": _count("strategy_cache"),
            "best_pattern": dict(best) if best else None,
            "db_path": str(self.db_path),
        }

    # ═══════════════════════════════════════════════════════════════════
    #  LIFECYCLE
    # ═══════════════════════════════════════════════════════════════════

    def close(self):
        if self.conn:
            self.conn.close()
            self.conn = None
