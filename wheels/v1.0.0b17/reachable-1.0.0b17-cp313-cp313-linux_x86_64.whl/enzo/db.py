#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.
"""
Per-repo Enzo database — ``enzo.db`` lives as a sibling to ``repo.db``.

    ~/.reachable/scans/{repo-slug}/repo.db     ← scanner owns (READ ONLY)
    ~/.reachable/scans/{repo-slug}/enzo.db     ← Enzo owns

Tracks every remediation attempt for findings in this repository.
"""

from __future__ import annotations

import json
import logging
import sqlite3
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)

_SCHEMA_VERSION = "1.1"

_SCHEMA_SQL = """
-- ═══════════════════════════════════════════════════════════════════
--  ENZO PER-REPO SCHEMA v1.0
-- ═══════════════════════════════════════════════════════════════════

CREATE TABLE IF NOT EXISTS enzo_meta (
    key   TEXT PRIMARY KEY,
    value TEXT
);

CREATE TABLE IF NOT EXISTS remediation_attempts (
    id                INTEGER PRIMARY KEY AUTOINCREMENT,
    scan_id           INTEGER,               -- FK to repo.db scans(id) (not enforced cross-DB)
    finding_id        TEXT NOT NULL,          -- 16-char fingerprint from findings table
    finding_type      TEXT NOT NULL,          -- cve | cwe | config | secret
    severity          TEXT NOT NULL,
    fix_type          TEXT NOT NULL,          -- dependency_upgrade | code_patch | ...

    -- Package context
    package_name      TEXT,
    package_version   TEXT,
    cwe_id            TEXT,
    cve_id            TEXT,

    -- Reachability snapshot
    app_reachability  TEXT,
    epss_score        REAL,
    in_kev            INTEGER DEFAULT 0,

    -- Strategy
    cloud_strategy    TEXT,                   -- JSON from cloud model
    model_local       TEXT,
    model_cloud       TEXT,

    -- Patch
    patch_diff        TEXT,
    files_modified    TEXT,                   -- JSON array

    -- Validation
    rescan_result     TEXT,                   -- PASS | FAIL | SKIP
    build_result      TEXT,
    test_result       TEXT,
    build_error       TEXT,
    test_error        TEXT,

    -- Outcome
    status            TEXT NOT NULL DEFAULT 'pending',  -- pending | success | failed | aborted | manual
    attempt_number    INTEGER DEFAULT 1,
    pr_url            TEXT,
    attestation       TEXT,                   -- JSON signed attestation

    -- Metrics (0.5.7+)
    tokens_in         INTEGER DEFAULT 0,
    tokens_out        INTEGER DEFAULT 0,
    cost_usd          REAL    DEFAULT 0.0,
    duration_ms       INTEGER DEFAULT 0,
    patcher_method    TEXT    DEFAULT 'ai',     -- 'deterministic' | 'ai'

    created_at        DATETIME DEFAULT CURRENT_TIMESTAMP,
    completed_at      DATETIME
);

CREATE INDEX IF NOT EXISTS idx_enzo_finding   ON remediation_attempts(finding_id);
CREATE INDEX IF NOT EXISTS idx_enzo_status    ON remediation_attempts(status);
CREATE INDEX IF NOT EXISTS idx_enzo_scan      ON remediation_attempts(scan_id);
CREATE INDEX IF NOT EXISTS idx_enzo_fix_type  ON remediation_attempts(fix_type);
"""


class EnzoRepoDB:
    """Per-repo enzo.db — sibling to repo.db, never touches repo.db."""

    def __init__(self, repo_db_path: Path):
        """
        Args:
            repo_db_path: Path to the existing repo.db.
                          enzo.db is created in the same directory.
        """
        self.db_path = Path(repo_db_path).parent / "enzo.db"
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self.conn: Optional[sqlite3.Connection] = None
        self._init()

    def _init(self):
        self.conn = sqlite3.connect(str(self.db_path), timeout=30)
        self.conn.row_factory = sqlite3.Row
        self.conn.execute("PRAGMA journal_mode=WAL")
        self.conn.execute("PRAGMA busy_timeout=30000")
        self.conn.executescript(_SCHEMA_SQL)
        # Run migrations for existing DBs that predate new columns
        self._migrate()
        # Store schema version
        self.conn.execute(
            "INSERT OR REPLACE INTO enzo_meta(key, value) VALUES (?, ?)",
            ("schema_version", _SCHEMA_VERSION),
        )
        self.conn.commit()

    def _migrate(self):
        """If schema is outdated, wipe and recreate enzo.db.
        enzo.db is fully reproducible from scans — no user data is lost."""
        import logging as _log
        _logger = _log.getLogger(__name__)
        existing = {row[1] for row in
                    self.conn.execute("PRAGMA table_info(remediation_attempts)").fetchall()}
        required = {"tokens_in", "tokens_out", "cost_usd", "duration_ms", "patcher_method"}
        if not required.issubset(existing):
            _logger.warning(
                "[DB] enzo.db schema outdated — dropping and recreating. "
                "Run history cleared (findings in repo.db unaffected)."
            )
            self.conn.close()
            self.db_path.unlink(missing_ok=True)
            self.conn = sqlite3.connect(str(self.db_path), timeout=30)
            self.conn.row_factory = sqlite3.Row
            self.conn.execute("PRAGMA journal_mode=WAL")
            self.conn.execute("PRAGMA busy_timeout=30000")
            self.conn.executescript(_SCHEMA_SQL)

    # ── Write ─────────────────────────────────────────────────────────────

    def record_attempt(
        self,
        finding_id: str,
        finding_type: str,
        severity: str,
        fix_type: str,
        scan_id: Optional[int] = None,
        **kwargs,
    ) -> int:
        """Insert a new remediation attempt.  Returns the row id."""
        cols = [
            "scan_id", "finding_id", "finding_type", "severity", "fix_type",
        ]
        vals: List[Any] = [scan_id, finding_id, finding_type, severity, fix_type]

        # Optional columns
        _OPTIONAL = [
            "package_name", "package_version", "cwe_id", "cve_id",
            "app_reachability", "epss_score", "in_kev",
            "cloud_strategy", "model_local", "model_cloud",
            "patch_diff", "files_modified",
            "rescan_result", "build_result", "test_result",
            "build_error", "test_error",
            "status", "attempt_number", "pr_url", "attestation",
        ]
        for col in _OPTIONAL:
            if col in kwargs:
                v = kwargs[col]
                # Serialise lists/dicts
                if isinstance(v, (dict, list)):
                    v = json.dumps(v)
                cols.append(col)
                vals.append(v)

        placeholders = ", ".join(["?"] * len(cols))
        col_names = ", ".join(cols)
        cur = self.conn.execute(
            f"INSERT INTO remediation_attempts ({col_names}) VALUES ({placeholders})",
            vals,
        )
        self.conn.commit()
        return cur.lastrowid

    def update_attempt(self, attempt_id: int, **kwargs):
        """Update fields on an existing attempt. Silently skips unknown columns."""
        # Fetch actual columns present in this DB (handles old DBs missing new columns)
        existing_cols = {row[1] for row in
                         self.conn.execute("PRAGMA table_info(remediation_attempts)").fetchall()}
        sets = []
        vals = []
        for k, v in kwargs.items():
            if k not in existing_cols:
                continue  # skip columns not yet in this DB — no crash
            if isinstance(v, (dict, list)):
                v = json.dumps(v)
            sets.append(f"{k} = ?")
            vals.append(v)
        if not sets:
            return
        vals.append(attempt_id)
        self.conn.execute(
            f"UPDATE remediation_attempts SET {', '.join(sets)} WHERE id = ?",
            vals,
        )
        self.conn.commit()

    def complete_attempt(self, attempt_id: int, status: str, **kwargs):
        kwargs["status"] = status
        kwargs["completed_at"] = datetime.now().isoformat()
        self.update_attempt(attempt_id, **kwargs)

    # ── Read ──────────────────────────────────────────────────────────────

    def get_attempts(
        self,
        finding_id: Optional[str] = None,
        status: Optional[str] = None,
        scan_id: Optional[int] = None,
        limit: int = 50,
    ) -> List[Dict[str, Any]]:
        query = "SELECT * FROM remediation_attempts WHERE 1=1"
        params: List[Any] = []
        if finding_id:
            query += " AND finding_id = ?"
            params.append(finding_id)
        if status:
            query += " AND status = ?"
            params.append(status)
        if scan_id:
            query += " AND scan_id = ?"
            params.append(scan_id)
        query += " ORDER BY created_at DESC LIMIT ?"
        params.append(limit)
        return [dict(r) for r in self.conn.execute(query, params).fetchall()]

    def get_last_attempt(self, finding_id: str) -> Optional[Dict[str, Any]]:
        rows = self.get_attempts(finding_id=finding_id, limit=1)
        return rows[0] if rows else None

    def get_attempt_count(self, finding_id: str) -> int:
        row = self.conn.execute(
            "SELECT COUNT(*) as cnt FROM remediation_attempts WHERE finding_id = ?",
            (finding_id,),
        ).fetchone()
        return row["cnt"] if row else 0

    def get_summary(self) -> Dict[str, Any]:
        cur = self.conn.execute("""
            SELECT
                COUNT(*) as total,
                SUM(CASE WHEN status = 'success' THEN 1 ELSE 0 END) as succeeded,
                SUM(CASE WHEN status = 'failed'  THEN 1 ELSE 0 END) as failed,
                SUM(CASE WHEN status = 'manual'  THEN 1 ELSE 0 END) as manual,
                SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) as pending
            FROM remediation_attempts
        """)
        return dict(cur.fetchone())

    # ── Lifecycle ─────────────────────────────────────────────────────────

    def close(self):
        if self.conn:
            self.conn.close()
            self.conn = None
