#!/usr/bin/env python3
# Copyright (c) 2026 Sthenos Security. All rights reserved.
"""
Generate a new Ed25519 keypair for license signing.

Run once. Store private.pem in GitHub Secret STHENOS_LICENSE_SIGNING_KEY
and in 1Password. Update _public_key.py with the printed public key.
Never commit private.pem.
"""

from pathlib import Path

from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
from cryptography.hazmat.primitives.serialization import Encoding, NoEncryption, PrivateFormat, PublicFormat

priv = Ed25519PrivateKey.generate()
pub = priv.public_key()

priv_pem = priv.private_bytes(Encoding.PEM, PrivateFormat.PKCS8, NoEncryption())
pub_pem = pub.public_bytes(Encoding.PEM, PublicFormat.SubjectPublicKeyInfo)

Path("private.pem").write_bytes(priv_pem)
Path("public.pem").write_bytes(pub_pem)

print("=== PUBLIC KEY (embed in reachable/licensing/_public_key.py) ===")
print(pub_pem.decode())
print("=== PRIVATE KEY ===")
print("Written to private.pem")
print()
print("Next steps:")
print("  1. Add private.pem contents to GitHub Secret: STHENOS_LICENSE_SIGNING_KEY")
print("  2. Save private.pem to 1Password vault")
print("  3. Update reachable/licensing/_public_key.py with the public key above")
print("  4. Update reach-secrets/licensing/public.pem")
print("  5. rm private.pem  ← do this last")
