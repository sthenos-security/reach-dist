#!/usr/bin/env python3
# Copyright (c) 2026 Sthenos Security. All rights reserved.
"""
License signing tool — internal use only. NOT shipped in wheel.

Three modes:

  1. Local file (manual signing):
     python tools/licensing/sign_license.py --type trial --days 30 \\
       --private-key /tmp/private.pem --out reachable/licensing/trial_license.json

  2. CI/CD (GitHub Actions — key from env var):
     python tools/licensing/sign_license.py --type trial --days 30 \\
       --private-key-env STHENOS_LICENSE_SIGNING_KEY \\
       --out reachable/licensing/trial_license.json

  3. Interactive (paste key when prompted):
     python tools/licensing/sign_license.py --type trial --days 30 \\
       --out reachable/licensing/trial_license.json

  4. Dev build (no key needed — sets REACHABLE_DEV bypass):
     python tools/licensing/sign_license.py --type dev \\
       --out reachable/licensing/trial_license.json
"""

import argparse
import base64
import json
import os
import sys
import tempfile
import uuid
from datetime import datetime, timedelta, timezone
from pathlib import Path


def sign_license(
    license_type: str,
    private_key_path: str,
    days: int,
    customer: str = None,
    email: str = None,
    features: dict = None,
) -> dict:
    from cryptography.hazmat.primitives.serialization import load_pem_private_key

    priv_pem = Path(private_key_path).read_bytes()
    priv = load_pem_private_key(priv_pem, password=None)

    now = datetime.now(timezone.utc)

    # Trial: relative expiry (expires_at=null, duration_days set)
    # Annual/Enterprise: absolute expiry baked in (reinstall does not reset)
    if license_type == "trial":
        expires_at = None
        duration_days = days
    else:
        expires_at = (now + timedelta(days=days)).strftime("%Y-%m-%dT%H:%M:%SZ")
        duration_days = None

    payload = {
        "license_id": str(uuid.uuid4()),
        "license_type": license_type,
        "issued_at": now.strftime("%Y-%m-%dT%H:%M:%SZ"),
        "duration_days": duration_days,
        "expires_at": expires_at,
        "customer": customer,
        "email": email,
        "features": features,
    }

    canonical = json.dumps(payload, sort_keys=True, separators=(",", ":")).encode()
    sig_bytes = priv.sign(canonical)
    sig_b64 = base64.urlsafe_b64encode(sig_bytes).rstrip(b"=").decode()
    payload["signature"] = sig_b64
    return payload


def main():
    parser = argparse.ArgumentParser(description="Sthenos license signing tool")
    parser.add_argument("--type", required=True, choices=["trial", "annual", "enterprise", "dev"])
    parser.add_argument("--days", type=int, default=30, help="Duration in days")
    parser.add_argument("--customer", default=None, help="Customer name (annual/enterprise)")
    parser.add_argument("--email", default=None, help="Customer email (annual/enterprise)")
    parser.add_argument("--private-key", default=None, help="Path to private.pem (mode 1: local)")
    parser.add_argument("--private-key-env", default=None, help="Env var name containing PEM contents (mode 2: CI/CD)")
    parser.add_argument("--out", required=True, help="Output license.json path")
    parser.add_argument("--features", default=None, help="JSON features object e.g. '{\"ai_security\":true}'")
    args = parser.parse_args()

    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)

    # ── Mode 4: dev build — no key, no signature, verifier bypassed via REACHABLE_DEV ──
    if args.type == "dev":
        dev_license = {
            "license_id": str(uuid.uuid4()),
            "license_type": "dev",
            "issued_at": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
            "duration_days": 36500,
            "expires_at": None,
            "customer": "local-dev",
            "email": None,
            "features": None,
            "signature": "DEV_UNSIGNED",
        }
        out.write_text(json.dumps(dev_license, indent=2))
        print(f"✅ Dev license → {out}  (set REACHABLE_DEV=1 to bypass verification)")
        return

    # ── Resolve private key ──
    key_path = None
    tmp_file = None

    if args.private_key:
        # Mode 1: local file
        if not Path(args.private_key).exists():
            print(f"ERROR: private key not found: {args.private_key}", file=sys.stderr)
            sys.exit(1)
        key_path = args.private_key

    elif args.private_key_env:
        # Mode 2: CI/CD — key from environment variable
        pem = os.environ.get(args.private_key_env, "")
        if not pem:
            print(f"ERROR: env var {args.private_key_env} is not set or empty", file=sys.stderr)
            sys.exit(1)
        tmp_file = tempfile.NamedTemporaryFile(mode="w", suffix=".pem", delete=False)
        tmp_file.write(pem)
        tmp_file.close()
        key_path = tmp_file.name

    else:
        # Mode 3: interactive — paste PEM
        print("Paste private key PEM then press Ctrl-D (Mac/Linux) or Ctrl-Z Enter (Windows):")
        lines = []
        try:
            while True:
                lines.append(input())
        except EOFError:
            pass
        pem = "\n".join(lines)
        if "BEGIN" not in pem:
            print("ERROR: invalid PEM — expected -----BEGIN PRIVATE KEY-----", file=sys.stderr)
            sys.exit(1)
        tmp_file = tempfile.NamedTemporaryFile(mode="w", suffix=".pem", delete=False)
        tmp_file.write(pem)
        tmp_file.close()
        key_path = tmp_file.name

    if args.type != "trial" and not args.customer:
        print("ERROR: --customer is required for annual/enterprise licenses", file=sys.stderr)
        sys.exit(1)

    features = json.loads(args.features) if args.features else None

    try:
        license_data = sign_license(
            license_type=args.type,
            private_key_path=key_path,
            days=args.days,
            customer=args.customer,
            email=args.email,
            features=features,
        )
    finally:
        if tmp_file:
            Path(tmp_file.name).unlink(missing_ok=True)  # always wipe temp key

    out.write_text(json.dumps(license_data, indent=2))

    print(f"✅ License signed → {out}")
    print(f"   Type:     {license_data['license_type']}")
    print(f"   ID:       {license_data['license_id']}")
    print(f"   Customer: {license_data['customer'] or '(trial)'}")
    if license_data["expires_at"]:
        print(f"   Expires:  {license_data['expires_at']}")
    else:
        print(f"   Duration: {license_data['duration_days']} days from first install")


if __name__ == "__main__":
    main()
