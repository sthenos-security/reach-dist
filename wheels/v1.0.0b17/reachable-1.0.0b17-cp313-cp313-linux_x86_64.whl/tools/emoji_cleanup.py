#!/usr/bin/env python3
"""
P2.55 Emoji Cleanup — Replace hardcoded emojis with _e() pattern.

When no_emoji=True (timestamps ON, default CI/CD), _e() returns "" (nothing).
When no_emoji=False (--no-timestamps), _e() returns the emoji.

Usage:
    python3 tools/emoji_cleanup.py              # Dry run
    python3 tools/emoji_cleanup.py --apply      # Apply changes
"""

import os
import sys

BASE = os.path.join(os.path.dirname(__file__), "..", "reachable")
BASE = os.path.abspath(BASE)

# ──────────────────────────────────────────────────────────────
# Emoji detection
# ──────────────────────────────────────────────────────────────

EMOJI_MAP = {
    "\u2705": 1,
    "\u274c": 1,
    "\u26a0\ufe0f": 1,
    "\u26a0": 1,
    "\u2139\ufe0f": 1,
    "\u2139": 1,
    "\U0001f50d": 1,
    "\U0001f4e6": 1,
    "\U0001f4c2": 1,
    "\U0001f4c1": 1,
    "\U0001f4cb": 1,
    "\U0001f4be": 1,
    "\U0001f4a1": 1,
    "\U0001f433": 1,
    "\U0001f512": 1,
    "\U0001f504": 1,
    "\U0001f528": 1,
    "\U0001f4ca": 1,
    "\U0001f6a8": 1,
    "\u23f1\ufe0f": 1,
    "\u23f1": 1,
    "\U0001f9ea": 1,
    "\U0001f5d1\ufe0f": 1,
    "\U0001f5d1": 1,
    "\u2753": 1,
    "\U0001f40d": 1,
    "\U0001f550": 1,
    "\U0001f4c8": 1,
    "\U0001f4c9": 1,
    "\U0001f7e0": 1,
    "\U0001f7e1": 1,
    "\U0001f7e2": 1,
    "\U0001f534": 1,
    "\u26a1": 1,
    "\U0001f527": 1,
    "\U0001f33f": 1,
    "\U0001f4c5": 1,
    "\U0001f4c6": 1,
    "\U0001f522": 1,
    "\u2713": 1,
    "\U0001f6e1\ufe0f": 1,
    "\U0001f6e1": 1,
    "\U0001f9a0": 1,
    "\U0001f511": 1,
    "\U0001f4b0": 1,
    "\U0001f3e0": 1,
    "\u26d4": 1,
    "\U0001f4dd": 1,
    "\U0001f4c4": 1,
    "\U0001f4bb": 1,
    "\U0001f333": 1,
    "\U0001f6ab": 1,
    "\U0001f389": 1,
    "\U0001f680": 1,
    "\U0001f4e1": 1,
    "\U0001f310": 1,
    "\U0001f510": 1,
    "\U0001f195": 1,
    "\U0001f52c": 1,
    "\U0001fa7a": 1,
    "\U0001f9f9": 1,
    "\u23ed\ufe0f": 1,
    "\u23ed": 1,
    "\U0001fa9d": 1,
    "\u2b06\ufe0f": 1,
    "\u2b06": 1,
    "\u2b07\ufe0f": 1,
    "\u2b07": 1,
    "\U0001f3af": 1,
    "\U0001f48e": 1,
    "\U0001f52e": 1,
    "\U0001f9e9": 1,
    "\U0001f4d6": 1,
    "\U0001f3a8": 1,
    "\U0001f4dc": 1,
    "\U0001f4cd": 1,
    "\U0001f3d7\ufe0f": 1,
    "\U0001f3d7": 1,
    "\U0001f48a": 1,
    "\U0001f5c4\ufe0f": 1,
    "\U0001f5c4": 1,
    "\u2728": 1,
}

SKIP_PATTERNS = [
    "_e(",
    "def _e",
    "no_emoji",
    "emoji_char",
    "render_emoji",
    "# Returns",
    ".replace('",
    "EMOJI_MAP",
    "emoji_map",
]


def has_emoji(text):
    for ch in text:
        cp = ord(ch)
        if 0x1F300 <= cp <= 0x1F9FF:
            return True
        if 0x2600 <= cp <= 0x26FF:
            return True
        if 0x2700 <= cp <= 0x27BF:
            return True
        if cp in (
            0x2705,
            0x274C,
            0x2714,
            0x2716,
            0x2139,
            0x231B,
            0x23F0,
            0x23F1,
            0x23F2,
            0x23F3,
            0x2049,
            0x203C,
            0x2753,
            0x2757,
            0x2728,
        ):
            return True
    return False


# ──────────────────────────────────────────────────────────────
# Replacement logic
# ──────────────────────────────────────────────────────────────


def find_emoji_in_line(line):
    found = []
    i = 0
    while i < len(line):
        ch = line[i]
        if i + 1 < len(line) and line[i + 1] == "\ufe0f":
            combo = ch + "\ufe0f"
            if combo in EMOJI_MAP:
                found.append((i, combo))
                i += 2
                continue
        if ch in EMOJI_MAP:
            found.append((i, ch))
            i += 1
            continue
        cp = ord(ch)
        if (
            0x1F300 <= cp <= 0x1F9FF
            or 0x2600 <= cp <= 0x26FF
            or 0x2700 <= cp <= 0x27BF
            or cp in (0x2705, 0x274C, 0x2714, 0x2716, 0x2139, 0x2728)
        ):
            found.append((i, ch))
            i += 1
            continue
        i += 1
    return found


def replace_emojis_in_line(line):
    emojis = find_emoji_in_line(line)
    if not emojis:
        return line, False

    result = line
    changed = False
    for pos, emoji in reversed(emojis):
        before = result[:pos]
        after = result[pos + len(emoji) :]

        # Standalone: '..emoji..' or "..emoji.." (emoji is entire string value)
        if before.endswith("'") and after.startswith("'"):
            result = before[:-1] + f"_e('{emoji}')" + after[1:]
            changed = True
            continue
        elif before.endswith('"') and after.startswith('"'):
            result = before[:-1] + f"_e('{emoji}')" + after[1:]
            changed = True
            continue

        # Inside a string: inject {_e('emoji')}
        result = before + "{_e('" + emoji + "')}" + after
        changed = True

    if changed:
        result = ensure_fstring(result)
    return result, changed


def ensure_fstring(line):
    if "{_e(" not in line:
        return line

    result = []
    i = 0
    while i < len(line):
        if line[i] in ('"', "'"):
            quote = line[i]
            if line[i : i + 3] == quote * 3:
                quote = quote * 3
            is_fstr = i > 0 and line[i - 1] == "f"
            start = i
            i += len(quote)
            while i < len(line):
                if line[i] == "\\":
                    i += 2
                    continue
                if line[i : i + len(quote)] == quote:
                    i += len(quote)
                    break
                i += 1
            string_content = line[start:i]
            if "{_e(" in string_content and not is_fstr:
                result.append(line[:start])
                result.append("f")
                result.append(string_content)
                line = line[i:]
                i = 0
                continue
        i += 1

    if result:
        result.append(line)
        return "".join(result)
    return line


# ──────────────────────────────────────────────────────────────
# Quote nesting fix: f'...{_e('x')}...' -> f"...{_e('x')}..."
# ──────────────────────────────────────────────────────────────


def fix_quote_nesting(filepath):
    with open(filepath) as f:
        lines = f.readlines()
    fixed = 0
    new_lines = []
    for line in lines:
        if "f'" in line and "{_e('" in line:
            result = []
            i = 0
            while i < len(line):
                if i + 1 < len(line) and line[i] == "f" and line[i + 1] == "'":
                    start = i + 2
                    depth = 0
                    j = start
                    while j < len(line):
                        if line[j] == "{":
                            depth += 1
                        elif line[j] == "}":
                            depth -= 1
                        elif line[j] == "'" and depth == 0:
                            content = line[start:j]
                            if "{_e('" in content:
                                result.append('f"')
                                result.append(content)
                                result.append('"')
                                fixed += 1
                            else:
                                result.append("f'")
                                result.append(content)
                                result.append("'")
                            i = j + 1
                            break
                        elif line[j] == "\\":
                            j += 1
                        j += 1
                    else:
                        result.append(line[i:])
                        i = len(line)
                    continue
                result.append(line[i])
                i += 1
            new_lines.append("".join(result))
        else:
            new_lines.append(line)
    if fixed > 0:
        with open(filepath, "w") as f:
            f.writelines(new_lines)
    return fixed


# ──────────────────────────────────────────────────────────────
# _e() helper injection
# ──────────────────────────────────────────────────────────────

E_HELPER_STD = '''
# Emoji helper (respects --no-emoji flag)
def _e(emoji: str, fallback: str = "") -> str:
    """Return emoji or fallback based on no_emoji setting."""
    try:
        from .scan_logger import get_no_emoji
        return fallback if get_no_emoji() else emoji
    except ImportError:
        return emoji

'''

E_HELPER_SUB = '''
# Emoji helper (respects --no-emoji flag)
def _e(emoji: str, fallback: str = "") -> str:
    """Return emoji or fallback based on no_emoji setting."""
    try:
        from ..scan_logger import get_no_emoji
        return fallback if get_no_emoji() else emoji
    except ImportError:
        return emoji

'''


def process_file(filepath, dry_run=False, subpackage=False):
    with open(filepath, "r") as f:
        lines = f.readlines()

    changes = 0
    new_lines = []
    needs_helper = False
    has_helper = any("def _e(" in l for l in lines)

    for line in lines:
        stripped = line.strip()
        if any(p in stripped for p in SKIP_PATTERNS):
            new_lines.append(line)
            continue
        if has_emoji(stripped):
            new_line, changed = replace_emojis_in_line(line)
            if changed:
                changes += 1
                needs_helper = True
            new_lines.append(new_line)
        else:
            new_lines.append(line)

    if changes > 0 and not has_helper and needs_helper:
        helper = E_HELPER_SUB if subpackage else E_HELPER_STD
        insert_idx = 0
        for i, line in enumerate(new_lines):
            s = line.strip()
            if s.startswith("import ") or s.startswith("from ") or s == "" or s.startswith("#"):
                insert_idx = i + 1
            elif s.startswith("logger") or s.startswith("def ") or s.startswith("class "):
                break
        new_lines.insert(insert_idx, helper)

    if not dry_run and changes > 0:
        with open(filepath, "w") as f:
            f.writelines(new_lines)
    return changes


# ──────────────────────────────────────────────────────────────
# File list
# ──────────────────────────────────────────────────────────────

FILES = [
    # (relative path from reachable/, is_subpackage)
    ("cli.py", False),
    ("license.py", False),
    ("audit.py", False),
    ("reachable.py", False),
    ("guarddog_scanner.py", False),
    ("guarddog_setup.py", False),
    ("database_storage.py", False),
    ("db_manager.py", False),
    ("execution_engine.py", False),
    ("integrated_scanner.py", False),
    ("monorepo_orchestrator.py", False),
    ("output_manager.py", False),
    ("output_modes.py", False),
    ("pipeline_cli.py", False),
    ("scan_context.py", False),
    ("vulndb.py", False),
    ("dashboard_v2/loaders.py", True),
]

# ──────────────────────────────────────────────────────────────
# Main
# ──────────────────────────────────────────────────────────────

if __name__ == "__main__":
    apply = "--apply" in sys.argv
    total = 0
    quote_fixes = 0

    print(f"{'APPLYING' if apply else 'DRY RUN'}: Emoji -> _e() replacement")
    print(f"Base: {BASE}")
    print()

    for relpath, is_sub in FILES:
        fp = os.path.join(BASE, relpath)
        if not os.path.exists(fp):
            print(f"  SKIP {relpath} (not found)")
            continue
        n = process_file(fp, dry_run=not apply, subpackage=is_sub)
        q = 0
        if apply and n > 0:
            q = fix_quote_nesting(fp)
            quote_fixes += q
        total += n
        extra = f" + {q} quote fixes" if q > 0 else ""
        print(f"  {relpath}: {n} replacements{extra}")

    print(f"\nTotal: {total} emoji replacements, {quote_fixes} quote fixes")

    if not apply:
        print("\nRun with --apply to make changes:")
        print("  python3 tools/emoji_cleanup.py --apply")
    else:
        print("\nDone! Run a scan to verify.")
