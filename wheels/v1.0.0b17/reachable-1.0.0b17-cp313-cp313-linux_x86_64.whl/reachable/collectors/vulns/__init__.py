# Copyright © 2026 Sthenos Security. All rights reserved.
"""
Vulnerability detection collectors.

Modules:
- grype       - Grype vulnerability scanner (wraps Syft SBOM + Grype)
- ghsa        - GitHub Security Advisory mapper
- exploitdb   - ExploitDB exploit availability checker
- metasploit  - Metasploit module availability checker
"""
