#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.
"""
Fuzzy matching engine for unresolved private registry packages.

Given a private package name, attempts to find the most likely upstream
public package by:
  1. Stripping common private prefixes/suffixes
  2. Computing name similarity against known public package names
  3. Checking version overlap with public candidates
  4. Producing a confidence score

Matches are SUGGESTIONS only — never auto-applied. The user must confirm
via `reachctl registries alias add` to promote a fuzzy match to an alias.

Confidence score: name_similarity × 0.6 + version_match × 0.4
Threshold to surface as suggestion: confidence >= 0.65
"""

import logging
import re
from difflib import SequenceMatcher
from typing import Dict, List, Optional

logger = logging.getLogger(__name__)

# Common private registry prefixes/suffixes to strip before matching
_STRIP_PREFIXES = [
    r"^@[\w-]+/",  # @company/foo → foo
    r"^company[-_]",  # company-foo → foo
    r"^acme[-_]",  # acme-foo → foo
    r"^internal[-_]",  # internal-foo → foo
    r"^private[-_]",  # private-foo → foo
    r"^corp[-_]",  # corp-foo → foo
    r"^mirror[-_]",  # mirror-foo → foo
]

_STRIP_SUFFIXES = [
    r"[-_]internal$",  # foo-internal → foo
    r"[-_]private$",  # foo-private → foo
    r"[-_]mirror$",  # foo-mirror → foo
    r"[-_]wrapper$",  # foo-wrapper → foo
    r"[-_]fork$",  # foo-fork → foo
    r"[-_]patched$",  # foo-patched → foo
]

# Well-known public packages per ecosystem (top ~200 each)
# Used as candidate list when no better source is available.
# In production, this would be supplemented by the local SBOM cache.
_KNOWN_PUBLIC: Dict[str, List[str]] = {
    "python": [
        "requests",
        "flask",
        "django",
        "numpy",
        "pandas",
        "scipy",
        "boto3",
        "botocore",
        "cryptography",
        "authlib",
        "jinja2",
        "sqlalchemy",
        "celery",
        "redis",
        "pyyaml",
        "pytest",
        "pillow",
        "urllib3",
        "certifi",
        "idna",
        "charset-normalizer",
        "setuptools",
        "pip",
        "wheel",
        "six",
        "python-dateutil",
        "pytz",
        "click",
        "pydantic",
        "fastapi",
        "uvicorn",
        "gunicorn",
        "httpx",
        "aiohttp",
        "grpcio",
        "protobuf",
        "google-cloud-storage",
        "google-auth",
        "paramiko",
        "fabric",
        "invoke",
        "tox",
        "coverage",
        "mypy",
        "black",
        "ruff",
        "isort",
        "flake8",
        "pylint",
        "bandit",
        "marshmallow",
        "attrs",
        "jsonschema",
        "lxml",
        "beautifulsoup4",
        "scrapy",
        "selenium",
        "playwright",
        "psycopg2",
        "pymongo",
        "elasticsearch",
        "kafka-python",
        "pika",
        "kombu",
        "tenacity",
        "sentry-sdk",
        "datadog",
        "prometheus-client",
        "opentelemetry-api",
    ],
    "npm": [
        "express",
        "lodash",
        "axios",
        "react",
        "vue",
        "angular",
        "winston",
        "moment",
        "dayjs",
        "uuid",
        "chalk",
        "commander",
        "yargs",
        "dotenv",
        "cors",
        "helmet",
        "jsonwebtoken",
        "bcrypt",
        "mongoose",
        "sequelize",
        "typeorm",
        "prisma",
        "knex",
        "webpack",
        "vite",
        "esbuild",
        "rollup",
        "babel",
        "typescript",
        "eslint",
        "prettier",
        "jest",
        "mocha",
        "chai",
        "supertest",
        "socket.io",
        "graphql",
        "apollo-server",
        "next",
        "nuxt",
        "passport",
        "multer",
        "body-parser",
        "cookie-parser",
        "compression",
        "morgan",
        "debug",
        "semver",
        "minimist",
        "glob",
        "rimraf",
        "fs-extra",
        "mkdirp",
        "cross-env",
        "nodemon",
        "pm2",
        "concurrently",
        "lerna",
        "nx",
        "aws-sdk",
        "@aws-sdk/client-s3",
        "firebase",
        "stripe",
    ],
    "go": [
        "golang.org/x/crypto",
        "golang.org/x/net",
        "golang.org/x/text",
        "golang.org/x/sys",
        "golang.org/x/sync",
        "golang.org/x/time",
        "golang.org/x/tools",
        "golang.org/x/oauth2",
        "golang.org/x/exp",
        "github.com/gin-gonic/gin",
        "github.com/gorilla/mux",
        "github.com/go-chi/chi",
        "github.com/labstack/echo",
        "github.com/stretchr/testify",
        "github.com/sirupsen/logrus",
        "go.uber.org/zap",
        "github.com/spf13/cobra",
        "github.com/spf13/viper",
        "gorm.io/gorm",
        "github.com/jackc/pgx",
        "github.com/go-redis/redis",
        "github.com/aws/aws-sdk-go-v2",
        "google.golang.org/grpc",
        "google.golang.org/protobuf",
        "github.com/golang-jwt/jwt",
        "github.com/prometheus/client_golang",
        "github.com/hashicorp/consul",
        "github.com/hashicorp/vault",
        "github.com/docker/docker",
        "k8s.io/client-go",
        "k8s.io/api",
        "k8s.io/apimachinery",
    ],
    "maven": [
        "org.springframework/spring-core",
        "org.springframework.boot/spring-boot",
        "com.h2database/h2",
        "org.apache.commons/commons-lang3",
        "com.fasterxml.jackson.core/jackson-databind",
        "com.fasterxml.jackson.core/jackson-core",
        "org.apache.logging.log4j/log4j-core",
        "ch.qos.logback/logback-classic",
        "org.slf4j/slf4j-api",
        "com.google.guava/guava",
        "org.apache.httpcomponents/httpclient",
        "junit/junit",
        "org.mockito/mockito-core",
        "io.netty/netty-all",
        "com.squareup.okhttp3/okhttp",
        "org.postgresql/postgresql",
        "mysql/mysql-connector-java",
        "org.apache.kafka/kafka-clients",
        "com.amazonaws/aws-java-sdk",
        "io.grpc/grpc-core",
        "com.google.protobuf/protobuf-java",
        "org.projectlombok/lombok",
    ],
}

# Confidence threshold to surface as a suggestion
SUGGESTION_THRESHOLD = 0.65


def _normalize_name(name: str) -> str:
    """Strip common private prefixes/suffixes and normalize separators."""
    n = name.lower().strip()
    for pat in _STRIP_PREFIXES:
        n = re.sub(pat, "", n)
    for pat in _STRIP_SUFFIXES:
        n = re.sub(pat, "", n)
    # Normalize separators: _ and . → -
    n = n.replace("_", "-").replace(".", "-")
    return n


def _name_similarity(private_name: str, public_name: str) -> float:
    """
    Compute name similarity between a stripped private name and a public name.

    Returns a float in [0.0, 1.0].
    """
    a = _normalize_name(private_name)
    # For Go/Maven, extract the last path segment for comparison
    b = public_name.lower().replace("_", "-").replace(".", "-")
    if "/" in b:
        b_short = b.rsplit("/", 1)[-1]
    else:
        b_short = b

    # Exact match after normalization
    if a == b or a == b_short:
        return 1.0

    # Substring containment
    if a in b_short or b_short in a:
        return 0.85

    # SequenceMatcher ratio
    ratio_full = SequenceMatcher(None, a, b_short).ratio()
    ratio_partial = SequenceMatcher(None, a, b).ratio()
    return max(ratio_full, ratio_partial)


def fuzzy_match(
    name: str,
    version: str,
    ecosystem: str,
    known_packages: Optional[List[str]] = None,
) -> List[Dict]:
    """
    Find candidate public packages for an unresolved private package.

    Args:
        name: Private package name (e.g. 'company-auth')
        version: Package version (e.g. '1.0.0')
        ecosystem: Ecosystem key ('python', 'npm', 'go', 'maven')
        known_packages: Optional override list of public package names.
                       Defaults to _KNOWN_PUBLIC[ecosystem].

    Returns:
        List of candidate dicts sorted by confidence desc:
        [
            {
                'name': 'authlib',
                'version': '1.0.0',      # same version assumed
                'confidence': 0.82,
                'method': 'name_similarity+version',
                'purl': 'pkg:pypi/authlib@1.0.0',
            },
            ...
        ]
        Empty list if no candidates above threshold.
    """
    candidates = known_packages or _KNOWN_PUBLIC.get(ecosystem, [])
    if not candidates:
        return []

    eco_purl_prefix = {
        "python": "pypi",
        "pypi": "pypi",
        "npm": "npm",
        "go": "golang",
        "golang": "golang",
        "maven": "maven",
    }.get(ecosystem, ecosystem)

    results = []
    for pub_name in candidates:
        sim = _name_similarity(name, pub_name)
        if sim < 0.4:
            continue  # too dissimilar, skip

        # Version match bonus: if version strings match exactly, +0.4 weight
        # (In production, would query registry for available versions)
        version_score = 1.0 if version else 0.5

        confidence = sim * 0.6 + version_score * 0.4

        if confidence >= SUGGESTION_THRESHOLD:
            results.append(
                {
                    "name": pub_name,
                    "version": version,
                    "confidence": round(confidence, 3),
                    "method": "name_similarity+version",
                    "purl": f"pkg:{eco_purl_prefix}/{pub_name}@{version}",
                }
            )

    # Sort by confidence descending, keep top 3
    results.sort(key=lambda x: x["confidence"], reverse=True)
    return results[:3]


def best_guess(
    name: str,
    version: str,
    ecosystem: str,
    known_packages: Optional[List[str]] = None,
) -> Optional[Dict]:
    """
    Return the single best fuzzy match candidate, or None if below threshold.
    """
    matches = fuzzy_match(name, version, ecosystem, known_packages)
    if matches and matches[0]["confidence"] >= SUGGESTION_THRESHOLD:
        return matches[0]
    return None
