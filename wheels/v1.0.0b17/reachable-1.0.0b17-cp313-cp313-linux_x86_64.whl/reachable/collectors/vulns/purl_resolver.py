#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.
"""
PURLResolver — out-of-band PURL resolution for private registry packages.

Enriches a Syft SBOM before passing it to Grype so that:
  Case 1 (mirror)    → already canonical, nothing to do
  Case 2 (renamed)   → PURL rewritten via alias map or hash lookup
  Case 3 (internal)  → marked as internal, CVE lookup skipped

Pipeline:
    Syft → sbom.json → PURLResolver.enrich_sbom() → enriched_sbom.json → Grype
"""

import gzip
import hashlib
import json
import logging
import time
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen

from reachable.core.registry_config import is_internal_package, resolve_alias

logger = logging.getLogger(__name__)

# Cache location
_CACHE_DIR = Path.home() / ".reachable" / "cache" / "purl-resolution"
_CACHE_TTL_SECONDS = 7 * 24 * 3600  # 7 days


# ---------------------------------------------------------------------------
# Ecosystem helpers — extract the bare package name from a PURL
# ---------------------------------------------------------------------------


def _purl_parts(purl: str) -> Tuple[str, str, str]:
    """
    Parse a PURL into (ecosystem, name, version).

    pkg:pypi/requests@2.31.0           → ('pypi',   'requests',              '2.31.0')
    pkg:npm/%40acme/http-client@3.2.0  → ('npm',    '@acme/http-client',     '3.2.0')
    pkg:golang/golang.org/x/net@v0.23  → ('golang', 'golang.org/x/net',      'v0.23')
    pkg:maven/org.apache/commons@1.9   → ('maven',  'org.apache/commons',    '1.9')
    """
    if not purl or not purl.startswith("pkg:"):
        return "", "", ""
    rest = purl[4:]  # drop 'pkg:'
    eco, _, rest = rest.partition("/")
    name_ver = rest
    if "@" in name_ver:
        name, _, version = name_ver.rpartition("@")
    else:
        name, version = name_ver, ""
    # URL-decode %40 → @  (npm scoped packages)
    name = name.replace("%40", "@").replace("%2F", "/")
    return eco, name, version


_ECO_MAP = {
    "pypi": "python",
    "npm": "npm",
    "golang": "go",
    "maven": "maven",
}


# ---------------------------------------------------------------------------
# Hash lookup per ecosystem
# ---------------------------------------------------------------------------


def _cache_key(ecosystem: str, name: str, version: str, pkg_hash: str) -> str:
    raw = f"{ecosystem}:{name}:{version}:{pkg_hash}"
    return hashlib.sha256(raw.encode()).hexdigest()[:32]


def _cache_get(key: str) -> Optional[str]:
    path = _CACHE_DIR / key
    if not path.exists():
        return None
    if time.time() - path.stat().st_mtime > _CACHE_TTL_SECONDS:
        path.unlink(missing_ok=True)
        return None
    return path.read_text().strip() or None


def _cache_set(key: str, canonical_purl: str) -> None:
    _CACHE_DIR.mkdir(parents=True, exist_ok=True)
    (_CACHE_DIR / key).write_text(canonical_purl)


def _http_get_json(url: str, timeout: int = 8) -> Optional[Dict]:
    try:
        req = Request(url, headers={"User-Agent": "REACHABLE-PURLResolver/1.0"})
        with urlopen(req, timeout=timeout) as resp:
            if resp.status == 200:
                return json.loads(resp.read())
    except (URLError, HTTPError, json.JSONDecodeError, OSError):
        pass
    return None


# --- PyPI ---


def _lookup_pypi_hash(sha256: str) -> Optional[str]:
    """Query PyPI's simple JSON to find a package that has this file hash."""
    # PyPI doesn't support reverse hash lookup directly — we'd need to know
    # the package name first.  Instead we rely on dist-info METADATA which
    # always has the canonical name; this function is called when we *don't*
    # know the canonical name.  The caller should first try the dist-info
    # approach; this is a last-resort brute search (not implemented here,
    # would require crawling all packages).  Return None to fall through.
    return None


def _verify_pypi_package(name: str, version: str, sha256: str) -> bool:
    """Confirm a (name, version) pair on PyPI matches the given sha256."""
    data = _http_get_json(f"https://pypi.org/pypi/{name}/{version}/json")
    if not data:
        return False
    for url_info in data.get("urls", []):
        digests = url_info.get("digests", {})
        if digests.get("sha256") == sha256:
            return True
    return False


# --- npm ---


def _lookup_npm_integrity(integrity: str, name: str, version: str) -> bool:
    """Confirm an npm package (name@version) has this integrity hash."""
    data = _http_get_json(f"https://registry.npmjs.org/{name}/{version}")
    if not data:
        return False
    dist = data.get("dist", {})
    return dist.get("integrity") == integrity or dist.get("shasum") == integrity


# --- Go ---


def _lookup_go_hash(module: str, version: str, h1_hash: str) -> bool:
    """Verify a Go module (module@version) has this h1: hash via sum.golang.org."""
    url = f"https://sum.golang.org/lookup/{module}@{version}"
    try:
        req = Request(url, headers={"User-Agent": "REACHABLE-PURLResolver/1.0"})
        with urlopen(req, timeout=8) as resp:
            if resp.status == 200:
                text = resp.read().decode()
                # Response format: <hash>\n<tree hash>\n<signed tree>\n
                lines = text.splitlines()
                if lines and lines[0] == h1_hash:
                    return True
    except Exception:
        pass
    return False


# --- Maven ---


def _lookup_maven_sha1(sha1: str) -> Optional[Tuple[str, str, str]]:
    """
    Query Maven Central's search API to find a JAR by SHA1.

    Returns (groupId, artifactId, version) or None.
    """
    url = f"https://search.maven.org/solrsearch/select?q=1:{sha1}&wt=json"
    data = _http_get_json(url)
    if not data:
        return None
    docs = data.get("response", {}).get("docs", [])
    if docs:
        d = docs[0]
        g = d.get("g", "")
        a = d.get("a", "")
        v = d.get("latestVersion") or d.get("v", "")
        if g and a and v:
            return g, a, v
    return None


# ---------------------------------------------------------------------------
# Per-artifact resolution
# ---------------------------------------------------------------------------


def _resolve_artifact(
    artifact: Dict[str, Any],
    offline: bool = False,
) -> Tuple[Dict[str, Any], str]:
    """
    Attempt to resolve/rewrite the PURL of a single SBOM artifact.

    Returns (possibly-modified artifact dict, resolution_reason).
    reason values: 'canonical' | 'internal' | 'alias' | 'hash_match' | 'unresolved'
    """
    import copy

    art = copy.deepcopy(artifact)
    purl = art.get("purl", "")
    if not purl:
        return art, "no_purl"

    eco_raw, name, version = _purl_parts(purl)
    eco = _ECO_MAP.get(eco_raw, eco_raw)

    # --- Step 1: internal namespace check ---
    if is_internal_package(eco, name):
        art["_reachable_registry"] = {
            "resolution": "internal",
            "original_purl": purl,
        }
        return art, "internal"

    # --- Step 2: alias map ---
    aliased = resolve_alias(purl)
    if aliased:
        art["purl"] = aliased
        art["_reachable_registry"] = {
            "resolution": "alias",
            "original_purl": purl,
        }
        # Also update CPEs if present (leave as-is — hash-matched CPEs are fine)
        logger.debug(f"PURLResolver: alias rewrite {purl} → {aliased}")
        return art, "alias"

    # --- Step 3: if purl looks canonical (known public registry name), done ---
    # Heuristic: if name doesn't contain company-specific patterns, assume canonical.
    # The hash check below is only worthwhile for packages with private-looking names.
    if offline:
        return art, "canonical"

    # --- Step 4: hash-based lookup ---
    resolved_purl = _hash_lookup(eco, name, version, artifact)
    if resolved_purl and resolved_purl != purl:
        art["purl"] = resolved_purl
        art["_reachable_registry"] = {
            "resolution": "hash_match",
            "original_purl": purl,
        }
        logger.info(f"PURLResolver: hash resolved {name}@{version} → {resolved_purl}")
        return art, "hash_match"

    return art, "canonical"


def _hash_lookup(
    eco: str,
    name: str,
    version: str,
    artifact: Dict[str, Any],
) -> Optional[str]:
    """
    Try to find the canonical PURL for a package by matching its hash
    against public registry APIs.

    Returns canonical PURL string, or None if no match found.
    """
    locations: List[str] = artifact.get("locations", [])
    metadata: Dict = artifact.get("metadata", {}) or {}

    if eco == "python":
        # dist-info RECORD entries have sha256 hashes
        sha256 = _extract_python_hash(locations, metadata)
        if not sha256:
            return None
        ckey = _cache_key("python", name, version, sha256)
        cached = _cache_get(ckey)
        if cached:
            return cached
        # Try to verify current name/version on PyPI first
        if _verify_pypi_package(name, version, sha256):
            return None  # already canonical
        # If private name doesn't match, we can't brute-search PyPI
        # (would need package name as input). Fall through.
        return None

    elif eco == "npm":
        integrity = metadata.get("integrity") or _extract_npm_integrity(locations)
        if not integrity:
            return None
        ckey = _cache_key("npm", name, version, integrity)
        cached = _cache_get(ckey)
        if cached:
            return cached
        # For renamed npm packages, we need the alias map — hash verification
        # only confirms a known name. Return None to fall through to alias.
        return None

    elif eco == "go":
        h1 = _extract_go_hash(name, version)
        if not h1:
            return None
        ckey = _cache_key("go", name, version, h1)
        cached = _cache_get(ckey)
        if cached:
            return cached
        # Go sum DB: verify the module itself is canonical
        if _lookup_go_hash(name, version, h1):
            result = f"pkg:golang/{name}@{version}"
            _cache_set(ckey, result)
            return result
        return None

    elif eco == "maven":
        sha1 = _extract_maven_sha1(locations, metadata)
        if not sha1:
            return None
        ckey = _cache_key("maven", name, version, sha1)
        cached = _cache_get(ckey)
        if cached:
            return cached
        result = _lookup_maven_sha1(sha1)
        if result:
            group_id, artifact_id, ver = result
            canonical = f"pkg:maven/{group_id}/{artifact_id}@{ver}"
            _cache_set(ckey, canonical)
            return canonical

    return None


def _extract_python_hash(locations: List[str], metadata: Dict) -> Optional[str]:
    """Try to extract the wheel/sdist SHA256 from installed dist-info."""
    # Syft may record the file hash in metadata.files
    for f in metadata.get("files", []):
        if isinstance(f, dict) and f.get("digest", {}).get("algorithm") == "sha256":
            return f["digest"]["value"]
    return None


def _extract_npm_integrity(locations) -> Optional[str]:
    """Try to read integrity hash from package-lock.json."""
    # Syft SBOM locations are dicts: {"path": "/abs/path", "layerID": ...}
    # Walk up from any location to find package-lock.json
    for loc in locations:
        loc_path = loc.get("path", "") if isinstance(loc, dict) else str(loc)
        if not loc_path:
            continue
        pkg_dir = Path(loc_path).parent
        for _ in range(5):
            lock = pkg_dir / "package-lock.json"
            if lock.exists():
                try:
                    json.loads(lock.read_text())
                    # This would need the package name to look up — defer to alias map
                    pass
                except Exception:
                    pass
            pkg_dir = pkg_dir.parent
    return None


def _extract_go_hash(module: str, version: str) -> Optional[str]:
    """Try to find the h1: hash for a module from go.sum in the project."""
    # go.sum format: module version h1:hash=
    # We scan common locations
    for candidate in [Path.cwd() / "go.sum", Path("go.sum")]:
        if candidate.exists():
            try:
                for line in candidate.read_text().splitlines():
                    parts = line.split()
                    if len(parts) == 3 and parts[0] == module and parts[1] == version:
                        if parts[2].startswith("h1:"):
                            return parts[2]
            except Exception:
                pass
    return None


def _extract_maven_sha1(locations: List[str], metadata: Dict) -> Optional[str]:
    """Try to find the JAR SHA1 from local .m2 cache."""
    for loc in locations:
        sha1_path = Path(str(loc) + ".sha1")
        if sha1_path.exists():
            try:
                return sha1_path.read_text().strip().split()[0]
            except Exception:
                pass
    return None


# ---------------------------------------------------------------------------
# Main public API
# ---------------------------------------------------------------------------


class PURLResolver:
    """
    Enriches a Syft SBOM to ensure private registry packages have canonical
    PURLs before Grype CVE matching runs.

    Usage:
        resolver = PURLResolver()
        enriched_path = resolver.enrich_sbom(Path('sbom.json.gz'))
        # pass enriched_path to grype instead of original sbom
    """

    def __init__(self, offline: bool = False):
        self.offline = offline

    def enrich_sbom(self, sbom_path: Path) -> Path:
        """
        Read sbom_path, resolve PURLs, write enriched copy.

        Returns path to enriched SBOM (in same directory with .enriched suffix).
        If no changes were needed, returns the original path unchanged.
        """
        # Load
        if sbom_path.suffix == ".gz":
            with gzip.open(sbom_path) as f:
                sbom = json.load(f)
        else:
            sbom = json.loads(sbom_path.read_text())

        artifacts = sbom.get("artifacts", [])
        if not artifacts:
            return sbom_path

        # Resolve
        counts: Dict[str, int] = {
            "canonical": 0,
            "internal": 0,
            "alias": 0,
            "hash_match": 0,
            "unresolved": 0,
            "no_purl": 0,
        }
        changed = False
        enriched_artifacts = []
        unresolved: List[Dict] = []

        for art in artifacts:
            new_art, reason = _resolve_artifact(art, offline=self.offline)
            counts[reason] = counts.get(reason, 0) + 1
            if reason not in ("canonical", "no_purl"):
                changed = True
            if reason == "unresolved":
                unresolved.append(
                    {
                        "name": art.get("name"),
                        "version": art.get("version"),
                        "purl": art.get("purl"),
                    }
                )
            enriched_artifacts.append(new_art)

        # Attach coverage metadata
        sbom["_reachable_registry_coverage"] = {
            "total_packages": len(artifacts),
            **counts,
            "unresolved_packages": unresolved,
        }

        logger.info(
            f"PURLResolver: {len(artifacts)} packages — "
            f"{counts['canonical']} canonical, "
            f"{counts['internal']} internal, "
            f"{counts['alias']} alias, "
            f"{counts['hash_match']} hash-matched, "
            f"{counts['unresolved']} unresolved"
        )

        if not changed:
            return sbom_path

        # Write enriched copy
        sbom["artifacts"] = enriched_artifacts
        # Handle .json.gz → .enriched.json (strip .gz first)
        if sbom_path.suffixes == [".json", ".gz"]:
            out_path = sbom_path.with_suffix("").with_suffix(".enriched.json")
        else:
            out_path = sbom_path.with_suffix(".enriched.json")
        out_path.write_text(json.dumps(sbom, indent=2))
        return out_path

    def get_resolution_map(self, sbom_path: Path) -> Dict[str, Dict[str, str]]:
        """
        Extract private-name → canonical-name mapping from an enriched SBOM.

        Returns a dict keyed by (ecosystem, original_name) with canonical info:
            {
                ('pypi', 'company-auth'): {
                    'canonical_name': 'authlib',
                    'canonical_version': '1.3.0',
                    'canonical_purl': 'pkg:pypi/authlib@1.3.0',
                    'method': 'hash_match',
                },
                ...
            }

        Used by lib_manager to fetch canonical upstream source when a private
        package has been resolved via hash match or alias.
        """
        if sbom_path.suffix == ".gz":
            with gzip.open(sbom_path) as f:
                sbom = json.load(f)
        else:
            sbom = json.loads(sbom_path.read_text())

        resolution_map: Dict = {}
        for art in sbom.get("artifacts", []):
            reg = art.get("_reachable_registry")
            if not reg:
                continue
            method = reg.get("resolution")
            if method not in ("hash_match", "alias"):
                continue

            original_purl = reg.get("original_purl", "")
            canonical_purl = art.get("purl", "")
            if not original_purl or not canonical_purl:
                continue

            orig_eco, orig_name, orig_ver = _purl_parts(original_purl)
            canon_eco, canon_name, canon_ver = _purl_parts(canonical_purl)
            if not orig_name or not canon_name:
                continue

            eco = _ECO_MAP.get(orig_eco, orig_eco)
            resolution_map[(eco, orig_name)] = {
                "canonical_name": canon_name,
                "canonical_version": canon_ver or orig_ver,
                "canonical_purl": canonical_purl,
                "method": method,
            }

        return resolution_map

    def persist_unresolved(self, sbom_path: Path, db=None) -> List[Dict]:
        """
        Phase 5: Run fuzzy matching on unresolved packages and persist to DB.

        Called after enrich_sbom(). Reads the enriched SBOM's coverage metadata,
        runs fuzzy matching on each unresolved package, and writes results to the
        DB via store_unresolved_packages().

        Also emits structured WARN/DEBUG log lines per the design doc.

        Args:
            sbom_path: Path to the enriched SBOM.
            db: Optional RepoDatabase instance. If provided, writes to DB.

        Returns:
            List of unresolved package dicts (with fuzzy match results).
        """
        from reachable.collectors.vulns.fuzzy_match import fuzzy_match

        if sbom_path.suffix == ".gz":
            with gzip.open(sbom_path) as f:
                sbom = json.load(f)
        else:
            sbom = json.loads(sbom_path.read_text())

        coverage = sbom.get("_reachable_registry_coverage", {})
        raw_unresolved = coverage.get("unresolved_packages", [])
        total = coverage.get("total_packages", 0)

        if not raw_unresolved:
            return []

        enriched: List[Dict] = []
        for pkg in raw_unresolved:
            name = pkg.get("name", "")
            version = pkg.get("version", "")
            purl = pkg.get("purl", "")

            # Determine ecosystem from PURL
            eco_raw, _, _ = _purl_parts(purl)
            eco = _ECO_MAP.get(eco_raw, eco_raw) or "unknown"

            # Run fuzzy matching
            candidates = fuzzy_match(name, version, eco)
            top = candidates[0] if candidates else None

            entry = {
                "name": name,
                "version": version,
                "ecosystem": eco,
                "purl": purl,
                "reason": "no_hash_match",
                "fuzzy_candidates": candidates,
                "best_guess_purl": top["purl"] if top else None,
                "best_guess_confidence": top["confidence"] if top else None,
            }
            enriched.append(entry)

            # DEBUG log per package
            if top:
                logger.debug(
                    f"UNRESOLVED {name}@{version} ({eco}) "
                    f"best_guess: {top['name']}@{version} "
                    f"(confidence: {top['confidence']:.2f}, method: {top['method']})\n"
                    f"      to confirm: reachctl registries alias add "
                    f'"pkg:{eco_raw}/{name}@" "pkg:{eco_raw}/{top["name"]}@"'
                )
            else:
                logger.debug(
                    f"UNRESOLVED {name}@{version} ({eco}) "
                    f"best_guess: none (confidence below threshold)\n"
                    f"      to resolve: reachctl registries alias add "
                    f"{eco} {name} <upstream-name>"
                )

        # WARN summary
        resolved_count = total - len(enriched)
        coverage_pct = (resolved_count / total * 100) if total > 0 else 100.0
        logger.warning(
            f"{len(enriched)} packages unresolved — scan coverage gap\n"
            f"      coverage: {resolved_count}/{total} packages fully analyzed "
            f"({coverage_pct:.1f}%)\n"
            f"      run 'reachctl registries alias list' to see current aliases\n"
            f"      run 'reachctl aliases show' to see unresolved ranked by frequency"
        )

        # Write JSON log alongside SBOM
        self._write_unresolved_json_log(sbom_path, enriched, total, resolved_count, coverage_pct)

        # Persist to DB if available
        if db is not None:
            try:
                db.store_unresolved_packages(enriched)
            except Exception as e:
                logger.warning(f"Failed to persist unresolved to DB: {e}")

        return enriched

    def _write_unresolved_json_log(
        self,
        sbom_path: Path,
        unresolved: List[Dict],
        total: int,
        resolved: int,
        coverage_pct: float,
    ) -> None:
        """Write machine-readable JSON log of unresolved packages."""
        log_data = {
            "level": "warn",
            "event": "purl_resolver.unresolved_summary",
            "total_packages": total,
            "resolved": resolved,
            "unresolved": len(unresolved),
            "coverage_pct": round(coverage_pct, 2),
            "packages": [
                {
                    "name": p["name"],
                    "version": p["version"],
                    "ecosystem": p["ecosystem"],
                    "reason": p["reason"],
                    "best_guess_purl": p.get("best_guess_purl"),
                    "best_guess_confidence": p.get("best_guess_confidence"),
                }
                for p in unresolved
            ],
        }
        out_path = sbom_path.parent / "unresolved-packages.json"
        try:
            out_path.write_text(json.dumps(log_data, indent=2))
            logger.info(f"Wrote {out_path}")
        except Exception as e:
            logger.debug(f"Could not write unresolved log: {e}")

    def get_coverage_summary(self, sbom_path: Path) -> Dict[str, Any]:
        """Dry-run: return coverage stats without writing any file."""
        if sbom_path.suffix == ".gz":
            with gzip.open(sbom_path) as f:
                sbom = json.load(f)
        else:
            sbom = json.loads(sbom_path.read_text())

        artifacts = sbom.get("artifacts", [])
        counts: Dict[str, int] = {}
        unresolved = []
        for art in artifacts:
            _, reason = _resolve_artifact(art, offline=True)  # offline for dry-run
            counts[reason] = counts.get(reason, 0) + 1
            if reason == "unresolved":
                unresolved.append(art.get("name"))
        return {
            "total": len(artifacts),
            "by_reason": counts,
            "unresolved": unresolved,
        }
