#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.

"""
Metasploit Module Checker

Checks if weaponized Metasploit exploit modules exist for CVEs.

Data Source: Metasploit Framework GitHub repository
Repository: https://github.com/rapid7/metasploit-framework
"""

import json
import logging
from datetime import datetime, timedelta
from pathlib import Path
from typing import Dict, List, Optional

import requests

# Initialize module-level logger
logger = logging.getLogger(__name__)


class MetasploitChecker:
    """Check Metasploit module availability for CVEs"""

    # Direct raw file access to Metasploit metadata
    RAW_BASE = "https://raw.githubusercontent.com/rapid7/metasploit-framework/master"

    def __init__(self, cache_dir: Optional[Path] = None):
        """
        Initialize Metasploit checker

        Args:
            cache_dir: Directory to cache module database
        """
        self.cache_dir = Path(cache_dir) if cache_dir else None
        if self.cache_dir:
            self.cache_dir.mkdir(parents=True, exist_ok=True)

        self.cve_to_modules = {}
        self._loaded = False

    def load_database(self, force_refresh: bool = False) -> bool:
        """
        Build CVE-to-module mapping from Metasploit repository

        Uses Metasploit's pre-built metadata JSON.
        Caches for 7 days (modules change less frequently).

        Args:
            force_refresh: Force refresh even if cached

        Returns:
            True if successful
        """
        if self._loaded and not force_refresh:
            return True

        # Check cache
        cache_file = None
        if self.cache_dir:
            cache_file = self.cache_dir / "metasploit_cve_map.json"
            if cache_file.exists() and not force_refresh:
                cache_age = datetime.now() - datetime.fromtimestamp(cache_file.stat().st_mtime)
                if cache_age < timedelta(days=7):
                    with open(cache_file) as f:
                        self.cve_to_modules = json.load(f)
                        self._loaded = True
                        return True

        # Fetch from GitHub
        try:
            logger.info("    Fetching Metasploit module database...")

            # Use pre-built database from Metasploit
            url = f"{self.RAW_BASE}/db/modules_metadata_base.json"

            response = requests.get(url, timeout=30)
            response.raise_for_status()

            # Parse metadata
            metadata = response.json()

            cve_map = {}
            module_count = 0

            # Metasploit metadata format:
            # {
            #   "exploit/unix/webapp/example": {
            #     "name": "Example Exploit",
            #     "fullname": "exploit/unix/webapp/example",
            #     "rank": "excellent",
            #     "disclosuredate": "2023-01-01",
            #     "references": ["CVE-2023-1234", "URL-..."]
            #   }
            # }

            for module_path, module_info in metadata.items():
                module_count += 1

                # Extract CVEs from references
                refs = module_info.get("references", [])
                cves = [ref for ref in refs if isinstance(ref, str) and ref.startswith("CVE-")]

                if not cves:
                    continue

                for cve_id in cves:
                    if cve_id not in cve_map:
                        cve_map[cve_id] = []

                    cve_map[cve_id].append(
                        {
                            "module_path": module_path,
                            "module_name": module_info.get("name", ""),
                            "rank": module_info.get("rank", "unknown"),
                            "disclosure_date": module_info.get("disclosuredate", ""),
                            "type": module_path.split("/")[0] if "/" in module_path else "unknown",
                        }
                    )

            self.cve_to_modules = cve_map
            self._loaded = True

            # Save to cache
            if cache_file:
                with open(cache_file, "w") as f:
                    json.dump(cve_map, f, indent=2)

            logger.info(f" Loaded Metasploit: {module_count} modules, {len(cve_map)} CVEs")
            return True

        except Exception as e:
            logger.info(f" Failed to load Metasploit data: {e}")
            return False

    def check_cve(self, cve_id: str) -> Optional[Dict]:
        """
        Check if Metasploit modules exist for a CVE

        Args:
            cve_id: CVE identifier

        Returns:
            Dict with module info or None
        """
        if not self._loaded:
            if not self.load_database():
                return None

        modules = self.cve_to_modules.get(cve_id)

        if not modules:
            return None

        # Classify modules by rank
        rank_order = ["excellent", "great", "good", "normal", "average", "low", "manual"]
        rank_counts = {rank: 0 for rank in rank_order}

        for module in modules:
            rank = module.get("rank", "unknown").lower()
            if rank in rank_counts:
                rank_counts[rank] += 1

        # Get highest rank
        highest_rank = "unknown"
        for rank in rank_order:
            if rank_counts[rank] > 0:
                highest_rank = rank
                break

        # Count exploit vs auxiliary vs post
        exploit_count = sum(1 for m in modules if m.get("type") == "exploit")

        return {
            "module_available": True,
            "module_count": len(modules),
            "exploit_count": exploit_count,
            "highest_rank": highest_rank,
            "ranks": {k: v for k, v in rank_counts.items() if v > 0},
            "module_paths": [m["module_path"] for m in modules[:3]],  # First 3
        }

    def check_batch(self, cve_ids: List[str]) -> Dict[str, Dict]:
        """
        Check multiple CVEs at once

        Args:
            cve_ids: List of CVE IDs

        Returns:
            Dict mapping CVE ID -> module data
        """
        if not self._loaded:
            if not self.load_database():
                return {}

        results = {}
        for cve_id in cve_ids:
            data = self.check_cve(cve_id)
            if data:
                results[cve_id] = data

        return results


def main():
    """Test Metasploit checker"""
    import sys

    if len(sys.argv) < 2:
        logger.info("Usage: python metasploit_checker.py <CVE-ID> [CVE-ID...]")
        logger.info("Example:")
        logger.info("  python metasploit_checker.py CVE-2023-38545 CVE-2021-44228")
        sys.exit(1)

    checker = MetasploitChecker(cache_dir=Path(".cache"))

    logger.info("Loading Metasploit database...")
    checker.load_database()
    for cve_id in sys.argv[1:]:
        logger.info(f"Checking {cve_id}...")
        data = checker.check_cve(cve_id)

        if data:
            logger.info(f" {data['module_count']} module(s) available")
            logger.info(f" Exploit modules: {data['exploit_count']}")
            logger.info(f" Highest rank: {data['highest_rank']}")
            logger.info(f" Modules: {', '.join(data['module_paths'])}")
        else:
            logger.info(" No Metasploit modules found")


if __name__ == "__main__":
    main()
