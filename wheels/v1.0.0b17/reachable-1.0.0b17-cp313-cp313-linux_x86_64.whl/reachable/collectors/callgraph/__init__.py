# Copyright © 2026 Sthenos Security. All rights reserved.
"""
Call graph analysis collectors.

Modules:
- go          - Go call graph parser
- java        - Java/Maven ecosystem analyzer
- javascript  - JavaScript/TypeScript call graph parser
- hop_registry re-exported from reachable.engine.hop_registry
"""

# T-AI3: re-export so both import paths work:
#   from reachable.engine.hop_registry import ...
#   from reachable.collectors.callgraph import hop_registry
from reachable.engine import hop_registry  # noqa: F401
from reachable.engine.hop_registry import (
    CORE_RULES as CORE_RULES,
)
from reachable.engine.hop_registry import (
    HCR_RULES as HCR_RULES,
)
from reachable.engine.hop_registry import (
    LLM_SINK_RULES as LLM_SINK_RULES,
)
from reachable.engine.hop_registry import (
    PII_SOURCE_RULES as PII_SOURCE_RULES,
)
from reachable.engine.hop_registry import (
    REGISTRY as REGISTRY,
)
from reachable.engine.hop_registry import (
    HopDecision as HopDecision,
)
from reachable.engine.hop_registry import (
    HopPosition as HopPosition,
)
from reachable.engine.hop_registry import (
    HopRule as HopRule,
)
from reachable.engine.hop_registry import (
    NodeKind as NodeKind,
)
from reachable.engine.hop_registry import (
    PathNode as PathNode,
)
from reachable.engine.hop_registry import (
    classify_hop as classify_hop,
)
