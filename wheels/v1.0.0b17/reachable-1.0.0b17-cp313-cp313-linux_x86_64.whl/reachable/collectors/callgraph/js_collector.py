#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.
"""
JS/TS Call Graph Collector — T-CG15 / T9

Two-tier implementation:
  Tier 1 (Joern):     Full CPG — layer 4 reachability (function-level)
  Tier 2 (ts-morph):  Import tracing — layer 3 (file-level, no callgraph)

Joern is optional and heavyweight (~300MB JVM). If not installed, ts-morph
import tracing runs automatically and still gives us package-level UNKNOWN
classification (better than the current nothing).

Joern install: reachctl doctor --full
ts-morph requires Node.js (checked at runtime).

Output: raw/call-graph-js.json  (same schema for both tiers)
"""

from __future__ import annotations

import json
import logging
import os
import platform
import shutil
import subprocess
from pathlib import Path
from typing import List, Optional, Set

logger = logging.getLogger(__name__)

# ── Tool locations ─────────────────────────────────────────────────────────────
REACHABLE_HOME = Path.home() / ".reachable"
TOOLS_DIR = REACHABLE_HOME / "tools"
JOERN_BIN = TOOLS_DIR / "bin" / "joern"
JOERN_SCRIPT = Path(__file__).parent / "joern_query.sc"
TS_TRACER = Path(__file__).parent / "ts_import_tracer.js"

# Pinned Joern version — used ONLY for managed installs via install_joern().
# Does NOT constrain system-installed Joern (brew, manual, etc.).
JOERN_VERSION = "v4.0.490"
JOERN_MIN_VERSION = (4, 0, 100)  # minimum supported; older versions lack jsts/repeat API
JOERN_TIMEOUT = 300  # seconds — large JS repos can take a while
TS_TRACER_TIMEOUT = 60

# Cache: skip Joern re-run if CPG is fresh for same commit
_CPG_CACHE_DIR = REACHABLE_HOME / "cache" / "joern-cpg"


def _find_joern_bin() -> Optional[Path]:
    """Find Joern binary: check managed install first, then system PATH (brew etc)."""
    if JOERN_BIN.exists():
        return JOERN_BIN
    system_joern = shutil.which("joern")
    if system_joern:
        return Path(system_joern)
    return None


def _get_joern_version(joern_bin: Path) -> Optional[tuple]:
    """
    Return installed Joern version as (major, minor, patch) tuple, or None on failure.

    Detection methods (in order):
    1. Resolve binary symlink — Homebrew installs at .../Cellar/joern/VERSION/bin/joern
    2. joern-parse --version — some builds output the version here
    3. joern --version — older builds
    Note: joern --help is NOT parsed — its output contains example Maven
    coordinates (e.g. versionsort:1.0.7) that produce false matches.
    """
    import re as _re

    # Method 1: Resolve symlink to Cellar path
    # /opt/homebrew/bin/joern → /opt/homebrew/Cellar/joern/4.0.490/bin/joern
    try:
        resolved = Path(joern_bin).resolve()
        parts = resolved.parts
        for i, part in enumerate(parts):
            if part in ("Cellar", "cellar") and i + 2 < len(parts):
                ver_str = parts[i + 2]  # Cellar/joern/VERSION/...
                m = _re.match(r"(\d+)\.(\d+)\.(\d+)", ver_str)
                if m:
                    return (int(m.group(1)), int(m.group(2)), int(m.group(3)))
                m = _re.match(r"(\d+)\.(\d+)", ver_str)
                if m:
                    return (int(m.group(1)), int(m.group(2)), 0)
    except Exception:
        pass

    # Method 2: joern-parse --version (some builds expose version here)
    joern_parse = joern_bin.parent / "joern-parse" if joern_bin.parent else None
    if joern_parse and joern_parse.exists():
        try:
            result = subprocess.run(
                [str(joern_parse), "--version"],
                capture_output=True,
                text=True,
                timeout=5,
                stdin=subprocess.DEVNULL,
            )
            output = (result.stdout + result.stderr).strip()
            m = _re.search(r"(\d+)\.(\d+)\.(\d+)", output)
            if m:
                return (int(m.group(1)), int(m.group(2)), int(m.group(3)))
        except (subprocess.TimeoutExpired, Exception):
            pass

    # Method 3: joern --version (some older builds)
    try:
        result = subprocess.run(
            [str(joern_bin), "--version"],
            capture_output=True,
            text=True,
            timeout=5,
            stdin=subprocess.DEVNULL,
        )
        output = (result.stdout + result.stderr).strip()
        # Only match if it looks like a version line, not help text
        for line in output.splitlines()[:3]:
            m = _re.match(r"(?:joern\s+)?v?(\d+)\.(\d+)\.(\d+)", line.strip())
            if m:
                return (int(m.group(1)), int(m.group(2)), int(m.group(3)))
    except (subprocess.TimeoutExpired, Exception):
        pass

    return None


def _check_joern_version(joern_bin: Path) -> bool:
    """
    Return True if the installed Joern meets JOERN_MIN_VERSION.
    Logs a warning (but does NOT block execution) if version is below minimum
    or undetectable — the user controls their own Joern install.
    """
    ver = _get_joern_version(joern_bin)
    if ver is None:
        logger.debug(
            f"Joern version could not be detected from {joern_bin}. "
            f"Minimum recommended: {'.'.join(str(v) for v in JOERN_MIN_VERSION)}. "
            "Proceeding — script may fail on older versions."
        )
        return True  # don't block; let it try and fail with real error
    if ver < JOERN_MIN_VERSION:
        min_str = ".".join(str(v) for v in JOERN_MIN_VERSION)
        ver_str = ".".join(str(v) for v in ver)
        logger.warning(
            f"Joern {ver_str} is below the minimum recommended version {min_str}. "
            "Call graph analysis may produce errors. "
            "Upgrade with: brew upgrade joern   or   reachctl doctor --full"
        )
        return True  # still attempt; ts-morph fallback will catch actual failure
    return True


class JSCallGraphCollector:
    """
    Collect JS/TS call graph for npm CVE reachability enrichment.

    Usage:
        collector = JSCallGraphCollector()
        cg_file = collector.collect(src_dir, output_dir, commit_sha='abc123')
        # cg_file = raw/call-graph-js.json or None
    """

    def __init__(self):
        self._tier: Optional[str] = None  # 'joern' | 'ts_morph' | None

    @property
    def tier(self) -> Optional[str]:
        """Which tier was used in the last collect() call."""
        return self._tier

    def is_available(self) -> bool:
        """True if at least the ts-morph fallback is available (Node.js present)."""
        return shutil.which("node") is not None

    def collect(
        self, src_dir: Path, output_dir: Path, commit_sha: str = "", entrypoints: Optional[List[str]] = None
    ) -> Optional[Path]:
        """
        Run callgraph analysis on src_dir. Returns path to call-graph-js.json or None.

        Args:
            src_dir:     Root of the JS/TS project source
            output_dir:  Scan output directory (raw/ subdirectory used)
            commit_sha:  Git commit SHA for CPG cache keying
            entrypoints: Override auto-detected entrypoints
        """
        if not src_dir.exists():
            return None

        raw_dir = output_dir / "raw"
        raw_dir.mkdir(parents=True, exist_ok=True)
        out_file = raw_dir / "call-graph-js.json"

        # Check for cached result (same commit, not stale)
        if commit_sha and self._is_cached(commit_sha, out_file):
            logger.info(f" JS callgraph: cache hit (commit {commit_sha[:8]})")
            return out_file

        resolved_eps = entrypoints or self._detect_entrypoints(src_dir)

        # Tier 1: Joern (full CPG) — check managed install + system PATH (brew)
        joern_bin = _find_joern_bin()
        if joern_bin:
            result = self._run_joern(src_dir, out_file, resolved_eps, joern_bin)
            if result:
                self._tier = "joern"
                self._write_cache_marker(commit_sha, out_file)
                ver = _get_joern_version(joern_bin)
                ver_str = ".".join(str(v) for v in ver) if ver else "unknown"
                logger.info(f" JS callgraph: Joern {ver_str} CPG — {self._count_records(out_file)} call records")
                return result

        # Tier 2: ts-morph import tracing (Node.js fallback)
        if shutil.which("node"):
            result = self._run_ts_morph(src_dir, out_file, resolved_eps)
            if result:
                self._tier = "ts_morph"
                self._write_cache_marker(commit_sha, out_file)
                logger.info(
                    f" JS callgraph: ts-morph import tracing — {self._count_records(out_file)} import records "
                    f"(install Joern via 'reachctl doctor --full' for full callgraph)"
                )
                return result

        logger.info(" JS callgraph: skipped (Node.js not found — install Node.js for JS reachability)")
        self._tier = None
        return None

    # ── Tier 1: Joern ──────────────────────────────────────────────────────────

    def _run_joern(
        self, src_dir: Path, out_file: Path, entrypoints: List[str], joern_bin: Optional[Path] = None
    ) -> Optional[Path]:
        """Run Joern CPG analysis."""
        joern = joern_bin or _find_joern_bin()
        if not joern:
            return None
        if not JOERN_SCRIPT.exists():
            logger.warning(f"Joern script missing: {JOERN_SCRIPT}")
            return None

        # Version check — warn but never block (user controls their Joern install)
        _check_joern_version(joern)

        eps_str = ",".join(entrypoints)

        try:
            env = os.environ.copy()
            env["JAVA_OPTS"] = env.get("JAVA_OPTS", "") + " -Xmx2g"

            # Write Joern CPG workspace under ~/.reachable, not the repo cwd.
            # Without this, Joern creates workspace/ inside the scanned repo.
            joern_workspace = REACHABLE_HOME / "cache" / "joern-workspace"
            joern_workspace.mkdir(parents=True, exist_ok=True)

            result = subprocess.run(
                [
                    str(joern),
                    "--script",
                    str(JOERN_SCRIPT),
                    "--param",
                    f"inputPath={src_dir}",
                    "--param",
                    f"entrypoints={eps_str}",
                    "--param",
                    f"outPath={out_file}",
                ],
                capture_output=True,
                text=True,
                timeout=JOERN_TIMEOUT,
                env=env,
                cwd=str(joern_workspace),  # ensure relative paths don't land in repo
            )

            if result.returncode != 0:
                logger.warning(f"Joern exited {result.returncode}:\n{result.stderr}")
                if result.stdout:
                    logger.warning(f"Joern stdout:\n{result.stdout}")
                return None

            if not out_file.exists() or out_file.stat().st_size < 3:
                logger.warning("Joern produced no output")
                return None

            return out_file

        except subprocess.TimeoutExpired:
            logger.warning(f"Joern timed out after {JOERN_TIMEOUT}s — falling back to ts-morph")
            return None
        except Exception as e:
            logger.warning(f"Joern error: {e}")
            return None

    # ── Tier 2: ts-morph import tracer ─────────────────────────────────────────

    def _run_ts_morph(self, src_dir: Path, out_file: Path, entrypoints: List[str]) -> Optional[Path]:
        """Run Node.js ts-morph import tracer."""
        if not shutil.which("node"):
            return None
        if not TS_TRACER.exists():
            logger.warning(f"ts_import_tracer.js missing: {TS_TRACER}")
            return None

        try:
            cmd = ["node", str(TS_TRACER), str(src_dir), str(out_file)] + entrypoints

            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=TS_TRACER_TIMEOUT,
            )

            if result.returncode != 0:
                logger.warning(f"ts_import_tracer exited {result.returncode}: {result.stderr[-300:]}")
                return None

            if not out_file.exists() or out_file.stat().st_size < 3:
                return None

            return out_file

        except subprocess.TimeoutExpired:
            logger.warning(f"ts_import_tracer timed out after {TS_TRACER_TIMEOUT}s")
            return None
        except Exception as e:
            logger.warning(f"ts_import_tracer error: {e}")
            return None

    # ── Entrypoint detection ────────────────────────────────────────────────────

    def _detect_entrypoints(self, src_dir: Path) -> List[str]:
        """Detect JS/TS entrypoints from package.json, tsconfig, conventions."""
        entrypoints: List[str] = []
        seen: Set[str] = set()

        def add(p: Path):
            if p.exists() and str(p) not in seen:
                entrypoints.append(str(p))
                seen.add(str(p))

        # package.json: main + exports
        pkg_json = src_dir / "package.json"
        if pkg_json.exists():
            try:
                pkg = json.loads(pkg_json.read_text())
                if pkg.get("main"):
                    add(src_dir / pkg["main"])
                exports = pkg.get("exports")
                if isinstance(exports, str):
                    add(src_dir / exports)
                elif isinstance(exports, dict):
                    for val in exports.values():
                        if isinstance(val, str) and val.endswith((".ts", ".js")):
                            add(src_dir / val)
                # scripts.start often reveals entry
                start_script = pkg.get("scripts", {}).get("start", "")
                for tok in start_script.split():
                    for ext in (".ts", ".js"):
                        candidate = src_dir / (tok.lstrip("node").strip() + ext)
                        if candidate.exists():
                            add(candidate)
            except Exception:
                pass

        # CG-01: Parse tsconfig.json to discover TypeScript entrypoints.
        # tsconfig.json may declare 'files' (explicit entrypoints) or 'outDir'
        # pointing to compiled JS. We use 'files' and 'include' to find TS roots.
        tsconfig = src_dir / "tsconfig.json"
        if tsconfig.exists():
            try:
                import json as _json
                import re as _re

                # Strip trailing commas + line comments (tsconfig allows them)
                raw = tsconfig.read_text(encoding="utf-8", errors="ignore")
                raw = _re.sub(r",\s*([}\]])", r"\1", raw)  # trailing commas
                raw = _re.sub(r"//[^\n]*", "", raw)  # line comments
                tc = _json.loads(raw)
                # 'files': explicit list of TS entrypoints
                for f in tc.get("files", []):
                    add(src_dir / f)
                # 'include': glob patterns — extract any explicit .ts paths
                for pat in tc.get("include", []):
                    if pat.endswith(".ts") and "*" not in pat:
                        add(src_dir / pat)
            except Exception:
                pass

        # Convention-based candidates
        for candidate in [
            "src/index.ts",
            "src/app.ts",
            "src/server.ts",
            "src/main.ts",
            "src/index.js",
            "src/app.js",
            "src/server.js",
            "index.ts",
            "app.ts",
            "index.js",
            "app.js",
        ]:
            add(src_dir / candidate)

        return entrypoints

    # ── Cache helpers ───────────────────────────────────────────────────────────

    def _cache_marker_path(self, commit_sha: str) -> Path:
        return _CPG_CACHE_DIR / f"{commit_sha[:16]}.marker"

    def _is_cached(self, commit_sha: str, out_file: Path) -> bool:
        if not commit_sha:
            return False
        marker = self._cache_marker_path(commit_sha)
        return marker.exists() and out_file.exists() and out_file.stat().st_size > 3

    def _write_cache_marker(self, commit_sha: str, out_file: Path):
        if not commit_sha:
            return
        try:
            _CPG_CACHE_DIR.mkdir(parents=True, exist_ok=True)
            self._cache_marker_path(commit_sha).touch()
        except Exception:
            pass

    @staticmethod
    def _count_records(out_file: Path) -> int:
        try:
            return len(json.loads(out_file.read_text()))
        except Exception:
            return 0


# ── Joern installer ─────────────────────────────────────────────────────────────


def install_joern(verbose: bool = False) -> bool:
    """
    Download and install Joern to ~/.reachable/tools/bin/joern.
    Called by `reachctl doctor --full`.

    Requires: curl, unzip, Java 11+
    Size: ~300MB
    """

    def log(msg):
        if verbose:
            logger.info(msg)

    # Check Java
    if not shutil.which("java"):
        log(" Joern requires Java 11+ — install via: brew install openjdk@17")
        return False

    # Check Java version
    try:
        java_ver = subprocess.run(["java", "-version"], capture_output=True, text=True, timeout=5)
        ver_output = java_ver.stderr + java_ver.stdout
        if 'version "1.' in ver_output:
            # Java 8 or earlier — not supported
            log(" Joern requires Java 11+ — found Java 8 or earlier")
            return False
    except Exception:
        pass

    TOOLS_DIR.mkdir(parents=True, exist_ok=True)

    platform.system().lower()
    platform.machine().lower()

    zip_name = "joern-cli.zip"
    download_url = f"https://github.com/joernio/joern/releases/download/{JOERN_VERSION}/joern-cli.zip"

    zip_path = TOOLS_DIR / zip_name
    joern_dir = TOOLS_DIR / "joern-cli"

    try:
        log(f" Downloading Joern {JOERN_VERSION} (~300MB)...")
        result = subprocess.run(
            ["curl", "-sSfL", "-o", str(zip_path), download_url],
            capture_output=not verbose,
            timeout=600,
        )
        if result.returncode != 0:
            log(f" Joern download failed (exit {result.returncode})")
            return False

        log(" Extracting Joern...")
        subprocess.run(
            ["unzip", "-q", "-o", str(zip_path), "-d", str(TOOLS_DIR)],
            capture_output=not verbose,
            timeout=120,
            check=True,
        )

        # The zip extracts to joern-cli/ — create symlink in bin/
        joern_executable = joern_dir / "joern"
        if not joern_executable.exists():
            log(f" Joern executable not found at {joern_executable}")
            return False

        # Make executable
        joern_executable.chmod(0o755)

        # Symlink to tools/bin/joern
        JOERN_BIN.parent.mkdir(parents=True, exist_ok=True)
        if JOERN_BIN.exists() or JOERN_BIN.is_symlink():
            JOERN_BIN.unlink()
        JOERN_BIN.symlink_to(joern_executable)

        # Clean up zip
        zip_path.unlink(missing_ok=True)

        # Quick smoke test
        test = subprocess.run([str(JOERN_BIN), "--version"], capture_output=True, timeout=30)
        if test.returncode != 0:
            log(" Joern installed but smoke test failed")
            return False

        log(f" Joern installed → {JOERN_BIN}")
        return True

    except Exception as e:
        log(f" Joern installation failed: {e}")
        return False


def joern_available() -> bool:
    """Quick check — is Joern installed and working?"""
    return JOERN_BIN.exists()


def node_available() -> bool:
    """Quick check — is Node.js available for ts-morph fallback?"""
    return shutil.which("node") is not None
