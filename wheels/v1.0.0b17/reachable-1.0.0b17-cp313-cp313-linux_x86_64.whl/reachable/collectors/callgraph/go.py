#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.

"""
FIXED Go Call Graph Parser

BUGS FIXED FROM ORIGINAL:
1. Call graph edges were created but NEVER added to self.call_graph!
2. No tracking of current function context - now properly tracks caller
3. No function_imports tracking - now tracks which functions use which imports

This is the CORE of reachability analysis - without proper call graph, nothing works!
"""

import logging
import re
from collections import defaultdict
from pathlib import Path
from typing import Dict, List, Optional, Set, Tuple

# Initialize module-level logger
logger = logging.getLogger(__name__)


class GoParser:
    """
    Parse Go code to extract call graphs.

    FIXED: Actually builds call graph with edges!
    """

    def __init__(self):
        self.call_graph: Dict[str, Set[str]] = defaultdict(set)
        self.imports_map: Dict[str, List[str]] = {}
        self.function_imports: Dict[str, Set[str]] = defaultdict(set)  # NEW: track imports per function
        self.all_functions: Set[str] = set()
        self.current_module: str = ""
        self.module_imports: Dict[str, str] = {}  # alias -> full package path
        self.package_name: str = ""
        self.function_metadata: Dict[str, dict] = {}  # NEW: func -> {file, line, module}
        self.current_file: str = ""  # NEW: track current file being parsed

    def parse_directory(self, directory: Path, prefix: str = "app") -> Tuple[Dict, Dict, Set]:
        """
        Parse all Go files in directory.

        Returns:
            Tuple of (call_graph, imports_map, all_functions)
        """
        go_files = list(directory.rglob("*.go"))

        # Exclude vendor, tests, generated code
        go_files = [
            f
            for f in go_files
            if "vendor" not in str(f)
            and "_test.go" not in str(f)
            and ".pb.go" not in str(f)  # protobuf generated
            and "mock_" not in str(f.name)
            and f.is_file()
        ]

        for file_path in go_files:
            self._parse_file(file_path, prefix)

        # Resolve cross-package calls
        self._resolve_cross_package_calls()

        return dict(self.call_graph), self.imports_map, self.all_functions

    def get_function_imports(self) -> Dict[str, Set[str]]:
        """Return function→imports mapping for CVE tracking."""
        return dict(self.function_imports)

    def get_module_imports(self) -> Dict[str, Set[str]]:
        """Return module→imports mapping for transitive dependency tracking."""
        # Convert imports_map to sets for consistency
        return {mod: set(imports) for mod, imports in self.imports_map.items()}

    def _parse_file(self, file_path: Path, prefix: str):
        """Parse a single Go file."""
        try:
            if file_path.is_dir():
                return

            # Store current file for metadata
            self.current_file = str(file_path)

            with open(file_path, encoding="utf-8", errors="ignore") as f:
                code = f.read()

            # Get package name
            package_match = re.search(r"^\s*package\s+(\w+)", code, re.MULTILINE)
            if package_match:
                self.package_name = package_match.group(1)

            # Build module name from directory path
            try:
                rel_path = file_path.parent.relative_to(file_path.parent.parent.parent)
                module_name = str(rel_path).replace("/", ".").replace("\\", ".")
            except Exception:
                module_name = file_path.parent.name

            if not module_name or module_name == ".":
                module_name = self.package_name or file_path.parent.name

            self.current_module = f"{prefix}.{module_name}"
            self.module_imports = {}

            # Step 1: Extract imports
            self._extract_imports(code)

            # Step 2: Extract functions and their calls
            self._extract_functions_and_calls(code)

            # Store imports for this module
            if self.module_imports:
                self.imports_map[module_name] = list(self.module_imports.values())

        except Exception:
            pass  # Skip unparseable files

    def _extract_imports(self, code: str):
        """Extract imported packages from code."""
        # Remove comments
        code_clean = re.sub(r"//.*$", "", code, flags=re.MULTILINE)
        code_clean = re.sub(r"/\*[\s\S]*?\*/", "", code_clean)

        # Single import: import "package"
        for match in re.finditer(r'import\s+"([^"]+)"', code_clean):
            package = match.group(1)
            alias = package.split("/")[-1]  # Last component is default alias
            self.module_imports[alias] = package

        # Named import: import alias "package"
        for match in re.finditer(r'import\s+(\w+)\s+"([^"]+)"', code_clean):
            alias = match.group(1)
            package = match.group(2)
            if alias != "_":  # Skip blank imports
                self.module_imports[alias] = package

        # Import block: import ( ... )
        import_blocks = re.findall(r"import\s+\(([\s\S]*?)\)", code_clean)
        for block in import_blocks:
            # Named: alias "package"
            for match in re.finditer(r'(\w+)\s+"([^"]+)"', block):
                alias = match.group(1)
                package = match.group(2)
                if alias != "_":
                    self.module_imports[alias] = package

            # Unnamed: "package"
            for match in re.finditer(r'^\s*"([^"]+)"\s*$', block, re.MULTILINE):
                package = match.group(1)
                alias = package.split("/")[-1]
                self.module_imports[alias] = package

    def _extract_functions_and_calls(self, code: str):
        """Extract function definitions and their internal calls."""
        # Remove comments
        code_clean = re.sub(r"//.*$", "", code, flags=re.MULTILINE)
        code_clean = re.sub(r"/\*[\s\S]*?\*/", "", code_clean)

        # Find all function definitions with their bodies
        functions = self._find_functions(code_clean)

        for func_name, receiver_type, start_pos, end_pos in functions:
            # Build qualified name
            if receiver_type:
                qualified_name = f"{self.current_module}.{receiver_type}.{func_name}"
            else:
                qualified_name = f"{self.current_module}.{func_name}"

            self.all_functions.add(qualified_name)

            # Store function metadata for reachability tracking
            self.function_metadata[qualified_name] = {
                "file": self.current_file,
                "module": self.current_module,
                "line": None,  # Could extract from position if needed
            }

            # Extract function body
            body = code_clean[start_pos:end_pos]

            # Find all function calls in body
            calls = self._extract_calls(body)

            for call, import_alias in calls:
                # Track the call in call graph
                self.call_graph[qualified_name].add(call)

                # Track which imports this function uses
                if import_alias and import_alias in self.module_imports:
                    self.function_imports[qualified_name].add(self.module_imports[import_alias])

    def _find_functions(self, code: str) -> List[Tuple[str, Optional[str], int, int]]:
        """Find all function definitions and their body positions.

        Returns list of (func_name, receiver_type, body_start, body_end)
        """
        functions = []

        # Pattern for regular functions: func Name(...) ... {
        func_pattern = r"func\s+([A-Za-z_][A-Za-z0-9_]*)\s*\([^)]*\)[^{]*\{"
        for match in re.finditer(func_pattern, code):
            func_name = match.group(1)
            brace_pos = match.end() - 1
            end_pos = self._find_matching_brace(code, brace_pos)
            if end_pos > brace_pos:
                functions.append((func_name, None, brace_pos, end_pos))

        # Pattern for methods: func (r Type) Name(...) ... {
        # or: func (r *Type) Name(...) ... {
        method_pattern = (
            r"func\s+\(\s*\w+\s+\*?([A-Za-z_][A-Za-z0-9_]*)\s*\)\s+([A-Za-z_][A-Za-z0-9_]*)\s*\([^)]*\)[^{]*\{"
        )
        for match in re.finditer(method_pattern, code):
            receiver_type = match.group(1)
            func_name = match.group(2)
            brace_pos = match.end() - 1
            end_pos = self._find_matching_brace(code, brace_pos)
            if end_pos > brace_pos:
                functions.append((func_name, receiver_type, brace_pos, end_pos))

        return functions

    def _find_matching_brace(self, code: str, start: int) -> int:
        """Find the position of matching closing brace."""
        depth = 0
        in_string = False
        string_char = None
        in_raw_string = False

        for i in range(start, min(start + 100000, len(code))):
            char = code[i]

            # Handle raw strings (backticks)
            if char == "`":
                in_raw_string = not in_raw_string
                continue

            if in_raw_string:
                continue

            # Handle regular strings
            if char in "\"'" and (i == 0 or code[i - 1] != "\\"):
                if not in_string:
                    in_string = True
                    string_char = char
                elif char == string_char:
                    in_string = False
                continue

            if in_string:
                continue

            if char == "{":
                depth += 1
            elif char == "}":
                depth -= 1
                if depth == 0:
                    return i + 1

        return start

    def _extract_calls(self, body: str) -> List[Tuple[str, Optional[str]]]:
        """Extract function calls from function body.

        Returns list of (call_name, import_alias) tuples.
        """
        calls = []

        # Pattern for function calls
        # Matches: foo(), pkg.Function(), obj.Method(), Type{}.Method()
        call_pattern = r"([a-zA-Z_][a-zA-Z0-9_]*(?:\.[a-zA-Z_][a-zA-Z0-9_]*)*)\s*\("

        # Go keywords and built-ins to skip
        skip = {
            "if",
            "for",
            "switch",
            "select",
            "case",
            "return",
            "defer",
            "go",
            "func",
            "make",
            "new",
            "len",
            "cap",
            "append",
            "copy",
            "delete",
            "panic",
            "recover",
            "print",
            "println",
            "close",
            "complex",
            "real",
            "imag",
            "range",
            "type",
            "struct",
            "interface",
            "map",
            "chan",
            "var",
            "const",
            "break",
            "continue",
            "fallthrough",
            "goto",
            "default",
        }

        for match in re.finditer(call_pattern, body):
            call = match.group(1)
            call_parts = call.split(".")
            call_base = call_parts[0]

            if call_base in skip:
                continue

            # Determine import alias (if package call)
            import_alias = None
            if len(call_parts) >= 2:
                # Could be package.Function or obj.Method
                # Check if first part is a known import
                if call_base in self.module_imports:
                    import_alias = call_base

            # Qualify local calls with current module
            if "." not in call:
                call = f"{self.current_module}.{call}"

            calls.append((call, import_alias))

        return calls

    def _resolve_cross_package_calls(self):
        """Resolve cross-package function calls."""
        # Build a lookup of simple function names to qualified names
        func_lookup: Dict[str, List[str]] = defaultdict(list)
        for func in self.all_functions:
            simple_name = func.split(".")[-1]
            func_lookup[simple_name].append(func)

        # Resolve calls in call graph
        resolved_graph = defaultdict(set)

        for caller, callees in self.call_graph.items():
            for callee in callees:
                # If callee is already qualified and exists, keep it
                if callee in self.all_functions:
                    resolved_graph[caller].add(callee)
                    continue

                # Try to resolve unqualified call
                simple_name = callee.split(".")[-1]
                if simple_name in func_lookup:
                    # Prefer function in same package
                    caller_module = ".".join(caller.split(".")[:-1])
                    for candidate in func_lookup[simple_name]:
                        candidate_module = ".".join(candidate.split(".")[:-1])
                        if candidate_module == caller_module:
                            resolved_graph[caller].add(candidate)
                            break
                    else:
                        # Use first match if no same-package match
                        resolved_graph[caller].add(func_lookup[simple_name][0])
                else:
                    # Keep unresolved (might be external package call)
                    resolved_graph[caller].add(callee)

        self.call_graph = resolved_graph


def detect_go_project(directory: Path) -> bool:
    """Check if directory is a Go project."""
    indicators = [
        directory / "go.mod",
        directory / "go.sum",
    ]

    # Also check for .go files
    go_files = list(directory.glob("*.go"))

    return any(indicator.exists() for indicator in indicators) or len(go_files) > 0


if __name__ == "__main__":
    # Test with sample Go code
    test_code = """
package main

import (
import logging

# Initialize module-level logger
logger = logging.getLogger(__name__)

# Initialize module-level logger
logger = logging.getLogger(__name__)
    "fmt"
    "net/http"

    "github.com/gin-gonic/gin"
    "golang.org/x/crypto/bcrypt"
)

func hashPassword(password string) (string, error) {
    bytes, err := bcrypt.GenerateFromPassword([]byte(password), 14)
    return string(bytes), err
}

func checkPassword(password, hash string) bool {
    err := bcrypt.CompareHashAndPassword([]byte(hash), []byte(password))
    return err == nil
}

func (s *Server) handleLogin(c *gin.Context) {
    password := c.PostForm("password")
    hash, err := hashPassword(password)
    if err != nil {
        c.JSON(500, gin.H{"error": "failed to hash"})
        return
    }

    if checkPassword(password, hash) {
        c.JSON(200, gin.H{"status": "ok"})
    }
}

func main() {
    r := gin.Default()
    server := &Server{}
    r.POST("/login", server.handleLogin)
    r.Run(":8080")
}
"""

    logger.info("=" * 60)
    logger.info("FIXED Go Parser - Test")
    logger.info("=" * 60)

    parser = GoParser()
    parser.current_module = "app.main"
    parser._extract_imports(test_code)

    logger.info(f"\n Imports found: {parser.module_imports}")

    parser._extract_functions_and_calls(test_code)

    logger.info(f"\n Functions found ({len(parser.all_functions)}):")
    for func in sorted(parser.all_functions):
        logger.info(f" • {func}")

    logger.info(f"\n Call graph ({sum(len(v) for v in parser.call_graph.values())} edges):")
    for caller, callees in sorted(parser.call_graph.items()):
        logger.info(f" {caller} →")
        for callee in sorted(callees):
            logger.info(f" → {callee}")

    logger.info("\n Function imports (CVE tracking):")
    for func, imports in sorted(parser.function_imports.items()):
        if imports:
            logger.info(f" {func}: {imports}")

    # Verify fix
    edge_count = sum(len(v) for v in parser.call_graph.values())
    logger.info(f"\n{'' if edge_count > 0 else ''} Edge count: {edge_count}")
    logger.info(f"{'' if parser.function_imports else ''} Function imports populated: {bool(parser.function_imports)}")
