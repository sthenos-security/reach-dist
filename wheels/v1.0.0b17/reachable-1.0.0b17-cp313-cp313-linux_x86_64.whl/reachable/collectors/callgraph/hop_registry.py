#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.
"""
Shim — re-exports everything from reachable.engine.hop_registry.

Exists so both import paths resolve to the same module:
    from reachable.engine.hop_registry import NodeKind, ...
    from reachable.collectors.callgraph.hop_registry import NodeKind, ...
"""

from reachable.engine.hop_registry import *  # noqa: F401, F403
from reachable.engine.hop_registry import (  # noqa: F401 — re-exported shim
    CORE_RULES,
    HCR_RULES,
    JS_RULES,
    LLM_SINK_RULES,
    PII_SOURCE_RULES,
    REGISTRY,
    HopDecision,
    HopPosition,
    HopRule,
    NodeKind,
    PathNode,
    classify_hop,
)
