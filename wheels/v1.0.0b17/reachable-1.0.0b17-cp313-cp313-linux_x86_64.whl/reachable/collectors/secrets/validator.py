#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.

"""
Secret Validator - Active Secret Verification

Validates if discovered secrets are actually active/valid by making
safe API calls to the respective services.

This is critical for risk prioritization:
- VERIFIED ACTIVE: Secret works → CRITICAL (immediate action required)
- VERIFIED INACTIVE: Secret revoked/expired → HIGH (cleanup task)
- UNVERIFIED: Couldn't test → HIGH (assume active, investigate)

Supported Services:
- AWS (Access Keys)
- GitHub (Personal Access Tokens, OAuth Apps)
- GitLab (Personal Access Tokens)
- Slack (Bot Tokens, Webhooks)
- Stripe (API Keys)
- SendGrid (API Keys)
- Twilio (Account SID + Auth Token)
- OpenAI (API Keys)
- Google Cloud (Service Account Keys - partial)
- Generic JWT (validates structure and expiry)

SECURITY NOTES:
- All API calls are read-only (GET requests where possible)
- No data is exfiltrated
- Secrets are never logged or transmitted externally
- Validation is opt-in (--verify-secrets flag)
"""

import base64
import hashlib
import hmac
import json
import logging
import re
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)

# Optional imports - validation works without these but is limited
try:
    import requests

    REQUESTS_AVAILABLE = True
except ImportError:
    REQUESTS_AVAILABLE = False

try:
    import jwt  # noqa: F401 — used conditionally when JWT_AVAILABLE

    JWT_AVAILABLE = True
except ImportError:
    JWT_AVAILABLE = False


class ValidationStatus(Enum):
    """Status of secret validation"""

    ACTIVE = "active"  # Secret is valid and working
    INACTIVE = "inactive"  # Secret is revoked, expired, or invalid
    EXPIRED = "expired"  # Secret has expired (for time-limited tokens)
    RATE_LIMITED = "rate_limited"  # Couldn't verify due to rate limiting
    NETWORK_ERROR = "network_error"  # Network issue during validation
    UNSUPPORTED = "unsupported"  # Can't validate this secret type
    SKIPPED = "skipped"  # Validation was skipped (disabled or missing deps)


@dataclass
class ValidationResult:
    """Result of secret validation"""

    status: ValidationStatus
    secret_type: str
    is_active: bool
    confidence: float  # 0.0 to 1.0
    details: str
    service_response: Optional[str] = None
    expires_at: Optional[datetime] = None
    scopes: List[str] = field(default_factory=list)
    identity: Optional[str] = None  # e.g., AWS account ID, GitHub username
    risk_multiplier: float = 1.0  # For risk calculation


class SecretValidator:
    """
    Validates secrets by making safe API calls to respective services.

    Usage:
        validator = SecretValidator()
        result = validator.validate(secret_value, secret_type)

        if result.is_active:
            logger.info(f"SECRET IS ACTIVE - {result.identity}")
        else:
            logger.info(f"Secret is inactive/expired")
    """

    def __init__(self, timeout: int = 10, verify_ssl: bool = True):
        """
        Initialize validator.

        Args:
            timeout: Request timeout in seconds
            verify_ssl: Whether to verify SSL certificates
        """
        self.timeout = timeout
        self.verify_ssl = verify_ssl
        self._rate_limit_cache: Dict[str, float] = {}

        if not REQUESTS_AVAILABLE:
            logger.info("  requests library not available - secret validation limited")

    def validate(self, secret_value: str, secret_type: str, context: Dict[str, Any] = None) -> ValidationResult:
        """
        Validate a secret.

        Args:
            secret_value: The actual secret value
            secret_type: Type of secret (aws_key, github_token, etc.)
            context: Additional context (file path, line number, etc.)

        Returns:
            ValidationResult with status and details
        """
        if not REQUESTS_AVAILABLE:
            return ValidationResult(
                status=ValidationStatus.SKIPPED,
                secret_type=secret_type,
                is_active=True,  # Assume active if we can't verify
                confidence=0.0,
                details="requests library not available",
                risk_multiplier=1.0,
            )

        # Detect secret type if not provided
        if secret_type == "unknown" or not secret_type:
            secret_type = self._detect_secret_type(secret_value)

        # Route to appropriate validator
        validators = {
            "aws_access_key": self._validate_aws,
            "aws_secret_key": self._validate_aws_secret,
            "github_token": self._validate_github,
            "github_pat": self._validate_github,
            "gitlab_token": self._validate_gitlab,
            "slack_token": self._validate_slack,
            "slack_webhook": self._validate_slack_webhook,
            "stripe_key": self._validate_stripe,
            "sendgrid_key": self._validate_sendgrid,
            "twilio_sid": self._validate_twilio,
            "openai_key": self._validate_openai,
            "jwt_token": self._validate_jwt,
            "google_api_key": self._validate_google_api,
            "npm_token": self._validate_npm,
            "pypi_token": self._validate_pypi,
            "azure_key": self._validate_azure,
            "database_url": self._validate_database_url,
            "private_key": self._validate_private_key,
        }

        validator_func = validators.get(secret_type, self._validate_unknown)

        try:
            return validator_func(secret_value, context or {})
        except Exception as e:
            return ValidationResult(
                status=ValidationStatus.NETWORK_ERROR,
                secret_type=secret_type,
                is_active=True,  # Assume active on error
                confidence=0.3,
                details=f"Validation error: {str(e)}",
                risk_multiplier=0.9,
            )

    def _detect_secret_type(self, secret_value: str) -> str:
        """Auto-detect secret type from value pattern."""
        s = secret_value.strip()

        # AWS Access Key ID
        if re.match(r"^AKIA[0-9A-Z]{16}$", s):
            return "aws_access_key"

        # AWS Secret Access Key (40 chars, base64-ish)
        if re.match(r"^[A-Za-z0-9+/]{40}$", s):
            return "aws_secret_key"

        # GitHub Personal Access Token (new format)
        if re.match(r"^ghp_[A-Za-z0-9]{36}$", s):
            return "github_token"

        # GitHub Personal Access Token (old format)
        if re.match(r"^[a-f0-9]{40}$", s) and len(s) == 40:
            return "github_token"

        # GitHub OAuth Token
        if re.match(r"^gho_[A-Za-z0-9]{36}$", s):
            return "github_token"

        # GitLab Personal Access Token
        if re.match(r"^glpat-[A-Za-z0-9_-]{20}$", s):
            return "gitlab_token"

        # Slack Bot Token
        if re.match(r"^xoxb-[0-9]+-[0-9A-Za-z]+$", s):
            return "slack_token"

        # Slack Webhook
        if re.match(r"^https://hooks\.slack\.com/services/", s):
            return "slack_webhook"

        # Stripe API Key
        if re.match(r"^sk_(live|test)_[A-Za-z0-9]{24,}$", s):
            return "stripe_key"

        # SendGrid API Key
        if re.match(r"^SG\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+$", s):
            return "sendgrid_key"

        # Twilio Account SID
        if re.match(r"^AC[a-f0-9]{32}$", s):
            return "twilio_sid"

        # OpenAI API Key
        if re.match(r"^sk-[A-Za-z0-9]{48}$", s):
            return "openai_key"

        # NPM Token
        if re.match(r"^npm_[A-Za-z0-9]{36}$", s):
            return "npm_token"

        # PyPI Token
        if re.match(r"^pypi-[A-Za-z0-9_-]+$", s):
            return "pypi_token"

        # JWT Token
        if re.match(r"^eyJ[A-Za-z0-9_-]+\.eyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+$", s):
            return "jwt_token"

        # Google API Key
        if re.match(r"^AIza[A-Za-z0-9_-]{35}$", s):
            return "google_api_key"

        # Private Key (PEM)
        if "-----BEGIN" in s and "PRIVATE KEY" in s:
            return "private_key"

        # Database URL
        if re.match(r"^(postgres|mysql|mongodb|redis)://", s):
            return "database_url"

        return "unknown"

    # =========================================================================
    # AWS VALIDATION
    # =========================================================================

    def _validate_aws(self, secret_value: str, context: Dict) -> ValidationResult:
        """
        Validate AWS Access Key ID using STS GetCallerIdentity.

        Requires both access key and secret key to be available.
        """
        # AWS access key alone can't be validated - need secret key too
        # Check if secret key is in context
        secret_key = context.get("aws_secret_key")

        if not secret_key:
            return ValidationResult(
                status=ValidationStatus.UNSUPPORTED,
                secret_type="aws_access_key",
                is_active=True,  # Assume active
                confidence=0.5,
                details="Need both access key and secret key to validate AWS credentials",
                risk_multiplier=0.8,
            )

        return self._validate_aws_credentials(secret_value, secret_key)

    def _validate_aws_secret(self, secret_value: str, context: Dict) -> ValidationResult:
        """Validate AWS Secret Access Key (needs access key ID too)."""
        access_key = context.get("aws_access_key")

        if not access_key:
            return ValidationResult(
                status=ValidationStatus.UNSUPPORTED,
                secret_type="aws_secret_key",
                is_active=True,
                confidence=0.5,
                details="Need both access key and secret key to validate AWS credentials",
                risk_multiplier=0.8,
            )

        return self._validate_aws_credentials(access_key, secret_value)

    def _validate_aws_credentials(self, access_key: str, secret_key: str) -> ValidationResult:
        """Validate AWS credentials by calling STS GetCallerIdentity."""
        try:
            # Build AWS STS request manually (no boto3 dependency)
            service = "sts"
            host = "sts.amazonaws.com"
            region = "us-east-1"
            endpoint = f"https://{host}"

            # Create request
            method = "POST"
            request_params = "Action=GetCallerIdentity&Version=2011-06-15"

            t = datetime.utcnow()
            amz_date = t.strftime("%Y%m%dT%H%M%SZ")
            date_stamp = t.strftime("%Y%m%d")

            # Create canonical request
            canonical_uri = "/"
            canonical_querystring = ""
            canonical_headers = f"host:{host}\nx-amz-date:{amz_date}\n"
            signed_headers = "host;x-amz-date"
            payload_hash = hashlib.sha256(request_params.encode()).hexdigest()
            canonical_request = f"{method}\n{canonical_uri}\n{canonical_querystring}\n{canonical_headers}\n{signed_headers}\n{payload_hash}"

            # Create string to sign
            algorithm = "AWS4-HMAC-SHA256"
            credential_scope = f"{date_stamp}/{region}/{service}/aws4_request"
            string_to_sign = (
                f"{algorithm}\n{amz_date}\n{credential_scope}\n{hashlib.sha256(canonical_request.encode()).hexdigest()}"
            )

            # Sign
            def sign(key, msg):
                return hmac.new(key, msg.encode("utf-8"), hashlib.sha256).digest()

            k_date = sign(("AWS4" + secret_key).encode("utf-8"), date_stamp)
            k_region = sign(k_date, region)
            k_service = sign(k_region, service)
            k_signing = sign(k_service, "aws4_request")
            signature = hmac.new(k_signing, string_to_sign.encode("utf-8"), hashlib.sha256).hexdigest()

            # Build authorization header
            authorization_header = f"{algorithm} Credential={access_key}/{credential_scope}, SignedHeaders={signed_headers}, Signature={signature}"

            headers = {
                "Content-Type": "application/x-www-form-urlencoded",
                "X-Amz-Date": amz_date,
                "Authorization": authorization_header,
            }

            response = requests.post(
                endpoint, data=request_params, headers=headers, timeout=self.timeout, verify=self.verify_ssl
            )

            if response.status_code == 200:
                # Parse response for account ID
                account_match = re.search(r"<Account>(\d+)</Account>", response.text)
                account_id = account_match.group(1) if account_match else "unknown"

                arn_match = re.search(r"<Arn>([^<]+)</Arn>", response.text)
                arn = arn_match.group(1) if arn_match else "unknown"

                return ValidationResult(
                    status=ValidationStatus.ACTIVE,
                    secret_type="aws_credentials",
                    is_active=True,
                    confidence=1.0,
                    details=f"AWS credentials are ACTIVE for account {account_id}",
                    identity=f"Account: {account_id}, ARN: {arn}",
                    risk_multiplier=1.0,
                )
            elif response.status_code == 403:
                # Invalid credentials
                return ValidationResult(
                    status=ValidationStatus.INACTIVE,
                    secret_type="aws_credentials",
                    is_active=False,
                    confidence=1.0,
                    details="AWS credentials are INVALID or REVOKED",
                    risk_multiplier=0.3,
                )
            else:
                return ValidationResult(
                    status=ValidationStatus.NETWORK_ERROR,
                    secret_type="aws_credentials",
                    is_active=True,
                    confidence=0.5,
                    details=f"AWS validation returned status {response.status_code}",
                    risk_multiplier=0.8,
                )

        except Exception as e:
            return ValidationResult(
                status=ValidationStatus.NETWORK_ERROR,
                secret_type="aws_credentials",
                is_active=True,
                confidence=0.3,
                details=f"AWS validation error: {str(e)}",
                risk_multiplier=0.9,
            )

    # =========================================================================
    # GITHUB VALIDATION
    # =========================================================================

    def _validate_github(self, secret_value: str, context: Dict) -> ValidationResult:
        """Validate GitHub token by calling /user endpoint."""
        try:
            headers = {
                "Authorization": f"token {secret_value}",
                "Accept": "application/vnd.github.v3+json",
                "User-Agent": "REACHABLE-Secret-Validator",
            }

            response = requests.get(
                "https://api.github.com/user", headers=headers, timeout=self.timeout, verify=self.verify_ssl
            )

            if response.status_code == 200:
                data = response.json()
                username = data.get("login", "unknown")

                # Check scopes
                scopes = response.headers.get("X-OAuth-Scopes", "").split(", ")
                scopes = [s.strip() for s in scopes if s.strip()]

                return ValidationResult(
                    status=ValidationStatus.ACTIVE,
                    secret_type="github_token",
                    is_active=True,
                    confidence=1.0,
                    details=f"GitHub token is ACTIVE for user '{username}'",
                    identity=username,
                    scopes=scopes,
                    risk_multiplier=1.0,
                )
            elif response.status_code == 401:
                return ValidationResult(
                    status=ValidationStatus.INACTIVE,
                    secret_type="github_token",
                    is_active=False,
                    confidence=1.0,
                    details="GitHub token is INVALID or REVOKED",
                    risk_multiplier=0.3,
                )
            elif response.status_code == 403:
                # Rate limited or forbidden
                return ValidationResult(
                    status=ValidationStatus.RATE_LIMITED,
                    secret_type="github_token",
                    is_active=True,
                    confidence=0.6,
                    details="GitHub API rate limited or forbidden",
                    risk_multiplier=0.8,
                )
            else:
                return ValidationResult(
                    status=ValidationStatus.NETWORK_ERROR,
                    secret_type="github_token",
                    is_active=True,
                    confidence=0.5,
                    details=f"GitHub validation returned status {response.status_code}",
                    risk_multiplier=0.9,
                )

        except Exception as e:
            return ValidationResult(
                status=ValidationStatus.NETWORK_ERROR,
                secret_type="github_token",
                is_active=True,
                confidence=0.3,
                details=f"GitHub validation error: {str(e)}",
                risk_multiplier=0.9,
            )

    # =========================================================================
    # GITLAB VALIDATION
    # =========================================================================

    def _validate_gitlab(self, secret_value: str, context: Dict) -> ValidationResult:
        """Validate GitLab token by calling /user endpoint."""
        try:
            headers = {
                "PRIVATE-TOKEN": secret_value,
            }

            response = requests.get(
                "https://gitlab.com/api/v4/user",
                headers=headers,
                timeout=self.timeout,
                verify=self.verify_ssl,
            )

            if response.status_code == 200:
                data = response.json()
                username = data.get("username", "unknown")

                return ValidationResult(
                    status=ValidationStatus.ACTIVE,
                    secret_type="gitlab_token",
                    is_active=True,
                    confidence=1.0,
                    details=f"GitLab token is ACTIVE for user '{username}'",
                    identity=username,
                    risk_multiplier=1.0,
                )
            elif response.status_code == 401:
                return ValidationResult(
                    status=ValidationStatus.INACTIVE,
                    secret_type="gitlab_token",
                    is_active=False,
                    confidence=1.0,
                    details="GitLab token is INVALID or REVOKED",
                    risk_multiplier=0.3,
                )
            else:
                return ValidationResult(
                    status=ValidationStatus.NETWORK_ERROR,
                    secret_type="gitlab_token",
                    is_active=True,
                    confidence=0.5,
                    details=f"GitLab validation returned status {response.status_code}",
                    risk_multiplier=0.9,
                )

        except Exception as e:
            return ValidationResult(
                status=ValidationStatus.NETWORK_ERROR,
                secret_type="gitlab_token",
                is_active=True,
                confidence=0.3,
                details=f"GitLab validation error: {str(e)}",
                risk_multiplier=0.9,
            )

    # =========================================================================
    # SLACK VALIDATION
    # =========================================================================

    def _validate_slack(self, secret_value: str, context: Dict) -> ValidationResult:
        """Validate Slack token by calling auth.test."""
        try:
            headers = {
                "Authorization": f"Bearer {secret_value}",
                "Content-Type": "application/json",
            }

            response = requests.post(
                "https://slack.com/api/auth.test",
                headers=headers,
                timeout=self.timeout,
                verify=self.verify_ssl,
            )

            data = response.json()

            if data.get("ok"):
                user = data.get("user", "unknown")
                team = data.get("team", "unknown")

                return ValidationResult(
                    status=ValidationStatus.ACTIVE,
                    secret_type="slack_token",
                    is_active=True,
                    confidence=1.0,
                    details=f"Slack token is ACTIVE for {user}@{team}",
                    identity=f"{user}@{team}",
                    risk_multiplier=1.0,
                )
            else:
                error = data.get("error", "unknown")
                if error in ["invalid_auth", "account_inactive", "token_revoked"]:
                    return ValidationResult(
                        status=ValidationStatus.INACTIVE,
                        secret_type="slack_token",
                        is_active=False,
                        confidence=1.0,
                        details=f"Slack token is INVALID: {error}",
                        risk_multiplier=0.3,
                    )
                else:
                    return ValidationResult(
                        status=ValidationStatus.NETWORK_ERROR,
                        secret_type="slack_token",
                        is_active=True,
                        confidence=0.5,
                        details=f"Slack validation error: {error}",
                        risk_multiplier=0.8,
                    )

        except Exception as e:
            return ValidationResult(
                status=ValidationStatus.NETWORK_ERROR,
                secret_type="slack_token",
                is_active=True,
                confidence=0.3,
                details=f"Slack validation error: {str(e)}",
                risk_multiplier=0.9,
            )

    def _validate_slack_webhook(self, secret_value: str, context: Dict) -> ValidationResult:
        """Validate Slack webhook (can't safely test without posting)."""
        # We can't validate webhooks without actually posting a message
        # But we can at least verify the URL format
        if re.match(r"^https://hooks\.slack\.com/services/T[A-Z0-9]+/B[A-Z0-9]+/[A-Za-z0-9]+$", secret_value):
            return ValidationResult(
                status=ValidationStatus.UNSUPPORTED,
                secret_type="slack_webhook",
                is_active=True,  # Assume active
                confidence=0.7,
                details="Slack webhook format is valid (cannot verify without posting)",
                risk_multiplier=0.8,
            )
        else:
            return ValidationResult(
                status=ValidationStatus.INACTIVE,
                secret_type="slack_webhook",
                is_active=False,
                confidence=0.8,
                details="Slack webhook URL format is invalid",
                risk_multiplier=0.4,
            )

    # =========================================================================
    # STRIPE VALIDATION
    # =========================================================================

    def _validate_stripe(self, secret_value: str, context: Dict) -> ValidationResult:
        """Validate Stripe API key by calling /v1/balance."""
        try:
            headers = {
                "Authorization": f"Bearer {secret_value}",
            }

            response = requests.get(
                "https://api.stripe.com/v1/balance",
                headers=headers,
                timeout=self.timeout,
                verify=self.verify_ssl,
            )

            if response.status_code == 200:
                is_live = secret_value.startswith("sk_live_")
                mode = "LIVE" if is_live else "TEST"

                return ValidationResult(
                    status=ValidationStatus.ACTIVE,
                    secret_type="stripe_key",
                    is_active=True,
                    confidence=1.0,
                    details=f"Stripe {mode} key is ACTIVE",
                    identity=f"Stripe {mode} mode",
                    risk_multiplier=1.0 if is_live else 0.5,
                )
            elif response.status_code == 401:
                return ValidationResult(
                    status=ValidationStatus.INACTIVE,
                    secret_type="stripe_key",
                    is_active=False,
                    confidence=1.0,
                    details="Stripe key is INVALID or REVOKED",
                    risk_multiplier=0.3,
                )
            else:
                return ValidationResult(
                    status=ValidationStatus.NETWORK_ERROR,
                    secret_type="stripe_key",
                    is_active=True,
                    confidence=0.5,
                    details=f"Stripe validation returned status {response.status_code}",
                    risk_multiplier=0.9,
                )

        except Exception as e:
            return ValidationResult(
                status=ValidationStatus.NETWORK_ERROR,
                secret_type="stripe_key",
                is_active=True,
                confidence=0.3,
                details=f"Stripe validation error: {str(e)}",
                risk_multiplier=0.9,
            )

    # =========================================================================
    # SENDGRID VALIDATION
    # =========================================================================

    def _validate_sendgrid(self, secret_value: str, context: Dict) -> ValidationResult:
        """Validate SendGrid API key by calling /v3/user/profile."""
        try:
            headers = {
                "Authorization": f"Bearer {secret_value}",
            }

            response = requests.get(
                "https://api.sendgrid.com/v3/user/profile",
                headers=headers,
                timeout=self.timeout,
                verify=self.verify_ssl,
            )

            if response.status_code == 200:
                data = response.json()
                username = data.get("username", "unknown")

                return ValidationResult(
                    status=ValidationStatus.ACTIVE,
                    secret_type="sendgrid_key",
                    is_active=True,
                    confidence=1.0,
                    details=f"SendGrid key is ACTIVE for '{username}'",
                    identity=username,
                    risk_multiplier=1.0,
                )
            elif response.status_code in [401, 403]:
                return ValidationResult(
                    status=ValidationStatus.INACTIVE,
                    secret_type="sendgrid_key",
                    is_active=False,
                    confidence=1.0,
                    details="SendGrid key is INVALID or REVOKED",
                    risk_multiplier=0.3,
                )
            else:
                return ValidationResult(
                    status=ValidationStatus.NETWORK_ERROR,
                    secret_type="sendgrid_key",
                    is_active=True,
                    confidence=0.5,
                    details=f"SendGrid validation returned status {response.status_code}",
                    risk_multiplier=0.9,
                )

        except Exception as e:
            return ValidationResult(
                status=ValidationStatus.NETWORK_ERROR,
                secret_type="sendgrid_key",
                is_active=True,
                confidence=0.3,
                details=f"SendGrid validation error: {str(e)}",
                risk_multiplier=0.9,
            )

    # =========================================================================
    # TWILIO VALIDATION
    # =========================================================================

    def _validate_twilio(self, secret_value: str, context: Dict) -> ValidationResult:
        """Validate Twilio Account SID (needs auth token too)."""
        auth_token = context.get("twilio_auth_token")

        if not auth_token:
            return ValidationResult(
                status=ValidationStatus.UNSUPPORTED,
                secret_type="twilio_sid",
                is_active=True,
                confidence=0.5,
                details="Need both Account SID and Auth Token to validate Twilio",
                risk_multiplier=0.8,
            )

        try:
            response = requests.get(
                f"https://api.twilio.com/2010-04-01/Accounts/{secret_value}.json",
                auth=(secret_value, auth_token),
                timeout=self.timeout,
                verify=self.verify_ssl,
            )

            if response.status_code == 200:
                data = response.json()
                friendly_name = data.get("friendly_name", "unknown")
                status = data.get("status", "unknown")

                return ValidationResult(
                    status=ValidationStatus.ACTIVE,
                    secret_type="twilio_credentials",
                    is_active=True,
                    confidence=1.0,
                    details=f"Twilio account is ACTIVE: {friendly_name} ({status})",
                    identity=friendly_name,
                    risk_multiplier=1.0,
                )
            elif response.status_code == 401:
                return ValidationResult(
                    status=ValidationStatus.INACTIVE,
                    secret_type="twilio_credentials",
                    is_active=False,
                    confidence=1.0,
                    details="Twilio credentials are INVALID",
                    risk_multiplier=0.3,
                )
            else:
                return ValidationResult(
                    status=ValidationStatus.NETWORK_ERROR,
                    secret_type="twilio_credentials",
                    is_active=True,
                    confidence=0.5,
                    details=f"Twilio validation returned status {response.status_code}",
                    risk_multiplier=0.9,
                )

        except Exception as e:
            return ValidationResult(
                status=ValidationStatus.NETWORK_ERROR,
                secret_type="twilio_credentials",
                is_active=True,
                confidence=0.3,
                details=f"Twilio validation error: {str(e)}",
                risk_multiplier=0.9,
            )

    # =========================================================================
    # OPENAI VALIDATION
    # =========================================================================

    def _validate_openai(self, secret_value: str, context: Dict) -> ValidationResult:
        """Validate OpenAI API key by calling /v1/models."""
        try:
            headers = {
                "Authorization": f"Bearer {secret_value}",
            }

            response = requests.get(
                "https://api.openai.com/v1/models",
                headers=headers,
                timeout=self.timeout,
                verify=self.verify_ssl,
            )

            if response.status_code == 200:
                return ValidationResult(
                    status=ValidationStatus.ACTIVE,
                    secret_type="openai_key",
                    is_active=True,
                    confidence=1.0,
                    details="OpenAI API key is ACTIVE",
                    risk_multiplier=1.0,
                )
            elif response.status_code == 401:
                return ValidationResult(
                    status=ValidationStatus.INACTIVE,
                    secret_type="openai_key",
                    is_active=False,
                    confidence=1.0,
                    details="OpenAI key is INVALID or REVOKED",
                    risk_multiplier=0.3,
                )
            elif response.status_code == 429:
                return ValidationResult(
                    status=ValidationStatus.RATE_LIMITED,
                    secret_type="openai_key",
                    is_active=True,
                    confidence=0.7,
                    details="OpenAI API rate limited (key likely active)",
                    risk_multiplier=0.9,
                )
            else:
                return ValidationResult(
                    status=ValidationStatus.NETWORK_ERROR,
                    secret_type="openai_key",
                    is_active=True,
                    confidence=0.5,
                    details=f"OpenAI validation returned status {response.status_code}",
                    risk_multiplier=0.9,
                )

        except Exception as e:
            return ValidationResult(
                status=ValidationStatus.NETWORK_ERROR,
                secret_type="openai_key",
                is_active=True,
                confidence=0.3,
                details=f"OpenAI validation error: {str(e)}",
                risk_multiplier=0.9,
            )

    # =========================================================================
    # JWT VALIDATION
    # =========================================================================

    def _validate_jwt(self, secret_value: str, context: Dict) -> ValidationResult:
        """Validate JWT token structure and expiry (no signature verification)."""
        try:
            # Decode without verification (just to check structure and expiry)
            parts = secret_value.split(".")
            if len(parts) != 3:
                return ValidationResult(
                    status=ValidationStatus.INACTIVE,
                    secret_type="jwt_token",
                    is_active=False,
                    confidence=0.9,
                    details="Invalid JWT format",
                    risk_multiplier=0.2,
                )

            # Decode payload (add padding)
            payload_b64 = parts[1]
            payload_b64 += "=" * (4 - len(payload_b64) % 4)
            payload = json.loads(base64.urlsafe_b64decode(payload_b64))

            # Check expiry
            exp = payload.get("exp")
            if exp:
                exp_dt = datetime.fromtimestamp(exp, tz=timezone.utc)
                now = datetime.now(timezone.utc)

                if exp_dt < now:
                    return ValidationResult(
                        status=ValidationStatus.EXPIRED,
                        secret_type="jwt_token",
                        is_active=False,
                        confidence=1.0,
                        details=f"JWT token EXPIRED on {exp_dt.isoformat()}",
                        expires_at=exp_dt,
                        risk_multiplier=0.2,
                    )
                else:
                    return ValidationResult(
                        status=ValidationStatus.ACTIVE,
                        secret_type="jwt_token",
                        is_active=True,
                        confidence=0.8,  # Can't verify signature
                        details=f"JWT token valid until {exp_dt.isoformat()}",
                        expires_at=exp_dt,
                        identity=payload.get("sub", payload.get("user", "unknown")),
                        risk_multiplier=1.0,
                    )
            else:
                # No expiry - assume active
                return ValidationResult(
                    status=ValidationStatus.ACTIVE,
                    secret_type="jwt_token",
                    is_active=True,
                    confidence=0.6,
                    details="JWT token has no expiry (cannot determine if active)",
                    identity=payload.get("sub", payload.get("user", "unknown")),
                    risk_multiplier=0.9,
                )

        except Exception as e:
            return ValidationResult(
                status=ValidationStatus.INACTIVE,
                secret_type="jwt_token",
                is_active=False,
                confidence=0.7,
                details=f"JWT decode error: {str(e)}",
                risk_multiplier=0.4,
            )

    # =========================================================================
    # OTHER VALIDATORS
    # =========================================================================

    def _validate_google_api(self, secret_value: str, context: Dict) -> ValidationResult:
        """Validate Google API key (limited - just format check)."""
        if re.match(r"^AIza[A-Za-z0-9_-]{35}$", secret_value):
            return ValidationResult(
                status=ValidationStatus.UNSUPPORTED,
                secret_type="google_api_key",
                is_active=True,
                confidence=0.6,
                details="Google API key format is valid (cannot verify without specific API)",
                risk_multiplier=0.8,
            )
        else:
            return ValidationResult(
                status=ValidationStatus.INACTIVE,
                secret_type="google_api_key",
                is_active=False,
                confidence=0.8,
                details="Google API key format is invalid",
                risk_multiplier=0.3,
            )

    def _validate_npm(self, secret_value: str, context: Dict) -> ValidationResult:
        """Validate NPM token by calling whoami."""
        try:
            headers = {
                "Authorization": f"Bearer {secret_value}",
            }

            response = requests.get(
                "https://registry.npmjs.org/-/whoami",
                headers=headers,
                timeout=self.timeout,
                verify=self.verify_ssl,
            )

            if response.status_code == 200:
                data = response.json()
                username = data.get("username", "unknown")

                return ValidationResult(
                    status=ValidationStatus.ACTIVE,
                    secret_type="npm_token",
                    is_active=True,
                    confidence=1.0,
                    details=f"NPM token is ACTIVE for '{username}'",
                    identity=username,
                    risk_multiplier=1.0,
                )
            elif response.status_code == 401:
                return ValidationResult(
                    status=ValidationStatus.INACTIVE,
                    secret_type="npm_token",
                    is_active=False,
                    confidence=1.0,
                    details="NPM token is INVALID or REVOKED",
                    risk_multiplier=0.3,
                )
            else:
                return ValidationResult(
                    status=ValidationStatus.NETWORK_ERROR,
                    secret_type="npm_token",
                    is_active=True,
                    confidence=0.5,
                    details=f"NPM validation returned status {response.status_code}",
                    risk_multiplier=0.9,
                )

        except Exception as e:
            return ValidationResult(
                status=ValidationStatus.NETWORK_ERROR,
                secret_type="npm_token",
                is_active=True,
                confidence=0.3,
                details=f"NPM validation error: {str(e)}",
                risk_multiplier=0.9,
            )

    def _validate_pypi(self, secret_value: str, context: Dict) -> ValidationResult:
        """Validate PyPI token (format check only - API doesn't support validation)."""
        if re.match(r"^pypi-[A-Za-z0-9_-]{40,}$", secret_value):
            return ValidationResult(
                status=ValidationStatus.UNSUPPORTED,
                secret_type="pypi_token",
                is_active=True,
                confidence=0.6,
                details="PyPI token format is valid (cannot verify via API)",
                risk_multiplier=0.8,
            )
        else:
            return ValidationResult(
                status=ValidationStatus.INACTIVE,
                secret_type="pypi_token",
                is_active=False,
                confidence=0.8,
                details="PyPI token format is invalid",
                risk_multiplier=0.3,
            )

    def _validate_azure(self, secret_value: str, context: Dict) -> ValidationResult:
        """Validate Azure key (format check only)."""
        # Azure keys are complex - would need tenant ID and more
        return ValidationResult(
            status=ValidationStatus.UNSUPPORTED,
            secret_type="azure_key",
            is_active=True,
            confidence=0.5,
            details="Azure key validation requires additional context (tenant ID, etc.)",
            risk_multiplier=0.8,
        )

    def _validate_database_url(self, secret_value: str, context: Dict) -> ValidationResult:
        """Validate database URL (format check - won't attempt connection)."""
        # Never actually connect to databases during scanning
        if re.match(r"^(postgres|mysql|mongodb|redis)://[^:]+:[^@]+@", secret_value):
            return ValidationResult(
                status=ValidationStatus.UNSUPPORTED,
                secret_type="database_url",
                is_active=True,
                confidence=0.7,
                details="Database URL contains credentials (not attempting connection)",
                risk_multiplier=1.0,
            )
        else:
            return ValidationResult(
                status=ValidationStatus.INACTIVE,
                secret_type="database_url",
                is_active=False,
                confidence=0.6,
                details="Database URL format appears invalid",
                risk_multiplier=0.5,
            )

    def _validate_private_key(self, secret_value: str, context: Dict) -> ValidationResult:
        """Validate private key structure."""
        if "-----BEGIN" in secret_value and "PRIVATE KEY-----" in secret_value:
            # Check if it's encrypted
            if "ENCRYPTED" in secret_value:
                return ValidationResult(
                    status=ValidationStatus.ACTIVE,
                    secret_type="private_key",
                    is_active=True,
                    confidence=0.8,
                    details="Private key is ENCRYPTED (password protected)",
                    risk_multiplier=0.6,
                )
            else:
                return ValidationResult(
                    status=ValidationStatus.ACTIVE,
                    secret_type="private_key",
                    is_active=True,
                    confidence=0.9,
                    details="Private key is UNENCRYPTED (immediate risk)",
                    risk_multiplier=1.0,
                )
        else:
            return ValidationResult(
                status=ValidationStatus.INACTIVE,
                secret_type="private_key",
                is_active=False,
                confidence=0.7,
                details="Private key format appears invalid",
                risk_multiplier=0.3,
            )

    def _validate_unknown(self, secret_value: str, context: Dict) -> ValidationResult:
        """Handle unknown secret types."""
        return ValidationResult(
            status=ValidationStatus.UNSUPPORTED,
            secret_type="unknown",
            is_active=True,  # Assume active for unknown secrets
            confidence=0.3,
            details="Unknown secret type - cannot validate",
            risk_multiplier=0.8,
        )


# =============================================================================
# BATCH VALIDATION
# =============================================================================


def validate_secrets_batch(
    secrets: List[Dict], validator: SecretValidator = None, progress_callback=None
) -> List[Dict]:
    """
    Validate a batch of secrets.

    Args:
        secrets: List of secret findings (must have 'raw_secret' or 'value' and 'secret_type')
        validator: SecretValidator instance (created if not provided)
        progress_callback: Optional callback(current, total) for progress

    Returns:
        List of secrets with 'validation' field added
    """
    if validator is None:
        validator = SecretValidator()

    results = []
    total = len(secrets)

    for i, secret in enumerate(secrets):
        if progress_callback:
            progress_callback(i + 1, total)

        # Extract secret value
        secret_value = secret.get("raw_secret", secret.get("value", secret.get("secret", "")))
        secret_type = secret.get("secret_type", secret.get("type", "unknown"))

        # Build context from other fields
        context = {k: v for k, v in secret.items() if k not in ["raw_secret", "value", "secret"]}

        # Validate
        if secret_value:
            result = validator.validate(secret_value, secret_type, context)

            # Add validation result to secret
            secret["validation"] = {
                "status": result.status.value,
                "is_active": result.is_active,
                "confidence": result.confidence,
                "details": result.details,
                "identity": result.identity,
                "scopes": result.scopes,
                "risk_multiplier": result.risk_multiplier,
                "expires_at": result.expires_at.isoformat() if result.expires_at else None,
            }

            # Update risk score based on validation
            if not result.is_active:
                secret["validation_severity"] = "LOW"
                secret["validation_note"] = "Secret is INACTIVE/REVOKED - lower priority cleanup"
            elif result.status == ValidationStatus.ACTIVE:
                secret["validation_severity"] = "CRITICAL"
                secret["validation_note"] = f"Secret is ACTIVE - immediate action required ({result.identity or ''})"
            else:
                secret["validation_severity"] = "HIGH"
                secret["validation_note"] = "Secret status uncertain - treat as active"
        else:
            secret["validation"] = {
                "status": "skipped",
                "is_active": True,
                "confidence": 0.0,
                "details": "No secret value available for validation",
                "risk_multiplier": 1.0,
            }

        results.append(secret)

    return results


# =============================================================================
# CLI INTERFACE
# =============================================================================

if __name__ == "__main__":
    logger.info("=" * 70)
    logger.info("REACHABLE Secret Validator")
    logger.info("=" * 70)
    logger.info("")

    validator = SecretValidator()

    # Test with some example patterns
    # v4.4.7: Added nosemgrep comments to prevent false positives when scanning REACHABLE itself
    # nosemgrep: generic.secrets.security.detected-stripe-api-key
    # nosemgrep: generic.secrets.security.detected-github-pat
    # nosemgrep: generic.secrets.security.detected-jwt-token
    # nosemgrep: generic.secrets.security.detected-picatic-api-key
    # nosemgrep: generic.secrets.security.detected-sendgrid-api-key
    # nosemgrep: generic.secrets.security.detected-aws-access-key-id
    test_secrets = [
        ("ghp_1234567890abcdefghijklmnopqrstuvwx", "github_token"),  # nosemgrep
        ("AKIAIOSFODNN7EXAMPLE", "aws_access_key"),  # nosemgrep
        ("sk_live_1234567890abcdefghijklmnopqrstuvwxyz", "stripe_key"),  # nosemgrep
        ("SG.abcdefghijklmnop.qrstuvwxyz123456", "sendgrid_key"),  # nosemgrep
        (
            "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwiZXhwIjoxNjAwMDAwMDAwfQ.abc",
            "jwt_token",
        ),  # nosemgrep
    ]

    logger.info("Testing secret type detection and validation:")
    logger.info("-" * 70)

    for secret, expected_type in test_secrets:
        detected = validator._detect_secret_type(secret)
        result = validator.validate(secret, detected)

        logger.info(f"\nSecret: {secret[:20]}...")
        logger.info(f" Detected type: {detected}")
        logger.info(f" Expected type: {expected_type}")
        logger.info(f" Status: {result.status.value}")
        logger.info(f" Is Active: {result.is_active}")
        logger.info(f" Confidence: {result.confidence}")
        logger.info(f" Details: {result.details}")
        logger.info(f" Risk Multiplier: {result.risk_multiplier}")

    logger.info("")
    logger.info("=" * 70)
    logger.info("Validation complete. Use --verify-secrets flag in REACHABLE to enable.")
    logger.info("=" * 70)
