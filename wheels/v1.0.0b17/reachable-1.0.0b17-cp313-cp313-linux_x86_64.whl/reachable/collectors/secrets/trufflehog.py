#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.

"""
TruffleHog Integration for REACHABLE

Integrates TruffleHog secret scanner for comprehensive secret detection.
TruffleHog provides:
- 700+ secret detectors (API keys, tokens, passwords, certificates)
- Secret verification (tests if secrets are valid by calling APIs)
- Git history scanning (finds secrets in old commits, even deleted ones)
- Lower false positives than regex-only scanners

v2.9.40: Full integration with secret verification
- TruffleHog's Verified=true means secret is ACTIVE (API call succeeded)
- TruffleHog's Verified=false means couldn't verify OR inactive
- We classify based on Verified field for risk prioritization

This complements Semgrep:
- Semgrep: Fast scan of current code (pattern matching)
- TruffleHog: Deep scan with verification + git history (800+ detectors)

Usage:
    scanner = TruffleHogScanner(app_dir)
    results = scanner.scan()

    # Results include verification status
    for secret in results.verified_secrets:
        logger.info(f"VERIFIED ACTIVE: {secret.detector_type} in {secret.file_path}")
"""

import json
import logging
import os
import re
import shutil
import subprocess
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Optional, Tuple

# Initialize module-level logger
logger = logging.getLogger(__name__)

# Minimum supported TruffleHog version.
# v3 completely rewrote the JSON output schema (DetectorName, Verified, SourceMetadata).
# v2 output is incompatible — we'd silently parse nothing and report 0 secrets.
# Does NOT constrain the user's install — warn only, never block.
TRUFFLEHOG_MIN_VERSION = (3, 0, 0)


@dataclass
class SecretFinding:
    """Individual secret finding from TruffleHog"""

    detector_type: str  # e.g., "AWS", "GitHub", "Slack"
    detector_name: str  # Full detector name
    source_type: str  # "filesystem" or "git"
    file_path: str  # File path
    line: int  # Line number
    verified: bool  # Whether secret was verified as ACTIVE
    raw_secret: str  # The actual secret (for internal use only)
    redacted: str  # Redacted version (e.g., "ghp_***")
    commit: Optional[str] = None  # Git commit SHA if from history
    extra_data: Dict = field(default_factory=dict)

    def to_dict(self) -> Dict:
        """Convert to dictionary for JSON serialization"""
        return {
            "detector_type": self.detector_type,
            "detector_name": self.detector_name,
            "source_type": self.source_type,
            "file": self.file_path,
            "line": self.line,
            "verified": self.verified,
            "is_active": self.verified,  # Alias for clarity
            "redacted": self.redacted,
            "commit": self.commit,
        }


@dataclass
class TruffleHogResults:
    """Results from TruffleHog scan"""

    total_findings: int
    verified_secrets: List[SecretFinding]  # ACTIVE secrets (verified by API call)
    unverified_secrets: List[SecretFinding]  # Found but not verified
    by_detector_type: Dict[str, int]
    by_file: Dict[str, int]
    scan_time_seconds: float
    git_history_scanned: bool
    trufflehog_version: Optional[str] = None

    @property
    def active_count(self) -> int:
        return len(self.verified_secrets)

    @property
    def unverified_count(self) -> int:
        return len(self.unverified_secrets)

    def to_dict(self) -> Dict:
        """Convert to dictionary for JSON serialization"""
        return {
            "total_findings": self.total_findings,
            "verified_active": self.active_count,
            "unverified": self.unverified_count,
            "verified_secrets": [s.to_dict() for s in self.verified_secrets],
            "unverified_secrets": [s.to_dict() for s in self.unverified_secrets],
            "by_detector_type": self.by_detector_type,
            "by_file": self.by_file,
            "scan_time_seconds": self.scan_time_seconds,
            "git_history_scanned": self.git_history_scanned,
            "trufflehog_version": self.trufflehog_version,
        }


class TruffleHogScanner:
    """
    TruffleHog secret scanner integration

    Scans for hardcoded secrets using TruffleHog's 700+ detectors
    with secret verification (calls APIs to check if secrets are active).
    """

    def __init__(self, target_dir: Path, verify_secrets: bool = True, scan_git_history: bool = False):
        """
        Initialize TruffleHog scanner

        Args:
            target_dir: Directory to scan
            verify_secrets: If True, verify secrets by calling APIs (default: True)
            scan_git_history: If True, scan git history for secrets (slower)
        """
        self.target_dir = Path(target_dir)
        self.verify_secrets = verify_secrets
        self.scan_git_history = scan_git_history
        self._trufflehog_bin = "trufflehog"  # default; may be overridden by _check_trufflehog
        self.trufflehog_available = self._check_trufflehog()
        self.trufflehog_version = self._get_version() if self.trufflehog_available else None
        if self.trufflehog_available:
            # Warn-only — user controls their own install
            self._check_version()

    def _check_trufflehog(self) -> bool:
        """Check if TruffleHog is installed.

        Note: On macOS with Homebrew (especially Apple Silicon), /opt/homebrew/bin
        may not be in Python's inherited PATH. We check common locations as fallback.
        """
        found = shutil.which("trufflehog")
        if found is not None:
            self._trufflehog_bin = found
            return True
        # Fallback: check common Homebrew/system paths not in Python's PATH
        for candidate in [
            "/opt/homebrew/bin/trufflehog",  # macOS Apple Silicon
            "/usr/local/bin/trufflehog",  # macOS Intel / Linux Homebrew
            "/usr/bin/trufflehog",  # System install
        ]:
            if Path(candidate).is_file():
                self._trufflehog_bin = candidate
                return True
        return False

    def _get_version_tuple(self) -> Optional[tuple]:
        """
        Parse installed TruffleHog version into (major, minor, patch).
        TruffleHog outputs version to stderr: 'trufflehog  3.88.1'
        Returns None if version cannot be detected.
        """
        try:
            result = subprocess.run(
                [self._trufflehog_bin, "--version"],
                capture_output=True,
                text=True,
                timeout=10,
            )
            output = (result.stdout + result.stderr).strip()
            m = re.search(r"(\d+)\.(\d+)\.(\d+)", output)
            if m:
                return (int(m.group(1)), int(m.group(2)), int(m.group(3)))
        except Exception:
            pass
        return None

    def _get_version(self) -> Optional[str]:
        """Return version as human-readable string, or None."""
        ver = self._get_version_tuple()
        return ".".join(str(v) for v in ver) if ver else None

    def _check_version(self) -> bool:
        """
        Warn if the installed TruffleHog is below TRUFFLEHOG_MIN_VERSION.
        Never blocks execution — the user controls their install.
        Returns True always (caller decides whether to proceed).
        """
        ver = self._get_version_tuple()
        if ver is None:
            logger.warning(
                f"TruffleHog version could not be detected ({self._trufflehog_bin}). "
                f"Minimum recommended: {'.'.join(str(v) for v in TRUFFLEHOG_MIN_VERSION)}. "
                "Proceeding anyway — v2 JSON schema is incompatible and will produce 0 findings."
            )
            return True
        if ver < TRUFFLEHOG_MIN_VERSION:
            min_str = ".".join(str(v) for v in TRUFFLEHOG_MIN_VERSION)
            ver_str = ".".join(str(v) for v in ver)
            logger.warning(
                f"TruffleHog {ver_str} is below the minimum recommended version {min_str}. "
                "The JSON output schema changed in v3 — secret findings may be empty. "
                "Upgrade with: brew upgrade trufflehog"
            )
        return True

    def is_available(self) -> bool:
        """Check if TruffleHog is available"""
        return self.trufflehog_available

    def scan(self) -> Optional[TruffleHogResults]:
        """
        Run TruffleHog scan

        Returns:
            TruffleHogResults object or None if TruffleHog not available
        """
        if not self.trufflehog_available:
            return None

        import time

        start_time = time.time()

        is_git_repo = (self.target_dir / ".git").exists()

        if is_git_repo and self.scan_git_history:
            raw_output = self._scan_git()
        else:
            raw_output = self._scan_filesystem()

        scan_time = time.time() - start_time

        return self._parse_results(raw_output, scan_time, is_git_repo and self.scan_git_history)

    def _scan_filesystem(self) -> str:
        """Scan filesystem for secrets (current code only)"""
        cmd = [
            self._trufflehog_bin,
            "filesystem",
            str(self.target_dir),
            "--json",
            "--no-update",
        ]

        if not self.verify_secrets:
            cmd.append("--no-verification")

        try:
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=300)
            return result.stdout
        except subprocess.TimeoutExpired:
            logger.info("        TruffleHog scan timed out (>5 minutes)")
            return ""
        except Exception as e:
            logger.info(f" TruffleHog scan failed: {e}")
            return ""

    def _scan_git(self) -> str:
        """Scan git history for secrets"""
        cmd = [
            self._trufflehog_bin,
            "git",
            f"file://{self.target_dir}",
            "--json",
            "--no-update",
        ]

        if not self.verify_secrets:
            cmd.append("--no-verification")

        try:
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=600)
            return result.stdout
        except subprocess.TimeoutExpired:
            logger.info("        TruffleHog git scan timed out (>10 minutes)")
            return ""
        except Exception as e:
            logger.info(f" TruffleHog git scan failed: {e}")
            return ""

    def _parse_results(self, raw_output: str, scan_time: float, git_scanned: bool) -> TruffleHogResults:
        """Parse TruffleHog JSON output"""
        verified_list = []
        unverified_list = []
        by_detector = {}
        by_file = {}

        if not raw_output:
            return TruffleHogResults(
                total_findings=0,
                verified_secrets=[],
                unverified_secrets=[],
                by_detector_type={},
                by_file={},
                scan_time_seconds=scan_time,
                git_history_scanned=git_scanned,
                trufflehog_version=self.trufflehog_version,
            )

        # TruffleHog outputs one JSON object per line (NDJSON)
        for line in raw_output.strip().split("\n"):
            if not line:
                continue

            try:
                finding = json.loads(line)

                detector_name = finding.get("DetectorName", "Unknown")
                detector_type = finding.get("DetectorType", 0)
                is_verified = finding.get("Verified", False)
                raw_secret = finding.get("Raw", "")
                redacted = finding.get("Redacted", "")

                detector_type_name = self._get_detector_type_name(detector_type, detector_name)

                source_metadata = finding.get("SourceMetadata", {})
                data = source_metadata.get("Data", {})

                file_path = "unknown"
                line_number = 0
                commit_sha = None

                if "Filesystem" in data:
                    file_path = data["Filesystem"].get("file", "unknown")
                    line_number = data["Filesystem"].get("line", 0)
                elif "Git" in data:
                    file_path = data["Git"].get("file", "unknown")
                    line_number = data["Git"].get("line", 0)
                    commit_sha = data["Git"].get("commit", None)

                # Make path relative
                try:
                    if os.path.isabs(file_path):
                        file_path = os.path.relpath(file_path, self.target_dir)
                except Exception as e:
                    logger.debug(f"TruffleHog: could not make path relative ({file_path}): {e}")

                secret_finding = SecretFinding(
                    detector_type=detector_type_name,
                    detector_name=detector_name,
                    source_type="git" if commit_sha else "filesystem",
                    file_path=file_path,
                    line=line_number,
                    verified=is_verified,
                    raw_secret=raw_secret,
                    redacted=redacted,
                    commit=commit_sha,
                )

                if is_verified:
                    verified_list.append(secret_finding)
                else:
                    unverified_list.append(secret_finding)

                by_detector[detector_type_name] = by_detector.get(detector_type_name, 0) + 1
                by_file[file_path] = by_file.get(file_path, 0) + 1

            except json.JSONDecodeError as e:
                logger.debug(f"TruffleHog: skipping malformed JSON line: {e}")
                continue
            except Exception as e:
                logger.warning(f"TruffleHog: error parsing finding: {e}")
                continue

        return TruffleHogResults(
            total_findings=len(verified_list) + len(unverified_list),
            verified_secrets=verified_list,
            unverified_secrets=unverified_list,
            by_detector_type=by_detector,
            by_file=by_file,
            scan_time_seconds=scan_time,
            git_history_scanned=git_scanned,
            trufflehog_version=self.trufflehog_version,
        )

    def _get_detector_type_name(self, detector_type: int, detector_name: str) -> str:
        """Map detector type to human-readable name"""
        for known_type in [
            "AWS",
            "GitHub",
            "GitLab",
            "Slack",
            "Stripe",
            "Azure",
            "Google",
            "NPM",
            "PyPI",
            "Twilio",
            "SendGrid",
            "JWT",
            "SSH",
            "RSA",
            "OpenAI",
            "Anthropic",
            "HuggingFace",
            "MongoDB",
            "Postgres",
        ]:
            if known_type.lower() in detector_name.lower():
                return known_type
        return detector_name if detector_name != "Unknown" else "Generic"


def merge_trufflehog_with_semgrep(
    trufflehog_results: TruffleHogResults, semgrep_findings: List[Dict]
) -> Tuple[List[Dict], Dict]:
    """
    Merge TruffleHog verification status into Semgrep findings.

    Returns:
        (merged_findings, validation_stats)
    """
    if not trufflehog_results:
        return semgrep_findings, {"active": 0, "inactive": 0, "unverified": len(semgrep_findings)}

    # Build index of TruffleHog findings by file
    th_by_file = {}
    for secret in trufflehog_results.verified_secrets:
        if secret.file_path not in th_by_file:
            th_by_file[secret.file_path] = []
        th_by_file[secret.file_path].append((secret, True))

    for secret in trufflehog_results.unverified_secrets:
        if secret.file_path not in th_by_file:
            th_by_file[secret.file_path] = []
        th_by_file[secret.file_path].append((secret, None))

    merged = []
    matched_th = set()
    active_count = 0
    inactive_count = 0
    unverified_count = 0

    for finding in semgrep_findings:
        file_path = finding.get("path", finding.get("file", ""))
        line = finding.get("start", {}).get("line", finding.get("line", 0))
        file_norm = file_path.replace("\\", "/").lstrip("./")

        best_match = None
        best_distance = float("inf")

        for th_file, th_findings in th_by_file.items():
            th_norm = th_file.replace("\\", "/").lstrip("./")
            if th_norm == file_norm or th_norm.endswith(file_norm) or file_norm.endswith(th_norm):
                for th_finding, is_active in th_findings:
                    distance = abs(th_finding.line - line)
                    if distance < best_distance and distance <= 5:
                        best_distance = distance
                        best_match = (th_finding, is_active)
                        matched_th.add(id(th_finding))

        if best_match:
            th_finding, is_active = best_match
            finding["trufflehog_verified"] = True
            finding["is_active"] = is_active if is_active is not None else True
            finding["verified_active"] = is_active
            finding["verification_source"] = "trufflehog"
            finding["trufflehog_detector"] = th_finding.detector_type

            if is_active is True:
                finding["validation"] = {
                    "status": "active",
                    "is_active": True,
                    "confidence": 1.0,
                    "details": f"TruffleHog verified: {th_finding.detector_type} secret is ACTIVE",
                    "risk_multiplier": 1.0,
                }
                active_count += 1
            else:
                finding["validation"] = {
                    "status": "unverified",
                    "is_active": True,
                    "confidence": 0.5,
                    "details": f"TruffleHog found: {th_finding.detector_type} (not verified)",
                    "risk_multiplier": 0.8,
                }
                unverified_count += 1
        else:
            finding["trufflehog_verified"] = False
            finding["verification_source"] = "none"
            unverified_count += 1

        merged.append(finding)

    # Add TruffleHog-only findings
    for th_file, th_findings in th_by_file.items():
        for th_finding, is_active in th_findings:
            if id(th_finding) not in matched_th:
                new_finding = {
                    "path": th_finding.file_path,
                    "file": th_finding.file_path,
                    "line": th_finding.line,
                    "start": {"line": th_finding.line},
                    "check_id": f"trufflehog.{th_finding.detector_type.lower()}",
                    "rule_id": f"trufflehog.{th_finding.detector_type.lower()}",
                    "message": f"{th_finding.detector_type} secret detected by TruffleHog",
                    "severity": "ERROR" if is_active else "WARNING",
                    "is_actual_secret": True,
                    "secret_type": th_finding.detector_type.lower(),
                    "trufflehog_verified": True,
                    "is_active": is_active if is_active is not None else True,
                    "verified_active": is_active,
                    "verification_source": "trufflehog",
                    "source": "trufflehog",
                }

                if is_active:
                    new_finding["validation"] = {
                        "status": "active",
                        "is_active": True,
                        "confidence": 1.0,
                        "details": f"TruffleHog verified: {th_finding.detector_type} secret is ACTIVE",
                        "risk_multiplier": 1.0,
                    }
                    active_count += 1
                else:
                    new_finding["validation"] = {
                        "status": "unverified",
                        "is_active": True,
                        "confidence": 0.5,
                        "details": f"TruffleHog found: {th_finding.detector_type}",
                        "risk_multiplier": 0.8,
                    }
                    unverified_count += 1

                merged.append(new_finding)

    stats = {
        "active": active_count,
        "inactive": inactive_count,
        "unverified": unverified_count,
        "total_validated": active_count + inactive_count,
        "verification_enabled": True,
        "source": "trufflehog",
    }

    return merged, stats
