# Copyright © 2026 Sthenos Security. All rights reserved.
"""
Secret detection collectors.

Modules:
- semgrep     - Semgrep-based secret and code pattern detection
- trufflehog  - TruffleHog deep secret scanning with Git history
- entropy     - Shannon entropy-based secret detection
- env         - Environment variable and .env file secret scanning
- loader      - Secret loader/usage pattern detection (reachability)
- validator   - Live API credential validation
- enhanced    - Enhanced secret classification and remediation
"""
