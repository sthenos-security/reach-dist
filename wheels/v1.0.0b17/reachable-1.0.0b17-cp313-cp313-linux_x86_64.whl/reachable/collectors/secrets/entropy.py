#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.

"""
Advanced Entropy Scanner with Sliding Window Analysis

Detects encrypted/obfuscated payloads hidden in larger files using
sliding window entropy analysis. Can catch small 200-byte encrypted
payloads hidden in 1MB files.

Key Features:
- Sliding window entropy (256 bytes default)
- File-level entropy (fallback)
- Configurable thresholds
- High-performance scanning
- Detailed reporting with exact byte ranges

Entropy Thresholds:
- 0.0 - 3.0: Low entropy (normal code, config)
- 3.0 - 5.0: Medium entropy (mixed content)
- 5.0 - 6.5: Elevated entropy (compressed/minified)
- 6.5 - 7.5: High entropy (encrypted/obfuscated)
- 7.5 - 8.0: Very high entropy (random/encrypted)

Usage:
    from entropy_scanner import EntropyScanner

    scanner = EntropyScanner(window_size=256, threshold=6.5)
    results = scanner.scan_file("package/malicious.js")

    if results.has_high_entropy:
        logger.info(f" High entropy detected at {results.high_entropy_windows}")
"""

import logging
import math
from collections import Counter
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Optional, Tuple

# Initialize module-level logger
logger = logging.getLogger(__name__)


@dataclass
class EntropyWindow:
    """Single entropy window result"""

    start_byte: int
    end_byte: int
    entropy: float
    severity: str  # "low", "medium", "elevated", "high", "critical"

    def __repr__(self):
        return f"Window[{self.start_byte}-{self.end_byte}]: {self.entropy:.2f} ({self.severity})"


@dataclass
class EntropyResults:
    """Complete entropy scan results"""

    file_path: str
    file_size: int

    # File-level entropy
    overall_entropy: float

    # Sliding window results
    window_size: int
    total_windows: int
    high_entropy_windows: List[EntropyWindow] = field(default_factory=list)
    critical_entropy_windows: List[EntropyWindow] = field(default_factory=list)

    # Statistical summary
    max_entropy: float = 0.0
    avg_entropy: float = 0.0
    min_entropy: float = 0.0

    # Detection status
    has_high_entropy: bool = False
    has_critical_entropy: bool = False

    # Detailed findings
    suspicious_ranges: List[Tuple[int, int, float]] = field(default_factory=list)

    def to_dict(self) -> Dict:
        """Convert to dictionary"""
        return {
            "file_path": self.file_path,
            "file_size": self.file_size,
            "overall_entropy": round(self.overall_entropy, 3),
            "window_analysis": {
                "window_size": self.window_size,
                "total_windows": self.total_windows,
                "max_entropy": round(self.max_entropy, 3),
                "avg_entropy": round(self.avg_entropy, 3),
                "min_entropy": round(self.min_entropy, 3),
            },
            "detections": {
                "has_high_entropy": self.has_high_entropy,
                "has_critical_entropy": self.has_critical_entropy,
                "high_entropy_count": len(self.high_entropy_windows),
                "critical_entropy_count": len(self.critical_entropy_windows),
            },
            "suspicious_ranges": [
                {
                    "start": start,
                    "end": end,
                    "entropy": round(entropy, 3),
                    "byte_range": f"{start}-{end}",
                    "size_bytes": end - start,
                }
                for start, end, entropy in self.suspicious_ranges
            ],
            "high_entropy_windows": [
                {
                    "start_byte": w.start_byte,
                    "end_byte": w.end_byte,
                    "entropy": round(w.entropy, 3),
                    "severity": w.severity,
                }
                for w in self.high_entropy_windows[:10]  # First 10 only
            ],
        }


class EntropyScanner:
    """
    Advanced entropy scanner with sliding window analysis

    Detects encrypted/obfuscated payloads that might be hidden in:
    - Large JavaScript bundles
    - Python packages
    - Binary files
    - Any text/binary content
    """

    # Severity thresholds
    THRESHOLD_LOW = 3.0
    THRESHOLD_MEDIUM = 5.0
    THRESHOLD_ELEVATED = 6.5
    THRESHOLD_HIGH = 7.0
    THRESHOLD_CRITICAL = 7.5

    def __init__(self, window_size: int = 256, threshold: float = 6.5, step_size: Optional[int] = None):
        """
        Initialize entropy scanner

        Args:
            window_size: Size of sliding window in bytes (default: 256)
            threshold: Entropy threshold for alerts (default: 6.5)
            step_size: Step size for sliding window (default: window_size // 4)
        """
        self.window_size = window_size
        self.threshold = threshold
        self.step_size = step_size or (window_size // 4)  # 75% overlap

    def calculate_entropy(self, data: bytes) -> float:
        """
        Calculate Shannon entropy of byte sequence

        Returns:
            Entropy value between 0.0 (no randomness) and 8.0 (max randomness)
        """
        if not data:
            return 0.0

        # Count byte frequencies
        counter = Counter(data)
        length = len(data)

        # Calculate Shannon entropy
        entropy = 0.0
        for count in counter.values():
            probability = count / length
            if probability > 0:
                entropy -= probability * math.log2(probability)

        return entropy

    def classify_entropy(self, entropy: float) -> str:
        """Classify entropy value into severity levels"""
        if entropy >= self.THRESHOLD_CRITICAL:
            return "critical"
        elif entropy >= self.THRESHOLD_HIGH:
            return "high"
        elif entropy >= self.THRESHOLD_ELEVATED:
            return "elevated"
        elif entropy >= self.THRESHOLD_MEDIUM:
            return "medium"
        else:
            return "low"

    def scan_file(self, file_path: str) -> EntropyResults:
        """
        Scan file with sliding window entropy analysis

        Args:
            file_path: Path to file to scan

        Returns:
            EntropyResults object with detailed findings
        """
        path = Path(file_path)

        if not path.exists():
            raise FileNotFoundError(f"File not found: {file_path}")

        # Read file
        try:
            with open(path, "rb") as f:
                data = f.read()
        except Exception as e:
            raise IOError(f"Error reading file: {e}") from e

        file_size = len(data)

        # Calculate overall file entropy
        overall_entropy = self.calculate_entropy(data)

        # Initialize results
        results = EntropyResults(
            file_path=str(path),
            file_size=file_size,
            overall_entropy=overall_entropy,
            window_size=self.window_size,
            total_windows=0,
        )

        # If file is smaller than window, only do overall scan
        if file_size < self.window_size:
            results.total_windows = 1
            results.max_entropy = overall_entropy
            results.avg_entropy = overall_entropy
            results.min_entropy = overall_entropy

            if overall_entropy >= self.threshold:
                results.has_high_entropy = True
                window = EntropyWindow(
                    start_byte=0,
                    end_byte=file_size,
                    entropy=overall_entropy,
                    severity=self.classify_entropy(overall_entropy),
                )
                results.high_entropy_windows.append(window)
                results.suspicious_ranges.append((0, file_size, overall_entropy))

            return results

        # Sliding window scan
        entropies = []
        window_results = []

        for start in range(0, file_size - self.window_size + 1, self.step_size):
            end = start + self.window_size
            window_data = data[start:end]

            entropy = self.calculate_entropy(window_data)
            entropies.append(entropy)

            severity = self.classify_entropy(entropy)
            window = EntropyWindow(start_byte=start, end_byte=end, entropy=entropy, severity=severity)
            window_results.append(window)

            # Track high entropy windows
            if entropy >= self.threshold:
                results.high_entropy_windows.append(window)
                results.has_high_entropy = True

                # Group consecutive high-entropy windows into ranges
                if not results.suspicious_ranges or results.suspicious_ranges[-1][1] < start:
                    # New range
                    results.suspicious_ranges.append((start, end, entropy))
                else:
                    # Extend existing range
                    last_start, _, last_entropy = results.suspicious_ranges[-1]
                    max_entropy = max(last_entropy, entropy)
                    results.suspicious_ranges[-1] = (last_start, end, max_entropy)

            if entropy >= self.THRESHOLD_CRITICAL:
                results.critical_entropy_windows.append(window)
                results.has_critical_entropy = True

        # Calculate statistics
        results.total_windows = len(entropies)
        if entropies:
            results.max_entropy = max(entropies)
            results.avg_entropy = sum(entropies) / len(entropies)
            results.min_entropy = min(entropies)

        return results

    def scan_directory(self, directory: str, extensions: Optional[List[str]] = None) -> Dict[str, EntropyResults]:
        """
        Scan all files in directory

        Args:
            directory: Path to directory
            extensions: List of file extensions to scan (default: all files)

        Returns:
            Dictionary mapping file paths to EntropyResults
        """
        dir_path = Path(directory)
        if not dir_path.is_dir():
            raise NotADirectoryError(f"Not a directory: {directory}")

        results = {}

        # Default extensions if none specified
        if extensions is None:
            extensions = [".js", ".py", ".json", ".txt", ".sh", ".yml", ".yaml"]

        for file_path in dir_path.rglob("*"):
            if file_path.is_file():
                if extensions and file_path.suffix not in extensions:
                    continue

                try:
                    file_results = self.scan_file(str(file_path))
                    if file_results.has_high_entropy:
                        results[str(file_path)] = file_results
                except Exception as e:
                    logger.info(f"Warning: Could not scan {file_path}: {e}")

        return results

    def generate_report(self, results: EntropyResults) -> str:
        """Generate human-readable report"""
        severity_emoji = {"low": "", "medium": "", "elevated": "", "high": "", "critical": ""}

        overall_severity = self.classify_entropy(results.overall_entropy)

        report = []
        report.append("=" * 70)
        report.append(f"ENTROPY SCAN REPORT: {Path(results.file_path).name}")
        report.append("=" * 70)
        report.append(f"File: {results.file_path}")
        report.append(f"Size: {results.file_size:,} bytes")
        report.append("")
        report.append(
            f"Overall Entropy: {results.overall_entropy:.3f} {severity_emoji.get(overall_severity, '')} ({overall_severity})"
        )
        report.append("")

        if results.total_windows > 1:
            report.append("SLIDING WINDOW ANALYSIS:")
            report.append(f"  Window Size: {results.window_size} bytes")
            report.append(f"  Total Windows: {results.total_windows}")
            report.append(f"  Max Entropy: {results.max_entropy:.3f}")
            report.append(f"  Avg Entropy: {results.avg_entropy:.3f}")
            report.append(f"  Min Entropy: {results.min_entropy:.3f}")
            report.append("")

        if results.has_high_entropy:
            report.append(f"  HIGH ENTROPY DETECTED: {len(results.high_entropy_windows)} windows")
            report.append("")
            report.append("SUSPICIOUS RANGES:")
            for start, end, entropy in results.suspicious_ranges:
                size = end - start
                severity = self.classify_entropy(entropy)
                emoji = severity_emoji.get(severity, "")
                report.append(
                    f"  {emoji} Bytes {start:,} - {end:,} ({size:,} bytes): Entropy {entropy:.3f} ({severity})"
                )
            report.append("")

            if results.critical_entropy_windows:
                report.append(f" CRITICAL ENTROPY: {len(results.critical_entropy_windows)} windows (likely encrypted)")
                for window in results.critical_entropy_windows[:5]:
                    report.append(f"  Bytes {window.start_byte:,} - {window.end_byte:,}: {window.entropy:.3f}")
                report.append("")
        else:
            report.append(" No high entropy detected - file appears normal")
            report.append("")

        report.append("=" * 70)

        return "\n".join(report)


def main():
    """CLI entry point for testing"""
    import sys

    if len(sys.argv) < 2:
        logger.info("Usage: python entropy_scanner.py <file_or_directory>")
        logger.info("\nExamples:")
        logger.info("  python entropy_scanner.py malicious.js")
        logger.info("  python entropy_scanner.py ./node_modules/suspicious-package/")
        sys.exit(1)

    target = sys.argv[1]
    path = Path(target)

    scanner = EntropyScanner(window_size=256, threshold=6.5)

    if path.is_file():
        # Scan single file
        results = scanner.scan_file(target)
        logger.info(str(scanner.generate_report(results)))

        if results.has_high_entropy:
            sys.exit(1)

    elif path.is_dir():
        # Scan directory
        logger.info(f"Scanning directory: {target}")
        logger.info("")

        all_results = scanner.scan_directory(target)

        if all_results:
            logger.info(f"Found {len(all_results)} files with high entropy:")
            logger.info("")

            for file_path, file_results in sorted(all_results.items()):
                logger.info(str(scanner.generate_report(file_results)))
                logger.info("")

            sys.exit(1)
        else:
            logger.info(" No high entropy files detected")
    else:
        logger.info(f"Error: {target} is not a file or directory")
        sys.exit(2)


if __name__ == "__main__":
    main()
