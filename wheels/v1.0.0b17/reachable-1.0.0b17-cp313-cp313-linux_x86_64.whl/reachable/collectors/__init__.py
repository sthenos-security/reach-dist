# Copyright © 2026 Sthenos Security. All rights reserved.
"""
Collectors package - modular security scanners.

Each sub-package contains one category of security analysis:
- malware/    - Malware detection (GuardDog, YARA, SAST, sandbox)
- secrets/    - Secret detection (Semgrep, TruffleHog, entropy)
- vulns/      - Vulnerability detection (Grype, GHSA, ExploitDB)
- callgraph/  - Call graph analysis (Python, Go, Java, JS)
- sbom/       - SBOM generation (Syft, ecosystem detection)
- semgrep/    - Code weakness detection (Semgrep rules, OWASP)
- ai/         - AI/LLM security analysis
- dlp/        - Data Loss Prevention / PII detection
- iac/        - Infrastructure as Code scanning
"""
