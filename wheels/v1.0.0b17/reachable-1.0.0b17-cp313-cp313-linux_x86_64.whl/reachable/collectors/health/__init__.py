#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.

"""
Package Health Collector

Supply chain health analysis: abandoned packages, dependency confusion,
deprecated dependencies, maintainer risk.

Usage:
    from reachable.collectors.health import run_package_health

    results = run_package_health(sbom_path, purl_resolution_map)
    for r in results:
        print(f"{r.name}@{r.version}: {r.status}")
"""

from .analyzer import (
    HealthSignal,
    PackageHealthResult,
    analyze_private_package,
    analyze_public_package,
)
from .collector import (
    PackageHealthCollector,
    classify_packages,
    parse_sbom_packages,
    run_package_health,
)
from .normalizer import (
    normalize_for_dashboard,
    results_to_db_rows,
)
from .registry import (
    PackageMetadata,
    check_public_exists,
    fetch_metadata,
    fetch_npm,
    fetch_pypi,
)

__all__ = [
    "PackageHealthCollector",
    "run_package_health",
    "parse_sbom_packages",
    "classify_packages",
    "PackageMetadata",
    "PackageHealthResult",
    "HealthSignal",
    "analyze_public_package",
    "analyze_private_package",
    "fetch_metadata",
    "fetch_npm",
    "fetch_pypi",
    "check_public_exists",
    "normalize_for_dashboard",
    "results_to_db_rows",
]
