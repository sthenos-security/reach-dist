#!/usr/bin/env python3
# Copyright 2026 Sthenos Security. All rights reserved.

"""
Pipeline Integration Patch

Copy-paste this block into scan.py / pipeline.py after Step 1b (PURL enrichment)
and before Step 2 (Grype vulnerability scan).

This is NOT a standalone file -- it's a reference for where to insert the call.
"""

# --- INSERT AFTER: PURL enrichment (step 1b) ---
# --- INSERT BEFORE: Grype vulnerability scan (step 2) ---

STEP_1C_CODE = '''
    # Step 1c: Package Health (supply chain advisory signals)
    try:
        from reachable.collectors.health import run_package_health
        from reachable.collectors.health.normalizer import results_to_db_rows

        logger.info("Step 1c: Checking package health...")
        health_results = run_package_health(
            sbom_path=sbom_path,
            purl_resolution_map=getattr(scan_context, 'purl_resolution_map', None),
            timeout_budget=30.0,
        )

        if health_results and db:
            rows = results_to_db_rows(health_results, scan_id)
            db.store_package_health(scan_id, rows)
            logger.info(f"  Stored {len(rows)} package health advisories")
        elif health_results:
            # No DB -- store in scan context for dashboard normalizer
            scan_context.health_results = health_results
            logger.info(f"  {len(health_results)} package health advisories (in-memory)")
        else:
            logger.info("  All packages healthy -- no advisories")

    except Exception as exc:
        logger.warning(f"  Package health check failed (non-fatal): {exc}")
        # Package health is advisory -- never block the scan
'''

# --- INSERT INTO: loaders.py load_from_database() ---
LOADERS_PATCH = '''
    # Load package health advisories
    try:
        health_rows = db.load_package_health(scan_id)
        status_counts = {"abandoned": 0, "deprecated": 0, "confused": 0, "info": 0}
        for h in health_rows:
            s = h.get("status", "")
            if s in status_counts:
                status_counts[s] += 1

        data["package_health"] = {
            "summary": {
                "total_advisories": len(health_rows),
                **status_counts,
            },
            "advisories": health_rows,
        }
    except Exception as exc:
        logger.warning(f"  Could not load package health: {exc}")
        data["package_health"] = {"summary": {"total_advisories": 0}, "advisories": []}
'''

# --- INSERT INTO: template-shell.html tab buttons ---
TEMPLATE_TAB_BUTTON = '''
    <!-- Add between DLP/PII and GRC/Compliance tab buttons -->
    <button class="tab-btn" data-tab="supply-chain">
        <span class="tab-icon">\U0001F4E6</span> Supply Chain
    </button>
'''

TEMPLATE_TAB_CONTENT = '''
    <!-- Add between DLP/PII and GRC/Compliance tab content divs -->
    <div id="supply-chain" class="tab-content" style="display:none;"></div>
'''

# --- INSERT INTO: main.js tab switching logic ---
MAIN_JS_TAB_RENDER = '''
    // In the tab switching function, add this case:
    case 'supply-chain':
        renderSupplyChain('supply-chain');
        break;
'''
