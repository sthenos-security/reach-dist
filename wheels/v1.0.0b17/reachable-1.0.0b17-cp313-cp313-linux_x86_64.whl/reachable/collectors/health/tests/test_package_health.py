#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.

"""
Unit tests for the Package Health feature (T7).

Covers:
  - registry.py       : PackageMetadata, _parse_iso_date, _days_since, fetch dispatcher
  - analyzer.py       : HealthSignal, PackageHealthResult, _resolve_status,
                        analyze_public_package, analyze_private_package
  - collector.py      : parse_sbom_packages, classify_packages,
                        _PackageHealthReport, PackageHealthCollector
  - normalizer.py     : normalize_for_dashboard, results_to_db_rows
  - confusion.py      : ConfusionResult, evaluate_confusion, detect_private_packages
  - storage.py        : store_package_health / load_package_health round-trip
  - loaders.py        : _load_package_health from raw cursor
"""

import gzip
import json
import os
import sqlite3
import tempfile
import unittest
from datetime import datetime, timedelta, timezone
from typing import Dict, List
from unittest.mock import MagicMock, patch

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _iso(days_ago: int) -> str:
    """Return ISO-8601 UTC string for N days ago."""
    dt = datetime.now(timezone.utc) - timedelta(days=days_ago)
    return dt.strftime("%Y-%m-%dT%H:%M:%SZ")


def _make_meta(
    name="requests",
    version="2.28.0",
    ecosystem="pypi",
    fetched=True,
    days_ago=None,
    deprecated=None,
    yanked=False,
    maintainer_count=2,
    maintainers=None,
    repository_url="https://github.com/psf/requests",
    latest_version="2.31.0",
    error=None,
):
    """Build a PackageMetadata for testing."""
    from reachable.collectors.health.registry import PackageMetadata
    meta = PackageMetadata(
        name=name,
        version=version,
        ecosystem=ecosystem,
        fetched=fetched,
        latest_version=latest_version,
        deprecated=deprecated,
        yanked=yanked,
        maintainer_count=maintainer_count,
        maintainers=maintainers or ["alice", "bob"][:maintainer_count],
        repository_url=repository_url,
        error=error,
    )
    if days_ago is not None:
        meta.latest_publish_iso = _iso(days_ago)
        meta.days_since_last_publish = days_ago
    return meta


def _make_result(
    name="requests",
    version="2.28.0",
    ecosystem="pypi",
    status="healthy",
    signals=None,
    meta=None,
):
    """Build a PackageHealthResult for testing."""
    from reachable.collectors.health.analyzer import PackageHealthResult
    r = PackageHealthResult(
        name=name,
        version=version,
        ecosystem=ecosystem,
        status=status,
        signals=signals or [],
        metadata=meta,
    )
    return r


def _make_sbom(packages: List[Dict]) -> str:
    """Write a minimal Syft SBOM JSON to a temp file. Returns path."""
    artifacts = []
    for p in packages:
        artifacts.append({
            "name": p["name"],
            "version": p.get("version", "1.0"),
            "language": p.get("language", "python"),
            "purl": p.get("purl", f"pkg:pypi/{p['name']}@{p.get('version','1.0')}"),
            "locations": [{"path": "requirements.txt"}],
        })
    data = {"artifacts": artifacts}
    fd, path = tempfile.mkstemp(suffix=".json")
    os.write(fd, json.dumps(data).encode())
    os.close(fd)
    return path


def _make_db_with_schema() -> str:
    """Create a temp SQLite DB with the package_health table. Returns path."""
    fd, path = tempfile.mkstemp(suffix=".db")
    os.close(fd)
    con = sqlite3.connect(path)
    con.executescript("""
        CREATE TABLE IF NOT EXISTS scans (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            branch TEXT, commit_hash TEXT, short_hash TEXT,
            scan_dir TEXT, version TEXT, status TEXT DEFAULT 'running',
            timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE IF NOT EXISTS package_health (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            scan_id INTEGER NOT NULL,
            package_name TEXT NOT NULL,
            package_version TEXT,
            ecosystem TEXT NOT NULL,
            purl TEXT,
            status TEXT NOT NULL DEFAULT 'healthy',
            severity TEXT DEFAULT 'INFO',
            signals TEXT DEFAULT '[]',
            title TEXT,
            detail TEXT,
            last_publish_date TEXT,
            latest_version TEXT,
            deprecated_msg TEXT,
            maintainer_count INTEGER,
            has_repository INTEGER DEFAULT 1,
            is_deprecated INTEGER DEFAULT 0,
            is_private INTEGER DEFAULT 0,
            is_direct INTEGER DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
    """)
    con.commit()
    con.close()
    return path


# ===========================================================================
# 1. registry.py
# ===========================================================================

class TestPackageMetadata(unittest.TestCase):

    def test_defaults(self):
        from reachable.collectors.health.registry import PackageMetadata
        m = PackageMetadata(name="foo", version="1.0", ecosystem="npm")
        self.assertFalse(m.fetched)
        self.assertIsNone(m.error)
        self.assertEqual(m.maintainer_count, 0)
        self.assertEqual(m.maintainers, [])

    def test_to_dict_roundtrip(self):
        m = _make_meta(days_ago=100)
        d = m.to_dict()
        self.assertEqual(d["name"], "requests")
        self.assertEqual(d["ecosystem"], "pypi")
        self.assertEqual(d["maintainer_count"], 2)
        self.assertIn("latest_publish_iso", d)

    def test_fetched_false_on_error(self):
        from reachable.collectors.health.registry import PackageMetadata
        m = PackageMetadata(name="x", version="1", ecosystem="npm", error="timeout")
        self.assertFalse(m.fetched)


class TestParseIsoDate(unittest.TestCase):

    def test_z_suffix(self):
        from reachable.collectors.health.registry import _parse_iso_date
        dt = _parse_iso_date("2022-01-15T10:30:00Z")
        self.assertIsNotNone(dt)
        self.assertEqual(dt.year, 2022)

    def test_offset(self):
        from reachable.collectors.health.registry import _parse_iso_date
        dt = _parse_iso_date("2022-01-15T10:30:00+00:00")
        self.assertIsNotNone(dt)

    def test_none_returns_none(self):
        from reachable.collectors.health.registry import _parse_iso_date
        self.assertIsNone(_parse_iso_date(None))

    def test_garbage_returns_none(self):
        from reachable.collectors.health.registry import _parse_iso_date
        self.assertIsNone(_parse_iso_date("not-a-date"))


class TestDaysSince(unittest.TestCase):

    def test_recent(self):
        from reachable.collectors.health.registry import _days_since
        days = _days_since(_iso(10))
        self.assertIsNotNone(days)
        self.assertAlmostEqual(days, 10, delta=1)

    def test_old(self):
        from reachable.collectors.health.registry import _days_since
        days = _days_since(_iso(800))
        self.assertGreater(days, 700)

    def test_none(self):
        from reachable.collectors.health.registry import _days_since
        self.assertIsNone(_days_since(None))


class TestFetchMetadataDispatcher(unittest.TestCase):

    def test_unsupported_ecosystem(self):
        from reachable.collectors.health.registry import fetch_metadata
        meta = fetch_metadata("foo", "1.0", "rust")
        self.assertFalse(meta.fetched)
        self.assertIn("unsupported_ecosystem", meta.error)

    def test_npm_dispatches(self):
        from reachable.collectors.health import registry as _reg
        original = _reg._FETCHERS["npm"]
        mock_fn = MagicMock(return_value=_make_meta(ecosystem="npm"))
        _reg._FETCHERS["npm"] = mock_fn
        try:
            _reg.fetch_metadata("express", "4.18.0", "npm")
            mock_fn.assert_called_once()
        finally:
            _reg._FETCHERS["npm"] = original

    def test_javascript_alias(self):
        from reachable.collectors.health import registry as _reg
        original = _reg._FETCHERS["javascript"]
        mock_fn = MagicMock(return_value=_make_meta(ecosystem="javascript"))
        _reg._FETCHERS["javascript"] = mock_fn
        try:
            _reg.fetch_metadata("react", "18.0.0", "javascript")
            mock_fn.assert_called_once()
        finally:
            _reg._FETCHERS["javascript"] = original

    def test_pypi_dispatches(self):
        from reachable.collectors.health import registry as _reg
        original = _reg._FETCHERS["pypi"]
        mock_fn = MagicMock(return_value=_make_meta())
        _reg._FETCHERS["pypi"] = mock_fn
        try:
            _reg.fetch_metadata("requests", "2.28.0", "pypi")
            mock_fn.assert_called_once()
        finally:
            _reg._FETCHERS["pypi"] = original

    def test_python_alias(self):
        from reachable.collectors.health import registry as _reg
        original = _reg._FETCHERS["python"]
        mock_fn = MagicMock(return_value=_make_meta())
        _reg._FETCHERS["python"] = mock_fn
        try:
            _reg.fetch_metadata("flask", "3.0.0", "python")
            mock_fn.assert_called_once()
        finally:
            _reg._FETCHERS["python"] = original


class TestFetchNpmParsing(unittest.TestCase):

    def _fake_response(self, data: dict):
        resp = MagicMock()
        resp.status_code = 200
        resp.json.return_value = data
        resp.raise_for_status = MagicMock()
        return resp

    def test_latest_version_from_dist_tags(self):
        import json

        from reachable.collectors.health.registry import fetch_npm
        data = {
            "dist-tags": {"latest": "4.18.2"},
            "time": {"4.18.2": _iso(30), "modified": _iso(30)},
            "versions": {"4.18.2": {}},
            "maintainers": [{"name": "alice"}],
        }
        with patch("reachable.collectors.health.registry._http_get",
                   return_value=(200, json.dumps(data).encode())):
            meta = fetch_npm("express", "4.18.0")
        self.assertTrue(meta.fetched)
        self.assertEqual(meta.latest_version, "4.18.2")
        self.assertEqual(meta.maintainer_count, 1)

    def test_deprecated_field(self):
        import json

        from reachable.collectors.health.registry import fetch_npm
        data = {
            "dist-tags": {"latest": "1.0.0"},
            "time": {"modified": _iso(10)},
            "versions": {"1.0.0": {"deprecated": "Use newpkg instead"}},
            "maintainers": [],
        }
        with patch("reachable.collectors.health.registry._http_get",
                   return_value=(200, json.dumps(data).encode())):
            meta = fetch_npm("oldpkg", "1.0.0")
        self.assertEqual(meta.deprecated, "Use newpkg instead")

    def test_404_not_found(self):
        import urllib.error

        from reachable.collectors.health.registry import fetch_npm
        http_err = urllib.error.HTTPError(url=None, code=404, msg="Not Found", hdrs=None, fp=None)
        with patch("reachable.collectors.health.registry._http_get", side_effect=http_err):
            meta = fetch_npm("nonexistent-pkg-xyz", "1.0.0")
        self.assertFalse(meta.fetched)
        self.assertEqual(meta.error, "not_found")

    def test_timeout(self):
        import socket

        from reachable.collectors.health.registry import fetch_npm
        with patch("reachable.collectors.health.registry._http_get",
                   side_effect=socket.timeout("timed out")):
            meta = fetch_npm("slowpkg", "1.0.0")
        self.assertFalse(meta.fetched)
        self.assertEqual(meta.error, "timeout")


class TestFetchPypiParsing(unittest.TestCase):

    def _fake_response(self, data: dict):
        resp = MagicMock()
        resp.status_code = 200
        resp.json.return_value = data
        resp.raise_for_status = MagicMock()
        return resp

    def test_basic_metadata(self):
        from reachable.collectors.health.registry import fetch_pypi
        data = {
            "info": {
                "version": "2.31.0",
                "author": "kennethreitz",
                "home_page": "https://requests.readthedocs.io",
                "project_urls": {"Source": "https://github.com/psf/requests"},
                "classifiers": [],
            },
            "releases": {
                "2.31.0": [{"upload_time_iso_8601": _iso(60), "yanked": False}],
                "2.28.0": [{"upload_time_iso_8601": _iso(400), "yanked": False}],
            },
        }
        with patch("reachable.collectors.health.registry._http_get",
                   return_value=(200, __import__('json').dumps(data).encode())):
            meta = fetch_pypi("requests", "2.28.0")
        self.assertTrue(meta.fetched)
        self.assertEqual(meta.latest_version, "2.31.0")
        self.assertEqual(meta.maintainer_count, 1)
        self.assertIn("github.com", meta.repository_url)

    def test_yanked_version(self):
        from reachable.collectors.health.registry import fetch_pypi
        data = {
            "info": {"version": "1.0.1", "author": "x", "home_page": None,
                     "project_urls": {}, "classifiers": []},
            "releases": {
                "1.0.1": [{"upload_time_iso_8601": _iso(5), "yanked": False}],
                "1.0.0": [{"upload_time_iso_8601": _iso(30), "yanked": True}],
            },
        }
        with patch("reachable.collectors.health.registry._http_get",
                   return_value=(200, __import__('json').dumps(data).encode())):
            meta = fetch_pypi("mypkg", "1.0.0")
        self.assertTrue(meta.yanked)

    def test_deprecated_via_classifier(self):
        from reachable.collectors.health.registry import fetch_pypi
        data = {
            "info": {
                "version": "1.0.0", "author": "x", "home_page": None,
                "project_urls": {},
                "classifiers": ["Development Status :: 7 - Inactive"],
            },
            "releases": {"1.0.0": [{"upload_time_iso_8601": _iso(1000), "yanked": False}]},
        }
        with patch("reachable.collectors.health.registry._http_get",
                   return_value=(200, __import__('json').dumps(data).encode())):
            meta = fetch_pypi("oldlib", "1.0.0")
        self.assertIsNotNone(meta.deprecated)


class TestCheckPublicExists(unittest.TestCase):

    def test_exists_npm(self):
        from reachable.collectors.health.registry import check_public_exists
        with patch("reachable.collectors.health.registry._http_head", return_value=200):
            self.assertTrue(check_public_exists("express", "npm"))

    def test_not_exists_pypi(self):
        from reachable.collectors.health.registry import check_public_exists
        with patch("reachable.collectors.health.registry._http_head", return_value=404):
            self.assertFalse(check_public_exists("my-private-lib", "pypi"))

    def test_network_error_returns_false(self):
        from reachable.collectors.health.registry import check_public_exists
        # _http_head catches all exceptions internally — simulate by having it raise
        # at the urlopen level so check_public_exists outer try/except catches it
        with patch("reachable.collectors.health.registry._http_head", side_effect=Exception("err")):
            self.assertFalse(check_public_exists("mypkg", "npm"))

    def test_unsupported_ecosystem_returns_false(self):
        from reachable.collectors.health.registry import check_public_exists
        self.assertFalse(check_public_exists("cargo-pkg", "rust"))


# ===========================================================================
# 2. analyzer.py
# ===========================================================================

class TestHealthSignal(unittest.TestCase):

    def test_to_dict(self):
        from reachable.collectors.health.analyzer import HealthSignal
        s = HealthSignal(signal_type="abandoned", confidence="high", detail="2 years old")
        d = s.to_dict()
        self.assertEqual(d["signal_type"], "abandoned")
        self.assertEqual(d["confidence"], "high")
        self.assertEqual(d["detail"], "2 years old")


class TestResolveStatus(unittest.TestCase):

    def setUp(self):
        from reachable.collectors.health.analyzer import HealthSignal
        self.HS = HealthSignal

    def test_empty_signals_healthy(self):
        from reachable.collectors.health.analyzer import _resolve_status
        self.assertEqual(_resolve_status([]), "healthy")

    def test_confused_wins(self):
        from reachable.collectors.health.analyzer import _resolve_status
        sigs = [
            self.HS("abandoned", "high", "old"),
            self.HS("confused", "high", "confusion"),
        ]
        self.assertEqual(_resolve_status(sigs), "confused")

    def test_abandoned_beats_deprecated(self):
        from reachable.collectors.health.analyzer import _resolve_status
        sigs = [
            self.HS("deprecated", "high", "dep"),
            self.HS("abandoned", "high", "old"),
        ]
        self.assertEqual(_resolve_status(sigs), "abandoned")

    def test_stale_maps_to_info(self):
        from reachable.collectors.health.analyzer import _resolve_status
        sigs = [self.HS("stale", "medium", "a year old")]
        self.assertEqual(_resolve_status(sigs), "info")

    def test_fetch_error_maps_to_info(self):
        from reachable.collectors.health.analyzer import _resolve_status
        sigs = [self.HS("fetch_error", "low", "network timeout")]
        self.assertEqual(_resolve_status(sigs), "info")

    def test_single_maintainer_maps_to_info(self):
        from reachable.collectors.health.analyzer import _resolve_status
        sigs = [self.HS("single_maintainer", "low", "only alice")]
        self.assertEqual(_resolve_status(sigs), "info")


class TestAnalyzePublicPackage(unittest.TestCase):

    def test_healthy_package(self):
        from reachable.collectors.health.analyzer import analyze_public_package
        meta = _make_meta(days_ago=50)
        result = analyze_public_package(meta)
        self.assertEqual(result.status, "healthy")
        self.assertEqual(result.signals, [])

    def test_abandoned_package(self):
        from reachable.collectors.health.analyzer import ABANDONED_DAYS, analyze_public_package
        meta = _make_meta(days_ago=ABANDONED_DAYS + 100)
        result = analyze_public_package(meta)
        signal_types = [s.signal_type for s in result.signals]
        self.assertIn("abandoned", signal_types)
        self.assertEqual(result.status, "abandoned")

    def test_stale_package(self):
        from reachable.collectors.health.analyzer import STALE_DAYS, analyze_public_package
        meta = _make_meta(days_ago=STALE_DAYS + 10)
        result = analyze_public_package(meta)
        signal_types = [s.signal_type for s in result.signals]
        self.assertIn("stale", signal_types)
        self.assertEqual(result.status, "info")

    def test_deprecated_package(self):
        from reachable.collectors.health.analyzer import analyze_public_package
        meta = _make_meta(days_ago=30, deprecated="Use newlib instead")
        result = analyze_public_package(meta)
        signal_types = [s.signal_type for s in result.signals]
        self.assertIn("deprecated", signal_types)
        self.assertEqual(result.status, "deprecated")

    def test_yanked_version(self):
        from reachable.collectors.health.analyzer import analyze_public_package
        meta = _make_meta(days_ago=30, yanked=True)
        result = analyze_public_package(meta)
        signal_types = [s.signal_type for s in result.signals]
        self.assertIn("yanked", signal_types)

    def test_single_maintainer(self):
        from reachable.collectors.health.analyzer import analyze_public_package
        meta = _make_meta(days_ago=30, maintainer_count=1, maintainers=["alice"])
        result = analyze_public_package(meta)
        signal_types = [s.signal_type for s in result.signals]
        self.assertIn("single_maintainer", signal_types)

    def test_no_repository(self):
        from reachable.collectors.health.analyzer import analyze_public_package
        meta = _make_meta(days_ago=30, repository_url=None)
        result = analyze_public_package(meta)
        signal_types = [s.signal_type for s in result.signals]
        self.assertIn("no_repository", signal_types)

    def test_fetch_error_path(self):
        from reachable.collectors.health.analyzer import analyze_public_package
        meta = _make_meta(fetched=False, error="timeout")
        result = analyze_public_package(meta)
        signal_types = [s.signal_type for s in result.signals]
        self.assertIn("fetch_error", signal_types)
        self.assertEqual(result.status, "info")

    def test_metadata_attached(self):
        from reachable.collectors.health.analyzer import analyze_public_package
        meta = _make_meta(days_ago=50)
        result = analyze_public_package(meta)
        self.assertIs(result.metadata, meta)


class TestAnalyzePrivatePackage(unittest.TestCase):

    def test_not_on_public_returns_none(self):
        from reachable.collectors.health.analyzer import analyze_private_package
        result = analyze_private_package("mylib", "1.0", "npm", exists_on_public=False)
        self.assertIsNone(result)

    def test_on_public_returns_confused(self):
        from reachable.collectors.health.analyzer import analyze_private_package
        result = analyze_private_package("mylib", "1.0", "npm", exists_on_public=True)
        self.assertIsNotNone(result)
        self.assertEqual(result.status, "confused")
        signal_types = [s.signal_type for s in result.signals]
        self.assertIn("confused", signal_types)

    def test_confused_signal_detail_mentions_name(self):
        from reachable.collectors.health.analyzer import analyze_private_package
        result = analyze_private_package("internal-auth", "2.0", "pypi", exists_on_public=True)
        detail = result.signals[0].detail
        self.assertIn("internal-auth", detail)


class TestPackageHealthResultToDict(unittest.TestCase):

    def test_to_dict(self):
        from reachable.collectors.health.analyzer import HealthSignal
        meta = _make_meta(days_ago=100)
        r = _make_result(
            status="abandoned",
            signals=[HealthSignal("abandoned", "high", "old")],
            meta=meta,
        )
        d = r.to_dict()
        self.assertEqual(d["status"], "abandoned")
        self.assertEqual(len(d["signals"]), 1)
        self.assertIsNotNone(d["metadata"])


# ===========================================================================
# 3. collector.py
# ===========================================================================

class TestParseSbomPackages(unittest.TestCase):

    def test_basic_python(self):
        from reachable.collectors.health.collector import parse_sbom_packages
        path = _make_sbom([
            {"name": "requests", "version": "2.28.0", "language": "python"},
            {"name": "flask", "version": "3.0.0", "language": "python"},
        ])
        try:
            pkgs = parse_sbom_packages(path)
            self.assertEqual(len(pkgs), 2)
            names = {p["name"] for p in pkgs}
            self.assertIn("requests", names)
            self.assertIn("flask", names)
        finally:
            os.unlink(path)

    def test_deduplication(self):
        from reachable.collectors.health.collector import parse_sbom_packages
        path = _make_sbom([
            {"name": "requests", "version": "2.28.0", "language": "python"},
            {"name": "requests", "version": "2.28.0", "language": "python"},
        ])
        try:
            pkgs = parse_sbom_packages(path)
            self.assertEqual(len(pkgs), 1)
        finally:
            os.unlink(path)

    def test_unsupported_ecosystem_excluded(self):
        from reachable.collectors.health.collector import parse_sbom_packages
        path = _make_sbom([
            {"name": "requests", "version": "2.28.0", "language": "python"},
            {"name": "serde", "version": "1.0.0", "language": "rust"},
        ])
        try:
            pkgs = parse_sbom_packages(path)
            names = {p["name"] for p in pkgs}
            self.assertIn("requests", names)
            self.assertNotIn("serde", names)
        finally:
            os.unlink(path)

    def test_missing_name_excluded(self):
        from reachable.collectors.health.collector import parse_sbom_packages
        data = {"artifacts": [{"version": "1.0", "language": "python"}]}
        fd, path = tempfile.mkstemp(suffix=".json")
        os.write(fd, json.dumps(data).encode())
        os.close(fd)
        try:
            pkgs = parse_sbom_packages(path)
            self.assertEqual(pkgs, [])
        finally:
            os.unlink(path)

    def test_gzip_sbom(self):
        from reachable.collectors.health.collector import parse_sbom_packages
        data = {"artifacts": [
            {"name": "numpy", "version": "1.24.0", "language": "python",
             "purl": "pkg:pypi/numpy@1.24.0", "locations": []}
        ]}
        fd, path = tempfile.mkstemp(suffix=".json.gz")
        os.close(fd)
        with gzip.open(path, "wt") as f:
            json.dump(data, f)
        try:
            pkgs = parse_sbom_packages(path)
            self.assertEqual(len(pkgs), 1)
            self.assertEqual(pkgs[0]["name"], "numpy")
        finally:
            os.unlink(path)


class TestClassifyPackages(unittest.TestCase):

    def setUp(self):
        self.pkgs = [
            {"name": "requests", "version": "2.28.0", "ecosystem": "python",
             "purl": "pkg:pypi/requests@2.28.0"},
            {"name": "myinternal", "version": "1.0.0", "ecosystem": "python",
             "purl": ""},
        ]

    def test_no_map_all_public(self):
        from reachable.collectors.health.collector import classify_packages
        public, private = classify_packages(self.pkgs, purl_resolution_map=None)
        self.assertEqual(len(public), 2)
        self.assertEqual(len(private), 0)

    def test_no_purl_goes_private(self):
        from reachable.collectors.health.collector import classify_packages
        purl_map = {"pkg:pypi/requests@2.28.0": "pkg:pypi/requests@2.28.0"}
        public, private = classify_packages(self.pkgs, purl_resolution_map=purl_map)
        pub_names = {p["name"] for p in public}
        priv_names = {p["name"] for p in private}
        self.assertIn("requests", pub_names)
        self.assertIn("myinternal", priv_names)

    def test_empty_packages(self):
        from reachable.collectors.health.collector import classify_packages
        public, private = classify_packages([], purl_resolution_map={})
        self.assertEqual(public, [])
        self.assertEqual(private, [])


class TestPackageHealthReport(unittest.TestCase):

    def test_empty_results(self):
        from reachable.collectors.health.collector import _PackageHealthReport
        report = _PackageHealthReport([])
        self.assertEqual(report.advisories, [])

    def test_advisory_shape(self):
        from reachable.collectors.health.analyzer import HealthSignal
        from reachable.collectors.health.collector import _PackageHealthReport
        meta = _make_meta(days_ago=800)
        r = _make_result(
            name="oldlib", version="1.0", ecosystem="pypi",
            status="abandoned",
            signals=[HealthSignal("abandoned", "high", "very old")],
            meta=meta,
        )
        report = _PackageHealthReport([r])
        self.assertEqual(len(report.advisories), 1)
        adv = report.advisories[0]
        self.assertIn("package_name", adv)
        self.assertIn("version", adv)
        self.assertIn("ecosystem", adv)
        self.assertIn("status", adv)
        self.assertIn("signals", adv)
        self.assertIn("last_publish_date", adv)
        self.assertIn("latest_version", adv)
        self.assertIn("deprecated_msg", adv)

    def test_severity_mapping(self):
        from reachable.collectors.health.collector import _PackageHealthReport
        meta = _make_meta(days_ago=50)
        confused = _make_result(status="confused", meta=meta)
        abandoned = _make_result(status="abandoned", meta=meta)
        deprecated = _make_result(status="deprecated", meta=meta)
        report = _PackageHealthReport([confused, abandoned, deprecated])
        sevs = {a["package_name"]: a["severity"] for a in report.advisories}
        # All share the same name "requests", last one wins - just check CRITICAL assigned
        self.assertIn("CRITICAL", [a["severity"] for a in report.advisories])

    def test_get_compat(self):
        from reachable.collectors.health.collector import _PackageHealthReport
        report = _PackageHealthReport([])
        self.assertEqual(report.get("advisories", "default"), [])
        self.assertEqual(report.get("nonexistent", "fallback"), "fallback")


class TestRunPackageHealth(unittest.TestCase):

    def test_returns_list(self):
        from reachable.collectors.health.collector import run_package_health
        path = _make_sbom([
            {"name": "requests", "version": "2.28.0", "language": "python"},
        ])
        try:
            with patch("reachable.collectors.health.collector.fetch_metadata") as mock_fetch:
                mock_fetch.return_value = _make_meta(days_ago=50)
                results = run_package_health(path)
            self.assertIsInstance(results, list)
        finally:
            os.unlink(path)

    def test_healthy_package_excluded(self):
        from reachable.collectors.health.collector import run_package_health
        path = _make_sbom([
            {"name": "requests", "version": "2.28.0", "language": "python"},
        ])
        try:
            with patch("reachable.collectors.health.collector.fetch_metadata") as mock_fetch:
                mock_fetch.return_value = _make_meta(days_ago=30)
                results = run_package_health(path)
            self.assertEqual(results, [])
        finally:
            os.unlink(path)

    def test_abandoned_included(self):
        from reachable.collectors.health.collector import run_package_health
        path = _make_sbom([
            {"name": "oldlib", "version": "1.0.0", "language": "python"},
        ])
        try:
            with patch("reachable.collectors.health.collector.fetch_metadata") as mock_fetch:
                mock_fetch.return_value = _make_meta(name="oldlib", days_ago=800)
                results = run_package_health(path)
            self.assertEqual(len(results), 1)
            self.assertEqual(results[0].status, "abandoned")
        finally:
            os.unlink(path)

    def test_empty_sbom(self):
        from reachable.collectors.health.collector import run_package_health
        path = _make_sbom([])
        try:
            results = run_package_health(path)
            self.assertEqual(results, [])
        finally:
            os.unlink(path)

    def test_sort_order_confused_first(self):
        from reachable.collectors.health.collector import run_package_health
        path = _make_sbom([
            {"name": "libA", "version": "1.0", "language": "python"},
            {"name": "libB", "version": "1.0", "language": "python"},
        ])
        try:
            call_count = [0]
            def _fake_fetch(name, version, ecosystem, timeout=8.0):
                call_count[0] += 1
                if name == "libA":
                    return _make_meta(name="libA", days_ago=800)  # abandoned
                else:
                    # Return confused
                    meta = _make_meta(name="libB", days_ago=30)
                    return meta
            with patch("reachable.collectors.health.collector.fetch_metadata", side_effect=_fake_fetch):
                with patch("reachable.collectors.health.collector.analyze_public_package") as mock_analyze:
                    from reachable.collectors.health.analyzer import PackageHealthResult
                    def _fake_analyze(meta):
                        if meta.name == "libA":
                            return PackageHealthResult("libA", "1.0", "python", status="abandoned")
                        else:
                            return PackageHealthResult("libB", "1.0", "python", status="confused")
                    mock_analyze.side_effect = _fake_analyze
                    results = run_package_health(path)
            if results:
                statuses = [r.status for r in results]
                if "confused" in statuses and "abandoned" in statuses:
                    self.assertEqual(statuses.index("confused"), 0)
        finally:
            os.unlink(path)


# ===========================================================================
# 4. normalizer.py
# ===========================================================================

class TestNormalizeForDashboard(unittest.TestCase):

    def test_empty(self):
        from reachable.collectors.health.normalizer import normalize_for_dashboard
        result = normalize_for_dashboard([])
        self.assertEqual(result["summary"]["total_advisories"], 0)
        self.assertEqual(result["advisories"], [])

    def test_summary_counts(self):
        from reachable.collectors.health.normalizer import normalize_for_dashboard
        results = [
            _make_result(name="a", status="abandoned"),
            _make_result(name="b", status="abandoned"),
            _make_result(name="c", status="deprecated"),
            _make_result(name="d", status="confused"),
            _make_result(name="e", status="info"),
        ]
        out = normalize_for_dashboard(results)
        self.assertEqual(out["summary"]["total_advisories"], 5)
        self.assertEqual(out["summary"]["abandoned"], 2)
        self.assertEqual(out["summary"]["deprecated"], 1)
        self.assertEqual(out["summary"]["confused"], 1)
        self.assertEqual(out["summary"]["info"], 1)

    def test_advisory_has_required_keys(self):
        from reachable.collectors.health.analyzer import HealthSignal
        from reachable.collectors.health.normalizer import normalize_for_dashboard
        meta = _make_meta(days_ago=800)
        r = _make_result(
            name="oldlib", status="abandoned",
            signals=[HealthSignal("abandoned", "high", "really old")],
            meta=meta,
        )
        out = normalize_for_dashboard([r])
        adv = out["advisories"][0]
        for key in ("package", "version", "ecosystem", "status", "signals",
                    "days_since_publish", "maintainer_count", "repository_url",
                    "latest_version", "deprecated_msg"):
            self.assertIn(key, adv, f"Missing key: {key}")

    def test_signals_serialized(self):
        from reachable.collectors.health.analyzer import HealthSignal
        from reachable.collectors.health.normalizer import normalize_for_dashboard
        sig = HealthSignal("abandoned", "high", "old")
        r = _make_result(status="abandoned", signals=[sig])
        out = normalize_for_dashboard([r])
        adv = out["advisories"][0]
        self.assertEqual(len(adv["signals"]), 1)
        self.assertEqual(adv["signals"][0]["signal_type"], "abandoned")

    def test_no_metadata_defaults(self):
        from reachable.collectors.health.normalizer import normalize_for_dashboard
        r = _make_result(status="info", meta=None)
        out = normalize_for_dashboard([r])
        adv = out["advisories"][0]
        self.assertIsNone(adv["days_since_publish"])
        self.assertIsNone(adv["maintainer_count"])
        self.assertIsNone(adv["repository_url"])


class TestResultsToDbRows(unittest.TestCase):

    def test_row_shape(self):
        from reachable.collectors.health.analyzer import HealthSignal
        from reachable.collectors.health.normalizer import results_to_db_rows
        meta = _make_meta(days_ago=100)
        r = _make_result(
            name="testlib", version="1.0", ecosystem="npm",
            status="deprecated",
            signals=[HealthSignal("deprecated", "high", "old")],
            meta=meta,
        )
        rows = results_to_db_rows([r], scan_id="42")
        self.assertEqual(len(rows), 1)
        row = rows[0]
        self.assertEqual(row["scan_id"], "42")
        self.assertEqual(row["package_name"], "testlib")
        self.assertEqual(row["package_version"], "1.0")
        self.assertEqual(row["ecosystem"], "npm")
        self.assertEqual(row["status"], "deprecated")
        # signals should be JSON string
        signals_parsed = json.loads(row["signals"])
        self.assertEqual(len(signals_parsed), 1)

    def test_empty(self):
        from reachable.collectors.health.normalizer import results_to_db_rows
        rows = results_to_db_rows([], scan_id="1")
        self.assertEqual(rows, [])

    def test_no_metadata(self):
        from reachable.collectors.health.normalizer import results_to_db_rows
        r = _make_result(status="info", meta=None)
        rows = results_to_db_rows([r], scan_id="1")
        self.assertIsNone(rows[0]["days_since_publish"])
        self.assertIsNone(rows[0]["maintainer_count"])


# ===========================================================================
# 5. confusion.py
# ===========================================================================

class TestConfusionResult(unittest.TestCase):

    def test_to_dict(self):
        from reachable.collectors.health.confusion import ConfusionResult
        cr = ConfusionResult(
            package_name="mylib", ecosystem="npm",
            public_exists=True, public_version="2.0",
            private_version="1.0", is_critical=True,
        )
        d = cr.to_dict()
        self.assertEqual(d["package_name"], "mylib")
        self.assertTrue(d["public_exists"])
        self.assertTrue(d["is_critical"])

    def test_defaults(self):
        from reachable.collectors.health.confusion import ConfusionResult
        cr = ConfusionResult("pkg", "pypi")
        self.assertFalse(cr.public_exists)
        self.assertFalse(cr.is_critical)


class TestEvaluateConfusion(unittest.TestCase):

    def test_not_public_returns_none(self):
        from reachable.collectors.health.confusion import ConfusionResult, evaluate_confusion
        cr = ConfusionResult("mypkg", "npm", public_exists=False)
        self.assertIsNone(evaluate_confusion(cr))

    def test_public_returns_signal(self):
        from reachable.collectors.health.confusion import ConfusionResult, evaluate_confusion
        cr = ConfusionResult("mypkg", "npm", public_exists=True,
                             public_version="1.0", private_version="0.5")
        sig = evaluate_confusion(cr)
        self.assertIsNotNone(sig)
        self.assertEqual(sig["signal_type"], "confused")
        self.assertEqual(sig["confidence"], "high")
        self.assertIn("mypkg", sig["detail"])

    def test_critical_when_public_higher(self):
        from reachable.collectors.health.confusion import ConfusionResult, evaluate_confusion
        cr = ConfusionResult("mypkg", "npm", public_exists=True,
                             public_version="2.0", private_version="1.0",
                             is_critical=True)
        sig = evaluate_confusion(cr)
        self.assertEqual(sig["severity"], "critical")
        self.assertIn("HIGHER", sig["detail"])

    def test_non_critical_severity_high(self):
        from reachable.collectors.health.confusion import ConfusionResult, evaluate_confusion
        cr = ConfusionResult("mypkg", "npm", public_exists=True,
                             public_version="0.5", private_version="1.0",
                             is_critical=False)
        sig = evaluate_confusion(cr)
        self.assertEqual(sig["severity"], "high")

    def test_signal_has_required_keys(self):
        from reachable.collectors.health.confusion import ConfusionResult, evaluate_confusion
        cr = ConfusionResult("x", "npm", public_exists=True)
        sig = evaluate_confusion(cr)
        for key in ("signal_type", "confidence", "detail", "severity"):
            self.assertIn(key, sig)


class TestDetectPrivatePackages(unittest.TestCase):

    def test_private_resolved_url(self):
        from reachable.collectors.health.confusion import detect_private_packages
        pkgs = [
            {
                "name": "mylib", "version": "1.0", "ecosystem": "npm",
                "purl": "pkg:npm/mylib@1.0",
                "resolved": "https://artifactory.corp.com/npm/mylib/-/mylib-1.0.tgz",
            }
        ]
        private = detect_private_packages(pkgs)
        self.assertEqual(len(private), 1)
        self.assertEqual(private[0]["name"], "mylib")

    def test_public_registry_not_private(self):
        from reachable.collectors.health.confusion import detect_private_packages
        pkgs = [
            {
                "name": "express", "version": "4.18.0", "ecosystem": "npm",
                "purl": "pkg:npm/express@4.18.0",
                "resolved": "https://registry.npmjs.org/express/-/express-4.18.0.tgz",
            }
        ]
        private = detect_private_packages(pkgs)
        self.assertEqual(private, [])

    def test_no_resolved_url_not_flagged(self):
        from reachable.collectors.health.confusion import detect_private_packages
        pkgs = [
            {"name": "flask", "version": "3.0.0", "ecosystem": "python",
             "purl": "pkg:pypi/flask@3.0.0", "resolved": ""},
        ]
        private = detect_private_packages(pkgs)
        self.assertEqual(private, [])

    def test_unsupported_ecosystem_excluded(self):
        from reachable.collectors.health.confusion import detect_private_packages
        pkgs = [
            {
                "name": "mypkg", "version": "1.0", "ecosystem": "go",
                "purl": "", "resolved": "https://private.corp.com/go/mypkg",
            }
        ]
        private = detect_private_packages(pkgs)
        self.assertEqual(private, [])

    def test_supported_ecosystems_set(self):
        from reachable.collectors.health.confusion import SUPPORTED_ECOSYSTEMS
        self.assertIn("npm", SUPPORTED_ECOSYSTEMS)
        self.assertIn("pypi", SUPPORTED_ECOSYSTEMS)

    def test_error_classes_importable(self):
        from reachable.collectors.health.confusion import RateLimitedError, RegistryError
        self.assertTrue(issubclass(RateLimitedError, RegistryError))


# ===========================================================================
# 6. storage.py — store_package_health / load_package_health round-trip
# ===========================================================================

class TestStorageRoundTrip(unittest.TestCase):
    """
    Test store_package_health() + load_package_health() against a real
    in-memory SQLite DB (same schema as production).
    """

    def setUp(self):
        self.db_path = _make_db_with_schema()
        # Insert a fake scan row so the FK constraint is satisfied
        con = sqlite3.connect(self.db_path)
        con.execute(
            "INSERT INTO scans (branch, commit_hash, short_hash, scan_dir, version, status) "
            "VALUES (?, ?, ?, ?, ?, ?)",
            ("main", "abc123", "abc", "/tmp/repo", "1.0.0b16", "running"),
        )
        con.commit()
        self.scan_id = con.execute("SELECT last_insert_rowid()").fetchone()[0]
        con.close()

    def tearDown(self):
        os.unlink(self.db_path)

    def _make_report_with(self, advisories: List[Dict]):
        """Wrap advisory dicts in a report-like object."""
        class _FakeReport:
            pass
        report = _FakeReport()
        report.advisories = advisories
        return report

    def _get_db(self):
        from reachable.database.storage import RepoDatabase
        db = RepoDatabase.__new__(RepoDatabase)
        db.conn = sqlite3.connect(self.db_path)
        db.conn.row_factory = sqlite3.Row
        db._current_scan_id = self.scan_id
        return db

    def test_store_returns_count(self):
        db = self._get_db()
        adv = {
            "package_name": "requests", "version": "2.28.0", "ecosystem": "pypi",
            "purl": "pkg:pypi/requests@2.28.0", "status": "abandoned",
            "severity": "HIGH", "signals": [{"signal_type": "abandoned", "detail": "old"}],
            "title": "requests: abandoned", "detail": "2 years no update",
            "last_publish_date": _iso(800), "latest_version": "2.31.0",
            "deprecated_msg": None, "maintainer_count": 2,
            "has_repository": True, "is_deprecated": False, "is_private": False,
        }
        report = self._make_report_with([adv])
        n = db.store_package_health(report)
        self.assertEqual(n, 1)
        db.conn.close()

    def test_load_returns_stored(self):
        db = self._get_db()
        adv = {
            "package_name": "flask", "version": "3.0.0", "ecosystem": "python",
            "purl": "", "status": "deprecated", "severity": "MEDIUM",
            "signals": [{"signal_type": "deprecated", "detail": "dep msg"}],
            "title": "flask: deprecated", "detail": "deprecated",
            "last_publish_date": _iso(200), "latest_version": "3.1.0",
            "deprecated_msg": "Use newflask instead",
            "maintainer_count": 1, "has_repository": True,
            "is_deprecated": True, "is_private": False,
        }
        db.store_package_health(self._make_report_with([adv]))
        rows = db.load_package_health(self.scan_id)
        self.assertEqual(len(rows), 1)
        row = rows[0]
        self.assertEqual(row["package"], "flask")
        self.assertEqual(row["version"], "3.0.0")
        self.assertEqual(row["status"], "deprecated")
        self.assertIsInstance(row["signals"], list)
        self.assertEqual(len(row["signals"]), 1)
        db.conn.close()

    def test_latest_version_and_deprecated_msg_stored(self):
        """Bug 3 regression: these two fields must survive the round-trip."""
        db = self._get_db()
        adv = {
            "package_name": "oldpkg", "version": "1.0.0", "ecosystem": "npm",
            "purl": "", "status": "deprecated", "severity": "MEDIUM",
            "signals": [], "title": "t", "detail": "d",
            "last_publish_date": None, "latest_version": "2.5.0",
            "deprecated_msg": "Use newpkg instead",
            "maintainer_count": 1, "has_repository": False,
            "is_deprecated": True, "is_private": False,
        }
        db.store_package_health(self._make_report_with([adv]))
        rows = db.load_package_health(self.scan_id)
        self.assertEqual(len(rows), 1)
        row = rows[0]
        self.assertEqual(row.get("latest_version"), "2.5.0")
        self.assertEqual(row.get("deprecated_msg"), "Use newpkg instead")
        db.conn.close()

    def test_healthy_packages_excluded(self):
        db = self._get_db()
        adv = {
            "package_name": "safepkg", "version": "1.0.0", "ecosystem": "npm",
            "purl": "", "status": "healthy", "severity": "INFO",
            "signals": [], "title": "", "detail": "",
            "last_publish_date": None, "latest_version": None,
            "deprecated_msg": None, "maintainer_count": 2,
            "has_repository": True, "is_deprecated": False, "is_private": False,
        }
        db.store_package_health(self._make_report_with([adv]))
        rows = db.load_package_health(self.scan_id)
        self.assertEqual(rows, [])  # healthy excluded by WHERE status != 'healthy'
        db.conn.close()

    def test_ordering_confused_first(self):
        db = self._get_db()
        def _adv(name, status):
            return {
                "package_name": name, "version": "1.0", "ecosystem": "npm",
                "purl": "", "status": status, "severity": "HIGH",
                "signals": [], "title": name, "detail": "",
                "last_publish_date": None, "latest_version": None,
                "deprecated_msg": None, "maintainer_count": 1,
                "has_repository": True, "is_deprecated": False, "is_private": False,
            }
        db.store_package_health(self._make_report_with([
            _adv("deprecated-pkg", "deprecated"),
            _adv("confused-pkg", "confused"),
            _adv("abandoned-pkg", "abandoned"),
        ]))
        rows = db.load_package_health(self.scan_id)
        statuses = [r["status"] for r in rows]
        self.assertEqual(statuses[0], "confused")
        db.conn.close()

    def test_no_scan_id_returns_zero(self):
        from reachable.database.storage import RepoDatabase
        db = RepoDatabase.__new__(RepoDatabase)
        db.conn = sqlite3.connect(self.db_path)
        db._current_scan_id = None
        n = db.store_package_health(self._make_report_with([{"package_name": "x"}]))
        self.assertEqual(n, 0)
        db.conn.close()

    def test_empty_advisories_returns_zero(self):
        db = self._get_db()
        n = db.store_package_health(self._make_report_with([]))
        self.assertEqual(n, 0)
        db.conn.close()

    def test_signals_json_roundtrip(self):
        db = self._get_db()
        signals = [
            {"signal_type": "abandoned", "confidence": "high", "detail": "2y old"},
            {"signal_type": "no_repository", "confidence": "low", "detail": "no repo"},
        ]
        adv = {
            "package_name": "multilib", "version": "1.0", "ecosystem": "pypi",
            "purl": "", "status": "abandoned", "severity": "HIGH",
            "signals": signals, "title": "t", "detail": "d",
            "last_publish_date": None, "latest_version": None,
            "deprecated_msg": None, "maintainer_count": 1,
            "has_repository": False, "is_deprecated": False, "is_private": False,
        }
        db.store_package_health(self._make_report_with([adv]))
        rows = db.load_package_health(self.scan_id)
        loaded_signals = rows[0]["signals"]
        self.assertEqual(len(loaded_signals), 2)
        self.assertEqual(loaded_signals[0]["signal_type"], "abandoned")
        db.conn.close()

    def test_days_since_publish_computed(self):
        db = self._get_db()
        adv = {
            "package_name": "oldpkg", "version": "1.0", "ecosystem": "npm",
            "purl": "", "status": "abandoned", "severity": "HIGH",
            "signals": [], "title": "t", "detail": "d",
            "last_publish_date": _iso(100), "latest_version": None,
            "deprecated_msg": None, "maintainer_count": 1,
            "has_repository": True, "is_deprecated": False, "is_private": False,
        }
        db.store_package_health(self._make_report_with([adv]))
        rows = db.load_package_health(self.scan_id)
        self.assertIsNotNone(rows[0]["days_since_publish"])
        self.assertAlmostEqual(rows[0]["days_since_publish"], 100, delta=2)
        db.conn.close()


# ===========================================================================
# 7. loaders.py — _load_package_health
# ===========================================================================

class TestLoadersPackageHealth(unittest.TestCase):
    """
    Test the standalone _load_package_health function used by load_from_database().
    """

    def setUp(self):
        self.db_path = _make_db_with_schema()
        con = sqlite3.connect(self.db_path)
        con.execute(
            "INSERT INTO scans (branch, commit_hash, short_hash, scan_dir, version, status) "
            "VALUES ('main','abc','abc','/tmp','1.0','completed')"
        )
        con.commit()
        self.scan_id = con.execute("SELECT last_insert_rowid()").fetchone()[0]
        con.close()

    def tearDown(self):
        os.unlink(self.db_path)

    def _get_cursor(self):
        con = sqlite3.connect(self.db_path)
        con.row_factory = sqlite3.Row
        return con, con.cursor()

    def _insert_advisory(self, con, scan_id, name, status,
                         latest_version=None, deprecated_msg=None):
        con.execute(
            """INSERT INTO package_health
               (scan_id, package_name, package_version, ecosystem, status,
                severity, signals, latest_version, deprecated_msg)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (scan_id, name, "1.0", "npm", status, "HIGH", "[]",
             latest_version, deprecated_msg),
        )
        con.commit()

    def test_returns_none_when_no_data(self):
        from reachable.dashboard_v2.loaders import _load_package_health
        con, cursor = self._get_cursor()
        result = _load_package_health(cursor, self.scan_id)
        con.close()
        self.assertIsNone(result)

    def test_returns_dict_with_advisories(self):
        from reachable.dashboard_v2.loaders import _load_package_health
        con, cursor = self._get_cursor()
        self._insert_advisory(con, self.scan_id, "badpkg", "abandoned")
        result = _load_package_health(cursor, self.scan_id)
        con.close()
        self.assertIsNotNone(result)
        self.assertIn("summary", result)
        self.assertIn("advisories", result)
        self.assertEqual(len(result["advisories"]), 1)

    def test_healthy_excluded(self):
        from reachable.dashboard_v2.loaders import _load_package_health
        con, cursor = self._get_cursor()
        self._insert_advisory(con, self.scan_id, "goodpkg", "healthy")
        result = _load_package_health(cursor, self.scan_id)
        con.close()
        self.assertIsNone(result)

    def test_summary_counts(self):
        from reachable.dashboard_v2.loaders import _load_package_health
        con, cursor = self._get_cursor()
        self._insert_advisory(con, self.scan_id, "a", "confused")
        self._insert_advisory(con, self.scan_id, "b", "abandoned")
        self._insert_advisory(con, self.scan_id, "c", "deprecated")
        result = _load_package_health(cursor, self.scan_id)
        con.close()
        self.assertEqual(result["summary"]["total_advisories"], 3)
        self.assertEqual(result["summary"]["confused"], 1)
        self.assertEqual(result["summary"]["abandoned"], 1)
        self.assertEqual(result["summary"]["deprecated"], 1)

    def test_latest_version_in_output(self):
        """Bug 3 regression: latest_version must flow through to dashboard."""
        from reachable.dashboard_v2.loaders import _load_package_health
        con, cursor = self._get_cursor()
        self._insert_advisory(con, self.scan_id, "oldpkg", "deprecated",
                              latest_version="2.5.0", deprecated_msg="Use newpkg")
        result = _load_package_health(cursor, self.scan_id)
        con.close()
        adv = result["advisories"][0]
        self.assertEqual(adv.get("latest_version"), "2.5.0")
        self.assertEqual(adv.get("deprecated_msg"), "Use newpkg")

    def test_package_name_remapped(self):
        from reachable.dashboard_v2.loaders import _load_package_health
        con, cursor = self._get_cursor()
        self._insert_advisory(con, self.scan_id, "mylib", "abandoned")
        result = _load_package_health(cursor, self.scan_id)
        con.close()
        adv = result["advisories"][0]
        self.assertEqual(adv["package"], "mylib")
        self.assertNotIn("package_name", adv)

    def test_signals_parsed_as_list(self):
        from reachable.dashboard_v2.loaders import _load_package_health
        con, cursor = self._get_cursor()
        signals = json.dumps([{"signal_type": "abandoned", "detail": "old"}])
        con.execute(
            "INSERT INTO package_health (scan_id, package_name, package_version, "
            "ecosystem, status, severity, signals) VALUES (?, ?, ?, ?, ?, ?, ?)",
            (self.scan_id, "lib", "1.0", "npm", "abandoned", "HIGH", signals),
        )
        con.commit()
        result = _load_package_health(cursor, self.scan_id)
        con.close()
        adv = result["advisories"][0]
        self.assertIsInstance(adv["signals"], list)
        self.assertEqual(adv["signals"][0]["signal_type"], "abandoned")

    def test_missing_table_returns_none(self):
        """Table doesn't exist yet — should return None gracefully."""
        from reachable.dashboard_v2.loaders import _load_package_health
        con = sqlite3.connect(":memory:")
        con.row_factory = sqlite3.Row
        cursor = con.cursor()
        result = _load_package_health(cursor, 1)
        con.close()
        self.assertIsNone(result)


# ===========================================================================
# 8. End-to-end: PackageHealthCollector → store → load
# ===========================================================================

class TestEndToEnd(unittest.TestCase):

    def setUp(self):
        self.db_path = _make_db_with_schema()
        con = sqlite3.connect(self.db_path)
        con.execute(
            "INSERT INTO scans (branch, commit_hash, short_hash, scan_dir, version, status) "
            "VALUES ('main','abc','abc','/tmp','1.0','running')"
        )
        con.commit()
        self.scan_id = con.execute("SELECT last_insert_rowid()").fetchone()[0]
        con.close()

    def tearDown(self):
        os.unlink(self.db_path)

    def test_collector_to_db_to_loader(self):
        """Full pipeline: collect → store → load via loaders._load_package_health."""
        from reachable.collectors.health.collector import PackageHealthCollector
        from reachable.dashboard_v2.loaders import _load_package_health
        from reachable.database.storage import RepoDatabase

        sbom_path = _make_sbom([
            {"name": "abandonedlib", "version": "1.0.0", "language": "python"},
        ])
        try:
            def _fake_fetch(name, version, ecosystem, timeout=8.0):
                return _make_meta(name=name, days_ago=900)

            with patch("reachable.collectors.health.collector.fetch_metadata",
                       side_effect=_fake_fetch):
                collector = PackageHealthCollector(sbom_path=sbom_path)
                report = collector.collect()

            db = RepoDatabase.__new__(RepoDatabase)
            db.conn = sqlite3.connect(self.db_path)
            db.conn.row_factory = sqlite3.Row
            db._current_scan_id = self.scan_id
            stored = db.store_package_health(report)

            cursor = db.conn.cursor()
            result = _load_package_health(cursor, self.scan_id)
            db.conn.close()

            if stored > 0:
                self.assertIsNotNone(result)
                self.assertEqual(result["summary"]["total_advisories"], stored)
                self.assertEqual(result["advisories"][0]["status"], "abandoned")
        finally:
            os.unlink(sbom_path)


if __name__ == "__main__":
    unittest.main(verbosity=2)
