#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.

"""
Package Health Signal Computation

Takes RegistryMetadata and computes advisory health signals.
Each signal is a verdict with evidence, confidence, and remediation.
"""

import logging
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)

ABANDONED_DAYS = 730
STALE_DAYS = 365
AGING_DAYS = 180


@dataclass
class PackageSignal:
    """A single health signal for a package."""

    signal: str
    severity: str
    confidence: str
    title: str
    description: str
    evidence: Dict[str, Any] = field(default_factory=dict)
    remediation: str = ""

    def to_dict(self) -> Dict[str, Any]:
        return {
            "signal": self.signal, "severity": self.severity,
            "confidence": self.confidence, "title": self.title,
            "description": self.description, "evidence": self.evidence,
            "remediation": self.remediation,
        }


def _days_since(iso_date: Optional[str]) -> Optional[int]:
    if not iso_date:
        return None
    try:
        dt = datetime.fromisoformat(iso_date.replace("Z", "+00:00"))
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        return max(0, (datetime.now(timezone.utc) - dt).days)
    except (ValueError, TypeError):
        return None


def compute_signals(meta) -> List[PackageSignal]:
    """Compute all health signals from RegistryMetadata."""
    signals = []

    if not meta.fetch_ok or not meta.exists_on_public:
        return signals

    # ─── Deprecated ─────────────────────────────────────────
    if meta.is_deprecated:
        signals.append(PackageSignal(
            signal="deprecated", severity="high", confidence="high",
            title=f"{meta.name} is deprecated",
            description=(
                f"The package maintainer has deprecated this package"
                f"{': ' + meta.deprecation_message if meta.deprecation_message else ''}. "
                f"Deprecated packages may stop receiving security patches."
            ),
            evidence={"deprecated": True, "message": meta.deprecation_message or ""},
            remediation="Migrate to the recommended replacement package.",
        ))

    if meta.is_yanked:
        signals.append(PackageSignal(
            signal="deprecated", severity="high", confidence="high",
            title=f"{meta.name}@{meta.version} has been yanked",
            description=(
                f"This specific version was pulled from the registry"
                f"{': ' + meta.deprecation_message if meta.deprecation_message else ''}. "
                f"Yanked versions may contain known defects or security issues."
            ),
            evidence={"yanked": True, "version": meta.version, "message": meta.deprecation_message or ""},
            remediation=f"Upgrade to latest version ({meta.latest_version})." if meta.latest_version else "Find an alternative package.",
        ))

    # ─── Abandoned ──────────────────────────────────────────
    latest_age_days = _days_since(meta.latest_publish_date)

    if latest_age_days is not None and latest_age_days > ABANDONED_DAYS:
        years = latest_age_days / 365.25
        signals.append(PackageSignal(
            signal="abandoned",
            severity="high" if latest_age_days > ABANDONED_DAYS * 2 else "medium",
            confidence="high" if latest_age_days > ABANDONED_DAYS else "medium",
            title=f"{meta.name} has not been updated in {years:.1f} years",
            description=(
                f"The latest version ({meta.latest_version or '?'}) was published "
                f"{latest_age_days} days ago. Packages without active maintenance "
                f"are unlikely to receive security patches for new vulnerabilities."
            ),
            evidence={
                "latest_version": meta.latest_version,
                "latest_publish_date": meta.latest_publish_date,
                "days_since_update": latest_age_days,
            },
            remediation="Evaluate actively-maintained alternatives. If none exist, consider vendoring a fork.",
        ))
    elif latest_age_days is not None and latest_age_days > STALE_DAYS:
        signals.append(PackageSignal(
            signal="stale", severity="low", confidence="low",
            title=f"{meta.name} has not been updated in {latest_age_days} days",
            description=(
                f"The latest version ({meta.latest_version or '?'}) was published "
                f"{latest_age_days} days ago. This may be stable and complete, "
                f"or it may indicate declining maintenance."
            ),
            evidence={
                "latest_version": meta.latest_version,
                "latest_publish_date": meta.latest_publish_date,
                "days_since_update": latest_age_days,
            },
            remediation="Monitor for continued inactivity.",
        ))

    # ─── No repository ──────────────────────────────────────
    if not meta.repository_url:
        signals.append(PackageSignal(
            signal="no_repository", severity="low", confidence="medium",
            title=f"{meta.name} has no linked source repository",
            description="No repository URL is published in the registry metadata. This makes it harder to audit source code or verify provenance.",
            evidence={"repository_url": None},
            remediation="Verify package provenance through alternative means.",
        ))

    # ─── Single maintainer ──────────────────────────────────
    if meta.maintainer_count == 1 and meta.ecosystem != "go":
        signals.append(PackageSignal(
            signal="single_maintainer", severity="low", confidence="medium",
            title=f"{meta.name} has a single maintainer",
            description=(
                f"Only one maintainer ({meta.maintainers[0] if meta.maintainers else '?'}) "
                f"is listed. Single-maintainer packages are more vulnerable to "
                f"account compromise and bus-factor risk."
            ),
            evidence={"maintainer_count": 1, "maintainers": meta.maintainers},
            remediation="Consider the risk if this maintainer's account is compromised.",
        ))

    # ─── Version drift ──────────────────────────────────────
    if meta.latest_version and meta.version and meta.latest_version != meta.version:
        installed_age_days = _days_since(meta.current_version_publish_date)
        if installed_age_days is not None and installed_age_days > ABANDONED_DAYS:
            signals.append(PackageSignal(
                signal="version_drift", severity="low", confidence="medium",
                title=f"{meta.name}@{meta.version} is {installed_age_days} days behind latest",
                description=(
                    f"Installed version {meta.version} was published {installed_age_days} days ago. "
                    f"Latest is {meta.latest_version}. Large version drift may mean "
                    f"missing security patches."
                ),
                evidence={
                    "installed_version": meta.version, "latest_version": meta.latest_version,
                    "installed_publish_date": meta.current_version_publish_date,
                    "drift_days": installed_age_days,
                },
                remediation=f"Upgrade to {meta.latest_version} if compatible.",
            ))

    return signals


def compute_status(signals: List[PackageSignal]) -> str:
    """Derive single health status. Priority: confused > deprecated > abandoned > stale > info > healthy."""
    signal_names = {s.signal for s in signals}
    if "confused" in signal_names: return "confused"
    if "deprecated" in signal_names: return "deprecated"
    if "abandoned" in signal_names: return "abandoned"
    if "stale" in signal_names: return "stale"
    if signal_names: return "info"
    return "healthy"


def compute_status_severity(status: str) -> str:
    return {"confused": "critical", "deprecated": "high", "abandoned": "medium",
            "stale": "low", "info": "info", "healthy": "none"}.get(status, "info")
