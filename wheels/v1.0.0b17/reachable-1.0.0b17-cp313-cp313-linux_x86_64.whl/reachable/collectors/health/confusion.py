# Copyright © 2026 Sthenos Security. All rights reserved.

"""
Dependency Confusion Detection

Identifies private/internal packages whose names also exist on public
registries. This is a high-severity supply chain risk: an attacker can
publish a higher-versioned package on the public registry to hijack installs.

How it works:
1. PURL enrichment (Step 1b) identifies which packages are truly private
   (could not be resolved to a canonical public PURL via hash verification)
2. For each private package, we check if the name exists on the public
   npm/PyPI registry
3. If it exists (especially with a higher version) → dependency confusion risk

We never query the customer's private registry (Artifactory, Nexus, etc.)
"""

import logging
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass
from typing import Dict, List, Optional, Set, Tuple

from .registry import _FETCHERS, check_public_exists

logger = logging.getLogger(__name__)

# Ecosystems supported for confusion detection
SUPPORTED_ECOSYSTEMS = set(_FETCHERS.keys())  # npm, javascript, pypi, python

# Known public registry hosts — resolved packages from these are public
_PUBLIC_HOSTS = {
    "registry.npmjs.org",
    "pypi.org",
    "files.pythonhosted.org",
    "proxy.golang.org",
    "repo1.maven.org",
    "repo.maven.apache.org",
    "crates.io",
}


class RegistryError(Exception):
    """Registry lookup failure."""


class RateLimitedError(RegistryError):
    """Registry returned 429 / rate-limit response."""


@dataclass
class ConfusionResult:
    """Result of a public-registry existence check for a private package."""

    package_name: str
    ecosystem: str
    public_exists: bool = False
    public_version: Optional[str] = None
    private_version: Optional[str] = None
    is_critical: bool = False  # True when public version > private version

    def to_dict(self) -> Dict:
        return {
            "package_name": self.package_name,
            "ecosystem": self.ecosystem,
            "public_exists": self.public_exists,
            "public_version": self.public_version,
            "private_version": self.private_version,
            "is_critical": self.is_critical,
        }


def evaluate_confusion(cr: ConfusionResult) -> Optional[Dict]:
    """
    Return a signal dict if confusion is confirmed, else None.

    Uses the same shape as HealthSignal.to_dict() so supply_chain.js can render it.
    """
    if not cr.public_exists:
        return None

    severity = "high"
    detail = (
        f"Private package '{cr.package_name}' also exists on the public "
        f"{cr.ecosystem} registry"
    )
    if cr.public_version and cr.private_version:
        detail += (
            f" (public: {cr.public_version}, private: {cr.private_version})."
        )
        if cr.is_critical:
            severity = "critical"
            detail += " Public version is HIGHER — hijack risk is immediate."
        else:
            detail += (
                " An attacker could publish a higher version to hijack installs."
            )
    else:
        detail += ". An attacker could publish a higher version to hijack installs."

    return {
        "signal_type": "confused",
        "confidence": "high",
        "detail": detail,
        "severity": severity,
    }


def detect_private_packages(
    sbom_packages: List[Dict],
    purl_resolution_map: Optional[Dict[str, str]] = None,
) -> List[Dict]:
    """
    Identify packages that are likely private/internal.

    A package is considered private if:
    - Its resolved URL is non-empty AND points to a non-public registry host
    - It was not rewritten by PURL enrichment to a canonical public PURL

    Args:
        sbom_packages: List of package dicts from SBOM (name, version, ecosystem, purl, resolved)
        purl_resolution_map: Dict from PURL enrichment {original_purl: canonical_purl}

    Returns:
        List of package dicts that are likely private
    """
    purl_map = purl_resolution_map or {}
    private_packages = []

    for pkg in sbom_packages:
        purl = pkg.get("purl", "")
        resolved = pkg.get("resolved", "")
        ecosystem = pkg.get("ecosystem", "")

        # Skip unsupported ecosystems for confusion detection
        if ecosystem not in SUPPORTED_ECOSYSTEMS:
            continue

        # Check if resolved URL is from a public registry
        is_public_resolved = any(host in resolved for host in _PUBLIC_HOSTS)

        # Check if PURL enrichment resolved this to a canonical public PURL
        was_rewritten = purl in purl_map and purl_map[purl] != purl

        if is_public_resolved or was_rewritten:
            continue  # public package

        # If resolved URL is non-empty and points to a non-public host → private
        if resolved and not is_public_resolved:
            private_packages.append(pkg)

    return private_packages


def check_confusion(
    private_packages: List[Dict],
    max_workers: int = 10,
    timeout: float = 5.0,
) -> List[Tuple[Dict, ConfusionResult, Optional[Dict]]]:
    """
    Check if private package names exist on public registries.

    Args:
        private_packages: List of package dicts identified as private
        max_workers: Concurrent workers for registry checks
        timeout: Per-request timeout

    Returns:
        List of (package_dict, ConfusionResult, signal_dict or None) tuples.
        Only includes packages where confusion was detected.
    """
    if not private_packages:
        return []

    results = []
    rate_limited = False

    # Deduplicate by (name, ecosystem) — no point checking same name twice
    by_ecosystem: Dict[str, List[Dict]] = {}
    for pkg in private_packages:
        eco = pkg.get("ecosystem", "npm")
        by_ecosystem.setdefault(eco, []).append(pkg)

    for ecosystem, pkgs in by_ecosystem.items():
        if ecosystem not in SUPPORTED_ECOSYSTEMS:
            logger.debug(f"No registry support for {ecosystem}, skipping confusion check")
            continue

        seen_names: Set[str] = set()
        unique_pkgs = []
        for p in pkgs:
            name = p.get("name", "")
            if name and name not in seen_names:
                seen_names.add(name)
                unique_pkgs.append(p)

        logger.info(
            f"  Checking {len(unique_pkgs)} private {ecosystem} package(s) "
            f"for dependency confusion..."
        )

        def _check_one(pkg_dict: Dict) -> Tuple[Dict, ConfusionResult]:
            name = pkg_dict["name"]
            eco = pkg_dict.get("ecosystem", "npm")
            try:
                exists = check_public_exists(name, eco, timeout=timeout)
            except Exception as exc:
                raise RegistryError(str(exc)) from exc

            # Fetch public version for criticality assessment
            public_version = None
            if exists:
                try:
                    from .registry import fetch_metadata
                    meta = fetch_metadata(name, pkg_dict.get("version", ""), eco, timeout=timeout)
                    if meta.fetched:
                        public_version = meta.latest_version
                except Exception:
                    pass

            private_ver = pkg_dict.get("version", "")
            is_critical = False
            if public_version and private_ver:
                try:
                    from packaging.version import Version
                    is_critical = Version(public_version) > Version(private_ver)
                except Exception:
                    pass  # packaging not available — conservative

            cr = ConfusionResult(
                package_name=name,
                ecosystem=eco,
                public_exists=exists,
                public_version=public_version,
                private_version=private_ver,
                is_critical=is_critical,
            )
            return pkg_dict, cr

        workers = min(max_workers, len(unique_pkgs))
        with ThreadPoolExecutor(max_workers=workers) as pool:
            futures = {pool.submit(_check_one, p): p for p in unique_pkgs}

            for future in as_completed(futures):
                try:
                    pkg_dict, cr = future.result()

                    if cr.public_exists:
                        signal = evaluate_confusion(cr)
                        if signal:
                            results.append((pkg_dict, cr, signal))
                            level = "CRITICAL" if cr.is_critical else "HIGH"
                            logger.warning(
                                f"  ⚠ CONFUSION [{level}]: {cr.package_name} "
                                f"(private: {cr.private_version}) exists on public "
                                f"{ecosystem} (public: {cr.public_version})"
                            )

                except RateLimitedError:
                    if not rate_limited:
                        logger.warning(
                            f"  Rate limited by {ecosystem} registry, stopping confusion checks"
                        )
                        rate_limited = True
                    break
                except RegistryError as exc:
                    logger.debug(f"  Confusion check error: {exc}")
                except Exception as exc:
                    logger.debug(f"  Unexpected confusion check error: {exc}")

    return results
