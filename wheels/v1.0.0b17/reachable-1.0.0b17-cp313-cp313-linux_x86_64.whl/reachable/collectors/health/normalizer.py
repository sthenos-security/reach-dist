#!/usr/bin/env python3
# Copyright 2026 Sthenos Security. All rights reserved.

"""
Package Health Normalizer

Converts PackageHealthResult objects into the format expected by
data.json for dashboard rendering, and provides DB storage helpers.
"""

import json
import logging
from typing import Any, Dict, List

from .analyzer import PackageHealthResult

logger = logging.getLogger(__name__)


def normalize_for_dashboard(results: List[PackageHealthResult]) -> Dict[str, Any]:
    """Convert health results to dashboard data.json format.

    Returns dict to be merged into data.json under 'package_health' key.
    """
    advisories = []
    for r in results:
        entry = {
            "package": r.name,
            "version": r.version,
            "ecosystem": r.ecosystem,
            "status": r.status,
            "signals": [s.to_dict() for s in r.signals],
        }

        if r.metadata:
            entry["days_since_publish"] = r.metadata.days_since_last_publish
            entry["maintainer_count"] = r.metadata.maintainer_count
            entry["repository_url"] = r.metadata.repository_url
            entry["latest_version"] = r.metadata.latest_version
            entry["deprecated_msg"] = r.metadata.deprecated
        else:
            entry["days_since_publish"] = None
            entry["maintainer_count"] = None
            entry["repository_url"] = None
            entry["latest_version"] = None
            entry["deprecated_msg"] = None

        entry["is_direct"] = r.is_direct

        advisories.append(entry)

    status_counts = {"abandoned": 0, "deprecated": 0, "confused": 0, "info": 0}
    for a in advisories:
        s = a["status"]
        if s in status_counts:
            status_counts[s] += 1

    return {
        "summary": {
            "total_advisories": len(advisories),
            "abandoned": status_counts["abandoned"],
            "deprecated": status_counts["deprecated"],
            "confused": status_counts["confused"],
            "info": status_counts["info"],
        },
        "advisories": advisories,
    }


def results_to_db_rows(
    results: List[PackageHealthResult], scan_id: str
) -> List[Dict[str, Any]]:
    """Convert health results to rows for package_health DB table."""
    rows = []
    for r in results:
        row = {
            "scan_id": scan_id,
            "package_name": r.name,
            "package_version": r.version,
            "ecosystem": r.ecosystem,
            "status": r.status,
            "signals": json.dumps([s.to_dict() for s in r.signals]),
            "days_since_publish": r.metadata.days_since_last_publish if r.metadata else None,
            "maintainer_count": r.metadata.maintainer_count if r.metadata else None,
            "deprecated_msg": r.metadata.deprecated if r.metadata else None,
            "repository_url": r.metadata.repository_url if r.metadata else None,
            "latest_version": r.metadata.latest_version if r.metadata else None,
            "raw_metadata": json.dumps(r.metadata.to_dict()) if r.metadata else None,
        }
        rows.append(row)
    return rows
