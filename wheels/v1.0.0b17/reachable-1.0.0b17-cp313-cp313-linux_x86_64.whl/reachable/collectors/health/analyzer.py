#!/usr/bin/env python3
# Copyright 2026 Sthenos Security. All rights reserved.

"""
Package Health Analyzer

Takes PackageMetadata and computes health signals.
Pure logic - no I/O, no network, fully testable.
"""

import logging
from dataclasses import dataclass, field
from typing import Dict, List, Optional

from .registry import PackageMetadata

logger = logging.getLogger(__name__)

ABANDONED_DAYS = 730
STALE_DAYS = 365

STATUS_PRIORITY = {
    "healthy": 0,
    "info": 1,
    "deprecated": 2,
    "abandoned": 3,
    "confused": 4,
}


@dataclass
class HealthSignal:
    """A single health signal for a package."""

    signal_type: str
    confidence: str
    detail: str

    def to_dict(self) -> Dict:
        return {
            "signal_type": self.signal_type,
            "confidence": self.confidence,
            "detail": self.detail,
        }


@dataclass
class PackageHealthResult:
    """Health assessment for a single package."""

    name: str
    version: str
    ecosystem: str
    status: str = "healthy"
    signals: List[HealthSignal] = field(default_factory=list)
    metadata: Optional[PackageMetadata] = None
    is_direct: bool = False  # True if listed in a manifest (not only in a lock file)

    def to_dict(self) -> Dict:
        return {
            "name": self.name,
            "version": self.version,
            "ecosystem": self.ecosystem,
            "status": self.status,
            "signals": [s.to_dict() for s in self.signals],
            "metadata": self.metadata.to_dict() if self.metadata else None,
            "is_direct": self.is_direct,
        }


def _resolve_status(signals: List[HealthSignal]) -> str:
    """Determine overall status from signals. Highest priority wins."""
    if not signals:
        return "healthy"

    signal_to_status = {
        "abandoned": "abandoned",
        "deprecated": "deprecated",
        "yanked": "deprecated",
        "stale": "info",
        "single_maintainer": "info",
        "no_repository": "info",
        "confused": "confused",
        "fetch_error": "info",
    }

    best_status = "healthy"
    best_priority = -1

    for sig in signals:
        mapped = signal_to_status.get(sig.signal_type, "info")
        prio = STATUS_PRIORITY.get(mapped, 0)
        if prio > best_priority:
            best_priority = prio
            best_status = mapped

    return best_status


def analyze_public_package(meta: PackageMetadata) -> PackageHealthResult:
    """Analyze a public package for health signals."""
    result = PackageHealthResult(
        name=meta.name, version=meta.version, ecosystem=meta.ecosystem, metadata=meta
    )

    if not meta.fetched:
        result.signals.append(HealthSignal(
            signal_type="fetch_error",
            confidence="low",
            detail=f"Could not fetch metadata: {meta.error or 'unknown'}",
        ))
        result.status = _resolve_status(result.signals)
        return result

    if meta.deprecated:
        result.signals.append(HealthSignal(
            signal_type="deprecated",
            confidence="high",
            detail=f"Registry deprecated: {meta.deprecated}",
        ))

    if meta.yanked:
        result.signals.append(HealthSignal(
            signal_type="yanked",
            confidence="high",
            detail=f"Version {meta.version} has been yanked from the registry.",
        ))

    days = meta.days_since_last_publish
    if days is not None:
        if days >= ABANDONED_DAYS:
            result.signals.append(HealthSignal(
                signal_type="abandoned",
                confidence="high",
                detail=f"Last published {days} days ago ({days // 365}+ years). No active maintenance.",
            ))
        elif days >= STALE_DAYS:
            result.signals.append(HealthSignal(
                signal_type="stale",
                confidence="medium",
                detail=f"Last published {days} days ago. Maintenance may be inactive.",
            ))

    if meta.maintainer_count == 1:
        result.signals.append(HealthSignal(
            signal_type="single_maintainer",
            confidence="low",
            detail=f"Single maintainer: {meta.maintainers[0] if meta.maintainers else 'unknown'}",
        ))

    if not meta.repository_url:
        result.signals.append(HealthSignal(
            signal_type="no_repository",
            confidence="low",
            detail="No source repository URL in registry metadata.",
        ))

    result.status = _resolve_status(result.signals)
    return result


def analyze_private_package(
    name: str,
    version: str,
    ecosystem: str,
    exists_on_public: bool,
) -> Optional[PackageHealthResult]:
    """Analyze a private package for dependency confusion."""
    if not exists_on_public:
        return None

    result = PackageHealthResult(name=name, version=version, ecosystem=ecosystem)
    result.signals.append(HealthSignal(
        signal_type="confused",
        confidence="high",
        detail=(
            f"Private package '{name}' also exists on the public {ecosystem} registry. "
            "This creates a dependency confusion attack vector \u2014 an adversary could "
            "publish a higher version on the public registry."
        ),
    ))
    result.status = "confused"
    return result
