#!/usr/bin/env python3
# Copyright 2026 Sthenos Security. All rights reserved.

"""
Database schema addition for package_health table.

This file contains the SQL and the helper functions to add to storage.py.
Apply as a patch or copy the relevant sections.
"""

# --- SQL: Add to CREATE TABLE block in storage.py ---

PACKAGE_HEALTH_TABLE_SQL = """
CREATE TABLE IF NOT EXISTS package_health (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    scan_id         TEXT NOT NULL,
    package_name    TEXT NOT NULL,
    package_version TEXT NOT NULL,
    ecosystem       TEXT NOT NULL,
    status          TEXT NOT NULL DEFAULT 'healthy',
    signals         TEXT DEFAULT '[]',
    days_since_publish INTEGER,
    maintainer_count   INTEGER,
    deprecated_msg  TEXT,
    repository_url  TEXT,
    latest_version  TEXT,
    raw_metadata    TEXT,
    created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (scan_id) REFERENCES scans(scan_id)
);
"""

# --- Python: store_package_health() - add to storage.py ---

STORE_FUNCTION = '''
def store_package_health(self, scan_id: str, rows: list) -> int:
    """Store package health results.

    Args:
        scan_id: Current scan ID.
        rows: List of dicts from normalizer.results_to_db_rows().

    Returns:
        Number of rows inserted.
    """
    if not rows:
        return 0

    sql = """
        INSERT INTO package_health
            (scan_id, package_name, package_version, ecosystem, status,
             signals, days_since_publish, maintainer_count, deprecated_msg,
             repository_url, latest_version, raw_metadata)
        VALUES
            (:scan_id, :package_name, :package_version, :ecosystem, :status,
             :signals, :days_since_publish, :maintainer_count, :deprecated_msg,
             :repository_url, :latest_version, :raw_metadata)
    """
    cursor = self.conn.cursor()
    for row in rows:
        cursor.execute(sql, row)
    self.conn.commit()
    return len(rows)
'''

# --- Python: load_package_health() - add to storage.py ---

LOAD_FUNCTION = '''
def load_package_health(self, scan_id: str) -> list:
    """Load package health results for a scan.

    Returns:
        List of dicts ready for dashboard data.json.
    """
    sql = """
        SELECT package_name, package_version, ecosystem, status,
               signals, days_since_publish, maintainer_count,
               deprecated_msg, repository_url, latest_version
        FROM package_health
        WHERE scan_id = ?
        ORDER BY
            CASE status
                WHEN 'confused' THEN 0
                WHEN 'abandoned' THEN 1
                WHEN 'deprecated' THEN 2
                WHEN 'info' THEN 3
                ELSE 4
            END
    """
    cursor = self.conn.cursor()
    cursor.execute(sql, (scan_id,))
    rows = cursor.fetchall()

    results = []
    for row in rows:
        results.append({
            "package": row[0],
            "version": row[1],
            "ecosystem": row[2],
            "status": row[3],
            "signals": json.loads(row[4]) if row[4] else [],
            "days_since_publish": row[5],
            "maintainer_count": row[6],
            "deprecated_msg": row[7],
            "repository_url": row[8],
            "latest_version": row[9],
        })
    return results
'''
