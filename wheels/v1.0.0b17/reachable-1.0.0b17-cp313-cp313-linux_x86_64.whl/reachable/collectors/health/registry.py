#!/usr/bin/env python3
# Copyright 2026 Sthenos Security. All rights reserved.

"""
Registry API Clients — stdlib only, no third-party dependencies.

Fetches package metadata from public registries:
  - npm:  registry.npmjs.org
  - PyPI: pypi.org/pypi

Uses urllib.request (stdlib) instead of requests.
"""

import json
import logging
import socket
import urllib.error
import urllib.parse
import urllib.request
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Dict, List, Optional

logger = logging.getLogger(__name__)

_NPM_BASE  = "https://registry.npmjs.org"
_PYPI_BASE = "https://pypi.org/pypi"
_HEADERS   = {
    "User-Agent": "reachable-security/1.0 (package-health-scanner)",
    "Accept": "application/json",
}


def _http_get(url: str, timeout: float = 8.0):
    """GET url → (status: int, body: bytes). Raises on network error."""
    req = urllib.request.Request(url, headers=_HEADERS)
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        return resp.status, resp.read()


def _http_head(url: str, timeout: float = 5.0) -> int:
    """HEAD url → HTTP status code, 0 on error."""
    req = urllib.request.Request(url, headers=_HEADERS, method="HEAD")
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return resp.status
    except urllib.error.HTTPError as exc:
        return exc.code
    except Exception:
        return 0


@dataclass
class PackageMetadata:
    """Normalised metadata from any registry."""
    name: str
    version: str
    ecosystem: str

    latest_version: Optional[str] = None
    latest_publish_iso: Optional[str] = None
    version_publish_iso: Optional[str] = None
    days_since_last_publish: Optional[int] = None
    deprecated: Optional[str] = None
    yanked: bool = False

    maintainer_count: int = 0
    maintainers: List[str] = field(default_factory=list)

    repository_url: Optional[str] = None
    homepage_url: Optional[str] = None
    total_versions: int = 0

    fetched: bool = False
    error: Optional[str] = None

    def to_dict(self) -> Dict:
        return {
            "name": self.name, "version": self.version, "ecosystem": self.ecosystem,
            "latest_version": self.latest_version,
            "latest_publish_iso": self.latest_publish_iso,
            "version_publish_iso": self.version_publish_iso,
            "days_since_last_publish": self.days_since_last_publish,
            "deprecated": self.deprecated, "yanked": self.yanked,
            "maintainer_count": self.maintainer_count, "maintainers": self.maintainers,
            "repository_url": self.repository_url, "homepage_url": self.homepage_url,
            "total_versions": self.total_versions,
            "fetched": self.fetched, "error": self.error,
        }


def _parse_iso_date(iso_str: Optional[str]) -> Optional[datetime]:
    if not iso_str:
        return None
    try:
        cleaned = iso_str.replace("Z", "+00:00")
        if "+" not in cleaned and "T" in cleaned:
            cleaned += "+00:00"
        return datetime.fromisoformat(cleaned)
    except (ValueError, TypeError):
        return None


def _days_since(iso_str: Optional[str]) -> Optional[int]:
    dt = _parse_iso_date(iso_str)
    if dt is None:
        return None
    return (datetime.now(timezone.utc) - dt).days


def fetch_npm(name: str, version: str, timeout: float = 8.0) -> PackageMetadata:
    """Fetch npm package metadata from registry.npmjs.org."""
    meta = PackageMetadata(name=name, version=version, ecosystem="npm")
    try:
        url = f"{_NPM_BASE}/{urllib.parse.quote(name, safe='@')}"
        try:
            status, body = _http_get(url, timeout=timeout)
        except urllib.error.HTTPError as exc:
            if exc.code == 404:
                meta.error = "not_found"
                return meta
            raise
        if status == 404:
            meta.error = "not_found"
            return meta

        data = json.loads(body)
        time_map = data.get("time", {})
        if isinstance(time_map, str):
            time_map = {"modified": time_map}

        dist_tags = data.get("dist-tags", {})
        meta.latest_version = dist_tags.get("latest")

        if meta.latest_version and meta.latest_version in time_map:
            meta.latest_publish_iso = time_map[meta.latest_version]
        elif "modified" in time_map:
            meta.latest_publish_iso = time_map["modified"]

        if version in time_map:
            meta.version_publish_iso = time_map[version]

        meta.days_since_last_publish = _days_since(meta.latest_publish_iso)

        raw_maintainers = data.get("maintainers", [])
        if raw_maintainers:
            meta.maintainers = [
                m.get("name", str(m)) if isinstance(m, dict) else str(m)
                for m in raw_maintainers
            ]
            meta.maintainer_count = len(meta.maintainers)

        versions = data.get("versions", {})
        meta.total_versions = len(versions) if isinstance(versions, dict) else 0

        ver_data = versions.get(version, {}) if isinstance(versions, dict) else {}
        dep_msg = ver_data.get("deprecated")
        if dep_msg:
            meta.deprecated = str(dep_msg)
        elif data.get("deprecated"):
            meta.deprecated = str(data["deprecated"])

        repo = data.get("repository")
        if isinstance(repo, dict):
            meta.repository_url = repo.get("url", "")
        elif isinstance(repo, str):
            meta.repository_url = repo

        meta.homepage_url = data.get("homepage")
        meta.fetched = True

    except socket.timeout:
        meta.error = "timeout"
    except urllib.error.URLError as exc:
        if "timed out" in str(exc).lower() or isinstance(getattr(exc, "reason", None), socket.timeout):
            meta.error = "timeout"
        else:
            meta.error = f"network_error: {exc}"
    except Exception as exc:
        meta.error = f"parse_error: {exc}"

    return meta


def fetch_pypi(name: str, version: str, timeout: float = 8.0) -> PackageMetadata:
    """Fetch PyPI package metadata from pypi.org."""
    meta = PackageMetadata(name=name, version=version, ecosystem="pypi")
    try:
        url = f"{_PYPI_BASE}/{urllib.parse.quote(name)}/json"
        try:
            status, body = _http_get(url, timeout=timeout)
        except urllib.error.HTTPError as exc:
            if exc.code == 404:
                meta.error = "not_found"
                return meta
            raise
        if status == 404:
            meta.error = "not_found"
            return meta

        data = json.loads(body)
        info = data.get("info", {})
        meta.latest_version = info.get("version")
        meta.homepage_url = info.get("home_page")
        meta.repository_url = info.get("project_url") or info.get("home_page")

        project_urls = info.get("project_urls") or {}
        for key in ("Source", "Repository", "Source Code", "GitHub", "Code"):
            if key in project_urls:
                meta.repository_url = project_urls[key]
                break

        author = info.get("author") or info.get("maintainer")
        if author:
            meta.maintainers = [author]
            meta.maintainer_count = 1

        releases = data.get("releases", {})
        meta.total_versions = len(releases)

        if meta.latest_version and meta.latest_version in releases:
            files = releases[meta.latest_version]
            if files:
                upload_time = files[0].get("upload_time_iso_8601") or files[0].get("upload_time")
                if upload_time:
                    meta.latest_publish_iso = upload_time

        if version in releases:
            files = releases[version]
            if files:
                upload_time = files[0].get("upload_time_iso_8601") or files[0].get("upload_time")
                if upload_time:
                    meta.version_publish_iso = upload_time
                meta.yanked = bool(files[0].get("yanked", False))

        meta.days_since_last_publish = _days_since(meta.latest_publish_iso)

        classifiers = info.get("classifiers", [])
        for c in classifiers:
            if "Inactive" in c or "Deprecated" in c:
                meta.deprecated = c
                break

        meta.fetched = True

    except socket.timeout:
        meta.error = "timeout"
    except urllib.error.URLError as exc:
        if "timed out" in str(exc).lower() or isinstance(getattr(exc, "reason", None), socket.timeout):
            meta.error = "timeout"
        else:
            meta.error = f"network_error: {exc}"
    except Exception as exc:
        meta.error = f"parse_error: {exc}"

    return meta


_FETCHERS = {
    "npm": fetch_npm, "javascript": fetch_npm,
    "pypi": fetch_pypi, "python": fetch_pypi,
}


def fetch_metadata(name: str, version: str, ecosystem: str, timeout: float = 8.0) -> PackageMetadata:
    """Dispatch to the correct registry fetcher by ecosystem."""
    eco_key = ecosystem.lower().strip()
    fetcher = _FETCHERS.get(eco_key)
    if not fetcher:
        return PackageMetadata(name=name, version=version, ecosystem=eco_key,
                               error=f"unsupported_ecosystem: {eco_key}")
    return fetcher(name, version, timeout=timeout)


def check_public_exists(name: str, ecosystem: str, timeout: float = 5.0) -> bool:
    """HEAD check: does this package name exist on the public registry?"""
    eco = ecosystem.lower().strip()
    try:
        if eco in ("npm", "javascript"):
            return _http_head(f"{_NPM_BASE}/{urllib.parse.quote(name, safe='@')}", timeout) == 200
        elif eco in ("pypi", "python"):
            return _http_head(f"{_PYPI_BASE}/{urllib.parse.quote(name)}/json", timeout) == 200
    except Exception:
        pass
    return False
