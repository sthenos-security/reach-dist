# Copyright © 2026 Sthenos Security. All rights reserved.
"""
External tool wrappers and integrations.

Modules:
- lib_manager  - External library installation and management
- preflight    - System readiness checks
- git          - Git utilities
"""
