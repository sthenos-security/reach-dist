#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.

"""
MCP GitHub Integration for REACHABLE

5-Step Fetch Strategy (MCP-First with Smart Fallbacks):
1. SNIFF: Check repo size via API - abort MCP if > 50MB
2. GUARD: Check tree file count - abort MCP if > 500 files
3. EXECUTE: Use MCP to fetch files (small repos only)
4. FALLBACK 1: npm pack (exact version, no semver issues, no monorepo bloat)
5. FALLBACK 2: git shallow clone (last resort)

This prevents:
- Monorepo bloat (babel=26k files, next.js=9k files)
- Rate limit burn on huge repos
- Semver mismatches (npm pack always gets exact version)
"""

import base64
import json
import logging
import os
import shutil
import subprocess
import tempfile
import time
import urllib.error
import urllib.request
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, Optional, Tuple

logger = logging.getLogger(__name__)

# === CONFIGURATION ===
MAX_REPO_SIZE_KB = 50 * 1024  # 50MB - skip MCP for repos larger than this
MAX_FILES_MCP = 500  # Skip MCP if tree has more than 500 files
MCP_TIMEOUT_SECONDS = 60  # Abort MCP fetch after 60 seconds


@dataclass
class GitHubRepo:
    """GitHub repository information"""

    owner: str
    repo: str
    branch: Optional[str] = None
    commit: Optional[str] = None
    tag: Optional[str] = None

    @property
    def full_name(self):
        return f"{self.owner}/{self.repo}"

    @property
    def ref(self):
        if self.commit:
            return self.commit
        elif self.tag:
            return f"refs/tags/{self.tag}"
        elif self.branch:
            return f"refs/heads/{self.branch}"
        else:
            return "refs/heads/main"

    @ref.setter
    def ref(self, value: str):
        if value is None:
            return
        if value.startswith("v") or (value and value[0].isdigit()):
            self.tag = value
            self.branch = None
            self.commit = None
        elif len(value) == 40 and all(c in "0123456789abcdef" for c in value.lower()):
            self.commit = value
            self.tag = None
            self.branch = None
        else:
            self.branch = value
            self.tag = None
            self.commit = None

    @classmethod
    def parse(cls, repo_url: str) -> "GitHubRepo":
        """Parse GitHub URL or shorthand"""
        if not repo_url or len(repo_url) < 5:
            raise ValueError(f"Invalid GitHub repo format: {repo_url}")

        # Normalize URL formats
        if repo_url.startswith("git://"):
            repo_url = repo_url.replace("git://", "https://", 1)
        elif repo_url.startswith("git:/") and not repo_url.startswith("git://"):
            repo_url = "https://" + repo_url[5:]
        if repo_url.startswith("git+https://"):
            repo_url = repo_url.replace("git+https://", "https://", 1)
        if repo_url.startswith("ssh://git@github.com"):
            repo_url = repo_url.replace("ssh://git@github.com", "https://github.com", 1)

        if "github.com" not in repo_url.lower() and not repo_url.startswith("github:"):
            raise ValueError(f"Not a GitHub URL: {repo_url}")

        # Remove prefixes
        for prefix in ["github:", "https://github.com/", "http://github.com/"]:
            if repo_url.startswith(prefix):
                repo_url = repo_url[len(prefix) :]
                break
        if repo_url.endswith(".git"):
            repo_url = repo_url[:-4]

        parts = repo_url.split("/")
        if len(parts) < 2:
            raise ValueError(f"Invalid GitHub repo format: {repo_url}")

        owner, repo_part = parts[0], parts[1]
        if not owner or not repo_part:
            raise ValueError(f"Invalid GitHub repo format: {repo_url}")

        if "@" in repo_part:
            repo, ref = repo_part.split("@", 1)
            return cls(owner=owner, repo=repo, branch=ref)
        elif "#" in repo_part:
            repo, commit = repo_part.split("#", 1)
            return cls(owner=owner, repo=repo, commit=commit)
        elif len(parts) > 3 and parts[2] == "tree":
            return cls(owner=owner, repo=repo_part, branch="/".join(parts[3:]))
        else:
            return cls(owner=owner, repo=repo_part)

    from_url = parse


class MCPGitHubClient:
    """
    GitHub client with 5-step fetch strategy.

    1. SNIFF: Check repo size - skip MCP if > 50MB
    2. GUARD: Check file count - skip MCP if > 500 files
    3. EXECUTE: Fetch via MCP (small repos only)
    4. FALLBACK 1: npm pack (exact version, no semver issues)
    5. FALLBACK 2: git shallow clone
    """

    TOKEN_ENV_VARS = ["GITHUB_TOKEN", "GH_TOKEN", "MCP_GITHUB_TOKEN"]

    def __init__(self, github_token: Optional[str] = None):
        self.token = github_token
        if not self.token:
            for var in self.TOKEN_ENV_VARS:
                self.token = os.getenv(var)
                if self.token:
                    break
        if not self.token:
            try:
                from reachable.core.credentials import get_credential

                self.token = get_credential("github-mcp-token")
            except Exception:
                pass
        self.api_base = "https://api.github.com"
        self.cache_dir = Path.home() / ".reachable-cache" / "github-repos"
        self.cache_dir.mkdir(parents=True, exist_ok=True)

    def fetch_repository(
        self,
        repo: GitHubRepo,
        target_dir: Optional[Path] = None,
        package_name: Optional[str] = None,
        package_version: Optional[str] = None,
        ecosystem: Optional[str] = None,
    ) -> Path:
        """
        Fetch repository using 5-step strategy.

        Args:
            repo: GitHubRepo object
            target_dir: Target directory
            package_name: Package name for npm pack fallback
            package_version: Package version for npm pack fallback
            ecosystem: Package ecosystem ("npm", "pypi", "go", etc.)
        """
        start_time = time.time()

        if target_dir is None:
            cache_key = f"{repo.full_name}@{repo.ref}".replace("/", "_").replace(":", "_")
            target_dir = Path(self.cache_dir / cache_key)
        else:
            target_dir = Path(target_dir)

        # Check cache
        if target_dir.exists() and any(target_dir.iterdir()):
            logger.info(f" Using cached repository: {target_dir}")
            return target_dir

        logger.info(f" [MCP] Fetching {repo.full_name} (ref: {repo.ref}) via GitHub API...")
        self._log_auth_status()

        mcp_skip_reason = None

        try:
            # === STEP 1: SNIFF - Check repo size ===
            repo_size_kb = self._sniff_repo_size(repo)
            if repo_size_kb > MAX_REPO_SIZE_KB:
                mcp_skip_reason = f"repo too large ({repo_size_kb // 1024}MB > {MAX_REPO_SIZE_KB // 1024}MB)"
                logger.info(f" [MCP] SNIFF failed: {mcp_skip_reason}")
                raise Exception(mcp_skip_reason)
            logger.info(f" [MCP] SNIFF passed: {repo_size_kb}KB")

            # === STEP 2: GUARD - Check file count ===
            tree_sha = self._get_tree_sha(repo)
            logger.info(f" [MCP] Tree SHA: {tree_sha[:12]}...")

            tree = self._get_tree_recursive(repo, tree_sha)
            file_count = len([item for item in tree["tree"] if item["type"] == "blob"])

            if file_count > MAX_FILES_MCP:
                mcp_skip_reason = f"too many files ({file_count} > {MAX_FILES_MCP})"
                logger.info(f" [MCP] GUARD failed: {mcp_skip_reason}")
                raise Exception(mcp_skip_reason)
            logger.info(f" [MCP] GUARD passed: {file_count} files")

            # === STEP 3: EXECUTE - Download files ===
            target_dir.mkdir(parents=True, exist_ok=True)

            downloaded = 0
            for item in tree["tree"]:
                if item["type"] == "blob":
                    self._download_file(repo, item, target_dir)
                    downloaded += 1
                    if downloaded % 50 == 0:
                        logger.info(f" [MCP] Progress: {downloaded}/{file_count} files...")

            duration_ms = (time.time() - start_time) * 1000
            logger.info(f" [MCP] Downloaded {downloaded} files in {duration_ms:.0f}ms")
            logger.info(f" [MCP] Saved to: {target_dir}")
            return target_dir

        except Exception as mcp_error:
            logger.info(f" [MCP] MCP failed: {str(mcp_error)[:80]}")

            # === STEP 4: FALLBACK 1 - npm pack ===
            if ecosystem == "npm" and package_name and package_version:
                try:
                    result = self._fallback_npm_pack(package_name, package_version, target_dir, start_time)
                    if result:
                        return result
                except Exception as npm_error:
                    logger.info(f" [NPM] npm pack failed: {str(npm_error)[:80]}")

            # === STEP 5: FALLBACK 2 - git shallow clone ===
            try:
                result = self._fallback_git_shallow(repo, target_dir, start_time)
                return result
            except Exception as git_error:
                logger.info(f" [GIT] git clone failed: {str(git_error)[:80]}")
                raise Exception(f"All fetch methods failed. MCP: {mcp_error}, Git: {git_error}") from git_error

    def _log_auth_status(self):
        """Log authentication status"""
        if self.token:
            masked = self.token[:7] + "***" + self.token[-3:] if len(self.token) > 10 else "***"
            token_type = (
                "fine-grained"
                if self.token.startswith("github_pat_")
                else "classic" if self.token.startswith("ghp_") else "unknown"
            )
            logger.info(f" [MCP] Authentication: Token present ({masked}, type: {token_type})")
        else:
            logger.info(" [MCP] Authentication: None (public access, rate limited)")

    def _sniff_repo_size(self, repo: GitHubRepo) -> int:
        """STEP 1: SNIFF - Check repository size in KB"""
        url = f"{self.api_base}/repos/{repo.full_name}"
        data = self._api_request(url)
        return data.get("size", 0)  # GitHub returns size in KB

    def _get_tree_sha(self, repo: GitHubRepo) -> str:
        """Get tree SHA for the specified ref"""
        if not repo.tag:
            ref = repo.ref.replace("refs/", "")
            url = f"{self.api_base}/repos/{repo.full_name}/git/ref/{ref}"
            try:
                data = self._api_request(url)
                return data["object"]["sha"]
            except Exception as e:
                raise Exception(f"Could not find ref '{ref}': {e}") from e

        # Tag resolution with exact matching only (no fuzzy matching!)
        tag = repo.tag

        # Try exact tag patterns
        for tag_format in [f"tags/{tag}", f"tags/v{tag}", f"tags/{tag.lstrip('v')}"]:
            url = f"{self.api_base}/repos/{repo.full_name}/git/ref/{tag_format}"
            try:
                data = self._api_request(url)
                return data["object"]["sha"]
            except Exception:
                continue

        # If exact match fails, let fallback handle it (npm pack will get exact version)
        raise Exception(f"Tag '{tag}' not found - will try npm pack for exact version") from None

    def _get_tree_recursive(self, repo: GitHubRepo, tree_sha: str) -> Dict:
        """Get recursive tree structure"""
        url = f"{self.api_base}/repos/{repo.full_name}/git/trees/{tree_sha}?recursive=1"
        return self._api_request(url)

    def _download_file(self, repo: GitHubRepo, item: Dict, target_dir: Path):
        """Download a single file"""
        file_path = target_dir / item["path"]
        file_path.parent.mkdir(parents=True, exist_ok=True)

        url = f"{self.api_base}/repos/{repo.full_name}/git/blobs/{item['sha']}"
        data = self._api_request(url)
        content = base64.b64decode(data["content"])

        with open(file_path, "wb") as f:
            f.write(content)

    def _fallback_npm_pack(self, package_name: str, version: str, target_dir: Path, start_time: float) -> Path:
        """
        STEP 4: FALLBACK 1 - npm pack

        npm pack always gets the EXACT published version:
        - No semver guessing
        - No monorepo bloat (only published files)
        - Works even if tag doesn't exist in git
        """
        logger.info(f" [NPM] Trying npm pack {package_name}@{version}...")

        target_dir.mkdir(parents=True, exist_ok=True)

        # Create temp dir for npm pack
        with tempfile.TemporaryDirectory() as temp_dir:
            temp_path = Path(temp_dir)

            # Run npm pack
            cmd = ["npm", "pack", f"{package_name}@{version}", "--pack-destination", str(temp_path)]

            env = os.environ.copy()
            env["npm_config_progress"] = "false"

            result = subprocess.run(cmd, capture_output=True, text=True, timeout=120, cwd=temp_path, env=env)

            if result.returncode != 0:
                raise Exception(f"npm pack failed: {result.stderr}") from None

            # Find the tarball
            tarballs = list(temp_path.glob("*.tgz"))
            if not tarballs:
                raise Exception("npm pack produced no tarball") from None

            tarball = tarballs[0]

            # Extract tarball
            import tarfile

            with tarfile.open(tarball, "r:gz") as tar:
                tar.extractall(temp_path)

            # npm pack extracts to 'package/' directory
            package_dir = temp_path / "package"
            if not package_dir.exists():
                # Try finding extracted dir
                dirs = [d for d in temp_path.iterdir() if d.is_dir()]
                if dirs:
                    package_dir = dirs[0]
                else:
                    raise Exception("Could not find extracted package directory") from None

            # Move contents to target
            for item in package_dir.iterdir():
                dest = target_dir / item.name
                if item.is_dir():
                    shutil.copytree(item, dest, dirs_exist_ok=True)
                else:
                    shutil.copy2(item, dest)

        duration_ms = (time.time() - start_time) * 1000
        file_count = sum(1 for _ in target_dir.rglob("*") if _.is_file())
        logger.info(f" [NPM] Downloaded {file_count} files via npm pack in {duration_ms:.0f}ms")

        return target_dir

    def _fallback_git_shallow(self, repo: GitHubRepo, target_dir: Path, start_time: float) -> Path:
        """
        STEP 5: FALLBACK 2 - git shallow clone

        Uses --depth 1 to avoid downloading full history.
        """
        logger.info(" [GIT] Trying git shallow clone...")

        # Check for SSH config (any common key type or Host github.com in config)
        ssh_dir = Path.home() / ".ssh"
        ssh_configured = any((ssh_dir / k).exists() for k in ("id_ed25519", "id_rsa", "id_ecdsa", "id_ed25519_sk"))
        if not ssh_configured and (ssh_dir / "config").exists():
            try:
                cfg = (ssh_dir / "config").read_text(errors="ignore").lower()
                ssh_configured = "github.com" in cfg
            except Exception:
                pass

        if ssh_configured:
            clone_url = f"git@github.com:{repo.full_name}.git"
        else:
            clone_url = f"https://github.com/{repo.full_name}.git"

        cmd = ["git", "clone", "--depth=1", "--single-branch"]

        # Add branch/tag
        branch_ref = repo.ref
        if branch_ref.startswith("refs/tags/"):
            branch_ref = branch_ref[10:]  # Remove 'refs/tags/'
            cmd.extend(["--branch", branch_ref])
        elif branch_ref.startswith("refs/heads/"):
            branch_ref = branch_ref[11:]  # Remove 'refs/heads/'
            if branch_ref not in ("HEAD", "main", "master"):
                cmd.extend(["--branch", branch_ref])

        cmd.extend([clone_url, str(target_dir)])

        logger.info(f" [GIT] Running: git clone --depth=1 ... ({'SSH' if ssh_configured else 'HTTPS'})")

        env = os.environ.copy()
        env["GIT_TERMINAL_PROMPT"] = "0"
        env["GIT_ASKPASS"] = "echo"

        result = subprocess.run(cmd, capture_output=True, text=True, timeout=300, env=env)

        if result.returncode != 0:
            raise Exception(f"Git clone failed: {result.stderr}") from None

        duration_ms = (time.time() - start_time) * 1000
        file_count = sum(1 for _ in target_dir.rglob("*") if _.is_file())

        logger.info(f" [GIT] Clone complete ({file_count} files, {duration_ms:.0f}ms)")

        return target_dir

    def _api_request(self, url: str) -> Dict:
        """Make GitHub API request"""
        request = urllib.request.Request(url)

        if self.token:
            if self.token.startswith("github_pat_") or self.token.startswith("ghp_"):
                request.add_header("Authorization", f"Bearer {self.token}")
            else:
                request.add_header("Authorization", f"token {self.token}")

        request.add_header("Accept", "application/vnd.github.v3+json")
        request.add_header("User-Agent", "REACHABLE-Security-Scanner")

        try:
            with urllib.request.urlopen(request, timeout=10) as response:
                return json.loads(response.read().decode())
        except urllib.error.HTTPError as e:
            error_msg = f"GitHub API error: {e.code} {e.reason}"
            if e.code == 401:
                error_msg += " (Invalid token)"
            elif e.code == 403:
                error_msg += " (Rate limit exceeded or insufficient permissions)"
            elif e.code == 404:
                error_msg += " (Not found)"
            raise Exception(error_msg) from e
        except urllib.error.URLError as e:
            raise Exception(f"Connection error: {e.reason}") from e


class GitCloneClient:
    """Legacy git clone client (for --git-clone flag)"""

    TOKEN_ENV_VARS = ["GITHUB_TOKEN", "GH_TOKEN", "MCP_GITHUB_TOKEN"]

    def __init__(self, github_token: Optional[str] = None):
        self.token = github_token
        if not self.token:
            for var in self.TOKEN_ENV_VARS:
                self.token = os.getenv(var)
                if self.token:
                    break
        if not self.token:
            try:
                from reachable.core.credentials import get_credential

                self.token = get_credential("github-token")
            except Exception:
                pass
        self.cache_dir = Path.home() / ".reachable-cache" / "git-clones"
        self.cache_dir.mkdir(parents=True, exist_ok=True)

    def clone_repository(self, repo: GitHubRepo, target_dir: Optional[Path] = None) -> Path:
        """Clone repository using git"""
        if target_dir is None:
            cache_key = f"{repo.full_name}@{repo.ref}".replace("/", "_").replace(":", "_")
            target_dir = self.cache_dir / cache_key

        if target_dir.exists() and (target_dir / ".git").exists():
            logger.info(f" Using cached clone: {target_dir}")
            return target_dir

        logger.info(f" Cloning {repo.full_name} via git...")

        if self.token:
            clone_url = f"https://{self.token}@github.com/{repo.full_name}.git"
        else:
            clone_url = f"https://github.com/{repo.full_name}.git"

        cmd = ["git", "clone", "--depth", "1"]

        if repo.branch:
            cmd.extend(["--branch", repo.branch])
        elif repo.tag:
            cmd.extend(["--branch", repo.tag])

        cmd.extend([clone_url, str(target_dir)])

        env = os.environ.copy()
        env["GIT_TERMINAL_PROMPT"] = "0"

        try:
            subprocess.run(cmd, check=True, capture_output=True, text=True, env=env)

            if repo.commit:
                subprocess.run(
                    ["git", "-C", str(target_dir), "checkout", repo.commit],
                    check=True,
                    capture_output=True,
                    env=env,
                )

            logger.info(f" Cloned to {target_dir}")
            return target_dir

        except subprocess.CalledProcessError as e:
            raise Exception(f"Git clone failed: {e.stderr}") from e
        except FileNotFoundError:
            raise Exception("git binary not found") from None


def clone_github_repo_mcp(
    repo_url: str,
    target_dir: str,
    branch_or_tag: str = None,
    package_name: str = None,
    package_version: str = None,
    ecosystem: str = None,
) -> bool:
    """
    Clone a GitHub repository using 5-step strategy.

    This is the function called by lib_manager for library cloning.

    Args:
        repo_url: GitHub repository URL
        target_dir: Target directory
        branch_or_tag: Version/tag to checkout
        package_name: Package name for npm pack fallback
        package_version: Package version for npm pack fallback
        ecosystem: Package ecosystem ("npm", "pypi", "go")

    Returns:
        True if successful, False otherwise
    """
    try:
        target_path = Path(target_dir)
        repo = GitHubRepo.parse(repo_url)

        if branch_or_tag:
            repo.ref = branch_or_tag

        client = MCPGitHubClient()
        result_path = client.fetch_repository(
            repo,
            target_dir=target_path,
            package_name=package_name,
            package_version=package_version,
            ecosystem=ecosystem,
        )

        return result_path.exists() and any(result_path.iterdir())

    except Exception as e:
        logger.debug(f" Clone error: {str(e)[:100]}")
        return False


def analyze_github_repository(
    repo_url: str, use_git_clone: bool = False, github_token: Optional[str] = None
) -> Tuple[Path, GitHubRepo]:
    """Analyze GitHub repository"""
    repo = GitHubRepo.parse(repo_url)

    if use_git_clone:
        logger.info("  Using LEGACY git clone mode")
        client = GitCloneClient(github_token)
        repo_path = client.clone_repository(repo)
    else:
        logger.info(" Using 5-step MCP strategy")
        client = MCPGitHubClient(github_token)
        repo_path = client.fetch_repository(repo)

    return repo_path, repo


if __name__ == "__main__":
    import sys

    if len(sys.argv) < 2:
        logger.info("Usage: python mcp_github.py <repo_url> [--git-clone]")
        logger.info("\nExamples:")
        logger.info("  python mcp_github.py github:psf/requests")
        logger.info("  python mcp_github.py github:lodash/lodash@4.17.21")
        sys.exit(1)

    repo_url = sys.argv[1]
    use_git = "--git-clone" in sys.argv

    logging.basicConfig(level=logging.INFO, format="%(message)s")

    try:
        repo_path, repo = analyze_github_repository(repo_url, use_git_clone=use_git)
        logger.info(f"\n Repository ready: {repo_path}")
    except Exception as e:
        logger.info(f" Error: {e}")
        sys.exit(1)
