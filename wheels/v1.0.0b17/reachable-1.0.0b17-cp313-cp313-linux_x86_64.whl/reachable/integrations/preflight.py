#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.

"""
Preflight Check - Single function to verify REACHABLE is ready to run.

Call this before scan, selftest, or doctor. Optionally auto-fix issues.

Usage:
    from reachable.preflight import preflight_check

    # Check only (returns issues list)
    issues = preflight_check()

    # Check and fix
    issues = preflight_check(fix=True)

    # Quiet mode (no output)
    issues = preflight_check(quiet=True)
"""

import logging
import shutil
import subprocess
import sys
from pathlib import Path
from typing import Dict, List

# Initialize module-level logger
logger = logging.getLogger(__name__)

# Cross-process lock for concurrent scan safety
from reachable.collectors.malware.guarddog_setup import setup_lock

# Tool locations
REACHABLE_HOME = Path.home() / ".reachable"
TOOLS_BIN = REACHABLE_HOME / "tools" / "bin"
VENV_DIR = REACHABLE_HOME / "venv"
VENV_BIN = VENV_DIR / "bin"
GUARDDOG_VENV = REACHABLE_HOME / "guarddog-venv"
GUARDDOG_BIN = GUARDDOG_VENV / "bin"
GRYPE_DB_CACHE = REACHABLE_HOME / "cache" / "grype-db"

# Tool versions — pinned for reproducibility.
# Used by the curl-based install scripts (_install_syft, _install_grype).
# Does NOT constrain a user's system-installed binary (brew, manual, etc.).
SYFT_VERSION = "v1.42.1"    # latest; improved npm/go/java SBOM accuracy + metadata.relationship
GRYPE_VERSION = "v0.109.0"  # latest; v6 DB schema

# Semgrep is installed into the managed venv via pip — we own it.
# Pinned so the venv is deterministic; bump + bump SEMGREP_CACHE_VERSION
# when upgrading.  The venv is rebuilt automatically on next scan.
SEMGREP_PINNED_VERSION = "1.113.0"

# Minimum supported versions — warn (never block) if below these.
# Grype v0.60 added SBOM support; earlier versions produce incomplete results.
# Syft v1.0 rewrote the JSON schema; v0.x output is incompatible.
# Semgrep v1.0 dropped the --strict flag and changed JSON output shape.
# tree-sitter-languages 1.5 changed get_parser() API; v1.4 raises AttributeError.
SYFT_MIN_VERSION = (1, 0, 0)
GRYPE_MIN_VERSION = (0, 88, 0)   # v6 DB schema required
SEMGREP_MIN_VERSION = (1, 1, 0)
TREE_SITTER_MIN_VERSION = (1, 5, 0)  # tree-sitter-languages package version


class PreflightResult:
    """Result of preflight check."""

    def __init__(self):
        self.checks: List[Dict] = []
        self.issues: List[str] = []
        self.fixed: List[str] = []

    def add_check(self, name: str, status: str, message: str = "", fixable: bool = False):
        """Add a check result."""
        self.checks.append(
            {
                "name": name,
                "status": status,  # 'ok', 'warn', 'fail'
                "message": message,
                "fixable": fixable,
            }
        )
        if status == "fail":
            self.issues.append(f"{name}: {message}")

    def add_fixed(self, name: str):
        """Record that something was fixed."""
        self.fixed.append(name)

    @property
    def ok(self) -> bool:
        """True if no failures."""
        return len(self.issues) == 0

    @property
    def has_warnings(self) -> bool:
        """True if there are warnings."""
        return any(c["status"] == "warn" for c in self.checks)


def preflight_check(
    fix: bool = False, quiet: bool = False, verbose: bool = False, skip_vulndb: bool = False
) -> PreflightResult:
    """
    Single preflight check for all REACHABLE dependencies.

    Checks:
        1. Python version (>= 3.9)
        2. syft binary in ~/.reachable/tools/bin/
        3. grype binary in ~/.reachable/tools/bin/
        4. semgrep in ~/.reachable/venv/bin/
        5. guarddog in ~/.reachable/guarddog-venv/bin/
        6. grype vulnerability DB (unless skip_vulndb=True)

    Args:
        fix: If True, attempt to install missing components
        quiet: If True, suppress all output
        verbose: If True, show detailed progress
        skip_vulndb: If True, skip vulnerability DB check (faster)

    Returns:
        PreflightResult with check status and any issues
    """

    result = PreflightResult()

    def log(msg: str):
        if not quiet:
            logger.info(msg)

    def log_verbose(msg: str):
        if verbose and not quiet:
            logger.info(msg)

    if not quiet:
        log(" Preflight check...")

    # 1. git client (required — not auto-fixable)
    git_path = shutil.which("git")
    if git_path:
        git_ver = _get_tool_version(Path(git_path), "--version")
        result.add_check("git", "ok")
        log_verbose(f"   git {git_ver}" if git_ver else "   git")
    else:
        result.add_check("git", "fail", "not found — scanner cannot clone library source", fixable=False)
        log("   git not found (install: brew install git | sudo apt install git)")

    # 2. Python version
    py_ver = sys.version_info
    if py_ver >= (3, 9):
        result.add_check("python", "ok", f"{py_ver.major}.{py_ver.minor}")
        log_verbose(f"   Python {py_ver.major}.{py_ver.minor}")
    else:
        result.add_check("python", "fail", f"{py_ver.major}.{py_ver.minor} < 3.9 required", fixable=False)
        log(f"   Python {py_ver.major}.{py_ver.minor} (3.9+ required)")

    # 3. syft binary
    syft_path = TOOLS_BIN / "syft"
    if syft_path.exists() and _check_tool_works(syft_path, "version"):
        syft_ver = _get_tool_version(syft_path, "version")
        pinned = SYFT_VERSION.lstrip("v")
        if syft_ver and syft_ver != pinned:
            if fix:
                log(f"   syft {syft_ver} → upgrading to {pinned}...")
                syft_path.unlink(missing_ok=True)
                if _install_syft():
                    result.add_check("syft", "ok")
                    result.add_fixed("syft")
                    log(f"   syft upgraded to {pinned}")
                else:
                    result.add_check("syft", "fail", "upgrade failed", fixable=True)
                    log("   syft upgrade failed")
            else:
                result.add_check("syft", "warn", f"version {syft_ver} (pinned: {pinned})", fixable=True)
                log(f"   syft {syft_ver} (pinned: {pinned} — run preflight --fix to upgrade)")
        else:
            result.add_check("syft", "ok")
            log_verbose(f"   syft {syft_ver}" if syft_ver else "   syft")
    else:
        if fix:
            log("   Installing syft...")
            if _install_syft():
                result.add_check("syft", "ok")
                result.add_fixed("syft")
                log("   syft installed")
            else:
                result.add_check("syft", "fail", "installation failed", fixable=True)
                log("   syft installation failed")
        else:
            result.add_check("syft", "fail", "not found", fixable=True)
            log("   syft not found")

    # 4. grype binary
    grype_path = TOOLS_BIN / "grype"
    if grype_path.exists() and _check_tool_works(grype_path, "version"):
        grype_ver = _get_tool_version(grype_path, "version")
        pinned = GRYPE_VERSION.lstrip("v")
        if grype_ver and grype_ver != pinned:
            if fix:
                log(f"   grype {grype_ver} → upgrading to {pinned}...")
                grype_path.unlink(missing_ok=True)
                if _install_grype():
                    result.add_check("grype", "ok")
                    result.add_fixed("grype")
                    log(f"   grype upgraded to {pinned}")
                else:
                    result.add_check("grype", "fail", "upgrade failed", fixable=True)
                    log("   grype upgrade failed")
            else:
                result.add_check("grype", "warn", f"version {grype_ver} (pinned: {pinned})", fixable=True)
                log(f"   grype {grype_ver} (pinned: {pinned} — run preflight --fix to upgrade)")
        else:
            result.add_check("grype", "ok")
            log_verbose(f"   grype {grype_ver}" if grype_ver else "   grype")
    else:
        if fix:
            log("   Installing grype...")
            if _install_grype():
                result.add_check("grype", "ok")
                result.add_fixed("grype")
                log("   grype installed")
            else:
                result.add_check("grype", "fail", "installation failed", fixable=True)
                log("   grype installation failed")
        else:
            result.add_check("grype", "fail", "not found", fixable=True)
            log("   grype not found")

    # 5. semgrep in venv
    semgrep_path = VENV_BIN / "semgrep"
    if semgrep_path.exists() and _check_tool_works(semgrep_path, "--version"):
        semgrep_ver = _get_tool_version(semgrep_path, "--version")
        result.add_check("semgrep", "ok")
        log_verbose(f"   semgrep {semgrep_ver}" if semgrep_ver else "   semgrep")
    else:
        if fix:
            log("   Installing semgrep...")
            if _install_semgrep():
                result.add_check("semgrep", "ok")
                result.add_fixed("semgrep")
                log("   semgrep installed")
            else:
                result.add_check("semgrep", "fail", "installation failed", fixable=True)
                log("   semgrep installation failed")
        else:
            result.add_check("semgrep", "fail", "not found", fixable=True)
            log("   semgrep not found")

    # 6. guarddog in isolated venv
    guarddog_path = GUARDDOG_BIN / "guarddog"
    if guarddog_path.exists() and _check_tool_works(guarddog_path, "--version"):
        guarddog_ver = _get_tool_version(guarddog_path, "--version")
        result.add_check("guarddog", "ok")
        log_verbose(f"   guarddog {guarddog_ver}" if guarddog_ver else "   guarddog")
    else:
        if fix:
            log("   Installing guarddog (isolated venv)...")
            if _install_guarddog():
                result.add_check("guarddog", "ok")
                result.add_fixed("guarddog")
                log("   guarddog installed")
            else:
                result.add_check("guarddog", "fail", "installation failed", fixable=True)
                log("   guarddog installation failed")
        else:
            result.add_check("guarddog", "fail", "not found", fixable=True)
            log("   guarddog not found")

    # 7. Joern (optional — JS/TS full callgraph, requires Java 17+ ~300MB)
    import shutil as _shutil

    # Detect Java and version
    _java_bin = _shutil.which("java")
    _java_ver = None
    if _java_bin:
        try:
            import re as _re

            _jv = subprocess.run([_java_bin, "-version"], capture_output=True, text=True, timeout=5)
            _jout = _jv.stderr + _jv.stdout  # java -version writes to stderr
            m = _re.search(r'version "(\d+)', _jout)
            if m:
                _java_ver = int(m.group(1))
        except Exception:
            pass

    _joern_sys = _shutil.which("joern")
    joern_path = TOOLS_BIN / "joern" if (TOOLS_BIN / "joern").exists() else (Path(_joern_sys) if _joern_sys else None)
    if joern_path and joern_path.exists():
        joern_ver = _get_tool_version(joern_path, "--version")
        if _java_ver and _java_ver < 17:
            result.add_check(
                "joern",
                "warn",
                f"installed but Java {_java_ver} detected — Joern requires Java 17+",
                fixable=False,
            )
            log(f"   joern: Java {_java_ver} detected (17+ required — upgrade: brew install openjdk@17)")
        else:
            result.add_check("joern", "ok")
            java_str = f" (Java {_java_ver})" if _java_ver else ""
            log_verbose(f"   joern {joern_ver}{java_str}" if joern_ver else f"   joern{java_str}")
    else:
        # Joern is optional — warn, never fail
        if fix and getattr(fix, "full", False) if hasattr(fix, "full") else False:
            log("   Installing Joern (this may take a few minutes)...")
            from reachable.collectors.callgraph.js_collector import install_joern

            if install_joern(verbose=not quiet):
                result.add_check("joern", "ok")
                result.add_fixed("joern")
                log("   joern installed")
            else:
                result.add_check("joern", "warn", "installation failed — JS callgraph unavailable", fixable=True)
        else:
            result.add_check(
                "joern",
                "warn",
                "not installed — JS/TS full callgraph unavailable "
                "(ts-morph import tracing runs as fallback). "
                "Install: brew install joern  or  reachctl doctor",
                fixable=True,
            )
            log_verbose("   joern: not installed (optional — brew install joern or run reachctl doctor to install)")

    # 8. grype vulnerability DB
    if not skip_vulndb:
        db_status = _check_vulndb()
        if db_status == "ok":
            result.add_check("vulndb", "ok")
            log_verbose("   grype vulnerability DB")
        elif db_status == "stale":
            result.add_check("vulndb", "warn", "stale (> 24h old)", fixable=True)
            log("    grype DB stale (will refresh on scan)")
        else:  # missing
            if fix:
                log("   Downloading vulnerability database...")
                if _update_vulndb():
                    result.add_check("vulndb", "ok")
                    result.add_fixed("vulndb")
                    log("   vulnerability DB downloaded")
                else:
                    result.add_check("vulndb", "warn", "download failed (will retry on scan)", fixable=True)
                    log("    vulnerability DB download failed")
            else:
                result.add_check("vulndb", "warn", "not initialized", fixable=True)
                log("    grype DB not initialized (will download on first scan)")

    # Summary
    if not quiet:
        if result.ok:
            if result.has_warnings:
                log(" Preflight passed with warnings")
            else:
                log(" Preflight passed")
        else:
            log(f" Preflight failed: {len(result.issues)} issue(s)")
            if not fix:
                log("   Run with --fix to auto-install missing tools")

    return result


def _check_tool_works(path: Path, version_arg: str) -> bool:
    """Check if a tool binary works."""
    try:
        result = subprocess.run([str(path), version_arg], capture_output=True, timeout=10)
        return result.returncode == 0
    except Exception:
        return False


def _get_tool_version(path: Path, version_arg: str) -> str:
    """Extract version string from a tool. Returns '' on failure."""
    try:
        import re as _re

        result = subprocess.run([str(path), version_arg], capture_output=True, text=True, timeout=10)
        if result.returncode == 0:
            output = result.stdout.strip() or result.stderr.strip()
            match = _re.search(r"(\d+\.\d+\.?\d*)", output)
            if match:
                return match.group(1)
    except Exception:
        pass
    return ""


def _check_vulndb() -> str:
    """Check vulnerability DB status. Returns 'ok', 'stale', or 'missing'."""
    try:
        from reachable.collectors.vulns.grype import VulnDBManager

        mgr = VulnDBManager()
        status = mgr.get_status()

        if not status["exists"]:
            return "missing"
        if status["is_stale"]:
            return "stale"
        return "ok"
    except Exception:
        return "missing"


def _update_vulndb() -> bool:
    """Update vulnerability database (lock-protected)."""
    with setup_lock("grype-db"):
        # Skip if another process already updated while we waited
        try:
            status = _check_vulndb()
            if status == "ok":
                return True
        except Exception:
            pass

        try:
            from reachable.collectors.vulns.grype import VulnDBManager

            mgr = VulnDBManager()
            return mgr.update(force=True, verbose=False)
        except Exception:
            return False


def _install_syft() -> bool:
    """Install syft using Anchore's install script (lock-protected)."""
    with setup_lock("syft"):
        # Skip if another process already installed while we waited
        if (TOOLS_BIN / "syft").exists() and _check_tool_works(TOOLS_BIN / "syft", "version"):
            return True

        TOOLS_BIN.mkdir(parents=True, exist_ok=True)

        try:
            import os
            import tempfile

            with tempfile.NamedTemporaryFile(suffix=".sh", delete=False) as tmp:
                tmp_path = tmp.name
            try:
                # Download install script
                dl = subprocess.run(
                    [
                        "curl",
                        "-sSfL",
                        "https://raw.githubusercontent.com/anchore/syft/main/install.sh",
                        "-o",
                        tmp_path,
                    ],
                    capture_output=True,
                    timeout=60,
                )
                if dl.returncode != 0:
                    return False
                os.chmod(tmp_path, 0o755)
                result = subprocess.run(
                    ["sh", tmp_path, "-b", str(TOOLS_BIN), SYFT_VERSION], capture_output=True, timeout=120
                )
                return result.returncode == 0 and (TOOLS_BIN / "syft").exists()
            finally:
                if os.path.exists(tmp_path):
                    os.unlink(tmp_path)
        except Exception:
            return False


def _install_grype() -> bool:
    """Install grype using Anchore's install script (lock-protected)."""
    with setup_lock("grype"):
        # Skip if another process already installed while we waited
        if (TOOLS_BIN / "grype").exists() and _check_tool_works(TOOLS_BIN / "grype", "version"):
            return True

        TOOLS_BIN.mkdir(parents=True, exist_ok=True)

        try:
            import os
            import tempfile

            with tempfile.NamedTemporaryFile(suffix=".sh", delete=False) as tmp:
                tmp_path = tmp.name
            try:
                dl = subprocess.run(
                    [
                        "curl",
                        "-sSfL",
                        "https://raw.githubusercontent.com/anchore/grype/main/install.sh",
                        "-o",
                        tmp_path,
                    ],
                    capture_output=True,
                    timeout=60,
                )
                if dl.returncode != 0:
                    return False
                os.chmod(tmp_path, 0o755)
                result = subprocess.run(
                    ["sh", tmp_path, "-b", str(TOOLS_BIN), GRYPE_VERSION], capture_output=True, timeout=120
                )
                return result.returncode == 0 and (TOOLS_BIN / "grype").exists()
            finally:
                if os.path.exists(tmp_path):
                    os.unlink(tmp_path)
        except Exception:
            return False


def _install_semgrep() -> bool:
    """Install semgrep into REACHABLE's venv (lock-protected)."""
    with setup_lock("semgrep-venv"):
        # Skip if another process already installed while we waited
        if (VENV_BIN / "semgrep").exists() and _check_tool_works(VENV_BIN / "semgrep", "--version"):
            return True

        VENV_DIR.mkdir(parents=True, exist_ok=True)

        try:
            # Create venv if it doesn't exist
            venv_python = VENV_BIN / "python3"
            if not venv_python.exists():
                venv_python = VENV_BIN / "python"  # Fallback for some systems

            if not venv_python.exists():
                subprocess.run(
                    [sys.executable, "-m", "venv", str(VENV_DIR)], check=True, capture_output=True, timeout=60
                )
                # Re-check after creation
                venv_python = VENV_BIN / "python3"
                if not venv_python.exists():
                    venv_python = VENV_BIN / "python"

            python_path = str(venv_python)

            # Ensure pip is available (some systems create venv without pip)
            subprocess.run([python_path, "-m", "ensurepip", "--upgrade"], capture_output=True, timeout=60)

            # Install semgrep using python -m pip (more reliable than pip binary)
            result = subprocess.run(
                [python_path, "-m", "pip", "install", "semgrep", "-q"], capture_output=True, timeout=300
            )
            return result.returncode == 0 and (VENV_BIN / "semgrep").exists()
        except Exception:
            return False


def _install_guarddog() -> bool:
    """Install guarddog into isolated venv.

    Uses the centralized guarddog_setup module which handles:
    - macOS: Installing libgit2 via Homebrew
    - Linux: Installing libgit2-dev via apt/dnf/yum/pacman/apk/zypper
    - Cross-platform venv creation and pip install
    """
    try:
        from reachable.collectors.malware.guarddog_setup import setup_guarddog

        return setup_guarddog(verbose=True)
    except Exception as e:
        logger.info(f" guarddog setup failed: {e}")
        return False


def ensure_ready(fix: bool = True, quiet: bool = False) -> bool:
    """
    Ensure REACHABLE is ready to run. Convenience wrapper.

    Args:
        fix: Auto-fix issues (default True)
        quiet: Suppress output

    Returns:
        True if ready, False if critical issues remain
    """
    result = preflight_check(fix=fix, quiet=quiet)
    return result.ok


# CLI entry point for testing
if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="REACHABLE Preflight Check")
    parser.add_argument("--fix", action="store_true", help="Auto-fix issues")
    parser.add_argument("--quiet", "-q", action="store_true", help="Quiet mode")
    parser.add_argument("--verbose", "-v", action="store_true", help="Verbose mode")
    args = parser.parse_args()

    result = preflight_check(fix=args.fix, quiet=args.quiet, verbose=args.verbose)
    sys.exit(0 if result.ok else 1)
