# REACHABLE AI Security Module - Configuration
# Copyright (c) 2026 Sthenos Security. All rights reserved.

"""
AI Security Scanner Configuration.

Defines configuration options for AI security scanning including:
- Detection modes (Semgrep, Tree-sitter, taint analysis)
- Language selection
- OWASP LLM category filtering
- Output options
"""

from dataclasses import dataclass
from pathlib import Path
from typing import Optional


@dataclass
class AIScanConfig:
    """Configuration for AI security scanning."""

    # Detection modes
    enable_semgrep: bool = True
    enable_treesitter: bool = True
    enable_taint_analysis: bool = True
    enable_reachability: bool = True  # AI-specific reachability analysis

    # Language selection (None = auto-detect)
    languages: Optional[list[str]] = None

    # OWASP LLM categories to scan (None = all)
    # Options: LLM01-LLM10
    owasp_categories: Optional[list[str]] = None

    # MCP scanning
    enable_mcp_analysis: bool = True

    # Tool capability mapping
    enable_tool_mapping: bool = True

    # Guard detection (reduces risk scores when controls present)
    enable_guard_detection: bool = True

    # Custom rule paths (additional to built-in rules)
    custom_semgrep_rules: Optional[list[Path]] = None

    # Severity threshold for findings
    # Options: INFO, WARNING, ERROR
    min_severity: str = "INFO"

    # Output options
    include_call_paths: bool = True
    include_guards_in_output: bool = True

    # Performance options
    max_files: Optional[int] = None  # None = no limit
    timeout_seconds: int = 300  # 5 minutes default

    # Integration options
    include_in_risk_score: bool = True  # Wire AI findings to correlation engine

    def __post_init__(self):
        """Validate configuration after initialization."""
        valid_severities = {"INFO", "WARNING", "ERROR"}
        if self.min_severity not in valid_severities:
            raise ValueError(f"min_severity must be one of {valid_severities}")

        valid_owasp = {f"LLM{i:02d}" for i in range(1, 11)}
        if self.owasp_categories:
            invalid = set(self.owasp_categories) - valid_owasp
            if invalid:
                raise ValueError(f"Invalid OWASP categories: {invalid}. Valid: {valid_owasp}")

        valid_languages = {"python", "typescript", "javascript", "go", "java", "rust"}
        if self.languages:
            invalid = set(self.languages) - valid_languages
            if invalid:
                raise ValueError(f"Unsupported languages: {invalid}. Valid: {valid_languages}")

    @classmethod
    def quick(cls) -> "AIScanConfig":
        """Fast scan configuration (Semgrep only, no taint analysis)."""
        return cls(
            enable_semgrep=True,
            enable_treesitter=False,
            enable_taint_analysis=False,
            enable_reachability=False,
            enable_tool_mapping=False,
            min_severity="WARNING",
        )

    @classmethod
    def full(cls) -> "AIScanConfig":
        """Full analysis configuration (all detectors enabled)."""
        return cls(
            enable_semgrep=True,
            enable_treesitter=True,
            enable_taint_analysis=True,
            enable_reachability=True,
            enable_mcp_analysis=True,
            enable_tool_mapping=True,
            enable_guard_detection=True,
            include_in_risk_score=True,
            min_severity="INFO",
        )

    @classmethod
    def owasp_only(cls, categories: list[str]) -> "AIScanConfig":
        """Scan for specific OWASP LLM categories only."""
        return cls(
            owasp_categories=categories,
            enable_semgrep=True,
            enable_treesitter=False,
            enable_taint_analysis=True,  # Needed for LLM01, LLM05
            enable_reachability=True,
        )

    @classmethod
    def ci_mode(cls) -> "AIScanConfig":
        """CI/CD optimized configuration (fast, high/critical only)."""
        return cls(
            enable_semgrep=True,
            enable_treesitter=False,
            enable_taint_analysis=False,
            enable_reachability=True,  # Still want reachability for CI
            enable_tool_mapping=False,
            min_severity="WARNING",
            timeout_seconds=120,  # Faster timeout for CI
            include_in_risk_score=True,
        )
