# REACHABLE AI Security Module
# Copyright (c) 2026 Sthenos Security. All rights reserved.
#
# AI/LLM security analysis for:
# - OWASP Top 10 for LLM Applications (2025)
# - MCP (Model Context Protocol) security
# - Prompt injection detection
# - Tool capability mapping
# - Model controls analysis

"""
REACHABLE AI Security Module

Extends REACHABLE's reachability-based AppSec model to AI/LLM/agentic systems.

Core Question:
    Can external input reach a model request, and can that request
    reach real-world side effects (filesystem, SaaS, databases, execution)?

Usage:
    from reachable.ai import AISecurityScanner, AIScanConfig

    scanner = AISecurityScanner()
    findings = scanner.scan(repo_path)

    # With reachability analysis
    from reachable.ai import AIReachabilityAnalyzer
    analyzer = AIReachabilityAnalyzer()
    results = analyzer.analyze_directory(repo_path)

    # Generate report
    from reachable.ai import AISecurityReport, create_ai_report_from_semgrep
    report = create_ai_report_from_semgrep(semgrep_output)
    report.save("ai-security.json")

Components:
    - detectors/semgrep/    OWASP LLM Top 10, MCP, model control rules
    - detectors/semgrep/garak_derived/   Garak-based jailbreak patterns (25 rules)
    - detectors/semgrep/corpus_derived/  Research corpus patterns (22 rules)
    - analyzers/            Taint tracking, reachability analysis
    - parsers/              Language-specific AI pattern detection
    - schemas/              AI finding and primitive data models
    - scoring/              OWASP LLM scoring, risk calculation
    - integrations/         Dashboard, correlation engine hooks

Schema Version: 2.0 (with AI extension)
"""

__version__ = "0.3.0"


# Lazy imports to avoid circular dependencies
def __getattr__(name):
    if name == "AISecurityScanner":
        from reachable.ai.scanner import AISecurityScanner

        return AISecurityScanner
    elif name == "AIScanConfig":
        from reachable.ai.config import AIScanConfig

        return AIScanConfig
    elif name == "AIReachabilityAnalyzer":
        from reachable.ai.ai_reachability import AIReachabilityAnalyzer

        return AIReachabilityAnalyzer
    elif name == "analyze_ai_reachability":
        from reachable.ai.ai_reachability import analyze_ai_reachability

        return analyze_ai_reachability
    elif name == "AISecurityReport":
        from reachable.ai.ai_schema import AISecurityReport

        return AISecurityReport
    elif name == "AIFinding":
        from reachable.ai.ai_schema import AIFinding

        return AIFinding
    elif name == "AISecuritySummary":
        from reachable.ai.ai_schema import AISecuritySummary

        return AISecuritySummary
    elif name == "create_ai_report_from_semgrep":
        from reachable.ai.ai_schema import create_ai_report_from_semgrep

        return create_ai_report_from_semgrep
    elif name == "extend_reachable_output":
        from reachable.ai.ai_schema import extend_reachable_output

        return extend_reachable_output
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


__all__ = [
    # Scanner
    "AISecurityScanner",
    "AIScanConfig",
    # Reachability (P6.8)
    "AIReachabilityAnalyzer",
    "analyze_ai_reachability",
    # Schema (P6.12)
    "AISecurityReport",
    "AIFinding",
    "AISecuritySummary",
    "create_ai_report_from_semgrep",
    "extend_reachable_output",
]
