# REACHABLE AI Security Module - AI Finding Schema
# Copyright (c) 2026 Sthenos Security. All rights reserved.

"""
AI Finding data model.

Represents a security finding from AI analysis, including:
- OWASP LLM Top 10 mapping
- Policy ID mapping (AI-001 to AI-010)
- Reachability path information
- Guard/control detection
- Risk scoring
"""

from dataclasses import dataclass, field
from datetime import datetime
from typing import Optional

# OWASP LLM Top 10 (2025) category names
OWASP_LLM_NAMES = {
    "LLM01": "Prompt Injection",
    "LLM02": "Sensitive Information Disclosure",
    "LLM03": "Supply Chain",
    "LLM04": "Data and Model Poisoning",
    "LLM05": "Improper Output Handling",
    "LLM06": "Excessive Agency",
    "LLM07": "System Prompt Leakage",
    "LLM08": "Vector and Embedding Weaknesses",
    "LLM09": "Misinformation",
    "LLM10": "Unbounded Consumption",
}

# Agentic Security Index (ASI) 2025 category names
OWASP_ASI_NAMES = {
    "ASI01": "Agent Goal Hijacking",
    "ASI02": "Tool Misuse",
    "ASI03": "Identity & Privilege Abuse",
    "ASI04": "Supply Chain Vulnerabilities",
    "ASI05": "Unexpected Code Execution",
    "ASI06": "Memory & Context Poisoning",
    "ASI07": "Inter-Agent Communication",
    "ASI08": "Cascading Failures",
    "ASI09": "Human-Agent Trust Exploitation",
    "ASI10": "Rogue Agents",
}

# LLM → ASI Mapping (same detection, dual tags)
# These are findings where the same code pattern indicates BOTH an LLM and ASI risk
LLM_TO_ASI_MAPPING = {
    "LLM01": ["ASI01", "ASI06"],  # Prompt injection → Goal hijack, Memory poison
    "LLM03": ["ASI04"],  # Supply chain → Supply chain
    "LLM05": ["ASI04", "ASI05"],  # Output handling → Supply chain, Code exec
    "LLM06": [
        "ASI02",
        "ASI03",
        "ASI05",
        "ASI09",
    ],  # Excessive agency → Tool misuse, Privilege, Code exec, Trust
    "LLM09": ["ASI09"],  # Overreliance → Trust exploitation
    "LLM10": ["ASI08"],  # Unbounded → Cascading failures
}

# ASI categories that have NO LLM equivalent (truly new agentic risks)
ASI_ONLY_CATEGORIES = ["ASI07", "ASI10"]

# LLM categories that are model-centric only (no agentic mapping)
LLM_ONLY_CATEGORIES = ["LLM02", "LLM04", "LLM07", "LLM08"]

# Policy ID to OWASP LLM mapping
POLICY_TO_OWASP_LLM = {
    "AI-001": "LLM01",  # Direct prompt injection
    "AI-002": "LLM01",  # Indirect injection (RAG)
    "AI-003": "LLM02",  # Sensitive data disclosure
    "AI-004": "LLM03",  # AI supply chain
    "AI-005": "LLM05",  # Improper output handling
    "AI-006": "LLM06",  # Excessive agency
    "AI-007": "LLM07",  # System prompt leakage
    "AI-008": "LLM10",  # Unbounded consumption
    "AI-009": "LLM06",  # MCP tool security → Excessive Agency (unguarded tool calls)
    "AI-010": "LLM06",  # Model control bypass → Excessive Agency (missing controls)
}

# Rule ID pattern to policy mapping (for rules without explicit policy_id)
RULE_PATTERN_TO_POLICY = {
    "llm01": "AI-001",
    "llm02": "AI-003",
    "llm03": "AI-004",
    "llm05": "AI-005",
    "llm06": "AI-006",
    "llm07": "AI-007",
    "llm10": "AI-008",
    "prompt-injection": "AI-001",
    "prompt_injection": "AI-001",
    "sensitive": "AI-003",
    "disclosure": "AI-003",
    "supply-chain": "AI-004",
    "supply_chain": "AI-004",
    "output-handling": "AI-005",
    "output_handling": "AI-005",
    "excessive-agency": "AI-006",
    "excessive_agency": "AI-006",
    "mcp": "AI-009",
    "model-control": "AI-010",
    "model_control": "AI-010",
    "garak-dan": "AI-001",
    "garak-promptinject": "AI-001",
    "garak-encoding": "AI-001",
    "garak-knownbadsignatures": "AI-001",
    "garak-leakreplay": "AI-003",
    "garak-packagehallucination": "AI-004",
    "garak-xss": "AI-005",
    "garak-malwaregen": "AI-005",
    "garak-continuation": "AI-001",
    "garak-gcg": "AI-001",
    "garak-lmrc": "AI-001",
    "corpus-tensortrust": "AI-001",
    "corpus-jailbreakbench": "AI-001",
    "corpus-promptinject": "AI-001",
}


@dataclass
class AIFinding:
    """
    Represents an AI security finding.

    Findings are the output of AI security analysis, mapped to
    OWASP LLM Top 10 categories and REACHABLE policy IDs.
    """

    # Identity
    rule_id: str
    message: str

    # Location
    file_path: str
    line_start: int
    line_end: int = 0
    column_start: int = 0
    column_end: int = 0

    # Severity: INFO, WARNING, ERROR
    severity: str = "WARNING"

    # Policy mapping (AI-001 to AI-010)
    policy_id: Optional[str] = None

    # OWASP LLM mapping
    owasp_category: Optional[str] = None  # e.g., "LLM01", "LLM05"
    owasp_name: Optional[str] = None  # e.g., "Prompt Injection"

    # Agentic Security Index (ASI) mapping - dual tags
    agentic_categories: list[str] = field(default_factory=list)  # e.g., ["ASI01", "ASI06"]
    is_agentic_context: bool = False  # True if agentic patterns detected in codebase

    # Primitive type
    primitive: Optional[str] = None

    # Framework/provider
    framework: Optional[str] = None
    provider: Optional[str] = None

    # Code context
    code_snippet: Optional[str] = None

    # Reachability
    is_reachable: bool = False
    call_path: list[str] = field(default_factory=list)
    call_paths_v2: list = field(default_factory=list)  # T-AI9: List[PathNode] — typed call path

    # Guards detected on path (reduce risk)
    guards: list[str] = field(default_factory=list)
    guard_risk_reduction: float = 0.0

    # Risk scoring
    base_risk_score: float = 5.0
    adjusted_risk_score: float = 5.0  # After guard reduction

    # Additional metadata
    metadata: dict = field(default_factory=dict)

    # Detection source
    detection_source: str = "semgrep"  # semgrep, treesitter, taint
    source_type: Optional[str] = None  # custom, garak, corpus

    # Timestamps
    detected_at: datetime = field(default_factory=datetime.now)

    # Remediation
    fix_suggestion: Optional[str] = None
    references: list[str] = field(default_factory=list)

    @property
    def location(self) -> str:
        """Human-readable location string."""
        return f"{self.file_path}:{self.line_start}"

    @property
    def is_critical(self) -> bool:
        """True if this is a critical finding (high risk, no guards)."""
        return self.severity == "ERROR" and self.adjusted_risk_score >= 8.0 and len(self.guards) == 0

    @property
    def severity_icon(self) -> str:
        """Emoji icon for severity."""
        icons = {
            "ERROR": "",
            "WARNING": "",
            "INFO": "",
        }
        return icons.get(self.severity.upper(), "")

    @property
    def display_category(self) -> str:
        """Display string for OWASP category."""
        if self.owasp_category and self.owasp_name:
            return f"{self.owasp_category}: {self.owasp_name}"
        elif self.owasp_category:
            return self.owasp_category
        elif self.policy_id:
            return self.policy_id
        return "AI Security"

    def calculate_adjusted_risk(self) -> float:
        """Calculate risk score adjusted for guards."""
        if not self.guards:
            self.adjusted_risk_score = self.base_risk_score
        else:
            # Each guard reduces risk
            reduction = min(0.9, self.guard_risk_reduction)  # Cap at 90% reduction
            self.adjusted_risk_score = self.base_risk_score * (1 - reduction)
        return self.adjusted_risk_score

    def apply_agentic_tags(self, is_agentic_context: bool = True) -> None:
        """
        Apply ASI tags based on LLM category (dual-tagging).

        Same detection pattern can indicate both LLM and ASI risks.
        Only applies if agentic context is detected in the codebase.
        """
        self.is_agentic_context = is_agentic_context

        if not is_agentic_context:
            return

        if self.owasp_category and self.owasp_category in LLM_TO_ASI_MAPPING:
            self.agentic_categories = LLM_TO_ASI_MAPPING[self.owasp_category].copy()

    def to_dict(self) -> dict:
        """Convert to dictionary for JSON serialization."""
        return {
            "rule_id": self.rule_id,
            "message": self.message,
            "file_path": self.file_path,
            "line_start": self.line_start,
            "line_end": self.line_end,
            "column_start": self.column_start,
            "column_end": self.column_end,
            "severity": self.severity,
            "policy_id": self.policy_id,
            "owasp_category": self.owasp_category,
            "owasp_name": self.owasp_name,
            "agentic_categories": self.agentic_categories,
            "is_agentic_context": self.is_agentic_context,
            "primitive": self.primitive,
            "framework": self.framework,
            "provider": self.provider,
            "code_snippet": self.code_snippet,
            "is_reachable": self.is_reachable,
            "call_paths_v2": self.call_paths_v2,
            "guards": self.guards,
            "guard_risk_reduction": self.guard_risk_reduction,
            "base_risk_score": self.base_risk_score,
            "adjusted_risk_score": self.adjusted_risk_score,
            "metadata": self.metadata,
            "detection_source": self.detection_source,
            "source_type": self.source_type,
            "detected_at": self.detected_at.isoformat(),
            "fix_suggestion": self.fix_suggestion,
            "references": self.references,
        }

    @classmethod
    def from_dict(cls, data: dict) -> "AIFinding":
        """Create from dictionary."""
        data = data.copy()
        if "detected_at" in data and isinstance(data["detected_at"], str):
            data["detected_at"] = datetime.fromisoformat(data["detected_at"])
        return cls(**data)

    @classmethod
    def from_semgrep(cls, result: dict) -> "AIFinding":
        """
        Create AIFinding from Semgrep result.

        Args:
            result: A single result from Semgrep JSON output.
        """
        # Extract metadata
        extra = result.get("extra", {})
        metadata = extra.get("metadata", {})

        # Get rule ID
        rule_id = result.get("check_id", "unknown")

        # Map severity
        semgrep_severity = extra.get("severity", "WARNING")
        severity_map = {
            "ERROR": "ERROR",
            "WARNING": "WARNING",
            "INFO": "INFO",
        }
        severity = severity_map.get(semgrep_severity.upper(), "WARNING")

        # Extract policy_id (try multiple keys)
        policy_id = metadata.get("policy_id") or metadata.get("policyId") or cls._infer_policy_from_rule_id(rule_id)

        # Extract OWASP LLM category (try multiple keys)
        owasp = (
            metadata.get("owasp_llm")  # Our new standard
            or metadata.get("owasp")  # Legacy
            or metadata.get("owaspLlm")  # Alternative
            or cls._infer_owasp_from_policy(policy_id)
            or cls._infer_owasp_from_rule_id(rule_id)
        )

        owasp_name = OWASP_LLM_NAMES.get(owasp)

        # Extract source type (custom, garak, corpus)
        source_type = metadata.get("source", "custom")

        # Calculate base risk score from severity and category
        severity_scores = {"ERROR": 8.0, "WARNING": 5.0, "INFO": 2.0}
        base_score = severity_scores.get(severity, 5.0)

        # Critical policies get higher scores
        critical_policies = {"AI-001", "AI-005", "AI-006", "AI-009"}
        if policy_id in critical_policies:
            base_score = min(10.0, base_score + 2.0)

        return cls(
            rule_id=rule_id,
            message=extra.get("message", "AI security finding"),
            file_path=result.get("path", ""),
            line_start=result.get("start", {}).get("line", 0),
            line_end=result.get("end", {}).get("line", 0),
            column_start=result.get("start", {}).get("col", 0),
            column_end=result.get("end", {}).get("col", 0),
            severity=severity,
            policy_id=policy_id,
            owasp_category=owasp,
            owasp_name=owasp_name,
            primitive=metadata.get("primitive"),
            framework=metadata.get("framework"),
            provider=metadata.get("provider"),
            code_snippet=extra.get("lines", ""),
            metadata=metadata,
            detection_source="semgrep",
            source_type=source_type,
            base_risk_score=base_score,
            adjusted_risk_score=base_score,
            references=metadata.get("references", []),
        )

    @classmethod
    def _infer_policy_from_rule_id(cls, rule_id: str) -> Optional[str]:
        """Infer policy ID from rule ID patterns."""
        rule_lower = rule_id.lower()
        for pattern, policy in RULE_PATTERN_TO_POLICY.items():
            if pattern in rule_lower:
                return policy
        return "AI-001"  # Default to prompt injection

    @classmethod
    def _infer_owasp_from_policy(cls, policy_id: Optional[str]) -> Optional[str]:
        """Get OWASP LLM category from policy ID."""
        if policy_id:
            return POLICY_TO_OWASP_LLM.get(policy_id)
        return None

    @classmethod
    def _infer_owasp_from_rule_id(cls, rule_id: str) -> Optional[str]:
        """Infer OWASP LLM category from rule ID patterns."""
        rule_lower = rule_id.lower()

        # Direct LLM category patterns
        for i in range(1, 11):
            pattern = f"llm{i:02d}" if i < 10 else f"llm{i}"
            if pattern in rule_lower:
                return f"LLM{i:02d}"

        # Indirect patterns
        if "prompt" in rule_lower and "inject" in rule_lower:
            return "LLM01"
        if "sensitive" in rule_lower or "disclosure" in rule_lower:
            return "LLM02"
        if "supply" in rule_lower and "chain" in rule_lower:
            return "LLM03"
        if "output" in rule_lower:
            return "LLM05"
        if "agency" in rule_lower or "tool" in rule_lower:
            return "LLM06"
        if "leak" in rule_lower:
            return "LLM07"

        return None
