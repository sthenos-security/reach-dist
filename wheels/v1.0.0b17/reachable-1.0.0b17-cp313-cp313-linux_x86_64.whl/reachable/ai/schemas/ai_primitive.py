# REACHABLE AI Security Module - AI Primitive Schema
# Copyright (c) 2026 Sthenos Security. All rights reserved.

"""
AI Primitive data model.

Primitives are the building blocks of AI security analysis:
- ENTRYPOINT: External access points (HTTP, WebSocket, MCP)
- SOURCE: Untrusted input origins
- PROMPT_SINK: Model invocation points
- PROMPT_CONSTRUCTION: String interpolation into prompts
- TOOL_DEFINITION: Capabilities exposed to models
- TOOL_ROUTER: Logic dispatching tool calls
- MCP_SERVER: MCP server definitions
- MCP_TOOL: MCP-exposed tools
- DANGEROUS_EXEC: Code execution primitives
- DANGEROUS_FS_WRITE: Filesystem write operations
- DANGEROUS_EGRESS: Outbound network calls
- GUARD: Security controls (validation, allowlist)
- RAG_RETRIEVAL: Document/vector retrieval
- EMBEDDING_CALL: Embedding generation
- OUTPUT_RENDERER: LLM output display/execution
"""

from dataclasses import dataclass, field
from enum import Enum, auto
from typing import Optional


class PrimitiveType(Enum):
    """Categories of AI primitives."""

    # Entry points
    ENTRYPOINT = auto()

    # Data flow
    SOURCE = auto()
    PROMPT_SINK = auto()
    PROMPT_CONSTRUCTION = auto()
    OUTPUT_RENDERER = auto()

    # Tool/capability
    TOOL_DEFINITION = auto()
    TOOL_ROUTER = auto()

    # MCP specific
    MCP_SERVER = auto()
    MCP_TOOL = auto()
    MCP_RESOURCE = auto()
    MCP_CLIENT = auto()

    # Dangerous operations
    DANGEROUS_EXEC = auto()
    DANGEROUS_FS_WRITE = auto()
    DANGEROUS_FS_READ = auto()
    DANGEROUS_EGRESS = auto()
    DANGEROUS_DB_WRITE = auto()

    # RAG/Embedding
    RAG_RETRIEVAL = auto()
    EMBEDDING_CALL = auto()
    VECTOR_STORE_WRITE = auto()

    # Guards (risk reduction)
    GUARD = auto()
    GUARD_INPUT_VALIDATION = auto()
    GUARD_OUTPUT_SANITIZATION = auto()
    GUARD_INJECTION_DETECTION = auto()
    GUARD_TOOL_ALLOWLIST = auto()
    GUARD_HITL = auto()  # Human-in-the-loop


@dataclass
class AIPrimitive:
    """
    Represents a detected AI primitive in source code.

    Primitives are the nodes in the AI reachability graph.
    """

    # Identity
    type: PrimitiveType
    name: str  # Function/variable/decorator name

    # Location
    file_path: str
    line_number: int
    column: int = 0
    end_line: Optional[int] = None
    end_column: Optional[int] = None

    # Code snippet
    code_snippet: Optional[str] = None

    # Framework/provider (e.g., "openai", "langchain", "mcp")
    framework: Optional[str] = None
    provider: Optional[str] = None

    # Additional metadata
    metadata: dict = field(default_factory=dict)

    # Risk attributes
    is_public: bool = False  # True if externally accessible
    is_authenticated: bool = True  # False if no auth required

    # For guards: how much they reduce risk
    risk_reduction: float = 0.0  # 0.0-1.0

    @property
    def location(self) -> str:
        """Human-readable location string."""
        return f"{self.file_path}:{self.line_number}"

    @property
    def is_dangerous(self) -> bool:
        """True if this primitive represents a dangerous operation."""
        dangerous_types = {
            PrimitiveType.DANGEROUS_EXEC,
            PrimitiveType.DANGEROUS_FS_WRITE,
            PrimitiveType.DANGEROUS_EGRESS,
            PrimitiveType.DANGEROUS_DB_WRITE,
        }
        return self.type in dangerous_types

    @property
    def is_guard(self) -> bool:
        """True if this primitive is a security control."""
        return self.type in {
            PrimitiveType.GUARD,
            PrimitiveType.GUARD_INPUT_VALIDATION,
            PrimitiveType.GUARD_OUTPUT_SANITIZATION,
            PrimitiveType.GUARD_INJECTION_DETECTION,
            PrimitiveType.GUARD_TOOL_ALLOWLIST,
            PrimitiveType.GUARD_HITL,
        }

    @property
    def is_mcp(self) -> bool:
        """True if this is an MCP-related primitive."""
        return self.type in {
            PrimitiveType.MCP_SERVER,
            PrimitiveType.MCP_TOOL,
            PrimitiveType.MCP_RESOURCE,
            PrimitiveType.MCP_CLIENT,
        }

    def to_dict(self) -> dict:
        """Convert to dictionary for JSON serialization."""
        return {
            "type": self.type.name,
            "name": self.name,
            "file_path": self.file_path,
            "line_number": self.line_number,
            "column": self.column,
            "end_line": self.end_line,
            "end_column": self.end_column,
            "code_snippet": self.code_snippet,
            "framework": self.framework,
            "provider": self.provider,
            "metadata": self.metadata,
            "is_public": self.is_public,
            "is_authenticated": self.is_authenticated,
            "risk_reduction": self.risk_reduction,
        }

    @classmethod
    def from_dict(cls, data: dict) -> "AIPrimitive":
        """Create from dictionary."""
        data = data.copy()
        data["type"] = PrimitiveType[data["type"]]
        return cls(**data)
