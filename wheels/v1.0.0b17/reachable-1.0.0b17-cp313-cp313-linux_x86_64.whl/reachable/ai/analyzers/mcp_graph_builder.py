#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.
"""
T-AI7: MCP Server Graph Builder
================================

Scans Python source files for MCP server tool registrations
(@server.tool(), FastMCP, mcp.server decorators) and builds a graph of:

  - MCPToolNode   — individual tool with capabilities, input validation,
                    and danger classification
  - MCPServerGraph — collection of tools from one file / server instance

Capabilities are classified using the same patterns as ToolCapabilityMapper
(T-AI6), with additional MCP-specific checks:

  - Input validation: Pydantic BaseModel parameter type annotation
  - Dangerous: EXEC capability present OR WRITE + no input validation

OWASP LLM mapping: LLM06 (Excessive Agency), LLM07 (System Prompt Leakage)
NodeKind: SINK_DANGER for dangerous tools, MCP_TOOL for safe ones

Design reference: docs/engineering/design/callgraph_engine_v2.md § 3.5
"""

from __future__ import annotations

import logging
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import List, Optional, Set

from reachable.ai.analyzers.tool_capability_mapper import (
    _APPROVAL_PATTERNS,
    _CAPABILITY_PATTERNS,
    ToolCapabilityMapper,
    _derive_risk,
)

logger = logging.getLogger(__name__)


# ════════════════════════════════════════════════════════════════════════════
# MCP-specific patterns
# ════════════════════════════════════════════════════════════════════════════

# MCP server / tool decorator patterns
_MCP_TOOL_PATTERNS = re.compile(
    r"@server\.tool\s*\(\s*\)|" r"@mcp\.tool\s*\(\s*\)|" r"@app\.tool\s*\(\s*\)|" r"FastMCP\b|" r"mcp\.server\.",
    re.I,
)

_MCP_TOOL_DECORATOR = re.compile(
    r"@\w+\.tool\s*\(\s*\)",
    re.I,
)

# Pydantic model usage — parameter type hint or explicit BaseModel subclass
_PYDANTIC_PATTERNS = re.compile(
    r"\bBaseModel\b|\bpydantic\b|\bField\s*\(|\bfield_validator\b|"
    r":\s*\w+Model\b|:\s*\w+Input\b|:\s*\w+Params\b|:\s*\w+Schema\b",
    re.I,
)

# Function definition
_FUNC_DEF = re.compile(r"^\s*(?:async\s+)?def\s+(\w+)\s*\(")


# ════════════════════════════════════════════════════════════════════════════
# Data classes
# ════════════════════════════════════════════════════════════════════════════


@dataclass
class MCPToolNode:
    """
    A single MCP tool registration.

    Attributes
    ----------
    name                Tool function name.
    file_path           Source file.
    line_start          Decorator line (1-indexed).
    capabilities        EXEC | WRITE | EGRESS | READ | MEMORY.
    has_input_validation  True if Pydantic BaseModel detected in signature/body.
    has_human_approval  True if confirm() / await_approval() detected.
    is_dangerous        True if EXEC present or WRITE with no input validation.
    risk_level          CRITICAL | HIGH | MEDIUM | LOW.
    owasp_llm           LLM06 for all MCP tool findings.
    body_lines          Raw source of the tool body.
    """

    name: str
    file_path: str
    line_start: int
    capabilities: Set[str] = field(default_factory=set)
    has_input_validation: bool = False
    has_human_approval: bool = False
    is_dangerous: bool = False
    risk_level: str = "INFO"
    owasp_llm: str = "LLM06"
    body_lines: List[str] = field(default_factory=list)

    def __post_init__(self):
        self.risk_level = _derive_risk(self.capabilities, self.has_human_approval)
        self.is_dangerous = "EXEC" in self.capabilities or (
            "WRITE" in self.capabilities and not self.has_input_validation
        )


@dataclass
class MCPServerGraph:
    """
    All MCP tools found in one source file.

    Attributes
    ----------
    file_path       Analyzed source file.
    server_name     Name passed to FastMCP() if found, else ''.
    tools           All MCPToolNode objects found.
    """

    file_path: str
    server_name: str = ""
    tools: List[MCPToolNode] = field(default_factory=list)

    @property
    def dangerous_tools(self) -> List[MCPToolNode]:
        return [t for t in self.tools if t.is_dangerous]

    @property
    def unvalidated_tools(self) -> List[MCPToolNode]:
        return [t for t in self.tools if not t.has_input_validation]


# ════════════════════════════════════════════════════════════════════════════
# MCPGraphBuilder
# ════════════════════════════════════════════════════════════════════════════


class MCPGraphBuilder:
    """
    T-AI7: Extract MCP tool registrations from source files and build a
    capability graph.

    Usage::

        builder = MCPGraphBuilder()
        graph = builder.analyze_file(Path("server.py"))
        for tool in graph.dangerous_tools:
            print(tool.name, tool.capabilities)
    """

    # Reuse ToolCapabilityMapper's body extractor
    _mapper = ToolCapabilityMapper()

    def analyze_file(self, file_path: Path) -> MCPServerGraph:
        """Analyze a single file and return an MCPServerGraph."""
        graph = MCPServerGraph(file_path=str(file_path))

        try:
            content = file_path.read_text(encoding="utf-8", errors="ignore")
            lines = content.split("\n")
        except Exception as e:
            logger.debug(f"MCPGraphBuilder: cannot read {file_path}: {e}")
            return graph

        # Extract server name from FastMCP('name') if present
        m = re.search(r'FastMCP\s*\(\s*[\'"]([^\'"]+)[\'"]', content)
        if m:
            graph.server_name = m.group(1)

        # Check for Pydantic usage at file level (any BaseModel subclass)
        file_has_pydantic = bool(_PYDANTIC_PATTERNS.search(content))

        n = len(lines)
        i = 0
        while i < n:
            line = lines[i]

            if not _MCP_TOOL_DECORATOR.search(line):
                i += 1
                continue

            decorator_line = i + 1  # 1-indexed

            # Find function definition in next 5 lines
            func_name = "<anonymous>"
            body_start = i + 1
            for j in range(i + 1, min(i + 6, n)):
                m2 = _FUNC_DEF.search(lines[j])
                if m2:
                    func_name = m2.group(1)
                    body_start = j + 1
                    break

            # Extract body
            body_lines = self._mapper._extract_body(lines, body_start, is_ts=False, max_lines=50)
            body_text = "\n".join(body_lines)

            # Collect signature line(s) for Pydantic param check
            sig_text = "\n".join(lines[max(0, body_start - 2) : body_start])

            # Capabilities
            caps: Set[str] = set()
            for pattern, tag in _CAPABILITY_PATTERNS:
                if pattern.search(body_text):
                    caps.add(tag)

            # Input validation: Pydantic in signature OR body OR file level
            has_validation = (
                bool(_PYDANTIC_PATTERNS.search(sig_text))
                or bool(_PYDANTIC_PATTERNS.search(body_text))
                or file_has_pydantic
            )

            has_approval = bool(_APPROVAL_PATTERNS.search(body_text))

            tool = MCPToolNode(
                name=func_name,
                file_path=str(file_path),
                line_start=decorator_line,
                capabilities=caps,
                has_input_validation=has_validation,
                has_human_approval=has_approval,
                body_lines=body_lines,
            )
            graph.tools.append(tool)
            logger.debug(
                f"T-AI7 MCP tool: {func_name} caps={caps} "
                f"dangerous={tool.is_dangerous} validation={has_validation} "
                f"({file_path}:{decorator_line})"
            )

            i = body_start + len(body_lines)

        return graph

    def analyze_directory(
        self,
        dir_path: Path,
        extensions: Optional[List[str]] = None,
    ) -> List[MCPServerGraph]:
        """Analyze all Python files under dir_path."""
        if extensions is None:
            extensions = [".py"]

        graphs: List[MCPServerGraph] = []
        for ext in extensions:
            for fp in dir_path.rglob(f"*{ext}"):
                path_str = str(fp)
                if any(
                    skip in path_str
                    for skip in [
                        ".venv",
                        "node_modules",
                        "__pycache__",
                        ".git",
                        "dist",
                        "build",
                    ]
                ):
                    continue
                graph = self.analyze_file(fp)
                if graph.tools:
                    graphs.append(graph)
        return graphs
