#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.
"""
T-AI6: Tool Capability Mapper
=============================

Scans Python and TypeScript source files for LLM tool definitions
(@tool, StructuredTool, AgentExecutor, FastMCP @server.tool, etc.),
extracts each tool's function body, and classifies its capabilities:

  EXEC   -- executes OS commands or arbitrary code (subprocess, os.system, eval)
  WRITE  -- writes files, databases, or sends network mutations (POST/PUT/DELETE)
  EGRESS -- exfiltrates data to external endpoints (requests.get/post, http.client)
  READ   -- reads files, databases, or external data sources
  MEMORY -- reads/writes agent memory stores

Risk levels are derived from capability combinations:
  CRITICAL -- EXEC present
  HIGH     -- WRITE + EGRESS, or WRITE alone
  MEDIUM   -- READ + EGRESS, or EGRESS alone
  LOW      -- READ only

For each tool, the mapper also checks for human-approval guards
(confirm(), await_approval(), interrupt_before, etc.) which reduce the
effective risk level by one tier for LLM06 scoring.

T-AI11: Also detects multi-hop agentic tool chains:
  - LangChain SequentialChain(chains=[a, b, c])
  - LangGraph graph.add_edge("node_a", "node_b")
  - CrewAI Task(depends_on=[prev_task])
  - Pipe operator: tool_a | tool_b | tool_c

Design reference: docs/engineering/design/callgraph_engine_v2.md sec 3.5
OWASP LLM mapping: LLM06 (Excessive Agency), LLM07 (System Prompt Leakage)
"""

from __future__ import annotations

import logging
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Optional, Set

logger = logging.getLogger(__name__)


# ============================================================================
# Capability patterns
# ============================================================================

# Each entry: (regex, capability_tag)
_CAPABILITY_PATTERNS: List[tuple] = [
    # EXEC -- OS command execution, code evaluation
    (
        re.compile(
            r"\bsubprocess\b|\bos\.system\b|\bos\.popen\b|\bexecSync\b|" r"\bchild_process\b|\bshell=True\b",
            re.I,
        ),
        "EXEC",
    ),
    (
        re.compile(
            r"\beval\s*\(|\bexec\s*\(|\bcompile\s*\(|" r"PythonREPL|RestrictedPython|vm\.runIn",
            re.I,
        ),
        "EXEC",
    ),
    # WRITE -- file writes, DB mutations, outbound state-change requests
    (
        re.compile(
            r'\bopen\s*\([^)]+["\']w["\']|\bwritelines?\s*\(|' r"\bshutil\.copy\b|\bshutil\.move\b|\.write\s*\(",
            re.I,
        ),
        "WRITE",
    ),
    (
        re.compile(
            r"\bcursor\.execute\b|\bsession\.add\b|\bdb\.commit\b|" r"\.insert\s*\(|\.update\s*\(|\.delete\s*\(",
            re.I,
        ),
        "WRITE",
    ),
    (
        re.compile(
            r"requests\.(post|put|patch|delete)\b|"
            r"httpx\.(post|put|patch|delete)\b|"
            r"axios\.(post|put|patch|delete)\b|"
            r"fetch\s*\([^,]+,\s*\{.*method.*(?:POST|PUT|DELETE)",
            re.I | re.S,
        ),
        "WRITE",
    ),
    (
        re.compile(
            r"smtp\.send\b|sendmail\b|send_message\b|" r"boto3.*send\b|sns\.publish\b",
            re.I,
        ),
        "EGRESS",
    ),
    # EGRESS -- outbound reads / data exfiltration
    (
        re.compile(
            r"requests\.(get|head)\b|httpx\.(get|head)\b|"
            r"urllib\.request\b|http\.client\b|"
            r"axios\.(get|head)\b|fetch\s*\(",
            re.I,
        ),
        "EGRESS",
    ),
    # READ -- file reads, DB queries
    (
        re.compile(
            r'\bopen\s*\([^)]+["\']r["\']|\bread_text\b|' r"\.read\s*\(|\bread_csv\b|\bread_json\b",
            re.I,
        ),
        "READ",
    ),
    (
        re.compile(
            r"\bcursor\.fetchall\b|\bcursor\.fetchone\b|" r"\.query\s*\(|SELECT\b",
            re.I,
        ),
        "READ",
    ),
    # MEMORY -- agent memory stores
    (
        re.compile(
            r"memory\.save\b|memory\.load\b|ConversationBuffer|" r"VectorStoreRetrieverMemory|ChatMessageHistory",
            re.I,
        ),
        "MEMORY",
    ),
]

# Human-approval guard patterns
_APPROVAL_PATTERNS = re.compile(
    r"\bconfirm\s*\(|\bawait_approval\s*\(|\bapproval\s*\(|"
    r"\bhuman_in_the_loop\b|\brequire_confirmation\b|"
    r"\binterrupt_before\b|\binterrupt_after\b",
    re.I,
)

# Tool decorator / registration patterns (Python)
_TOOL_DECORATOR_PY = re.compile(
    r"@tool\b|@mcp\.tool\b|@server\.tool\b|"
    r"StructuredTool\.from_function|Tool\.from_function|"
    r"FunctionTool\s*\(|tool_manager\.register",
    re.I,
)

# Tool decorator / registration patterns (JS/TS)
_TOOL_DECORATOR_JS = re.compile(
    r"tool\s*\(\s*\{|createTool\s*\(|defineTool\s*\(|" r"server\.tool\s*\(|registerTool\s*\(",
    re.I,
)

# Function definition line following a decorator
_FUNC_DEF_PY = re.compile(r"^\s*(?:async\s+)?def\s+(\w+)\s*\(")
_FUNC_DEF_JS = re.compile(
    r"^\s*(?:async\s+)?function\s+(\w+)\s*\(|" r"^\s*(?:const|let|var)\s+(\w+)\s*=\s*(?:async\s*)?\("
)

# Risk level ordering for reduction
_RISK_ORDER = ["CRITICAL", "HIGH", "MEDIUM", "LOW", "INFO"]

# Identifier-only token pattern (reused in chain detection)
_IDENT_RE = re.compile(r"^[\w]+$")


def _classify_capabilities(text: str) -> Set[str]:
    """Classify capabilities from arbitrary text (used for unknown chain terminals)."""
    caps: Set[str] = set()
    for pattern, tag in _CAPABILITY_PATTERNS:
        if pattern.search(text):
            caps.add(tag)
    return caps


# ============================================================================
# Data classes
# ============================================================================


@dataclass
class ToolDefinition:
    """
    A single LLM tool definition found in source code.

    Attributes
    ----------
    name             Function/tool name (from def statement or registration call).
    file_path        Source file containing this tool.
    line_start       Line number of the decorator or registration.
    capabilities     Set of capability tags: EXEC | WRITE | EGRESS | READ | MEMORY.
    has_human_approval  True if a human-approval guard was detected in the body.
    risk_level       Derived from capabilities: CRITICAL | HIGH | MEDIUM | LOW.
    owasp_llm        Primary OWASP LLM category (always LLM06 for tool findings).
    body_lines       Raw source lines of the tool body (for evidence).
    """

    name: str
    file_path: str
    line_start: int
    capabilities: Set[str] = field(default_factory=set)
    has_human_approval: bool = False
    risk_level: str = "INFO"
    owasp_llm: str = "LLM06"
    body_lines: List[str] = field(default_factory=list)

    def __post_init__(self):
        self.risk_level = _derive_risk(self.capabilities, self.has_human_approval)


@dataclass
class AgentChain:
    """
    T-AI11: A detected multi-hop agentic tool chain.

    Represents a sequence of tools where the output of one feeds the input
    of the next (SequentialChain, LangGraph edges, CrewAI task deps, pipe).

    Attributes
    ----------
    hops                   Ordered list of tool/function names in the chain.
    terminal_capabilities  Capabilities of the final tool in the chain.
    chain_type             'sequential_chain' | 'langgraph' | 'crewai' | 'pipe_operator'
    file_path              Source file where the chain was found.
    line_start             Line number of the chain definition.
    """

    hops: List[str] = field(default_factory=list)
    terminal_capabilities: Set[str] = field(default_factory=set)
    chain_type: str = "sequential_chain"
    file_path: str = ""
    line_start: int = 0


@dataclass
class ToolCapabilityReport:
    """
    Result of analyzing one source file for tool definitions.

    Attributes
    ----------
    file_path   Source file analyzed.
    tools       All tool definitions found.
    chains      T-AI11: Multi-hop agentic tool chains detected.
    """

    file_path: str
    tools: List[ToolDefinition] = field(default_factory=list)
    chains: List[AgentChain] = field(default_factory=list)  # T-AI11

    @property
    def critical_tools(self) -> List[ToolDefinition]:
        return [t for t in self.tools if t.risk_level == "CRITICAL"]

    @property
    def high_risk_tools(self) -> List[ToolDefinition]:
        return [t for t in self.tools if t.risk_level in ("CRITICAL", "HIGH")]

    @property
    def unguarded_high_risk(self) -> List[ToolDefinition]:
        return [t for t in self.high_risk_tools if not t.has_human_approval]


# ============================================================================
# Risk derivation
# ============================================================================


def _derive_risk(capabilities: Set[str], has_approval: bool) -> str:
    """
    Derive risk level from capability set.

    EXEC present                    -> CRITICAL (reduced to HIGH if approved)
    WRITE + EGRESS, or WRITE alone  -> HIGH     (reduced to MEDIUM if approved)
    EGRESS alone, or READ + EGRESS  -> MEDIUM
    READ only, or MEMORY            -> LOW
    """
    if "EXEC" in capabilities:
        base = "CRITICAL"
    elif "WRITE" in capabilities:
        base = "HIGH"
    elif "EGRESS" in capabilities:
        base = "MEDIUM"
    elif capabilities:
        base = "LOW"
    else:
        base = "INFO"

    if has_approval and base in _RISK_ORDER:
        idx = _RISK_ORDER.index(base)
        base = _RISK_ORDER[min(idx + 1, len(_RISK_ORDER) - 1)]

    return base


# ============================================================================
# ToolCapabilityMapper
# ============================================================================


class ToolCapabilityMapper:
    """
    T-AI6: Scan source files for LLM tool definitions and classify capabilities.
    T-AI11: Also detects multi-hop agentic tool chains.

    Usage::

        mapper = ToolCapabilityMapper()
        report = mapper.analyze_file(Path("tools.py"))
        for tool in report.tools:
            print(tool.name, tool.capabilities, tool.risk_level)
        for chain in report.chains:
            print(chain.hops, chain.terminal_capabilities)
    """

    def analyze_file(self, file_path: Path) -> ToolCapabilityReport:
        """Analyze a single file and return a ToolCapabilityReport."""
        report = ToolCapabilityReport(file_path=str(file_path))

        try:
            content = file_path.read_text(encoding="utf-8", errors="ignore")
            lines = content.split("\n")
        except Exception as e:
            logger.debug(f"ToolCapabilityMapper: cannot read {file_path}: {e}")
            return report

        is_ts = file_path.suffix.lower() in (".ts", ".js", ".tsx", ".jsx")
        report.tools = self._extract_tools(lines, str(file_path), is_ts)
        # T-AI11: detect multi-hop agentic chains
        report.chains = self._detect_chains(lines, report.tools, str(file_path))
        return report

    def analyze_directory(
        self,
        dir_path: Path,
        extensions: Optional[List[str]] = None,
    ) -> List[ToolCapabilityReport]:
        """Analyze all matching files under dir_path."""
        if extensions is None:
            extensions = [".py", ".ts", ".js", ".tsx", ".jsx"]

        reports: List[ToolCapabilityReport] = []
        for ext in extensions:
            for fp in dir_path.rglob(f"*{ext}"):
                path_str = str(fp)
                if any(
                    skip in path_str
                    for skip in [
                        ".venv",
                        "node_modules",
                        "__pycache__",
                        ".git",
                        "dist",
                        "build",
                    ]
                ):
                    continue
                report = self.analyze_file(fp)
                if report.tools:
                    reports.append(report)
        return reports

    # -------------------------------------------------------------------------
    # Internal helpers
    # -------------------------------------------------------------------------

    def _extract_tools(
        self,
        lines: List[str],
        file_path: str,
        is_ts: bool,
    ) -> List[ToolDefinition]:
        """
        Extract tool definitions by scanning for decorator/registration lines,
        then parsing the body that follows each one.
        """
        tools: List[ToolDefinition] = []
        decorator_pattern = _TOOL_DECORATOR_JS if is_ts else _TOOL_DECORATOR_PY
        func_def_pattern = _FUNC_DEF_JS if is_ts else _FUNC_DEF_PY
        n = len(lines)

        i = 0
        while i < n:
            line = lines[i]

            if not decorator_pattern.search(line):
                i += 1
                continue

            decorator_line = i + 1  # 1-indexed

            # Find the function definition within the next 5 lines
            func_name = "<anonymous>"
            body_start = i + 1
            for j in range(i + 1, min(i + 6, n)):
                m = func_def_pattern.search(lines[j])
                if m:
                    func_name = next(g for g in m.groups() if g) if m.groups() else func_name
                    body_start = j + 1
                    break

            # Extract function body (indented block after def, max 50 lines)
            body_lines = self._extract_body(lines, body_start, is_ts, max_lines=50)

            # Classify capabilities
            body_text = "\n".join(body_lines)
            caps: Set[str] = set()
            for pattern, tag in _CAPABILITY_PATTERNS:
                if pattern.search(body_text):
                    caps.add(tag)

            # Check for human-approval guard
            has_approval = bool(_APPROVAL_PATTERNS.search(body_text))

            tool = ToolDefinition(
                name=func_name,
                file_path=file_path,
                line_start=decorator_line,
                capabilities=caps,
                has_human_approval=has_approval,
                body_lines=body_lines,
            )
            tools.append(tool)
            logger.debug(
                f"T-AI6 tool: {func_name} caps={caps} risk={tool.risk_level} "
                f"approval={has_approval} ({file_path}:{decorator_line})"
            )

            # Skip past this tool's body to avoid re-matching nested decorators
            i = body_start + len(body_lines)

        return tools

    def _extract_body(
        self,
        lines: List[str],
        start: int,
        is_ts: bool,
        max_lines: int = 50,
    ) -> List[str]:
        """
        Extract the indented body block starting at ``start``.

        For Python: collect lines more indented than the function def.
        For JS/TS:  collect until matching closing brace.
        """
        if start >= len(lines):
            return []

        body: List[str] = []

        if is_ts:
            depth = 0
            for i in range(start, min(start + max_lines, len(lines))):
                line = lines[i]
                depth += line.count("{") - line.count("}")
                body.append(line)
                if depth <= 0 and body:
                    break
        else:
            # Python: use indentation
            baseline_indent: Optional[int] = None
            for i in range(start, min(start + max_lines, len(lines))):
                line = lines[i]
                stripped = line.rstrip()
                if not stripped:
                    body.append(line)
                    continue
                indent = len(line) - len(line.lstrip())
                if baseline_indent is None:
                    baseline_indent = indent
                if indent < (baseline_indent or 0) and stripped:
                    break  # dedented past body
                body.append(line)

        return body

    # -------------------------------------------------------------------------
    # T-AI11: Multi-hop agentic chain detection
    # -------------------------------------------------------------------------

    _SEQUENTIAL_CHAIN_RE = re.compile(
        r"(?:Sequential|Simple(?:Sequential)?)Chain\s*\(" r"(?:[^)]*chains\s*=\s*\[([^\]]+)\])?",
        re.DOTALL,
    )
    _LANGGRAPH_EDGE_RE = re.compile(
        r'\.add_edge\s*\(\s*["\'](\w+)["\']\s*,\s*["\'](\w+)["\']\s*\)',
    )
    _CREWAI_DEPENDS_RE = re.compile(
        r"Task\s*\([^)]*depends_on\s*=\s*\[([^\]]+)\]",
        re.DOTALL,
    )

    def _detect_chains(
        self,
        lines: List[str],
        tools: List[ToolDefinition],
        file_path: str,
    ) -> List[AgentChain]:
        """
        T-AI11: Detect multi-hop agentic tool chains in source.

        Handles:
        - LangChain SequentialChain(chains=[a, b, c])
        - LangGraph graph.add_edge("node_a", "node_b")
        - CrewAI Task(depends_on=[prev_task])
        - Pipe operator: known_tool_a | known_tool_b
        """
        chains: List[AgentChain] = []
        tool_cap_map: Dict[str, Set[str]] = {t.name: t.capabilities for t in tools}
        content = "\n".join(lines)

        # ---- 1. SequentialChain --------------------------------------------
        for m in self._SEQUENTIAL_CHAIN_RE.finditer(content):
            if not m.group(1):
                continue
            raw = m.group(1)
            hops = [tok.strip().strip("\"'") for tok in re.split(r"[,\s]+", raw) if _IDENT_RE.match(tok.strip())]
            if len(hops) < 2:
                continue
            terminal_caps = tool_cap_map.get(hops[-1], set())
            if not terminal_caps:
                terminal_caps = _classify_capabilities(" ".join(hops))
            line_start = content[: m.start()].count("\n") + 1
            chains.append(
                AgentChain(
                    hops=hops,
                    terminal_capabilities=terminal_caps,
                    chain_type="sequential_chain",
                    file_path=file_path,
                    line_start=line_start,
                )
            )

        # ---- 2. LangGraph add_edge -----------------------------------------
        edges: List[tuple] = [(m.group(1), m.group(2)) for m in self._LANGGRAPH_EDGE_RE.finditer(content)]
        if edges:
            from_nodes = {e[0] for e in edges}
            to_nodes = {e[1] for e in edges}
            roots = from_nodes - to_nodes
            adj: Dict[str, List[str]] = {}
            for src, dst in edges:
                adj.setdefault(src, []).append(dst)
            for root in sorted(roots):
                path = [root]
                visited = {root}
                while path[-1] in adj:
                    nxt = adj[path[-1]][0]
                    if nxt in visited:
                        break
                    visited.add(nxt)
                    path.append(nxt)
                if len(path) >= 2:
                    terminal_caps = tool_cap_map.get(path[-1], set())
                    chains.append(
                        AgentChain(
                            hops=path,
                            terminal_capabilities=terminal_caps,
                            chain_type="langgraph",
                            file_path=file_path,
                            line_start=0,
                        )
                    )

        # ---- 3. CrewAI depends_on ------------------------------------------
        for m in self._CREWAI_DEPENDS_RE.finditer(content):
            raw = m.group(1)
            deps = [tok.strip().strip("\"'") for tok in re.split(r"[,\s]+", raw) if _IDENT_RE.match(tok.strip())]
            if not deps:
                continue
            # Find the task variable name just before this match
            context_before = content[: m.start()].rsplit("\n", 3)[-1]
            task_name_m = re.search(r"(\w+)\s*=\s*Task\s*\(", context_before)
            task_name = task_name_m.group(1) if task_name_m else "task"
            hops = deps + [task_name]
            terminal_caps = tool_cap_map.get(task_name, set())
            line_start = content[: m.start()].count("\n") + 1
            chains.append(
                AgentChain(
                    hops=hops,
                    terminal_capabilities=terminal_caps,
                    chain_type="crewai",
                    file_path=file_path,
                    line_start=line_start,
                )
            )

        # ---- 4. Pipe operator ----------------------------------------------
        known_names = set(tool_cap_map.keys())
        if len(known_names) >= 2:
            for line_num, line in enumerate(lines, 1):
                stripped = line.strip()
                if "|" not in stripped:
                    continue
                parts = [p.strip() for p in stripped.split("|")]
                known_parts = [p for p in parts if p in known_names]
                if len(known_parts) >= 2:
                    terminal_caps = tool_cap_map.get(parts[-1], set())
                    chains.append(
                        AgentChain(
                            hops=parts,
                            terminal_capabilities=terminal_caps,
                            chain_type="pipe_operator",
                            file_path=file_path,
                            line_start=line_num,
                        )
                    )

        return chains
