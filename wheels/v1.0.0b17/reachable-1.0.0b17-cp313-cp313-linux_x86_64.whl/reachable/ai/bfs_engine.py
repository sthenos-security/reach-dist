#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.
"""
T-AI5: Cross-file BFS taint engine for AI/LLM reachability.

Provides ``CrossFileBFSEngine`` — given the call graph adjacency dict produced
by the REACHABLE engine, performs:

  1. Reverse-BFS from a sink function back to the nearest HTTP entry point
     (LLM01 / prompt injection attack surface confirmation).
  2. Forward-BFS from LLM API calls outward to dangerous operations
     (LLM05 / improper output handling — LLM response → exec / eval).

Results are returned as lists of ``PathNode`` objects (typed semantic nodes
from ``hop_registry.py``) so they can be stored in ``call_paths_v2`` and
rendered by the dashboard v2 renderer.

Design reference: docs/engineering/design/callgraph_engine_v2.md § 3.5
Gap analysis:     docs/engineering/design/ai_security_module_design.md (Gap 1 / Gap 3)
"""

from __future__ import annotations

import logging
import re
from collections import deque
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Optional, Set, Tuple

from reachable.engine.hop_registry import HopPosition, NodeKind, PathNode, classify_hop

logger = logging.getLogger(__name__)


# ════════════════════════════════════════════════════════════════════════════
# Entry-point detection heuristics
# ════════════════════════════════════════════════════════════════════════════

# Used when walking callers mid-BFS — broader, since we have caller context
_ENTRY_PATTERNS = re.compile(
    r"(handler|endpoint|route|view|controller|action|"
    r"serve_http|handle_request|dispatch|process_request|"
    r"get|post|put|patch|delete|head|options|"
    r"main|run|start|execute|cli|command|"
    r"on_message|consume|worker|job|task|cron)",
    re.IGNORECASE,
)

# Used at init to heuristically detect entry points from call graph keys.
# Stricter than _ENTRY_PATTERNS — excludes "handler" (too common in services).
_STRICT_ENTRY_LOCAL = re.compile(
    r"^(endpoint|route|view|controller|action|serve_http|"
    r"handle_request|dispatch|process_request|"
    r"main|run|start|execute|cli|command|"
    r"on_message|consume|worker|job|task|cron)$",
    re.IGNORECASE,
)

# Prefix patterns that indicate HTTP/framework entry-point modules
_ENTRY_PREFIX_PATTERNS = re.compile(
    r"(routes\.|handlers\.|controllers\.|views\.|"
    r"api\.|endpoints\.|resources\.|"
    r"cmd\.|cli\.|jobs\.|tasks\.|workers\.)",
    re.IGNORECASE,
)


def _is_entry_point(func_name: str) -> bool:
    """
    Heuristic: is this function an HTTP/CLI/MQ entry point?

    Used only when walking callers mid-BFS where we already have evidence
    (a caller chain) that this function is being called from app code.
    At init time, use the stricter _STRICT_ENTRY_LOCAL check instead.
    """
    parts = func_name.split(".")
    local = parts[-1] if parts else func_name
    prefix = ".".join(parts[:-1]) + "." if len(parts) > 1 else ""
    return bool(_ENTRY_PATTERNS.search(local) or _ENTRY_PREFIX_PATTERNS.search(prefix))


def _is_entry_point_strict(func_name: str) -> bool:
    """
    Stricter entry-point check for init-time heuristic promotion.

    Only promotes a call-graph root if its local name is unambiguously
    HTTP/CLI/MQ (e.g. 'endpoint', 'view', 'main') OR its module prefix is
    a framework-style path (e.g. 'api.', 'routes.').

    Intentionally excludes 'handler' to avoid promoting internal service
    functions like chat_handler, error_handler as entry points.
    """
    parts = func_name.split(".")
    local = parts[-1] if parts else func_name
    prefix = ".".join(parts[:-1]) + "." if len(parts) > 1 else ""
    return bool(_STRICT_ENTRY_LOCAL.match(local) or _ENTRY_PREFIX_PATTERNS.search(prefix))


# ════════════════════════════════════════════════════════════════════════════
# LLM / dangerous-operation sink detection
# ════════════════════════════════════════════════════════════════════════════

_LLM_SINK_PATTERN = re.compile(
    r"openai|anthropic|langchain|llm|generateText|streamText|"
    r"chat\.completions|messages\.create|\.invoke\b|\.arun\b|"
    r"cohere|mistral|ollama|gemini|vertexai|huggingface",
    re.IGNORECASE,
)

_DANGER_SINK_PATTERN = re.compile(
    r"\beval\b|\bexec\b|\bexecSync\b|subprocess\.run|subprocess\.call|" r"os\.system|os\.popen|child_process",
    re.IGNORECASE,
)


def _is_llm_sink(func_name: str) -> bool:
    return bool(_LLM_SINK_PATTERN.search(func_name))


def _is_danger_sink(func_name: str) -> bool:
    return bool(_DANGER_SINK_PATTERN.search(func_name))


# ════════════════════════════════════════════════════════════════════════════
# BFS result
# ════════════════════════════════════════════════════════════════════════════


@dataclass
class BFSPath:
    """
    A call path found by cross-file BFS.

    Attributes
    ----------
    hops          Qualified function names from entry point → sink, inclusive.
    path_nodes    Same path as typed PathNode objects (for call_paths_v2).
    owasp_llm     Inferred OWASP LLM category for this path.
    finding_type  'AI' | 'DLP' (used for HCR display decisions).
    entry_point   The function at the start of the path (ENTRY node).
    sink          The function at the end of the path (SINK_DANGER).
    is_reachable  True if the BFS found a path from entry to sink.
    depth         Number of hops in the path.
    """

    hops: List[str] = field(default_factory=list)
    path_nodes: List[PathNode] = field(default_factory=list)
    owasp_llm: str = "LLM01"
    finding_type: str = "AI"
    entry_point: str = ""
    sink: str = ""
    is_reachable: bool = False
    depth: int = 0

    def __post_init__(self):
        self.depth = len(self.hops)


# ════════════════════════════════════════════════════════════════════════════
# Cross-file BFS engine
# ════════════════════════════════════════════════════════════════════════════


class CrossFileBFSEngine:
    """
    T-AI5: Cross-file BFS taint tracer for AI/LLM findings.

    Takes the call graph adjacency dict (``{caller: [callees]}``) produced by
    the REACHABLE engine and performs BFS to build full call paths.

    Two modes
    ---------
    backward_from_sink(sink_func)
        Walk callers backwards until an entry point is found.
        Used for LLM01 (prompt injection): HTTP input → prompt builder → LLM.

    forward_from_llm(llm_func)
        Walk callees forward until a dangerous operation is found.
        Used for LLM05 (improper output handling): LLM call → eval / exec.

    Parameters
    ----------
    call_graph          Adjacency dict ``{caller: [callees]}``.
    reachable_functions Set of functions reachable from any entry point.
    entrypoints         Known HTTP/CLI entry point function names.
    max_depth           BFS depth cap (default 10 — prevents combinatorial explosion).
    """

    def __init__(
        self,
        call_graph: Dict[str, List[str]],
        reachable_functions: Optional[Set[str]] = None,
        entrypoints: Optional[Set[str]] = None,
        max_depth: int = 10,
    ):
        self.call_graph = call_graph or {}
        self.reachable_functions = reachable_functions or set()
        self.entrypoints = entrypoints or set()
        self.max_depth = max_depth

        # Build reverse graph: callee → {callers}
        self._reverse: Dict[str, Set[str]] = {}
        for caller, callees in self.call_graph.items():
            for callee in callees:
                self._reverse.setdefault(callee, set()).add(caller)

        # Identify roots: call-graph keys that are never a callee
        all_callees: Set[str] = set(self._reverse.keys())

        # Build entry set from:
        #   (a) explicitly provided entrypoints
        #   (b) heuristic: call-graph ROOTS that pass the strict entry-point check
        #
        # "Root" means: the function appears as a caller but nothing calls IT.
        # This prevents internal service functions (e.g. chat_handler) from
        # being promoted to entry points just because the graph has no caller
        # for them in the test fixture — they must also pass the strict name check.
        self._entry_set: Set[str] = set(self.entrypoints)
        for func in self.call_graph:
            if func in all_callees:
                continue  # has at least one caller — not a root
            if _is_entry_point_strict(func):
                self._entry_set.add(func)

        logger.debug(f"CrossFileBFSEngine: {len(self.call_graph)} funcs, {len(self._entry_set)} entry points")

    # ── Public API ──────────────────────────────────────────────────────────

    def backward_from_sink(
        self,
        sink_func: str,
        finding_type: str = "AI",
        owasp_llm: str = "LLM01",
    ) -> List[BFSPath]:
        """
        BFS backward from ``sink_func`` to entry points.

        Returns all shortest paths (up to ``max_depth`` hops) that start at
        an entry point and end at ``sink_func``.  Each path is returned as a
        BFSPath with typed PathNode objects.

        If no entry point is reached, returns a single BFSPath with
        ``is_reachable=False`` and ``hops=[sink_func]``.
        """
        if not self.call_graph:
            return [
                BFSPath(
                    hops=[sink_func],
                    sink=sink_func,
                    is_reachable=False,
                    owasp_llm=owasp_llm,
                    finding_type=finding_type,
                )
            ]

        # BFS state: (current_func, path_so_far)
        queue: deque[Tuple[str, List[str]]] = deque([(sink_func, [sink_func])])
        visited: Set[str] = {sink_func}
        found_paths: List[List[str]] = []

        while queue:
            current, path = queue.popleft()
            if len(path) > self.max_depth:
                continue

            callers = self._reverse.get(current, set())

            if not callers:
                # Dead end — only accept if in the pre-built entry set.
                # Never re-run _is_entry_point() here: an internal dead-end
                # function (e.g. chat_handler with no callers in the fixture)
                # would otherwise be falsely promoted.
                if current in self._entry_set:
                    found_paths.append(list(reversed(path)))
                continue

            for caller in callers:
                if caller in visited:
                    continue
                new_path = path + [caller]
                visited.add(caller)

                if caller in self._entry_set or _is_entry_point(caller):
                    # Found an entry point — record path reversed to entry→sink
                    found_paths.append(list(reversed(new_path)))
                else:
                    queue.append((caller, new_path))

        # Belt-and-suspenders: discard any "path" that is just [sink_func].
        # That would mean we started at the sink and immediately hit a dead end
        # with no callers — the sink cannot be its own entry point.
        found_paths = [p for p in found_paths if not (len(p) == 1 and p[0] == sink_func)]

        if not found_paths:
            return [
                BFSPath(
                    hops=[sink_func],
                    sink=sink_func,
                    is_reachable=False,
                    owasp_llm=owasp_llm,
                    finding_type=finding_type,
                )
            ]

        # Convert to BFSPath objects, deduplicate by entry point (shortest first)
        result: List[BFSPath] = []
        seen_entries: Set[str] = set()
        for hops in sorted(found_paths, key=len):
            entry = hops[0]
            # Entry must differ from sink — a function can't be both
            if entry == sink_func or entry in seen_entries:
                continue
            seen_entries.add(entry)
            result.append(
                BFSPath(
                    hops=hops,
                    path_nodes=self._to_path_nodes(hops, finding_type),
                    owasp_llm=owasp_llm,
                    finding_type=finding_type,
                    entry_point=entry,
                    sink=sink_func,
                    is_reachable=True,
                )
            )

        if not result:
            return [
                BFSPath(
                    hops=[sink_func],
                    sink=sink_func,
                    is_reachable=False,
                    owasp_llm=owasp_llm,
                    finding_type=finding_type,
                )
            ]

        return result

    def forward_from_llm(
        self,
        llm_func: str,
        finding_type: str = "AI",
        owasp_llm: str = "LLM05",
    ) -> List[BFSPath]:
        """
        BFS forward from ``llm_func`` to dangerous operations (LLM05).

        Walks callees until ``_is_danger_sink`` is found.  Used to detect
        LLM response → eval() / exec() / subprocess flows.
        """
        if not self.call_graph:
            return []

        queue: deque[Tuple[str, List[str]]] = deque([(llm_func, [llm_func])])
        visited: Set[str] = {llm_func}
        found_paths: List[List[str]] = []

        while queue:
            current, path = queue.popleft()
            if len(path) > self.max_depth:
                continue

            for callee in self.call_graph.get(current, []):
                if callee in visited:
                    continue
                new_path = path + [callee]
                visited.add(callee)

                if _is_danger_sink(callee):
                    found_paths.append(new_path)
                else:
                    queue.append((callee, new_path))

        result: List[BFSPath] = []
        seen_sinks: Set[str] = set()
        for hops in sorted(found_paths, key=len):
            sink = hops[-1]
            if sink in seen_sinks:
                continue
            seen_sinks.add(sink)
            result.append(
                BFSPath(
                    hops=hops,
                    path_nodes=self._to_path_nodes(hops, finding_type),
                    owasp_llm=owasp_llm,
                    finding_type=finding_type,
                    entry_point=llm_func,
                    sink=sink,
                    is_reachable=True,
                )
            )

        return result

    def find_llm_sinks_in_callees(
        self,
        func: str,
        depth: int = 5,
    ) -> List[str]:
        """
        Return all LLM-sink functions reachable from ``func`` within ``depth`` hops.
        Used by the integration bridge to seed backward_from_sink().
        """
        visited: Set[str] = set()
        queue: deque[Tuple[str, int]] = deque([(func, 0)])
        sinks: List[str] = []

        while queue:
            current, d = queue.popleft()
            if d >= depth or current in visited:
                continue
            visited.add(current)
            for callee in self.call_graph.get(current, []):
                if _is_llm_sink(callee):
                    sinks.append(callee)
                queue.append((callee, d + 1))

        return sinks

    # ── Internal helpers ─────────────────────────────────────────────────────

    def _to_path_nodes(self, hops: List[str], finding_type: str) -> List[PathNode]:
        """Convert a list of qualified function names to PathNode objects."""
        nodes: List[PathNode] = []
        n = len(hops)
        for i, hop in enumerate(hops):
            if i == 0:
                pos = HopPosition.FIRST
            elif i == n - 1:
                pos = HopPosition.LAST
            else:
                pos = HopPosition.MIDDLE

            decision = classify_hop(hop, finding_type, pos)

            # Override: first hop that is a known/heuristic entry point → ENTRY
            if i == 0 and (hop in self._entry_set or _is_entry_point(hop)):
                kind = NodeKind.ENTRY
            else:
                kind = decision.kind

            nodes.append(
                PathNode(
                    label=hop,
                    kind=kind,
                    file=_func_to_file(hop),
                    package=_func_package(hop),
                )
            )
        return nodes


# ════════════════════════════════════════════════════════════════════════════
# Utilities
# ════════════════════════════════════════════════════════════════════════════


def _func_to_file(func_name: str) -> str:
    """
    Derive a probable file path from a dotted function name.
    e.g. ``app.api.chat.chat_endpoint`` → ``app/api/chat.py``
    """
    parts = func_name.split(".")
    if len(parts) < 2:
        return ""
    return "/".join(parts[:-1]) + ".py"


def _func_package(func_name: str) -> str:
    """Return the module prefix (everything except the last segment)."""
    parts = func_name.split(".")
    return ".".join(parts[:-1]) if len(parts) > 1 else ""


def enrich_flows_with_bfs(
    flows: list,
    call_graph: Dict[str, List[str]],
    reachable_functions: Optional[Set[str]] = None,
    entrypoints: Optional[Set[str]] = None,
    repo_path: Optional[Path] = None,
) -> list:
    """
    T-AI5 high-level enrichment function.

    For each DataFlow in ``flows``:
    - If the sink function is known in the call graph, run backward BFS to find
      the entry-point→sink chain and attach it as ``path_nodes``.
    - Update ``is_reachable`` based on whether BFS found a path.
    - Update ``path`` (string list) with the BFS hop names.

    Falls back gracefully when the call graph is empty.
    """
    if not call_graph or not flows:
        return flows

    engine = CrossFileBFSEngine(
        call_graph=call_graph,
        reachable_functions=reachable_functions,
        entrypoints=entrypoints,
    )

    for flow in flows:
        sink_func = getattr(flow, "sink", None)
        if sink_func is None:
            continue
        sink_name = getattr(sink_func, "function", "") or ""
        if not sink_name:
            continue

        cg_sink = _resolve_func_in_graph(sink_name, call_graph)
        if not cg_sink:
            continue

        owasp = getattr(flow, "owasp_llm", "LLM01") or "LLM01"
        bfs_paths = engine.backward_from_sink(cg_sink, finding_type="AI", owasp_llm=owasp)

        if bfs_paths and bfs_paths[0].is_reachable:
            best = bfs_paths[0]
            flow.is_reachable = True
            flow.path = best.hops
            if not hasattr(flow, "path_nodes"):
                try:
                    flow.path_nodes = best.path_nodes
                except AttributeError:
                    pass  # frozen dataclass — skip
        elif bfs_paths:
            flow.is_reachable = False

    return flows


def _resolve_func_in_graph(
    func_fragment: str,
    call_graph: Dict[str, List[str]],
) -> Optional[str]:
    """
    Find the fully-qualified function name in the call graph that ends with
    ``func_fragment``.  Returns None if not found.
    """
    if func_fragment in call_graph:
        return func_fragment
    fragment_lower = func_fragment.lower()
    for name in call_graph:
        if name.lower().endswith("." + fragment_lower) or name.lower() == fragment_lower:
            return name
    return None
