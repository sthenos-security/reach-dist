# Copyright © 2026 Sthenos Security. All rights reserved.

"""
REACHABLE Dashboard v2

Funnel visualization dashboard with Executive + Engineering views.

Architecture:
    repo.db / JSON report → data.json → index.html

Usage:
    from reachable.dashboard_v2.generator import DashboardV2Generator, generate_dashboard

    # From scan directory (auto-detects source)
    dashboard_dir = generate_dashboard(scan_dir)

    # From report dict
    generator = DashboardV2Generator()
    dashboard_dir = generator.generate_from_report(report, output_dir)
"""

from .generator import DashboardV2Generator, generate_dashboard

__all__ = ["DashboardV2Generator", "generate_dashboard"]
