#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.

"""
Report transformation and issue extraction.
Transforms raw report data into dashboard format.
"""

from pathlib import Path
from typing import Any, Dict, List

from .metrics import calculate_risk_level
from .utils import determine_finding_type, get_version, normalize_severity


def transform_report(report: Dict[str, Any]) -> Dict[str, Any]:
    """Transform full report to dashboard format with complete metrics"""
    summary = report.get("summary", {})
    totals = summary.get("totals", {})
    metadata = report.get("metadata", {})
    target = metadata.get("analysis_target", {})
    git_info = metadata.get("git_info", {}) or target.get("git", {})
    sandbox = (
        report.get("dynamic_malware", {})
        or report.get("security_scans", {}).get("dynamic_malware", {})
        or report.get("sandbox", {})
    )
    sandbox_summary = sandbox.get("summary", {})

    # Extract repo info
    app_dir = target.get("app_directory", "")
    repo_name = Path(app_dir).name if app_dir else "unknown"
    branch = git_info.get("branch", "main")
    commit = git_info.get("commit_short") or (git_info.get("commit_sha") or "")[:8]
    commit_date = git_info.get("commit_date", "")

    # Try to get GitHub URL from various sources
    github_url = (
        git_info.get("remote_url")
        or git_info.get("github_url")
        or target.get("github_url")
        or metadata.get("github_url")
        or ""
    )
    # Clean up GitHub URL
    if github_url:
        github_url = github_url.rstrip("/")
        if github_url.endswith(".git"):
            github_url = github_url[:-4]
        if github_url.startswith("git@github.com:"):
            github_url = "https://github.com/" + github_url[15:]

    # Build metrics
    metrics = _build_metrics(totals, sandbox_summary, metadata, sandbox)

    # Build security issues list
    issues = extract_issues_from_report(report)

    # Calculate risk level based on reachable issues
    summary_for_risk = {
        "malware_total": metrics.get("malware_total", 0),
        "suspicious_total": metrics.get("suspicious_total", 0),
    }
    risk_level = calculate_risk_level(summary_for_risk, metrics, issues)

    # Determine scan date
    scan_date = ""
    if commit_date:
        scan_date = commit_date.split(" ")[0] if " " in commit_date else commit_date

    return {
        "version": report.get("reachable_version") or get_version(),
        "scan": {
            "repository": repo_name,
            "branch": branch,
            "commit": commit,
            "date": scan_date,
            "display": f"{repo_name} @ {branch}",
            "github_url": github_url,
            "repo_root": app_dir,
        },
        "risk_level": risk_level,
        "metrics": metrics,
        "summary": {
            "cves": f"{metrics['cves_total']} total, {metrics['cves_reachable']} reachable",
            "secrets": f"{metrics['secrets_total']} total, {metrics['secrets_reachable']} reachable",
            "malware": f"{metrics['malware_total']} malicious packages",
            "sast": f"{metrics['sast_total']} code issues, {metrics['sast_reachable']} reachable",
        },
        "issues": issues,
        # AI Security (if present from --enable-ai scan)
        "ai_security": report.get("ai_security"),
        # OWASP Top 10 Web (mapped from CWE findings)
        "owasp_web": _build_owasp_web_summary(issues),
    }


def _build_metrics(totals: Dict, sandbox_summary: Dict, metadata: Dict, sandbox: Dict) -> Dict[str, Any]:
    """Build comprehensive metrics for funnel visualization"""
    # Raw signals (before reachability filtering)
    raw_cves = totals.get("cves_total", 0)
    raw_malware = totals.get("malware_total", 0)
    raw_suspicious = sandbox_summary.get("suspicious", 0)
    raw_secrets = totals.get("secrets_total", 0)
    raw_sast = totals.get("cwe_total", 0)
    raw_cwe = totals.get("cwe_total", 0)

    # Reachable signals (after reachability filtering)
    reach_cves = totals.get("cves_reachable", 0)
    reach_malware = totals.get("malware_total", 0)  # Malware is always "reachable"
    reach_secrets = totals.get("secrets_reachable", 0) or totals.get("secrets_reachable_actual", 0)
    reach_sast = totals.get("cwe_reachable", 0)
    reach_cwe = totals.get("cwe_reachable", 0)

    return {
        # CVE/Vulnerable Packages
        "cves_total": raw_cves,
        "cves_reachable": reach_cves,
        "cves_critical": totals.get("cves_critical", 0),
        "cves_high": totals.get("cves_high", 0),
        "cves_medium": totals.get("cves_medium", 0),
        "cves_low": totals.get("cves_low", 0),
        # Malware — 4-counter model (static/dynamic × confirmed/suspicious)
        "malware_total": raw_malware,
        "malware_reachable": reach_malware,
        "malware_static_confirmed": totals.get("malware_reachable", 0),
        "malware_static_suspicious": max(0, totals.get("malware_total", 0) - totals.get("malware_reachable", 0)),
        "malware_dynamic_confirmed": sandbox_summary.get("malicious", 0),
        "malware_dynamic_suspicious": sandbox_summary.get("suspicious", 0),
        # Suspicious (Sandbox) — backward compat
        "suspicious_total": raw_suspicious,
        "suspicious_reachable": 0,
        # Secrets
        "secrets_total": raw_secrets,
        "secrets_reachable": reach_secrets,
        "secrets_critical": totals.get("secrets_critical", 0),
        # SAST/Code vulnerabilities
        "sast_total": raw_sast,
        "sast_reachable": reach_sast,
        # License
        "license_total": 0,
        "license_reachable": 0,
        # CWE patterns
        "cwe_total": raw_cwe,
        "cwe_reachable": reach_cwe,
        # Totals
        "raw_total": raw_cves + raw_malware + raw_suspicious + raw_secrets + raw_sast + totals.get("config_total", 0),
        "reachable_total": reach_cves
        + reach_malware
        + reach_secrets
        + reach_sast,  # CONFIG excluded — not_applicable plane
        # Other
        "packages_scanned": totals.get("total_packages", 0),
        "source_files_scanned": totals.get("source_files_scanned", 0) or metadata.get("source_files_scanned", 0),
        "sandbox_packages_tested": sandbox.get("packages_tested", 0),
        # v4.4.2: Threat Intel metrics
        "kev_total": totals.get("kev_matches", 0),
        "epss_high": totals.get("epss_high", 0),
        "threat_intel_total": (totals.get("kev_matches", 0) or 0) + (totals.get("epss_high", 0) or 0),
        # v4.4.2: Supply Chain metrics
        "phantom_deps": totals.get("phantom_deps", 0),
        "shadow_imports": totals.get("shadow_imports", 0),
        "dead_deps": totals.get("dead_deps", 0),
        # v4.4.2: Library Health metrics
        "health_critical": totals.get("health_critical", 0),
        "unhealthy_packages": totals.get("unhealthy_packages", 0),
        # v4.4.2: Direct vs Transitive dependencies
        "direct_deps": totals.get("direct_deps", 0),
        "transitive_deps": totals.get("transitive_deps", 0),
        # v4.4.4: Threat Intel (KEV/EPSS)
        "threatintel_total": (totals.get("kev_matches", 0) or 0) + (totals.get("epss_high", 0) or 0),
        "threatintel_reachable": (totals.get("kev_reachable", 0) or totals.get("kev_matches", 0) or 0)
        + (totals.get("epss_high_reachable", 0) or totals.get("epss_high", 0) or 0),
        # v4.4.4: Phantom Libraries
        "phantom_total": totals.get("phantom_deps", 0) or 0,
        "phantom_reachable": totals.get("phantom_reachable", 0) or totals.get("phantom_deps", 0) or 0,
        # v4.4.5: Config Issues
        "config_total": totals.get("config_total", 0),
        "config_not_applicable": totals.get(
            "config_total", 0
        ),  # All config findings are not_applicable for reachability
        # v4.5.4: Attack Surface metrics
        "entrypoints": totals.get("entrypoints", 0),
        "functions_total": totals.get("functions_total", 0),
        "functions_reachable": totals.get("functions_reachable", 0),
    }


def extract_issues_from_report(report: Dict[str, Any]) -> List[Dict[str, Any]]:
    """Extract all security issues from report with remediation and compliance data"""
    issues = []

    # Extract CVEs from reachable
    issues.extend(_extract_cves(report.get("reachable", {}), is_reachable=True))

    # Extract CVEs from unreachable
    issues.extend(_extract_cves(report.get("unreachable", {}), is_reachable=False))

    # Extract secrets/CWE/CONFIG from detailed_findings
    detailed = report.get("detailed_findings", {})
    issues.extend(_extract_secrets_and_code_findings(detailed.get("secrets", {})))

    # Extract malware findings
    issues.extend(_extract_malware_findings(detailed.get("malware", {}), report))

    # Extract dynamic malware findings
    issues.extend(_extract_dynamic_malware(report))

    return issues


def _extract_cves(cve_dict: Dict[str, Any], is_reachable: bool) -> List[Dict[str, Any]]:
    """Extract CVE issues from reachable/unreachable dict"""
    issues = []

    for cve_id, cve_data in cve_dict.items():
        remediation = cve_data.get("remediation", {})
        raw_sev = cve_data.get("severity", "MEDIUM")
        is_fixable = cve_data.get("is_fixable", False)

        # P2.20-A1: FIX CVE ID extraction - try multiple sources
        final_cve_id = cve_id
        if not final_cve_id or final_cve_id == "-":
            # Try aliases (GHSA might have CVE in aliases)
            aliases = cve_data.get("aliases", [])
            for alias in aliases:
                if alias.startswith("CVE-"):
                    final_cve_id = alias
                    break
            # If still no ID, use GHSA with note
            if not final_cve_id or final_cve_id == "-":
                ghsa_id = cve_data.get("ghsa_id", "")
                if ghsa_id:
                    final_cve_id = f"{ghsa_id} (GHSA)"
                else:
                    final_cve_id = cve_data.get("id", cve_id)

        # P2.20-A2: FIX package version extraction
        version = cve_data.get("version", "")
        package_name = cve_data.get("package", "")

        # Parse from package URL if version is missing (pkg:pypi/requests@2.31.0)
        if not version and package_name:
            if "@" in package_name:
                parts = package_name.split("@")
                if len(parts) == 2:
                    package_name = parts[0].split("/")[-1]  # Just the name
                    version = parts[1]
            # Also check purl field
            purl = cve_data.get("purl", "")
            if not version and purl and "@" in purl:
                version = purl.split("@")[-1]

        # Determine fix_status
        fix_status = "fix_available" if is_fixable else "no_fix"
        if cve_data.get("fix_state") == "wont-fix":
            fix_status = "wont_fix"

        issues.append(
            {
                "id": final_cve_id,
                "type": "CVE",
                "severity": raw_sev,
                "raw_severity": raw_sev,
                "is_reachable": is_reachable,
                "reachability_state": "reachable" if is_reachable else "not_reachable",
                "title": final_cve_id,
                "description": cve_data.get("description", ""),
                "message": cve_data.get("description", ""),
                "package": package_name,
                "version": version,
                "file_path": "",
                "is_transitive": cve_data.get("is_transitive", False),
                "fix_available": is_fixable,
                "fix_status": fix_status,
                "call_paths_v2": (cve_data if "cve_data" in dir() else finding).get("call_paths_v2", []),  # noqa: F821
                "remediation": {
                    "action": remediation.get("action", "UPGRADE" if is_reachable else "MONITOR"),
                    "fixed_in": remediation.get("fixed_in", ""),
                    "summary": remediation.get("summary", ""),
                    "steps": remediation.get("steps", []),
                    "workaround": remediation.get("workaround"),
                    "references": remediation.get("references", []),
                },
                "compliance_mapping": cve_data.get("compliance_mapping", {}),
                "exploitability": cve_data.get("exploitability", {}),
            }
        )

    return issues


def _extract_secrets_and_code_findings(secrets_data: Dict[str, Any]) -> List[Dict[str, Any]]:
    """Extract secrets, CWE, and CONFIG findings"""
    issues = []

    for idx, finding in enumerate(secrets_data.get("findings", []), 1):
        is_secret = finding.get("is_actual_secret", False)
        raw_sev = finding.get("severity", "MEDIUM")
        rule_id = finding.get("rule_id", "")

        # P2.20-A4: FIX file path preservation - NO truncation
        file_path = finding.get("file", "") or finding.get("path", "")
        # Clean up path but keep full relative path for GitHub linking
        if file_path.startswith("./"):
            file_path = file_path[2:]

        # Determine finding type
        ftype = determine_finding_type(is_secret, rule_id, file_path)

        # Normalize severity
        severity = normalize_severity(raw_sev, rule_id, file_path)

        # Determine reachability state
        reachability_state = _determine_reachability_state(finding, ftype)

        # FIX: Compute is_reachable based on type and state
        # - SECRET unknown → True (conservative - assume exposed)
        # - CONFIG unknown → None (runtime-dependent)
        # - reachable → True
        # - not_reachable → False
        if reachability_state == "reachable":
            is_reachable = True
        elif reachability_state == "not_reachable":
            is_reachable = False
        elif reachability_state == "not_applicable":
            is_reachable = None  # Config plane — reachability does not apply
        elif reachability_state == "unknown":
            if ftype == "SECRET":
                is_reachable = (
                    False  # P2.21 FIX: Unknown secrets are not proven reachable (shown separately in dashboard)
                )
            else:
                is_reachable = False
        else:
            is_reachable = finding.get("is_reachable")

        remediation = finding.get("remediation", {})

        # P2.20-A3: ENHANCED CWE ID extraction from multiple sources
        cwe_id = finding.get("cwe_id", "")
        if not cwe_id and rule_id:
            import re

            # Try to extract CWE from rule_id
            cwe_match = re.search(r"cwe[-_]?(\d+)", rule_id.lower())
            if cwe_match:
                cwe_id = f"CWE-{cwe_match.group(1).lstrip('0') or '0'}"

            # Also check semgrep metadata for CWE
            if not cwe_id:
                metadata = finding.get("extra", {}).get("metadata", {})
                if metadata:
                    # Check cwe field in metadata
                    if "cwe" in metadata:
                        cwe_val = metadata["cwe"]
                        if isinstance(cwe_val, list) and cwe_val:
                            cwe_id = f"CWE-{str(cwe_val[0]).split('-')[-1]}"
                        elif isinstance(cwe_val, str):
                            cwe_id = cwe_val if cwe_val.startswith("CWE-") else f"CWE-{cwe_val}"
                    # Check cwe2021-top25, cwe2022-top25, etc.
                    if not cwe_id:
                        for key in metadata.keys():
                            if "cwe" in key.lower() and metadata[key]:
                                cwe_id = f"CWE-{str(metadata[key]).split('-')[-1]}"
                                break

        # P2.20 FIX: Better ID extraction with fallbacks
        issue_id = (
            finding.get("rule_id")
            or finding.get("id")
            or finding.get("policy_id")
            or finding.get("finding_id")
            or f"{ftype}-{idx}"
        ).strip()

        # P2.20 FIX: Better description extraction with type-specific fallbacks
        desc = (finding.get("description") or finding.get("message") or finding.get("title") or "").strip()

        if not desc or desc == "-":
            if ftype == "CVE":
                pkg = finding.get("package") or finding.get("package_name") or "unknown"
                desc = f"Vulnerable dependency: {pkg}"
            elif ftype == "CWE":
                desc = f"Code weakness detected: {cwe_id}" if cwe_id else "Code weakness detected"
            elif ftype == "SECRET":
                desc = f"Secret detected in {finding.get('file', 'code')}"
            elif ftype == "CONFIG":
                desc = "Configuration issue detected"
            else:
                desc = f"{ftype} finding"

        issues.append(
            {
                "id": issue_id,
                "type": ftype,
                "severity": severity,
                "raw_severity": raw_sev,
                "is_reachable": is_reachable,
                "reachability_state": reachability_state,
                "title": finding.get("rule_id", ""),
                "description": desc,
                "message": desc,
                "package": "",
                "file_path": finding.get("file", ""),
                "line": finding.get("line"),
                "cwe_id": cwe_id,
                "call_paths_v2": (cve_data if "cve_data" in dir() else finding).get("call_paths_v2", []),  # noqa: F821
                "remediation": {
                    "action": remediation.get("action", "CODE_FIX"),
                    "steps": remediation.get("steps", []),
                    "references": [],
                },
                "compliance_mapping": finding.get("compliance_mapping", {}),
            }
        )

    return issues


def _determine_reachability_state(finding: Dict[str, Any], ftype: str) -> str:
    """
    Determine reachability state for a finding.

    v4.5.16: UNIFIED REACHABILITY MODEL
    States: reachable / not_reachable / unknown
    """
    cwe_reachability = finding.get("cwe_reachability", "").lower()
    is_reachable = finding.get("is_reachable")
    reachability_confidence = finding.get("reachability_confidence", "")

    if ftype == "CONFIG":
        return "not_applicable"  # Config plane — reachability analysis does not apply
    elif cwe_reachability in ("reachable", "config_issue"):
        return "reachable"
    elif cwe_reachability in ("unreachable", "not_reachable"):
        return "not_reachable"
    elif cwe_reachability == "test_only":
        return "not_reachable"
    elif is_reachable is True:
        return "reachable"
    elif is_reachable is False:
        reachability_field = finding.get("reachability", "unknown").lower()
        if reachability_field in ("unknown", ""):
            return "unknown"
        else:
            return "not_reachable"
    elif reachability_confidence and reachability_confidence.startswith("UNKNOWN"):
        return "unknown"
    elif "is_reachable" not in finding and not cwe_reachability:
        return "unknown"
    else:
        return "unknown"


def _extract_malware_findings(malware_data: Dict[str, Any], report: Dict[str, Any]) -> List[Dict[str, Any]]:
    """Extract malware findings with reachability context"""
    issues = []

    # Get used packages for reachability check
    used_packages = set(p.lower() for p in report.get("used_packages", []))
    imported_packages = set(p.lower() for p in report.get("imported_packages", []))
    all_used = used_packages | imported_packages

    function_imports = report.get("function_imports", {})

    for idx, finding in enumerate(malware_data.get("findings", []), 1):
        has_dynamic_evidence = finding.get("dynamic_evidence") or finding.get("sandbox_result")

        # Build evidence structure
        evidence = {}
        if finding.get("static_indicators") or finding.get("guarddog_findings"):
            evidence["static"] = {
                "scanner": "GuardDog",
                "indicators": finding.get("static_indicators", finding.get("guarddog_findings", [])),
                "confidence": finding.get("static_confidence", 0.0),
            }
        if has_dynamic_evidence:
            evidence["dynamic"] = {
                "scanner": "Sandbox",
                "behaviors": finding.get("dynamic_evidence", finding.get("sandbox_result", {}).get("behaviors", [])),
                "confidence": finding.get("dynamic_confidence", 0.0),
            }

        # Check if malicious package is actually imported/used
        pkg_name = finding.get("package", "").lower()
        pkg_in_imports = any(pkg_name in imp.lower() for imps in function_imports.values() for imp in imps)

        # v4.6.10: Reachability determines verdict:
        #   Reachable → MALWARE (CRITICAL) — shows in malware alert
        #   Not reachable → SUSPICIOUS (WARNING) — separate counter, no alert
        if pkg_name in all_used or pkg_in_imports:
            malware_reachable = True
            malware_reachability_state = "reachable"
            verdict = "MALWARE"
            malware_severity = "CRITICAL"
        else:
            malware_reachable = False
            malware_reachability_state = "not_reachable"
            verdict = "SUSPICIOUS"
            malware_severity = "MEDIUM"

        # Build remediation
        if malware_reachable:
            remediation_steps = [
                f"🚨 URGENT: {finding.get('package', 'package')} is IMPORTED in your code",
                f"Remove {finding.get('package', 'the package')} from dependencies IMMEDIATELY",
                "Audit for any data exfiltration or unauthorized access",
                "Rotate any credentials that may have been exposed",
                "Review install-time hooks and scripts",
            ]
        else:
            remediation_steps = [
                f"⚠️ {finding.get('package', 'package')} is in dependencies but NOT directly imported",
                f"Remove {finding.get('package', 'the package')} from dependencies",
                "Check if it is a transitive dependency (required by another package)",
                "May have executed install-time hooks - audit for side effects",
            ]

        issues.append(
            {
                "id": finding.get("package", f"MAL-{idx}"),
                "type": verdict,
                "severity": malware_severity,
                "raw_severity": "CRITICAL" if verdict == "MALWARE" else "HIGH",
                "is_reachable": malware_reachable,
                "reachability_state": malware_reachability_state,
                "title": f"Malicious package: {finding.get('package', 'unknown')}",
                "description": finding.get("description", finding.get("reason", "")),
                "message": finding.get("reason", finding.get("description", "")),
                "package": finding.get("package", ""),
                "version": finding.get("version", ""),
                "file_path": "",
                "call_paths_v2": (cve_data if "cve_data" in dir() else finding).get("call_paths_v2", []),  # noqa: F821
                "evidence": evidence,
                "remediation": {
                    "action": "REMOVE_IMMEDIATELY" if malware_reachable else "REMOVE",
                    "steps": remediation_steps,
                    "references": finding.get("references", []),
                },
                "compliance_mapping": {
                    "CWE-TOP-25": ["CWE-506"],
                    "OWASP": ["A08:2021"],
                },
            }
        )

    return issues


def _extract_dynamic_malware(report: Dict[str, Any]) -> List[Dict[str, Any]]:
    """Extract dynamic malware findings from sandbox results"""
    issues = []

    dynamic_malware = report.get("dynamic_malware", {}) or report.get("security_scans", {}).get("dynamic_malware", {})
    if not dynamic_malware or dynamic_malware.get("verdict") in ("NOT_RUN", "CLEAN", None):
        return issues

    # Add sandbox findings
    for finding in dynamic_malware.get("findings", []):
        severity = finding.get("severity", "HIGH")
        if severity == "CRITICAL" or dynamic_malware.get("verdict") == "CRITICAL":
            verdict_type = "MALWARE"
        else:
            verdict_type = "SUSPICIOUS"

        pkg_name = finding.get("package", "unknown")
        issues.append(
            {
                "id": f"SANDBOX-{pkg_name}-{finding.get('rule', 'unknown')}",
                "type": verdict_type,
                "severity": severity,
                "raw_severity": severity,
                "is_reachable": True,
                "reachability_state": "reachable",
                "title": f"Dynamic analysis: {finding.get('rule', 'Suspicious behavior')}",
                "description": finding.get("description", ""),
                "message": finding.get("description", ""),
                "package": pkg_name,
                "version": "",
                "file_path": "",
                "call_paths_v2": (cve_data if "cve_data" in dir() else finding).get("call_paths_v2", []),  # noqa: F821
                "evidence": {
                    "dynamic": {
                        "scanner": "Colima Sandbox",
                        "behaviors": [finding.get("evidence", finding.get("description", ""))],
                        "phase": finding.get("phase", "install"),
                    }
                },
                "remediation": {
                    "action": "INVESTIGATE_IMMEDIATELY",
                    "steps": [
                        f"Review {pkg_name} for malicious behavior",
                        "Check for network calls during installation",
                        "Audit credential access patterns",
                        "Consider removing or replacing the package",
                    ],
                    "references": [],
                },
                "compliance_mapping": {
                    "CWE-TOP-25": ["CWE-506"],
                    "OWASP": ["A08:2021"],
                },
            }
        )

    # Add malicious packages from sandbox verdict
    for pkg in dynamic_malware.get("malicious_packages", []):
        if not any(i.get("package") == pkg and i.get("type") == "MALWARE" for i in issues):
            issues.append(
                {
                    "id": f"SANDBOX-{pkg}",
                    "type": "MALWARE",
                    "severity": "CRITICAL",
                    "raw_severity": "CRITICAL",
                    "is_reachable": True,
                    "reachability_state": "reachable",
                    "title": f"Malicious package confirmed: {pkg}",
                    "description": "Dynamic sandbox analysis confirmed malicious behavior",
                    "message": "Package exhibited malicious behavior during installation",
                    "package": pkg,
                    "version": "",
                    "file_path": "",
                    "evidence": {
                        "dynamic": {
                            "scanner": "Colima Sandbox",
                            "behaviors": ["Confirmed malicious during dynamic analysis"],
                            "phase": "install",
                        }
                    },
                    "remediation": {
                        "action": "REMOVE_IMMEDIATELY",
                        "steps": [
                            f"Remove {pkg} from dependencies immediately",
                            "Audit for data exfiltration",
                            "Rotate any credentials",
                            "Review git history for when package was added",
                        ],
                        "references": [],
                    },
                    "compliance_mapping": {
                        "CWE-TOP-25": ["CWE-506"],
                        "OWASP": ["A08:2021"],
                    },
                }
            )

    return issues


# CWE to OWASP Top 10 2021 mapping
CWE_TO_OWASP = {
    # A01: Broken Access Control
    "CWE-22": "A01",
    "CWE-23": "A01",
    "CWE-35": "A01",
    "CWE-59": "A01",
    "CWE-200": "A01",
    "CWE-201": "A01",
    "CWE-219": "A01",
    "CWE-264": "A01",
    "CWE-275": "A01",
    "CWE-276": "A01",
    "CWE-284": "A01",
    "CWE-285": "A01",
    "CWE-352": "A01",
    "CWE-359": "A01",
    "CWE-377": "A01",
    "CWE-402": "A01",
    "CWE-425": "A01",
    "CWE-441": "A01",
    "CWE-497": "A01",
    "CWE-538": "A01",
    "CWE-540": "A01",
    "CWE-548": "A01",
    "CWE-552": "A01",
    "CWE-566": "A01",
    "CWE-601": "A01",
    "CWE-639": "A01",
    "CWE-651": "A01",
    "CWE-668": "A01",
    "CWE-706": "A01",
    "CWE-862": "A01",
    "CWE-863": "A01",
    "CWE-913": "A01",
    "CWE-922": "A01",
    "CWE-1275": "A01",
    # A02: Cryptographic Failures
    "CWE-261": "A02",
    "CWE-296": "A02",
    "CWE-310": "A02",
    "CWE-319": "A02",
    "CWE-321": "A02",
    "CWE-322": "A02",
    "CWE-323": "A02",
    "CWE-324": "A02",
    "CWE-325": "A02",
    "CWE-326": "A02",
    "CWE-327": "A02",
    "CWE-328": "A02",
    "CWE-329": "A02",
    "CWE-330": "A02",
    "CWE-331": "A02",
    "CWE-335": "A02",
    "CWE-336": "A02",
    "CWE-337": "A02",
    "CWE-338": "A02",
    "CWE-340": "A02",
    "CWE-347": "A02",
    "CWE-523": "A02",
    "CWE-720": "A02",
    "CWE-757": "A02",
    "CWE-759": "A02",
    "CWE-760": "A02",
    "CWE-780": "A02",
    "CWE-818": "A02",
    "CWE-916": "A02",
    # A03: Injection
    "CWE-20": "A03",
    "CWE-74": "A03",
    "CWE-75": "A03",
    "CWE-77": "A03",
    "CWE-78": "A03",
    "CWE-79": "A03",
    "CWE-80": "A03",
    "CWE-83": "A03",
    "CWE-87": "A03",
    "CWE-88": "A03",
    "CWE-89": "A03",
    "CWE-90": "A03",
    "CWE-91": "A03",
    "CWE-93": "A03",
    "CWE-94": "A03",
    "CWE-95": "A03",
    "CWE-96": "A03",
    "CWE-97": "A03",
    "CWE-98": "A03",
    "CWE-99": "A03",
    "CWE-100": "A03",
    "CWE-113": "A03",
    "CWE-116": "A03",
    "CWE-138": "A03",
    "CWE-184": "A03",
    "CWE-470": "A03",
    "CWE-471": "A03",
    "CWE-564": "A03",
    "CWE-610": "A03",
    "CWE-643": "A03",
    "CWE-644": "A03",
    "CWE-652": "A03",
    "CWE-917": "A03",
    # A04: Insecure Design
    "CWE-73": "A04",
    "CWE-183": "A04",
    "CWE-209": "A04",
    "CWE-213": "A04",
    "CWE-235": "A04",
    "CWE-256": "A04",
    "CWE-257": "A04",
    "CWE-266": "A04",
    "CWE-269": "A04",
    "CWE-280": "A04",
    "CWE-311": "A04",
    "CWE-312": "A04",
    "CWE-313": "A04",
    "CWE-316": "A04",
    "CWE-419": "A04",
    "CWE-430": "A04",
    "CWE-434": "A04",
    "CWE-444": "A04",
    "CWE-451": "A04",
    "CWE-472": "A04",
    "CWE-501": "A04",
    "CWE-522": "A04",
    "CWE-525": "A04",
    "CWE-539": "A04",
    "CWE-579": "A04",
    "CWE-598": "A04",
    "CWE-602": "A04",
    "CWE-642": "A04",
    "CWE-646": "A04",
    "CWE-650": "A04",
    "CWE-653": "A04",
    "CWE-656": "A04",
    "CWE-657": "A04",
    "CWE-799": "A04",
    "CWE-807": "A04",
    "CWE-840": "A04",
    "CWE-841": "A04",
    "CWE-927": "A04",
    "CWE-1021": "A04",
    "CWE-1173": "A04",
    # A05: Security Misconfiguration
    "CWE-2": "A05",
    "CWE-11": "A05",
    "CWE-13": "A05",
    "CWE-15": "A05",
    "CWE-16": "A05",
    "CWE-260": "A05",
    "CWE-315": "A05",
    "CWE-520": "A05",
    "CWE-526": "A05",
    "CWE-537": "A05",
    "CWE-541": "A05",
    "CWE-547": "A05",
    "CWE-611": "A05",
    "CWE-614": "A05",
    "CWE-756": "A05",
    "CWE-776": "A05",
    "CWE-942": "A05",
    "CWE-1004": "A05",
    "CWE-1032": "A05",
    "CWE-1174": "A05",
    # A06: Vulnerable Components (handled by Grype/CVE)
    "CWE-937": "A06",
    "CWE-1035": "A06",
    "CWE-1104": "A06",
    # A07: Auth Failures
    "CWE-255": "A07",
    "CWE-259": "A07",
    "CWE-287": "A07",
    "CWE-288": "A07",
    "CWE-290": "A07",
    "CWE-294": "A07",
    "CWE-295": "A07",
    "CWE-297": "A07",
    "CWE-300": "A07",
    "CWE-302": "A07",
    "CWE-304": "A07",
    "CWE-306": "A07",
    "CWE-307": "A07",
    "CWE-346": "A07",
    "CWE-384": "A07",
    "CWE-521": "A07",
    "CWE-613": "A07",
    "CWE-620": "A07",
    "CWE-640": "A07",
    "CWE-798": "A07",
    "CWE-940": "A07",
    "CWE-1216": "A07",
    # A08: Data Integrity Failures
    "CWE-345": "A08",
    "CWE-353": "A08",
    "CWE-426": "A08",
    "CWE-494": "A08",
    "CWE-502": "A08",
    "CWE-565": "A08",
    "CWE-784": "A08",
    "CWE-829": "A08",
    "CWE-830": "A08",
    "CWE-915": "A08",
    # A09: Logging Failures
    "CWE-117": "A09",
    "CWE-223": "A09",
    "CWE-532": "A09",
    "CWE-778": "A09",
    # A10: SSRF
    "CWE-918": "A10",
}

OWASP_NAMES = {
    "A01": "Broken Access Control",
    "A02": "Cryptographic Failures",
    "A03": "Injection",
    "A04": "Insecure Design",
    "A05": "Security Misconfiguration",
    "A06": "Vulnerable Components",
    "A07": "Auth Failures",
    "A08": "Data Integrity",
    "A09": "Logging Failures",
    "A10": "SSRF",
}


def _normalize_cwe_id(cwe_id: str) -> str:
    """
    Normalize CWE ID: CWE-016 -> CWE-16, 094 -> CWE-94

    v4.5.29: Fix for leading zeros in CWE IDs from semgrep
    """
    if not cwe_id:
        return ""
    cwe_id = cwe_id.upper().strip()
    if cwe_id.startswith("CWE-"):
        # Remove leading zeros: CWE-016 -> CWE-16
        num_part = cwe_id[4:].lstrip("0") or "0"
        return f"CWE-{num_part}"
    elif cwe_id.isdigit():
        # Just a number: 094 -> CWE-94
        return f"CWE-{cwe_id.lstrip('0') or '0'}"
    return cwe_id


def _build_owasp_web_summary(issues: List[Dict[str, Any]]) -> Dict[str, Any]:
    """
    Build OWASP Top 10 Web summary from CWE findings.

    v4.5.31: Enhanced CWE extraction from rule_id and better type handling
    """
    import re

    by_category = {f"A{i:02d}": 0 for i in range(1, 11)}
    by_severity = {"CRITICAL": 0, "HIGH": 0, "MEDIUM": 0, "LOW": 0}
    total = 0
    reachable = 0

    for issue in issues:
        cwe_id = issue.get("cwe_id", "") or ""
        ftype = issue.get("type", "").upper()
        rule_id = issue.get("id", "") or issue.get("title", "") or ""

        # Map CWE to OWASP category
        owasp_cat = None

        # Try to get CWE from cwe_id field
        if cwe_id:
            cwe_id = _normalize_cwe_id(cwe_id)
            owasp_cat = CWE_TO_OWASP.get(cwe_id)

        # v4.5.31: If no cwe_id but type is CWE, try extracting from rule_id
        if not owasp_cat and ftype == "CWE" and rule_id:
            cwe_match = re.search(r"cwe[-_]?(\d+)", rule_id.lower())
            if cwe_match:
                extracted_cwe = f"CWE-{cwe_match.group(1).lstrip('0') or '0'}"
                owasp_cat = CWE_TO_OWASP.get(extracted_cwe)

        # CVEs map to A06 (Vulnerable Components)
        if ftype == "CVE":
            owasp_cat = "A06"

        # v4.5.31: CWE type without specific mapping goes to A03 (Injection) as fallback
        if not owasp_cat and ftype == "CWE":
            owasp_cat = "A03"

        if owasp_cat:
            by_category[owasp_cat] += 1
            total += 1
            sev = (issue.get("severity") or "MEDIUM").upper()
            if sev in by_severity:
                by_severity[sev] += 1
            if issue.get("is_reachable"):
                reachable += 1

    return {
        "total": total,
        "reachable": reachable,
        "by_category": by_category,
        "by_severity": by_severity,
        "category_names": OWASP_NAMES,
    }
