#!/usr/bin/env python3
"""Build template from components"""

import logging
import re
from pathlib import Path

# Configure logging for this build script
logging.basicConfig(level=logging.INFO, format="%(message)s")
logger = logging.getLogger(__name__)

base_dir = Path(__file__).parent

# Read template shell
with open(base_dir / "template-shell.html") as f:
    template = f.read()

# T-AG1: Chart.js vendor injection.
# If scripts/vendor_assets.py has been run, a vendored build lives at:
#   reachable/dashboard_v2/split/components/vendor/chart.js.min.js
# When found: inline it as a <script> block and remove the CDN <script> tag.
# When absent: strip the INJECTED marker and keep the CDN tag (online mode).
_chartjs_vendor = base_dir / "components" / "vendor" / "chart.js.min.js"
if _chartjs_vendor.exists():
    _chartjs_src = _chartjs_vendor.read_text(encoding="utf-8")
    _inline_block = f'<script id="chartjs-vendored">\n{_chartjs_src}\n</script>'
    # Replace the injection marker with the inline block
    template = template.replace("<!-- INJECTED: chart.js.vendor -->", _inline_block)
    # Remove the CDN fallback tag — vendored build takes precedence
    template = re.sub(
        r'<script[^>]+id="chartjs-cdn"[^>]*></script>',
        "<!-- Chart.js CDN omitted: using vendored build -->",
        template,
    )
    logger.info(f"[OK] Chart.js vendored inline ({len(_chartjs_src):,} bytes) — air-gap safe")
else:
    # No vendor build — remove the injection marker, keep CDN tag
    template = template.replace("<!-- INJECTED: chart.js.vendor -->", "")
    logger.info("[OK] Chart.js: CDN mode (run scripts/vendor_assets.py for air-gap build)")

# Read components - TWO SYSTEMS SUPPORTED:
# 1. New system: <!-- INJECTED: marker -->
# 2. Old system: {{STYLES}}, {{SCRIPTS}}, {{BODY}}

components = {
    "dashboard-styles.css": base_dir / "components" / "styles" / "dashboard-styles.css",
    "dashboard-body.html": base_dir / "components" / "dashboard-body.html",
    "main.js": base_dir / "components" / "scripts" / "main.js",
    "tabs.js": base_dir / "components" / "scripts" / "tabs.js",
    "tab-wiring.js": base_dir / "components" / "scripts" / "tab-wiring.js",
    "owasp-cards.js": base_dir / "components" / "scripts" / "owasp-cards.js",
    "supply_chain.js": base_dir / "components" / "scripts" / "supply_chain.js",
}

# Try new injection marker system first
for marker, path in components.items():
    if path.exists():
        content = path.read_text()
        old_template = template
        template = template.replace(f"<!-- INJECTED: {marker} -->", content)
        if template != old_template:
            logger.info(f"[OK] Injected {marker} via <!-- INJECTED: --> marker")
    else:
        logger.info(f"[WARN] {path} not found")

# Fallback: Try old {{PLACEHOLDER}} system
# Combine all CSS files
css_content = ""
css_file = base_dir / "components" / "styles" / "dashboard-styles.css"
if css_file.exists():
    css_content = css_file.read_text()
    logger.info(f"[OK] Loaded CSS: {len(css_content)} chars")

# Combine all JS files in order
js_files = [
    base_dir / "components" / "scripts" / "main.js",
    base_dir / "components" / "scripts" / "tabs.js",
    base_dir / "components" / "scripts" / "tab-wiring.js",
    base_dir / "components" / "scripts" / "owasp-cards.js",
]
js_content = ""
for js_file in js_files:
    if js_file.exists():
        js_content += js_file.read_text() + "\n\n"
        logger.info(f"[OK] Loaded {js_file.name}: {len(js_file.read_text())} chars")

# Load body HTML
body_file = base_dir / "components" / "dashboard-body.html"
body_content = ""
if body_file.exists():
    body_content = body_file.read_text()
    logger.info(f"[OK] Loaded body HTML: {len(body_content)} chars")

# Replace old-style placeholders - replace ALL occurrences
if "{{STYLES}}" in template:
    count = template.count("{{STYLES}}")
    template = template.replace("{{STYLES}}", css_content)
    logger.info(f"[OK] Replaced {{{{STYLES}}}} ({count} occurrences)")
if "{{SCRIPTS}}" in template:
    count = template.count("{{SCRIPTS}}")
    template = template.replace("{{SCRIPTS}}", js_content)
    logger.info(f"[OK] Replaced {{{{SCRIPTS}}}} ({count} occurrences)")
if "{{BODY}}" in template:
    count = template.count("{{BODY}}")
    template = template.replace("{{BODY}}", body_content)
    logger.info(f"[OK] Replaced {{{{BODY}}}} ({count} occurrences)")

# Write compiled template
output_file = base_dir / "template-shell-compiled.html"
output_file.write_text(template)
logger.info(f"\n[OK] Built {output_file.name} ({len(template):,} bytes)")

# Verify no placeholders remain
import re

remaining_curly = re.findall(r"{{[A-Z_]+}}", template)
remaining_injected = re.findall(r"<!-- INJECTED: [^>]+ -->", template)
remaining = remaining_curly + remaining_injected

if remaining:
    logger.info(f"\n[WARN] {len(remaining)} unreplaced placeholders found:")
    for p in set(remaining[:10]):  # Use set() to show unique placeholders
        count = remaining.count(p)
        logger.info(f"   - {p} (appears {count} times)")
    logger.info("\n   Note: If placeholders appear in comments or strings, this is harmless.")
else:
    logger.info("\n[OK] No unreplaced placeholders - template is complete!")
