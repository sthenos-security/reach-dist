/* === Tabs wiring — clean v2 === */
/* BUG 20 FIX: Do NOT overwrite window.activateTab if owasp-cards.js already wrapped it.
   Instead, define the raw tab switcher and let owasp-cards.js wrap it. */
(function(){
  function rawActivateTab(name){
    // Strip 'tab-' prefix if present
    name = name.replace(/^tab-/, '');
    document.querySelectorAll('.tab').forEach(t => t.classList.toggle('active', t.dataset.tab === name));
    document.querySelectorAll('.tab-page').forEach(p => p.classList.toggle('active', p.id === `tab-${name}`));
  }

  // Tab click handler
  document.addEventListener('click', (e) => {
    const btn = e.target && e.target.closest ? e.target.closest('.tab') : null;
    if (!btn) return;
    const name = btn.dataset.tab;
    // Use the global activateTab (which may be wrapped by owasp-cards.js)
    if (typeof window.activateTab === 'function') {
      window.activateTab(name);
    } else {
      rawActivateTab(name);
    }
  });

  // BUG 20 FIX: Only set window.activateTab if it hasn't been set/wrapped already
  if (typeof window.activateTab !== 'function') {
    window.activateTab = rawActivateTab;
  }
  // Expose raw version for owasp-cards.js to use when wrapping
  window._rawActivateTab = rawActivateTab;
})();
