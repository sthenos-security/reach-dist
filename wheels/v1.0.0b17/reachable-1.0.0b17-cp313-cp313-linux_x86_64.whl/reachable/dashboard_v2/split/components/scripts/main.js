// dashboardData is injected by html_builder.py via window.dashboardData before this script loads
// Use window.dashboardData directly — never redeclare with var (hoisting shadows the global)

    // === HTML ESCAPING UTILITY ===
    function escapeHtml(str) {
        if (!str) return '';
        return String(str)
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;');
    }

let allIssues = [];
    let currentFilteredIssues = [];

    // === NULL-SAFE DOM HELPERS (added v4.6.4 for robustness) ===
    function setEl(id, val) {
        const el = document.getElementById(id);
        if (el) el.textContent = val;
    }
    function setHTML(id, val) {
        const el = document.getElementById(id);
        if (el) el.innerHTML = val;
    }
    function setVal(id, val) {
        const el = document.getElementById(id);
        if (el) el.value = val;
    }
    function setStyle(id, prop, val) {
        const el = document.getElementById(id);
        if (el) el.style[prop] = val;
    }
    function addClass(id, cls) {
        const el = document.getElementById(id);
        if (el) el.classList.add(cls);
    }
    function removeClass(id, cls) {
        const el = document.getElementById(id);
        if (el) el.classList.remove(cls);
    }
    // === END NULL-SAFE DOM HELPERS ===

    // === STRING UTILITIES ===
    function escapeHtml(str) {
        if (!str) return '';
        return String(str).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
    }
    // === END STRING UTILITIES ===

    // === CALL GRAPH VISUALIZATION ===

    // T-CG11: PathNode kind → icon + colour map
    const PATH_NODE_STYLE = {
        'entry':       { icon: '🌐', color: '#66BB6A', label: 'HTTP Entrypoint' },
        'app':         { icon: '⚙️', color: '#94a3b8', label: 'App Function'    },
        'transformer': { icon: '🔄', color: '#60a5fa', label: 'Transformer'     },
        'sink_vuln':   { icon: '⚠️', color: '#f59e0b', label: 'Vulnerable Call' },
        'sink_danger': { icon: '💀', color: '#EF5350', label: 'Dangerous Sink'  },
        'sink_secret': { icon: '🔑', color: '#f97316', label: 'Secret Sink'     },
        'sink_data':   { icon: '📤', color: '#a78bfa', label: 'Data Sink'       },
        'source_pii':  { icon: '🧬', color: '#e879f9', label: 'PII Source'      },
        'guard':       { icon: '🛡️', color: '#10b981', label: 'Security Guard'  },
        'stdlib':      { icon: '📦', color: '#475569', label: 'Stdlib'          },
        'boundary':    { icon: '🚧', color: '#fbbf24', label: 'OS Boundary'     },
        'via':         { icon: '↪️', color: '#64748b', label: 'Via Package'     },
        'llm_output':  { icon: '🤖', color: '#a78bfa', label: 'LLM Output'      },
        'agent':       { icon: '🕵️', color: '#f472b6', label: 'Agent'           },
        'mcp_server':  { icon: '🔌', color: '#38bdf8', label: 'MCP Server'      },
        'mcp_tool':    { icon: '🔧', color: '#34d399', label: 'MCP Tool'        },
    };

    // ── Endpoint inference from entry node labels ──────────────────────────
    function _inferEndpoint(node) {
        if (!node) return null;
        // Prefer backend-provided route/http_method when available
        if (node.route || node.http_method) {
            return { method: (node.http_method || 'HTTP').toUpperCase(), route: node.route || '/*' };
        }
        var label = (node.label || '').toLowerCase();
        var file = (node.file || '').toLowerCase();
        // Extract HTTP method from label patterns
        var methods = ['get','post','put','delete','patch'];
        var method = '';
        for (var m = 0; m < methods.length; m++) {
            var meth = methods[m];
            if (label.endsWith('.' + meth) || label.endsWith('_' + meth) ||
                label === meth || label.startsWith(meth + '_') ||
                label.includes('.' + meth + '_')) {
                method = meth.toUpperCase();
                break;
            }
        }
        // Infer route from function/file path
        var route = '';
        var parts = (node.label || '').split('.');
        var funcName = parts[parts.length - 1] || '';
        // Strip common prefixes to get resource name
        var resource = funcName.replace(/^(handle|process|do|get|post|put|delete|patch|create|update|list|serve|api_)/i, '');
        if (resource && resource !== funcName) {
            route = '/' + resource.replace(/_/g, '/').replace(/([A-Z])/g, function(m) { return '/' + m.toLowerCase(); }).replace(/^\//, '').replace(/\/\//g, '/');
        }
        // Try to get route from file path (e.g., routes/users.py → /users)
        if (!route && file) {
            var fileMatch = file.match(/(?:routes|views|handlers|api|endpoints)\/([^.]+)/i);
            if (fileMatch) route = '/' + fileMatch[1].replace(/_/g, '/');
        }
        if (!method && !route) return null;
        return { method: method || 'HTTP', route: route || '/*' };
    }

    // ── Embellished node card renderer ─────────────────────────────────────
    function _renderNodeCard(node, i, total, isEntry, isSink) {
        var kind = (node.kind || 'app').toLowerCase();
        var style = PATH_NODE_STYLE[kind] || { icon: '•', color: '#94a3b8', label: kind };
        var rawLabel = node.label || node.function || 'unknown';
        var displayLabel = _formatGoLabel(rawLabel);
        var version = node.version || '';
        var versionHtml = version ? ' <span style="font-size:10px;color:#64748b;">' + formatGoVersion(version) + '</span>' : '';
        var file = node.file ? node.file.split('/').slice(-2).join('/') : '';
        var line = node.line ? ':' + node.line : '';
        var tooltip = style.label + (file ? ' | ' + file + line : '');
        var indent = i * 10;

        // Node card background based on type
        var cardBg = 'transparent';
        var cardBorder = '#1e293b';
        var labelWeight = '400';
        if (isEntry) { cardBg = 'rgba(102,187,106,0.06)'; cardBorder = '#66BB6A44'; labelWeight = '700'; }
        else if (isSink) { cardBg = kind === 'sink_danger' ? 'rgba(239,83,80,0.06)' : 'rgba(245,158,11,0.06)'; cardBorder = style.color + '44'; labelWeight = '700'; }
        else if (kind === 'guard') { cardBg = 'rgba(16,185,129,0.06)'; cardBorder = '#10b98144'; }
        else if (kind === 'boundary') { cardBg = 'rgba(251,191,36,0.06)'; cardBorder = '#fbbf2444'; }

        // Endpoint badge for entry nodes
        var endpointBadge = '';
        if (isEntry) {
            var ep = _inferEndpoint(node);
            if (ep) {
                var methodColors = { GET:'#66BB6A', POST:'#42A5F5', PUT:'#f59e0b', DELETE:'#EF5350', PATCH:'#a78bfa', HTTP:'#94a3b8' };
                var mc = methodColors[ep.method] || '#94a3b8';
                endpointBadge = '<div style="margin-top:4px;display:flex;align-items:center;gap:6px;">'
                    + '<span style="font-size:9px;font-weight:800;color:' + mc + ';background:' + mc + '18;padding:1px 5px;border-radius:3px;font-family:monospace;letter-spacing:0.5px;">' + ep.method + '</span>'
                    + '<span style="font-size:10px;color:#94a3b8;font-family:monospace;">' + ep.route + '</span>'
                    + '<span style="font-size:8px;font-weight:700;color:#f59e0b;background:rgba(245,158,11,0.12);padding:1px 5px;border-radius:3px;text-transform:uppercase;letter-spacing:1px;">EXPOSED</span>'
                    + '</div>';
            } else {
                // Detect non-HTTP entrypoint types from label/kind
                var _entryLabel = (node.label || '').toLowerCase();
                var _epType = 'ENTRYPOINT'; var _epColor = '#66BB6A';
                if (/cron|timer|schedule|periodic|tick/.test(_entryLabel)) { _epType = 'SCHEDULED'; _epColor = '#fbbf24'; }
                else if (/internal|grpc|rpc|worker|queue|consumer|subscriber/.test(_entryLabel)) { _epType = 'INTERNAL'; _epColor = '#60a5fa'; }
                else if (kind === 'agent') { _epType = 'AGENT'; _epColor = '#f472b6'; }
                else if (kind === 'mcp_server' || kind === 'mcp_tool') { _epType = 'MCP'; _epColor = '#38bdf8'; }
                endpointBadge = '<div style="margin-top:2px;"><span style="font-size:8px;font-weight:700;color:' + _epColor + ';background:' + _epColor + '1e;padding:1px 5px;border-radius:3px;text-transform:uppercase;letter-spacing:1px;">' + _epType + '</span></div>';
            }
        }

        // Sink badge
        var sinkBadge = '';
        if (isSink && (kind === 'sink_danger' || kind === 'sink_vuln')) {
            var sinkColor = kind === 'sink_danger' ? '#EF5350' : '#f59e0b';
            var sinkLabel = kind === 'sink_danger' ? 'DANGER SINK' : 'VULNERABLE';
            sinkBadge = '<span style="font-size:8px;font-weight:700;color:' + sinkColor + ';background:' + sinkColor + '18;padding:1px 5px;border-radius:3px;text-transform:uppercase;letter-spacing:1px;margin-left:6px;">' + sinkLabel + '</span>';
        }

        // Kind badge for intermediate nodes
        var kindBadge = '';
        if (!isEntry && !isSink && kind !== 'app') {
            kindBadge = '<span style="font-size:8px;font-weight:600;color:' + style.color + ';background:' + style.color + '15;padding:1px 4px;border-radius:3px;margin-left:6px;">' + style.label + '</span>';
        }

        var html = '<div style="margin-left:' + indent + 'px;display:flex;align-items:flex-start;gap:10px;padding:6px 10px;background:' + cardBg + ';border:1px solid ' + cardBorder + ';border-radius:6px;margin-bottom:2px;">'
            + '<span title="' + tooltip + '" style="font-size:14px;line-height:1.3;flex-shrink:0;margin-top:1px;">' + style.icon + '</span>'
            + '<div style="min-width:0;flex:1;">'
            + '<div style="display:flex;align-items:center;flex-wrap:wrap;">'
            + '<span title="' + rawLabel + '" style="color:' + style.color + ';font-weight:' + labelWeight + ';font-size:11px;font-family:monospace;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:380px;">' + displayLabel + versionHtml + '</span>'
            + sinkBadge + kindBadge
            + '</div>'
            + (file ? '<div style="color:#475569;font-size:9px;margin-top:2px;font-family:monospace;">' + file + line + '</div>' : '')
            + endpointBadge
            + '</div>'
            + '</div>';

        // Connector to next node
        if (i < total - 1) {
            var connColor = isSink ? (style.color + '60') : '#1e3a4a';
            html += '<div style="margin-left:' + (indent + 16) + 'px;display:flex;align-items:center;gap:4px;padding:0 0 0 2px;">'
                + '<div style="width:1px;height:10px;background:' + connColor + ';"></div>'
                + '<span style="color:#334155;font-size:8px;">▼</span>'
                + '</div>';
        }
        return html;
    }

    // T-CG11: Human-readable reachability reason text for tooltip
    const REACH_REASON_TEXT = {
        'file_not_read':        'File exists but is never read in any code path',
        'file_read_confirmed':  'File is read at runtime via os.ReadFile() / open()',
        'dev_dependency':       'devDependency — not included in production bundle',
        'no_call_path':         'No reachable call path found from any entrypoint',
        'entrypoint_reached':   'Reachable from HTTP entrypoint via call graph BFS',
        'cross_file_bfs':       'Reachable — confirmed by cross-file BFS analysis',
    };

    // T-CG22: Semgrep rule ID pattern — single-node paths matching this are suppressed
    const RULE_ID_PATTERN = /^[a-z][a-z0-9]*(?:[\-\.][a-z0-9]+){1,}$/i;
    function _isRuleIdNode(label) {
        if (!label) return false;
        if (label.includes('(') || label.includes('/') || label.includes(' ')) return false;
        return RULE_ID_PATTERN.test(label);
    }

    // T-CG23: Go node type labeling helpers
    const GO_MODULE_RE = /^(?:golang\.org|github\.com|gopkg\.in|google\.golang\.org|go\.uber\.org|go\.opencensus\.io|cloud\.google\.com)/;
    function _classifyGoNode(label) {
        if (!label) return { type: 'app', short: label, badge: '' };
        if (GO_MODULE_RE.test(label)) return { type: 'mod', short: label.split('/').slice(-1)[0], badge: '<span title="Go module import path" style="font-size:9px;background:rgba(99,102,241,0.2);color:#818cf8;padding:1px 4px;border-radius:3px;margin-left:4px;font-family:sans-serif;font-weight:600;">mod</span>' };
        const parts = label.split('.');
        if (parts.length >= 4) {
            const last = parts[parts.length - 1];
            const secondLast = parts[parts.length - 2];
            const isMethod = /^[A-Z]/.test(last) || /^[A-Z]/.test(secondLast);
            if (isMethod) {
                const short = parts.slice(-2).join('.') + (label.includes('(') ? '' : '()');
                return { type: 'fn', short, badge: '<span title="Function / method" style="font-size:9px;background:rgba(16,185,129,0.2);color:#34d399;padding:1px 4px;border-radius:3px;margin-left:4px;font-family:sans-serif;font-weight:600;">fn</span>' };
            }
            return { type: 'pkg', short: parts.slice(-2).join('.'), badge: '<span title="Package" style="font-size:9px;background:rgba(59,130,246,0.2);color:#93c5fd;padding:1px 4px;border-radius:3px;margin-left:4px;font-family:sans-serif;font-weight:600;">pkg</span>' };
        }
        if (parts.length === 1 && /^[A-Z]/.test(label[0])) {
            return { type: 'fn', short: label + (label.includes('(') ? '' : '()'), badge: '' };
        }
        return { type: 'app', short: label, badge: '' };
    }
    function _formatGoLabel(raw) {
        const { short, badge } = _classifyGoNode(raw);
        return short + badge;
    }

    // T-CG24: Go pseudo-version formatting
    const PSEUDO_VER_RE = /^v0\.0\.0-(\d{4})(\d{2})(\d{2})\d{6}-([0-9a-f]{12})$/;
    function formatGoVersion(ver) {
        if (!ver) return ver;
        const m = PSEUDO_VER_RE.exec(ver);
        if (!m) return ver;
        const date = m[1] + '-' + m[2] + '-' + m[3];
        const hash = m[4].slice(0, 7);
        return 'v0.0.0 <span title="Commit-pinned — no release tag" style="font-size:9px;background:rgba(245,158,11,0.15);color:#f59e0b;padding:1px 4px;border-radius:3px;cursor:help;">⚠ ' + hash + ' · ' + date + '</span>';
    }

    // T-CG30: Global counter for unique accordion IDs across all findings
    let _cgVizCounter = 0;

    function buildCallGraphViz(issue) {
        // T-CG28: call_paths_v2 is the ONLY path source (v2 authoritative)
        // Shape from DB: List[List[PathNode]]  (multiple paths, each a list of typed nodes)
        const v2 = issue.call_paths_v2;
        if (!v2 || !Array.isArray(v2) || v2.length === 0) return '';

        // Detect shape: [[{kind,label,...}, ...], [...]]  vs  [{kind,label,...}, ...]
        const isMultiPath = Array.isArray(v2[0]);
        const paths = isMultiPath ? v2.filter(p => Array.isArray(p) && p.length > 0) : [v2];
        if (paths.length === 0) return '';

        // T-CG22: Suppress single-node paths that are just a Semgrep rule ID
        if (paths.length === 1 && paths[0].length === 1 && _isRuleIdNode(paths[0][0].label || '')) return '';

        // Single path: use typed PathNode renderer directly
        if (paths.length === 1) {
            return buildPathNodeViz(paths[0], issue.reachability_reason);
        }

        // Multi-path: accordion with per-path typed rendering
        // T-CG30: unique prefix per call so multiple findings don't collide
        const _uid = _cgVizCounter++;
        let html = '<div style="background:#080d17;border-radius:8px;padding:16px;margin-top:12px;border:1px solid #1e3a4a;">';
        let header = '📍 Call Paths';
        if (issue.reachability_reason) {
            const reasonText = REACH_REASON_TEXT[issue.reachability_reason] || issue.reachability_reason;
            header += ' <span title="' + reasonText + '" style="cursor:help;opacity:0.6;">ℹ️</span>';
        }
        html += '<div style="padding:0 0 10px 0;display:flex;align-items:center;justify-content:space-between;">';
        html += '<div style="color:#10b981;font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:1.5px;">' + header + '</div>';
        html += '<div style="font-size:10px;background:rgba(16,185,129,0.08);color:#10b981;padding:2px 10px;border-radius:10px;font-weight:600;">' + paths.length + ' execution paths</div>';
        html += '</div>';

        paths.forEach(function(pathNodes, pidx) {
            // Entry label from first node
            var entryLabel = (pathNodes[0] && pathNodes[0].label) || 'Path';
            var entryShort = entryLabel.split('.').slice(-2).join('.');
            // Last node
            var sinkLabel = (pathNodes[pathNodes.length - 1] && pathNodes[pathNodes.length - 1].label) || '';
            var sinkShort = sinkLabel.split('/').slice(-1)[0];

            html += '<div style="border-top:1px solid #1e293b;">';
            html += '<div style="padding:8px 0;display:flex;align-items:center;gap:8px;cursor:pointer;" onclick="var b=document.getElementById(\'cpv2_' + _uid + '_b' + pidx + '\');var a=document.getElementById(\'cpv2_' + _uid + '_a' + pidx + '\');if(b.style.display===\'none\'){b.style.display=\'block\';a.textContent=\'\u25BC\';}else{b.style.display=\'none\';a.textContent=\'\u25B6\';}">'
                + '<span id="cpv2_' + _uid + '_a' + pidx + '" style="color:#64748b;font-size:10px;">' + (pidx === 0 ? '\u25BC' : '\u25B6') + '</span>'
                + '<span style="color:#94a3b8;font-size:11px;font-weight:600;">P' + (pidx+1) + '</span>'
                + '<span style="color:#cbd5e1;font-size:11px;font-family:monospace;">' + entryShort + ' \u2192 ' + sinkShort + '</span>'
                + '<span style="color:#475569;font-size:10px;">' + pathNodes.length + ' hops</span>'
                + '</div>';
            html += '<div id="cpv2_' + _uid + '_b' + pidx + '" style="display:' + (pidx === 0 ? 'block' : 'none') + ';padding:0 0 8px 16px;">';

            // Render each node in this path using embellished card renderer
            pathNodes.forEach(function(node, i) {
                html += _renderNodeCard(node, i, pathNodes.length, i === 0, i === pathNodes.length - 1);
            });

            html += '</div></div>';
        });

        html += '</div>';
        return html;
    }

    // T-CG11: Typed PathNode renderer — uses NodeKind for icons + colours
    function buildPathNodeViz(nodes, reachabilityReason) {
        const visible = nodes.filter(function(n, i) {
            if (!n || !n.kind) return true;
            if (n.kind === 'stdlib' && i > 0 && i < nodes.length - 1) return false;
            return true;
        });
        if (visible.length === 0) return '';

        // Detect entry and sink nodes for attack surface display
        var firstKind = (visible[0] && visible[0].kind || '').toLowerCase();
        var lastKind = (visible[visible.length-1] && visible[visible.length-1].kind || '').toLowerCase();
        var hasEntry = firstKind === 'entry' || firstKind === 'agent' || firstKind === 'mcp_server';
        var hasSink = lastKind.startsWith('sink');

        // Attack surface banner when we have entry/agent/mcp → sink flow
        var surfaceBanner = '';
        if ((hasEntry || firstKind === 'app') && hasSink) {
            var ep = _inferEndpoint(visible[0]);
            var sinkStyle = PATH_NODE_STYLE[lastKind] || { icon: '⚠️', color: '#f59e0b', label: 'Sink' };
            // Determine entrypoint display based on kind
            var epText, bannerLabel, bannerColor;
            var _firstLabel = (visible[0].label || '').toLowerCase();
            if (ep) {
                epText = '<span style="font-family:monospace;color:#66BB6A;font-weight:700;">' + ep.method + ' ' + ep.route + '</span>';
                bannerLabel = 'ATTACK SURFACE'; bannerColor = '#f59e0b';
            } else if (firstKind === 'agent') {
                epText = '<span style="color:#f472b6;font-weight:700;">🕵️ Agent</span>';
                bannerLabel = 'AGENT ATTACK SURFACE'; bannerColor = '#f472b6';
            } else if (firstKind === 'mcp_server') {
                epText = '<span style="color:#38bdf8;font-weight:700;">🔌 MCP Server</span>';
                bannerLabel = 'MCP ATTACK SURFACE'; bannerColor = '#38bdf8';
            } else if (/cron|timer|schedule|periodic/.test(_firstLabel)) {
                epText = '<span style="color:#fbbf24;font-weight:700;">⏰ Scheduled Task</span>';
                bannerLabel = 'TIMED EXECUTION'; bannerColor = '#fbbf24';
            } else if (/internal|grpc|rpc|worker|queue/.test(_firstLabel)) {
                epText = '<span style="color:#60a5fa;font-weight:700;">🔒 Internal Service</span>';
                bannerLabel = 'INTERNAL SURFACE'; bannerColor = '#60a5fa';
            } else {
                epText = '<span style="color:#66BB6A;">entrypoint</span>';
                bannerLabel = 'ATTACK SURFACE'; bannerColor = '#f59e0b';
            }
            surfaceBanner = '<div style="display:flex;align-items:center;gap:10px;padding:8px 12px;background:' + bannerColor + '0a;border:1px solid ' + bannerColor + '26;border-radius:6px;margin-bottom:10px;">'
                + '<span style="font-size:8px;font-weight:800;color:' + bannerColor + ';background:' + bannerColor + '26;padding:2px 6px;border-radius:3px;text-transform:uppercase;letter-spacing:1.5px;">' + bannerLabel + '</span>'
                + '<span style="color:#475569;font-size:11px;">' + epText + ' \u2192 ' + sinkStyle.icon + ' <span style="color:' + sinkStyle.color + ';">' + sinkStyle.label + '</span></span>'
                + '<span style="color:#334155;font-size:10px;">(' + visible.length + ' hops)</span>'
                + '</div>';
        }

        let html = '<div style="background:#080d17;border-radius:8px;padding:16px;margin-top:12px;border:1px solid #1e3a4a;">';
        let headerLabel = '\ud83d\udccd Call Path';
        if (reachabilityReason) {
            const reasonText = REACH_REASON_TEXT[reachabilityReason] || reachabilityReason;
            headerLabel += ' <span title="' + reasonText + '" style="cursor:help;opacity:0.6;">\u2139\ufe0f</span>';
        }
        html += '<div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:10px;">'
            + '<div style="color:#10b981;font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:1.5px;">' + headerLabel + '</div>'
            + '<div style="font-size:10px;background:rgba(16,185,129,0.08);color:#10b981;padding:2px 10px;border-radius:10px;font-weight:600;">' + visible.length + ' hops</div>'
            + '</div>';
        html += surfaceBanner;

        visible.forEach(function(node, i) {
            html += _renderNodeCard(node, i, visible.length, i === 0, i === visible.length - 1);
        });

        html += '</div>';
        return html;
    }

    // Add call graph to issue detail expansion
    function showIssueDetail(issue) {
        const detailHTML = buildCallGraphViz(issue);
        const detailEl = document.getElementById('issueDetail_' + issue.id);
        if (detailEl) {
            detailEl.innerHTML = detailHTML;
            detailEl.style.display = 'block';
        }
    }
    

        
        // GRC SLA timelines (in hours)
        const GRC_SLA_TIMELINES = {
            'default':          { CRITICAL: 24,  HIGH: 168,  MEDIUM: 720,  LOW: 2160 },
            // International
            'iso27001':         { CRITICAL: 72,  HIGH: 720,  MEDIUM: 2160, LOW: 4320 },
            'soc2':             { CRITICAL: 72,  HIGH: 720,  MEDIUM: 2160, LOW: null },
            // Industry
            'pci-dss':          { CRITICAL: 24,  HIGH: 720,  MEDIUM: 2160, LOW: 4320 },
            'hipaa':            { CRITICAL: 48,  HIGH: 720,  MEDIUM: 1440, LOW: 4320 },
            // US Federal
            'fedramp-high':     { CRITICAL: 24,  HIGH: 720,  MEDIUM: 2160, LOW: 4320 },
            'fedramp-moderate': { CRITICAL: 72,  HIGH: 720,  MEDIUM: 2160, LOW: 8760 },
            'fisma-high':       { CRITICAL: 24,  HIGH: 720,  MEDIUM: 2160, LOW: 4320 },
            'fisma-moderate':   { CRITICAL: 72,  HIGH: 720,  MEDIUM: 2160, LOW: 8760 },
            'nist-800-53':      { CRITICAL: 24,  HIGH: 720,  MEDIUM: 2160, LOW: 4320 },
            'nist-800-171':     { CRITICAL: 72,  HIGH: 720,  MEDIUM: 2160, LOW: 4320 },
            // Defense
            'cmmc-l2':          { CRITICAL: 72,  HIGH: 720,  MEDIUM: 2160, LOW: 4320 },
            'cmmc-l3':          { CRITICAL: 24,  HIGH: 720,  MEDIUM: 2160, LOW: 4320 },
            'disa-stig':        { CRITICAL: 24,  HIGH: 720,  MEDIUM: 2160, LOW: 4320 },
        };
        
        // Compliance framework link generators
        const complianceLinkGenerators = {
            'OWASP': (code) => {
                const mapping = {
                    // Bare codes (from scan data — no year suffix) → 2021 standard
                    // NOTE: 2025 categories have SHIFTED (A02↔A05, A03=Supply Chain new, etc.)
                    // Scan data is tagged against 2021; bare codes always resolve to 2021 URLs.
                    'A01': 'https://owasp.org/Top10/A01_2021-Broken_Access_Control/',
                    'A02': 'https://owasp.org/Top10/A02_2021-Cryptographic_Failures/',
                    'A03': 'https://owasp.org/Top10/A03_2021-Injection/',
                    'A04': 'https://owasp.org/Top10/A04_2021-Insecure_Design/',
                    'A05': 'https://owasp.org/Top10/A05_2021-Security_Misconfiguration/',
                    'A06': 'https://owasp.org/Top10/A06_2021-Vulnerable_and_Outdated_Components/',
                    'A07': 'https://owasp.org/Top10/A07_2021-Identification_and_Authentication_Failures/',
                    'A08': 'https://owasp.org/Top10/A08_2021-Software_and_Data_Integrity_Failures/',
                    'A09': 'https://owasp.org/Top10/A09_2021-Security_Logging_and_Monitoring_Failures/',
                    'A10': 'https://owasp.org/Top10/A10_2021-Server-Side_Request_Forgery_%28SSRF%29/',
                    // OWASP Top 10:2025 (current)
                    'A01:2025': 'https://owasp.org/Top10/2025/A01_2025-Broken_Access_Control/',
                    'A02:2025': 'https://owasp.org/Top10/2025/A02_2025-Security_Misconfiguration/',
                    'A03:2025': 'https://owasp.org/Top10/2025/A03_2025-Software_Supply_Chain_Failures/',
                    'A04:2025': 'https://owasp.org/Top10/2025/A04_2025-Cryptographic_Failures/',
                    'A05:2025': 'https://owasp.org/Top10/2025/A05_2025-Injection/',
                    'A06:2025': 'https://owasp.org/Top10/2025/A06_2025-Insecure_Design/',
                    'A07:2025': 'https://owasp.org/Top10/2025/A07_2025-Authentication_Failures/',
                    'A08:2025': 'https://owasp.org/Top10/2025/A08_2025-Software_or_Data_Integrity_Failures/',
                    'A09:2025': 'https://owasp.org/Top10/2025/A09_2025-Security_Logging_and_Alerting_Failures/',
                    'A10:2025': 'https://owasp.org/Top10/2025/A10_2025-Mishandling_of_Exceptional_Conditions/',
                    // OWASP Top 10:2021 (legacy — backward compat with existing scan data)
                    'A01:2021': 'https://owasp.org/Top10/A01_2021-Broken_Access_Control/',
                    'A02:2021': 'https://owasp.org/Top10/A02_2021-Cryptographic_Failures/',
                    'A03:2021': 'https://owasp.org/Top10/A03_2021-Injection/',
                    'A04:2021': 'https://owasp.org/Top10/A04_2021-Insecure_Design/',
                    'A05:2021': 'https://owasp.org/Top10/A05_2021-Security_Misconfiguration/',
                    'A06:2021': 'https://owasp.org/Top10/A06_2021-Vulnerable_and_Outdated_Components/',
                    'A07:2021': 'https://owasp.org/Top10/A07_2021-Identification_and_Authentication_Failures/',
                    'A08:2021': 'https://owasp.org/Top10/A08_2021-Software_and_Data_Integrity_Failures/',
                    'A09:2021': 'https://owasp.org/Top10/A09_2021-Security_Logging_and_Monitoring_Failures/',
                    'A10:2021': 'https://owasp.org/Top10/A10_2021-Server-Side_Request_Forgery_%28SSRF%29/',
                };
                return mapping[code] || null;
            },
            // NIST Family
            'NIST-800-53': (ctrl) => `https://csrc.nist.gov/projects/cprt/catalog#/cprt/framework/version/SP_800_53_5_1_0/home?element=${ctrl}`,
            'NIST-800-171': () => 'https://csrc.nist.gov/pubs/sp/800/171/r3/final',
            // Federal
            'FedRAMP': (ctrl) => `https://csrc.nist.gov/projects/cprt/catalog#/cprt/framework/version/SP_800_53_5_1_0/home?element=${ctrl}`,
            'FEDRAMP': (ctrl) => `https://csrc.nist.gov/projects/cprt/catalog#/cprt/framework/version/SP_800_53_5_1_0/home?element=${ctrl}`,
            'FISMA': (ctrl) => `https://csrc.nist.gov/projects/cprt/catalog#/cprt/framework/version/SP_800_53_5_1_0/home?element=${ctrl}`,
            'CISA-BOD': (bod) => `https://www.cisa.gov/news-events/directives/${bod.toLowerCase()}`,
            // Defense
            'CMMC': () => 'https://dodcio.defense.gov/CMMC/',
            'DISA-STIG': () => 'https://public.cyber.mil/stigs/',
            // Industry
            'HIPAA': (sec) => `https://www.law.cornell.edu/cfr/text/45/${sec.split('(')[0]}`,
            'PCI-DSS': () => 'https://www.pcisecuritystandards.org/document_library/',
            'SOC2': () => 'https://www.aicpa-cima.com/topic/audit-assurance/audit-and-assurance-greater-than-soc-2',
            // International
            'ISO27001': () => 'https://www.iso.org/standard/27001',
            // CWE
            'CWE-TOP-25': (cwe) => `https://cwe.mitre.org/data/definitions/${cwe.replace('CWE-', '')}.html`,
            // CWE framework key used in scan data
            'CWE': (cwe) => `https://cwe.mitre.org/data/definitions/${cwe.replace('CWE-', '')}.html`,
            // OWASP LLM Top 10
            'OWASP_LLM': (cat) => {
                const llmUrls = {
                    LLM01:'https://genai.owasp.org/llmrisk/llm01-prompt-injection/',
                    LLM02:'https://genai.owasp.org/llmrisk/llm02-sensitive-information-disclosure/',
                    LLM03:'https://genai.owasp.org/llmrisk/llm03-supply-chain/',
                    LLM04:'https://genai.owasp.org/llmrisk/llm04-data-and-model-poisoning/',
                    LLM05:'https://genai.owasp.org/llmrisk/llm05-improper-output-handling/',
                    LLM06:'https://genai.owasp.org/llmrisk/llm06-excessive-agency/',
                    LLM07:'https://genai.owasp.org/llmrisk/llm07-system-prompt-leakage/',
                    LLM08:'https://genai.owasp.org/llmrisk/llm08-vector-and-embedding-weaknesses/',
                    LLM09:'https://genai.owasp.org/llmrisk/llm09-misinformation/',
                    LLM10:'https://genai.owasp.org/llmrisk/llm10-unbounded-consumption/',
                    MCP:  'https://genai.owasp.org/llmrisk/llm06-excessive-agency/',
                    AGENTIC: 'https://genai.owasp.org/initiatives/agentic-security-initiative/',
                };
                return llmUrls[cat] || 'https://genai.owasp.org/';
            },
        };
        
        function getComplianceLink(framework, code) {
            const gen = complianceLinkGenerators[framework];
            return gen ? gen(code) : null;
        }
        
        function renderComplianceTag(framework, codes) {
            const codeArr = Array.isArray(codes) ? codes : [codes];
            return codeArr.map(code => {
                const link = getComplianceLink(framework, code);
                if (link) {
                    return `<a href="${link}" class="compliance-tag compliance-link" target="_blank" title="View ${framework} ${code}">${framework}: ${code}</a>`;
                }
                return `<span class="compliance-tag">${framework}: ${code}</span>`;
            }).join('');
        }
        
        // Normalize Semgrep severity (ERROR→CRITICAL, WARNING→HIGH)
        // P2.20-A6 FIX: Removed INFO→LOW mapping
        function normalizeSeverity(sev) {
            if (!sev || sev === 'Unknown') return sev || 'Unknown';  // Preserve Unknown
            const s = sev.toUpperCase();
            if (s === 'ERROR') return 'CRITICAL';
            if (s === 'WARNING') return 'HIGH';
            return s;
        }

        // v4.6.0: Normalize issue types for consistent UI buckets
        // P2.20 Fix 4: Use "Config" terminology (database uses lowercase 'config')
        function normalizeIssueType(typeRaw) {
            const t = String(typeRaw || '').trim().toUpperCase();

            // Config normalization (database uses 'config')
            if (t === 'CONFIG' || t === 'IAC' || t === 'INFRA' || t === 'INFRASTRUCTURE') return 'Config';

            // Keep existing canonical types stable
            if (t === 'CVE') return 'CVE';
            if (t === 'CWE') return 'CWE';
            if (t === 'SECRET' || t === 'SECRETS') return 'SECRET';
            if (t === 'MALWARE') return 'MALWARE';
            if (t === 'SUSPICIOUS') return 'SUSPICIOUS';
            if (t === 'PHANTOM') return 'PHANTOM';
            if (t === 'THREATINTEL') return 'THREATINTEL';

            // Default: preserve original value (but avoid empty)
            return typeRaw || 'UNKNOWN';
        }
        
        function fmt(n) { return (n || 0).toLocaleString(); }
        function pctFiltered(raw, reach) { 
            if (!raw || raw === 0) return ''; 
            const pct = ((raw - reach) / raw * 100).toFixed(1);
            return `(${pct}% filtered)`; 
        }
        
        // v4.4.6: Simplified SLA - just show suggested remediation time, no countdown
        // P2.20 Fix 2: Add Unknown severity handling
        function getSlaInfo(severity) {
            const slaMap = {
                'CRITICAL': { display: '24 hours', class: 'sla-critical' },
                'HIGH': { display: '7 days', class: 'sla-high' },
                'MEDIUM': { display: '30 days', class: 'sla-medium' },
                'LOW': { display: '90 days', class: 'sla-low' },
                'Unknown': { display: 'ASSESS', class: 'sla-unknown' }  // NEW: Grype unknown severity
            };
            return slaMap[severity] || { display: 'N/A', class: '' };
        }
        
        // P2.20 Fix 6: Handle Config variants in reachability check
        function getReachabilityState(finding) {
            // Check explicit reachability_state first (new scans have this set correctly)
            if (finding.reachability_state) return finding.reachability_state;
            // Fallback for old data.json: CONFIG type = not_applicable plane
            if (finding.type === 'Config' || finding.type === 'CONFIG' || finding.type === 'config') return 'not_applicable';
            if (finding.is_reachable === true) return 'reachable';
            if (finding.is_reachable === false) return 'not_reachable';
            return 'unknown';
        }
        
        function renderDashboard() {
            const d = dashboardData;
            setEl('versionDisplay', `v${d.version || '4.5.8'}`);
            
            const scan = d.scan || {};
            
            // Populate exec header (v4.5.9: Enhanced repo/commit panel)
            const execRepoEl = document.getElementById('execRepo');
            const execBranchEl = document.getElementById('execBranch');
            const execCommitEl = document.getElementById('execCommit');
            const execDateEl = document.getElementById('execDate');
            const execGithubLink = document.getElementById('execGithubLink');
            const scanDateEl = document.getElementById('scanDate');
            const scanFirstEl = document.getElementById('scanFirst');
            const scanNumberEl = document.getElementById('scanNumber');
            
            // Repo name (just the name, not the full display)
            if (execRepoEl) execRepoEl.textContent = scan.repository || 'Unknown';
            
            // Branch badge
            if (execBranchEl) execBranchEl.textContent = scan.branch || 'main';
            
            // Commit hash
            if (execCommitEl) execCommitEl.textContent = scan.commit ? scan.commit.substring(0, 8) : '';
            
            // Date
            if (execDateEl) execDateEl.textContent = scan.date || new Date().toLocaleDateString();
            
            // GitHub link (show/hide based on availability)
            if (execGithubLink) {
                if (scan.github_url) {
                    execGithubLink.href = scan.github_url;
                    execGithubLink.classList.remove('hidden');
                } else {
                    execGithubLink.classList.add('hidden');
                }
            }
            
            // Scan metadata - extract from scan_history, repo_metadata, or URL path
            const repoMeta = d.repo_metadata || {};
            let scanDateStr = '-';
            let firstScanStr = '-';
            let scanNumStr = '-';
            
            // Try 1: Get scan date from scan_history (most accurate)
            if (d.scan_history && d.scan_history.length > 0) {
                const latestScan = d.scan_history[d.scan_history.length - 1];
                const firstScan = d.scan_history[0];
                if (latestScan.timestamp) {
                    scanDateStr = latestScan.timestamp.split(' ')[0];
                }
                if (firstScan.timestamp) {
                    firstScanStr = firstScan.timestamp.split(' ')[0];
                }
                scanNumStr = `#${d.scan_history.length}`;
            }
            
            // Try 2: Get from repo_metadata
            if (scanDateStr === '-' && repoMeta.first_scan) {
                firstScanStr = repoMeta.first_scan;
            }
            if (scanNumStr === '-' && repoMeta.scan_number) {
                scanNumStr = `#${repoMeta.scan_number}`;
            }
            
            // Try 3: Extract scan date from URL path (format: .../20260113-190306-xxxxx/dashboard/)
            if (scanDateStr === '-') {
                const pathMatch = window.location.pathname.match(/\/([0-9]{8})-[0-9]{6}-[a-f0-9]+\/dashboard/);
                if (pathMatch) {
                    const dateStr = pathMatch[1]; // 20260113
                    scanDateStr = `${dateStr.slice(0,4)}-${dateStr.slice(4,6)}-${dateStr.slice(6,8)}`;
                    // If no first scan, use same date (assume first scan)
                    if (firstScanStr === '-') firstScanStr = scanDateStr;
                    if (scanNumStr === '-') scanNumStr = '#1';
                }
            }
            
            // Try 4: Use today's date as last resort
            if (scanDateStr === '-') {
                scanDateStr = new Date().toISOString().split('T')[0];
            }
            
            if (scanDateEl) scanDateEl.textContent = scanDateStr;
            if (scanFirstEl) scanFirstEl.textContent = firstScanStr;
            if (scanNumberEl) scanNumberEl.textContent = scanNumStr;
            
            // Populate breakdown fields
            const scanTimeEl = document.getElementById('scanTime');
            const scanAgeEl = document.getElementById('scanAge');
            const scanFreqEl = document.getElementById('scanFreq');
            
            // Scan time (from scan_history or URL)
            if (scanTimeEl) {
                let timeStr = '';
                if (d.scan_history && d.scan_history.length > 0) {
                    const ts = d.scan_history[d.scan_history.length - 1].timestamp;
                    if (ts && ts.includes(' ')) {
                        timeStr = ts.split(' ')[1].substring(0, 5); // HH:MM
                    }
                } else {
                    // Extract from URL: 20260113-214645-xxx
                    const timeMatch = window.location.pathname.match(/[0-9]{8}-([0-9]{2})([0-9]{2})([0-9]{2})-/);
                    if (timeMatch) {
                        timeStr = `${timeMatch[1]}:${timeMatch[2]}`;
                    }
                }
                scanTimeEl.textContent = timeStr || '';
            }
            
            // Scan age (days since first scan)
            if (scanAgeEl && firstScanStr !== '-') {
                const firstDate = new Date(firstScanStr);
                const today = new Date();
                const diffDays = Math.floor((today - firstDate) / (1000 * 60 * 60 * 24));
                if (diffDays === 0) {
                    scanAgeEl.textContent = 'Today';
                } else if (diffDays === 1) {
                    scanAgeEl.textContent = '1 day ago';
                } else {
                    scanAgeEl.textContent = `${diffDays} days ago`;
                }
            }
            
            // Scan frequency hint
            if (scanFreqEl && d.scan_history && d.scan_history.length > 1) {
                // Count scans today
                const todayStr = new Date().toISOString().split('T')[0];
                const scansToday = d.scan_history.filter(s => s.timestamp && s.timestamp.startsWith(todayStr)).length;
                if (scansToday > 1) {
                    scanFreqEl.textContent = `+${scansToday - 1} today`;
                } else {
                    scanFreqEl.textContent = `of ${d.scan_history.length} total`;
                }
            } else if (scanFreqEl) {
                scanFreqEl.textContent = '';
            }
            
            // Calculate counts from issues
            const issues = d.issues || [];
            const reachable = issues.filter(f => getReachabilityState(f) === 'reachable');
            const criticalReach = reachable.filter(f => normalizeSeverity(f.severity) === 'CRITICAL').length;
            const highReach = reachable.filter(f => normalizeSeverity(f.severity) === 'HIGH').length;
            const mediumReach = reachable.filter(f => normalizeSeverity(f.severity) === 'MEDIUM').length;
            
            const m = d.metrics || {};
            
            // Malware count (v4.5.3: combined)
            const totalMalware = (m.suspicious_total || 0) + (m.malware_total || 0);
            
            // v4.6.6: UNIFIED COUNTING - Calculate totals from issues array for consistency
            // This ensures Funnel, Signal Quality table, and Trends all use the same data
            
            // Count all issues by type and reachability state from the issues array
            const countByTypeAndReach = (type, reachState) => {
                return issues.filter(f => {
                    const t = (f.type || '').toUpperCase();
                    const typeMatch = type === 'ALL' || t === type || 
                        (type === 'MALWARE' && (t === 'MALWARE' || t === 'SUSPICIOUS'));
                    if (!typeMatch) return false;
                    if (reachState === 'ALL') return true;
                    return getReachabilityState(f) === reachState;
                }).length;
            };
            
            // Get unreachable count for noise reduction calculation (matches Signal Quality table)
            const getUnreachableCount = (type) => countByTypeAndReach(type, 'not_reachable');
            const getTotalCount = (type) => countByTypeAndReach(type, 'ALL');
            
            // Calculate noise reduction as unreachable/total (same formula as Signal Quality table)
            // This is the TRUE noise reduction - issues we filtered OUT
            const calcNoiseReduction = (total, unreach) => {
                if (total === 0) return 0;
                return ((unreach / total) * 100).toFixed(1);
            };
            
            // P2.50 CRITICAL: Read ALL funnel values from d.funnel (database = single source of truth)
            // NO calculations here - just display what the database computed
            const funnel = d.funnel || {};
            const rawSignals = funnel.raw_signals || {};
            const reachSignals = funnel.reachable_signals || {};
            const unknownSignals = funnel.unknown_signals || {};
            const unreachSignals = funnel.unreachable_signals || {};
            
            // Totals from pre-computed funnel (DB = single source of truth, NO manual calculations)
            const totalAllIssues = funnel.raw_total || 0;
            const totalReachable = funnel.reachable_total || 0;
            const totalUnreachable = funnel.unreachable_total || 0;
            const totalUnknownFunnel = funnel.unknown_total || 0;
            const unifiedNoiseReduction = funnel.noise_reduction_pct || 0;
            
            // Update funnel display elements with pre-computed values
            const reductionPctEl = document.getElementById('reductionPct');
            const reductionPercentageEl = document.getElementById('reductionPercentage');
            const reductionDetailEl = document.getElementById('reductionDetail');
            if (reductionPctEl) reductionPctEl.textContent = `${unifiedNoiseReduction}%`;
            if (reductionPercentageEl) reductionPercentageEl.textContent = `${unifiedNoiseReduction}%`;
            if (reductionDetailEl) reductionDetailEl.textContent = `${fmt(totalUnreachable)} of ${fmt(totalAllIssues)} issues filtered as unreachable`;
            
            // Funnel - Raw signals (read from d.funnel.raw_signals)
            const rawCves = rawSignals.CVE || 0;
            const rawSecrets = rawSignals.SECRET || 0;
            const rawCwe = rawSignals.CWE || 0;
            const rawConfig = rawSignals.CONFIG || 0;
            const rawAi = rawSignals.AI || 0;
            const rawDlp = rawSignals.DLP || 0;
            // Malware signals (v4.6.10: from findings table)
            const rawMalware = rawSignals.MALWARE || 0;
            const rawSuspicious = rawSignals.SUSPICIOUS || 0;
            const rawPhantom = rawSignals.PHANTOM || 0;
            
            setEl('rawCves', fmt(rawCves));
            setEl('rawMalwareStatic', fmt(rawMalware));
            setEl('rawMalwareDynamic', fmt(rawSuspicious));
            setEl('rawSecrets', fmt(rawSecrets));
            setEl('rawCwe', fmt(rawCwe));
            setEl('rawConfig', fmt(rawConfig));
            setEl('rawPhantom', fmt(rawPhantom));
            setEl('rawAi', fmt(rawAi));
            setEl('rawDlp', fmt(rawDlp));
            setEl('rawTotal', fmt(totalAllIssues));
            
            // v4.5.0: Packages scanned (from health analysis)
            const packagesScanned = m.packages_scanned || 0;
            const packagesScannedEl = document.getElementById('packagesScanned');
            if (packagesScannedEl) packagesScannedEl.textContent = fmt(packagesScanned);
            
            // Funnel - Reachable signals (read from d.funnel.reachable_signals)
            const reachCves = reachSignals.CVE || 0;
            const reachSecrets = reachSignals.SECRET || 0;
            const reachCwe = reachSignals.CWE || 0;
            const reachConfig = reachSignals.CONFIG || 0;
            const reachAi = reachSignals.AI || 0;
            const reachDlp = reachSignals.DLP || 0;
            // Malware signals (v4.6.10)
            const reachMalware = reachSignals.MALWARE || 0;
            const reachSuspicious = reachSignals.SUSPICIOUS || 0;
            const reachPhantom = reachSignals.PHANTOM || 0;
            
            setEl('reachCves', fmt(reachCves));
            setEl('reachCvesPct', '');
            setEl('reachMalwareStatic', fmt(reachMalware));
            setEl('reachMalwareStaticPct', '');
            setEl('reachMalwareDynamic', fmt(reachSuspicious));
            setEl('reachMalwareDynamicPct', '');
            setEl('reachSecrets', fmt(reachSecrets));
            setEl('reachSecretsPct', '');
            setEl('reachCwe', fmt(reachCwe));
            setEl('reachCwePct', '');
            setEl('reachConfig', fmt(reachConfig));
            setEl('reachConfigPct', '');
            setEl('reachPhantom', fmt(reachPhantom));
            setEl('reachPhantomPct', '');
            setEl('reachAi', fmt(reachAi));
            setEl('reachAiPct', '');
            setEl('reachDlp', fmt(reachDlp));
            setEl('reachDlpPct', '');
            setEl('reachTotal', fmt(totalReachable));
            
            // DLP findings reference for other uses
            const dlpFindings = d.dlp_findings || [];
            
            // P2.60: Vulnerable package counts from pre-computed engineering panel
            const engCve = (d.engineering || {}).cve || {};
            const vulnerablePackages = engCve.vulnerable_packages || 0;
            const reachableVulnPackages = engCve.reachable_vuln_packages || 0;

            // v4.6.0: Normalize types for UI consistency (e.g., CONFIG + IAC -> IaC)
            issues.forEach(f => { f.type = normalizeIssueType(f.type); });

            allIssues = issues;
            
            // P2.50 REMOVED: AI and DLP are now added to issues[] by loaders.py
            // via _convert_ai_to_issues() and _convert_dlp_to_issues()
            // Do NOT merge them again here or they will be double-counted
            // See: loaders.py lines 70-78 (DLP) and lines 74-78 (AI)
            
            // Default sort: reachability first, then severity, then type
            // Reachable → Unknown → Not Reachable; within each group CRITICAL→HIGH→MEDIUM→LOW
            const riskOrder  = { CRITICAL: 0, HIGH: 1, MEDIUM: 2, LOW: 3, INFO: 4 };
            const typeOrder  = { CVE: 0, CWE: 1, AI: 2, DLP: 3, SECRET: 4, MALWARE: 5, SUSPICIOUS: 5, CONFIG: 6, PHANTOM: 7, THREATINTEL: 8 };
            const reachOrder = { reachable: 0, unknown: 1, not_reachable: 2, not_applicable: 3 };
            allIssues.sort((a, b) => {
                // Primary: Reachability (reachable first, then unknown, then not_reachable)
                const aReach = reachOrder[getReachabilityState(a)] ?? 3;
                const bReach = reachOrder[getReachabilityState(b)] ?? 3;
                if (aReach !== bReach) return aReach - bReach;
                // Secondary: Severity descending (CRITICAL first)
                const aRisk = riskOrder[calculateRisk(a)] ?? 5;
                const bRisk = riskOrder[calculateRisk(b)] ?? 5;
                if (aRisk !== bRisk) return aRisk - bRisk;
                // Tertiary: Type order
                const aType = typeOrder[(a.type || '').toUpperCase()] ?? 7;
                const bType = typeOrder[(b.type || '').toUpperCase()] ?? 7;
                return aType - bType;
            });
            
            renderTable(allIssues);
            
            // v4.5.12: Populate Engineering Details Panel
            populateEngineeringPanel(issues);
            
            // Enrichments Panel (v4.4.4) - v4.5.0: Fixed to show packages not CVE counts
            const enrichments = d.enrichments || {};
            setEl('enrichKev', fmt(enrichments.kev_count || m.threatintel_kev || 0));
            setEl('enrichEpss', fmt(enrichments.high_epss_count || m.threatintel_epss_high || 0));
            setEl('enrichExploits', fmt(enrichments.exploit_count || 0));
            setEl('enrichHealthCritical', fmt(enrichments.health_critical || 0));
            setEl('enrichHealthRisky', fmt(enrichments.health_risky || 0));
            setEl('enrichUnmaintained', fmt(enrichments.unmaintained || 0));
            // v4.6.10: Malware counters from metrics pipeline (consistent with log + DB)
            const msc = m.malware_static_confirmed || 0;
            const mss = m.malware_static_suspicious || 0;
            const mdc = m.malware_dynamic_confirmed || 0;
            const mds = m.malware_dynamic_suspicious || 0;
            // v5.0.2: Use union totals (avoids double-counting packages detected by both scanners)
            setEl('enrichMalwareConfirmed', fmt(m.malware_confirmed_total ?? (msc + mdc)));
            setEl('enrichMalwareSuspicious', fmt(m.malware_suspicious_total ?? (mss + mds)));
            setEl('enrichMalwareStatic', fmt(msc) + ' / ' + fmt(mss));
            setEl('enrichMalwareDynamic', fmt(mdc) + ' / ' + fmt(mds));
            setEl('enrichEntrypoints', fmt(m.entrypoints || m.entrypoints_count || enrichments.entrypoints || 0));
            setEl('enrichShadow', fmt(enrichments.shadow_imports || 0));
            setEl('enrichPhantom', fmt(rawPhantom));
            // v4.5.1: Files scanned (source files analyzed by Semgrep)
            const filesScanned = m.source_files_scanned || 0;
            const enrichFilesScannedEl = document.getElementById('enrichFilesScanned');
            if (enrichFilesScannedEl) enrichFilesScannedEl.textContent = filesScanned > 0 ? fmt(filesScanned) : 'N/A';
            
            // v4.5.0: Show packages scanned and vulnerable packages, not CVE counts
            setEl('enrichTotalDeps', fmt(packagesScanned));
            const enrichVulnPkgsEl = document.getElementById('enrichVulnPkgs');
            if (enrichVulnPkgsEl) enrichVulnPkgsEl.textContent = fmt(vulnerablePackages);
            // P2.60: Direct vs transitive from pre-computed engineering panel
            setEl('enrichDirectCves', fmt(engCve.direct || 0));
            setEl('enrichTransitiveCves', fmt(engCve.transitive || 0));
            
            // v4.5.7: Sleek Executive Summary Panel
            const lowReach = reachable.filter(f => normalizeSeverity(f.severity) === 'LOW').length;
            const malwareTotalCombined = rawMalware + rawSuspicious;  // Combined for exec summary
            const totalReachableIssues = reachable.length;
            
            // P2.60: Read pre-computed exec summary (DB = single source of truth)
            // NO filtering/counting from issues[] — loaders.py pre-computed everything
            const es = d.exec_summary || {};
            const esCrit = es.critical_by_type || {};
            const esHigh = es.high_by_type || {};
            const criticalReachAll = es.critical_total || 0;
            const highReachAll = es.high_total || 0;
            const posture = es.posture || 'low';
            const criticalCves = esCrit.cve || 0;
            const criticalSecrets = esCrit.secret || 0;
            const criticalCwes = esCrit.cwe || 0;
            const criticalMalware = esCrit.malware || 0;
            const criticalAi = esCrit.ai || 0;
            const criticalConfig = esCrit.config || 0;
            const criticalDlp = esCrit.dlp || 0;
            const highCves = esHigh.cve || 0;
            const highSecrets = esHigh.secret || 0;
            const highCwes = esHigh.cwe || 0;
            const highMalware = esHigh.malware || 0;
            const highAi = esHigh.ai || 0;
            const highConfig = esHigh.config || 0;
            const highDlp = esHigh.dlp || 0;
            
            // Update posture row
            const execPostureEl = document.getElementById('execPosture');
            const execPostureDotEl = document.getElementById('execPostureDot');
            const execPostureTextEl = document.getElementById('execPostureText');
            const postureEmojis = { critical: '🔴', high: '🟠', medium: '🟡', low: '🟢' };
            if (execPostureEl) {
                execPostureEl.className = `status ${posture}`;
            }
            if (execPostureDotEl) {
                execPostureDotEl.textContent = postureEmojis[posture] || '🔴';
            }
            if (execPostureTextEl) {
                execPostureTextEl.textContent = posture.charAt(0).toUpperCase() + posture.slice(1);
            }
            
            // P2.60: Malware alert from pre-computed exec summary
            const execPostureContextEl = document.getElementById('execPostureContext');
            if (execPostureContextEl) {
                const malPkgCount = es.malware_package_count || 0;
                if (malPkgCount > 0) {
                    execPostureContextEl.innerHTML = `<span style="color:#ff4444;font-weight:700;">⚠ ACTIVE MALWARE</span>` +
                        `<span style="color:#94a3b8;"> — ${malPkgCount} compromised package${malPkgCount > 1 ? 's' : ''}</span>`;
                } else {
                    execPostureContextEl.textContent = '(Confirmed Production Reachability)';
                }
            }
            
            // v4.5.25: Populate severity-tiered action lines
            const execCriticalLineEl = document.getElementById('execCriticalLine');
            const execCriticalCountEl = document.getElementById('execCriticalCount');
            const execCriticalBreakdownEl = document.getElementById('execCriticalBreakdown');
            const execHighLineEl = document.getElementById('execHighLine');
            const execHighCountEl = document.getElementById('execHighCount');
            const execHighBreakdownEl = document.getElementById('execHighBreakdown');
            const execNoActionLineEl = document.getElementById('execNoActionLine');
            
            // v4.5.40: Helper to build breakdown string - ALWAYS show breakdown for visibility (added AI)
            // P2.20-E1 FIX: Added config and dlp parameters
            // P2.63 FIX: Breakdown items are now plain text (no clickable links) - only the main total is clickable
            function buildBreakdown(cves, secrets, cwes, malware, ai = 0, config = 0, dlp = 0, severity = 'CRITICAL') {
                // P2.63: Plain text breakdown (no links) - clicking the main line handles filtering
                const parts = [
                    `<span style="color:#94a3b8;">🛡️ ${cves} CVE${cves !== 1 ? 's' : ''}</span>`,
                    `<span style="color:#94a3b8;">🔐 ${secrets} secret${secrets !== 1 ? 's' : ''}</span>`,
                    `<span style="color:#94a3b8;">⚠️ ${cwes} CWE${cwes !== 1 ? 's' : ''}</span>`,
                    `<span style="color:#94a3b8;">☠️ ${malware} malware</span>`,
                    `<span style="color:#94a3b8;">🤖 ${ai} AI</span>`,
                    `<span style="color:#94a3b8;">⚙️ ${config} config</span>`,
                    `<span style="color:#94a3b8;">🔒 ${dlp} DLP</span>`
                ];
                return parts.join(' · ');
            }
            
            // P2.46: Quick filter helper for clicking breakdown links
            window.applyQuickFilter = function(type, severity) {
                // Wait for DOM to be ready
                setTimeout(() => {
                    const typeFilter = document.getElementById('filterType');
                    const sevFilter = document.getElementById('filterSeverity');
                    if (typeFilter) typeFilter.value = type;
                    if (sevFilter) sevFilter.value = severity;
                    // Call applyFilters directly instead of clicking
                    if (typeof applyFilters === 'function') {
                        applyFilters();
                    }
                }, 100);
            };
            
            // CRITICAL line
            if (execCriticalLineEl && execCriticalCountEl) {
                if (criticalReachAll > 0) {
                    execCriticalCountEl.textContent = criticalReachAll;
                    execCriticalLineEl.style.display = 'block';
                    if (execCriticalBreakdownEl) {
                        execCriticalBreakdownEl.innerHTML = buildBreakdown(criticalCves, criticalSecrets, criticalCwes, criticalMalware, criticalAi, criticalConfig, criticalDlp, 'CRITICAL');
                    }
                } else {
                    execCriticalLineEl.style.display = 'none';
                }
            }
            
            // HIGH line
            if (execHighLineEl && execHighCountEl) {
                if (highReachAll > 0) {
                    execHighCountEl.textContent = highReachAll;
                    execHighLineEl.style.display = 'block';
                    if (execHighBreakdownEl) {
                        execHighBreakdownEl.innerHTML = buildBreakdown(highCves, highSecrets, highCwes, highMalware, highAi, highConfig, highDlp, 'HIGH');
                    }
                } else {
                    execHighLineEl.style.display = 'none';
                }
            }
            
            // No action line (only show if no CRITICAL or HIGH)
            if (execNoActionLineEl) {
                execNoActionLineEl.style.display = (criticalReachAll === 0 && highReachAll === 0) ? 'block' : 'none';
            }
            
            // Update signal quality - v4.5.50: Show BOTH technical and global noise reduction
            const execPctEl = document.getElementById('execReductionPct');
            const execFilterDetailEl = document.getElementById('execFilterDetail');
            
            // v4.6.6: Use UNIFIED noise reduction (same as funnel and Signal Quality table)
            // Global totals come from issues array, not metrics (ensures consistency)
            const globalReductionPct = unifiedNoiseReduction;
            
            
            if (execPctEl) execPctEl.textContent = `${globalReductionPct}%`;
            if (execFilterDetailEl) {
                // v4.6.6: Use unified totals from issues array
                const totalActionable = totalAllIssues - totalUnreachable;
                const line1 = `${fmt(totalUnreachable)} unreachable issues filtered from ${fmt(totalAllIssues)} total`;
                const line2 = `${globalReductionPct}% noise reduction · ${fmt(totalAllIssues)} total → ${fmt(totalActionable)} actionable`;
                execFilterDetailEl.innerHTML = `${line1}<br><span style="font-size: 11px; color: #86efac;">${line2}</span>`;
            }
            
            // v4.6.5: Populate Signal Quality breakdown table
            populateSignalQualityTable(d.funnel);
            
            // P2.60: Read unknown/review breakdown from pre-computed exec summary
            const esUnk = es.unknown_by_type || {};
            const unknownCves = esUnk.cve || 0;
            const unknownSecrets = esUnk.secret || 0;
            const unknownCwes = esUnk.cwe || 0;
            const unknownMalware = esUnk.malware || 0;
            const unknownAi = esUnk.ai || 0;
            const unknownConfig = esUnk.config || 0;
            const unknownDlp = esUnk.dlp || 0;
            const totalUnknown = es.unknown_total || 0;
            
            const execReviewCountEl = document.getElementById('execReviewCount');
            const execReviewLineEl = document.getElementById('execReviewLine');
            const execReviewBreakdownEl = document.getElementById('execReviewBreakdown');
            if (execReviewCountEl) execReviewCountEl.textContent = totalUnknown;
            if (execReviewLineEl) {
                execReviewLineEl.style.display = totalUnknown > 0 ? 'block' : 'none';
            }
            // Add breakdown for review items (only if multiple types)
            // P2.21: Added CONFIG and DLP to breakdown
            if (execReviewBreakdownEl && totalUnknown > 0) {
                execReviewBreakdownEl.innerHTML = buildBreakdown(unknownCves, unknownSecrets, unknownCwes, unknownMalware, unknownAi, unknownConfig, unknownDlp, '');
            }
            
            // v4.5.8: Populate footer metadata (scan count, first scan, db size)
            const footerMetaEl = document.getElementById('footerScanMeta');
            if (footerMetaEl && repoMeta.scan_number) {
                let metaLine = `Scan #${repoMeta.scan_number}`;
                if (repoMeta.first_scan) metaLine += ` · First: ${repoMeta.first_scan}`;
                if (repoMeta.db_size_display) metaLine += ` · DB: ${repoMeta.db_size_display}`;
                footerMetaEl.textContent = metaLine;
            
                const repoMetaEl = document.getElementById('repoScanMeta');
                if (repoMetaEl) repoMetaEl.textContent = metaLine;
}
        }
        
        function calculateRisk(f) {
            const sev = normalizeSeverity(f.severity);
            const reachState = getReachabilityState(f);
            
            // Malware is always high risk
            if (f.type === 'MALWARE') return 'CRITICAL';
            
            // Config has UNKNOWN reachability - use raw severity
            if (reachState === 'unknown') return sev;
            
            // Reachable findings keep severity, unreachable downgrade
            if (reachState === 'reachable') return sev;
            
            // Downgrade unreachable
            const downgrade = { CRITICAL: 'MEDIUM', HIGH: 'LOW', MEDIUM: 'LOW', LOW: 'INFO' };
            return downgrade[sev] || sev;
        }
        
        // v4.6.5: Populate Signal Quality breakdown table
        // P2.50 CRITICAL: Read from d.funnel (database = single source of truth)
        function populateSignalQualityTable(funnel) {
            const tbody = document.getElementById('signalQualityTableBody');
            if (!tbody) return;
            
            const rawSignals = funnel?.raw_signals || {};
            const reachSignals = funnel?.reachable_signals || {};
            const unknownSignals = funnel?.unknown_signals || {};
            const unreachSignals = funnel?.unreachable_signals || {};
            
            // Signal type metadata
            const signalMeta = {
                'CVE': { icon: '🛡️', label: 'CVE Vulnerabilities', color: '#fca5a5' },
                'MALWARE': { icon: '☢️', label: 'Malware (Confirmed)', color: '#FF1F1F' },
                'SUSPICIOUS': { icon: '🔍', label: 'Malware (Suspicious)', color: '#fb923c' },
                'SECRET': { icon: '🔐', label: 'Exposed Secrets', color: '#fbbf24' },
                'CWE': { icon: '⚠️', label: 'Code Weaknesses', color: '#f9a8d4' },
                'CONFIG': { icon: '⚙️', label: 'Config Issues', color: '#67e8f9', isConfig: true },
                'AI': { icon: '🤖', label: 'AI/LLM Security', color: '#38bdf8' },
                'DLP': { icon: '🔒', label: 'DLP / PII', color: '#fdba74', isDlp: true }
            };
            
            let html = '';
            let totalAll = 0, totalReach = 0, totalUnkn = 0, totalUnreach = 0;
            
            Object.entries(signalMeta).forEach(([key, meta]) => {
                const total = rawSignals[key] || 0;
                const reach = reachSignals[key] || 0;
                const unkn = unknownSignals[key] || 0;
                const unreach = unreachSignals[key] || 0;
                
                const filtered = total > 0 ? ((unreach / total) * 100).toFixed(1) : '0.0';
                const filteredDisplay = `${filtered}%`;
                
                // Special styling for config/dlp issues
                const isExcluded = meta.isConfig || meta.isDlp;
                const labelStyle = isExcluded ? 'color: #cbd5e1; opacity: 0.7;' : 'color: #cbd5e1;';
                const configNote = meta.isConfig ? ' <span style="color: #64748b; font-size: 10px; font-weight: 500;">(not in risk)</span>'
                                 : meta.isDlp   ? ' <span style="color: #64748b; font-size: 10px; font-weight: 500;">(always reachable)</span>'
                                 : '';
                
                html += `
                    <tr>
                        <td style="padding: 8px 4px; ${labelStyle}">
                            <span style="color: ${meta.color};">${meta.icon}</span> ${meta.label}${configNote}
                        </td>
                        <td style="text-align: right; padding: 8px 4px; color: #f8fafc; font-weight: 600;">${total}</td>
                        <td style="text-align: right; padding: 8px 4px; color: #42A5F5; font-weight: 600;">${reach}</td>
                        <td style="text-align: right; padding: 8px 4px; color: #78909C; font-weight: 600;">${unkn}</td>
                        <td style="text-align: right; padding: 8px 4px; color: #64748b;">${unreach}</td>
                        <td style="text-align: right; padding: 8px 4px; color: #94a3b8; font-weight: 600;">${filteredDisplay}</td>
                    </tr>
                `;
                
                // Don't count CONFIG or DLP in totals (CONFIG = not_applicable plane, DLP = always reachable)
                if (!meta.isConfig && !meta.isDlp) {
                    totalAll += total;
                    totalReach += reach;
                    totalUnkn += unkn;
                    totalUnreach += unreach;
                }
            });
            
            // Add total row (no separator)
            const totalFiltered = totalAll > 0 ? ((totalUnreach / totalAll) * 100).toFixed(1) : '0.0';
            html += `
                <tr style="font-weight: 700;">
                    <td style="padding: 10px 4px; color: #f8fafc;">Total</td>
                    <td style="text-align: right; padding: 10px 4px; color: #f8fafc;">${totalAll}</td>
                    <td style="text-align: right; padding: 10px 4px; color: #42A5F5;">${totalReach}</td>
                    <td style="text-align: right; padding: 10px 4px; color: #78909C;">${totalUnkn}</td>
                    <td style="text-align: right; padding: 10px 4px; color: #64748b;">${totalUnreach}</td>
                    <td style="text-align: right; padding: 10px 4px; color: #f8fafc;">${totalFiltered}%</td>
                </tr>
            `;
            
            tbody.innerHTML = html;
        }
        
        function renderTable(issues) {
            const tbody = document.getElementById('issuesBody');

            // --- Normalization helpers (v4.6.3) ---
            // Different scanners/DB records use different field names.
            // These helpers keep the Security Issues table consistent across CVE/CWE/AI/DLP/SECRET/CONFIG/MALWARE.
            const pickFirst = (obj, keys) => {
                for (const k of keys) {
                    const v = obj?.[k];
                    if (v === 0) return 0;
                    if (v !== undefined && v !== null && String(v).trim() !== '' && String(v).trim() !== '-') return v;
                }
                return '';
            };

            const normLine = (f) => {
                const v = pickFirst(f, ['line','line_no','line_number','start_line','line_start','begin_line']);
                const n = parseInt(v, 10);
                return Number.isFinite(n) && n > 0 ? n : null;
            };

            const normIssueId = (f, idx) => {
                const t = (f.type || '').toUpperCase();
                if (t === 'CVE') {
                    return String(pickFirst(f, ['ghsa_id','ghsa','cve_id','cve','advisory_id','id','finding_id','rule_id'])).trim() || `CVE-${idx}`;
                }
                if (t === 'CWE' || t === 'CODE') {
                    // BUG 11 fix: never use internal hex id/finding_id for CWE display
                    const cweId = pickFirst(f, ['cwe_id','cwe','policy_id','rule_id','check_id']);
                    if (cweId && !/^[0-9a-f]{8,}$/i.test(String(cweId).trim())) {
                        return String(cweId).trim();
                    }
                    return `CWE-${idx}`;
                }
                if (t === 'SECRET') {
                    return String(pickFirst(f, ['secret_type','detector','rule_id','id','finding_id','policy_id'])).trim() || `SECRET-${idx}`;
                }
                if (t === 'DLP') {
                    return String(pickFirst(f, ['dlp_id','policy_id','rule_id','id','finding_id'])).trim() || `DLP-${idx}`;
                }
                if (t === 'AI') {
                    return String(pickFirst(f, ['rule_id','ai_rule_id','policy_id','id','finding_id','owasp_llm','owasp'])).trim() || `AI-${idx}`;
                }
                if (t === 'CONFIG' || t === 'IAC') {
                    return String(pickFirst(f, ['rule_id','policy_id','id','finding_id'])).trim() || `${t}-${idx}`;
                }
                if (t === 'MALWARE' || t === 'SUSPICIOUS') {
                    return String(pickFirst(f, ['package','purl','id','finding_id','rule_id'])).trim() || `${t}-${idx}`;
                }
                return String(pickFirst(f, ['id','rule_id','policy_id','finding_id'])).trim() || `${t || 'ISSUE'}-${idx}`;
            };

            const normFilePath = (f) => pickFirst(f, ['file_path','file','path','source_file','source_path','location_path']);

            const normLocation = (f) => {
                const t = (f.type || '').toUpperCase();
                if (t === 'CVE') {
                    if (!f.is_transitive) {
                        // Direct dep → show manifest so dev knows WHERE to fix
                        return pickFirst(f, ['manifest','manifest_path','dependency_file','file','location','package','purl']) || 'Unknown package';
                    }
                    // Transitive dep → show package + version (via_package rendered separately in row template)
                    return pickFirst(f, ['package','purl','dependency','component','location']) || 'Unknown package';
                }
                if (t === 'MALWARE' || t === 'SUSPICIOUS') return pickFirst(f, ['package','purl','dependency','component']) || 'Package';
                if (t === 'DLP') {
                    return pickFirst(f, ['file_path','source_file','source_path']) || pickFirst(f, ['sink_function','sink_type']) || 'UNKNOWN';
                }
                if (t === 'SECRET') return pickFirst(f, ['file_path','source_file','source_path']) || 'Repository';
                return normFilePath(f) || pickFirst(f, ['package','purl']) || '-';
            };

            const normFixTag = (f) => pickFirst(f, ['fix_tag_display','fix_display','fix','fixed_in','upgrade_to','recommended_fix']) || '-';

            const normSlaTag = (f) => {
                // Prefer explicit display/class from DB, but accept common alternates
                const display = pickFirst(f, ['sla_display','sla','sla_text','sla_label']);
                const klass = pickFirst(f, ['sla_class','sla_level','sla_badge_class']);
                if (!display) return null;
                return `<span class="sla-tag ${klass || ''}">${display}</span>`;
            };

            if (!issues.length) {
                tbody.innerHTML = '<tr><td colspan="11" class="loading">No issues found matching filters</td></tr>';
                return;
            }
            
            // ── CVE/CWE GROUPING ────────────────────────────────────────────────
            // CVEs group by package@version (Option A) — one header row per
            //   affected package showing all its CVEs and the resolved fix version.
            // CWE/CONFIG/IAC group by issue ID (same rule at multiple locations).
            // Secrets/AI/DLP remain ungrouped.
            const _groupMap = new Map(); // groupKey → [{f, idx}]
            const _groupOrder = [];      // preserves first-seen order

            // semver-max helper used for resolved_fix badge in CVE group header
            function _semverMax(a, b) {
                if (!a) return b; if (!b) return a;
                const pa = a.split('.').map(x => parseInt(x) || 0);
                const pb = b.split('.').map(x => parseInt(x) || 0);
                for (let i = 0; i < Math.max(pa.length, pb.length); i++) {
                    if ((pb[i]||0) > (pa[i]||0)) return b;
                    if ((pa[i]||0) > (pb[i]||0)) return a;
                }
                return b;
            }

            issues.forEach((f, idx) => {
                const fType = (f.type || '').toUpperCase();
                const fId = normIssueId(f, idx);
                if (fType === 'CVE') {
                    // Group by package@version
                    const pkg = f.package || f.package_name || '';
                    const ver = f.version || f.package_version || '';
                    const pkgKey = pkg ? 'PKG:' + pkg + '@' + ver : '__solo_' + idx;
                    if (pkg) {
                        if (!_groupMap.has(pkgKey)) { _groupMap.set(pkgKey, []); _groupOrder.push(pkgKey); }
                        _groupMap.get(pkgKey).push({ f, idx });
                    } else {
                        _groupMap.set('__solo_' + idx, [{ f, idx }]);
                        _groupOrder.push('__solo_' + idx);
                    }
                } else if (['CWE','CONFIG','IAC'].includes(fType) && fId && !fId.startsWith('__')) {
                    // Group by issue ID
                    if (!_groupMap.has(fId)) { _groupMap.set(fId, []); _groupOrder.push(fId); }
                    _groupMap.get(fId).push({ f, idx });
                } else {
                    const soloKey = '__solo_' + idx;
                    _groupMap.set(soloKey, [{ f, idx }]);
                    _groupOrder.push(soloKey);
                }
            });
            // ────────────────────────────────────────────────────────────────────

            let html = '';
            _cgVizCounter = 0; // T-CG30: reset so IDs stay predictable per render
            _groupOrder.forEach((groupKey) => {
              const group = _groupMap.get(groupKey);
              const isGroup = group.length > 1;
              const groupId = `grp_${groupKey.replace(/[^a-zA-Z0-9_]/g,'_')}`;

              if (isGroup) {
                // ── GROUP HEADER ROW ──────────────────────────────────────────
                // Use the worst-risk member for the header display
                const worst = group.reduce((a, b) => {
                    const order = {CRITICAL:0,HIGH:1,MEDIUM:2,LOW:3,UNKNOWN:4};
                    const ra = order[(a.f.risk_level||a.f.severity||'UNKNOWN').toUpperCase()] ?? 4;
                    const rb = order[(b.f.risk_level||b.f.severity||'UNKNOWN').toUpperCase()] ?? 4;
                    return ra <= rb ? a : b;
                }, group[0]);
                const wf = worst.f;
                const wIdx = worst.idx;
                const wReach = getReachabilityState(wf);
                const wReachable = wReach === 'reachable';
                const wUnknown = wReach === 'unknown';
                const wRisk = (wf.risk_level || normalizeSeverity(wf.severity) || 'UNKNOWN').toUpperCase();
                const wSev = normalizeSeverity(wf.severity) || 'UNKNOWN';
                const wRiskClass = `risk-${wRisk.toLowerCase()}`;
                const wSevClass = `severity-${wSev.toLowerCase()}`;
                const wType = (wf.type || 'CWE').toUpperCase();
                const wTypeClass = `type-${wType.toLowerCase()}`;
                const wFix = normFixTag(wf);
                const wSla = normSlaTag(wf) || (wUnknown ? '<span class="sla-tag sla-unknown">ASSESS</span>' : '-');
                const wDesc = wf.description || wf.message || wf.title || 'Security issue detected';
                const allReachable = group.every(({f:gf}) => getReachabilityState(gf) === 'reachable');
                const anyReachable = group.some(({f:gf}) => getReachabilityState(gf) === 'reachable');
                const groupReachDisplay = anyReachable
                    ? '<span class="reachable-status reachable-yes" style="background:#42A5F5;color:#fff;padding:2px 8px;border-radius:3px;">Reachable</span>'
                    : '<span class="reachable-status reachable-unknown" style="background:#78909C;color:#fff;padding:2px 8px;border-radius:3px;">Unknown</span>';
                // CVE groups: show package@version as header, compute resolved fix
                const isCveGroup = groupKey.startsWith('PKG:');
                let groupLabel = groupKey;
                let resolvedFixBadge = '';
                let countBadge = '';
                if (isCveGroup) {
                    // package@version from key "PKG:express@4.18.0"
                    groupLabel = groupKey.slice(4); // strip "PKG:"
                    // Collect resolved fix from cve_group in raw_data, or semver-max of fix_versions
                    let resolvedFix = null;
                    group.forEach(({f: gf}) => {
                        try {
                            const rd = typeof gf.raw_data === 'string' ? JSON.parse(gf.raw_data) : (gf.raw_data || {});
                            const cg = rd.cve_group;
                            if (cg && cg.resolved_fix) { resolvedFix = _semverMax(resolvedFix, cg.resolved_fix); }
                            else if (gf.fix_version) { resolvedFix = _semverMax(resolvedFix, gf.fix_version); }
                        } catch(e) {}
                    });
                    const nCves = group.length;
                    countBadge = `<span style="display:inline-block;margin-left:6px;background:rgba(66,165,245,0.15);color:#42A5F5;border:1px solid rgba(66,165,245,0.3);border-radius:10px;padding:1px 8px;font-size:10px;font-weight:700;cursor:pointer;" onclick="event.stopPropagation();toggleGroup('${groupId}')">${nCves} CVE${nCves>1?'s':''} ▾</span>`;
                    if (resolvedFix) {
                        resolvedFixBadge = `<span style="display:inline-block;margin-left:6px;background:rgba(16,185,129,0.12);color:#10b981;border:1px solid rgba(16,185,129,0.3);border-radius:10px;padding:1px 8px;font-size:10px;font-weight:700;">→ ${resolvedFix}</span>`;
                    }
                } else {
                    countBadge = `<span style="display:inline-block;margin-left:6px;background:rgba(66,165,245,0.15);color:#42A5F5;border:1px solid rgba(66,165,245,0.3);border-radius:10px;padding:1px 8px;font-size:10px;font-weight:700;cursor:pointer;" onclick="event.stopPropagation();toggleGroup('${groupId}')">${group.length} locations ▾</span>`;
                }

                html += `<tr class="clickable group-header-row" data-group-id="${groupId}" data-id="${wIdx}" data-reach="${wReach}" data-risk="${wRisk}" data-type="${wf.type||''}" data-severity="${wSev}" onclick="toggleGroup('${groupId}')">
                    <td><span class="expand-arrow">▶</span></td>
                    <td><span class="risk-badge ${wRiskClass}">${wRisk}</span></td>
                    <td><span style="display:inline-flex;align-items:center;gap:4px;white-space:nowrap;"><span class="issue-type ${wTypeClass}">${wType}</span>${wf.is_transitive ? `<span title="Not in your direct dependencies" style="background:rgba(120,144,156,0.18);color:#78909C;padding:1px 5px;border-radius:3px;font-size:10px;font-weight:600;cursor:help;flex-shrink:0;">TRANSITIVE</span>` : (wType === 'CVE' ? `<span title="This package is in your direct dependencies" style="background:rgba(37,99,235,0.12);color:#60a5fa;padding:1px 5px;border-radius:3px;font-size:10px;font-weight:600;cursor:help;flex-shrink:0;">DIRECT</span>` : '')}</span></td>
                    <td><strong>${groupLabel}</strong>${countBadge}${resolvedFixBadge}</td>
                    <td>${wFix || '-'}</td>
                    <td style="color:#64748b;font-size:12px;font-style:italic;">${isCveGroup ? group.length + ' CVE' + (group.length>1?'s':'') : group.length + ' affected locations'}</td>
                    <td title="${wDesc}">${wDesc.length > 80 ? wDesc.slice(0,77)+'…' : wDesc}</td>
                    <td><span class="severity-badge ${wSevClass}">${wSev}</span></td>
                    <td>${groupReachDisplay}</td>
                    <td>${wSla}</td>
                </tr>`;
                // Group expanded detail row (hidden by default)
                html += `<tr class="expanded-row group-detail-row" data-group-detail="${groupId}" style="display:none;">
                    <td colspan="10" style="padding:0;">
                        <table style="width:100%;border-collapse:collapse;background:rgba(15,23,42,0.6);">
                            <thead><tr style="background:#0d1526;">
                                <th style="width:28px;"></th>
                                <th style="width:44px;padding:6px 8px;font-size:10px;color:#475569;font-weight:600;">RISK</th>
                                <th style="padding:6px 8px;font-size:10px;color:#475569;font-weight:600;">LOCATION</th>
                                <th style="padding:6px 8px;font-size:10px;color:#475569;font-weight:600;">FIX</th>
                                <th style="padding:6px 8px;font-size:10px;color:#475569;font-weight:600;">REACHABILITY</th>
                                <th style="padding:6px 8px;font-size:10px;color:#475569;font-weight:600;">SLA</th>
                            </tr></thead>
                            <tbody>
                            ${group.map(({f: gf, idx: gIdx}) => {
                                const gReach = getReachabilityState(gf);
                                const gRisk = (gf.risk_level || normalizeSeverity(gf.severity) || 'UNKNOWN').toUpperCase();
                                const gRiskClass = `risk-${gRisk.toLowerCase()}`;
                                const gFilePath = normFilePath(gf);
                                const gLineNo = normLine(gf);
                                const gLoc = normLocation(gf);
                                const gLocShort = gLoc.length > 60 ? '…' + gLoc.slice(-57) : gLoc;
                                const gGithubBase = dashboardData.scan?.github_url || '';
                                const gBranch = dashboardData.scan?.branch || 'main';
                                const gRepoRoot = dashboardData.scan?.repo_root || '';
                                const gCveManifest = (gf.type||'').toUpperCase()==='CVE' && !gf.is_transitive ? pickFirst(gf, ['manifest','manifest_path','dependency_file']) : null;
                                const gAbsPath = gCveManifest || gFilePath;
                                let gLocLink = null;
                                if (gAbsPath && gAbsPath !== '-' && !gAbsPath.startsWith('pkg:')) {
                                    if (gGithubBase) {
                                        let cp = gAbsPath;
                                        if (gRepoRoot && cp.startsWith(gRepoRoot)) cp = cp.slice(gRepoRoot.length);
                                        cp = cp.replace(/^\/+/,'');
                                        if (cp) gLocLink = gGithubBase + '/blob/' + gBranch + '/' + cp + (gLineNo ? '#L'+gLineNo : '');
                                    }
                                }
                                const gFix = normFixTag(gf);
                                const gSla = normSlaTag(gf) || (gReach==='unknown' ? '<span class="sla-tag sla-unknown">ASSESS</span>' : '-');
                                const gReachDisplay = gReach==='reachable'
                                    ? '<span class="reachable-status reachable-yes" style="background:#42A5F5;color:#fff;padding:2px 6px;border-radius:3px;font-size:11px;">Reachable</span>'
                                    : gReach==='unknown'
                                        ? '<span class="reachable-status reachable-unknown" style="background:#78909C;color:#fff;padding:2px 6px;border-radius:3px;font-size:11px;">Unknown</span>'
                                        : '<span style="background:#1e293b;color:#64748b;padding:2px 6px;border-radius:3px;font-size:11px;">Not Reachable</span>';
                                return `<tr class="clickable group-sub-row" data-id="${gIdx}" style="border-bottom:1px solid rgba(30,41,59,0.5);" onclick="event.stopPropagation();toggleExpand(this)">
                                    <td style="padding:6px 4px 6px 20px;"><span class="expand-arrow" style="font-size:10px;">▶</span></td>
                                    <td style="padding:6px 8px;"><span class="risk-badge ${gRiskClass}" style="font-size:10px;">${gRisk}</span></td>
                                    <td style="padding:6px 8px;font-size:12px;">${gLocLink ? '<a href="'+gLocLink+'" class="loc-link" onclick="event.stopPropagation()">'+gLocShort+'</a>' : gLocShort}${gf.is_transitive && gf.via_package ? '<br><span style="color:#64748b;font-size:10px;">via '+gf.via_package+'</span>' : ''}</td>
                                    <td style="padding:6px 8px;font-size:12px;">${gFix || '-'}</td>
                                    <td style="padding:6px 8px;">${gReachDisplay}</td>
                                    <td style="padding:6px 8px;">${gSla}</td>
                                </tr>`;
                            }).join('')}
                            </tbody>
                        </table>
                    </td>
                </tr>`;
              } // end isGroup header

              // ── PER-FINDING ROWS (solo OR sub-rows of group get full expand detail) ──
              group.forEach(({ f, idx }) => {
                {
                const reachState = getReachabilityState(f);
                const isReachable = reachState === 'reachable';
                const isUnknown = reachState === 'unknown';
                
                let rowClass = 'clickable';
                if (!isReachable && !isUnknown) rowClass += ' unreachable';
                if (isUnknown) rowClass += ' unknown-reach';
                
                const severity = normalizeSeverity(f.severity);
                const riskLevel = calculateRisk(f);
                const typeClass = `type-${(f.type || 'cwe').toLowerCase()}`;
                const sevClass = `severity-${severity.toLowerCase()}`;
                const riskClass = `risk-${riskLevel.toLowerCase()}`;
                // Normalized core fields (v4.6.3)
                const filePath = normFilePath(f);
                const lineNo = normLine(f);
                const loc = normLocation(f);
                const locShort = loc.length > 55 ? '...' + loc.substring(loc.length - 52) : loc;

                // Fix + SLA display (prefer DB fields, but accept common alternates)
                const fixTag = normFixTag(f);
                // P2.20 Fix: Show ASSESS for unknown reachability instead of "-"
                const slaTag = normSlaTag(f) || (isUnknown ? '<span class="sla-tag sla-unknown">ASSESS</span>' : '-');
                
                // Build link for file location
                const githubBase = dashboardData.scan?.github_url || '';
                const branch = dashboardData.scan?.branch || 'main';
                const repoRoot = dashboardData.scan?.repo_root || '';
                const buildLocLink = (path, line) => {
                    if (!path || path === '-' || path.startsWith('pkg:')) return null;
                    // Skip bare package names (e.g. "xlsx 0.18.5") — not a file path
                    if (/^[a-zA-Z@]/.test(path) && !path.includes('/') && !path.includes('.')) return null;
                    if (githubBase) {
                        let cleanPath = path;
                        if (repoRoot && path.startsWith(repoRoot)) cleanPath = path.substring(repoRoot.length);
                        cleanPath = cleanPath.replace(/^\/+/, '');
                        if (!cleanPath) return null;
                        let url = `${githubBase}/blob/${branch}/${cleanPath}`;
                        if (line) url += `#L${line}`;
                        return url;
                    }
                    // VSCode requires absolute paths: vscode://file/abs/path:line
                    let absPath = path;
                    if (!path.startsWith('/') && repoRoot) {
                        absPath = repoRoot.replace(/\/+$/, '') + '/' + path;
                    }
                    return `vscode://file/${absPath.replace(/^\/+/, '')}${line ? ':' + line : ''}`;
                };
                // For CVE direct deps, link to the manifest file; otherwise link to source file
                const cveManifest = (f.type || '').toUpperCase() === 'CVE' && !f.is_transitive
                    ? pickFirst(f, ['manifest','manifest_path','dependency_file'])
                    : null;
                const locLink = buildLocLink(cveManifest || filePath, lineNo);
                
                // Normalized Issue ID (v4.6.3)
                const issueId = normIssueId(f, idx);
                
                // v4.6.2: Better description fallbacks for each issue type
                let desc = f.description || f.message || f.title || '';
                if (!desc || desc === '-') {
                    if (f.type === 'CVE') desc = f.title || `Vulnerable dependency: ${f.package || 'unknown'}`;
                    else if (f.type === 'CWE') desc = f.title || 'Code vulnerability detected';
                    else if (f.type === 'SECRET') desc = f.title || 'Exposed credential/secret';
                    else if (f.type === 'MALWARE' || f.type === 'SUSPICIOUS') desc = f.title || 'Malicious package detected';
                    else if (f.type === 'AI') desc = f.owasp_name || f.title || 'AI/LLM security finding';
                    else if (f.type === 'DLP') desc = `${f.pii_type || 'Sensitive data'} flows to ${f.sink_type || 'external sink'}`;
                    else if (f.type === 'CONFIG' || f.type === 'IAC') desc = f.title || 'Configuration/infrastructure issue';
                }
                // P2.20 FIX: Ensure desc is never empty (fallback if no match above)
                if (!desc || desc.trim() === '') {
                    desc = 'Security issue detected';
                }
                
                // Reachability display
                let reachDisplay = '';
                // v4.5.11 - Show "call graph" hint for reachable items with call path
                const hasCallPath = f.call_paths_v2 && f.call_paths_v2.length > 0;
                if (isReachable) {
                    reachDisplay = hasCallPath 
                        ? '<span class="reachable-status reachable-yes" style="background:#42A5F5;color:#fff;padding:2px 8px;border-radius:3px;">Reachable</span>'
                        : '<span class="reachable-status reachable-yes" style="background:#42A5F5;color:#fff;padding:2px 8px;border-radius:3px;">Reachable</span>';
                } else if (isUnknown) {
                    reachDisplay = '<span class="reachable-status reachable-unknown" style="background:#78909C;color:#fff;padding:2px 8px;border-radius:3px;">Unknown</span> <span style="color:#94a3b8;font-size:10px;font-weight:500;"></span>';
                } else {
                    reachDisplay = '<span class="reachable-status reachable-no" style="background:#1e293b;color:#E0E0E0;padding:2px 8px;border-radius:3px;">Not Reachable</span>';
                }
                
                html += `<tr class="${rowClass}" data-id="${idx}" data-reach="${reachState}" data-risk="${riskLevel}" data-type="${f.type||''}" data-severity="${normalizeSeverity(f.severity)||''}">
                    <td><span class="expand-arrow">▶</span></td>
                    <td><span class="risk-badge ${riskClass}">${riskLevel}</span></td>
                    <td><span style="display:inline-flex;align-items:center;gap:4px;white-space:nowrap;"><span class="issue-type ${typeClass}">${f.type || 'CWE'}</span>${f.is_transitive ? `<span title="Not in your direct dependencies. Pulled in via ${f.via_package||'a transitive dependency'}" style="background:rgba(120,144,156,0.18);color:#78909C;padding:1px 5px;border-radius:3px;font-size:10px;font-weight:600;cursor:help;flex-shrink:0;">TRANSITIVE</span>` : ((f.type||'').toUpperCase()==='CVE' ? `<span title="This package is in your direct dependencies" style="background:rgba(37,99,235,0.12);color:#60a5fa;padding:1px 5px;border-radius:3px;font-size:10px;font-weight:600;cursor:help;flex-shrink:0;">DIRECT</span>` : '')}</span></td>
                    <td><strong>${issueId}</strong></td>
                    <td>${fixTag || '-'}</td>
                    <td title="${loc}${f.is_transitive && f.via_package ? ' (via ' + f.via_package + ')' : ''}">${locLink ? '<a href="' + locLink + '" class="loc-link" onclick="event.stopPropagation()">' + locShort + '</a>' : locShort}${f.is_transitive && f.via_package ? `<span style="color:#64748b;font-size:10px;"> via ${f.via_package}</span>` : ''}</td>
                    <td title="${f.description || f.message || desc}">${desc}</td>
                    <td><span class="severity-badge ${sevClass}">${severity}</span></td>
                    <td>${reachDisplay}</td>
                    <td>${slaTag}</td>
                </tr>`;
                
                // Expanded row with remediation details
                const rem = f.remediation || {};
                const steps = rem.steps || [];
                const refs = rem.references || [];
                const compMapping = f.compliance_mapping || {};
                const evidence = f.evidence || {};
                
                html += `<tr class="expanded-row" data-parent="${idx}">
                    <td colspan="10">
                        <div class="expanded-content">
                            <div class="remediation-grid">
                                <div class="remediation-block">
                                    <div class="remediation-title">🔧 Remediation</div>
                                    <div class="remediation-content">
                                        <strong>Action:</strong> ${(() => {
                                            if (rem.action) return rem.action;
                                            const defaults = {
                                              CVE:       'Upgrade the affected package to the patched version shown in the fix reference. If no fix exists, evaluate a replacement package or add a compensating control.',
                                              CWE:       'Fix the vulnerable code pattern in the identified file and line. Follow the remediation steps below and validate with a re-scan.',
                                              AI:        'Fix the insecure AI/LLM integration in code: add input validation, enforce output sanitization, restrict model permissions, or remove the vulnerable data flow.',
                                              DLP:       'Implement data sanitization before external transmission. Add PII masking or encryption for sensitive data flows.',
                                              SECRET:    'Rotate the exposed credential immediately. Remove it from code, add the file to .gitignore, and store secrets in a secrets manager or environment variable.',
                                              MALWARE:   'Remove the malicious package immediately. Audit all code that depends on it and rotate any credentials it may have accessed.',
                                              SUSPICIOUS:'Investigate the flagged package for malicious behavior. Remove if confirmed malicious; otherwise pin to a verified version and monitor.',
                                              CONFIG:    'Update the configuration to follow secure defaults. Apply the fix shown in the reference and validate in a non-production environment first.',
                                            };
                                            return defaults[f.type] || 'Investigate the finding, identify the root cause in the source code, and apply the appropriate code or configuration fix.';
                                          })()}<br>
                                        ${(isUnknown && getReachabilityState(f) !== 'not_applicable') ? `<div class="context-note" style="background:rgba(245,158,11,0.1);padding:8px;border-radius:4px;margin-top:8px;">⚠️ <strong>REVIEW REQUIRED:</strong> Reachability could not be determined. Check: 1) Is this code path reachable from an entry point? 2) Is it loaded dynamically?${f.type === 'SECRET' ? ' 3) Rotate credential if in doubt.' : ''}</div>` : ''}
                                        ${(f.type === 'CONFIG' || f.type === 'IaC') ? `<div class="context-note" style="background:rgba(59,130,246,0.1);padding:8px;border-radius:4px;margin-top:8px;">${f.action_message || (f.iac_classification ? f.iac_classification.action_message : null) || 'ℹ️ <strong>REVIEW:</strong> IaC finding with context-dependent impact. Severity may vary based on deployment context (standalone Docker, Kubernetes with PodSecurityPolicies, etc.).'}</div>` : ''}
                                        ${f.type === 'DLP' ? `<div style="margin-top:8px;padding:10px;background:rgba(59,130,246,0.1);border-radius:4px;border-left:3px solid #2979FF;"><strong style="color:#93c5fd;">🚨 DLP Remediation Steps:</strong><ol style="margin:8px 0 0 16px;padding:0;color:#93c5fd;"><li>Review data flow from source to sink</li><li>Implement input validation/sanitization</li><li>Add PII masking (e.g., ${f.pii_type === 'SSN' ? 'XXX-XX-####' : f.pii_type === 'CREDIT_CARD' ? '****-****-****-####' : 'redact/mask'})</li><li>Consider encryption for data at rest/transit</li><li>Add audit logging for sensitive data access</li></ol></div>` : ''}<br>
                                        ${rem.fixed_in ? `<strong>Upgrade to:</strong> <code style="background:rgba(34,197,94,0.15);color:#66BB6A;padding:2px 6px;border-radius:3px;font-family:monospace;">${rem.fixed_in}</code><br>` : ''}
                                        ${f.fix_status === 'no_fix' ? `<div class="context-note">⚠️ <em>No fix currently available. Monitor for updates or consider alternative packages.</em></div>` : ''}
                                        ${rem.summary ? `<strong>Summary:</strong> ${rem.summary}<br>` : ''}
                                        ${steps.length > 0 ? `<ol class="remediation-steps">${steps.map(s => `<li>${s}</li>`).join('')}</ol>` : ''}
                                        ${rem.workaround ? `<div class="code-block">${rem.workaround}</div>` : ''}
                                        ${f.type === 'CVE' ? (() => {
                                            let chain = (f.dependency_chain && f.dependency_chain.length > 0) ? [...f.dependency_chain] : [];
                                            if (chain.length === 0 || chain[chain.length-1] !== f.package) {
                                                chain = f.via_package ? [f.via_package, f.package] : [f.package];
                                            }
                                            // Derive entrypoint label from call_paths_v2 first node, or fall back
                                            const _ep = (f.call_paths_v2 && Array.isArray(f.call_paths_v2) && f.call_paths_v2.length > 0)
                                                ? (Array.isArray(f.call_paths_v2[0]) ? f.call_paths_v2[0][0] : f.call_paths_v2[0]) : null;
                                            const _epKind = (_ep && _ep.kind) ? _ep.kind.toLowerCase() : '';
                                            let rootLabel = 'your project';
                                            let rootIcon = '📦';
                                            let rootBadge = 'DIRECT';
                                            let rootColor = '#94a3b8';
                                            let rootRoute = '';
                                            if (_ep && _ep.label) {
                                                rootLabel = _ep.label;
                                                if (_epKind === 'entry') { rootIcon = '🌐'; rootBadge = 'ENDPOINT'; rootColor = '#66BB6A'; }
                                                else if (_epKind === 'app') { rootIcon = '⚙️'; rootBadge = 'APP'; rootColor = '#94a3b8'; }
                                                else if (_epKind === 'agent') { rootIcon = '🕵️'; rootBadge = 'AGENT'; rootColor = '#f472b6'; }
                                                else if (_epKind === 'mcp_server') { rootIcon = '🔌'; rootBadge = 'MCP'; rootColor = '#38bdf8'; }
                                                else { rootIcon = '📦'; rootBadge = 'ROOT'; rootColor = '#94a3b8'; }
                                                // Infer HTTP method + route for richer endpoint display
                                                var _epRoute = (typeof _inferEndpoint === 'function') ? _inferEndpoint(_ep) : null;
                                                if (_epRoute) rootRoute = '<span style="font-size:9px;font-weight:800;color:' + ({GET:'#66BB6A',POST:'#42A5F5',PUT:'#f59e0b',DELETE:'#EF5350',PATCH:'#a78bfa',HTTP:'#94a3b8'}[_epRoute.method]||'#94a3b8') + ';font-family:monospace;margin-left:6px;">' + _epRoute.method + ' ' + _epRoute.route + '</span>';
                                                // Detect cron/timer/internal patterns
                                                var _lbl = (_ep.label || '').toLowerCase();
                                                if (/cron|timer|schedule|periodic|tick/.test(_lbl)) { rootIcon = '⏰'; rootBadge = 'SCHEDULED'; rootColor = '#fbbf24'; }
                                                else if (/internal|grpc|rpc|worker|queue|consumer|subscriber/.test(_lbl)) { rootIcon = '🔒'; rootBadge = 'INTERNAL'; rootColor = '#60a5fa'; }
                                            } else if (f.file_path && f.file_path !== f.package) {
                                                // No call_paths_v2 — use file_path as better fallback
                                                rootLabel = f.file_path.split('/').slice(-2).join('/');
                                                rootIcon = '📄'; rootBadge = 'IMPORT'; rootColor = '#94a3b8';
                                                // Infer endpoint from file path patterns
                                                var _fpLower = f.file_path.toLowerCase();
                                                if (/(?:routes|handlers|views|api|endpoints|controllers)\//.test(_fpLower)) { rootIcon = '🌐'; rootBadge = 'ROUTE'; rootColor = '#66BB6A'; }
                                                else if (/(?:cron|jobs|tasks|workers|scheduler)\//.test(_fpLower)) { rootIcon = '⏰'; rootBadge = 'SCHEDULED'; rootColor = '#fbbf24'; }
                                                else if (/(?:internal|pkg|lib|utils|helpers)\//.test(_fpLower)) { rootIcon = '🔒'; rootBadge = 'INTERNAL'; rootColor = '#60a5fa'; }
                                                if (f.line) rootLabel += ':' + f.line;
                                            }
                                            const fullChain = [rootLabel, ...chain];
                                            const depNodes = fullChain.map((node, i, arr) => {
                                                const isVuln = i === arr.length - 1;
                                                const isRoot = i === 0;
                                                const isVia = !isRoot && !isVuln;
                                                const bg = isVuln ? 'rgba(245,158,11,0.08)' : isRoot ? 'rgba(102,187,106,0.05)' : 'rgba(226,232,240,0.04)';
                                                const border = isVuln ? '#f59e0b44' : isRoot ? (rootColor + '44') : '#1e293b';
                                                const color = isVuln ? '#f59e0b' : isRoot ? rootColor : '#e2e8f0';
                                                const icon = isVuln ? '⚠️' : isRoot ? rootIcon : '↪️';
                                                const badgeText = isVuln ? 'VULNERABLE' : isRoot ? rootBadge : 'TRANSITIVE';
                                                const badgeColor = isVuln ? '#f59e0b' : '#64748b';
                                                const badgeBg = isVuln ? 'rgba(245,158,11,0.12)' : 'rgba(100,116,139,0.1)';
                                                const badge = '<span style="font-size:8px;font-weight:700;color:' + badgeColor + ';background:' + badgeBg + ';padding:1px 5px;border-radius:3px;text-transform:uppercase;letter-spacing:0.5px;margin-left:6px;">' + badgeText + '</span>';
                                                const routeHtml = (isRoot && rootRoute) ? rootRoute : '';
                                                const depth = isVia ? '<span style="font-size:9px;color:#475569;margin-left:auto;">depth ' + i + '</span>' : '';
                                                return '<div style="display:flex;align-items:center;gap:8px;padding:6px 10px;background:' + bg + ';border:1px solid ' + border + ';border-radius:6px;">'
                                                    + '<span style="font-size:13px;">' + icon + '</span>'
                                                    + '<span style="color:' + color + ';font-weight:' + (isVuln||isRoot ? '700' : '400') + ';font-size:11px;font-family:monospace;">' + node + '</span>'
                                                    + badge + routeHtml + depth
                                                    + '</div>'
                                                    + (i < arr.length - 1 ? '<div style="display:flex;align-items:center;padding-left:18px;"><div style="width:2px;height:10px;background:linear-gradient(to bottom,#1e3a4a,#334155);border-radius:1px;"></div><span style="color:#475569;font-size:9px;margin-left:4px;">▼</span></div>' : '');
                                            }).join('');
                                            // Threat context line — varies by entrypoint type
                                            const threatCtx = (_epKind === 'entry' || rootBadge === 'ENDPOINT' || rootBadge === 'ROUTE')
                                                ? '<div style="margin-top:8px;padding:6px 10px;background:rgba(245,158,11,0.06);border:1px solid rgba(245,158,11,0.15);border-radius:5px;font-size:10px;color:#f59e0b;">⚡ Exposed via HTTP endpoint — exploitable by external attackers</div>'
                                                : (rootBadge === 'SCHEDULED')
                                                ? '<div style="margin-top:8px;padding:6px 10px;background:rgba(251,191,36,0.06);border:1px solid rgba(251,191,36,0.15);border-radius:5px;font-size:10px;color:#fbbf24;">⏰ Triggered by scheduled task / cron — runs without user interaction</div>'
                                                : (rootBadge === 'INTERNAL')
                                                ? '<div style="margin-top:8px;padding:6px 10px;background:rgba(96,165,250,0.06);border:1px solid rgba(96,165,250,0.15);border-radius:5px;font-size:10px;color:#60a5fa;">🔒 Internal service path — exploitable via lateral movement or compromised upstream</div>'
                                                : (rootBadge === 'AGENT' || rootBadge === 'MCP')
                                                ? '<div style="margin-top:8px;padding:6px 10px;background:rgba(244,114,182,0.06);border:1px solid rgba(244,114,182,0.15);border-radius:5px;font-size:10px;color:#f472b6;">🤖 AI agent / MCP tool path — LLM-controlled execution flow</div>'
                                                : '';
                                            return '<div style="margin-top:12px;padding:14px;background:rgba(120,144,156,0.05);border-radius:8px;border:1px solid #1e293b;">'
                                                 + '<div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:10px;">'
                                                 + '<div style="color:#94a3b8;font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:1px;">🔗 ' + (f.is_transitive ? 'Transitive Dependency Path' : 'Dependency Path') + '</div>'
                                                 + '<div style="display:flex;gap:6px;align-items:center;">'
                                                 + (_epKind === 'entry' ? '<span style="font-size:9px;background:rgba(102,187,106,0.12);color:#66BB6A;padding:2px 8px;border-radius:10px;font-weight:600;">REACHABLE</span>' : '')
                                                 + '<span style="font-size:10px;background:rgba(120,144,156,0.1);color:#78909C;padding:2px 10px;border-radius:10px;font-weight:600;">' + fullChain.length + ' hops</span>'
                                                 + '</div></div>'
                                                 + '<div style="display:flex;flex-direction:column;gap:2px;">' + depNodes + '</div>'
                                                 + threatCtx
                                                 + (f.is_transitive
                                                    ? '<div style="margin-top:10px;padding:8px 10px;background:rgba(59,130,246,0.04);border:1px solid rgba(59,130,246,0.1);border-radius:6px;font-size:11px;color:#64748b;"><em>You do not import <strong style="color:#94a3b8;">' + (f.package||'') + '</strong> directly. To fix: update <strong style="color:#94a3b8;">' + (f.via_package||'the intermediate dependency') + '</strong> to a version that includes a patched release of ' + (f.package||'') + '.</em></div>'
                                                    : '<div style="margin-top:10px;padding:8px 10px;background:rgba(59,130,246,0.04);border:1px solid rgba(59,130,246,0.1);border-radius:6px;font-size:11px;color:#64748b;"><em><strong style="color:#94a3b8;">' + (f.package||'') + '</strong> is a direct dependency. ' + (f.fix_available ? 'Upgrade to the patched version shown above.' : 'No fix is currently available — monitor for updates or evaluate alternatives.') + '</em></div>'
                                                ) + '</div>';
                                        })() : ''}
${f.type === 'AI' ? (() => {
                                            const _aiEp = (f.call_paths_v2 && Array.isArray(f.call_paths_v2) && f.call_paths_v2.length > 0)
                                                ? (Array.isArray(f.call_paths_v2[0]) ? f.call_paths_v2[0][0] : f.call_paths_v2[0]) : null;
                                            const _aiEpKind = (_aiEp && _aiEp.kind) ? _aiEp.kind.toLowerCase() : '';
                                            let _aiEntry = ''; let _aiEntryColor = '#94a3b8'; let _aiBadge = 'SOURCE';
                                            if (_aiEp && _aiEp.label) {
                                                const _aiRoute = (typeof _inferEndpoint === 'function') ? _inferEndpoint(_aiEp) : null;
                                                if (_aiRoute) { _aiEntry = _aiRoute.method + ' ' + _aiRoute.route; _aiEntryColor = '#66BB6A'; _aiBadge = 'ENDPOINT'; }
                                                else { _aiEntry = _aiEp.label.split('.').slice(-2).join('.'); if (_aiEpKind === 'agent') { _aiEntryColor = '#f472b6'; _aiBadge = 'AGENT'; } else if (_aiEpKind === 'mcp_server') { _aiEntryColor = '#38bdf8'; _aiBadge = 'MCP SERVER'; } else if (_aiEpKind === 'mcp_tool') { _aiEntryColor = '#34d399'; _aiBadge = 'MCP TOOL'; } else { _aiBadge = 'APP'; } }
                                            } else if (filePath) {
                                                _aiEntry = filePath.split('/').slice(-2).join('/');
                                                const _fp = filePath.toLowerCase();
                                                if (/(?:routes|handlers|api|views|controllers)\//.test(_fp)) { _aiEntryColor = '#66BB6A'; _aiBadge = 'ROUTE'; }
                                                else if (/(?:agents?|crew|chain)\//.test(_fp)) { _aiEntryColor = '#f472b6'; _aiBadge = 'AGENT'; }
                                                else if (/(?:tools?|mcp|plugins?)\//.test(_fp)) { _aiEntryColor = '#34d399'; _aiBadge = 'TOOL'; }
                                            }
                                            const _llmCat = f.owasp_llm || f.llm_category || '';
                                            const _llmNames = {LLM01:'Prompt Injection',LLM02:'Sensitive Disclosure',LLM03:'Supply Chain',LLM04:'Data Poisoning',LLM05:'Improper Output',LLM06:'Excessive Agency',LLM07:'Prompt Leakage',LLM08:'Vector Weakness',LLM09:'Misinformation',LLM10:'Unbounded Consumption',MCP:'MCP Security',MCP_SECURITY:'MCP Security'};
                                            const _llmName = _llmNames[_llmCat] || _llmCat || 'AI Security';
                                            const _asiMap = {LLM01:['ASI01','ASI06'],LLM03:['ASI04'],LLM05:['ASI04','ASI05'],LLM06:['ASI02','ASI03','ASI05','ASI09'],LLM09:['ASI09'],LLM10:['ASI08'],MCP:['ASI02','ASI03'],MCP_SECURITY:['ASI02','ASI03']};
                                            const _asiNames = {ASI01:'Goal Hijack',ASI02:'Tool Misuse',ASI03:'Privilege Abuse',ASI04:'Supply Chain',ASI05:'Code Execution',ASI06:'Memory Poisoning',ASI07:'Inter-Agent',ASI08:'Cascading Failures',ASI09:'Trust Exploitation',ASI10:'Rogue Agents'};
                                            const _asiTags = (_asiMap[_llmCat] || []).map(a => '<span style="display:inline-block;background:rgba(30,58,138,0.25);color:#93c5fd;border:1px solid rgba(96,165,250,0.25);border-radius:3px;font-size:9px;font-weight:700;padding:1px 5px;">' + a + ' \u00b7 ' + (_asiNames[a]||a) + '</span>').join(' ');
                                            const _aiNodes = [];
                                            if (_aiEntry) _aiNodes.push({icon: _aiEpKind === 'entry' ? '\ud83c\udf10' : _aiEpKind === 'agent' ? '\ud83d\udd75\ufe0f' : _aiEpKind === 'mcp_server' ? '\ud83d\udd0c' : _aiEpKind === 'mcp_tool' ? '\ud83d\udd27' : '\ud83d\udcc4', label: _aiEntry, color: _aiEntryColor, badge: _aiBadge});
                                            _aiNodes.push({icon: '\ud83e\udd16', label: _llmName, color: '#818cf8', badge: _llmCat || 'AI'});
                                            if (_llmCat === 'LLM06' || _llmCat === 'MCP' || _llmCat === 'MCP_SECURITY') _aiNodes.push({icon: '\ud83d\udd27', label: 'Tool Execution', color: '#34d399', badge: 'EXCESSIVE AGENCY'});
                                            if (_llmCat === 'LLM05') _aiNodes.push({icon: '\ud83d\udce4', label: 'Unsafe Output', color: '#f59e0b', badge: 'OUTPUT RISK'});
                                            if (_llmCat === 'LLM01') _aiNodes.push({icon: '\ud83d\udc89', label: 'Injected Input', color: '#EF5350', badge: 'INJECTION'});
                                            const _aiFlowHtml = _aiNodes.map((n, i) => '<div style="display:flex;align-items:center;gap:8px;padding:6px 10px;background:' + n.color + '0a;border:1px solid ' + n.color + '22;border-radius:6px;">'
                                                + '<span style="font-size:13px;">' + n.icon + '</span>'
                                                + '<span style="color:' + n.color + ';font-weight:600;font-size:11px;font-family:monospace;">' + n.label + '</span>'
                                                + '<span style="font-size:8px;font-weight:700;color:#64748b;background:rgba(100,116,139,0.1);padding:1px 5px;border-radius:3px;text-transform:uppercase;letter-spacing:0.5px;margin-left:6px;">' + n.badge + '</span></div>'
                                                + (i < _aiNodes.length - 1 ? '<div style="display:flex;align-items:center;padding-left:18px;"><div style="width:2px;height:10px;background:linear-gradient(to bottom,#1e3a4a,#334155);border-radius:1px;"></div><span style="color:#475569;font-size:9px;margin-left:4px;">\u25bc</span></div>' : '')).join('');
                                            const _aiThreat = (_aiBadge === 'ENDPOINT' || _aiBadge === 'ROUTE')
                                                ? '<div style="margin-top:8px;padding:6px 10px;background:rgba(245,158,11,0.06);border:1px solid rgba(245,158,11,0.15);border-radius:5px;font-size:10px;color:#f59e0b;">\u26a1 AI/LLM component reachable from HTTP endpoint \u2014 exploitable by external attackers</div>'
                                                : (_aiBadge === 'AGENT')
                                                ? '<div style="margin-top:8px;padding:6px 10px;background:rgba(244,114,182,0.06);border:1px solid rgba(244,114,182,0.15);border-radius:5px;font-size:10px;color:#f472b6;">\ud83d\udd75\ufe0f Autonomous agent execution \u2014 LLM-directed tool use without human oversight</div>'
                                                : (_aiBadge === 'MCP SERVER' || _aiBadge === 'MCP TOOL')
                                                ? '<div style="margin-top:8px;padding:6px 10px;background:rgba(56,189,248,0.06);border:1px solid rgba(56,189,248,0.15);border-radius:5px;font-size:10px;color:#38bdf8;">\ud83d\udd0c MCP tool dispatch \u2014 LLM can invoke external services with elevated permissions</div>'
                                                : '';
                                            return '<div style="margin-top:8px;padding:14px;background:rgba(129,140,248,0.03);border-radius:8px;border:1px solid rgba(129,140,248,0.12);">'
                                                + '<div style="display:flex;align-items:center;gap:8px;margin-bottom:10px;"><span style="font-size:13px;">\ud83e\udd16</span><span style="color:#818cf8;font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:1.2px;">AI Attack Flow</span><span style="font-size:10px;background:rgba(129,140,248,0.1);color:#818cf8;padding:2px 10px;border-radius:10px;font-weight:600;">' + _aiNodes.length + ' stages</span></div>'
                                                + '<div style="display:flex;flex-direction:column;gap:2px;">' + _aiFlowHtml + '</div>'
                                                + (_asiTags ? '<div style="margin-top:8px;display:flex;flex-wrap:wrap;gap:4px;">' + _asiTags + '</div>' : '')
                                                + _aiThreat + '</div>';
                                        })() : ''}
${f.type === 'CWE' && !buildCallGraphViz(f) ? (() => {
                                            // T5: buildCallGraphViz (below) renders the real path when call_paths_v2 present;
                                            // this simplified panel only fires when call_paths_v2 is absent.
                                            const _cweEp = (f.call_paths_v2 && Array.isArray(f.call_paths_v2) && f.call_paths_v2.length > 0)
                                                ? (Array.isArray(f.call_paths_v2[0]) ? f.call_paths_v2[0][0] : f.call_paths_v2[0]) : null;
                                            const _cweEpKind = (_cweEp && _cweEp.kind) ? _cweEp.kind.toLowerCase() : '';
                                            let _cweEntry = ''; let _cweEntryColor = '#94a3b8'; let _cweBadge = 'SOURCE';
                                            if (_cweEp && _cweEp.label) {
                                                const _cweRoute = (typeof _inferEndpoint === 'function') ? _inferEndpoint(_cweEp) : null;
                                                if (_cweRoute) { _cweEntry = _cweRoute.method + ' ' + _cweRoute.route; _cweEntryColor = '#66BB6A'; _cweBadge = 'ENDPOINT'; }
                                                else { _cweEntry = _cweEp.label.split('.').slice(-2).join('.'); if (_cweEpKind === 'entry') { _cweEntryColor = '#66BB6A'; _cweBadge = 'ENDPOINT'; } else { _cweBadge = 'APP'; } }
                                            } else if (filePath) {
                                                _cweEntry = filePath.split('/').slice(-2).join('/');
                                                const _fp = filePath.toLowerCase();
                                                if (/(?:routes|handlers|api|views|controllers)\//.test(_fp)) { _cweEntryColor = '#66BB6A'; _cweBadge = 'ROUTE'; }
                                                else if (/(?:internal|pkg|lib|utils)\//.test(_fp)) { _cweEntryColor = '#60a5fa'; _cweBadge = 'INTERNAL'; }
                                                if (lineNo) _cweEntry += ':' + lineNo;
                                            }
                                            const _cweId = f.cwe_id || f.policy_id || f.rule_id || '';
                                            const _cweNodes = [];
                                            if (_cweEntry) _cweNodes.push({icon: _cweBadge === 'ENDPOINT' || _cweBadge === 'ROUTE' ? '\ud83c\udf10' : '\ud83d\udcc4', label: _cweEntry, color: _cweEntryColor, badge: _cweBadge});
                                            _cweNodes.push({icon: '\u26a0\ufe0f', label: _cweId || 'Code Weakness', color: '#f9a8d4', badge: 'WEAKNESS'});
                                            if (f.sink_function || f.vulnerable_function) _cweNodes.push({icon: '\ud83d\udca5', label: f.sink_function || f.vulnerable_function, color: '#EF5350', badge: 'VULNERABLE CALL'});
                                            else if (desc && desc.length > 5) {
                                                const shortDesc = desc.length > 40 ? desc.substring(0, 40) + '...' : desc;
                                                _cweNodes.push({icon: '\ud83d\udca5', label: shortDesc, color: '#EF5350', badge: 'PATTERN'});
                                            }
                                            const _cweFlowHtml = _cweNodes.map((n, i) => '<div style="display:flex;align-items:center;gap:8px;padding:6px 10px;background:' + n.color + '0a;border:1px solid ' + n.color + '22;border-radius:6px;">'
                                                + '<span style="font-size:13px;">' + n.icon + '</span>'
                                                + '<span style="color:' + n.color + ';font-weight:600;font-size:11px;font-family:monospace;">' + n.label + '</span>'
                                                + '<span style="font-size:8px;font-weight:700;color:#64748b;background:rgba(100,116,139,0.1);padding:1px 5px;border-radius:3px;text-transform:uppercase;letter-spacing:0.5px;margin-left:6px;">' + n.badge + '</span></div>'
                                                + (i < _cweNodes.length - 1 ? '<div style="display:flex;align-items:center;padding-left:18px;"><div style="width:2px;height:10px;background:linear-gradient(to bottom,#1e3a4a,#334155);border-radius:1px;"></div><span style="color:#475569;font-size:9px;margin-left:4px;">\u25bc</span></div>' : '')).join('');
                                            const _cweThreat = (_cweBadge === 'ENDPOINT' || _cweBadge === 'ROUTE')
                                                ? '<div style="margin-top:8px;padding:6px 10px;background:rgba(245,158,11,0.06);border:1px solid rgba(245,158,11,0.15);border-radius:5px;font-size:10px;color:#f59e0b;">\u26a1 Code weakness reachable from HTTP endpoint \u2014 exploitable by external attackers</div>'
                                                : '';
                                            return '<div style="margin-top:8px;padding:14px;background:rgba(249,168,212,0.03);border-radius:8px;border:1px solid rgba(249,168,212,0.12);">'
                                                + '<div style="display:flex;align-items:center;gap:8px;margin-bottom:10px;"><span style="font-size:13px;">\u26a0\ufe0f</span><span style="color:#f9a8d4;font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:1.2px;">Code Weakness Flow</span><span style="font-size:10px;background:rgba(249,168,212,0.1);color:#f9a8d4;padding:2px 10px;border-radius:10px;font-weight:600;">' + _cweNodes.length + ' stages</span></div>'
                                                + '<div style="display:flex;flex-direction:column;gap:2px;">' + _cweFlowHtml + '</div>'
                                                + _cweThreat + '</div>';
                                        })() : ''}
${f.type === 'SECRET' ? (() => {
                                            const _secEp = (f.call_paths_v2 && Array.isArray(f.call_paths_v2) && f.call_paths_v2.length > 0)
                                                ? (Array.isArray(f.call_paths_v2[0]) ? f.call_paths_v2[0][0] : f.call_paths_v2[0]) : null;
                                            const _secEpKind = (_secEp && _secEp.kind) ? _secEp.kind.toLowerCase() : '';
                                            let _secEntry = ''; let _secEntryColor = '#94a3b8'; let _secBadge = 'SOURCE';
                                            if (_secEp && _secEp.label) {
                                                const _secRoute = (typeof _inferEndpoint === 'function') ? _inferEndpoint(_secEp) : null;
                                                if (_secRoute) { _secEntry = _secRoute.method + ' ' + _secRoute.route; _secEntryColor = '#66BB6A'; _secBadge = 'ENDPOINT'; }
                                                else { _secEntry = _secEp.label.split('.').slice(-2).join('.'); _secBadge = 'APP'; }
                                            } else if (filePath) {
                                                _secEntry = filePath.split('/').slice(-2).join('/');
                                                const _fp = filePath.toLowerCase();
                                                if (/\.env/.test(_fp)) { _secEntryColor = '#fbbf24'; _secBadge = 'ENV FILE'; }
                                                else if (/(?:config|settings|secrets|credentials)/.test(_fp)) { _secEntryColor = '#f59e0b'; _secBadge = 'CONFIG'; }
                                                else if (/(?:routes|handlers|api|views|controllers)\//.test(_fp)) { _secEntryColor = '#66BB6A'; _secBadge = 'ROUTE'; }
                                                else if (/(?:docker|k8s|kubernetes|deploy|infra|terraform|helm)/.test(_fp)) { _secEntryColor = '#0ea5e9'; _secBadge = 'INFRA'; }
                                                else { _secBadge = 'FILE'; }
                                                if (lineNo) _secEntry += ':' + lineNo;
                                            }
                                            const _secType = f.secret_type || f.detector || issueId || 'Credential';
                                            const _secNodes = [];
                                            if (_secEntry) _secNodes.push({icon: _secBadge === 'ENV FILE' ? '\ud83d\udcdd' : _secBadge === 'CONFIG' ? '\u2699\ufe0f' : _secBadge === 'INFRA' ? '\ud83c\udfed' : _secBadge === 'ENDPOINT' || _secBadge === 'ROUTE' ? '\ud83c\udf10' : '\ud83d\udcc4', label: _secEntry, color: _secEntryColor, badge: _secBadge});
                                            _secNodes.push({icon: '\ud83d\udd11', label: _secType, color: '#fbbf24', badge: 'SECRET EXPOSED'});
                                            const _secExposure = f.is_in_git_history ? 'Git History' : f.is_in_env ? '.env' : (filePath && /\.env/.test(filePath)) ? '.env' : (filePath && /(?:docker|k8s|deploy)/.test(filePath.toLowerCase())) ? 'Infrastructure' : 'Repository';
                                            _secNodes.push({icon: '\ud83d\udd13', label: _secExposure, color: '#EF5350', badge: 'EXPOSURE VECTOR'});
                                            const _secFlowHtml = _secNodes.map((n, i) => '<div style="display:flex;align-items:center;gap:8px;padding:6px 10px;background:' + n.color + '0a;border:1px solid ' + n.color + '22;border-radius:6px;">'
                                                + '<span style="font-size:13px;">' + n.icon + '</span>'
                                                + '<span style="color:' + n.color + ';font-weight:600;font-size:11px;font-family:monospace;">' + n.label + '</span>'
                                                + '<span style="font-size:8px;font-weight:700;color:#64748b;background:rgba(100,116,139,0.1);padding:1px 5px;border-radius:3px;text-transform:uppercase;letter-spacing:0.5px;margin-left:6px;">' + n.badge + '</span></div>'
                                                + (i < _secNodes.length - 1 ? '<div style="display:flex;align-items:center;padding-left:18px;"><div style="width:2px;height:10px;background:linear-gradient(to bottom,#1e3a4a,#334155);border-radius:1px;"></div><span style="color:#475569;font-size:9px;margin-left:4px;">\u25bc</span></div>' : '')).join('');
                                            const _secThreat = (_secBadge === 'ENDPOINT' || _secBadge === 'ROUTE')
                                                ? '<div style="margin-top:8px;padding:6px 10px;background:rgba(239,68,68,0.06);border:1px solid rgba(239,68,68,0.15);border-radius:5px;font-size:10px;color:#EF5350;">\u26a1 Credential exposed in HTTP-reachable code \u2014 rotate immediately</div>'
                                                : (_secBadge === 'ENV FILE')
                                                ? '<div style="margin-top:8px;padding:6px 10px;background:rgba(251,191,36,0.06);border:1px solid rgba(251,191,36,0.15);border-radius:5px;font-size:10px;color:#fbbf24;">\ud83d\udcdd Secret in .env file \u2014 ensure excluded from version control</div>'
                                                : (_secBadge === 'INFRA')
                                                ? '<div style="margin-top:8px;padding:6px 10px;background:rgba(14,165,233,0.06);border:1px solid rgba(14,165,233,0.15);border-radius:5px;font-size:10px;color:#0ea5e9;">\ud83c\udfed Secret in infrastructure config \u2014 use secrets manager (Vault, AWS Secrets Manager, K8s Secrets)</div>'
                                                : f.is_in_git_history
                                                ? '<div style="margin-top:8px;padding:6px 10px;background:rgba(239,68,68,0.06);border:1px solid rgba(239,68,68,0.15);border-radius:5px;font-size:10px;color:#EF5350;">\u26a0\ufe0f Secret persists in git history \u2014 rotate credential and use BFG/git-filter-repo to purge</div>'
                                                : '';
                                            return '<div style="margin-top:8px;padding:14px;background:rgba(251,191,36,0.03);border-radius:8px;border:1px solid rgba(251,191,36,0.12);">'
                                                + '<div style="display:flex;align-items:center;gap:8px;margin-bottom:10px;"><span style="font-size:13px;">\ud83d\udd10</span><span style="color:#fbbf24;font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:1.2px;">Secret Exposure Path</span><span style="font-size:10px;background:rgba(251,191,36,0.1);color:#fbbf24;padding:2px 10px;border-radius:10px;font-weight:600;">' + _secNodes.length + ' stages</span></div>'
                                                + '<div style="display:flex;flex-direction:column;gap:2px;">' + _secFlowHtml + '</div>'
                                                + _secThreat + '</div>';
                                        })() : ''}
${f.type === 'DLP' ? (() => {
                                            const _dlpEp = (f.call_paths_v2 && Array.isArray(f.call_paths_v2) && f.call_paths_v2.length > 0)
                                                ? (Array.isArray(f.call_paths_v2[0]) ? f.call_paths_v2[0][0] : f.call_paths_v2[0]) : null;
                                            const _dlpEpKind = (_dlpEp && _dlpEp.kind) ? _dlpEp.kind.toLowerCase() : '';
                                            let _dlpEntry = ''; let _dlpEntryColor = '#94a3b8'; let _dlpBadge = 'SOURCE';
                                            if (_dlpEp && _dlpEp.label) {
                                                const _dlpRoute = (typeof _inferEndpoint === 'function') ? _inferEndpoint(_dlpEp) : null;
                                                if (_dlpRoute) { _dlpEntry = _dlpRoute.method + ' ' + _dlpRoute.route; _dlpEntryColor = '#66BB6A'; _dlpBadge = 'ENDPOINT'; }
                                                else { _dlpEntry = _dlpEp.label.split('.').slice(-2).join('.'); if (_dlpEpKind === 'agent') { _dlpEntryColor = '#f472b6'; _dlpBadge = 'AGENT'; } else if (_dlpEpKind === 'mcp_server') { _dlpEntryColor = '#38bdf8'; _dlpBadge = 'MCP'; } }
                                            } else if (filePath) {
                                                const _fp = filePath.toLowerCase();
                                                _dlpEntry = filePath.split('/').slice(-2).join('/');
                                                if (/(?:routes|handlers|api|views|controllers)\//.test(_fp)) { _dlpEntryColor = '#66BB6A'; _dlpBadge = 'ROUTE'; }
                                                else if (/(?:cron|jobs|tasks)\//.test(_fp)) { _dlpEntryColor = '#fbbf24'; _dlpBadge = 'SCHEDULED'; }
                                                else if (/(?:internal|pkg|lib)\//.test(_fp)) { _dlpEntryColor = '#60a5fa'; _dlpBadge = 'INTERNAL'; }
                                            }
                                            const _pii = f.pii_type || 'Sensitive Data';
                                            const _sink = f.sink_type || 'External Sink';
                                            const _sinkColors = {HTTP:'#EF5350',DATABASE:'#0ea5e9',FILE:'#06b6d4',LOG:'#f59e0b',EXTERNAL_API:'#f59e0b',CLOUD:'#0ea5e9',EMAIL:'#ec4899',STDERR:'#FF6B00'};
                                            const _sinkColor = _sinkColors[(_sink||'').toUpperCase()] || '#f59e0b';
                                            const _sinkIcons = {HTTP:'\ud83c\udf10',DATABASE:'\ud83d\uddc4',FILE:'\ud83d\udcc4',LOG:'\ud83d\udcdd',EXTERNAL_API:'\u2192',CLOUD:'\u2601\ufe0f',EMAIL:'\ud83d\udce7',STDERR:'\u26a0\ufe0f'};
                                            const _sinkIcon = _sinkIcons[(_sink||'').toUpperCase()] || '\u2192';
                                            const _flowNodes = [];
                                            if (_dlpEntry) _flowNodes.push({icon: _dlpEpKind === 'entry' ? '\ud83c\udf10' : _dlpEpKind === 'agent' ? '\ud83d\udd75\ufe0f' : '\ud83d\udcc4', label: _dlpEntry, color: _dlpEntryColor, badge: _dlpBadge, bg: _dlpEntryColor + '0a'});
                                            _flowNodes.push({icon: '\ud83e\uddec', label: _pii, color: '#e879f9', badge: 'PII DETECTED', bg: 'rgba(232,121,249,0.06)'});
                                            if (f.sink_function) _flowNodes.push({icon: '\u2699\ufe0f', label: f.sink_function, color: '#94a3b8', badge: 'VIA FUNCTION', bg: 'rgba(148,163,184,0.04)'});
                                            _flowNodes.push({icon: _sinkIcon, label: _sink, color: _sinkColor, badge: 'DATA SINK', bg: _sinkColor + '0a'});
                                            const _flowHtml = _flowNodes.map((n, i) => '<div style="display:flex;align-items:center;gap:8px;padding:6px 10px;background:' + n.bg + ';border:1px solid ' + n.color + '22;border-radius:6px;">'
                                                + '<span style="font-size:13px;">' + n.icon + '</span>'
                                                + '<span style="color:' + n.color + ';font-weight:600;font-size:11px;font-family:monospace;">' + n.label + '</span>'
                                                + '<span style="font-size:8px;font-weight:700;color:#64748b;background:rgba(100,116,139,0.1);padding:1px 5px;border-radius:3px;text-transform:uppercase;letter-spacing:0.5px;margin-left:6px;">' + n.badge + '</span></div>'
                                                + (i < _flowNodes.length - 1 ? '<div style="display:flex;align-items:center;padding-left:18px;"><div style="width:2px;height:10px;background:linear-gradient(to bottom,#1e3a4a,#334155);border-radius:1px;"></div><span style="color:#475569;font-size:9px;margin-left:4px;">\u25bc</span></div>' : '')).join('');
                                            const _dlpThreat = (_dlpBadge === 'ENDPOINT' || _dlpBadge === 'ROUTE')
                                                ? '<div style="margin-top:8px;padding:6px 10px;background:rgba(245,158,11,0.06);border:1px solid rgba(245,158,11,0.15);border-radius:5px;font-size:10px;color:#f59e0b;">\u26a1 PII exposed via HTTP endpoint \u2014 external data exfiltration risk</div>'
                                                : (/LOG|STDERR/.test((_sink||'').toUpperCase()))
                                                ? '<div style="margin-top:8px;padding:6px 10px;background:rgba(245,158,11,0.06);border:1px solid rgba(245,158,11,0.15);border-radius:5px;font-size:10px;color:#f59e0b;">\ud83d\udcdd PII written to logs \u2014 compliance violation risk (GDPR/HIPAA/PCI-DSS)</div>'
                                                : (_dlpBadge === 'AGENT' || _dlpBadge === 'MCP')
                                                ? '<div style="margin-top:8px;padding:6px 10px;background:rgba(244,114,182,0.06);border:1px solid rgba(244,114,182,0.15);border-radius:5px;font-size:10px;color:#f472b6;">\ud83e\udd16 PII exposed via AI agent/MCP tool \u2014 LLM-controlled data exfiltration risk</div>'
                                                : '';
                                            return '<div style="margin-top:8px;padding:14px;background:rgba(232,121,249,0.03);border-radius:8px;border:1px solid rgba(232,121,249,0.12);">'
                                                + '<div style="display:flex;align-items:center;gap:8px;margin-bottom:10px;"><span style="font-size:13px;">\ud83d\udd12</span><span style="color:#e879f9;font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:1.2px;">Data Flow Path</span><span style="font-size:10px;background:rgba(232,121,249,0.1);color:#e879f9;padding:2px 10px;border-radius:10px;font-weight:600;">' + _flowNodes.length + ' stages</span></div>'
                                                + '<div style="display:flex;flex-direction:column;gap:2px;">' + _flowHtml + '</div>'
                                                + _dlpThreat + '</div>';
                                        })() : ''}
                                    </div>
                                </div>
                                <div class="remediation-block">
                                    <div class="remediation-title">📋 Details & References</div>
                                    <div class="remediation-content">
                                        <strong>ID:</strong> ${issueId || 'N/A'}<br>
                                        <strong>Type:</strong> ${f.type || 'Unknown'}${f.is_transitive ? ' <span style="background:rgba(120,144,156,0.18);color:#78909C;padding:2px 6px;border-radius:3px;font-size:10px;font-weight:600;">TRANSITIVE DEP</span>' : ((f.type||'').toUpperCase()==='CVE' ? ' <span style="background:rgba(37,99,235,0.12);color:#60a5fa;padding:2px 6px;border-radius:3px;font-size:10px;font-weight:600;">DIRECT DEP</span>' : '')}<br>
                                        <strong>Severity:</strong> <span class="severity-badge ${sevClass}">${severity}</span><br>
                                        <strong>Risk:</strong> <span class="risk-badge ${riskClass}">${riskLevel}</span> <span style="color:#6b7280;font-size:11px;">(${isReachable ? 'Reachable' : isUnknown ? 'Unknown' : 'Not Reachable'})</span><br>
                                        ${isReachable ? `<strong>Suggested SLA:</strong> <span class="sla-tag ${f.sla_class || ''}">${f.sla_display || 'N/A'}</span><br>` : ''}
                                        ${(() => {
                                            // B1+B2: Per-type correct metadata fields. NO graphs in right panel.
                                            const _t = (f.type || '').toUpperCase();
                                            if (_t === 'CVE') {
                                                // CVE: package + version
                                                return `<strong>Package:</strong> ${f.package || loc}${f.version ? ' @ ' + f.version : ''}<br>`;
                                            } else if (_t === 'MALWARE' || _t === 'SUSPICIOUS') {
                                                // MALWARE: package name (no version needed)
                                                return `<strong>Package:</strong> ${f.package || f.package_name || loc}<br>`;
                                            } else if (_t === 'DLP') {
                                                // DLP: source file + PII type + sink type (NO graph — graph is in left panel)
                                                const _dlpFile = filePath ? `${filePath}${lineNo ? ':' + lineNo : ''}` : '-';
                                                const _dlpFileParts = filePath ? filePath.split('/').slice(-2).join('/') + (lineNo ? ':' + lineNo : '') : '-';
                                                const _dlpLocLink = locLink ? `<a href="${locLink}" class="loc-link">${_dlpFileParts}</a>` : _dlpFileParts;
                                                return `<strong>Source File:</strong> ${_dlpLocLink}<br>`
                                                    + `<strong>PII Type:</strong> <span style="color:#e879f9;font-weight:600;">${f.pii_type || 'Sensitive Data'}</span><br>`
                                                    + `<strong>Sink Type:</strong> <span style="color:#f59e0b;font-weight:600;">${f.sink_type || 'External Sink'}</span><br>`;
                                            } else {
                                                // CWE / SECRET / AI / IaC / CONFIG: file path (NOT "Package:")
                                                const _fileDisplay = filePath
                                                    ? (locLink
                                                        ? `<a href="${locLink}" class="loc-link">${filePath}${lineNo ? ':' + lineNo : ''}</a>`
                                                        : `${filePath}${lineNo ? ':' + lineNo : ''}`)
                                                    : (loc || '-');
                                                return `<strong>File:</strong> ${_fileDisplay}<br>`;
                                            }
                                        })()}
                                        
                                        ${(f.type||'').toUpperCase() === 'CVE' && f.file_path && f.file_path !== f.package ? `<strong>Used In:</strong> ${locLink ? `<a href="${locLink}" class="loc-link">${f.file_path}${f.line ? `:${f.line}` : ''}</a>` : `${f.file_path}${f.line ? `:${f.line}` : ''}`}<br>` : ''}
                                        ${f.cwe_id ? `<strong>CWE:</strong> ${f.cwe_id}<br>` : ''}
                                        ${(f.cvss_score !== null && f.cvss_score !== undefined && f.cvss_score > 0) ? (() => {
                                            const cs = f.cvss_score;
                                            const cvssColor = cs >= 9.0 ? '#EF5350' : cs >= 7.0 ? '#f59e0b' : cs >= 4.0 ? '#fbbf24' : '#66BB6A';
                                            const cvssLabel = cs >= 9.0 ? 'CRITICAL' : cs >= 7.0 ? 'HIGH' : cs >= 4.0 ? 'MEDIUM' : 'LOW';
                                            return `<strong>CVSS:</strong> <span style="color:${cvssColor};font-weight:700;">${cs.toFixed(1)}</span> <span style="background:${cvssColor}22;color:${cvssColor};padding:1px 6px;border-radius:3px;font-size:10px;font-weight:600;">${cvssLabel}</span><br>`;
                                        })() : ''}
                                        ${f.go_vuln_id ? `<strong>Go Vuln ID:</strong> <a href="https://pkg.go.dev/vuln/${f.go_vuln_id}" class="reference-link" target="_blank">${f.go_vuln_id}</a><br>` : ''}
                                        ${(f.epss_score !== null && f.epss_score !== undefined) ? `<strong>EPSS:</strong> <span style="color:#60a5fa;">${(f.epss_score * 100).toFixed(2)}%</span>${f.epss_percentile !== null && f.epss_percentile !== undefined ? ` <span style="color:#64748b;font-size:11px;">(${f.epss_percentile}th percentile)</span>` : ''}<br>` : ''}
                                        ${f.is_kev ? `<strong>KEV:</strong> <span style="background:#7f1d1d;color:#fca5a5;padding:2px 8px;border-radius:4px;font-size:11px;font-weight:700;">⚠ CISA Known Exploited</span><br>` : ''}
                                        ${f.fix_commit_url ? `<strong>Fix Commit:</strong> <a href="${f.fix_commit_url}" class="reference-link" target="_blank">View patch ↗</a><br>` : ''}
                                        ${f.osv_withdrawn ? `<span style="display:inline-block;margin-bottom:6px;padding:4px 10px;background:#7f1d1d22;border:1px solid #7f1d1d66;border-radius:4px;color:#fca5a5;font-size:11px;font-weight:700;">⚠ Advisory Withdrawn/Retracted ${f.osv_withdrawn.split('T')[0]}</span><br>` : ''}
                                        ${(f.osv_summary && f.osv_summary !== (f.description || '').substring(0,f.osv_summary.length)) ? `<strong>OSV Summary:</strong> <span style="color:#94a3b8;font-style:italic;">${escapeHtml(f.osv_summary)}</span><br>` : ''}
                                        ${(f.osv_aliases && f.osv_aliases.length) ? `<strong>Also Known As:</strong> ${f.osv_aliases.slice(0,6).map(a => { const url = a.startsWith('GHSA-') ? 'https://github.com/advisories/' + a : a.startsWith('CVE-') ? 'https://nvd.nist.gov/vuln/detail/' + a : a.startsWith('GO-') ? 'https://pkg.go.dev/vuln/' + a : null; return url ? '<a href="' + url + '" class="reference-link" target="_blank">' + escapeHtml(a) + ' ↗</a>' : '<code style=\'font-size:11px;\'>' + escapeHtml(a) + '</code>'; }).join(' &middot; ')}<br>` : ''}
                                        ${(f.osv_cwes && f.osv_cwes.length) ? `<strong>CWEs (OSV):</strong> ${f.osv_cwes.map(c => `<a href="https://cwe.mitre.org/data/definitions/${c.replace('CWE-','')}.html" class="reference-link" target="_blank">${escapeHtml(c)} ↗</a>`).join(' ')}<br>` : ''}
                                        ${(f.fix_refs && f.fix_refs.length && !f.fix_commit_url) ? `<strong>Fix References:</strong> ${f.fix_refs.slice(0,3).map((u,i) => `<a href="${escapeHtml(u)}" class="reference-link" target="_blank">Patch ${i+1} ↗</a>`).join(' &middot; ')}<br>` : ''}
                                        ${(() => {
                                            // v1.0.0b16: Generate advisory links from GHSA/CVE IDs
                                            const t = (f.type || '').toUpperCase();
                                            if (t !== 'CVE') return '';
                                            const id = f.id || f.title || '';
                                            const links = [];
                                            const ghsaMatch = id.match(/GHSA-[a-z0-9]{4}-[a-z0-9]{4}-[a-z0-9]{4}/i);
                                            const cveMatch = id.match(/CVE-\d{4}-\d+/);
                                            if (ghsaMatch) links.push(`<a href="https://github.com/advisories/${ghsaMatch[0]}" class="reference-link" target="_blank">${ghsaMatch[0]} ↗</a>`);
                                            if (cveMatch) links.push(`<a href="https://nvd.nist.gov/vuln/detail/${cveMatch[0]}" class="reference-link" target="_blank">NVD ↗</a>`);
                                            // Package registry link
                                            const pkg = (f.package || '').split(' ')[0];
                                            if (pkg && pkg.startsWith('@') || (pkg && !pkg.includes('/') && !pkg.includes('.'))) {
                                                links.push(`<a href="https://www.npmjs.com/package/${pkg}" class="reference-link" target="_blank">npm ↗</a>`);
                                            } else if (pkg && pkg.includes('.') && !pkg.includes('/')) {
                                                links.push(`<a href="https://pypi.org/project/${pkg}/" class="reference-link" target="_blank">PyPI ↗</a>`);
                                            } else if (pkg && pkg.includes('/')) {
                                                links.push(`<a href="https://pkg.go.dev/${pkg}" class="reference-link" target="_blank">Go ↗</a>`);
                                            }
                                            return links.length ? `<strong>Advisory:</strong> ${links.join(' &middot; ')}<br>` : '';
                                        })()}
                                        ${(function(){ const rawLlm = f.owasp_llm; if (!rawLlm || rawLlm === 'NONE') return ''; return `<strong>OWASP LLM:</strong> <span style="background:#2979FF;color:white;padding:2px 8px;border-radius:4px;font-size:11px;font-weight:600;">${rawLlm}</span><br>`; })()}
${(() => {
                                            const owaspUrls = {
                                            A01:'https://owasp.org/Top10/A01_2021-Broken_Access_Control/',
                                            A02:'https://owasp.org/Top10/A02_2021-Cryptographic_Failures/',
                                            A03:'https://owasp.org/Top10/A03_2021-Injection/',
                                            A04:'https://owasp.org/Top10/A04_2021-Insecure_Design/',
                                            A05:'https://owasp.org/Top10/A05_2021-Security_Misconfiguration/',
                                            A06:'https://owasp.org/Top10/A06_2021-Vulnerable_and_Outdated_Components/',
                                            A07:'https://owasp.org/Top10/A07_2021-Identification_and_Authentication_Failures/',
                                            A08:'https://owasp.org/Top10/A08_2021-Software_and_Data_Integrity_Failures/',
                                            A09:'https://owasp.org/Top10/A09_2021-Security_Logging_and_Monitoring_Failures/',
                                            A10:'https://owasp.org/Top10/A10_2021-Server-Side_Request_Forgery_%28SSRF%29/',
                                        };
                                        const owaspLlmUrls = {
                                            LLM01:'https://genai.owasp.org/llmrisk/llm01-prompt-injection/',
                                            LLM02:'https://genai.owasp.org/llmrisk/llm02-sensitive-information-disclosure/',
                                            LLM03:'https://genai.owasp.org/llmrisk/llm03-supply-chain/',
                                            LLM04:'https://genai.owasp.org/llmrisk/llm04-data-and-model-poisoning/',
                                            LLM05:'https://genai.owasp.org/llmrisk/llm05-improper-output-handling/',
                                            LLM06:'https://genai.owasp.org/llmrisk/llm06-excessive-agency/',
                                            LLM07:'https://genai.owasp.org/llmrisk/llm07-system-prompt-leakage/',
                                            LLM08:'https://genai.owasp.org/llmrisk/llm08-vector-and-embedding-weaknesses/',
                                            LLM09:'https://genai.owasp.org/llmrisk/llm09-misinformation/',
                                            LLM10:'https://genai.owasp.org/llmrisk/llm10-unbounded-consumption/',
                                            MCP:  'https://genai.owasp.org/llmrisk/llm06-excessive-agency/',
                    AGENTIC: 'https://genai.owasp.org/initiatives/agentic-security-initiative/',
                                        };
                                            // OWASP/LLM reference links suppressed — compliance badges already render
                                            // clickable OWASP and OWASP_LLM tags via renderComplianceTag()
                                            return '';
                                        })()}
                                        ${refs.length > 0 ? `<div class="reference-links">${refs.map(r => `<a href="${r}" class="reference-link" target="_blank">${r.includes('github') ? 'GitHub Advisory' : r.includes('nvd') ? 'NVD' : 'Reference'}</a>`).join('')}</div>` : ''}
                                        ${f.type === 'DLP' && f.compliance_mapping?.regulations?.length > 0 ? `<div style="margin-top: 12px; padding: 12px; background:rgba(245,158,11,0.15);border-radius:6px; border-left: 4px solid #f59e0b;"><strong>⚠️ Regulatory Impact:</strong><div style="margin-top: 8px; display: flex; flex-wrap: wrap; gap: 8px;">${f.compliance_mapping.regulations.map(r => `<span style="background: ${r.includes('GDPR') ? '#FF1F1F' : r.includes('CCPA') ? '#2979FF' : r.includes('HIPAA') ? '#059669' : r.includes('PCI') ? '#0ea5e9' : '#64748b'}; color: white; padding: 4px 10px; border-radius: 4px; font-weight: 600; font-size: 11px;">${r}</span>`).join('')}</div><div style="margin-top: 8px; font-size: 11px; color:#78909C;">This data flow may violate data protection regulations. Immediate remediation recommended.</div></div>` : ''}
                                        ${Object.keys(compMapping).length > 0 ? `<div style="margin-top: 10px;"><strong>Compliance:</strong></div><div class="compliance-tags">${Object.entries(compMapping).filter(([framework]) => framework !== 'regulations').map(([framework, codes]) => renderComplianceTag(framework, codes)).join('')}</div>` : ''}
                                    </div>
                                </div>
                            </div>
                            ${(f.type === 'MALWARE' || f.type === 'SUSPICIOUS') && (evidence.static || evidence.dynamic) ? `
                                <div class="evidence-panel">
                                    <div class="evidence-title">🔍 Detection Evidence</div>
                                    ${evidence.static ? `
                                        <div class="evidence-section">
                                            <div class="evidence-label">Static Malware (${evidence.static.scanner || 'Static'})</div>
                                            <div class="evidence-items">
                                                ${(evidence.static.indicators || []).map(i => `<div class="evidence-item">${i.type}: ${i.detail || i}</div>`).join('')}
                                            </div>
                                        </div>
                                    ` : ''}
                                    ${evidence.dynamic ? `
                                        <div class="evidence-section">
                                            <div class="evidence-label">Dynamic Malware (${evidence.dynamic.scanner || 'Dynamic'})</div>
                                            <div class="evidence-items">
                                                ${(evidence.dynamic.behaviors || []).map(b => `<div class="evidence-item">${b.type}: ${b.detail || b}</div>`).join('')}
                                            </div>
                                        </div>
                                    ` : '<div class="evidence-section"><div class="evidence-label">Dynamic Malware</div><div class="evidence-items"><div class="evidence-item">Not performed (static indicators only)</div></div></div>'}
                                </div>
                            ` : ''}
                            ${buildCallGraphViz(f)}
                            ${(() => {
                                // T-CG31: Universal fallback flow graph for findings without call_paths_v2
                                if (f.call_paths_v2 && Array.isArray(f.call_paths_v2) && f.call_paths_v2.length > 0) return '';
                                const _fbNodes = [];
                                const _filePath = f.file_path || f.source_file || f.location || '';
                                const _pkg = f.package || f.purl || '';
                                const _line = f.line || f.line_number || '';
                                const _fType = f.type || '';
                                if (_filePath) {
                                    const _fpShort = _filePath.split('/').slice(-2).join('/') + (_line ? ':' + _line : '');
                                    const _fpLow = _filePath.toLowerCase();
                                    let _fbIcon = '📄'; let _fbBadge = 'FILE'; let _fbColor = '#94a3b8';
                                    if (/(?:routes|handlers|api|views|controllers|endpoints)\//.test(_fpLow)) { _fbIcon = '🌐'; _fbBadge = 'ROUTE'; _fbColor = '#66BB6A'; }
                                    else if (/(?:cron|jobs|tasks|workers|scheduler)\//.test(_fpLow)) { _fbIcon = '⏰'; _fbBadge = 'SCHEDULED'; _fbColor = '#fbbf24'; }
                                    else if (/(?:docker|k8s|kubernetes|deploy|infra|terraform|helm)/.test(_fpLow)) { _fbIcon = '🏭'; _fbBadge = 'INFRA'; _fbColor = '#0ea5e9'; }
                                    else if (/\.env/.test(_fpLow)) { _fbIcon = '📝'; _fbBadge = 'ENV'; _fbColor = '#fbbf24'; }
                                    else if (/(?:config|settings)/.test(_fpLow)) { _fbIcon = '⚙️'; _fbBadge = 'CONFIG'; _fbColor = '#60a5fa'; }
                                    _fbNodes.push({ icon: _fbIcon, label: _fpShort, color: _fbColor, badge: _fbBadge });
                                }
                                if (_pkg && _pkg !== _filePath) {
                                    _fbNodes.push({ icon: '📦', label: _pkg + (f.version ? '@' + f.version : ''), color: '#94a3b8', badge: 'PACKAGE' });
                                }
                                const _findingIcons = { CVE: '🛡️', CWE: '⚠️', SECRET: '🔑', DLP: '🧬', AI: '🤖', MALWARE: '💀', SUSPICIOUS: '❓', CONFIG: '⚙️' };
                                const _findingColors = { CVE: '#f59e0b', CWE: '#f9a8d4', SECRET: '#fbbf24', DLP: '#e879f9', AI: '#818cf8', MALWARE: '#EF5350', SUSPICIOUS: '#FF6B00', CONFIG: '#60a5fa' };
                                const _findingLabels = {
                                    CVE: f.id || f.cve_id || 'CVE Finding', CWE: f.cwe_id || f.rule_id || 'Code Weakness',
                                    SECRET: f.secret_type || f.detector || 'Exposed Secret', DLP: (f.pii_type || 'PII') + ' → ' + (f.sink_type || 'Sink'),
                                    AI: f.owasp_llm || f.llm_category || 'AI Security', MALWARE: f.package || 'Malicious Package',
                                    SUSPICIOUS: f.package || 'Suspicious Package', CONFIG: f.rule_id || f.title || 'Config Issue'
                                };
                                _fbNodes.push({ icon: _findingIcons[_fType] || '⚠️', label: _findingLabels[_fType] || f.id || 'Finding', color: _findingColors[_fType] || '#f59e0b', badge: _fType || 'FINDING' });
                                if (_fbNodes.length < 2) return '';
                                const _fbHtml = _fbNodes.map((n, i) =>
                                    '<div style="display:flex;align-items:center;gap:8px;padding:6px 10px;background:' + n.color + '0a;border:1px solid ' + n.color + '22;border-radius:6px;">'
                                    + '<span style="font-size:13px;">' + n.icon + '</span>'
                                    + '<span style="color:' + n.color + ';font-weight:600;font-size:11px;font-family:monospace;">' + n.label + '</span>'
                                    + '<span style="font-size:8px;font-weight:700;color:#64748b;background:rgba(100,116,139,0.1);padding:1px 5px;border-radius:3px;text-transform:uppercase;letter-spacing:0.5px;margin-left:6px;">' + n.badge + '</span></div>'
                                    + (i < _fbNodes.length - 1 ? '<div style="display:flex;align-items:center;padding-left:18px;"><div style="width:2px;height:10px;background:linear-gradient(to bottom,#1e3a4a,#334155);border-radius:1px;"></div><span style="color:#475569;font-size:9px;margin-left:4px;">▼</span></div>' : '')
                                ).join('');
                                const _hdrColor = _findingColors[_fType] || '#94a3b8';
                                return '<div style="background:#080d17;border-radius:8px;padding:16px;margin-top:12px;border:1px solid #1e3a4a;">'
                                    + '<div style="display:flex;align-items:center;gap:8px;margin-bottom:10px;"><span style="color:' + _hdrColor + ';font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:1.2px;">📍 Finding Flow</span></div>'
                                    + '<div style="display:flex;flex-direction:column;gap:2px;">' + _fbHtml + '</div></div>';
                            })()}
                            ${f.description || f.message ? `<div style="margin-top: 15px; padding: 10px; background: #0f1729; border-radius: 4px; font-size: 12px; color: #94a3b8; border: 1px solid #1e293b;"><strong style='color:#e2e8f0;'>Full Description:</strong> ${f.description || f.message}</div>` : ''}
                        </div>
                    </td>
                </tr>`;
                } // end per-finding row
              }); // end itemsToRender.forEach
            }); // end _groupOrder.forEach
            tbody.innerHTML = html;
            attachRowHandlers();
            // Update result count — show grouped count when grouping is active
            const countEl = document.getElementById('findingsResultCount');
            if (countEl) {
                const groupedCount = _groupOrder.length;
                const totalCount = issues.length;
                countEl.textContent = groupedCount < totalCount
                    ? `${groupedCount} groups (${totalCount} total)`
                    : `${totalCount} result${totalCount !== 1 ? 's' : ''}`;
            }
        }
        
        // Toggle a group's sub-rows visible/hidden
        window.toggleGroup = function(groupId) {
            const detailRow = document.querySelector(`tr[data-group-detail="${groupId}"]`);
            const headerRow = document.querySelector(`tr[data-group-id="${groupId}"]`);
            if (!detailRow) return;
            const isOpen = detailRow.style.display !== 'none';
            detailRow.style.display = isOpen ? 'none' : '';
            const arrow = headerRow ? headerRow.querySelector('.expand-arrow') : null;
            if (arrow) arrow.textContent = isOpen ? '▶' : '▼';
            const badge = headerRow ? headerRow.querySelector('span[onclick*="toggleGroup"]') : null;
            if (badge) {
                // Flip ▾ ↔ ▴ preserving label ("N CVEs" or "N locations")
                badge.textContent = badge.textContent.replace(/[▾▴]/, isOpen ? '▾' : '▴');
            }
        };

        // Expand/collapse a group sub-row's inline detail (remediation panel)
        window.toggleExpand = function(row) {
            const idx = row.dataset.id;
            const detailRow = document.querySelector(`tr[data-parent="${idx}"]`);
            const arrow = row.querySelector('.expand-arrow');
            if (detailRow) {
                const isOpen = detailRow.classList.contains('show');
                detailRow.classList.toggle('show', !isOpen);
                if (arrow) { arrow.textContent = isOpen ? '▶' : '▼'; arrow.classList.toggle('expanded', !isOpen); }
            }
        };

        function attachRowHandlers() {
            document.querySelectorAll('tr.clickable').forEach(row => {
                row.addEventListener('click', (e) => {
                    if (e.target.tagName === 'A') return;
                    const exp = document.querySelector(`tr[data-parent="${row.dataset.id}"]`);
                    const arr = row.querySelector('.expand-arrow');
                    if (exp) { 
                        exp.classList.toggle('show'); 
                        arr.classList.toggle('expanded'); 
                        arr.textContent = arr.classList.contains('expanded') ? '▼' : '▶'; 
                    }
                });
            });
        }
        
        // v4.4.6: Improved compliance framework matching
        function normalizeComplianceKey(key) {
            if (!key) return '';
            // Remove special chars, normalize to uppercase, handle common variations
            return key.toUpperCase()
                .replace(/[^A-Z0-9]/g, '')
                .replace('TOP25', 'TOP25')
                .replace('80053', '80053')
                .replace('800171', '800171');
        }
        
        // v4.4.6: Check if compliance mapping contains a framework
        function hasComplianceFramework(mapping, filterValue) {
            if (!mapping || !filterValue) return false;
            const normalizedFilter = normalizeComplianceKey(filterValue);
            
            // v4.5.38: Handle OWASP category filters (OWASP-A01, OWASP-LLM01, etc.)
            if (filterValue.startsWith('OWASP-A') || filterValue.startsWith('OWASP-LLM')) {
                const category = filterValue.replace('OWASP-', ''); // A01, LLM01, etc.
                // Check if finding has this OWASP category
                if (mapping.OWASP && Array.isArray(mapping.OWASP)) {
                    return mapping.OWASP.some(code => code.startsWith(category));
                }
                if (mapping['OWASP-LLM'] && Array.isArray(mapping['OWASP-LLM'])) {
                    return mapping['OWASP-LLM'].some(code => code.startsWith(category));
                }
                // v4.5.39 FIX: Data uses OWASP_LLM (underscore), not OWASP-LLM (dash)
                if (mapping.OWASP_LLM && Array.isArray(mapping.OWASP_LLM)) {
                    return mapping.OWASP_LLM.some(code => code.startsWith(category));
                }
                // Also check llm_category field directly
                const llmCat = mapping.llm_category || mapping.owasp_llm;
                if (llmCat && llmCat.startsWith(category)) return true;
                // Also check owasp_category field directly
                const owaspCat = mapping.owasp_category || mapping.owasp_llm_category;
                if (owaspCat && owaspCat.startsWith(category)) return true;
                return false;
            }
            
            // Common aliases for frameworks
            const aliases = {
                'OWASP': ['OWASP', 'OWASPTOP10'],
                // BUG-CTR-04 FIX: 'CWE' is a common raw key in compliance_mapping — must match CWE-TOP-25 filter
                'CWETOP25': ['CWETOP25', 'CWE25', 'CWETOP', 'CWE'],
                'PCIDSS': ['PCIDSS', 'PCI'],
                'NIST80053': ['NIST80053', 'NIST53', 'SP80053'],
                'NIST800171': ['NIST800171', 'NIST171', 'SP800171'],
                'FEDRAMP': ['FEDRAMP', 'FEDRAMPMODERATE', 'FEDRAMPHIGH'],
                'ISO27001': ['ISO27001', 'ISO27K', 'ISO'],
                'SOC2': ['SOC2', 'SOC', 'AICPA'],
                'CMMC': ['CMMC', 'CMMCL2', 'CMMCL3'],
                'DISASTIG': ['DISASTIG', 'STIG', 'DISA']
            };
            
            // Get all possible matches for filter
            const filterAliases = aliases[normalizedFilter] || [normalizedFilter];
            
            // Check each key in the mapping
            return Object.keys(mapping).some(key => {
                const normalizedKey = normalizeComplianceKey(key);
                // Check direct match or alias match
                // BUG 50/51/52 FIX: strict equality only — alias.includes(normalizedKey) caused
                // 'CWETOP25'.includes('CWE')=true and 'FISMA'.includes('')=true (empty key),
                // making table return far more rows than the GRC card counter shows.
                return filterAliases.some(alias => normalizedKey === alias);
            });
        }
        
        // v4.5.3: Keywords that should NOT match in free text search (they have dedicated filters)
        const STATUS_KEYWORDS = ['unknown', 'reachable', 'not_reachable', 'critical', 'high', 'medium', 'low', 'info'];
        
        function applyFilters() {
            const search = document.getElementById('searchBox').value.toLowerCase().trim();
            const typeF = document.getElementById('typeFilter').value.toUpperCase();
            const riskF = document.getElementById('riskFilter').value;
            const reachF = document.getElementById('reachableFilter').value;
            const compF = document.getElementById('complianceFilter').value;
            const fixF = document.getElementById('fixStatusFilter').value;
            
            const filtered = allIssues.filter(f => {
                // Exclude not_applicable (CONFIG) findings unless explicitly filtering for CONFIG
                if (getReachabilityState(f) === 'not_applicable' && typeF !== 'CONFIG') return false;
                // Search filter - check multiple fields
                // v4.5.3: If searching for a status keyword, match the actual status field instead
                if (search) {
                    // Check if searching for a status keyword
                    if (STATUS_KEYWORDS.includes(search)) {
                        const reachState = getReachabilityState(f);
                        const severity = normalizeSeverity(f.severity).toLowerCase();
                        const risk = calculateRisk(f).toLowerCase();
                        // Match against actual status fields only
                        if (search === 'unknown' && reachState !== 'unknown') return false;
                        if (search === 'reachable' && reachState !== 'reachable') return false;
                        if (search === 'not_reachable' && reachState !== 'not_reachable') return false;
                        if (['critical', 'high', 'medium', 'low', 'info'].includes(search)) {
                            if (severity !== search && risk !== search) return false;
                        }
                    } else {
                        // v4.5.39 FIX: Also search OWASP/LLM policy codes in compliance_mapping
                        // This enables searching for "A01", "LLM01" etc from search box
                        // BUG 39 FIX: search-box path must use same merged mapping as compliance filter path
                        // Old OR logic loses inferred keys when DB mapping exists
                        const _dbMapS = f.compliance_mapping || {};
                        const _inferredS = (typeof inferComplianceMapping === 'function' && inferComplianceMapping(f)) || {};
                        const mapping = Object.assign({}, _inferredS, _dbMapS); // DB wins on conflict
                        const owaspCodes = (mapping && mapping.OWASP) ? mapping.OWASP.join(' ') : '';
                        // v4.5.39 FIX: Data uses OWASP_LLM (underscore), not OWASP-LLM (dash)
                        const llmCodes = (mapping && mapping.OWASP_LLM) ? mapping.OWASP_LLM.join(' ') : '';
                        // Also check llm_category field directly on the finding
                        const llmCategory = f.llm_category || f.owasp_llm || '';
                        const policyId = f.policy_id || '';
                        
                        // Regular text search - include policy codes, DLP fields, description for OWASP/LLM/DLP filtering
                        const searchFields = [
                            f.id, f.title, f.package, f.file_path, f.type, policyId, owaspCodes, llmCodes, llmCategory,
                            f.pii_type, f.sink_type, f.source_type, f.flow_type, f.description, f.message, f.owasp_name,
                            f.secret_type, f.detector, f.rule_id, f.cwe_id
                        ].filter(Boolean).join(' ').toLowerCase();
                        if (!searchFields.includes(search)) return false;
                    }
                }
                
                // Type filter (case-insensitive)
                if (typeF) {
                var ft = (f.type || '').toUpperCase();
                if (ft !== typeF) return false;
              }
                
                // Severity filter: use calculateRisk (same value displayed in UI)
                if (riskF && calculateRisk(f) !== riskF) return false;
                
                // Reachability filter
                const reachState = getReachabilityState(f);
                if (reachF === 'reachable' && reachState !== 'reachable') return false;
                if (reachF === 'not_reachable' && reachState !== 'not_reachable') return false;
                if (reachF === 'unknown' && reachState !== 'unknown') return false;
                // Actionable = reachable + unknown (exclude not_reachable)
                if (reachF === 'actionable' && reachState === 'not_reachable') return false;
                
                // Fix status filter
                if (fixF) {
                    const hasFixAvailable = f.fix_available === true || f.fix_status === 'fix_available';
                    const hasNoFix = f.fix_status === 'no_fix' || f.fix_available === false;
                    if (fixF === 'fix_available' && !hasFixAvailable) return false;
                    if (fixF === 'no_fix' && !hasNoFix) return false;
                    if (fixF === 'unknown' && (hasFixAvailable || hasNoFix)) return false;
                }
                
                // BUG 39 FIX: Compliance filter must use MERGED mapping (DB + inferred)
                // GRC renderer counts with merged mapping — applyFilters must match exactly.
                // Merge both sources; DB wins on conflict (identical to renderGRC logic)
                if (compF) {
                    const _dbMap = f.compliance_mapping || {};
                    const _inferred = (typeof inferComplianceMapping === 'function' && inferComplianceMapping(f)) || {};
                    const mapping = Object.assign({}, _inferred, _dbMap); // DB wins on conflict
                    // Also check f.llm_category directly for LLM findings
                    if (compF.startsWith('OWASP-')) {
                        // Handle all OWASP subcategories: LLM01-10, MCP, CONTROLS, A01-A10 etc
                        const filterCat = compF.replace('OWASP-', ''); // LLM01, MCP, A01, etc.
                        const findingLlmCat = (f.llm_category || f.owasp_llm || '').toUpperCase();
                        const filterCatUpper = filterCat.toUpperCase();
                        if (findingLlmCat === filterCatUpper) {
                            // Match found via direct owasp_llm/llm_category field
                        } else if (!hasComplianceFramework(mapping, compF)) {
                            return false;
                        }
                    } else if (!hasComplianceFramework(mapping, compF)) {
                        return false;
                    }
                }
                
                return true;
            });
            currentFilteredIssues = filtered;
            renderTable(filtered);
        }
        
        // Infer compliance mapping for items without explicit mapping
        function inferComplianceMapping(finding) {
            const type = finding.type;
            const severity = normalizeSeverity(finding.severity);
            
            // CVEs typically map to multiple frameworks
            if (type === 'CVE') {
                return {
                    'OWASP': ['A03:2025'],  // Software Supply Chain Failures
                    'CWE-TOP-25': true,
                    'PCI-DSS': ['6.3'],
                    'NIST-800-53': ['SI-2'],
                    'ISO27001': ['A.12.6.1'],
                    'SOC2': ['CC6.1'],
                    'HIPAA': ['164.308(a)(5)(ii)(B)'],
                    'CMMC': ['SI.2.216'],
                    'FEDRAMP': ['SI-2'],
                    'FISMA': ['SI-2']
                };
            }
            
            // Secrets map to auth/crypto frameworks
            if (type === 'SECRET') {
                return {
                    'OWASP': ['A04:2025'],  // Cryptographic Failures
                    'PCI-DSS': ['3.4', '8.2'],
                    'NIST-800-53': ['SC-12', 'SC-13'],
                    'ISO27001': ['A.10.1.1'],
                    'SOC2': ['CC6.1'],
                    'HIPAA': ['164.312(a)(2)(iv)']
                };
            }
            
            // CWE findings have specific mappings
            if (type === 'CWE') {
                return {
                    'OWASP': ['A05:2025'],  // Injection
                    'CWE-TOP-25': true,
                    'PCI-DSS': ['6.5'],
                    'NIST-800-53': ['SI-10']
                };
            }
            
            // BUG 10/17/29 FIX: AI/LLM findings map to multiple frameworks
            if (type === 'AI') {
                return {
                    'OWASP_LLM': [finding.owasp_llm || finding.llm_category || 'LLM06'],
                    'OWASP': ['A06:2025'],
                    'NIST-800-53': ['SI-10', 'AC-4'],
                    'ISO27001': ['A.14.2.5'],
                    'SOC2': ['CC6.1'],
                    'FEDRAMP': ['SI-10'],
                    'FISMA': ['SI-10']
                };
            }
            
            // BUG 10/17/29 FIX: DLP findings map to data protection frameworks
            if (type === 'DLP') {
                return {
                    'OWASP': ['A01:2025'],
                    'PCI-DSS': ['3.4', '3.5'],
                    'HIPAA': ['164.312(a)(1)'],
                    'NIST-800-53': ['SC-28', 'SI-12'],
                    'ISO27001': ['A.8.2.3'],
                    'SOC2': ['CC6.1'],
                    'NIST-800-171': ['3.1.3'],
                    'FEDRAMP': ['SC-28'],
                    'FISMA': ['SC-28']
                };
            }
            
            // BUG 10/17/29 FIX: Malware/Suspicious map to supply chain frameworks
            if (type === 'MALWARE' || type === 'SUSPICIOUS') {
                return {
                    'OWASP': ['A03:2025'],
                    'NIST-800-53': ['SI-3', 'SI-7'],
                    'ISO27001': ['A.12.2.1'],
                    'PCI-DSS': ['5.1', '5.2'],
                    'SOC2': ['CC6.8'],
                    'CMMC': ['SI.2.216'],
                    'DISA-STIG': ['SI-3'],
                    'FEDRAMP': ['SI-3'],
                    'FISMA': ['SI-3']
                };
            }
            
            // BUG 10/17/29 FIX: Config/IaC findings map to hardening frameworks
            if (type === 'CONFIG' || type === 'IAC') {
                return {
                    'OWASP': ['A02:2025'],
                    'NIST-800-53': ['CM-6', 'CM-7'],
                    'ISO27001': ['A.14.1.1'],
                    'PCI-DSS': ['2.2'],
                    'DISA-STIG': ['CM-6'],
                    'CMMC': ['CM.2.064'],
                    'FEDRAMP': ['CM-6'],
                    'FISMA': ['CM-6']
                };
            }
            
            return null;
        }
        
        function exportCSV() {
            const rows = [['Risk', 'Type', 'ID', 'Fix Status', 'Severity', 'Reachable', 'Location', 'Description', 'Compliance']];
            const exportSet = (typeof currentFilteredIssues !== 'undefined' && currentFilteredIssues.length > 0) ? currentFilteredIssues : allIssues;
            exportSet.forEach(f => {
                const reachState = getReachabilityState(f);
                rows.push([
                    calculateRisk(f),
                    f.type || 'CWE',
                    f.id || '',
                    f.fix_available ? 'Fix Available' : (f.fix_status || 'Unknown'),
                    normalizeSeverity(f.severity),
                    reachState,
                    f.file_path || f.package || '',
                    (f.description || '').replace(/,/g, ';'),
                    f.compliance_mapping ? Object.keys(f.compliance_mapping).join('; ') : ''
                ]);
            });
            const csv = rows.map(r => r.join(',')).join('\n');
            const blob = new Blob([csv], { type: 'text/csv' });
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a'); a.href = url; a.download = 'reachable-issues.csv'; a.click();
        }
        
        // v4.5.38: Click OWASP/LLM category card → filter Security Issues table
        function filterByOwaspCategory(category, isLlm = false) {
            // v4.5.39 FIX: Switch to Security Issues tab (where risk-inventory-wrapper is moved)
            const securityTab = document.querySelector('[data-tab="security-issues"]');
            if (securityTab) {
                document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
                document.querySelectorAll('.tab-page').forEach(p => p.classList.remove('active'));
                securityTab.classList.add('active');
                document.getElementById('tab-security-issues').classList.add('active');
            }
            
            // v4.5.39 FIX: Populate search box with category code (e.g., A01, LLM01)
            // This allows users to see the filter and easily modify it
            const searchBox = document.getElementById('searchBox');
            if (searchBox) {
                searchBox.value = category; // e.g., "A01" or "LLM01"
            }
            
            // Also set compliance filter for precise filtering
            // v4.6.5 FIX: Use correct format - OWASP-A01 for Web, OWASP-LLM01 for LLM
            const filterValue = `OWASP-${category}`;
            const complianceFilter = document.getElementById('complianceFilter');
            if (complianceFilter) {
                complianceFilter.value = filterValue;  // e.g. OWASP-A01 (valid dropdown option)
            }
            // Clear search box — compliance filter handles the filtering
            if (searchBox) searchBox.value = '';
            
            // Expand Security Issues section if collapsed
            const inventoryContent = document.getElementById('inventorySectionContent');
            if (inventoryContent && inventoryContent.style.display === 'none') {
                toggleSection('inventory');
            }
            
            // Always show all reachability states for compliance clicks
            setReachPill('all');
            // Apply filters and scroll to table
            applyFilters();
            
            // Scroll to Security Issues section
            const issuesTable = document.getElementById('issuesTable');
            if (issuesTable) {
                issuesTable.scrollIntoView({ behavior: 'smooth', block: 'start' });
            }
        }
        
        // Initialize
        const searchBox = document.getElementById('searchBox');
        const typeFilter = document.getElementById('typeFilter');
        const riskFilter = document.getElementById('riskFilter');
        const reachableFilter = document.getElementById('reachableFilter');
        const fixStatusFilter = document.getElementById('fixStatusFilter');
        const complianceFilter = document.getElementById('complianceFilter');
        const exportBtn = document.getElementById('exportBtn');
        
        if (searchBox) searchBox.addEventListener('input', applyFilters);
        if (typeFilter) typeFilter.addEventListener('change', applyFilters);
        if (riskFilter) riskFilter.addEventListener('change', applyFilters);
        if (reachableFilter) reachableFilter.addEventListener('change', applyFilters);
        if (fixStatusFilter) fixStatusFilter.addEventListener('change', applyFilters);
        if (complianceFilter) complianceFilter.addEventListener('change', applyFilters);
        if (exportBtn) exportBtn.addEventListener('click', exportCSV);
        
        // Sorting
        document.querySelectorAll('th.sortable').forEach(th => {
            th.addEventListener('click', () => {
                const col = th.dataset.column;
                const isAsc = th.classList.contains('sorted-asc');
                document.querySelectorAll('th').forEach(h => h.classList.remove('sorted-asc', 'sorted-desc'));
                th.classList.add(isAsc ? 'sorted-desc' : 'sorted-asc');
                
                allIssues.sort((a, b) => {
                    let aVal, bVal;
                    if (col === 'severity') { aVal = normalizeSeverity(a.severity); bVal = normalizeSeverity(b.severity); }
                    else if (col === 'risk') { aVal = calculateRisk(a); bVal = calculateRisk(b); }
                    else if (col === 'reachable') { aVal = getReachabilityState(a); bVal = getReachabilityState(b); }
                    else if (col === 'file_path') { aVal = a.file_path || a.package || ''; bVal = b.file_path || b.package || ''; }
                    else if (col === 'type') { aVal = (a.type || '').toUpperCase(); bVal = (b.type || '').toUpperCase(); }
                    else { aVal = a[col] || ''; bVal = b[col] || ''; }
                    
                    const sevOrder = { CRITICAL: 0, HIGH: 1, MEDIUM: 2, LOW: 3, INFO: 4 };
                    const reachOrder = { reachable: 0, unknown: 1, not_reachable: 2 };
                    
                    if (col === 'severity' || col === 'risk') {
                        aVal = sevOrder[aVal] ?? 5; bVal = sevOrder[bVal] ?? 5;
                    }
                    if (col === 'reachable') {
                        aVal = reachOrder[aVal] ?? 3; bVal = reachOrder[bVal] ?? 3;
                    }
                    
                    if (aVal < bVal) return isAsc ? 1 : -1;
                    if (aVal > bVal) return isAsc ? -1 : 1;
                    return 0;
                });
                applyFilters();
            });
        });
        

        // v4.5.22: Main Panel Toggle (Risk Overview / Remediation Overview)
        function toggleMainPanel(panelName) {
            const content = document.getElementById(panelName + 'Content');
            const toggle = document.getElementById(panelName + 'Toggle');
            if (content && toggle) {
                content.classList.toggle('collapsed');
                toggle.classList.toggle('collapsed');
            }
        }
        
        // v4.5.12: Engineering Panel Toggle (legacy - now uses toggleSection)
        function toggleEngineeringPanel() {
            toggleSection('engineering');
        }
        
        // v4.5.13: Exec Panel (Risk Posture) Toggle
        function toggleExecPanel() {
            const content = document.getElementById('execPanelContent');
            const toggle = document.getElementById('execPanelToggle');
            if (content && toggle) {
                content.classList.toggle('collapsed');
                toggle.classList.toggle('collapsed');
            }
        }
        
        // v4.5.20: Generic Section Toggle for Collapsible Panels
        function toggleSection(sectionName) {
            const content = document.getElementById(sectionName + 'SectionContent');
            const toggle = document.getElementById(sectionName + 'SectionToggle');
            if (content && toggle) {
                content.classList.toggle('collapsed');
                toggle.classList.toggle('collapsed');
            }
        }
        
        // v4.5.12: Populate Engineering Details Panel
        function populateEngineeringPanel(issues) {
            // P2.60: Read ALL engineering panel data from d.engineering (DB = single source of truth)
            // NO filtering/counting from issues[] — loaders.py pre-computed everything
            const eng = dashboardData.engineering || {};
            const cve = eng.cve || {};
            const secret = eng.secret || {};
            const cwe = eng.cwe || {};
            const mal = eng.malware || {};
            const cfg = eng.config || {};

            // === CVE Panel ===
            setEl('engCveReachable', cve.reachable || 0);
            setEl('engCveUnknown', cve.unknown || 0);
            setEl('engCveCritical', cve.critical || 0);
            setEl('engCveHigh', cve.high || 0);
            setEl('engCveMedium', cve.medium || 0);
            setEl('engCveLow', cve.low || 0);
            setEl('engCveTotal', cve.total || 0);
            setEl('engCveFixable', cve.fixable || 0);
            setEl('engCveNotFixable', cve.not_fixable || 0);

            // === Secrets Panel ===
            setEl('engSecretsAws', secret.aws || 0);
            setEl('engSecretsApi', secret.api || 0);
            setEl('engSecretsPrivate', secret['private'] || 0);
            setEl('engSecretsTokens', secret.tokens || 0);
            setEl('engSecretsOther', secret.other || 0);
            setEl('engSecretsCritical', secret.critical || 0);
            setEl('engSecretsHigh', secret.high || 0);
            setEl('engSecretsMedium', secret.medium || 0);
            setEl('engSecretsTotal', secret.total || 0);
            setEl('engSecretsPasswords', secret.passwords || 0);
            setEl('engSecretsReachable', secret.reachable || 0);
            setEl('engSecretsUnknown', secret.unknown || 0);

            // === CWE Panel ===
            setEl('engCweCritical', cwe.critical || 0);
            setEl('engCweHigh', cwe.high || 0);
            setEl('engCweMedium', cwe.medium || 0);
            setEl('engCweLow', cwe.low || 0);
            setEl('engCweTotal', cwe.total || 0);
            setEl('engCweReachable', cwe.reachable || 0);
            setEl('engCweUnknown', cwe.unknown || 0);
            // === CWE Policy Categories ===
            setEl('engCweInjection', cwe.injection || 0);
            setEl('engCweXss', cwe.xss || 0);
            setEl('engCwePathTraversal', cwe.path_traversal || 0);
            setEl('engCweCrypto', cwe.crypto || 0);
            setEl('engCweAuth', cwe.auth || 0);
            setEl('engCweSsrf', cwe.ssrf || 0);
            setEl('engCweOther', cwe.other || 0);

            // === Malware Panel (distinct packages, not raw findings) ===
            const malSt = mal['static'] || {};
            const malDy = mal.dynamic || {};
            setEl('engMalwareReachable', mal.total_packages || 0);
            setEl('engMalwareUnknown', 0);
            setEl('engMalwareCritical', mal.critical || 0);
            setEl('engMalwareHigh', mal.high || 0);
            setEl('engMalwareMedium', mal.medium || 0);
            setEl('engMalwareStatic', mal.confirmed_packages || 0);
            setEl('engMalwareDynamic', mal.suspicious_packages || 0);
            setEl('engMalwareTotal', mal.total_packages || 0);
            setEl('engMalwarePackages', mal.total_packages || 0);
            // Static subcategories
            setEl('engMalwareBackdoor', malSt.backdoor || 0);
            setEl('engMalwareCrypto', malSt.crypto || 0);
            setEl('engMalwareExfil', malSt.exfil || 0);
            setEl('engMalwareTypo', malSt.typosquat || 0);
            setEl('engMalwareObfuscation', malSt.obfuscation || 0);
            setEl('engMalwareCmdInject', malSt.cmd_inject || 0);
            setEl('engMalwareOther', malSt.other || 0);
            setEl('engStaticTotal', mal.static_total || 0);
            // Dynamic subcategories
            setEl('engDynamicMalicious', malDy.confirmed || 0);
            setEl('engDynamicSuspicious', malDy.suspicious || 0);
            setEl('engDynamicC2', malDy.c2 || 0);
            setEl('engDynamicFileExfil', malDy.exfil || 0);
            setEl('engDynamicCreds', malDy.creds || 0);
            setEl('engDynamicShell', malDy.shell || 0);
            setEl('engDynamicMining', malDy.mining || 0);
            setEl('engDynamicTotal', mal.dynamic_total || 0);

            // === Config Panel ===
            setEl('engConfigK8s', cfg.k8s || 0);
            setEl('engConfigDocker', cfg.docker || 0);
            setEl('engConfigPorts', cfg.ports || 0);
            setEl('engConfigOther', cfg.other || 0);
            setEl('engConfigTotal', cfg.total || 0);
            
            // Health issues (from enrichments or inferred)
            const enrichments = dashboardData.enrichments || {};
            const metrics = dashboardData.metrics || {};
            // v4.5.19: Add packages scanned to health panel
            const engHealthPkgsEl = document.getElementById('engHealthPackagesScanned');
            if (engHealthPkgsEl) engHealthPkgsEl.textContent = fmt(metrics.packages_scanned || 0);
            setEl('engHealthUnmaintained', enrichments.unmaintained || 0);
            setEl('engHealthOutdated', enrichments.outdated || 0);
            setEl('engHealthNoLicense', enrichments.no_license || 0);
            setEl('engHealthLowQuality', enrichments.low_quality || 0);
            setEl('engHealthTotal', (enrichments.unmaintained || 0) + (enrichments.outdated || 0) + (enrichments.no_license || 0) + (enrichments.low_quality || 0));
        }
        
        // v4.5.19: Trends Chart Initialization
        let trendsChart = null;
        
        
// === Trends series builder ===
// Series: Raw | Actionable (reach+unkn) | Critical(actionable) | High(actionable) | Medium(actionable)
function buildTrendsSeries(history) {
  const raw        = history.map(h => h.raw || 0);
  const actionable = history.map(h => h.actionable !== undefined
    ? h.actionable
    : (h.reachable || 0) + (h.unknown_reachability || 0));
  const critical   = history.map(h => h.actionable_critical !== undefined ? h.actionable_critical : (h.critical || 0));
  const high       = history.map(h => h.actionable_high     !== undefined ? h.actionable_high     : (h.high || 0));
  const medium     = history.map(h => h.actionable_medium   !== undefined ? h.actionable_medium   : (h.medium || 0));
  return { raw, actionable, critical, high, medium };
}

function initTrendsChart(data) {
            // P2.53 FIX: Use pre-computed trends.data_points (has .raw field with CONFIG excluded)
            // NOT scan_history (has total_issues field without .raw)
            const history = data.trends?.data_points || data.scan_history || [];
            const trendsNoData = document.getElementById('trendsNoData');
            const trendsChartWrapper = document.getElementById('trendsChartWrapper');
            const trendsSection = document.getElementById('trendsSection');
            
            // Need at least 2 data points for trends
            if (history.length < 2) {
                if (trendsNoData) trendsNoData.style.display = 'block';
                if (trendsChartWrapper) trendsChartWrapper.style.display = 'none';
                return;
            }
            
            // Show chart, hide no-data message
            if (trendsNoData) trendsNoData.style.display = 'none';
            if (trendsChartWrapper) trendsChartWrapper.style.display = 'block';
            
            // Prepare chart data
            const series = buildTrendsSeries(history);
            const labels = history.map(h => {
                const date = new Date(h.timestamp);
                return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
            });
            const totalData = history.map(h => h.total_issues || 0);
            const reachableData = history.map(h => h.reachable_issues || 0);
            const criticalData = history.map(h => (h.critical || 0) + (h.high || 0));
            
            // Create/update chart
            const ctx = document.getElementById('trendsChart');
            if (!ctx) return;
            
            if (trendsChart) {
                trendsChart.destroy();
            }
            
            trendsChart = new Chart(ctx, {
                type: 'line',
                data: {
                    labels: labels,
                    datasets: [
      { label: 'Raw',        data: series.raw,        borderColor: '#475569', backgroundColor: '#475569', tension: 0.3, fill: false, borderWidth: 1.5, pointRadius: 2, pointHoverRadius: 4, borderDash: [4,3] },
      { label: 'Actionable', data: series.actionable, borderColor: '#2979FF', backgroundColor: '#2979FF', tension: 0.3, fill: false, borderWidth: 2,   pointRadius: 3, pointHoverRadius: 5 },
      { label: 'Critical',   data: series.critical,   borderColor: '#FF1F1F', backgroundColor: '#FF1F1F', tension: 0.3, fill: false, borderWidth: 1.5, pointRadius: 2, pointHoverRadius: 4 },
      { label: 'High',       data: series.high,       borderColor: '#FF6B00', backgroundColor: '#FF6B00', tension: 0.3, fill: false, borderWidth: 1.5, pointRadius: 2, pointHoverRadius: 4 },
      { label: 'Medium',     data: series.medium,     borderColor: '#FFEE58', backgroundColor: '#FFEE58', tension: 0.3, fill: false, borderWidth: 1.5, pointRadius: 2, pointHoverRadius: 4 }
    ]},
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    interaction: {
                        intersect: false,
                        mode: 'index'
                    },
                    plugins: {
                        legend: {
                            position: 'top',
                            labels: {
                                color: '#94a3b8',
                                usePointStyle: true,
                                padding: 20
                            }
                        },
                        tooltip: {
                            backgroundColor: 'rgba(8, 14, 25, 0.9)',
                            titleColor: '#f1f5f9',
                            bodyColor: '#94a3b8',
                            borderColor: 'rgba(255,255,255,0.1)',
                            borderWidth: 1,
                            padding: 12,
                            displayColors: true
                        }
                    },
                    scales: {
                        x: {
                            grid: { color: 'rgba(255,255,255,0.05)' },
                            ticks: { color: '#64748b' }
                        },
                        y: {
                            beginAtZero: true,
                            grid: { color: 'rgba(255,255,255,0.05)' },
                            ticks: { color: '#64748b' }
                        }
                    }
                }
            });
            
            // Update summary stats
            const latest = history[history.length - 1];
            // Compare against oldest point in window, not second-to-last
            // (consecutive scans may be identical giving false 'No change')
            const previous = history[0];
            
            const updateTrendStat = (valueId, changeId, current, prev) => {
                const valueEl = document.getElementById(valueId);
                const changeEl = document.getElementById(changeId);
                if (valueEl) valueEl.textContent = current;
                if (changeEl) {
                    const diff = current - prev;
                    const pct = prev > 0 ? Math.round((diff / prev) * 100) : 0;
                    if (diff < 0) {
                        changeEl.className = 'trend-stat-change positive';
                        changeEl.textContent = `↓ ${Math.abs(pct)}% (${Math.abs(diff)} fewer)`;
                    } else if (diff > 0) {
                        changeEl.className = 'trend-stat-change negative';
                        changeEl.textContent = `↑ ${pct}% (${diff} more)`;
                    } else {
                        changeEl.className = 'trend-stat-change neutral';
                        changeEl.textContent = '— No change';
                    }
                }
            };
            
            const latestRaw        = latest.raw || 0;
            const latestActionable = latest.actionable !== undefined
              ? latest.actionable
              : (latest.reachable || 0) + (latest.unknown_reachability || 0);
            const prevActionable   = previous.actionable !== undefined
              ? previous.actionable
              : (previous.reachable || 0) + (previous.unknown_reachability || 0);

            updateTrendStat('trendRawValue',        'trendRawChange',        latestRaw,        previous.raw || 0);
            updateTrendStat('trendReachableValue',  'trendReachableChange',  latestActionable, prevActionable);
            updateTrendStat('trendCriticalValue',   'trendCriticalChange',   latest.actionable_critical !== undefined ? latest.actionable_critical : (latest.critical || 0),   previous.actionable_critical !== undefined ? previous.actionable_critical : (previous.critical || 0));
            updateTrendStat('trendHighValue',       'trendHighChange',       latest.actionable_high     !== undefined ? latest.actionable_high     : (latest.high || 0),       previous.actionable_high     !== undefined ? previous.actionable_high     : (previous.high || 0));
            updateTrendStat('trendMediumValue',     'trendMediumChange',     latest.actionable_medium   !== undefined ? latest.actionable_medium   : (latest.medium || 0),     previous.actionable_medium   !== undefined ? previous.actionable_medium   : (previous.medium || 0));
            // trendUnknownValue hidden — folded into Actionable
            

        }
        
        // Embedded data (works with file:// protocol)
        renderDashboard();
        initTrendsChart(dashboardData);
        // v5.2: V2 renderers (owasp-cards.js) handle all tab content
        if (typeof initV2Renderers === 'function') initV2Renderers();
        renderScanCoverage(dashboardData);
        // T7: Supply Chain Health tab
        if (typeof renderSupplyChain === 'function') renderSupplyChain();
        // UI-04: Populate footer with scan metadata from repo_metadata
        (function renderFooterMeta() {
            var rm = (dashboardData && dashboardData.repo_metadata) || {};
            var scanNum = rm.scan_number;
            var firstScan = rm.first_scan || '';
            var dbSize = rm.db_size_display || '';
            var sep = ' \u00b7 '; // middle dot
            var fFirst = document.getElementById('footerFirstScan');
            var fCount = document.getElementById('footerScanCount');
            var fDb = document.getElementById('footerDbSize');
            if (fFirst && firstScan) fFirst.textContent = sep + 'First scan: ' + firstScan;
            if (fCount && scanNum) fCount.textContent = sep + 'Scan #' + scanNum;
            if (fDb && dbSize) fDb.textContent = sep + 'DB: ' + dbSize;
        })();
    

        // === FILTER FUNCTIONS FOR CLICKABLE NUMBERS ===
        // P2.47: Fixed to use correct filter dropdown IDs and applyFilters function
        function filterBySeverity(severity) {
            console.log('Filtering Security Issues by severity:', severity);
            
            // Wait for DOM to be ready after tab switch
            setTimeout(() => {
                // Clear other filters first
                const typeFilter = document.getElementById('typeFilter');
                const reachableFilter = document.getElementById('reachableFilter');
                const riskFilter = document.getElementById('riskFilter');
                const searchBox = document.getElementById('searchBox');
                
                if (typeFilter) typeFilter.value = '';
                if (reachableFilter) reachableFilter.value = '';
                if (searchBox) searchBox.value = '';
                
                // Set severity filter (riskFilter is the dropdown ID)
                if (riskFilter) riskFilter.value = severity;
                
                // Apply filters
                if (typeof applyFilters === 'function') {
                    applyFilters();
                }
            }, 150);
        }
        
        function filterByReachability(state) {
            console.log('Filtering Security Issues by reachability:', state);
            
            // Normalize state value (UNKNOWN -> unknown)
            const normalizedState = state.toLowerCase();
            
            // Wait for DOM to be ready after tab switch
            setTimeout(() => {
                // Clear other filters first
                const typeFilter = document.getElementById('typeFilter');
                const riskFilter = document.getElementById('riskFilter');
                const reachableFilter = document.getElementById('reachableFilter');
                const searchBox = document.getElementById('searchBox');
                
                if (typeFilter) typeFilter.value = '';
                if (riskFilter) riskFilter.value = '';
                if (searchBox) searchBox.value = '';
                
                // Set reachability filter
                if (reachableFilter) reachableFilter.value = normalizedState;
                
                // Apply filters
                if (typeof applyFilters === 'function') {
                    applyFilters();
                }
            }, 150);
        }
        
        // P2.47: Combined filter - filter by both type and severity
        function filterByTypeAndSeverity(type, severity) {
            console.log('Filtering Security Issues by type:', type, 'and severity:', severity);
            
            // Wait for DOM to be ready after tab switch
            setTimeout(() => {
                const typeFilter = document.getElementById('typeFilter');
                const riskFilter = document.getElementById('riskFilter');
                const reachableFilter = document.getElementById('reachableFilter');
                const searchBox = document.getElementById('searchBox');
                
                // Clear search and reachability
                if (searchBox) searchBox.value = '';
                if (reachableFilter) reachableFilter.value = '';
                
                // Set type and severity filters
                if (typeFilter) typeFilter.value = type;
                if (riskFilter) riskFilter.value = severity;
                
                // Apply filters
                if (typeof applyFilters === 'function') {
                    applyFilters();
                }
            }, 150);
        }
        
        // P2.52: Combined filter - filter by both type and reachability (for Review Required breakdown)
        function filterByTypeAndReachability(type, reachability) {
            console.log('Filtering Security Issues by type:', type, 'and reachability:', reachability);
            
            // Normalize reachability value
            const normalizedReach = reachability.toLowerCase();
            
            // Wait for DOM to be ready after tab switch
            setTimeout(() => {
                const typeFilter = document.getElementById('typeFilter');
                const riskFilter = document.getElementById('riskFilter');
                const reachableFilter = document.getElementById('reachableFilter');
                const searchBox = document.getElementById('searchBox');
                
                // Clear search and severity
                if (searchBox) searchBox.value = '';
                if (riskFilter) riskFilter.value = '';
                
                // Set type and reachability filters
                if (typeFilter) typeFilter.value = type;
                if (reachableFilter) reachableFilter.value = normalizedReach;
                
                // Apply filters
                if (typeof applyFilters === 'function') {
                    applyFilters();
                }
            }, 150);
        }

        // === EXPOSE FILTER FUNCTIONS GLOBALLY FOR ONCLICK HANDLERS ===
        window.filterBySeverity = filterBySeverity;
        window.filterByReachability = filterByReachability;
        window.filterByTypeAndSeverity = filterByTypeAndSeverity;
        window.filterByTypeAndReachability = filterByTypeAndReachability;
        window.applyFilters = applyFilters;
        window.toggleMainPanel = toggleMainPanel;
        window.toggleSection = toggleSection;
        // Expose core helpers so owasp-cards.js (separate IIFE) can call them
        window.getReachabilityState = getReachabilityState;
        window.normalizeSeverity = normalizeSeverity;
        window.calculateRisk = calculateRisk;

        // P2.50: Filter Security Issues by type and switch to Security Issues tab
        function filterSecurityIssuesByType(type) {
            console.log('Filtering Security Issues by type:', type);
            
            // Switch to Security Issues tab
            const securityTab = document.querySelector('[data-tab="security-issues"]');
            if (securityTab) securityTab.click();
            
            // Wait for tab switch, then apply filter
            setTimeout(() => {
                const typeFilter = document.getElementById('typeFilter');
                const searchBox = document.getElementById('searchBox');
                const riskFilter = document.getElementById('riskFilter');
                const reachableFilter = document.getElementById('reachableFilter');
                
                // Clear other filters
                if (searchBox) searchBox.value = '';
                if (riskFilter) riskFilter.value = '';
                if (reachableFilter) reachableFilter.value = '';
                
                // Set type filter
                if (typeFilter) typeFilter.value = type;
                
                // Apply filters
                if (typeof applyFilters === 'function') {
                    applyFilters();
                }
            }, 150);
        }
        window.filterSecurityIssuesByType = filterSecurityIssuesByType;

        // P2.60: filterByOwaspCategory — delegated to owasp-cards.js via gotoFindings
        // The old type-based implementation was overwriting the correct compliance-filter version
        // Now just a thin wrapper: card onclick fires gotoFindings directly via owasp-cards.js
        // This stub exists only so any legacy references don't throw ReferenceError
        function filterByOwaspCategory(category, isLlm) {
            var prefix = isLlm ? 'OWASP-' : 'OWASP-';
            if (typeof gotoFindings === 'function') {
                gotoFindings({ compliance: prefix + category, search: '', pill: 'all' });
            }
        }
        window.filterByOwaspCategory = filterByOwaspCategory;
        // Expose core helpers for owasp-cards.js (separate IIFE scope)
        window.getReachabilityState = getReachabilityState;
        window.normalizeSeverity = normalizeSeverity;
        window.calculateRisk = calculateRisk;
        // BUG 10/17/29 FIX: Expose inferComplianceMapping for owasp-cards.js GRC renderer
        window.inferComplianceMapping = inferComplianceMapping;

        // setReachPill — called by owasp-cards.js onclick handlers to set reachability filter
        // e.g. setReachPill('reachable'), setReachPill('unknown'), setReachPill('')
        function setReachPill(state) {
            const reachableFilter = document.getElementById('reachableFilter');
            if (reachableFilter) reachableFilter.value = state || '';
        }
        window.setReachPill = setReachPill;





// ═══════════════════════════════════════════════════════════════
// SCAN COVERAGE RENDERER  (v1.0.0b15)
// ═══════════════════════════════════════════════════════════════
function _esc(s) {
    return String(s || '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

function _ecoFromPath(p) {
    p = (p || '').toLowerCase();
    if (p.endsWith('go.mod') || p.endsWith('go.sum')) return 'go';
    if (p.endsWith('package.json') || p.endsWith('yarn.lock') || p.endsWith('package-lock.json')) return 'javascript';
    if (p.endsWith('requirements.txt') || p.endsWith('pyproject.toml') || p.endsWith('setup.py')) return 'python';
    if (p.endsWith('cargo.toml') || p.endsWith('cargo.lock')) return 'rust';
    if (p.endsWith('pom.xml') || p.endsWith('build.gradle')) return 'java';
    return '';
}

function _covBar(id, pct, color) {
    var el = document.getElementById(id);
    if (!el) return;
    setTimeout(function() {
        el.style.width = Math.min(100, pct) + '%';
        el.style.background = color;
    }, 80);
}

function renderScanCoverage(d) {
    var cov = d && d.coverage_report;
    var noData = document.getElementById('covNoData');
    var sections = ['covHeroGrid','covRepoConfigSection','covRecsSection','covLangSection','covManifestSection',
                    'covBlindSection','covSubmodSection','covExcludeConfigSection','covExcludedSection'];

    if (!cov) {
        sections.forEach(function(id) {
            var el = document.getElementById(id);
            if (el) el.style.display = 'none';
        });
        if (noData) noData.style.display = '';
        return;
    }
    if (noData) noData.style.display = 'none';
    sections.forEach(function(id) {
        var el = document.getElementById(id);
        if (el) el.style.display = '';
    });

    // ── Score arc ────────────────────────────────────────────
    var pct   = Math.round((cov.coverage_score || 0) * 100);
    var circ  = 2 * Math.PI * 50;
    var color = pct >= 80 ? '#10b981' : pct >= 60 ? '#3b82f6' : pct >= 40 ? '#f59e0b' : '#ef4444';
    var arcEl = document.getElementById('covArcFill');
    var numEl = document.getElementById('covScoreNumber');
    if (arcEl) {
        arcEl.style.stroke = color;
        setTimeout(function() { arcEl.style.strokeDashoffset = circ - (pct / 100) * circ; }, 80);
    }
    if (numEl) numEl.textContent = pct + '%';

    // ── Stat: Files ───────────────────────────────────────────
    var files  = cov.files || {};
    var fTotal = files.total_found || 0;
    var fAnal  = files.analyzed   || 0;
    var fSkipP = files.skipped_patterns || 0;
    var fSkipD = files.skipped_dirs     || 0;
    var fPct   = fTotal > 0 ? Math.round(fAnal / fTotal * 100) : 100;
    var fColor = fPct >= 80 ? '#10b981' : '#f59e0b';
    var sManNum = document.getElementById('covManifestNum');
    var sManSub = document.getElementById('covManifestSub');
    if (sManNum) sManNum.textContent = fAnal.toLocaleString();
    if (sManSub) sManSub.textContent = fSkipP + ' test/gen skipped  ·  ' + fSkipD.toLocaleString() + ' in excl. dirs';
    _covBar('covManifestBar', fPct, fColor);

    // ── Stat: Languages ───────────────────────────────────────
    var langs = cov.languages || {};
    var lDet  = Object.keys(langs.detected || {}).length;
    var lAnal = Object.values(langs.analyzed || {}).filter(Boolean).length;
    var lGaps = (langs.gaps || []).length;
    var lPct  = lDet > 0 ? Math.round(lAnal / lDet * 100) : 100;
    var lColor= lPct >= 80 ? '#10b981' : '#f59e0b';
    var sLangNum = document.getElementById('covLangNum');
    var sLangSub = document.getElementById('covLangSub');
    if (sLangNum) sLangNum.textContent = lAnal;
    if (sLangSub) sLangSub.textContent = lDet + ' detected  ·  ' + lGaps + ' gap' + (lGaps === 1 ? '' : 's');
    _covBar('covLangBar', lPct, lColor);

    // ── Stat: Packages ────────────────────────────────────────
    var pkgs  = cov.packages || {};
    var pPct  = pkgs.reachability_coverage_pct || 0;
    var pColor= pPct >= 70 ? '#10b981' : pPct >= 40 ? '#3b82f6' : '#f59e0b';
    var sPkgNum = document.getElementById('covPkgNum');
    var sPkgSub = document.getElementById('covPkgSub');
    if (sPkgNum) sPkgNum.textContent = pkgs.with_reachability || 0;
    if (sPkgSub) sPkgSub.textContent = (pkgs.total_in_sbom || 0) + ' with CVEs  ·  ' + pPct + '% coverage';
    _covBar('covPkgBar', pPct, pColor);

    // ── Recommendations ───────────────────────────────────────
    var recList = document.getElementById('covRecList');
    if (recList) {
        var recs = cov.recommendations || [];
        if (recs.length === 0) {
            document.getElementById('covRecsSection').style.display = 'none';
        } else {
            recList.innerHTML = recs.map(function(r, i) {
                var p    = i === 0 ? 'priority-high' : i < 3 ? 'priority-medium' : 'priority-info';
                var icon = i === 0 ? '⚠️' : i < 3 ? '💡' : 'ℹ️';
                return '<div class="cov-rec-item ' + p + '"><span class="cov-rec-icon">' + icon + '</span><span class="cov-rec-text">' + _esc(r) + '</span></div>';
            }).join('');
        }
    }

    // ── Language cards ────────────────────────────────────────
    var langGrid = document.getElementById('covLangGrid');
    if (langGrid) {
        var detected = langs.detected || {};
        var analyzed = langs.analyzed || {};
        var gapsList = langs.gaps || [];
        var langKeys = Object.keys(detected).sort();
        if (langKeys.length === 0) {
            document.getElementById('covLangSection').style.display = 'none';
        } else {
            langGrid.innerHTML = langKeys.map(function(lang) {
                var ok  = !!analyzed[lang];
                var cnt = detected[lang];
                var gi  = gapsList.find(function(g) { return g.language === lang; });
                var cls = ok ? 'covered' : 'gap';
                return '<div class="cov-lang-card ' + cls + '">'
                     + '<div class="cov-lang-header"><span class="cov-lang-name">' + _esc(lang) + '</span>'
                     + '<span class="cov-lang-badge ' + cls + '">' + (ok ? '✓ Analyzed' : '⚠ Gap') + '</span></div>'
                     + '<div class="cov-lang-files">' + cnt.toLocaleString() + ' source file' + (cnt === 1 ? '' : 's') + '</div>'
                     + (gi ? '<div class="cov-lang-reason">' + _esc(gi.reason) + '</div>' : '')
                     + '</div>';
            }).join('');
        }
    }

    // ── Manifest table ────────────────────────────────────────
    var manBody = document.getElementById('covManifestBody');
    if (manBody) {
        var manifests = cov.manifests || {};
        var allM = (manifests.scanned || []).map(function(p) {
            return { path: p, ecosystem: _ecoFromPath(p), status: 'scanned', reason: '' };
        }).concat((manifests.skipped || []).map(function(s) {
            return { path: s.path, ecosystem: s.ecosystem || _ecoFromPath(s.path), status: 'skipped', reason: s.reason || '' };
        })).concat((manifests.excluded || []).map(function(e) {
            return { path: e.path, ecosystem: e.ecosystem || _ecoFromPath(e.path), status: 'excluded', reason: e.reason || ('excluded by config — ' + (e.excluded_dir || '')) };
        }));
        allM.sort(function(a, b) { return a.path.localeCompare(b.path); });
        if (allM.length === 0) {
            document.getElementById('covManifestSection').style.display = 'none';
        } else {
            manBody.innerHTML = allM.map(function(m) {
                var statusHtml = m.status === 'scanned'
                    ? '<span class="cov-scanned">✓ Scanned</span>'
                    : m.status === 'excluded'
                    ? '<span class="cov-excluded">⊘ Excluded</span>'
                    : '<span class="cov-skipped">⊘ Skipped</span>';
                return '<tr>'
                     + '<td><span class="cov-mono">' + _esc(m.path) + '</span></td>'
                     + '<td><span style="font-size:11px;color:#94a3b8;">' + _esc(m.ecosystem || '—') + '</span></td>'
                     + '<td>' + statusHtml + '</td>'
                     + '<td><span class="cov-reason-text">' + _esc(m.reason) + '</span></td>'
                     + '</tr>';
            }).join('');
        }
    }

    // ── Reachability blind spots ──────────────────────────────
    var blindGrid = document.getElementById('covBlindGrid');
    if (blindGrid) {
        var blinds = (cov.reachability_blind_spots || []).slice();
        var sevRank = { CRITICAL: 4, HIGH: 3, MEDIUM: 2, LOW: 1 };
        blinds.sort(function(a, b) { return (sevRank[b.severity] || 0) - (sevRank[a.severity] || 0); });
        if (blinds.length === 0) {
            document.getElementById('covBlindSection').style.display = 'none';
        } else {
            blindGrid.innerHTML = blinds.map(function(b) {
                var sev   = (b.severity || '').toLowerCase();
                var cves  = (b.cve_ids || []);
                var chips = cves.slice(0, 4).map(function(c) {
                    return '<span class="cov-cve-chip">' + _esc(c) + '</span>';
                }).join('');
                var more  = cves.length > 4 ? '<span style="font-size:10px;color:#64748b;">+' + (cves.length - 4) + ' more</span>' : '';
                return '<div class="cov-blind-card ' + sev + '">'
                     + '<div class="cov-blind-pkg">' + _esc(b.package) + '</div>'
                     + '<div class="cov-blind-ver">' + _esc(b.version || '') + '</div>'
                     + '<div class="cov-blind-cves">' + chips + more + '</div>'
                     + '<div class="cov-blind-reason">' + _esc(b.reason || '') + '</div>'
                     + '</div>';
            }).join('');
        }
    }

    // ── Sub-modules ───────────────────────────────────────────
    var submodGrid = document.getElementById('covSubmodGrid');
    if (submodGrid) {
        var subs = cov.sub_modules || [];
        if (subs.length === 0) {
            document.getElementById('covSubmodSection').style.display = 'none';
        } else {
            submodGrid.innerHTML = subs.map(function(s) {
                return '<div class="cov-submod-card">'
                     + '<div class="cov-submod-eco">' + _esc(s.ecosystem || '') + '</div>'
                     + '<div class="cov-submod-name">' + _esc(s.module_name || s.path) + '</div>'
                     + '<div class="cov-submod-path">' + _esc(s.path) + '</div>'
                     + '<span class="cov-submod-badge">Not Scanned</span>'
                     + '</div>';
            }).join('');
        }
    }

    // ── Exclude config summary ─────────────────────────────────
    var excCfgEl = document.getElementById('covExcludeConfigContent');
    if (excCfgEl) {
        var cfg = cov.exclude_config || {};
        var semgrepFile = cfg.semgrep_exclude_file || '';
        var guardFile   = cfg.guarddog_exclude_file || '';
        var semgrepOk   = cfg.semgrep_exclude_file_exists;
        var guardOk     = cfg.guarddog_exclude_file_exists;
        var builtIn     = cfg.dirs_excluded_builtin || 0;
        var userCfg     = cfg.dirs_excluded_user_config || 0;
        var totalDirs   = cfg.dirs_excluded_total || 0;
        var totalFiles  = cfg.files_excluded_total || 0;
        var totalSizeKb = cfg.size_excluded_kb || 0;
        var totalSizeFmt = totalSizeKb >= 1024 ? (totalSizeKb / 1024).toFixed(1) + ' MB' : totalSizeKb + ' KB';
        var builtinPats = cfg.builtin_patterns || [];

        var fileLink = function(fpath, exists, label) {
            if (!fpath) return '<span style="color:#64748b;">' + _esc(label) + ' — not found</span>';
            var badge = exists
                ? '<span style="color:#10b981;font-size:10px;margin-left:6px;">✓ exists</span>'
                : '<span style="color:#f59e0b;font-size:10px;margin-left:6px;">⚠ not created yet (run a scan first)</span>';
            return '<span class="cov-mono" style="font-size:11px;word-break:break-all;">' + _esc(fpath) + '</span>' + badge;
        };

        if (!semgrepFile && !guardFile) {
            document.getElementById('covExcludeConfigSection').style.display = 'none';
        } else {
            var html = '<div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:14px;">';
            html += '<div style="background:#0f172a;border:1px solid #1e293b;border-radius:6px;padding:12px;">';
            html += '<div style="font-size:10px;font-weight:600;color:#64748b;text-transform:uppercase;letter-spacing:.05em;margin-bottom:6px;">Semgrep / DLP / CWE</div>';
            html += fileLink(semgrepFile, semgrepOk, 'semgrep-exclude.txt');
            html += '</div>';
            html += '<div style="background:#0f172a;border:1px solid #1e293b;border-radius:6px;padding:12px;">';
            html += '<div style="font-size:10px;font-weight:600;color:#64748b;text-transform:uppercase;letter-spacing:.05em;margin-bottom:6px;">GuardDog Malware</div>';
            html += fileLink(guardFile, guardOk, 'guarddog-exclude.txt');
            html += '</div>';
            html += '</div>';

            html += '<div style="display:flex;gap:24px;margin-bottom:14px;flex-wrap:wrap;">';
            html += '<span style="font-size:12px;color:#94a3b8;"><span style="color:#e2e8f0;font-weight:600;">' + totalDirs + '</span> directories excluded total</span>';
            html += '<span style="font-size:12px;color:#94a3b8;"><span style="color:#e2e8f0;font-weight:600;">' + builtIn + '</span> built-in defaults</span>';
            html += '<span style="font-size:12px;color:#94a3b8;"><span style="color:' + (userCfg > 0 ? '#38bdf8' : '#475569') + ';font-weight:600;">' + userCfg + '</span> from your config</span>';
            html += '<span style="font-size:12px;color:#94a3b8;"><span style="color:#e2e8f0;font-weight:600;">' + totalFiles.toLocaleString() + ' files</span> excluded (' + totalSizeFmt + ')</span>';
            html += '</div>';

            if (builtinPats.length > 0) {
                html += '<div style="margin-bottom:6px;font-size:10px;font-weight:600;color:#64748b;text-transform:uppercase;letter-spacing:.05em;">Built-in default patterns</div>';
                html += '<div style="display:flex;flex-wrap:wrap;gap:6px;margin-bottom:4px;">';
                html += builtinPats.map(function(p) {
                    return '<span style="background:#1e293b;color:#94a3b8;font-family:monospace;font-size:10px;padding:2px 7px;border-radius:3px;">' + _esc(p) + '</span>';
                }).join('');
                html += '</div>';
            }

            excCfgEl.innerHTML = html;
        }
    }

    // ── Excluded directories ──────────────────────────────────
    var exclBody = document.getElementById('covExcludedBody');
    if (exclBody) {
        var excl = (cov.excluded_paths || []).slice();
        excl.sort(function(a, b) { return b.file_count - a.file_count; });
        if (excl.length === 0) {
            document.getElementById('covExcludedSection').style.display = 'none';
        } else {
            exclBody.innerHTML = excl.map(function(e) {
                var sz = e.size_kb >= 1024
                    ? (e.size_kb / 1024).toFixed(1) + ' MB'
                    : (e.size_kb || 0) + ' KB';
                var isUser = e.source === 'user-config';
                var srcBadge = isUser
                    ? '<span style="font-size:10px;color:#38bdf8;background:#0f2942;padding:1px 5px;border-radius:3px;">your config</span>'
                    : '<span style="font-size:10px;color:#64748b;">built-in</span>';
                var fileHint = (isUser && e.exclude_file)
                    ? '<div style="font-size:9px;color:#475569;margin-top:2px;word-break:break-all;">' + _esc(e.exclude_file) + '</div>'
                    : '';
                return '<tr>'
                     + '<td><span class="cov-mono">' + _esc(e.path) + '</span></td>'
                     + '<td>' + srcBadge + fileHint + '</td>'
                     + '<td><span class="cov-reason-text">' + _esc(e.reason) + '</span></td>'
                     + '<td style="text-align:right;color:#94a3b8;">' + (e.file_count || 0).toLocaleString() + '</td>'
                     + '<td style="text-align:right;color:#64748b;">' + sz + '</td>'
                     + '</tr>';
            }).join('');
        }
    }

    // ── ENH #2: Repository Config panel ──────────────────────────────────────
    var repoConfigEl = document.getElementById('covRepoConfigContent');
    if (repoConfigEl) {
        var scan       = d.scan || {};
        var repometa   = d.repo_metadata || {};
        var gitUrl     = scan.github_url || '';
        var branch     = scan.branch || '';
        var repoRoot   = scan.repo_root || '';
        var repoName   = scan.display || scan.repository || (repoRoot ? repoRoot.split('/').pop() : '');
        var scanStore  = '';
        var excCfg     = (d.coverage_report && d.coverage_report.exclude_config) || {};
        // Derive scan store from semgrep exclude file path
        var semgrepFile = excCfg.semgrep_exclude_file || '';
        if (semgrepFile) {
            var parts = semgrepFile.split('/');
            var slugIdx = parts.indexOf('scans');
            if (slugIdx >= 0 && parts[slugIdx + 1]) {
                scanStore = parts.slice(0, slugIdx + 2).join('/') + '/';
            }
        }

        // Visibility detection from git URL
        var visibility = 'unknown';
        var visClass   = 'unknown';
        if (gitUrl) {
            if (gitUrl.indexOf('github.com') >= 0 || gitUrl.indexOf('gitlab.com') >= 0 || gitUrl.indexOf('bitbucket.org') >= 0) {
                // Public hosting — could be public or private, can't tell without API
                visibility = 'unknown (hosted)';
                visClass   = 'unknown';
            }
            if (gitUrl.indexOf('@') >= 0) {
                // SSH — likely private (SSH implies auth)
                visibility = 'likely private (SSH)';
                visClass   = 'private';
            }
            if (gitUrl.indexOf('https://') === 0 && gitUrl.indexOf('github.com') >= 0) {
                visibility = 'unknown (HTTPS — check GitHub)';
                visClass   = 'unknown';
            }
        }

        var html = '<div class="cov-repo-grid">';

        // Card 1: Repository
        html += '<div class="cov-repo-card">';
        html += '<div class="cov-repo-card-label">Repository</div>';
        html += '<div class="cov-repo-card-value">' + _esc(repoName || '—') + '</div>';
        if (branch) html += '<div style="margin-top:4px;font-size:11px;color:#64748b;">branch: <span style="color:#22c55e;font-weight:600;">' + _esc(branch) + '</span></div>';
        html += '</div>';

        // Card 2: Origin URL
        html += '<div class="cov-repo-card">';
        html += '<div class="cov-repo-card-label">Origin URL</div>';
        if (gitUrl) {
            var httpUrl = gitUrl.replace(/^git@([^:]+):/, 'https://$1/').replace(/\.git$/, '');
            html += '<div class="cov-repo-card-value"><a href="' + _esc(httpUrl) + '" target="_blank" style="color:#60a5fa;text-decoration:none;" title="Open in browser">' + _esc(gitUrl) + ' ↗</a></div>';
        } else {
            html += '<div class="cov-repo-card-value" style="color:#475569;">—</div>';
        }
        html += '<div style="margin-top:4px;font-size:11px;color:#94a3b8;">Visibility: <span class="cov-repo-badge ' + visClass + '">' + visibility + '</span></div>';
        html += '</div>';

        // Card 3: Scan store
        html += '<div class="cov-repo-card">';
        html += '<div class="cov-repo-card-label">Scan Store</div>';
        html += '<div class="cov-repo-card-value" style="font-size:11px;">' + _esc(scanStore || repoRoot || '—') + '</div>';
        if (repometa.scan_number) {
            html += '<div style="margin-top:4px;font-size:11px;color:#64748b;">'
                  + repometa.scan_number + ' scan' + (repometa.scan_number !== 1 ? 's' : '')
                  + (repometa.first_scan ? ' · first: ' + repometa.first_scan : '')
                  + ' · ' + (repometa.db_size_display || '?') + '</div>';
        }
        html += '</div>';

        // Card 4: Config files
        html += '<div class="cov-repo-card">';
        html += '<div class="cov-repo-card-label">Config Files</div>';
        var semgrepOk  = excCfg.semgrep_exclude_file_exists;
        var guardOk    = excCfg.guarddog_exclude_file_exists;
        var guardFile  = excCfg.guarddog_exclude_file || '';
        html += '<div style="font-size:11px;color:#94a3b8;line-height:1.8;">';
        if (semgrepFile) {
            var sfName = semgrepFile.split('/').pop();
            html += (semgrepOk ? '✓ ' : '⚠ ') + '<span style="color:' + (semgrepOk ? '#e2e8f0' : '#f59e0b') + ';font-family:monospace;">' + _esc(sfName) + '</span>';
            html += '<span style="color:' + (semgrepOk ? '#10b981' : '#f59e0b') + ';margin-left:6px;font-size:10px;">' + (semgrepOk ? 'exists' : 'missing') + '</span><br>';
        }
        if (guardFile) {
            var gfName = guardFile.split('/').pop();
            html += (guardOk ? '✓ ' : '⚠ ') + '<span style="color:' + (guardOk ? '#e2e8f0' : '#f59e0b') + ';font-family:monospace;">' + _esc(gfName) + '</span>';
            html += '<span style="color:' + (guardOk ? '#10b981' : '#f59e0b') + ';margin-left:6px;font-size:10px;">' + (guardOk ? 'exists' : 'missing — run a scan to create') + '</span><br>';
        }
        html += '</div>';
        html += '</div>';

        html += '</div>'; // end cov-repo-grid

        // Visibility note if unknown
        if (visClass === 'unknown' && gitUrl) {
            html += '<div style="margin-top:8px;padding:8px 12px;background:rgba(245,158,11,0.06);border:1px solid rgba(245,158,11,0.15);border-radius:6px;font-size:11px;color:#f59e0b;">'
                  + '⚠ Repository visibility cannot be determined without a GitHub API call. '
                  + 'If this is a <strong>public repo</strong>, treat HIGH/CRITICAL secrets findings as immediate breach risk — rotate credentials now.'
                  + '</div>';
        }

        repoConfigEl.innerHTML = html;
    }
}

window.renderScanCoverage = renderScanCoverage;

// ── UI-02: Resizable columns ──────────────────────────────────────────────────
(function initColumnResize() {
    var table = document.getElementById('issuesTable');
    if (!table) return;
    var handles = table.querySelectorAll('.col-resize-handle');
    handles.forEach(function(handle) {
        var th = handle.parentElement;
        var startX, startW;
        handle.addEventListener('mousedown', function(e) {
            e.preventDefault();
            e.stopPropagation();
            startX = e.pageX;
            startW = th.offsetWidth;
            handle.classList.add('resizing');
            var onMove = function(e) {
                var newW = Math.max(40, startW + e.pageX - startX);
                th.style.width = newW + 'px';
                // find matching col by index
                var idx = Array.prototype.indexOf.call(th.parentElement.children, th);
                var cols = table.querySelectorAll('colgroup col');
                if (cols[idx]) cols[idx].style.width = newW + 'px';
            };
            var onUp = function() {
                handle.classList.remove('resizing');
                document.removeEventListener('mousemove', onMove);
                document.removeEventListener('mouseup', onUp);
            };
            document.addEventListener('mousemove', onMove);
            document.addEventListener('mouseup', onUp);
        });
        // prevent sort trigger on handle click
        handle.addEventListener('click', function(e) { e.stopPropagation(); });
    });
})();
