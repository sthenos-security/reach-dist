// Supply Chain Tab - Package Health Dashboard Component
// Add to main.js in the tab rendering section.
// Tab button goes between DLP/PII and GRC/Compliance in template-shell.html:
//   <button class="tab-btn" data-tab="supply-chain">
//     <span class="tab-icon">📦</span> Supply Chain
//   </button>
// Tab content div:
//   <div id="supply-chain" class="tab-content" style="display:none;"></div>
// Then add renderSupplyChain() call in tab switching logic.

function escapeHtml(str) {
    if (!str) return '';
    return String(str).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

function renderSupplyChain(containerId) {
    const container = document.getElementById(containerId || 'supplyChainContent');
    if (!container) return;

    const health = (typeof dashboardData !== 'undefined' ? dashboardData : {}).package_health;
    if (!health || !health.advisories) {
        container.innerHTML = '<div style="padding:40px;text-align:center;color:#64748b;"><p style="font-size:2em;margin:0;">📦</p><p>No package health data available.</p><p style="font-size:12px;">Package health analysis requires registry connectivity.</p></div>';
        return;
    }

    const summary = health.summary || {};
    const advisories = health.advisories || [];

    function statusBadge(status) {
        const map = {
            confused:   { bg: 'rgba(220,38,38,0.15)',   border: 'rgba(220,38,38,0.35)',   color: '#f87171', icon: '🔀', label: 'Dep Confusion' },
            abandoned:  { bg: 'rgba(234,88,12,0.12)',   border: 'rgba(234,88,12,0.3)',    color: '#fb923c', icon: '🏚️', label: 'Abandoned' },
            deprecated: { bg: 'rgba(202,138,4,0.12)',   border: 'rgba(202,138,4,0.3)',    color: '#fbbf24', icon: '⚠️',  label: 'Deprecated' },
            stale:      { bg: 'rgba(2,132,199,0.10)',   border: 'rgba(2,132,199,0.25)',   color: '#38bdf8', icon: '🕰️', label: 'Stale' },
            info:       { bg: 'rgba(100,116,139,0.10)', border: 'rgba(100,116,139,0.2)',  color: '#94a3b8', icon: 'ℹ️',  label: 'Info' },
            healthy:    { bg: 'rgba(34,197,94,0.08)',   border: 'rgba(34,197,94,0.2)',    color: '#4ade80', icon: '✅', label: 'Healthy' },
        };
        const m = map[status] || map.info;
        return `<span style="display:inline-flex;align-items:center;gap:4px;font-size:11px;font-weight:600;padding:3px 8px;border-radius:4px;background:${m.bg};border:1px solid ${m.border};color:${m.color};white-space:nowrap;">${m.icon} ${m.label}</span>`;
    }

    // Summary stat cards
    const statCards = [
        { val: summary.total_advisories || 0, label: 'Total Advisories', color: '#e2e8f0' },
        { val: summary.confused    || 0, label: 'Dep Confusion', color: '#f87171' },
        { val: summary.abandoned   || 0, label: 'Abandoned',     color: '#fb923c' },
        { val: summary.deprecated  || 0, label: 'Deprecated',    color: '#fbbf24' },
        { val: summary.stale       || 0, label: 'Stale',         color: '#38bdf8' },
        { val: summary.info        || 0, label: 'Info',          color: '#64748b' },
    ];

    let html = `
    <div class="v2-panel-header" style="margin-bottom:6px;">
        <span class="v2-panel-title">📦 Supply Chain Health</span>
    </div>
    <p class="v2-panel-subtitle" style="margin-bottom:20px;">
        Advisory signals for dependency maintenance and supply chain risks.
        These do <strong>not</strong> count toward vulnerability totals.
    </p>
    <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(130px,1fr));gap:10px;margin-bottom:24px;">
        ${statCards.map(s => `
        <div style="background:#1a2332;border:1px solid #1e293b;border-radius:8px;padding:16px 12px;text-align:center;">
            <div style="font-size:2em;font-weight:700;color:${s.val === 0 ? '#475569' : s.color};line-height:1.1;">${s.val}</div>
            <div style="font-size:11px;color:#64748b;margin-top:5px;font-weight:500;">${s.label}</div>
        </div>`).join('')}
    </div>`;

    // Dep confusion alert
    const confused = advisories.filter(a => a.status === 'confused');
    if (confused.length > 0) {
        html += `
        <div style="background:rgba(220,38,38,0.07);border:1px solid rgba(220,38,38,0.25);border-radius:8px;padding:16px 20px;margin-bottom:20px;">
            <h3 style="color:#f87171;margin:0 0 8px 0;font-size:14px;">🔀 Dependency Confusion Detected (${confused.length})</h3>
            <p style="margin:0 0 12px 0;font-size:13px;color:#94a3b8;">
                These internal packages have matching names on public registries.
                An attacker could publish a higher version to hijack installs.
            </p>
            <table style="width:100%;border-collapse:collapse;">
                <thead><tr>
                    <th style="text-align:left;padding:7px 10px;font-size:10px;font-weight:700;color:#475569;text-transform:uppercase;border-bottom:1px solid rgba(220,38,38,0.2);">Package</th>
                    <th style="text-align:left;padding:7px 10px;font-size:10px;font-weight:700;color:#475569;text-transform:uppercase;border-bottom:1px solid rgba(220,38,38,0.2);">Version</th>
                    <th style="text-align:left;padding:7px 10px;font-size:10px;font-weight:700;color:#475569;text-transform:uppercase;border-bottom:1px solid rgba(220,38,38,0.2);">Ecosystem</th>
                    <th style="text-align:left;padding:7px 10px;font-size:10px;font-weight:700;color:#475569;text-transform:uppercase;border-bottom:1px solid rgba(220,38,38,0.2);">Detail</th>
                </tr></thead>
                <tbody>
                    ${confused.map(a => `
                        <tr>
                            <td style="padding:8px 10px;font-size:12px;border-bottom:1px solid rgba(30,41,59,0.4);"><code style="color:#e2e8f0;">${escapeHtml(a.package)}</code></td>
                            <td style="padding:8px 10px;font-size:12px;color:#94a3b8;border-bottom:1px solid rgba(30,41,59,0.4);">${escapeHtml(a.version)}</td>
                            <td style="padding:8px 10px;font-size:12px;color:#94a3b8;border-bottom:1px solid rgba(30,41,59,0.4);">${escapeHtml(a.ecosystem)}</td>
                            <td style="padding:8px 10px;font-size:12px;color:#64748b;border-bottom:1px solid rgba(30,41,59,0.4);">${a.signals?.[0]?.detail ? escapeHtml(a.signals[0].detail) : '—'}</td>
                        </tr>`).join('')}
                </tbody>
            </table>
        </div>`;
    }

    // Withdrawn advisories
    const withdrawn = advisories.filter(a => a.osv_withdrawn);
    if (withdrawn.length > 0) {
        html += `
        <div style="background:rgba(127,29,29,0.07);border:1px solid rgba(127,29,29,0.25);border-radius:8px;padding:12px 16px;margin-bottom:20px;display:flex;gap:12px;align-items:flex-start;">
            <span style="font-size:1.3em;margin-top:1px;">⚠</span>
            <div>
                <strong style="color:#fca5a5;font-size:13px;">Retracted Advisories (${withdrawn.length})</strong>
                <p style="margin:4px 0 0;font-size:12px;color:#94a3b8;">
                    ${withdrawn.map(a => `<code>${escapeHtml(a.package)}</code>`).join(', ')}
                    — these advisories were withdrawn by the originating database. Verify before treating as actionable.
                </p>
            </div>
        </div>`;
    }

    // Main advisory table
    const nonConfused = advisories.filter(a => a.status !== 'confused');
    if (nonConfused.length > 0) {
        const nDirect = nonConfused.filter(a => a.is_direct).length;
        const nTransitive = nonConfused.filter(a => !a.is_direct).length;

        html += `
        <div style="background:#1a2332;border:1px solid #1e293b;border-radius:10px;overflow:hidden;">
            <div style="display:flex;justify-content:space-between;align-items:center;padding:14px 20px;border-bottom:1px solid #1e293b;flex-wrap:wrap;gap:8px;">
                <h3 style="margin:0;font-size:14px;font-weight:700;color:#e2e8f0;">Package Health Advisories</h3>
                <div style="display:flex;gap:6px;align-items:center;">
                    <span style="font-size:11px;color:#475569;margin-right:2px;">Show:</span>
                    <button onclick="scFilterPkgs('all',this)" class="sc-filter-btn sc-filter-active"
                        style="font-size:11px;padding:3px 10px;border-radius:4px;border:1px solid #475569;background:#0d1526;color:#e2e8f0;cursor:pointer;font-weight:600;">
                        All (${nonConfused.length})
                    </button>
                    <button onclick="scFilterPkgs('direct',this)" class="sc-filter-btn"
                        style="font-size:11px;padding:3px 10px;border-radius:4px;border:1px solid #1e293b;background:transparent;color:#64748b;cursor:pointer;">
                        Direct (${nDirect})
                    </button>
                    <button onclick="scFilterPkgs('transitive',this)" class="sc-filter-btn"
                        style="font-size:11px;padding:3px 10px;border-radius:4px;border:1px solid #1e293b;background:transparent;color:#64748b;cursor:pointer;">
                        Transitive (${nTransitive})
                    </button>
                </div>
            </div>
            <div style="font-size:11px;color:#475569;padding:7px 20px;background:rgba(0,0,0,0.18);border-bottom:1px solid #1e293b;">
                <strong style="color:#94a3b8;">DIRECT</strong> = listed in your manifest &nbsp;·&nbsp;
                <strong style="color:#64748b;">TRANSIT.</strong> = pulled in by your dependencies — lower priority to fix
            </div>
            <div style="overflow-x:auto;">
            <table id="scAdvisoryTable" style="width:100%;border-collapse:collapse;">
                <thead>
                    <tr style="background:rgba(0,0,0,0.2);">
                        <th style="padding:9px 10px 9px 20px;text-align:left;font-size:10px;font-weight:700;color:#475569;text-transform:uppercase;letter-spacing:0.06em;border-bottom:1px solid #1e293b;">Package</th>
                        <th style="padding:9px 10px;text-align:left;font-size:10px;font-weight:700;color:#475569;text-transform:uppercase;letter-spacing:0.06em;border-bottom:1px solid #1e293b;width:75px;">Version</th>
                        <th style="padding:9px 10px;text-align:left;font-size:10px;font-weight:700;color:#475569;text-transform:uppercase;letter-spacing:0.06em;border-bottom:1px solid #1e293b;width:90px;">Type</th>
                        <th style="padding:9px 10px;text-align:left;font-size:10px;font-weight:700;color:#475569;text-transform:uppercase;letter-spacing:0.06em;border-bottom:1px solid #1e293b;width:115px;">Status</th>
                        <th style="padding:9px 10px;text-align:left;font-size:10px;font-weight:700;color:#475569;text-transform:uppercase;letter-spacing:0.06em;border-bottom:1px solid #1e293b;width:120px;">Last Published</th>
                        <th style="padding:9px 10px;text-align:center;font-size:10px;font-weight:700;color:#475569;text-transform:uppercase;letter-spacing:0.06em;border-bottom:1px solid #1e293b;width:55px;">Maint.</th>
                        <th style="padding:9px 10px;text-align:left;font-size:10px;font-weight:700;color:#475569;text-transform:uppercase;letter-spacing:0.06em;border-bottom:1px solid #1e293b;width:95px;">Repo</th>
                        <th style="padding:9px 20px 9px 10px;text-align:left;font-size:10px;font-weight:700;color:#475569;text-transform:uppercase;letter-spacing:0.06em;border-bottom:1px solid #1e293b;">Signals</th>
                    </tr>
                </thead>
                <tbody>
                    ${nonConfused.map((a, i) => {
                        const daysStr = a.days_since_publish != null
                            ? (a.days_since_publish > 365
                                ? `${Math.floor(a.days_since_publish / 365)}y ${a.days_since_publish % 365}d ago`
                                : `${a.days_since_publish}d ago`)
                            : '\u2014';
                        const maintStr = a.maintainer_count != null ? a.maintainer_count : '\u2014';

                        const depTypeBadge = a.is_direct
                            ? `<span style="display:inline-block;font-size:10px;font-weight:700;color:#93c5fd;background:rgba(37,99,235,0.15);border:1px solid rgba(59,130,246,0.35);padding:2px 7px;border-radius:3px;letter-spacing:0.03em;">DIRECT</span>`
                            : `<span style="display:inline-block;font-size:10px;font-weight:600;color:#94a3b8;background:rgba(71,85,105,0.18);border:1px solid rgba(100,116,139,0.3);padding:2px 7px;border-radius:3px;letter-spacing:0.03em;">TRANSIT.</span>`;

                        const repoUrl = a.repository_url ? a.repository_url.replace(/^git\+/, '').replace(/\.git$/, '') : null;
                        const repoLink = repoUrl
                            ? `<a href="${repoUrl}" style="color:#42A5F5;font-size:11px;text-decoration:none;" target="_blank">${repoUrl.includes('github.com') ? 'GitHub ↗' : repoUrl.includes('gitlab.com') ? 'GitLab ↗' : 'Repo ↗'}</a>`
                            : '<span style="color:#334155;font-size:11px;">—</span>';

                        const withdrawnBadge = a.osv_withdrawn
                            ? `<span style="display:inline-block;margin-left:5px;font-size:10px;color:#fca5a5;background:rgba(127,29,29,0.2);border:1px solid rgba(127,29,29,0.3);padding:1px 5px;border-radius:3px;" title="Retracted ${a.osv_withdrawn}">⚠ Withdrawn</span>`
                            : '';

                        const signalDetail = (a.signals || []).map(s => {
                            const tip = [s.detail, s.remediation].filter(Boolean).join(' → ');
                            const sev = s.severity === 'high' ? '#fb923c' : s.severity === 'medium' ? '#fbbf24' : '#64748b';
                            return `<span style="display:inline-block;padding:2px 7px;border-radius:3px;font-size:11px;background:rgba(100,116,139,0.1);border:1px solid ${sev}33;color:${sev};margin:1px;cursor:help;" title="${escapeHtml(tip)}">${escapeHtml(s.signal_type)}</span>`;
                        }).join('');

                        const rowBase = i % 2 === 0 ? 'transparent' : 'rgba(0,0,0,0.1)';

                        return `
                        <tr data-dep-type="${a.is_direct ? 'direct' : 'transitive'}" data-row-base="${rowBase}"
                            style="background:${rowBase};"
                            onmouseover="this.style.background='rgba(255,255,255,0.03)'"
                            onmouseout="this.style.background=this.dataset.rowBase">
                            <td style="padding:9px 10px 9px 20px;border-bottom:1px solid rgba(30,41,59,0.45);vertical-align:middle;">
                                <code style="font-size:12px;color:#e2e8f0;">${escapeHtml(a.package)}</code>${withdrawnBadge}
                                ${a.latest_version && a.latest_version !== a.version
                                    ? `<br><small style="color:#475569;font-size:10px;" title="You have ${escapeHtml(a.version)}">latest: ${escapeHtml(a.latest_version)}</small>`
                                    : ''}
                                ${a.ecosystem ? `<br><small style="color:#334155;font-size:10px;">${escapeHtml(a.ecosystem)}</small>` : ''}
                            </td>
                            <td style="padding:9px 10px;border-bottom:1px solid rgba(30,41,59,0.45);font-size:12px;color:#64748b;vertical-align:middle;white-space:nowrap;">${escapeHtml(a.version)}</td>
                            <td style="padding:9px 10px;border-bottom:1px solid rgba(30,41,59,0.45);vertical-align:middle;">${depTypeBadge}</td>
                            <td style="padding:9px 10px;border-bottom:1px solid rgba(30,41,59,0.45);vertical-align:middle;">${statusBadge(a.status)}</td>
                            <td style="padding:9px 10px;border-bottom:1px solid rgba(30,41,59,0.45);font-size:12px;color:#64748b;vertical-align:middle;white-space:nowrap;">${daysStr}</td>
                            <td style="padding:9px 10px;border-bottom:1px solid rgba(30,41,59,0.45);font-size:12px;color:#64748b;text-align:center;vertical-align:middle;">${maintStr}</td>
                            <td style="padding:9px 10px;border-bottom:1px solid rgba(30,41,59,0.45);vertical-align:middle;">${repoLink}</td>
                            <td style="padding:9px 20px 9px 10px;border-bottom:1px solid rgba(30,41,59,0.45);vertical-align:middle;">${signalDetail}</td>
                        </tr>`;
                    }).join('')}
                </tbody>
            </table>
            </div>
        </div>`;
    }

    if (advisories.length === 0) {
        html += `
        <div style="background:#1a2332;border:1px solid #1e293b;border-radius:10px;padding:40px;text-align:center;">
            <p style="font-size:2em;margin:0;">✅</p>
            <p style="margin:10px 0 4px;font-weight:700;color:#e2e8f0;">All packages healthy</p>
            <p style="color:#64748b;font-size:13px;margin:0;">No abandoned, deprecated, or confused packages detected.</p>
        </div>`;
    }

    // Filter function
    if (!window.scFilterPkgs) {
        window.scFilterPkgs = function(type, btn) {
            var table = document.getElementById('scAdvisoryTable');
            if (!table) return;
            table.querySelectorAll('tbody tr').forEach(function(row) {
                if (type === 'all') { row.style.display = ''; return; }
                row.style.display = row.dataset.depType === type ? '' : 'none';
            });
            document.querySelectorAll('.sc-filter-btn').forEach(function(b) {
                b.classList.remove('sc-filter-active');
                b.style.background = 'transparent';
                b.style.color = '#64748b';
                b.style.borderColor = '#1e293b';
                b.style.fontWeight = '';
            });
            btn.classList.add('sc-filter-active');
            btn.style.background = '#0d1526';
            btn.style.color = '#e2e8f0';
            btn.style.borderColor = '#475569';
            btn.style.fontWeight = '600';
        };
    }

    container.innerHTML = html;
}

// Auto-render when this script loads.
(function () {
    if (typeof dashboardData !== 'undefined') {
        renderSupplyChain('supplyChainContent');
    }
})();
