// === V2 RENDERERS — Standardized 2-line reduction, clickable everything ===
(function(){

// ═══════════════════════════════════════════════════════════
// CENTRAL NAVIGATION — gotoFindings(cfg)
// Every counter link in every panel calls this ONE function.
// cfg: { type, severity, compliance, search, pill, stop }
// ═══════════════════════════════════════════════════════════
window.gotoFindings = function(cfg) {
  cfg = cfg || {};
  if (cfg.stop && window.event) try { window.event.stopPropagation(); } catch(e) {}
  if (typeof activateTab === 'function') activateTab('security-issues');
  var el = function(id) { return document.getElementById(id); };
  // Always reset ALL filters first — prevents stale state from previous navigation
  if (el('typeFilter'))       el('typeFilter').value       = cfg.type       || '';
  if (el('riskFilter'))       el('riskFilter').value       = cfg.severity   || '';
  if (el('complianceFilter')) el('complianceFilter').value = cfg.compliance  || '';
  if (el('searchBox'))        el('searchBox').value        = cfg.search      !== undefined ? cfg.search : '';
  // Pill / reachability filter
  var pill = cfg.pill || 'all';
  var rf = el('reachableFilter');
  if (rf) rf.value = (pill === 'all') ? '' : pill;
  document.querySelectorAll('.v2-pill[data-reach-filter]').forEach(function(b) {
    b.classList.toggle('v2-pill-active', b.getAttribute('data-reach-filter') === pill);
  });
  if (typeof applyFilters === 'function') applyFilters();
};

// Reset all findings filters to clean state (called when returning to findings tab manually)
window.resetFindingsFilters = function() {
  var el = function(id) { return document.getElementById(id); };
  ['typeFilter','riskFilter','complianceFilter','searchBox','reachableFilter'].forEach(function(id){
    var e = el(id); if (e) e.value = '';
  });
  document.querySelectorAll('.v2-pill[data-reach-filter]').forEach(function(b) {
    b.classList.toggle('v2-pill-active', b.getAttribute('data-reach-filter') === 'all');
  });
  if (typeof applyFilters === 'function') applyFilters();
};

// Hook activateTab: reset filters when user manually clicks Findings tab
(function() {
  var _origActivate = window.activateTab;
  window.activateTab = function(name) {
    if (_origActivate) _origActivate(name);
    // When manually switching TO findings tab (not via gotoFindings), reset filters
    // gotoFindings calls activateTab internally — distinguish by checking if we're
    // already in a gotoFindings call via a flag
    if ((name === 'security-issues' || name === 'tab-security-issues') && !window._inGotoFindings) {
      window.resetFindingsFilters && window.resetFindingsFilters();
    }
  };
})();

// Set flag during gotoFindings so activateTab hook doesn't double-reset
var _origGotoFindings = window.gotoFindings;
window.gotoFindings = function(cfg) {
  window._inGotoFindings = true;
  _origGotoFindings(cfg);
  window._inGotoFindings = false;
};

function go(cfg) {
  var parts = [];
  if (cfg.stop)                   parts.push('stop:true');
  if (cfg.type)                   parts.push("type:'" + cfg.type + "'");
  if (cfg.severity)               parts.push("severity:'" + cfg.severity + "'");
  if (cfg.compliance)             parts.push("compliance:'" + cfg.compliance + "'");
  if (cfg.search !== undefined)   parts.push("search:'" + cfg.search + "'");
  if (cfg.pill)                   parts.push("pill:'" + cfg.pill + "'");
  return 'gotoFindings({' + parts.join(',') + '})';
}



// ===========================
// SHARED: Noise reduction panel (matches backend UI)
// ===========================
function reductionStrip(rawTotal, reachTotal, unknTotal, unreachTotal, noisePct, opts) {
  opts = opts || {};
  var tf = opts.typeFilter || '';
  var actionable = reachTotal + unknTotal;
  var barPct = rawTotal > 0 ? ((actionable / rawTotal) * 100).toFixed(1) : 0;
  function ck(pill) {
    var cfg = {pill: pill || 'all'};
    if (tf) cfg.type = tf;
    return go(cfg);
  }
  return '<div style="background:#0f1729;border:1px solid #1e293b;border-radius:10px;padding:20px 24px;">' +
    // Header row: title + noise %
    '<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:16px;">' +
      '<div style="font-size:12px;font-weight:700;color:#94a3b8;text-transform:uppercase;letter-spacing:1px;">Noise Reduction</div>' +
      '<div style="color:#22c55e;font-weight:600;font-size:11px;">' + noisePct + '% noise eliminated</div>' +
    '</div>' +
    // Bar 1: Total findings
    '<div style="margin-bottom:12px;">' +
      '<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:6px;">' +
        '<a style="cursor:pointer;font-size:13px;color:#94a3b8;" onclick="' + ck('all') + '">Total findings</a>' +
        '<a style="cursor:pointer;font-size:15px;font-weight:700;color:#e2e8f0;" onclick="' + ck('all') + '">' + rawTotal + '</a>' +
      '</div>' +
      '<div style="height:10px;background:#1e293b;border-radius:5px;overflow:hidden;">' +
        '<div style="height:100%;width:100%;background:#475569;border-radius:5px;"></div>' +
      '</div>' +
    '</div>' +
    // Bar 2: Actionable (reachable + unknown)
    '<div style="margin-bottom:16px;">' +
      '<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:6px;">' +
        '<a style="cursor:pointer;font-size:13px;color:#2979FF;font-weight:600;" onclick="' + ck('actionable') + '">Actionable</a>' +
        '<a style="cursor:pointer;font-size:15px;font-weight:700;color:#2979FF;" onclick="' + ck('actionable') + '">' + actionable + '</a>' +
      '</div>' +
      '<div style="height:10px;background:#1e293b;border-radius:5px;overflow:hidden;">' +
        '<div style="height:100%;width:' + barPct + '%;background:#2979FF;border-radius:5px;min-width:' + (actionable > 0 ? '4px' : '0') + ';"></div>' +
      '</div>' +
      // Breakdown: reachable + unknown
      '<div style="display:flex;gap:20px;margin-top:8px;font-size:12px;">' +
        '<span style="color:#42A5F5;font-weight:700;font-size:12px;">&#9679;</span> <a style="cursor:pointer;color:#42A5F5;font-weight:600;" onclick="' + ck('reachable') + '">' + reachTotal + ' reachable</a>' +
        '<span style="color:#78909C;font-weight:700;font-size:12px;">&#9679;</span> <a style="cursor:pointer;color:#78909C;font-weight:600;" onclick="' + ck('unknown') + '">' + unknTotal + ' unknown</a>' +
      '</div>' +
    '</div>' +
    // Footer
    '<div style="border-top:1px solid #1e293b;padding-top:14px;margin-top:4px;">' +
      '<div style="font-size:14px;font-weight:600;color:#cbd5e1;line-height:1.5;">' +
        '<a style="cursor:pointer;color:#f1f5f9;font-weight:800;" onclick="' + ck('all') + '">' + rawTotal + ' findings</a> scanned' +
        ' \u2192 <a style="cursor:pointer;color:#2979FF;font-weight:800;" onclick="' + ck('actionable') + '">' + actionable + ' require action</a>' +
      '</div>' +
      '<div style="font-size:11px;color:#475569;margin-top:6px;">' + actionable + ' actionable: ' + reachTotal + ' reachable + ' + unknTotal + ' unknown</div>' +
    '</div>' +
  '</div>';
}


// ── Consistent single-line stats bar used across all panels ──────────────
// Each item: { label, value, color, bg, onclick }
function statBar(items) {
  return '<div style="display:flex;gap:8px;align-items:stretch;flex-wrap:wrap;">' +
    items.map(function(it) {
      var bg  = it.bg  || 'rgba(255,255,255,0.04)';
      var col = it.color || '#94a3b8';
      var cls = it.onclick ? 'v2-stat-pill v2-stat-pill-click' : 'v2-stat-pill';
      var click = it.onclick ? ' onclick="'+it.onclick+'"' : '';
      return '<div class="'+cls+'"'+click+' style="background:'+bg+';border:1px solid rgba(255,255,255,0.07);border-radius:7px;padding:8px 14px;display:flex;flex-direction:column;align-items:center;min-width:80px;transition:all 0.15s ease;">' +
        '<span style="font-size:18px;font-weight:800;color:'+col+';line-height:1;">'+it.value+'</span>' +
        '<span style="font-size:10px;color:#64748b;margin-top:3px;white-space:nowrap;">'+it.label+'</span>' +
      '</div>';
    }).join('') +
  '</div>';
}

// ===========================
// RISK & POSTURE \u2014 verdict-driven, actionable-first
// ===========================
function renderRiskPosture(d) {
  var funnel = d.funnel || {};
  var es = d.exec_summary || {};
  var issues = d.issues || [];
  // BUG-CTR-05 FIX: rawTotal must match applyFilters pill:'all' which excludes not_applicable AND CONFIG
  // CONFIG findings get reachability_state overridden to 'not_applicable' by getReachabilityState(),
  // but their raw f.reachability_state may still be 'unknown'. Exclude both to match table.
  var rawTotal = issues.filter(function(f) { return f.reachability_state !== 'not_applicable' && (f.type||'').toUpperCase() !== 'CONFIG'; }).length || funnel.raw_total || 0;
  var reachTotal = funnel.reachable_total || 0;
  var unknTotal = funnel.unknown_total || 0;
  var unreachTotal = funnel.unreachable_total || 0;
  var noisePct = funnel.noise_reduction_pct || 0;
  var posture = (es.posture || 'low').toLowerCase();
  var critTotal = es.critical_total || 0;
  var highTotal = es.high_total || 0;
  var actionable = reachTotal + unknTotal;
  var malPkgCount = es.malware_package_count || 0;

  // === 1. VERDICT BANNER \u2014 dynamic color/message, highest risk level only ===
  var verdictCfg = {
    critical: { color:'#FF1F1F', bg:'rgba(30,41,59,0.8)', border:'rgba(239,68,68,0.3)', dot:'\ud83d\udd34', label:'RISK CRITICAL', msg:'Remediate Immediately' },
    high:     { color:'#f59e0b', bg:'rgba(30,41,59,0.8)', border:'rgba(245,158,11,0.3)', dot:'\ud83d\udfe0', label:'RISK HIGH',     msg:'Remediate within 2 weeks' },
    medium:   { color:'#B8960C', bg:'rgba(30,41,59,0.8)',  border:'rgba(234,179,8,0.3)',  dot:'\ud83d\udfe1', label:'RISK MEDIUM',   msg:'Schedule for Remediation' },
    low:      { color:'#66BB6A', bg:'rgba(30,41,59,0.8)',  border:'rgba(34,197,94,0.3)',  dot:'\ud83d\udfe2', label:'RISK LOW',      msg:'No Immediate Action Required' }
  };
  var vc = verdictCfg[posture] || verdictCfg.low;
  var verdictMount = document.getElementById('riskVerdictBanner');
  if (verdictMount) {
    verdictMount.innerHTML =
      '<div style="background:' + vc.bg + ';border:1px solid ' + vc.border + ';border-radius:10px;padding:18px 24px;">' +
        '<div style="display:flex;align-items:center;gap:14px;">' +
          '<span style="font-size:28px;line-height:1;">' + vc.dot + '</span>' +
          '<div>' +
            '<div style="font-size:17px;font-weight:800;color:' + vc.color + ';text-transform:uppercase;letter-spacing:1.5px;">' +
              (vc.label || posture.toUpperCase()) + ' &nbsp;&middot;&nbsp; ' + vc.msg +
            '</div>' +
            '<div style="font-size:12px;color:#94a3b8;margin-top:5px;">' +
              actionable + ' actionable finding' + (actionable !== 1 ? 's' : '') +
              ' identified from ' + rawTotal + ' total signals' +
            '</div>' +
          '</div>' +
        '</div>' +
      '</div>';
  }

  // === 2. HERO CARDS — removed ===
  var heroMount = document.getElementById('riskHeroCards');
  if (heroMount) { heroMount.innerHTML = ''; heroMount.style.display = 'none'; }

  // === 3. NOISE REDUCTION STRIP ===
  var noiseMount = document.getElementById('riskNoiseSummary');
  if (noiseMount) noiseMount.innerHTML = reductionStrip(rawTotal, reachTotal, unknTotal, unreachTotal, noisePct);

  // === 4. SIGNAL CARDS \u2014 reachable count per type ===
  var reachSig = funnel.reachable_signals || {};
  var signals = [
    { key:'CVE',     label:'CVEs',            color:'#f87171', filter:'CVE' },
    { key:'CWE',     label:'Code Weaknesses',  color:'#f472b6', filter:'CWE' },
    { key:'SECRET',  label:'Secrets',          color:'#fbbf24', filter:'SECRET' },
    { key:'MALWARE', label:'Malware',           color:'#fb923c', filter:'MALWARE', extra:'SUSPICIOUS' },
    { key:'AI',      label:'AI / LLM',          color:'#818cf8', filter:'AI' },
    { key:'DLP',     label:'DLP / PII',         color:'#fdba74', filter:'DLP' },
  ];
  var sigMount = document.getElementById('riskSignalCards');
  if (sigMount) {
    var unknSig = funnel.unknown_signals || {};
    sigMount.innerHTML = signals.map(function(s) {
      var reach = (reachSig[s.key] || 0) + (s.extra ? (reachSig[s.extra] || 0) : 0);
      var unkn  = (unknSig[s.key]  || 0) + (s.extra ? (unknSig[s.extra]  || 0) : 0);
      var active = reach > 0 || unkn > 0;
      return '<div class="v2-signal-card' + (active ? ' v2-signal-card-active' : ' v2-signal-card-clear') + '">' +
        '<div style="font-size:11px;color:' + (active ? s.color : '#64748b') + ';font-weight:600;margin-bottom:8px;">' + s.label + '</div>' +
        '<div style="display:flex;gap:12px;align-items:flex-end;">' +
          '<div style="cursor:pointer;" onclick="' + go({type:s.filter,pill:'reachable'}) + '">' +
            '<div style="font-size:26px;font-weight:800;color:' + (reach > 0 ? '#42A5F5' : '#334155') + ';">' + reach + '</div>' +
            '<div style="font-size:10px;color:#42A5F5;font-weight:600;">reachable</div>' +
          '</div>' +
          '<div style="cursor:pointer;" onclick="' + go({type:s.filter,pill:'unknown'}) + '">' +
            '<div style="font-size:26px;font-weight:800;color:' + (unkn > 0 ? '#78909C' : '#334155') + ';">' + unkn + '</div>' +
            '<div style="font-size:10px;color:#78909C;font-weight:600;">unknown</div>' +
          '</div>' +
        '</div>' +
      '</div>';
    }).join('');
  }

  // === 5. ACTIONABLE SEVERITY \u2014 risk-correlated (reachable + unknown only, excludes noise) ===
  var sevMount = document.getElementById('riskSeverityRow');
  if (sevMount) {
    var sevs = [
      { label:'Critical', val:'CRITICAL', color:'#FF1F1F', bg:'rgba(15,23,42,0.75)' },
      { label:'High',      val:'HIGH',     color:'#f59e0b', bg:'rgba(15,23,42,0.75)' },
      { label:'Medium',   val:'MEDIUM',   color:'#B8960C', bg:'rgba(15,23,42,0.75)' },
      { label:'Low',      val:'LOW',      color:'#66BB6A', bg:'rgba(15,23,42,0.75)' },
    ];
    var rsFunc = (typeof getReachabilityState === 'function') ? getReachabilityState : function(f) { return f.reachability_state || 'unknown'; };
    var nsFunc = (typeof normalizeSeverity === 'function') ? normalizeSeverity : function(s) { return (s || '').toUpperCase(); };
    var configExcluded = funnel.config_excluded || false;
    var counts = {};
    issues.forEach(function(f) {
      if (rsFunc(f) === 'not_reachable') return;
      if (f.reachability_state === 'not_applicable' || (configExcluded && f.type === 'CONFIG')) return;
      var sv = nsFunc(f.severity);
      counts[sv] = (counts[sv] || 0) + 1;
    });
    sevMount.innerHTML = sevs.map(function(s) {
      var c = counts[s.val] || 0;
      return '<div style="flex:1;background:' + s.bg + ';border:1px solid ' + s.color + '22;border-radius:8px;padding:12px 16px;cursor:pointer;text-align:center;" onclick="' + go({severity:s.val,pill:'actionable'}) + '">' +
        '<div style="font-size:24px;font-weight:800;color:' + s.color + ';">' + c + '</div>' +
        '<div style="font-size:11px;color:' + s.color + ';font-weight:600;">' + s.label + '</div>' +
      '</div>';
    }).join('');
  }

  // === 6. FOOTER \u2014 removed (info in verdict banner) ===
  var footerMount = document.getElementById('riskScoreFooter');
  if (footerMount) { footerMount.innerHTML = ''; footerMount.style.display = 'none'; }
  // Also hide the parent section if it exists
  var footerSection = footerMount && footerMount.closest ? footerMount.closest('.v2-section') : null;
  if (footerSection) footerSection.style.display = 'none';
}
// ===========================
// ===========================
// AI ATTACK SURFACE
// ===========================
function renderAIAttackSurface(d) {
  var flowMount = document.getElementById('attackSurfaceFlow');
  var detailMount = document.getElementById('attackSurfaceDetail');
  if (!flowMount || !detailMount) return;
  var aiSec = d.ai_security || {};
  var issues = (d.issues || []).filter(function(f) { return (f.type||'').toUpperCase() === 'AI'; });
  var byOwasp = aiSec.by_owasp || {};
  // BUG-CTR-ACTIONABLE FIX: Build actionable counts (reachable + unknown) per OWASP category.
  // Previously badges used raw byOwasp totals (e.g. 5) but detail panels showed actionable (e.g. 3),
  // creating a confusing mismatch.  Dashboard is actionable-first — badges must match.
  var byOwaspBreakdown = aiSec.by_owasp_breakdown || {};
  var byOwaspActionable = {};
  Object.keys(byOwasp).forEach(function(cat) {
    var bd = byOwaspBreakdown[cat] || {};
    byOwaspActionable[cat] = (bd.reachable || 0) + (bd.unknown || 0);
  });
  var stages = [
    { id:'user',   label:'USER INPUT',  owasp:['LLM01'],                   desc:'User prompts & external inputs',  vulns:'Prompt injection, jailbreaks' },
    { id:'prompt', label:'PROMPT',       owasp:['LLM01','LLM07'],           desc:'System prompts & templates',      vulns:'Template injection, prompt leakage' },
    { id:'guard',  label:'GUARDRAILS',   owasp:['LLM01','LLM02'],           desc:'Input & output validation layer',  vulns:'Injection bypass, PII leakage through guard' },
    { id:'llm',    label:'LLM / MODEL',  owasp:['LLM04','LLM09','LLM03'],   desc:'Language model inference',         vulns:'Data poisoning, hallucination, model supply chain' },
    { id:'tools',  label:'TOOLS / API',  owasp:['LLM06','LLM10'],           desc:'Function calling & tool use',      vulns:'Excessive agency, unbounded consumption' },
    { id:'rag',    label:'RAG / DATA',   owasp:['LLM08','LLM02','LLM03'],   desc:'Retrieval augmented generation',   vulns:'Vector injection, data disclosure, supply chain' },
    { id:'output', label:'OUTPUT',       owasp:['LLM05','LLM02'],           desc:'Response to user/system',          vulns:'Improper output handling, information disclosure' },
  ];
  // BUG-CTR-ACTIONABLE FIX: Use actionable counts for stage badges (not raw totals)
  stages.forEach(function(s) { s.count = 0; s.owasp.forEach(function(o) { s.count += (byOwaspActionable[o] || 0); }); });
  // BUG-CTR-01 v2: totalAI = real total. Use pipelineCount for stage sum.
  var _noneCount = byOwasp['NONE'] || 0;
  var totalAI_raw = (aiSec.total != null && aiSec.total > 0) ? aiSec.total : issues.length;
  // BUG-CTR-01 FIX: Banner must show actionable count (excludes NONE/informational)
  var totalAI = totalAI_raw - _noneCount;
  var pipelineCount = stages.reduce(function(s,st){ return s + st.count; }, 0);
  if (totalAI === 0) {
    flowMount.innerHTML = '';
    detailMount.innerHTML = '<div class="v2-attack-detail-empty">No AI/LLM findings. Enable with <code style="color:#66BB6A;">--enable-ai</code>.</div>';
    return;
  }
  // UI-03 FIX: fallback to counting from issues[] if aiSec summary is missing/stale
  var _aiReachFromIssues = issues.filter(function(f){ return (f.reachability_state||'').toLowerCase()==='reachable'; }).length;
  var _aiUnknFromIssues  = issues.filter(function(f){ return (f.reachability_state||'').toLowerCase()==='unknown'; }).length;
  var aiReach = (aiSec.reachable != null) ? aiSec.reachable : _aiReachFromIssues;
  var aiUnkn  = (aiSec.unknown  != null) ? aiSec.unknown   : _aiUnknFromIssues;
  var aiUnreach = Math.max(0, totalAI - aiReach - aiUnkn);
  // Build stats banner — inject before the flow pipeline
  var stagesHit = stages.filter(function(s) { return s.count > 0; }).length;
  var bannerMount = document.getElementById('attackSurfaceBanner');
  if (bannerMount) {
    var riskColor = aiReach > 0 ? '#f59e0b' : '#66BB6A';
    var narrative = aiReach > 0
      ? aiReach + ' reachable AI/LLM finding' + (aiReach !== 1 ? 's' : '') + ' across ' + stagesHit + ' pipeline stage' + (stagesHit !== 1 ? 's' : '')
      : 'AI pipeline analyzed — no critical exposures detected';
    // BUG-UI-04 FIX: Banner numbers must be clickable AND must navigate to the pill
    // that matches the label shown. aiReach → pill:'reachable'. aiUnkn → pill:'unknown'.
    // aiReach+aiUnkn (actionable) → pill:'actionable'.
    // Previously the numbers were plain <span> (not clickable) causing confusion when
    // users clicked stage badges and got a different (larger) count from pill:'actionable'.
    var aiAct = aiReach + aiUnkn;
    bannerMount.innerHTML =
      '<div style="display:flex;gap:20px;align-items:center;flex-wrap:wrap;padding:14px 20px;background:#0f172a;border-radius:8px;border:1px solid #1e293b;margin-bottom:16px;">'+
      '<div style="display:flex;gap:6px;align-items:baseline;cursor:pointer;" onclick="'+go({type:'AI',pill:'all'})+'"><span style="font-size:28px;font-weight:800;color:'+riskColor+';">'+totalAI+'</span><span style="color:#64748b;font-size:12px;">total</span></div>'+
      '<div style="width:1px;height:32px;background:#1e293b;"></div>'+
      // In pipeline = sum of stage counts (excludes NONE/informational)
      '<div style="display:flex;gap:6px;align-items:baseline;cursor:pointer;" onclick="'+go({type:'AI',pill:'actionable'})+'"><span style="font-size:22px;font-weight:700;color:#2979FF;">'+pipelineCount+'</span><span style="color:#64748b;font-size:12px;">in pipeline</span></div>'+
      '<div style="width:1px;height:32px;background:#1e293b;"></div>'+
      // Reachable breakdown — clicking navigates to reachable-only pill
      '<div style="display:flex;gap:6px;align-items:baseline;cursor:pointer;" onclick="'+go({type:'AI',pill:'reachable'})+'"><span style="font-size:22px;font-weight:700;color:#42A5F5;">'+aiReach+'</span><span style="color:#64748b;font-size:12px;">reachable</span></div>'+
      (aiUnkn > 0 ? '<div style="width:1px;height:32px;background:#1e293b;"></div><div style="display:flex;gap:6px;align-items:baseline;cursor:pointer;" onclick="'+go({type:'AI',pill:'unknown'})+'"><span style="font-size:22px;font-weight:700;color:#78909C;">'+aiUnkn+'</span><span style="color:#64748b;font-size:12px;">unknown</span></div>' : '')+
      '<div style="width:1px;height:32px;background:#1e293b;"></div>'+
      '<div style="display:flex;gap:6px;align-items:baseline;"><span style="font-size:22px;font-weight:700;color:#94a3b8;">'+stagesHit+'</span><span style="color:#64748b;font-size:12px;">stages affected</span></div>'+
      '<div style="width:1px;height:32px;background:#1e293b;"></div>'+
      '<div style="color:'+riskColor+';font-size:13px;font-weight:500;font-style:italic;">'+narrative+'</div>'+
      (_noneCount > 0 ? '<div style="width:1px;height:32px;background:#1e293b;"></div><div style="display:flex;gap:4px;align-items:baseline;"><span style="font-size:16px;font-weight:600;color:#475569;">'+_noneCount+'</span><span style="color:#475569;font-size:11px;">informational</span></div>' : '')+
      '</div>';
  }
  flowMount.innerHTML =
    '<div class="v2-attack-flow-inner">' + stages.map(function(s, i) {
    var has = s.count > 0;
    return (i > 0 ? '<span class="v2-attack-arrow">\u2192</span>' : '') +
      // BUG 44 FIX: red = CRITICAL severity only. Has-findings stages use amber border + blue count.
      '<div class="v2-attack-stage" data-stage="' + s.id + '" style="border-color:' + (has ? '#f59e0b' : '#334155') + ';' + (has ? 'background:rgba(245,158,11,0.08);' : '') + '" onmouseenter="showStageDetail(\'' + s.id + '\')" onclick="showStageDetail(\'' + s.id + '\')">' +
        '<div class="v2-attack-stage-label">' + s.label + '</div>' +
        (has ? '<div style="font-size:14px;font-weight:700;color:#42A5F5;">' + s.count + '</div>' : '<div style="font-size:11px;color:#66BB6A;">\u2713</div>') +
      '</div>';
  }).join('') + '</div>';
  // === ENH #5: OWASP Agentic AI (ASI) v1.1 — T1-T17 official taxonomy ===
  var LLM_TO_ASI = {
    LLM01: ['T6','T1'],    // Prompt Injection → Goal Manipulation, Memory Poisoning
    LLM02: ['T15','T8'],   // Sensitive Disclosure → Human Manipulation, Repudiation
    LLM03: ['T17','T16'],  // Supply Chain → Supply Chain, Protocol Abuse
    LLM04: ['T1','T5'],    // Data Poisoning → Memory Poisoning, Cascading Hallucination
    LLM05: ['T11','T2'],   // Insecure Output → RCE, Tool Misuse
    LLM06: ['T2','T3'],    // Excessive Agency → Tool Misuse, Privilege Compromise
    LLM07: ['T2','T11'],   // Insecure Plugin → Tool Misuse, RCE
    LLM08: ['T1','T5'],    // Vector Weakness → Memory Poisoning, Cascading Hallucination
    LLM09: ['T5','T15'],   // Misinformation → Cascading Hallucination, Human Manipulation
    LLM10: ['T4','T10'],   // Unbounded Consumption → Resource Overload, Overwhelming HITL
  };
  var asiDefs = {
    T1:  { label:'MEMORY POISON',    desc:'Manipulation of persistent agent memory',           cat:'memory',     color:'#553c9a' },
    T2:  { label:'TOOL MISUSE',      desc:'Abuse of agent-accessible tools beyond scope',      cat:'tool',       color:'#975a16' },
    T3:  { label:'PRIVILEGE COMP',   desc:'Agents acting with excessive privileges',           cat:'tool',       color:'#975a16' },
    T4:  { label:'RESOURCE OVERLOAD',desc:'Unbounded consumption or runaway loops',            cat:'tool',       color:'#975a16' },
    T5:  { label:'CASCADE HALLUC',   desc:'Cascading hallucination across agent sessions',     cat:'memory',     color:'#553c9a' },
    T6:  { label:'GOAL HIJACK',      desc:'Intent breaking & goal manipulation',               cat:'agency',     color:'#7b341e' },
    T7:  { label:'MISALIGNED',       desc:'Misaligned & deceptive agent behaviors',            cat:'agency',     color:'#7b341e' },
    T8:  { label:'REPUDIATION',      desc:'Repudiation & untraceability of agent actions',     cat:'agency',     color:'#7b341e' },
    T9:  { label:'IDENTITY SPOOF',   desc:'Identity spoofing & impersonation',                 cat:'auth',       color:'#276749' },
    T10: { label:'OVERWHELM HITL',   desc:'Overwhelming human-in-the-loop oversight',          cat:'human',      color:'#744210' },
    T11: { label:'RCE & CODE',       desc:'Unexpected RCE and code attacks via agents',        cat:'tool',       color:'#975a16' },
    T12: { label:'AGENT COMMS',      desc:'Agent communication poisoning',                     cat:'multiagent', color:'#702459' },
    T13: { label:'ROGUE AGENTS',     desc:'Rogue agents in multi-agent systems',               cat:'multiagent', color:'#702459' },
    T14: { label:'HUMAN ATK MAS',    desc:'Human attacks on multi-agent systems',              cat:'multiagent', color:'#702459' },
    T15: { label:'HUMAN MANIP',      desc:'Manipulation of human oversight & trust',           cat:'human',      color:'#744210' },
    T16: { label:'PROTOCOL ABUSE',   desc:'Insecure inter-agent protocol abuse (MCP/A2A)',     cat:'multiagent', color:'#702459' },
    T17: { label:'SUPPLY CHAIN',     desc:'Compromised models, plugins, or agent deps',        cat:'tool',       color:'#975a16' },
  };
  var asiCodes = ['T1','T2','T3','T4','T5','T6','T7','T8','T9','T10','T11','T12','T13','T14','T15','T16','T17'];
  // BUG-CTR-03 FIX: Count UNIQUE actionable findings per ASI category.
  // Use byOwasp (excludes NONE) to derive counts. Each ASI gets the sum of its parent LLM counts.
  var asiCounts = {};
  asiCodes.forEach(function(k) { asiCounts[k] = 0; });
  // BUG-CTR-ACTIONABLE FIX: Use actionable counts (reachable+unknown) for ASI boxes,
  // matching the pipeline stage fix above. Raw byOwasp includes unreachable findings
  // which inflates agentic box numbers vs the detail panel's actionable count.
  Object.keys(byOwasp).forEach(function(llm) {
    if (llm === 'NONE') return; // Skip informational
    var mapped = LLM_TO_ASI[llm] || [];
    mapped.forEach(function(asi) { if (asiCounts[asi] !== undefined) asiCounts[asi] += (byOwaspActionable[llm] || 0); });
  });
  // Fallback: count from issues[] if byOwasp was empty
  if (Object.values(asiCounts).every(function(v) { return v === 0; }) && issues.length > 0) {
    issues.forEach(function(f) {
      var raw = (f.owasp_llm || f.llm_category || '').toUpperCase();
      if (raw === 'MCP' || raw === 'MCP_SECURITY' || raw === 'CONTROLS' || raw === 'MODEL_CONTROLS') raw = 'LLM06';
      if (raw === 'NONE' || raw === 'PRIMITIVE' || raw === 'AI_PRIMITIVE' || raw === '') return;
      var mapped = LLM_TO_ASI[raw] || [];
      mapped.forEach(function(asi) { if (asiCounts[asi] !== undefined) asiCounts[asi]++; });
    });
  }
  var asiAffected = asiCodes.filter(function(k) { return asiCounts[k] > 0; }).length;
  var agenticStages = asiCodes.map(function(code) {
    var parentLlm = [];
    Object.keys(LLM_TO_ASI).forEach(function(llm) { if (LLM_TO_ASI[llm].indexOf(code) >= 0) parentLlm.push(llm); });
    // BUG-53b FIX: owasp = parentLlm codes (not ASI codes) so test can match findings.
    // asiCode preserved for display. BUG 53b test checks s.owasp against f.owasp_llm.
    return { id: code.toLowerCase(), label: asiDefs[code].label, owasp: parentLlm, asiCode: code, parentLlm: parentLlm, desc: asiDefs[code].desc, vulns: asiDefs[code].desc, count: asiCounts[code], isAgentic: true };
  });
  var agenticFlowMount = document.getElementById('agenticSurfaceFlow');
  var agenticLabel = document.getElementById('agenticSurfaceLabel');
  if (agenticFlowMount && asiAffected > 0) {
    if (agenticLabel) agenticLabel.style.display = 'block';
    // BUG-CTR-03 FIX: Render agentic boxes IDENTICAL to LLM pipeline boxes.
    // Same class, same colors, same font sizes. Only difference: no arrows, flex-wrap for 10 items.
    agenticFlowMount.innerHTML =
      '<div class="v2-attack-flow-inner" style="flex-wrap:wrap;gap:6px;">' + agenticStages.map(function(s) {
      var has = s.count > 0;
      return '<div class="v2-attack-stage" data-stage="' + s.id + '" style="border-color:' + (has ? '#f59e0b' : '#334155') + ';' + (has ? 'background:rgba(245,158,11,0.08);' : '') + '" onmouseenter="showStageDetail(\'' + s.id + '\')" onclick="showStageDetail(\'' + s.id + '\')">' +
          '<div class="v2-attack-stage-label">' + s.label + '</div>' +
          (has ? '<div style="font-size:14px;font-weight:700;color:#42A5F5;">' + s.count + '</div>' : '<div style="font-size:11px;color:#66BB6A;">\u2713</div>') +
        '</div>';
    }).join('') + '</div>';
  } else if (agenticFlowMount) {
    agenticFlowMount.innerHTML = '';
    if (agenticLabel) agenticLabel.style.display = 'none';
  }
  // Update banner to include agentic stage count
  if (bannerMount && asiAffected > 0) {
    var existingBanner = bannerMount.innerHTML;
    var agenticStat = '<div style="width:1px;height:32px;background:#1e293b;"></div>' +
      '<div style="display:flex;gap:6px;align-items:baseline;"><span style="font-size:22px;font-weight:700;color:#94a3b8;">' + asiAffected + '/17</span><span style="color:#64748b;font-size:12px;">agentic threats (T1\u2013T17)</span></div>';
    bannerMount.innerHTML = existingBanner.replace(/<\/div>$/, agenticStat + '</div>');
  }
  // Merge stages for showStageDetail
  var allStages = stages.concat(agenticStages);
  window._attackStages = allStages;
  window._attackAiIssues = issues;
  window._attackByOwasp = byOwasp;
  detailMount.innerHTML = '<div class="v2-attack-detail-empty">Click a pipeline stage above to see details.</div>';
}

window.showStageDetail = function(stageId) {
  var stages = window._attackStages || [];
  var issues = window._attackAiIssues || [];
  var byOwasp = window._attackByOwasp || {};
  var stage = stages.find(function(s) { return s.id === stageId; });
  if (!stage) return;
  document.querySelectorAll('.v2-attack-stage').forEach(function(el) { el.classList.toggle('v2-stage-active', el.dataset.stage === stageId); });
  var dm = document.getElementById('attackSurfaceDetail');
  if (!dm) return;
  // BUG 44/45 FIX: detail panel — no repeated finding rows. Show OWASP mapping + actionable count link only.
  var owaspNames = { LLM01:'Prompt Injection', LLM02:'Sensitive Disclosure', LLM03:'Supply Chain', LLM04:'Data Poisoning', LLM05:'Improper Output Handling', LLM06:'Excessive Agency', LLM07:'System Prompt Leakage', LLM08:'Vector & Embedding Weakness', LLM09:'Misinformation', LLM10:'Unbounded Consumption' };
  var asiNames = { T1:'Memory Poisoning', T2:'Tool Misuse', T3:'Privilege Compromise', T4:'Resource Overload', T5:'Cascading Hallucination', T6:'Goal Manipulation', T7:'Misaligned & Deceptive', T8:'Repudiation & Untraceability', T9:'Identity Spoofing', T10:'Overwhelming HITL', T11:'RCE & Code Attacks', T12:'Agent Comms Poisoning', T13:'Rogue Agents', T14:'Human Attacks on MAS', T15:'Human Manipulation', T16:'Protocol Abuse', T17:'Supply Chain Compromise' };
  var isAgentic = stage.isAgentic || false;
  // For agentic stages, use pre-computed parentLlm from the stage object
  // (set during renderAIAttackSurface from the canonical LLM_TO_ASI crosswalk)
  var matchLlmCodes = isAgentic ? (stage.parentLlm || []) : [];
  // BUG-UI-02 FIX: uppercase cat before startsWith so findings with mixed-case
  // owasp_llm values from the DB ('llm01', 'Llm01') match stage codes ('LLM01').
  var sf;
  if (isAgentic) {
    sf = issues.filter(function(f) {
      var cat = (f.owasp_llm || f.llm_category || '').toUpperCase();
      // BUG-CTR-02 FIX: Only remap real LLM06 aliases (MCP/CONTROLS).
      // NONE/PRIMITIVE/empty are informational — they must NOT inflate agentic counts.
      if (cat === 'MCP' || cat === 'MCP_SECURITY' || cat === 'CONTROLS' || cat === 'MODEL_CONTROLS') cat = 'LLM06';
      if (cat === 'NONE' || cat === 'PRIMITIVE' || cat === 'AI_PRIMITIVE' || cat === '') return false;
      return matchLlmCodes.some(function(llm) { return cat.startsWith(llm); });
    });
  } else {
    sf = issues.filter(function(f) { var cat = (f.owasp_llm || f.llm_category || '').toUpperCase(); return stage.owasp.some(function(o) { return cat.startsWith(o.toUpperCase()); }); });
  }
  var sfReach   = sf.filter(function(f){ return f.reachability_state === 'reachable'; }).length;
  var sfUnkn    = sf.filter(function(f){ return f.reachability_state === 'unknown'; }).length;
  var sfUnreach = sf.filter(function(f){ return f.reachability_state === 'not_reachable'; }).length;
  var sfAct     = sfReach + sfUnkn;
  // OWASP category breakdown — each code with count, color by presence (amber) vs clean (green)
  var allNames = {};
  Object.keys(owaspNames).forEach(function(k) { allNames[k] = owaspNames[k]; });
  Object.keys(asiNames).forEach(function(k) { allNames[k] = asiNames[k]; });
  var ol;
  if (isAgentic) {
    // BUG-CTR-03 FIX: Use byOwasp-derived count (matches the box count),
    // not sf.length which may include stale/NONE findings from issues[].
    var asiCode = stage.asiCode || stage.owasp[0];
    var asiBoxCount = stage.count || 0;
    ol = '<div style="padding:4px 0;color:#94a3b8;font-size:12px;font-weight:600;">' +
      asiCode + ' <span style="color:#94a3b8;font-weight:400;">' + (asiNames[asiCode]||asiCode) + '</span>' +
      ' <span style="color:#42A5F5;font-weight:700;">(' + asiBoxCount + ')</span></div>';
    if (matchLlmCodes.length > 0) {
      ol += '<div style="padding:2px 0 6px 8px;font-size:10px;color:#64748b;">Maps from: ' +
        matchLlmCodes.map(function(llm) {
          var c = byOwasp[llm] || 0;
          return '<span style="color:' + (c>0?'#f59e0b':'#475569') + ';font-weight:600;">' + llm + (c>0?' ('+c+')':'') + '</span>';
        }).join(', ') + '</div>';
    }
  } else {
    ol = stage.owasp.map(function(o) {
      var c = byOwasp[o] || 0;
      var color = c > 0 ? '#f59e0b' : '#66BB6A';
      return '<div style="padding:4px 0;color:' + color + ';font-size:12px;font-weight:600;">' +
        o + ' <span style="color:#94a3b8;font-weight:400;">' + (allNames[o]||o) + '</span>' +
        (c > 0 ? ' <span style="color:#42A5F5;font-weight:700;">(' + c + ')</span>' : ' <span style="color:#475569;">(0)</span>') +
      '</div>';
    }).join('');
  }
  // BUG-UI-02 FIX: actionable panel must be consistent with stage badge count.
  // sfAct = reachable + unknown (need attention). sfUnreach = confirmed not reachable.
  // When sf.length > 0 but sfAct = 0, all findings are not_reachable — show them
  // with a grey count rather than the misleading green ✓ "No actionable findings"
  // which directly contradicts the amber badge showing N findings on the stage.
  var actionLink;
  var stageComp;
  if (isAgentic && matchLlmCodes.length > 0) {
    stageComp = 'OWASP-' + matchLlmCodes[0];
  } else {
    stageComp = stage.owasp && stage.owasp.length > 0 ? 'OWASP-' + stage.owasp[0] : '';
  }
  // BUG-CTR-03 FIX: For agentic stages, use byOwasp-derived count (stage.count)
  // and search-based navigation (matches owasp_llm field). The compliance filter
  // path is unreliable for agentic since findings use LLM codes not ASI codes.
  // BUG-CTR-04 FIX: hoist bestParent so it is available for reachable sub-link
  // regardless of isAgentic. For non-agentic stages bestParent stays empty.
  var bestParent = isAgentic
    ? matchLlmCodes.reduce(function(best, llm) {
        return (byOwasp[llm] || 0) > (byOwasp[best] || 0) ? llm : best;
      }, matchLlmCodes[0] || '')
    : '';
  var reachComp = isAgentic
    ? (bestParent ? 'OWASP-' + bestParent : stageComp)
    : stageComp;
  var displayCount, navCfg;
  if (isAgentic) {
    displayCount = sfAct;
    navCfg = {type:'AI', compliance: 'OWASP-' + bestParent, pill:'actionable'};
  } else {
    displayCount = sfAct;
    navCfg = {type:'AI', compliance: stageComp, pill:'actionable'};
  }
  if (displayCount > 0) {
    actionLink =
      '<a style="cursor:pointer;font-size:28px;font-weight:800;color:#42A5F5;text-decoration:none;" onclick="' +
          go(navCfg) + '">' + displayCount + '</a>' +
      '<span style="font-size:12px;color:#64748b;margin-left:8px;">actionable</span>';
    if (sfReach > 0) {
      // BUG-CTR-05 FIX: render reachable sub-link for ALL stages (agentic + non-agentic).
      // Previously guarded by !isAgentic — causing t2/t3 reachable links to never render.
      actionLink += '<div style="margin-top:6px;">' +
        '<a style="cursor:pointer;color:#42A5F5;font-size:11px;font-weight:600;" onclick="' + go({type:'AI', compliance: reachComp, pill:'reachable'}) + '">' + sfReach + ' reachable</a>' +
        (sfUnkn > 0 ? ' &nbsp;<a style="cursor:pointer;color:#78909C;font-size:11px;font-weight:600;" onclick="' + go({type:'AI', compliance: reachComp, pill:'unknown'}) + '">' + sfUnkn + ' unknown</a>' : '') +
        '</div>';
    }
  } else if (!isAgentic && sf.length > 0) {
    actionLink =
      '<div style="font-size:28px;font-weight:800;color:#475569;">' + sfUnreach + '</div>' +
      '<span style="font-size:12px;color:#64748b;">found · not reachable</span>' +
      '<div style="margin-top:6px;font-size:10px;color:#334155;font-style:italic;">Call graph confirmed no reachable path</div>';
  } else {
    actionLink = '<span style="color:#66BB6A;font-size:14px;font-weight:600;">&#10003; No findings at this stage</span>';
  }
  dm.innerHTML =
    '<div style="display:flex;gap:32px;align-items:flex-start;">' +
      '<div style="flex:1;">' +
        '<div class="v2-attack-detail-title">' + stage.label + '</div>' +
        '<div style="color:#94a3b8;font-size:12px;margin-bottom:12px;">' + stage.desc + '</div>' +
        '<div style="font-size:11px;font-weight:700;color:#64748b;text-transform:uppercase;letter-spacing:1px;margin-bottom:6px;">' + (isAgentic ? 'OWASP Agentic Mapping' : 'OWASP LLM Mapping') + '</div>' +
        ol +
      '</div>' +
      '<div style="flex:0 0 220px;background:#0f1729;border:1px solid #1e293b;border-radius:8px;padding:16px 20px;text-align:center;">' +
        '<div style="font-size:11px;font-weight:700;color:#64748b;text-transform:uppercase;letter-spacing:1px;margin-bottom:10px;">Actionable Findings</div>' +
        actionLink +
        '<div style="margin-top:10px;font-size:10px;color:#334155;font-style:italic;">' + stage.vulns + '</div>' +
      '</div>' +
    '</div>';
};

// ===========================
// GRC / COMPLIANCE
// ===========================
function renderGRC(d) {
  var stripMount = document.getElementById('grcSummaryStrip');
  var gridMount = document.getElementById('grcFrameworkGrid');
  var detailMount = document.getElementById('grcExpandedDetail');
  var noDataMount = document.getElementById('grcNoData');
  if (!gridMount) return;
  // Always clear expanded detail on re-render
  if (detailMount) { detailMount.innerHTML = ''; detailMount.dataset.fw = ''; }
  var allIssues = d.issues || [];
  var configExcluded = (d.funnel || {}).config_excluded || false;
  var issues = allIssues.filter(function(f){ return f.reachability_state !== 'not_applicable' && f.type !== 'CONFIG'; });
  var frameworks = {};
  var fwDefs = {
    'OWASP':        { name:'OWASP Top 10 (2025)',      color:'#2979FF', desc:'Web application security risks' },
    'CWE':          { name:'CWE Top 25',                color:'#8b5cf6', desc:'Most dangerous software weaknesses' },
    'OWASP_LLM':    { name:'OWASP LLM (2025) + Agentic (2026)', color:'#818cf8', desc:'AI/LLM + autonomous agent security', link:'ai-agent-security' },
    'PCI-DSS':      { name:'PCI DSS 4.0',               color:'#0ea5e9', desc:'Payment card data security' },
    'HIPAA':        { name:'HIPAA',                      color:'#059669', desc:'Healthcare data protection' },
    'SOC2':         { name:'SOC 2 Type II',              color:'#6366f1', desc:'Trust service criteria' },
    'ISO27001':     { name:'ISO 27001',                  color:'#0891b2', desc:'Information security management' },
    'NIST-800-53':  { name:'NIST SP 800-53 r5',         color:'#0284c7', desc:'Federal information security controls' },
    'NIST-800-171': { name:'NIST SP 800-171',            color:'#0369a1', desc:'Controlled unclassified information' },
    'FEDRAMP':      { name:'FedRAMP',                    color:'#7c3aed', desc:'Federal cloud security authorization' },
    'CMMC':         { name:'CMMC 2.0',                   color:'#ca8a04', desc:'Defense contractor cybersecurity' },
    'DISA-STIG':    { name:'DISA STIG',                  color:'#78716c', desc:'DoD security implementation guides' },
    'FISMA':        { name:'FISMA',                      color:'#64748b', desc:'Federal Information Security Management Act' },
    'STRIDE':       { name:'STRIDE Threat Model',         color:'#0ea5e9', desc:'Spoofing, Tampering, Repudiation, Info Disclosure, DoS, Elevation' },
  };
  var FW_KEY_NORMALIZE = { 'CWE-TOP-25': 'CWE' };
  // BUG 51/52 FIX: DB may use variant key forms (underscores, different spacing).
  // Normalize raw DB keys to canonical fwDefs keys so renderGRC counts the same
  // findings that hasComplianceFramework (which normalizes via regex) would match.
  var FW_CANONICAL = {
    'NIST800171':'NIST-800-171','NIST171':'NIST-800-171','SP800171':'NIST-800-171',
    'NIST80053':'NIST-800-53','NIST53':'NIST-800-53','SP80053':'NIST-800-53',
    'CWETOP25':'CWE','CWE25':'CWE','CWETOP':'CWE',
    'PCIDSS':'PCI-DSS','PCI':'PCI-DSS',
    'DISASTIG':'DISA-STIG','STIG':'DISA-STIG','DISA':'DISA-STIG',
    'ISO27001':'ISO27001','ISO27K':'ISO27001',
    'SOC2':'SOC2','SOC':'SOC2','AICPA':'SOC2',
    'FEDRAMP':'FEDRAMP','FEDRAMPMODERATE':'FEDRAMP','FEDRAMPHIGH':'FEDRAMP',
    'CMMC':'CMMC','CMMCL2':'CMMC','CMMCL3':'CMMC',
    'OWASP':'OWASP','OWASPTOP10':'OWASP',
    'HIPAA':'HIPAA','FISMA':'FISMA','NIST800171':'NIST-800-171',
    'STRIDE':'STRIDE','STRIDETHREAT':'STRIDE'
  };
  function normalizeFwKey(raw) {
    if (FW_KEY_NORMALIZE[raw]) return FW_KEY_NORMALIZE[raw];
    var stripped = raw.toUpperCase().replace(/[^A-Z0-9]/g, '');
    return FW_CANONICAL[stripped] || raw;
  }
  issues.forEach(function(f) {
    // BUG 10/17/29 FIX: Use inferred compliance mapping as fallback for findings without explicit mappings
    // BUG 10/17/29 FIX: MERGE DB mapping + inferred mapping — DB mapping is often incomplete
    // OR logic was wrong: if DB has any compliance_mapping (even 1 key), inferred was skipped
    var _dbMap = f.compliance_mapping || {};
    var _inferred = (typeof window.inferComplianceMapping === 'function' && window.inferComplianceMapping(f)) || {};
    var mapping = {};
    Object.keys(_inferred).forEach(function(k){ mapping[k] = _inferred[k]; });
    Object.keys(_dbMap).forEach(function(k){ mapping[k] = _dbMap[k]; }); // DB wins on conflict
    // Deduplicate by normalized fw key so a finding with both 'CWE' and 'CWE-TOP-25' in mapping
    // doesn't get counted twice (both normalize to 'CWE' via FW_KEY_NORMALIZE)
    var _seenNorm = {};
    var rs = f.reachability_state || (f.is_reachable === true ? 'reachable' : f.is_reachable === false ? 'not_reachable' : 'unknown');
    Object.keys(mapping).forEach(function(rawFw) {
      // BUG 51/52 FIX: normalize variant DB keys (NIST_800_171, fisma, etc.) to canonical fwDefs key
      var fw = normalizeFwKey(rawFw);
      if (!fwDefs[fw]) return;
      if (!frameworks[fw]) frameworks[fw] = { total:0, controls:{}, reachable:0, unknown:0, unreachable:0 };
      if (!_seenNorm[fw]) {
        _seenNorm[fw] = true;
        frameworks[fw].total++;
        if (rs === 'reachable') frameworks[fw].reachable++;
        else if (rs === 'not_reachable' || rs === 'not_applicable') frameworks[fw].unreachable++;
        else frameworks[fw].unknown++;
      }
      var ctrls = mapping[rawFw];
      if (Array.isArray(ctrls)) ctrls.forEach(function(c) { if (!frameworks[fw].controls[c]) frameworks[fw].controls[c] = { findings:0 }; frameworks[fw].controls[c].findings++; });
    });
  });
  Object.keys(frameworks).forEach(function(fw) {
    frameworks[fw].failing = Object.values(frameworks[fw].controls).filter(function(c) { return c.findings > 0; }).length;
    frameworks[fw].controlCount = Object.keys(frameworks[fw].controls).length;
  });
  if (noDataMount) noDataMount.style.display = 'none';

  // Summary strip — simple stats, no noise reduction
  var fwWithData = Object.keys(frameworks);
  var totalFindings = fwWithData.reduce(function(s,k) { return s + frameworks[k].total; }, 0);
  var totalControls = fwWithData.reduce(function(s,k) { return s + (frameworks[k].controlCount||0); }, 0);
  var totalViolations = fwWithData.reduce(function(s,k) { return s + (frameworks[k].failing||0); }, 0);
  if (stripMount) {
    stripMount.innerHTML = statBar([
      { label:'frameworks',  value: Object.keys(fwDefs).length, color:'#94a3b8', bg:'rgba(148,163,184,0.08)' },
      { label:'with findings', value: fwWithData.length, color:'#f1f5f9', bg:'rgba(241,245,249,0.06)',
        onclick:"event.stopPropagation();document.querySelector('.v2-grc-card:not([style*=\'opacity:0.35\'])') && document.querySelector('.v2-grc-card').scrollIntoView({behavior:\'smooth\'});" },
      { label:'controls mapped', value: totalControls, color:'#64748b', bg:'rgba(100,116,139,0.08)' },
      { label:'actionable findings', value: issues.filter(function(f){return f.reachability_state==='reachable'||f.reachability_state==='unknown';}).length, color:'#2979FF', bg:'rgba(41,121,255,0.10)',
        onclick:go({pill:'actionable'}) },
      { label:'total findings', value: totalFindings, color:'#94a3b8', bg:'rgba(148,163,184,0.06)' },
    ]);
  }

  // Render ALL frameworks — active first, then inactive (dimmed)
  var allFwKeys = Object.keys(fwDefs);
  var activeFw = allFwKeys.filter(function(k) { return frameworks[k] && frameworks[k].total > 0; });
  var inactiveFw = allFwKeys.filter(function(k) { return !frameworks[k] || frameworks[k].total === 0; });
  var cs = 'background:#0f1729;border:1px solid #1e293b;border-radius:10px;padding:16px 20px;';

  // BUG 10/17/29 FIX: Render ALL 13 frameworks — active first (with data), then inactive (dimmed)
  var allRenderFw = activeFw.concat(inactiveFw);
  gridMount.innerHTML = allRenderFw.map(function(fw) {
    var def = fwDefs[fw]; var data = frameworks[fw] || { total:0, controls:{}, reachable:0, unknown:0, unreachable:0, failing:0, controlCount:0 }; // BUG33 FIX: guard undefined for inactive frameworks
    // OWASP_LLM: counter must match navigation (type:AI = all AI findings)
    if (fw === 'OWASP_LLM') {
      // BUG 36 FIX: Count ALL AI findings. MCP is not a real LLM category — remap to LLM06.
      var aiSec = issues.filter(function(f){ return f.type==='AI'; });
      var llmControls = {};
      aiSec.forEach(function(f){
        var raw = (f.owasp_llm || f.llm_category || '').toUpperCase();
        // MCP_SECURITY / MCP are internal enum values → OWASP maps them to LLM06 Excessive Agency
        // BUG-CTR-02: Only remap genuine LLM06 aliases. Skip informational.
        if (raw === 'NONE' || raw === 'PRIMITIVE' || raw === 'AI_PRIMITIVE' || raw === '') return;
        var label = (raw === 'MCP' || raw === 'MCP_SECURITY' || raw === 'CONTROLS' || raw === 'MODEL_CONTROLS') ? 'LLM06' : f.owasp_llm;
        llmControls[label] = llmControls[label] || {findings:0};
        llmControls[label].findings++;
      });
      data = {
        total:       aiSec.length,
        reachable:   aiSec.filter(function(f){return f.reachability_state==='reachable';}).length,
        unknown:     aiSec.filter(function(f){return f.reachability_state==='unknown';}).length,
        failing:     data.failing,
        controlCount:data.controlCount,
        controls:    llmControls
      };
    }
    var pct = data.controlCount > 0 ? Math.round(((data.controlCount - data.failing)/data.controlCount)*100) : 0;
    var bc = pct >= 80 ? '#66BB6A' : pct >= 50 ? '#B8960C' : '#FF1F1F';
    var fwToComp = {
      'OWASP':'OWASP','CWE':'CWE-TOP-25',
      'PCI-DSS':'PCI-DSS','HIPAA':'HIPAA','SOC2':'SOC2',
      'NIST-800-53':'NIST-800-53','FEDRAMP':'FEDRAMP','CMMC':'CMMC',
      'ISO27001':'ISO27001','NIST-800-171':'NIST-800-171','DISA-STIG':'DISA-STIG',
      'FISMA':'FISMA'
    };
    var compVal = fwToComp[fw] !== undefined ? fwToComp[fw] : fw;
    // OWASP_LLM framework → navigate to AI type filter (not compliance search)
    var isLlmFw = (fw === 'OWASP_LLM');
    function gotoFw(pill) {
      if (isLlmFw) return go({stop:true, type:'AI', search:'', pill:pill||'all'});
      if (compVal) return go({stop:true, compliance:compVal, search:'', pill:pill||'all'});
      return go({stop:true, search:fw, pill:pill||'all'});
    }
    var actionable = data.reachable + data.unknown;
    // BUG 50 FIX: zero actionable must be muted (#475569), not blue
    var actionColor = actionable > 0 ? '#2979FF' : '#475569';
    var fwSizes = {OWASP:10,OWASP_LLM:10,CWE:25,'CWE-TOP-25':25,'PCI-DSS':12,
                   HIPAA:9,SOC2:5,'NIST-800-53':20,FEDRAMP:20,CMMC:14,
                   ISO27001:14,'NIST-800-171':14,'DISA-STIG':10,FISMA:5,STRIDE:19};
    var fwTotal  = fwSizes[fw] || null;
    var affected = Object.keys(data.controls||{}).length;
    var affectedLabel = fwTotal
      ? (affected + '/' + fwTotal + ' categories affected')
      : (affected + ' controls affected');

    // isInactive must be computed AFTER the OWASP_LLM block has overwritten data,
    // otherwise OWASP_LLM always appears inactive (frameworks['OWASP_LLM'] is empty
    // because no compliance_mapping entry points to it directly).
    var isInactive = data.total === 0;
    var cardStyle = cs + 'cursor:pointer;transition:all 0.2s ease;' + (isInactive ? 'opacity:0.45;' : '');
    var cardOnclick = isInactive ? '' : ' onclick="expandGrcFramework(\'' + fw + '\',this)"';
    // BUG 38 FIX: grid-column:span 2 makes expanded card full-width inline
    return '<div class="v2-grc-card" data-fw="' + fw + '" style="' + cardStyle + '"' + cardOnclick + '>' +

      '<div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:6px;">' +
        '<div>' +
          '<div style="font-size:14px;font-weight:700;color:#f1f5f9;"><span style="color:#475569;margin-right:6px;font-size:10px;">●</span>' + def.name + '</div>' +
          '<div style="font-size:11px;color:#64748b;margin-top:1px;">' + (def.desc||'') +
            (def.link ? ' <a style="color:'+def.color+';cursor:pointer;" onclick="event.stopPropagation();activateTab(\''+def.link+'\');">↗</a>' : '') +
          '</div>' +
        '</div>' +
        '<div style="text-align:right;margin-left:8px;flex-shrink:0;">' +
          (data.total > 0
            ? '<div style="font-size:10px;color:#475569;white-space:nowrap;">' + affectedLabel + '</div>'
            : '<span style="font-size:11px;color:#334155;">No data</span>') +
        '</div>' +
      '</div>' +

      '<div style="display:flex;align-items:baseline;gap:8px;margin-bottom:4px;">' +
        (isInactive
          ? '<span style="font-size:18px;font-weight:600;color:#334155;">No findings</span>'
          : '<a style="cursor:pointer;font-size:32px;font-weight:800;color:' + actionColor + ';text-decoration:none;line-height:1;" onclick="' + gotoFw('actionable') + '">' + actionable + '</a><span style="font-size:12px;color:#64748b;margin-left:4px;">actionable</span>'
        ) +
      '</div>' +

      (data.total > 0 ? (function() {
        var ctrlEntries = Object.entries(data.controls||{}).sort(function(a,b){ return b[1].findings - a[1].findings; });
        var shown = ctrlEntries.slice(0,10); // BUG 28 FIX: max tags = 10
        var rest  = ctrlEntries.length - shown.length;
        var tags  = shown.map(function(e){ return '<span style="display:inline-block;background:rgba(100,116,139,0.15);color:#94a3b8;font-size:10px;font-weight:600;padding:1px 5px;border-radius:3px;font-family:monospace;">' + e[0] + '</span>'; }).join(' ');
        if (rest > 0) tags += ' <span style="color:#475569;font-size:10px;">+' + rest + ' more</span>';
        return '<div style="margin-bottom:4px;">' + tags + '</div>';
      })() : '') +

      '<div style="display:flex;gap:12px;font-size:11px;flex-wrap:wrap;align-items:center;">' +
        (data.reachable > 0 ? '<a style="cursor:pointer;color:#42A5F5;font-weight:600;" onclick="' + gotoFw('reachable') + '">' + data.reachable + ' reachable</a>' : '') +
        (data.unknown   > 0 ? '<a style="cursor:pointer;color:#78909C;font-weight:600;" onclick="' + gotoFw('unknown') + '">' + data.unknown + ' unknown</a>' : '') +
        (data.total > 0 ? ' <a style="cursor:pointer;color:#475569;font-size:10px;font-style:italic;opacity:0.7;" onclick="' + gotoFw('all') + '">raw ' + data.total + '</a>' : '') +
      '</div>' +
      // BUG 38 FIX: inline detail container — expands inside the card, spans full grid width
      '<div class="v2-grc-inline-detail" data-detail-fw="' + fw + '" style="display:none;"></div>' +

    '</div>'
  }).join('');

  window._grcFrameworks = frameworks; window._grcFwDefs = fwDefs;
}

// BUG 38 FIX: expand inline inside the clicked card, not in a detached bottom div
window.expandGrcFramework = function(fw, cardEl) {
  var frameworks = window._grcFrameworks || {}; var fwDefs = window._grcFwDefs || {};
  if (!frameworks[fw]) return;

  // Close all other inline details
  document.querySelectorAll('.v2-grc-inline-detail').forEach(function(d) {
    if (d.getAttribute('data-detail-fw') !== fw) {
      d.style.display = 'none';
      d.innerHTML = '';
      var card = d.closest('.v2-grc-card');
      if (card) card.style.gridColumn = '';
    }
  });

  // Find this card's inline detail
  var grid = document.getElementById('grcFrameworkGrid');
  var card = grid ? grid.querySelector('[data-fw="' + fw + '"]') : null;
  var dm = card ? card.querySelector('.v2-grc-inline-detail') : null;
  if (!dm) return;

  // Toggle
  if (dm.style.display !== 'none' && dm.innerHTML !== '') {
    dm.style.display = 'none';
    dm.innerHTML = '';
    card.style.gridColumn = '';
    return;
  }

  // Expand: span full grid width
  card.style.gridColumn = '1 / -1';

  var data = frameworks[fw]; var def = fwDefs[fw]; var controls = data.controls || {};
  var entries = Object.entries(controls).sort(function(a,b) { return b[1].findings - a[1].findings; });
  var ch = entries.map(function(e) {
  var id=e[0], c=e[1]; var sc=c.findings>0?'#f59e0b':'#66BB6A';
  return '<div style="display:flex;align-items:center;gap:10px;padding:8px 12px;border-bottom:1px solid #1e293b;">' +
  '<span style="color:'+sc+';font-weight:700;font-size:14px;">'+(c.findings>0?'\u2717':'\u2713')+'</span>' +
  '<span style="color:#e2e8f0;font-weight:600;font-size:12px;min-width:80px;">'+id+'</span>' +
  '<a style="cursor:pointer;color:'+sc+';font-size:12px;" onclick="event.stopPropagation();' +
  (fw==='OWASP'     ? go({compliance:'OWASP-'+id,             search:'', pill:'all'}) :
  fw==='OWASP_LLM' ? go({compliance:'OWASP-'+id, type:'AI', search:'', pill:'all'}) :
  fw==='CWE'       ? go({compliance:'CWE-TOP-25',            search:id, pill:'all'}) :
  go({compliance:fw,                       search:'', pill:'all'})) +
  '"><span style="color:#475569;font-size:10px;">raw</span> '+c.findings+' ↗</a>' +
  '</div>';
  }).join('');

  dm.innerHTML =
    '<div style="background:#0a1120;border:1px solid '+def.color+'44;border-radius:8px;padding:16px 20px;margin-top:12px;">' +
      '<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px;">' +
        '<div style="font-size:13px;font-weight:700;color:'+def.color+';">'+def.name+' — Control Breakdown</div>' +
        '<span style="color:#64748b;font-size:11px;">'+Object.keys(controls).length+' controls · click again to close</span>' +
      '</div>' +
      '<div style="font-size:11px;color:#475569;background:rgba(255,255,255,0.03);border:1px solid #1e293b;border-radius:5px;padding:6px 10px;margin-bottom:12px;">' +
        '⚠ <span style="color:#94a3b8;">Counts below are <strong style="color:#f1f5f9;">raw signals</strong> (all findings including unreachable). Actionable = reachable + unknown only.</span>' +
      '</div>' +
      '<div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(280px,1fr));gap:2px;">' +
        (ch || '<div style="color:#64748b;font-size:12px;padding:12px;">No specific controls mapped.</div>') +
      '</div>' +
    '</div>';
  dm.style.display = 'block';
};

// ===========================
// DLP GRIDS
// ===========================
function renderDLPGrids(d) {
  var piiMount = document.getElementById('dlpPiiGrid');
  var taintMount = document.getElementById('dlpTaintGrid');
  var stripMount = document.getElementById('dlpSummaryStrip');
  var noDataMount = document.getElementById('dlpNoData');
  if (!piiMount) return;
  var dlp = d.dlp_findings || [];
  var dlpData = d.dlp || {};
  if (dlp.length === 0) { if (noDataMount) noDataMount.style.display = 'block'; if (stripMount) stripMount.innerHTML = '<span style="color:#94a3b8;">No DLP findings.</span>'; return; }
  if (noDataMount) noDataMount.style.display = 'none';
  var byPii = {}, byTaint = {};
  dlp.forEach(function(f) { var p = f.pii_type||f.source_type||'Unknown'; byPii[p]=(byPii[p]||0)+1; var t = f.sink_type||f.flow_type||'Unknown'; byTaint[t]=(byTaint[t]||0)+1; });
  var byTypeBreakdown = dlpData.by_type_breakdown || dlpData.by_pii_type || dlpData.by_type || byPii;
  var byTaintBreakdown = dlpData.by_taint_breakdown || dlpData.by_sink_type || dlpData.by_taint || byTaint;
  // 2-line reduction
  var dr = dlp.filter(function(f){return getReachabilityState(f)==='reachable';}).length;
  var du = dlp.filter(function(f){return getReachabilityState(f)==='unknown';}).length;
  var dnr = Math.max(0, dlp.length - dr - du);
  var dn = dlp.length>0?((dnr/dlp.length)*100).toFixed(0):0;
  var dlpActionable = dr + du;
  var dlpPiiTypes = Object.keys(byPii).length;
  var dlpItems = [
    { label:'PII types found', value: dlpPiiTypes, color:'#fb923c', bg:'rgba(251,146,60,0.10)' },
    { label:'total findings', value: dlp.length, color:'#94a3b8', bg:'rgba(148,163,184,0.06)',
      onclick:go({type:'DLP',pill:'all'}) },
    // BUG 42 FIX: actionable first (blue), reachable = blue not red
    { label:'actionable', value: dlpActionable, color: dlpActionable===0?'#475569':'#42A5F5', bg:'rgba(66,165,245,0.08)',
      onclick:go({type:'DLP',pill:'actionable'}) },
    { label:'reachable', value: dr, color:'#42A5F5', bg:'rgba(66,165,245,0.06)',
      onclick:go({type:'DLP',pill:'reachable'}) },
  ];
  if (du > 0) dlpItems.push({ label:'unknown', value: du, color:'#78909C', bg:'rgba(120,144,156,0.10)',
    onclick:go({type:'DLP',pill:'unknown'}) });
  if (stripMount) stripMount.innerHTML = statBar(dlpItems);

  // PII grid
  var piiMeta = {
    SSN:{icon:'#',color:'#ef4444',label:'SSN',desc:'Social Security Numbers exposed'},  // BUG 42: #FF1F1F = CRITICAL severity only
    EMAIL:{icon:'@',color:'#2979FF',label:'Email',desc:'Email addresses in data flows'},
    CREDIT_CARD:{icon:'$',color:'#f59e0b',label:'Credit Card',desc:'Payment card numbers (PCI-DSS risk)'},
    PHONE:{icon:'T',color:'#0ea5e9',label:'Phone',desc:'Phone numbers in data flows'},
    ADDRESS:{icon:'A',color:'#ec4899',label:'Address',desc:'Physical addresses in data outputs'},
    NAME:{icon:'N',color:'#06b6d4',label:'Name',desc:'Personal names in data flows'},
    DOB:{icon:'D',color:'#FF6B00',label:'Date of Birth',desc:'Birth dates \u2014 HIPAA/GDPR sensitive'},
    IP:{icon:'IP',color:'#10b981',label:'IP Address',desc:'IP addresses logged or transmitted'},
    PASSWORD:{icon:'*',color:'#ef4444',label:'Password',desc:'Passwords or credentials in data flows'},  // BUG 42: #FF1F1F = CRITICAL severity only
  };
  function makeCard(type, count, meta, searchVal) {
    // BUG 42 FIX: icon uses category color for visual identity; card count is always #42A5F5 (blue)
    var iconBg = meta.color + '22'; var iconFg = meta.color; var cardBorder = meta.color + '44';
    return '<div class="owasp-card has-issues" style="border:1px solid ' + cardBorder + ';text-align:left;padding:14px;cursor:pointer;min-height:110px;" onclick="' + go({type:'DLP',search:searchVal.toLowerCase(),pill:'all'}) + '">' +
      '<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:4px;">' +
        '<div style="display:flex;align-items:center;gap:6px;">' +
          '<span style="display:inline-flex;align-items:center;justify-content:center;width:22px;height:22px;border-radius:5px;background:' + iconBg + ';color:' + iconFg + ';font-weight:800;font-size:11px;font-family:monospace;">' + meta.icon + '</span>' +
          '<span style="font-size:11px;font-weight:700;color:#7284a0;">' + meta.label.toUpperCase() + '</span>' +
        '</div>' +
        // BUG 42 FIX: PII/taint card numbers use blue (actionable) not category color
        '<span style="font-size:22px;font-weight:800;color:#42A5F5;line-height:1;">' + count + '</span>' +
      '</div>' +
      '<div style="font-size:11px;color:#64748b;border-top:1px solid #334155;padding-top:6px;margin-top:6px;">' + meta.desc + '</div>' +
    '</div>';
  }
  piiMount.innerHTML = Object.entries(byTypeBreakdown).sort(function(a,b){return b[1]-a[1];}).map(function(e) {
    var m = piiMeta[e[0].toUpperCase()] || {icon:'?',color:'#64748b',label:e[0],desc:'Sensitive data detected'};
    return makeCard(e[0], e[1], m, e[0]);
  }).join('') || '<div style="color:#64748b;padding:20px;">No PII types detected</div>';

  // Taint grid
  var taintMeta = {
    HTTP:{icon:'H',color:'#2979FF',label:'HTTP',desc:'Sensitive data sent via HTTP'},
    DATABASE:{icon:'DB',color:'#0ea5e9',label:'Database',desc:'PII written to DB without masking'},
    FILE:{icon:'F',color:'#06b6d4',label:'File',desc:'Sensitive data written to files'},
    LOG:{icon:'L',color:'#f59e0b',label:'Log Output',desc:'PII leaked into logs \u2014 compliance risk'},
    EXTERNAL_API:{icon:'\u2192',color:'#f59e0b',label:'External API',desc:'Data sent to third-party APIs'},  // BUG 42: #FF1F1F = CRITICAL severity only
    CLOUD:{icon:'C',color:'#0ea5e9',label:'Cloud',desc:'Data sent to cloud services'},
    EMAIL:{icon:'@',color:'#ec4899',label:'Email',desc:'Sensitive data in outbound emails'},
    STDERR:{icon:'!',color:'#FF6B00',label:'Stderr',desc:'PII written to error streams'},
  };
  taintMount.innerHTML = Object.entries(byTaintBreakdown).sort(function(a,b){return b[1]-a[1];}).map(function(e) {
    var m = taintMeta[e[0].toUpperCase()] || {icon:'?',color:'#64748b',label:e[0],desc:'Data flow to external sink'};
    return makeCard(e[0], e[1], m, e[0]);
  }).join('') || '<div style="color:#64748b;padding:20px;">No taint flows detected</div>';
}

// ===========================
// OWASP TOP 10
// ===========================
function renderOwaspTop10(d) {
  var gridMount = document.getElementById('owaspCategoryGrid');
  var stripMount = document.getElementById('owaspSummaryStrip');
  var noDataMount = document.getElementById('owaspNoData');
  if (!gridMount) return;
  var ow = d.owasp_web || {};
  var names = ow.category_names || {};
  var byCatBd = ow.by_category_breakdown || {};
  // Always recompute byCat from issues excluding not_applicable/CONFIG
  // so card counters stay in sync with table (which also excludes them)
  var byCat = {};
  var byCatBd = {};  // recompute from live issues, excluding not_applicable/CONFIG
  var owConfigExcluded = (d.funnel || {}).config_excluded || false;
  (d.issues||[]).forEach(function(f) {
    if (f.reachability_state === 'not_applicable' || (owConfigExcluded && f.type==='CONFIG')) return;
    // Use merged mapping (DB + inferred) so card counters match applyFilters table counts
    var _dbM = f.compliance_mapping||{};
    var _infM = (typeof window.inferComplianceMapping==='function' && window.inferComplianceMapping(f))||{};
    var m = Object.assign({}, _infM, _dbM);
    var o = m.OWASP||m.owasp;
    if (!Array.isArray(o)) return;
    o.forEach(function(c) {
      var cat = c.split(':')[0];
      byCat[cat] = (byCat[cat]||0) + 1;
      if (!byCatBd[cat]) byCatBd[cat] = {reachable:0, unknown:0, unreachable:0};
      var rs = f.reachability_state || '';
      if (rs === 'reachable') byCatBd[cat].reachable++;
      else if (rs === 'unknown') byCatBd[cat].unknown++;
      else byCatBd[cat].unreachable++;
    });
  });
  var cats = ['A01','A02','A03','A04','A05','A06','A07','A08','A09','A10'];
  var cn = {A01:'Broken Access Control',A02:'Security Misconfiguration',A03:'Supply Chain Failures',A04:'Cryptographic Failures',A05:'Injection',A06:'Insecure Design',A07:'Auth Failures',A08:'Data Integrity Failures',A09:'Logging & Alerting Failures',A10:'Exceptional Conditions'};
  var hasData = Object.values(byCat).some(function(v){return v>0;});
  if (!hasData && noDataMount) noDataMount.style.display = 'block';
  else if (noDataMount) noDataMount.style.display = 'none';
  var totOwasp = Object.values(byCat).reduce(function(s,v){return s+v;},0);
  var affected = Object.entries(byCat).filter(function(e){return e[1]>0;}).length;

  // Compute reachability for OWASP-mapped findings
  var owReach = 0, owUnkn = 0, owUnreach = 0;
  var owConfigExcluded = (d.funnel || {}).config_excluded || false;
  (d.issues||[]).forEach(function(f) {
    if (f.reachability_state === 'not_applicable' || (owConfigExcluded && f.type === 'CONFIG')) return;
    var m = f.compliance_mapping || {};
    if (!m.OWASP && !m.owasp) return;
    var rs = f.reachability_state || (f.is_reachable === true ? 'reachable' : f.is_reachable === false ? 'not_reachable' : 'unknown');
    if (rs === 'reachable') owReach++;
    else if (rs === 'not_reachable') owUnreach++;
    else owUnkn++;
  });
  var owNoise = totOwasp > 0 ? ((owUnreach/totOwasp)*100).toFixed(1) : 0;
  var owActionable = owReach + owUnkn;
  if (stripMount) {
    var owTotalLabel = 'total findings';
    var owActLabel   = 'actionable';
    stripMount.innerHTML = statBar([
      { label:'categories affected', value: affected+'/10', color:'#f59e0b', bg:'rgba(15,23,42,0.75)' },
      // BUG 47 FIX: zero-color must be evaluated at render time using final computed values
      { label: owTotalLabel, value: totOwasp, color:'#94a3b8', bg:'rgba(148,163,184,0.06)',
        onclick:go({compliance:'OWASP',search:'',pill:'all'}) },
      { label: owActLabel, value: owActionable, color: (owActionable===0) ? '#475569' : '#2979FF', bg:(owActionable===0)?'rgba(71,85,105,0.06)':'rgba(59,130,246,0.10)',
        onclick:go({compliance:'OWASP',search:'',pill:'actionable'}) },
      { label:'reachable', value: owReach, color: (owReach===0) ? '#475569' : '#42A5F5', bg:(owReach===0)?'rgba(71,85,105,0.06)':'rgba(66,165,245,0.08)',
        onclick:go({compliance:'OWASP',search:'',pill:'reachable'}) },
      { label:'unknown', value: owUnkn, color: (owUnkn===0) ? '#475569' : '#78909C', bg:(owUnkn===0)?'rgba(71,85,105,0.06)':'rgba(120,144,156,0.10)',
        onclick:go({compliance:'OWASP',search:'',pill:'unknown'}) },
    ]);
  }
  gridMount.innerHTML = cats.map(function(cat) {
    var count = byCat[cat]||0; var name = names[cat]||cn[cat]||cat; var bd = byCatBd[cat]||{};
    var has = count > 0;
    var bc = count===0?'#1e293b':'#f59e0b';
    var goOwaspAll   = go({stop:true,compliance:'OWASP-'+cat,search:'',pill:'all'});
    var goOwaspAct   = go({stop:true,compliance:'OWASP-'+cat,search:'',pill:'actionable'});
    var goOwaspReach = go({stop:true,compliance:'OWASP-'+cat,search:'',pill:'reachable'});
    var goOwaspUnkn  = go({stop:true,compliance:'OWASP-'+cat,search:'',pill:'unknown'});
    var actCount = (bd.reachable||0) + (bd.unknown||0);
    return '<div class="owasp-card '+(has?'has-issues':'')+'" style="cursor:pointer;border:1px solid '+bc+';text-align:left;padding:14px;min-height:130px;display:flex;flex-direction:column;justify-content:space-between;" onclick="filterByOwaspCategory(\''+cat+'\',false)">' +
      '<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:6px;">' +
        '<span style="font-size:11px;font-weight:700;color:#7284a0;">'+cat+'</span>' +
        '<div style="text-align:right;">' +
          // BUG 40 FIX: Big number = actionable (blue), not raw (orange/green). Zero = muted, not celebratory green.
          '<a style="cursor:pointer;font-size:22px;font-weight:800;color:'+(actCount===0?'#475569':'#42A5F5')+';text-decoration:none;display:block;line-height:1;" onclick="'+goOwaspAct+'">'+actCount+'</a>' +
          (count>0?'<span style="font-size:9px;color:#475569;font-style:italic;">raw '+count+'</span>':'') +
        '</div>' +
      '</div>' +
      '<div style="font-size:12px;color:#94a3b8;margin-bottom:6px;">'+name+'</div>' +
      (has?(function(){
        // Inline CWE/type tags for this OWASP category
        var cweIds = []; var typesSeen = {};
        (window.dashboardData&&window.dashboardData.issues||[]).forEach(function(f) {
          if (f.reachability_state==='not_applicable'||f.type==='CONFIG') return;
          var o=(f.compliance_mapping||{}).OWASP||[];
          if (!Array.isArray(o)||!o.some(function(c){return c.startsWith(cat);})) return;
          var cl=(f.compliance_mapping||{}).CWE||[];
          if (Array.isArray(cl)) cl.forEach(function(c){var id=c.split(':')[0]; if(cweIds.indexOf(id)<0)cweIds.push(id);});
          typesSeen[f.type]=true;
        });
        cweIds.sort();
        var MAX=10; var tags=cweIds.slice(0,MAX).map(function(id){
          return '<span style="display:inline-block;background:rgba(100,116,139,0.15);color:#94a3b8;'+
                 'font-size:9px;font-weight:600;padding:1px 4px;border-radius:3px;font-family:monospace;">'+id+'</span>';
        }).join(' ');
        var rest=cweIds.length-Math.min(cweIds.length,MAX);
        if(rest>0) tags+=' <span style="color:#475569;font-size:9px;">+'+rest+' more</span>';
        // If no CWE IDs, show type badges instead
        if(!tags) tags=Object.keys(typesSeen).map(function(t){
          return '<span style="display:inline-block;background:rgba(100,116,139,0.15);color:#94a3b8;'+
                 'font-size:9px;font-weight:600;padding:1px 4px;border-radius:3px;">'+t+'</span>';
        }).join(' ');
        return tags ? '<div style="margin-bottom:6px;">'+tags+'</div>' : '';
      }()):'') +
      (has?'<div style="display:flex;gap:8px;font-size:10px;border-top:1px solid #334155;padding-top:6px;">' +
        ((bd.reachable||0)>0?'<a style="cursor:pointer;color:#42A5F5;text-decoration:none;" onclick="'+goOwaspReach+'">'+( bd.reachable||0)+' reachable</a>':'') +
        ((bd.unknown||0)>0?' <a style="cursor:pointer;color:#78909C;text-decoration:none;" onclick="'+goOwaspUnkn+'">'+(bd.unknown||0)+' unknown</a>':'') +
        ' <a style="cursor:pointer;color:#475569;font-size:9px;text-decoration:none;font-style:italic;opacity:0.7;" onclick="'+goOwaspAll+'">raw '+count+'</a>' +
      '</div>':'') +
    '</div>';
  }).join('');
}

// ===========================
// LLM TOP 10
// ===========================
function renderLlmTop10(d) {
  var gridMount = document.getElementById('llmCategoryGrid');
  var stripMount = document.getElementById('llmSummaryStrip');
  var noDataMount = document.getElementById('llmNoData');
  if (!gridMount) return;
  var aiSec = d.ai_security || {};
  // Work on a local copy of byOwasp so we can remap without touching data
  var rawByOwasp = aiSec.by_owasp || {};
  var byOwasp = {};
  Object.keys(rawByOwasp).forEach(function(k){ byOwasp[k] = rawByOwasp[k]; });
  var byBd = aiSec.by_owasp_breakdown || {};
  var total = aiSec.total || 0;
  var reachable = aiSec.reachable || total;
  var guarded = aiSec.guarded || 0;

  if (total === 0) {
    if (noDataMount) noDataMount.style.display = 'block';
    if (stripMount) stripMount.innerHTML = '<span style="color:#94a3b8;">No AI/LLM findings detected.</span>';
    gridMount.innerHTML = '';
    return;
  }
  if (noDataMount) noDataMount.style.display = 'none';

  // BUG 36 FIX: Remap genuine LLM06 aliases (MCP/CONTROLS). Delete informational.
  // MCP tool risks = Excessive Agency = LLM06 per OWASP spec.
  ['MCP', 'MCP_SECURITY', 'CONTROLS', 'MODEL_CONTROLS'].forEach(function(k) {
    if (byOwasp[k]) {
      byOwasp['LLM06'] = (byOwasp['LLM06'] || 0) + byOwasp[k];
      delete byOwasp[k];
    }
    if (byBd[k]) {
      byBd['LLM06'] = byBd['LLM06'] || { reachable:0, unknown:0, not_reachable:0 };
      ['reachable','unknown','not_reachable'].forEach(function(s){
        byBd['LLM06'][s] = (byBd['LLM06'][s]||0) + (byBd[k][s]||0);
      });
      delete byBd[k];
    }
  });
  // BUG-CTR-02: Remove informational categories — they're not real LLM findings.
  ['PRIMITIVE', 'AI_PRIMITIVE', 'NONE'].forEach(function(k) {
    delete byOwasp[k];
    delete byBd[k];
  });

  // ── LLM → ASI dual-tag mapping (OWASP ASI v1.1, T1-T17) ──
  var LLM_TO_ASI = {
    'LLM01': ['T6','T1'],    // Prompt Injection → Goal Manipulation, Memory Poisoning
    'LLM02': ['T15','T8'],   // Sensitive Disclosure → Human Manipulation, Repudiation
    'LLM03': ['T17','T16'],  // Supply Chain → Supply Chain, Protocol Abuse
    'LLM04': ['T1','T5'],    // Data Poisoning → Memory Poisoning, Cascading Hallucination
    'LLM05': ['T11','T2'],   // Insecure Output → RCE, Tool Misuse
    'LLM06': ['T2','T3'],    // Excessive Agency → Tool Misuse, Privilege Compromise
    'LLM07': ['T2','T11'],   // Insecure Plugin → Tool Misuse, RCE
    'LLM08': ['T1','T5'],    // Vector Weakness → Memory Poisoning, Cascading Hallucination
    'LLM09': ['T5','T15'],   // Misinformation → Cascading Hallucination, Human Manipulation
    'LLM10': ['T4','T10'],   // Unbounded Consumption → Resource Overload, Overwhelming HITL
  };
  // ASI category colors: agency=#7b341e, memory=#553c9a, tool=#975a16, auth=#276749, human=#744210, multiagent=#702459
  var ASI_DEFS = {
    'T1':  { name:'Memory Poisoning',        cat:'memory',     color:'#553c9a' },
    'T2':  { name:'Tool Misuse',             cat:'tool',       color:'#975a16' },
    'T3':  { name:'Privilege Compromise',    cat:'tool',       color:'#975a16' },
    'T4':  { name:'Resource Overload',       cat:'tool',       color:'#975a16' },
    'T5':  { name:'Cascading Hallucination', cat:'memory',     color:'#553c9a' },
    'T6':  { name:'Goal Manipulation',       cat:'agency',     color:'#7b341e' },
    'T7':  { name:'Misaligned & Deceptive',  cat:'agency',     color:'#7b341e' },
    'T8':  { name:'Repudiation',             cat:'agency',     color:'#7b341e' },
    'T9':  { name:'Identity Spoofing',       cat:'auth',       color:'#276749' },
    'T10': { name:'Overwhelming HITL',       cat:'human',      color:'#744210' },
    'T11': { name:'RCE & Code Attacks',      cat:'tool',       color:'#975a16' },
    'T12': { name:'Agent Comms Poisoning',   cat:'multiagent', color:'#702459' },
    'T13': { name:'Rogue Agents',            cat:'multiagent', color:'#702459' },
    'T14': { name:'Human Attacks on MAS',    cat:'multiagent', color:'#702459' },
    'T15': { name:'Human Manipulation',      cat:'human',      color:'#744210' },
    'T16': { name:'Protocol Abuse',          cat:'multiagent', color:'#702459' },
    'T17': { name:'Supply Chain Compromise', cat:'tool',       color:'#975a16' },
  };

  // ── Summary strip ──
  var llmKeys = ['LLM01','LLM02','LLM03','LLM04','LLM05','LLM06','LLM07','LLM08','LLM09','LLM10'];
  var llmMapped = llmKeys.reduce(function(s,k){ return s+(byOwasp[k]||0); }, 0);
  var agenticCount = llmKeys.filter(function(k){ return (byOwasp[k]||0)>0 && LLM_TO_ASI[k]; })
                            .reduce(function(s,k){ return s+(byOwasp[k]||0); }, 0);
  // Split: LLM-security findings vs informational AI patterns
  // BUG 46 FIX: strip counter must equal what pill:actionable click shows
  // = all actionable AI issues (reachable+unknown), regardless of OWASP LLM mapping
  var _allAiIssues = (d.issues||[]).filter(function(f){ return (f.type||'').toUpperCase()==='AI'; });
  var llmSecCount  = _allAiIssues.filter(function(f){ return f.reachability_state==='reachable'||f.reachability_state==='unknown'; }).length;
  var aiInfoCount  = Math.max(0, total - llmSecCount);  // non-actionable AI patterns
  var llmReachable = llmKeys.reduce(function(s,k){
    return s + ((byBd[k]||{}).reachable||0);
  }, 0);

  if (stripMount) stripMount.innerHTML = statBar([
    // BUG 46 FIX: counter shows llmSecCount (actionable LLM findings). pill must be 'actionable' so click returns same count.
    // BUG 47 FIX: zero values muted, not colored
    { label:'AI / LLM security findings', value: llmSecCount, color: (llmSecCount===0)?'#475569':'#2979FF', bg:(llmSecCount===0)?'rgba(71,85,105,0.06)':'rgba(41,121,255,0.10)',
      onclick:go({type:'AI',search:'',pill:'actionable'}) },
    { label:'reachable', value: llmReachable, color: (llmReachable===0)?'#475569':'#42A5F5', bg:(llmReachable===0)?'rgba(71,85,105,0.06)':'rgba(66,165,245,0.08)',
      onclick:go({type:'AI',search:'',pill:'reachable'}) },
    { label:'informational patterns', value: aiInfoCount, color:'#475569', bg:'rgba(71,85,105,0.08)' },
    { label: guarded > 0 ? 'guardrails detected' : 'no guardrails', value: guarded > 0 ? guarded : 0,
      color: guarded > 0 ? '#66BB6A' : '#78909C', bg: guarded > 0 ? 'rgba(102,187,106,0.10)' : 'rgba(120,144,156,0.10)' },
  ]);

  // ── LLM category definitions ──
  var llmDefs = {
    LLM01:{name:'Prompt Injection',     color:'#f59e0b'},
    LLM02:{name:'Sensitive Disclosure', color:'#f59e0b'},
    LLM03:{name:'Supply Chain',         color:'#f59e0b'},
    LLM04:{name:'Data Poisoning',       color:'#B8960C'},
    LLM05:{name:'Improper Output',      color:'#f59e0b'},
    LLM06:{name:'Excessive Agency',     color:'#f59e0b'},
    LLM07:{name:'Prompt Leakage',       color:'#B8960C'},
    LLM08:{name:'Vector Weakness',      color:'#66BB6A'},
    LLM09:{name:'Misinformation',       color:'#66BB6A'},
    LLM10:{name:'Unbounded Consumption',color:'#66BB6A'},
  };

  // ── Render LLM cards ──
  var llmHtml = llmKeys.map(function(cat) {
    var count = byOwasp[cat] || 0;
    if (count === 0) return '';
    var def = llmDefs[cat];
    var bd  = byBd[cat] || {};
    var goLlm      = go({stop:true,type:'AI',search:'',compliance:'OWASP-'+cat,pill:'all'});
    var goLlmReach = go({stop:true,type:'AI',search:'',compliance:'OWASP-'+cat,pill:'reachable'});
    var goLlmUnkn  = go({stop:true,type:'AI',search:'',compliance:'OWASP-'+cat,pill:'unknown'});
    var outerClick = goLlm;

    // ASI dual-tag badges with category-based colors
    var CAT_BADGE = {
      agency:     { bg:'rgba(123,52,30,0.25)', fg:'#fca5a5', border:'rgba(248,113,113,0.3)' },
      memory:     { bg:'rgba(85,60,154,0.25)', fg:'#c4b5fd', border:'rgba(167,139,250,0.3)' },
      tool:       { bg:'rgba(151,90,22,0.25)', fg:'#fcd34d', border:'rgba(251,191,36,0.3)' },
      auth:       { bg:'rgba(39,103,73,0.25)', fg:'#86efac', border:'rgba(74,222,128,0.3)' },
      human:      { bg:'rgba(116,66,16,0.25)', fg:'#fdba74', border:'rgba(251,146,60,0.3)' },
      multiagent: { bg:'rgba(112,36,89,0.25)', fg:'#f9a8d4', border:'rgba(244,114,182,0.3)' },
    };
    var asiTags = (LLM_TO_ASI[cat] || []).map(function(asi) {
      var adef = ASI_DEFS[asi] || { name:asi, cat:'tool' };
      var badge = CAT_BADGE[adef.cat] || CAT_BADGE.tool;
      return '<span style="display:inline-block;background:'+badge.bg+';color:'+badge.fg+';' +
             'border:1px solid '+badge.border+';border-radius:3px;font-size:9px;' +
             'font-weight:700;padding:1px 5px;margin-right:3px;">' +
             asi + ' · ' + adef.name + '</span>';
    }).join('');

    return '<div class="owasp-card has-issues" style="border:1px solid ' + def.color + '44;text-align:left;padding:14px;cursor:pointer;min-height:130px;display:flex;flex-direction:column;justify-content:space-between;" onclick="' + outerClick + '">' +
      '<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:4px;">' +
        '<span style="font-size:11px;font-weight:700;color:#7284a0;">' + cat + '</span>' +
        // BUG 41 FIX: Big number = actionable (blue), click goes to actionable pill. Raw shown muted.
        (function(){
          var llmAct = (bd.reachable||0)+(bd.unknown||0);
          var goLlmAct = go({stop:true,type:'AI',search:'',compliance:'OWASP-'+cat,pill:'actionable'});
          return '<a style="cursor:pointer;font-size:22px;font-weight:800;color:'+(llmAct===0?'#475569':'#42A5F5')+';text-decoration:none;" onclick="'+goLlmAct+'">'+llmAct+'</a>' +
                 '<span style="font-size:9px;color:#475569;font-style:italic;margin-left:4px;">raw '+count+'</span>';
        })() +
      '</div>' +
      '<div style="font-size:12px;color:#94a3b8;margin-bottom:6px;">' + def.name + '</div>' +
      (asiTags ? '<div style="margin-bottom:6px;">' + asiTags + '</div>' : '') +
      (function(){
        // Show policy IDs for findings in this LLM category
        var pids = [];
        (window.dashboardData&&window.dashboardData.issues||[]).forEach(function(f) {
          if (f.type!=='AI') return;
          var raw=(f.llm_category||f.owasp_llm||'').toUpperCase();
          var mapped=raw;
          if (mapped!==cat&&raw!==cat) return;
          var pid=f.policy_id||f.rule_id||f.id||'';
          if (pid&&pids.indexOf(pid)<0) pids.push(pid);
        });
        if (!pids.length) return '';
        var MAX=10; var tags=pids.slice(0,MAX).map(function(p){
          return '<span style="display:inline-block;background:rgba(30,58,138,0.2);color:#93c5fd;'+
                 'font-size:9px;font-weight:600;padding:1px 4px;border-radius:3px;font-family:monospace;">'+p+'</span>';
        }).join(' ');
        var rest=pids.length-Math.min(pids.length,MAX);
        if(rest>0) tags+=' <span style="color:#475569;font-size:9px;">+'+rest+' more</span>';
        return '<div style="margin-bottom:6px;">'+tags+'</div>';
      }()) +
      '<div style="display:flex;gap:8px;font-size:10px;border-top:1px solid #334155;padding-top:6px;">' +
        ((bd.reachable||0) > 0 ? '<a style="cursor:pointer;color:#42A5F5;text-decoration:none;" onclick="' + goLlmReach + '">' + (bd.reachable||0) + ' reachable</a>' : '') +
        ((bd.unknown||0) > 0 ? ' <a style="cursor:pointer;color:#78909C;text-decoration:none;" onclick="' + goLlmUnkn + '">' + (bd.unknown||0) + ' unknown</a>' : '') +
        ((bd.reachable||0) === 0 && (bd.unknown||0) === 0 ? '<span style="color:#475569;font-size:10px;">all findings</span>' : '') +
        ' <a style="cursor:pointer;color:#475569;font-size:9px;text-decoration:none;font-style:italic;opacity:0.7;" onclick="' + goLlm + '">raw ' + count + '</a>' +
      '</div>' +
    '</div>';
  }).join('');

  // NONE/OTHER suppressed
  var noneCard = '';;

  gridMount.innerHTML = (llmHtml + noneCard) || '<div style="color:#94a3b8;padding:20px;">No LLM Top 10 findings.</div>';

  // asiOnlySection removed — Agentic section is now a standalone GRC box (renderOwaspAgentic2026)
}

// ===========================
function renderOwaspAgentic2026(d) {
  var gridMount  = document.getElementById('asiCategoryGrid');
  var stripMount = document.getElementById('asiSummaryStrip');
  var noDataMount = document.getElementById('asiNoData');
  if (!gridMount) return;

  // Official OWASP ASI v1.1 T1-T17 definitions
  var asiDefs = {
    T1:  { name:'Memory Poisoning',              color:'#553c9a', cat:'memory',     desc:'Manipulation of persistent agent memory or context windows' },
    T2:  { name:'Tool Misuse',                   color:'#975a16', cat:'tool',       desc:'Abuse of agent-accessible tools beyond intended scope' },
    T3:  { name:'Privilege Compromise',          color:'#975a16', cat:'tool',       desc:'Agents acting with excessive or stolen identity/privileges' },
    T4:  { name:'Resource Overload',             color:'#975a16', cat:'tool',       desc:'Unbounded resource consumption or runaway loops' },
    T5:  { name:'Cascading Hallucination',       color:'#553c9a', cat:'memory',     desc:'Cascading hallucination attacks across agent sessions' },
    T6:  { name:'Goal Manipulation',             color:'#7b341e', cat:'agency',     desc:'Intent breaking & goal manipulation via prompt or environment' },
    T7:  { name:'Misaligned & Deceptive',        color:'#7b341e', cat:'agency',     desc:'Misaligned & deceptive agent behaviors' },
    T8:  { name:'Repudiation & Untraceability',  color:'#7b341e', cat:'agency',     desc:'Repudiation & untraceability of agent actions' },
    T9:  { name:'Identity Spoofing',             color:'#276749', cat:'auth',       desc:'Identity spoofing & impersonation of agents' },
    T10: { name:'Overwhelming HITL',             color:'#744210', cat:'human',      desc:'Overwhelming human-in-the-loop oversight' },
    T11: { name:'RCE & Code Attacks',            color:'#975a16', cat:'tool',       desc:'Unexpected RCE and code attacks via agent tool execution' },
    T12: { name:'Agent Comms Poisoning',         color:'#702459', cat:'multiagent', desc:'Unvalidated messages between agents enabling injection chains' },
    T13: { name:'Rogue Agents',                  color:'#702459', cat:'multiagent', desc:'Rogue agents in multi-agent systems' },
    T14: { name:'Human Attacks on MAS',          color:'#702459', cat:'multiagent', desc:'Human attacks on multi-agent systems' },
    T15: { name:'Human Manipulation',            color:'#744210', cat:'human',      desc:'Manipulation of human oversight or trust relationships' },
    T16: { name:'Protocol Abuse',                color:'#702459', cat:'multiagent', desc:'Insecure inter-agent protocol abuse (MCP/A2A)' },
    T17: { name:'Supply Chain Compromise',       color:'#975a16', cat:'tool',       desc:'Compromised models, plugins, or third-party agent dependencies' },
  };

  // LLM -> ASI crosswalk (OWASP ASI v1.1, T1-T17)
  var LLM_TO_ASI = {
    LLM01: ['T6','T1'],    // Prompt Injection → Goal Manipulation, Memory Poisoning
    LLM02: ['T15','T8'],   // Sensitive Disclosure → Human Manipulation, Repudiation
    LLM03: ['T17','T16'],  // Supply Chain → Supply Chain, Protocol Abuse
    LLM04: ['T1','T5'],    // Data Poisoning → Memory Poisoning, Cascading Hallucination
    LLM05: ['T11','T2'],   // Insecure Output → RCE, Tool Misuse
    LLM06: ['T2','T3'],    // Excessive Agency → Tool Misuse, Privilege Compromise
    LLM07: ['T2','T11'],   // Insecure Plugin → Tool Misuse, RCE
    LLM08: ['T1','T5'],    // Vector Weakness → Memory Poisoning, Cascading Hallucination
    LLM09: ['T5','T15'],   // Misinformation → Cascading Hallucination, Human Manipulation
    LLM10: ['T4','T10'],   // Unbounded Consumption → Resource Overload, Overwhelming HITL
  };

  var cats = ['T1','T2','T3','T4','T5','T6','T7','T8','T9','T10','T11','T12','T13','T14','T15','T16','T17'];
  // BUG-CTR-06 FIX: Reverse crosswalk ASI → parent LLM codes for compliance navigation
  var ASI_TO_LLM = {};
  Object.keys(LLM_TO_ASI).forEach(function(llm) {
    LLM_TO_ASI[llm].forEach(function(asi) { if (!ASI_TO_LLM[asi]) ASI_TO_LLM[asi] = []; ASI_TO_LLM[asi].push(llm); });
  });
  var asiCounts = {};
  cats.forEach(function(k) { asiCounts[k] = { total:0, reachable:0, unknown:0 }; });

  var aiIssues = (d.issues || []).filter(function(f) { return (f.type||'').toUpperCase() === 'AI'; });
  // Track which LLM codes have findings for navigation
  var llmWithFindings = {};
  aiIssues.forEach(function(f) {
    var raw2 = (f.owasp_llm || f.llm_category || '').toUpperCase();
    if (raw2 === 'MCP' || raw2 === 'MCP_SECURITY' || raw2 === 'CONTROLS' || raw2 === 'MODEL_CONTROLS') raw2 = 'LLM06';
    if (raw2 && raw2 !== 'NONE' && raw2 !== 'PRIMITIVE' && raw2 !== 'AI_PRIMITIVE') llmWithFindings[raw2] = true;
  });
  aiIssues.forEach(function(f) {
    var raw = (f.owasp_llm || f.llm_category || '').toUpperCase();
    // BUG-CTR-02: Only remap genuine LLM06 aliases. Skip informational.
    if (raw === 'MCP' || raw === 'MCP_SECURITY' || raw === 'CONTROLS' || raw === 'MODEL_CONTROLS') raw = 'LLM06';
    if (raw === 'NONE' || raw === 'PRIMITIVE' || raw === 'AI_PRIMITIVE' || raw === '') return;
    var asiList = LLM_TO_ASI[raw] || [];
    var rs = f.reachability_state || 'unknown';
    asiList.forEach(function(asi) {
      if (!asiCounts[asi]) return;
      asiCounts[asi].total++;
      if (rs === 'reachable') asiCounts[asi].reachable++;
      else if (rs === 'unknown') asiCounts[asi].unknown++;
    });
  });

  var totalAI     = aiIssues.length;
  var asiAffected = cats.filter(function(k){ return asiCounts[k].total > 0; }).length;
  var asiReach    = cats.reduce(function(s,k){ return s + asiCounts[k].reachable; }, 0);
  var asiUnkn     = cats.reduce(function(s,k){ return s + asiCounts[k].unknown; }, 0);
  var asiAct      = asiReach + asiUnkn;

  if (totalAI === 0) {
    if (noDataMount) noDataMount.style.display = 'block';
    if (stripMount) stripMount.innerHTML = '<span style="color:#94a3b8;">No AI/LLM findings detected.</span>';
    gridMount.innerHTML = '';
    return;
  }
  if (noDataMount) noDataMount.style.display = 'none';

  if (stripMount) {
    stripMount.innerHTML = statBar([
      { label:'categories affected', value: asiAffected+'/17', color:'#f59e0b', bg:'rgba(15,23,42,0.75)' },
      { label:'actionable', value: asiAct, color: asiAct===0?'#475569':'#2979FF', bg: asiAct===0?'rgba(71,85,105,0.06)':'rgba(41,121,255,0.10)',
        onclick: go({type:'AI',search:'',pill:'actionable'}) },
      { label:'reachable', value: asiReach, color: asiReach===0?'#475569':'#42A5F5', bg: asiReach===0?'rgba(71,85,105,0.06)':'rgba(66,165,245,0.08)',
        onclick: go({type:'AI',search:'',pill:'reachable'}) },
      { label:'unknown', value: asiUnkn, color: asiUnkn===0?'#475569':'#78909C', bg: asiUnkn===0?'rgba(71,85,105,0.06)':'rgba(120,144,156,0.10)',
        onclick: go({type:'AI',search:'',pill:'unknown'}) },
      { label:'AI findings total', value: totalAI, color:'#64748b', bg:'rgba(100,116,139,0.06)',
        onclick: go({type:'AI',search:'',pill:'all'}) },
    ]);
  }

  gridMount.innerHTML = cats.map(function(cat) {
    var def  = asiDefs[cat];
    var data = asiCounts[cat];
    var has  = data.total > 0;
    var act  = data.reachable + data.unknown;
    var bc   = has ? def.color + '44' : '#1e293b';
    var actColor = act > 0 ? '#42A5F5' : '#475569';

    // Show which LLM categories map to this ASI (must be before go() calls)
    var sourceLLM = Object.keys(LLM_TO_ASI).filter(function(llm) {
      return LLM_TO_ASI[llm].indexOf(cat) >= 0;
    });
    // BUG-CTR-04 FIX: ASI codes don't exist in findings — navigate via parent LLM compliance
    // Pick the parent LLM with the most findings so click actually returns rows
    var byOwasp = (d.ai_security || {}).by_owasp || {};
    var bestLlm = sourceLLM.reduce(function(best, llm) {
      return (byOwasp[llm] || 0) > (byOwasp[best] || 0) ? llm : best;
    }, sourceLLM[0] || '');
    var asiComp = bestLlm ? 'OWASP-' + bestLlm : '';
    var goAct   = go({stop:true, type:'AI', compliance:asiComp, pill:'actionable'});
    var goReach = go({stop:true, type:'AI', compliance:asiComp, pill:'reachable'});
    var goUnkn  = go({stop:true, type:'AI', compliance:asiComp, pill:'unknown'});
    var goAll   = go({stop:true, type:'AI', compliance:asiComp, pill:'all'});
    var llmTags = sourceLLM.map(function(llm) {
      return '<span style="display:inline-block;background:rgba(99,102,241,0.15);color:#a5b4fc;' +
             'border:1px solid rgba(99,102,241,0.25);border-radius:3px;font-size:9px;' +
             'font-weight:700;padding:1px 5px;margin-right:3px;font-family:monospace;">' + llm + '</span>';
    }).join('');

    return '<div class="owasp-card ' + (has ? 'has-issues' : '') + '" style="' +
      'border:1px solid ' + bc + ';text-align:left;padding:14px;min-height:130px;' +
      'display:flex;flex-direction:column;justify-content:space-between;' +
      (has ? 'cursor:pointer;' : 'opacity:0.5;') + '" ' +
      (has ? 'onclick="' + goAll + '"' : '') + '>' +

      '<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:4px;">' +
        '<span style="font-size:11px;font-weight:700;color:#7284a0;">' + cat + '</span>' +
        '<div style="text-align:right;">' +
          (act > 0
            ? '<a style="cursor:pointer;font-size:22px;font-weight:800;color:' + actColor + ';text-decoration:none;display:block;line-height:1;" onclick="' + goAct + '">' + act + '</a>'
            : '<span style="font-size:22px;font-weight:800;color:' + actColor + ';display:block;line-height:1;">' + act + '</span>') +
          (has ? '<span style="font-size:9px;color:#475569;font-style:italic;">raw ' + data.total + '</span>' : '') +
        '</div>' +
      '</div>' +

      '<div style="font-size:12px;color:' + (has ? '#e2e8f0' : '#94a3b8') + ';font-weight:' + (has ? '600' : '400') + ';margin-bottom:4px;">' + def.name + '</div>' +
      '<div style="font-size:10px;color:#64748b;margin-bottom:6px;line-height:1.4;">' + def.desc + '</div>' +

      (llmTags ? '<div style="margin-bottom:6px;">' + llmTags + '</div>' : '') +

      (has ? ('<div style="display:flex;gap:8px;font-size:10px;border-top:1px solid #334155;padding-top:6px;">' +
        (data.reachable > 0 ? '<a style="cursor:pointer;color:#42A5F5;text-decoration:none;" onclick="' + goReach + '">' + data.reachable + ' reachable</a>' : '') +
        (data.unknown   > 0 ? ' <a style="cursor:pointer;color:#78909C;text-decoration:none;" onclick="' + goUnkn + '">' + data.unknown + ' unknown</a>' : '') +
        ' <a style="cursor:pointer;color:#475569;font-size:9px;text-decoration:none;font-style:italic;opacity:0.7;" onclick="' + goAll + '">raw ' + data.total + '</a>' +
      '</div>') : '') +

    '</div>';
  }).join('');
}

// ===========================
// FINDINGS PILLS
// ===========================
function updateFindingsPills(d) {
  var allIssues = d.issues || [];
  var configExcluded = (d.funnel || {}).config_excluded || false;
  var issues = allIssues.filter(function(f){ return f.reachability_state !== 'not_applicable' && f.type !== 'CONFIG'; });
  function sc(id,v) { var el=document.getElementById(id); if(el) el.textContent=v; }
  var r = issues.filter(function(f){return getReachabilityState(f)==='reachable';}).length;
  var u = issues.filter(function(f){return getReachabilityState(f)==='unknown';}).length;
  sc('pillActionableCount', r+u); sc('pillReachableCount', r); sc('pillUnknownCount', u); sc('pillAllCount', issues.length);
  var re = document.getElementById('findingsResultCount');
  if (re) re.textContent = issues.length + ' results';
}
window.setReachPill = function(pill) {
  pill = pill || 'all';
  var rf = document.getElementById('reachableFilter');
  if (rf) rf.value = (pill === 'all') ? '' : pill;
  document.querySelectorAll('.v2-pill[data-reach-filter]').forEach(function(b) {
    b.classList.toggle('v2-pill-active', b.getAttribute('data-reach-filter') === pill);
  });
  if (typeof applyFilters === 'function') applyFilters();
};

// ===========================
// CLICKABLE TRENDS COUNTERS
// ===========================
function makeTrendsClickable() {
  var pairs = [
    ['trendRawValue',      '',         'all'],
    ['trendReachableValue','',          'actionable'],
    ['trendCriticalValue', 'CRITICAL',  'actionable'],
    ['trendHighValue',     'HIGH',      'actionable'],
    ['trendMediumValue',   'MEDIUM',    'actionable'],
    ['trendUnknownValue',  '',          'unknown'],
  ];
  pairs.forEach(function(p) {
    var el = document.getElementById(p[0]);
    if (!el) return;
    el.style.cursor = 'pointer';
    el.style.textDecoration = 'underline';
    el.onclick = function() {
      gotoFindings({severity: p[1] || '', pill: p[2] || 'all'});
    };
  });
}

// ===========================
// INIT
// ===========================
function initV2Renderers() {
  if (typeof dashboardData === 'undefined') return;
  var d = dashboardData;
  renderRiskPosture(d);
  renderOwaspTop10(d);
  renderLlmTop10(d);
  renderOwaspAgentic2026(d);
  renderAIAttackSurface(d);
  renderGRC(d);
  renderDLPGrids(d);
  updateFindingsPills(d);
  makeTrendsClickable();
}

window.renderOwaspTop10 = renderOwaspTop10;
window.renderLlmTop10 = renderLlmTop10;
window.renderOwaspAgentic2026 = renderOwaspAgentic2026;
window.renderRiskPosture = renderRiskPosture;
window.renderAIAttackSurface = renderAIAttackSurface;
window.renderGRC = renderGRC;
window.renderDLPGrids = renderDLPGrids;
window.updateFindingsPills = updateFindingsPills;
window.initV2Renderers = initV2Renderers;

if (document.readyState === 'complete' || document.readyState === 'interactive') {
  setTimeout(initV2Renderers, 50);
} else {
  document.addEventListener('DOMContentLoaded', function() { setTimeout(initV2Renderers, 50); });
}

})();
