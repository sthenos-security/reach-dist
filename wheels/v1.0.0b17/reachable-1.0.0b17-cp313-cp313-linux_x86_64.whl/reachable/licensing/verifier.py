# Copyright (c) 2026 Sthenos Security. All rights reserved.
"""
License verifier — runtime enforcement.

Called at scan start. Reads ~/.reachable/license.json, verifies Ed25519
signature, computes expiry, returns LicenseState.

Never reads the DB. Never writes anything. Pure verification.
"""

from __future__ import annotations

import base64
import json
import logging
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

from reachable.licensing._public_key import PUBLIC_KEY_PEM
from reachable.licensing.schema import LicenseFile, LicenseState

logger = logging.getLogger(__name__)

# Paths
LICENSE_DIR = Path.home() / ".reachable"
LICENSE_FILE = LICENSE_DIR / "license.json"
INSTALL_STAMP_FILE = LICENSE_DIR / ".license_install"

# Bundled trial license (shipped inside the wheel)
BUNDLED_TRIAL = Path(__file__).parent / "trial_license.json"

# Days remaining threshold for 'expiring_soon' status
EXPIRING_SOON_DAYS = 7


def _load_public_key():
    from cryptography.hazmat.primitives.serialization import load_pem_public_key

    return load_pem_public_key(PUBLIC_KEY_PEM)


def _verify_signature(lic: LicenseFile) -> bool:
    """Return True if the license signature is valid."""
    try:
        from cryptography.exceptions import InvalidSignature
        from cryptography.hazmat.primitives.serialization import load_pem_public_key  # noqa
    except ImportError as e:
        logger.debug(f"cryptography not available, skipping signature check: {e}")
        return True  # degrade gracefully — signature check skipped
    try:
        pub = _load_public_key()
        sig = base64.urlsafe_b64decode(lic.signature + "==")  # pad for safety
        pub.verify(sig, lic.canonical_payload())
        return True
    except InvalidSignature:
        return False
    except Exception as e:
        logger.debug(f"Signature verification error: {e}")
        return False


def _get_install_stamp() -> Optional[datetime]:
    """
    Return the install timestamp from ~/.reachable/.license_install.
    Written on first use. Deletion = clock reset (intentional for trial).
    """
    if not INSTALL_STAMP_FILE.exists():
        return None
    try:
        data = json.loads(INSTALL_STAMP_FILE.read_text())
        return datetime.fromisoformat(data["installed_at"])
    except Exception:
        return None


def _write_install_stamp() -> datetime:
    """Write install timestamp if not already present. Return the timestamp."""
    existing = _get_install_stamp()
    if existing:
        return existing
    now = datetime.now(timezone.utc)
    LICENSE_DIR.mkdir(parents=True, exist_ok=True)
    INSTALL_STAMP_FILE.write_text(json.dumps({"installed_at": now.isoformat()}))
    return now


def _compute_expiry(lic: LicenseFile) -> Optional[datetime]:
    """
    Compute absolute expiry datetime.
    - Annual: uses expires_at from signed file (absolute)
    - Trial:  installed_at + duration_days (relative, reinstall resets)
    """
    if lic.expires_at:
        # Absolute expiry — annual/enterprise
        return datetime.fromisoformat(lic.expires_at.replace("Z", "+00:00"))

    if lic.duration_days:
        # Relative expiry — trial
        installed = _get_install_stamp()
        if not installed:
            installed = _write_install_stamp()
        installed = installed.replace(tzinfo=timezone.utc) if installed.tzinfo is None else installed
        from datetime import timedelta

        return installed + timedelta(days=lic.duration_days)

    return None


def _ensure_license_installed():
    """
    On first run: if no license.json exists in ~/.reachable but the wheel
    ships a bundled trial, copy it in.
    """
    if not LICENSE_FILE.exists() and BUNDLED_TRIAL.exists():
        LICENSE_DIR.mkdir(parents=True, exist_ok=True)
        LICENSE_FILE.write_bytes(BUNDLED_TRIAL.read_bytes())
        logger.info("Trial license installed to ~/.reachable/license.json")


def check() -> LicenseState:
    """
    Main entry point. Call at scan start.

    Returns LicenseState. If valid=False, the caller should abort the scan
    and print state.error to the user.

    Bypass modes (dev only — never set these in production):
      REACHABLE_DEV=1          skip all verification
      license_type == 'dev'    unsigned dev license bundled in local wheel
    """
    import os

    if os.environ.get("REACHABLE_DEV") == "1":
        return LicenseState(
            valid=True,
            license_id="dev",
            license_type="dev",
            customer="local-dev",
            email=None,
            expires_at="2099-01-01T00:00:00Z",
            days_remaining=36500,
            status="active",
        )

    _ensure_license_installed()

    # 1. License file must exist
    if not LICENSE_FILE.exists():
        return LicenseState(
            valid=False,
            license_id="",
            license_type="",
            customer=None,
            email=None,
            expires_at="",
            days_remaining=0,
            status="invalid",
            error="No license found. Run: reachctl license install <license.json>",
        )

    # 2. Parse license file
    try:
        raw = json.loads(LICENSE_FILE.read_text())
        lic = LicenseFile.from_dict(raw)
    except Exception as e:
        return LicenseState(
            valid=False,
            license_id="",
            license_type="",
            customer=None,
            email=None,
            expires_at="",
            days_remaining=0,
            status="invalid",
            error=f"License file is corrupt or unreadable: {e}",
        )

    # 3. Verify signature (skip for dev licenses — unsigned by design)
    if lic.license_type == "dev" and lic.signature == "DEV_UNSIGNED":
        return LicenseState(
            valid=True,
            license_id=lic.license_id,
            license_type="dev",
            customer="local-dev",
            email=None,
            expires_at="2099-01-01T00:00:00Z",
            days_remaining=36500,
            status="active",
        )

    if not _verify_signature(lic):
        return LicenseState(
            valid=False,
            license_id=lic.license_id,
            license_type=lic.license_type,
            customer=lic.customer,
            email=lic.email,
            expires_at="",
            days_remaining=0,
            status="invalid",
            error="License signature is invalid — file may be tampered.",
        )

    # 4. Compute expiry
    expiry = _compute_expiry(lic)
    if expiry is None:
        return LicenseState(
            valid=False,
            license_id=lic.license_id,
            license_type=lic.license_type,
            customer=lic.customer,
            email=lic.email,
            expires_at="",
            days_remaining=0,
            status="invalid",
            error="License has no expiry date and no duration. Contact support.",
        )

    now = datetime.now(timezone.utc)
    expiry = expiry.replace(tzinfo=timezone.utc) if expiry.tzinfo is None else expiry
    delta = expiry - now
    days_remaining = max(0, delta.days)
    expires_at_str = expiry.strftime("%Y-%m-%dT%H:%M:%SZ")

    # 5. Check expired
    if now > expiry:
        days_over = abs(delta.days)
        return LicenseState(
            valid=False,
            license_id=lic.license_id,
            license_type=lic.license_type,
            customer=lic.customer,
            email=lic.email,
            expires_at=expires_at_str,
            days_remaining=0,
            status="expired",
            error=f"License expired {days_over} day{'s' if days_over != 1 else ''} ago. Contact support@sthenosec.com",
        )

    # 6. Determine status
    status = "expiring_soon" if days_remaining <= EXPIRING_SOON_DAYS else "active"

    return LicenseState(
        valid=True,
        license_id=lic.license_id,
        license_type=lic.license_type,
        customer=lic.customer,
        email=lic.email,
        expires_at=expires_at_str,
        days_remaining=days_remaining,
        status=status,
    )
