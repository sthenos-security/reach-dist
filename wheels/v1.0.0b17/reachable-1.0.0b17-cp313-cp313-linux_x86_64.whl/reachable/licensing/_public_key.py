# Copyright (c) 2026 Sthenos Security. All rights reserved.
"""
Ed25519 public key for license signature verification.

This key is intentionally public — it is used only to VERIFY signatures,
not to create them. The private key lives in GitHub Secrets only.

Key generated: 2026-02-25
Algorithm: Ed25519 (PKCS8 / SubjectPublicKeyInfo PEM)
"""

PUBLIC_KEY_PEM = b"""-----BEGIN PUBLIC KEY-----
MCowBQYDK2VwAyEAP2BUG3sCDcMy37QHiHkolebA62xXSUPlHn6ixAPQnEg=
-----END PUBLIC KEY-----
"""

# Increment if key is ever rotated — old licenses will fail verification
KEY_VERSION = 1
