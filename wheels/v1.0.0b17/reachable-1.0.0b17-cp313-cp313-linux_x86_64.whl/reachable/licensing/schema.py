# Copyright (c) 2026 Sthenos Security. All rights reserved.
"""
License schema — dataclasses for license file and runtime state.
"""

from __future__ import annotations

import json
from dataclasses import dataclass
from typing import Dict, Optional


@dataclass
class LicenseFile:
    """
    Represents the contents of ~/.reachable/license.json.
    All fields except 'signature' are covered by the Ed25519 signature.
    """

    license_id: str
    license_type: str  # 'trial' | 'annual' | 'enterprise'
    issued_at: str  # ISO8601
    duration_days: Optional[int]  # trial: 30, annual: None
    expires_at: Optional[str]  # annual: absolute ISO date, trial: None
    customer: Optional[str] = None  # None for trial
    email: Optional[str] = None  # None for trial
    features: Optional[Dict[str, bool]] = None  # None = all features enabled
    signature: str = ""  # base64url Ed25519 sig — not part of signed payload

    def canonical_payload(self) -> bytes:
        """Return the canonical JSON bytes that were signed (excludes 'signature')."""
        d = {
            "license_id": self.license_id,
            "license_type": self.license_type,
            "issued_at": self.issued_at,
            "duration_days": self.duration_days,
            "expires_at": self.expires_at,
            "customer": self.customer,
            "email": self.email,
            "features": self.features,
        }
        return json.dumps(d, sort_keys=True, separators=(",", ":")).encode()

    @classmethod
    def from_dict(cls, d: dict) -> "LicenseFile":
        return cls(
            license_id=d["license_id"],
            license_type=d["license_type"],
            issued_at=d["issued_at"],
            duration_days=d.get("duration_days"),
            expires_at=d.get("expires_at"),
            customer=d.get("customer"),
            email=d.get("email"),
            features=d.get("features"),
            signature=d.get("signature", ""),
        )

    def to_dict(self) -> dict:
        return {
            "license_id": self.license_id,
            "license_type": self.license_type,
            "issued_at": self.issued_at,
            "duration_days": self.duration_days,
            "expires_at": self.expires_at,
            "customer": self.customer,
            "email": self.email,
            "features": self.features,
            "signature": self.signature,
        }


@dataclass
class LicenseState:
    """
    Runtime license state — produced by verifier, stored in DB as display cache.
    This is what the CLI banner and dashboard widget read.
    """

    valid: bool
    license_id: str
    license_type: str  # 'trial' | 'annual' | 'enterprise'
    customer: Optional[str]
    email: Optional[str]
    expires_at: str  # computed absolute ISO date
    days_remaining: int
    status: str  # 'active' | 'expiring_soon' | 'expired'
    error: Optional[str] = None  # set if valid=False

    def is_feature_enabled(self, feature: str) -> bool:
        """
        v1: all features enabled (features array not enforced yet).
        Future: check features dict from LicenseFile.
        """
        return True

    @property
    def banner(self) -> str:
        """One-line string for CLI scan banner."""
        if not self.valid:
            return f"⛔ License: {self.error}"
        if self.status == "expiring_soon":
            t = self.license_type.capitalize()
            return f"⚠️  License: {t} · expires in {self.days_remaining} day{'s' if self.days_remaining != 1 else ''} — contact support@sthenosec.com"
        if self.license_type == "trial":
            return f"🔑 License: Trial · {self.days_remaining} day{'s' if self.days_remaining != 1 else ''} remaining"
        customer = f" · {self.customer}" if self.customer else ""
        return f"✅ License: Annual{customer} · expires {self.expires_at[:10]}"
