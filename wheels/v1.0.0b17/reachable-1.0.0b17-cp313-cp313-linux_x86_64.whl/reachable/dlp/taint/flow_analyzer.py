# REACHABLE DLP Security Module - Taint Flow Analyzer
# Copyright (c) 2026 Sthenos Security. All rights reserved.

"""
DLP Flow Analyzer - AST-based taint tracking for PII data flows.

Analyzes code to find:
1. PII Sources: Where sensitive data enters the system
2. PII Sinks: Where data could be exposed
3. Sanitizers: Transformations that reduce risk
4. Data Flows: Source → Sanitizer? → Sink paths

Integrates with REACHABLE's call graph for cross-function analysis.

Architecture:
    PII Sources → [Taint Propagation] → Sanitizers? → Sinks
                         ↑                    ↓
                    Call Graph          Risk Calculation

Usage:
    from reachable.dlp.taint import DLPFlowAnalyzer, analyze_dlp_flows

    analyzer = DLPFlowAnalyzer(call_graph=cg, reachable_functions=rf)
    results = analyzer.analyze_directory(Path("/path/to/repo"))

    for result in results:
        for flow in result.flows:
            logger.info(f"{flow.source.pii_type} → {flow.sink.sink_type.value}")
"""

import logging
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Tuple

from reachable.dlp.schema import PII_SENSITIVITY_TIER, TIER_BASE_RISK, DLPFinding, PIIEntityType
from reachable.dlp.schema import SinkType as SchemaSinkType
from reachable.dlp.taint.sanitizers import (
    PYTHON_SANITIZERS,
    TYPESCRIPT_SANITIZERS,
    Sanitizer,
    calculate_combined_effectiveness,
)
from reachable.dlp.taint.sinks import (
    PYTHON_DLP_SINKS,
    SINK_REGULATIONS,
    SINK_RISK_SCORES,
    TYPESCRIPT_DLP_SINKS,
    DLPSink,
    DLPSinkType,
)
from reachable.dlp.taint.sources import (
    PYTHON_PII_SOURCES,
    TYPESCRIPT_PII_SOURCES,
    PIISource,
    PIISourceProvenance,
    classify_source_provenance,
    get_source_confidence,
    infer_pii_type_from_source,
)
from reachable.engine.hop_registry import NodeKind, PathNode

logger = logging.getLogger(__name__)


# =============================================================================
# DATA CLASSES
# =============================================================================


@dataclass
class DLPDataFlow:
    """A complete data flow from PII source to sink."""

    flow_id: str
    source: PIISource
    sink: DLPSink
    sanitizers: List[Sanitizer] = field(default_factory=list)
    path: List[str] = field(default_factory=list)  # Variable flow path

    # Reachability
    is_reachable: bool = True
    reachability_confidence: float = 1.0

    # Risk calculation
    base_risk: float = 0.0
    sanitized_risk: float = 0.0
    final_risk: float = 0.0

    # Compliance
    regulations: List[str] = field(default_factory=list)

    # Metadata
    file_path: str = ""
    pii_type: str = ""
    sink_type: str = ""
    path_nodes: List[PathNode] = field(default_factory=list)  # T-AI10: typed PathNode objects

    def __post_init__(self):
        """Calculate risk scores after initialization."""
        self._calculate_risk()

    def _calculate_risk(self):
        """Calculate risk based on PII type, sink type, and sanitizers."""
        # Base risk from sink (0-100)
        sink_risk = SINK_RISK_SCORES.get(self.sink.sink_type, 50)

        # PII type multiplier - look up tier first, then risk
        pii_type_enum = self._get_pii_enum()
        tier = PII_SENSITIVITY_TIER.get(pii_type_enum, None)
        if tier:
            pii_risk = TIER_BASE_RISK.get(tier, 50)
        else:
            pii_risk = 50  # Default for unknown PII types

        # Combined base risk (average of sink and PII risks)
        self.base_risk = (sink_risk + pii_risk) / 2

        # Apply sanitizer reduction
        if self.sanitizers:
            effectiveness = calculate_combined_effectiveness(self.sanitizers)
            self.sanitized_risk = self.base_risk * (1 - effectiveness)
        else:
            self.sanitized_risk = self.base_risk

        # Apply reachability adjustment
        if not self.is_reachable:
            self.final_risk = self.sanitized_risk * 0.2  # 80% reduction for unreachable
        else:
            self.final_risk = self.sanitized_risk

        # Set regulations based on sink
        self.regulations = SINK_REGULATIONS.get(self.sink.sink_type, ["GDPR"])

    def _get_pii_enum(self) -> PIIEntityType:
        """Convert string pii_type to enum.

        b14 FIX: Changed default from EMAIL to PERSON_NAME (LOW tier).
        b15 FIX: Complete mapping — ip_address, cvv, iban, npi, password,
        api_key, secret, auth_token were missing and all defaulted to
        PERSON_NAME, causing 16+ false positives per scan.
        """
        pii_map = {
            "ssn": PIIEntityType.SSN,
            "credit_card": PIIEntityType.CREDIT_CARD,
            "cvv": PIIEntityType.CREDIT_CARD,
            "email": PIIEntityType.EMAIL,
            "phone": PIIEntityType.PHONE,
            "person_name": PIIEntityType.PERSON_NAME,
            "address": PIIEntityType.ADDRESS,
            "ip_address": PIIEntityType.ADDRESS,  # b15: was missing → defaulted to PERSON_NAME
            "dob": PIIEntityType.DATE_OF_BIRTH,
            "date_of_birth": PIIEntityType.DATE_OF_BIRTH,
            "passport": PIIEntityType.PASSPORT,
            "drivers_license": PIIEntityType.DRIVERS_LICENSE,
            "bank_account": PIIEntityType.BANK_ACCOUNT,
            "routing_number": PIIEntityType.BANK_ACCOUNT,
            "iban": PIIEntityType.BANK_ACCOUNT,
            "mrn": PIIEntityType.MRN,
            "npi": PIIEntityType.MRN,
            # Credential types — not really PII, but map to avoid PERSON_NAME default
            "password": PIIEntityType.EMAIL,  # b15: was missing → PERSON_NAME FPs
            "api_key": PIIEntityType.EMAIL,  # b15: was missing → PERSON_NAME FPs
            "secret": PIIEntityType.EMAIL,  # b15: was missing → PERSON_NAME FPs
            "auth_token": PIIEntityType.EMAIL,  # b15: was missing → PERSON_NAME FPs
            # b14: user_data now maps to PERSON_NAME (LOW tier) not EMAIL (SENSITIVE)
            "user_data": PIIEntityType.PERSON_NAME,
        }
        # b14: Default to PERSON_NAME (LOW tier) not EMAIL (SENSITIVE)
        return pii_map.get(self.pii_type or self.source.pii_type, PIIEntityType.PERSON_NAME)

    @property
    def severity(self) -> str:
        """Get severity based on final risk."""
        if self.final_risk >= 80:
            return "CRITICAL"
        elif self.final_risk >= 60:
            return "HIGH"
        elif self.final_risk >= 40:
            return "MEDIUM"
        elif self.final_risk >= 25:
            return "WARNING"  # P2.56: context propagation, indirect exposure
        else:
            return "LOW"

    @property
    def is_sanitized(self) -> bool:
        """Check if flow has any sanitizers."""
        return len(self.sanitizers) > 0

    def to_dlp_finding(self, file_path: str = None) -> DLPFinding:
        """Convert to DLPFinding for correlation engine.

        P2.54 FIX:
        - line_start from SOURCE (where PII originates), not sink
        - Populate source_location, sink_location, propagation_path, call_paths
        """
        # Map sink type
        sink_type_map = {
            DLPSinkType.LOG: SchemaSinkType.LOG,
            DLPSinkType.CONSOLE: SchemaSinkType.LOG,
            DLPSinkType.EXTERNAL_API: SchemaSinkType.EXTERNAL_API,
            DLPSinkType.LLM_API: SchemaSinkType.LLM_API,
            DLPSinkType.LLM_PROMPT: SchemaSinkType.LLM_API,
            DLPSinkType.LLM_EMBEDDING: SchemaSinkType.LLM_API,
            DLPSinkType.VECTOR_STORE: SchemaSinkType.VECTOR_STORE,
            DLPSinkType.ANALYTICS: SchemaSinkType.ANALYTICS,
            DLPSinkType.DATABASE: SchemaSinkType.DATABASE,
            DLPSinkType.FILE_WRITE: SchemaSinkType.FILE_WRITE,
            DLPSinkType.EMAIL: SchemaSinkType.EXTERNAL_API,
            DLPSinkType.CONTEXT_PROPAGATION: SchemaSinkType.CONTEXT,  # P2.56
        }

        schema_sink = sink_type_map.get(self.sink.sink_type, SchemaSinkType.LOG)

        # Use provided file_path or extract from self
        actual_file_path = file_path or self.file_path

        # P2.54: line_start = SOURCE line (where PII originates)
        try:
            source_line = int(self.source.location.split(":")[-1])
        except (ValueError, IndexError):
            source_line = 0

        # P2.54: Also extract sink line for sink_location
        try:
            int(self.sink.location.split(":")[-1])
        except (ValueError, IndexError):
            pass

        finding = DLPFinding.create_taint(
            file_path=actual_file_path,
            line_start=source_line,
            pii_type=self._get_pii_enum(),
            source=self.source.variable,
            sink=self.sink.function,
            sink_type=schema_sink,
            sanitizer_present=self.is_sanitized,
        )

        # P2.54: Populate path fields for dashboard display
        finding.source_location = self.source.location
        finding.sink_location = self.sink.location

        # Build propagation path from flow path + call_path
        prop_path = []
        if hasattr(self, "_call_path") and self._call_path:
            for step in self._call_path:
                prop_path.append(f"{step['function']}() [{step['type']}] {step['file']}:{step['line']}")
        else:
            # Fallback to simple path
            prop_path.append(f"{self.source.variable} @ {self.source.location}")
            prop_path.append(f"→ {self.sink.function}() @ {self.sink.location}")

        finding.propagation_path = prop_path
        finding.call_paths_v2 = [prop_path] if prop_path else []

        return finding


@dataclass
class DLPReachabilityResult:
    """Result of DLP flow analysis for a file."""

    file_path: str
    flows: List[DLPDataFlow] = field(default_factory=list)
    sources_found: int = 0
    sinks_found: int = 0
    sanitizers_found: int = 0

    # Flow statistics
    total_flows: int = 0
    sanitized_flows: int = 0
    unsanitized_flows: int = 0
    high_risk_flows: int = 0

    # By sink type
    flows_by_sink: Dict[str, int] = field(default_factory=dict)

    # By PII type
    flows_by_pii: Dict[str, int] = field(default_factory=dict)

    # v4.6.5: LLM-specific flows (for AI security integration)
    llm_flows: List[DLPDataFlow] = field(default_factory=list)

    def __post_init__(self):
        self._calculate_stats()

    def _calculate_stats(self):
        """Calculate statistics from flows."""
        self.total_flows = len(self.flows)
        self.sanitized_flows = sum(1 for f in self.flows if f.is_sanitized)
        self.unsanitized_flows = self.total_flows - self.sanitized_flows
        self.high_risk_flows = sum(1 for f in self.flows if f.final_risk >= 60)

        # Count by sink type
        for flow in self.flows:
            sink_type = flow.sink.sink_type.value
            self.flows_by_sink[sink_type] = self.flows_by_sink.get(sink_type, 0) + 1

        # Count by PII type
        for flow in self.flows:
            pii_type = flow.source.pii_type or "unknown"
            self.flows_by_pii[pii_type] = self.flows_by_pii.get(pii_type, 0) + 1


# =============================================================================
# T-AI10: PathNode builder for DLP flows
# =============================================================================

_DLP_SINK_KIND_MAP = re.compile(
    r"log|console|print|analytics|third_party|external_api|llm_api|llm_prompt|" r"network|cloud_storage|database|db",
    re.IGNORECASE,
)


def _build_dlp_path_nodes(source: "PIISource", sink: "DLPSink") -> List[PathNode]:
    """
    T-AI10/T-CG17: Build PathNode list for a DLPDataFlow.

    3-node chain: input → PII extraction → sink

      ENTRY        user_msg / request.body  (HTTP or DB input)
      SOURCE_PII   user.email / payload.ssn (PII field access / extraction)
      SINK_DATA    logger.info / segment.track (exfiltration destination)

    When the source IS the HTTP input (no distinct PII extraction step visible),
    we emit only 2 nodes (ENTRY → SINK_DATA) to avoid a meaningless duplicate.
    """
    import re as _re

    nodes: List[PathNode] = []

    source_label = getattr(source, "variable", "") or "pii_source"
    source_file = str(getattr(source, "location", "")).split(":")[0]
    source_line_str = str(getattr(source, "location", "")).split(":")[-1]
    try:
        source_line = int(source_line_str)
    except ValueError:
        source_line = None

    # Determine whether there is a distinct PII extraction step:
    # the context string usually contains something like
    #   "user.email", "payload['ssn']", "req.body.phone"
    context = getattr(source, "context", "") or ""
    getattr(source, "pii_type", "") or ""
    _PII_FIELD_RE = _re.compile(
        r"[\w]+\.(?:email|ssn|phone|address|credit_card|dob|passport|name"
        r"|first_name|last_name|zip|postal_code|account_number|iban|tax_id)",
        _re.I,
    )
    has_extraction = bool(_PII_FIELD_RE.search(context) or _PII_FIELD_RE.search(source_label))

    # Determine entry label — prefer variable name over raw function/location
    entry_label = source_label
    _HTTP_SOURCE_RE = _re.compile(
        r"request\.|req\.|body\[|query\[|params\.|form\[|get_json|fastapi",
        _re.I,
    )
    if _HTTP_SOURCE_RE.search(context):
        entry_label = source_label or "http_input"

    # Node 1: ENTRY — HTTP request / DB row / queue message where PII enters the app
    nodes.append(
        PathNode(
            label=entry_label,
            kind=NodeKind.ENTRY,
            file=source_file,
            line=source_line,
            package="",
        )
    )

    # Node 2: SOURCE_PII — the field access that extracts PII (if distinct from Node 1)
    if has_extraction:
        # Build a more descriptive label: "email (user.email)" or just "user.email"
        pii_label = source_label
        m = _PII_FIELD_RE.search(context) or _PII_FIELD_RE.search(source_label)
        if m:
            pii_label = m.group(0)
        nodes.append(
            PathNode(
                label=pii_label,
                kind=NodeKind.SOURCE_PII,
                file=source_file,
                line=source_line,
                package="",
            )
        )

    # Node 3: SINK_DATA — exfiltration destination
    sink_func = getattr(sink, "function", "") or "sink"
    sink_file = str(getattr(sink, "location", "")).split(":")[0]
    sink_line_str = str(getattr(sink, "location", "")).split(":")[-1]
    try:
        sink_line = int(sink_line_str)
    except ValueError:
        sink_line = None

    # LLM API sinks escalate to SINK_DANGER — PII reaching an LLM is more critical
    sink_type_val = getattr(sink, "sink_type", None)
    if sink_type_val is not None:
        stv = sink_type_val.value if hasattr(sink_type_val, "value") else str(sink_type_val)
        sink_kind = NodeKind.SINK_DANGER if "llm" in stv.lower() else NodeKind.SINK_DATA
    else:
        sink_kind = NodeKind.SINK_DATA

    nodes.append(
        PathNode(
            label=sink_func,
            kind=sink_kind,
            file=sink_file,
            line=sink_line,
            package="",
        )
    )

    return nodes


# =============================================================================
# FLOW ANALYZER
# =============================================================================


class DLPFlowAnalyzer:
    """
    AST-based taint flow analyzer for PII data.

    Integrates with REACHABLE's call graph for cross-function tracking.
    """

    def __init__(
        self,
        call_graph: Optional[Dict] = None,
        reachable_functions: Optional[Set[str]] = None,
        entrypoints: Optional[Set[str]] = None,
        verbose: bool = False,
    ):
        """
        Initialize analyzer.

        Args:
            call_graph: Application call graph from REACHABLE
            reachable_functions: Set of functions reachable from entrypoints
            entrypoints: Application entry points
            verbose: Enable verbose logging
        """
        self.call_graph = call_graph or {}
        self.reachable_functions = reachable_functions or set()
        self.entrypoints = entrypoints or set()
        self.verbose = verbose

        # Results
        self.all_flows: List[DLPDataFlow] = []
        self.flow_counter = 0

    def analyze_file(self, file_path: Path) -> DLPReachabilityResult:
        """Analyze a single file for PII data flows."""
        result = DLPReachabilityResult(file_path=str(file_path))

        try:
            content = file_path.read_text(encoding="utf-8", errors="ignore")
            lines = content.split("\n")
        except Exception as e:
            logger.debug(f"Could not read {file_path}: {e}")
            return result

        # Determine language
        ext = file_path.suffix.lower()
        is_typescript = ext in [".ts", ".js", ".tsx", ".jsx"]

        # Find sources, sinks, sanitizers
        sources = self._find_sources(lines, file_path, is_typescript)
        result.sources_found = len(sources)

        sinks = self._find_sinks(lines, file_path, is_typescript)
        result.sinks_found = len(sinks)

        sanitizers = self._find_sanitizers(lines, file_path, is_typescript)
        result.sanitizers_found = len(sanitizers)

        # Build flows
        flows = self._build_flows(sources, sinks, sanitizers, lines, file_path)
        result.flows = flows

        # Recalculate stats
        result._calculate_stats()

        return result

    def analyze_directory(
        self,
        dir_path: Path,
        extensions: Optional[List[str]] = None,
        exclude_patterns: Optional[List[str]] = None,
    ) -> List[DLPReachabilityResult]:
        """Analyze all files in a directory."""
        if extensions is None:
            extensions = [".py", ".js", ".ts", ".tsx", ".jsx", ".go", ".java"]

        if exclude_patterns is None:
            exclude_patterns = [
                ".venv",
                "venv",
                "node_modules",
                "__pycache__",
                ".git",
                "dist",
                "build",
                ".tox",
                ".pytest_cache",
                "vendor",
            ]

        results = []

        for ext in extensions:
            for file_path in dir_path.rglob(f"*{ext}"):
                # Skip excluded patterns
                path_str = str(file_path)
                if any(excl in path_str for excl in exclude_patterns):
                    continue

                if self.verbose:
                    logger.info(f"Analyzing: {file_path}")

                result = self.analyze_file(file_path)

                # Only include files with flows or detected sources/sinks
                if result.flows or result.sources_found > 0 or result.sinks_found > 0:
                    results.append(result)
                    self.all_flows.extend(result.flows)

        # T-AI8: cross-file BFS pass — follow PII sources through the call
        # graph into callee modules and detect sinks there.
        if self.call_graph and results:
            cross_flows = self._cross_file_bfs_pass(results, dir_path)
            self.all_flows.extend(cross_flows)

        return results

    def _cross_file_bfs_pass(
        self,
        results: List["DLPReachabilityResult"],
        dir_path: Path,
    ) -> List["DLPDataFlow"]:
        """
        T-AI8: Follow PII sources forward through the call graph into callee
        modules and detect sinks there.

        Algorithm
        ---------
        For every per-file result that has PII sources:
          1. Derive the dotted module path of the source file.
          2. Find call-graph functions that belong to that module.
          3. BFS forward through adjacency to find callee module functions.
          4. Resolve callee modules to file paths, scan for DLP sinks.
          5. Emit a synthetic DLPDataFlow (cross-file) per (source, sink) pair.

        Synthetic flows are tagged with ``reachability_confidence=0.7`` to
        distinguish them from same-file flows (confidence=1.0).
        """
        cross_flows: List[DLPDataFlow] = []
        seen_keys: set = set()  # (source_location, pii_type, sink_location)

        # Index existing flows to avoid duplicates
        for f in self.all_flows:
            key = (f.source.location, f.pii_type, f.sink.location)
            seen_keys.add(key)

        # Build result index: file_path -> DLPReachabilityResult
        {r.file_path: r for r in results}

        # Build file -> [sources] index for quick lookup
        sources_by_file: Dict[str, List[PIISource]] = {}
        for result in results:
            if result.sources_found:
                fp = result.file_path
                sources_by_file.setdefault(fp, [])
                # Re-extract sources (result doesn't store them directly)
                try:
                    path = Path(fp)
                    content = path.read_text(encoding="utf-8", errors="ignore")
                    lines = content.split("\n")
                    is_ts = path.suffix.lower() in (".ts", ".js", ".tsx", ".jsx")
                    sources_by_file[fp] = self._find_sources(lines, path, is_ts)
                except Exception:
                    pass

        # For deduplication we also need sinks from each file on demand
        _sink_cache: Dict[str, List[DLPSink]] = {}

        def _get_sinks(fp_str: str) -> List[DLPSink]:
            if fp_str not in _sink_cache:
                try:
                    path = Path(fp_str)
                    content = path.read_text(encoding="utf-8", errors="ignore")
                    lines = content.split("\n")
                    is_ts = path.suffix.lower() in (".ts", ".js", ".tsx", ".jsx")
                    _sink_cache[fp_str] = self._find_sinks(lines, path, is_ts)
                except Exception:
                    _sink_cache[fp_str] = []
            return _sink_cache[fp_str]

        GENERIC_PII_TYPES = {
            "user_data",
            "unknown",
            "",
            "password",
            "api_key",
            "secret",
            "auth_token",
            "ip_address",
        }

        for source_file, sources in sources_by_file.items():
            if not sources:
                continue

            # Derive module prefix for this file
            rel = source_file
            try:
                rel = str(Path(source_file).resolve().relative_to(dir_path.resolve()))
            except (ValueError, AttributeError):
                pass
            module_prefix = (
                rel.replace("\\", "/")
                .lstrip("/")
                .replace("/", ".")
                .removesuffix(".py")
                .removesuffix(".ts")
                .removesuffix(".js")
                .removesuffix(".jsx")
                .removesuffix(".tsx")
            )

            # Find call-graph functions that belong to this module
            module_funcs = [fn for fn in self.call_graph if fn == module_prefix or fn.startswith(module_prefix + ".")]
            if not module_funcs:
                stem = module_prefix.rsplit(".", 1)[-1]
                module_funcs = (
                    [fn for fn in self.call_graph if fn.endswith("." + stem) or fn.split(".")[-2] == stem]
                    if stem
                    else []
                )

            if not module_funcs:
                continue

            # BFS forward: find all callee functions reachable within 5 hops
            visited: set = set(module_funcs)
            queue = list(module_funcs)
            callee_funcs: List[str] = []
            depth_map: Dict[str, int] = {fn: 0 for fn in module_funcs}
            MAX_DEPTH = 5

            while queue:
                current = queue.pop(0)
                d = depth_map.get(current, 0)
                if d >= MAX_DEPTH:
                    continue
                for callee in self.call_graph.get(current, []):
                    if callee not in visited:
                        visited.add(callee)
                        depth_map[callee] = d + 1
                        callee_funcs.append(callee)
                        queue.append(callee)

            # Resolve callee modules to file paths and scan for sinks
            callee_modules: Dict[str, str] = {}  # module_prefix -> file_path
            for callee in callee_funcs:
                parts = callee.split(".")
                if len(parts) < 2:
                    continue
                mod = ".".join(parts[:-1])
                if mod in callee_modules:
                    continue
                # Try to locate the file
                mod_path = mod.replace(".", "/") + ".py"
                candidate = dir_path / mod_path
                if candidate.exists():
                    callee_modules[mod] = str(candidate)
                else:
                    # Try relative to dir_path recursively
                    stem = parts[-2]  # module name
                    matches = list(dir_path.rglob(f"{stem}.py"))
                    if matches:
                        callee_modules[mod] = str(matches[0])

            if not callee_modules:
                continue

            # For each PII source, look for sinks in callee files
            for source in sources:
                if source.pii_type in GENERIC_PII_TYPES:
                    continue

                for mod, callee_file in callee_modules.items():
                    sinks = _get_sinks(callee_file)
                    for sink in sinks:
                        key = (source.location, source.pii_type, sink.location)
                        if key in seen_keys:
                            continue
                        seen_keys.add(key)

                        self.flow_counter += 1
                        flow = DLPDataFlow(
                            flow_id=f"dlp-xflow-{self.flow_counter:04d}",
                            source=source,
                            sink=sink,
                            sanitizers=[],
                            path=[source.variable, f"\u2192 {mod}.{sink.function}"],
                            file_path=callee_file,
                            pii_type=source.pii_type,
                            sink_type=sink.sink_type.value,
                            is_reachable=True,
                            reachability_confidence=0.7,
                        )
                        cross_flows.append(flow)
                        logger.debug(
                            f"T-AI8 cross-file flow: {source.pii_type} "
                            f"{source_file} \u2192 {callee_file} "
                            f"sink={sink.sink_type.value}"
                        )

        return cross_flows

    def _find_sources(
        self,
        lines: List[str],
        file_path: Path,
        is_typescript: bool = False,
    ) -> List[PIISource]:
        """Find PII sources in code."""
        sources = []
        patterns = TYPESCRIPT_PII_SOURCES if is_typescript else PYTHON_PII_SOURCES

        for line_num, line in enumerate(lines, 1):
            for source_type, pattern_list in patterns.items():
                for pattern in pattern_list:
                    match = re.search(pattern, line, re.IGNORECASE)
                    if match:
                        # Extract variable name
                        var_match = re.search(r"(\w+)\s*=", line)
                        var_name = var_match.group(1) if var_match else "data"

                        # Infer PII type from source code
                        pii_type = infer_pii_type_from_source(line)

                        # v5.1.6: Classify provenance — skip static metadata
                        provenance = classify_source_provenance(
                            source_code=line,
                            file_path=str(file_path),
                            source_type=source_type,
                            variable_name=var_name,
                        )
                        if provenance == PIISourceProvenance.STATIC_METADATA:
                            logger.debug(
                                "DLP source skipped (static metadata): %s=%s in %s:%d",
                                var_name,
                                pii_type,
                                file_path,
                                line_num,
                            )
                            break  # Skip this source

                        sources.append(
                            PIISource(
                                source_type=source_type,
                                location=f"{file_path}:{line_num}",
                                variable=var_name,
                                pii_type=pii_type,
                                confidence=get_source_confidence(source_type),
                                context=line.strip()[:100],
                            )
                        )
                        break  # One match per line per source type

        return sources

    def _find_sinks(
        self,
        lines: List[str],
        file_path: Path,
        is_typescript: bool = False,
    ) -> List[DLPSink]:
        """Find DLP sinks in code."""
        sinks = []
        patterns = TYPESCRIPT_DLP_SINKS if is_typescript else PYTHON_DLP_SINKS

        for line_num, line in enumerate(lines, 1):
            for sink_type, pattern_list in patterns.items():
                for pattern in pattern_list:
                    match = re.search(pattern, line, re.IGNORECASE)
                    if match:
                        # Extract function name
                        func_match = re.search(r"\.(\w+)\s*\(", line)
                        func_name = func_match.group(1) if func_match else "unknown"

                        sinks.append(
                            DLPSink(
                                sink_type=sink_type,
                                location=f"{file_path}:{line_num}",
                                function=func_name,
                                confidence=1.0,
                                context=line.strip()[:100],
                            )
                        )
                        break  # One match per line per sink type

        return sinks

    def _find_sanitizers(
        self,
        lines: List[str],
        file_path: Path,
        is_typescript: bool = False,
    ) -> List[Sanitizer]:
        """Find sanitizers in code."""
        sanitizers = []
        patterns = TYPESCRIPT_SANITIZERS if is_typescript else PYTHON_SANITIZERS

        for line_num, line in enumerate(lines, 1):
            for sanitizer_type, pattern_list in patterns.items():
                for pattern, effectiveness in pattern_list:
                    match = re.search(pattern, line, re.IGNORECASE)
                    if match:
                        # Extract function name
                        func_match = re.search(r"(\w+)\s*\(", line)
                        func_name = func_match.group(1) if func_match else "sanitizer"

                        sanitizers.append(
                            Sanitizer(
                                sanitizer_type=sanitizer_type,
                                location=f"{file_path}:{line_num}",
                                function=func_name,
                                effectiveness=effectiveness,
                                confidence=1.0,
                                context=line.strip()[:100],
                            )
                        )
                        break

        return sanitizers

    @staticmethod
    def _find_function_calls_in_range(
        lines: List[str],
        start_line: int,
        end_line: int,
    ) -> List[Tuple[int, str]]:
        """P2.54: Find function calls within a line range.

        Returns list of (line_num, func_name) for calls like:
            print_table(res), do_something(data)
        Excludes keywords: if, for, while, return, class, def, except, with, elif, assert
        """
        KEYWORDS = {
            "if",
            "for",
            "while",
            "return",
            "class",
            "def",
            "except",
            "with",
            "elif",
            "assert",
            "import",
            "from",
            "raise",
            "yield",
            "async",
            "await",
            "lambda",
            "not",
            "and",
            "or",
            "in",
            "is",
            "try",
            "finally",
            "pass",
            "break",
            "continue",
            "del",
            "global",
            # Built-in types/functions that aren't interesting as call targets
            "dict",
            "list",
            "set",
            "tuple",
            "int",
            "str",
            "float",
            "bool",
            "len",
            "range",
            "enumerate",
            "isinstance",
            "type",
            "super",
            "append",
            "extend",
            "get",
            "setattr",
            "getattr",
            "hasattr",
        }
        calls = []
        for i in range(start_line - 1, min(end_line, len(lines))):
            line = lines[i].strip()
            # Find all function calls on the line
            for match in re.finditer(r"\b(\w+)\s*\(", line):
                func_name = match.group(1)
                if func_name.lower() not in KEYWORDS and not func_name.startswith("_"):
                    calls.append((i + 1, func_name))  # 1-indexed
        return calls

    @staticmethod
    def _parse_function_boundaries(lines: List[str]) -> List[Tuple[int, int, str]]:
        """P2.54: Parse Python function boundaries from source lines.

        Returns list of (start_line, end_line, func_name) tuples (1-indexed).
        End line is inclusive. Handles nested functions by tracking indentation.
        """
        functions = []
        func_stack = []  # (start_line, indent_level, func_name)

        for i, line in enumerate(lines):
            stripped = line.lstrip()
            if stripped.startswith("def ") or stripped.startswith("async def "):
                indent = len(line) - len(stripped)
                # Extract function name
                if stripped.startswith("async def "):
                    name = stripped[10:].split("(")[0].strip()
                else:
                    name = stripped[4:].split("(")[0].strip()

                # Close any functions at same or deeper indent
                while func_stack and func_stack[-1][1] >= indent:
                    start, _, fname = func_stack.pop()
                    functions.append((start, i, fname))  # end at line before this def

                func_stack.append((i + 1, indent, name))  # 1-indexed

        # Close remaining open functions
        total_lines = len(lines)
        while func_stack:
            start, _, fname = func_stack.pop()
            functions.append((start, total_lines, fname))

        return functions

    @staticmethod
    def _get_function_at_line(functions: List[Tuple[int, int, str]], line_num: int) -> Optional[str]:
        """P2.54: Get function name containing a given line number."""
        best_match = None
        best_size = float("inf")
        for start, end, name in functions:
            if start <= line_num <= end:
                size = end - start
                if size < best_size:  # Prefer innermost (smallest) function
                    best_match = name
                    best_size = size
        return best_match

    def _build_flows(
        self,
        sources: List[PIISource],
        sinks: List[DLPSink],
        sanitizers: List[Sanitizer],
        lines: List[str],
        file_path: Path,
    ) -> List[DLPDataFlow]:
        """Build data flows connecting sources to sinks.

        P2.54 FIX: Function-scoped flow analysis.
        Sources and sinks must be in the SAME function to form a flow.
        Previously used line proximity only (source < sink < source+200),
        which connected PII in print_iam_results to print() in print_object_storage_results.
        """
        flows = []

        # b14 FIX: PII types that require SPECIFIC detection to create findings
        # b15 FIX: Added credential types (password, api_key, secret, auth_token)
        # because these are secrets, not PII — they belong to the secrets scanner.
        # Also added ip_address because it's infrastructure metadata, not PII.
        GENERIC_PII_TYPES = {
            "user_data",
            "unknown",
            "",
            # b15: Credentials are NOT PII — handled by secrets scanner
            "password",
            "api_key",
            "secret",
            "auth_token",
            # b15: IP address is infrastructure, not personal data
            "ip_address",
        }

        # P2.54: Parse function boundaries for scope-aware matching
        functions = self._parse_function_boundaries(lines)

        # P2.54: Build a map of sink functions to their sinks for call-through analysis
        func_sinks = {}  # func_name -> [sink]
        for sink in sinks:
            sink_line = int(sink.location.split(":")[1])
            sink_func = self._get_function_at_line(functions, sink_line)
            if sink_func:
                func_sinks.setdefault(sink_func, []).append(sink)

        for source in sources:
            if source.pii_type in GENERIC_PII_TYPES:
                continue

            source_line = int(source.location.split(":")[1])
            source_func = self._get_function_at_line(functions, source_line)

            for sink in sinks:
                sink_line = int(sink.location.split(":")[1])
                sink_func = self._get_function_at_line(functions, sink_line)

                # P2.54: Source and sink must be in the same function
                if source_func != sink_func:
                    continue

                # Source must come before sink.
                # P2.56: Exception — context propagation sinks (c.set, req.user)
                # can be on the SAME line as the source because the pattern is:
                #   c.set('accessUser', { email: payload.email })
                # where the PII keyword and the context-set call are one statement.
                if sink.sink_type == DLPSinkType.CONTEXT_PROPAGATION:
                    if source_line > sink_line:  # allow same line
                        continue
                elif source_line >= sink_line:
                    continue

                # Find sanitizers between source and sink in same function
                applicable_sanitizers = []
                for san in sanitizers:
                    san_line = int(san.location.split(":")[1])
                    san_func = self._get_function_at_line(functions, san_line)
                    if san_func == source_func and source_line < san_line < sink_line:
                        applicable_sanitizers.append(san)

                # Check reachability via call graph
                self._check_reachability(file_path, source_line, sink_line)

                # P2.54: Build call path trace
                call_path = []
                if source_func:
                    call_path.append(
                        {
                            "function": source_func,
                            "file": str(file_path),
                            "line": source_line,
                            "type": "source",
                            "detail": f"{source.pii_type}: {source.context[:60]}",
                        }
                    )
                call_path.append(
                    {
                        "function": sink.function,
                        "file": str(file_path),
                        "line": sink_line,
                        "type": "sink",
                        "detail": f"{sink.sink_type.value}: {sink.context[:60]}",
                    }
                )

                # Create flow
                self.flow_counter += 1
                flow = DLPDataFlow(
                    flow_id=f"dlp-flow-{self.flow_counter:04d}",
                    source=source,
                    sink=sink,
                    sanitizers=applicable_sanitizers,
                    path=[source.variable, f"→ {sink.function}"],
                    path_nodes=_build_dlp_path_nodes(source, sink),
                    file_path=str(file_path),
                    pii_type=source.pii_type,
                    sink_type=sink.sink_type.value,
                )
                # P2.54: Attach call path for dashboard display
                flow._call_path = call_path

                flows.append(flow)

        # =====================================================================
        # P2.54: CROSS-FUNCTION FLOWS
        # Detect: source in func A → call to func B → sink in func B
        # Example: user.email in print_iam_results → print_table(res) → print()
        # =====================================================================

        # Build function name → boundaries lookup
        func_by_name = {}  # func_name -> (start, end)
        for start, end, fname in functions:
            func_by_name[fname] = (start, end)

        for source in sources:
            if source.pii_type in GENERIC_PII_TYPES:
                continue

            source_line = int(source.location.split(":")[1])
            source_func = self._get_function_at_line(functions, source_line)
            if not source_func or source_func not in func_by_name:
                continue

            sfunc_start, sfunc_end = func_by_name[source_func]

            # Find function calls AFTER the source, within the same function
            calls_after = self._find_function_calls_in_range(lines, source_line + 1, sfunc_end)

            for call_line, called_func_name in calls_after:
                # Does the called function have sinks?
                if called_func_name not in func_sinks:
                    continue

                # Create a cross-function flow for each sink in the called function
                for target_sink in func_sinks[called_func_name]:
                    target_sink_line = int(target_sink.location.split(":")[1])

                    # Avoid duplicate: skip if we already have a same-function flow
                    # with this exact source+sink
                    is_dup = any(f.source is source and f.sink is target_sink for f in flows)
                    if is_dup:
                        continue

                    # Build cross-function call path
                    call_path = [
                        {
                            "function": source_func,
                            "file": str(file_path),
                            "line": source_line,
                            "type": "source",
                            "detail": f"{source.pii_type}: {source.context[:60]}",
                        },
                        {
                            "function": called_func_name,
                            "file": str(file_path),
                            "line": call_line,
                            "type": "call",
                            "detail": f"data flows via {called_func_name}()",
                        },
                        {
                            "function": target_sink.function,
                            "file": str(file_path),
                            "line": target_sink_line,
                            "type": "sink",
                            "detail": f"{target_sink.sink_type.value}: {target_sink.context[:60]}",
                        },
                    ]

                    self.flow_counter += 1
                    flow = DLPDataFlow(
                        flow_id=f"dlp-flow-{self.flow_counter:04d}",
                        source=source,
                        sink=target_sink,
                        sanitizers=[],
                        path=[
                            source.variable,
                            f"→ {called_func_name}()",
                            f"→ {target_sink.function}",
                        ],
                        path_nodes=_build_dlp_path_nodes(source, target_sink),
                        file_path=str(file_path),
                        pii_type=source.pii_type,
                        sink_type=target_sink.sink_type.value,
                    )
                    flow._call_path = call_path
                    flows.append(flow)

        # P2.54: Deduplicate flows by (source_location, pii_type, schema_sink_type)
        # print() matches both LOG and CONSOLE patterns, both map to SchemaSinkType.LOG
        # → creates duplicate findings with same finding_id. Dedupe here.
        seen = set()
        deduped = []
        for flow in flows:
            # Key: source location + pii type + sink type category
            # Collapse LOG/CONSOLE since both map to SchemaSinkType.LOG
            sink_category = flow.sink.sink_type.value
            if sink_category == "console":
                sink_category = "log"
            key = (flow.source.location, flow.pii_type, sink_category)
            if key not in seen:
                seen.add(key)
                deduped.append(flow)

        return deduped

    def _check_reachability(
        self,
        file_path: Path,
        source_line: int,
        sink_line: int,
    ) -> bool:
        """
        Check if a flow is reachable using the call graph.

        If no call graph is provided, assume reachable (conservative).
        """
        if not self.reachable_functions:
            return True  # No call graph, assume reachable

        # Check if any function in the file is reachable
        file_str = str(file_path)

        for func in self.reachable_functions:
            if file_str in func or func in file_str:
                return True

        # Additional: check if file is under test/ or fixture/
        if "/test" in file_str.lower() or "/fixture" in file_str.lower():
            return False  # Test code typically not reachable in production

        return True  # Default to reachable

    def get_findings(self) -> List[DLPFinding]:
        """Convert all flows to DLPFinding objects for correlation."""
        return [flow.to_dlp_finding() for flow in self.all_flows]

    def get_summary(self) -> Dict[str, Any]:
        """Get summary statistics of all analyzed flows."""
        return {
            "total_flows": len(self.all_flows),
            "sanitized_flows": sum(1 for f in self.all_flows if f.is_sanitized),
            "unsanitized_flows": sum(1 for f in self.all_flows if not f.is_sanitized),
            "high_risk_flows": sum(1 for f in self.all_flows if f.final_risk >= 60),
            "critical_flows": sum(1 for f in self.all_flows if f.final_risk >= 80),
            "reachable_flows": sum(1 for f in self.all_flows if f.is_reachable),
            "by_sink_type": self._count_by_attr("sink_type"),
            "by_pii_type": self._count_by_attr("pii_type"),
        }

    def _count_by_attr(self, attr: str) -> Dict[str, int]:
        """Count flows by attribute."""
        counts = {}
        for flow in self.all_flows:
            value = getattr(flow, attr, "unknown")
            counts[value] = counts.get(value, 0) + 1
        return counts


# =============================================================================
# HIGH-LEVEL INTEGRATION FUNCTIONS
# =============================================================================


def analyze_dlp_flows(
    target_path: Path,
    call_graph: Optional[Dict] = None,
    reachable_functions: Optional[Set[str]] = None,
    verbose: bool = False,
) -> Dict[str, Any]:
    """
    High-level function to analyze DLP flows in a codebase.

    Returns dict suitable for integration with correlation engine.
    """
    analyzer = DLPFlowAnalyzer(
        call_graph=call_graph,
        reachable_functions=reachable_functions,
        verbose=verbose,
    )

    if target_path.is_file():
        results = [analyzer.analyze_file(target_path)]
    else:
        results = analyzer.analyze_directory(target_path)

    return {
        "files_analyzed": len(results),
        "results": results,
        "flows": analyzer.all_flows,
        "findings": analyzer.get_findings(),
        "summary": analyzer.get_summary(),
        "analyzer": analyzer,
    }


# =============================================================================
# CLI ENTRY POINT
# =============================================================================

if __name__ == "__main__":
    import sys

    if len(sys.argv) < 2:
        logger.info("Usage: python flow_analyzer.py <path>")
        sys.exit(1)

    target = Path(sys.argv[1])
    results = analyze_dlp_flows(target, verbose=True)

    logger.info(f"\n DLP Flow Analysis: {target}")
    logger.info("=" * 70)
    logger.info(f" Files analyzed: {results['files_analyzed']}")

    summary = results["summary"]
    logger.info("\n Flow Summary:")
    logger.info(f" Total flows: {summary['total_flows']}")
    logger.info(f" Sanitized: {summary['sanitized_flows']}")
    logger.info(f" Unsanitized: {summary['unsanitized_flows']}")
    logger.info(f" High risk (≥60): {summary['high_risk_flows']}")
    logger.info(f" Critical (≥80): {summary['critical_flows']}")

    if summary.get("by_sink_type"):
        logger.info("\n By Sink Type:")
        for sink, count in sorted(summary["by_sink_type"].items(), key=lambda x: -x[1]):
            logger.info(f" {sink}: {count}")

    if summary.get("by_pii_type"):
        logger.info("\n By PII Type:")
        for pii, count in sorted(summary["by_pii_type"].items(), key=lambda x: -x[1]):
            logger.info(f" {pii}: {count}")

    # Show critical flows
    critical = [f for f in results["flows"] if f.final_risk >= 60 and not f.is_sanitized]
    if critical:
        logger.info(f"\n High-Risk Unsanitized Flows ({len(critical)}):")
        for flow in critical[:10]:
            logger.info(f" [{flow.severity}] {flow.pii_type} → {flow.sink_type}")
            logger.info(f" {flow.file_path}")
            logger.info(f" Risk: {flow.final_risk:.1f}")
