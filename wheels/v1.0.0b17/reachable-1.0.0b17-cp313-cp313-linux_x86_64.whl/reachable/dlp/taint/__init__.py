# REACHABLE DLP Security Module - Taint Analysis
# Copyright (c) 2026 Sthenos Security. All rights reserved.

"""
DLP Taint Analysis - Track PII data flows from sources to sinks.

Follows the same architecture as AI Reachability Analyzer:
    PII Sources → [Taint Tracking] → Sanitizers? → Dangerous Sinks
                                          ↓
                                    Risk Adjustment

This module provides:
- PII-aware taint sources (user data, database queries, form inputs)
- DLP-specific sinks (logs, external APIs, LLM APIs, analytics)
- Sanitizer detection (Presidio, scrubadub, masking functions)
- AST-based flow tracking with call graph integration
"""

from reachable.dlp.taint.flow_analyzer import (
    DLPDataFlow,
    DLPFlowAnalyzer,
    DLPReachabilityResult,
    analyze_dlp_flows,
)
from reachable.dlp.taint.sanitizers import PYTHON_SANITIZERS, TYPESCRIPT_SANITIZERS, Sanitizer, SanitizerType
from reachable.dlp.taint.sinks import (
    PYTHON_DLP_SINKS,
    SINK_REGULATIONS,
    SINK_RISK_SCORES,
    TYPESCRIPT_DLP_SINKS,
    DLPSink,
    DLPSinkType,
)
from reachable.dlp.taint.sources import PYTHON_PII_SOURCES, TYPESCRIPT_PII_SOURCES, PIISource, PIISourceType

__all__ = [
    # Sources
    "PIISourceType",
    "PIISource",
    "PYTHON_PII_SOURCES",
    "TYPESCRIPT_PII_SOURCES",
    # Sinks
    "DLPSinkType",
    "DLPSink",
    "PYTHON_DLP_SINKS",
    "TYPESCRIPT_DLP_SINKS",
    "SINK_REGULATIONS",
    "SINK_RISK_SCORES",
    # Sanitizers
    "SanitizerType",
    "Sanitizer",
    "PYTHON_SANITIZERS",
    "TYPESCRIPT_SANITIZERS",
    # Flow Analysis
    "DLPFlowAnalyzer",
    "DLPDataFlow",
    "DLPReachabilityResult",
    "analyze_dlp_flows",
]
