# REACHABLE DLP Security Module - PII Taint Sources
# Copyright (c) 2026 Sthenos Security. All rights reserved.

"""
PII Taint Sources - Origins of sensitive data in code.

Categories:
- User Input: Forms, HTTP requests, CLI input
- Database: Query results containing user data
- Session/Auth: User sessions, authentication tokens
- External: API responses, file reads
- Internal: Variables/attributes containing PII

Usage:
    from reachable.dlp.taint.sources import PIISourceType, PYTHON_PII_SOURCES

    # Find PII sources in code
    for source_type, patterns in PYTHON_PII_SOURCES.items():
        for pattern in patterns:
            if re.search(pattern, line):
                print(f"Found {source_type.value} source")
"""

import re
from dataclasses import dataclass
from enum import Enum
from typing import Dict, List


class PIISourceType(Enum):
    """Types of PII data sources."""

    # HTTP/Web sources
    HTTP_FORM = "http_form"  # request.form, form data
    HTTP_JSON = "http_json"  # request.json, JSON body
    HTTP_QUERY = "http_query"  # request.args, query params
    HTTP_HEADER = "http_header"  # request.headers (auth, cookies)

    # User session
    USER_SESSION = "user_session"  # session.user, current_user
    USER_AUTH = "user_auth"  # authentication tokens

    # Database
    DB_QUERY = "db_query"  # cursor.fetchall(), ORM queries
    DB_MODEL = "db_model"  # User.query, Model.get()

    # File/External
    FILE_READ = "file_read"  # open().read(), CSV/JSON files
    API_RESPONSE = "api_response"  # requests.get().json()

    # PII-specific attributes
    PII_ATTRIBUTE = "pii_attribute"  # .ssn, .credit_card, .email
    PII_DICT_KEY = "pii_dict_key"  # data['ssn'], user['email']
    PII_VARIABLE = "pii_variable"  # ssn = ..., credit_card = ...

    # Environment
    ENVIRONMENT = "environment"  # os.environ, env vars

    # Message queues
    MESSAGE_QUEUE = "message_queue"  # kafka, rabbitmq messages


# ═══════════════════════════════════════════════════════════════════════════════
# v5.1.6: Source provenance classification
# ═══════════════════════════════════════════════════════════════════════════════


class PIISourceProvenance(Enum):
    """Provenance of PII data — runtime user input vs static metadata."""

    RUNTIME = "runtime"  # User-controlled: HTTP, DB, CLI, env
    STATIC_METADATA = "static"  # Package/connection/build metadata
    UNKNOWN = "unknown"  # Cannot determine


# Source types that are ALWAYS runtime user input
_RUNTIME_SOURCE_TYPES = {
    PIISourceType.HTTP_FORM,
    PIISourceType.HTTP_JSON,
    PIISourceType.HTTP_QUERY,
    PIISourceType.HTTP_HEADER,
    PIISourceType.USER_SESSION,
    PIISourceType.USER_AUTH,
    PIISourceType.DB_QUERY,
    PIISourceType.DB_MODEL,
    PIISourceType.API_RESPONSE,
    PIISourceType.ENVIRONMENT,
    PIISourceType.MESSAGE_QUEUE,
}

# Files that contain package/build metadata — not user PII
_METADATA_FILES = re.compile(
    r"(?i)(?:"
    r"setup\.py|setup\.cfg|pyproject\.toml|Pipfile|MANIFEST\.in"
    r"|package\.json|package-lock\.json|yarn\.lock|bower\.json"
    r"|composer\.json|Cargo\.toml|Gemfile|Gemspec"
    r"|pom\.xml|build\.gradle|go\.mod|go\.sum"
    r"|\.gemspec$|\.podspec$|\.nuspec$"
    r")$"
)

# v5.1.7: Security scanner source files — contain PII keywords as DETECTION
# PATTERNS, not actual PII data.  e.g. env.py defines 'ssn', 'credit_card'
# regex patterns; flow_analyzer.py references PII types for taint analysis.
_SCANNER_SOURCE_PATHS = re.compile(
    r"(?i)(?:"
    r"collectors/secrets/"
    r"|collectors/malware/"
    r"|dlp/taint/"
    r"|dlp/discovery/"
    r"|dlp/rules/"
    r"|database/normalizers/"
    r"|standards/"
    r")"
)

# Variable/attribute names that indicate metadata context, not user PII
_METADATA_VARIABLE_NAMES = re.compile(
    r"(?i)^(?:"
    r"author|maintainer|contributor|committer|creator"
    r"|author_name|author_email|maintainer_email|contributor_email"
    r"|pkg_author|pkg_email|package_author"
    r"|__author__|__email__|__maintainer__"
    r"|git_author|commit_author|repo_owner"
    r"|contact_email|admin_email|support_email"
    r"|connection_(?:string|url|uri|host|addr)"
    r"|db_(?:host|url|uri|addr|connection)"
    r"|server_(?:host|addr|address|url)"
    r"|neo4j_(?:uri|url|address)|mongo_(?:uri|url)|redis_(?:url|host)"
    r")$"
)

# String literal assignment: var = "..." or var = '...'
_STRING_LITERAL_ASSIGN = re.compile(r"""(\w+)\s*=\s*(?:f?["'][^"']*["'])""")

# Dict/config literal with metadata keys
_METADATA_DICT_KEYS = re.compile(
    r"""(?i)["'](?:author|maintainer|email|contributor|homepage|"""
    r"""repository|url|bugs|license|description|version)["']\s*:"""
)


def classify_source_provenance(
    source_code: str,
    file_path: str,
    source_type: PIISourceType,
    variable_name: str = "",
) -> PIISourceProvenance:
    """v5.1.6: Classify whether a PII source is runtime user input or static metadata.

    Runtime (HIGH RISK): HTTP request body, form fields, CLI input, DB records,
        cookies, env vars, message queues, API responses.
    Static metadata (LOW RISK): setup.py author, package.json author, git commit
        author, config defaults, connection metadata, hardcoded string literals
        in metadata files.

    Returns:
        PIISourceProvenance.RUNTIME — treat as sensitive PII
        PIISourceProvenance.STATIC_METADATA — suppress or downgrade
        PIISourceProvenance.UNKNOWN — keep (conservative)
    """
    # 1. Source type determines provenance for HTTP/DB/session/env/queue sources
    if source_type in _RUNTIME_SOURCE_TYPES:
        return PIISourceProvenance.RUNTIME

    # 2a. v5.1.7: Scanner source files — PII keywords are detection patterns
    if _SCANNER_SOURCE_PATHS.search(file_path):
        return PIISourceProvenance.STATIC_METADATA

    # 2b. Metadata file path → static metadata
    file_basename = file_path.rsplit("/", 1)[-1] if "/" in file_path else file_path
    if _METADATA_FILES.search(file_basename):
        return PIISourceProvenance.STATIC_METADATA

    # 3. Variable name is a known metadata field
    if variable_name and _METADATA_VARIABLE_NAMES.match(variable_name):
        return PIISourceProvenance.STATIC_METADATA

    # 4. Source code context: hardcoded string literal in metadata dict
    if _METADATA_DICT_KEYS.search(source_code):
        return PIISourceProvenance.STATIC_METADATA

    # 5. PII_VARIABLE with hardcoded string literal assignment
    if source_type == PIISourceType.PII_VARIABLE:
        m = _STRING_LITERAL_ASSIGN.search(source_code)
        if m:
            var = m.group(1).lower()
            # Only flag as metadata if the variable name is metadata-like
            if _METADATA_VARIABLE_NAMES.match(var):
                return PIISourceProvenance.STATIC_METADATA

    # 6. Cannot determine — keep as unknown (conservative)
    return PIISourceProvenance.UNKNOWN


@dataclass
class PIISource:
    """A source of PII data in code."""

    source_type: PIISourceType
    location: str  # file:line
    variable: str  # Variable name
    pii_type: str = ""  # Detected PII type (ssn, email, etc.)
    confidence: float = 1.0
    context: str = ""  # Surrounding code context


# =============================================================================
# PYTHON PII SOURCE PATTERNS
# =============================================================================

# PII attribute/key names to detect
PII_ATTRIBUTES = [
    "ssn",
    "social_security",
    "social_security_number",
    "credit_card",
    "creditcard",
    "card_number",
    "pan",
    "cvv",
    "cvc",
    "security_code",
    "bank_account",
    "account_number",
    "routing_number",
    "iban",
    "email",
    "email_address",
    "user_email",
    "phone",
    "phone_number",
    "mobile",
    "telephone",
    "address",
    "street_address",
    "mailing_address",
    "home_address",
    "dob",
    "date_of_birth",
    "birthdate",
    "birthday",
    "passport",
    "passport_number",
    "drivers_license",
    "license_number",
    "dl_number",
    "tax_id",
    "ein",
    "tin",
    "mrn",
    "medical_record",
    "patient_id",
    "npi",
    "provider_id",
    "password",
    "passwd",
    "pwd",
    "secret",
    "api_key",
    "apikey",
    "auth_token",
    # v5.1.7: Removed standalone 'name' — too many FPs (model_name, table_name,
    # s.name in Cypher, etc.). Only match high-signal person name fields.
    "first_name",
    "last_name",
    "full_name",
    "given_name",
    "family_name",
    "display_name",
    "customer_name",
    "employee_name",
    "patient_name",
    "user_name",
    "ip_address",
    "ipaddress",
    "client_ip",
    "user_data",
    "personal_info",
    "pii",
    "sensitive_data",
]

# Build regex patterns for PII attributes
_pii_attr_pattern = "|".join(PII_ATTRIBUTES)

PYTHON_PII_SOURCES: Dict[PIISourceType, List[str]] = {
    # HTTP/Web sources
    PIISourceType.HTTP_FORM: [
        r"request\.form\[",
        r"request\.form\.get\(",
        r"request\.values\[",
        r"request\.values\.get\(",
        r"form\.data",
        r"form\.cleaned_data",  # Django
        r"Form\([^)]*\)\.data",
    ],
    PIISourceType.HTTP_JSON: [
        r"request\.json",
        r"request\.get_json\(",
        r"request\.data",  # Flask/FastAPI
        r"await request\.json\(",
        r"body\s*=\s*await\s+request\.body\(",
        r"Body\(",  # FastAPI
    ],
    PIISourceType.HTTP_QUERY: [
        r"request\.args\[",
        r"request\.args\.get\(",
        r"request\.params\[",
        r"request\.query_params",
        r"Query\(",  # FastAPI
    ],
    PIISourceType.HTTP_HEADER: [
        r"request\.headers\[",
        r"request\.headers\.get\(",
        r"request\.cookies\[",
        r"request\.cookies\.get\(",
        r"Header\(",  # FastAPI
    ],
    # User session
    PIISourceType.USER_SESSION: [
        r"session\[",
        r"session\.get\(",
        r"current_user\.",
        r"g\.user\.",  # Flask
        r"request\.user\.",  # Django
        r"flask_login\.current_user",
    ],
    PIISourceType.USER_AUTH: [
        r"jwt\.decode\(",
        r"decode_token\(",
        r"get_current_user\(",
        r"authenticate\(",
        r"credentials\.",
    ],
    # Database
    PIISourceType.DB_QUERY: [
        r"cursor\.fetchone\(",
        r"cursor\.fetchall\(",
        r"cursor\.fetchmany\(",
        r"\.execute\([^)]+\)\.fetch",
        r"connection\.execute\(",
        r"session\.execute\(",  # SQLAlchemy
        r"pd\.read_sql\(",  # Pandas
    ],
    PIISourceType.DB_MODEL: [
        r"User\.query\.",
        r"User\.objects\.",  # Django ORM
        r"User\.get\(",
        r"\.filter\([^)]+\)\.first\(",
        r"\.filter_by\([^)]+\)\.first\(",
        r"get_user_by_",
        r"find_user\(",
        r"Customer\.query\.",
        r"Patient\.query\.",
    ],
    # File/External
    PIISourceType.FILE_READ: [
        r"open\([^)]+\)\.read",
        r"Path\([^)]+\)\.read_text",
        r"\.read_csv\(",
        r"\.read_json\(",
        r"\.read_excel\(",
        r"json\.load\(",
        r"csv\.reader\(",
        r"csv\.DictReader\(",
    ],
    PIISourceType.API_RESPONSE: [
        r"requests\.get\([^)]+\)\.json\(",
        r"requests\.post\([^)]+\)\.json\(",
        r"httpx\.\w+\([^)]+\)\.json\(",
        r"response\.json\(",
        r"aiohttp\.\w+\([^)]+\)\.json\(",
    ],
    # PII-specific patterns
    PIISourceType.PII_ATTRIBUTE: [
        # user.ssn, data.credit_card, etc.
        rf"\.({_pii_attr_pattern})\b",
    ],
    PIISourceType.PII_DICT_KEY: [
        # data['ssn'], user['email'], etc.
        rf'\[\s*["\']({_pii_attr_pattern})["\']\s*\]',
        rf'\.get\(\s*["\']({_pii_attr_pattern})["\']',
    ],
    PIISourceType.PII_VARIABLE: [
        # ssn = ..., credit_card = ...
        rf"\b({_pii_attr_pattern})\s*=\s*",
    ],
    # Environment
    PIISourceType.ENVIRONMENT: [
        r"os\.environ\[",
        r"os\.environ\.get\(",
        r"os\.getenv\(",
        r"environ\[",
    ],
    # Message queues
    PIISourceType.MESSAGE_QUEUE: [
        r"\.consume\(",
        r"\.receive\(",
        r"consumer\.poll\(",
        r"channel\.basic_get\(",
        r"queue\.get\(",
    ],
}


# =============================================================================
# TYPESCRIPT/JAVASCRIPT PII SOURCE PATTERNS
# =============================================================================

TYPESCRIPT_PII_SOURCES: Dict[PIISourceType, List[str]] = {
    # HTTP/Web sources
    PIISourceType.HTTP_FORM: [
        r"req\.body\.",
        r"request\.body\.",
        r"formData\.get\(",
        r"new FormData\(",
    ],
    PIISourceType.HTTP_JSON: [
        r"req\.body",
        r"await req\.json\(",
        r"await request\.json\(",
        r"JSON\.parse\(.*body",
    ],
    PIISourceType.HTTP_QUERY: [
        r"req\.query\.",
        r"req\.params\.",
        r"request\.query\.",
        r"searchParams\.get\(",
        r"URLSearchParams",
    ],
    PIISourceType.HTTP_HEADER: [
        r"req\.headers\[",
        r"req\.headers\.",
        r"request\.headers\.",
        r"req\.cookies\.",
    ],
    # User session
    PIISourceType.USER_SESSION: [
        r"session\.",
        r"req\.session\.",
        r"req\.user\.",
        r"currentUser\.",
        r"getSession\(",
    ],
    PIISourceType.USER_AUTH: [
        r"jwt\.decode\(",
        r"verifyToken\(",
        r"authenticate\(",
        r"getUser\(",
    ],
    # Database
    PIISourceType.DB_QUERY: [
        r"\.query\([^)]+\)",
        r"\.findOne\(",
        r"\.findMany\(",
        r"\.find\(\{",
        r"prisma\.\w+\.findUnique",
        r"db\.query\(",
    ],
    PIISourceType.DB_MODEL: [
        r"User\.find",
        r"User\.get",
        r"Customer\.find",
        r"Patient\.find",
    ],
    # File/External
    PIISourceType.FILE_READ: [
        r"fs\.readFile",
        r"readFileSync\(",
        r"\.text\(\)",
        r"\.json\(\)",
    ],
    PIISourceType.API_RESPONSE: [
        r"fetch\([^)]+\)\.then\([^)]+\.json",
        r"await fetch\([^)]+\)\.json\(",
        r"axios\.\w+\([^)]+\)\.then",
        r"response\.data",
    ],
    # PII-specific patterns
    PIISourceType.PII_ATTRIBUTE: [
        rf"\.({_pii_attr_pattern})\b",
    ],
    PIISourceType.PII_DICT_KEY: [
        rf'\[\s*["\']({_pii_attr_pattern})["\']\s*\]',
    ],
    PIISourceType.PII_VARIABLE: [
        rf"\b({_pii_attr_pattern})\s*[=:]\s*",
    ],
    # Environment
    PIISourceType.ENVIRONMENT: [
        r"process\.env\.",
        r"process\.env\[",
    ],
}


# =============================================================================
# SOURCE TO PII TYPE MAPPING
# =============================================================================

# Map source patterns to likely PII types
SOURCE_TO_PII_TYPE: Dict[str, str] = {
    "ssn": "ssn",
    "social_security": "ssn",
    "credit_card": "credit_card",
    "creditcard": "credit_card",
    "card_number": "credit_card",
    "pan": "credit_card",
    "cvv": "cvv",
    "cvc": "cvv",
    "bank_account": "bank_account",
    "account_number": "bank_account",
    "routing_number": "routing_number",
    "iban": "iban",
    "email": "email",
    "email_address": "email",
    "phone": "phone",
    "phone_number": "phone",
    "mobile": "phone",
    "address": "address",
    "street_address": "address",
    "dob": "dob",
    "date_of_birth": "dob",
    "birthdate": "dob",
    "passport": "passport",
    "drivers_license": "drivers_license",
    "license_number": "drivers_license",
    "tax_id": "tax_id",
    "mrn": "mrn",
    "medical_record": "mrn",
    "patient_id": "mrn",
    "npi": "npi",
    "password": "password",
    "api_key": "api_key",
    # v5.1.7: Removed standalone 'name' — causes FPs on model_name, file_name,
    # table_name, service_name, etc. Only high-signal variants remain.
    "first_name": "person_name",
    "last_name": "person_name",
    "given_name": "person_name",
    "family_name": "person_name",
    "display_name": "person_name",
    "customer_name": "person_name",
    "employee_name": "person_name",
    "patient_name": "person_name",
    "user_name": "person_name",
    "ip_address": "ip_address",
    "user_data": "user_data",
    "personal_info": "user_data",
    "pii": "user_data",
}


# P2.54b: ALLOWLIST approach — only treat .name as person_name when the object
# is a known person/user entity. Everything else (.name on files, archives,
# infra objects, stdlib types) is NOT a person name.
#
# Previous blacklist approach (_INFRA_NAME_PREFIXES) couldn't scale:
#   f.name (file), tar.name, path.name, sp.name, etc. — infinite exceptions.
# Allowlist is finite: only ~20 words mean "this is a human being".
_PERSON_CONTEXT_PREFIXES = {
    # Direct person references
    "user",
    "person",
    "people",
    "human",
    "individual",
    "employee",
    "staff",
    "worker",
    "manager",
    "admin",
    "customer",
    "client",
    "buyer",
    "seller",
    "vendor",
    "patient",
    "doctor",
    "provider",
    "nurse",
    "clinician",
    "student",
    "teacher",
    "instructor",
    "professor",
    "contact",
    "recipient",
    "sender",
    "author",
    "owner",
    "member",
    "subscriber",
    "applicant",
    "candidate",
    "actor",
    "principal",  # security contexts
    # ORM/model references that imply person records
    "profile",
    "identity",
    # Object references to user in context (obj_user, current_user)
    "obj_user",
    "current_user",
    "logged_in_user",
    "auth_user",
}


def _is_person_name_context(source_code: str) -> bool:
    """P2.54b: Check if .name/.display_name refers to a PERSON (allowlist approach).

    Returns True ONLY when the object before .name is a known person-like entity.
    Returns False for everything else (files, archives, infra, stdlib, etc.)

    Examples:
        user.name          → True  (person)
        obj_user.name      → True  (person)
        customer.name      → True  (person)
        f.name             → False (file object)
        bucket.name        → False (infra)
        tar.name           → False (stdlib)
        instance.name      → False (infra)
    """
    source_lower = source_code.lower()

    # Match: <variable>.name or <variable>.display_name
    name_access_patterns = [
        r"(\w+)\.(?:display_)?name\b",
        r'(\w+)\[\s*["\'](?:display_)?name["\']\s*\]',
    ]

    for pattern in name_access_patterns:
        for match in re.finditer(pattern, source_lower):
            obj_name = match.group(1)
            # Direct match: user.name, patient.name
            if obj_name in _PERSON_CONTEXT_PREFIXES:
                return True
            # Compound match: obj_user.name, current_user.name, logged_in_user.name
            for prefix in _PERSON_CONTEXT_PREFIXES:
                if prefix in obj_name:
                    return True

    # Check for dict key patterns that imply person context
    # e.g. {"User Name": user.name}, but NOT {"Bucket Name": bucket.name}
    person_dict_pattern = r'["\'](?:' + "|".join(_PERSON_CONTEXT_PREFIXES) + r')\s+name["\']'
    if re.search(person_dict_pattern, source_lower):
        return True

    return False


# =============================================================================
# P2.55: BOOLEAN / TRIVIAL VALUE FILTER
# =============================================================================
# Prevents false positives when PII keywords are used as config flags, not data.
# e.g. 'mobile: false' is a CDP viewport param, NOT a phone number.


def _has_non_sensitive_value(source_code: str, keyword: str) -> bool:
    """P2.55: Check if a PII keyword is assigned a boolean/null/trivial value,
    or is a type annotation (not actual data).

    Catches false positives like:
        mobile: false           → NOT a phone number (CDP viewport config)
        email_enabled: true     → NOT an email address (feature flag)
        address: null           → NOT an address (unset field)
        ssn_required: 0         → NOT an SSN (config flag)
        phone_verified: False   → NOT a phone number (status flag)
        is_mobile = check()     → NOT a phone number (boolean check)
        email: string           → NOT an email (TS/JS type annotation) [b15]
        phone?: number          → NOT a phone (TS optional type) [b15]

    Does NOT filter real PII:
        mobile = "+1-555-0123"  → IS a phone number
        email = user.email      → IS an email
        phone = request.form["phone"] → IS a phone number
    """
    source_lower = source_code.lower()
    keyword_lower = keyword.lower()

    # Check 0 (b15): TypeScript/JavaScript type annotations.
    # Interface fields like `email: string`, `phone?: number`, `address: string[]`
    # are type declarations, not PII data assignments.
    # Also catches Python type hints: `email: str`, `phone: Optional[str]`
    _TYPE_KEYWORDS = (
        r"string|number|boolean|any|object|void|never|unknown|undefined|null"
        r"|string\[\]|number\[\]|Array<"
        r"|str|int|float|bool|dict|list|Optional\[|List\[|Dict\["
    )
    type_annot_re = r"\b" + re.escape(keyword_lower) + r"\??\s*:\s*(?:" + _TYPE_KEYWORDS + r")"
    if re.search(type_annot_re, source_code, re.IGNORECASE):
        return True

    # b15: Also catch TS interface fields with custom types:
    #   email: UserEmail, address: Address, phone: PhoneType
    # But NOT: email: "foo@bar.com" (string literal) or email: user.email (value)
    custom_type_re = r"\b" + re.escape(keyword_lower) + r"\??\s*:\s*([A-Z]\w*)"
    ct_match = re.search(custom_type_re, source_code)
    if ct_match:
        ct_match.group(1)
        # Type names don't have ( immediately after (that would be a constructor call)
        end_pos = ct_match.end()
        rest = source_code[end_pos : end_pos + 5].lstrip()
        if not rest.startswith("("):
            return True
    # e.g. mobile: false, phone = None, address = null, ssn_required: 0
    # P2.55b: Must NOT be followed by ||, ??, && — those mean the trivial value
    # is just a fallback default and real data comes next.
    #   mobile = false              → non-sensitive (sole value) ✓
    #   phone = null || getPhone()  → SKIP (null is just a default) ✓
    #   email = false || req.email  → SKIP (false is just a default) ✓
    trivial_values = r"(?:true|false|null|undefined|None|True|False|0|1|-1|0\.0)"
    value_re = r"\b" + re.escape(keyword_lower) + r"\b\s*[:=]\s*" + trivial_values + r"\b(?!\s*(?:\|\||&&|\?\?))"
    if re.search(value_re, source_code, re.IGNORECASE):
        return True

    # Check 2: keyword is part of a boolean-style compound variable name
    # Prefix patterns: is_mobile, has_phone, use_email, require_address
    bool_prefix_pattern = re.compile(
        r"\b(?:is|has|use|enable|disable|require|allow|show|hide|need|include|exclude|verify|skip)"
        r"[_]?" + re.escape(keyword_lower) + r"\b",
        re.IGNORECASE,
    )
    if bool_prefix_pattern.search(source_lower):
        return True

    # Suffix patterns: email_enabled, phone_verified, address_required
    bool_suffix_pattern = re.compile(
        r"\b"
        + re.escape(keyword_lower)
        + r"[_]?(?:enabled|disabled|required|verified|present|active|visible|flag|mode|check|opt|option|setting)\b",
        re.IGNORECASE,
    )
    if bool_suffix_pattern.search(source_lower):
        return True

    # Check 3: line contains boolean type signals alongside the keyword
    # Catches patterns like:
    #   const mobile = (params.mobile as boolean) || false;
    #   let phone: boolean = config.phone ?? true;
    #   var address = Boolean(opts.address);
    #   mobile = !!params.mobile;
    # These indicate the keyword is being used as a boolean flag, not PII data.
    if re.search(r"\b" + re.escape(keyword_lower) + r"\b", source_lower):
        bool_type_signals = [
            r"\bas\s+boolean\b",  # TS type assertion: as boolean
            r":\s*boolean\b",  # TS type annotation: : boolean
            r"\bboolean\s*\(",  # Boolean() cast (matched against lowered source)
            r"\|\|\s*(?:true|false)\b",  # fallback: || false, || true
            r"\?\?\s*(?:true|false)\b",  # nullish: ?? false, ?? true
            r"!![\w.]",  # double-bang coercion: !!value
        ]
        for signal in bool_type_signals:
            if re.search(signal, source_lower):
                return True

    return False


# v5.1.7: Physical address context — standalone 'address' in code is almost
# always a network/IP/wallet/memory address, NOT a mailing address.
# Physical addresses use 'street_address', 'mailing_address', etc.
_NETWORK_ADDRESS_PREFIXES = {
    "ip",
    "ip_",
    "bolt",
    "neo4j",
    "connection",
    "server",
    "host",
    "endpoint",
    "bind",
    "listen",
    "socket",
    "peer",
    "remote",
    "local",
    "wallet",
    "contract",
    "memory",
    "base",
    "return",
    "callback",
    "grpc",
    "redis",
    "mongo",
    "postgres",
    "mysql",
    "broker",
    "node",
    "cluster",
    "gateway",
    "proxy",
    "dns",
    "mac",
    "eth",
    "network",
    "multicast",
    "broadcast",
    "loopback",
    "src",
    "dst",
    "source",
    "dest",
}


def _is_physical_address_context(source_code: str) -> bool:
    """v5.1.7: Check if 'address' refers to a PHYSICAL/mailing address.

    Returns True ONLY when context indicates a person's physical address.
    Returns False for IP, network, wallet, memory, and other technical addresses.

    Examples:
        user.address       → True  (person)
        customer.address   → True  (person)
        i.address          → False (IP node in Cypher)
        ip_address         → False (network)
        server.address     → False (network)
        wallet.address     → False (blockchain)
    """
    source_lower = source_code.lower()

    # Check 1: Is .address on a person-like object? (allowlist)
    for pattern in [r"(\w+)\.address\b", r'(\w+)\[\s*["\']address']:
        for match in re.finditer(pattern, source_lower):
            obj = match.group(1)
            # Person context → physical address
            if obj in _PERSON_CONTEXT_PREFIXES:
                return True
            if any(p in obj for p in _PERSON_CONTEXT_PREFIXES):
                return True
            # Network/tech context → not physical
            if any(obj.startswith(n) or n in obj for n in _NETWORK_ADDRESS_PREFIXES):
                return False

    # Check 2: Variable name like ip_address, server_address → not physical
    if re.search(r"\b(?:" + "|".join(re.escape(n) for n in _NETWORK_ADDRESS_PREFIXES) + r")_?address\b", source_lower):
        return False

    # Check 3: Inside a query string (Cypher, SQL) → not physical
    if re.search(r"(?:CREATE|MATCH|SELECT|INSERT|UPDATE|REQUIRE|INDEX|CONSTRAINT)", source_code, re.IGNORECASE):
        return False

    # Check 4: address=<ip_var> pattern → not physical
    if re.search(r"address\s*=\s*(?:ip|addr|host|endpoint|url|uri|bolt)", source_lower):
        return False

    # Default: ambiguous, keep as physical (conservative)
    return True


def infer_pii_type_from_source(source_code: str) -> str:
    """Infer PII type from source code pattern.

    b14 FIX: Use word-boundary regex instead of substring matching.
    P2.54b FIX: Allowlist approach for .name — only return 'person_name'
    when the object is a known person entity (user.name, patient.name).
    Everything else (f.name, bucket.name, tar.name, arcname) → not a person.
    P2.55 FIX: Skip keywords whose VALUE is a boolean, null, or trivial literal.
    e.g. 'mobile: false' is a config flag, not a phone number.
    """
    source_lower = source_code.lower()

    # b14: Sort by longest keyword first so 'credit_card' matches before 'card'
    # and 'email_address' matches before 'address'
    sorted_items = sorted(SOURCE_TO_PII_TYPE.items(), key=lambda x: -len(x[0]))

    for keyword, pii_type in sorted_items:
        # b14: Word-boundary match — keyword must be a standalone identifier
        # segment, not a substring of a larger word.
        if not re.search(r"\b" + re.escape(keyword) + r"\b", source_lower):
            continue

        # P2.54b: For 'name' keywords, require person context (allowlist).
        # .name on files (f.name), archives (arcname), infra (bucket.name),
        # stdlib (path.name) are NOT person names.
        if pii_type == "person_name":
            if not _is_person_name_context(source_code):
                continue  # Skip — .name is not on a person object

        # v5.1.7: For standalone 'address', require physical address context.
        # IP, network, wallet, memory addresses are not PII.
        if pii_type == "address" and keyword == "address":
            if not _is_physical_address_context(source_code):
                continue  # Skip — .address is not a mailing address

        # P2.55: Skip if the keyword's value is a boolean/null/trivial literal.
        # 'mobile: false' is a config flag, not a phone number.
        if _has_non_sensitive_value(source_code, keyword):
            continue

        return pii_type

    return "user_data"  # Default


def get_source_confidence(source_type: PIISourceType) -> float:
    """Get confidence score for a source type."""
    HIGH_CONFIDENCE = {
        PIISourceType.PII_ATTRIBUTE,
        PIISourceType.PII_DICT_KEY,
        PIISourceType.DB_MODEL,
    }
    MEDIUM_CONFIDENCE = {
        PIISourceType.HTTP_FORM,
        PIISourceType.HTTP_JSON,
        PIISourceType.USER_SESSION,
        PIISourceType.DB_QUERY,
        PIISourceType.PII_VARIABLE,
    }

    if source_type in HIGH_CONFIDENCE:
        return 0.9
    elif source_type in MEDIUM_CONFIDENCE:
        return 0.7
    else:
        return 0.5
