# REACHABLE DLP Discovery Module
# Copyright (c) 2026 Sthenos Security. All rights reserved.

"""
DLP Discovery - File classification for DLP scanning.

P2.45: Regex-based entity_patterns removed. PII detection via Semgrep taint only.

Components:
- file_classifier: Classify files by type and purpose (Phase 1)
"""

from reachable.dlp.discovery.file_classifier import FileClassifier, classify_file

__all__ = [
    "FileClassifier",
    "classify_file",
]
