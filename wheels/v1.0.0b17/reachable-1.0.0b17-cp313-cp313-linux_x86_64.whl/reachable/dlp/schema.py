# REACHABLE DLP Security Module - Schema Definitions
# Copyright (c) 2026 Sthenos Security. All rights reserved.

"""
DLP Schema - Data structures for DLP findings and classifications.

Severity Classification v2.0.0 (2026-01-22):
- Severity determined by Data Sensitivity Tier × Reachability State
- Sink type, sanitizers = metadata only, do NOT reduce severity
- See SEVERITY_CLASSIFICATION.md for full documentation

Defines:
- DLPFinding: Main finding dataclass
- Enums for PII types, file classes, sinks, regulations
- Mapping tables for severity, regulations, patterns

Usage:
    from reachable.dlp.schema import DLPFinding, PIIEntityType, SinkType

    finding = DLPFinding(
        finding_type=DLPFindingType.PII_TAINT,
        pii_type=PIIEntityType.SSN,
        sink_type=SinkType.LLM_API,
        ...
    )
"""

import hashlib
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any, Dict, List, Optional, Tuple


class DLPFindingType(Enum):
    """Type of DLP finding - maps to entity_type in correlation engine."""

    PII_DISCOVERY = "dlp_discovery"  # PII exists in repo
    PII_TAINT = "dlp_taint"  # PII flows to dangerous sink
    PII_AI = "dlp_ai"  # PII flows to LLM/AI
    CONFIG_MISSING = "dlp_config"  # Missing sanitizer/Presidio


class PIIEntityType(Enum):
    """PII entity categories with detection priority."""

    # Identity (SENSITIVE tier)
    PERSON_NAME = "person_name"
    EMAIL = "email"
    PHONE = "phone"
    ADDRESS = "address"
    DATE_OF_BIRTH = "dob"

    # Government IDs (RESTRICTED tier)
    SSN = "ssn"
    PASSPORT = "passport"
    DRIVERS_LICENSE = "drivers_license"
    TAX_ID = "tax_id"

    # Financial (RESTRICTED tier - PCI)
    CREDIT_CARD = "credit_card"
    BANK_ACCOUNT = "bank_account"
    ROUTING_NUMBER = "routing_number"
    CVV = "cvv"
    IBAN = "iban"

    # Health (RESTRICTED tier - HIPAA)
    MRN = "mrn"  # Medical Record Number
    ICD10 = "icd10"  # Diagnosis codes
    NPI = "npi"  # National Provider ID
    DIAGNOSIS = "diagnosis"

    # Authentication (RESTRICTED tier)
    PASSWORD = "password"
    API_KEY = "api_key"  # Overlaps with secrets

    # Internal (LOW tier)
    CUSTOMER_ID = "customer_id"
    EMPLOYEE_ID = "employee_id"
    USER_ID = "user_id"

    # IP Address (LOW tier - context dependent)
    IP_ADDRESS = "ip_address"


class FileClass(Enum):
    """File classification for context-aware scanning."""

    DATA_ARTIFACT = "data_artifact"  # .csv, .json, .sql
    FIXTURE = "fixture"  # fixtures/, testdata/, seed/
    DOCS = "docs"  # .md, .ipynb
    SOURCE = "source"  # .py, .js, .go
    CONFIG = "config"  # .yaml, .env, .toml
    GENERATED = "generated"  # node_modules/, vendor/


class SinkType(Enum):
    """Dangerous sink categories for taint analysis."""

    LOG = "log"  # log calls, logging module, print
    EXTERNAL_API = "external_api"  # requests.post, fetch, axios
    LLM_API = "llm_api"  # openai.*, anthropic.*
    ANALYTICS = "analytics"  # segment, mixpanel
    ERROR_REPORTING = "error_reporting"  # sentry, bugsnag
    CLIENT_RESPONSE = "client_response"  # response.json, res.send
    VECTOR_STORE = "vector_store"  # chromadb, pinecone (RAG)
    DATABASE = "database"  # db.insert, cursor.execute
    FILE_WRITE = "file_write"  # open().write, fs.writeFile
    FILE_SYSTEM = "file_system"  # Alias for FILE_WRITE
    CACHE = "cache"  # redis.set, memcache
    MESSAGE_QUEUE = "message_queue"  # kafka, rabbitmq
    CONTEXT = "context"  # P2.56: framework request context (c.set, req.user)


class RegulationType(Enum):
    """Regulatory frameworks for compliance mapping."""

    GDPR = "GDPR"  # EU General Data Protection
    HIPAA = "HIPAA"  # US Health Insurance Portability
    PCI_DSS = "PCI-DSS"  # Payment Card Industry
    CCPA = "CCPA"  # California Consumer Privacy Act
    SOX = "SOX"  # Sarbanes-Oxley
    FERPA = "FERPA"  # Family Educational Rights
    GLBA = "GLBA"  # Gramm-Leach-Bliley


class DataSensitivityTier(Enum):
    """
    Data sensitivity classification for severity determination.

    v2.0.0: Severity = Tier × Reachability (sink/sanitizer are metadata only)
    See SEVERITY_CLASSIFICATION.md for rationale.
    """

    RESTRICTED = "restricted"  # Catastrophic if leaked (SSN, credit card, PHI, secrets)
    SENSITIVE = "sensitive"  # Privacy violation, regulatory fines (email, phone, address)
    LOW = "low"  # Context dependent (person_name, internal IDs)


class ReachabilityState(Enum):
    """
    Reachability states for DLP findings.

    Maps to app_reachability in findings table.
    """

    REACHABLE = "REACHABLE"  # Confirmed execution path from entrypoint
    UNKNOWN = "UNKNOWN"  # Call graph incomplete, cannot determine
    NOT_REACHABLE = "NOT_REACHABLE"  # Confirmed dead code, test-only


# =============================================================================
# SEVERITY CLASSIFICATION v2.0.0
# =============================================================================
# Key principle: For restricted data, the data itself is the risk.
# Sink type, sanitizers = metadata for remediation, NOT severity reducers.

# PII Type → Sensitivity Tier mapping
PII_SENSITIVITY_TIER: Dict[PIIEntityType, DataSensitivityTier] = {
    # RESTRICTED - catastrophic if leaked
    PIIEntityType.SSN: DataSensitivityTier.RESTRICTED,
    PIIEntityType.CREDIT_CARD: DataSensitivityTier.RESTRICTED,
    PIIEntityType.CVV: DataSensitivityTier.RESTRICTED,
    PIIEntityType.BANK_ACCOUNT: DataSensitivityTier.RESTRICTED,
    PIIEntityType.ROUTING_NUMBER: DataSensitivityTier.RESTRICTED,
    PIIEntityType.IBAN: DataSensitivityTier.RESTRICTED,
    PIIEntityType.PASSWORD: DataSensitivityTier.RESTRICTED,
    PIIEntityType.API_KEY: DataSensitivityTier.RESTRICTED,
    PIIEntityType.TAX_ID: DataSensitivityTier.RESTRICTED,
    PIIEntityType.PASSPORT: DataSensitivityTier.RESTRICTED,
    PIIEntityType.DRIVERS_LICENSE: DataSensitivityTier.RESTRICTED,
    PIIEntityType.MRN: DataSensitivityTier.RESTRICTED,
    PIIEntityType.DIAGNOSIS: DataSensitivityTier.RESTRICTED,
    PIIEntityType.ICD10: DataSensitivityTier.RESTRICTED,
    PIIEntityType.NPI: DataSensitivityTier.RESTRICTED,
    # SENSITIVE - privacy violation, regulatory fines
    PIIEntityType.EMAIL: DataSensitivityTier.SENSITIVE,
    PIIEntityType.PHONE: DataSensitivityTier.SENSITIVE,
    PIIEntityType.ADDRESS: DataSensitivityTier.SENSITIVE,
    PIIEntityType.DATE_OF_BIRTH: DataSensitivityTier.SENSITIVE,
    # LOW - context dependent
    PIIEntityType.PERSON_NAME: DataSensitivityTier.LOW,
    PIIEntityType.CUSTOMER_ID: DataSensitivityTier.LOW,
    PIIEntityType.EMPLOYEE_ID: DataSensitivityTier.LOW,
    PIIEntityType.USER_ID: DataSensitivityTier.LOW,
    PIIEntityType.IP_ADDRESS: DataSensitivityTier.LOW,
}

# Severity Matrix: (Tier, Reachability) → Severity
# This is the ONLY source of truth for DLP severity
SEVERITY_MATRIX: Dict[Tuple[DataSensitivityTier, str], str] = {
    # RESTRICTED tier - catastrophic if leaked
    (DataSensitivityTier.RESTRICTED, "REACHABLE"): "CRITICAL",
    (DataSensitivityTier.RESTRICTED, "UNKNOWN"): "CRITICAL",
    (DataSensitivityTier.RESTRICTED, "NOT_REACHABLE"): "MEDIUM",
    # SENSITIVE tier - privacy violation
    (DataSensitivityTier.SENSITIVE, "REACHABLE"): "HIGH",
    (DataSensitivityTier.SENSITIVE, "UNKNOWN"): "HIGH",
    (DataSensitivityTier.SENSITIVE, "NOT_REACHABLE"): "MEDIUM",
    # LOW tier - context dependent
    (DataSensitivityTier.LOW, "REACHABLE"): "MEDIUM",
    (DataSensitivityTier.LOW, "UNKNOWN"): "MEDIUM",
    (DataSensitivityTier.LOW, "NOT_REACHABLE"): "LOW",
}

# File classes that map to NOT_REACHABLE (test data, generated code)
NOT_REACHABLE_FILE_CLASSES = {
    FileClass.FIXTURE,
    FileClass.GENERATED,
    FileClass.DOCS,
}

# =============================================================================
# LEGACY MAPPINGS (kept for risk score sorting within severity levels)
# =============================================================================

# Mapping: PII type to applicable regulations
PII_TO_REGULATIONS: Dict[PIIEntityType, List[RegulationType]] = {
    PIIEntityType.SSN: [RegulationType.GDPR, RegulationType.CCPA],
    PIIEntityType.CREDIT_CARD: [RegulationType.PCI_DSS, RegulationType.GDPR],
    PIIEntityType.BANK_ACCOUNT: [RegulationType.GLBA, RegulationType.PCI_DSS],
    PIIEntityType.MRN: [RegulationType.HIPAA],
    PIIEntityType.ICD10: [RegulationType.HIPAA],
    PIIEntityType.NPI: [RegulationType.HIPAA],
    PIIEntityType.DIAGNOSIS: [RegulationType.HIPAA],
    PIIEntityType.EMAIL: [RegulationType.GDPR, RegulationType.CCPA],
    PIIEntityType.PHONE: [RegulationType.GDPR, RegulationType.CCPA],
    PIIEntityType.PERSON_NAME: [RegulationType.GDPR, RegulationType.CCPA],
    PIIEntityType.ADDRESS: [RegulationType.GDPR, RegulationType.CCPA],
    PIIEntityType.DATE_OF_BIRTH: [RegulationType.GDPR, RegulationType.HIPAA],
    PIIEntityType.PASSPORT: [RegulationType.GDPR],
    PIIEntityType.DRIVERS_LICENSE: [RegulationType.GDPR, RegulationType.CCPA],
    PIIEntityType.TAX_ID: [RegulationType.GDPR, RegulationType.SOX],
    PIIEntityType.PASSWORD: [RegulationType.GDPR, RegulationType.PCI_DSS],
    PIIEntityType.IP_ADDRESS: [RegulationType.GDPR],
}


# Risk score base by tier (for sorting within severity levels)
TIER_BASE_RISK: Dict[DataSensitivityTier, int] = {
    DataSensitivityTier.RESTRICTED: 90,
    DataSensitivityTier.SENSITIVE: 60,
    DataSensitivityTier.LOW: 30,
}

# Sink risk bonus (0-10, for prioritization only - does NOT affect severity)
SINK_RISK_BONUS: Dict[SinkType, int] = {
    SinkType.LLM_API: 10,
    SinkType.EXTERNAL_API: 8,
    SinkType.ANALYTICS: 7,
    SinkType.VECTOR_STORE: 7,
    SinkType.ERROR_REPORTING: 5,
    SinkType.CLIENT_RESPONSE: 5,
    SinkType.MESSAGE_QUEUE: 4,
    SinkType.LOG: 3,
    SinkType.DATABASE: 2,
    SinkType.CACHE: 2,
    SinkType.FILE_WRITE: 1,
    SinkType.FILE_SYSTEM: 1,
}


@dataclass
class DLPFinding:
    """
    A DLP finding that will be passed to the correlation engine.

    Severity Classification v2.0.0:
    - Severity = lookup(PII_SENSITIVITY_TIER[pii_type], reachability_state)
    - Sink type, sanitizers = metadata only (for remediation guidance)

    Maps to EntityRiskProfile in correlation_engine.py

    Attributes:
        finding_id: Unique identifier for deduplication
        finding_type: Discovery vs Taint vs AI
        file_path: Path to file containing the finding
        line_start: Starting line number
        pii_type: Type of PII detected
        sink_type: Where PII flows to (for taint findings)
        reachability_state: REACHABLE, UNKNOWN, or NOT_REACHABLE
        sanitizer_present: Whether a sanitizer was detected (metadata only)
    """

    # Core identification
    finding_id: str = ""  # Unique ID for deduplication
    finding_type: DLPFindingType = DLPFindingType.PII_DISCOVERY

    # Location
    file_path: str = ""
    line_start: int = 0
    line_end: int = 0
    column_start: int = 0
    column_end: int = 0

    # File context (Phase 1)
    file_class: FileClass = FileClass.SOURCE

    # PII entity details (Phase 2)
    pii_type: Optional[PIIEntityType] = None
    pii_count: int = 1  # How many instances
    pii_sample: str = ""  # Redacted sample
    pii_value_hash: str = ""  # SHA256 hash for deduplication
    confidence: str = "HIGH"  # HIGH, MEDIUM, LOW

    # Taint analysis details (Phase 3)
    source: str = ""  # Where PII originated
    source_location: str = ""  # file:line of source
    sink: str = ""  # Where it flowed to
    sink_location: str = ""  # file:line of sink
    sink_type: Optional[SinkType] = None
    propagation_path: List[str] = field(default_factory=list)
    sanitizer_present: bool = False  # Metadata only - does NOT reduce severity
    sanitizer_name: str = ""
    sanitizer_location: str = ""

    # Severity and context (v2.0.0 - tier × reachability)
    base_severity: str = "MEDIUM"  # Before context adjustment
    adjusted_severity: str = "MEDIUM"  # Final severity (same as base in v2.0)
    risk_score: float = 50.0  # 0-100 for sorting within severity

    # Reachability (REACHABLE's unique value)
    reachability_state: str = "REACHABLE"  # REACHABLE, UNKNOWN, NOT_REACHABLE
    is_reachable: bool = True  # Legacy compat: True if not NOT_REACHABLE
    call_paths: List[str] = field(default_factory=list)

    # Compliance
    regulations: List[str] = field(default_factory=list)

    # Message and remediation
    message: str = ""
    remediation: str = ""

    # Rule metadata
    rule_id: str = ""
    semgrep_rule_id: str = ""
    cwe_id: str = ""

    # Detection source
    detection_source: str = "pattern"  # pattern, semgrep, taint

    # Timestamps
    detected_at: datetime = field(default_factory=datetime.now)

    def __post_init__(self):
        """Generate finding_id if not provided and populate regulations."""
        if not self.finding_id:
            self.finding_id = self._generate_id()

        # Auto-populate regulations from PII type
        if self.pii_type and not self.regulations:
            regs = PII_TO_REGULATIONS.get(self.pii_type, [])
            self.regulations = [r.value for r in regs]

        # Sync is_reachable with reachability_state (legacy compat)
        self._sync_reachability()

        # Set severity using tier × reachability matrix
        self._set_severity()

        # Calculate risk score for sorting within severity
        self._calculate_risk_score()

    def _sync_reachability(self):
        """Sync is_reachable bool with reachability_state string."""
        # If file class indicates test/generated, override to NOT_REACHABLE
        if self.file_class in NOT_REACHABLE_FILE_CLASSES:
            self.reachability_state = "NOT_REACHABLE"
            self.is_reachable = False
        elif self.reachability_state == "NOT_REACHABLE":
            self.is_reachable = False
        elif not self.is_reachable and self.reachability_state == "REACHABLE":
            # Legacy: is_reachable=False was set, convert to state
            self.reachability_state = "NOT_REACHABLE"
        else:
            # Default: is_reachable reflects state
            self.is_reachable = self.reachability_state != "NOT_REACHABLE"

    def _generate_id(self) -> str:
        """Generate unique finding ID from location and type."""
        components = [
            self.finding_type.value if self.finding_type else "unknown",
            self.file_path,
            str(self.line_start),
            self.pii_type.value if self.pii_type else "",
            self.sink_type.value if self.sink_type else "",
        ]
        content = ":".join(components)
        return hashlib.sha256(content.encode()).hexdigest()[:16]

    def _set_severity(self):
        """
        Set severity using tier × reachability matrix.

        v2.0.0: This is the ONLY place severity is determined.
        Sink type and sanitizers do NOT affect severity.
        """
        # Get sensitivity tier for this PII type
        tier = PII_SENSITIVITY_TIER.get(self.pii_type, DataSensitivityTier.LOW)

        # Normalize reachability state
        state = self.reachability_state
        if state not in ("REACHABLE", "UNKNOWN", "NOT_REACHABLE"):
            state = "UNKNOWN"  # Default to worst case for unknown states

        # Lookup severity in matrix
        severity = SEVERITY_MATRIX.get((tier, state), "MEDIUM")

        self.base_severity = severity
        self.adjusted_severity = severity

    def _calculate_risk_score(self):
        """
        Calculate risk score for sorting within severity level.

        This does NOT affect severity - it's purely for prioritization
        when multiple findings have the same severity.
        """
        # Get tier for this PII type
        tier = PII_SENSITIVITY_TIER.get(self.pii_type, DataSensitivityTier.LOW)

        # Base score from tier
        base = TIER_BASE_RISK.get(tier, 30)

        # Sink type adds 0-10 points (for prioritization only)
        if self.sink_type:
            base += SINK_RISK_BONUS.get(self.sink_type, 0)

        # Sanitizer reduces score slightly (for prioritization within severity)
        if self.sanitizer_present:
            base -= 5

        # Not reachable reduces score (already reflected in severity, but helps sorting)
        if self.reachability_state == "NOT_REACHABLE":
            base -= 20

        self.risk_score = min(100, max(0, base))

    def recalculate(self):
        """Recalculate severity and risk score after modifications."""
        self._sync_reachability()
        self._set_severity()
        self._calculate_risk_score()

    @property
    def sensitivity_tier(self) -> DataSensitivityTier:
        """Get the sensitivity tier for this finding's PII type."""
        return PII_SENSITIVITY_TIER.get(self.pii_type, DataSensitivityTier.LOW)

    @property
    def location(self) -> str:
        """Human-readable location string."""
        return f"{self.file_path}:{self.line_start}"

    @property
    def is_critical(self) -> bool:
        """True if this is a critical finding (RESTRICTED tier, reachable)."""
        return self.adjusted_severity == "CRITICAL"

    @property
    def is_actionable(self) -> bool:
        """True if this finding requires action (not dead code)."""
        return self.reachability_state != "NOT_REACHABLE"

    @property
    def severity_icon(self) -> str:
        """Emoji icon for severity."""
        icons = {
            "CRITICAL": "",
            "HIGH": "",
            "MEDIUM": "",
            "LOW": "",
        }
        return icons.get(self.adjusted_severity, "")

    @property
    def tier_icon(self) -> str:
        """Emoji icon for sensitivity tier."""
        icons = {
            DataSensitivityTier.RESTRICTED: "",
            DataSensitivityTier.SENSITIVE: "",
            DataSensitivityTier.LOW: "",
        }
        return icons.get(self.sensitivity_tier, "")

    @property
    def display_pii_type(self) -> str:
        """Display string for PII type."""
        if self.pii_type:
            return self.pii_type.value.upper().replace("_", " ")
        return "UNKNOWN"

    @property
    def display_sink_type(self) -> str:
        """Display string for sink type."""
        if self.sink_type:
            return self.sink_type.value.upper().replace("_", " ")
        return "N/A"

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for JSON serialization."""
        return {
            "finding_id": self.finding_id,
            "finding_type": self.finding_type.value if self.finding_type else None,
            "file_path": self.file_path,
            "line_start": self.line_start,
            "line_end": self.line_end,
            "column_start": self.column_start,
            "column_end": self.column_end,
            "file_class": self.file_class.value if self.file_class else None,
            "pii_type": self.pii_type.value if self.pii_type else None,
            "pii_count": self.pii_count,
            "pii_sample": self.pii_sample,
            "confidence": self.confidence,
            "source": self.source,
            "source_location": self.source_location,
            "sink": self.sink,
            "sink_location": self.sink_location,
            "sink_type": self.sink_type.value if self.sink_type else None,
            "propagation_path": self.propagation_path,
            "sanitizer_present": self.sanitizer_present,
            "sanitizer_name": self.sanitizer_name,
            "sanitizer_location": self.sanitizer_location,
            "sensitivity_tier": self.sensitivity_tier.value,
            "reachability_state": self.reachability_state,
            "base_severity": self.base_severity,
            "adjusted_severity": self.adjusted_severity,
            "risk_score": round(self.risk_score, 2),
            "is_reachable": self.is_reachable,
            "call_paths_v2": self.call_paths_v2,
            "regulations": self.regulations,
            "message": self.message,
            "remediation": self.remediation,
            "rule_id": self.rule_id,
            "semgrep_rule_id": self.semgrep_rule_id,
            "cwe_id": self.cwe_id,
            "detection_source": self.detection_source,
            "detected_at": self.detected_at.isoformat() if self.detected_at else None,
        }

    def to_correlation_dict(self) -> Dict[str, Any]:
        """
        Convert to format expected by correlation engine.

        This matches the structure used by ai_findings in _build_ai_profiles().
        """
        return {
            "rule_id": self.rule_id or f"dlp-{self.finding_type.value}",
            "file_path": self.file_path,
            "line_start": self.line_start,
            "line_number": self.line_start,
            "message": self.message,
            "severity": self.adjusted_severity,
            "is_reachable": self.is_reachable,
            "reachability_state": self.reachability_state,
            "risk_weight": self.risk_score,
            "cwe_id": self.cwe_id,
            # DLP-specific fields
            "dlp_type": self.finding_type.value,
            "pii_type": self.pii_type.value if self.pii_type else None,
            "pii_count": self.pii_count,
            "sensitivity_tier": self.sensitivity_tier.value,
            "file_class": self.file_class.value if self.file_class else None,
            "sink_type": self.sink_type.value if self.sink_type else None,
            "source": self.source,
            "sink": self.sink,
            "sanitizer_present": self.sanitizer_present,
            "regulations": self.regulations,
            "remediation": self.remediation,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "DLPFinding":
        """Create from dictionary."""
        data = data.copy()

        # Convert enums
        if "finding_type" in data and isinstance(data["finding_type"], str):
            data["finding_type"] = DLPFindingType(data["finding_type"])
        if "pii_type" in data and isinstance(data["pii_type"], str):
            data["pii_type"] = PIIEntityType(data["pii_type"])
        if "sink_type" in data and isinstance(data["sink_type"], str):
            data["sink_type"] = SinkType(data["sink_type"])
        if "file_class" in data and isinstance(data["file_class"], str):
            data["file_class"] = FileClass(data["file_class"])
        if "detected_at" in data and isinstance(data["detected_at"], str):
            data["detected_at"] = datetime.fromisoformat(data["detected_at"])

        # Remove computed fields that will be recalculated
        data.pop("sensitivity_tier", None)

        return cls(**data)

    @classmethod
    def create_discovery(
        cls,
        file_path: str,
        line_start: int,
        pii_type: PIIEntityType,
        pii_sample: str = "",
        pii_count: int = 1,
        confidence: str = "HIGH",
        file_class: FileClass = FileClass.SOURCE,
        reachability_state: str = "REACHABLE",
    ) -> "DLPFinding":
        """Factory method for PII discovery findings."""
        return cls(
            finding_type=DLPFindingType.PII_DISCOVERY,
            file_path=file_path,
            line_start=line_start,
            pii_type=pii_type,
            pii_sample=pii_sample,
            pii_count=pii_count,
            confidence=confidence,
            file_class=file_class,
            reachability_state=reachability_state,
            rule_id=f"dlp-discovery-{pii_type.value}",
            message=f"Hardcoded {pii_type.value.upper().replace('_', ' ')} detected",
        )

    @classmethod
    def create_taint(
        cls,
        file_path: str,
        line_start: int,
        pii_type: PIIEntityType,
        source: str,
        sink: str,
        sink_type: SinkType,
        sanitizer_present: bool = False,
        reachability_state: str = "REACHABLE",
    ) -> "DLPFinding":
        """Factory method for PII taint findings."""
        finding_type = DLPFindingType.PII_AI if sink_type == SinkType.LLM_API else DLPFindingType.PII_TAINT

        # P2.56: Custom message for context propagation
        pii_label = pii_type.value.upper().replace("_", " ")
        if sink_type == SinkType.CONTEXT:
            message = f"{pii_label} propagated to request context — audit downstream consumers"
        elif sanitizer_present:
            message = f"{pii_label} flows to {sink_type.value.upper()} (sanitizer present)"
        else:
            message = f"{pii_label} flows to {sink_type.value.upper()} without sanitization"

        return cls(
            finding_type=finding_type,
            file_path=file_path,
            line_start=line_start,
            pii_type=pii_type,
            source=source,
            sink=sink,
            sink_type=sink_type,
            sanitizer_present=sanitizer_present,
            reachability_state=reachability_state,
            rule_id=f"dlp-taint-{pii_type.value}-to-{sink_type.value}",
            message=message,
        )
