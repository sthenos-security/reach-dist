# REACHABLE DLP Security Module - Scanner Orchestrator
# Copyright (c) 2026 Sthenos Security. All rights reserved.

"""
DLP Scanner - Main orchestrator for DLP security analysis.

P2.45: Removed regex Phase 2 discovery - use ONLY Semgrep taint analysis

Coordinates detection across:
- Phase 1: File classification (fixture, source, data artifact)
- Phase 2: Semgrep taint analysis (PII source → sink flows)
- Phase 3: AI-specific sinks (LLM APIs, vector stores)
- Phase 4: Context-aware scoring with reachability

P2.45: Regex-based PII discovery removed. All detection via Semgrep taint analysis.

Usage:
    from reachable.dlp import DLPScanner, DLPScanConfig

    scanner = DLPScanner()
    findings = scanner.scan(repo_path)

    for finding in findings:
        logger.info(str(finding))

Integration:
    Results integrate with the correlation engine via:
    - SignalType.DLP_TAINT
    - SignalType.DLP_AI
"""

import json
import logging
import re
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, Iterator, List, Optional, Set

from reachable.dlp.config import DLPScanConfig
from reachable.dlp.discovery.file_classifier import FileClassification, FileClassifier
from reachable.dlp.schema import DLPFinding, DLPFindingType, PIIEntityType, SinkType

# Taint analysis imports
TAINT_AVAILABLE = False
TaintSinkType = None

try:
    from reachable.dlp.taint.flow_analyzer import DLPFlowAnalyzer, DLPReachabilityResult, analyze_dlp_flows
    from reachable.dlp.taint.sinks import DLPSinkType as TaintSinkType
    from reachable.dlp.taint.sinks import is_llm_sink

    TAINT_AVAILABLE = True
except ImportError:
    DLPFlowAnalyzer = None
    DLPReachabilityResult = None
    analyze_dlp_flows = None
    is_llm_sink = None

logger = logging.getLogger(__name__)


class DLPScanner:
    """
    Main orchestrator for DLP scanning.

    P2.45: Uses ONLY Semgrep taint analysis (no regex patterns)

    Implements DLP Architecture phases:
    - Phase 1: File classification
    - Phase 2: Semgrep taint analysis (PII source → sink)
    - Phase 3: AI-specific sink categorization
    - Phase 4: Context-aware scoring with reachability

    P2.45: Regex-based discovery removed. All PII detection via Semgrep taint.
    """

    def __init__(
        self,
        config: Optional[DLPScanConfig] = None,
        call_graph: Optional[Dict] = None,
        reachable_functions: Optional[Set[str]] = None,
        entrypoints: Optional[Set[str]] = None,
    ):
        """
        Initialize DLP scanner.

        Args:
            config: Scan configuration. Defaults to full analysis.
            call_graph: Application call graph for reachability analysis.
            reachable_functions: Set of functions reachable from entrypoints.
            entrypoints: Application entry points (HTTP handlers, main, etc.).
        """
        self.config = config or DLPScanConfig.full()

        # Initialize components
        self._file_classifier = FileClassifier()

        # Call graph integration for reachability
        self.call_graph = call_graph or {}
        self.reachable_functions = reachable_functions or set()
        self.entrypoints = entrypoints or set()

        # Initialize flow analyzer for taint analysis
        if TAINT_AVAILABLE:
            self._flow_analyzer = DLPFlowAnalyzer(
                call_graph=self.call_graph,
                reachable_functions=self.reachable_functions,
                entrypoints=self.entrypoints,
            )
        else:
            self._flow_analyzer = None

        # Results
        self._findings: List[DLPFinding] = []
        self._file_classifications: List[FileClassification] = []
        self._taint_results: List[DLPReachabilityResult] = []

        # Statistics
        self._stats = {
            "files_scanned": 0,
            "files_skipped": 0,
            "total_findings": 0,
            "taint_findings": 0,
            "ai_findings": 0,
            "by_finding_type": {},
            "by_pii_type": {},
            "by_file_class": {},
            "by_severity": {},
            "by_sink_type": {},
            "reachable_findings": 0,
            "sanitized_findings": 0,
            "llm_flows": 0,
            "scan_start": None,
            "scan_end": None,
        }

    def scan(self, repo_path: Path) -> List[DLPFinding]:
        """
        Run full DLP scan on repository.

        Args:
            repo_path: Path to repository root.

        Returns:
            List of DLPFinding objects.
        """
        repo_path = Path(repo_path).resolve()

        if not repo_path.exists():
            raise ValueError(f"Repository path does not exist: {repo_path}")

        logger.info(f"Starting DLP scan: {repo_path}")
        self._stats["scan_start"] = datetime.now().isoformat()

        # Reset results
        self._findings = []
        self._file_classifications = []
        self._taint_results = []

        # Phase 1: File classification
        logger.info("Phase 1: Classifying files...")
        self._classify_files(repo_path)

        # Phase 2: Semgrep taint analysis (PII source → sink flows)
        if self.config.enable_taint and TAINT_AVAILABLE:
            logger.info("Phase 2: Running Semgrep taint analysis...")
            self._run_taint_analysis(repo_path)
        elif self.config.enable_taint and not TAINT_AVAILABLE:
            logger.warning("Taint analysis requested but module not available")

        # Phase 3: AI-specific sinks (LLM, vector stores)
        if self.config.enable_ai_sinks:
            logger.info("Phase 3: Categorizing AI-specific findings...")
            self._categorize_ai_findings()

        # Phase 4: Context-aware scoring
        if self.config.enable_context_scoring:
            logger.info("Phase 4: Applying context-aware scoring...")
            self._apply_context_scoring()

        # Finalize
        self._stats["scan_end"] = datetime.now().isoformat()
        self._log_summary()

        return self._findings

    def scan_iter(self, repo_path: Path) -> Iterator[DLPFinding]:
        """
        Scan repository and yield findings as they're discovered.

        Args:
            repo_path: Path to repository root.

        Yields:
            DLPFinding objects as they're found.
        """
        findings = self.scan(repo_path)
        for finding in findings:
            yield finding

    def _classify_files(self, repo_path: Path):
        """Phase 1: Classify all files in repository."""
        for file_path in repo_path.rglob("*"):
            if not file_path.is_file():
                continue

            # Classify file
            classification = self._file_classifier.classify(file_path)

            # Check if we should scan this file
            if not self.config.should_scan_file(file_path, classification.file_class):
                self._stats["files_skipped"] += 1
                continue

            # Skip binary files
            if FileClassifier.is_binary_file(file_path):
                self._stats["files_skipped"] += 1
                continue

            # Check file size
            try:
                size_kb = file_path.stat().st_size / 1024
                if size_kb > self.config.max_file_size_kb:
                    logger.debug(f"Skipping large file: {file_path} ({size_kb:.1f}KB)")
                    self._stats["files_skipped"] += 1
                    continue
            except Exception:
                pass

            self._file_classifications.append(classification)
            self._stats["files_scanned"] += 1

        logger.info(f"Classified {len(self._file_classifications)} files for scanning")

        # Update stats
        for fc in self._file_classifications:
            file_class = fc.file_class.value
            self._stats["by_file_class"][file_class] = self._stats["by_file_class"].get(file_class, 0) + 1

    def _run_taint_analysis(self, repo_path: Path):
        """
        Phase 2: Run Semgrep taint analysis to detect PII flowing to dangerous sinks.

        Uses Semgrep rules for accurate, context-aware detection.
        """
        if not self._flow_analyzer:
            logger.warning("Flow analyzer not available, skipping taint analysis")
            return

        # Run analysis on source files
        source_extensions = [".py", ".js", ".ts", ".tsx", ".jsx"]

        for fc in self._file_classifications:
            if fc.file_path.suffix.lower() not in source_extensions:
                continue

            try:
                result = self._flow_analyzer.analyze_file(fc.file_path)

                if result.flows:
                    self._taint_results.append(result)

                    # Convert taint flows to DLPFinding objects
                    for flow in result.flows:
                        finding = flow.to_dlp_finding(str(fc.file_path))

                        # Apply file class modifier
                        finding.file_class = fc.file_class
                        finding.recalculate()

                        self._findings.append(finding)

                        # Update stats
                        if finding.finding_type == DLPFindingType.PII_AI:
                            self._stats["ai_findings"] += 1
                        else:
                            self._stats["taint_findings"] += 1

                        self._update_stats(finding)

                    # Track LLM flows
                    if hasattr(result, "llm_flows"):
                        self._stats["llm_flows"] += (
                            len(result.llm_flows) if isinstance(result.llm_flows, list) else result.llm_flows
                        )

            except Exception as e:
                logger.debug(f"Taint analysis error for {fc.file_path}: {e}")

        logger.info(
            f"Taint analysis found {self._stats['taint_findings']} taint flows, {self._stats['ai_findings']} AI flows"
        )

    def _categorize_ai_findings(self):
        """
        Phase 3: Categorize and highlight AI-specific findings.

        AI sinks get highest risk scores:
        - LLM APIs (OpenAI, Anthropic, etc.)
        - Vector stores (ChromaDB, Pinecone, etc.)
        - RAG ingestion pipelines
        """
        if not TAINT_AVAILABLE or not TaintSinkType:
            return  # Skip if taint module not available

        for finding in self._findings:
            if finding.finding_type == DLPFindingType.PII_AI:
                # Already categorized as AI finding
                continue

            # Check if it's a taint finding going to an AI sink
            if finding.finding_type == DLPFindingType.PII_TAINT:
                if finding.sink_type:
                    # Map schema SinkType to taint DLPSinkType for is_llm_sink check
                    schema_to_taint_sink = {
                        SinkType.LLM_API: TaintSinkType.LLM_API,
                        SinkType.VECTOR_STORE: TaintSinkType.VECTOR_STORE,
                    }
                    taint_sink = schema_to_taint_sink.get(finding.sink_type)
                    if taint_sink and is_llm_sink(taint_sink):
                        finding.finding_type = DLPFindingType.PII_AI
                        self._stats["ai_findings"] += 1
                        self._stats["taint_findings"] -= 1

    def _is_reachable(self, file_path: Path, line_number: int) -> bool:
        """
        Determine if code at location is reachable from entrypoints.

        Uses call graph for accurate determination.
        Gate 1: Auto-suppress test/fixture/docs paths.
        """
        file_str = str(file_path).lower()

        # Gate 1: Fast path suppression - test/fixture/docs are NOT_REACHABLE
        # These patterns indicate non-production code that won't run in prod
        suppression_patterns = [
            "/test/",
            "/tests/",
            "_test.py",
            ".test.js",
            ".test.ts",
            ".spec.js",
            ".spec.ts",
            "/mock/",
            "/mocks/",
            "/__mocks__/",
            "/fixture/",
            "/fixtures/",
            "/__fixtures__/",
            "/example/",
            "/examples/",
            "/sample/",
            "/samples/",
            "/docs/",
            "/doc/",
            "/__snapshots__/",
            "/storybook/",
            "/vendor/",
            "/node_modules/",
            "/venv/",
            "/.venv/",
        ]
        for pattern in suppression_patterns:
            if pattern in file_str:
                return False  # NOT_REACHABLE - test/fixture/docs

        # Gate 1b: Doc file extensions
        if file_str.endswith((".md", ".rst", ".txt", ".adoc", ".html")):
            return False  # NOT_REACHABLE - documentation

        if not self.call_graph and not self.reachable_functions:
            return True  # Conservative: assume reachable if no call graph

        # Check if any reachable function is in this file
        for func in self.reachable_functions:
            if file_str in func or func in file_str:
                return True

        # Check call graph for file
        for node in self.call_graph:
            if file_str in node:
                return True

        return False  # No evidence of reachability - NOT_REACHABLE

    # b15: Test/dummy email domains → downgrade to LOW
    _TEST_EMAIL_RE = re.compile(
        r"[\w.+-]+@(?:example\.com|example\.org|example\.net"
        r"|test\.com|test\.org|localhost|invalid"
        r"|foo\.bar|bar\.com|baz\.com"
        r"|mailinator\.com|noreply\.com"
        r"|placeholder\.com|dummy\.com|fake\.com)\b",
        re.IGNORECASE,
    )

    def _apply_context_scoring(self):
        """Phase 4: Apply context-aware severity adjustment."""
        for finding in self._findings:
            # Recalculate risk score with full context
            finding.recalculate()

            # b15: Downgrade test/dummy email literals to LOW
            if finding.pii_type == PIIEntityType.EMAIL and finding.adjusted_severity in ("HIGH", "CRITICAL"):
                self._check_test_email_downgrade(finding)

            # Update stats
            if finding.is_reachable:
                self._stats["reachable_findings"] += 1
            if finding.sanitizer_present:
                self._stats["sanitized_findings"] += 1

    # b15: User-input sources that indicate real PII flow regardless of fallback
    _USER_INPUT_RE = re.compile(
        r"req\.body|req\.query|req\.params|request\.body"
        r"|request\.form|request\.json|request\.data"
        r"|ctx\.request|context\.request"
        r"|event\.body|payload\.",
        re.IGNORECASE,
    )

    def _check_test_email_downgrade(self, finding: DLPFinding):
        """b15: Downgrade email findings that contain only test/example domain literals.

        Reads the source line and checks if email literals use known
        dummy domains (example.com, test.com, etc.).

        Does NOT downgrade if the line also contains user-input sources
        (req.body, request.form, etc.) because the real PII risk is from
        user-controlled data, not the test fallback.
        """
        try:
            with open(finding.file_path, errors="replace") as f:
                for i, line in enumerate(f, 1):
                    if i == finding.line_start:
                        if not self._TEST_EMAIL_RE.search(line):
                            break  # No test email on this line
                        if self._USER_INPUT_RE.search(line):
                            break  # Has real user input — keep HIGH
                        finding.adjusted_severity = "LOW"
                        finding.message = (
                            (finding.message or "") + " [test_data_email: literal uses test/example domain]"
                        ).strip()
                        break
        except (OSError, IOError):
            pass

    def _update_stats(self, finding: DLPFinding):
        """Update scan statistics with a new finding."""
        self._stats["total_findings"] += 1

        # By finding type
        ft = finding.finding_type.value
        self._stats["by_finding_type"][ft] = self._stats["by_finding_type"].get(ft, 0) + 1

        # By PII type
        if finding.pii_type:
            pt = finding.pii_type.value
            self._stats["by_pii_type"][pt] = self._stats["by_pii_type"].get(pt, 0) + 1

        # By sink type
        if finding.sink_type:
            st = finding.sink_type.value
            self._stats["by_sink_type"][st] = self._stats["by_sink_type"].get(st, 0) + 1

        # By severity
        sev = finding.adjusted_severity
        self._stats["by_severity"][sev] = self._stats["by_severity"].get(sev, 0) + 1

    def _log_summary(self):
        """Log scan summary."""
        total = self._stats["total_findings"]
        taint = self._stats["taint_findings"]
        ai = self._stats["ai_findings"]
        files = len(self._file_classifications)
        skipped = self._stats["files_skipped"]

        logger.info("DLP scan complete:")
        logger.info(f" Files classified: {files}, skipped: {skipped}")
        logger.info(f" Total findings: {total}")
        logger.info(f" - Semgrep taint flows: {taint}")
        logger.info(f" - AI/LLM flows: {ai}")

        if self._stats["by_pii_type"]:
            logger.info(f" By PII type: {self._stats['by_pii_type']}")

        if self._stats["by_severity"]:
            logger.info(f" By severity: {self._stats['by_severity']}")

        logger.info(f" Reachable: {self._stats['reachable_findings']}")
        logger.info(f" Sanitized: {self._stats['sanitized_findings']}")

    @property
    def findings(self) -> List[DLPFinding]:
        """Get all findings from last scan."""
        return self._findings.copy()

    @property
    def statistics(self) -> Dict[str, Any]:
        """Get scan statistics."""
        return self._stats.copy()

    @property
    def file_classifications(self) -> List[FileClassification]:
        """Get all file classifications from last scan."""
        return self._file_classifications.copy()

    @property
    def taint_results(self) -> List:
        """Get taint analysis results from last scan."""
        return self._taint_results.copy()

    def get_findings_by_type(self, finding_type: DLPFindingType) -> List[DLPFinding]:
        """Get findings by type (taint, ai)."""
        return [f for f in self._findings if f.finding_type == finding_type]

    def get_findings_by_pii(self, pii_type: PIIEntityType) -> List[DLPFinding]:
        """Get findings by PII type (ssn, credit_card, etc)."""
        return [f for f in self._findings if f.pii_type == pii_type]

    def get_findings_by_severity(self, severity: str) -> List[DLPFinding]:
        """Get findings by severity (CRITICAL, HIGH, MEDIUM, LOW)."""
        return [f for f in self._findings if f.adjusted_severity == severity.upper()]

    def get_reachable_findings(self) -> List[DLPFinding]:
        """Get only findings in reachable code paths."""
        return [f for f in self._findings if f.is_reachable]

    def get_critical_findings(self) -> List[DLPFinding]:
        """Get critical findings (high severity, reachable, no sanitizer)."""
        return [f for f in self._findings if f.is_critical]

    def get_ai_findings(self) -> List[DLPFinding]:
        """Get findings specifically for AI/LLM sinks."""
        return [f for f in self._findings if f.finding_type == DLPFindingType.PII_AI]

    def get_taint_findings(self) -> List[DLPFinding]:
        """Get taint flow findings (source → sink)."""
        return [f for f in self._findings if f.finding_type == DLPFindingType.PII_TAINT]

    def get_summary(self) -> Dict[str, Any]:
        """Get comprehensive scan summary for integration with correlation engine."""
        return {
            "enabled": True,
            "included_in_risk_score": True,
            "total": len(self._findings),
            "taint_findings": self._stats["taint_findings"],
            "ai_findings": self._stats["ai_findings"],
            "llm_flows": self._stats["llm_flows"],
            "reachable": self._stats["reachable_findings"],
            "sanitized": self._stats["sanitized_findings"],
            "by_finding_type": self._stats["by_finding_type"],
            "by_pii_type": self._stats["by_pii_type"],
            "by_sink_type": self._stats["by_sink_type"],
            "by_file_class": self._stats["by_file_class"],
            "by_severity": self._stats["by_severity"],
            "files_classified": len(self._file_classifications),
            "files_skipped": self._stats["files_skipped"],
            "scan_start": self._stats["scan_start"],
            "scan_end": self._stats["scan_end"],
        }

    def to_correlation_format(self) -> List[Dict[str, Any]]:
        """
        Convert findings to format expected by correlation engine.

        Returns list of dicts with fields expected by SignalType.DLP_*.
        """
        return [f.to_correlation_dict() for f in self._findings]

    def to_json(self, indent: int = 2) -> str:
        """Export findings as JSON."""
        return json.dumps(
            {
                "summary": self.get_summary(),
                "findings": [f.to_dict() for f in self._findings],
            },
            indent=indent,
            default=str,
        )

    def save_report(self, output_path: Path):
        """
        Save DLP report to file.

        Args:
            output_path: Path for output file (JSON)
        """
        output_path = Path(output_path)
        output_path.write_text(self.to_json())
        logger.info(f"DLP report saved to: {output_path}")


def run_dlp_scan(
    repo_path: Path,
    config: Optional[DLPScanConfig] = None,
    call_graph: Optional[Dict] = None,
    reachable_functions: Optional[Set[str]] = None,
) -> List[DLPFinding]:
    """
    Convenience function to run a DLP scan.

    Args:
        repo_path: Path to repository
        config: Optional scan configuration
        call_graph: Optional call graph for reachability
        reachable_functions: Optional set of reachable functions

    Returns:
        List of DLPFinding objects
    """
    scanner = DLPScanner(
        config=config,
        call_graph=call_graph,
        reachable_functions=reachable_functions,
    )
    return scanner.scan(repo_path)
