#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.

"""
REACHABLE IaC (Infrastructure as Code) Security Module

Provides context-aware severity classification for IaC findings
(Dockerfile, Kubernetes, Terraform, etc.)
"""

from .severity_classifier import (
    IAC_SEVERITY_MAP,
    DeploymentContext,
    classify_iac_severity,
    get_deployment_context,
    set_deployment_context,
)

__all__ = [
    "classify_iac_severity",
    "get_deployment_context",
    "set_deployment_context",
    "DeploymentContext",
    "IAC_SEVERITY_MAP",
]
