# Copyright © 2026 Sthenos Security. All rights reserved.

"""
REACHABLE Docker Compose Security Scanner

Detects security misconfigurations in docker-compose.yml files:
- Privileged containers
- Dangerous capabilities
- Host mounts
- Exposed ports
- Missing resource limits
- Network mode issues
"""

import re
from pathlib import Path

try:
    import yaml
except ImportError:
    yaml = None
import logging
from dataclasses import dataclass
from typing import Dict, List

# Initialize module-level logger
logger = logging.getLogger(__name__)


@dataclass
class DockerComposeFinding:
    """Docker Compose security finding"""

    rule_id: str
    severity: str
    title: str
    description: str
    file_path: str
    service_name: str
    remediation: str


class DockerComposeScanner:
    """Scanner for Docker Compose file security issues"""

    RULES = {
        "DC-001": {
            "title": "Privileged Container",
            "severity": "CRITICAL",
            "description": "Service runs in privileged mode with full host access",
            "remediation": "Remove privileged: true unless absolutely required",
            "cwe": "CWE-250",
        },
        "DC-002": {
            "title": "Dangerous Capabilities",
            "severity": "HIGH",
            "description": "Service has dangerous Linux capabilities",
            "remediation": "Remove unnecessary capabilities from cap_add",
            "cwe": "CWE-250",
        },
        "DC-003": {
            "title": "Host Network Mode",
            "severity": "HIGH",
            "description": "Service uses host network, bypassing isolation",
            "remediation": "Use bridge or custom networks instead of network_mode: host",
            "cwe": "CWE-653",
        },
        "DC-004": {
            "title": "Host PID Mode",
            "severity": "HIGH",
            "description": "Service shares host PID namespace",
            "remediation": "Remove pid: host",
            "cwe": "CWE-653",
        },
        "DC-005": {
            "title": "Sensitive Host Mount",
            "severity": "CRITICAL",
            "description": "Service mounts sensitive host directory",
            "remediation": "Avoid mounting /, /etc, /var, /root, ~/.ssh, ~/.aws",
            "cwe": "CWE-552",
        },
        "DC-006": {
            "title": "Docker Socket Mount",
            "severity": "CRITICAL",
            "description": "Service mounts Docker socket - container escape risk",
            "remediation": "Remove /var/run/docker.sock mount unless required",
            "cwe": "CWE-269",
        },
        "DC-007": {
            "title": "Missing Memory Limit",
            "severity": "MEDIUM",
            "description": "Service has no memory limit, risking resource exhaustion",
            "remediation": "Add mem_limit or deploy.resources.limits.memory",
            "cwe": "CWE-770",
        },
        "DC-008": {
            "title": "Missing CPU Limit",
            "severity": "LOW",
            "description": "Service has no CPU limit",
            "remediation": "Add cpus or deploy.resources.limits.cpus",
            "cwe": "CWE-770",
        },
        "DC-009": {
            "title": "All Ports Exposed",
            "severity": "MEDIUM",
            "description": "Service exposes ports to all interfaces (0.0.0.0)",
            "remediation": "Bind to 127.0.0.1 for internal services",
            "cwe": "CWE-668",
        },
        "DC-010": {
            "title": "Latest Tag Used",
            "severity": "MEDIUM",
            "description": "Service uses :latest tag which is mutable",
            "remediation": "Pin to specific image version or digest",
            "cwe": "CWE-829",
        },
        "DC-011": {
            "title": "Hardcoded Secret",
            "severity": "HIGH",
            "description": "Service has hardcoded password or secret in environment",
            "remediation": "Use Docker secrets or external secret management",
            "cwe": "CWE-798",
        },
        "DC-012": {
            "title": "Security Opt Disabled",
            "severity": "HIGH",
            "description": "Service disables security features (seccomp, apparmor)",
            "remediation": "Remove security_opt overrides unless required",
            "cwe": "CWE-693",
        },
        "DC-013": {
            "title": "Run as Root",
            "severity": "MEDIUM",
            "description": "Service explicitly runs as root user",
            "remediation": "Set user to non-root UID",
            "cwe": "CWE-250",
        },
        "DC-014": {
            "title": "Writable Bind Mount",
            "severity": "LOW",
            "description": "Bind mount is writable (no :ro flag)",
            "remediation": "Add :ro to bind mounts that don't need write access",
            "cwe": "CWE-732",
        },
    }

    # Dangerous capabilities
    DANGEROUS_CAPS = {
        "SYS_ADMIN",
        "NET_ADMIN",
        "SYS_PTRACE",
        "SYS_RAWIO",
        "DAC_OVERRIDE",
        "NET_RAW",
        "SYS_CHROOT",
        "MKNOD",
        "AUDIT_WRITE",
        "SETFCAP",
        "ALL",
    }

    # Sensitive host paths
    SENSITIVE_PATHS = {
        "/",
        "/etc",
        "/var",
        "/root",
        "/home",
        "/usr",
        "/bin",
        "/sbin",
        "/lib",
        "/lib64",
        "/boot",
        "/sys",
        "/proc",
        "/dev",
    }

    # Secret indicators in env vars
    SECRET_PATTERNS = [
        r'(?i)password\s*[=:]\s*[\'"]?[^\s\'"]+',
        r'(?i)secret\s*[=:]\s*[\'"]?[^\s\'"]+',
        r'(?i)api_key\s*[=:]\s*[\'"]?[^\s\'"]+',
        r'(?i)token\s*[=:]\s*[\'"]?[^\s\'"]+',
        r'(?i)private_key\s*[=:]\s*[\'"]?[^\s\'"]+',
    ]

    def __init__(self):
        self.findings: List[DockerComposeFinding] = []

    def scan_directory(self, path: Path) -> List[DockerComposeFinding]:
        """Scan directory for docker-compose files"""
        if yaml is None:
            return []  # YAML not available

        self.findings = []

        compose_patterns = [
            "docker-compose.yml",
            "docker-compose.yaml",
            "docker-compose.*.yml",
            "docker-compose.*.yaml",
            "compose.yml",
            "compose.yaml",
        ]

        for pattern in compose_patterns:
            for compose_file in path.rglob(pattern):
                # Skip hidden dirs
                if any(p.startswith(".") for p in compose_file.parts):
                    continue
                if "node_modules" in compose_file.parts:
                    continue

                self._scan_file(compose_file)

        return self.findings

    def _scan_file(self, file_path: Path) -> None:
        """Scan a single docker-compose file"""
        if yaml is None:
            return

        try:
            content = file_path.read_text()
            doc = yaml.safe_load(content)

            if not doc or not isinstance(doc, dict):
                return

            # Get services (v2 and v3 format)
            services = doc.get("services", {})
            if not services:
                # v1 format - top-level services
                services = {k: v for k, v in doc.items() if isinstance(v, dict) and "image" in v or "build" in v}

            for service_name, service_config in services.items():
                if isinstance(service_config, dict):
                    self._scan_service(service_config, file_path, service_name)

        except yaml.YAMLError:
            pass
        except Exception:
            pass

    def _scan_service(self, service: Dict, file_path: Path, service_name: str) -> None:
        """Scan a single service definition"""

        # DC-001: Privileged
        if service.get("privileged", False):
            self._add_finding("DC-001", file_path, service_name)

        # DC-002: Dangerous capabilities
        cap_add = service.get("cap_add", [])
        dangerous = set(cap_add) & self.DANGEROUS_CAPS
        if dangerous:
            self._add_finding("DC-002", file_path, service_name, description=f"Dangerous capabilities: {dangerous}")

        # DC-003: Host network
        if service.get("network_mode") == "host":
            self._add_finding("DC-003", file_path, service_name)

        # DC-004: Host PID
        if service.get("pid") == "host":
            self._add_finding("DC-004", file_path, service_name)

        # Check volumes
        volumes = service.get("volumes", [])
        for vol in volumes:
            self._check_volume(vol, file_path, service_name)

        # DC-007/008: Resource limits
        has_mem_limit = False
        has_cpu_limit = False

        # Check legacy format
        if "mem_limit" in service or "memory" in service:
            has_mem_limit = True
        if "cpus" in service or "cpu_shares" in service:
            has_cpu_limit = True

        # Check deploy format (Compose v3)
        deploy = service.get("deploy", {})
        resources = deploy.get("resources", {})
        limits = resources.get("limits", {})
        if "memory" in limits:
            has_mem_limit = True
        if "cpus" in limits:
            has_cpu_limit = True

        if not has_mem_limit:
            self._add_finding("DC-007", file_path, service_name)
        if not has_cpu_limit:
            self._add_finding("DC-008", file_path, service_name)

        # DC-009: Port exposure
        ports = service.get("ports", [])
        for port in ports:
            port_str = str(port)
            # Check if exposed to all interfaces
            if ":" in port_str and not port_str.startswith("127."):
                # Format: "8080:80" or "0.0.0.0:8080:80"
                if not any(port_str.startswith(p) for p in ["127.", "localhost"]):
                    self._add_finding(
                        "DC-009",
                        file_path,
                        service_name,
                        description=f"Port {port_str} exposed to all interfaces",
                    )
                    break  # One finding per service

        # DC-010: Latest tag
        image = service.get("image", "")
        if image:
            if ":latest" in image or (":" not in image and "@" not in image):
                self._add_finding("DC-010", file_path, service_name, description=f"Image '{image}' uses mutable tag")

        # DC-011: Hardcoded secrets in environment
        environment = service.get("environment", {})
        if isinstance(environment, list):
            environment = {e.split("=")[0]: e.split("=")[1] if "=" in e else "" for e in environment}

        for key, value in environment.items():
            if value and isinstance(value, str):
                for pattern in self.SECRET_PATTERNS:
                    if re.search(pattern, f"{key}={value}"):
                        self._add_finding(
                            "DC-011",
                            file_path,
                            service_name,
                            description=f"Possible hardcoded secret in {key}",
                        )
                        break

        # DC-012: Security options disabled
        security_opt = service.get("security_opt", [])
        dangerous_opts = [
            opt for opt in security_opt if "unconfined" in str(opt).lower() or "disable" in str(opt).lower()
        ]
        if dangerous_opts:
            self._add_finding("DC-012", file_path, service_name, description=f"Security disabled: {dangerous_opts}")

        # DC-013: Run as root
        user = service.get("user", "")
        if user in ("root", "0", "0:0"):
            self._add_finding("DC-013", file_path, service_name)

    def _check_volume(self, volume, file_path: Path, service_name: str) -> None:
        """Check a volume mount for security issues"""
        vol_str = str(volume)

        # Parse volume string
        if isinstance(volume, dict):
            source = volume.get("source", "")
            read_only = volume.get("read_only", False)
        else:
            parts = vol_str.split(":")
            source = parts[0] if parts else ""
            read_only = len(parts) > 2 and "ro" in parts[2]

        # DC-006: Docker socket
        if "docker.sock" in source:
            self._add_finding("DC-006", file_path, service_name, description=f"Docker socket mounted: {source}")
            return

        # DC-005: Sensitive paths
        source_path = Path(source).resolve() if source.startswith("/") else None
        if source_path:
            for sensitive in self.SENSITIVE_PATHS:
                if str(source_path) == sensitive or str(source_path).startswith(sensitive + "/"):
                    # Check for really dangerous ones
                    really_dangerous = source in ["/", "/etc", "/var", "/root"]
                    if really_dangerous or source.startswith("/root/") or "/.ssh" in source or "/.aws" in source:
                        self._add_finding(
                            "DC-005", file_path, service_name, description=f"Sensitive path mounted: {source}"
                        )
                        return

        # DC-014: Writable bind mount
        if source.startswith("/") or source.startswith("./") or source.startswith("../"):
            if not read_only and "ro" not in vol_str:
                # Don't flag if it's likely data dir
                if not any(d in source.lower() for d in ["data", "logs", "tmp", "var"]):
                    self._add_finding("DC-014", file_path, service_name, description=f"Writable bind mount: {source}")

    def _add_finding(self, rule_id: str, file_path: Path, service_name: str, description: str = None) -> None:
        """Add a finding"""
        rule = self.RULES.get(rule_id, {})

        finding = DockerComposeFinding(
            rule_id=rule_id,
            severity=rule.get("severity", "MEDIUM"),
            title=rule.get("title", rule_id),
            description=description or rule.get("description", ""),
            file_path=str(file_path),
            service_name=service_name,
            remediation=rule.get("remediation", ""),
        )
        self.findings.append(finding)

    def to_dict(self) -> List[Dict]:
        """Convert findings to dictionary format"""
        return [
            {
                "type": "CONFIG",
                "subtype": "DOCKER_COMPOSE",
                "rule_id": f.rule_id,
                "severity": f.severity,
                "title": f.title,
                "description": f.description,
                "file": f.file_path,
                "service": f.service_name,
                "remediation": f.remediation,
                "reachability": "UNKNOWN",
            }
            for f in self.findings
        ]


def scan_docker_compose(path: Path) -> List[Dict]:
    """Convenience function to scan Docker Compose files"""
    scanner = DockerComposeScanner()
    scanner.scan_directory(path)
    return scanner.to_dict()


if __name__ == "__main__":
    import sys

    if len(sys.argv) < 2:
        logger.info("Usage: python docker_compose_scanner.py <path>")
        sys.exit(1)

    path = Path(sys.argv[1])
    findings = scan_docker_compose(path)

    logger.info(f"Found {len(findings)} Docker Compose security issues:")
    for f in findings:
        logger.info(f" [{f['severity']}] {f['rule_id']}: {f['title']}")
        logger.info(f" Service '{f['service']}' in {f['file']}")
