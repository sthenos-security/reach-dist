#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.

"""
REACHABLE Data Consistency Fixes v4.5.39

This module patches database_storage.py to fix:
1. DLP call_paths field mismatch (call_paths vs call_path)
2. risk_level not being derived from severity
3. Findings table not receiving reachability paths

Apply by importing this module before using RepoDatabase:
    from reachable.fixes.data_consistency_fixes import apply_fixes
    apply_fixes()

Or run as standalone:
    python -m reachable.fixes.data_consistency_fixes
"""

import json
import logging
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)


def derive_risk_level(severity: str) -> str:
    """
    Derive risk_level from severity when not explicitly set.

    Maps REACHABLE severity to risk level with SLA guidance:
    - CRITICAL → CRITICAL (24h SLA)
    - HIGH → HIGH (7 day SLA)
    - MEDIUM → MEDIUM (30 day SLA)
    - LOW → LOW (90 day SLA)
    - WARNING → LOW (best effort)
    - ERROR → HIGH (immediate)
    - INFO → INFO (no SLA)
    """
    severity_upper = (severity or "MEDIUM").upper()

    mapping = {
        "CRITICAL": "CRITICAL",
        "HIGH": "HIGH",
        "MEDIUM": "MEDIUM",
        "LOW": "LOW",
        "WARNING": "LOW",
        "ERROR": "HIGH",
        "INFO": "INFO",
    }

    return mapping.get(severity_upper, "MEDIUM")


def get_call_path(finding: Dict[str, Any]) -> Optional[str]:
    """
    Extract call path from finding, handling multiple field names.

    Checks for: call_path, call_paths, reachability_path, propagation_path
    """
    # Try different field names (singular and plural variants)
    for key in ["call_paths_v2", "reachability_path", "propagation_path"]:
        path = finding.get(key)
        if path:
            if isinstance(path, str):
                return path
            elif isinstance(path, list) and len(path) > 0:
                return json.dumps(path)

    return None


def apply_fixes():
    """
    Monkey-patch RepoDatabase to fix data consistency issues.

    This should be called early in application startup.
    """
    try:
        from reachable.database.storage import RepoDatabase
    except ImportError:
        logger.info("Warning: Could not import RepoDatabase for patching")
        return False

    # Store original methods
    original_store_findings = RepoDatabase.store_findings
    original_store_dlp_findings = RepoDatabase.store_dlp_findings

    def patched_store_findings(self, findings: List[Dict[str, Any]], finding_type: str) -> int:
        """
        Patched store_findings that:
        1. Derives risk_level from severity when not set
        2. Handles multiple call path field names
        """
        if not findings:
            return 0

        # Pre-process findings to fix data
        for f in findings:
            # Fix 1: Derive risk_level if not set
            if not f.get("risk_level"):
                f["risk_level"] = derive_risk_level(f.get("severity", "MEDIUM"))

            # Fix 2: Normalize call path field
            if not f.get("call_paths_v2") and not f.get("reachability_path"):
                path = get_call_path(f)
                if path:
                    try:
                        f["reachability_path"] = json.loads(path) if path.startswith("[") else [path]
                    except json.JSONDecodeError:
                        f["reachability_path"] = [path]

        # Call original
        return original_store_findings(self, findings, finding_type)

    def patched_store_dlp_findings(self, dlp_findings: List[Dict[str, Any]]) -> int:
        """
        Patched store_dlp_findings that handles call_paths vs call_path mismatch.
        """
        if not dlp_findings:
            return 0

        # Pre-process findings to fix field name mismatch
        for f in dlp_findings:
            # Handle both dict and object
            if hasattr(f, "to_dict"):
                f_dict = f.to_dict()
            else:
                f_dict = f

            # Fix: Copy call_paths to call_path if needed
            if not f_dict.get("call_paths_v2") and f_dict.get("call_paths_v2_legacy"):
                if isinstance(f, dict):
                    f["call_paths_v2"] = f_dict.get("call_paths_v2", [])
                else:
                    # For objects, try to set attribute
                    try:
                        f.call_paths_v2 = f_dict.get("call_paths_v2", [])
                    except AttributeError:
                        pass

        # Call original
        return original_store_dlp_findings(self, dlp_findings)

    # Apply patches
    RepoDatabase.store_findings = patched_store_findings
    RepoDatabase.store_dlp_findings = patched_store_dlp_findings

    logger.info(" Data consistency fixes applied to RepoDatabase")
    return True


if __name__ == "__main__":
    logger.info("REACHABLE Data Consistency Fixes v4.5.39")
    logger.info("=" * 50)
    logger.info("")

    success = apply_fixes()
    if success:
        logger.info("\nFixes applied successfully!")
    else:
        logger.info("\nFailed to apply runtime fixes.")
        logger.info("Please apply the direct edits below:")
        logger.info("")
        logger.info("=" * 50)
        logger.info("DIRECT EDITS TO database_storage.py")
        logger.info("=" * 50)
        logger.info("""
In store_findings() method, around line 380, change:

FROM:
    f.get('risk_level'),

TO:
    f.get('risk_level') or self._derive_risk_level(f.get('severity', 'MEDIUM')),

AND change:
    json.dumps(f.get('reachability_path', [])) if f.get('reachability_path') else None,

TO:
    json.dumps(f.get('reachability_path', [])) if f.get('reachability_path') else None,

---

In store_dlp_findings() method, around line 450, change:

FROM:
    json.dumps(f.get('call_paths_v2', [])) if f.get('call_paths_v2') else None,

TO:
    json.dumps(f.get('call_paths_v2', [])) if f.get('call_paths_v2') else None,

---

Add this method to the RepoDatabase class:

    def _derive_risk_level(self, severity: str) -> str:
        \"\"\"Derive risk_level from severity for SLA guidance.\"\"\"
        severity_upper = (severity or 'MEDIUM').upper()
        mapping = {
            'CRITICAL': 'CRITICAL',
            'HIGH': 'HIGH',
            'MEDIUM': 'MEDIUM',
            'LOW': 'LOW',
            'WARNING': 'LOW',
            'ERROR': 'HIGH',
            'INFO': 'INFO',
        }
        return mapping.get(severity_upper, 'MEDIUM')
""")
