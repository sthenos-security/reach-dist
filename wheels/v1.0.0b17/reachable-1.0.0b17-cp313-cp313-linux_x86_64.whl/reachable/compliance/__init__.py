# Copyright © 2026 Sthenos Security. All rights reserved.

"""
REACHABLE Compliance Framework Mapping

Maps REACHABLE capabilities and scan findings to major compliance frameworks:
SOC 2, SLSA, NIST SSDF, ISO 27001, FedRAMP, PCI DSS 4.0, STRIDE.

Usage:
    from reachable.compliance import ComplianceEvaluator, Framework
    from reachable.compliance import generate_compliance_report
"""

# Audit report generator
from .audit_report import STANDARD_LINKS, generate_all_audit_reports, generate_audit_report_html

# Capabilities
from .capabilities import REACHABLE_CAPABILITIES

# Evaluator
from .evaluator import (
    ComplianceEvaluator,
    generate_compliance_report,
    get_framework_controls,
    list_all_frameworks,
)

# Framework controls
from .frameworks import (
    FEDRAMP_CONTROLS,
    ISO27001_CONTROLS,
    PCI_DSS_CONTROLS,
    SLSA_CONTROLS,
    SOC2_CONTROLS,
    SSDF_CONTROLS,
)

# Models
from .models import (
    Control,
    ControlResult,
    ControlStatus,
    Framework,
    FrameworkReport,
    Severity,
    ThreatCategory,
)

# STRIDE
from .stride import (
    STRIDE_CONTROLS,
    STRIDE_POLICY_MAP,
    get_stride_mapping_for_event,
    get_stride_mapping_for_finding,
)

__all__ = [
    # Models
    "Framework",
    "ThreatCategory",
    "ControlStatus",
    "Severity",
    "Control",
    "ControlResult",
    "FrameworkReport",
    # Capabilities
    "REACHABLE_CAPABILITIES",
    # Controls
    "SOC2_CONTROLS",
    "SLSA_CONTROLS",
    "SSDF_CONTROLS",
    "ISO27001_CONTROLS",
    "FEDRAMP_CONTROLS",
    "PCI_DSS_CONTROLS",
    "STRIDE_CONTROLS",
    "STRIDE_POLICY_MAP",
    # STRIDE helpers
    "get_stride_mapping_for_finding",
    "get_stride_mapping_for_event",
    # Evaluator
    "ComplianceEvaluator",
    "generate_compliance_report",
    "get_framework_controls",
    "list_all_frameworks",
    # Audit reports
    "STANDARD_LINKS",
    "generate_audit_report_html",
    "generate_all_audit_reports",
]
