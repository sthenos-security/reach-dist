# Copyright © 2026 Sthenos Security. All rights reserved.

"""
Compliance audit report HTML generator.
"""

import json
from datetime import datetime
from pathlib import Path
from typing import Any, Dict

from .evaluator import generate_compliance_report
from .models import Framework

# Official documentation links for each standard
STANDARD_LINKS = {
    "SOC2": {
        "name": "SOC 2 Type II",
        "url": "https://www.aicpa.org/topic/audit-assurance/audit-and-assurance-greater-than-soc-2",
        "description": "AICPA Service Organization Control 2",
        "icon": "",
    },
    "SLSA": {
        "name": "SLSA (Supply Chain Levels)",
        "url": "https://slsa.dev/spec/v1.0/",
        "description": "Supply-chain Levels for Software Artifacts",
        "icon": "",
    },
    "SSDF": {
        "name": "NIST SSDF",
        "url": "https://csrc.nist.gov/publications/detail/sp/800-218/final",
        "description": "NIST SP 800-218 Secure Software Development Framework",
        "icon": "",
    },
    "ISO27001": {
        "name": "ISO/IEC 27001:2022",
        "url": "https://www.iso.org/standard/27001",
        "description": "Information Security Management Systems",
        "icon": "",
    },
    "FEDRAMP": {
        "name": "FedRAMP / NIST 800-53",
        "url": "https://www.fedramp.gov/",
        "description": "Federal Risk and Authorization Management Program",
        "icon": "🇺🇸",
    },
    "PCI_DSS": {
        "name": "PCI DSS 4.0",
        "url": "https://www.pcisecuritystandards.org/document_library/",
        "description": "Payment Card Industry Data Security Standard",
        "icon": "",
    },
    "STRIDE": {
        "name": "STRIDE Threat Model",
        "url": "https://learn.microsoft.com/en-us/azure/security/develop/threat-modeling-tool-threats",
        "description": "Microsoft STRIDE Threat Modeling Framework",
        "icon": "",
    },
    "OWASP": {
        "name": "OWASP Top 10",
        "url": "https://owasp.org/Top10/",
        "description": "Open Web Application Security Project Top 10",
        "icon": "",
    },
    "HIPAA": {
        "name": "HIPAA Security Rule",
        "url": "https://www.hhs.gov/hipaa/for-professionals/security/index.html",
        "description": "Health Insurance Portability and Accountability Act",
        "icon": "",
    },
    "CMMC": {
        "name": "CMMC 2.0",
        "url": "https://dodcio.defense.gov/CMMC/",
        "description": "Cybersecurity Maturity Model Certification",
        "icon": "",
    },
    "NIST_CSF": {
        "name": "NIST CSF",
        "url": "https://www.nist.gov/cyberframework",
        "description": "NIST Cybersecurity Framework",
        "icon": "",
    },
    "CWE_TOP25": {
        "name": "CWE Top 25",
        "url": "https://cwe.mitre.org/top25/archive/2023/2023_top25_list.html",
        "description": "Common Weakness Enumeration Top 25",
        "icon": "",
    },
}


def generate_audit_report_html(
    framework_id: str,
    framework_report: Dict,
    scan_metadata: Dict,
    output_dir: str,
) -> str:
    """Generate an HTML audit report for a specific compliance framework."""
    std_info = STANDARD_LINKS.get(
        framework_id,
        {
            "name": framework_id,
            "url": "#",
            "description": "Compliance Standard",
            "icon": "",
        },
    )

    summary = framework_report.get("summary", {})
    controls = framework_report.get("controls", [])

    total = summary.get("total_controls", len(controls))
    satisfied = summary.get("satisfied", 0)
    partial = summary.get("partial", 0)
    not_satisfied = summary.get("not_satisfied", 0)
    score = summary.get("compliance_score", 0)

    if score >= 80:
        status_color, status_text = "#28a745", "COMPLIANT"
    elif score >= 60:
        status_color, status_text = "#ffc107", "PARTIAL"
    else:
        status_color, status_text = "#dc3545", "NON-COMPLIANT"

    controls_html = ""
    for ctrl in controls:
        status = ctrl.get("status", "unknown")
        badges = {
            "satisfied": '<span style="background:#28a745;color:white;padding:2px 8px;border-radius:4px;"> PASS</span>',
            "partial": '<span style="background:#ffc107;color:black;padding:2px 8px;border-radius:4px;"> PARTIAL</span>',
            "not_satisfied": '<span style="background:#dc3545;color:white;padding:2px 8px;border-radius:4px;"> FAIL</span>',
        }
        status_badge = badges.get(
            status,
            '<span style="background:#6c757d;color:white;padding:2px 8px;border-radius:4px;">N/A</span>',
        )
        evidence = "<br>".join(ctrl.get("evidence", [])[:3]) or "—"
        gaps = "<br>".join(ctrl.get("gaps", [])[:3]) or "—"
        recommendation = ctrl.get("recommendation") or "—"

        controls_html += f"""
        <tr>
            <td><strong>{ctrl.get("id", "")}</strong></td>
            <td>{ctrl.get("name", "")}</td>
            <td>{ctrl.get("category", "")}</td>
            <td>{status_badge}</td>
            <td style="font-size:12px;">{evidence}</td>
            <td style="font-size:12px;color:#dc3545;">{gaps}</td>
            <td style="font-size:12px;">{recommendation}</td>
        </tr>"""

    html = f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{std_info["name"]} Audit Report - REACHABLE</title>
    <style>
        * {{ box-sizing: border-box; margin: 0; padding: 0; }}
        body {{ font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; background: #f5f5f5; color: #333; line-height: 1.6; }}
        .container {{ max-width: 1200px; margin: 0 auto; padding: 20px; }}
        .header {{ background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%); color: white; padding: 30px; border-radius: 8px; margin-bottom: 20px; }}
        .header h1 {{ font-size: 28px; margin-bottom: 10px; }}
        .header .subtitle {{ opacity: 0.8; font-size: 14px; }}
        .header .icon {{ font-size: 48px; float: right; }}
        .summary-grid {{ display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 20px; margin-bottom: 20px; }}
        .summary-card {{ background: white; padding: 20px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); text-align: center; }}
        .summary-card .value {{ font-size: 36px; font-weight: bold; }}
        .summary-card .label {{ font-size: 12px; color: #666; text-transform: uppercase; }}
        .status-banner {{ background: {status_color}; color: white; padding: 15px 20px; border-radius: 8px; margin-bottom: 20px; display: flex; justify-content: space-between; align-items: center; }}
        .status-banner .status {{ font-size: 24px; font-weight: bold; }}
        .status-banner .score {{ font-size: 18px; }}
        .section {{ background: white; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); margin-bottom: 20px; overflow: hidden; }}
        .section-header {{ background: #f8f9fa; padding: 15px 20px; border-bottom: 1px solid #e9ecef; font-weight: bold; }}
        .section-content {{ padding: 20px; }}
        table {{ width: 100%; border-collapse: collapse; font-size: 14px; }}
        th {{ background: #f8f9fa; text-align: left; padding: 12px; border-bottom: 2px solid #dee2e6; }}
        td {{ padding: 12px; border-bottom: 1px solid #e9ecef; vertical-align: top; }}
        tr:hover {{ background: #f8f9fa; }}
        .footer {{ text-align: center; padding: 20px; color: #666; font-size: 12px; }}
        @media print {{ body {{ background: white; }} .container {{ max-width: 100%; }} }}
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <span class="icon">{std_info["icon"]}</span>
            <h1>{std_info["name"]} Compliance Audit Report</h1>
            <div class="subtitle">
                Generated by REACHABLE | {scan_metadata.get("timestamp", datetime.now().isoformat())}<br>
                Repository: {scan_metadata.get("repo_name", "Unknown")} | Branch: {scan_metadata.get("git_branch", "main")}
            </div>
        </div>
        <div class="status-banner">
            <span class="status">{status_text}</span>
            <span class="score">Compliance Score: {score:.1f}%</span>
        </div>
        <div class="summary-grid">
            <div class="summary-card"><div class="value" style="color:#28a745;">{satisfied}</div><div class="label">Controls Satisfied</div></div>
            <div class="summary-card"><div class="value" style="color:#ffc107;">{partial}</div><div class="label">Partial Compliance</div></div>
            <div class="summary-card"><div class="value" style="color:#dc3545;">{not_satisfied}</div><div class="label">Not Satisfied</div></div>
            <div class="summary-card"><div class="value">{total}</div><div class="label">Total Controls</div></div>
        </div>
        <div class="section">
            <div class="section-header"> Control Assessment Details</div>
            <div class="section-content">
                <table>
                    <thead><tr><th>Control ID</th><th>Control Name</th><th>Category</th><th>Status</th><th>Evidence</th><th>Gaps</th><th>Recommendation</th></tr></thead>
                    <tbody>{controls_html}</tbody>
                </table>
            </div>
        </div>
        <div class="section">
            <div class="section-header"> Reference Links</div>
            <div class="section-content">
                <p><strong>{std_info["name"]}</strong>: {std_info["description"]}</p>
                <p><a href="{std_info["url"]}" target="_blank"> Official Documentation</a></p>
            </div>
        </div>
        <div class="footer"><p>REACHABLE Compliance Audit Report | &copy; 2026 Sthenos Security | Confidential</p></div>
    </div>
</body>
</html>"""

    output_path = Path(output_dir) / f"audit-{framework_id.lower()}.html"
    with open(output_path, "w") as f:
        f.write(html)
    return str(output_path)


def generate_all_audit_reports(
    scan_results: Dict[str, Any],
    output_dir: str,
) -> Dict[str, str]:
    """Generate audit reports for all compliance frameworks."""
    compliance_report = generate_compliance_report(scan_results)

    scan_metadata = {
        "timestamp": scan_results.get("metadata", {}).get("scan_timestamp", ""),
        "repo_name": scan_results.get("metadata", {}).get("analysis_target", {}).get("repo_name", "Unknown"),
        "git_branch": scan_results.get("metadata", {}).get("analysis_target", {}).get("git_branch", "main"),
        "scan_id": scan_results.get("metadata", {}).get("scan_id", ""),
    }

    reports = {}
    for framework in Framework:
        fw_id = framework.name
        fw_name = framework.value
        if fw_name in compliance_report:
            report_path = generate_audit_report_html(
                framework_id=fw_id,
                framework_report=compliance_report[fw_name],
                scan_metadata=scan_metadata,
                output_dir=output_dir,
            )
            reports[fw_id] = report_path

    combined_path = Path(output_dir) / "compliance-report.json"
    with open(combined_path, "w") as f:
        json.dump(compliance_report, f, indent=2)
    reports["_json"] = str(combined_path)

    return reports
