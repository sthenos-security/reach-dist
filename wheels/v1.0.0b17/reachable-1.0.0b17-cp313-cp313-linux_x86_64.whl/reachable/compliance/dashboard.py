# Copyright © 2026 Sthenos Security. All rights reserved.

"""
REACHABLE Compliance Dashboard Integration

Provides dashboard-ready compliance visualizations and widgets.
"""

from dataclasses import dataclass
from datetime import datetime
from typing import Any, Dict, List, Optional

from . import ComplianceEvaluator, ControlStatus, Framework, Severity


@dataclass
class ComplianceWidget:
    """Dashboard widget data for compliance display"""

    # Overall metrics
    overall_score: float
    overall_status: str
    frameworks_evaluated: int

    # Per-framework scores
    framework_scores: Dict[str, float]

    # Status distribution
    satisfied_count: int
    partial_count: int
    failed_count: int

    # Critical gaps requiring attention
    critical_gaps: List[Dict[str, str]]

    # Trend data (if available)
    trend_data: Optional[List[Dict]] = None

    def to_dict(self) -> Dict[str, Any]:
        return {
            "widget_type": "compliance_summary",
            "overall": {
                "score": round(self.overall_score, 1),
                "status": self.overall_status,
                "status_color": self._status_color(self.overall_status),
                "frameworks_evaluated": self.frameworks_evaluated,
            },
            "framework_scores": {
                k: {"score": round(v, 1), "status": self._score_to_status(v)} for k, v in self.framework_scores.items()
            },
            "distribution": {
                "satisfied": self.satisfied_count,
                "partial": self.partial_count,
                "failed": self.failed_count,
                "total": self.satisfied_count + self.partial_count + self.failed_count,
            },
            "critical_gaps": self.critical_gaps[:5],  # Top 5 gaps
            "trend": self.trend_data,
        }

    def _score_to_status(self, score: float) -> str:
        if score >= 90:
            return "compliant"
        elif score >= 70:
            return "mostly_compliant"
        elif score >= 50:
            return "partial"
        else:
            return "non_compliant"

    def _status_color(self, status: str) -> str:
        colors = {
            "compliant": "#22C55E",  # green
            "mostly_compliant": "#EAB308",  # yellow
            "partial": "#F97316",  # orange
            "non_compliant": "#EF4444",  # red
        }
        return colors.get(status, "#6B7280")


class ComplianceDashboard:
    """Generate dashboard-ready compliance data"""

    def __init__(self, evaluator: ComplianceEvaluator):
        self.evaluator = evaluator

    def generate_widget(self, scan_id: str = "scan-001") -> ComplianceWidget:
        """Generate main compliance widget data"""

        reports = self.evaluator.evaluate_all_frameworks(scan_id)

        # Calculate totals
        total_satisfied = sum(r.satisfied for r in reports.values())
        total_partial = sum(r.partial for r in reports.values())
        total_failed = sum(r.not_satisfied for r in reports.values())

        # Framework scores
        framework_scores = {name: report.compliance_score for name, report in reports.items()}

        # Overall score
        overall_score = sum(framework_scores.values()) / len(framework_scores) if framework_scores else 0

        # Determine status
        if overall_score >= 90:
            status = "compliant"
        elif overall_score >= 70:
            status = "mostly_compliant"
        elif overall_score >= 50:
            status = "partial"
        else:
            status = "non_compliant"

        # Get critical gaps
        critical_gaps = []
        for name, report in reports.items():
            for cr in report.controls:
                if cr.status == ControlStatus.NOT_SATISFIED and cr.control.severity == Severity.CRITICAL:
                    critical_gaps.append(
                        {
                            "framework": name,
                            "control": cr.control.id,
                            "name": cr.control.name,
                            "recommendation": cr.recommendation or "Review and remediate",
                        }
                    )

        return ComplianceWidget(
            overall_score=overall_score,
            overall_status=status,
            frameworks_evaluated=len(reports),
            framework_scores=framework_scores,
            satisfied_count=total_satisfied,
            partial_count=total_partial,
            failed_count=total_failed,
            critical_gaps=critical_gaps,
        )

    def generate_framework_detail(self, framework: Framework, scan_id: str = "scan-001") -> Dict[str, Any]:
        """Generate detailed view for a single framework"""

        report = self.evaluator.evaluate_framework(framework, scan_id)

        # Group controls by category
        categories = {}
        for cr in report.controls:
            cat = cr.control.category
            if cat not in categories:
                categories[cat] = {"name": cat, "controls": [], "satisfied": 0, "partial": 0, "failed": 0}

            categories[cat]["controls"].append(
                {
                    "id": cr.control.id,
                    "name": cr.control.name,
                    "severity": cr.control.severity.value,
                    "status": cr.status.value,
                    "evidence": cr.evidence,
                    "gaps": cr.gaps,
                    "recommendation": cr.recommendation,
                }
            )

            if cr.status == ControlStatus.SATISFIED:
                categories[cat]["satisfied"] += 1
            elif cr.status == ControlStatus.PARTIAL:
                categories[cat]["partial"] += 1
            elif cr.status == ControlStatus.NOT_SATISFIED:
                categories[cat]["failed"] += 1

        return {
            "framework": framework.value,
            "scan_id": scan_id,
            "timestamp": datetime.utcnow().isoformat() + "Z",
            "summary": {
                "score": round(report.compliance_score, 1),
                "total_controls": report.total_controls,
                "satisfied": report.satisfied,
                "partial": report.partial,
                "not_satisfied": report.not_satisfied,
                "not_applicable": report.not_applicable,
            },
            "categories": list(categories.values()),
        }

    def generate_control_matrix(self) -> Dict[str, Any]:
        """Generate capability-to-control mapping matrix"""

        from . import REACHABLE_CAPABILITIES

        # Build matrix showing which capabilities satisfy which controls
        matrix = {}

        for cap_id, cap_info in REACHABLE_CAPABILITIES.items():
            matrix[cap_id] = {
                "name": cap_info["name"],
                "description": cap_info["description"],
                "frameworks": {},
            }

        # Map controls to capabilities
        for framework, controls in ComplianceEvaluator.FRAMEWORK_CONTROLS.items():
            for control in controls:
                for cap in control.capabilities:
                    if cap in matrix:
                        fw_name = framework.value
                        if fw_name not in matrix[cap]["frameworks"]:
                            matrix[cap]["frameworks"][fw_name] = []
                        matrix[cap]["frameworks"][fw_name].append(
                            {
                                "id": control.id,
                                "name": control.name,
                                "severity": control.severity.value,
                            }
                        )

        return {"matrix_type": "capability_control_mapping", "capabilities": matrix}

    def generate_gap_analysis(self, scan_id: str = "scan-001") -> Dict[str, Any]:
        """Generate gap analysis report"""

        reports = self.evaluator.evaluate_all_frameworks(scan_id)

        # Categorize gaps by severity
        critical_gaps = []
        high_gaps = []
        medium_gaps = []

        for name, report in reports.items():
            for cr in report.controls:
                if cr.status in (ControlStatus.NOT_SATISFIED, ControlStatus.PARTIAL):
                    gap = {
                        "framework": name,
                        "control_id": cr.control.id,
                        "control_name": cr.control.name,
                        "status": cr.status.value,
                        "severity": cr.control.severity.value,
                        "category": cr.control.category,
                        "capabilities_needed": cr.control.capabilities,
                        "recommendation": cr.recommendation,
                        "gaps": cr.gaps,
                    }

                    if cr.control.severity == Severity.CRITICAL:
                        critical_gaps.append(gap)
                    elif cr.control.severity == Severity.HIGH:
                        high_gaps.append(gap)
                    else:
                        medium_gaps.append(gap)

        return {
            "analysis_type": "compliance_gap_analysis",
            "scan_id": scan_id,
            "timestamp": datetime.utcnow().isoformat() + "Z",
            "summary": {
                "critical_gaps": len(critical_gaps),
                "high_gaps": len(high_gaps),
                "medium_gaps": len(medium_gaps),
                "total_gaps": len(critical_gaps) + len(high_gaps) + len(medium_gaps),
            },
            "gaps_by_severity": {"critical": critical_gaps, "high": high_gaps, "medium": medium_gaps},
            "remediation_priority": [
                *critical_gaps[:10],  # Top 10 critical
                *high_gaps[:5],  # Top 5 high
            ],
        }


def create_dashboard_html_widget(widget: ComplianceWidget) -> str:
    """Generate HTML snippet for embedding in dashboard"""

    data = widget.to_dict()

    status_icons = {"compliant": "", "mostly_compliant": "", "partial": "", "non_compliant": ""}

    icon = status_icons.get(data["overall"]["status"], "")
    color = data["overall"]["status_color"]

    # Generate framework bars
    framework_bars = ""
    for fw_name, fw_data in data["framework_scores"].items():
        bar_width = fw_data["score"]
        framework_bars += f"""
        <div class="compliance-framework">
            <span class="fw-name">{fw_name}</span>
            <div class="progress-bar">
                <div class="progress" style="width: {bar_width}%"></div>
            </div>
            <span class="fw-score">{fw_data["score"]}%</span>
        </div>
        """

    # Generate gaps list
    gaps_html = ""
    for gap in data["critical_gaps"][:3]:
        gaps_html += f"""
        <div class="gap-item">
            <span class="gap-control">{gap["control"]}</span>
            <span class="gap-framework">{gap["framework"]}</span>
        </div>
        """

    html = f"""
    <div class="compliance-widget" style="font-family: system-ui, sans-serif;">
        <div class="compliance-header" style="display: flex; align-items: center; gap: 12px; margin-bottom: 16px;">
            <span style="font-size: 32px;">{icon}</span>
            <div>
                <div style="font-size: 28px; font-weight: bold; color: {color};">{data["overall"]["score"]}%</div>
                <div style="font-size: 14px; color: #666;">Compliance Score</div>
            </div>
        </div>

        <div class="compliance-distribution" style="display: flex; gap: 16px; margin-bottom: 16px;">
            <div style="text-align: center;">
                <div style="font-size: 24px; color: #22C55E;">{data["distribution"]["satisfied"]}</div>
                <div style="font-size: 12px; color: #666;">Satisfied</div>
            </div>
            <div style="text-align: center;">
                <div style="font-size: 24px; color: #EAB308;">{data["distribution"]["partial"]}</div>
                <div style="font-size: 12px; color: #666;">Partial</div>
            </div>
            <div style="text-align: center;">
                <div style="font-size: 24px; color: #EF4444;">{data["distribution"]["failed"]}</div>
                <div style="font-size: 12px; color: #666;">Failed</div>
            </div>
        </div>

        <div class="compliance-frameworks" style="margin-bottom: 16px;">
            <div style="font-weight: bold; margin-bottom: 8px;">Framework Scores</div>
            {framework_bars}
        </div>

        <div class="compliance-gaps">
            <div style="font-weight: bold; color: #EF4444; margin-bottom: 8px;">Critical Gaps</div>
            {gaps_html if gaps_html else '<div style="color: #22C55E;">No critical gaps!</div>'}
        </div>
    </div>

    <style>
        .compliance-framework {{
            display: flex;
            align-items: center;
            gap: 8px;
            margin-bottom: 4px;
        }}
        .fw-name {{
            width: 120px;
            font-size: 12px;
        }}
        .progress-bar {{
            flex: 1;
            height: 8px;
            background: #E5E7EB;
            border-radius: 4px;
            overflow: hidden;
        }}
        .progress {{
            height: 100%;
            background: linear-gradient(90deg, #22C55E, #4ADE80);
            border-radius: 4px;
        }}
        .fw-score {{
            width: 40px;
            font-size: 12px;
            text-align: right;
        }}
        .gap-item {{
            display: flex;
            justify-content: space-between;
            padding: 4px 0;
            border-bottom: 1px solid #E5E7EB;
            font-size: 12px;
        }}
        .gap-control {{
            font-weight: 500;
        }}
        .gap-framework {{
            color: #666;
        }}
    </style>
    """

    return html
