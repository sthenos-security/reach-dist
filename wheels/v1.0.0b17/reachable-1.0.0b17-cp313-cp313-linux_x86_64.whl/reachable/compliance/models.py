# Copyright © 2026 Sthenos Security. All rights reserved.

"""
Compliance data models: enums, dataclasses for controls and reports.
"""

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional


class Framework(Enum):
    """Supported compliance frameworks"""

    SOC2 = "SOC 2 Type II"
    SLSA = "SLSA"
    SSDF = "NIST SSDF"
    ISO27001 = "ISO/IEC 27001:2022"
    FEDRAMP = "FedRAMP / NIST 800-53"
    PCI_DSS = "PCI DSS 4.0"
    STRIDE = "STRIDE Threat Model"
    DORA = "DORA (Digital Operational Resilience Act)"
    NIS2 = "NIS2 Directive"
    GDPR = "GDPR"


class ThreatCategory(Enum):
    """STRIDE threat categories"""

    SPOOFING = "Spoofing"
    TAMPERING = "Tampering"
    REPUDIATION = "Repudiation"
    INFORMATION_DISCLOSURE = "Information Disclosure"
    DENIAL_OF_SERVICE = "Denial of Service"
    ELEVATION_OF_PRIVILEGE = "Elevation of Privilege"


class ControlStatus(Enum):
    """Status of a compliance control"""

    SATISFIED = "satisfied"
    PARTIAL = "partial"
    NOT_SATISFIED = "not_satisfied"
    NOT_APPLICABLE = "n/a"
    REQUIRES_REVIEW = "requires_review"


class Severity(Enum):
    """Control importance for compliance"""

    CRITICAL = "critical"
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"


@dataclass
class Control:
    """A single compliance control/requirement"""

    id: str
    name: str
    description: str
    framework: Framework
    severity: Severity
    category: str
    capabilities: List[str] = field(default_factory=list)
    violation_indicators: List[str] = field(default_factory=list)
    evidence_types: List[str] = field(default_factory=list)


@dataclass
class ControlResult:
    """Result of evaluating a control against scan findings"""

    control: Control
    status: ControlStatus
    evidence: List[str] = field(default_factory=list)
    gaps: List[str] = field(default_factory=list)
    findings_count: int = 0
    recommendation: Optional[str] = None


@dataclass
class FrameworkReport:
    """Compliance report for a single framework"""

    framework: Framework
    scan_id: str
    timestamp: str
    total_controls: int
    satisfied: int
    partial: int
    not_satisfied: int
    not_applicable: int
    compliance_score: float
    controls: List[ControlResult] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "framework": self.framework.value,
            "scan_id": self.scan_id,
            "timestamp": self.timestamp,
            "summary": {
                "total_controls": self.total_controls,
                "satisfied": self.satisfied,
                "partial": self.partial,
                "not_satisfied": self.not_satisfied,
                "not_applicable": self.not_applicable,
                "compliance_score": round(self.compliance_score, 1),
            },
            "controls": [
                {
                    "id": cr.control.id,
                    "name": cr.control.name,
                    "category": cr.control.category,
                    "severity": cr.control.severity.value,
                    "status": cr.status.value,
                    "evidence": cr.evidence,
                    "gaps": cr.gaps,
                    "findings_count": cr.findings_count,
                    "recommendation": cr.recommendation,
                }
                for cr in self.controls
            ],
        }
