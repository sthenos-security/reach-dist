# Copyright © 2026 Sthenos Security. All rights reserved.

"""
REACHABLE capability definitions for compliance mapping.
"""

REACHABLE_CAPABILITIES = {
    "sbom_generation": {
        "name": "SBOM Generation",
        "description": "Generate Software Bill of Materials using Syft",
        "evidence": "SBOM document in CycloneDX/SPDX format",
    },
    "vulnerability_scanning": {
        "name": "Vulnerability Scanning",
        "description": "CVE detection using Grype and multiple databases",
        "evidence": "Vulnerability report with CVE IDs and severity",
    },
    "reachability_analysis": {
        "name": "Reachability Analysis",
        "description": "Determine if vulnerable code is actually executed",
        "evidence": "Reachability score and call graph analysis",
    },
    "malware_detection": {
        "name": "Malware Detection",
        "description": "Static malware scanning with GuardDog and YARA",
        "evidence": "Malware scan results with rule matches",
    },
    "sandbox_behavioral": {
        "name": "Behavioral Sandbox",
        "description": "Install-time behavioral analysis in isolated container",
        "evidence": "Sandbox verdict and capability score",
    },
    "secrets_detection": {
        "name": "Secrets Detection",
        "description": "Detect hardcoded secrets and credentials",
        "evidence": "Secrets scan results with locations",
    },
    "env_config_secrets": {
        "name": "ENV-001 Config Secrets",
        "description": "Detect secrets in .env files, CI/CD configs, K8s manifests (Base64 decoded)",
        "evidence": "ENV-001 findings with decoded secrets and remediation",
    },
    "license_compliance": {
        "name": "License Compliance",
        "description": "Identify and validate open source licenses",
        "evidence": "License inventory and policy violations",
    },
    "provenance_verification": {
        "name": "Provenance Verification",
        "description": "Verify package authenticity and signatures",
        "evidence": "Signature verification results",
    },
    "vex_generation": {
        "name": "VEX Document Generation",
        "description": "Generate Vulnerability Exploitability eXchange documents",
        "evidence": "VEX document with exploitability assessments",
    },
    "audit_logging": {
        "name": "Audit Logging",
        "description": "Immutable audit trail of all scan activities",
        "evidence": "Audit log entries with timestamps",
    },
    "policy_enforcement": {
        "name": "Policy Enforcement",
        "description": "Configurable security policies with automated enforcement",
        "evidence": "Policy evaluation results",
    },
    "ci_cd_integration": {
        "name": "CI/CD Integration",
        "description": "Automated scanning in build pipelines",
        "evidence": "CI/CD scan execution logs",
    },
    "dependency_graph": {
        "name": "Dependency Graph Analysis",
        "description": "Full transitive dependency mapping",
        "evidence": "Dependency tree visualization",
    },
    "epss_scoring": {
        "name": "EPSS Scoring",
        "description": "Exploit Prediction Scoring System integration",
        "evidence": "EPSS probability scores",
    },
    "kev_checking": {
        "name": "KEV Catalog Checking",
        "description": "CISA Known Exploited Vulnerabilities checking",
        "evidence": "KEV match results",
    },
}
