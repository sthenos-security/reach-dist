# Copyright © 2026 Sthenos Security. All rights reserved.

"""
Compliance evaluator — scores scan results against framework controls.
"""

from datetime import datetime
from typing import Any, Dict, List, Set

from .frameworks import (
    DORA_CONTROLS,
    FEDRAMP_CONTROLS,
    GDPR_CONTROLS,
    ISO27001_CONTROLS,
    NIS2_CONTROLS,
    PCI_DSS_CONTROLS,
    SLSA_CONTROLS,
    SOC2_CONTROLS,
    SSDF_CONTROLS,
)
from .models import Control, ControlResult, ControlStatus, Framework, FrameworkReport, Severity
from .stride import STRIDE_CONTROLS


class ComplianceEvaluator:
    """Evaluates scan results against compliance frameworks."""

    FRAMEWORK_CONTROLS = {
        Framework.SOC2: SOC2_CONTROLS,
        Framework.SLSA: SLSA_CONTROLS,
        Framework.SSDF: SSDF_CONTROLS,
        Framework.ISO27001: ISO27001_CONTROLS,
        Framework.FEDRAMP: FEDRAMP_CONTROLS,
        Framework.PCI_DSS: PCI_DSS_CONTROLS,
        Framework.STRIDE: STRIDE_CONTROLS,
        Framework.DORA: DORA_CONTROLS,
        Framework.NIS2: NIS2_CONTROLS,
        Framework.GDPR: GDPR_CONTROLS,
    }

    def __init__(self):
        self.capabilities_enabled: Set[str] = set()
        self.findings: Dict[str, List[Dict]] = {}
        self.evidence: Dict[str, List[str]] = {}

    def set_scan_results(
        self,
        capabilities_used: List[str],
        vulnerability_findings: List[Dict] = None,
        malware_findings: List[Dict] = None,
        sandbox_findings: List[Dict] = None,
        secrets_findings: List[Dict] = None,
        policy_results: Dict = None,
        sbom_generated: bool = False,
        vex_generated: bool = False,
    ):
        """Load scan results for compliance evaluation."""
        self.capabilities_enabled = set(capabilities_used)
        self.findings = {
            "vulnerability": vulnerability_findings or [],
            "malware": malware_findings or [],
            "sandbox": sandbox_findings or [],
            "secrets": secrets_findings or [],
        }
        self.evidence = {}
        if sbom_generated:
            self.evidence["sbom"] = ["SBOM generated in CycloneDX format"]
        if vex_generated:
            self.evidence["vex"] = ["VEX document generated"]
        if vulnerability_findings:
            self.evidence["vulnerability_report"] = [f"Scanned {len(vulnerability_findings)} vulnerabilities"]
        if malware_findings is not None:
            self.evidence["malware_scan"] = [f"Malware scan completed, {len(malware_findings)} findings"]
        if sandbox_findings is not None:
            self.evidence["sandbox_verdict"] = [
                f"Sandbox analysis completed, {len(sandbox_findings)} behavioral findings"
            ]
        if policy_results:
            self.evidence["policy_results"] = ["Policy evaluation completed"]

    def evaluate_control(self, control: Control) -> ControlResult:
        """Evaluate a single control against scan results."""
        capabilities_present = set(control.capabilities) & self.capabilities_enabled
        capabilities_missing = set(control.capabilities) - self.capabilities_enabled

        evidence = []
        for etype in control.evidence_types:
            if etype in self.evidence:
                evidence.extend(self.evidence[etype])

        violations_found = []
        findings_count = 0
        for indicator in control.violation_indicators:
            for finding_type, findings_list in self.findings.items():
                for finding in findings_list:
                    severity = finding.get("severity", "").lower()
                    rule = finding.get("rule", "").lower()
                    if indicator.lower() in rule or indicator.lower() in severity:
                        violations_found.append(f"{finding_type}: {rule}")
                        findings_count += 1

        if not capabilities_present:
            status = ControlStatus.NOT_APPLICABLE
            recommendation = f"Enable capabilities: {', '.join(control.capabilities)}"
        elif violations_found:
            status = ControlStatus.NOT_SATISFIED if control.severity == Severity.CRITICAL else ControlStatus.PARTIAL
            recommendation = f"Address {len(violations_found)} findings"
        elif capabilities_missing:
            status = ControlStatus.PARTIAL
            recommendation = f"Also enable: {', '.join(capabilities_missing)}"
        else:
            status = ControlStatus.SATISFIED
            recommendation = None

        return ControlResult(
            control=control,
            status=status,
            evidence=evidence,
            gaps=violations_found,
            findings_count=findings_count,
            recommendation=recommendation,
        )

    def evaluate_framework(self, framework: Framework, scan_id: str = "scan-001") -> FrameworkReport:
        """Evaluate all controls for a framework."""
        controls = self.FRAMEWORK_CONTROLS.get(framework, [])
        results = [self.evaluate_control(c) for c in controls]

        satisfied = sum(1 for r in results if r.status == ControlStatus.SATISFIED)
        partial = sum(1 for r in results if r.status == ControlStatus.PARTIAL)
        not_satisfied = sum(1 for r in results if r.status == ControlStatus.NOT_SATISFIED)
        not_applicable = sum(1 for r in results if r.status == ControlStatus.NOT_APPLICABLE)

        applicable = len(results) - not_applicable
        score = ((satisfied * 100) + (partial * 50)) / applicable if applicable > 0 else 0.0

        return FrameworkReport(
            framework=framework,
            scan_id=scan_id,
            timestamp=datetime.utcnow().isoformat() + "Z",
            total_controls=len(controls),
            satisfied=satisfied,
            partial=partial,
            not_satisfied=not_satisfied,
            not_applicable=not_applicable,
            compliance_score=score,
            controls=results,
        )

    def evaluate_all_frameworks(self, scan_id: str = "scan-001") -> Dict[str, FrameworkReport]:
        """Evaluate all supported frameworks."""
        return {fw.value: self.evaluate_framework(fw, scan_id) for fw in self.FRAMEWORK_CONTROLS.keys()}

    def get_dashboard_summary(self, scan_id: str = "scan-001") -> Dict[str, Any]:
        """Generate dashboard-ready compliance summary."""
        reports = self.evaluate_all_frameworks(scan_id)
        return {
            "compliance_summary": {
                "scan_id": scan_id,
                "timestamp": datetime.utcnow().isoformat() + "Z",
                "frameworks": {
                    name: {
                        "score": round(report.compliance_score, 1),
                        "status": self._score_to_status(report.compliance_score),
                        "satisfied": report.satisfied,
                        "partial": report.partial,
                        "not_satisfied": report.not_satisfied,
                        "total_applicable": report.total_controls - report.not_applicable,
                    }
                    for name, report in reports.items()
                },
                "overall_score": round(sum(r.compliance_score for r in reports.values()) / len(reports), 1),
                "critical_gaps": self._get_critical_gaps(reports),
            }
        }

    def _score_to_status(self, score: float) -> str:
        if score >= 90:
            return "compliant"
        elif score >= 70:
            return "mostly_compliant"
        elif score >= 50:
            return "partial"
        return "non_compliant"

    def _get_critical_gaps(self, reports: Dict[str, FrameworkReport]) -> List[Dict]:
        return [
            {
                "framework": name,
                "control_id": cr.control.id,
                "control_name": cr.control.name,
                "recommendation": cr.recommendation,
            }
            for name, report in reports.items()
            for cr in report.controls
            if cr.status == ControlStatus.NOT_SATISFIED and cr.control.severity == Severity.CRITICAL
        ]


# =============================================================================
# CONVENIENCE FUNCTIONS
# =============================================================================


def generate_compliance_report(
    scan_results: Dict[str, Any],
    frameworks: List[Framework] = None,
) -> Dict[str, Any]:
    """Generate compliance report from REACHABLE scan results."""
    evaluator = ComplianceEvaluator()

    vulnerabilities = scan_results.get("vulnerabilities", {}).get("findings", [])
    malware = scan_results.get("malware", {}).get("findings", [])
    sandbox = scan_results.get("sandbox", {}).get("findings", [])
    secrets = scan_results.get("secrets", {}).get("findings", [])

    capabilities = []
    for key, cap in [
        ("sbom", "sbom_generation"),
        ("vulnerabilities", "vulnerability_scanning"),
        ("reachability", "reachability_analysis"),
        ("malware", "malware_detection"),
        ("sandbox", "sandbox_behavioral"),
        ("secrets", "secrets_detection"),
        ("vex", "vex_generation"),
    ]:
        if scan_results.get(key):
            capabilities.append(cap)

    evaluator.set_scan_results(
        capabilities_used=capabilities,
        vulnerability_findings=vulnerabilities,
        malware_findings=malware,
        sandbox_findings=sandbox,
        secrets_findings=secrets,
        sbom_generated="sbom" in scan_results,
        vex_generated="vex" in scan_results,
    )

    scan_id = scan_results.get("scan_metadata", {}).get("scan_id", "unknown")

    if frameworks:
        return {fw.value: evaluator.evaluate_framework(fw, scan_id).to_dict() for fw in frameworks}
    return {name: report.to_dict() for name, report in evaluator.evaluate_all_frameworks(scan_id).items()}


def get_framework_controls(framework: Framework) -> List[Dict]:
    """Get all controls for a framework as dictionaries."""
    controls = ComplianceEvaluator.FRAMEWORK_CONTROLS.get(framework, [])
    return [
        {
            "id": c.id,
            "name": c.name,
            "description": c.description,
            "category": c.category,
            "severity": c.severity.value,
            "capabilities": c.capabilities,
            "evidence_types": c.evidence_types,
        }
        for c in controls
    ]


def list_all_frameworks() -> List[Dict]:
    """List all supported compliance frameworks."""
    return [
        {
            "id": fw.name,
            "name": fw.value,
            "control_count": len(ComplianceEvaluator.FRAMEWORK_CONTROLS.get(fw, [])),
        }
        for fw in Framework
    ]
