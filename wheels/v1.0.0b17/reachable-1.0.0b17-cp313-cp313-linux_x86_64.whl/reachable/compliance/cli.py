# Copyright © 2026 Sthenos Security. All rights reserved.

"""
REACHABLE Compliance CLI Commands

Provides the 'reachctl compliance' command group for framework
mapping and compliance reporting.
"""

import json
import sys
from typing import Optional

import click

from . import (
    ComplianceEvaluator,
    Framework,
    generate_compliance_report,
    get_framework_controls,
    list_all_frameworks,
)


@click.group()
def compliance():
    """Compliance framework mapping and reporting"""
    pass


@compliance.command("list")
def list_frameworks():
    """
    List all supported compliance frameworks.
    """
    frameworks = list_all_frameworks()

    click.echo(" Supported Compliance Frameworks")
    click.echo("=" * 50)
    click.echo("")

    for fw in frameworks:
        click.echo(f"  {fw['id']:<12} {fw['name']:<30} ({fw['control_count']} controls)")

    click.echo("")
    click.echo("Use 'reachctl compliance controls <framework>' to see controls")


@compliance.command()
@click.argument("framework")
@click.option("--json", "output_json", is_flag=True, help="Output as JSON")
@click.option("--category", "-c", default=None, help="Filter by category")
def controls(framework: str, output_json: bool, category: Optional[str]):
    """
    Show controls for a specific framework.

    \b
    FRAMEWORK can be: SOC2, SLSA, SSDF, ISO27001, FEDRAMP, PCI_DSS
    """
    # Map framework name
    framework_map = {
        "soc2": Framework.SOC2,
        "slsa": Framework.SLSA,
        "ssdf": Framework.SSDF,
        "iso27001": Framework.ISO27001,
        "iso": Framework.ISO27001,
        "fedramp": Framework.FEDRAMP,
        "nist": Framework.FEDRAMP,
        "pci": Framework.PCI_DSS,
        "pci_dss": Framework.PCI_DSS,
        "pcidss": Framework.PCI_DSS,
        "stride": Framework.STRIDE,
    }

    fw = framework_map.get(framework.lower())
    if not fw:
        click.secho(f"Unknown framework: {framework}", fg="red")
        click.echo("Valid frameworks: SOC2, SLSA, SSDF, ISO27001, FEDRAMP, PCI_DSS")
        sys.exit(1)

    controls_list = get_framework_controls(fw)

    # Filter by category if specified
    if category:
        controls_list = [c for c in controls_list if category.lower() in c["category"].lower()]

    if output_json:
        click.echo(json.dumps(controls_list, indent=2))
        return

    click.echo(f" {fw.value} Controls")
    click.echo("=" * 70)
    click.echo("")

    # Group by category
    categories = {}
    for c in controls_list:
        cat = c["category"]
        if cat not in categories:
            categories[cat] = []
        categories[cat].append(c)

    for cat, cat_controls in categories.items():
        click.secho(f"  {cat}", fg="cyan", bold=True)
        for c in cat_controls:
            sev_colors = {"critical": "red", "high": "yellow", "medium": "white", "low": "white"}
            sev_color = sev_colors.get(c["severity"], "white")
            click.echo(f"    {c['id']:<12} ", nl=False)
            click.secho(f"[{c['severity'].upper():<8}] ", fg=sev_color, nl=False)
            click.echo(c["name"])
        click.echo("")

    click.echo(f"Total: {len(controls_list)} controls")


@compliance.command()
@click.argument("scan_file", type=click.Path(exists=True))
@click.option("--framework", "-f", multiple=True, help="Frameworks to evaluate (all if not specified)")
@click.option("--json", "output_json", is_flag=True, help="Output as JSON")
@click.option("--output", "-o", type=click.Path(), help="Write report to file")
def evaluate(scan_file: str, framework: tuple, output_json: bool, output: Optional[str]):
    """
    Evaluate scan results against compliance frameworks.

    \b
    SCAN_FILE should be a JSON file from 'reachctl scan --json'

    Examples:
        reachctl compliance evaluate scan_results.json
        reachctl compliance evaluate scan.json -f SOC2 -f FEDRAMP
        reachctl compliance evaluate scan.json --json -o compliance_report.json
    """
    # Load scan results
    try:
        with open(scan_file) as f:
            scan_results = json.load(f)
    except Exception as e:
        click.secho(f"Error loading scan file: {e}", fg="red")
        sys.exit(1)

    # Map frameworks
    framework_map = {
        "soc2": Framework.SOC2,
        "slsa": Framework.SLSA,
        "ssdf": Framework.SSDF,
        "iso27001": Framework.ISO27001,
        "iso": Framework.ISO27001,
        "fedramp": Framework.FEDRAMP,
        "nist": Framework.FEDRAMP,
        "pci": Framework.PCI_DSS,
        "pci_dss": Framework.PCI_DSS,
    }

    frameworks_to_evaluate = None
    if framework:
        frameworks_to_evaluate = []
        for f in framework:
            fw = framework_map.get(f.lower())
            if fw:
                frameworks_to_evaluate.append(fw)
            else:
                click.secho(f"Warning: Unknown framework '{f}', skipping", fg="yellow")

    # Generate report
    report = generate_compliance_report(scan_results, frameworks_to_evaluate)

    if output_json or output:
        report_json = json.dumps(report, indent=2)
        if output:
            with open(output, "w") as f:
                f.write(report_json)
            click.secho(f"Report written to: {output}", fg="green")
        else:
            click.echo(report_json)
        return

    # Pretty print
    click.echo("")
    click.echo(" COMPLIANCE EVALUATION REPORT")
    click.echo("=" * 70)
    click.echo("")

    for fw_name, fw_report in report.items():
        summary = fw_report["summary"]
        score = summary["compliance_score"]

        # Color based on score
        if score >= 90:
            score_color = "green"
            status = " COMPLIANT"
        elif score >= 70:
            score_color = "yellow"
            status = "  MOSTLY COMPLIANT"
        elif score >= 50:
            score_color = "yellow"
            status = " PARTIAL"
        else:
            score_color = "red"
            status = " NON-COMPLIANT"

        click.secho(f"  {fw_name}", fg="cyan", bold=True)
        click.echo("    Score: ", nl=False)
        click.secho(f"{score:.1f}%", fg=score_color, bold=True, nl=False)
        click.echo(f"  {status}")
        click.echo(
            f"    Controls: {summary['satisfied']} satisfied, {summary['partial']} partial, {summary['not_satisfied']} failed"
        )
        click.echo("")

        # Show failed controls
        failed = [c for c in fw_report["controls"] if c["status"] == "not_satisfied"]
        if failed:
            click.secho("    Failed Controls:", fg="red")
            for c in failed[:5]:  # Show first 5
                click.echo(f"      • {c['id']}: {c['name']}")
            if len(failed) > 5:
                click.echo(f"      ... and {len(failed) - 5} more")
            click.echo("")

    # Overall summary
    all_scores = [r["summary"]["compliance_score"] for r in report.values()]
    avg_score = sum(all_scores) / len(all_scores) if all_scores else 0

    click.echo("-" * 70)
    click.echo("Overall Compliance Score: ", nl=False)
    if avg_score >= 70:
        click.secho(f"{avg_score:.1f}%", fg="green", bold=True)
    else:
        click.secho(f"{avg_score:.1f}%", fg="yellow", bold=True)


@compliance.command()
@click.option("--json", "output_json", is_flag=True, help="Output as JSON")
def capabilities(output_json: bool):
    """
    Show REACHABLE capabilities and their compliance mappings.
    """
    from . import REACHABLE_CAPABILITIES

    if output_json:
        click.echo(json.dumps(REACHABLE_CAPABILITIES, indent=2))
        return

    click.echo(" REACHABLE Capabilities")
    click.echo("=" * 60)
    click.echo("")

    for cap_id, cap_info in REACHABLE_CAPABILITIES.items():
        click.secho(f"  {cap_id}", fg="cyan", bold=True)
        click.echo(f"    {cap_info['name']}")
        click.echo(f"    {cap_info['description']}")
        click.echo("")


@compliance.command()
@click.argument("scan_file", type=click.Path(exists=True))
@click.option("--output", "-o", type=click.Path(), help="Write dashboard data to file")
def dashboard(scan_file: str, output: Optional[str]):
    """
    Generate dashboard-ready compliance summary.

    \b
    Produces a summary optimized for dashboard display.
    """
    # Load scan results
    try:
        with open(scan_file) as f:
            scan_results = json.load(f)
    except Exception as e:
        click.secho(f"Error loading scan file: {e}", fg="red")
        sys.exit(1)

    # Create evaluator and load results
    evaluator = ComplianceEvaluator()

    # Extract findings
    vulnerabilities = scan_results.get("vulnerabilities", {}).get("findings", [])
    malware = scan_results.get("malware", {}).get("findings", [])
    sandbox = scan_results.get("sandbox", {}).get("findings", [])
    secrets = scan_results.get("secrets", {}).get("findings", [])

    # Determine capabilities
    capabilities = []
    if scan_results.get("sbom"):
        capabilities.append("sbom_generation")
    if scan_results.get("vulnerabilities"):
        capabilities.append("vulnerability_scanning")
    if scan_results.get("reachability"):
        capabilities.append("reachability_analysis")
    if scan_results.get("malware"):
        capabilities.append("malware_detection")
    if scan_results.get("sandbox"):
        capabilities.append("sandbox_behavioral")
    if scan_results.get("secrets"):
        capabilities.append("secrets_detection")

    evaluator.set_scan_results(
        capabilities_used=capabilities,
        vulnerability_findings=vulnerabilities,
        malware_findings=malware,
        sandbox_findings=sandbox,
        secrets_findings=secrets,
        sbom_generated="sbom" in scan_results,
    )

    scan_id = scan_results.get("scan_metadata", {}).get("scan_id", "unknown")
    dashboard_data = evaluator.get_dashboard_summary(scan_id)

    dashboard_json = json.dumps(dashboard_data, indent=2)

    if output:
        with open(output, "w") as f:
            f.write(dashboard_json)
        click.secho(f"Dashboard data written to: {output}", fg="green")
    else:
        click.echo(dashboard_json)
