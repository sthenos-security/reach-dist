# Copyright © 2026 Sthenos Security. All rights reserved.

"""
STRIDE threat model controls and policy mapping.
"""

from typing import List

from .models import Control, Framework, Severity, ThreatCategory

# =============================================================================
# STRIDE THREAT MODEL CONTROLS
# =============================================================================

STRIDE_CONTROLS = [
    # SPOOFING
    Control(
        id="S-1",
        name="Package Identity Verification",
        description="Verify that packages are authentic and from legitimate sources.",
        framework=Framework.STRIDE,
        severity=Severity.CRITICAL,
        category="Spoofing",
        capabilities=["provenance_verification", "sbom_generation"],
        violation_indicators=["unsigned_package", "unknown_publisher"],
        evidence_types=["signature_verification", "provenance_attestation"],
    ),
    Control(
        id="S-2",
        name="Typosquatting Detection",
        description="Detect packages with names similar to popular packages.",
        framework=Framework.STRIDE,
        severity=Severity.HIGH,
        category="Spoofing",
        capabilities=["malware_detection", "sandbox_behavioral"],
        violation_indicators=["typosquat_detected"],
        evidence_types=["malware_findings", "name_similarity_score"],
    ),
    Control(
        id="S-3",
        name="Dependency Confusion Prevention",
        description="Prevent private package namespace hijacking.",
        framework=Framework.STRIDE,
        severity=Severity.CRITICAL,
        category="Spoofing",
        capabilities=["sbom_generation", "policy_enforcement"],
        violation_indicators=["namespace_conflict"],
        evidence_types=["sbom", "registry_analysis"],
    ),
    # TAMPERING
    Control(
        id="T-1",
        name="Code Integrity Verification",
        description="Verify that package code has not been modified.",
        framework=Framework.STRIDE,
        severity=Severity.CRITICAL,
        category="Tampering",
        capabilities=["provenance_verification", "sbom_generation"],
        violation_indicators=["checksum_mismatch", "modified_package"],
        evidence_types=["hash_verification", "sbom_diff"],
    ),
    Control(
        id="T-2",
        name="Build Process Integrity",
        description="Ensure build artifacts match source code.",
        framework=Framework.STRIDE,
        severity=Severity.HIGH,
        category="Tampering",
        capabilities=["provenance_verification"],
        violation_indicators=["build_mismatch"],
        evidence_types=["reproducible_build_check"],
    ),
    Control(
        id="T-3",
        name="Install-Time Modification Detection",
        description="Detect code modifications during package installation.",
        framework=Framework.STRIDE,
        severity=Severity.CRITICAL,
        category="Tampering",
        capabilities=["sandbox_behavioral"],
        violation_indicators=["postinstall_modification"],
        evidence_types=["sandbox_fs_events"],
    ),
    # REPUDIATION
    Control(
        id="R-1",
        name="Scan Activity Logging",
        description="Maintain audit trail of all security scans.",
        framework=Framework.STRIDE,
        severity=Severity.MEDIUM,
        category="Repudiation",
        capabilities=["audit_logging"],
        violation_indicators=["missing_audit_trail"],
        evidence_types=["audit_logs"],
    ),
    Control(
        id="R-2",
        name="Finding Attribution",
        description="Track source of each security finding.",
        framework=Framework.STRIDE,
        severity=Severity.MEDIUM,
        category="Repudiation",
        capabilities=["audit_logging", "vex_generation"],
        violation_indicators=["unattributed_finding"],
        evidence_types=["finding_metadata", "vex_document"],
    ),
    Control(
        id="R-3",
        name="Remediation Tracking",
        description="Track vulnerability remediation decisions and actions.",
        framework=Framework.STRIDE,
        severity=Severity.HIGH,
        category="Repudiation",
        capabilities=["vex_generation", "policy_enforcement"],
        violation_indicators=["untracked_remediation"],
        evidence_types=["vex_history", "policy_decisions"],
    ),
    # INFORMATION DISCLOSURE
    Control(
        id="I-1",
        name="Secrets Detection",
        description="Detect hardcoded secrets and credentials in code.",
        framework=Framework.STRIDE,
        severity=Severity.CRITICAL,
        category="Information Disclosure",
        capabilities=["secrets_detection"],
        violation_indicators=["hardcoded_secret", "exposed_credential"],
        evidence_types=["secrets_findings"],
    ),
    Control(
        id="I-2",
        name="Credential Exfiltration Prevention",
        description="Prevent packages from stealing credentials during install.",
        framework=Framework.STRIDE,
        severity=Severity.CRITICAL,
        category="Information Disclosure",
        capabilities=["sandbox_behavioral"],
        violation_indicators=["credential_access", "honeypot_triggered"],
        evidence_types=["sandbox_verdict", "honeypot_events"],
    ),
    Control(
        id="I-3",
        name="Token Protection",
        description="Protect CI/CD tokens and API keys from exfiltration.",
        framework=Framework.STRIDE,
        severity=Severity.CRITICAL,
        category="Information Disclosure",
        capabilities=["sandbox_behavioral", "secrets_detection"],
        violation_indicators=["token_access", "env_exfiltration"],
        evidence_types=["env_scrub_events", "sandbox_events"],
    ),
    # DENIAL OF SERVICE
    Control(
        id="D-1",
        name="Resource Exhaustion Prevention",
        description="Prevent packages from exhausting system resources.",
        framework=Framework.STRIDE,
        severity=Severity.HIGH,
        category="Denial of Service",
        capabilities=["sandbox_behavioral"],
        violation_indicators=["resource_exhaustion", "fork_bomb"],
        evidence_types=["resource_limits", "sandbox_config"],
    ),
    Control(
        id="D-2",
        name="Dependency Chain Analysis",
        description="Detect dependency chains that could cause build failures.",
        framework=Framework.STRIDE,
        severity=Severity.MEDIUM,
        category="Denial of Service",
        capabilities=["dependency_graph", "vulnerability_scanning"],
        violation_indicators=["circular_dependency", "incompatible_versions"],
        evidence_types=["dependency_analysis"],
    ),
    Control(
        id="D-3",
        name="Build Timeout Protection",
        description="Ensure package installations complete within time limits.",
        framework=Framework.STRIDE,
        severity=Severity.MEDIUM,
        category="Denial of Service",
        capabilities=["sandbox_behavioral"],
        violation_indicators=["installation_timeout"],
        evidence_types=["sandbox_duration"],
    ),
    # ELEVATION OF PRIVILEGE
    Control(
        id="E-1",
        name="Privilege Escalation Prevention",
        description="Prevent packages from gaining elevated privileges.",
        framework=Framework.STRIDE,
        severity=Severity.CRITICAL,
        category="Elevation of Privilege",
        capabilities=["sandbox_behavioral"],
        violation_indicators=["privilege_escalation", "capability_abuse"],
        evidence_types=["capability_drops", "seccomp_violations"],
    ),
    Control(
        id="E-2",
        name="Container Escape Prevention",
        description="Prevent packages from escaping sandbox isolation.",
        framework=Framework.STRIDE,
        severity=Severity.CRITICAL,
        category="Elevation of Privilege",
        capabilities=["sandbox_behavioral"],
        violation_indicators=["container_escape_attempt"],
        evidence_types=["sandbox_isolation_events"],
    ),
    Control(
        id="E-3",
        name="Vulnerable Code Reachability",
        description="Determine if vulnerable code paths are actually executable.",
        framework=Framework.STRIDE,
        severity=Severity.HIGH,
        category="Elevation of Privilege",
        capabilities=["reachability_analysis", "vulnerability_scanning"],
        violation_indicators=["reachable_vulnerability"],
        evidence_types=["reachability_score", "call_graph"],
    ),
    Control(
        id="E-4",
        name="Known Exploit Detection",
        description="Detect vulnerabilities with known exploits in the wild.",
        framework=Framework.STRIDE,
        severity=Severity.CRITICAL,
        category="Elevation of Privilege",
        capabilities=["kev_checking", "epss_scoring"],
        violation_indicators=["kev_match", "high_epss"],
        evidence_types=["kev_results", "epss_scores"],
    ),
]

# =============================================================================
# STRIDE-TO-POLICY MAPPING
# =============================================================================

STRIDE_POLICY_MAP = {
    ThreatCategory.SPOOFING: {
        "description": "Threats involving impersonation of legitimate packages or sources",
        "detection_rules": ["TYPOSQUAT_DETECTED", "UNSIGNED_PACKAGE", "UNKNOWN_PUBLISHER"],
        "capabilities": ["provenance_verification", "malware_detection", "sbom_generation"],
        "sandbox_signals": [],
        "controls": ["S-1", "S-2", "S-3"],
    },
    ThreatCategory.TAMPERING: {
        "description": "Threats involving unauthorized modification of code or data",
        "detection_rules": ["CHECKSUM_MISMATCH", "POSTINSTALL_MODIFICATION"],
        "capabilities": ["provenance_verification", "sandbox_behavioral", "sbom_generation"],
        "sandbox_signals": ["file_write", "executable_creation"],
        "controls": ["T-1", "T-2", "T-3"],
    },
    ThreatCategory.REPUDIATION: {
        "description": "Threats related to inability to trace actions",
        "detection_rules": [],
        "capabilities": ["audit_logging", "vex_generation"],
        "sandbox_signals": ["process_spawn", "script_start", "script_end"],
        "controls": ["R-1", "R-2", "R-3"],
    },
    ThreatCategory.INFORMATION_DISCLOSURE: {
        "description": "Threats involving exposure of sensitive data",
        "detection_rules": ["CREDENTIAL_ACCESS", "ENV_EXFIL_ATTEMPT", "HARDCODED_SECRET"],
        "capabilities": ["secrets_detection", "sandbox_behavioral"],
        "sandbox_signals": ["honeypot_access", "env_scrubbed", "network_blocked"],
        "controls": ["I-1", "I-2", "I-3"],
    },
    ThreatCategory.DENIAL_OF_SERVICE: {
        "description": "Threats that disrupt availability or operations",
        "detection_rules": ["RESOURCE_EXHAUSTION", "FORK_BOMB"],
        "capabilities": ["sandbox_behavioral", "dependency_graph"],
        "sandbox_signals": ["process_spawn"],
        "controls": ["D-1", "D-2", "D-3"],
    },
    ThreatCategory.ELEVATION_OF_PRIVILEGE: {
        "description": "Threats involving unauthorized access escalation",
        "detection_rules": ["NETWORK_DURING_INSTALL", "BLOCKED_TOOL", "SUSPICIOUS_ARGUMENT"],
        "capabilities": ["sandbox_behavioral", "reachability_analysis", "kev_checking"],
        "sandbox_signals": ["network_blocked", "blocked_execution", "suspicious_argument"],
        "controls": ["E-1", "E-2", "E-3", "E-4"],
    },
}


def get_stride_mapping_for_finding(finding_rule: str) -> List[ThreatCategory]:
    """Map a finding rule to STRIDE threat categories."""
    return [cat for cat, policy in STRIDE_POLICY_MAP.items() if finding_rule in policy["detection_rules"]]


def get_stride_mapping_for_event(event_type: str) -> List[ThreatCategory]:
    """Map a sandbox event to STRIDE threat categories."""
    return [cat for cat, policy in STRIDE_POLICY_MAP.items() if event_type in policy["sandbox_signals"]]
