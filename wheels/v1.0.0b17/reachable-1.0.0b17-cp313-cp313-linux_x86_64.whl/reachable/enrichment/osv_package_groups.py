#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.
"""
OSV Package Groups — Google OSV Schema Parser
==============================================

Parses the full OSV advisory record schema as defined at:
  https://ossf.github.io/osv-schema/

A single CVE/GHSA in OSV can affect the same library under MULTIPLE
package names and ecosystems — each element of `affected[]` is one
"package group" (one (package, ecosystem) pair with its own version ranges).

For example, CVE-2021-44228 (Log4Shell) has package groups for:
  - Maven:org.apache.logging.log4j:log4j-core
  - npm:log4js                  (different name, same vuln)
  - PyPI:log4j                  (wrapper, also affected)

What this module extracts:

  OsvRecord
  ├── id              primary OSV ID (GHSA-xxx / GO-xxxx / PYSEC-xxx)
  ├── aliases         ALL cross-IDs  [CVE-xxx, GHSA-xxx, GO-xxx, PYSEC-xxx]
  ├── summary         one-liner for display
  ├── details         full Markdown description
  ├── severity        list of {type, score} — CVSS_V3, CVSS_V2, CVSS_V4
  ├── published       ISO date
  ├── modified        ISO date
  ├── withdrawn       ISO date (set if vuln was retracted)
  ├── references      [{type, url}]  types: ADVISORY,FIX,ARTICLE,REPORT,WEB,PACKAGE
  ├── credits         [{name, contact[], type}]
  └── affected        list of OsvPackageGroup

  OsvPackageGroup
  ├── package_name    canonical name in that ecosystem
  ├── ecosystem       OSV ecosystem string (npm, PyPI, Go, Maven, ...)
  ├── purl            package URL if present
  ├── versions        explicit list of all affected version strings
  ├── ranges          list of OsvVersionRange
  ├── database_specific  {severity, cvss, cwe, ...} — varies by DB
  └── ecosystem_specific {imports, functions, ...} — varies by ecosystem

  OsvVersionRange
  ├── range_type      SEMVER | GIT | ECOSYSTEM
  ├── repo            git repo URL (GIT ranges only)
  ├── introduced      version/commit where vuln was introduced (may be "0")
  ├── fixed           version/commit that fixes it (None if not fixed yet)
  └── limit           upper bound (rare)

Convenience helpers:

  extract_fix_versions(groups, pkg, ecosystem)
      → list of clean semver fix strings for a given (pkg, ecosystem)

  extract_aliases_by_prefix(record, prefix)
      → list of IDs matching prefix ("CVE-", "GHSA-", "GO-", "PYSEC-")

  is_withdrawn(record)
      → bool

  best_cvss_score(record)
      → (score: float, vector: str) | (None, None)
      Prefers CVSS_V3, falls back to CVSS_V4 then CVSS_V2.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Dataclasses
# ---------------------------------------------------------------------------


@dataclass
class OsvVersionRange:
    """One version range from affected[].ranges[]."""
    range_type: str              # SEMVER | GIT | ECOSYSTEM
    repo: Optional[str]          # git repo URL (GIT type only)
    introduced: Optional[str]    # "0" means "since the beginning"
    fixed: Optional[str]         # None = still vulnerable
    limit: Optional[str]         # exclusive upper bound (rare)

    def is_fixed(self) -> bool:
        return self.fixed is not None

    def to_dict(self) -> Dict[str, Any]:
        return {
            "range_type": self.range_type,
            "repo":       self.repo,
            "introduced": self.introduced,
            "fixed":      self.fixed,
            "limit":      self.limit,
        }


@dataclass
class OsvPackageGroup:
    """
    One element of OSV affected[].

    Each represents one (package_name, ecosystem) pair affected by the
    advisory.  A single CVE can have many groups when the same vulnerable
    code ships under different names across ecosystems.
    """
    package_name: str
    ecosystem: str
    purl: Optional[str]

    # Explicit version list — often absent; ranges are the canonical form.
    versions: List[str] = field(default_factory=list)

    # Version ranges with introduced/fixed/limit events.
    ranges: List[OsvVersionRange] = field(default_factory=list)

    # database_specific: contains severity, CVSS, CWEs etc.  Shape varies.
    database_specific: Dict[str, Any] = field(default_factory=dict)

    # ecosystem_specific: Go imports, Python entry points, etc.
    ecosystem_specific: Dict[str, Any] = field(default_factory=dict)

    # ── Convenience ─────────────────────────────────────────────────────────

    def fix_versions(self) -> List[str]:
        """All fix version strings from SEMVER ranges (v-prefixed)."""
        out = []
        for r in self.ranges:
            if r.range_type == "SEMVER" and r.fixed:
                v = r.fixed if r.fixed.startswith("v") else f"v{r.fixed}"
                if v not in out:
                    out.append(v)
        return out

    def fix_commits(self) -> List[str]:
        """All fix commit hashes from GIT ranges."""
        return [r.fixed for r in self.ranges if r.range_type == "GIT" and r.fixed]

    def is_still_vulnerable(self) -> bool:
        """True if no range has a fixed event (no patch released)."""
        return all(r.fixed is None for r in self.ranges)

    def introduced_versions(self) -> List[str]:
        """All 'introduced' markers across ranges."""
        return [r.introduced for r in self.ranges if r.introduced and r.introduced != "0"]

    def to_dict(self) -> Dict[str, Any]:
        return {
            "package_name":      self.package_name,
            "ecosystem":         self.ecosystem,
            "purl":              self.purl,
            "versions":          self.versions,
            "ranges":            [r.to_dict() for r in self.ranges],
            "fix_versions":      self.fix_versions(),
            "fix_commits":       self.fix_commits(),
            "is_still_vulnerable": self.is_still_vulnerable(),
            "database_specific": self.database_specific,
            "ecosystem_specific": self.ecosystem_specific,
        }


@dataclass
class OsvRecord:
    """
    Parsed representation of a full OSV advisory record.

    Constructed from the JSON returned by:
      GET  https://api.osv.dev/v1/vulns/{id}
      POST https://api.osv.dev/v1/querybatch  (each vulns[] element)
    """
    id: str
    aliases: List[str] = field(default_factory=list)     # all cross-IDs
    related: List[str] = field(default_factory=list)     # loosely related
    summary: str = ""
    details: str = ""                                    # Markdown
    severity: List[Dict[str, str]] = field(default_factory=list)  # [{type,score}]
    published: Optional[str] = None
    modified: Optional[str] = None
    withdrawn: Optional[str] = None                      # set if retracted
    references: List[Dict[str, str]] = field(default_factory=list)
    credits: List[Dict[str, Any]] = field(default_factory=list)
    affected: List[OsvPackageGroup] = field(default_factory=list)

    # ── Convenience ─────────────────────────────────────────────────────────

    def all_ids(self) -> List[str]:
        """Primary ID + all aliases."""
        return [self.id] + [a for a in self.aliases if a != self.id]

    def cve_ids(self) -> List[str]:
        return [a for a in self.all_ids() if a.startswith("CVE-")]

    def ghsa_ids(self) -> List[str]:
        return [a for a in self.all_ids() if a.startswith("GHSA-")]

    def go_ids(self) -> List[str]:
        return [a for a in self.all_ids() if a.startswith("GO-")]

    def pysec_ids(self) -> List[str]:
        return [a for a in self.all_ids() if a.startswith("PYSEC-")]

    def is_withdrawn(self) -> bool:
        return self.withdrawn is not None

    def fix_references(self) -> List[str]:
        """URLs categorised as FIX in references."""
        return [r["url"] for r in self.references if r.get("type") == "FIX"]

    def advisory_references(self) -> List[str]:
        return [r["url"] for r in self.references if r.get("type") == "ADVISORY"]

    def groups_for(self, pkg: str, ecosystem: str) -> List[OsvPackageGroup]:
        """Return affected groups matching (pkg, ecosystem), case-insensitive."""
        pkg_l = pkg.lower()
        eco_l = ecosystem.lower()
        return [
            g for g in self.affected
            if g.package_name.lower() == pkg_l and g.ecosystem.lower() == eco_l
        ]

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id":         self.id,
            "aliases":    self.aliases,
            "related":    self.related,
            "summary":    self.summary,
            "details":    self.details[:500] if self.details else "",
            "severity":   self.severity,
            "published":  self.published,
            "modified":   self.modified,
            "withdrawn":  self.withdrawn,
            "references": self.references,
            "credits":    self.credits,
            "affected":   [g.to_dict() for g in self.affected],
            "cve_ids":    self.cve_ids(),
            "ghsa_ids":   self.ghsa_ids(),
            "go_ids":     self.go_ids(),
            "fix_refs":   self.fix_references(),
        }


# ---------------------------------------------------------------------------
# Parser
# ---------------------------------------------------------------------------


def parse_osv_record(raw: Dict[str, Any]) -> OsvRecord:
    """
    Parse a raw OSV JSON dict (from the API or cache) into an OsvRecord.

    Handles missing fields gracefully — all fields have safe defaults.
    """
    rec = OsvRecord(
        id       = raw.get("id", ""),
        aliases  = list(raw.get("aliases", []) or []),
        related  = list(raw.get("related", []) or []),
        summary  = raw.get("summary", "") or "",
        details  = raw.get("details", "") or "",
        severity = list(raw.get("severity", []) or []),
        published = raw.get("published"),
        modified  = raw.get("modified"),
        withdrawn = raw.get("withdrawn"),
        references = _parse_references(raw.get("references", [])),
        credits    = list(raw.get("credits", []) or []),
    )

    for aff in (raw.get("affected") or []):
        group = _parse_affected_entry(aff)
        if group:
            rec.affected.append(group)

    return rec


def _parse_references(refs: Any) -> List[Dict[str, str]]:
    """Normalise reference list — each entry must have type + url."""
    if not refs or not isinstance(refs, list):
        return []
    out = []
    for r in refs:
        if not isinstance(r, dict):
            continue
        url = r.get("url", "")
        if url:
            out.append({"type": r.get("type", "WEB"), "url": url})
    return out


def _parse_affected_entry(aff: Dict[str, Any]) -> Optional[OsvPackageGroup]:
    """Parse one element of affected[] into OsvPackageGroup."""
    pkg_raw = aff.get("package") or {}
    pkg_name = pkg_raw.get("name", "")
    ecosystem = pkg_raw.get("ecosystem", "")

    if not pkg_name or not ecosystem:
        return None

    ranges: List[OsvVersionRange] = []
    for rng in (aff.get("ranges") or []):
        rtype = rng.get("type", "ECOSYSTEM")
        repo  = rng.get("repo")
        introduced = fixed = limit = None
        for event in (rng.get("events") or []):
            if "introduced" in event and introduced is None:
                introduced = event["introduced"]
            elif "fixed" in event and fixed is None:
                fixed = event["fixed"]
            elif "limit" in event and limit is None:
                limit = event["limit"]
        ranges.append(OsvVersionRange(
            range_type = rtype,
            repo       = repo,
            introduced = introduced,
            fixed      = fixed,
            limit      = limit,
        ))

    return OsvPackageGroup(
        package_name       = pkg_name,
        ecosystem          = ecosystem,
        purl               = pkg_raw.get("purl"),
        versions           = list(aff.get("versions") or []),
        ranges             = ranges,
        database_specific  = dict(aff.get("database_specific") or {}),
        ecosystem_specific = dict(aff.get("ecosystem_specific") or {}),
    )


# ---------------------------------------------------------------------------
# Helpers — used by threat_intel.py enrich loop
# ---------------------------------------------------------------------------


def extract_fix_versions(
    record: OsvRecord,
    pkg: str,
    ecosystem: str,
) -> List[str]:
    """
    Return all SEMVER fix versions for (pkg, ecosystem) from an OsvRecord.
    Falls back to any group if no exact match (handles ecosystem aliases).
    """
    # Exact match first
    groups = record.groups_for(pkg, ecosystem)
    if not groups:
        # Fuzzy: match by name only (ecosystem may differ e.g. "npm" vs "Node")
        pkg_l = pkg.lower()
        groups = [g for g in record.affected if g.package_name.lower() == pkg_l]
    if not groups:
        # Last resort: any group that has fix versions
        groups = [g for g in record.affected if g.fix_versions()]

    seen: List[str] = []
    for g in groups:
        for v in g.fix_versions():
            if v not in seen:
                seen.append(v)
    return seen


def extract_fix_commit(record: OsvRecord, pkg: str, ecosystem: str) -> Optional[str]:
    """Return first GIT fix commit hash for this package."""
    groups = record.groups_for(pkg, ecosystem)
    if not groups:
        groups = record.affected
    for g in groups:
        commits = g.fix_commits()
        if commits:
            return commits[0]
    return None


def best_cvss_score(record: OsvRecord) -> Tuple[Optional[float], Optional[str]]:
    """
    Return (score, vector) from OSV severity array.
    Preference order: CVSS_V3 → CVSS_V4 → CVSS_V2.
    Score is extracted from the vector string if numeric score not explicit.
    """
    preferred = ["CVSS_V3", "CVSS_V4", "CVSS_V2"]
    by_type: Dict[str, str] = {}
    for s in record.severity:
        t = s.get("type", "")
        v = s.get("score", "")
        if t and v:
            by_type[t] = v

    for pref in preferred:
        vector = by_type.get(pref)
        if not vector:
            continue
        score = _cvss_base_score_from_vector(vector)
        return score, vector
    return None, None


def _cvss_base_score_from_vector(vector: str) -> Optional[float]:
    """
    Extract the numeric base score embedded in a CVSS vector string.

    CVSS vectors don't embed a numeric score — the score is computed from
    the vector components. Rather than bundle a full CVSS calculator we
    look for a trailing /score pattern sometimes appended by OSV:
      "CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:C/C:H/I:H/A:H"  → compute from AV etc.

    For simplicity: if the vector starts with a version we trust the
    caller's own CVSS calculation; we return None so the caller falls
    back to the Grype-supplied cvss_score.  This avoids shipping a full
    CVSS calculator but keeps the vector available for display.
    """
    # Some OSV records embed the score as a plain float in the "score" field
    # directly (e.g. {"type":"CVSS_V3","score":"9.8"}).  Handle that case.
    try:
        return float(vector)
    except (ValueError, TypeError):
        pass
    return None


def aliases_by_prefix(record: OsvRecord, prefix: str) -> List[str]:
    """Return all IDs (primary + aliases) matching the given prefix."""
    return [oid for oid in record.all_ids() if oid.startswith(prefix)]


def database_severity(group: OsvPackageGroup) -> Optional[str]:
    """
    Extract severity string from database_specific.
    GitHub Advisory DB uses database_specific.severity = "HIGH" etc.
    """
    ds = group.database_specific
    return ds.get("severity") or ds.get("cvss_severity")


def database_cwes(group: OsvPackageGroup) -> List[str]:
    """
    Extract CWE IDs from database_specific.
    GitHub Advisory DB uses database_specific.cwes = [{"cweId": "CWE-79"}].
    """
    ds = group.database_specific
    cwes_raw = ds.get("cwes") or ds.get("cwe_ids") or []
    seen: set = set()
    out = []
    for c in cwes_raw:
        if isinstance(c, dict):
            cid = c.get("cweId") or c.get("cwe_id") or ""
            if cid and cid not in seen:
                seen.add(cid)
                out.append(cid)
        elif isinstance(c, str) and c.startswith("CWE-"):
            if c not in seen:
                seen.add(c)
                out.append(c)
    return out
