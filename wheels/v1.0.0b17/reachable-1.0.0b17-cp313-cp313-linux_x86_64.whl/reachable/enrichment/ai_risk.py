#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.
# STATUS: not-yet-wired — AI-specific risk scoring enrichment.

"""
AI Security Risk Assessment Engine

Calculates risk scores for AI/LLM security findings.
Integrates with the main risk engine to contribute to overall risk score.

Policy References (from RISK_SCORING_MODEL.md):
- AI-001: Prompt injection (direct) - 150 pts
- AI-002: Prompt injection (indirect/RAG) - 100 pts
- AI-003: Sensitive data disclosure - 80 pts
- AI-004: AI supply chain vulnerabilities - 100 pts
- AI-005: Improper output handling - 200 pts
- AI-006: Excessive agency/tool permissions - 100 pts
- AI-007: System prompt leakage - 50 pts
- AI-008: Unbounded resource consumption - 30 pts
- AI-009: MCP tool security violations - 100 pts
- AI-010: Model control bypass - 80 pts
"""

from dataclasses import dataclass, field
from enum import Enum
from typing import Dict, List, Optional, Set


class AIRiskLevel(Enum):
    """AI security risk levels."""

    CRITICAL = 1  # Direct code execution, active exploitation
    HIGH = 2  # Exploitable injection, sensitive disclosure
    MEDIUM = 3  # Potential injection, missing controls
    LOW = 4  # Informational, best practices
    INFO = 5  # Detection only, no risk


@dataclass
class AIRiskConfig:
    """Configuration for AI risk scoring."""

    # Policy ID → Base risk weight
    policy_weights: Dict[str, int] = field(
        default_factory=lambda: {
            "AI-001": 150,  # Direct prompt injection
            "AI-002": 100,  # Indirect injection (RAG)
            "AI-003": 80,  # Sensitive data disclosure
            "AI-004": 100,  # AI supply chain
            "AI-005": 200,  # Improper output handling (code exec!)
            "AI-006": 100,  # Excessive agency
            "AI-007": 50,  # System prompt leakage
            "AI-008": 30,  # Unbounded consumption
            "AI-009": 100,  # MCP tool security
            "AI-010": 80,  # Model control bypass
        }
    )

    # Policy ID → Cap (max points per policy)
    policy_caps: Dict[str, int] = field(
        default_factory=lambda: {
            "AI-001": 300,
            "AI-002": 200,
            "AI-003": 160,
            "AI-004": 0,  # No cap (CVEs)
            "AI-005": 400,
            "AI-006": 200,
            "AI-007": 100,
            "AI-008": 60,
            "AI-009": 200,
            "AI-010": 160,
        }
    )

    # Guard type → Risk reduction percentage
    guard_reductions: Dict[str, float] = field(
        default_factory=lambda: {
            "input_validation": 0.50,  # Pydantic, Zod schemas
            "injection_detection": 0.80,  # Rebuff, LlamaGuard, NeMo
            "output_sanitization": 0.60,  # html.escape, DOMPurify
            "tool_allowlist": 0.70,  # Explicit tool filtering
            "human_in_the_loop": 0.90,  # Confirmation required
            "sandbox": 0.60,  # RestrictedPython, pyodide
            "rate_limiting": 0.50,  # Token/request limits
        }
    )

    # Maximum total guard reduction
    max_guard_reduction: float = 0.90


@dataclass
class AIFindingRisk:
    """Risk assessment for a single AI finding."""

    finding_id: str
    rule_id: str
    policy_id: str
    owasp_llm: str

    # Inputs
    severity: str  # ERROR, WARNING, INFO
    is_reachable: bool
    guards_detected: List[str] = field(default_factory=list)

    # Calculated
    base_weight: int = 0
    guard_reduction: float = 0.0
    final_weight: int = 0
    risk_level: AIRiskLevel = AIRiskLevel.INFO
    reasoning: str = ""


@dataclass
class AIRiskAssessment:
    """Complete AI security risk assessment."""

    # Summary
    total_findings: int = 0
    total_score: int = 0
    adjusted_score: int = 0  # After guard reductions
    risk_level: AIRiskLevel = AIRiskLevel.INFO

    # Breakdown by policy
    by_policy: Dict[str, int] = field(default_factory=dict)
    by_owasp: Dict[str, int] = field(default_factory=dict)
    by_severity: Dict[str, int] = field(default_factory=dict)

    # Guards detected
    guards_detected: Set[str] = field(default_factory=set)
    total_guard_reduction: float = 0.0

    # Individual findings
    findings: List[AIFindingRisk] = field(default_factory=list)

    # Critical findings (immediate attention)
    critical_findings: List[AIFindingRisk] = field(default_factory=list)


class AIRiskEngine:
    """
    AI Security Risk Assessment Engine.

    Calculates risk scores for AI/LLM security findings and determines
    overall AI security risk level.
    """

    def __init__(self, config: Optional[AIRiskConfig] = None):
        self.config = config or AIRiskConfig()

    def assess_finding(
        self, finding: dict, is_reachable: bool = True, guards_detected: Optional[List[str]] = None
    ) -> AIFindingRisk:
        """
        Assess risk for a single AI finding.

        Args:
            finding: AI finding dict with rule_id, severity, metadata
            is_reachable: Whether the code is reachable
            guards_detected: List of guard types detected on code path

        Returns:
            AIFindingRisk with calculated risk
        """
        guards = guards_detected or []

        # Extract metadata
        rule_id = finding.get("rule_id", finding.get("check_id", "unknown"))
        metadata = finding.get("metadata", finding.get("extra", {}).get("metadata", {}))
        policy_id = metadata.get("policy_id", self._infer_policy_id(rule_id))
        owasp_llm = metadata.get("owasp_llm", metadata.get("owasp", ""))
        severity = finding.get("severity", "INFO").upper()

        # Calculate base weight
        base_weight = self.config.policy_weights.get(policy_id, 10)

        # Adjust for reachability
        if not is_reachable:
            base_weight = int(base_weight * 0.25)  # 75% reduction if unreachable

        # Calculate guard reduction
        guard_reduction = 0.0
        matching_guards = []
        for guard in guards:
            if guard in self.config.guard_reductions:
                guard_reduction += self.config.guard_reductions[guard]
                matching_guards.append(guard)

        # Cap guard reduction
        guard_reduction = min(guard_reduction, self.config.max_guard_reduction)

        # Calculate final weight
        final_weight = int(base_weight * (1 - guard_reduction))

        # Determine risk level
        risk_level = self._determine_risk_level(policy_id, severity, is_reachable, final_weight)

        # Build reasoning
        reasoning_parts = []
        if is_reachable:
            reasoning_parts.append("reachable code path")
        else:
            reasoning_parts.append("unreachable (75% reduction)")

        if matching_guards:
            reasoning_parts.append(f"guards: {', '.join(matching_guards)} ({guard_reduction:.0%} reduction)")

        reasoning = "; ".join(reasoning_parts)

        return AIFindingRisk(
            finding_id=finding.get("id", str(hash(str(finding)))[:8]),
            rule_id=rule_id,
            policy_id=policy_id,
            owasp_llm=owasp_llm,
            severity=severity,
            is_reachable=is_reachable,
            guards_detected=guards,
            base_weight=base_weight,
            guard_reduction=guard_reduction,
            final_weight=final_weight,
            risk_level=risk_level,
            reasoning=reasoning,
        )

    def assess_all(
        self,
        findings: List[dict],
        guards_detected: Optional[List[str]] = None,
        reachability_map: Optional[Dict[str, bool]] = None,
    ) -> AIRiskAssessment:
        """
        Assess risk for all AI findings.

        Args:
            findings: List of AI finding dicts
            guards_detected: Global list of guards detected in codebase
            reachability_map: Map of finding_id → is_reachable

        Returns:
            AIRiskAssessment with overall risk and breakdown
        """
        guards = guards_detected or []
        reach_map = reachability_map or {}

        assessment = AIRiskAssessment()
        assessment.guards_detected = set(guards)

        # Track scores by policy (for capping)
        policy_scores: Dict[str, int] = {}

        for finding in findings:
            finding_id = finding.get("id", str(hash(str(finding)))[:8])
            is_reachable = reach_map.get(finding_id, True)  # Default to reachable

            # Assess individual finding
            finding_risk = self.assess_finding(finding, is_reachable, guards)
            assessment.findings.append(finding_risk)

            # Track by policy (with cap)
            policy_id = finding_risk.policy_id
            current_policy_score = policy_scores.get(policy_id, 0)
            cap = self.config.policy_caps.get(policy_id, 1000)

            if cap == 0 or current_policy_score < cap:
                add_score = finding_risk.final_weight
                if cap > 0:
                    add_score = min(add_score, cap - current_policy_score)
                policy_scores[policy_id] = current_policy_score + add_score

            # Track by OWASP
            owasp = finding_risk.owasp_llm
            assessment.by_owasp[owasp] = assessment.by_owasp.get(owasp, 0) + 1

            # Track by severity
            sev = finding_risk.severity
            assessment.by_severity[sev] = assessment.by_severity.get(sev, 0) + 1

            # Track critical findings
            if finding_risk.risk_level == AIRiskLevel.CRITICAL:
                assessment.critical_findings.append(finding_risk)

        # Calculate totals
        assessment.total_findings = len(findings)
        assessment.by_policy = policy_scores
        assessment.total_score = sum(policy_scores.values())

        # Calculate guard reduction impact
        if guards:
            total_reduction = sum(self.config.guard_reductions.get(g, 0) for g in guards)
            assessment.total_guard_reduction = min(total_reduction, self.config.max_guard_reduction)

        assessment.adjusted_score = assessment.total_score  # Already adjusted per-finding

        # Determine overall risk level
        assessment.risk_level = self._determine_overall_risk(assessment)

        return assessment

    def _infer_policy_id(self, rule_id: str) -> str:
        """Infer policy ID from rule ID."""
        rule_lower = rule_id.lower()

        # Direct mappings
        if "llm01" in rule_lower or "prompt" in rule_lower and "inject" in rule_lower:
            return "AI-001"
        if "llm02" in rule_lower or "sensitive" in rule_lower:
            return "AI-003"
        if "llm03" in rule_lower or "supply" in rule_lower:
            return "AI-004"
        if "llm05" in rule_lower or "output" in rule_lower or "exec" in rule_lower:
            return "AI-005"
        if "llm06" in rule_lower or "agency" in rule_lower or "tool" in rule_lower:
            return "AI-006"
        if "llm07" in rule_lower or "leak" in rule_lower:
            return "AI-007"
        if "llm10" in rule_lower or "rate" in rule_lower or "limit" in rule_lower:
            return "AI-008"
        if "mcp" in rule_lower:
            return "AI-009"
        if "control" in rule_lower or "bypass" in rule_lower:
            return "AI-010"

        # Garak/Corpus patterns
        if "garak-dan" in rule_lower or "garak-promptinject" in rule_lower:
            return "AI-001"
        if "garak-leakreplay" in rule_lower:
            return "AI-003"
        if "garak-xss" in rule_lower or "garak-malwaregen" in rule_lower:
            return "AI-005"
        if "corpus-" in rule_lower:
            return "AI-001"  # Most corpus patterns are injection

        return "AI-001"  # Default to prompt injection

    def _determine_risk_level(
        self, policy_id: str, severity: str, is_reachable: bool, final_weight: int
    ) -> AIRiskLevel:
        """Determine risk level for a single finding."""

        # CRITICAL: Output execution vulnerabilities when reachable
        if policy_id == "AI-005" and is_reachable and severity == "ERROR":
            return AIRiskLevel.CRITICAL

        # CRITICAL: Direct prompt injection with high severity
        if policy_id == "AI-001" and is_reachable and severity == "ERROR":
            return AIRiskLevel.CRITICAL

        # HIGH: Reachable + ERROR severity
        if is_reachable and severity == "ERROR":
            return AIRiskLevel.HIGH

        # HIGH: Certain policies always high when reachable
        if is_reachable and policy_id in ["AI-001", "AI-005", "AI-006", "AI-009"]:
            return AIRiskLevel.HIGH

        # MEDIUM: Reachable + WARNING
        if is_reachable and severity == "WARNING":
            return AIRiskLevel.MEDIUM

        # MEDIUM: Certain policies medium even without ERROR
        if is_reachable and policy_id in ["AI-002", "AI-003", "AI-004"]:
            return AIRiskLevel.MEDIUM

        # LOW: Unreachable but still security-relevant
        if not is_reachable and severity in ["ERROR", "WARNING"]:
            return AIRiskLevel.LOW

        # INFO: Everything else
        return AIRiskLevel.INFO

    def _determine_overall_risk(self, assessment: AIRiskAssessment) -> AIRiskLevel:
        """Determine overall AI security risk level."""

        # CRITICAL if any critical findings
        if assessment.critical_findings:
            return AIRiskLevel.CRITICAL

        # CRITICAL if score > 400
        if assessment.adjusted_score >= 400:
            return AIRiskLevel.CRITICAL

        # HIGH if score > 200
        if assessment.adjusted_score >= 200:
            return AIRiskLevel.HIGH

        # MEDIUM if score > 100
        if assessment.adjusted_score >= 100:
            return AIRiskLevel.MEDIUM

        # LOW if score > 25
        if assessment.adjusted_score >= 25:
            return AIRiskLevel.LOW

        # INFO
        return AIRiskLevel.INFO

    def get_score_contribution(self, assessment: AIRiskAssessment) -> int:
        """
        Get the AI security score contribution for the overall risk score.

        This value is added to the BASE_SCORE in the main risk formula.
        """
        return assessment.adjusted_score

    def format_summary(self, assessment: AIRiskAssessment) -> str:
        """Format assessment as human-readable summary."""
        risk_names = {
            AIRiskLevel.CRITICAL: " CRITICAL",
            AIRiskLevel.HIGH: " HIGH",
            AIRiskLevel.MEDIUM: " MEDIUM",
            AIRiskLevel.LOW: " LOW",
            AIRiskLevel.INFO: " INFO",
        }

        lines = [
            "=" * 70,
            "AI SECURITY RISK ASSESSMENT",
            "=" * 70,
            "",
            f"Overall Risk:  {risk_names.get(assessment.risk_level, 'UNKNOWN')}",
            f"Risk Score:    {assessment.adjusted_score} points",
            f"Total Findings: {assessment.total_findings}",
            "",
            "By OWASP LLM Category:",
        ]

        for owasp, count in sorted(assessment.by_owasp.items()):
            lines.append(f"  {owasp}: {count}")

        lines.append("")
        lines.append("By Policy:")

        for policy, score in sorted(assessment.by_policy.items()):
            lines.append(f"  {policy}: {score} pts")

        if assessment.guards_detected:
            lines.append("")
            lines.append(f"Guards Detected: {', '.join(assessment.guards_detected)}")
            lines.append(f"Guard Reduction: {assessment.total_guard_reduction:.0%}")

        if assessment.critical_findings:
            lines.append("")
            lines.append(f"  CRITICAL FINDINGS: {len(assessment.critical_findings)}")
            for f in assessment.critical_findings[:5]:
                lines.append(f"  - {f.rule_id} ({f.policy_id})")

        lines.append("=" * 70)

        return "\n".join(lines)


# Convenience function
def calculate_ai_risk_score(findings: List[dict], guards_detected: Optional[List[str]] = None) -> int:
    """
    Calculate AI security risk score from findings.

    Args:
        findings: List of AI security findings
        guards_detected: List of guard types detected

    Returns:
        Risk score (0-1000+)
    """
    engine = AIRiskEngine()
    assessment = engine.assess_all(findings, guards_detected)
    return assessment.adjusted_score


# For integration with main risk.py
def get_ai_risk_score(ai_findings: List[dict], guards: Optional[List[str]] = None) -> tuple:
    """
    Get AI risk score and assessment for integration with main risk engine.

    Returns:
        (score: int, assessment: AIRiskAssessment)
    """
    engine = AIRiskEngine()
    assessment = engine.assess_all(ai_findings, guards)
    return assessment.adjusted_score, assessment
