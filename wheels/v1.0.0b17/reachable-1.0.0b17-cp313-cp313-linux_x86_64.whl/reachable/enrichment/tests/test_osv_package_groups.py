#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.
"""
Unit tests for reachable.enrichment.osv_package_groups

Covers:
  - parse_osv_record: all field paths including absent/null fields
  - OsvPackageGroup: fix_versions(), fix_commits(), is_still_vulnerable(), introduced_versions()
  - OsvVersionRange: is_fixed()
  - OsvRecord: all_ids(), cve_ids(), ghsa_ids(), go_ids(), pysec_ids(), is_withdrawn(), fix_references()
  - extract_fix_versions(): exact match, name-only fallback, any-group fallback
  - extract_fix_commit(): GIT range extraction
  - best_cvss_score(): CVSS_V3 preference, CVSS_V2 fallback, numeric score string
  - aliases_by_prefix()
  - database_cwes(): GHSA shape, flat string shape
  - database_severity()
  - _merge_records(): multiple records merged, worst severity wins, aliases deduplicated
  - Edge cases: empty record, withdrawn, no ranges, missing package name
"""

import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent.parent.parent))

from reachable.enrichment.osv_package_groups import (
    OsvPackageGroup,
    OsvVersionRange,
    aliases_by_prefix,
    best_cvss_score,
    database_cwes,
    database_severity,
    extract_fix_commit,
    extract_fix_versions,
    parse_osv_record,
)

# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

LOG4SHELL_RAW = {
    "id": "GHSA-jfh8-c2jp-hdp9",
    "aliases": ["CVE-2021-44228", "GO-2021-99999"],
    "related": ["CVE-2021-45046"],
    "summary": "Remote code execution in Log4j2",
    "details": "Apache Log4j2 JNDI features do not protect against attacker-controlled LDAP.",
    "severity": [
        {"type": "CVSS_V3", "score": "CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:C/C:H/I:H/A:H"},
        {"type": "CVSS_V2",  "score": "9.3"},
    ],
    "published": "2021-12-10T00:00:00Z",
    "modified": "2021-12-14T00:00:00Z",
    "withdrawn": None,
    "references": [
        {"type": "ADVISORY", "url": "https://nvd.nist.gov/vuln/detail/CVE-2021-44228"},
        {"type": "FIX",      "url": "https://github.com/apache/logging-log4j2/pull/608"},
        {"type": "WEB",      "url": "https://logging.apache.org/log4j/2.x/security.html"},
    ],
    "credits": [{"name": "Chen Zhaojun", "contact": [], "type": "FINDER"}],
    "affected": [
        {
            "package": {
                "name": "log4j-core",
                "ecosystem": "Maven",
                "purl": "pkg:maven/org.apache.logging.log4j/log4j-core",
            },
            "versions": ["2.0-beta9", "2.12.1", "2.14.1"],
            "ranges": [
                {
                    "type": "ECOSYSTEM",
                    "events": [{"introduced": "2.0-beta9"}, {"fixed": "2.15.0"}],
                },
                {
                    "type": "SEMVER",
                    "events": [{"introduced": "2.0.0"}, {"fixed": "2.15.0"}],
                },
                {
                    "type": "GIT",
                    "repo": "https://github.com/apache/logging-log4j2",
                    "events": [{"introduced": "0"}, {"fixed": "abc123def456"}],
                },
            ],
            "database_specific": {
                "severity": "CRITICAL",
                "cwes": [{"cweId": "CWE-502"}, {"cweId": "CWE-400"}],
            },
            "ecosystem_specific": {"imports": ["org.apache.logging.log4j.core"]},
        }
    ],
}

PYSEC_RAW = {
    "id": "PYSEC-2021-855",
    "aliases": ["CVE-2021-33503", "GHSA-q2q7-5pp4-w6pg"],
    "summary": "urllib3 ReDoS vulnerability",
    "severity": [],
    "published": "2021-06-29T00:00:00Z",
    "modified": "2021-09-29T00:00:00Z",
    "withdrawn": None,
    "references": [],
    "affected": [
        {
            "package": {"name": "urllib3", "ecosystem": "PyPI"},
            "versions": ["1.26.4"],
            "ranges": [
                {
                    "type": "ECOSYSTEM",
                    "events": [{"introduced": "0"}, {"fixed": "1.26.5"}],
                },
            ],
            "database_specific": {"severity": "HIGH"},
        }
    ],
}

WITHDRAWN_RAW = {
    "id": "GHSA-xxxx-yyyy-zzzz",
    "aliases": [],
    "summary": "Erroneously filed advisory",
    "severity": [],
    "published": "2024-01-01T00:00:00Z",
    "modified": "2024-01-15T00:00:00Z",
    "withdrawn": "2024-01-15T12:00:00Z",
    "references": [],
    "affected": [],
}

NO_FIX_RAW = {
    "id": "GHSA-no-fix-0001",
    "aliases": ["CVE-2024-99999"],
    "summary": "Unpatched vulnerability",
    "severity": [{"type": "CVSS_V3", "score": "7.5"}],
    "published": "2024-06-01T00:00:00Z",
    "modified": "2024-06-01T00:00:00Z",
    "withdrawn": None,
    "references": [{"type": "FIX", "url": "https://example.com/fix-pr"}],
    "affected": [
        {
            "package": {"name": "vuln-pkg", "ecosystem": "npm"},
            "versions": [],
            "ranges": [
                {
                    "type": "SEMVER",
                    "events": [{"introduced": "1.0.0"}],  # no fixed event
                },
            ],
            "database_specific": {"cwes": ["CWE-79"]},  # flat string shape
        }
    ],
}

MULTI_GROUP_RAW = {
    "id": "GHSA-multi-0001",
    "aliases": ["CVE-2023-multi"],
    "summary": "Multi-ecosystem vulnerability",
    "severity": [{"type": "CVSS_V2", "score": "6.8"}],
    "published": "2023-01-01T00:00:00Z",
    "modified": "2023-01-01T00:00:00Z",
    "withdrawn": None,
    "references": [],
    "affected": [
        {
            "package": {"name": "requests", "ecosystem": "PyPI"},
            "versions": [],
            "ranges": [{"type": "SEMVER", "events": [{"introduced": "2.0.0"}, {"fixed": "2.28.2"}]}],
            "database_specific": {},
        },
        {
            "package": {"name": "requests", "ecosystem": "npm"},
            "versions": [],
            "ranges": [{"type": "SEMVER", "events": [{"introduced": "0"}, {"fixed": "2.88.0"}]}],
            "database_specific": {},
        },
    ],
}


# ---------------------------------------------------------------------------
# Tests: parse_osv_record
# ---------------------------------------------------------------------------

class TestParseOsvRecord(unittest.TestCase):

    def setUp(self):
        self.log4shell = parse_osv_record(LOG4SHELL_RAW)
        self.pysec = parse_osv_record(PYSEC_RAW)
        self.withdrawn = parse_osv_record(WITHDRAWN_RAW)
        self.no_fix = parse_osv_record(NO_FIX_RAW)
        self.multi = parse_osv_record(MULTI_GROUP_RAW)

    # ── Top-level fields ───────────────────────────────────────────────────

    def test_id_parsed(self):
        self.assertEqual(self.log4shell.id, "GHSA-jfh8-c2jp-hdp9")

    def test_aliases_parsed(self):
        self.assertIn("CVE-2021-44228", self.log4shell.aliases)
        self.assertIn("GO-2021-99999", self.log4shell.aliases)

    def test_related_parsed(self):
        self.assertIn("CVE-2021-45046", self.log4shell.related)

    def test_summary_parsed(self):
        self.assertIn("Log4j2", self.log4shell.summary)

    def test_details_parsed(self):
        self.assertIn("JNDI", self.log4shell.details)

    def test_published_parsed(self):
        self.assertEqual(self.log4shell.published, "2021-12-10T00:00:00Z")

    def test_withdrawn_none(self):
        self.assertIsNone(self.log4shell.withdrawn)

    def test_withdrawn_set(self):
        self.assertEqual(self.withdrawn.withdrawn, "2024-01-15T12:00:00Z")

    def test_credits_parsed(self):
        self.assertEqual(len(self.log4shell.credits), 1)
        self.assertEqual(self.log4shell.credits[0]["name"], "Chen Zhaojun")

    def test_severity_list_parsed(self):
        self.assertEqual(len(self.log4shell.severity), 2)
        types = [s["type"] for s in self.log4shell.severity]
        self.assertIn("CVSS_V3", types)
        self.assertIn("CVSS_V2", types)

    # ── References ─────────────────────────────────────────────────────────

    def test_references_parsed(self):
        self.assertEqual(len(self.log4shell.references), 3)

    def test_fix_references(self):
        fix_refs = self.log4shell.fix_references()
        self.assertEqual(len(fix_refs), 1)
        self.assertIn("pull/608", fix_refs[0])

    def test_advisory_references(self):
        adv_refs = self.log4shell.advisory_references()
        self.assertEqual(len(adv_refs), 1)
        self.assertIn("nvd.nist.gov", adv_refs[0])

    def test_empty_references(self):
        self.assertEqual(self.pysec.fix_references(), [])

    # ── Affected groups ────────────────────────────────────────────────────

    def test_affected_count(self):
        self.assertEqual(len(self.log4shell.affected), 1)
        self.assertEqual(len(self.multi.affected), 2)

    def test_affected_package_name(self):
        grp = self.log4shell.affected[0]
        self.assertEqual(grp.package_name, "log4j-core")

    def test_affected_ecosystem(self):
        grp = self.log4shell.affected[0]
        self.assertEqual(grp.ecosystem, "Maven")

    def test_affected_purl(self):
        grp = self.log4shell.affected[0]
        self.assertIn("log4j-core", grp.purl)

    def test_affected_versions_list(self):
        grp = self.log4shell.affected[0]
        self.assertIn("2.14.1", grp.versions)

    def test_affected_ranges_count(self):
        grp = self.log4shell.affected[0]
        self.assertEqual(len(grp.ranges), 3)

    def test_affected_database_specific(self):
        grp = self.log4shell.affected[0]
        self.assertEqual(grp.database_specific["severity"], "CRITICAL")

    def test_affected_ecosystem_specific(self):
        grp = self.log4shell.affected[0]
        self.assertIn("imports", grp.ecosystem_specific)

    def test_empty_affected(self):
        self.assertEqual(len(self.withdrawn.affected), 0)

    # ── Edge: missing optional fields ──────────────────────────────────────

    def test_empty_raw_produces_empty_record(self):
        rec = parse_osv_record({})
        self.assertEqual(rec.id, "")
        self.assertEqual(rec.aliases, [])
        self.assertEqual(rec.affected, [])
        self.assertIsNone(rec.withdrawn)

    def test_affected_missing_package_name_skipped(self):
        raw = {
            "id": "GHSA-bad-0000",
            "affected": [
                {"package": {"name": "", "ecosystem": "npm"}, "ranges": []},  # skipped
                {"package": {"name": "good-pkg", "ecosystem": "npm"}, "ranges": []},
            ],
        }
        rec = parse_osv_record(raw)
        self.assertEqual(len(rec.affected), 1)
        self.assertEqual(rec.affected[0].package_name, "good-pkg")

    def test_null_aliases_handled(self):
        raw = {"id": "X", "aliases": None}
        rec = parse_osv_record(raw)
        self.assertEqual(rec.aliases, [])

    def test_null_affected_handled(self):
        raw = {"id": "X", "affected": None}
        rec = parse_osv_record(raw)
        self.assertEqual(rec.affected, [])


# ---------------------------------------------------------------------------
# Tests: OsvRecord convenience methods
# ---------------------------------------------------------------------------

class TestOsvRecordMethods(unittest.TestCase):

    def setUp(self):
        self.log4shell = parse_osv_record(LOG4SHELL_RAW)
        self.pysec = parse_osv_record(PYSEC_RAW)
        self.withdrawn = parse_osv_record(WITHDRAWN_RAW)

    def test_all_ids_includes_primary(self):
        ids = self.log4shell.all_ids()
        self.assertIn("GHSA-jfh8-c2jp-hdp9", ids)

    def test_all_ids_includes_aliases(self):
        ids = self.log4shell.all_ids()
        self.assertIn("CVE-2021-44228", ids)
        self.assertIn("GO-2021-99999", ids)

    def test_cve_ids(self):
        cves = self.log4shell.cve_ids()
        self.assertEqual(cves, ["CVE-2021-44228"])

    def test_ghsa_ids(self):
        ghsas = self.log4shell.ghsa_ids()
        self.assertEqual(ghsas, ["GHSA-jfh8-c2jp-hdp9"])

    def test_go_ids(self):
        goids = self.log4shell.go_ids()
        self.assertEqual(goids, ["GO-2021-99999"])

    def test_pysec_ids(self):
        pysecs = self.pysec.pysec_ids()
        self.assertEqual(pysecs, ["PYSEC-2021-855"])

    def test_pysec_ids_none_in_log4shell(self):
        self.assertEqual(self.log4shell.pysec_ids(), [])

    def test_is_withdrawn_false(self):
        self.assertFalse(self.log4shell.is_withdrawn())

    def test_is_withdrawn_true(self):
        self.assertTrue(self.withdrawn.is_withdrawn())

    def test_groups_for_exact_match(self):
        groups = self.log4shell.groups_for("log4j-core", "Maven")
        self.assertEqual(len(groups), 1)

    def test_groups_for_case_insensitive(self):
        groups = self.log4shell.groups_for("LOG4J-CORE", "maven")
        self.assertEqual(len(groups), 1)

    def test_groups_for_no_match(self):
        groups = self.log4shell.groups_for("requests", "PyPI")
        self.assertEqual(len(groups), 0)

    def test_to_dict_has_expected_keys(self):
        d = self.log4shell.to_dict()
        for k in ("id", "aliases", "summary", "severity", "affected", "cve_ids", "fix_refs"):
            self.assertIn(k, d, f"missing key: {k}")

    def test_to_dict_details_truncated(self):
        # to_dict truncates details to 500 chars
        d = self.log4shell.to_dict()
        self.assertLessEqual(len(d["details"]), 500)


# ---------------------------------------------------------------------------
# Tests: OsvPackageGroup
# ---------------------------------------------------------------------------

class TestOsvPackageGroup(unittest.TestCase):

    def setUp(self):
        self.log4shell = parse_osv_record(LOG4SHELL_RAW)
        self.grp = self.log4shell.affected[0]
        self.no_fix_grp = parse_osv_record(NO_FIX_RAW).affected[0]

    def test_fix_versions_semver(self):
        fixes = self.grp.fix_versions()
        self.assertIn("v2.15.0", fixes)

    def test_fix_versions_v_prefix_added(self):
        # Raw OSV has "2.15.0" without v prefix — should be normalised
        for v in self.grp.fix_versions():
            self.assertTrue(v.startswith("v"), f"{v} missing v prefix")

    def test_fix_commits_git(self):
        commits = self.grp.fix_commits()
        self.assertEqual(commits, ["abc123def456"])

    def test_is_still_vulnerable_false(self):
        self.assertFalse(self.grp.is_still_vulnerable())

    def test_is_still_vulnerable_true(self):
        self.assertTrue(self.no_fix_grp.is_still_vulnerable())

    def test_introduced_versions(self):
        introduced = self.grp.introduced_versions()
        # "0" sentinel is excluded; "2.0.0" and "2.0-beta9" may appear
        for v in introduced:
            self.assertNotEqual(v, "0")

    def test_to_dict_has_fix_versions(self):
        d = self.grp.to_dict()
        self.assertIn("fix_versions", d)
        self.assertIn("fix_commits", d)
        self.assertIn("is_still_vulnerable", d)

    def test_no_fix_versions_when_no_fixed_event(self):
        self.assertEqual(self.no_fix_grp.fix_versions(), [])


# ---------------------------------------------------------------------------
# Tests: OsvVersionRange
# ---------------------------------------------------------------------------

class TestOsvVersionRange(unittest.TestCase):

    def test_is_fixed_true(self):
        r = OsvVersionRange(range_type="SEMVER", repo=None, introduced="0", fixed="1.2.3", limit=None)
        self.assertTrue(r.is_fixed())

    def test_is_fixed_false(self):
        r = OsvVersionRange(range_type="SEMVER", repo=None, introduced="0", fixed=None, limit=None)
        self.assertFalse(r.is_fixed())

    def test_to_dict_keys(self):
        r = OsvVersionRange(range_type="GIT", repo="https://github.com/x/y", introduced="abc", fixed="def", limit=None)
        d = r.to_dict()
        self.assertEqual(d["range_type"], "GIT")
        self.assertEqual(d["repo"], "https://github.com/x/y")
        self.assertEqual(d["fixed"], "def")


# ---------------------------------------------------------------------------
# Tests: extract_fix_versions
# ---------------------------------------------------------------------------

class TestExtractFixVersions(unittest.TestCase):

    def setUp(self):
        self.log4shell = parse_osv_record(LOG4SHELL_RAW)
        self.multi = parse_osv_record(MULTI_GROUP_RAW)
        self.no_fix = parse_osv_record(NO_FIX_RAW)

    def test_exact_match(self):
        fixes = extract_fix_versions(self.log4shell, "log4j-core", "Maven")
        self.assertIn("v2.15.0", fixes)

    def test_name_only_fallback(self):
        # Different ecosystem label — should still find by name
        fixes = extract_fix_versions(self.log4shell, "log4j-core", "UnknownEco")
        self.assertIn("v2.15.0", fixes)

    def test_multi_ecosystem_exact(self):
        fixes = extract_fix_versions(self.multi, "requests", "PyPI")
        self.assertIn("v2.28.2", fixes)
        self.assertNotIn("v2.88.0", fixes)

    def test_multi_ecosystem_npm(self):
        fixes = extract_fix_versions(self.multi, "requests", "npm")
        self.assertIn("v2.88.0", fixes)

    def test_no_fix_returns_empty(self):
        fixes = extract_fix_versions(self.no_fix, "vuln-pkg", "npm")
        self.assertEqual(fixes, [])

    def test_wrong_package_returns_empty(self):
        fixes = extract_fix_versions(self.log4shell, "nonexistent", "Maven")
        # Falls back to any group with fixes
        # log4j-core has fixes so last fallback may return them
        # This is correct — any fix is better than none
        self.assertIsInstance(fixes, list)

    def test_empty_record_returns_empty(self):
        rec = parse_osv_record({})
        self.assertEqual(extract_fix_versions(rec, "any", "npm"), [])


# ---------------------------------------------------------------------------
# Tests: extract_fix_commit
# ---------------------------------------------------------------------------

class TestExtractFixCommit(unittest.TestCase):

    def setUp(self):
        self.log4shell = parse_osv_record(LOG4SHELL_RAW)
        self.pysec = parse_osv_record(PYSEC_RAW)

    def test_commit_found(self):
        commit = extract_fix_commit(self.log4shell, "log4j-core", "Maven")
        self.assertEqual(commit, "abc123def456")

    def test_no_git_range_returns_none(self):
        commit = extract_fix_commit(self.pysec, "urllib3", "PyPI")
        self.assertIsNone(commit)


# ---------------------------------------------------------------------------
# Tests: best_cvss_score
# ---------------------------------------------------------------------------

class TestBestCvssScore(unittest.TestCase):

    def setUp(self):
        self.log4shell = parse_osv_record(LOG4SHELL_RAW)
        self.no_fix = parse_osv_record(NO_FIX_RAW)
        self.multi = parse_osv_record(MULTI_GROUP_RAW)
        self.empty = parse_osv_record({})

    def test_prefers_cvss_v3_over_v2(self):
        # log4shell has both V3 (vector string) and V2 ("9.3")
        score, vector = best_cvss_score(self.log4shell)
        # V3 vector string; numeric parsing returns None for CVSS vector strings
        self.assertIn("CVSS:3.1", vector)

    def test_numeric_score_parsed(self):
        # no_fix record has score "7.5" as a plain number string
        score, vector = best_cvss_score(self.no_fix)
        self.assertEqual(score, 7.5)

    def test_cvss_v2_numeric_fallback(self):
        # multi has only CVSS_V2 with score "6.8"
        score, vector = best_cvss_score(self.multi)
        self.assertEqual(score, 6.8)

    def test_no_severity_returns_none(self):
        score, vector = best_cvss_score(self.empty)
        self.assertIsNone(score)
        self.assertIsNone(vector)

    def test_pysec_no_severity(self):
        pysec = parse_osv_record(PYSEC_RAW)
        score, vector = best_cvss_score(pysec)
        self.assertIsNone(score)


# ---------------------------------------------------------------------------
# Tests: aliases_by_prefix
# ---------------------------------------------------------------------------

class TestAliasesByPrefix(unittest.TestCase):

    def setUp(self):
        self.log4shell = parse_osv_record(LOG4SHELL_RAW)

    def test_cve_prefix(self):
        self.assertEqual(aliases_by_prefix(self.log4shell, "CVE-"), ["CVE-2021-44228"])

    def test_go_prefix(self):
        self.assertEqual(aliases_by_prefix(self.log4shell, "GO-"), ["GO-2021-99999"])

    def test_ghsa_prefix_includes_primary(self):
        ghsas = aliases_by_prefix(self.log4shell, "GHSA-")
        self.assertIn("GHSA-jfh8-c2jp-hdp9", ghsas)

    def test_unknown_prefix_returns_empty(self):
        self.assertEqual(aliases_by_prefix(self.log4shell, "RUBBISH-"), [])


# ---------------------------------------------------------------------------
# Tests: database_cwes
# ---------------------------------------------------------------------------

class TestDatabaseCwes(unittest.TestCase):

    def setUp(self):
        self.grp_dict_shape = parse_osv_record(LOG4SHELL_RAW).affected[0]
        self.grp_flat_shape = parse_osv_record(NO_FIX_RAW).affected[0]

    def test_dict_shape_cwes(self):
        cwes = database_cwes(self.grp_dict_shape)
        self.assertIn("CWE-502", cwes)
        self.assertIn("CWE-400", cwes)

    def test_flat_string_shape_cwes(self):
        # NO_FIX_RAW uses {"cwes": ["CWE-79"]} — flat strings
        cwes = database_cwes(self.grp_flat_shape)
        self.assertIn("CWE-79", cwes)

    def test_no_cwes_returns_empty(self):
        grp = OsvPackageGroup(
            package_name="x", ecosystem="npm", purl=None,
            database_specific={},
        )
        self.assertEqual(database_cwes(grp), [])

    def test_deduplication(self):
        grp = OsvPackageGroup(
            package_name="x", ecosystem="npm", purl=None,
            database_specific={"cwes": [{"cweId": "CWE-79"}, {"cweId": "CWE-79"}]},
        )
        cwes = database_cwes(grp)
        self.assertEqual(cwes.count("CWE-79"), 1)


# ---------------------------------------------------------------------------
# Tests: database_severity
# ---------------------------------------------------------------------------

class TestDatabaseSeverity(unittest.TestCase):

    def test_severity_from_database_specific(self):
        grp = parse_osv_record(LOG4SHELL_RAW).affected[0]
        self.assertEqual(database_severity(grp), "CRITICAL")

    def test_no_severity_returns_none(self):
        grp = OsvPackageGroup(
            package_name="x", ecosystem="npm", purl=None,
            database_specific={},
        )
        self.assertIsNone(database_severity(grp))


# ---------------------------------------------------------------------------
# Tests: _merge_records (via threat_intel helper)
# ---------------------------------------------------------------------------

class TestMergeRecords(unittest.TestCase):

    def setUp(self):
        from reachable.enrichment.threat_intel import _merge_records
        self._merge = _merge_records
        self.log4shell = parse_osv_record(LOG4SHELL_RAW)
        self.pysec = parse_osv_record(PYSEC_RAW)

    def test_single_record_passthrough(self):
        merged = self._merge([self.log4shell], "log4j-core", "Maven", "2.14.1")
        self.assertEqual(merged.id, self.log4shell.id)

    def test_empty_returns_sentinel(self):
        merged = self._merge([], "x", "npm", "1.0")
        self.assertEqual(merged.id, "")

    def test_multiple_records_aliases_combined(self):
        merged = self._merge([self.log4shell, self.pysec], "pkg", "PyPI", "1.0")
        all_ids = merged.all_ids()
        # Aliases from both records should appear
        self.assertIn("CVE-2021-44228", all_ids)
        self.assertIn("CVE-2021-33503", all_ids)

    def test_multiple_records_references_combined(self):
        merged = self._merge([self.log4shell, self.pysec], "pkg", "PyPI", "1.0")
        urls = {r["url"] for r in merged.references}
        self.assertIn("https://nvd.nist.gov/vuln/detail/CVE-2021-44228", urls)

    def test_multiple_records_no_duplicate_aliases(self):
        merged = self._merge([self.log4shell, self.log4shell], "log4j-core", "Maven", "2.14.1")
        all_ids = merged.all_ids()
        # No duplicates
        self.assertEqual(len(all_ids), len(set(all_ids)))

    def test_worst_severity_wins_position(self):
        # log4shell has CVSS_V3 (no numeric), pysec has no severity
        # merge should pick log4shell as base (highest score)
        merged = self._merge([self.pysec, self.log4shell], "pkg", "PyPI", "1.0")
        # Base id should be log4shell's (higher CVSS)
        self.assertEqual(merged.id, self.log4shell.id)

    def test_withdrawn_propagated(self):
        withdrawn = parse_osv_record(WITHDRAWN_RAW)
        merged = self._merge([self.log4shell, withdrawn], "x", "npm", "1.0")
        # Any withdrawn record should make merged withdrawn
        self.assertIsNotNone(merged.withdrawn)


# ---------------------------------------------------------------------------
# Tests: Integration — parse → extract pipeline
# ---------------------------------------------------------------------------

class TestIntegrationPipeline(unittest.TestCase):
    """End-to-end: parse a raw record and run the full extraction helpers."""

    def test_log4shell_full_pipeline(self):
        rec = parse_osv_record(LOG4SHELL_RAW)

        # IDs
        self.assertEqual(rec.cve_ids(), ["CVE-2021-44228"])
        self.assertEqual(rec.go_ids(), ["GO-2021-99999"])

        # Fix version
        fixes = extract_fix_versions(rec, "log4j-core", "Maven")
        self.assertIn("v2.15.0", fixes)

        # Fix commit
        commit = extract_fix_commit(rec, "log4j-core", "Maven")
        self.assertEqual(commit, "abc123def456")

        # CVSS — V3 vector (no numeric) preferred over V2 numeric 9.3
        score, vector = best_cvss_score(rec)
        self.assertIn("CVSS:3.1", vector)

        # CWEs
        cwes = database_cwes(rec.affected[0])
        self.assertIn("CWE-502", cwes)

        # Not withdrawn
        self.assertFalse(rec.is_withdrawn())

        # Fix references
        self.assertEqual(len(rec.fix_references()), 1)

    def test_withdrawn_full_pipeline(self):
        rec = parse_osv_record(WITHDRAWN_RAW)
        self.assertTrue(rec.is_withdrawn())
        self.assertEqual(extract_fix_versions(rec, "any", "npm"), [])
        self.assertIsNone(extract_fix_commit(rec, "any", "npm"))
        score, _ = best_cvss_score(rec)
        self.assertIsNone(score)

    def test_pysec_full_pipeline(self):
        rec = parse_osv_record(PYSEC_RAW)
        self.assertEqual(rec.pysec_ids(), ["PYSEC-2021-855"])
        self.assertIn("CVE-2021-33503", rec.cve_ids())
        fixes = extract_fix_versions(rec, "urllib3", "PyPI")
        # ECOSYSTEM range — not SEMVER, so extract_fix_versions returns []
        # (only SEMVER ranges produce v-prefixed fix versions)
        self.assertIsInstance(fixes, list)


if __name__ == "__main__":
    unittest.main(verbosity=2)
