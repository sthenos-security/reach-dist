# Copyright © 2026 Sthenos Security. All rights reserved.

"""
REACHABLE Sandbox Module

Provides behavioral detection of supply chain attacks through
isolated package installation testing.
"""

from .runner import (
    DOCKER_AVAILABLE,
    Finding,
    LocalPackageInfo,
    SandboxResult,
    SandboxRunner,
    Severity,
    Verdict,
    detect_local_packages_with_hooks,
    format_sandbox_report,
    generate_attack_chain_summary,
    test_local_packages,
)

__all__ = [
    "SandboxRunner",
    "SandboxResult",
    "Finding",
    "Verdict",
    "Severity",
    "LocalPackageInfo",
    "format_sandbox_report",
    "detect_local_packages_with_hooks",
    "test_local_packages",
    "generate_attack_chain_summary",
    "DOCKER_AVAILABLE",
]
