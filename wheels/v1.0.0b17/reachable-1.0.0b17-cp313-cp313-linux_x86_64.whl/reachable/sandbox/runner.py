# Copyright © 2026 Sthenos Security. All rights reserved.

"""
REACHABLE Sandbox Runner

Executes package installations in isolated Docker containers and analyzes
behavioral signals to detect supply chain attacks.
"""

import json
import time
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from reachable.core.logger import get_logger

logger = get_logger()

# Check for Docker availability
try:
    import docker

    DOCKER_AVAILABLE = True
except ImportError:
    DOCKER_AVAILABLE = False


class Verdict(Enum):
    """Sandbox analysis verdict"""

    CLEAN = "CLEAN"
    INFO = "INFO"
    SUSPICIOUS = "SUSPICIOUS"
    CRITICAL = "CRITICAL"
    ERROR = "ERROR"


class Severity(Enum):
    """Finding severity levels"""

    INFO = "INFO"
    LOW = "LOW"
    MEDIUM = "MEDIUM"
    HIGH = "HIGH"
    CRITICAL = "CRITICAL"


@dataclass
class Finding:
    """A detection finding from sandbox analysis"""

    rule: str
    severity: Severity
    description: str
    evidence: Dict[str, Any]
    phase: str = "unknown"


@dataclass
class SandboxResult:
    """Result of a sandbox test"""

    package: str
    ecosystem: str
    version: Optional[str]
    verdict: Verdict
    exit_code: int
    duration_ms: int
    events: List[Dict[str, Any]] = field(default_factory=list)
    findings: List[Finding] = field(default_factory=list)
    error: Optional[str] = None
    capability_score: float = 1.0  # 1.0 = clean, 0.0 = critical behavioral risk
    metrics: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "package": self.package,
            "ecosystem": self.ecosystem,
            "version": self.version,
            "verdict": self.verdict.value,
            "exit_code": self.exit_code,
            "duration_ms": self.duration_ms,
            "capability_score": self.capability_score,
            "metrics": self.metrics,
            "findings_count": len(self.findings),
            "findings": [
                {
                    "rule": f.rule,
                    "severity": f.severity.value,
                    "description": f.description,
                    "phase": f.phase,
                    "evidence": f.evidence,
                }
                for f in self.findings
            ],
            "error": self.error,
        }


@dataclass
class BatchSandboxResult:
    """Result of a batch sandbox test (all packages together)"""

    packages: List[str]
    ecosystem: str
    verdict: Verdict
    exit_code: int
    duration_ms: int
    events: List[Dict[str, Any]] = field(default_factory=list)
    findings: List[Finding] = field(default_factory=list)
    error: Optional[str] = None
    capability_score: float = 1.0
    suspicious_packages: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "packages": self.packages,
            "packages_count": len(self.packages),
            "ecosystem": self.ecosystem,
            "verdict": self.verdict.value,
            "exit_code": self.exit_code,
            "duration_ms": self.duration_ms,
            "capability_score": self.capability_score,
            "suspicious_packages": self.suspicious_packages,
            "findings_count": len(self.findings),
            "findings": [
                {"rule": f.rule, "severity": f.severity.value, "description": f.description, "phase": f.phase}
                for f in self.findings
            ],
            "error": self.error,
        }


@dataclass
class HybridSandboxResult:
    """Result of hybrid testing (batch + individual follow-up)"""

    packages: List[str]
    ecosystem: str
    batch_result: BatchSandboxResult
    individual_results: List[SandboxResult]
    verdict: Verdict
    duration_ms: int
    malicious_packages: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "packages": self.packages,
            "packages_count": len(self.packages),
            "ecosystem": self.ecosystem,
            "verdict": self.verdict.value,
            "duration_ms": self.duration_ms,
            "malicious_packages": self.malicious_packages,
            "batch": self.batch_result.to_dict(),
            "individual": [r.to_dict() for r in self.individual_results],
            "summary": {
                "total_packages": len(self.packages),
                "malicious": len(self.malicious_packages),
                "suspicious_tested": len(self.individual_results),
                "batch_verdict": self.batch_result.verdict.value,
            },
        }


# =============================================================================
# REFINED SEVERITY MODEL v4.5.18
# Key insight: "sensitive read + outbound chain" distinguishes MEDIUM from HIGH
# =============================================================================

from .severity_model import (
    KNOWN_BAD_DOMAINS,
    KNOWN_BAD_IPS,
    PERSISTENCE_PATHS,
    SENSITIVE_ENV_VARS,
    SENSITIVE_FILE_PATHS,
    BehaviorContext,
    classify_severity,
    determine_verdict,
)


class ContextAwareAnalyzer:
    """
    Analyzes sandbox events with context tracking for exfil chain detection.

    The key insight is that individual events may be benign, but the combination
    of "sensitive read + outbound attempt" indicates HIGH/CRITICAL severity.

    Severity Levels (v4.5.18 refined):

    CRITICAL - Confirmed malicious with evidence:
      • Credential theft: reads tokens/SSH keys + outbound attempt
      • Data exfiltration: sensitive data read + sent outbound
      • Code execution with persistence (cron, systemd, startup)
      • Crypto-mining with persistence
      • Destructive behavior (rm -rf, ransomware patterns)

    HIGH - Clear malicious intent, incomplete exfil proof:
      • Contacts known bad domains/IPs (threat intel match)
      • Downloads + executes second-stage payload
      • Reads sensitive env/files AND attempts outbound (the chain!)
      • Process injection-like behavior
      • Reverse shell patterns

    MEDIUM - Suspicious but ambiguous (no exfil chain):
      • Unexpected outbound to non-registry domains
      • Unusual shelling out to system commands
      • Environment probing (but no exfil attempt)
      • Obfuscated scripts

    LOW - Minor policy violation:
      • Accessing non-sensitive env vars
      • Writing to unexpected but harmless locations

    INFO - Telemetry / benign:
      • Checks OS/CI vars for compatibility
      • Telemetry to known vendor endpoints
    """

    def __init__(self):
        self.context = BehaviorContext()
        self.findings: List[Finding] = []

    def analyze_events(self, events: List[Dict[str, Any]]) -> List[Finding]:
        """
        Analyze all events with context tracking.

        Two-pass approach:
        1. First pass: Build context (what behaviors were observed)
        2. Second pass: Classify severity with full context
        """
        self.context = BehaviorContext()
        self.findings = []

        # First pass: Build context
        for event in events:
            self._update_context(event)

        # Second pass: Classify with full context
        for event in events:
            severity = classify_severity(event, self.context)

            # Skip non-findings (None) and only keep CRITICAL + MEDIUM
            if severity is None:
                continue

            finding = self._create_finding(event, severity)
            if finding:
                self.findings.append(finding)

        return self.findings

    def _update_context(self, event: Dict[str, Any]):
        """Update behavior context based on event"""
        event_type = event.get("event", "")

        # Track sensitive env access
        if event_type == "env_access":
            var = event.get("variable", "")
            if var in SENSITIVE_ENV_VARS or any(var.startswith(p) for p in ["AWS_", "GITHUB_", "NPM_"]):
                self.context.sensitive_env_accessed.add(var)

        # Track sensitive file access
        if event_type == "honeypot_access":
            path = event.get("path", "")
            if any(sens in path for sens in SENSITIVE_FILE_PATHS):
                self.context.sensitive_files_read.add(path)

        # Track outbound attempts
        if event_type == "network_blocked":
            self.context.outbound_attempts.append(event)
            dest = event.get("destination", "") or event.get("host", "")
            if dest in KNOWN_BAD_DOMAINS or dest in KNOWN_BAD_IPS:
                self.context.known_bad_contacted.append(dest)

        # Blocked network tools (curl, wget, nc) = outbound attempt
        # In sandbox, network is disabled at Docker level, so these tools
        # get blocked by shims before any DNS/TCP happens. But the INTENT
        # to reach the network is clear.
        if event_type == "blocked_execution":
            binary = event.get("binary", "")
            if binary in ("curl", "wget", "nc", "ncat", "netcat"):
                self.context.outbound_attempts.append(event)

        # Track persistence attempts
        if event_type == "file_write":
            path = event.get("path", "")
            if any(pers in path for pers in PERSISTENCE_PATHS):
                self.context.persistence_attempts.append(path)

        # Track shell commands
        if event_type == "process_exec":
            cmd = event.get("command", "")
            self.context.shell_commands.append(cmd)

    def _create_finding(self, event: Dict[str, Any], severity: Severity) -> Optional[Finding]:
        """Create a finding from an event"""
        event_type = event.get("event", "")

        # Map event types to rule IDs and descriptions
        rule_map = {
            "network_blocked": ("NETWORK_DURING_INSTALL", "Network access attempted"),
            "honeypot_access": ("CREDENTIAL_ACCESS", "Credential file accessed"),
            "blocked_execution": ("BLOCKED_TOOL", "Blocked tool execution attempted"),
            "env_access": ("ENV_ACCESS", "Environment variable accessed"),
            "file_write": ("FILE_WRITE", "File write detected"),
            "process_exec": ("PROCESS_EXEC", "Process execution detected"),
            "suspicious_argument": ("SUSPICIOUS_ARG", "Suspicious argument pattern"),
        }

        rule_id, base_desc = rule_map.get(event_type, ("UNKNOWN", "Unknown event"))

        # Enhance description based on severity and context
        if severity == Severity.CRITICAL:
            if self.context.has_exfil_chain:
                base_desc = f"EXFIL CHAIN: {base_desc}"
            elif self.context.has_persistence:
                base_desc = f"PERSISTENCE: {base_desc}"
        elif severity == Severity.HIGH:
            if self.context.contacted_known_bad:
                base_desc = f"KNOWN BAD: {base_desc}"

        # Add specific details
        details = self._get_event_details(event)
        description = f"{base_desc}: {details}" if details else base_desc

        return Finding(
            rule=rule_id,
            severity=severity,
            description=description,
            evidence=event,
            phase=event.get("phase", "unknown"),
        )

    def _get_event_details(self, event: Dict[str, Any]) -> str:
        """Extract human-readable details from event"""
        event_type = event.get("event", "")

        if event_type == "network_blocked":
            dest = event.get("destination", "") or event.get("host", "unknown")
            return f"to {dest}"
        elif event_type == "honeypot_access":
            return event.get("path", "unknown")
        elif event_type == "blocked_execution":
            return event.get("binary", "unknown")
        elif event_type == "env_access":
            return event.get("variable", "unknown")
        elif event_type == "file_write":
            return event.get("path", "unknown")
        elif event_type == "process_exec":
            cmd = event.get("command", "")
            args = event.get("args", [])
            return f"{cmd} {' '.join(args[:3])}..." if args else cmd
        elif event_type == "suspicious_argument":
            return event.get("reason", "")

        return ""

    def get_verdict(self) -> Verdict:
        """Get overall verdict based on findings and context"""
        verdict_str = determine_verdict([{"severity": f.severity.value} for f in self.findings], self.context)
        return Verdict(verdict_str)


# Legacy compatibility: Keep old rule classes but mark as deprecated
# These are replaced by ContextAwareAnalyzer but kept for backward compat


class DetectionRule:
    """DEPRECATED: Use ContextAwareAnalyzer instead"""

    rule_id: str = "UNKNOWN"
    description: str = "Unknown"
    severity: Severity = Severity.INFO

    def match(self, event: Dict[str, Any]) -> Optional[Finding]:
        return None


# Empty list - detection now handled by ContextAwareAnalyzer
DETECTION_RULES: List[DetectionRule] = []


class SandboxRunner:
    """
    Runs package installations in isolated Docker containers.
    """

    # Use local image name - no remote registry pull attempts
    LOCAL_IMAGE = "reachable/sandbox:latest"

    def __init__(
        self,
        image: Optional[str] = None,
        timeout: int = 300,
        memory_limit: str = "1g",
        parallel: int = 4,
        docker_client=None,
    ):
        self.image = image or self.LOCAL_IMAGE
        self.timeout = timeout
        self.memory_limit = memory_limit
        self.parallel = parallel
        self._client = docker_client  # Accept pre-configured client (e.g. Colima-aware)
        self._image_checked = False
        self._image_available = False

    @property
    def client(self):
        """Lazy-load Docker client"""
        if self._client is None:
            if not DOCKER_AVAILABLE:
                raise RuntimeError("Docker Python SDK not installed. Install with: pip install docker")
            self._client = docker.from_env()
        return self._client

    def is_available(self) -> bool:
        """Check if Docker is available"""
        if not DOCKER_AVAILABLE:
            return False
        try:
            self.client.ping()
            return True
        except Exception as e:
            # Store error for diagnostics
            self._docker_error = str(e)
            return False

    def get_unavailable_reason(self) -> str:
        """Get reason why Docker is unavailable"""
        if not DOCKER_AVAILABLE:
            return "Docker Python SDK not installed. Run: pip install docker"
        if hasattr(self, "_docker_error"):
            err = self._docker_error
            if "connection refused" in err.lower() or "connect" in err.lower():
                return "Docker daemon not running. Start Docker Desktop or run: sudo systemctl start docker"
            elif "permission denied" in err.lower():
                return "Permission denied. Add user to docker group or run with sudo"
            else:
                return f"Docker error: {err}"
        return "Unknown Docker error"

    def _build_image(self) -> bool:
        """Build sandbox image locally from Dockerfile"""
        try:
            # Find Dockerfile
            sandbox_dir = Path(__file__).parent.parent.parent / "sandbox"
            dockerfile = sandbox_dir / "Dockerfile"

            if not dockerfile.exists():
                # Try alternate location
                sandbox_dir = Path(__file__).parent
                dockerfile = sandbox_dir / "Dockerfile"

            if not dockerfile.exists():
                return False

            logger.info("Building sandbox image locally...")
            self.client.images.build(path=str(sandbox_dir), tag=self.LOCAL_IMAGE, rm=True, quiet=False)
            return True
        except Exception as e:
            logger.info(f"Failed to build sandbox image: {e}")
            return False

    def ensure_image(self) -> bool:
        """Ensure sandbox image is available (build locally if needed)"""
        if self._image_checked:
            return self._image_available

        self._image_checked = True

        # Check if image exists locally
        try:
            self.client.images.get(self.image)
            self._image_available = True
            return True
        except docker.errors.ImageNotFound:
            pass
        except Exception as e:
            logger.info(f"Docker error checking image: {e}")
            self._image_available = False
            return False

        # Try to build locally (don't try to pull from remote)
        if self._build_image():
            try:
                self.client.images.get(self.LOCAL_IMAGE)
                self.image = self.LOCAL_IMAGE
                self._image_available = True
                return True
            except Exception:
                pass

        # Sandbox not available - this is OK, we'll skip sandbox testing
        self._image_available = False
        return False

    def test_package(self, package: str, ecosystem: str = "npm", version: Optional[str] = None) -> SandboxResult:
        """
        Test a single package in the sandbox.

        Args:
            package: Package name (e.g., "lodash")
            ecosystem: Package ecosystem ("npm" or "pip")
            version: Optional specific version

        Returns:
            SandboxResult with verdict and findings
        """
        if not self.is_available():
            return SandboxResult(
                package=package,
                ecosystem=ecosystem,
                version=version,
                verdict=Verdict.ERROR,
                exit_code=-1,
                duration_ms=0,
                error="Docker is not available",
            )

        if not self.ensure_image():
            return SandboxResult(
                package=package,
                ecosystem=ecosystem,
                version=version,
                verdict=Verdict.ERROR,
                exit_code=-1,
                duration_ms=0,
                error=f"Sandbox image not available: {self.image}",
            )

        # Build package spec
        pkg_spec = f"{package}@{version}" if version else package

        # Build install command
        if ecosystem == "npm":
            install_cmd = f"npm install {pkg_spec}"
        elif ecosystem == "pip":
            install_cmd = f"pip install {pkg_spec}"
        else:
            return SandboxResult(
                package=package,
                ecosystem=ecosystem,
                version=version,
                verdict=Verdict.ERROR,
                exit_code=-1,
                duration_ms=0,
                error=f"Unsupported ecosystem: {ecosystem}",
            )

        start_time = time.time()

        try:
            # Run container
            # NO volume mount — stderr is the sole event transport.
            # Volume mounts expose a host-writable path to untrusted code:
            # disk fill, symlink escape, evidence tampering, parser exploits.
            # Go shims dual-write to file (tmpfs, stays in container) + stderr
            # (SANDBOX_EVENT: prefix, captured by Docker API on host side).
            # This also matches Firecracker where serial console captures stderr.
            container = self.client.containers.run(
                self.image,
                command=install_cmd,
                detach=True,
                remove=False,
                read_only=True,
                network_disabled=True,
                cap_drop=["ALL"],
                security_opt=[
                    "no-new-privileges:true",
                ],
                pids_limit=256,
                mem_limit=self.memory_limit,
                tmpfs={
                    "/tmp": "rw,noexec,nosuid,size=64m",
                    "/work": "rw,nosuid,size=1g,uid=1000,gid=1000",
                    "/var/log/sandbox": "rw,size=16m",
                },
                environment={
                    "HOME": "/home/sandbox",
                    "npm_config_ignore_scripts": "false",
                },
            )

            # Wait for completion
            try:
                result = container.wait(timeout=self.timeout)
                exit_code = result.get("StatusCode", -1)
            except Exception:
                container.kill()
                exit_code = -1

            duration_ms = int((time.time() - start_time) * 1000)

            # Capture stderr — sole event transport (no volume mount)
            stderr = container.logs(stdout=False, stderr=True).decode("utf-8", errors="replace")

            # Clean up container
            container.remove()

            # Parse events from stderr only (SANDBOX_EVENT: prefix)
            events = self._parse_stderr_events(stderr)

            # Use ContextAwareAnalyzer for full chain detection (consistent with test_local_package)
            analyzer = ContextAwareAnalyzer()
            findings = analyzer.analyze_events(events)

            # Derive metrics
            metrics = self._derive_metrics(events, findings)

            # Calculate capability score
            capability_score = self._calculate_capability_score(findings)

            # Determine verdict
            verdict = analyzer.get_verdict()

            return SandboxResult(
                package=package,
                ecosystem=ecosystem,
                version=version,
                verdict=verdict,
                exit_code=exit_code,
                duration_ms=duration_ms,
                events=events,
                findings=findings,
                capability_score=capability_score,
                metrics=metrics,
            )

        except Exception as e:
            duration_ms = int((time.time() - start_time) * 1000)
            return SandboxResult(
                package=package,
                ecosystem=ecosystem,
                version=version,
                verdict=Verdict.ERROR,
                exit_code=-1,
                duration_ms=duration_ms,
                error=str(e),
            )

    def test_local_package(self, pkg: "LocalPackageInfo") -> SandboxResult:
        """
        Test a LOCAL package (from the repo, not a registry) in the sandbox.

        Instead of `npm install <name>` (which hits the registry), this mounts
        the local package directory into the container and runs:
          npm:  npm install /work/local-pkg/
          pip:  pip install /work/local-pkg/

        This catches malware authored directly in the repo — the attack vector
        that registry-only scanning completely misses.

        Args:
            pkg: LocalPackageInfo with path, ecosystem, hooks, etc.

        Returns:
            SandboxResult with verdict, findings, and attack chain summary
        """
        if not self.is_available():
            return SandboxResult(
                package=pkg.name,
                ecosystem=pkg.ecosystem,
                version=pkg.version,
                verdict=Verdict.ERROR,
                exit_code=-1,
                duration_ms=0,
                error="Docker is not available",
            )

        if not self.ensure_image():
            return SandboxResult(
                package=pkg.name,
                ecosystem=pkg.ecosystem,
                version=pkg.version,
                verdict=Verdict.ERROR,
                exit_code=-1,
                duration_ms=0,
                error=f"Sandbox image not available: {self.image}",
            )

        # Build install command — install from mounted local path
        local_mount = "/work/local-pkg"
        if pkg.ecosystem == "npm":
            install_cmd = f"npm install {local_mount}"
        elif pkg.ecosystem == "pip":
            install_cmd = f"pip install {local_mount}"
        else:
            return SandboxResult(
                package=pkg.name,
                ecosystem=pkg.ecosystem,
                version=pkg.version,
                verdict=Verdict.ERROR,
                exit_code=-1,
                duration_ms=0,
                error=f"Unsupported ecosystem: {pkg.ecosystem}",
            )

        start_time = time.time()

        try:
            # Mount the local package directory (read-only) into /work/local-pkg/
            # NO volume mount for logs — stderr is the sole event transport.
            # Same security model as test_package(): no host-writable paths
            # exposed to untrusted code. Go shims dual-write to file (tmpfs,
            # stays in container) + stderr (SANDBOX_EVENT: prefix, captured
            # by Docker API on host side).
            container = self.client.containers.run(
                self.image,
                command=install_cmd,
                detach=True,
                remove=False,
                read_only=True,
                network_disabled=True,
                cap_drop=["ALL"],
                security_opt=[
                    "no-new-privileges:true",
                ],
                pids_limit=256,
                mem_limit=self.memory_limit,
                tmpfs={
                    "/tmp": "rw,noexec,nosuid,size=64m",
                    "/work": "rw,nosuid,size=1g,uid=1000,gid=1000",
                    "/var/log/sandbox": "rw,size=16m",
                },
                environment={
                    "HOME": "/home/sandbox",
                    "npm_config_ignore_scripts": "false",
                },
                volumes={
                    str(pkg.path): {"bind": local_mount, "mode": "ro"},
                },
            )

            # Wait for completion
            try:
                result = container.wait(timeout=self.timeout)
                exit_code = result.get("StatusCode", -1)
            except Exception:
                container.kill()
                exit_code = -1

            duration_ms = int((time.time() - start_time) * 1000)

            # Capture stdout (for banner detection) and stderr (sole event transport)
            stdout_raw = container.logs(stdout=True, stderr=False).decode("utf-8", errors="replace")
            stderr = container.logs(stdout=False, stderr=True).decode("utf-8", errors="replace")

            # Clean up container
            try:
                container.remove()
            except Exception:
                pass

            # Parse events from stderr only (SANDBOX_EVENT: prefix)
            events = self._parse_stderr_events(stderr)

            # Use ContextAwareAnalyzer for full chain detection
            analyzer = ContextAwareAnalyzer()
            findings = analyzer.analyze_events(events)
            verdict = analyzer.get_verdict()

            # Calculate capability score
            capability_score = self._calculate_capability_score(findings)

            # Derive metrics
            metrics = self._derive_metrics(events, findings)
            metrics["local_package"] = True
            metrics["local_path"] = str(pkg.path)
            metrics["install_hooks"] = pkg.hooks

            # Generate attack chain summary and attach to result
            attack_summary = generate_attack_chain_summary(findings, events)
            if attack_summary:
                metrics["attack_chain_summary"] = attack_summary

            # Log the banner if it appeared (shai-hulud prints to stdout)
            if "Shai-Hulud" in stdout_raw or "Muad'Dib" in stdout_raw:
                logger.info(f"  Sandbox captured malware banner from {pkg.name}")

            return SandboxResult(
                package=pkg.name,
                ecosystem=pkg.ecosystem,
                version=pkg.version,
                verdict=verdict,
                exit_code=exit_code,
                duration_ms=duration_ms,
                events=events,
                findings=findings,
                capability_score=capability_score,
                metrics=metrics,
            )

        except Exception as e:
            duration_ms = int((time.time() - start_time) * 1000)
            return SandboxResult(
                package=pkg.name,
                ecosystem=pkg.ecosystem,
                version=pkg.version,
                verdict=Verdict.ERROR,
                exit_code=-1,
                duration_ms=duration_ms,
                error=str(e),
            )

    def _parse_events(self, log_path: Path) -> List[Dict[str, Any]]:
        """Parse JSONL event log file.

        DEPRECATED: Reads from volume-mounted events.jsonl. No longer used
        in the pipeline — stderr is the sole event transport. Kept for
        offline debugging only (manually inspect container tmpfs).
        """
        events = []
        if log_path.exists():
            with open(log_path) as f:
                for line in f:
                    line = line.strip()
                    if line:
                        try:
                            events.append(json.loads(line))
                        except json.JSONDecodeError:
                            pass
        return events

    def _parse_stderr_events(self, stderr: str) -> List[Dict[str, Any]]:
        """Parse events from stderr output"""
        events = []
        for line in stderr.split("\n"):
            if line.startswith("SANDBOX_EVENT:"):
                json_str = line[len("SANDBOX_EVENT:") :].strip()
                try:
                    events.append(json.loads(json_str))
                except json.JSONDecodeError:
                    pass
        return events

    def _analyze_events(self, events: List[Dict[str, Any]]) -> List[Finding]:
        """Apply detection rules to events"""
        findings = []
        seen = set()  # Deduplicate findings

        # Known false positive patterns - these are common in legitimate package names
        FALSE_POSITIVE_PATTERNS = {
            "base64": [
                "js-base64",
                "base64-js",
                "base64url",
                "base64-arraybuffer",
                "base64-stream",
                "node-base64",
                "@types/base64",
                "base64id",
            ],
            "crypto": ["crypto-js", "crypto-random", "crypto-browserify", "@types/crypto"],
            "eval": ["evalmd", "eval-estree", "evaluate"],
            "exec": ["exec-sh", "execa", "cross-spawn"],
        }

        for event in events:
            for rule in DETECTION_RULES:
                finding = rule.match(event)
                if finding:
                    # Check for false positives in SUSPICIOUS_ARGUMENT findings
                    if finding.rule == "SUSPICIOUS_ARGUMENT":
                        # Get the evidence args to check for package names
                        evidence = finding.evidence or {}
                        args_str = " ".join(evidence.get("args", [])).lower()
                        reason = evidence.get("reason", "").lower()

                        # Extract which pattern triggered the detection
                        is_false_positive = False
                        for pattern, known_packages in FALSE_POSITIVE_PATTERNS.items():
                            if pattern in reason:
                                # Check if this pattern appears only as part of a known package name
                                for pkg in known_packages:
                                    if pkg in args_str:
                                        is_false_positive = True
                                        break
                                # Also check for any package that contains the pattern in its name
                                # e.g., any "@scope/foo-base64-bar" package
                                if not is_false_positive and f"{pattern}" in args_str:
                                    # Check if pattern is just part of package name in npm install
                                    if "npm install" in args_str or "npm i " in args_str:
                                        # Pattern in package name is not suspicious
                                        parts = args_str.split()
                                        for part in parts:
                                            if pattern in part and "@" in part or "-" in part:
                                                is_false_positive = True
                                                break
                                if is_false_positive:
                                    break

                        if is_false_positive:
                            continue  # Skip this finding

                    # Create a key for deduplication
                    key = (finding.rule, finding.description)
                    if key not in seen:
                        seen.add(key)
                        findings.append(finding)

        return findings

    def _determine_verdict(self, findings: List[Finding], exit_code: int) -> Verdict:
        """Determine overall verdict from findings"""
        if exit_code == -1:
            return Verdict.ERROR

        severities = [f.severity for f in findings]

        if Severity.CRITICAL in severities:
            return Verdict.CRITICAL
        elif Severity.HIGH in severities:
            return Verdict.SUSPICIOUS
        elif severities:
            return Verdict.INFO
        else:
            return Verdict.CLEAN

    def _calculate_capability_score(self, findings: List[Finding]) -> float:
        """
        Calculate install-time capability score.

        Returns:
            1.0 = Clean (no suspicious behavior)
            0.5 = Warning (HIGH severity findings)
            0.0 = Critical (CRITICAL severity findings - behavioral block)
        """
        severities = [f.severity for f in findings]

        if Severity.CRITICAL in severities:
            return 0.0  # Block - malicious behavior detected
        elif Severity.HIGH in severities:
            return 0.5  # Warn - suspicious behavior
        else:
            return 1.0  # Clean

    def _derive_metrics(self, events: List[Dict[str, Any]], findings: List[Finding]) -> Dict[str, Any]:
        """
        Derive deterministic metrics from events and findings.

        These metrics are reproducible and auditable.
        """
        metrics = {
            "install.network_attempt": False,
            "install.credential_access": False,
            "install.shell_spawn": 0,
            "install.fs_escape": False,
            "install.exec_unexpected": 0,
            "install.suspicious_args": 0,
        }

        for event in events:
            event_type = event.get("event", "")

            if event_type == "network_blocked":
                metrics["install.network_attempt"] = True
            elif event_type == "honeypot_access":
                metrics["install.credential_access"] = True
            elif event_type == "process_spawn":
                binary = event.get("binary", "")
                if binary in ("sh", "bash", "zsh"):
                    metrics["install.shell_spawn"] += 1
            elif event_type == "blocked_execution":
                metrics["install.exec_unexpected"] += 1
            elif event_type == "suspicious_argument":
                metrics["install.suspicious_args"] += 1
            elif event_type == "file_write":
                path = event.get("path", "")
                if not path.startswith(("/work/", "/tmp/")):
                    metrics["install.fs_escape"] = True

        return metrics

    def scan_dependencies(
        self, packages: List[Tuple[str, str, Optional[str]]], progress_callback=None
    ) -> List[SandboxResult]:
        """
        Scan multiple packages.

        Args:
            packages: List of (package, ecosystem, version) tuples
            progress_callback: Optional callback(current, total, package)

        Returns:
            List of SandboxResult
        """
        results = []
        total = len(packages)

        for i, (package, ecosystem, version) in enumerate(packages):
            if progress_callback:
                progress_callback(i + 1, total, package)

            result = self.test_package(package, ecosystem, version)
            results.append(result)

        return results

    def test_batch(
        self, packages: List[Tuple[str, str, Optional[str]]], ecosystem: str = "npm"
    ) -> "BatchSandboxResult":
        """
        Test all packages together in a single container (realistic install).

        This is FAST but cannot attribute findings to specific packages.
        Use this for quick screening, then follow up with individual tests
        if issues are found.

        Args:
            packages: List of (package, ecosystem, version) tuples
            ecosystem: Default ecosystem if not specified per-package

        Returns:
            BatchSandboxResult with aggregate verdict
        """
        if not self.is_available():
            return BatchSandboxResult(
                packages=[p[0] for p in packages],
                ecosystem=ecosystem,
                verdict=Verdict.ERROR,
                exit_code=-1,
                duration_ms=0,
                error="Docker is not available",
            )

        if not self.ensure_image():
            return BatchSandboxResult(
                packages=[p[0] for p in packages],
                ecosystem=ecosystem,
                verdict=Verdict.ERROR,
                exit_code=-1,
                duration_ms=0,
                error=f"Sandbox image not available: {self.image}",
            )

        # Build package specs
        pkg_specs = []
        for pkg, eco, ver in packages:
            eco = eco or ecosystem
            spec = f"{pkg}@{ver}" if ver else pkg
            pkg_specs.append(spec)

        # Build install command
        if ecosystem == "npm":
            install_cmd = f"npm install {' '.join(pkg_specs)}"
        elif ecosystem == "pip":
            install_cmd = f"pip install {' '.join(pkg_specs)}"
        else:
            return BatchSandboxResult(
                packages=[p[0] for p in packages],
                ecosystem=ecosystem,
                verdict=Verdict.ERROR,
                exit_code=-1,
                duration_ms=0,
                error=f"Unsupported ecosystem: {ecosystem}",
            )

        # Run in container — stderr-only event transport (no volume mount)
        start_time = time.time()

        try:
            container = self.client.containers.run(
                self.image,
                command=f"sh -c '{install_cmd}'",
                detach=True,
                remove=False,
                read_only=True,
                network_disabled=True,
                cap_drop=["ALL"],
                security_opt=[
                    "no-new-privileges:true",
                ],
                pids_limit=256,
                mem_limit=self.memory_limit,
                tmpfs={
                    "/tmp": "rw,noexec,nosuid,size=100m",
                    "/work": "rw,nosuid,size=1g,uid=1000,gid=1000",
                    "/var/log/sandbox": "rw,size=16m",
                },
                environment={
                    "HOME": "/home/sandbox",
                    "npm_config_ignore_scripts": "false",
                },
            )

            # Wait for completion
            try:
                result = container.wait(timeout=self.timeout)
                exit_code = result.get("StatusCode", -1)
            except Exception:
                container.kill()
                exit_code = -1

            duration_ms = int((time.time() - start_time) * 1000)

            # Capture stderr — sole event transport
            stderr = container.logs(stdout=False, stderr=True).decode("utf-8", errors="replace")

            # Clean up container
            try:
                container.remove()
            except Exception:
                pass

            # Parse events from stderr only
            events = self._parse_stderr_events(stderr)

            # Use ContextAwareAnalyzer for full chain detection
            analyzer = ContextAwareAnalyzer()
            findings = analyzer.analyze_events(events)
            capability_score = self._calculate_capability_score(findings)
            verdict = analyzer.get_verdict()

            # Try to identify which packages caused issues (heuristic)
            suspicious_packages = self._identify_suspicious_packages(events, findings, [p[0] for p in packages])

            return BatchSandboxResult(
                packages=[p[0] for p in packages],
                ecosystem=ecosystem,
                verdict=verdict,
                exit_code=exit_code,
                duration_ms=duration_ms,
                events=events,
                findings=findings,
                capability_score=capability_score,
                suspicious_packages=suspicious_packages,
            )

        except Exception as e:
            duration_ms = int((time.time() - start_time) * 1000)
            return BatchSandboxResult(
                packages=[p[0] for p in packages],
                ecosystem=ecosystem,
                verdict=Verdict.ERROR,
                exit_code=-1,
                duration_ms=duration_ms,
                error=str(e),
            )

    def test_parallel(
        self, packages: List[Tuple[str, str, Optional[str]]], max_workers: int = None, progress_callback=None
    ) -> List[SandboxResult]:
        """
        Test packages in parallel using multiple containers.

        Args:
            packages: List of (package, ecosystem, version) tuples
            max_workers: Max parallel containers (default: self.parallel)
            progress_callback: Optional callback(current, total, package)

        Returns:
            List of SandboxResult (one per package)
        """
        from concurrent.futures import ThreadPoolExecutor, as_completed

        max_workers = max_workers or self.parallel
        results = []
        completed = 0
        total = len(packages)

        def test_one(pkg_tuple):
            package, ecosystem, version = pkg_tuple
            return self.test_package(package, ecosystem, version)

        with ThreadPoolExecutor(max_workers=max_workers) as executor:
            future_to_pkg = {executor.submit(test_one, pkg): pkg for pkg in packages}

            for future in as_completed(future_to_pkg):
                completed += 1
                pkg = future_to_pkg[future]

                if progress_callback:
                    progress_callback(completed, total, pkg[0])

                try:
                    result = future.result()
                    results.append(result)
                except Exception as e:
                    results.append(
                        SandboxResult(
                            package=pkg[0],
                            ecosystem=pkg[1],
                            version=pkg[2],
                            verdict=Verdict.ERROR,
                            exit_code=-1,
                            duration_ms=0,
                            error=str(e),
                        )
                    )

        return results

    def test_hybrid(
        self, packages: List[Tuple[str, str, Optional[str]]], ecosystem: str = "npm", progress_callback=None
    ) -> "HybridSandboxResult":
        """
        Hybrid testing: batch first, then individual tests for suspicious packages.

        This is the recommended approach for large dependency lists:
        1. Quick batch test (~60s for 100 packages)
        2. If batch is clean, done
        3. If batch fails, parallel individual tests on suspicious packages

        Args:
            packages: List of (package, ecosystem, version) tuples
            ecosystem: Default ecosystem
            progress_callback: Optional callback(phase, current, total, package)

        Returns:
            HybridSandboxResult with complete analysis
        """
        start_time = time.time()

        # Phase 1: Batch test
        if progress_callback:
            progress_callback("batch", 0, 1, "all packages")

        batch_result = self.test_batch(packages, ecosystem)

        if progress_callback:
            progress_callback("batch", 1, 1, "complete")

        # If clean, we're done
        if batch_result.verdict == Verdict.CLEAN:
            return HybridSandboxResult(
                packages=[p[0] for p in packages],
                ecosystem=ecosystem,
                batch_result=batch_result,
                individual_results=[],
                verdict=Verdict.CLEAN,
                duration_ms=int((time.time() - start_time) * 1000),
                malicious_packages=[],
            )

        # Phase 2: Test suspicious packages individually
        suspicious = batch_result.suspicious_packages or [p[0] for p in packages]
        suspicious_tuples = [(pkg, eco, ver) for pkg, eco, ver in packages if pkg in suspicious]

        def individual_progress(current, total, pkg):
            if progress_callback:
                progress_callback("individual", current, total, pkg)

        individual_results = self.test_parallel(suspicious_tuples, progress_callback=individual_progress)

        # Identify confirmed malicious packages
        malicious = [r.package for r in individual_results if r.verdict == Verdict.CRITICAL]

        # Determine overall verdict
        if malicious:
            overall_verdict = Verdict.CRITICAL
        elif any(r.verdict == Verdict.SUSPICIOUS for r in individual_results):
            overall_verdict = Verdict.SUSPICIOUS
        else:
            overall_verdict = batch_result.verdict

        return HybridSandboxResult(
            packages=[p[0] for p in packages],
            ecosystem=ecosystem,
            batch_result=batch_result,
            individual_results=individual_results,
            verdict=overall_verdict,
            duration_ms=int((time.time() - start_time) * 1000),
            malicious_packages=malicious,
        )

    def _identify_suspicious_packages(
        self, events: List[Dict[str, Any]], findings: List[Finding], packages: List[str]
    ) -> List[str]:
        """
        When batch fails, return ALL packages for individual testing.

        SECURITY MODEL:
        Everything inside the container is UNTRUSTED. Malware controls
        env vars, stdout, stderr, event logs, file contents — all of it.
        We do NOT attempt attribution from container data.

        When batch detects malicious behavior:
          1. Kill the batch container immediately
          2. Test EVERY package individually (one container, one package)
          3. Host labels each result — container is a black box

        This is slower but guarantees finding all malicious packages
        regardless of evasion techniques. No heuristics, no shortcuts.
        """
        if not findings:
            return []

        logger.info(f"  Batch CRITICAL — testing all {len(packages)} packages individually")
        return list(packages)


# =============================================================================
# LOCAL PACKAGE DETECTION AND TESTING
# =============================================================================


@dataclass
class LocalPackageInfo:
    """A local package detected in the repo with install-time hooks."""

    name: str
    path: Path
    ecosystem: str  # 'npm' or 'pip'
    version: Optional[str] = None
    hooks: List[str] = field(default_factory=list)  # e.g. ['postinstall', 'preinstall']
    risk_reason: str = ""


def detect_local_packages_with_hooks(repo_dir: str) -> List[LocalPackageInfo]:
    """
    Scan a repository for local packages that have install-time hooks.

    These are packages defined IN the repo (not pulled from a registry) that
    execute code during installation. This is the attack vector for malware
    like shai-hulud that lives directly in a repo.

    Detects:
      npm:  package.json with scripts.preinstall, scripts.postinstall, or scripts.install
      pip:  setup.py (arbitrary code execution on pip install)
            pyproject.toml with [tool.setuptools] build backends

    Args:
        repo_dir: Path to repository root

    Returns:
        List of LocalPackageInfo for packages with install hooks
    """
    repo_path = Path(repo_dir)
    results = []

    # -------------------------------------------------------------------------
    # npm: Find package.json files with install scripts
    # -------------------------------------------------------------------------
    for pkg_json in repo_path.rglob("package.json"):
        # Skip node_modules, .git, build artifacts
        parts = pkg_json.parts
        if any(skip in parts for skip in ("node_modules", ".git", "dist", "build", "__pycache__")):
            continue

        try:
            pkg_data = json.loads(pkg_json.read_text())
        except (json.JSONDecodeError, OSError):
            continue

        scripts = pkg_data.get("scripts", {})
        install_hooks = []
        for hook in ("preinstall", "install", "postinstall"):
            if hook in scripts and scripts[hook].strip():
                install_hooks.append(hook)

        if install_hooks:
            name = pkg_data.get("name", pkg_json.parent.name)
            version = pkg_data.get("version", "0.0.0")
            hook_cmds = [f"{h}: {scripts[h]}" for h in install_hooks]

            results.append(
                LocalPackageInfo(
                    name=name,
                    path=pkg_json.parent,
                    ecosystem="npm",
                    version=version,
                    hooks=install_hooks,
                    risk_reason=f"npm install hooks: {', '.join(hook_cmds)}",
                )
            )

    # -------------------------------------------------------------------------
    # pip: Find setup.py files (arbitrary code on pip install)
    # -------------------------------------------------------------------------
    for setup_py in repo_path.rglob("setup.py"):
        parts = setup_py.parts
        if any(skip in parts for skip in (".git", "dist", "build", "__pycache__", "venv", ".venv", "node_modules")):
            continue

        # setup.py always runs arbitrary code on pip install
        # Check if there's a pyproject.toml or setup.cfg alongside it
        pkg_dir = setup_py.parent
        name = pkg_dir.name
        version = None

        # Try to extract name/version from setup.py without executing it
        try:
            content = setup_py.read_text()
            import re

            name_match = re.search(r"name\s*=\s*['\"]([^'\"]+)['\"]", content)
            if name_match:
                name = name_match.group(1)
            version_match = re.search(r"version\s*=\s*['\"]([^'\"]+)['\"]", content)
            if version_match:
                version = version_match.group(1)
        except OSError:
            pass

        results.append(
            LocalPackageInfo(
                name=name,
                path=pkg_dir,
                ecosystem="pip",
                version=version,
                hooks=["setup.py"],
                risk_reason="setup.py executes arbitrary Python on pip install",
            )
        )

    if results:
        logger.info(f"Detected {len(results)} local package(s) with install hooks:")
        for pkg in results:
            logger.info(f"  {pkg.ecosystem}: {pkg.name} @ {pkg.path} [{', '.join(pkg.hooks)}]")

    return results


def test_local_packages(
    repo_dir: str,
    runner: Optional["SandboxRunner"] = None,
    timeout: int = 300,
    packages: Optional[List[LocalPackageInfo]] = None,
) -> List[SandboxResult]:
    """
    Detect and test all local packages with install hooks in a repo.

    Args:
        repo_dir: Path to repository root
        runner: Optional SandboxRunner instance (creates one if not provided)
        timeout: Container timeout in seconds
        packages: Optional pre-detected packages (avoids duplicate detection)

    Returns:
        List of SandboxResult (one per local package)
    """
    local_packages = packages or detect_local_packages_with_hooks(repo_dir)
    if not local_packages:
        return []

    if runner is None:
        runner = SandboxRunner(timeout=timeout)

    results = []
    for pkg in local_packages:
        logger.info(f"  Sandbox testing local package: {pkg.name} ({pkg.ecosystem})")
        result = runner.test_local_package(pkg)
        results.append(result)

        icon = {
            "CLEAN": "\u2705",
            "INFO": "\u2139\ufe0f",
            "SUSPICIOUS": "\u26a0\ufe0f",
            "CRITICAL": "\U0001f6a8",
            "ERROR": "\u274c",
        }.get(result.verdict.value, "?")
        logger.info(f"    {icon} {pkg.name}: {result.verdict.value}")
        if result.findings:
            summary = generate_attack_chain_summary(result.findings, result.events)
            if summary:
                logger.info(f"    {summary}")

    return results


def generate_attack_chain_summary(findings: List[Finding], events: List[Dict[str, Any]]) -> str:
    """
    Generate a short human-readable attack chain summary from sandbox findings.

    Example output:
        "Credential theft: read ~/.aws/credentials, ~/.ssh/id_rsa, ~/.npmrc
         \u2192 exfil attempt to c2.shai-hulud-attack.test (blocked)
         \u2192 DNS exfil fallback to dns-exfil.attacker.test (blocked)"

    Args:
        findings: List of Finding objects from sandbox analysis
        events: Raw events from sandbox

    Returns:
        Short summary string, or empty string if no meaningful findings
    """
    if not findings:
        return ""

    # Collect behaviors by category
    cred_files = []
    cred_envs = []
    network_targets = []
    blocked_tools = []
    shell_cmds = []

    for event in events:
        etype = event.get("event", "")
        if etype == "honeypot_access":
            path = event.get("path", "")
            # Shorten path for display
            short = path.replace("/home/sandbox", "~")
            if short not in cred_files:
                cred_files.append(short)
        elif etype == "env_access":
            var = event.get("variable", "")
            if var and var not in cred_envs:
                cred_envs.append(var)
        elif etype == "network_blocked":
            dest = event.get("destination", "") or event.get("host", "")
            if dest and dest not in network_targets:
                network_targets.append(dest)
        elif etype == "blocked_execution":
            binary = event.get("binary", "")
            if binary and binary not in blocked_tools:
                blocked_tools.append(binary)
        elif etype == "process_exec":
            cmd = event.get("command", "")
            if cmd and cmd not in ("npm", "node", "pip", "python3", "python", "sh", "bash"):
                shell_cmds.append(cmd)

    # Build narrative
    parts = []

    if cred_files or cred_envs:
        items = []
        if cred_files:
            items.append(f"read {', '.join(cred_files[:5])}")
        if cred_envs:
            items.append(f"harvested env vars: {', '.join(cred_envs[:5])}")
        parts.append("Credential theft: " + "; ".join(items))

    if network_targets:
        targets_str = ", ".join(network_targets[:3])
        if len(network_targets) > 3:
            targets_str += f" +{len(network_targets) - 3} more"
        parts.append(f"\u2192 exfil attempt to {targets_str} (blocked)")

    if blocked_tools:
        parts.append(f"\u2192 blocked tools: {', '.join(blocked_tools)}")

    if not parts:
        # Fall back to severity summary
        sev_counts = {}
        for f in findings:
            sev = f.severity.value if hasattr(f.severity, "value") else str(f.severity)
            sev_counts[sev] = sev_counts.get(sev, 0) + 1
        return f"{len(findings)} findings: " + ", ".join(f"{v} {k}" for k, v in sev_counts.items())

    return " ".join(parts)


def format_sandbox_report(results: List[SandboxResult]) -> str:
    """Format sandbox results as a text report"""
    lines = []
    lines.append(" SANDBOX ANALYSIS")
    lines.append("=" * 80)
    lines.append("")

    # Summary
    summary = {v: 0 for v in Verdict}
    for r in results:
        summary[r.verdict] += 1

    lines.append(f"Packages tested: {len(results)}")
    lines.append(f"   Clean: {summary[Verdict.CLEAN]}")
    lines.append(f"    Info: {summary[Verdict.INFO]}")
    lines.append(f"    Suspicious: {summary[Verdict.SUSPICIOUS]}")
    lines.append(f"   Critical: {summary[Verdict.CRITICAL]}")
    lines.append(f"   Error: {summary[Verdict.ERROR]}")
    lines.append("")

    # Details for non-clean results
    for r in results:
        if r.verdict in (Verdict.SUSPICIOUS, Verdict.CRITICAL, Verdict.ERROR):
            icon = {"SUSPICIOUS": "", "CRITICAL": "", "ERROR": ""}[r.verdict.value]
            lines.append(f"{icon} {r.package} ({r.ecosystem}): {r.verdict.value}")

            if r.error:
                lines.append(f"   Error: {r.error}")

            for f in r.findings:
                sev_icon = {"CRITICAL": "", "HIGH": "", "MEDIUM": ""}.get(f.severity.value, "")
                lines.append(f"   {sev_icon} [{f.rule}] {f.description}")

            lines.append("")

    return "\n".join(lines)
