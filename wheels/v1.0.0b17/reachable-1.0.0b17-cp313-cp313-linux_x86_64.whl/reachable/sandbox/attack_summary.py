# Copyright © 2026 Sthenos Security. All rights reserved.

"""
Attack Chain Summary Generator

Builds a concise, human-readable narrative from sandbox events and findings.
Used in CLI output, dashboard cards, and structured JSON reports.

Architecture:
    Raw events (events.jsonl) → ContextAwareAnalyzer (findings) → AttackChainSummary

Output examples:
    CRITICAL: "Credential theft: read ~/.aws/credentials, ~/.ssh/id_rsa, ~/.npmrc
               → exfil attempt to c2.shai-hulud-attack.test:443 (blocked)
               → DNS exfil fallback to dns-exfil.attacker.test (blocked)"

    WARNING:  "Suspicious: network access to unknown-host.com (blocked),
               environment probing (CI, GITHUB_ACTIONS)"

    CLEAN:    "No malicious behavior detected"
"""

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional


class MalwareStatus(Enum):
    """
    Per-package malware status from sandbox analysis.

    This is the external-facing status exposed in reports and dashboards.
    Verdict (CLEAN/INFO/WARNING/CRITICAL/ERROR) is the internal classification;
    MalwareStatus is what the user sees.
    """

    MALICIOUS = "MALICIOUS"  # Confirmed malicious behavior (CRITICAL verdict)
    SUSPICIOUS = "SUSPICIOUS"  # Suspicious but inconclusive (WARNING/INFO verdict)
    CLEAN = "CLEAN"  # No behavioral indicators (CLEAN verdict)
    ERROR = "ERROR"  # Sandbox execution failed
    SKIPPED = "SKIPPED"  # Sandbox not available or not applicable


@dataclass
class AttackChainSummary:
    """
    Structured summary of sandbox behavioral analysis for a single package.

    Includes:
    - malware_status: Per-package status (MALICIOUS/SUSPICIOUS/CLEAN/ERROR/SKIPPED)
    - narrative: One-line human-readable summary of the attack chain
    - stages: Ordered list of attack stages observed
    - event_count: Total sandbox events captured
    - critical_events: Count of CRITICAL severity events
    - credentials_accessed: List of honeypot files/env vars touched
    - network_targets: List of outbound destinations attempted
    - kill_reason: If fail-fast killed the container, the triggering event
    """

    malware_status: MalwareStatus
    narrative: str
    stages: List[str] = field(default_factory=list)
    event_count: int = 0
    critical_events: int = 0
    credentials_accessed: List[str] = field(default_factory=list)
    network_targets: List[str] = field(default_factory=list)
    blocked_tools: List[str] = field(default_factory=list)
    persistence_paths: List[str] = field(default_factory=list)
    kill_reason: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        d = {
            "malware_status": self.malware_status.value,
            "narrative": self.narrative,
            "stages": self.stages,
            "event_count": self.event_count,
            "critical_events": self.critical_events,
        }
        if self.credentials_accessed:
            d["credentials_accessed"] = self.credentials_accessed
        if self.network_targets:
            d["network_targets"] = self.network_targets
        if self.blocked_tools:
            d["blocked_tools"] = self.blocked_tools
        if self.persistence_paths:
            d["persistence_paths"] = self.persistence_paths
        if self.kill_reason:
            d["kill_reason"] = self.kill_reason
        return d

    def to_log_line(self) -> str:
        """Single-line log output for CLI / scan log."""
        status_icon = {
            MalwareStatus.MALICIOUS: "🚨",
            MalwareStatus.SUSPICIOUS: "⚠️",
            MalwareStatus.CLEAN: "✅",
            MalwareStatus.ERROR: "❌",
            MalwareStatus.SKIPPED: "⏭️",
        }.get(self.malware_status, "?")
        return f"{status_icon} [{self.malware_status.value}] {self.narrative}"


# =========================================================================
# SENSITIVE PATH DISPLAY NAMES
# =========================================================================

_CRED_DISPLAY = {
    "/.aws/credentials": "~/.aws/credentials",
    "/.aws/config": "~/.aws/config",
    "/.ssh/id_rsa": "~/.ssh/id_rsa",
    "/.ssh/id_ed25519": "~/.ssh/id_ed25519",
    "/.ssh/id_ecdsa": "~/.ssh/id_ecdsa",
    "/.ssh/config": "~/.ssh/config",
    "/.npmrc": "~/.npmrc",
    "/.pypirc": "~/.pypirc",
    "/.netrc": "~/.netrc",
    "/.docker/config.json": "~/.docker/config.json",
    "/.kube/config": "~/.kube/config",
    "/.git-credentials": "~/.git-credentials",
    "/.gitconfig": "~/.gitconfig",
    "/.env": "~/.env",
}


def _short_path(path: str) -> str:
    """Return display-friendly credential path."""
    for pattern, display in _CRED_DISPLAY.items():
        if pattern in path:
            return display
    # Fallback: strip /home/sandbox prefix
    return path.replace("/home/sandbox", "~")


# =========================================================================
# MAIN ENTRY POINT
# =========================================================================


def generate_attack_summary(
    events: List[Dict[str, Any]],
    findings: List[Any],
    verdict_value: str,
    kill_reason: Optional[str] = None,
) -> AttackChainSummary:
    """
    Build an AttackChainSummary from raw sandbox events and analyzed findings.

    Args:
        events: Raw events parsed from events.jsonl + stderr
        findings: List of Finding objects (from ContextAwareAnalyzer)
        verdict_value: Verdict string ("CLEAN", "INFO", "WARNING", "CRITICAL", "ERROR")
        kill_reason: If container was killed early, the reason string

    Returns:
        AttackChainSummary with narrative and structured data
    """

    # ---- Collect behavioral signals from raw events ----

    creds_accessed: List[str] = []
    env_vars_accessed: List[str] = []
    network_targets: List[str] = []
    blocked_tools: List[str] = []
    persistence_paths: List[str] = []
    stages: List[str] = []
    critical_count = 0

    seen_creds = set()
    seen_net = set()
    seen_tools = set()

    for event in events:
        etype = event.get("event", "")
        severity = event.get("severity", "")

        if severity == "CRITICAL":
            critical_count += 1

        # Credential file access
        if etype == "honeypot_access":
            path = event.get("path", "")
            short = _short_path(path)
            if short not in seen_creds:
                seen_creds.add(short)
                creds_accessed.append(short)

        # Sensitive env var access
        if etype == "env_access":
            var = event.get("variable", "")
            sensitive_prefixes = (
                "AWS_",
                "GITHUB_",
                "GH_",
                "GITLAB_",
                "NPM_",
                "NODE_AUTH",
                "CI_",
                "SECRET",
                "API_KEY",
                "PRIVATE_KEY",
                "DATABASE_URL",
                "DOCKER_",
                "SLACK_",
                "DISCORD_",
            )
            if any(var.startswith(p) or var == p for p in sensitive_prefixes):
                if var not in seen_creds:
                    seen_creds.add(var)
                    env_vars_accessed.append(var)

        # Network blocked
        if etype == "network_blocked":
            dest = event.get("destination", "") or event.get("host", "")
            port = event.get("port", "")
            target = f"{dest}:{port}" if port else dest
            if target and target not in seen_net:
                seen_net.add(target)
                network_targets.append(target)

        # Blocked tool execution
        if etype == "blocked_execution":
            binary = event.get("binary", "")
            if binary and binary not in seen_tools:
                seen_tools.add(binary)
                blocked_tools.append(binary)

        # Persistence
        if etype == "file_write":
            path = event.get("path", "")
            persistence_markers = (
                "/etc/cron",
                "/var/spool/cron",
                "/.bashrc",
                "/.bash_profile",
                "/.profile",
                "/.zshrc",
                "/etc/systemd",
                "/etc/init.d",
                "/.config/autostart",
            )
            if any(m in path for m in persistence_markers):
                persistence_paths.append(path)

    # Also count CRITICAL from findings (severity model may upgrade events)
    for f in findings:
        sev = f.severity.value if hasattr(f, "severity") else str(f.get("severity", ""))
        if sev == "CRITICAL":
            critical_count += 1

    # Deduplicate critical count (events + findings may overlap)
    # Use the max of raw event count and finding count
    critical_count = max(
        critical_count,
        sum(
            1
            for f in findings
            if (f.severity.value if hasattr(f, "severity") else str(f.get("severity", ""))) == "CRITICAL"
        ),
    )

    # ---- Build ordered attack stages ----

    if creds_accessed or env_vars_accessed:
        all_creds = creds_accessed + [f"${v}" for v in env_vars_accessed]
        stages.append(
            f"credential harvest: {', '.join(all_creds[:6])}"
            + (f" (+{len(all_creds) - 6} more)" if len(all_creds) > 6 else "")
        )

    if network_targets:
        stages.append(
            f"exfil attempt: {', '.join(network_targets[:4])}"
            + (f" (+{len(network_targets) - 4} more)" if len(network_targets) > 4 else "")
            + " (blocked)"
        )

    if blocked_tools:
        stages.append(f"blocked tools: {', '.join(blocked_tools)}")

    if persistence_paths:
        stages.append(f"persistence: {', '.join(persistence_paths[:3])}")

    # ---- Determine malware status ----

    if verdict_value == "CRITICAL":
        malware_status = MalwareStatus.MALICIOUS
    elif verdict_value in ("WARNING", "INFO"):
        # INFO with findings = SUSPICIOUS, not CLEAN
        has_findings = bool(findings) or bool(stages)
        malware_status = MalwareStatus.SUSPICIOUS if has_findings else MalwareStatus.CLEAN
    elif verdict_value == "ERROR":
        malware_status = MalwareStatus.ERROR
    elif verdict_value == "CLEAN":
        malware_status = MalwareStatus.CLEAN
    else:
        malware_status = MalwareStatus.SKIPPED

    # ---- Build narrative ----

    if malware_status == MalwareStatus.MALICIOUS:
        narrative = _build_malicious_narrative(
            creds_accessed,
            env_vars_accessed,
            network_targets,
            blocked_tools,
            persistence_paths,
            kill_reason,
        )
    elif malware_status == MalwareStatus.SUSPICIOUS:
        narrative = _build_suspicious_narrative(
            creds_accessed,
            env_vars_accessed,
            network_targets,
            blocked_tools,
        )
    elif malware_status == MalwareStatus.ERROR:
        narrative = "Sandbox execution failed"
    elif malware_status == MalwareStatus.SKIPPED:
        narrative = "Sandbox analysis not available"
    else:
        narrative = "No malicious behavior detected"

    if kill_reason:
        narrative += f" [container killed: {kill_reason}]"

    return AttackChainSummary(
        malware_status=malware_status,
        narrative=narrative,
        stages=stages,
        event_count=len(events),
        critical_events=critical_count,
        credentials_accessed=creds_accessed + [f"${v}" for v in env_vars_accessed],
        network_targets=network_targets,
        blocked_tools=blocked_tools,
        persistence_paths=persistence_paths,
        kill_reason=kill_reason,
    )


# =========================================================================
# NARRATIVE BUILDERS
# =========================================================================


def _build_malicious_narrative(
    creds: List[str],
    env_vars: List[str],
    network: List[str],
    tools: List[str],
    persistence: List[str],
    kill_reason: Optional[str],
) -> str:
    """Build a CRITICAL narrative: credential theft → exfil → persistence."""
    parts = []

    # Credential harvest
    if creds or env_vars:
        all_creds = creds + [f"${v}" for v in env_vars]
        if len(all_creds) <= 4:
            parts.append(f"Credential theft: read {', '.join(all_creds)}")
        else:
            parts.append(f"Credential theft: read {', '.join(all_creds[:3])} (+{len(all_creds) - 3} more)")

    # Exfil attempts
    if network:
        if len(network) == 1:
            parts.append(f"exfil attempt to {network[0]} (blocked)")
        elif len(network) <= 3:
            parts.append(f"exfil attempts to {', '.join(network)} (all blocked)")
        else:
            parts.append(f"exfil attempts to {network[0]} (+{len(network) - 1} fallbacks, all blocked)")

    # Persistence
    if persistence:
        parts.append(f"persistence via {', '.join(persistence[:2])}")

    # Blocked tools
    if tools and not network:
        # Only mention tools if network wasn't already covered
        parts.append(f"attempted {', '.join(tools)} execution (blocked)")

    if not parts:
        return "Malicious install-time behavior detected"

    return " → ".join(parts)


def _build_suspicious_narrative(
    creds: List[str],
    env_vars: List[str],
    network: List[str],
    tools: List[str],
) -> str:
    """Build a WARNING/SUSPICIOUS narrative."""
    parts = []

    if network:
        parts.append(f"network access to {', '.join(network[:2])} (blocked)")

    if creds:
        parts.append(f"accessed {', '.join(creds[:3])}")

    if env_vars:
        parts.append(f"probed env vars ({', '.join(env_vars[:3])})")

    if tools and not network:
        parts.append(f"attempted {', '.join(tools)} execution")

    if not parts:
        return "Suspicious install-time behavior detected"

    return "Suspicious: " + ", ".join(parts)


# =========================================================================
# FAIL-FAST MONITOR
# =========================================================================


def check_events_for_critical(log_path: str) -> Optional[str]:
    """
    Poll events.jsonl for CRITICAL events during container execution.

    Called by the fail-fast monitor loop. Returns a kill reason string
    if a CRITICAL event is found, or None if safe to continue.

    This is a lightweight check — no full severity model analysis.
    It looks for events that are unambiguously CRITICAL on their own:
    - honeypot_access (credential file read)
    - network_blocked to known-bad domains
    - persistence file writes
    - reverse shell patterns

    Args:
        log_path: Path to events.jsonl (mounted volume)

    Returns:
        Kill reason string, or None
    """
    import os

    if not os.path.exists(log_path):
        return None

    try:
        import json as _json

        with open(log_path) as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    event = _json.loads(line)
                except (ValueError, _json.JSONDecodeError):
                    continue

                etype = event.get("event", "")

                # Honeypot access = instant kill
                if etype == "honeypot_access":
                    path = event.get("path", "unknown")
                    return f"credential file accessed: {_short_path(path)}"

                # Persistence attempt = instant kill
                if etype == "file_write":
                    path = event.get("path", "")
                    persistence_markers = (
                        "/etc/cron",
                        "/var/spool/cron",
                        "/.bashrc",
                        "/etc/systemd",
                        "/etc/init.d",
                    )
                    if any(m in path for m in persistence_markers):
                        return f"persistence attempt: {path}"

                # Known-bad network contact = instant kill
                if etype == "network_blocked":
                    severity = event.get("severity", "")
                    if severity == "CRITICAL":
                        dest = event.get("destination", "") or event.get("host", "")
                        return f"network to known-bad: {dest}"

    except (IOError, OSError):
        pass

    return None
