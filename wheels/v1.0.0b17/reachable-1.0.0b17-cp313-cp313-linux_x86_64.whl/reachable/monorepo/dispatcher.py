#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.

"""
REACHABLE Monorepo Dispatcher
Detects and maps multiple projects within a monorepo structure

Hierarchy:
  Monorepo (top) - entire codebase
    └── Project (middle) - ownership boundary (e.g., /services/user-api)
        └── Language Scans (bottom) - technical findings per language

Data Structure Philosophy:
- Project = Parent (what teams own/deploy)
- Languages = Children (technical details)
- Prevents "Vulnerability Soup" (backend bugs mixed with frontend bugs)
"""

import json
import logging
import os
from dataclasses import dataclass, field
from typing import Dict, List, Optional

# Initialize module-level logger
logger = logging.getLogger(__name__)


@dataclass
class LanguageScanTarget:
    """
    BOTTOM LEVEL: One language within a project that needs scanning.

    Example: Python component of /services/user-api
    """

    language: str  # "python", "go", "js_ts", etc.
    anchor_file: str  # The manifest that triggered detection
    is_hermetic: bool = False  # True for Bazel (requires special handling)
    metadata: Dict = field(default_factory=dict)  # Framework, manager, etc.

    # Scan results (populated during scan)
    scan_status: str = "pending"  # pending, running, success, failed
    sbom_path: Optional[str] = None
    vulns_path: Optional[str] = None
    report_path: Optional[str] = None
    error_message: Optional[str] = None


@dataclass
class ProjectUnit:
    """
    MIDDLE LEVEL: Ownership boundary (what a team maintains and deploys).

    A single project can be polyglot (Go + Python + React).
    Each language gets its own scan target as a child.

    Example:
      Project: /services/user-api
        ├── Python scan (requirements.txt)
        ├── Go scan (go.mod)
        └── React scan (package.json)
    """

    project_name: str  # Human-readable name (e.g., "user-api")
    path: str  # Absolute path to project root
    relative_path: str = ""  # Path relative to monorepo root

    # Language scan targets (CHILDREN)
    language_targets: Dict[str, LanguageScanTarget] = field(default_factory=dict)

    # Project-level metadata
    metadata: Dict = field(default_factory=dict)

    def add_language(self, lang: str, anchor: str, is_hermetic: bool = False, lang_metadata: Optional[Dict] = None):
        """Add a language scan target to this project."""
        self.language_targets[lang] = LanguageScanTarget(
            language=lang, anchor_file=anchor, is_hermetic=is_hermetic, metadata=lang_metadata or {}
        )

    @property
    def languages(self) -> List[str]:
        """Get list of languages detected in this project."""
        return list(self.language_targets.keys())

    @property
    def is_polyglot(self) -> bool:
        """True if project contains multiple languages."""
        return len(self.language_targets) > 1

    def to_scan_plan(self) -> Dict:
        """
        Generate a structured scan plan for this project.

        Returns a plan with Mount Point, Tooling, and Context.
        """
        plan = {
            "project_name": self.project_name,
            "mount_point": {
                "absolute_path": self.path,
                "relative_path": self.relative_path,
                "is_polyglot": self.is_polyglot,
            },
            "languages": {},
            "metadata": self.metadata,
        }

        for lang, target in self.language_targets.items():
            plan["languages"][lang] = {
                "anchor_file": target.anchor_file,
                "tooling": self._get_tooling_for_language(lang, target),
                "context": target.metadata,
                "is_hermetic": target.is_hermetic,
            }

        return plan

    def _get_tooling_for_language(self, lang: str, target: LanguageScanTarget) -> Dict:
        """
        Determine which tools to use for this language.

        Returns tooling requirements with commands.
        """
        tooling = {
            "sbom_generator": None,
            "vuln_scanner": None,
            "secrets_scanner": "semgrep",  # Works for all languages
            "malware_scanner": None,
            "reachable_analyzer": "reachable",
        }

        # SBOM + Vulnerability scanning (Syft/Grype support most languages)
        if lang in ["python", "js_ts", "go", "rust", "java", "ruby", "php"]:
            tooling["sbom_generator"] = {"tool": "syft", "command": f"syft scan dir:{self.path} -o json"}
            tooling["vuln_scanner"] = {"tool": "grype", "command": "grype sbom:{sbom_path} -o json"}

        # Language-specific malware scanners
        if lang == "python":
            tooling["malware_scanner"] = {
                "tool": "guarddog",
                "command": f"guarddog scan {self.path}",
                "note": "Python package malware detection",
            }
        elif lang == "js_ts":
            tooling["malware_scanner"] = {
                "tool": "socket",
                "command": f"socket npm {self.path}/package.json",
                "note": "JavaScript package malware detection",
                "fallback": {"tool": "npm audit", "command": f"cd {self.path} && npm audit --json"},
            }
        elif lang == "rust":
            tooling["malware_scanner"] = {
                "tool": "cargo-audit",
                "command": f"cd {self.path} && cargo audit --json",
                "note": "Rust crate security audit",
            }
        elif lang == "java":
            tooling["malware_scanner"] = {
                "tool": "dependency-check",
                "command": f"dependency-check --project {self.project_name} --scan {self.path}",
                "note": "OWASP Dependency-Check",
            }
        # Note: Go, Ruby, PHP don't have dedicated malware scanners
        # They rely on general CVE scanning via Grype

        # Hermetic builds (Bazel) need special handling
        if target.is_hermetic:
            tooling["sbom_generator"] = {
                "tool": "bazel + syft",
                "command": f"bazel query 'deps(//{self.relative_path}/...)' --output=build | syft scan",
                "note": "Requires Bazel to enumerate dependencies first",
            }

        return tooling


class MonorepoDispatcher:
    """
    Traverses a monorepo and identifies distinct project units.

    Based on the reference implementation but restructured to:
    1. Group by PROJECT first (not by language)
    2. Treat languages as children of projects
    3. Prevent "Vulnerability Soup"
    """

    def __init__(self):
        # Maps manifest files to their respective language/build handlers
        self.ANCHORS = {
            # Standard Languages
            "go.mod": "go",
            "package.json": "js_ts",
            "pyproject.toml": "python",
            "requirements.txt": "python",
            "setup.py": "python",
            "Pipfile": "python",
            "Cargo.toml": "rust",
            "pom.xml": "java",
            "build.gradle": "java",
            "build.gradle.kts": "kotlin",
            "Gemfile": "ruby",
            "composer.json": "php",
            # Build Systems
            "Makefile": "makefile",
            "BUILD.bazel": "bazel",
            "BUILD": "bazel",
            "CMakeLists.txt": "cpp_cmake",
        }

        # Directories to skip to ensure high performance
        self.IGNORE_LIST = {
            ".git",
            "node_modules",
            "venv",
            ".venv",
            "target",
            "dist",
            ".next",
            ".vercel",
            "build",
            "__pycache__",
            "out",
            ".svn",
            ".hg",
            "vendor",
            "third_party",
            "external",
            "bin",
            "obj",
            ".pytest_cache",
            ".mypy_cache",
            ".idea",
            ".vscode",
            ".DS_Store",
        }

    def _analyze_js_stack(self, root: str, files: List[str]) -> Dict:
        """
        Deep-peeks into JS projects to determine framework and tooling.

        Based on reference implementation.
        """
        meta = {
            "framework": "Vanilla JS/TS",
            "manager": "npm",
            "is_ts": "tsconfig.json" in files,
            "is_ssr": any(f in files for f in ["next.config.js", "next.config.mjs"]),
        }

        # Detect Package Manager
        if "pnpm-lock.yaml" in files:
            meta["manager"] = "pnpm"
        elif "yarn.lock" in files:
            meta["manager"] = "yarn"

        # Detect Framework (Priority: Next.js > React/Vue > Node)
        pkg_path = os.path.join(root, "package.json")
        if os.path.exists(pkg_path):
            try:
                with open(pkg_path) as f:
                    data = json.load(f)
                    deps = {**data.get("dependencies", {}), **data.get("devDependencies", {})}
                    if "next" in deps:
                        meta["framework"] = "Next.js"
                    elif "react" in deps:
                        meta["framework"] = "React"
                    elif "vue" in deps:
                        meta["framework"] = "Vue"
                    elif "express" in deps or "fastify" in deps:
                        meta["framework"] = "Node.js (Backend)"
            except Exception:
                pass
        return meta

    def _analyze_python_stack(self, root: str, files: List[str]) -> Dict:
        """Analyze Python project characteristics."""
        meta = {
            "manager": "pip",
            "framework": None,
        }

        if "poetry.lock" in files or "pyproject.toml" in files:
            meta["manager"] = "poetry"
        elif "Pipfile" in files:
            meta["manager"] = "pipenv"

        # Try to detect framework from requirements.txt
        req_path = os.path.join(root, "requirements.txt")
        if os.path.exists(req_path):
            try:
                with open(req_path) as f:
                    content = f.read().lower()
                    if "django" in content:
                        meta["framework"] = "Django"
                    elif "flask" in content:
                        meta["framework"] = "Flask"
                    elif "fastapi" in content:
                        meta["framework"] = "FastAPI"
            except Exception:
                pass

        return meta

    def get_scan_units(self, start_path: str) -> List[ProjectUnit]:
        """
        Traverses the monorepo and returns a list of PROJECT units.

        KEY DIFFERENCE from reference: Returns projects with language children,
        not one ProjectUnit per language.

        Example output:
          [
            ProjectUnit(
              project_name="user-api",
              path="/services/user-api",
              language_targets={
                "python": LanguageScanTarget(...),
                "go": LanguageScanTarget(...)
              }
            )
          ]
        """
        # Dictionary to accumulate languages by project directory
        # Key: absolute path, Value: ProjectUnit
        projects_map: Dict[str, ProjectUnit] = {}

        for root, dirs, files in os.walk(start_path):
            # Prune search tree: Modifying 'dirs' in-place skips these folders entirely
            # (From reference implementation)
            dirs[:] = [d for d in dirs if d not in self.IGNORE_LIST]

            # Identify which anchors are present in the current folder
            found_anchors = set(files) & set(self.ANCHORS.keys())

            if not found_anchors:
                continue  # No project detected in this directory

            # Create or get existing project for this directory
            abs_path = os.path.abspath(root)
            if abs_path not in projects_map:
                # Derive project name from directory
                project_name = os.path.basename(root)

                # Calculate relative path from start
                try:
                    rel_path = os.path.relpath(root, start_path)
                except ValueError:
                    rel_path = root

                projects_map[abs_path] = ProjectUnit(project_name=project_name, path=abs_path, relative_path=rel_path)

            project = projects_map[abs_path]

            # Strategy: Don't 'break' because a single folder can be polyglot
            # (e.g., Go + Makefile, or Python + Node.js)
            # (From reference implementation)

            for anchor in found_anchors:
                lang_type = self.ANCHORS[anchor]

                # Skip if we already detected this language
                # (e.g., both requirements.txt and pyproject.toml present)
                if lang_type in project.language_targets:
                    continue

                # Specialized logic for JS/TS types
                # (From reference implementation)
                metadata = {}
                if lang_type == "js_ts":
                    metadata = self._analyze_js_stack(root, files)
                elif lang_type == "python":
                    metadata = self._analyze_python_stack(root, files)

                # Special flag for Bazel (Requires hermetic/query-based scanning)
                # (From reference implementation)
                is_hermetic = lang_type == "bazel"

                # Add language as CHILD of this project
                project.add_language(lang=lang_type, anchor=anchor, is_hermetic=is_hermetic, lang_metadata=metadata)

        # Convert map to list
        return list(projects_map.values())

    def generate_scan_plan(self, start_path: str, output_file: Optional[str] = None) -> Dict:
        """
        Generate a complete scan plan for the monorepo.

        Returns structured plan with:
        - Mount Points (where to scan)
        - Tooling (what tools to use)
        - Context (metadata about each project)

        Args:
            start_path: Root of the monorepo
            output_file: Optional path to save plan as JSON

        Returns:
            Scan plan dictionary
        """
        projects = self.get_scan_units(start_path)

        plan = {
            "monorepo": {
                "root_path": os.path.abspath(start_path),
                "total_projects": len(projects),
                "total_languages": sum(len(p.language_targets) for p in projects),
                "polyglot_projects": sum(1 for p in projects if p.is_polyglot),
            },
            "projects": [p.to_scan_plan() for p in projects],
            "execution_order": self._generate_execution_order(projects),
            "estimated_duration": self._estimate_scan_duration(projects),
        }

        if output_file:
            with open(output_file, "w") as f:
                json.dump(plan, f, indent=2)

        return plan

    def _generate_execution_order(self, projects: List[ProjectUnit]) -> List[Dict]:
        """
        Generate recommended execution order for parallel/serial execution.

        Groups independent projects that can run in parallel.
        """
        execution_plan = []

        # Phase 1: All projects can scan in parallel (no dependencies)
        phase = {"phase": 1, "description": "Parallel SBOM + Vulnerability Scanning", "parallel_groups": []}

        for project in projects:
            for lang, target in project.language_targets.items():
                phase["parallel_groups"].append(
                    {
                        "project": project.project_name,
                        "language": lang,
                        "mount_point": project.path,
                        "steps": ["sbom", "vulns"],
                    }
                )

        execution_plan.append(phase)

        # Phase 2: Reachability analysis (depends on Phase 1)
        phase2 = {
            "phase": 2,
            "description": "Reachability Analysis (depends on Phase 1)",
            "parallel_groups": [],
        }

        for project in projects:
            for lang in project.language_targets.keys():
                phase2["parallel_groups"].append(
                    {
                        "project": project.project_name,
                        "language": lang,
                        "mount_point": project.path,
                        "steps": ["reachable", "correlation"],
                    }
                )

        execution_plan.append(phase2)

        return execution_plan

    def _estimate_scan_duration(self, projects: List[ProjectUnit]) -> Dict:
        """Estimate total scan duration based on project count and types."""
        total_scans = sum(len(p.language_targets) for p in projects)

        # Rough estimates (in seconds)
        sbom_time = 30  # per project
        vuln_time = 20  # per project
        reachable_time = 60  # per project

        serial_time = total_scans * (sbom_time + vuln_time + reachable_time)
        parallel_time = max(sbom_time + vuln_time + reachable_time, serial_time / 4)

        return {
            "total_scans": total_scans,
            "estimated_serial": f"{serial_time // 60}m {serial_time % 60}s",
            "estimated_parallel": f"{int(parallel_time) // 60}m {int(parallel_time) % 60}s",
            "speedup_factor": f"{serial_time / parallel_time:.1f}x",
        }


# Usage Example (from reference, adapted for new structure):
if __name__ == "__main__":
    dispatcher = MonorepoDispatcher()

    # Option 1: Get project units (for programmatic use)
    projects = dispatcher.get_scan_units(".")

    logger.info(f"--- Detected {len(projects)} Projects ---")
    for project in projects:
        polyglot_marker = "[POLYGLOT]" if project.is_polyglot else ""
        logger.info(f"\n{polyglot_marker} PROJECT: {project.project_name}")
        logger.info(f" Path: {project.relative_path}")
        logger.info(f" Languages: {len(project.language_targets)}")

        for lang, target in project.language_targets.items():
            hermetic = "[HERMETIC]" if target.is_hermetic else ""
            flavor = ""
            if lang == "js_ts":
                framework = target.metadata.get("framework", "Unknown")
                manager = target.metadata.get("manager", "npm")
                flavor = f"({framework}, {manager})"
            elif lang == "python":
                framework = target.metadata.get("framework")
                if framework:
                    flavor = f"({framework})"

            logger.info(f" {hermetic} [{lang.upper()}{flavor}] → {target.anchor_file}")

    # Option 2: Generate structured scan plan (for CI/CD)
    logger.info("\n" + "=" * 70)
    logger.info("GENERATING SCAN PLAN")
    logger.info("=" * 70)

    scan_plan = dispatcher.generate_scan_plan(".", output_file="scan-plan.json")

    logger.info("\n Scan Plan Summary:")
    logger.info(f" Total Projects: {scan_plan['monorepo']['total_projects']}")
    logger.info(f" Total Languages: {scan_plan['monorepo']['total_languages']}")
    logger.info(f" Polyglot Projects: {scan_plan['monorepo']['polyglot_projects']}")
    logger.info("\n Estimated Duration:")
    logger.info(f" Serial: {scan_plan['estimated_duration']['estimated_serial']}")
    logger.info(f" Parallel: {scan_plan['estimated_duration']['estimated_parallel']}")
    logger.info(f" Speedup: {scan_plan['estimated_duration']['speedup_factor']}")

    logger.info("\n Detailed scan plan saved to: scan-plan.json")

    logger.info("\n Tooling Requirements:")
    tooling_set = set()
    for project_plan in scan_plan["projects"]:
        for lang_plan in project_plan["languages"].values():
            tooling = lang_plan["tooling"]
            if tooling["sbom_generator"]:
                tooling_set.add(tooling["sbom_generator"]["tool"])
            if tooling["vuln_scanner"]:
                tooling_set.add(tooling["vuln_scanner"]["tool"])
            if tooling["malware_scanner"]:
                tooling_set.add(tooling["malware_scanner"]["tool"])
            tooling_set.add(tooling["secrets_scanner"])
            tooling_set.add(tooling["reachable_analyzer"])

    logger.info(f" Required tools: {', '.join(sorted(tooling_set))}")
