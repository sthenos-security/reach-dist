#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.

"""
REACHABLE Comprehensive Metrics System v3.0

Tracks logs, metrics, and dashboard data for ALL analysis areas:

1. Reachability Analysis - call graph, entrypoints, reachable/unreachable
2. CVE Scanning - Grype results, severity, fix availability
3. Exploitability Lookups - KEV, EPSS, CVSS, Exploit-DB, Metasploit
4. Malware Detection - GuardDog packages, Semgrep patterns
5. Secrets Scanning - Semgrep secrets, reachability
5b. Sandbox Analysis - behavioral detection, install-time attacks
6. Health Analysis - maintenance, popularity, outdated
7. Attack Surface - phantom deps, shadow imports, dead deps
8. SAST Findings - insecure code constructs
9. Import Analysis - dependency resolution, manifest parsing
10. Performance - step timings, API latency, duration
"""

import json
import logging
import time
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any, Dict, List, Optional

# Initialize module-level logger
logger = logging.getLogger(__name__)


class LogLevel(Enum):
    TRACE = "TRACE"
    DEBUG = "DEBUG"
    INFO = "INFO"
    WARN = "WARN"
    ERROR = "ERROR"
    METRIC = "METRIC"
    API = "API"


class AnalysisArea(Enum):
    REACHABILITY = "reachability"
    CVE_SCAN = "cve_scan"
    EXPLOITABILITY = "exploitability"
    MALWARE = "malware"
    SECRETS = "secrets"
    HEALTH = "health"
    ATTACK_SURFACE = "attack_surface"
    SAST = "sast"
    IMPORT_ANALYSIS = "import_analysis"
    PERFORMANCE = "performance"
    GIT = "git"
    CORRELATION = "correlation"
    SANDBOX = "sandbox"


@dataclass
class LogEntry:
    """Single log entry"""

    timestamp: str
    level: LogLevel
    area: AnalysisArea
    component: str
    message: str
    entity: str = ""
    value: Any = None
    duration_ms: float = 0.0
    details: Dict = field(default_factory=dict)

    def to_dict(self) -> Dict:
        return {
            "timestamp": self.timestamp,
            "level": self.level.value,
            "area": self.area.value,
            "component": self.component,
            "message": self.message,
            "entity": self.entity,
            "value": str(self.value) if not isinstance(self.value, (int, float, bool, str, type(None))) else self.value,
            "duration_ms": round(self.duration_ms, 2),
            "details": self.details,
        }


# ============================================================================
# 1. REACHABILITY METRICS
# ============================================================================
@dataclass
class ReachabilityMetrics:
    """Metrics for reachability analysis"""

    # Call graph
    total_functions: int = 0
    total_edges: int = 0
    avg_fan_out: float = 0.0
    max_fan_out: int = 0
    max_fan_out_function: str = ""

    # Entrypoints
    entrypoints_detected: int = 0
    entrypoints_by_type: Dict[str, int] = field(default_factory=dict)
    entrypoint_list: List[str] = field(default_factory=list)

    # Reachability
    reachable_functions: int = 0
    unreachable_functions: int = 0
    reachability_percentage: float = 0.0

    # By language
    functions_by_language: Dict[str, int] = field(default_factory=dict)
    reachable_by_language: Dict[str, int] = field(default_factory=dict)

    # Processing
    files_parsed: int = 0
    parse_errors: int = 0
    processing_time_ms: float = 0.0

    def to_dict(self) -> Dict:
        return {
            "call_graph": {
                "total_functions": self.total_functions,
                "total_edges": self.total_edges,
                "avg_fan_out": round(self.avg_fan_out, 2),
                "max_fan_out": self.max_fan_out,
                "max_fan_out_function": self.max_fan_out_function,
            },
            "entrypoints": {
                "total": self.entrypoints_detected,
                "by_type": self.entrypoints_by_type,
                "list": self.entrypoint_list[:20],
            },
            "reachability": {
                "reachable": self.reachable_functions,
                "unreachable": self.unreachable_functions,
                "percentage": round(self.reachability_percentage, 1),
            },
            "by_language": {"functions": self.functions_by_language, "reachable": self.reachable_by_language},
            "processing": {
                "files_parsed": self.files_parsed,
                "parse_errors": self.parse_errors,
                "time_ms": round(self.processing_time_ms, 2),
            },
        }


# ============================================================================
# 2. CVE SCANNING METRICS
# ============================================================================
@dataclass
class CVEScanMetrics:
    """Metrics for CVE scanning"""

    # Totals
    total_cves: int = 0
    unique_cves: int = 0
    affected_packages: int = 0

    # By severity
    critical_count: int = 0
    high_count: int = 0
    medium_count: int = 0
    low_count: int = 0
    unknown_count: int = 0

    # By reachability
    reachable_cves: int = 0
    unreachable_cves: int = 0
    reachable_critical: int = 0
    reachable_high: int = 0

    # Fix availability
    cves_with_fix: int = 0
    cves_without_fix: int = 0
    fix_percentage: float = 0.0

    # By ecosystem
    cves_by_ecosystem: Dict[str, int] = field(default_factory=dict)

    # CVSS scores
    avg_cvss: float = 0.0
    max_cvss: float = 0.0
    max_cvss_cve: str = ""
    cvss_distribution: Dict[str, int] = field(default_factory=dict)

    # Scanner info
    scanner_name: str = "grype"
    scanner_version: str = ""
    db_version: str = ""
    scan_time_ms: float = 0.0

    # Individual CVEs for logging
    cve_details: List[Dict] = field(default_factory=list)

    def to_dict(self) -> Dict:
        return {
            "totals": {
                "total_cves": self.total_cves,
                "unique_cves": self.unique_cves,
                "affected_packages": self.affected_packages,
            },
            "by_severity": {
                "critical": self.critical_count,
                "high": self.high_count,
                "medium": self.medium_count,
                "low": self.low_count,
                "unknown": self.unknown_count,
            },
            "by_reachability": {
                "reachable": self.reachable_cves,
                "unreachable": self.unreachable_cves,
                "reachable_critical": self.reachable_critical,
                "reachable_high": self.reachable_high,
            },
            "fix_availability": {
                "with_fix": self.cves_with_fix,
                "without_fix": self.cves_without_fix,
                "fix_percentage": round(self.fix_percentage, 1),
            },
            "by_ecosystem": self.cves_by_ecosystem,
            "cvss": {
                "average": round(self.avg_cvss, 2),
                "maximum": self.max_cvss,
                "max_cve": self.max_cvss_cve,
                "distribution": self.cvss_distribution,
            },
            "scanner": {
                "name": self.scanner_name,
                "version": self.scanner_version,
                "db_version": self.db_version,
                "scan_time_ms": round(self.scan_time_ms, 2),
            },
        }


# ============================================================================
# 3. EXPLOITABILITY METRICS
# ============================================================================
@dataclass
class ExploitabilityMetrics:
    """Metrics for exploitability lookups"""

    # KEV
    kev_lookups: int = 0
    kev_matches: int = 0
    kev_api_time_ms: float = 0.0
    kev_cache_hits: int = 0
    kev_details: List[Dict] = field(default_factory=list)

    # EPSS
    epss_lookups: int = 0
    epss_scores_found: int = 0
    epss_high_count: int = 0  # >0.5
    epss_medium_count: int = 0  # 0.1-0.5
    epss_low_count: int = 0  # <0.1
    epss_avg_score: float = 0.0
    epss_max_score: float = 0.0
    epss_max_cve: str = ""
    epss_api_time_ms: float = 0.0
    epss_details: List[Dict] = field(default_factory=list)

    # CVSS (from NVD)
    cvss_lookups: int = 0
    cvss_found: int = 0
    cvss_v3_count: int = 0
    cvss_v2_count: int = 0
    cvss_api_time_ms: float = 0.0

    # Exploit-DB
    exploitdb_lookups: int = 0
    exploitdb_matches: int = 0
    exploitdb_api_time_ms: float = 0.0
    exploitdb_details: List[Dict] = field(default_factory=list)

    # Metasploit
    metasploit_lookups: int = 0
    metasploit_modules: int = 0
    metasploit_api_time_ms: float = 0.0
    metasploit_details: List[Dict] = field(default_factory=list)

    # API errors
    api_errors: int = 0
    api_timeouts: int = 0
    api_rate_limits: int = 0

    def to_dict(self) -> Dict:
        return {
            "kev": {
                "lookups": self.kev_lookups,
                "matches": self.kev_matches,
                "api_time_ms": round(self.kev_api_time_ms, 2),
                "cache_hits": self.kev_cache_hits,
                "details": self.kev_details[:10],
            },
            "epss": {
                "lookups": self.epss_lookups,
                "found": self.epss_scores_found,
                "high_count": self.epss_high_count,
                "medium_count": self.epss_medium_count,
                "low_count": self.epss_low_count,
                "avg_score": round(self.epss_avg_score, 4),
                "max_score": round(self.epss_max_score, 4),
                "max_cve": self.epss_max_cve,
                "api_time_ms": round(self.epss_api_time_ms, 2),
            },
            "cvss": {
                "lookups": self.cvss_lookups,
                "found": self.cvss_found,
                "v3_count": self.cvss_v3_count,
                "v2_count": self.cvss_v2_count,
                "api_time_ms": round(self.cvss_api_time_ms, 2),
            },
            "exploit_db": {
                "lookups": self.exploitdb_lookups,
                "matches": self.exploitdb_matches,
                "api_time_ms": round(self.exploitdb_api_time_ms, 2),
                "details": self.exploitdb_details[:10],
            },
            "metasploit": {
                "lookups": self.metasploit_lookups,
                "modules": self.metasploit_modules,
                "api_time_ms": round(self.metasploit_api_time_ms, 2),
                "details": self.metasploit_details[:10],
            },
            "api_health": {
                "errors": self.api_errors,
                "timeouts": self.api_timeouts,
                "rate_limits": self.api_rate_limits,
            },
        }


# ============================================================================
# 4. MALWARE DETECTION METRICS
# ============================================================================
@dataclass
class MalwareMetrics:
    """Metrics for malware detection"""

    # GuardDog (package malware)
    guarddog_packages_scanned: int = 0
    guarddog_malicious: int = 0
    guarddog_suspicious: int = 0
    guarddog_clean: int = 0
    guarddog_by_risk: Dict[str, int] = field(default_factory=dict)
    guarddog_by_rule: Dict[str, int] = field(default_factory=dict)
    guarddog_scan_time_ms: float = 0.0
    guarddog_details: List[Dict] = field(default_factory=list)

    # Semgrep malware patterns
    semgrep_files_scanned: int = 0
    semgrep_patterns_found: int = 0
    semgrep_by_category: Dict[str, int] = field(default_factory=dict)
    semgrep_by_severity: Dict[str, int] = field(default_factory=dict)
    semgrep_scan_time_ms: float = 0.0
    semgrep_details: List[Dict] = field(default_factory=list)

    # Combined
    total_malware_indicators: int = 0
    high_confidence_malware: int = 0

    def to_dict(self) -> Dict:
        return {
            "guarddog": {
                "packages_scanned": self.guarddog_packages_scanned,
                "malicious": self.guarddog_malicious,
                "suspicious": self.guarddog_suspicious,
                "clean": self.guarddog_clean,
                "by_risk": self.guarddog_by_risk,
                "by_rule": self.guarddog_by_rule,
                "scan_time_ms": round(self.guarddog_scan_time_ms, 2),
                "details": self.guarddog_details[:10],
            },
            "semgrep_malware": {
                "files_scanned": self.semgrep_files_scanned,
                "patterns_found": self.semgrep_patterns_found,
                "by_category": self.semgrep_by_category,
                "by_severity": self.semgrep_by_severity,
                "scan_time_ms": round(self.semgrep_scan_time_ms, 2),
                "details": self.semgrep_details[:10],
            },
            "combined": {
                "total_indicators": self.total_malware_indicators,
                "high_confidence": self.high_confidence_malware,
            },
        }


# ============================================================================
# 5. SECRETS SCANNING METRICS
# ============================================================================
@dataclass
class SecretsMetrics:
    """Metrics for secrets scanning"""

    # Totals
    total_secrets: int = 0
    unique_secrets: int = 0
    files_with_secrets: int = 0

    # By type
    secrets_by_type: Dict[str, int] = field(default_factory=dict)

    # By severity
    error_severity: int = 0
    warning_severity: int = 0
    info_severity: int = 0

    # Reachability
    reachable_secrets: int = 0
    unreachable_secrets: int = 0
    reachable_percentage: float = 0.0

    # By file type
    secrets_by_filetype: Dict[str, int] = field(default_factory=dict)

    # Scanner
    scanner_name: str = "semgrep"
    rules_used: int = 0
    scan_time_ms: float = 0.0

    # Details
    secret_details: List[Dict] = field(default_factory=list)

    # ENV-001: Environment & Config Secrets (NEW)
    env_secrets_total: int = 0
    env_secrets_by_category: Dict[str, int] = field(default_factory=dict)
    env_secrets_by_severity: Dict[str, int] = field(default_factory=dict)
    env_forbidden_files: int = 0
    env_weak_secrets: int = 0
    env_base64_decoded: int = 0
    env_secrets_findings: List[Dict] = field(default_factory=list)

    def to_dict(self) -> Dict:
        return {
            "totals": {
                "total": self.total_secrets,
                "unique": self.unique_secrets,
                "files_affected": self.files_with_secrets,
            },
            "by_type": self.secrets_by_type,
            "by_severity": {
                "error": self.error_severity,
                "warning": self.warning_severity,
                "info": self.info_severity,
            },
            "reachability": {
                "reachable": self.reachable_secrets,
                "unreachable": self.unreachable_secrets,
                "percentage": round(self.reachable_percentage, 1),
            },
            "by_filetype": self.secrets_by_filetype,
            "scanner": {
                "name": self.scanner_name,
                "rules_used": self.rules_used,
                "scan_time_ms": round(self.scan_time_ms, 2),
            },
            "env_001": {
                "policy": "ENV-001",
                "total": self.env_secrets_total,
                "by_category": self.env_secrets_by_category,
                "by_severity": self.env_secrets_by_severity,
                "forbidden_files": self.env_forbidden_files,
                "weak_secrets": self.env_weak_secrets,
                "base64_decoded": self.env_base64_decoded,
                "findings": self.env_secrets_findings[:10],  # Top 10
            },
        }


# ============================================================================
# 5b. SANDBOX BEHAVIORAL ANALYSIS METRICS
# ============================================================================
@dataclass
class SandboxMetrics:
    """Metrics for behavioral sandbox analysis"""

    # Testing strategy
    strategy: str = "none"  # "batch", "individual", "hybrid", "none"

    # Execution
    packages_tested: int = 0
    packages_clean: int = 0
    packages_warning: int = 0
    packages_critical: int = 0
    packages_error: int = 0

    # Findings
    total_findings: int = 0
    critical_findings: int = 0
    high_findings: int = 0
    medium_findings: int = 0
    info_findings: int = 0

    # Detection breakdown
    network_blocked: int = 0  # NETWORK_DURING_INSTALL
    credential_access: int = 0  # CREDENTIAL_ACCESS
    blocked_tools: int = 0  # BLOCKED_TOOL (curl/wget/nc)
    env_exfil_attempts: int = 0  # ENV_EXFIL_ATTEMPT
    executable_creation: int = 0  # EXECUTABLE_CREATION
    fs_escape_attempts: int = 0  # FS_ESCAPE
    suspicious_args: int = 0  # SUSPICIOUS_ARGUMENT

    # Capability scores
    avg_capability_score: float = 1.0
    min_capability_score: float = 1.0

    # Performance
    total_test_time_ms: int = 0
    avg_test_time_ms: float = 0.0

    # Container stats
    containers_created: int = 0
    containers_killed: int = 0  # Timeout or resource limit

    # Malicious packages (confirmed)
    malicious_packages: List[str] = field(default_factory=list)
    suspicious_packages: List[str] = field(default_factory=list)

    # Hybrid-specific
    batch_verdict: str = ""
    batch_duration_ms: int = 0
    individual_tests_run: int = 0

    def to_dict(self) -> Dict[str, Any]:
        return {
            "strategy": self.strategy,
            "execution": {
                "packages_tested": self.packages_tested,
                "clean": self.packages_clean,
                "warning": self.packages_warning,
                "critical": self.packages_critical,
                "error": self.packages_error,
            },
            "findings": {
                "total": self.total_findings,
                "critical": self.critical_findings,
                "high": self.high_findings,
                "medium": self.medium_findings,
                "info": self.info_findings,
            },
            "detections": {
                "network_blocked": self.network_blocked,
                "credential_access": self.credential_access,
                "blocked_tools": self.blocked_tools,
                "env_exfil_attempts": self.env_exfil_attempts,
                "executable_creation": self.executable_creation,
                "fs_escape_attempts": self.fs_escape_attempts,
                "suspicious_args": self.suspicious_args,
            },
            "capability_score": {
                "average": round(self.avg_capability_score, 2),
                "minimum": round(self.min_capability_score, 2),
            },
            "performance": {
                "total_time_ms": self.total_test_time_ms,
                "avg_time_ms": round(self.avg_test_time_ms, 2),
            },
            "containers": {"created": self.containers_created, "killed": self.containers_killed},
            "results": {
                "malicious_packages": self.malicious_packages,
                "suspicious_packages": self.suspicious_packages,
            },
            "hybrid": {
                "batch_verdict": self.batch_verdict,
                "batch_duration_ms": self.batch_duration_ms,
                "individual_tests_run": self.individual_tests_run,
            },
        }

    @classmethod
    def from_hybrid_result(cls, result: Any) -> "SandboxMetrics":
        """
        Populate SandboxMetrics from a HybridSandboxResult.

        Args:
            result: HybridSandboxResult from sandbox runner

        Returns:
            Populated SandboxMetrics instance
        """
        metrics = cls()
        metrics.strategy = "hybrid"
        metrics.packages_tested = len(result.packages)
        metrics.total_test_time_ms = result.duration_ms
        metrics.malicious_packages = result.malicious_packages

        # From batch result
        batch = result.batch_result
        metrics.batch_verdict = batch.verdict.value if hasattr(batch.verdict, "value") else str(batch.verdict)
        metrics.batch_duration_ms = batch.duration_ms
        metrics.suspicious_packages = batch.suspicious_packages

        # Aggregate findings from batch
        for f in batch.findings:
            metrics.total_findings += 1
            sev = f.severity.value if hasattr(f.severity, "value") else str(f.severity)
            if sev == "CRITICAL":
                metrics.critical_findings += 1
            elif sev == "HIGH":
                metrics.high_findings += 1
            elif sev == "MEDIUM":
                metrics.medium_findings += 1
            else:
                metrics.info_findings += 1

            # Count detection types
            rule = f.rule
            if rule == "NETWORK_DURING_INSTALL":
                metrics.network_blocked += 1
            elif rule == "CREDENTIAL_ACCESS":
                metrics.credential_access += 1
            elif rule == "BLOCKED_TOOL":
                metrics.blocked_tools += 1
            elif rule == "ENV_EXFIL_ATTEMPT":
                metrics.env_exfil_attempts += 1
            elif rule == "EXECUTABLE_CREATION":
                metrics.executable_creation += 1
            elif rule == "FS_ESCAPE":
                metrics.fs_escape_attempts += 1
            elif rule == "SUSPICIOUS_ARGUMENT":
                metrics.suspicious_args += 1

        # From individual results
        metrics.individual_tests_run = len(result.individual_results)
        metrics.containers_created = 1 + len(result.individual_results)  # batch + individuals

        cap_scores = [batch.capability_score]
        for r in result.individual_results:
            verdict = r.verdict.value if hasattr(r.verdict, "value") else str(r.verdict)
            if verdict == "CLEAN":
                metrics.packages_clean += 1
            elif verdict == "WARNING":
                metrics.packages_warning += 1
            elif verdict == "CRITICAL":
                metrics.packages_critical += 1
            elif verdict == "ERROR":
                metrics.packages_error += 1

            cap_scores.append(r.capability_score)

            # Add individual findings
            for f in r.findings:
                metrics.total_findings += 1
                sev = f.severity.value if hasattr(f.severity, "value") else str(f.severity)
                if sev == "CRITICAL":
                    metrics.critical_findings += 1
                elif sev == "HIGH":
                    metrics.high_findings += 1

        # Calculate capability scores
        if cap_scores:
            metrics.avg_capability_score = sum(cap_scores) / len(cap_scores)
            metrics.min_capability_score = min(cap_scores)

        # Packages not individually tested are assumed clean if batch was clean
        if batch.verdict.value == "CLEAN" if hasattr(batch.verdict, "value") else batch.verdict == "CLEAN":
            metrics.packages_clean = metrics.packages_tested

        return metrics

    @classmethod
    def from_batch_result(cls, result: Any) -> "SandboxMetrics":
        """Populate SandboxMetrics from a BatchSandboxResult."""
        metrics = cls()
        metrics.strategy = "batch"
        metrics.packages_tested = len(result.packages)
        metrics.total_test_time_ms = result.duration_ms
        metrics.batch_verdict = result.verdict.value if hasattr(result.verdict, "value") else str(result.verdict)
        metrics.batch_duration_ms = result.duration_ms
        metrics.suspicious_packages = result.suspicious_packages
        metrics.containers_created = 1
        metrics.avg_capability_score = result.capability_score
        metrics.min_capability_score = result.capability_score

        # Count findings
        for f in result.findings:
            metrics.total_findings += 1
            sev = f.severity.value if hasattr(f.severity, "value") else str(f.severity)
            if sev == "CRITICAL":
                metrics.critical_findings += 1
            elif sev == "HIGH":
                metrics.high_findings += 1
            elif sev == "MEDIUM":
                metrics.medium_findings += 1
            else:
                metrics.info_findings += 1

        return metrics

    @classmethod
    def from_individual_results(cls, results: List[Any]) -> "SandboxMetrics":
        """Populate SandboxMetrics from a list of SandboxResult."""
        metrics = cls()
        metrics.strategy = "individual"
        metrics.packages_tested = len(results)
        metrics.containers_created = len(results)

        cap_scores = []
        total_time = 0

        for r in results:
            total_time += r.duration_ms
            cap_scores.append(r.capability_score)

            verdict = r.verdict.value if hasattr(r.verdict, "value") else str(r.verdict)
            if verdict == "CLEAN":
                metrics.packages_clean += 1
            elif verdict == "WARNING":
                metrics.packages_warning += 1
            elif verdict == "CRITICAL":
                metrics.packages_critical += 1
                metrics.malicious_packages.append(r.package)
            elif verdict == "ERROR":
                metrics.packages_error += 1

            for f in r.findings:
                metrics.total_findings += 1
                sev = f.severity.value if hasattr(f.severity, "value") else str(f.severity)
                if sev == "CRITICAL":
                    metrics.critical_findings += 1
                elif sev == "HIGH":
                    metrics.high_findings += 1
                elif sev == "MEDIUM":
                    metrics.medium_findings += 1
                else:
                    metrics.info_findings += 1

        metrics.total_test_time_ms = total_time
        if results:
            metrics.avg_test_time_ms = total_time / len(results)
        if cap_scores:
            metrics.avg_capability_score = sum(cap_scores) / len(cap_scores)
            metrics.min_capability_score = min(cap_scores)

        return metrics


# ============================================================================
# 6. HEALTH ANALYSIS METRICS
# ============================================================================
@dataclass
class HealthMetrics:
    """Metrics for package health analysis"""

    # Totals
    packages_analyzed: int = 0

    # Maintenance
    healthy_packages: int = 0
    risky_packages: int = 0
    critical_packages: int = 0
    unknown_packages: int = 0
    avg_days_since_update: float = 0.0
    max_days_since_update: int = 0
    max_stale_package: str = ""

    # Popularity
    high_popularity: int = 0
    medium_popularity: int = 0
    low_popularity: int = 0
    avg_downloads: int = 0
    avg_stars: int = 0

    # Outdated
    outdated_packages: int = 0
    up_to_date_packages: int = 0
    total_versions_behind: int = 0
    avg_versions_behind: float = 0.0

    # Deprecated
    deprecated_packages: int = 0
    deprecated_list: List[str] = field(default_factory=list)

    # API
    pypi_lookups: int = 0
    npm_lookups: int = 0
    github_lookups: int = 0
    api_time_ms: float = 0.0

    # Details
    package_details: List[Dict] = field(default_factory=list)

    def to_dict(self) -> Dict:
        return {
            "totals": {"analyzed": self.packages_analyzed},
            "maintenance": {
                "healthy": self.healthy_packages,
                "risky": self.risky_packages,
                "critical": self.critical_packages,
                "unknown": self.unknown_packages,
                "avg_days_stale": round(self.avg_days_since_update, 1),
                "max_days_stale": self.max_days_since_update,
                "stalest_package": self.max_stale_package,
            },
            "popularity": {
                "high": self.high_popularity,
                "medium": self.medium_popularity,
                "low": self.low_popularity,
                "avg_downloads": self.avg_downloads,
                "avg_stars": self.avg_stars,
            },
            "outdated": {
                "outdated": self.outdated_packages,
                "up_to_date": self.up_to_date_packages,
                "total_versions_behind": self.total_versions_behind,
                "avg_versions_behind": round(self.avg_versions_behind, 1),
            },
            "deprecated": {"count": self.deprecated_packages, "list": self.deprecated_list[:10]},
            "api": {
                "pypi_lookups": self.pypi_lookups,
                "npm_lookups": self.npm_lookups,
                "github_lookups": self.github_lookups,
                "time_ms": round(self.api_time_ms, 2),
            },
        }


# ============================================================================
# 7. ATTACK SURFACE METRICS
# ============================================================================
@dataclass
class AttackSurfaceMetrics:
    """Metrics for attack surface analysis"""

    # Phantom dependencies
    phantom_deps_count: int = 0
    phantom_deps_list: List[str] = field(default_factory=list)
    phantom_by_source: Dict[str, int] = field(default_factory=dict)

    # Shadow imports
    shadow_imports_count: int = 0
    shadow_imports_list: List[str] = field(default_factory=list)
    shadow_by_depth: Dict[int, int] = field(default_factory=dict)

    # Dead dependencies
    dead_deps_count: int = 0
    dead_deps_list: List[str] = field(default_factory=list)

    # Dependency depth
    max_depth: int = 0
    avg_depth: float = 0.0
    deep_chains: int = 0  # depth > 5

    # Transitive analysis
    direct_deps: int = 0
    transitive_deps: int = 0
    transitive_ratio: float = 0.0

    # Processing
    analysis_time_ms: float = 0.0

    def to_dict(self) -> Dict:
        return {
            "phantom_deps": {
                "count": self.phantom_deps_count,
                "list": self.phantom_deps_list[:20],
                "by_source": self.phantom_by_source,
            },
            "shadow_imports": {
                "count": self.shadow_imports_count,
                "list": self.shadow_imports_list[:20],
                "by_depth": self.shadow_by_depth,
            },
            "dead_deps": {"count": self.dead_deps_count, "list": self.dead_deps_list[:20]},
            "dependency_depth": {
                "max": self.max_depth,
                "average": round(self.avg_depth, 1),
                "deep_chains": self.deep_chains,
            },
            "transitive": {
                "direct": self.direct_deps,
                "transitive": self.transitive_deps,
                "ratio": round(self.transitive_ratio, 2),
            },
            "processing_time_ms": round(self.analysis_time_ms, 2),
        }


# ============================================================================
# 8. SAST METRICS
# ============================================================================
@dataclass
class SASTMetrics:
    """Metrics for SAST findings"""

    # Totals
    total_findings: int = 0
    files_scanned: int = 0
    files_with_findings: int = 0

    # By severity
    critical_findings: int = 0
    high_findings: int = 0
    medium_findings: int = 0
    low_findings: int = 0
    info_findings: int = 0

    # By category
    findings_by_category: Dict[str, int] = field(default_factory=dict)

    # By CWE
    findings_by_cwe: Dict[str, int] = field(default_factory=dict)

    # By language
    findings_by_language: Dict[str, int] = field(default_factory=dict)

    # Reachability
    reachable_findings: int = 0
    unreachable_findings: int = 0

    # Scanner
    scanner_name: str = "semgrep"
    rules_loaded: int = 0
    rules_matched: int = 0
    scan_time_ms: float = 0.0

    # Details
    finding_details: List[Dict] = field(default_factory=list)

    def to_dict(self) -> Dict:
        return {
            "totals": {
                "findings": self.total_findings,
                "files_scanned": self.files_scanned,
                "files_with_findings": self.files_with_findings,
            },
            "by_severity": {
                "critical": self.critical_findings,
                "high": self.high_findings,
                "medium": self.medium_findings,
                "low": self.low_findings,
                "info": self.info_findings,
            },
            "by_category": self.findings_by_category,
            "by_cwe": dict(list(self.findings_by_cwe.items())[:10]),
            "by_language": self.findings_by_language,
            "reachability": {"reachable": self.reachable_findings, "unreachable": self.unreachable_findings},
            "scanner": {
                "name": self.scanner_name,
                "rules_loaded": self.rules_loaded,
                "rules_matched": self.rules_matched,
                "scan_time_ms": round(self.scan_time_ms, 2),
            },
        }


# ============================================================================
# 9. IMPORT ANALYSIS METRICS
# ============================================================================
@dataclass
class ImportAnalysisMetrics:
    """Metrics for import/dependency analysis"""

    # Manifests
    manifests_found: int = 0
    manifests_parsed: int = 0
    manifests_by_type: Dict[str, int] = field(default_factory=dict)
    manifest_errors: int = 0

    # Dependencies
    declared_deps: int = 0
    dev_deps: int = 0
    optional_deps: int = 0
    peer_deps: int = 0

    # Imports
    import_statements_found: int = 0
    unique_imports: int = 0
    stdlib_imports: int = 0
    third_party_imports: int = 0
    local_imports: int = 0

    # Resolution
    resolved_imports: int = 0
    unresolved_imports: int = 0
    resolution_percentage: float = 0.0

    # By language
    imports_by_language: Dict[str, int] = field(default_factory=dict)

    # Processing
    files_analyzed: int = 0
    parse_time_ms: float = 0.0
    resolution_time_ms: float = 0.0

    def to_dict(self) -> Dict:
        return {
            "manifests": {
                "found": self.manifests_found,
                "parsed": self.manifests_parsed,
                "by_type": self.manifests_by_type,
                "errors": self.manifest_errors,
            },
            "dependencies": {
                "declared": self.declared_deps,
                "dev": self.dev_deps,
                "optional": self.optional_deps,
                "peer": self.peer_deps,
            },
            "imports": {
                "total_statements": self.import_statements_found,
                "unique": self.unique_imports,
                "stdlib": self.stdlib_imports,
                "third_party": self.third_party_imports,
                "local": self.local_imports,
            },
            "resolution": {
                "resolved": self.resolved_imports,
                "unresolved": self.unresolved_imports,
                "percentage": round(self.resolution_percentage, 1),
            },
            "by_language": self.imports_by_language,
            "processing": {
                "files_analyzed": self.files_analyzed,
                "parse_time_ms": round(self.parse_time_ms, 2),
                "resolution_time_ms": round(self.resolution_time_ms, 2),
            },
        }


# ============================================================================
# 10. PERFORMANCE METRICS
# ============================================================================
@dataclass
class PerformanceMetrics:
    """Metrics for performance tracking"""

    # Overall
    total_time_ms: float = 0.0
    start_timestamp: str = ""
    end_timestamp: str = ""

    # Step timings
    step_timings: Dict[str, float] = field(default_factory=dict)
    step_percentages: Dict[str, float] = field(default_factory=dict)
    slowest_step: str = ""
    slowest_step_time: float = 0.0

    # API latencies
    api_latencies: Dict[str, List[float]] = field(default_factory=dict)
    api_avg_latency: Dict[str, float] = field(default_factory=dict)
    api_max_latency: Dict[str, float] = field(default_factory=dict)
    total_api_time_ms: float = 0.0

    # File processing
    files_processed: int = 0
    total_lines_processed: int = 0
    avg_file_time_ms: float = 0.0

    # Memory (if available)
    peak_memory_mb: float = 0.0

    # Parallelism
    parallel_tasks: int = 0
    thread_pool_size: int = 0

    def to_dict(self) -> Dict:
        return {
            "overall": {
                "total_time_ms": round(self.total_time_ms, 2),
                "total_time_seconds": round(self.total_time_ms / 1000, 2),
                "start": self.start_timestamp,
                "end": self.end_timestamp,
            },
            "steps": {
                "timings": {k: round(v, 2) for k, v in self.step_timings.items()},
                "percentages": {k: round(v, 1) for k, v in self.step_percentages.items()},
                "slowest": self.slowest_step,
                "slowest_time_ms": round(self.slowest_step_time, 2),
            },
            "api": {
                "avg_latency": {k: round(v, 2) for k, v in self.api_avg_latency.items()},
                "max_latency": {k: round(v, 2) for k, v in self.api_max_latency.items()},
                "total_api_time_ms": round(self.total_api_time_ms, 2),
            },
            "files": {
                "processed": self.files_processed,
                "total_lines": self.total_lines_processed,
                "avg_time_ms": round(self.avg_file_time_ms, 2),
            },
            "resources": {
                "peak_memory_mb": round(self.peak_memory_mb, 2),
                "parallel_tasks": self.parallel_tasks,
                "thread_pool_size": self.thread_pool_size,
            },
        }


# ============================================================================
# 11. GIT METRICS
# ============================================================================
@dataclass
class GitMetrics:
    """Metrics for Git repository status"""

    # Status
    is_git_repo: bool = False
    has_uncommitted_changes: bool = False
    uncommitted_files: int = 0
    uncommitted_list: List[str] = field(default_factory=list)

    # Branch
    current_branch: str = ""
    default_branch: str = ""
    is_detached: bool = False

    # Commit
    head_commit: str = ""
    head_commit_short: str = ""
    head_commit_date: str = ""
    head_commit_author: str = ""

    # Remote
    remote_url: str = ""
    remote_name: str = ""

    # Stats
    total_commits: int = 0
    contributors: int = 0

    def to_dict(self) -> Dict:
        return {
            "status": {
                "is_repo": self.is_git_repo,
                "uncommitted_changes": self.has_uncommitted_changes,
                "uncommitted_files": self.uncommitted_files,
                "uncommitted_list": self.uncommitted_list[:10],
            },
            "branch": {
                "current": self.current_branch,
                "default": self.default_branch,
                "detached": self.is_detached,
            },
            "commit": {
                "head": self.head_commit,
                "short": self.head_commit_short,
                "date": self.head_commit_date,
                "author": self.head_commit_author,
            },
            "remote": {"url": self.remote_url, "name": self.remote_name},
            "stats": {"total_commits": self.total_commits, "contributors": self.contributors},
        }


# ============================================================================
# COMPREHENSIVE METRICS COLLECTOR
# ============================================================================
class ComprehensiveMetricsCollector:
    """
    Central collector for all metrics across all analysis areas
    """

    def __init__(self, verbose: bool = True):
        self.verbose = verbose
        self.start_time = datetime.now()

        # Initialize all metrics
        self.reachability = ReachabilityMetrics()
        self.cve_scan = CVEScanMetrics()
        self.exploitability = ExploitabilityMetrics()
        self.malware = MalwareMetrics()
        self.secrets = SecretsMetrics()
        self.sandbox = SandboxMetrics()
        self.health = HealthMetrics()
        self.attack_surface = AttackSurfaceMetrics()
        self.sast = SASTMetrics()
        self.import_analysis = ImportAnalysisMetrics()
        self.performance = PerformanceMetrics()
        self.git = GitMetrics()

        # Logs
        self.logs: List[LogEntry] = []

        # Step tracking
        self._current_step: str = ""
        self._step_start: float = 0.0

    def log(
        self,
        level: LogLevel,
        area: AnalysisArea,
        component: str,
        message: str,
        entity: str = "",
        value: Any = None,
        duration_ms: float = 0.0,
        details: Dict = None,
    ):
        """Add a log entry"""
        entry = LogEntry(
            timestamp=datetime.now().isoformat(),
            level=level,
            area=area,
            component=component,
            message=message,
            entity=entity,
            value=value,
            duration_ms=duration_ms,
            details=details or {},
        )
        self.logs.append(entry)

        if self.verbose and level in [LogLevel.INFO, LogLevel.WARN, LogLevel.ERROR, LogLevel.API]:
            icon = {
                LogLevel.TRACE: "⋯",
                LogLevel.DEBUG: "",
                LogLevel.INFO: "",
                LogLevel.WARN: "",
                LogLevel.ERROR: "",
                LogLevel.METRIC: "",
                LogLevel.API: "",
            }.get(level, "•")
            logger.info(f" {icon} [{area.value}:{component}] {message}")

    def start_step(self, step_name: str):
        """Start timing a step"""
        self._current_step = step_name
        self._step_start = time.time()
        self.log(LogLevel.INFO, AnalysisArea.PERFORMANCE, step_name, f"Starting {step_name}")

    def end_step(self, step_name: str = None):
        """End timing a step"""
        step = step_name or self._current_step
        elapsed = (time.time() - self._step_start) * 1000
        self.performance.step_timings[step] = elapsed
        self.log(
            LogLevel.INFO,
            AnalysisArea.PERFORMANCE,
            step,
            f"Completed in {elapsed:.1f}ms",
            duration_ms=elapsed,
        )

    def record_api_call(self, api_name: str, duration_ms: float, success: bool = True):
        """Record an API call"""
        if api_name not in self.performance.api_latencies:
            self.performance.api_latencies[api_name] = []
        self.performance.api_latencies[api_name].append(duration_ms)
        self.performance.total_api_time_ms += duration_ms

        self.log(
            LogLevel.API,
            AnalysisArea.EXPLOITABILITY,
            api_name,
            f"API call {'succeeded' if success else 'failed'}",
            duration_ms=duration_ms,
            details={"success": success},
        )

    def finalize(self):
        """Finalize all metrics"""
        end_time = datetime.now()
        self.performance.start_timestamp = self.start_time.isoformat()
        self.performance.end_timestamp = end_time.isoformat()
        self.performance.total_time_ms = (end_time - self.start_time).total_seconds() * 1000

        # Calculate step percentages
        total = self.performance.total_time_ms or 1
        for step, time_ms in self.performance.step_timings.items():
            self.performance.step_percentages[step] = (time_ms / total) * 100

        # Find slowest step
        if self.performance.step_timings:
            slowest = max(self.performance.step_timings.items(), key=lambda x: x[1])
            self.performance.slowest_step = slowest[0]
            self.performance.slowest_step_time = slowest[1]

        # Calculate API averages
        for api, latencies in self.performance.api_latencies.items():
            if latencies:
                self.performance.api_avg_latency[api] = sum(latencies) / len(latencies)
                self.performance.api_max_latency[api] = max(latencies)

    def to_dict(self) -> Dict:
        """Export all metrics"""
        return {
            "version": "3.0",
            "generated_at": datetime.now().isoformat(),
            "reachability": self.reachability.to_dict(),
            "cve_scan": self.cve_scan.to_dict(),
            "exploitability": self.exploitability.to_dict(),
            "malware": self.malware.to_dict(),
            "secrets": self.secrets.to_dict(),
            "sandbox": self.sandbox.to_dict(),
            "health": self.health.to_dict(),
            "attack_surface": self.attack_surface.to_dict(),
            "sast": self.sast.to_dict(),
            "import_analysis": self.import_analysis.to_dict(),
            "performance": self.performance.to_dict(),
            "git": self.git.to_dict(),
            "log_summary": self._log_summary(),
        }

    def _log_summary(self) -> Dict:
        """Summarize logs"""
        by_level = {}
        by_area = {}
        for log in self.logs:
            by_level[log.level.value] = by_level.get(log.level.value, 0) + 1
            by_area[log.area.value] = by_area.get(log.area.value, 0) + 1
        return {"total_entries": len(self.logs), "by_level": by_level, "by_area": by_area}

    def get_logs(self, area: AnalysisArea = None, level: LogLevel = None, limit: int = None) -> List[Dict]:
        """Get filtered logs"""
        filtered = self.logs
        if area:
            filtered = [log for log in filtered if log.area == area]
        if level:
            filtered = [log for log in filtered if log.level == level]
        if limit:
            filtered = filtered[-limit:]
        return [log.to_dict() for log in filtered]

    def get_dashboard_data(self) -> Dict:
        """Get dashboard-ready data"""
        return {
            "summary_cards": [
                {
                    "title": "Reachability",
                    "value": f"{self.reachability.reachability_percentage:.0f}%",
                    "subtitle": f"{self.reachability.reachable_functions}/{self.reachability.total_functions} functions",
                },
                {
                    "title": "CVEs Found",
                    "value": self.cve_scan.total_cves,
                    "subtitle": f"{self.cve_scan.reachable_cves} reachable",
                    "color": "red" if self.cve_scan.reachable_critical > 0 else "orange",
                },
                {
                    "title": "Exploitability",
                    "value": self.exploitability.kev_matches + self.exploitability.exploitdb_matches,
                    "subtitle": f"KEV: {self.exploitability.kev_matches}, Exploits: {self.exploitability.exploitdb_matches}",
                },
                {
                    "title": "Malware",
                    "value": self.malware.guarddog_malicious + self.malware.semgrep_patterns_found,
                    "subtitle": f"Packages: {self.malware.guarddog_malicious}, Patterns: {self.malware.semgrep_patterns_found}",
                },
                {
                    "title": "Secrets",
                    "value": self.secrets.total_secrets,
                    "subtitle": f"{self.secrets.reachable_secrets} reachable",
                },
                {
                    "title": "Health Issues",
                    "value": self.health.critical_packages + self.health.risky_packages,
                    "subtitle": f"Critical: {self.health.critical_packages}, Risky: {self.health.risky_packages}",
                },
                {
                    "title": "Attack Surface",
                    "value": self.attack_surface.phantom_deps_count + self.attack_surface.shadow_imports_count,
                    "subtitle": f"Phantom: {self.attack_surface.phantom_deps_count}, Shadow: {self.attack_surface.shadow_imports_count}",
                },
                {
                    "title": "SAST Issues",
                    "value": self.sast.total_findings,
                    "subtitle": f"Critical: {self.sast.critical_findings}, High: {self.sast.high_findings}",
                },
            ],
            "performance": {
                "total_time": f"{self.performance.total_time_ms / 1000:.1f}s",
                "slowest_step": self.performance.slowest_step,
                "api_time": f"{self.performance.total_api_time_ms / 1000:.1f}s",
            },
            "git_status": {
                "uncommitted": self.git.has_uncommitted_changes,
                "branch": self.git.current_branch,
                "commit": self.git.head_commit_short,
            },
        }


# Singleton instance
_metrics_instance: Optional[ComprehensiveMetricsCollector] = None


def get_metrics(verbose: bool = True) -> ComprehensiveMetricsCollector:
    """Get or create metrics collector"""
    global _metrics_instance
    if _metrics_instance is None:
        _metrics_instance = ComprehensiveMetricsCollector(verbose=verbose)
    return _metrics_instance


def reset_metrics(verbose: bool = True) -> ComprehensiveMetricsCollector:
    """Reset and return new metrics collector"""
    global _metrics_instance
    _metrics_instance = ComprehensiveMetricsCollector(verbose=verbose)
    return _metrics_instance


if __name__ == "__main__":
    logger.info("=" * 70)
    logger.info("REACHABLE Comprehensive Metrics System v3.0")
    logger.info("=" * 70)

    metrics = reset_metrics()

    # Simulate some metrics
    metrics.reachability.total_functions = 500
    metrics.reachability.reachable_functions = 150
    metrics.reachability.unreachable_functions = 350
    metrics.reachability.reachability_percentage = 30.0

    metrics.cve_scan.total_cves = 25
    metrics.cve_scan.reachable_cves = 8
    metrics.cve_scan.critical_count = 3

    metrics.exploitability.kev_matches = 2
    metrics.exploitability.epss_high_count = 5

    metrics.git.has_uncommitted_changes = True
    metrics.git.uncommitted_files = 3

    metrics.finalize()

    logger.info(json.dumps(metrics.to_dict(), indent=2))
