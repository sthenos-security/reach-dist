"""
Metrics Audit Module for REACHABLE

Validates consistency between database and dashboard data.
Specifically designed to detect P2.44 bug (empty issues array).
"""

import json
import logging
import re
import sqlite3
from pathlib import Path
from typing import Dict, Optional

logger = logging.getLogger(__name__)


class MetricsAuditor:
    """Audit metrics accuracy across database and dashboard."""

    def __init__(self):
        self.scans_dir = Path.home() / ".reachable" / "scans"

    def auto_detect_latest_scan(self) -> Optional[Path]:
        """Find the most recent scan directory across all repos/branches."""
        if not self.scans_dir.exists():
            return None

        latest_scan = None
        latest_time = 0

        # Iterate: scans/{repo}/{branch}/{timestamp}/
        for repo_dir in self.scans_dir.iterdir():
            if not repo_dir.is_dir():
                continue
            for branch_dir in repo_dir.iterdir():
                if not branch_dir.is_dir():
                    continue
                # Check 'latest' symlink
                latest_link = branch_dir / "latest"
                if latest_link.exists() and latest_link.is_symlink():
                    scan_dir = latest_link.resolve()
                    if scan_dir.exists():
                        mtime = scan_dir.stat().st_mtime
                        if mtime > latest_time:
                            latest_time = mtime
                            latest_scan = scan_dir

        return latest_scan

    def audit_database(self, scan_path: Path) -> Dict:
        """Audit database contents."""
        # Structure: {repo}/{branch}/{timestamp}/
        # repo.db is at {repo}/repo.db
        scan_path = scan_path.resolve()
        repo_dir = scan_path.parent.parent
        db_path = repo_dir / "repo.db"

        if not db_path.exists():
            return {"error": f"Database not found at {db_path}"}

        try:
            conn = sqlite3.connect(str(db_path))
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()

            # Get latest scan
            cursor.execute("SELECT * FROM scans ORDER BY id DESC LIMIT 1")
            scan_row = cursor.fetchone()

            if not scan_row:
                conn.close()
                return {"error": "No scan records in database"}

            scan_info = {
                "scan_id": scan_row["id"],
                "status": scan_row["status"],
                "risk_level": scan_row["risk_level"],
                "risk_score": scan_row["risk_score"],
            }

            # Count findings by type
            cursor.execute(
                """
                SELECT finding_type,
                       COUNT(*) as total,
                       SUM(CASE WHEN app_reachability = 'REACHABLE' THEN 1 ELSE 0 END) as reachable,
                       SUM(CASE WHEN app_reachability = 'UNKNOWN' THEN 1 ELSE 0 END) as unknown
                FROM findings
                WHERE scan_id = ?
                GROUP BY finding_type
            """,
                (scan_row["id"],),
            )

            findings_by_type = {}
            reachable_by_type = {}
            unknown_by_type = {}

            for row in cursor.fetchall():
                ftype = row["finding_type"]
                findings_by_type[ftype] = row["total"]
                reachable_by_type[ftype] = row["reachable"]
                unknown_by_type[ftype] = row["unknown"]

            conn.close()

            return {
                "db_path": str(db_path),
                "scan_info": scan_info,
                "findings_by_type": findings_by_type,
                "reachable_by_type": reachable_by_type,
                "unknown_by_type": unknown_by_type,
                "total_findings": sum(findings_by_type.values()),
                "total_reachable": sum(reachable_by_type.values()),
            }

        except Exception as e:
            return {"error": f"Database error: {e}"}

    def audit_dashboard(self, scan_path: Path) -> Dict:
        """Audit dashboard contents."""
        # Dashboard is at {scan}/dashboard/index.html
        scan_path = scan_path.resolve()
        dash_path = scan_path / "dashboard" / "index.html"

        if not dash_path.exists():
            return {"error": f"Dashboard not found at {dash_path}"}

        try:
            content = dash_path.read_text()

            # Extract dashboardData from HTML
            match = re.search(r"window\.dashboardData\s*=\s*({.*?});", content, re.DOTALL)
            if not match:
                return {"error": "Could not find dashboardData in HTML"}

            data = json.loads(match.group(1))

            issues = data.get("issues", [])

            return {
                "dash_path": str(dash_path),
                "version": data.get("version", "unknown"),
                "risk_level": data.get("riskLevel", "unknown"),
                "issues_count": len(issues),
                "issues_empty": len(issues) == 0,
            }

        except Exception as e:
            return {"error": f"Dashboard error: {e}"}

    def compare_results(self, db_results: Dict, dash_results: Dict) -> Dict:
        """Compare database vs dashboard."""
        issues = []

        # Check for errors
        if "error" in db_results:
            issues.append({"severity": "critical", "message": f"DB: {db_results['error']}"})
        if "error" in dash_results:
            issues.append({"severity": "critical", "message": f"Dashboard: {dash_results['error']}"})

        if issues:
            return {"has_critical_issues": True, "issues": issues}

        # P2.44: Empty issues when DB has findings
        db_total = db_results.get("total_findings", 0)
        dash_count = dash_results.get("issues_count", 0)

        if db_total > 0 and dash_count == 0:
            issues.append(
                {
                    "severity": "critical",
                    "message": "P2.44 BUG DETECTED: Dashboard issues array is EMPTY",
                    "detail": f"Database has {db_total} findings but dashboard shows 0",
                    "fix": "Apply loaders.py patch",
                }
            )

        # Risk level mismatch
        db_risk = db_results.get("scan_info", {}).get("risk_level", "").upper()
        dash_risk = dash_results.get("risk_level", "").upper()

        if db_risk and dash_risk and db_risk != dash_risk:
            issues.append(
                {
                    "severity": "warning",
                    "message": f"Risk mismatch: DB={db_risk}, Dashboard={dash_risk}",
                }
            )

        return {
            "has_critical_issues": any(i["severity"] == "critical" for i in issues),
            "has_warnings": any(i["severity"] == "warning" for i in issues),
            "issues": issues,
        }

    def print_report(self, scan_path: Path, db_results: Dict, dash_results: Dict, comparison: Dict):
        """Print audit report."""
        logger.info("=" * 80)
        logger.info("REACHABLE METRICS AUDIT")
        logger.info("=" * 80)
        logger.info(f"\n Scan: {scan_path}\n")

        # Database
        logger.info("─" * 80)
        logger.info("DATABASE")
        logger.info("─" * 80)
        if "error" in db_results:
            logger.info(f" {db_results['error']}")
        else:
            info = db_results["scan_info"]
            logger.info(f"Path: {db_results['db_path']}")
            logger.info(f"Risk: {info['risk_level']} (score: {info['risk_score']})")
            logger.info(f"Total: {db_results['total_findings']} findings")
            logger.info(f"Reachable: {db_results['total_reachable']}")
            logger.info("\nBy Type:")
            for ftype in sorted(db_results["findings_by_type"].keys()):
                total = db_results["findings_by_type"][ftype]
                reach = db_results["reachable_by_type"][ftype]
                logger.info(f" {ftype:10} {total:4} total, {reach:4} reachable")

        # Dashboard
        logger.info("\n" + "─" * 80)
        logger.info("DASHBOARD")
        logger.info("─" * 80)
        if "error" in dash_results:
            logger.info(f" {dash_results['error']}")
        else:
            logger.info(f"Path: {dash_results['dash_path']}")
            logger.info(f"Risk: {dash_results['risk_level']}")
            logger.info(f"Issues: {dash_results['issues_count']}")
            if dash_results["issues_empty"]:
                logger.info("  Issues array is EMPTY")

        # Comparison
        logger.info("\n" + "─" * 80)
        logger.info("RESULT")
        logger.info("─" * 80)

        if comparison.get("has_critical_issues") or comparison.get("has_warnings"):
            for issue in comparison["issues"]:
                icon = "" if issue["severity"] == "critical" else ""
                logger.info(f"{icon} {issue['message']}")
                if "detail" in issue:
                    logger.info(f" {issue['detail']}")
                if "fix" in issue:
                    logger.info(f" {issue['fix']}")
        else:
            logger.info(" No issues - database and dashboard are consistent")

        logger.info("\n" + "=" * 80)
