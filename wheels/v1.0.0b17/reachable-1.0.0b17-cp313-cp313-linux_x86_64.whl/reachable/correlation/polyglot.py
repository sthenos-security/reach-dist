# Copyright © 2026 Sthenos Security. All rights reserved.
# STATUS: investigate-superseded — Cross-language correlation. Check if engine.py replaces this.

"""
Polyglot Correlator - Cross-Language Call Graph Stitching

Stitches together call graphs from multiple languages to enable
unified reachability analysis across language boundaries.
"""

import json
import logging
from collections import defaultdict
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Tuple

# Initialize module-level logger
logger = logging.getLogger(__name__)


@dataclass
class CallGraphNode:
    """Represents a function/method in any language."""

    id: str  # Unique identifier (e.g., "python:app.process_data")
    language: str  # python, go, c, cpp, etc.
    file: str  # Source file path
    line: int  # Line number
    function_name: str  # Function/method name
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class CallGraphEdge:
    """Represents a call from one function to another."""

    source: str  # Source node ID
    target: str  # Target node ID
    edge_type: str  # function_call, ffi_call, subprocess_call
    mechanism: Optional[str] = None  # ctypes, cffi, cgo, etc.
    evidence: Optional[str] = None  # Source location of call


@dataclass
class CrossLanguagePath:
    """Represents a path across language boundaries."""

    start_node: str
    end_node: str
    path: List[str]
    languages: List[str]
    boundaries: List[Tuple[str, str, str]]  # (from_lang, to_lang, mechanism)
    cve_id: Optional[str] = None


class PolyglotCallGraph:
    """Unified call graph spanning multiple languages."""

    def __init__(self):
        self.nodes: Dict[str, CallGraphNode] = {}
        self.edges: List[CallGraphEdge] = []
        self.adjacency: Dict[str, List[str]] = defaultdict(list)
        self.reverse_adjacency: Dict[str, List[str]] = defaultdict(list)

    def add_node(self, node: CallGraphNode):
        """Add a node to the graph."""
        self.nodes[node.id] = node

    def add_edge(self, edge: CallGraphEdge):
        """Add an edge to the graph."""
        self.edges.append(edge)
        self.adjacency[edge.source].append(edge.target)
        self.reverse_adjacency[edge.target].append(edge.source)

    def get_successors(self, node_id: str) -> List[str]:
        """Get all nodes called by this node."""
        return self.adjacency.get(node_id, [])

    def get_predecessors(self, node_id: str) -> List[str]:
        """Get all nodes that call this node."""
        return self.reverse_adjacency.get(node_id, [])

    def find_path(self, start: str, end: str) -> Optional[List[str]]:
        """Find a path from start to end using BFS."""
        if start not in self.nodes or end not in self.nodes:
            return None

        queue = [(start, [start])]
        visited = {start}

        while queue:
            current, path = queue.pop(0)

            if current == end:
                return path

            for successor in self.get_successors(current):
                if successor not in visited:
                    visited.add(successor)
                    queue.append((successor, path + [successor]))

        return None

    def reachable_from(self, start: str) -> Set[str]:
        """Get all nodes reachable from start."""
        if start not in self.nodes:
            return set()

        reachable = set()
        queue = [start]
        visited = {start}

        while queue:
            current = queue.pop(0)
            reachable.add(current)

            for successor in self.get_successors(current):
                if successor not in visited:
                    visited.add(successor)
                    queue.append(successor)

        return reachable


class PolyglotCorrelator:
    """
    Correlates security findings across language boundaries.

    Stitches together:
    - Python call graphs (from AST analysis)
    - Go call graphs (from govulncheck)
    - FFI boundaries (from ffi_detector)
    """

    def __init__(self, output_dir: Path):
        self.output_dir = Path(output_dir)
        self.unified_graph = PolyglotCallGraph()
        self.project_graphs: Dict[str, Dict] = {}
        self.ffi_bridges: List[Dict] = []
        self.cve_locations: Dict[str, List[str]] = defaultdict(list)

    def load_project(self, project_id: str, project_output_dir: Path):
        """Load analysis results for a project."""
        project_data = {
            "id": project_id,
            "output_dir": project_output_dir,
            "language": None,
            "call_graph": None,
            "ffi_calls": None,
            "cves": None,
        }

        # Detect language
        if (project_output_dir / "govulncheck_results.json").exists():
            project_data["language"] = "go"
        elif (project_output_dir / "reachability_results.json").exists():
            # Could be Python, JS, etc.
            # Check for Python-specific files
            if (project_output_dir / "malware_findings.json").exists():
                project_data["language"] = "python"
            else:
                project_data["language"] = "javascript"

        # Load call graph
        reachability_file = project_output_dir / "reachability_results.json"
        if reachability_file.exists():
            with open(reachability_file) as f:
                project_data["call_graph"] = json.load(f)

        # Load govulncheck results (Go)
        govulncheck_file = project_output_dir / "govulncheck_results.json"
        if govulncheck_file.exists():
            with open(govulncheck_file) as f:
                project_data["govulncheck"] = json.load(f)

        # Load FFI calls
        ffi_file = project_output_dir / "ffi_analysis.json"
        if ffi_file.exists():
            with open(ffi_file) as f:
                project_data["ffi_calls"] = json.load(f)

        # Load CVEs
        final_report = project_output_dir / "final_report.json"
        if final_report.exists():
            with open(final_report) as f:
                project_data["cves"] = json.load(f)

        self.project_graphs[project_id] = project_data
        return project_data

    def build_unified_graph(self):
        """Build unified call graph from all projects."""

        # Step 1: Add nodes from each project
        for project_id, project_data in self.project_graphs.items():
            self._add_project_nodes(project_id, project_data)

        # Step 2: Add edges within each project
        for project_id, project_data in self.project_graphs.items():
            self._add_project_edges(project_id, project_data)

        # Step 3: Add cross-language edges (FFI bridges)
        self._stitch_ffi_boundaries()

        return self.unified_graph

    def _add_project_nodes(self, project_id: str, project_data: Dict):
        """Add nodes from a single project."""
        language = project_data["language"]

        if language == "python" and project_data.get("call_graph"):
            # Extract Python functions
            call_graph = project_data["call_graph"]
            functions = call_graph.get("functions", {})

            for func_id, func_data in functions.items():
                node = CallGraphNode(
                    id=f"python:{project_id}:{func_id}",
                    language="python",
                    file=func_data.get("file", ""),
                    line=func_data.get("line", 0),
                    function_name=func_id,
                    metadata=func_data,
                )
                self.unified_graph.add_node(node)

        elif language == "go" and project_data.get("govulncheck"):
            # Extract Go functions from govulncheck
            govulncheck = project_data["govulncheck"]

            # Add functions from call stacks
            for cve in govulncheck.get("reachable_cves", []):
                for call_stack in cve.get("call_stacks", []):
                    parts = call_stack.split(" → ")
                    for part in parts:
                        # Format: "package.Function"
                        node_id = f"go:{project_id}:{part}"
                        if node_id not in self.unified_graph.nodes:
                            node = CallGraphNode(
                                id=node_id,
                                language="go",
                                file="",  # Not available from govulncheck
                                line=0,
                                function_name=part,
                                metadata={"from_govulncheck": True},
                            )
                            self.unified_graph.add_node(node)

    def _add_project_edges(self, project_id: str, project_data: Dict):
        """Add edges within a single project."""
        language = project_data["language"]

        if language == "python" and project_data.get("call_graph"):
            # Extract Python call edges
            call_graph = project_data["call_graph"]
            call_edges = call_graph.get("call_edges", [])

            for edge_data in call_edges:
                source = edge_data.get("source", "")
                target = edge_data.get("target", "")

                if source and target:
                    edge = CallGraphEdge(
                        source=f"python:{project_id}:{source}",
                        target=f"python:{project_id}:{target}",
                        edge_type="function_call",
                        evidence=edge_data.get("location", ""),
                    )
                    self.unified_graph.add_edge(edge)

        elif language == "go" and project_data.get("govulncheck"):
            # Extract Go call edges from call stacks
            govulncheck = project_data["govulncheck"]

            for cve in govulncheck.get("reachable_cves", []):
                cve_id = cve.get("cve")

                for call_stack in cve.get("call_stacks", []):
                    parts = call_stack.split(" → ")

                    # Add edges along the call stack
                    for i in range(len(parts) - 1):
                        source = f"go:{project_id}:{parts[i]}"
                        target = f"go:{project_id}:{parts[i + 1]}"

                        edge = CallGraphEdge(
                            source=source,
                            target=target,
                            edge_type="function_call",
                            evidence=f"govulncheck call stack for {cve_id}",
                        )
                        self.unified_graph.add_edge(edge)

                        # Mark vulnerable function
                        if i == len(parts) - 2:
                            self.cve_locations[cve_id].append(target)

    def _stitch_ffi_boundaries(self):
        """Add edges across language boundaries."""

        for project_id, project_data in self.project_graphs.items():
            ffi_calls = project_data.get("ffi_calls")
            if not ffi_calls:
                continue

            for ffi_call in ffi_calls.get("cross_language_boundaries", []):
                # Find matching target project
                target_project = self._find_target_project(ffi_call)

                if target_project:
                    # Create FFI edge
                    source = self._get_ffi_source(project_id, ffi_call)
                    target = self._get_ffi_target(target_project, ffi_call)

                    if source and target:
                        edge = CallGraphEdge(
                            source=source,
                            target=target,
                            edge_type="ffi_call",
                            mechanism=ffi_call.get("mechanism"),
                            evidence=f"{ffi_call.get('file')}:{ffi_call.get('line')}",
                        )
                        self.unified_graph.add_edge(edge)
                        self.ffi_bridges.append(
                            {
                                "source": source,
                                "target": target,
                                "mechanism": ffi_call.get("mechanism"),
                                "source_lang": ffi_call.get("source_language", "python"),
                                "target_lang": ffi_call.get("target_language"),
                            }
                        )

    def _find_target_project(self, ffi_call: Dict) -> Optional[str]:
        """Find the project that corresponds to an FFI call target."""
        target_lang = ffi_call.get("target_language")

        # Simple heuristic: find first project with matching language
        for project_id, project_data in self.project_graphs.items():
            if project_data["language"] == target_lang:
                return project_id

        return None

    def _get_ffi_source(self, project_id: str, ffi_call: Dict) -> Optional[str]:
        """Get the source node ID for an FFI call."""
        # For now, create a generic caller node
        file = ffi_call.get("file", "")
        line = ffi_call.get("line", 0)
        return f"python:{project_id}:ffi_caller_{file}_{line}"

    def _get_ffi_target(self, target_project: str, ffi_call: Dict) -> Optional[str]:
        """Get the target node ID for an FFI call."""
        # Try to find matching Go/C function
        target_lang = ffi_call.get("target_language")

        if target_lang == "go":
            # Look for exported Go functions
            # For now, return first Go function in target project
            for node_id, node in self.unified_graph.nodes.items():
                if node_id.startswith(f"go:{target_project}:"):
                    return node_id

        return None

    def compute_cross_language_reachability(self) -> Dict[str, Any]:
        """
        Compute reachability across language boundaries.

        Returns:
            Dictionary mapping CVE IDs to cross-language reachability info
        """
        results = {
            "polyglot_analysis": True,
            "languages": list(set(p["language"] for p in self.project_graphs.values())),
            "ffi_boundaries": len(self.ffi_bridges),
            "cve_reachability": {},
        }

        # For each CVE, check if it's reachable across boundaries
        for cve_id, cve_nodes in self.cve_locations.items():
            for cve_node in cve_nodes:
                # Find all paths to this CVE from Python entrypoints
                paths = self._find_cross_language_paths_to_cve(cve_node)

                if paths:
                    results["cve_reachability"][cve_id] = {
                        "verdict": "REACHABLE_CROSS_LANGUAGE",
                        "paths": len(paths),
                        "sample_path": self._format_path(paths[0]) if paths else None,
                        "all_paths": [self._format_path(p) for p in paths[:5]],  # Top 5
                    }
                else:
                    results["cve_reachability"][cve_id] = {
                        "verdict": "UNREACHABLE_CROSS_LANGUAGE",
                        "note": "No path found across language boundaries",
                    }

        return results

    def _find_cross_language_paths_to_cve(self, cve_node: str) -> List[CrossLanguagePath]:
        """Find all cross-language paths to a CVE."""
        paths = []

        # Find all Python entrypoints
        entrypoints = [
            node_id
            for node_id, node in self.unified_graph.nodes.items()
            if node.language == "python" and "entrypoint" in node.metadata
        ]

        # For each entrypoint, try to find a path to the CVE
        for entrypoint in entrypoints:
            path = self.unified_graph.find_path(entrypoint, cve_node)

            if path:
                # Analyze the path for language boundaries
                languages = []
                boundaries = []

                for i in range(len(path)):
                    node = self.unified_graph.nodes[path[i]]
                    languages.append(node.language)

                    if i > 0:
                        prev_node = self.unified_graph.nodes[path[i - 1]]
                        if prev_node.language != node.language:
                            # Find the edge mechanism
                            mechanism = "unknown"
                            for edge in self.unified_graph.edges:
                                if edge.source == path[i - 1] and edge.target == path[i]:
                                    mechanism = edge.mechanism or "ffi"
                                    break

                            boundaries.append((prev_node.language, node.language, mechanism))

                cross_path = CrossLanguagePath(
                    start_node=entrypoint,
                    end_node=cve_node,
                    path=path,
                    languages=languages,
                    boundaries=boundaries,
                    cve_id=cve_node.split(":")[-1] if ":" in cve_node else None,
                )
                paths.append(cross_path)

        return paths

    def _format_path(self, cross_path: CrossLanguagePath) -> Dict[str, Any]:
        """Format a cross-language path for output."""
        steps = []

        for i, node_id in enumerate(cross_path.path):
            node = self.unified_graph.nodes.get(node_id)
            if not node:
                continue

            step = {
                "step": i + 1,
                "language": node.language,
                "function": node.function_name,
                "location": f"{node.file}:{node.line}" if node.file else "unknown",
            }

            # Check if this is a boundary crossing
            if i < len(cross_path.path) - 1:
                next_node = self.unified_graph.nodes.get(cross_path.path[i + 1])
                if next_node and next_node.language != node.language:
                    # Find mechanism
                    for boundary in cross_path.boundaries:
                        if boundary[0] == node.language and boundary[1] == next_node.language:
                            step["boundary_crossing"] = f"{node.language}→{next_node.language} via {boundary[2]}"
                            break

            steps.append(step)

        return {
            "steps": steps,
            "languages_crossed": list(set(cross_path.languages)),
            "boundary_count": len(cross_path.boundaries),
        }

    def save_results(self, output_path: Path):
        """Save polyglot correlation results."""
        results = self.compute_cross_language_reachability()

        # Add graph statistics
        results["graph_stats"] = {
            "total_nodes": len(self.unified_graph.nodes),
            "total_edges": len(self.unified_graph.edges),
            "nodes_by_language": self._count_nodes_by_language(),
            "ffi_bridges": [
                {
                    "source": b["source"],
                    "target": b["target"],
                    "mechanism": b["mechanism"],
                    "from": b["source_lang"],
                    "to": b["target_lang"],
                }
                for b in self.ffi_bridges
            ],
        }

        with open(output_path, "w") as f:
            json.dump(results, f, indent=2)

    def _count_nodes_by_language(self) -> Dict[str, int]:
        """Count nodes by language."""
        counts = defaultdict(int)
        for node in self.unified_graph.nodes.values():
            counts[node.language] += 1
        return dict(counts)


def main():
    """CLI entry point."""
    import sys

    if len(sys.argv) < 2:
        logger.info("Usage: python polyglot_correlator.py <output_directory>")
        logger.info("Example:")
        logger.info("  python polyglot_correlator.py output/")
        logger.info("This will correlate all projects in output/ directory")
        sys.exit(1)

    output_dir = Path(sys.argv[1])
    if not output_dir.exists():
        logger.info(f"Error: {output_dir} does not exist")
        sys.exit(1)

    logger.info(" Polyglot Correlator - Cross-Language Analysis")

    correlator = PolyglotCorrelator(output_dir)

    # Load all projects
    projects_found = 0
    for project_dir in output_dir.iterdir():
        if project_dir.is_dir():
            logger.info(f" Loading project: {project_dir.name}")
            correlator.load_project(project_dir.name, project_dir)
            projects_found += 1

    if projects_found == 0:
        logger.info("  No projects found in output directory")
        sys.exit(1)

    logger.info(f" Loaded {projects_found} project(s)")

    # Build unified graph
    logger.info(" Building unified call graph...")
    correlator.build_unified_graph()
    logger.info(f" Nodes: {len(correlator.unified_graph.nodes)}")
    logger.info(f" Edges: {len(correlator.unified_graph.edges)}")
    logger.info(f" FFI Boundaries: {len(correlator.ffi_bridges)}")

    # Compute cross-language reachability
    logger.info(" Computing cross-language reachability...")
    results = correlator.compute_cross_language_reachability()

    # Display results
    logger.info(" CROSS-LANGUAGE REACHABILITY RESULTS:")

    for cve_id, cve_data in results["cve_reachability"].items():
        logger.info(f"CVE: {cve_id}")
        logger.info(f" Verdict: {cve_data['verdict']}")

        if cve_data["verdict"] == "REACHABLE_CROSS_LANGUAGE":
            logger.info(f" Paths found: {cve_data['paths']}")

            if cve_data.get("sample_path"):
                logger.info("  Sample path:")
                for step in cve_data["sample_path"]["steps"]:
                    logger.info(f" {step['step']}. [{step['language']}] {step['function']}")
                    if "boundary_crossing" in step:
                        logger.info(f" {step['boundary_crossing']}")

    # Save results
    output_path = output_dir / "polyglot_correlation.json"
    correlator.save_results(output_path)
    logger.info(f" Saved results to: {output_path}")


if __name__ == "__main__":
    main()
