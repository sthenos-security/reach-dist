# Copyright © 2026 Sthenos Security. All rights reserved.
"""
Correlation engine — match findings to call graph, determine reachability.

Modules:
- engine          - Main correlation engine (ComprehensiveCorrelationEngine)
- cve_functions   - CVE-to-function mapping via git analysis
- cwe_reachability - CWE reachability analysis
- polyglot        - Cross-language correlation
- risk            - Risk scoring
- metrics         - Correlation quality metrics
- correlation     - Legacy correlation utilities
"""
