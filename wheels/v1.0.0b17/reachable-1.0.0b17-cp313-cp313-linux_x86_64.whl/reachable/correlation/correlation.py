#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.

"""
Correlation Engine - Cross-Threat Analysis

Combines multiple threat dimensions to identify:
1. Packages with multiple vulnerabilities (CVE + malware)
2. Functions with multiple issues (CVE + secrets)
3. Attack paths through the call graph
4. Composite risk scores

This provides unified risk assessment across all security findings.
"""

from collections import deque
from dataclasses import dataclass
from typing import Dict, List, Optional, Set


@dataclass
class ThreatEntity:
    """Base class for entities that can have threats"""

    name: str
    entity_type: str  # 'package', 'function', 'file'


@dataclass
class CompositeThreat:
    """Combined threat assessment for an entity"""

    entity: ThreatEntity
    threat_types: List[str]  # ['cve', 'malware', 'secret']
    base_risk: float
    composite_risk: float
    escalation_factor: float
    is_reachable: bool
    priority: str  # CRITICAL, HIGH, MEDIUM, LOW
    reasoning: str
    individual_threats: Dict[str, any]


@dataclass
class AttackPath:
    """Multi-stage attack path through call graph"""

    path_id: str
    severity: str
    composite_risk: float
    stages: List[Dict]
    threat_count: int
    is_exploitable: bool
    recommendation: str


class CorrelationEngine:
    """
    Cross-threat correlation engine with health-based risk scoring

    Combines CVE, malware, secrets, reachability AND package health metrics
    to produce comprehensive risk assessments.

    Risk Formula:
        TotalRiskScore = (CVE_Severity × Reachability) + ExploitRisk + HealthPenalty

    Where:
        - Reachability: 1.0 if reachable, 0.2 if unreachable (80% reduction)
        - HealthPenalty: Maintenance (50%) + Popularity (30%) + Outdated (20%)
    """

    def __init__(
        self,
        call_graph: Dict[str, Set[str]],
        reachable_functions: Set[str],
        health_metrics: Optional[Dict[str, any]] = None,
    ):
        self.call_graph = call_graph
        self.reachable_functions = reachable_functions
        self.health_metrics = health_metrics or {}  # package_name -> HealthMetrics

        # Threat data (populated by correlate method)
        self.cve_data: Dict[str, any] = {}
        self.malware_packages: Dict[str, any] = {}
        self.malware_code: Dict[str, any] = {}
        self.secrets: List[Dict] = []

        # Correlation results
        self.package_threats: Dict[str, CompositeThreat] = {}
        self.function_threats: Dict[str, CompositeThreat] = {}
        self.attack_paths: List[AttackPath] = []

    def correlate(
        self,
        cve_data: Dict[str, any],
        malware_packages: Optional[Dict[str, any]] = None,
        malware_code: Optional[Dict[str, any]] = None,
        secrets: Optional[List[Dict]] = None,
    ) -> Dict[str, any]:
        """
        Main correlation method - combines all threat data

        Args:
            cve_data: CVE findings with reachability
            malware_packages: GuardDog detections
            malware_code: Semgrep malware patterns
            secrets: Semgrep secrets findings

        Returns:
            Correlation results with composite threats and attack paths
        """
        self.cve_data = cve_data
        self.malware_packages = malware_packages or {}
        self.malware_code = malware_code or {}
        self.secrets = secrets or []

        # Step 1: Analyze packages (CVE + malware)
        self._correlate_packages()

        # Step 2: Analyze functions (CVE + secrets)
        self._correlate_functions()

        # Step 3: Identify attack paths
        self._analyze_attack_paths()

        # Step 4: Generate summary
        return self._generate_correlation_report()

    def _correlate_packages(self):
        """
        Correlate CVEs with malware for each package

        Identifies packages that have BOTH vulnerabilities AND malicious behavior
        """
        # Get all unique packages
        packages = set()

        # From CVEs
        for cve_id, cve_info in self.cve_data.items():
            package = cve_info.get("package")
            if package:
                packages.add(package)

        # From malware
        for package in self.malware_packages.keys():
            packages.add(package)

        # Analyze each package
        for package in packages:
            entity = ThreatEntity(name=package, entity_type="package")

            # Collect threats for this package
            threats = {}
            threat_types = []
            risks = []

            # Check for CVEs
            package_cves = [(cve_id, info) for cve_id, info in self.cve_data.items() if info.get("package") == package]

            if package_cves:
                threat_types.append("cve")
                # Get highest CVE risk
                cve_risks = [info.get("verdict", {}).get("risk_score", 0) for _, info in package_cves]
                max_cve_risk = max(cve_risks) if cve_risks else 0
                risks.append(max_cve_risk)

                threats["cves"] = {
                    "count": len(package_cves),
                    "highest_risk": max_cve_risk,
                    "reachable": any(info.get("is_reachable") for _, info in package_cves),
                    "cve_ids": [cve_id for cve_id, _ in package_cves],
                }

            # Check for malware
            if package in self.malware_packages:
                malware_info = self.malware_packages[package]

                # Handle both dict and object formats
                if isinstance(malware_info, dict):
                    is_malicious = malware_info.get("is_malicious", False)
                    risk_level = malware_info.get("risk_level", "MEDIUM")
                    detections = malware_info.get("detections", [])
                    confidence = malware_info.get("confidence", "medium")
                else:
                    # MalwareDetection object or similar
                    is_malicious = getattr(malware_info, "is_malicious", False)
                    risk_level = getattr(malware_info, "risk_level", "MEDIUM")
                    detections = getattr(malware_info, "detections", [])
                    confidence = getattr(malware_info, "confidence", "medium")

                if is_malicious:
                    threat_types.append("malware")

                    # Convert risk level to score
                    malware_risk = {"CRITICAL": 95, "HIGH": 80, "MEDIUM": 60, "LOW": 40}.get(risk_level, 60)

                    risks.append(malware_risk)

                    threats["malware"] = {
                        "risk_level": risk_level,
                        "risk_score": malware_risk,
                        "detections": detections,
                        "confidence": confidence,
                    }

            # Check for health issues (LEADING INDICATORS OF RISK)
            health_penalty = 0
            health_data = None
            if package in self.health_metrics:
                health_metrics = self.health_metrics[package]
                health_penalty = health_metrics.health_penalty  # 0-100
                health_data = {
                    "overall_health": health_metrics.overall_health,
                    "health_penalty": health_penalty,
                    "maintenance_risk": health_metrics.maintenance_risk,
                    "popularity_risk": health_metrics.popularity_risk,
                    "outdated_risk": health_metrics.outdated_risk,
                    "is_maintained": health_metrics.is_maintained,
                    "is_popular": health_metrics.is_popular,
                    "is_outdated": health_metrics.is_outdated,
                    "days_since_last_commit": health_metrics.days_since_last_commit,
                    "versions_behind": health_metrics.versions_behind,
                }

                # Flag high-risk health issues as separate threat type
                if health_metrics.overall_health in ("CRITICAL", "RISKY"):
                    if "health" not in threat_types:
                        threat_types.append("health")
                    threats["health"] = health_data

            # Only create composite threat if multiple threat types exist OR single high-risk threat
            if len(threat_types) >= 2 or (len(threat_types) == 1 and threat_types[0] in ("malware", "health")):
                base_risk = max(risks) if risks else 0

                # Escalation for multiple threats
                if len(threat_types) >= 2:
                    escalation_factor = 1.0 + (0.3 * (len(threat_types) - 1))  # 30% per additional threat
                    composite_risk_base = base_risk * escalation_factor
                    priority = "CRITICAL"
                    reasoning = f"Package has {len(threat_types)} threat types: {', '.join(threat_types)}"
                else:
                    # Single threat (malware or critical health)
                    escalation_factor = 1.0
                    composite_risk_base = base_risk
                    if threat_types[0] == "malware":
                        priority = "CRITICAL" if base_risk >= 70 else "HIGH"
                        reasoning = "Malicious package detected"
                    else:
                        priority = "HIGH"
                        reasoning = "Critical package health issues detected"

                # ADD HEALTH PENALTY TO COMPOSITE RISK
                # Health contributes up to 20% of total risk
                composite_risk = min(composite_risk_base + (health_penalty * 0.2), 100)

                # If health is critical, upgrade priority
                if health_data and health_data["overall_health"] == "CRITICAL":
                    if priority == "HIGH":
                        priority = "CRITICAL"
                    reasoning += f" + Critical health: {health_data['overall_health']}"

                is_reachable = threats.get("cves", {}).get("reachable", False)

                composite = CompositeThreat(
                    entity=entity,
                    threat_types=threat_types,
                    base_risk=base_risk,
                    composite_risk=composite_risk,
                    escalation_factor=escalation_factor,
                    is_reachable=is_reachable,
                    priority=priority,
                    reasoning=reasoning,
                    individual_threats=threats,
                )

                self.package_threats[package] = composite

    def _correlate_functions(self):
        """
        Correlate CVEs with secrets for each function

        Identifies functions that have BOTH vulnerable dependencies AND hardcoded secrets
        """
        # Get all functions with threats
        functions_with_threats = set()

        # From CVEs
        for cve_id, cve_info in self.cve_data.items():
            app_functions = cve_info.get("app_functions", [])
            for func in app_functions:
                functions_with_threats.add(func)

        # From secrets - match by file path to function
        # Build a file-to-functions map
        file_to_funcs = {}
        for func in self.reachable_functions:
            # Extract file info from function name pattern
            # e.g., "app.auth-service.handlers.login" -> try to match "auth-service/handlers"
            parts = func.split(".")
            for i, part in enumerate(parts):
                if part and part not in ("app", "lib", "main", "__init__"):
                    # Build potential file path patterns
                    path_pattern = "/".join(parts[1 : i + 1]).lower()
                    if path_pattern:
                        if path_pattern not in file_to_funcs:
                            file_to_funcs[path_pattern] = set()
                        file_to_funcs[path_pattern].add(func)

        for secret in self.secrets:
            # Get file path from secret
            secret_file = (secret.get("file") or secret.get("path") or "").lower()
            if secret_file:
                # Try to match secret file to functions
                matched_func = None
                for pattern, funcs in file_to_funcs.items():
                    if pattern in secret_file or secret_file in pattern:
                        # Use the first matching function
                        matched_func = next(iter(funcs), None)
                        break

                if matched_func:
                    functions_with_threats.add(matched_func)
                    # Store the matched function in the secret for later lookup
                    secret["_matched_function"] = matched_func

        # Analyze each function
        for function in functions_with_threats:
            entity = ThreatEntity(name=function, entity_type="function")

            threats = {}
            threat_types = []
            risks = []

            # Check for CVEs in this function
            function_cves = [
                (cve_id, info) for cve_id, info in self.cve_data.items() if function in info.get("app_functions", [])
            ]

            if function_cves:
                threat_types.append("cve")
                cve_risks = [info.get("verdict", {}).get("risk_score", 0) for _, info in function_cves]
                max_cve_risk = max(cve_risks) if cve_risks else 0
                risks.append(max_cve_risk)

                threats["cves"] = {
                    "count": len(function_cves),
                    "highest_risk": max_cve_risk,
                    "cve_ids": [cve_id for cve_id, _ in function_cves],
                }

            # Check for secrets in this function
            function_secrets = [
                s for s in self.secrets if s.get("_matched_function") == function or s.get("function") == function
            ]

            if function_secrets:
                threat_types.append("secret")

                # Secrets in reachable code = high risk (90)
                # Secrets in unreachable code = medium risk (50)
                is_reachable = function in self.reachable_functions
                secret_risk = 90 if is_reachable else 50
                risks.append(secret_risk)

                threats["secrets"] = {
                    "count": len(function_secrets),
                    "risk_score": secret_risk,
                    "is_reachable": is_reachable,
                    "types": list(set(s.get("type", "unknown") for s in function_secrets)),
                }

            # Create composite threat if multiple types or high risk
            if len(threat_types) >= 2:
                base_risk = max(risks) if risks else 0
                escalation_factor = 1.0 + (0.25 * (len(threat_types) - 1))  # 25% per additional threat
                composite_risk = min(base_risk * escalation_factor, 100)

                is_reachable = function in self.reachable_functions

                if is_reachable and composite_risk >= 70:
                    priority = "CRITICAL"
                elif is_reachable:
                    priority = "HIGH"
                elif composite_risk >= 70:
                    priority = "MEDIUM"
                else:
                    priority = "LOW"

                reasoning = f"Function has {len(threat_types)} threat types"
                if is_reachable:
                    reasoning += " in reachable code path"
                else:
                    reasoning += " in unreachable code"

                composite = CompositeThreat(
                    entity=entity,
                    threat_types=threat_types,
                    base_risk=base_risk,
                    composite_risk=composite_risk,
                    escalation_factor=escalation_factor,
                    is_reachable=is_reachable,
                    priority=priority,
                    reasoning=reasoning,
                    individual_threats=threats,
                )

                self.function_threats[function] = composite

    def _analyze_attack_paths(self):
        """
        Identify multi-stage attack paths through the call graph

        Traces paths from entrypoints through vulnerable functions
        """
        # Get entrypoints from call graph
        entrypoints = [func for func in self.call_graph.keys() if func.endswith(".main") or func == "main"]

        if not entrypoints:
            # Fallback: use reachable functions
            entrypoints = list(self.reachable_functions)[:5]

        path_counter = 0

        for entrypoint in entrypoints:
            # BFS to find paths with multiple vulnerabilities
            path = self._trace_vulnerable_path(entrypoint)

            if len(path) >= 2:  # At least 2 vulnerable nodes
                path_counter += 1

                # Calculate composite risk for path
                stage_risks = [stage["risk"] for stage in path]
                threat_count = sum(len(stage["threats"]) for stage in path)

                # Path risk = average of stages + bonus for length
                avg_risk = sum(stage_risks) / len(stage_risks)
                length_bonus = min(len(path) * 5, 20)  # Up to 20 bonus points
                composite_risk = min(avg_risk + length_bonus, 100)

                # Determine severity
                if composite_risk >= 80 or len(path) >= 3:
                    severity = "CRITICAL"
                elif composite_risk >= 60:
                    severity = "HIGH"
                else:
                    severity = "MEDIUM"

                is_exploitable = any("cve" in stage["threats"] for stage in path)

                recommendation = self._generate_path_recommendation(path, severity)

                attack_path = AttackPath(
                    path_id=f"path-{path_counter}",
                    severity=severity,
                    composite_risk=composite_risk,
                    stages=path,
                    threat_count=threat_count,
                    is_exploitable=is_exploitable,
                    recommendation=recommendation,
                )

                self.attack_paths.append(attack_path)

    def _trace_vulnerable_path(self, start_function: str, max_depth: int = 10) -> List[Dict]:
        """
        Trace path from start_function through vulnerable nodes

        Returns list of vulnerable stages in the path
        """
        path = []
        visited = set()
        queue = deque([(start_function, 0)])  # (function, depth)

        while queue and len(path) < 5:  # Limit to 5 stages
            current, depth = queue.popleft()

            if depth > max_depth or current in visited:
                continue

            visited.add(current)

            # Check if this node has threats
            node_threats = self._get_node_threats(current)

            if node_threats:
                # Calculate risk for this node
                risk = self._calculate_node_risk(node_threats)

                path.append(
                    {
                        "node": current,
                        "depth": depth,
                        "threats": node_threats,
                        "risk": risk,
                        "is_reachable": current in self.reachable_functions,
                    }
                )

            # Add callees to queue
            callees = self.call_graph.get(current, set())
            for callee in callees:
                if callee not in visited:
                    queue.append((callee, depth + 1))

        return path

    def _get_node_threats(self, function: str) -> List[str]:
        """Get list of threat types for a function"""
        threats = []

        # Check CVEs
        for cve_id, cve_info in self.cve_data.items():
            if function in cve_info.get("app_functions", []):
                threats.append("cve")
                break

        # Check secrets
        for secret in self.secrets:
            secret_func = secret.get("_matched_function") or secret.get("function")
            if secret_func == function:
                threats.append("secret")
                break
            # Also check by file path
            secret_file = (secret.get("file") or secret.get("path") or "").lower()
            if secret_file and function.lower().replace(".", "/") in secret_file:
                threats.append("secret")
                break

        # Check if function is in malicious package
        # (approximation - would need package mapping)

        return threats

    def _calculate_node_risk(self, threats: List[str]) -> float:
        """Calculate risk for a single node based on threats"""
        if "cve" in threats and "secret" in threats:
            return 90  # Both = very high risk
        elif "cve" in threats:
            return 70
        elif "secret" in threats:
            return 80
        else:
            return 50

    def _generate_path_recommendation(self, path: List[Dict], severity: str) -> str:
        """Generate actionable recommendation for attack path"""
        threat_types = set()
        for stage in path:
            threat_types.update(stage["threats"])

        if severity == "CRITICAL":
            action = "Immediate remediation required"
        elif severity == "HIGH":
            action = "Fix within 1 week"
        else:
            action = "Address in next sprint"

        details = []
        if "cve" in threat_types:
            details.append("patch vulnerable dependencies")
        if "secret" in threat_types:
            details.append("remove hardcoded secrets")
        if "malware" in threat_types:
            details.append("remove malicious packages")

        return f"{action}: {', '.join(details)}"

    def _generate_correlation_report(self) -> Dict[str, any]:
        """Generate final correlation report"""
        # Count escalations
        escalated_packages = sum(1 for t in self.package_threats.values() if t.escalation_factor > 1.0)

        escalated_functions = sum(1 for t in self.function_threats.values() if t.escalation_factor > 1.0)

        critical_paths = sum(1 for p in self.attack_paths if p.severity == "CRITICAL")

        return {
            "summary": {
                "total_composite_threats": len(self.package_threats) + len(self.function_threats),
                "escalated_packages": escalated_packages,
                "escalated_functions": escalated_functions,
                "attack_paths_found": len(self.attack_paths),
                "critical_attack_paths": critical_paths,
            },
            "packages": {
                pkg: {
                    "threat_types": t.threat_types,
                    "base_risk": t.base_risk,
                    "composite_risk": t.composite_risk,
                    "escalation_factor": t.escalation_factor,
                    "is_reachable": t.is_reachable,
                    "priority": t.priority,
                    "reasoning": t.reasoning,
                    "individual_threats": t.individual_threats,
                }
                for pkg, t in self.package_threats.items()
            },
            "functions": {
                func: {
                    "threat_types": t.threat_types,
                    "base_risk": t.base_risk,
                    "composite_risk": t.composite_risk,
                    "escalation_factor": t.escalation_factor,
                    "is_reachable": t.is_reachable,
                    "priority": t.priority,
                    "reasoning": t.reasoning,
                    "individual_threats": t.individual_threats,
                }
                for func, t in self.function_threats.items()
            },
            "attack_paths": [
                {
                    "path_id": p.path_id,
                    "severity": p.severity,
                    "composite_risk": p.composite_risk,
                    "threat_count": p.threat_count,
                    "is_exploitable": p.is_exploitable,
                    "stages": p.stages,
                    "recommendation": p.recommendation,
                }
                for p in self.attack_paths
            ],
        }
