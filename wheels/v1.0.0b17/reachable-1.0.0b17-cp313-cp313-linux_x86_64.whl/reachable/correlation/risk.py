#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.

"""
Risk Assessment Engine - Combines Reachability + Exploitability

Core Formula: Risk = Severity × Likelihood

Terminology:
- Severity: Raw scanner output (CVSS, CWE category) - immutable
- Risk: Effective level after reachability analysis - determines SLA
- Action: FIX, MONITOR, ACCEPT_RISK

Risk Levels & SLA:
- CRITICAL: 1-48 hours (reachable + actively exploited)
- HIGH: 7-14 days (reachable + high severity)
- MEDIUM: 30 days (reachable + medium severity)
- LOW: 90 days (unreachable any severity)
- INFO: No SLA (awareness only)
"""

from dataclasses import dataclass
from enum import Enum
from typing import Optional


class RiskLevel(Enum):
    """
    Risk levels after reachability analysis.

    Risk = Severity × Likelihood
    - Severity comes from scanner (CVSS, CWE)
    - Likelihood comes from reachability + exploits

    Risk determines SLA (compliance timeline).
    """

    CRITICAL = 1  # SLA: 1-48 hours
    HIGH = 2  # SLA: 7-14 days
    MEDIUM = 3  # SLA: 30 days
    LOW = 4  # SLA: 90 days
    INFO = 5  # No SLA


# Legacy alias for backward compatibility
VerdictLevel = RiskLevel


@dataclass
class CVERiskAssessment:
    """
    Risk assessment for a CVE.

    Fields:
    - severity: Raw CVSS severity (immutable)
    - risk_level: Effective risk after analysis (determines SLA)
    - action: Recommended action (FIX, MONITOR, ACCEPT_RISK)
    """

    cve_id: str

    # Inputs
    is_reachable: bool
    in_kev: bool
    epss_score: Optional[float]
    cvss_score: Optional[float]
    cvss_severity: Optional[str]  # Raw severity from CVSS

    # Exploit data
    exploit_db_available: bool = False
    metasploit_module: bool = False

    # Calculated outputs
    risk_level: RiskLevel = RiskLevel.INFO
    action: str = "MONITOR"  # FIX, MONITOR, or ACCEPT_RISK
    risk_name: str = ""  # Human-readable: " CRITICAL"
    sla: str = ""  # "1-48 hours", "7-14 days", etc.
    reasoning: str = ""
    risk_score: float = 0.0  # 0-100

    # Legacy aliases
    @property
    def verdict_level(self) -> RiskLevel:
        """Legacy alias"""
        return self.risk_level

    @property
    def verdict(self) -> str:
        """Legacy alias"""
        return self.action

    @property
    def verdict_name(self) -> str:
        """Legacy alias"""
        return self.risk_name

    @property
    def action_timeline(self) -> str:
        """Legacy alias"""
        return self.sla


# Legacy alias
CVEVerdict = CVERiskAssessment


class RiskEngine:
    """
    Risk assessment engine for CVEs.

    Combines reachability analysis with exploitability metrics
    to calculate effective risk levels.
    """

    # Risk score weights
    WEIGHT_REACHABILITY = 35
    WEIGHT_KEV = 25
    WEIGHT_EPSS = 15
    WEIGHT_CVSS = 10
    WEIGHT_EXPLOIT_DB = 10
    WEIGHT_METASPLOIT = 5

    def assess(
        self,
        cve_id: str,
        is_reachable: bool,
        in_kev: bool = False,
        epss_score: Optional[float] = None,
        cvss_score: Optional[float] = None,
        cvss_severity: Optional[str] = None,
        exploit_db_available: bool = False,
        metasploit_module: bool = False,
    ) -> CVERiskAssessment:
        """
        Assess risk for a CVE.

        Args:
            cve_id: CVE identifier
            is_reachable: True if code path is reachable from entrypoints
            in_kev: True if in CISA KEV catalog (actively exploited)
            epss_score: EPSS probability (0-1)
            cvss_score: CVSS score (0-10)
            cvss_severity: CVSS severity label
            exploit_db_available: True if public exploit exists
            metasploit_module: True if Metasploit module exists

        Returns:
            CVERiskAssessment with risk level, action, and SLA
        """
        # Calculate risk score (0-100)
        risk_score = self._calculate_risk_score(
            is_reachable, in_kev, epss_score, cvss_score, exploit_db_available, metasploit_module
        )

        # Determine risk level
        risk_level, reasoning, action = self._determine_risk_level(
            is_reachable, in_kev, epss_score, cvss_score, risk_score, exploit_db_available, metasploit_module
        )

        # Get SLA
        risk_name, sla = self._get_sla(risk_level)

        return CVERiskAssessment(
            cve_id=cve_id,
            is_reachable=is_reachable,
            in_kev=in_kev,
            epss_score=epss_score,
            cvss_score=cvss_score,
            cvss_severity=cvss_severity,
            exploit_db_available=exploit_db_available,
            metasploit_module=metasploit_module,
            risk_level=risk_level,
            action=action,
            risk_name=risk_name,
            sla=sla,
            reasoning=reasoning,
            risk_score=risk_score,
        )

    # Legacy method name
    def calculate_verdict(self, *args, **kwargs) -> CVERiskAssessment:
        """Legacy alias for assess()"""
        return self.assess(*args, **kwargs)

    def _calculate_risk_score(
        self,
        is_reachable: bool,
        in_kev: bool,
        epss_score: Optional[float],
        cvss_score: Optional[float],
        exploit_db_available: bool,
        metasploit_module: bool,
    ) -> float:
        """Calculate combined risk score (0-100)"""
        score = 0.0

        if is_reachable:
            score += self.WEIGHT_REACHABILITY

        if in_kev:
            score += self.WEIGHT_KEV

        if epss_score is not None:
            score += epss_score * self.WEIGHT_EPSS

        if cvss_score is not None:
            score += (cvss_score / 10.0) * self.WEIGHT_CVSS

        if exploit_db_available:
            score += self.WEIGHT_EXPLOIT_DB

        if metasploit_module:
            score += self.WEIGHT_METASPLOIT

        return round(score, 1)

    def _determine_risk_level(
        self,
        is_reachable: bool,
        in_kev: bool,
        epss_score: Optional[float],
        cvss_score: Optional[float],
        risk_score: float,
        exploit_db_available: bool,
        metasploit_module: bool,
    ) -> tuple[RiskLevel, str, str]:
        """
        Determine risk level.

        Returns:
            (RiskLevel, reasoning, action)
        """
        # CRITICAL: Reachable + actively exploited
        if is_reachable and in_kev:
            return (RiskLevel.CRITICAL, "Reachable + actively exploited (CISA KEV)", "FIX")

        # CRITICAL: Reachable + weaponized exploit
        if is_reachable and metasploit_module:
            return (RiskLevel.CRITICAL, "Reachable + weaponized exploit (Metasploit)", "FIX")

        # CRITICAL: Reachable + public exploit + high EPSS
        if is_reachable and exploit_db_available and epss_score and epss_score > 0.5:
            return (RiskLevel.CRITICAL, f"Reachable + public exploit + EPSS {epss_score:.0%}", "FIX")

        # HIGH: Reachable + critical severity
        if is_reachable and cvss_score and cvss_score >= 9.0:
            return (RiskLevel.HIGH, f"Reachable + critical severity (CVSS {cvss_score})", "FIX")

        # HIGH: Reachable + public exploit
        if is_reachable and exploit_db_available:
            return (RiskLevel.HIGH, "Reachable + public exploit available", "FIX")

        # HIGH: Reachable + elevated EPSS + high severity
        if is_reachable and epss_score and epss_score > 0.3 and cvss_score and cvss_score >= 7.0:
            return (RiskLevel.HIGH, f"Reachable + EPSS {epss_score:.0%} + CVSS {cvss_score}", "FIX")

        # MEDIUM: Reachable + high severity
        if is_reachable and cvss_score and cvss_score >= 7.0:
            return (RiskLevel.MEDIUM, f"Reachable + high severity (CVSS {cvss_score})", "FIX")

        # MEDIUM: Reachable + medium severity
        if is_reachable and cvss_score and cvss_score >= 4.0:
            return (RiskLevel.MEDIUM, f"Reachable + medium severity (CVSS {cvss_score})", "FIX")

        # LOW: Unreachable but in KEV (verify manually)
        if not is_reachable and in_kev:
            return (RiskLevel.LOW, "Unreachable but in KEV - verify manually", "MONITOR")

        # LOW: Reachable but low severity
        if is_reachable:
            return (RiskLevel.LOW, f"Reachable but low severity (score: {risk_score})", "MONITOR")

        # LOW: Unreachable high/critical severity
        if not is_reachable and cvss_score and cvss_score >= 7.0:
            return (RiskLevel.LOW, f"Severity {cvss_score} but unreachable → Risk: LOW", "MONITOR")

        # INFO: Unreachable medium/low severity
        if not is_reachable:
            return (RiskLevel.INFO, "Unreachable - awareness only", "ACCEPT_RISK")

        # Default
        return (RiskLevel.LOW, "Insufficient data for assessment", "MONITOR")

    def _get_sla(self, level: RiskLevel) -> tuple[str, str]:
        """Get risk name and SLA for a risk level."""
        sla_table = {
            RiskLevel.CRITICAL: (" CRITICAL", "1-48 hours"),
            RiskLevel.HIGH: (" HIGH", "7-14 days"),
            RiskLevel.MEDIUM: (" MEDIUM", "30 days"),
            RiskLevel.LOW: (" LOW", "90 days"),
            RiskLevel.INFO: (" INFO", "No SLA"),
        }
        return sla_table.get(level, ("UNKNOWN", "Unknown"))

    def format_summary(self, assessment: CVERiskAssessment) -> str:
        """Format assessment as human-readable summary."""
        lines = [
            "=" * 70,
            f"CVE: {assessment.cve_id}",
            "=" * 70,
            "",
            f"Risk Level:  {assessment.risk_name}",
            f"Action:      {assessment.action}",
            f"SLA:         {assessment.sla}",
            "",
            "Factors:",
            f"  Reachable:     {' Yes' if assessment.is_reachable else ' No'}",
            f"  CISA KEV:      {' Yes' if assessment.in_kev else 'No'}",
            f"  CVSS:          {assessment.cvss_score or 'N/A'} ({assessment.cvss_severity or 'N/A'})",
            f"  EPSS:          {f'{assessment.epss_score:.1%}' if assessment.epss_score else 'N/A'}",
            f"  Public Exploit: {'Yes' if assessment.exploit_db_available else 'No'}",
            f"  Metasploit:    {'Yes' if assessment.metasploit_module else 'No'}",
            "",
            f"Reasoning: {assessment.reasoning}",
            f"Risk Score: {assessment.risk_score}/100",
            "=" * 70,
        ]
        return "\n".join(lines)


# Legacy alias
VerdictEngine = RiskEngine


def get_risk_counts_template() -> dict:
    """Get template for risk counts."""
    return {"critical": 0, "high": 0, "medium": 0, "low": 0, "info": 0}
