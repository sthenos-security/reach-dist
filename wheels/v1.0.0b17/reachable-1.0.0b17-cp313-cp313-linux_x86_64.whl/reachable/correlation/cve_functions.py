#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.

"""
CVE-to-Git Analyzer - Extract vulnerable functions from git history

Given a CVE and library source code, this module:
1. Finds the fix commit (by comparing vulnerable vs fixed versions)
2. Extracts which functions were modified in the fix
3. Maps CVE → specific vulnerable functions
4. Stores commit SHA, date, and affected functions in JSON

This enables FUNCTION-LEVEL reachability analysis with confidence scores.
"""

import json
import logging
import re
import subprocess
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional

# Initialize module-level logger
logger = logging.getLogger(__name__)


class GitCVEAnalyzer:
    """Analyze git history to find vulnerable functions for CVEs"""

    def __init__(self, lib_repo_path: Path):
        self.repo_path = lib_repo_path

    def analyze_cve(
        self, cve_id: str, package: str, vulnerable_version: str, fixed_version: Optional[str] = None
    ) -> Dict:
        """
        Analyze a CVE by comparing git versions

        Returns complete analysis with commit info and vulnerable functions:
        {
            "cve_id": "CVE-2021-33503",
            "package": "urllib3",
            "vulnerable_version": "1.26.5",
            "fixed_version": "1.26.6",
            "fix_commit": {
                "sha": "abc123def456...",
                "sha_short": "abc123d",
                "date": "2021-06-01T10:30:00Z",
                "author": "John Doe",
                "message": "Fix catastrophic backtracking in URL parsing"
            },
            "vulnerable_functions": [
                {
                    "file": "urllib3/util/url.py",
                    "function": "parse_url",
                    "full_path": "urllib3.util.url.parse_url",
                    "change_type": "modified",
                    "lines_changed": 15,
                    "class": null
                }
            ],
            "analysis_metadata": {
                "method": "git_diff",
                "confidence": "high",
                "analyzed_at": "2024-12-19T18:00:00Z",
                "repo_path": "./libs/urllib3"
            }
        }
        """

        result = {
            "cve_id": cve_id,
            "package": package,
            "vulnerable_version": vulnerable_version,
            "fixed_version": fixed_version,
            "fix_commit": None,
            "vulnerable_functions": [],  # Changed from affected_functions for clarity
            "analysis_metadata": {
                "method": "unknown",
                "confidence": "none",
                "analyzed_at": datetime.utcnow().isoformat() + "Z",
                "repo_path": str(self.repo_path),
            },
        }

        # Validate repo exists
        if not self.repo_path.exists():
            result["analysis_metadata"]["error"] = f"Repository not found: {self.repo_path}"
            return result

        # Check if it's a git repo
        if not (self.repo_path / ".git").exists():
            result["analysis_metadata"]["error"] = "Not a git repository"
            return result

        # Find fix commit by comparing versions
        fix_commit = self._find_fix_commit(vulnerable_version, fixed_version)

        if fix_commit:
            result["fix_commit"] = fix_commit
            result["fixed_version"] = fix_commit.get("target_version", fixed_version)
            result["analysis_metadata"]["method"] = "git_diff"

            # Extract vulnerable functions from the fix diff
            vulnerable_funcs = self._extract_vulnerable_functions(fix_commit["sha"], fix_commit.get("parent_sha"))

            result["vulnerable_functions"] = vulnerable_funcs

            # NEW: Try to find when vulnerability was introduced
            introduction_commit = self._find_introduction_commit(fix_commit["sha"], fix_commit.get("parent_sha"))

            if introduction_commit:
                result["introduction_commit"] = introduction_commit

                # Calculate vulnerability lifespan
                if introduction_commit.get("date") and fix_commit.get("date"):
                    lifespan = self._calculate_lifespan(introduction_commit["date"], fix_commit["date"])
                    result["vulnerability_lifespan"] = lifespan

            # Set confidence based on what we found
            if vulnerable_funcs:
                result["analysis_metadata"]["confidence"] = "high"
                result["analysis_metadata"]["functions_found"] = len(vulnerable_funcs)
            else:
                result["analysis_metadata"]["confidence"] = "medium"
                result["analysis_metadata"]["note"] = "Fix commit found but no Python functions identified"
        else:
            result["analysis_metadata"]["confidence"] = "low"
            result["analysis_metadata"]["error"] = "Could not find fix commit between versions"

        return result

    def _find_fix_commit(self, vulnerable_version: str, fixed_version: Optional[str]) -> Optional[Dict]:
        """
        Find the commit that fixed the vulnerability

        Logic:
        1. If fixed_version provided, compare vulnerable_version..fixed_version
        2. If not provided, try incrementing patch version (1.26.5 → 1.26.6)
        3. Look for commits with security keywords (security, CVE, fix, vulnerability)
        4. Return commit with SHA, date, author, message
        """

        # Try to infer fixed version if not provided
        if not fixed_version:
            parts = vulnerable_version.split(".")
            if len(parts) >= 3:
                try:
                    parts[-1] = str(int(parts[-1]) + 1)
                    fixed_version = ".".join(parts)
                except ValueError:
                    # Can't increment, maybe it's something like "1.26.5rc1"
                    fixed_version = None

        if not fixed_version:
            return None

        try:
            # Get commits between vulnerable and fixed version
            # Format: vulnerable_version..fixed_version means "commits in fixed but not in vulnerable"
            cmd = [
                "git",
                "-C",
                str(self.repo_path),
                "log",
                f"{vulnerable_version}..{fixed_version}",
                "--format=%H|%aI|%an|%ae|%s",  # SHA|date|author name|author email|subject
                "--max-count=50",  # Look at up to 50 commits
            ]

            result = subprocess.run(cmd, capture_output=True, text=True, timeout=15)

            if result.returncode != 0:
                # Tags might not exist, try alternate approach
                return self._find_fix_commit_by_grep(vulnerable_version, fixed_version)

            # Parse commits
            commits = []
            for line in result.stdout.strip().split("\n"):
                if not line:
                    continue
                parts = line.split("|", 4)
                if len(parts) == 5:
                    sha, date, author_name, author_email, message = parts
                    commits.append(
                        {
                            "sha": sha,
                            "sha_short": sha[:7],
                            "date": date,
                            "author": author_name,
                            "author_email": author_email,
                            "message": message,
                            "target_version": fixed_version,
                        }
                    )

            if not commits:
                return None

            # Prioritize commits with security-related keywords

            # First pass: look for explicit security mentions
            for commit in commits:
                msg_lower = commit["message"].lower()
                if any(kw in msg_lower for kw in ["cve", "security", "vulnerability"]):
                    commit["parent_sha"] = self._get_parent_commit(commit["sha"])
                    commit["match_reason"] = "security_keyword"
                    return commit

            # Second pass: look for fix-related keywords
            for commit in commits:
                msg_lower = commit["message"].lower()
                if any(kw in msg_lower for kw in ["fix", "patch", "backtrack"]):
                    commit["parent_sha"] = self._get_parent_commit(commit["sha"])
                    commit["match_reason"] = "fix_keyword"
                    return commit

            # Fallback: return first commit (closest to fixed version)
            commit = commits[0]
            commit["parent_sha"] = self._get_parent_commit(commit["sha"])
            commit["match_reason"] = "first_commit_in_range"
            return commit

        except subprocess.TimeoutExpired:
            return None
        except Exception:
            return None

    def _find_fix_commit_by_grep(self, vulnerable_version: str, fixed_version: str) -> Optional[Dict]:
        """Fallback: search commit messages for CVE or security"""
        try:
            cmd = [
                "git",
                "-C",
                str(self.repo_path),
                "log",
                "--all",
                "--grep=security",
                "--grep=CVE",
                "--grep=vulnerability",
                "-i",  # case insensitive
                "--format=%H|%aI|%an|%ae|%s",
                "--max-count=10",
            ]

            result = subprocess.run(cmd, capture_output=True, text=True, timeout=10)

            if result.returncode == 0 and result.stdout.strip():
                line = result.stdout.strip().split("\n")[0]
                parts = line.split("|", 4)
                if len(parts) == 5:
                    sha, date, author_name, author_email, message = parts
                    commit = {
                        "sha": sha,
                        "sha_short": sha[:7],
                        "date": date,
                        "author": author_name,
                        "author_email": author_email,
                        "message": message,
                        "target_version": fixed_version,
                        "match_reason": "grep_search",
                    }
                    commit["parent_sha"] = self._get_parent_commit(sha)
                    return commit
        except Exception:
            pass

        return None

    def _get_parent_commit(self, commit_sha: str) -> Optional[str]:
        """Get parent commit SHA for diff comparison"""
        try:
            cmd = ["git", "-C", str(self.repo_path), "rev-parse", f"{commit_sha}^"]
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=5)
            if result.returncode == 0:
                return result.stdout.strip()
        except Exception:
            pass
        return None

    def _find_introduction_commit(self, fix_commit_sha: str, parent_sha: Optional[str]) -> Optional[Dict]:
        """
        Find when the vulnerability was introduced

        Strategy: Use git blame on the parent of fix commit to find
        when the vulnerable code was added

        Returns commit info similar to fix_commit
        """
        if not parent_sha:
            return None

        try:
            # Get files changed in fix commit
            cmd = ["git", "-C", str(self.repo_path), "diff", "--name-only", parent_sha, fix_commit_sha]
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=5)

            if result.returncode != 0 or not result.stdout.strip():
                return None

            changed_files = result.stdout.strip().split("\n")

            # For each changed file, find when lines were introduced
            introduction_commits = []

            for file_path in changed_files[:3]:  # Limit to first 3 files for performance
                if not file_path.endswith(".py"):
                    continue

                # Git blame on parent commit to see when code was added
                cmd = [
                    "git",
                    "-C",
                    str(self.repo_path),
                    "blame",
                    "--line-porcelain",
                    parent_sha,
                    "--",
                    file_path,
                ]

                try:
                    result = subprocess.run(cmd, capture_output=True, text=True, timeout=10)

                    if result.returncode != 0:
                        continue

                    # Parse blame output to find commits
                    for line in result.stdout.split("\n"):
                        if line.startswith("author-time "):
                            # Extract timestamp
                            try:
                                timestamp = int(line.split()[1])
                                from datetime import datetime

                                date = datetime.utcfromtimestamp(timestamp).isoformat() + "Z"
                                introduction_commits.append({"date": date, "file": file_path})
                            except Exception:
                                continue

                except Exception:
                    continue

            if not introduction_commits:
                return None

            # Find earliest commit
            earliest = min(introduction_commits, key=lambda c: c["date"])

            # Get commit details for earliest date
            cmd = [
                "git",
                "-C",
                str(self.repo_path),
                "log",
                "--until=" + earliest["date"],
                "--format=%H|%aI|%an|%s",
                "--max-count=1",
                "--",
                earliest["file"],
            ]

            result = subprocess.run(cmd, capture_output=True, text=True, timeout=5)

            if result.returncode == 0 and result.stdout.strip():
                parts = result.stdout.strip().split("|", 3)
                if len(parts) >= 4:
                    sha, date, author, message = parts
                    return {
                        "sha": sha,
                        "sha_short": sha[:7],
                        "date": date,
                        "author": author,
                        "message": message,
                        "method": "git_blame",
                    }

        except Exception:
            pass

        return None

    def _calculate_lifespan(self, intro_date: str, fix_date: str) -> Dict:
        """Calculate how long the vulnerability existed"""
        from datetime import datetime

        try:
            # Parse ISO dates
            intro = datetime.fromisoformat(intro_date.replace("Z", "+00:00"))
            fix = datetime.fromisoformat(fix_date.replace("Z", "+00:00"))

            delta = fix - intro

            return {
                "introduced_date": intro_date[:10],
                "fixed_date": fix_date[:10],
                "days_vulnerable": delta.days,
                "years_vulnerable": round(delta.days / 365.25, 1),
                "severity": "long-lived" if delta.days > 365 else "recent",
            }
        except Exception:
            return {
                "introduced_date": intro_date[:10] if intro_date else None,
                "fixed_date": fix_date[:10] if fix_date else None,
                "days_vulnerable": None,
                "years_vulnerable": None,
                "severity": "unknown",
            }

    def _extract_vulnerable_functions(self, commit_sha: str, parent_sha: Optional[str]) -> List[Dict]:
        """
        Extract which functions were modified/fixed in the commit

        Logic:
        1. Get git diff between parent and fix commit
        2. Parse diff to find function definitions that changed
        3. Track: file, function name, change type (added/modified/removed)
        4. Build full path for function (module.Class.function)

        Returns list of vulnerable function info with debugging details
        """

        if not parent_sha:
            return []

        try:
            # Get unified diff with context
            cmd = [
                "git",
                "-C",
                str(self.repo_path),
                "diff",
                parent_sha,
                commit_sha,
                "--unified=5",  # 5 lines of context
                "--",
                "*.py",  # Only Python files
            ]

            result = subprocess.run(cmd, capture_output=True, text=True, timeout=15)

            if result.returncode != 0:
                return []

            return self._parse_diff_for_functions(result.stdout)

        except Exception:
            return []

    def _parse_diff_for_functions(self, diff_text: str) -> List[Dict]:
        """
        Parse git diff to extract VULNERABLE functions (before the fix)

        Logic:
        - Functions that were REMOVED (−) = vulnerable code that was replaced
        - Functions that were MODIFIED = vulnerable code that was changed
        - Functions that were ADDED (+) = NEW code (the fix), NOT vulnerable

        We want to track which functions WERE vulnerable, so we focus on
        removed/modified functions, not newly added ones.
        """

        vulnerable_funcs = []
        current_file = None
        current_class = None

        # Patterns
        file_pattern = re.compile(r"^diff --git a/(.*\.py) b/")
        class_pattern = re.compile(r"^\s*class\s+([a-zA-Z_][a-zA-Z0-9_]*)")
        func_pattern = re.compile(r"^\s*def\s+([a-zA-Z_][a-zA-Z0-9_]*)\s*\(")

        lines = diff_text.split("\n")

        # Track seen function signatures to detect modifications
        # Key: full_path, Value: {'added': bool, 'removed': bool}
        function_changes = {}

        for i, line in enumerate(lines):
            # Track current file
            file_match = file_pattern.match(line)
            if file_match:
                current_file = file_match.group(1)
                current_class = None  # Reset class context on new file
                continue

            # Track current class context
            if current_file:
                class_match = class_pattern.match(line)
                if class_match:
                    current_class = class_match.group(1)
                    continue

            # Look for function definitions in changed lines
            if current_file and (line.startswith("+") or line.startswith("-")):
                func_match = func_pattern.match(line[1:])  # Skip the +/- prefix

                if func_match:
                    func_name = func_match.group(1)

                    # Build full module path
                    module_path = current_file.replace("/", ".").replace(".py", "")

                    if current_class:
                        full_path = f"{module_path}.{current_class}.{func_name}"
                    else:
                        full_path = f"{module_path}.{func_name}"

                    # Track whether this function was added or removed
                    if full_path not in function_changes:
                        function_changes[full_path] = {"added": False, "removed": False}

                    if line.startswith("+"):
                        function_changes[full_path]["added"] = True
                    elif line.startswith("-"):
                        function_changes[full_path]["removed"] = True

        # Now determine which functions are vulnerable
        # Vulnerable = removed OR (both added and removed = modified)
        # NOT vulnerable = only added (new code)
        for full_path, changes in function_changes.items():
            # Skip functions that were only added (not vulnerable, they're the fix)
            if changes["added"] and not changes["removed"]:
                continue

            # Include functions that were removed or modified
            if changes["removed"]:
                # Parse the full_path to extract components
                parts = full_path.rsplit(".", 1)
                module_path = parts[0]
                func_display = parts[1] if len(parts) > 1 else full_path

                # Reconstruct file path
                file_path = module_path.replace(".", "/") + ".py"

                # Determine change type
                if changes["added"] and changes["removed"]:
                    change_type = "modified"
                else:
                    change_type = "removed"

                # Extract class if present
                class_name = None
                if "." in func_display:
                    class_name = func_display.split(".")[0]

                # Count lines (approximate)
                lines_changed = self._count_changed_lines_for_function(lines, full_path)

                vulnerable_funcs.append(
                    {
                        "file": file_path,
                        "function": func_display,
                        "full_path": full_path,
                        "module": module_path,
                        "change_type": change_type,
                        "lines_changed": lines_changed,
                        "class": class_name,
                    }
                )

        return vulnerable_funcs

    def _count_changed_lines_for_function(self, lines: List[str], full_path: str) -> int:
        """Count changed lines for a specific function"""
        # Simple heuristic: count +/- lines near function definition
        func_name = full_path.split(".")[-1]
        count = 0
        in_function = False

        for line in lines:
            if f"def {func_name}(" in line:
                in_function = True
            elif in_function and re.match(r"^\s*def\s+", line):
                # Hit next function, stop counting
                break
            elif in_function and line.startswith(("+", "-")):
                count += 1

        return max(count, 1)  # At least 1 line changed


def analyze_all_cves(vulns_data: Dict, lib_repos: Dict[str, Path]) -> Dict:
    """
    Analyze all CVEs to find vulnerable functions

    Args:
        vulns_data: Grype vulnerability data
        lib_repos: Dict mapping package names to repo paths

    Returns:
        Dict mapping CVE IDs to git analysis results
    """

    results = {}

    for match in vulns_data.get("matches", []):
        cve_id = match["vulnerability"]["id"]
        package = match["artifact"]["name"]
        version = match["artifact"]["version"]

        # Get fix version from CVE data if available
        fixed_version = None
        if "fix" in match.get("vulnerability", {}):
            fix_info = match["vulnerability"]["fix"]
            if "versions" in fix_info and fix_info["versions"]:
                fixed_version = fix_info["versions"][0]

        # Check if we have the repo for this package
        if package not in lib_repos:
            results[cve_id] = {
                "cve_id": cve_id,
                "package": package,
                "vulnerable_version": version,
                "analysis_metadata": {"error": "Repository not available", "confidence": "none"},
            }
            continue

        # Analyze this CVE
        analyzer = GitCVEAnalyzer(lib_repos[package])
        analysis = analyzer.analyze_cve(cve_id, package, version, fixed_version)
        results[cve_id] = analysis

    return results


if __name__ == "__main__":
    # Example usage
    import sys

    if len(sys.argv) < 4:
        logger.info("Usage: cve_git_analyzer.py <repo_path> <cve_id> <vulnerable_version> [fixed_version]")
        logger.info("")
        logger.info("Example:")
        logger.info("  python3 cve_git_analyzer.py ./libs/urllib3 CVE-2021-33503 1.26.5 1.26.6")
        sys.exit(1)

    repo_path = Path(sys.argv[1])
    cve_id = sys.argv[2]
    vuln_version = sys.argv[3]
    fixed_version = sys.argv[4] if len(sys.argv) > 4 else None

    analyzer = GitCVEAnalyzer(repo_path)
    result = analyzer.analyze_cve(cve_id, repo_path.name, vuln_version, fixed_version)

    logger.info(json.dumps(result, indent=2))
