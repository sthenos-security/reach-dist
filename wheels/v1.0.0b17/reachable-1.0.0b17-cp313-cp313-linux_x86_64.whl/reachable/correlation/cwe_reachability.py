#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.

"""
CWE Reachability Analyzer

Determines if CWE findings are actually exploitable by checking
if the vulnerable code is reachable from application entry points.

KEY INSIGHT (from your document):
    "A CWE detected by a SAST tool does not automatically represent a real
    security vulnerability. Detection indicates the presence of a risky
    code pattern, but exploitability depends on whether the code is
    reachable from an exposed application entry point."

CLASSIFICATION MATRIX:
┌────────────────────────────────────────┬──────────────────┬────────────────┐
│ CWE Location                           │ Reachable?       │ Status         │
├────────────────────────────────────────┼──────────────────┼────────────────┤
│ App code, entry-point path             │ YES              │ VULNERABILITY  │
│ App code, dead/unreachable code        │ NO               │ LATENT         │
│ Library code, called by app            │ YES (via call)   │ VULNERABILITY  │
│ Library code, not called by app        │ NO               │ HYPOTHETICAL   │
│ Config/Deploy (Dockerfile, K8s, CI/CD) │ N/A (runtime)    │ CONFIG_ISSUE   │
│ Test code                              │ NO (not prod)    │ TEST_ONLY      │
└────────────────────────────────────────┴──────────────────┴────────────────┘

FINDING CATEGORIES:
- CODE_CWE: Vulnerability in application/library code (check reachability)
- CONFIG_CWE: Infrastructure/deployment issue (always relevant, no call graph)
- SECRET: Hardcoded credential (use secret reachability logic)
"""

import os
import re
from dataclasses import dataclass
from enum import Enum
from typing import Dict, List, Optional, Set, Tuple


class FindingCategory(Enum):
    """Category of security finding"""

    CODE_CWE = "code_cwe"  # Vulnerability in code (needs reachability check)
    CONFIG_CWE = "config_cwe"  # Config/deploy issue (Dockerfile, K8s, CI/CD)
    SECRET = "secret"  # Hardcoded secret
    MALWARE = "malware"  # Malicious code pattern


class ReachabilityStatus(Enum):
    """Reachability status for a CWE finding"""

    REACHABLE = "reachable"  # In execution path from entry point
    UNREACHABLE = "unreachable"  # Not in any execution path
    CONFIG_ISSUE = "config_issue"  # Not code - config/deploy issue
    TEST_ONLY = "test_only"  # Only in test code
    UNKNOWN = "unknown"  # Cannot determine


@dataclass
class CWEReachabilityResult:
    """Result of CWE reachability analysis"""

    finding_id: str
    cwe_id: str
    file_path: str
    line: int
    function_name: Optional[str]
    category: FindingCategory
    reachability: ReachabilityStatus
    reachable_via: List[str]  # Call path from entry point
    risk_multiplier: float  # 1.0 for reachable, 0.1 for unreachable
    compliance_mapping: Dict[str, List[str]]  # Standard -> requirements


# Patterns to identify config/deploy files (not code)
CONFIG_FILE_PATTERNS = [
    r"\.ya?ml$",  # YAML files (K8s, CI/CD, etc.)
    r"Dockerfile",  # Docker files
    r"docker-compose",  # Docker Compose
    r"\.tf$",  # Terraform
    r"\.hcl$",  # HashiCorp config
    r"Jenkinsfile",  # Jenkins
    r"\.github/workflows",  # GitHub Actions
    r"\.gitlab-ci",  # GitLab CI
    r"\.circleci",  # CircleCI
    r"azure-pipelines",  # Azure DevOps
    r"\.travis",  # Travis CI
    r"cloudbuild",  # Google Cloud Build
    r"buildspec",  # AWS CodeBuild
    r"kustomization",  # Kustomize
    r"helmfile",  # Helm
    r"Chart\.yaml",  # Helm Chart
    r"values\.yaml",  # Helm values
]

# Patterns to identify test files
TEST_FILE_PATTERNS = [
    r"_test\.py$",
    r"test_.*\.py$",
    r".*_test\.go$",
    r".*\.test\.js$",
    r".*\.spec\.js$",
    r".*\.test\.ts$",
    r".*\.spec\.ts$",
    r"/tests?/",
    r"/__tests__/",
    r"/spec/",
]

# CWEs that are specific to config/deploy (not code)
CONFIG_SPECIFIC_CWES = {
    "CWE-250": "Execution with Unnecessary Privileges",  # Container privileges
    "CWE-732": "Incorrect Permission Assignment",  # File permissions
    "CWE-269": "Improper Privilege Management",  # IAM issues
    "CWE-284": "Improper Access Control",  # Access control config
    "CWE-693": "Protection Mechanism Failure",  # Security headers
    "CWE-16": "Configuration",  # General config
    "CWE-1188": "Insecure Default Initialization",  # Default configs
}

# ============================================================================
# FALSE POSITIVE DETECTION (v2.9.61)
# ============================================================================
# These patterns identify common false positives in SAST findings.
# A finding is marked as a likely false positive if it matches these patterns.

# XSS False Positives - server-controlled data written to response
XSS_FALSE_POSITIVE_PATTERNS = [
    # Go patterns - writing non-user data
    (r"\.Write\(.*jwks", "Writing JWKS (server-controlled cryptographic keys)"),
    (r"\.Write\(.*payload", "Writing server payload to health endpoint"),
    (r"handleHealth.*Write", "Health check endpoint writing static response"),
    (r"handleJWKS.*Write", "JWKS endpoint writing server keys"),
    (r"PublicJWKS\(\)", "Server-controlled public key material"),
    # Common patterns
    (r"prometheus.*Write", "Prometheus metrics (server-generated)"),
    (r"metrics.*Write", "Metrics endpoint (server-generated)"),
    (r"healthz.*ok", "Health check static response"),
]

# Open Redirect False Positives - URLs are validated
OPEN_REDIRECT_FALSE_POSITIVE_PATTERNS = [
    # URL validation functions in code
    (r"IsReturnURLAllowed", "URL validation function detected"),
    (r"isAllowedURL", "URL validation function detected"),
    (r"validateRedirectURL", "URL validation function detected"),
    (r"allowedReturnURLs", "Allowlist configuration detected"),
    (r"allowedReturnRules", "Allowlist rules detected"),
    (r"allowedDomains", "Domain allowlist detected"),
    # Server-controlled redirects
    (r"hydra\.AuthorizeURL", "Redirect to internal OAuth server"),
    (r"hydra\.AcceptLoginRequest", "Redirect from internal OAuth flow"),
    (r"hydra\.AcceptConsentRequest", "Redirect from internal OAuth flow"),
    (r"kratos\.BuildLoginURL", "Redirect to internal identity server"),
]

# Cookie Security False Positives - security is configured
COOKIE_FALSE_POSITIVE_PATTERNS = [
    # Config-based security flags
    (r"Secure:\s*s\.cfg\.CookieSecure", "Cookie security from config (likely true)"),
    (r"Secure:\s*config\.CookieSecure", "Cookie security from config"),
    (r"Secure:\s*cfg\.Secure", "Cookie security from config"),
    (r"CookieSecure.*true", "Cookie security defaulting to true"),
    (r"getBool.*COOKIE_SECURE.*true", "Cookie secure defaults to true in config"),
    # HttpOnly is set
    (r"HttpOnly:\s*true", "HttpOnly flag is set"),
]

# SQL Injection False Positives - parameterized queries
SQL_FALSE_POSITIVE_PATTERNS = [
    (r"\.QueryRow\(.*\$\d", "PostgreSQL parameterized query"),
    (r"\.Query\(.*\$\d", "PostgreSQL parameterized query"),
    (r"\.Exec\(.*\$\d", "PostgreSQL parameterized query"),
    (r"db\.Prepare\(", "Prepared statement detected"),
    (r"sqlx\.Named", "Named parameters detected"),
    (r"gorm\.Where\(.*\?", "GORM parameterized query"),
]


def is_likely_false_positive(finding: Dict, source_context: str = None) -> Tuple[bool, Optional[str]]:
    """
    Determine if a CWE finding is likely a false positive.

    v2.9.61: Enhanced false positive detection based on code patterns.

    Args:
        finding: The CWE finding dict
        source_context: Optional source code context around the finding

    Returns:
        Tuple of (is_false_positive, reason)
    """
    cwe_id = finding.get("cwe_id", "")
    rule_id = finding.get("rule_id", "").lower()
    message = finding.get("message", "").lower()
    snippet = finding.get("snippet", finding.get("code_snippet", "")).lower()
    finding.get("file", finding.get("path", "")).lower()

    # Combine all text for pattern matching
    search_text = f"{rule_id} {message} {snippet} {source_context or ''}"

    # XSS False Positives
    if cwe_id == "CWE-079" or "xss" in rule_id or "responsewriter" in rule_id:
        for pattern, reason in XSS_FALSE_POSITIVE_PATTERNS:
            if re.search(pattern, search_text, re.IGNORECASE):
                return True, f"XSS False Positive: {reason}"

    # Open Redirect False Positives
    if cwe_id == "CWE-601" or "redirect" in rule_id:
        for pattern, reason in OPEN_REDIRECT_FALSE_POSITIVE_PATTERNS:
            if re.search(pattern, search_text, re.IGNORECASE):
                return True, f"Open Redirect False Positive: {reason}"

    # Cookie Security False Positives
    if cwe_id == "CWE-614" or "cookie" in rule_id:
        for pattern, reason in COOKIE_FALSE_POSITIVE_PATTERNS:
            if re.search(pattern, search_text, re.IGNORECASE):
                return True, f"Cookie Security False Positive: {reason}"

    # SQL Injection False Positives
    if cwe_id == "CWE-089" or "sql" in rule_id:
        for pattern, reason in SQL_FALSE_POSITIVE_PATTERNS:
            if re.search(pattern, search_text, re.IGNORECASE):
                return True, f"SQL Injection False Positive: {reason}"

    return False, None


# Rule IDs that indicate config/deploy issues
CONFIG_RULE_PATTERNS = [
    r"dockerfile\.",
    r"docker-compose\.",
    r"kubernetes\.",
    r"k8s\.",
    r"terraform\.",
    r"cloudformation\.",
    r"helm\.",
    r"yaml\.",
    r"cicd\.",
    r"github-actions\.",
    r"gitlab-ci\.",
    r"jenkins\.",
    r"security-headers",
    r"cors\.",
    r"ssl\.",
    r"tls\.",
]


def categorize_finding(finding: Dict) -> FindingCategory:
    """
    Determine the category of a security finding.

    Returns:
        FindingCategory: code_cwe, config_cwe, secret, or malware
    """
    # Check if explicitly marked as secret
    if finding.get("is_actual_secret", False):
        return FindingCategory.SECRET

    if finding.get("finding_type") == "SECRET":
        return FindingCategory.SECRET

    # Get file path and rule ID
    file_path = finding.get("file", finding.get("path", "")).lower()
    rule_id = finding.get("rule_id", finding.get("check_id", "")).lower()

    # Check for config file patterns
    for pattern in CONFIG_FILE_PATTERNS:
        if re.search(pattern, file_path, re.IGNORECASE):
            return FindingCategory.CONFIG_CWE

    # Check for config-specific rule patterns
    for pattern in CONFIG_RULE_PATTERNS:
        if re.search(pattern, rule_id, re.IGNORECASE):
            return FindingCategory.CONFIG_CWE

    # Check CWE ID
    cwe_id = finding.get("cwe_id", "")
    if cwe_id in CONFIG_SPECIFIC_CWES:
        return FindingCategory.CONFIG_CWE

    # Default to code CWE
    return FindingCategory.CODE_CWE


def is_test_file(file_path: str) -> bool:
    """Check if file is a test file."""
    file_lower = file_path.lower()
    for pattern in TEST_FILE_PATTERNS:
        if re.search(pattern, file_lower):
            return True
    return False


def extract_function_from_finding(finding: Dict, source_lines: Dict[str, List[str]] = None) -> Optional[str]:
    """
    Extract the function name containing a CWE finding.

    This requires either:
    1. The finding includes function info (some SAST tools do this)
    2. We have source code and can determine the enclosing function

    Args:
        finding: The CWE finding dict
        source_lines: Optional dict of file_path -> list of source lines

    Returns:
        Function name or None if cannot determine
    """
    # Check if finding already has function info
    if "function" in finding:
        return finding["function"]

    if "extra" in finding and "function" in finding.get("extra", {}):
        return finding["extra"]["function"]

    # Try to extract from snippet/context
    snippet = finding.get("snippet", finding.get("extra", {}).get("lines", ""))
    if snippet:
        # Look for function definition patterns
        func_patterns = [
            r"def\s+(\w+)\s*\(",  # Python
            r"function\s+(\w+)\s*\(",  # JavaScript
            r"func\s+(\w+)\s*\(",  # Go
            r"fn\s+(\w+)\s*\(",  # Rust
            r"(public|private|protected)?\s*\w+\s+(\w+)\s*\(",  # Java/C#
        ]
        for pattern in func_patterns:
            match = re.search(pattern, snippet)
            if match:
                return match.group(1) if match.lastindex == 1 else match.group(2)

    # Fallback: create a synthetic function name from file + line
    file_path = finding.get("file", finding.get("path", ""))
    line = finding.get("line", 0)
    if file_path and line:
        file_base = os.path.basename(file_path).rsplit(".", 1)[0]
        return f"{file_base}.<line:{line}>"

    return None


class CWEReachabilityAnalyzer:
    """
    Analyzes CWE findings for reachability based on call graph data.

    Key principle: A CWE is only a vulnerability if it can be reached
    from an application entry point through the call graph.

    For library CWEs: Uses function_imports to stitch library code to
    app functions that import it, then checks if those app functions
    are reachable. This matches CVE reachability behavior.
    """

    def __init__(
        self,
        call_graph: Dict[str, Set[str]],
        reachable_functions: Set[str],
        all_functions: Set[str],
        entry_points: Set[str],
        function_imports: Dict[str, Set[str]] = None,
        call_parents: Dict[str, Optional[str]] = None,
        entrypoint_reasons: Dict[str, str] = None,
    ):
        """
        Initialize with call graph data from ReachableAnalyzer.

        Args:
            call_graph: Dict mapping function -> set of called functions
            reachable_functions: Set of functions reachable from entry points
            all_functions: Set of all functions in codebase
            entry_points: Set of entry point functions
            function_imports: Dict mapping app function -> set of library imports
                              (for library CWE stitching)
        """
        self.call_graph = call_graph
        self.reachable_functions = reachable_functions
        self.all_functions = all_functions
        self.entry_points = entry_points
        self.function_imports = function_imports or {}
        self.call_parents = call_parents or {}  # BFS tree from ReachabilityAnalyzer
        self.entrypoint_reasons = entrypoint_reasons or {}  # Why each func is an entrypoint

        # Build reverse call graph for tracing paths
        self.reverse_graph: Dict[str, Set[str]] = {}
        for caller, callees in call_graph.items():
            for callee in callees:
                if callee not in self.reverse_graph:
                    self.reverse_graph[callee] = set()
                self.reverse_graph[callee].add(caller)

        # Build file -> functions index
        self.file_to_functions: Dict[str, Set[str]] = {}
        for func in all_functions:
            # Extract file from function name (e.g., "module.function" or "file.py:function")
            parts = func.replace("\\", "/").split(".")
            if len(parts) >= 2:
                file_key = parts[0].lower()
                if file_key not in self.file_to_functions:
                    self.file_to_functions[file_key] = set()
                self.file_to_functions[file_key].add(func)

        # Build library -> app functions index (for library CWE stitching)
        self.library_to_app_functions: Dict[str, Set[str]] = {}
        for app_func, imports in self.function_imports.items():
            for lib_import in imports:
                lib_base = lib_import.lower().replace("-", "_").replace(".", "_").split(".")[0]
                if lib_base not in self.library_to_app_functions:
                    self.library_to_app_functions[lib_base] = set()
                self.library_to_app_functions[lib_base].add(app_func)

    def analyze_finding(self, finding: Dict) -> CWEReachabilityResult:
        """
        Analyze a single CWE finding for reachability.

        For library CWEs: Uses function_imports to stitch library code to
        app functions that import it, then checks if those app functions
        are reachable. This matches CVE reachability behavior.

        Args:
            finding: Dict containing CWE finding data

        Returns:
            CWEReachabilityResult with reachability determination
        """
        file_path = finding.get("file", finding.get("path", ""))
        line = finding.get("line", 0)
        cwe_id = finding.get("cwe_id", "CWE-000")
        finding.get("rule_id", finding.get("check_id", ""))

        # Step 0: If the engine already computed reachable_via, trust it.
        # extract_function_from_finding() often produces a synthetic name like
        # "ai_vulnerabilities.<line:197>" that never matches qualified call graph
        # entries like "app.module.go.FunctionName", causing 200+ real reachable
        # findings to be incorrectly marked unreachable.
        engine_reachable_via = finding.get("reachable_via", [])
        if engine_reachable_via and any(v for v in engine_reachable_via if not v.startswith("LIKELY_FALSE_POSITIVE")):
            category = categorize_finding(finding)
            return CWEReachabilityResult(
                finding_id=f"{cwe_id}:{file_path}:{line}",
                cwe_id=cwe_id,
                file_path=file_path,
                line=line,
                function_name=extract_function_from_finding(finding),
                category=category,
                reachability=ReachabilityStatus.REACHABLE,
                reachable_via=engine_reachable_via,
                risk_multiplier=1.0,
                compliance_mapping=self._get_compliance_mapping(cwe_id),
            )

        # Step 1: Categorize the finding
        category = categorize_finding(finding)

        # Step 2: Determine reachability based on category
        if category == FindingCategory.CONFIG_CWE:
            # Config issues are always relevant (not subject to call graph)
            return CWEReachabilityResult(
                finding_id=f"{cwe_id}:{file_path}:{line}",
                cwe_id=cwe_id,
                file_path=file_path,
                line=line,
                function_name=None,
                category=category,
                reachability=ReachabilityStatus.CONFIG_ISSUE,
                reachable_via=[],
                risk_multiplier=1.0,  # Config issues always count
                compliance_mapping=self._get_compliance_mapping(cwe_id),
            )

        if category == FindingCategory.SECRET:
            # Secrets use existing secret reachability logic
            is_reachable = finding.get("is_reachable", False)
            return CWEReachabilityResult(
                finding_id=f"SECRET:{file_path}:{line}",
                cwe_id=cwe_id,
                file_path=file_path,
                line=line,
                function_name=None,
                category=category,
                reachability=ReachabilityStatus.REACHABLE if is_reachable else ReachabilityStatus.UNREACHABLE,
                reachable_via=finding.get("reachable_via", []),
                risk_multiplier=1.0 if is_reachable else 0.1,
                compliance_mapping=self._get_compliance_mapping(cwe_id),
            )

        # Step 3: For code CWEs, check if test file
        if is_test_file(file_path):
            return CWEReachabilityResult(
                finding_id=f"{cwe_id}:{file_path}:{line}",
                cwe_id=cwe_id,
                file_path=file_path,
                line=line,
                function_name=extract_function_from_finding(finding),
                category=category,
                reachability=ReachabilityStatus.TEST_ONLY,
                reachable_via=[],
                risk_multiplier=0.0,  # Test code doesn't count
                compliance_mapping=self._get_compliance_mapping(cwe_id),
            )

        # Step 3.5 (v2.9.61): Check for likely false positives
        is_fp, fp_reason = is_likely_false_positive(finding)
        if is_fp:
            # Mark as unreachable with reduced risk multiplier
            result = CWEReachabilityResult(
                finding_id=f"{cwe_id}:{file_path}:{line}",
                cwe_id=cwe_id,
                file_path=file_path,
                line=line,
                function_name=extract_function_from_finding(finding),
                category=category,
                reachability=ReachabilityStatus.UNREACHABLE,
                reachable_via=[f"LIKELY_FALSE_POSITIVE: {fp_reason}"],
                risk_multiplier=0.05,  # Very low risk for false positives
                compliance_mapping=self._get_compliance_mapping(cwe_id),
            )
            # Store false positive info in finding for reporting
            finding["is_likely_false_positive"] = True
            finding["false_positive_reason"] = fp_reason
            return result

        # Step 4: Check if this is LIBRARY code (requires stitching)
        # Library CWEs need special handling - we check if app imports the library
        is_library, library_name = self._is_library_code(file_path)

        if is_library and library_name:
            # Library CWE: Stitch to app functions that import this library
            is_reachable, call_path = self._check_library_cwe_reachability(library_name, file_path)
            return CWEReachabilityResult(
                finding_id=f"{cwe_id}:{file_path}:{line}",
                cwe_id=cwe_id,
                file_path=file_path,
                line=line,
                function_name=extract_function_from_finding(finding),
                category=category,
                reachability=ReachabilityStatus.REACHABLE if is_reachable else ReachabilityStatus.UNREACHABLE,
                reachable_via=call_path,
                risk_multiplier=1.0 if is_reachable else 0.1,
                compliance_mapping=self._get_compliance_mapping(cwe_id),
            )

        # Step 5: Application code - check call graph reachability directly
        func_name = extract_function_from_finding(finding)
        is_reachable, call_path = self._check_function_reachability(func_name, file_path)

        return CWEReachabilityResult(
            finding_id=f"{cwe_id}:{file_path}:{line}",
            cwe_id=cwe_id,
            file_path=file_path,
            line=line,
            function_name=func_name,
            category=category,
            reachability=ReachabilityStatus.REACHABLE if is_reachable else ReachabilityStatus.UNREACHABLE,
            reachable_via=call_path,
            risk_multiplier=1.0 if is_reachable else 0.1,
            compliance_mapping=self._get_compliance_mapping(cwe_id),
        )

    def _is_library_code(self, file_path: str) -> Tuple[bool, Optional[str]]:
        """
        Detect if file is in library/vendor code and extract library name.

        Returns:
            (is_library, library_name)
        """
        import re

        file_lower = file_path.lower().replace("\\", "/")

        # Common library/vendor patterns
        library_patterns = [
            (r"/lib/([^/]+)", "lib"),  # libs directory
            (r"/libs/([^/]+)", "libs"),  # libs directory
            (r"/vendor/([^/]+)", "vendor"),  # vendor directory
            (r"/node_modules/([^/]+)", "npm"),  # npm packages
            (r"/site-packages/([^/]+)", "pip"),  # pip packages
            (r"/dist-packages/([^/]+)", "pip"),  # debian pip
            (r"/\.venv/.*?site-packages/([^/]+)", "venv"),
            (r"/venv/.*?site-packages/([^/]+)", "venv"),
            (r"/pkg/mod/([^@/]+)", "go"),  # Go modules
        ]

        for pattern, _ in library_patterns:
            match = re.search(pattern, file_lower)
            if match:
                lib_name = match.group(1).replace("-", "_").replace(".", "_")
                return True, lib_name

        return False, None

    def _check_library_cwe_reachability(self, library_name: str, file_path: str) -> Tuple[bool, List[str]]:
        """
        Check if a library CWE is reachable by finding app functions that import it.

        This is the library→app stitching logic that matches CVE behavior.

        Args:
            library_name: Name of the library containing the CWE
            file_path: Path to the file with the CWE

        Returns:
            (is_reachable, call_path from entry point through app function to library)
        """
        lib_normalized = library_name.lower().replace("-", "_").replace(".", "_")

        # Find app functions that import this library
        app_funcs_using_lib = set()

        # Check library_to_app_functions index
        if lib_normalized in self.library_to_app_functions:
            app_funcs_using_lib = self.library_to_app_functions[lib_normalized]

        # Also check function_imports directly for partial matches
        for app_func, imports in self.function_imports.items():
            for imp in imports:
                imp_normalized = imp.lower().replace("-", "_").replace(".", "_")
                if lib_normalized in imp_normalized:
                    app_funcs_using_lib.add(app_func)

        # Check if any app function that uses this library is reachable
        for app_func in app_funcs_using_lib:
            if app_func in self.reachable_functions:
                # Found a reachable app function that imports this library
                call_path = self._trace_path_to_entry(app_func)
                call_path.append(f"→ {library_name}")
                return True, call_path

        # Library is imported but no importing function is reachable
        if app_funcs_using_lib:
            return False, [f"(library {library_name} imported but not reachable)"]

        # Library is not imported by any app function
        return False, [f"(library {library_name} not imported by app)"]

    def _check_function_reachability(self, func_name: Optional[str], file_path: str) -> Tuple[bool, List[str]]:
        """
        Check if a function is reachable from entry points.

        Returns:
            Tuple of (is_reachable, call_path)
        """
        if not func_name:
            # If we can't determine function, check file-level reachability
            return self._check_file_reachability(file_path)

        # Normalize function name for matching
        func_lower = func_name.lower()

        # Direct match
        if func_name in self.reachable_functions:
            path = self._trace_path_to_entry(func_name)
            return True, path

        # Try partial matching (module.function variations)
        for reachable_func in self.reachable_functions:
            if func_lower in reachable_func.lower() or reachable_func.lower() in func_lower:
                path = self._trace_path_to_entry(reachable_func)
                return True, path

        return False, []

    def _check_file_reachability(self, file_path: str) -> Tuple[bool, List[str]]:
        """
        Check if any function in a file is reachable.
        """
        file_lower = file_path.lower().replace("\\", "/")
        file_base = os.path.basename(file_lower).rsplit(".", 1)[0]

        # Check if file has any reachable functions
        if file_base in self.file_to_functions:
            for func in self.file_to_functions[file_base]:
                if func in self.reachable_functions:
                    return True, [func]

        # Check for entrypoint files
        entrypoint_names = {"main", "index", "app", "server", "cmd", "handler", "api"}
        if file_base in entrypoint_names:
            return True, ["<entrypoint>"]

        return False, []

    def _label_entrypoint(self, func: str) -> str:
        """Return a human-readable label for an entrypoint function."""
        reason = self.entrypoint_reasons.get(func, "")
        simple = func.split(".")[-1]
        if reason in ("HTTP method handler", "route/handler pattern", "Go HTTP handler", "Go handler suffix"):
            method = next(
                (m.upper() for m in ["get", "post", "put", "delete", "patch"] if simple.lower().startswith(m)),
                None,
            )
            return f"{method} /{simple}" if method else f"endpoint:{simple}"
        if reason == "gRPC service":
            return f"gRPC:{simple}"
        if reason == "main function":
            return "main()"
        if reason == "CLI command":
            return f"cli:{simple}"
        if reason in ("React component", "module entry", "exported function"):
            return f"export:{simple}"
        return simple

    def _trace_path_to_entry(self, func_name: str, max_depth: int = 10) -> List[str]:
        """
        T-CG4: Trace the call path from entry point to this function.
        call_parents is now Dict[func, List[str]] (multi-parent BFS from T-CG1).
        Returns the shortest path found (first parent chain that reaches a root).
        """
        # --- Primary: use call_parents (multi-parent BFS tree from T-CG1) ---
        if self.call_parents and func_name in self.call_parents:
            from collections import deque as _deque

            # BFS backward to find shortest path to a root
            q = _deque([(func_name, [func_name])])
            while q:
                node, rev_path = q.popleft()
                if len(rev_path) > max_depth:
                    path = list(reversed(rev_path))
                    if path:
                        path[0] = self._label_entrypoint(path[0])
                    return path
                parents = self.call_parents.get(node)
                # Handle both old format (None/str) and new format (List[str])
                if parents is None or parents == []:
                    # Reached root
                    path = list(reversed(rev_path))
                    if path:
                        path[0] = self._label_entrypoint(path[0])
                    return path
                if isinstance(parents, str):
                    parents = [parents]  # backward compat with old single-parent format
                for parent in parents:
                    if parent not in rev_path:  # cycle guard
                        q.append((parent, rev_path + [parent]))
            # If BFS exhausted without finding root, return what we have
            return [self._label_entrypoint(func_name)]

        # --- Fallback: reverse-graph traversal ---
        path = [func_name]
        current = func_name
        for _ in range(max_depth):
            callers = self.reverse_graph.get(current, set())
            if not callers:
                break
            for caller in callers:
                if caller in self.entry_points:
                    path.append(self._label_entrypoint(caller))
                    return list(reversed(path))
                if caller in self.reachable_functions:
                    path.append(caller)
                    current = caller
                    break
            else:
                break
        path.reverse()
        if path:
            path[0] = self._label_entrypoint(path[0])
        return path

    def _get_compliance_mapping(self, cwe_id: str) -> Dict[str, List[str]]:
        """
        Get compliance standard mapping for a CWE.
        """
        # Import from standards_mapper if available
        try:
            from reachable.standards.mapper import get_cwe_compliance_mapping

            return get_cwe_compliance_mapping(cwe_id)
        except ImportError:
            pass

        # Fallback mappings for common CWEs
        return CWE_COMPLIANCE_MAPPING.get(cwe_id, {})

    def analyze_all_findings(self, findings: List[Dict]) -> Dict:
        """
        Analyze all CWE findings and return summary statistics.

        Returns:
            Dict with analysis results and statistics
        """
        results = []
        stats = {
            "total": 0,
            "reachable": 0,
            "unreachable": 0,
            "config_issues": 0,
            "test_only": 0,
            "by_category": {},
            "by_cwe": {},
            "compliance_violations": {},
        }

        for finding in findings:
            result = self.analyze_finding(finding)
            results.append(result)

            stats["total"] += 1

            if result.reachability == ReachabilityStatus.REACHABLE:
                stats["reachable"] += 1
            elif result.reachability == ReachabilityStatus.UNREACHABLE:
                stats["unreachable"] += 1
            elif result.reachability == ReachabilityStatus.CONFIG_ISSUE:
                stats["config_issues"] += 1
            elif result.reachability == ReachabilityStatus.TEST_ONLY:
                stats["test_only"] += 1

            # By category
            cat = result.category.value
            stats["by_category"][cat] = stats["by_category"].get(cat, 0) + 1

            # By CWE
            stats["by_cwe"][result.cwe_id] = stats["by_cwe"].get(result.cwe_id, 0) + 1

            # Compliance violations (only for reachable/config issues)
            if result.reachability in (ReachabilityStatus.REACHABLE, ReachabilityStatus.CONFIG_ISSUE):
                for standard, reqs in result.compliance_mapping.items():
                    if standard not in stats["compliance_violations"]:
                        stats["compliance_violations"][standard] = {}
                    for req in reqs:
                        stats["compliance_violations"][standard][req] = (
                            stats["compliance_violations"][standard].get(req, 0) + 1
                        )

        return {"results": results, "statistics": stats}


# Fallback compliance mappings for common CWEs
CWE_COMPLIANCE_MAPPING = {
    "CWE-89": {  # SQL Injection
        "OWASP": ["A03:2021"],
        "PCI-DSS": ["6.5.1", "6.2.4"],
        "NIST-800-53": ["SI-10", "SI-11"],
        "SOC2": ["CC6.1"],
        "HIPAA": ["164.312(a)(1)"],
    },
    "CWE-79": {  # XSS
        "OWASP": ["A03:2021"],
        "PCI-DSS": ["6.5.7", "6.2.4"],
        "NIST-800-53": ["SI-10"],
        "SOC2": ["CC6.1"],
    },
    "CWE-78": {  # OS Command Injection
        "OWASP": ["A03:2021"],
        "PCI-DSS": ["6.5.1", "6.2.4"],
        "NIST-800-53": ["SI-10"],
        "SOC2": ["CC6.1"],
    },
    "CWE-798": {  # Hardcoded Credentials
        "OWASP": ["A07:2021"],
        "PCI-DSS": ["3.5", "8.2.1"],
        "NIST-800-53": ["IA-5", "SC-12"],
        "SOC2": ["CC6.1", "CC6.7"],
        "HIPAA": ["164.312(d)"],
    },
    "CWE-327": {  # Broken Crypto
        "OWASP": ["A02:2021"],
        "PCI-DSS": ["3.4", "4.1"],
        "NIST-800-53": ["SC-13"],
        "SOC2": ["CC6.7"],
        "HIPAA": ["164.312(e)(2)(ii)"],
    },
    "CWE-22": {  # Path Traversal
        "OWASP": ["A01:2021"],
        "PCI-DSS": ["6.5.8"],
        "NIST-800-53": ["AC-6"],
        "SOC2": ["CC6.1"],
    },
    "CWE-502": {  # Deserialization
        "OWASP": ["A08:2021"],
        "PCI-DSS": ["6.5.1"],
        "NIST-800-53": ["SI-10"],
        "SOC2": ["CC6.1"],
    },
    "CWE-918": {  # SSRF
        "OWASP": ["A10:2021"],
        "PCI-DSS": ["6.5.1"],
        "NIST-800-53": ["SC-7"],
        "SOC2": ["CC6.6"],
    },
    "CWE-250": {  # Execution with Unnecessary Privileges
        "OWASP": ["A05:2021"],
        "PCI-DSS": ["7.1"],
        "NIST-800-53": ["AC-6", "CM-7"],
        "SOC2": ["CC6.3"],
    },
    "CWE-352": {  # CSRF
        "OWASP": ["A01:2021"],
        "PCI-DSS": ["6.5.9"],
        "NIST-800-53": ["SI-10"],
        "SOC2": ["CC6.1"],
    },
}


def get_cwe_compliance_mapping(cwe_id: str) -> Dict[str, List[str]]:
    """Get compliance mapping for a CWE ID."""
    return CWE_COMPLIANCE_MAPPING.get(cwe_id, {})
