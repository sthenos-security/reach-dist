#!/usr/bin/env python3
# Copyright (c) 2026 Sthenos Security. All rights reserved.

"""
v5.1.3 CVE Normalizer

Reads: reachable-report.json.gz (analyzed output with reachability data)
Produces: findings (type=cve)

The report contains CVEs split into 'reachable' and 'unreachable' dicts,
each keyed by vuln ID with full metadata including reachability status,
CVSS scores, fix versions, and call paths.
"""

import hashlib
import json
import logging
import re
from pathlib import Path
from typing import Any, Dict, List, Optional

from reachable.database.normalizers.compliance_tags import get_compliance_mapping
from reachable.engine.hop_registry import HopPosition, PathNode, classify_hop

logger = logging.getLogger(__name__)

# Severity normalization
SEVERITY_MAP = {
    "CRITICAL": "CRITICAL",
    "HIGH": "HIGH",
    "MEDIUM": "MEDIUM",
    "LOW": "LOW",
    "NEGLIGIBLE": "LOW",
    "UNKNOWN": "MEDIUM",
}


def _build_path_nodes_v2(hops: List[str], finding_type: str) -> List[dict]:
    """
    T-CG28: Build call_paths_v2 PathNode list DIRECTLY from engine string hops.

    Builds call_paths_v2 — typed PathNode list.
    classify_hop() logic but is a normalizer function, not a legacy fallback.

    """
    if not hops:
        return []
    n = len(hops)
    result = []
    for i, hop in enumerate(hops):
        if not isinstance(hop, str) or not hop:
            continue
        pos = HopPosition.FIRST if i == 0 else (HopPosition.LAST if i == n - 1 else HopPosition.MIDDLE)
        decision = classify_hop(hop, finding_type, pos)
        node = PathNode(
            label=hop,
            kind=decision.kind,
            taint_exits=decision.taint_exits,
            is_boundary=(decision.kind.value == "boundary"),
        )
        if node.is_boundary:
            node.boundary_class = _boundary_class_for_hop(hop)
        result.append(node.to_dict())
    # T-CG16: append OS boundary terminator when last node is boundary
    if result and result[-1].get("is_boundary"):
        bc = result[-1].get("boundary_class", "os_stdlib")
        label_map = {
            "os_stdlib": "[OS BOUNDARY — execution continues in system layer]",
            "cgo": "[CGO BOUNDARY — execution continues in C code]",
            "dynamic_lib": "[DYNAMIC BOUNDARY — library resolved at runtime]",
            "reflection": "[REFLECTION BOUNDARY — dynamic dispatch]",
        }
        result.append(
            PathNode(
                label=label_map.get(bc, "[BOUNDARY — execution crosses static analysis limit]"),
                kind=decision.kind,  # type: ignore[possibly-undefined]
                is_boundary=True,
                boundary_class=bc,
                taint_exits=result[-1].get("taint_exits"),
            ).to_dict()
        )
    return result


_BOUNDARY_PATTERNS_SIMPLE = [
    (re.compile(r"^syscall\.|^golang\.org/x/sys|^unsafe\."), "os_stdlib"),
    (re.compile(r"#cgo\b|\bC\."), "cgo"),
    (re.compile(r"plugin\.Open"), "dynamic_lib"),
    (re.compile(r"^reflect\."), "reflection"),
]


def _boundary_class_for_hop(label: str) -> str:
    for pat, cls in _BOUNDARY_PATTERNS_SIMPLE:
        if pat.search(label):
            return cls
    return "os_stdlib"


def _extract_call_path(cve_data: dict) -> list:
    """
    T-CG2: Extract primary call path from CVE data.
    Engine now emits call_paths as List[List[str]]; _legacy_cp is the primary (first).
    Falls back to flat list or reachable_via for backward compat.
    """
    # T-CG2: primary path from multi-path engine output
    _legacy_cp = cve_data.get("_legacy_cp", [])  # T-CG28: local only, not written to DB
    if _legacy_cp and isinstance(_legacy_cp, list):
        # If it's a list of lists (shouldn't be for _legacy_cp but guard anyway)
        if _legacy_cp and isinstance(_legacy_cp[0], list):
            return _legacy_cp[0]
        return _legacy_cp
    reachable_via = cve_data.get("reachable_via", [])
    if reachable_via:
        return reachable_via
    return []


def _extract_all_call_paths(cve_data: dict) -> list:
    """
    T-CG2: Extract ALL call paths from CVE data.
    Engine emits call_paths: List[List[str]] (arrays of hops).
    Falls back to building a single-path list from _legacy_cp.
    """
    raw = cve_data.get("call_paths_v2", cve_data.get("call_paths", []))  # T-CG28: prefer v2
    if raw and isinstance(raw, list):
        if raw and isinstance(raw[0], list):
            # Already List[List[str]] — dedup while preserving order
            seen = set()
            result = []
            for p in raw:
                key = tuple(p)
                if key not in seen:
                    seen.add(key)
                    result.append(p)
            return result
        # Old format: List[str] strings like "a → b → c"
        result = []
        for p in raw:
            if isinstance(p, str) and " → " in p:
                result.append(p.split(" → "))
            elif isinstance(p, str):
                result.append([p])
        return result
    # Fallback to single path
    primary = _extract_call_path(cve_data)
    return [primary] if primary else []


def _calculate_risk_level(severity: str, reachability: str, is_exploited: bool = False, epss_score: float = 0.0) -> str:
    """Calculate risk level from severity + reachability + threat intel."""
    sev = severity.upper()
    if is_exploited and reachability == "REACHABLE":
        return "CRITICAL"
    if sev == "CRITICAL" and reachability == "REACHABLE":
        return "CRITICAL"
    if sev == "CRITICAL" and reachability != "REACHABLE":
        return "HIGH"
    if sev == "HIGH" and reachability == "REACHABLE":
        return "HIGH"
    if sev == "HIGH":
        return "MEDIUM"
    if sev == "MEDIUM" and reachability == "REACHABLE":
        return "MEDIUM"
    return "LOW"


def _generate_finding_id(primary_id: str, package: str, version: str) -> str:
    """Generate stable finding ID."""
    key = f"{primary_id}:{package}:{version}"
    return hashlib.md5(key.encode()).hexdigest()[:16]


# Go stdlib package prefixes - never treated as via_package candidates
_STDLIB_PREFIXES = (
    "net/",
    "encoding/",
    "crypto/",
    "fmt",
    "os",
    "io",
    "bytes",
    "strings",
    "strconv",
    "sync",
    "time",
    "context",
    "errors",
    "log",
    "math",
    "sort",
    "path/",
    "runtime",
    "reflect",
    "unicode",
    "bufio",
    "regexp",
    "syscall",
    "flag",
    "html",
    "image",
    "mime",
    "plugin",
    "testing",
    "text/",
    "hash/",
    "archive/",
    "compress/",
    "container/",
    "database/",
    "debug/",
    "expvar",
    "go/",
    "index/",
    "internal/",
    "unsafe",
    "builtin",
    "atomic",
)

# Module host prefixes that signal a real Go module path (not stdlib, not app code)
_MODULE_HOSTS = (
    "github.com/",
    "golang.org/",
    "gopkg.in/",
    "google.golang.org/",
    "k8s.io/",
    "sigs.k8s.io/",
    "go.opentelemetry.io/",
    "go.uber.org/",
)


def _is_stdlib_hop(hop: str) -> bool:
    """Return True if hop looks like a Go stdlib package."""
    return any(hop == p.rstrip("/") or hop.startswith(p) for p in _STDLIB_PREFIXES)


def _module_root(path: str) -> str:
    """Extract the module root (owner/repo) from a full import path."""
    parts = path.split("/")
    if len(parts) >= 3 and parts[0] in ("github.com", "golang.org", "go.opentelemetry.io", "go.uber.org"):
        return "/".join(parts[:3])
    if len(parts) >= 2:
        return "/".join(parts[:2])
    return path


def _derive_via_from_call_paths(
    call_paths,  # List[List[str]] or List[str]
    vulnerable_package: str,
    app_name: str = "app",
) -> Optional[tuple]:
    """
    Derive (via_package, dependency_chain) from call_paths (authoritative AST source).

    The module-graph walk in the engine can produce wrong chains by threading
    through stdlib packages (e.g. net/http) as bridges.  Call_paths from the
    AST reachability engine show the actual code execution route.

    Two patterns signal a genuine intermediate module:

    1. Direct module path hop (no app. prefix):
           github.com/wish/pod-netstat-exporter/pkg/netstat
           github.com/prometheus/common/expfmt
       Unambiguous third-party imports in the call path.

    2. Vendored module with dash in component name (app.X-Y.pkg.Func):
           app.crewjam-saml.samlidp.Server.HandleLogin  -> via=crewjam/saml
       Own-app packages use plain names (app.example.*, app.pkg.*) - no dash.
    """
    if not call_paths:
        return None

    vuln_lower = (vulnerable_package or "").lower()
    vuln_root = _module_root(vuln_lower) if "/" in vuln_lower else vuln_lower

    for path_item in call_paths:
        # T-CG2: path_item is now List[str]; backward compat with "a → b" strings
        if isinstance(path_item, list):
            hops = [h.strip() for h in path_item if isinstance(h, str)]
        else:
            hops = [h.strip() for h in str(path_item).replace("→", "→").split("→")]

        for hop in hops:
            hop_lower = hop.lower()

            # Skip the vulnerable package itself (exact or root match)
            if vuln_lower and (hop_lower == vuln_lower or hop_lower.startswith(vuln_root)):
                continue

            # Skip stdlib
            if _is_stdlib_hop(hop_lower):
                continue

            # Pattern 1: direct module path (github.com/..., golang.org/..., etc.)
            if any(hop_lower.startswith(h) for h in _MODULE_HOSTS):
                via = _module_root(hop)
                # Do NOT include app_name — template prepends 'your project'
                # ingester sub-module enrichment will insert the owning sub-module later
                chain = [via, vulnerable_package]
                return via, chain

            # Pattern 2: app.<vendor-with-dash>.<pkg>.<Func>
            # crewjam-saml has a dash -> vendored third-party
            # example, kubernetes, pkg -> own-app code, skip
            if hop_lower.startswith("app."):
                parts = hop.split(".")
                if len(parts) >= 3 and "-" in parts[1]:
                    via = parts[1].replace("-", "/")
                    # Do NOT include app_name — template prepends 'your project'
                    chain = [via, vulnerable_package]
                    return via, chain

    return None


def _process_cve_section(
    cves_dict: Dict, default_reachability: str, seen_keys: set, merged: Dict = None, order: List = None
) -> None:
    """
    T-CG2: Process one section (reachable/unreachable) into a shared merged dict.
    merged and order are shared across sections so paths accumulate.
    """
    if merged is None:
        merged = {}
    if order is None:
        order = []

    for vuln_id, cve_data in cves_dict.items():
        try:
            package = cve_data.get("package", "")
            version = cve_data.get("version", "")

            cve_id = cve_data.get("cve_id")
            if not cve_id and vuln_id.startswith("CVE-"):
                cve_id = vuln_id
            ghsa_id = cve_data.get("ghsa_id")
            if not ghsa_id and vuln_id.startswith("GHSA-"):
                ghsa_id = vuln_id

            # Canonical ID for the merge key: prefer CVE, else GHSA, else raw
            canonical_id = cve_id or ghsa_id or vuln_id
            merge_key = (canonical_id, package, version)

            # If already processed in the OTHER section, still accumulate new paths
            # (e.g. reachable via handler AND unreachable via another — keep all paths)
            _legacy_cp = _extract_call_path(cve_data)
            if merge_key in seen_keys:
                # Key already in merged from the other section — just merge paths
                existing = merged.get(merge_key)
                if existing is not None:
                    new_paths = _extract_all_call_paths(cve_data)
                    for np in new_paths:
                        if np and np not in existing["reachability_paths"]:
                            existing["reachability_paths"].append(np)
                    if _legacy_cp and _legacy_cp not in existing["reachability_paths"]:
                        existing["reachability_paths"].append(_legacy_cp)
                continue

            if merge_key not in merged:
                # First time we see this (CVE, pkg, version) — build the base finding
                seen_keys.add(merge_key)
                order.append(merge_key)

                if cve_data.get("reachability_unknown", False):
                    app_reach = "UNKNOWN"
                else:
                    app_reach = default_reachability

                severity = SEVERITY_MAP.get((cve_data.get("severity") or "MEDIUM").upper(), "MEDIUM")
                risk_level = _calculate_risk_level(
                    severity,
                    app_reach,
                    cve_data.get("is_exploited", cve_data.get("in_kev", False)),
                    cve_data.get("epss_score", cve_data.get("epss", 0.0)),
                )

                display_id = cve_data.get("display_id", vuln_id)
                finding_id = _generate_finding_id(canonical_id, package, version)

                fix_versions = cve_data.get("fix_versions", [])
                fix_status = "fix_available" if (cve_data.get("is_fixable") or fix_versions) else "no_fix"
                fix_version = ",".join(fix_versions) if fix_versions else None

                _exploit = cve_data.get("exploitability") or {}
                _epss = _exploit.get("epss") or {}
                _kev = _exploit.get("kev") or {}
                epss_score = cve_data.get("epss_score") or _epss.get("score")
                _ep_pct = cve_data.get("epss_percentile") or _epss.get("percentile")
                epss_percentile = int(_ep_pct * 100) if _ep_pct and _ep_pct <= 1.0 else (_ep_pct if _ep_pct else None)
                is_kev = cve_data.get("is_kev") if cve_data.get("is_kev") is not None else _kev.get("in_catalog", False)

                _raw_call_paths = _extract_all_call_paths(cve_data)  # T-CG2: List[List[str]]
                # T-CG28: build call_paths_v2 DIRECTLY
                _call_paths_v2 = [_build_path_nodes_v2(p, "cve") for p in _raw_call_paths if p]
                _raw_via = cve_data.get("via_package") or ""
                _raw_chain = cve_data.get("dependency_chain", [])
                _is_transitive = cve_data.get("is_transitive", False)
                if _is_transitive and _raw_call_paths:
                    _derived = _derive_via_from_call_paths(_raw_call_paths, package)
                    if _derived:
                        _raw_via, _raw_chain = _derived
                        logger.debug(
                            f"  via_package override: {cve_data.get('via_package')!r} -> {_raw_via!r} (from call_paths)"
                        )

                # v1.0.0b16: Extract manifest_path from engine output
                # Grype provides artifact.locations[].path (e.g. "requirements.txt")
                _manifest = cve_data.get("manifest_path", "") or ""

                merged[merge_key] = {
                    "id": finding_id,
                    "vuln_id": canonical_id,
                    # T-CG28: _legacy_cp removed — call_paths_v2 is authoritative
                    "cve_id": cve_id,
                    "ghsa_id": ghsa_id,
                    "display_id": display_id,
                    "severity": severity,
                    "risk_level": risk_level,
                    "title": display_id or vuln_id,
                    "description": (cve_data.get("description", "") or "")[:500],
                    "package": package,
                    "version": version,
                    "manifest_path": _manifest,  # v1.0.0b16: e.g. "requirements.txt"
                    "file_path": _manifest,  # v1.0.0b16: populate for DB storage (answers "where to fix")
                    "app_reachability": app_reach,
                    "reachability_path": _legacy_cp,  # primary path (backward compat)
                    "reachability_paths": _raw_call_paths or ([_legacy_cp] if _legacy_cp else []),  # T-CG2: all paths
                    "reachability_confidence": "HIGH" if app_reach == "REACHABLE" else "LOW",
                    "cvss_score": cve_data.get("cvss_score", 0.0) or 0.0,
                    "fix_status": fix_status,
                    "fix_version": fix_version,
                    "remediation": cve_data.get("remediation"),
                    "urls": cve_data.get("urls", []),
                    "dataSource": cve_data.get("dataSource"),
                    "exploitability": cve_data.get("exploitability"),
                    "is_transitive": _is_transitive,
                    "via_package": _raw_via,
                    "dependency_chain": _raw_chain,
                    "dependency_depth": cve_data.get("dependency_depth", 0),
                    # T-CG28: call_paths v1 field removed
                    # T-CG10: authoritative typed PathNode list for dashboard rendering
                    "call_paths_v2": _call_paths_v2,
                    "epss_score": epss_score,
                    "epss_percentile": epss_percentile,
                    "is_kev": is_kev,
                    "scanner": "grype",
                    # OSV package group enrichment fields (populated by threat_intel.py)
                    # osv_aliases: all cross-IDs (CVE↔GHSA↔GO-↔PYSEC-) for this vuln
                    "osv_aliases": cve_data.get("osv_aliases", []),
                    # osv_summary: one-liner from OSV (often clearer than NVD description)
                    "osv_summary": cve_data.get("osv_summary"),
                    # osv_cwes: CWE IDs from affected[].database_specific.cwes
                    "osv_cwes": cve_data.get("osv_cwes", []),
                    # osv_withdrawn: set if vuln was retracted by the advisory database
                    "osv_withdrawn": cve_data.get("osv_withdrawn"),
                    # COMP-01: compliance tags for CVE findings
                    "compliance_mapping": get_compliance_mapping("cve", cve_data.get("compliance_mapping") or {}),
                }
            else:
                # Same (CVE, pkg, version) seen again — just accumulate the path
                existing = merged[merge_key]

                # Upgrade reachability: REACHABLE wins over NOT_REACHABLE/UNKNOWN
                if default_reachability == "REACHABLE":
                    existing["app_reachability"] = "REACHABLE"
                    existing["reachability_confidence"] = "HIGH"

                # T-CG2: merge all new paths (List[List[str]]) into existing
                new_paths = _extract_all_call_paths(cve_data)
                for np in new_paths:
                    if np and np not in existing["reachability_paths"]:
                        existing["reachability_paths"].append(np)
                # Also check primary _legacy_cp (backward compat)
                if _legacy_cp and _legacy_cp not in existing["reachability_paths"]:
                    existing["reachability_paths"].append(_legacy_cp)
                # Keep shortest non-empty path as canonical
                all_paths = existing["reachability_paths"]
                if all_paths:
                    shortest = min(all_paths, key=len)
                    if not existing["reachability_path"] or len(shortest) < len(existing["reachability_path"]):
                        existing["reachability_path"] = shortest

        except Exception as e:
            logger.warning(f"Error normalizing CVE {vuln_id}: {e}")
            continue

    # T-CG2: caller uses shared merged/order — nothing to return from this function
    raw_count = len(cves_dict)
    logger.debug(f"  CVE section: processed {raw_count} raw entries")


# ════════════════════════════════════════════════════════════════════════════
# T-CG14: JS/TS dev/runtime split via package-lock.json
# ════════════════════════════════════════════════════════════════════════════


def _build_npm_dep_map(scan_dir: Path) -> Dict[str, str]:
    """
    T-CG14: Parse all package-lock.json files under scan_dir.
    Returns {package_name: 'runtime'|'dev'|'optional'|'peer'}.

    package-lock.json v2/v3 format (node_modules/ keys):
      'dev': true          → devDependency
      'devOptional': true  → devDependency (optional)
      'optional': true     → optionalDependency (may run in prod)
      'peer': true         → peerDependency
      absent / false       → runtime
    """
    dep_map: Dict[str, str] = {}
    if not scan_dir:
        return dep_map
    try:
        import json as _json

        for lockfile in Path(scan_dir).rglob("package-lock.json"):
            if "node_modules" in str(lockfile):
                continue
            try:
                data = _json.loads(lockfile.read_text(encoding="utf-8", errors="ignore"))
            except Exception:
                continue
            packages = data.get("packages", {})
            for pkg_path, info in packages.items():
                if not pkg_path or not isinstance(info, dict):
                    continue
                # Normalise: 'node_modules/foo' or 'node_modules/@scope/foo'
                name = pkg_path.removeprefix("node_modules/").strip()
                if not name or name in dep_map:
                    continue
                if info.get("dev") or info.get("devOptional"):
                    dep_map[name] = "dev"
                elif info.get("peer"):
                    dep_map[name] = "peer"
                elif info.get("optional"):
                    dep_map[name] = "optional"
                else:
                    dep_map[name] = "runtime"
    except Exception:
        pass
    return dep_map


def _enrich_npm_cve_reachability(
    findings: List[Dict],
    callgraph_file: Path,
    npm_dep_map: Dict[str, str],
) -> List[Dict]:
    """
    T-CG15: Enrich npm CVE findings with JS/TS callgraph reachability.

    Reads call-graph-js.json produced by JSCallGraphCollector (Joern or ts-morph).
    Priority order:
      1. dev dep already marked NOT_REACHABLE → skip (preserve T-CG14 result)
      2. In callgraph with is_reachable='true' → REACHABLE (Joern full CPG)
      3. In callgraph with is_reachable='import_traced' → UNKNOWN (ts-morph, import only)
      4. In callgraph with is_reachable='false' → NOT_REACHABLE (Joern: imported but unreachable)
      5. Not in callgraph at all → UNKNOWN (not analyzed)
    """
    try:
        records = json.loads(callgraph_file.read_text())
    except Exception:
        return findings

    if not records:
        return findings

    # Detect tier from is_reachable values
    is_ts_morph = any(r.get("is_reachable") == "import_traced" for r in records)

    # Build index: {package_name: [record, ...]}
    cg_index: Dict[str, list] = {}
    for rec in records:
        pkg = rec.get("package", "")
        if pkg:
            cg_index.setdefault(pkg, []).append(rec)

    for f in findings:
        # Only enrich npm findings
        ecosystem = (f.get("package_ecosystem") or f.get("ecosystem") or "").lower()
        # If ecosystem not set but npm_dep_map has the package, infer npm
        pkg = f.get("package", "")
        if ecosystem not in ("npm", "") and ecosystem != "unknown":
            continue
        if not pkg:
            continue

        # 1. Skip if already determined by T-CG14 (dev_dependency)
        if f.get("reachability_reason") == "dev_dependency":
            continue

        records_for_pkg = cg_index.get(pkg, [])

        if not records_for_pkg:
            # Package not found in callgraph at all
            f.setdefault("app_reachability", "UNKNOWN")
            f["reachability_reason"] = f.get("reachability_reason", "not_in_callgraph")
            continue

        # 2–4: Determine reachability from callgraph records
        reachable_recs = [r for r in records_for_pkg if r.get("is_reachable") == "true"]
        imported_recs = [r for r in records_for_pkg if r.get("is_reachable") == "import_traced"]
        unreachable_recs = [r for r in records_for_pkg if r.get("is_reachable") == "false"]

        if reachable_recs:
            # Joern: confirmed reachable from entrypoint
            r = reachable_recs[0]
            f["app_reachability"] = "REACHABLE"
            f["reachability_confidence"] = "MEDIUM"  # static analysis, not runtime
            f["reachability_reason"] = "js_callgraph_reachable"
            # Build a minimal dependency chain for the dashboard
            caller_file = r.get("caller_file", "")
            caller_func = r.get("caller_func", "")
            version = f.get("version", f.get("installed_version", ""))
            chain = []
            if caller_file:
                chain.append(caller_file)
            if caller_func and caller_func not in ("<import>", "<module>"):
                chain.append(f"{caller_func}()")
            chain.append(f"{pkg}@{version}" if version else pkg)
            f["dependency_chain"] = chain

        elif imported_recs:
            # ts-morph: imported somewhere but we can't confirm runtime reachability
            r = imported_recs[0]
            f["app_reachability"] = "UNKNOWN"
            f["reachability_confidence"] = "LOW"
            f["reachability_reason"] = "import_traced_no_callgraph"

        elif unreachable_recs:
            # Joern: imported but not reachable from any entrypoint
            f["app_reachability"] = "NOT_REACHABLE"
            f["reachability_confidence"] = "MEDIUM"
            f["reachability_reason"] = "not_in_reachable_path"

    cg_reach = sum(1 for f in findings if f.get("reachability_reason") == "js_callgraph_reachable")
    cg_import = sum(1 for f in findings if f.get("reachability_reason") == "import_traced_no_callgraph")
    cg_unreach = sum(1 for f in findings if f.get("reachability_reason") == "not_in_reachable_path")
    tier = "ts-morph (import tracing)" if is_ts_morph else "Joern CPG"
    logger.info(
        f"T-CG15 JS callgraph ({tier}): {cg_reach} reachable, {cg_import} import-traced, {cg_unreach} unreachable"
    )
    return findings


def normalize_cves(raw_files: Dict[str, Any], scan_dir: Path = None, call_graph: Dict = None) -> Dict[str, List[Dict]]:
    """
    Normalize CVEs from reachable-report.json(.gz).

    The report has 'reachable' and 'unreachable' dicts, each keyed by
    vuln ID (CVE-xxx or GHSA-xxx).

    Args:
        raw_files: {'reachable-report.json.gz': <loaded report data>}

    Returns:
        {'cve': [list of normalized finding dicts]}
    """
    # Accept any filename variant
    report_data = (
        raw_files.get("cve-analyzed.json")
        or raw_files.get("reachable-report.json.gz")
        or raw_files.get("reachable-report.json")
    )
    if not report_data:
        return {"cve": []}

    # T-CG2: shared merged+order so paths accumulate across reachable/unreachable sections
    seen_keys: set = set()
    shared_merged = {}
    shared_order = []

    reachable = report_data.get("reachable", {})
    _process_cve_section(reachable, "REACHABLE", seen_keys, shared_merged, shared_order)

    unreachable = report_data.get("unreachable", {})
    _process_cve_section(unreachable, "NOT_REACHABLE", seen_keys, shared_merged, shared_order)

    findings = [shared_merged[k] for k in shared_order]

    # Ensure each finding has shortest path as primary
    for f in findings:
        all_p = f.get("reachability_paths", [])
        if all_p:
            shortest = min(all_p, key=len)
            f["reachability_path"] = shortest
            if not f.get("call_paths_v2"):
                f["call_paths_v2"] = [shortest] if shortest else []

    # T-CG14: Apply npm dev/runtime split
    npm_dep_map = _build_npm_dep_map(scan_dir)
    if npm_dep_map:
        for f in findings:
            pkg = f.get("package", "")
            dep_type = npm_dep_map.get(pkg)
            if dep_type:
                f["npm_dep_type"] = dep_type
                if dep_type == "dev":
                    # devDependencies never run in production
                    f["app_reachability"] = "NOT_REACHABLE"
                    f["reachability_reason"] = "dev_dependency"
                    f["reachability_confidence"] = "HIGH"

    # T-CG15: Apply JS/TS callgraph reachability (Joern or ts-morph)
    if scan_dir:
        cg_file = Path(scan_dir) / "raw" / "call-graph-js.json"
        if cg_file.exists():
            findings = _enrich_npm_cve_reachability(findings, cg_file, npm_dep_map)

    # BUG-SEC-01 FIX: Recalculate risk_level after T-CG14/T-CG15 enrichment.
    # risk_level was set in _process_cve_section using the initial default_reachability,
    # but T-CG14 (dev dep) and T-CG15 (JS callgraph) can change app_reachability afterward.
    # A CVE downgraded to NOT_REACHABLE must also have its risk_level downgraded.
    for f in findings:
        sev = f.get("severity", "MEDIUM")
        reach = f.get("app_reachability", "UNKNOWN")
        f["risk_level"] = _calculate_risk_level(
            sev,
            reach,
            bool(f.get("is_kev")),
            float(f.get("epss_score") or 0.0),
        )

    multi = sum(1 for f in findings if len(f.get("reachability_paths", [])) > 1)
    dev_count = sum(1 for f in findings if f.get("npm_dep_type") == "dev")
    logger.info(
        f"Normalized {len(findings)} CVEs from report "
        f"({len(reachable)} reachable, {len(unreachable)} unreachable)"
        + (f", {multi} with multiple paths" if multi else "")
        + (f", {dev_count} dev-only (NOT_REACHABLE)" if dev_count else "")
    )
    return {"cve": findings}
