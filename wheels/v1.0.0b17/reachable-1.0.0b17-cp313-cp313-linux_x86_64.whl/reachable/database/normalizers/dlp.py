#!/usr/bin/env python3
# Copyright (c) 2026 Sthenos Security. All rights reserved.

"""
v5.1.3 DLP/PII Normalizer

Reads: raw/dlp-security.json
Produces: dlp_findings (stored in dlp_findings table, not findings table)

Handles PII discovery, taint flow, and AI-related data exposure findings.
"""

import logging
from pathlib import Path
from typing import Any, Dict, List, Optional

from reachable.database.normalizers.compliance_tags import get_compliance_mapping

logger = logging.getLogger(__name__)

# ════════════════════════════════════════════════════════════════════════════
# T-AI4: AI + DLP cross-signal bridge
# ════════════════════════════════════════════════════════════════════════════

# Sink types that indicate a DLP finding is flowing into an LLM
_LLM_SINK_TYPES = frozenset(
    {
        "llm_api",
        "llm_prompt",
        "llm_embedding",
        "llm_api_call",
        # canonical values from dlp/taint/sinks.py
        "LLM_API",
        "LLM_PROMPT",
        "LLM_EMBEDDING",
    }
)

# OWASP categories most relevant for PII-in-LLM (Sensitive Information Disclosure)
_LLM_PII_OWASP = frozenset({"LLM02", "LLM06", "LLM07"})


def _get(obj: Any, *keys: str, default: Any = None) -> Any:
    """Read an attribute from an object or dict, trying each key in order."""
    for key in keys:
        if isinstance(obj, dict):
            if key in obj:
                return obj[key]
        else:
            if hasattr(obj, key):
                val = getattr(obj, key)
                if val is not None:
                    return val
    return default


def _set(obj: Any, key: str, value: Any) -> None:
    """Set an attribute on an object or dict."""
    if isinstance(obj, dict):
        obj[key] = value
    else:
        setattr(obj, key, value)


def link_dlp_to_ai_findings(
    dlp_findings: List[Any],
    ai_findings: List[Any],
    proximity_lines: int = 50,
) -> List[Any]:
    """
    T-AI4: Cross-signal bridge — link DLP findings that flow into LLM sinks
    with co-located AI security findings.

    When a DLP finding has ``sink_type`` in LLM sink types, it represents PII
    flowing into an LLM call.  This simultaneously:
      - Is a DLP finding (LLM_API sink, PII exfiltration)
      - Is an AI LLM02/LLM06 finding (Sensitive Information Disclosure)

    The combined risk is higher than either signal alone.

    For each DLP finding with an LLM sink:
    1. Find the closest AI finding in the same file within ``proximity_lines``.
    2. Set ``related_ai_finding`` on the DLP finding (ID or object reference).
    3. Set ``combined_risk`` = max(dlp_risk, ai_risk_normalised) * compound_factor.
       compound_factor = 1.25 (25% uplift for dual-signal confirmation).

    Works on both real AIFinding/DLPFinding objects and plain dicts / MagicMocks.

    Parameters
    ----------
    dlp_findings     Output of normalize_dlp() or raw DLPFinding objects.
    ai_findings      Output of normalize_ai() or raw AIFinding objects.
    proximity_lines  Max line-distance for co-location match (default 50).

    Returns
    -------
    The same ``dlp_findings`` list, with ``related_ai_finding`` and
    ``combined_risk`` set on qualifying entries.
    """
    if not dlp_findings or not ai_findings:
        return dlp_findings

    # Build a lookup index for AI findings: file_path -> [(line_start, finding)]
    ai_index: Dict[str, List[Any]] = {}
    for af in ai_findings:
        fp = _get(af, "file_path", "file", default="")
        if fp:
            ai_index.setdefault(fp, []).append(af)

    linked_count = 0

    for df in dlp_findings:
        sink_type = _get(df, "sink_type", default="")
        if sink_type not in _LLM_SINK_TYPES:
            continue

        dlp_file = _get(df, "file_path", "file", default="")
        dlp_line = int(_get(df, "line_start", "line", default=0) or 0)
        dlp_risk = float(_get(df, "final_risk", "adjusted_risk_score", "base_risk_score", default=0.0))

        # Find the closest AI finding in the same file
        best_ai: Optional[Any] = None
        best_dist = float("inf")

        for af in ai_index.get(dlp_file, []):
            ai_cat = _get(af, "owasp_category", default="")
            ai_line = int(_get(af, "line_start", "line", default=0) or 0)
            dist = abs(ai_line - dlp_line)

            if dist > proximity_lines:
                continue

            # Prefer LLM02/LLM06/LLM07 over generic findings
            score = dist - (100 if ai_cat in _LLM_PII_OWASP else 0)
            if score < best_dist:
                best_dist = score
                best_ai = af

        if best_ai is None:
            continue

        # Link DLP → AI
        ai_id = _get(best_ai, "id", "rule_id", default=id(best_ai))
        _set(df, "related_ai_finding", ai_id)

        # Compute combined risk
        # ai adjusted_risk_score is 0-10; normalise to DLP scale (×20) for comparison
        ai_risk_raw = float(_get(best_ai, "adjusted_risk_score", "base_risk_score", default=0.0))
        ai_risk_normalised = ai_risk_raw * 20.0  # 0-10 → 0-200
        base_combined = max(dlp_risk, ai_risk_normalised)
        combined_risk = base_combined * 1.25  # 25% uplift for dual-signal confirmation
        _set(df, "combined_risk", combined_risk)

        # Also back-link AI → DLP
        dlp_id = _get(df, "id", "rule_id", default=id(df))
        _set(best_ai, "related_dlp_finding", dlp_id)

        linked_count += 1
        logger.debug(
            f"T-AI4 link: DLP({dlp_file}:{dlp_line}, sink={sink_type}) "
            f"↔ AI({_get(best_ai, 'owasp_category', default='?')}) "
            f"combined_risk={combined_risk:.1f}"
        )

    if linked_count:
        logger.info(f"T-AI4: Linked {linked_count} DLP↔AI finding pair(s)")

    return dlp_findings


def normalize_dlp(
    raw_files: Dict[str, Any],
    scan_dir: Path = None,
    call_graph: Dict = None,
    ai_findings: Optional[List[Any]] = None,  # T-AI4: cross-signal bridge
) -> Dict[str, List[Dict]]:
    """
    Normalize DLP/PII findings for dlp_findings table.

    Args:
        raw_files:   {'dlp-security.json': <loaded DLP scanner data>}
        ai_findings: T-AI4 — when provided, LLM-sink DLP findings are
                     linked to co-located AI findings via link_dlp_to_ai_findings().

    Returns:
        {'dlp': [list of DLP finding dicts ready for store_dlp_findings()]}
    """
    dlp_data = raw_files.get("dlp-security.json")
    if not dlp_data:
        return {"dlp": []}

    raw_findings = dlp_data.get("findings", [])
    if not raw_findings:
        return {"dlp": []}

    normalized = []

    for f in raw_findings:
        try:
            file_path = f.get("file_path", f.get("file", ""))
            line_start = f.get("line_start", f.get("line_number", f.get("line", 0)))
            pii_type = f.get("pii_type", "")

            if not file_path or not pii_type:
                logger.debug("Skipping DLP finding: missing file_path or pii_type")
                continue

            if not line_start:
                logger.debug(f"Skipping DLP finding: missing line_start for {file_path}")
                continue

            normalized.append(
                {
                    "rule_id": f.get("rule_id", ""),
                    "finding_type": f.get("finding_type", "pii_discovery"),
                    "pii_type": pii_type,
                    "pii_sample": f.get("pii_sample", ""),
                    "pii_count": f.get("pii_count", 1),
                    "sink_type": f.get("sink_type", ""),
                    "sink_function": f.get("sink_function", ""),
                    "severity": f.get("severity", f.get("adjusted_severity", "MEDIUM")),
                    "base_risk_score": f.get("base_risk_score", f.get("risk_score", 0.0)),
                    "adjusted_risk_score": f.get("adjusted_risk_score", f.get("risk_score", 0.0)),
                    "file_class": f.get("file_class", "source"),
                    "file_class_modifier": f.get("file_class_modifier", 1.0),
                    "is_reachable": f.get("is_reachable", True),
                    "reachability_confidence": f.get("reachability_confidence", "LOW"),
                    # T-CG28 write-deprecated: call_path (v1) not written on new scans
                    "sanitizer_present": f.get("sanitizer_present", False),
                    "sanitizer_type": f.get("sanitizer_type", ""),
                    "sanitizer_effectiveness": f.get("sanitizer_effectiveness", 0.0),
                    "regulations": f.get("regulations", []),
                    "file_path": file_path,
                    "line_start": line_start,
                    "line_end": f.get("line_end", 0),
                    "message": f.get("message", ""),
                    "remediation": f.get("remediation", ""),
                    "detection_source": f.get("detection_source", "pattern"),
                    "confidence": f.get("confidence", 0.8),
                    # COMP-01 FIX: compliance tags for DLP/PII findings
                    "compliance_mapping": get_compliance_mapping("dlp", f.get("compliance_mapping") or {}),
                }
            )

        except Exception as e:
            logger.warning(f"Error normalizing DLP finding: {e}")
            continue

    logger.info(f"Normalized {len(normalized)} DLP findings from {len(raw_findings)} raw")

    # T-AI4: link LLM-sink DLP findings to co-located AI findings
    if ai_findings:
        try:
            link_dlp_to_ai_findings(normalized, ai_findings)
        except Exception as _link_err:
            logger.debug(f"T-AI4 cross-signal link skipped: {_link_err}")

    return {"dlp": normalized}
