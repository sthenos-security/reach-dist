#!/usr/bin/env python3
# Copyright (c) 2026 Sthenos Security. All rights reserved.

"""
COMP-01 FIX: Compliance mapping for all finding types.

Previously compliance tags were only populated for DLP findings. This module
provides `get_compliance_mapping()` which all normalizers call to ensure
CVE, CWE, SECRET, MALWARE, and AI findings also carry a compliance_mapping
field in the DB.

Mapping logic:
  - Each finding type maps to a canonical set of compliance controls.
  - Controls are derived from the OWASP, NIST, FedRAMP, CMMC, SOC2,
    ISO 27001, GDPR, NIS2, DORA control catalogs in reachable/compliance/.
  - An existing compliance_mapping dict (from the scanner or earlier enrichment)
    is merged with the generated mapping — scanner-provided tags take precedence.
"""

from typing import Any, Dict

# ---------------------------------------------------------------------------
# Base compliance mappings by finding type
# ---------------------------------------------------------------------------

# OWASP Top 10:2021 — not LLM; standard web app OWASP categories
_OWASP_TOP10_A03 = "OWASP A03:2021"
_OWASP_TOP10_A06 = "OWASP A06:2021"
_OWASP_TOP10_A08 = "OWASP A08:2021"
_OWASP_TOP10_A09 = "OWASP A09:2021"

# NIST 800-53 controls
_NIST_RA5 = "NIST RA-5"
_NIST_SI2 = "NIST SI-2"
_NIST_SI3 = "NIST SI-3"
_NIST_SI7 = "NIST SI-7"
_NIST_SA11 = "NIST SA-11"
_NIST_SA15 = "NIST SA-15"
_NIST_SC7 = "NIST SC-7"
_NIST_AC4 = "NIST AC-4"
_NIST_SC13 = "NIST SC-13"
_NIST_SR3 = "NIST SR-3"
_NIST_SR4 = "NIST SR-4"

# FedRAMP (maps to same NIST 800-53 controls)
_FEDRAMP_RA5 = "FedRAMP RA-5"
_FEDRAMP_SI2 = "FedRAMP SI-2"
_FEDRAMP_SI3 = "FedRAMP SI-3"
_FEDRAMP_SI7 = "FedRAMP SI-7"
_FEDRAMP_SC7 = "FedRAMP SC-7"
_FEDRAMP_SC13 = "FedRAMP SC-13"
_FEDRAMP_SR3 = "FedRAMP SR-3"
_FEDRAMP_SR4 = "FedRAMP SR-4"

# CMMC 2.0 (DoD)
_CMMC_RM_2_1_3 = "CMMC RM.L2-3.11.2"
_CMMC_SI_1_1_1 = "CMMC SI.L1-3.14.1"
_CMMC_SI_2_1_2 = "CMMC SI.L2-3.14.2"
_CMMC_SR_L2 = "CMMC SR.L2-3.17.1"
_CMMC_CM_L2 = "CMMC CM.L2-3.4.1"
_CMMC_AC_L2 = "CMMC AC.L2-3.1.3"
_CMMC_SC_L2_13 = "CMMC SC.L2-3.13.1"

# SOC2 Trust Services Criteria
_SOC2_CC61 = "SOC2 CC6.1"
_SOC2_CC67 = "SOC2 CC6.7"
_SOC2_CC71 = "SOC2 CC7.1"
_SOC2_CC74 = "SOC2 CC7.4"
_SOC2_CC81 = "SOC2 CC8.1"
_SOC2_CC92 = "SOC2 CC9.2"

# ISO 27001:2022
_ISO_A88 = "ISO 27001 A.8.8"
_ISO_A828 = "ISO 27001 A.8.28"
_ISO_A823 = "ISO 27001 A.5.23"
_ISO_A825 = "ISO 27001 A.8.25"

# GDPR
_GDPR_ART32 = "GDPR Art.32"
_GDPR_ART5 = "GDPR Art.5.1(f)"
_GDPR_ART25 = "GDPR Art.25"

# NIS2
_NIS2_ART21D = "NIS2 Art.21(2)(d)"
_NIS2_ART21E = "NIS2 Art.21(2)(e)"

# DORA
_DORA_ART10 = "DORA Art.10"
_DORA_ART28 = "DORA Art.28"

# OWASP LLM (for AI findings)
_OWASP_LLM_TOP10 = "OWASP LLM Top 10"

# SSDF (NIST SP 800-218)
_SSDF_PW41 = "SSDF PW.4.1"
_SSDF_PS11 = "SSDF PS.1.1"
_SSDF_RV11 = "SSDF RV.1.1"

# STRIDE Threat Model
_STRIDE_S1 = "STRIDE S-1"  # Package Identity Verification (Spoofing)
_STRIDE_S2 = "STRIDE S-2"  # Typosquatting Detection
_STRIDE_T1 = "STRIDE T-1"  # Code Integrity Verification (Tampering)
_STRIDE_T2 = "STRIDE T-2"  # Dependency Integrity
_STRIDE_I1 = "STRIDE I-1"  # Sensitive Data in Code (Info Disclosure)
_STRIDE_I2 = "STRIDE I-2"  # Data Leakage Prevention
_STRIDE_I3 = "STRIDE I-3"  # Excessive Information Exposure
_STRIDE_D1 = "STRIDE D-1"  # Resource Exhaustion (Denial of Service)
_STRIDE_E1 = "STRIDE E-1"  # Privilege Escalation via Vulns
_STRIDE_E2 = "STRIDE E-2"  # Code Execution
_STRIDE_E3 = "STRIDE E-3"  # Supply Chain Compromise
_STRIDE_R1 = "STRIDE R-1"  # Audit Trail Integrity (Repudiation)


def _base_for_type(finding_type: str) -> Dict[str, Any]:
    """Return the base compliance mapping for a given finding type."""
    ft = (finding_type or "").lower()

    if ft in ("cve", "ghsa", "vulnerability"):
        return {
            "OWASP": _OWASP_TOP10_A06,
            "NIST": [_NIST_RA5, _NIST_SI2],
            "FedRAMP": [_FEDRAMP_RA5, _FEDRAMP_SI2],
            "CMMC": _CMMC_RM_2_1_3,
            "SOC2": [_SOC2_CC71, _SOC2_CC74],
            "ISO27001": _ISO_A88,
            "SSDF": [_SSDF_PW41, _SSDF_RV11],
            "GDPR": _GDPR_ART32,
            "NIS2": _NIS2_ART21E,
            "DORA": _DORA_ART10,
            "STRIDE": [_STRIDE_T1, _STRIDE_E1],
        }

    elif ft in ("cwe", "code", "sast", "iac", "config"):
        return {
            "OWASP": _OWASP_TOP10_A03,
            "NIST": [_NIST_SA11, _NIST_SA15],
            "FedRAMP": _FEDRAMP_SI2,
            "CMMC": _CMMC_CM_L2,
            "SOC2": _SOC2_CC81,
            "ISO27001": [_ISO_A825, _ISO_A828],
            "SSDF": _SSDF_PW41,
            "GDPR": _GDPR_ART32,
            "NIS2": _NIS2_ART21E,
            "STRIDE": [_STRIDE_T1, _STRIDE_E2, _STRIDE_I1],
        }

    elif ft == "secret":
        return {
            "OWASP": _OWASP_TOP10_A09,
            "NIST": [_NIST_SC13, _NIST_SI7],
            "FedRAMP": [_FEDRAMP_SC13, _FEDRAMP_SI7],
            "CMMC": _CMMC_SC_L2_13,
            "SOC2": [_SOC2_CC67, _SOC2_CC61],
            "ISO27001": _ISO_A828,
            "SSDF": _SSDF_PW41,
            "GDPR": [_GDPR_ART32, _GDPR_ART5, _GDPR_ART25],
            "NIS2": _NIS2_ART21E,
            "STRIDE": [_STRIDE_S1, _STRIDE_I1, _STRIDE_I2],
        }

    elif ft in ("malware", "suspicious"):
        return {
            "OWASP": _OWASP_TOP10_A08,
            "NIST": [_NIST_SI3, _NIST_SR3, _NIST_SR4],
            "FedRAMP": [_FEDRAMP_SI3, _FEDRAMP_SR3, _FEDRAMP_SR4],
            "CMMC": [_CMMC_SI_1_1_1, _CMMC_SR_L2],
            "SOC2": [_SOC2_CC71, _SOC2_CC92],
            "ISO27001": [_ISO_A88, _ISO_A823],
            "SSDF": [_SSDF_PS11, _SSDF_RV11],
            "GDPR": _GDPR_ART32,
            "NIS2": _NIS2_ART21D,
            "DORA": _DORA_ART28,
            "STRIDE": [_STRIDE_T1, _STRIDE_T2, _STRIDE_E3],
        }

    elif ft in ("ai", "ai_security", "llm"):
        return {
            "OWASP_LLM": _OWASP_LLM_TOP10,
            "NIST": [_NIST_SA11, _NIST_SA15],
            "FedRAMP": _FEDRAMP_SI2,
            "CMMC": _CMMC_CM_L2,
            "SOC2": _SOC2_CC81,
            "ISO27001": _ISO_A825,
            "GDPR": [_GDPR_ART32, _GDPR_ART25],
            "NIS2": _NIS2_ART21E,
            "STRIDE": [_STRIDE_S1, _STRIDE_T1, _STRIDE_I3, _STRIDE_E2],
        }

    elif ft in ("dlp", "pii"):
        return {
            "OWASP_LLM": "OWASP LLM02",
            "NIST": [_NIST_AC4, _NIST_SC7],
            "FedRAMP": [_FEDRAMP_SC7],
            "CMMC": [_CMMC_AC_L2, _CMMC_SC_L2_13],
            "SOC2": [_SOC2_CC67],
            "ISO27001": _ISO_A88,
            "GDPR": [_GDPR_ART32, _GDPR_ART5, _GDPR_ART25],
            "NIS2": _NIS2_ART21E,
            "STRIDE": [_STRIDE_I1, _STRIDE_I2, _STRIDE_R1],
        }

    # Unknown/fallback
    return {
        "NIST": _NIST_RA5,
        "FedRAMP": _FEDRAMP_RA5,
        "SOC2": _SOC2_CC71,
    }


def get_compliance_mapping(
    finding_type: str,
    existing_mapping: Dict[str, Any] = None,
) -> Dict[str, Any]:
    """
    Return a compliance mapping dict for a given finding type.

    Merges scanner-provided tags (if any) with the canonical base mapping.
    Scanner-provided tags take precedence for any key that exists in both.

    Args:
        finding_type:    One of cve, cwe, secret, malware, ai, dlp, config.
        existing_mapping: Dict already populated by the scanner or DLP engine.

    Returns:
        A merged compliance mapping dict ready for storage in the DB.
    """
    base = _base_for_type(finding_type)

    if not existing_mapping:
        return base

    # Merge: base provides defaults; existing_mapping overrides
    merged = dict(base)
    merged.update(existing_mapping)
    return merged
