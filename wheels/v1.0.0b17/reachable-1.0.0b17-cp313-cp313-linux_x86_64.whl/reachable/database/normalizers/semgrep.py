#!/usr/bin/env python3
# Copyright (c) 2026 Sthenos Security. All rights reserved.

"""
v5.1.3 Semgrep Normalizer

Reads: raw/security-findings.json
Produces: findings (type=cwe), findings (type=secret), findings (type=config)

This normalizer handles the CRITICAL reclassification logic that was previously
scattered across scan.py, storage.py, and cwe_reachability.py:

  1. Config file findings -> type=config (NOT cwe)
  2. Actual secrets (is_actual_secret=True) -> type=secret
  3. Config rule patterns (dockerfile.*, kubernetes.*) -> type=config
  4. Everything else -> type=cwe

Reachability defaults:
  - Config findings -> UNKNOWN (always)
  - Config rule patterns -> UNKNOWN (always)
  - Secrets with confirmed loaders -> REACHABLE
  - Secrets without loaders -> UNKNOWN
  - CWE with is_reachable=True -> REACHABLE
  - CWE with is_reachable=False -> NOT_REACHABLE
  - CWE unanalyzed -> UNKNOWN

T-CG8:  CWE findings get containing function + entrypoint BFS trace.
T-CG9:  Secret Level 1 — file-read confirmation via repo scan.
T-CG12: Secret Level 2 — transformer pattern detection.
T-CG13: Secret Level 3 — sink pattern detection, cross-function.
"""

import hashlib
import json
import logging
import os
import re
from pathlib import Path
from typing import Any, Dict, List, Optional

from reachable.database.normalizers.compliance_tags import get_compliance_mapping
from reachable.engine.hop_registry import HopPosition, PathNode, classify_hop

logger = logging.getLogger(__name__)


def _call_path_nodes_to_v2(call_path: list, finding_type: str) -> list:
    """T-CG10: Convert [{function, file, line}] call_path dicts to PathNode wire format.

    First and last nodes get positional classification; middle nodes use HCR.
    Returns List[dict] ready for JSON serialisation into call_paths_v2.
    """
    if not call_path:
        return []
    n = len(call_path)
    result = []
    for i, node in enumerate(call_path):
        label = node.get("function") or node.get("name") or ""
        if not label:
            continue
        if i == 0:
            pos = HopPosition.FIRST
        elif i == n - 1:
            pos = HopPosition.LAST
        else:
            pos = HopPosition.MIDDLE
        decision = classify_hop(label, finding_type, pos)
        pn = PathNode(
            label=label,
            kind=decision.kind,
            file=node.get("file") or "",
            line=node.get("line") or 0,
        )
        result.append(pn.to_dict())
    return result


# File extension classification
CONFIG_EXTENSIONS = (
    ".yaml",
    ".yml",
    ".json",
    ".tf",
    ".hcl",
    ".toml",
    ".ini",
    ".cfg",
    ".conf",
    ".env",
    ".properties",
)

# SCAN-01 FIX: Documentation file extensions — never produce code findings
DOC_EXTENSIONS = (
    ".md",
    ".markdown",
    ".rst",
    ".txt",
    ".adoc",
    ".asciidoc",
    ".html",
    ".htm",
    ".pdf",
    ".docx",
    ".tex",
)
DOC_PATH_PATTERNS = (
    "/docs/",
    "/doc/",
    "/documentation/",
    "/changelog",
    "/readme",
    "/license",
    "/contributing",
    "/history",
    "/release",
    "/notes/",
    "/wiki/",
)
CONFIG_PATTERNS = (
    "dockerfile",
    "docker-compose",
    ".github/",
    ".gitlab-ci",
    "jenkinsfile",
    "makefile",
    ".circleci/",
)
CODE_EXTENSIONS = (
    ".go",
    ".py",
    ".js",
    ".ts",
    ".java",
    ".rb",
    ".rs",
    ".c",
    ".cpp",
    ".cs",
    ".php",
    ".swift",
    ".kt",
    ".tsx",
    ".jsx",
)

# Semgrep rule ID patterns that indicate config issues (not code bugs)
CONFIG_RULE_PATTERNS = [
    "dockerfile.",
    "docker-compose.",
    "kubernetes.",
    "k8s.",
    "terraform.",
    "cloudformation.",
    "helm.",
    "yaml.",
    "cicd.",
    "github-actions.",
    "gitlab-ci.",
    "jenkins.",
    "security-headers",
    "cors.",
    "ssl.",
    "tls.",
]

# Semgrep rule ID patterns that indicate secret detection
SECRET_RULE_PATTERNS = [
    "generic.secrets",
    "secrets.",
    "leaked-",
    "hardcoded-",
    "api-key",
    "password",
    "token",
    "credential",
    "access_key",
    "secret_key",
    "encryption_key",
]

SEVERITY_MAP = {
    "ERROR": "CRITICAL",
    "WARNING": "MEDIUM",
    "INFO": "LOW",
    "CRITICAL": "CRITICAL",
    "HIGH": "HIGH",
    "MEDIUM": "MEDIUM",
    "LOW": "LOW",
}

IAC_SEVERITY_MAP = {
    "privileged": "HIGH",
    "allow-privilege-escalation": "HIGH",
    "hostnetwork": "HIGH",
    "hostpid": "HIGH",
    "host-ipc": "HIGH",
    "host-network": "HIGH",
    "capabilities-added": "HIGH",
    "s3-bucket-public": "CRITICAL",
    "public-bucket": "CRITICAL",
    "public-access": "CRITICAL",
    "open-to-world": "CRITICAL",
    "open-cidr": "CRITICAL",
    "exposed-service": "HIGH",
    "loadbalancer": "HIGH",
    "missing-user": "LOW",
    "hardcoded-secret": "CRITICAL",
    "cloud_access_key": "CRITICAL",
    "cloud_secret_key": "CRITICAL",
    "generic_secret": "CRITICAL",
    "run-as-non-root": "MEDIUM",
    "run-as-root": "MEDIUM",
    "runasnonroot": "MEDIUM",
    "read-only-filesystem": "MEDIUM",
    "readonly-rootfs": "MEDIUM",
    "seccomp": "MEDIUM",
    "apparmor": "MEDIUM",
    "drop-capabilities": "MEDIUM",
    "missing-network-policy": "MEDIUM",
    "resource-limit": "LOW",
    "memory-limit": "LOW",
    "cpu-limit": "LOW",
    "liveness-probe": "LOW",
    "readiness-probe": "LOW",
    "health-check": "LOW",
    "latest-tag": "LOW",
    "image-tag": "LOW",
}


def _iac_severity(rule_id: str, raw_severity: str) -> str:
    rule_lower = rule_id.lower()
    for pattern, severity in IAC_SEVERITY_MAP.items():
        if pattern in rule_lower:
            return severity
    fallback = {
        "ERROR": "HIGH",
        "WARNING": "MEDIUM",
        "INFO": "LOW",
        "CRITICAL": "HIGH",
        "HIGH": "HIGH",
        "MEDIUM": "MEDIUM",
        "LOW": "LOW",
    }
    return fallback.get(raw_severity, "MEDIUM")


def _is_doc_file(filepath: str) -> bool:
    """SCAN-01: Return True if filepath is a documentation/text file, not source code."""
    if not filepath:
        return False
    fp_lower = filepath.lower()
    if any(fp_lower.endswith(ext) for ext in DOC_EXTENSIONS):
        return True
    if any(pattern in fp_lower for pattern in DOC_PATH_PATTERNS):
        return True
    # Common doc file names
    basename = fp_lower.split("/")[-1]
    if basename in (
        "changelog",
        "readme",
        "license",
        "contributing",
        "history",
        "authors",
        "notice",
        "todo",
        "fixme",
    ):
        return True
    return False


def _is_config_file(filepath: str) -> bool:
    if not filepath:
        return False
    filepath_lower = filepath.lower()
    if any(filepath_lower.endswith(ext) for ext in CODE_EXTENSIONS):
        return False
    if any(filepath_lower.endswith(ext) for ext in CONFIG_EXTENSIONS):
        return True
    if any(pattern in filepath_lower for pattern in CONFIG_PATTERNS):
        return True
    return False


def _is_config_rule(rule_id: str) -> bool:
    rule_lower = rule_id.lower()
    return any(pattern in rule_lower for pattern in CONFIG_RULE_PATTERNS)


def _is_secret_rule(rule_id: str) -> bool:
    rule_lower = rule_id.lower()
    return any(pattern in rule_lower for pattern in SECRET_RULE_PATTERNS)


def _classify_finding(finding: Dict, filepath: str, rule_id: str) -> str:
    if finding.get("is_actual_secret"):
        return "secret"
    if _is_secret_rule(rule_id):
        return "secret"
    msg = (finding.get("message") or finding.get("extra", {}).get("message", "") or "").lower()
    if msg.startswith("secret detected:"):
        return "secret"
    if _is_config_file(filepath):
        return "config"
    if _is_config_rule(rule_id):
        return "config"
    return "cwe"


def _determine_reachability(finding: Dict, finding_type: str, filepath: str) -> str:
    if finding_type == "config":
        return "NOT_APPLICABLE"
    if finding_type == "secret":
        confidence = finding.get("reachability_confidence", "").upper()
        reachable_via = finding.get("reachable_via", [])
        if confidence == "CONFIRMED" and reachable_via:
            return "REACHABLE"
        reach = finding.get("reachability", "").lower()
        if reach == "reachable":
            return "REACHABLE"
        if reach in ("not_reachable", "unreachable"):
            return "NOT_REACHABLE"
        return "UNKNOWN"
    if _is_config_file(filepath):
        return "UNKNOWN"
    if _is_config_rule(finding.get("rule_id", "")):
        return "UNKNOWN"
    is_reach = finding.get("is_reachable")
    if is_reach is True:
        return "REACHABLE"
    elif is_reach is False:
        return "NOT_REACHABLE"
    return "UNKNOWN"


def _is_pattern_definition_fp(finding: Dict) -> bool:
    filepath = (finding.get("path", "") or finding.get("file", "") or finding.get("file_path", "")).lower()

    _REACHABLE_TOOL_PATHS = (
        "secrets/env.py",
        "secrets/enhanced.py",
        "secrets/loader.py",
        "secrets/validator.py",
        "secrets/entropy.py",
        "malware/yara_rules.py",
        "malware/yara.py",
        "taint/sources.py",
        "taint/sinks.py",
        "dlp/rules/",
        "conf/semgrep/",
    )
    if filepath and any(p in filepath for p in _REACHABLE_TOOL_PATHS):
        return True

    _SECURITY_TOOL_INDICATORS = (
        "secret_hunt",
        "secret_scan",
        "secretscan",
        "trufflehog",
        "gitleaks",
        "detect_secret",
        "credential_scan",
        "leak_detect",
        "token_scan",
        "recon/",
        "scanner/",
        "hunting/",
    )
    if filepath and any(ind in filepath for ind in _SECURITY_TOOL_INDICATORS):
        return True

    snippet = (
        finding.get("extra", {}).get("lines", "")
        or finding.get("code_snippet", "")
        or finding.get("extra", {}).get("line", "")
        or ""
    )

    if not snippet:
        line_num = finding.get("start", {}).get("line", finding.get("line", 0))
        src_path = filepath
        if src_path and line_num:
            try:
                with open(src_path, errors="replace") as f:
                    for i, line in enumerate(f, 1):
                        if i == line_num:
                            snippet = line
                            break
            except (OSError, IOError):
                pass

    if not snippet:
        return False

    if re.search(r"""r["']-----BEGIN\s*\w+""", snippet):
        return True
    if "-----BEGIN" in snippet and ('r"' in snippet or "r'" in snippet):
        return True
    if re.search(r"""["'][^"']*(?:Private|Secret)\s*Key[^"']*["']\s*[,:)]""", snippet):
        if re.search(r"""r["']""", snippet):
            return True
    if re.search(r"(?:PATTERNS|RULES|SIGNATURES)\s*[=\[{]", snippet, re.IGNORECASE):
        return True
    return False


_PURE_ENV_VAR_RE = re.compile(r"\$\{[A-Za-z_]\w*(?::\+[^}]*)?\}")
_ANY_ENV_INTERPOLATION_RE = re.compile(r"\$\{[A-Za-z_]\w*(?:[:#][+-]?[^}]*)?\}")
_ENV_WITH_DEFAULT_RE = re.compile(r"\$\{[A-Za-z_]\w*[:-]-[^}]+\}")
_DB_URL_RE = re.compile(r"(?:postgres(?:ql)?|mysql|mongodb|redis)://")
_LOCAL_HOST_RE = re.compile(
    r"@(?:localhost|127\.0\.0\.1|postgres|db|mysql|mongo|redis|" r"host\.docker\.internal|[a-z][a-z0-9_-]*):"
)
_WEAK_DEFAULTS = re.compile(
    r":-(?:changeme|password|secret|admin|dev|test|example|redamon|"
    r"postgres|mysql|mongo|root|default|sample|demo|placeholder|"
    r"[a-z_]{1,20}(?:_secret|_password|_pass|_pw|123|1234))\}",
    re.IGNORECASE,
)


def _is_templated_dev_secret(finding: Dict, filepath: str) -> bool:
    if "docker-compose" not in filepath.lower():
        return False
    snippet = (
        finding.get("extra", {}).get("lines", "")
        or finding.get("code_snippet", "")
        or finding.get("extra", {}).get("line", "")
        or ""
    )
    if not snippet:
        line_num = finding.get("start", {}).get("line", finding.get("line", 0))
        src_path = filepath
        if src_path and line_num:
            try:
                with open(src_path, errors="replace") as f:
                    for i, line in enumerate(f, 1):
                        if i == line_num:
                            snippet = line
                            break
            except (OSError, IOError):
                pass
    if not snippet:
        return False
    has_interpolation = bool(_ANY_ENV_INTERPOLATION_RE.search(snippet))
    has_default = bool(_ENV_WITH_DEFAULT_RE.search(snippet))
    host_local = bool(_LOCAL_HOST_RE.search(snippet))
    weak_default = bool(_WEAK_DEFAULTS.search(snippet))
    return has_interpolation and has_default and host_local and weak_default


def _has_env_interpolation(finding: Dict, filepath: str) -> bool:
    if not any(filepath.lower().endswith(ext) for ext in (".yml", ".yaml", ".env", ".json", ".toml", ".properties")):
        return False
    snippet = (
        finding.get("extra", {}).get("lines", "")
        or finding.get("code_snippet", "")
        or finding.get("extra", {}).get("line", "")
        or ""
    )
    if not snippet:
        line_num = finding.get("start", {}).get("line", finding.get("line", 0))
        src_path = filepath
        if src_path and line_num:
            try:
                with open(src_path, errors="replace") as f:
                    for i, line in enumerate(f, 1):
                        if i == line_num:
                            snippet = line
                            break
            except (OSError, IOError):
                pass
    if not snippet:
        return False
    if _ENV_WITH_DEFAULT_RE.search(snippet):
        return False
    return bool(_ANY_ENV_INTERPOLATION_RE.search(snippet))


# ════════════════════════════════════════════════════════════════════════════
# T-CG9: Secret Level 1 — file-read confirmation
# T-CG8: CWE containing-function + entrypoint BFS
# T-CG12/13: Secret Level 2-3 — transformer + sink chain
# ════════════════════════════════════════════════════════════════════════════

# Go/Python file-read patterns (Level 1)
_FILE_READ_PATTERNS = [
    # Standard Go file reads
    re.compile(r"""os\.ReadFile\(['"]([^'"]+)['"]\)"""),
    re.compile(r"""ioutil\.ReadFile\(['"]([^'"]+)['"]\)"""),
    re.compile(r"""os\.Open\(['"]([^'"]+)['"]\)"""),
    # Viper config loader (SetConfigFile takes explicit path; SetConfigName is basename-only)
    re.compile(r"""viper\.SetConfigFile\(['"]([^'"]+)['"]\)"""),
    re.compile(r"""config\.LoadFile\(['"]([^'"]+)['"]\)"""),
    # T-CG29 FIX: godotenv — the most common Go .env loader; was missing, causing
    # confirmed-REACHABLE secrets in .env.dev (and similar) to be downgraded to
    # NOT_REACHABLE by _check_file_is_read() because it didn't recognise the loader.
    re.compile(r"""godotenv\.Load\([^)]*['"]([^'"]+)['"][^)]*\)"""),
    re.compile(r"""godotenv\.Overload\([^)]*['"]([^'"]+)['"][^)]*\)"""),
    re.compile(r"""godotenv\.Read\(['"]([^'"]+)['"]\)"""),
    re.compile(r"""godotenv\.NewReader\([^)]*['"]([^'"]+)['"]"""),
    # Python / Node dotenv loaders
    re.compile(r"""load_dotenv\(['"]([^'"]+)['"]\)"""),
    re.compile(r"""dotenv\.config\(\{[^}]*path:\s*['"]([^'"]+)['"]"""),
    # Generic Python open()
    re.compile(r"""open\(['"]([^'"]+)['"][^)]*\)"""),
    re.compile(r"""Path\(['"]([^'"]+)['"]\)\.read_text"""),
]

# Transformer patterns (Level 2)
_TRANSFORMER_PATTERNS = [
    (re.compile(r"yaml\.Unmarshal|yaml\.NewDecoder"), "yaml.Unmarshal()"),
    (re.compile(r"json\.Unmarshal|json\.NewDecoder"), "json.Unmarshal()"),
    (re.compile(r"toml\.Decode"), "toml.Decode()"),
    (re.compile(r"viper\.Get|viper\.GetString"), "viper.Get()"),
    (re.compile(r"pem\.Decode"), "pem.Decode()"),
    (re.compile(r"x509\.ParseCertificate"), "x509.ParseCertificate()"),
    (re.compile(r"base64\.Decode"), "base64.Decode()"),
    (re.compile(r"yaml\.safe_load|yaml\.load\("), "yaml.safe_load()"),
    (re.compile(r"json\.loads\("), "json.loads()"),
    (re.compile(r"configparser\."), "configparser.read()"),
]

# Secret sink patterns (Level 3)
_SECRET_SINK_PATTERNS = [
    (re.compile(r"req\.Header\.Set.*Authorization|SetAuthHeader|Authorization.*Bearer"), "http auth header"),
    (re.compile(r"sql\.Open|gorm\.Open|pgx\.Connect"), "database connection"),
    (re.compile(r"redis\.NewClient|redis\.Connect"), "redis connection"),
    (re.compile(r"hmac\.New|aes\.NewCipher|des\.NewCipher"), "crypto key"),
    (re.compile(r"tls\.X509KeyPair|tls\.LoadX509|x509\.ParseCertificate"), "TLS credential"),
    (re.compile(r"jwt\.Parse|jwt\.Sign|jwt\.NewWithClaims"), "JWT signing"),
    (re.compile(r"credentials\.NewStaticCredentials|aws\.NewConfig"), "AWS credentials"),
    (re.compile(r"ssh\.NewPublicKeys|ssh\.ParseRawPrivateKey"), "SSH credential"),
    (re.compile(r"grpc\.WithTransportCredentials"), "gRPC credential"),
    (re.compile(r"smtp\.PlainAuth|smtp\.SendMail"), "SMTP auth"),
    (re.compile(r"create_engine|psycopg2\.connect|sqlite3\.connect"), "database connection"),
    (re.compile(r"cryptography\.hazmat|Fernet\(|AES\.new"), "crypto key"),
]

# HTTP entrypoint patterns for CWE BFS
_ENTRYPOINT_PATTERNS = [
    re.compile(r"Handle[A-Z]|[A-Z][a-z]+Handler$"),
    re.compile(r"^main$|^init$"),
    re.compile(r"ServeHTTP|HandleFunc"),
    re.compile(r"Router\b|Server\b|Mux\b"),
]


def _check_file_is_read(secret_file_path: str, repo_path: str) -> bool:
    """
    T-CG9: Level 1 — return True if any source file in repo reads this secret file.

    Scans .go/.py/.js/.ts files for ReadFile/Open calls referencing the secret
    file's basename. No match → secret should be downgraded to NOT_REACHABLE.

    FIX-REACH-01 (Raw=7 vs DB=124): The previous logic used `secret_stem in read_path`
    which caused massive false positives. For `config.yaml` (stem='config'), any call
    to open('config.json'), open('config.go'), etc. matched, inflating reachable count
    from 7 to 124. Now requires exact basename match or the read_path to be a suffix
    of the full secret file path — precise reference, not substring of stem.
    """
    if not secret_file_path or not repo_path:
        return False
    secret_basename = Path(secret_file_path).name

    try:
        repo = Path(repo_path)
        for ext in ("*.go", "*.py", "*.js", "*.ts"):
            for src_file in repo.rglob(ext):
                if any(
                    skip in str(src_file) for skip in ("vendor/", "node_modules/", "__pycache__/", ".git/", "testdata/")
                ):
                    continue
                try:
                    content = src_file.read_text(encoding="utf-8", errors="ignore")
                    for pattern in _FILE_READ_PATTERNS:
                        for m in pattern.finditer(content):
                            read_path = m.group(1)
                            read_basename = Path(read_path).name
                            # FIX-REACH-01: Require exact basename match or path suffix.
                            # REMOVED: `secret_stem in read_path` — far too broad.
                            # e.g. stem 'config' matches 'app.config.go', 'config.json', etc.
                            if (
                                read_basename == secret_basename  # exact filename
                                or secret_file_path.endswith(read_path)  # full path suffix
                                or read_path.endswith(secret_basename)
                            ):  # read ends with filename
                                return True
                except (OSError, IOError):
                    continue
    except Exception:
        pass
    return False


def _build_secret_chain_level2(secret_file_path: str, repo_path: str, secret_type: str) -> list:
    """
    T-CG12/13: Level 2-3 — source → transformer → sink chain for secrets.

    Finds the file that reads the secret, looks for transformer + sink patterns
    within 20 lines, and returns a chain of {function, file, line} dicts.
    """
    if not secret_file_path or not repo_path:
        return []

    secret_basename = Path(secret_file_path).name
    chain: list = []

    try:
        repo = Path(repo_path)
        for ext in ("*.go", "*.py"):
            for src_file in repo.rglob(ext):
                if any(skip in str(src_file) for skip in ("vendor/", "__pycache__/", ".git/", "testdata/")):
                    continue
                try:
                    content = src_file.read_text(encoding="utf-8", errors="ignore")
                    lines_list = content.split("\n")
                except (OSError, IOError):
                    continue

                read_line_num = None
                for i, ln in enumerate(lines_list, 1):
                    for pattern in _FILE_READ_PATTERNS:
                        m = pattern.search(ln)
                        if m and (secret_basename in m.group(1) or m.group(1) in secret_file_path):
                            read_line_num = i
                            chain.append({"function": ln.strip()[:80], "file": str(src_file), "line": i})
                            break
                    if read_line_num:
                        break

                if not read_line_num:
                    continue

                window = "\n".join(lines_list[max(0, read_line_num - 1) : min(len(lines_list), read_line_num + 20)])
                for t_pat, t_label in _TRANSFORMER_PATTERNS:
                    if t_pat.search(window):
                        chain.append({"function": t_label, "file": str(src_file), "line": read_line_num + 2})
                        break
                for s_pat, s_label in _SECRET_SINK_PATTERNS:
                    if s_pat.search(window):
                        chain.append(
                            {
                                "function": f"{s_label} sink",
                                "file": str(src_file),
                                "line": read_line_num + 5,
                            }
                        )
                        break

                if len(chain) >= 2:
                    break
    except Exception:
        pass

    return chain


def _find_containing_function(callgraph: Dict, file_path: str, line: int, repo_path: str) -> Optional[str]:
    """
    T-CG8: Find the callgraph function that contains file_path:line.

    Strategy 1: callgraph dict entries with start_line/end_line metadata.
    Strategy 2: scan source file for enclosing function definition.
    """
    if callgraph:
        best: Optional[str] = None
        best_span = float("inf")
        for func_name, func_data in callgraph.items():
            if not isinstance(func_data, dict):
                continue
            func_file = func_data.get("file", "")
            if not func_file:
                continue
            if not file_path.endswith(func_file.lstrip("./")) and func_file not in file_path:
                continue
            start = func_data.get("start_line", 0)
            end = func_data.get("end_line", 0)
            if start and end and start <= line <= end:
                span = end - start
                if span < best_span:
                    best_span = span
                    best = func_name
        if best:
            return best

    src = file_path if os.path.isabs(file_path) else (os.path.join(repo_path, file_path) if repo_path else file_path)
    if not os.path.exists(src):
        return None

    _FUNC_DEF = re.compile(r"^(?:func\s+(\w+)|def\s+(\w+)|function\s+(\w+)|const\s+(\w+)\s*=)")
    try:
        with open(src, encoding="utf-8", errors="ignore") as f:
            file_lines = f.readlines()
        current_func = None
        current_start = 0
        for i, raw in enumerate(file_lines, 1):
            m = _FUNC_DEF.match(raw)
            if m:
                if current_func and current_start < line <= i:
                    return current_func
                current_func = next((g for g in m.groups() if g), None)
                current_start = i
        if current_func and current_start <= line:
            return current_func
    except Exception:
        pass
    return None


def _trace_to_entrypoint(callgraph: Dict, start_func: str, max_depth: int = 5) -> list:
    """
    T-CG8: BFS up caller tree from start_func to nearest HTTP entrypoint.
    Returns [entrypoint, ..., start_func].
    """
    if not callgraph or not start_func:
        return [start_func] if start_func else []

    callers_of: Dict[str, list] = {}
    for func, callees in callgraph.items():
        targets = (
            callees
            if isinstance(callees, (list, set))
            else (callees.get("callees", []) if isinstance(callees, dict) else [])
        )
        for callee in targets:
            callers_of.setdefault(str(callee), []).append(func)

    visited = {start_func}
    queue = [(start_func, [start_func])]
    best_path = [start_func]

    for _ in range(max_depth):
        next_queue = []
        for current, path in queue:
            for caller in callers_of.get(current, []):
                if caller in visited:
                    continue
                visited.add(caller)
                new_path = [caller] + path
                func_short = caller.split(".")[-1]
                if any(p.search(func_short) for p in _ENTRYPOINT_PATTERNS):
                    return new_path
                next_queue.append((caller, new_path))
                if len(new_path) > len(best_path):
                    best_path = new_path
        queue = next_queue
        if not queue:
            break

    return best_path


# T-CG9: File extensions that are secret/config files (not source code).
# Only these get the file-read check — inline secrets in source code files
# are reachable by definition (the code runs, the secret is in it).
_SECRET_FILE_EXTENSIONS = {
    ".env",
    ".pem",
    ".key",
    ".crt",
    ".cer",
    ".p12",
    ".pfx",
    ".jks",
    ".keystore",
    ".yaml",
    ".yml",
    ".json",
    ".toml",
    ".ini",
    ".cfg",
    ".conf",
    ".config",
    ".properties",
    ".xml",
    ".secret",
    ".secrets",
    ".credentials",
}


def enrich_secret_reachability(findings: list, repo_path: str) -> list:
    """
    T-CG9: Post-normalize pass — upgrade/downgrade secret reachability.

    Only applies file-read logic to secret/config FILES (e.g. .env, .pem, .yaml).
    Inline secrets in source code (.py, .go, .js, .ts) are left as-is (UNKNOWN)
    because the secret is in the code itself — the file-read check is not applicable.

    - Secret file, read confirmed → REACHABLE + try Level 2-3 chain
    - Secret file, not read       → NOT_REACHABLE + reachability_reason: file_not_read
    - Inline secret in source     → unchanged (stays UNKNOWN/REACHABLE from normalizer)

    Called by the ingester after normalize_semgrep() when repo_path is known.
    """
    # T-CG21: Path segments that indicate vendor/test code — always NOT_REACHABLE
    _VENDOR_SEGMENTS = (
        "/vendor/",
        "/third_party/",
        "/node_modules/",
        "/testdata/",
        "/.git/",
        "/dist/",
        "/build/",
    )

    if not repo_path:
        return findings
    for f in findings:
        file_path = f.get("file_path", f.get("file", ""))
        if not file_path:
            continue

        # T-CG21: Suppress vendor/testdata secrets — not your code, not your risk
        fp_lower = file_path.lower().replace("\\", "/")
        if any(seg in fp_lower for seg in _VENDOR_SEGMENTS):
            f["app_reachability"] = "NOT_REACHABLE"
            f["reachability_confidence"] = "HIGH"
            segment_hit = next(s.strip("/") for s in _VENDOR_SEGMENTS if s in fp_lower)
            f["reachability_reason"] = (
                "vendor_dependency"
                if segment_hit in ("vendor", "third_party", "node_modules", "dist", "build")
                else "test_data"
            )
            continue

        p = Path(file_path)
        ext = p.suffix.lower()
        name = p.name.lower()
        # Also catch .env.dev, .env.kratos, .env.* variants and dotfiles
        is_secret_file = (
            ext in _SECRET_FILE_EXTENSIONS or name.startswith(".env") or name.endswith(".env") or ".env." in name
        )
        # Only apply file-read logic to secret/config files, not source code
        if not is_secret_file:
            # Inline secret in source code — leave reachability as-is
            continue

        # T-CG29 FIX (P0): Never downgrade a finding the scanner already
        # confirmed as REACHABLE.  _determine_reachability() sets REACHABLE
        # when reachability_confidence=CONFIRMED + reachable_via is present.
        # _check_file_is_read() only knows a handful of file-read patterns
        # (os.ReadFile, open(), etc.) and misses loaders like viper/godotenv,
        # so it returns False for files that ARE read — causing a spurious
        # REACHABLE → NOT_REACHABLE downgrade that loses the signal entirely.
        if f.get("app_reachability") == "REACHABLE":
            # Scanner already confirmed reachability — trust it, skip file-read
            # check but still try to enrich the call chain.
            chain = _build_secret_chain_level2(file_path, repo_path, f.get("secret_type", ""))
            if chain:
                f["call_paths_v2"] = [chain] if chain else []
                # T-CG28/T-CG29: sync call_paths_v2 after enrichment
                _v2 = _call_path_nodes_to_v2(chain, "SECRET")
                if _v2:
                    f["call_paths_v2"] = [_v2]
            continue

        # BUG-SEC-01 FIX: call_paths_v2 being non-empty means the call path tracer
        # already walked from an HTTP entrypoint to a loader that reads this file.
        # _check_file_is_read() only matches literal string patterns and will miss
        # dynamic paths (e.g. godotenv.Load(os.Getenv("ENV_FILE"))), causing a
        # spurious UNKNOWN → NOT_REACHABLE downgrade that contradicts the traced path.
        # Trust call_paths_v2 as authoritative — promote to REACHABLE and skip heuristic.
        if f.get("call_paths_v2") and f.get("app_reachability", "UNKNOWN") == "UNKNOWN":
            f["app_reachability"] = "REACHABLE"
            f["reachability_confidence"] = "HIGH"
            f["reachability_reason"] = "call_path_traced"
            continue

        if _check_file_is_read(file_path, repo_path):
            if f.get("app_reachability", "UNKNOWN") == "UNKNOWN":
                f["app_reachability"] = "REACHABLE"
                f["reachability_confidence"] = "MEDIUM"
                f["reachability_reason"] = "file_read_confirmed"
            chain = _build_secret_chain_level2(file_path, repo_path, f.get("secret_type", ""))
            if chain:
                f["call_paths_v2"] = [chain] if chain else []
                # T-CG28/T-CG29: sync call_paths_v2 after enrichment
                _v2 = _call_path_nodes_to_v2(chain, "SECRET")
                if _v2:
                    f["call_paths_v2"] = [_v2]
        else:
            # Only downgrade UNKNOWN — never override REACHABLE (guards above)
            if f.get("app_reachability", "UNKNOWN") == "UNKNOWN":
                f["app_reachability"] = "NOT_REACHABLE"
                f["reachability_confidence"] = "MEDIUM"
                f["reachability_reason"] = "file_not_read"
    return findings


# JS/TS extensions — Go callgraph doesn't cover these, skip BFS for them
_JS_TS_EXTENSIONS = {".js", ".ts", ".jsx", ".tsx", ".mjs", ".cjs"}


def enrich_cwe_with_containing_function(findings: list, callgraph: Dict, repo_path: str) -> list:
    """
    T-CG8: Post-normalize pass — attach containing function + entrypoint BFS
    trace to CWE findings from semgrep.

    T-CG20: Skip JS/TS files when callgraph is Go-only — the Go callgraph has
    no coverage of JS/TS functions, so BFS would produce garbage results.
    JS/TS CWE paths are built by _build_cwe_call_path() via dataflow_trace instead.

    Sets finding['containing_function'] and enriches call_path with the BFS
    trace from HTTP entrypoint down to the vulnerable function.
    """
    if not callgraph and not repo_path:
        return findings

    # Detect if callgraph is Go-only (no JS/TS function names)
    cg_is_go_only = False
    if callgraph:
        sample = list(callgraph.keys())[:20]
        has_js_ts = any(".js" in k or ".ts" in k or "require(" in k or "=>" in k for k in sample)
        cg_is_go_only = not has_js_ts

    for f in findings:
        scanner = f.get("scanner", "")
        if scanner and scanner != "semgrep":
            continue
        file_path = f.get("file_path", f.get("file", ""))
        line = f.get("line", f.get("line_number", 0))
        if not file_path or not line:
            continue

        # T-CG20: Skip JS/TS files if callgraph is Go-only
        file_ext = Path(file_path).suffix.lower()
        if cg_is_go_only and file_ext in _JS_TS_EXTENSIONS:
            # dataflow_trace already handled by _build_cwe_call_path — leave as-is
            continue

        func = _find_containing_function(callgraph or {}, file_path, int(line), repo_path or "")
        if func:
            f["containing_function"] = func
            ep_path = _trace_to_entrypoint(callgraph or {}, func)
            if len(ep_path) > 1:
                existing = f.get("call_paths_v2", [[]])[0] if f.get("call_paths_v2") else []
                ep_nodes = [{"function": fn, "file": "", "line": 0} for fn in ep_path]
                merged = ep_nodes + (existing if existing else [])
                f["call_paths_v2"] = [merged] if merged else []
                # T-CG28: sync call_paths_v2 — enrich_cwe_with_containing_function
                # runs AFTER normalize_semgrep so call_paths_v2 must be updated here
                _v2 = _call_path_nodes_to_v2(merged, "CWE")
                if _v2:
                    f["call_paths_v2"] = [_v2]
    return findings


def _build_cwe_call_path(finding: Dict, filepath: str, line: int, message: str) -> list:
    """
    Build a call_path array for CWE findings so the dashboard call graph renders.

    Priority:
      1. Semgrep dataflow_trace (taint source → intermediate vars → sink)
      2. Single-node path from the finding location
    """
    extra = finding.get("extra", {})
    dt = extra.get("dataflow_trace", {})

    if dt:
        path = []
        src = dt.get("taint_source") or dt.get("taint_sources", [{}])
        if isinstance(src, list):
            src = src[0] if src else {}
        if src:
            loc = src.get("location", src)
            src_file = loc.get("path", filepath)
            src_line = (loc.get("start", {}) or {}).get("line", line)
            src_content = loc.get("content", src.get("content", ""))
            path.append({"function": src_content or "taint source", "file": src_file, "line": src_line})
        for iv in dt.get("intermediate_vars", []):
            loc = iv.get("location", iv)
            path.append(
                {
                    "function": iv.get("name", loc.get("content", "propagation step")),
                    "file": loc.get("path", filepath),
                    "line": (loc.get("start", {}) or {}).get("line", 0),
                }
            )
        sink = dt.get("taint_sink") or dt.get("taint_sinks", [{}])
        if isinstance(sink, list):
            sink = sink[0] if sink else {}
        if sink:
            loc = sink.get("location", sink)
            path.append(
                {
                    "function": loc.get("content", sink.get("content", "taint sink (vulnerable)")),
                    "file": loc.get("path", filepath),
                    "line": (loc.get("start", {}) or {}).get("line", line),
                }
            )
        if len(path) >= 2:
            return path

    rule_id = finding.get("check_id", finding.get("rule_id", ""))
    rule_short = rule_id.split(".")[-1] if "." in rule_id else rule_id
    return [{"function": rule_short or message[:80] or "security finding", "file": filepath, "line": line}]


def _build_secret_call_path(finding: Dict, filepath: str, line: int, secret_type: str) -> list:
    """
    Build a 2-node call_path for secret findings (static detection, no runtime trace).

    Node 1: file/loader context with optional variable name
    Node 2: exact line with hardcoded credential
    """
    if not filepath:
        return []

    fname = Path(filepath).name
    parent = Path(filepath).parent.name

    snippet = finding.get("extra", {}).get("lines", "") or finding.get("code_snippet", "") or ""
    var_name = ""
    if snippet:
        m = re.match(r"^\s*([A-Za-z_][A-Za-z0-9_]*)\s*[=:]", snippet.strip())
        if m:
            var_name = m.group(1)

    if var_name:
        entry_label = f"{var_name} ({fname})"
    elif parent and parent not in (".", "/"):
        entry_label = f"{parent}/{fname}"
    else:
        entry_label = fname

    display_type = secret_type.replace("_", " ").replace("-", " ").title() if secret_type else "Hardcoded Secret"
    return [
        {"function": entry_label, "file": filepath, "line": 0},
        {"function": f"{display_type} (hardcoded credential)", "file": filepath, "line": line or 0},
    ]


def _generate_finding_id(rule_id: str, filepath: str, line: int) -> str:
    key = f"{rule_id}:{filepath}:{line}"
    return hashlib.md5(key.encode()).hexdigest()[:16]


def _generate_secret_display_id(secret_type: str, filepath: str) -> str:
    stype = (secret_type or "generic").replace(" ", "-").lower()
    if not filepath:
        return f"secret-{stype}-unknown"
    p = Path(filepath)
    fname = p.stem.replace(".", "-")
    parent = p.parent.name
    if parent and parent != "." and parent != "/":
        return f"secret-{stype}-{parent}-{fname}"
    return f"secret-{stype}-{fname}"


def _generate_config_display_id(rule_id: str, filepath: str) -> str:
    parts = (rule_id or "unknown").split(".")
    skip = {
        "yaml",
        "dockerfile",
        "generic",
        "security",
        "secrets",
        "docker-compose",
        "kubernetes",
        "k8s",
        "terraform",
        "cloudformation",
        "helm",
    }
    meaningful = [p for p in parts if p.lower() not in skip]
    rule_short = meaningful[-1] if meaningful else parts[-1]
    rule_short = rule_short.replace("_", "-").lower()
    if not filepath:
        return f"config-{rule_short}-unknown"
    p = Path(filepath)
    fname = p.stem.replace(".", "-")
    parent = p.parent.name
    if parent and parent != "." and parent != "/":
        return f"config-{rule_short}-{parent}-{fname}"
    return f"config-{rule_short}-{fname}"


def _resolve_repo_path(scan_dir: Path) -> Optional[str]:
    if not scan_dir:
        return None
    plan_file = Path(scan_dir) / "scan-plan.json"
    if plan_file.exists():
        try:
            with open(plan_file) as f:
                plan = json.load(f)
            return plan.get("repo_path")
        except Exception:
            pass
    return None


# R3/R4 FIX: Semgrep does not fire on docker-compose env-var defaults (${VAR:-value})
# or on username fields with literal values — these are not "secrets" by Semgrep's ruleset.
# This post-processor catches what Semgrep misses by directly parsing compose YAML.

_COMPOSE_WEAK_CRED_FIELDS = re.compile(
    r"(?:password|passwd|secret|token|api[_-]?key|access[_-]?key|credential|cred|auth)s?",
    re.IGNORECASE,
)
_COMPOSE_USERNAME_FIELDS = re.compile(
    r"(?:username|user|login|account)",
    re.IGNORECASE,
)
# Service names where default creds are especially dangerous
_HIGH_RISK_SERVICES = {
    "gvm",
    "openvas",
    "gvmd",
    "gsad",
    "metasploit",
    "msf",
    "nessus",
    "nexpose",
    "burp",
    "sonarqube",
    "sonar",
    "vault",
    "jenkins",
    "grafana",
    "kibana",
    "elasticsearch",
    "es",
    "postgres",
    "postgresql",
    "mysql",
    "mariadb",
    "mongo",
    "mongodb",
    "redis",
    "rabbitmq",
    "kafka",
    "zookeeper",
    "consul",
    "etcd",
}
_WEAK_LITERAL_VALUES = re.compile(
    r"^(?:admin|password|secret|changeme|default|test|dev|example|root|"
    r"12345|123456|password123|letmein|welcome|qwerty|abc123|pass|"
    r"postgres|mysql|mongo|redis)$",
    re.IGNORECASE,
)
_WEAK_ENV_DEFAULT_RE = re.compile(r"\$\{[A-Za-z_]\w*:-(?P<default>[^}]+)\}$")


def _scan_docker_compose_weak_creds(repo_path: str) -> List[Dict]:
    """
    R3/R4 FIX: Scan docker-compose files for weak credentials that Semgrep misses:
      - Env-var defaults with weak values: ${GVM_PASSWORD:-admin}
      - Literal username/password values in known security tool services: GVM_USERNAME: admin
    Returns synthesized secret findings ready to merge into classified['secret'].
    """
    if not repo_path:
        return []

    findings = []
    seen: set = set()

    try:
        import yaml as _yaml
    except ImportError:
        return []

    compose_files = []
    for root, dirs, files in os.walk(repo_path):
        dirs[:] = [d for d in dirs if d not in {".git", "node_modules", "vendor", "__pycache__"}]
        for fname in files:
            if re.match(r"docker-compose.*\.ya?ml$", fname, re.IGNORECASE):
                compose_files.append(os.path.join(root, fname))

    for compose_path in compose_files:
        try:
            with open(compose_path, errors="replace") as f:
                raw_lines = f.readlines()
                content = "".join(raw_lines)
            data = _yaml.safe_load(content)
        except Exception:
            continue

        if not isinstance(data, dict):
            continue

        services = data.get("services", {})
        if not isinstance(services, dict):
            continue

        for svc_name, svc_cfg in services.items():
            if not isinstance(svc_cfg, dict):
                continue

            is_high_risk = any(tok in svc_name.lower() for tok in _HIGH_RISK_SERVICES)

            env = svc_cfg.get("environment", {})
            # environment can be a dict or a list of "KEY=VALUE" strings
            env_pairs: List[tuple] = []
            if isinstance(env, dict):
                env_pairs = list(env.items())
            elif isinstance(env, list):
                for item in env:
                    if isinstance(item, str) and "=" in item:
                        k, v = item.split("=", 1)
                        env_pairs.append((k.strip(), v.strip()))
                    elif isinstance(item, str):
                        env_pairs.append((item.strip(), ""))

            for key, val in env_pairs:
                val_str = str(val) if val is not None else ""
                key_lower = key.lower()
                is_password_field = bool(_COMPOSE_WEAK_CRED_FIELDS.search(key_lower))
                is_username_field = bool(_COMPOSE_USERNAME_FIELDS.search(key_lower))

                if not (is_password_field or (is_username_field and is_high_risk)):
                    continue

                # Case 1: literal weak value  e.g. GVM_USERNAME: admin
                if _WEAK_LITERAL_VALUES.match(val_str):
                    dedup_key = f"compose-literal:{compose_path}:{svc_name}:{key}"
                    if dedup_key in seen:
                        continue
                    seen.add(dedup_key)

                    # Find line number
                    line_num = 0
                    for i, ln in enumerate(raw_lines, 1):
                        if key in ln:
                            line_num = i
                            break

                    severity = "HIGH" if is_high_risk else "MEDIUM"
                    title = (
                        f"Hardcoded {'username' if is_username_field else 'credential'} "
                        f"'{val_str}' in service '{svc_name}' ({key})"
                    )
                    findings.append(
                        {
                            "id": _generate_finding_id(f"compose-weak-cred:{key}", compose_path, line_num),
                            "finding_id": _generate_finding_id(f"compose-weak-cred:{key}", compose_path, line_num),
                            "severity": severity,
                            "title": title,
                            "description": (
                                f"{title}. Hardcoded credentials in docker-compose allow unauthorized access "
                                f"if the compose file is committed to version control or leaked. "
                                f"Replace with a strong secret managed via Docker secrets or a secrets manager."
                            ),
                            "file": compose_path,
                            "file_path": compose_path,
                            "line": line_num,
                            "line_number": line_num,
                            "app_reachability": "NOT_APPLICABLE",
                            "reachability_confidence": "N/A",
                            "cwe_id": "CWE-798",
                            "secret_type": "hardcoded_credential",
                            "scanner": "reachable-compose-scanner",
                            "rule_id": f"compose-weak-cred:{key.lower()}",
                            "display_id": _generate_secret_display_id("hardcoded_credential", compose_path),
                            "call_paths_v2": [
                                [
                                    {
                                        "function": f"docker-compose service: {svc_name}",
                                        "label": f"docker-compose service: {svc_name}",
                                        "file": compose_path,
                                        "line": 0,
                                        "kind": "entry",
                                    },
                                    {
                                        "function": f"{key}: {val_str} (hardcoded)",
                                        "label": f"{key}: {val_str} (hardcoded)",
                                        "file": compose_path,
                                        "line": line_num,
                                        "kind": "sink_secret",
                                    },
                                ]
                            ],
                            "reachable_via": [],
                            "is_actual_secret": True,
                            "is_reachable": None,
                            "compliance_mapping": {},
                        }
                    )

                # Case 2: env-var default is weak  e.g. GVM_PASSWORD: ${GVM_PASSWORD:-admin}
                m = _WEAK_ENV_DEFAULT_RE.match(val_str)
                if m:
                    default_val = m.group("default").strip()
                    if _WEAK_LITERAL_VALUES.match(default_val) and is_password_field:
                        dedup_key = f"compose-envdefault:{compose_path}:{svc_name}:{key}"
                        if dedup_key in seen:
                            continue
                        seen.add(dedup_key)

                        line_num = 0
                        for i, ln in enumerate(raw_lines, 1):
                            if key in ln:
                                line_num = i
                                break

                        severity = "HIGH" if is_high_risk else "MEDIUM"
                        title = (
                            f"Weak credential default '{default_val}' for {key} "
                            f"in service '{svc_name}' — if {key} env-var is unset, "
                            f"'{default_val}' is used"
                        )
                        findings.append(
                            {
                                "id": _generate_finding_id(f"compose-env-default:{key}", compose_path, line_num),
                                "finding_id": _generate_finding_id(
                                    f"compose-env-default:{key}", compose_path, line_num
                                ),
                                "severity": severity,
                                "title": title,
                                "description": (
                                    f"{title}. Ensure {key} is explicitly set in the deployment environment "
                                    f"and never left to the weak default. Use Docker secrets or a vault."
                                ),
                                "file": compose_path,
                                "file_path": compose_path,
                                "line": line_num,
                                "line_number": line_num,
                                "app_reachability": "NOT_APPLICABLE",
                                "reachability_confidence": "N/A",
                                "cwe_id": "CWE-1391",
                                "secret_type": "weak_credential_default",
                                "scanner": "reachable-compose-scanner",
                                "rule_id": f"compose-env-default:{key.lower()}",
                                "display_id": _generate_secret_display_id("weak_credential_default", compose_path),
                                "call_paths_v2": [
                                    [
                                        {
                                            "function": f"docker-compose service: {svc_name}",
                                            "label": f"docker-compose service: {svc_name}",
                                            "file": compose_path,
                                            "line": 0,
                                            "kind": "entry",
                                        },
                                        {
                                            "function": f"{key}: {{${{{key}:-{default_val}}}}} (weak default)",
                                            "label": f"{key}: {{${{{key}:-{default_val}}}}} (weak default)",
                                            "file": compose_path,
                                            "line": line_num,
                                            "kind": "sink_secret",
                                        },
                                    ]
                                ],
                                "reachable_via": [],
                                "is_actual_secret": True,
                                "is_reachable": None,
                                "compliance_mapping": {},
                            }
                        )

    return findings


def normalize_semgrep(
    raw_files: Dict[str, Any], scan_dir: Path = None, call_graph: Dict = None, skip_iac: bool = False
) -> Dict[str, List[Dict]]:
    """
    Normalize Semgrep output into CWE, secret, and config findings.

    Args:
        raw_files: {'security-findings.json': <loaded semgrep data>}
        scan_dir: Path to scan output directory
        call_graph: Optional callgraph dict for T-CG8 CWE enrichment
        skip_iac: If True, drop all config/IaC findings

    Returns:
        {'cwe': [...], 'secret': [...], 'config': [...]}
    """
    semgrep_data = raw_files.get("security-findings.json")
    if not semgrep_data:
        return {"cwe": [], "secret": [], "config": []}

    if isinstance(semgrep_data, dict):
        results = semgrep_data.get("results", semgrep_data.get("findings", []))
    elif isinstance(semgrep_data, list):
        results = semgrep_data
    else:
        logger.warning(f"Unexpected semgrep data type: {type(semgrep_data)}")
        return {"cwe": [], "secret": [], "config": []}

    classified: Dict[str, List[Dict]] = {"cwe": [], "secret": [], "config": []}
    seen_ids: set = set()

    repo_path = _resolve_repo_path(scan_dir)

    for finding in results:
        try:
            rule_id = finding.get("check_id", finding.get("rule_id", ""))
            filepath = finding.get("path", finding.get("file", ""))
            line = finding.get("start", {}).get("line", finding.get("line", 0))
            message = finding.get("extra", {}).get("message", finding.get("message", ""))

            if not rule_id or not filepath:
                continue

            # SCAN-01 FIX: Skip findings in documentation/markdown files entirely
            if _is_doc_file(filepath):
                logger.debug(f"SCAN-01: Skipping doc-file finding: {rule_id} in {filepath}")
                continue

            if filepath and not os.path.isabs(filepath) and repo_path:
                filepath = os.path.join(repo_path, filepath)

            finding_type = _classify_finding(finding, filepath, rule_id)

            if finding_type == "secret" and _is_pattern_definition_fp(finding):
                logger.debug(f"Skipping pattern-definition FP: {rule_id} in {filepath}:{line}")
                continue

            if finding_type == "secret" and _has_env_interpolation(finding, filepath):
                logger.debug(f"Skipping env-interpolated secret: {rule_id} in {filepath}:{line}")
                continue

            finding_id = _generate_finding_id(rule_id, filepath, line)
            if finding_id in seen_ids:
                continue
            seen_ids.add(finding_id)

            if finding_type == "config" and skip_iac:
                continue

            if finding_type == "config" and "websocket" in rule_id.lower() and "docker-compose" in filepath.lower():
                continue

            raw_severity = finding.get("extra", {}).get("severity", finding.get("severity", "WARNING"))
            if finding_type == "config":
                severity = _iac_severity(rule_id, raw_severity)
            else:
                severity = SEVERITY_MAP.get(raw_severity, "MEDIUM")

            if finding_type == "secret" and _is_templated_dev_secret(finding, filepath):
                severity = "LOW"
                message = (message or "") + " [weak_default_fallback]"

            app_reach = _determine_reachability(finding, finding_type, filepath)

            cwe_id = ""
            metadata = finding.get("extra", {}).get("metadata", {})
            cwe_ids = metadata.get("cwe", [])
            if cwe_ids:
                cwe_id = cwe_ids[0] if isinstance(cwe_ids, list) else str(cwe_ids)
                if ":" in cwe_id:
                    cwe_id = cwe_id.split(":")[0].strip()
            elif finding.get("cwe_id"):
                cwe_id = finding["cwe_id"]
            elif finding.get("policy_id", "").startswith("CWE-"):
                cwe_id = finding["policy_id"].split(":")[0].strip()

            secret_type = ""
            if finding_type == "secret":
                secret_type = (
                    finding.get("type", "")
                    or finding.get("secret_type", "")
                    or (rule_id.split(".")[-1] if "." in rule_id else "unknown")
                )

            confidence = "LOW"
            if finding.get("reachability_confidence"):
                confidence = finding["reachability_confidence"].upper()
            elif app_reach == "REACHABLE":
                confidence = "MEDIUM"

            cwe_call_path: list = []
            reachable_via = finding.get("reachable_via", [])
            if finding_type == "cwe":
                cwe_call_path = _build_cwe_call_path(finding, filepath, line, message)
            elif finding_type == "secret":
                if reachable_via:
                    if isinstance(reachable_via[0], str):
                        cwe_call_path = [{"function": hop, "file": filepath, "line": 0} for hop in reachable_via]
                    else:
                        cwe_call_path = reachable_via
                else:
                    cwe_call_path = _build_secret_call_path(finding, filepath, line, secret_type)

            # T-CG10: upgrade call_path to typed PathNode list for call_paths_v2
            _ft_for_classify = "secret" if finding_type == "secret" else "cwe"
            _v2_path = _call_path_nodes_to_v2(cwe_call_path, _ft_for_classify)

            # COMP-01 FIX: Build compliance mapping for all semgrep finding types
            _compliance = get_compliance_mapping(
                finding_type=finding_type,
                existing_mapping=finding.get("compliance_mapping") or {},
            )

            normalized: Dict[str, Any] = {
                "id": finding_id,
                "finding_id": finding_id,
                "severity": severity,
                "title": (message or f"{rule_id} in {filepath}")[:200],
                "description": message,
                "file": filepath,
                "file_path": filepath,
                "line": line,
                "line_number": line,
                "app_reachability": app_reach,
                "reachability_confidence": confidence,
                "cwe_id": cwe_id,
                "secret_type": secret_type,
                "scanner": "semgrep",
                # T-CG28 write-deprecated: call_path (v1) not written on new scans
                # T-CG10: authoritative typed PathNode list for dashboard rendering
                "call_paths_v2": [_v2_path] if _v2_path else [],
                "rule_id": rule_id,
                "reachable_via": finding.get("reachable_via", []),
                "is_actual_secret": finding.get("is_actual_secret", False),
                # COMP-01 FIX: compliance tags for all types
                "compliance_mapping": _compliance,
            }

            if finding_type == "secret":
                normalized["display_id"] = _generate_secret_display_id(secret_type, filepath)
            elif finding_type == "config":
                normalized["display_id"] = _generate_config_display_id(rule_id, filepath)

            if finding_type != "config":
                normalized["is_reachable"] = finding.get("is_reachable")

            classified[finding_type].append(normalized)

        except Exception as e:
            logger.warning(f"Error normalizing Semgrep finding: {e}")
            continue

    # R3/R4 FIX: Catch weak docker-compose credentials that Semgrep rule coverage misses
    if repo_path:
        try:
            compose_findings = _scan_docker_compose_weak_creds(repo_path)
            if compose_findings:
                # Deduplicate against already-seen findings
                existing_ids = {f["id"] for f in classified["secret"]}
                new_findings = [f for f in compose_findings if f["id"] not in existing_ids]
                classified["secret"].extend(new_findings)
                if new_findings:
                    logger.info(
                        f"compose-scanner: +{len(new_findings)} weak credential findings from docker-compose files"
                    )
        except Exception as e:
            logger.warning(f"compose-scanner error: {e}")

    logger.info(
        f"Normalized Semgrep: {len(classified['cwe'])} CWE, "
        f"{len(classified['secret'])} secret, {len(classified['config'])} config "
        f"from {len(results)} raw findings"
    )
    return classified
