#!/usr/bin/env python3
# Copyright (c) 2026 Sthenos Security. All rights reserved.

"""
v5.1.3 AI Security Normalizer

Reads: raw/ai-security.json
Produces: ai_findings (stored in ai_findings table, not findings table)

Handles OWASP LLM Top 10 findings from the AI scanner.
Severity mapping: WARNING -> MEDIUM, ERROR -> HIGH (consistent with design doc).
"""

import logging
from pathlib import Path
from typing import Any, Dict, List

from reachable.database.normalizers.compliance_tags import get_compliance_mapping

logger = logging.getLogger(__name__)

SEVERITY_MAP = {
    "ERROR": "HIGH",
    "WARNING": "MEDIUM",
    "INFO": "LOW",
    "CRITICAL": "CRITICAL",
    "HIGH": "HIGH",
    "MEDIUM": "MEDIUM",
    "LOW": "LOW",
}


def normalize_ai(raw_files: Dict[str, Any], scan_dir: Path = None, call_graph: Dict = None) -> Dict[str, List[Dict]]:
    """
    Normalize AI security findings for ai_findings table.

    Args:
        raw_files: {'ai-security.json': <loaded AI scanner data>}

    Returns:
        {'ai': [list of AI finding dicts ready for store_ai_findings()]}
    """
    ai_data = raw_files.get("ai-security.json")
    if not ai_data:
        return {"ai": []}

    raw_findings = ai_data.get("findings", [])
    if not raw_findings:
        return {"ai": []}

    normalized = []

    for f in raw_findings:
        try:
            file_path = f.get("file_path", f.get("file", ""))
            line_start = f.get("line_start", f.get("line_number", f.get("line", 0)))
            rule_id = f.get("rule_id", f.get("check_id", ""))

            if not file_path or not rule_id:
                logger.debug("Skipping AI finding: missing file_path or rule_id")
                continue

            if not line_start:
                logger.debug(f"Skipping AI finding: missing line_start for {file_path}")
                continue

            # Severity normalization
            raw_severity = f.get("severity", "WARNING")
            severity = SEVERITY_MAP.get(raw_severity, raw_severity)

            normalized.append(
                {
                    "rule_id": rule_id,
                    "policy_id": f.get("policy_id", ""),
                    "owasp_category": f.get("owasp_category", f.get("owasp_llm", "")),
                    "owasp_name": f.get("owasp_name", ""),
                    "severity": severity,
                    "base_risk_score": f.get("base_risk_score", 0.0),
                    "adjusted_risk_score": f.get("adjusted_risk_score", 0.0),
                    "is_reachable": f.get("is_reachable", True),
                    "call_paths_v2": f.get("call_paths_v2", []),
                    "guards": f.get("guards", []),
                    "guard_risk_reduction": f.get("guard_risk_reduction", 0.0),
                    "file_path": file_path,
                    "line_start": line_start,
                    "line_end": f.get("line_end", 0),
                    "message": f.get("message", ""),
                    "framework": f.get("framework", ""),
                    "provider": f.get("provider", ""),
                    "detection_source": f.get("detection_source", ""),
                    "is_critical": f.get("is_critical", False),
                    # COMP-01 FIX: compliance tags for AI findings
                    "compliance_mapping": get_compliance_mapping("ai", f.get("compliance_mapping") or {}),
                }
            )

        except Exception as e:
            logger.warning(f"Error normalizing AI finding: {e}")
            continue

    logger.info(f"Normalized {len(normalized)} AI findings from {len(raw_findings)} raw")
    return {"ai": normalized}
