#!/usr/bin/env python3
# Copyright (c) 2026 Sthenos Security. All rights reserved.

"""
v5.1.3 Sandbox Normalizer

Reads: raw/sandbox-results.json
Produces: findings (type=malware), findings (type=suspicious)

Dynamic sandbox analysis results. Runtime-observed behavior is stronger evidence
than static analysis, so these findings get REACHABLE status.

Classification:
  - CRITICAL verdict -> type=malware, REACHABLE
  - SUSPICIOUS verdict -> type=suspicious, REACHABLE (runtime observed)
  - CLEAN -> not stored
"""

import hashlib
import logging
from pathlib import Path
from typing import Any, Dict, List

logger = logging.getLogger(__name__)


def normalize_sandbox(
    raw_files: Dict[str, Any], scan_dir: Path = None, call_graph: Dict = None
) -> Dict[str, List[Dict]]:
    """
    Normalize sandbox analysis results into malware/suspicious findings.

    Args:
        raw_files: {'sandbox-results.json': <loaded sandbox data>}

    Returns:
        {'malware': [...], 'suspicious': [...]}
    """
    sandbox_data = raw_files.get("sandbox-results.json")
    if not sandbox_data:
        return {"malware": [], "suspicious": []}

    results = sandbox_data.get("results", sandbox_data.get("packages", []))
    if not results:
        return {"malware": [], "suspicious": []}

    malware = []
    suspicious = []

    for pkg_result in results:
        try:
            pkg_name = pkg_result.get("package", pkg_result.get("name", ""))
            version = pkg_result.get("version", "")
            verdict = pkg_result.get("verdict", pkg_result.get("status", "")).upper()

            if verdict == "CLEAN" or not pkg_name:
                continue

            behaviors = pkg_result.get("behaviors", pkg_result.get("findings", []))

            for behavior in behaviors:
                behavior_type = behavior.get("type", behavior.get("behavior", ""))
                severity = behavior.get("severity", "HIGH").upper()
                message = behavior.get("message", behavior.get("description", ""))
                filepath = behavior.get("file", behavior.get("path", ""))

                finding_id = hashlib.md5(
                    f"sandbox:{pkg_name}:{version}:{behavior_type}:{filepath}".encode()
                ).hexdigest()[:16]

                finding_type = "malware" if verdict == "CRITICAL" else "suspicious"

                finding = {
                    "id": finding_id,
                    "finding_type": finding_type,
                    "severity": severity if severity in ("CRITICAL", "HIGH", "MEDIUM", "LOW") else "HIGH",
                    "risk_level": severity,
                    "title": f"[Sandbox] {behavior_type}: {message}"[:500],
                    "description": f"Dynamic analysis of {pkg_name}@{version}: {message}"[:1000],
                    "package": pkg_name,
                    "package_name": pkg_name,
                    "version": version,
                    "package_version": version,
                    "scanner": "sandbox",
                    "file": filepath,
                    "file_path": filepath,
                    "line": behavior.get("line", 0),
                    "line_number": behavior.get("line", 0),
                    # Runtime-observed = REACHABLE
                    "app_reachability": "REACHABLE",
                    "reachability_confidence": "HIGH",
                    "evidence_dynamic": behavior,
                }

                if finding_type == "malware":
                    malware.append(finding)
                else:
                    suspicious.append(finding)

            # If no individual behaviors but verdict is malicious, create one finding
            if not behaviors and verdict in ("CRITICAL", "SUSPICIOUS"):
                finding_id = hashlib.md5(f"sandbox:{pkg_name}:{version}:{verdict}".encode()).hexdigest()[:16]

                finding_type = "malware" if verdict == "CRITICAL" else "suspicious"

                finding = {
                    "id": finding_id,
                    "finding_type": finding_type,
                    "severity": "CRITICAL" if verdict == "CRITICAL" else "HIGH",
                    "risk_level": "CRITICAL" if verdict == "CRITICAL" else "HIGH",
                    "title": f"[Sandbox] {pkg_name}@{version}: {verdict}"[:500],
                    "description": f"Dynamic sandbox verdict: {verdict}"[:1000],
                    "package": pkg_name,
                    "package_name": pkg_name,
                    "version": version,
                    "package_version": version,
                    "scanner": "sandbox",
                    "app_reachability": "REACHABLE",
                    "reachability_confidence": "HIGH",
                }

                if finding_type == "malware":
                    malware.append(finding)
                else:
                    suspicious.append(finding)

        except Exception as e:
            logger.warning(f"Error normalizing sandbox result: {e}")
            continue

    logger.info(f"Sandbox: {len(malware)} confirmed malware, {len(suspicious)} suspicious")
    return {"malware": malware, "suspicious": suspicious}
