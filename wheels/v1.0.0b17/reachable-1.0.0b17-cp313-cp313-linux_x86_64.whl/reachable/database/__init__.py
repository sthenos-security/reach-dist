# Copyright © 2026 Sthenos Security. All rights reserved.
"""
Database persistence layer.

Modules:
- storage     - Main RepoDatabase interface (SQLite)
- manager     - DB lifecycle management
- compaction  - Database compaction and cleanup
"""
