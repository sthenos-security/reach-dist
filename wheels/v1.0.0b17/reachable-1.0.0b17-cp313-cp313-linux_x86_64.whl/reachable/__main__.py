#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.

"""
Entrypoint for `python -m reachable`
"""

from reachable.cli import main

if __name__ == "__main__":
    main()
