#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.
"""
Private registry configuration loader.

Manages ~/.reachable/registries.yaml — credentials, internal namespaces,
and package alias maps for enterprise private artifact repositories.
"""

import fnmatch
import logging
import os
from pathlib import Path
from typing import Any, Dict, List, Optional

try:
    import yaml

    _YAML_AVAILABLE = True
except ImportError:
    _YAML_AVAILABLE = False

logger = logging.getLogger(__name__)

REGISTRIES_PATH = Path.home() / ".reachable" / "registries.yaml"

_DEFAULT_CONFIG: Dict[str, Any] = {
    "version": "1.0",
    "registries": {},
    "internal_namespaces": {
        "python": [],
        "npm": [],
        "go": [],
        "maven": [],
    },
    "package_aliases": {},
}


# ---------------------------------------------------------------------------
# Load / save
# ---------------------------------------------------------------------------


def get_registries_path() -> Path:
    return REGISTRIES_PATH


def load_registries() -> Dict[str, Any]:
    """Load registries.yaml. Returns empty defaults if file doesn't exist."""
    path = get_registries_path()
    if not path.exists():
        return dict(_DEFAULT_CONFIG)

    if not _YAML_AVAILABLE:
        logger.warning("PyYAML not installed — cannot load registries.yaml. Install with: pip install pyyaml")
        return dict(_DEFAULT_CONFIG)

    try:
        with open(path) as f:
            data = yaml.safe_load(f) or {}
        # Merge with defaults so missing keys are populated
        cfg = dict(_DEFAULT_CONFIG)
        cfg.update(data)
        return cfg
    except Exception as e:
        logger.warning(f"Failed to load registries.yaml: {e}")
        return dict(_DEFAULT_CONFIG)


def save_registries(config: Dict[str, Any]) -> bool:
    if not _YAML_AVAILABLE:
        logger.error("PyYAML not installed — cannot save registries.yaml.")
        return False
    path = get_registries_path()
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        with open(path, "w") as f:
            yaml.safe_dump(config, f, default_flow_style=False, sort_keys=False)
        return True
    except Exception as e:
        logger.error(f"Failed to save registries.yaml: {e}")
        return False


# ---------------------------------------------------------------------------
# Registry config accessors
# ---------------------------------------------------------------------------


def get_registry_config(ecosystem: str) -> Optional[Dict[str, Any]]:
    """
    Return registry config for an ecosystem, or None if not configured.

    ecosystem: 'python' | 'npm' | 'go' | 'maven'
    """
    cfg = load_registries()
    return cfg.get("registries", {}).get(ecosystem)


def get_registry_token(ecosystem: str) -> Optional[str]:
    """Resolve the auth token for an ecosystem from the configured env var."""
    reg = get_registry_config(ecosystem)
    if not reg:
        return None
    env_var = reg.get("token_env") or reg.get("password_env")
    if env_var:
        return os.environ.get(env_var)
    return None


# ---------------------------------------------------------------------------
# Internal namespace matching
# ---------------------------------------------------------------------------


def is_internal_package(ecosystem: str, package_name: str) -> bool:
    """
    Return True if the package matches a declared internal namespace.

    Internal packages are skipped during CVE hash-lookup — they have no
    upstream CVE equivalent.

    ecosystem: 'python' | 'npm' | 'go' | 'maven'
    package_name: bare package name (e.g. 'acme-core-auth', '@acme/ui', 'go.acme.com/platform/sdk')
    """
    cfg = load_registries()
    patterns: List[str] = cfg.get("internal_namespaces", {}).get(ecosystem, [])
    for pat in patterns:
        if fnmatch.fnmatch(package_name, pat):
            return True
    return False


def get_internal_namespaces(ecosystem: Optional[str] = None) -> Dict[str, List[str]]:
    cfg = load_registries()
    ns = cfg.get("internal_namespaces", {})
    if ecosystem:
        return {ecosystem: ns.get(ecosystem, [])}
    return ns


# ---------------------------------------------------------------------------
# Package alias map
# ---------------------------------------------------------------------------


def resolve_alias(purl: str) -> Optional[str]:
    """
    Check whether a PURL prefix matches a declared alias.

    The alias map uses PURL *prefixes* (up to and including '@'), so the
    version component is preserved from the original PURL.

    Example:
        alias: "pkg:pypi/acme-crypto@" → "pkg:pypi/cryptography@"
        resolve_alias("pkg:pypi/acme-crypto@42.0.0") → "pkg:pypi/cryptography@42.0.0"

    Returns the rewritten PURL, or None if no alias matched.
    """
    cfg = load_registries()
    aliases: Dict[str, str] = cfg.get("package_aliases", {})
    for private_prefix, canonical_prefix in aliases.items():
        if purl.startswith(private_prefix):
            suffix = purl[len(private_prefix) :]
            return canonical_prefix + suffix
    return None


def get_all_aliases() -> Dict[str, str]:
    return load_registries().get("package_aliases", {})


# ---------------------------------------------------------------------------
# Alias / namespace mutation helpers (used by CLI)
# ---------------------------------------------------------------------------


def add_alias(private_prefix: str, canonical_prefix: str) -> bool:
    cfg = load_registries()
    cfg.setdefault("package_aliases", {})[private_prefix] = canonical_prefix
    return save_registries(cfg)


def remove_alias(private_prefix: str) -> bool:
    cfg = load_registries()
    aliases = cfg.get("package_aliases", {})
    if private_prefix not in aliases:
        return False
    del aliases[private_prefix]
    return save_registries(cfg)


def add_namespace(ecosystem: str, pattern: str) -> bool:
    cfg = load_registries()
    ns = cfg.setdefault("internal_namespaces", {}).setdefault(ecosystem, [])
    if pattern not in ns:
        ns.append(pattern)
    return save_registries(cfg)


def remove_namespace(ecosystem: str, pattern: str) -> bool:
    cfg = load_registries()
    ns = cfg.get("internal_namespaces", {}).get(ecosystem, [])
    if pattern not in ns:
        return False
    ns.remove(pattern)
    return save_registries(cfg)


# ---------------------------------------------------------------------------
# Auto-detection
# ---------------------------------------------------------------------------


def autodetect_registries() -> Dict[str, Any]:
    """
    Probe environment and well-known config files to build an initial
    registries config. Returns a dict ready to be merged into a new
    registries.yaml.
    """
    detected: Dict[str, Any] = {}

    # --- Python ---
    index_url = os.environ.get("PIP_INDEX_URL") or os.environ.get("PIP_EXTRA_INDEX_URL") or _read_pip_conf()
    if index_url and "pypi.org" not in index_url:
        python_cfg: Dict[str, Any] = {"index_url": index_url}
        if os.environ.get("ARTIFACTORY_TOKEN"):
            python_cfg["token_env"] = "ARTIFACTORY_TOKEN"
        elif os.environ.get("PIP_TOKEN"):
            python_cfg["token_env"] = "PIP_TOKEN"
        detected["python"] = python_cfg

    # --- npm ---
    npm_registry = os.environ.get("NPM_CONFIG_REGISTRY") or _read_npmrc_registry()
    if npm_registry and "registry.npmjs.org" not in npm_registry:
        npm_cfg: Dict[str, Any] = {"registry": npm_registry}
        if os.environ.get("NPM_TOKEN"):
            npm_cfg["token_env"] = "NPM_TOKEN"
        detected["npm"] = npm_cfg

    # --- Go ---
    goproxy = os.environ.get("GOPROXY", "")
    if goproxy and "proxy.golang.org" not in goproxy and goproxy != "direct":
        go_cfg: Dict[str, Any] = {"goproxy": goproxy}
        for var in ("GONOSUMCHECK", "GOPRIVATE", "GONOSUMDB"):
            val = os.environ.get(var)
            if val:
                go_cfg[var.lower()] = val
        if os.environ.get("GOPROXY_TOKEN"):
            go_cfg["token_env"] = "GOPROXY_TOKEN"
        detected["go"] = go_cfg

    # --- Maven ---
    settings = Path.home() / ".m2" / "settings.xml"
    if settings.exists():
        detected["maven"] = {"settings_xml": str(settings)}

    return detected


def _read_pip_conf() -> Optional[str]:
    for candidate in (
        Path.home() / ".config" / "pip" / "pip.conf",
        Path("/etc/pip.conf"),
        Path(os.environ.get("PIP_CONFIG_FILE", "/dev/null")),
    ):
        if candidate.exists():
            try:
                text = candidate.read_text()
                for line in text.splitlines():
                    line = line.strip()
                    if line.startswith("index-url") or line.startswith("index_url"):
                        _, _, url = line.partition("=")
                        url = url.strip()
                        if url:
                            return url
            except Exception:
                pass
    return None


def _read_npmrc_registry() -> Optional[str]:
    for candidate in (Path.cwd() / ".npmrc", Path.home() / ".npmrc"):
        if candidate.exists():
            try:
                for line in candidate.read_text().splitlines():
                    line = line.strip()
                    if line.startswith("registry="):
                        return line.split("=", 1)[1].strip()
            except Exception:
                pass
    return None


# ---------------------------------------------------------------------------
# Display helpers (used by CLI)
# ---------------------------------------------------------------------------


def format_registries_display(show_raw: bool = False) -> str:
    """Return a human-readable summary of the registry configuration."""
    cfg = load_registries()
    regs = cfg.get("registries", {})
    ns_all = cfg.get("internal_namespaces", {})
    aliases = cfg.get("package_aliases", {})

    lines = ["PRIVATE REGISTRY CONFIGURATION", "═" * 60, f"Config file: {get_registries_path()}", ""]

    # Registries
    if regs:
        lines.append("REGISTRIES")
        lines.append("─" * 40)
        for eco, rcfg in regs.items():
            for k, v in rcfg.items():
                if k.endswith("_env") and not show_raw:
                    env_var = v
                    set_str = "[SET ✓]" if os.environ.get(env_var) else "[NOT SET ✗]"
                    lines.append(f"  {eco:<8} {k:<14} {env_var}  {set_str}")
                else:
                    lines.append(f"  {eco:<8} {k:<14} {v}")
        lines.append("")

    # Internal namespaces
    has_ns = any(v for v in ns_all.values())
    if has_ns:
        lines.append("INTERNAL NAMESPACES (skip CVE lookup)")
        lines.append("─" * 40)
        for eco, patterns in ns_all.items():
            if patterns:
                lines.append(f"  {eco:<8} {' '.join(patterns)}")
        lines.append("")

    # Aliases
    if aliases:
        lines.append("PACKAGE ALIASES (PURL rewrite)")
        lines.append("─" * 40)
        for priv, canon in aliases.items():
            lines.append(f"  {priv}")
            lines.append(f"      → {canon}")
        lines.append("")

    if not regs and not has_ns and not aliases:
        lines.append("No private registries configured.")
        lines.append("")
        lines.append("Run: reachctl registries init    (auto-detect from environment)")
        lines.append("  or edit: ~/.reachable/registries.yaml")

    return "\n".join(lines)
