# Copyright © 2026 Sthenos Security. All rights reserved.

"""
Compression utilities for REACHABLE output files.

Codec Selection by Artifact Type:
─────────────────────────────────────────────────────────────────────
| Artifact Type        | Codec         | Rationale                   |
|----------------------|---------------|-----------------------------|
| Logs / metadata      | zstd (3-6)    | Fast, good ratio for text   |
| Shipping artifacts   | zstd (10-15)  | Best ratio for distribution |
| Temporary cache      | lz4           | Fastest, for ephemeral data |
| Customer-facing      | gzip          | Universal compatibility     |
─────────────────────────────────────────────────────────────────────

Usage:
    from reachable.core.compression import save_json, load_json, ArtifactType

    # Save with automatic codec selection
    save_json(data, 'report.json', artifact_type=ArtifactType.SHIPPING)

    # Load transparently (auto-detects compression format)
    data = load_json('report.json')
"""

import gzip
import json
import logging
from enum import Enum
from pathlib import Path
from typing import Any, Dict, Tuple, Union

# Initialize module-level logger
logger = logging.getLogger(__name__)

# Try to import fast compression libraries
try:
    import zstandard as zstd

    ZSTD_AVAILABLE = True
except ImportError:
    ZSTD_AVAILABLE = False

try:
    import lz4.frame as lz4

    LZ4_AVAILABLE = True
except ImportError:
    LZ4_AVAILABLE = False


class ArtifactType(Enum):
    """Artifact type determines compression codec selection."""

    METADATA = "metadata"  # Logs, metrics, timing - zstd level 3-6
    SHIPPING = "shipping"  # Distribution packages - zstd level 10-15
    CACHE = "cache"  # Temporary cache files - lz4
    CUSTOMER_FACING = "customer"  # User downloads - gzip (compatibility)
    AUTO = "auto"  # Auto-detect from filename


class Codec(Enum):
    """Compression codecs with their file extensions."""

    NONE = ("", None)
    GZIP = (".gz", "gzip")
    ZSTD = (".zst", "zstd")
    LZ4 = (".lz4", "lz4")

    @property
    def extension(self) -> str:
        return self.value[0]

    @property
    def name_str(self) -> str:
        return self.value[1] or "none"


# Codec selection by artifact type
ARTIFACT_CODEC_MAP: Dict[ArtifactType, Tuple[Codec, int]] = {
    ArtifactType.METADATA: (Codec.ZSTD, 5),  # zstd level 5 (fast + decent)
    ArtifactType.SHIPPING: (Codec.ZSTD, 12),  # zstd level 12 (slow + best)
    ArtifactType.CACHE: (Codec.LZ4, 0),  # lz4 (fastest)
    ArtifactType.CUSTOMER_FACING: (Codec.GZIP, 6),  # gzip level 6 (compatible)
}

# File patterns to artifact type mapping
FILE_ARTIFACT_MAP = {
    # Shipping artifacts (best compression)
    "reachable-report.json": ArtifactType.SHIPPING,
    "sbom.json": ArtifactType.SHIPPING,
    ".vex.json": ArtifactType.SHIPPING,
    # Metadata (fast compression)
    "metrics.json": ArtifactType.METADATA,
    "summary.json": ArtifactType.METADATA,
    "scan_timing.json": ArtifactType.METADATA,
    "tool_execution_status.json": ArtifactType.METADATA,
    "policy_status.json": ArtifactType.METADATA,
    # Cache (fastest)
    "call-graph.json": ArtifactType.CACHE,
    "correlation.json": ArtifactType.CACHE,
    ".cache.json": ArtifactType.CACHE,
    # Customer-facing (gzip for compatibility)
    "dashboard.html": ArtifactType.CUSTOMER_FACING,
    "audit-": ArtifactType.CUSTOMER_FACING,  # audit-soc2.html, etc.
}

# Files that should never be compressed
NEVER_COMPRESS = {
    "scan.log",
    "dashboard.html",  # Must be servable directly
    ".html",  # HTML files need to open in browser
}

# Threshold for automatic compression (bytes)
COMPRESSION_THRESHOLD = 50 * 1024  # 50 KB


def _detect_artifact_type(filename: str) -> ArtifactType:
    """Detect artifact type from filename patterns."""
    filename_lower = filename.lower()

    for pattern, artifact_type in FILE_ARTIFACT_MAP.items():
        if pattern in filename_lower:
            return artifact_type

    # Default to metadata for JSON files
    if filename_lower.endswith(".json"):
        return ArtifactType.METADATA

    return ArtifactType.CUSTOMER_FACING


def _get_codec_for_type(artifact_type: ArtifactType) -> Tuple[Codec, int]:
    """Get the codec and level for an artifact type, with fallbacks."""
    codec, level = ARTIFACT_CODEC_MAP.get(artifact_type, (Codec.GZIP, 6))

    # Fallback if preferred codec not available
    if codec == Codec.ZSTD and not ZSTD_AVAILABLE:
        codec, level = Codec.GZIP, 9  # Use gzip with high compression
    elif codec == Codec.LZ4 and not LZ4_AVAILABLE:
        codec, level = Codec.GZIP, 1  # Use gzip with fast compression

    return codec, level


def _compress_data(data: bytes, codec: Codec, level: int) -> bytes:
    """Compress data with specified codec."""
    if codec == Codec.GZIP:
        import io

        buf = io.BytesIO()
        with gzip.GzipFile(fileobj=buf, mode="wb", compresslevel=level) as f:
            f.write(data)
        return buf.getvalue()

    elif codec == Codec.ZSTD and ZSTD_AVAILABLE:
        cctx = zstd.ZstdCompressor(level=level)
        return cctx.compress(data)

    elif codec == Codec.LZ4 and LZ4_AVAILABLE:
        return lz4.compress(data)

    else:
        # Fallback to gzip
        import io

        buf = io.BytesIO()
        with gzip.GzipFile(fileobj=buf, mode="wb", compresslevel=6) as f:
            f.write(data)
        return buf.getvalue()


def _decompress_data(data: bytes, codec: Codec) -> bytes:
    """Decompress data with specified codec."""
    if codec == Codec.GZIP:
        return gzip.decompress(data)

    elif codec == Codec.ZSTD and ZSTD_AVAILABLE:
        dctx = zstd.ZstdDecompressor()
        return dctx.decompress(data)

    elif codec == Codec.LZ4 and LZ4_AVAILABLE:
        return lz4.decompress(data)

    else:
        # Try gzip as fallback
        return gzip.decompress(data)


def _detect_codec_from_magic(data: bytes) -> Codec:
    """Detect compression codec from magic bytes."""
    if len(data) < 4:
        return Codec.NONE

    # GZIP: 1f 8b
    if data[:2] == b"\x1f\x8b":
        return Codec.GZIP

    # ZSTD: 28 b5 2f fd
    if data[:4] == b"\x28\xb5\x2f\xfd":
        return Codec.ZSTD

    # LZ4: 04 22 4d 18
    if data[:4] == b"\x04\x22\x4d\x18":
        return Codec.LZ4

    return Codec.NONE


def _detect_codec_from_extension(path: Path) -> Codec:
    """Detect compression codec from file extension."""
    suffix = path.suffix.lower()
    suffixes = "".join(path.suffixes).lower()

    if suffix == ".gz" or ".json.gz" in suffixes:
        return Codec.GZIP
    elif suffix == ".zst" or ".json.zst" in suffixes:
        return Codec.ZSTD
    elif suffix == ".lz4" or ".json.lz4" in suffixes:
        return Codec.LZ4

    return Codec.NONE


def save_json(
    data: Any,
    path: Union[str, Path],
    indent: int = 2,
    compress: bool = None,
    artifact_type: ArtifactType = ArtifactType.AUTO,
    keep_uncompressed: bool = False,
) -> Path:
    """
    Save JSON data with optimal compression based on artifact type.

    Args:
        data: JSON-serializable data
        path: Output file path (.json extension)
        indent: JSON indentation (default 2)
        compress: Force compression (True/False) or auto-detect (None)
        artifact_type: Type of artifact (determines codec selection)
        keep_uncompressed: Also save uncompressed version (for debugging)

    Returns:
        Path to the saved file (with appropriate extension)

    Codec Selection:
        METADATA:        zstd level 5  (logs, metrics)
        SHIPPING:        zstd level 12 (reports, SBOM)
        CACHE:           lz4           (call-graph, temp files)
        CUSTOMER_FACING: gzip          (downloads, HTML)
    """
    path = Path(path)
    filename = path.name

    # Check if this file should never be compressed
    for pattern in NEVER_COMPRESS:
        if pattern in filename.lower():
            compress = False
            break

    # Serialize to JSON string first to check size
    json_str = json.dumps(data, indent=indent, default=str)
    json_bytes = json_str.encode("utf-8")
    size = len(json_bytes)

    # Auto-detect artifact type if needed
    if artifact_type == ArtifactType.AUTO:
        artifact_type = _detect_artifact_type(filename)

    # Determine if we should compress
    if compress is None:
        compress = size > COMPRESSION_THRESHOLD

    if not compress:
        # Save uncompressed
        with open(path, "w") as f:
            f.write(json_str)
        return path

    # Get codec for this artifact type
    codec, level = _get_codec_for_type(artifact_type)

    # Determine output path with correct extension
    base_path = path.with_suffix("") if path.suffix == ".json" else path
    out_path = Path(str(base_path) + ".json" + codec.extension)

    # Compress and save
    compressed_data = _compress_data(json_bytes, codec, level)
    with open(out_path, "wb") as f:
        f.write(compressed_data)

    # Calculate stats
    compressed_size = len(compressed_data)
    (1 - compressed_size / size) * 100 if size > 0 else 0

    # Optionally keep uncompressed for debugging
    if keep_uncompressed:
        with open(path, "w") as f:
            f.write(json_str)

    return out_path


def load_json(path: Union[str, Path]) -> Any:
    """
    Load JSON data, automatically detecting compression format.

    Tries compressed versions first (.zst, .lz4, .gz), falls back to .json.
    Auto-detects format from magic bytes if extension is ambiguous.

    Args:
        path: File path (with or without compression extension)

    Returns:
        Parsed JSON data
    """
    path = Path(path)
    base_path = path

    # Strip compression extensions to get base path
    path_str = str(path)
    for ext in [".json.zst", ".json.lz4", ".json.gz", ".zst", ".lz4", ".gz"]:
        if path_str.endswith(ext):
            base_path = Path(path_str[: -len(ext)])
            if not base_path.suffix:
                base_path = Path(str(base_path) + ".json")
            break

    # Try compressed versions in order of preference
    for codec in [Codec.ZSTD, Codec.LZ4, Codec.GZIP]:
        compressed_path = Path(str(base_path) + codec.extension)
        if compressed_path.exists():
            with open(compressed_path, "rb") as f:
                data = f.read()

            # Verify codec from magic bytes
            detected_codec = _detect_codec_from_magic(data)
            if detected_codec != Codec.NONE:
                codec = detected_codec

            try:
                decompressed = _decompress_data(data, codec)
                return json.loads(decompressed.decode("utf-8"))
            except Exception:
                continue  # Try next format

    # Try original path if it exists (might be compressed or uncompressed)
    if path.exists():
        with open(path, "rb") as f:
            data = f.read()

        # Check if it's compressed
        codec = _detect_codec_from_magic(data)
        if codec != Codec.NONE:
            decompressed = _decompress_data(data, codec)
            return json.loads(decompressed.decode("utf-8"))

        # It's uncompressed JSON
        return json.loads(data.decode("utf-8"))

    # Try base path without compression
    if base_path.exists() and base_path != path:
        with open(base_path) as f:
            return json.load(f)

    raise FileNotFoundError(f"No JSON file found at {path} or compressed variants ({path}.zst, {path}.lz4, {path}.gz)")


def get_file_size_str(path: Union[str, Path]) -> str:
    """Get human-readable file size."""
    path = Path(path)
    if not path.exists():
        return "N/A"

    size = path.stat().st_size
    for unit in ["B", "KB", "MB", "GB"]:
        if size < 1024:
            return f"{size:.1f} {unit}"
        size /= 1024
    return f"{size:.1f} TB"


def get_compression_stats(original_size: int, compressed_path: Path) -> Dict[str, Any]:
    """Get compression statistics."""
    if not compressed_path.exists():
        return {"error": "File not found"}

    compressed_size = compressed_path.stat().st_size
    ratio = (1 - compressed_size / original_size) * 100 if original_size > 0 else 0
    codec = _detect_codec_from_extension(compressed_path)

    return {
        "original_size": original_size,
        "compressed_size": compressed_size,
        "ratio_percent": round(ratio, 1),
        "savings": original_size - compressed_size,
        "codec": codec.name_str,
    }


def compress_existing_file(
    path: Union[str, Path], artifact_type: ArtifactType = ArtifactType.AUTO, remove_original: bool = True
) -> Path:
    """
    Compress an existing JSON file with optimal codec.

    Args:
        path: Path to JSON file
        artifact_type: Type of artifact (determines codec)
        remove_original: Delete original after compression

    Returns:
        Path to compressed file
    """
    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(f"File not found: {path}")

    data = load_json(path)
    compressed_path = save_json(data, path, artifact_type=artifact_type, compress=True)

    if remove_original and path.exists() and compressed_path != path:
        path.unlink()

    return compressed_path


def decompress_file(compressed_path: Union[str, Path], remove_compressed: bool = False) -> Path:
    """
    Decompress a compressed JSON file.

    Args:
        compressed_path: Path to compressed file
        remove_compressed: Delete compressed file after decompression

    Returns:
        Path to decompressed file
    """
    compressed_path = Path(compressed_path)
    if not compressed_path.exists():
        raise FileNotFoundError(f"File not found: {compressed_path}")

    # Determine output path
    path_str = str(compressed_path)
    for ext in [".json.zst", ".json.lz4", ".json.gz", ".zst", ".lz4", ".gz"]:
        if path_str.endswith(ext):
            out_path = Path(path_str[: -len(ext)])
            if not out_path.suffix:
                out_path = Path(str(out_path) + ".json")
            break
    else:
        out_path = compressed_path.with_suffix(".json")

    data = load_json(compressed_path)
    with open(out_path, "w") as f:
        json.dump(data, f, indent=2, default=str)

    if remove_compressed:
        compressed_path.unlink()

    return out_path


def print_codec_availability():
    """Print available compression codecs."""
    logger.info("Compression Codec Availability:")
    logger.info(" gzip: Always available (stdlib)")
    logger.info(f" zstd: {'' if ZSTD_AVAILABLE else ''} {'Available' if ZSTD_AVAILABLE else 'pip install zstandard'}")
    logger.info(f" lz4: {'' if LZ4_AVAILABLE else ''} {'Available' if LZ4_AVAILABLE else 'pip install lz4'}")
    logger.info("")
    logger.info("Codec Selection by Artifact Type:")
    for atype, (codec, level) in ARTIFACT_CODEC_MAP.items():
        fallback = ""
        if codec == Codec.ZSTD and not ZSTD_AVAILABLE:
            fallback = " → gzip (fallback)"
        elif codec == Codec.LZ4 and not LZ4_AVAILABLE:
            fallback = " → gzip (fallback)"
        logger.info(f" {atype.value:20} → {codec.name_str} level {level}{fallback}")
