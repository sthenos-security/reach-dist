# Copyright © 2026 Sthenos Security. All rights reserved.

"""
REACHABLE Core Module

Contains core algorithms for reachability analysis.
"""

import logging

logger = logging.getLogger(__name__)

# Existing reachability imports
try:
    from .reachability_pure import build_call_graph, compute_reachability
except ImportError:
    pass

# Provenance (v5.3 - RADR)
try:
    from .provenance import collect_provenance
except ImportError:
    pass

# Callable functions registry (v5.4 - RADR)
try:
    from .callable_functions import extract_callable_functions
except ImportError:
    pass

# Internal entrypoint detection (v5.5 - RADR)
try:
    from .internal_entrypoints import detect_internal_entrypoints
except ImportError:
    pass

# Manifest compiler (v5.6 - RADR)
try:
    from .manifest_compiler import compile_manifest
except ImportError:
    pass

# New logger imports (v5.1) - optional, main logger is in reachable/logger.py
try:
    from .logger import OutputMode, ReachableLogger, configure
    from .logger import get_logger as core_get_logger
except ImportError:
    pass

__all__ = [
    # Reachability
    "compute_reachability",
    "build_call_graph",
    # Provenance (RADR)
    "collect_provenance",
    # Callable functions (RADR)
    "extract_callable_functions",
    # Internal entrypoints (RADR)
    "detect_internal_entrypoints",
    # Manifest compiler (RADR)
    "compile_manifest",
    # Logger (optional)
    "ReachableLogger",
    "OutputMode",
    "core_get_logger",
    "configure",
]
