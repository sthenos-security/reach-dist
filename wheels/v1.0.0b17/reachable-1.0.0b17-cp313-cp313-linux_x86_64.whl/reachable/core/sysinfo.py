#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.
"""
Shared system resource detection.

Used by:
    - reachctl doctor     (system vitals header)
    - reachctl enzo setup (model selection)

Detects OS, architecture, RAM, disk, GPU, and Ollama status without
requiring any third-party packages (psutil is optional for better
RAM estimates on macOS).
"""

from __future__ import annotations

import json
import logging
import os
import platform
import shutil
from dataclasses import dataclass, field
from pathlib import Path
from typing import List, Tuple

logger = logging.getLogger(__name__)

try:
    import urllib.request
except ImportError:
    pass


# ═══════════════════════════════════════════════════════════════════════════
#  Data Model
# ═══════════════════════════════════════════════════════════════════════════


@dataclass
class SystemResources:
    """Detected system resources."""

    os_name: str = ""
    arch: str = ""
    total_ram_gb: float = 0.0
    available_ram_gb: float = 0.0
    disk_free_gb: float = 0.0
    disk_path: str = ""
    gpu_detected: bool = False
    gpu_name: str = ""
    gpu_vram_gb: float = 0.0
    cuda_available: bool = False
    metal_available: bool = False
    ollama_installed: bool = False
    ollama_running: bool = False
    ollama_endpoint: str = ""
    ollama_models: List[str] = field(default_factory=list)


# ═══════════════════════════════════════════════════════════════════════════
#  Detection
# ═══════════════════════════════════════════════════════════════════════════


def detect_resources(
    ollama_endpoint: str = "http://localhost:11434",
    disk_check_path: str | None = None,
) -> SystemResources:
    """Detect system resources.

    Args:
        ollama_endpoint: Ollama API base URL.
        disk_check_path: Explicit path for disk-free check.
            Defaults to ~/.ollama if it exists, else ~/.reachable.
    """
    res = SystemResources(
        os_name=platform.system(),
        arch=platform.machine(),
        ollama_endpoint=ollama_endpoint,
    )

    # ── RAM ────────────────────────────────────────────────────────
    try:
        import psutil  # type: ignore

        mem = psutil.virtual_memory()
        res.total_ram_gb = round(mem.total / 1024**3, 1)
        res.available_ram_gb = round(mem.available / 1024**3, 1)
    except ImportError:
        res.total_ram_gb, res.available_ram_gb = _detect_ram_fallback()

    # ── Disk ───────────────────────────────────────────────────────
    if disk_check_path:
        check_path = disk_check_path
    else:
        ollama_dir = Path.home() / ".ollama"
        reachable_dir = Path.home() / ".reachable"
        check_path = str(
            ollama_dir if ollama_dir.exists() else reachable_dir if reachable_dir.exists() else Path.home()
        )
    try:
        usage = shutil.disk_usage(check_path if os.path.exists(check_path) else str(Path.home()))
        res.disk_free_gb = round(usage.free / 1024**3, 1)
        res.disk_path = check_path
    except OSError:
        pass

    # ── GPU ─────────────────────────────────────────────────────────
    res.gpu_detected, res.gpu_name, res.gpu_vram_gb, res.cuda_available = _detect_gpu()
    if res.os_name == "Darwin" and res.arch == "arm64":
        res.metal_available = True
        if not res.gpu_detected:
            res.gpu_detected = True
            res.gpu_name = "Apple Silicon (Metal)"
            res.gpu_vram_gb = res.total_ram_gb  # unified memory

    # ── Ollama ──────────────────────────────────────────────────────
    res.ollama_installed = shutil.which("ollama") is not None
    res.ollama_running, res.ollama_models = _check_ollama_status(ollama_endpoint)

    return res


# ═══════════════════════════════════════════════════════════════════════════
#  Formatting
# ═══════════════════════════════════════════════════════════════════════════


def format_resources(res: SystemResources, indent: str = "  ") -> str:
    """Format system resources as multi-line string for display.

    Returns plain text (no ANSI) suitable for logger.info() or print().
    """
    lines = []
    lines.append(f"{indent}OS:      {res.os_name} {res.arch}")
    lines.append(f"{indent}RAM:     {res.total_ram_gb}GB total, {res.available_ram_gb}GB available")
    lines.append(f"{indent}Disk:    {res.disk_free_gb}GB free ({res.disk_path})")

    if res.gpu_detected:
        gpu_info = res.gpu_name
        if res.gpu_vram_gb:
            gpu_info += f" ({res.gpu_vram_gb}GB)"
        lines.append(f"{indent}GPU:     {gpu_info}")
    else:
        lines.append(f"{indent}GPU:     None detected")

    return "\n".join(lines)


def format_ollama_status(res: SystemResources, indent: str = "  ") -> str:
    """Format Ollama status line."""
    if res.ollama_running:
        status = "running"
        if res.ollama_models:
            status += f" ({len(res.ollama_models)} model{'s' if len(res.ollama_models) != 1 else ''})"
        return f"{indent}Ollama:  {status}"
    elif res.ollama_installed:
        return f"{indent}Ollama:  installed (not running)"
    else:
        return f"{indent}Ollama:  not installed"


# ═══════════════════════════════════════════════════════════════════════════
#  Internals
# ═══════════════════════════════════════════════════════════════════════════


def _detect_ram_fallback() -> Tuple[float, float]:
    """RAM detection without psutil."""
    total = 0.0
    avail = 0.0
    system = platform.system()
    try:
        if system == "Linux":
            with open("/proc/meminfo") as f:
                for line in f:
                    if line.startswith("MemTotal:"):
                        total = int(line.split()[1]) / 1024 / 1024
                    elif line.startswith("MemAvailable:"):
                        avail = int(line.split()[1]) / 1024 / 1024
        elif system == "Darwin":
            import subprocess

            out = subprocess.check_output(["sysctl", "-n", "hw.memsize"], text=True)
            total = int(out.strip()) / 1024**3
            # macOS doesn't expose "available" easily without psutil
            avail = total * 0.5  # conservative estimate
    except Exception as exc:
        logger.debug("RAM detection fallback failed: %s", exc)
    return round(total, 1), round(avail, 1)


def _detect_gpu() -> Tuple[bool, str, float, bool]:
    """Detect NVIDIA GPU via nvidia-smi. Returns (detected, name, vram_gb, cuda)."""
    try:
        import subprocess

        out = subprocess.check_output(
            ["nvidia-smi", "--query-gpu=name,memory.total", "--format=csv,noheader,nounits"],
            text=True,
            timeout=5,
        )
        for line in out.strip().split("\n"):
            parts = [p.strip() for p in line.split(",")]
            if len(parts) >= 2:
                name = parts[0]
                vram = float(parts[1]) / 1024  # MiB to GiB
                return True, name, round(vram, 1), True
    except (FileNotFoundError, Exception):
        pass
    return False, "", 0.0, False


def _check_ollama_status(endpoint: str) -> Tuple[bool, List[str]]:
    """Check if Ollama is running and list pulled models."""
    try:
        req = urllib.request.Request(f"{endpoint}/api/tags", method="GET")
        with urllib.request.urlopen(req, timeout=3) as resp:
            data = json.loads(resp.read())
            models = [m.get("name", "") for m in data.get("models", [])]
            return True, models
    except Exception:
        return False, []
