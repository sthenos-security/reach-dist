#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.

"""
Callable Functions Registry for RADR.

Extracts all third-party functions called by application code,
grouped by package. This data powers:
  1. RADR runtime agent — knows which functions to monitor
  2. Proactive alerting — new CVE? check if any repo calls that function
  3. RADR manifest — compiled into agent-ready probe targets

Architecture:
  call_graph (app.X → lib.Y edges) + entrypoints + reachability
  → callable_functions.json

Usage:
    from reachable.core.callable_functions import extract_callable_functions

    registry = extract_callable_functions(
        call_graph=analyzer.call_graph,
        all_functions=analyzer.all_functions,
        reachable_functions=analyzer.reachable_functions,
        entrypoints=analyzer.entrypoints,
        function_metadata=analyzer.function_metadata,
        call_parents=getattr(analyzer, 'call_parents', {}),
    )
    # registry is a dict ready to save as callable-functions.json
"""

import logging
from collections import defaultdict
from typing import Any, Dict, List, Optional, Set

logger = logging.getLogger(__name__)


def _get_lib_package_name(func_name: str) -> Optional[str]:
    """
    Extract the top-level package name from a lib function.

    lib.requests.api.get           → requests
    lib.urllib3.poolmanager.Pool    → urllib3
    lib.flask.app.Flask.run        → flask
    lib.com.google.gson.Gson.parse → com.google.gson  (Java)
    """
    if not func_name.startswith("lib."):
        return None

    parts = func_name.split(".")
    if len(parts) < 3:
        return None

    # parts[0] = 'lib', parts[1] = package_name
    return parts[1]


def _get_function_short_name(func_name: str) -> str:
    """
    Get the function name without the lib./app. prefix and package.

    lib.requests.api.get                    → requests.api.get
    lib.flask.app.Flask.run                 → flask.app.Flask.run
    app.handlers.create_user                → handlers.create_user
    """
    parts = func_name.split(".", 1)
    if len(parts) > 1 and parts[0] in ("lib", "app"):
        return parts[1]
    return func_name


def _reconstruct_call_path(
    func: str,
    call_parents: Dict[str, Any],
    max_depth: int = 20,
) -> List[str]:
    """
    Reconstruct the call path from entrypoint to function.

    Returns list from entrypoint -> ... -> func.

    T-CG30 FIX: call_parents is Dict[str, List[str]] (multi-parent BFS tree),
    NOT Dict[str, Optional[str]].  Each value is a list of parent function names.
    We follow the first parent to reconstruct a single representative path.
    """
    path = [func]
    current = func
    visited: Set[str] = {func}
    depth = 0
    while depth < max_depth:
        parents = call_parents.get(current)
        if not parents:
            break
        # parents may be a list (multi-parent) or a legacy single string
        if isinstance(parents, list):
            if not parents:
                break
            parent = parents[0]
        else:
            parent = parents  # legacy single-string fallback
        if not isinstance(parent, str) or parent in visited:
            break
        visited.add(parent)
        path.append(parent)
        current = parent
        depth += 1
    path.reverse()
    return path


def _compute_call_depth(
    func: str,
    call_parents: Dict[str, Any],
    entrypoints: Set[str],
    max_depth: int = 50,
) -> int:
    """Compute hops from nearest entrypoint to this function.

    T-CG30 FIX: same multi-parent handling as _reconstruct_call_path.
    """
    current = func
    visited: Set[str] = {func}
    depth = 0
    while depth < max_depth:
        parents = call_parents.get(current)
        if not parents:
            break
        parent = parents[0] if isinstance(parents, list) else parents
        if not isinstance(parent, str) or parent in visited:
            break
        if parent in entrypoints:
            return depth + 1
        visited.add(parent)
        current = parent
        depth += 1
    return depth + 1  # Include the final hop


def extract_callable_functions(
    call_graph: Dict[str, Set[str]],
    all_functions: Set[str],
    reachable_functions: Set[str],
    entrypoints: Set[str],
    function_metadata: Dict[str, Dict[str, Any]],
    call_parents: Optional[Dict[str, Optional[str]]] = None,
    cve_functions: Optional[Dict[str, List[str]]] = None,
) -> Dict[str, Any]:
    """
    Extract the callable functions registry from analyzer data.

    Finds all edges that cross the app→lib boundary and groups
    by package, tracking callers, entrypoints, and CVE associations.

    Args:
        call_graph: Function call graph (caller → set of callees)
        all_functions: All known functions
        reachable_functions: Functions reachable from entrypoints
        entrypoints: Set of entrypoint function names
        function_metadata: func → {project_tag, file_path, line_number}
        call_parents: func → parent (for path reconstruction)
        cve_functions: Optional mapping of lib function → [CVE IDs]

    Returns:
        Dict with structure:
        {
            "schema_version": "1.0",
            "statistics": { ... },
            "packages": {
                "requests": {
                    "functions": {
                        "requests.api.get": {
                            "callers": [...],
                            "entrypoints": [...],
                            "call_depth": 2,
                            "is_reachable": true,
                            "cves": []
                        }
                    }
                }
            }
        }
    """
    call_parents = call_parents or {}
    cve_functions = cve_functions or {}

    # Registry: package → function → metadata
    packages: Dict[str, Dict[str, Dict[str, Any]]] = defaultdict(
        lambda: defaultdict(
            lambda: {
                "callers": [],
                "entrypoints": set(),
                "call_depth": 999,
                "is_reachable": False,
                "cves": [],
            }
        )
    )

    # Track stats
    total_edges = 0
    total_packages = set()

    # Build simple name → full qualified name index for fuzzy resolution.
    # The call graph stores callees as bare AST names (e.g. 'PdfReader',
    # 'requests.get') while all_functions has the full lib-prefixed names
    # (e.g. 'lib.pypdf.pypdf._reader.PdfReader'). This mirrors the same
    # fuzzy matching used by _compute_reachability's BFS traversal.
    simple_to_lib: Dict[str, List[str]] = {}
    for func in all_functions:
        if not func.startswith("lib."):
            continue
        simple = func.split(".")[-1] if "." in func else func
        if simple not in simple_to_lib:
            simple_to_lib[simple] = []
        simple_to_lib[simple].append(func)

    def _resolve_callee(callee: str) -> Optional[str]:
        """Resolve a bare callee name to its full lib.* qualified name."""
        # Already qualified
        if callee.startswith("lib."):
            return callee
        # Try simple name lookup
        simple = callee.split(".")[-1] if "." in callee else callee
        candidates = simple_to_lib.get(simple, [])
        if len(candidates) == 1:
            return candidates[0]
        if len(candidates) > 1:
            # Prefer candidate whose package matches the import name
            # e.g. callee='requests.get' → prefer 'lib.requests.api.get'
            callee_parts = callee.split(".")
            for c in candidates:
                if callee_parts[0] in c:
                    return c
            return candidates[0]  # fallback to first
        return None

    # Scan all call graph edges for app→lib crossings
    for caller, callees in call_graph.items():
        # Only app code calling library code
        if not caller.startswith("app."):
            continue

        # Is this caller reachable from entrypoints?
        caller_reachable = caller in reachable_functions

        for callee in callees:
            # Resolve bare callee names to full lib.* names
            resolved = _resolve_callee(callee)
            if not resolved:
                continue
            callee = resolved

            pkg = _get_lib_package_name(callee)
            if not pkg:
                continue

            total_edges += 1
            total_packages.add(pkg)

            func_short = _get_function_short_name(callee)
            entry = packages[pkg][func_short]

            # Add caller info
            caller_short = _get_function_short_name(caller)
            meta = function_metadata.get(caller, {})
            caller_info = {
                "function": caller_short,
                "file": meta.get("file_path", ""),
                "line": meta.get("line_number", 0),
            }

            # Avoid duplicate callers
            existing_funcs = {c["function"] for c in entry["callers"]}
            if caller_short not in existing_funcs:
                entry["callers"].append(caller_info)

            # Track entrypoints that reach this library function
            if caller_reachable:
                entry["is_reachable"] = True

                # Find which entrypoint reaches this caller
                path = _reconstruct_call_path(caller, call_parents)
                if path and path[0] in entrypoints:
                    entry["entrypoints"].add(path[0])

                # Update call depth (minimum across all paths)
                depth = _compute_call_depth(caller, call_parents, entrypoints)
                entry["call_depth"] = min(entry["call_depth"], depth)

    # Post-process: add CVE associations, convert sets to lists
    result_packages = {}
    for pkg, functions in packages.items():
        result_functions = {}
        for func_name, entry in functions.items():
            # Check for CVE associations
            cves = []
            for cve_func, cve_ids in cve_functions.items():
                if func_name in cve_func or cve_func in func_name:
                    cves.extend(cve_ids)
            entry["cves"] = list(set(cves))

            # Convert entrypoints set to sorted list
            entry["entrypoints"] = sorted(entry["entrypoints"])

            # Clamp call_depth
            if entry["call_depth"] == 999:
                entry["call_depth"] = -1  # Unknown

            result_functions[func_name] = entry

        result_packages[pkg] = {
            "function_count": len(result_functions),
            "functions": result_functions,
        }

    # Sort packages by function count (most called first)
    sorted_packages = dict(sorted(result_packages.items(), key=lambda x: x[1]["function_count"], reverse=True))

    # Build stats
    total_lib_functions = sum(p["function_count"] for p in sorted_packages.values())
    reachable_lib_functions = sum(
        1 for p in sorted_packages.values() for f in p["functions"].values() if f["is_reachable"]
    )

    registry = {
        "schema_version": "1.0",
        "statistics": {
            "total_packages": len(sorted_packages),
            "total_lib_functions_called": total_lib_functions,
            "reachable_lib_functions": reachable_lib_functions,
            "total_app_to_lib_edges": total_edges,
        },
        "packages": sorted_packages,
    }

    logger.info(
        f" Callable functions: {total_lib_functions} functions "
        f"across {len(sorted_packages)} packages "
        f"({reachable_lib_functions} reachable)"
    )

    return registry
