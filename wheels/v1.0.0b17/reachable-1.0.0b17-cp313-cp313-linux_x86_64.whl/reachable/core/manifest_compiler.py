#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.

"""
RADR Manifest Compiler (v5.6).

Compiles scan results into an agent-ready manifest for the RADR runtime SDK/agent.

Usage:
    reachctl manifest compile \\
        --scan-dir .reachable/scans/latest \\
        --image-tag ghcr.io/acme/backend:v1.2.3 \\
        --image-digest sha256:abc123def... \\
        --sign --key cosign.key \\
        --output manifest.json

Input files (from scan-dir):
    - provenance.json          (R1: build provenance)
    - callable-functions.json  (R2: app→lib function registry)
    - internal-entrypoints.json (R3: non-HTTP entrypoints)
    - reachable-report.json.gz  (main scan report)
    - scan-manifest.json        (scan metadata)

Output:
    manifest.json — agent-ready RADR manifest with:
    - probe_targets (language-specific monitoring config)
    - active_findings (CVEs mapped to callable functions)
    - entrypoints (HTTP + internal)
    - baseline_profile (expected runtime behavior)
    - radr_capabilities (coverage estimates)
    - anomaly_detection config

From module:
    from reachable.core.manifest_compiler import compile_manifest
"""

import gzip
import hashlib
import json
import logging
import subprocess
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Tuple

logger = logging.getLogger(__name__)

MANIFEST_VERSION = "1.0.0"
SCHEMA_VERSION = "1.0"


# =============================================================================
# FILE LOADERS
# =============================================================================


def _load_json(path: Path) -> Optional[Dict]:
    """Load a JSON file, return None if missing or invalid."""
    if not path.exists():
        logger.debug(f"File not found: {path}")
        return None
    try:
        with open(path) as f:
            return json.load(f)
    except (json.JSONDecodeError, OSError) as e:
        logger.warning(f"Failed to load {path}: {e}")
        return None


def _load_report(scan_dir: Path) -> Optional[Dict]:
    """Load the main reachable report (supports .json.gz and .json)."""
    gz_path = scan_dir / "reachable-report.json.gz"
    json_path = scan_dir / "reachable-report.json"

    if gz_path.exists():
        try:
            with gzip.open(gz_path, "rt") as f:
                return json.load(f)
        except Exception as e:
            logger.warning(f"Failed to load {gz_path}: {e}")

    if json_path.exists():
        return _load_json(json_path)

    logger.warning(f"No reachable-report found in {scan_dir}")
    return None


# =============================================================================
# LANGUAGE DETECTION HEURISTICS
# =============================================================================


def _looks_like_go(func_name: str) -> bool:
    """Go functions use / in package paths: net/http.(*Client).Do"""
    return "/" in func_name


def _looks_like_java(func_name: str) -> bool:
    """Java uses org., com., java., javax., io., net. prefixes."""
    java_prefixes = ("org.", "com.", "java.", "javax.", "io.spring", "io.micrometer")
    return any(func_name.startswith(p) for p in java_prefixes)


def _looks_like_node(func_name: str, pkg_name: str) -> bool:
    """Node packages often use @scope/name or well-known npm names."""
    if pkg_name.startswith("@"):
        return True
    node_pkgs = {
        "express",
        "axios",
        "lodash",
        "moment",
        "react",
        "next",
        "fastify",
        "koa",
        "hapi",
        "socket.io",
        "ws",
        "bull",
        "ioredis",
    }
    return pkg_name.lower() in node_pkgs


def _split_java_method(func_name: str) -> Tuple[str, str]:
    """Split 'org.apache.http.Client.execute' → ('org.apache.http.Client', 'execute')."""
    parts = func_name.rsplit(".", 1)
    if len(parts) == 2:
        return parts[0], parts[1]
    return func_name, ""


def _detect_languages_from_callable(callable_funcs: Dict) -> Set[str]:
    """Detect which languages are present based on callable function patterns."""
    languages = set()
    packages = callable_funcs.get("packages", {})
    for pkg_name, pkg_data in packages.items():
        for func_name in pkg_data.get("functions", {}):
            if _looks_like_go(func_name):
                languages.add("go")
            elif _looks_like_java(func_name):
                languages.add("java")
            elif _looks_like_node(func_name, pkg_name):
                languages.add("nodejs")
            else:
                languages.add("python")
    return languages


# =============================================================================
# PROBE TARGET GENERATION
# =============================================================================


def _build_cve_risk_map(report: Optional[Dict]) -> Dict[str, Dict]:
    """Build function→risk mapping from CVE data in scan report."""
    risk_map = {}
    if not report:
        return risk_map

    reachable_cves = report.get("reachable", {})
    for cve_id, cve_data in reachable_cves.items():
        func = cve_data.get("vulnerable_function", "")
        if not func:
            continue
        severity = cve_data.get("severity", "UNKNOWN")
        risk = {"CRITICAL": 1000, "HIGH": 500, "MEDIUM": 200, "LOW": 50}.get(severity, 100)
        if func not in risk_map:
            risk_map[func] = {"risk": risk, "cves": []}
        risk_map[func]["cves"].append(cve_id)
        risk_map[func]["risk"] = max(risk_map[func]["risk"], risk)
    return risk_map


def _build_probe_targets(
    callable_funcs: Dict,
    report: Optional[Dict],
) -> Dict[str, Any]:
    """
    Build probe_targets from callable functions registry.

    Groups functions by language runtime and generates the appropriate
    probe configuration for each:
    - interpreter_probes: Python (CPython uprobe), Node.js (module wrap)
    - binary_probes: Go, Rust (ELF uprobe)
    - jvm_probes: Java (JVMTI agent)
    """
    cve_risk_map = _build_cve_risk_map(report)
    packages = callable_funcs.get("packages", {})

    # Buckets by language
    python_modules: Dict[str, Dict] = {}
    node_modules: Dict[str, Dict] = {}
    go_functions: Dict[str, Dict] = {}
    java_classes: Dict[str, Dict] = {}

    for pkg_name, pkg_data in packages.items():
        functions = pkg_data.get("functions", {})
        for func_name, func_data in functions.items():
            # Get CVE/risk info
            risk_info = cve_risk_map.get(func_name, {"risk": 0, "cves": []})
            cves = func_data.get("cves", []) or risk_info["cves"]
            risk = risk_info["risk"]

            func_entry = {"risk": risk, "cves": cves}

            # Route to language bucket
            if _looks_like_go(func_name):
                go_functions[func_name] = func_entry
            elif _looks_like_java(func_name):
                class_name, method = _split_java_method(func_name)
                if class_name not in java_classes:
                    java_classes[class_name] = {"methods": {}}
                java_classes[class_name]["methods"][method] = func_entry
            elif _looks_like_node(func_name, pkg_name):
                if pkg_name not in node_modules:
                    node_modules[pkg_name] = {"functions": {}}
                node_modules[pkg_name]["functions"][func_name] = func_entry
            else:
                if pkg_name not in python_modules:
                    python_modules[pkg_name] = {"functions": {}}
                python_modules[pkg_name]["functions"][func_name] = func_entry

    # Build probe sections
    result = {}
    interpreter_probes = []
    binary_probes = []
    jvm_probes = []

    if python_modules:
        interpreter_probes.append(
            {
                "language": "python",
                "runtime_binary": "/usr/local/bin/python3",
                "probe_type": "uprobe",
                "probe_function": "_PyEval_EvalFrameDefault",
                "monitored_modules": python_modules,
            }
        )

    if node_modules:
        interpreter_probes.append(
            {
                "language": "nodejs",
                "runtime_binary": "/usr/local/bin/node",
                "probe_type": "module_wrap",
                "monitored_modules": node_modules,
            }
        )

    if go_functions:
        binary_probes.append(
            {
                "language": "go",
                "binary_path": "/app/main",
                "stripped": False,
                "probe_type": "uprobe",
                "functions": go_functions,
            }
        )

    if java_classes:
        jvm_probes.append(
            {
                "language": "java",
                "jvm_path": "/usr/lib/jvm/java-21/bin/java",
                "probe_type": "jvmti_agent",
                "classes": java_classes,
            }
        )

    if interpreter_probes:
        result["interpreter_probes"] = interpreter_probes
    if binary_probes:
        result["binary_probes"] = binary_probes
    if jvm_probes:
        result["jvm_probes"] = jvm_probes

    return result


# =============================================================================
# ENTRYPOINT COMPILATION
# =============================================================================


def _build_entrypoints(
    internal_eps: Optional[Dict],
    report: Optional[Dict],
) -> List[Dict[str, Any]]:
    """
    Compile entrypoints from internal detection (R3) + scan report HTTP handlers.
    """
    entrypoints = []
    ep_id = 0

    # HTTP entrypoints from scan report
    # Entrypoints live at call_graph.entrypoints (list of function names)
    # or metadata.entrypoints (legacy). Filter for app.* functions only.
    if report:
        raw_eps = report.get("call_graph", {}).get("entrypoints", []) or report.get("metadata", {}).get(
            "entrypoints", []
        )
        for ep in raw_eps:
            if isinstance(ep, str):
                # Only include app entrypoints (skip lib.* functions)
                if not ep.startswith("app."):
                    continue
                ep_id += 1
                # Extract short handler name from e.g. 'app.app.parse_pdf'
                handler = ep.split(".")[-1] if "." in ep else ep
                entrypoints.append(
                    {
                        "id": f"ep_{ep_id:03d}",
                        "type": "http_handler",
                        "function": ep,
                        "handler": handler,
                    }
                )
            elif isinstance(ep, dict):
                ep_id += 1
                entrypoints.append(
                    {
                        "id": f"ep_{ep_id:03d}",
                        "type": ep.get("type", "http_handler"),
                        "handler": ep.get("handler", ep.get("function", str(ep))),
                        "function": ep.get("function", ""),
                        "method": ep.get("method", ""),
                        "path": ep.get("path", ""),
                    }
                )

    # Internal entrypoints from R3
    if internal_eps:
        for ep_data in internal_eps.get("entrypoints", []):
            ep_id += 1
            entry = {
                "id": f"ep_{ep_id:03d}",
                "type": ep_data.get("type", "unknown"),
                "framework": ep_data.get("framework", ""),
                "handler": ep_data.get("handler", ep_data.get("function", "")),
                "function": ep_data.get("function", ""),
                "confidence": ep_data.get("confidence", "MEDIUM"),
            }
            if ep_data.get("schedule"):
                entry["schedule"] = ep_data["schedule"]
            entrypoints.append(entry)

    return entrypoints


# =============================================================================
# ACTIVE FINDINGS
# =============================================================================


def _build_active_findings(
    callable_funcs: Dict,
    report: Optional[Dict],
) -> List[Dict[str, Any]]:
    """
    Build active_findings from CVE data mapped to callable functions.

    Only includes CVEs where the vulnerable function is actually called
    by the application (confirmed via callable functions registry).
    """
    findings = []
    if not report:
        return findings

    reachable_cves = report.get("reachable", {})
    packages = callable_funcs.get("packages", {})

    # Build set of all called functions for fast lookup
    called_functions: Set[str] = set()
    for pkg_data in packages.values():
        called_functions.update(pkg_data.get("functions", {}).keys())

    for cve_id, cve_data in reachable_cves.items():
        vuln_func = cve_data.get("vulnerable_function", "")

        # Check if vulnerable function is directly called
        is_called = vuln_func in called_functions
        # Also check partial match (e.g. requests.adapters.HTTPAdapter.send
        # might be tracked as requests.HTTPAdapter.send)
        if not is_called:
            is_called = any(vuln_func in f or f in vuln_func for f in called_functions)

        findings.append(
            {
                "cve_id": cve_id,
                "package": cve_data.get("package", ""),
                "version": cve_data.get("version", ""),
                "function": vuln_func,
                "severity": cve_data.get("severity", "UNKNOWN"),
                "epss_score": cve_data.get("epss_score"),
                "is_called": is_called,
                "reachability_status": "confirmed_callable" if is_called else "reachable_static_only",
            }
        )

    # Sort: CRITICAL first, then HIGH, etc.
    severity_order = {"CRITICAL": 0, "HIGH": 1, "MEDIUM": 2, "LOW": 3, "UNKNOWN": 4}
    return sorted(
        findings,
        key=lambda x: (
            severity_order.get(x["severity"], 5),
            not x["is_called"],  # Called functions first
            x["cve_id"],
        ),
    )


# =============================================================================
# BASELINE PROFILE
# =============================================================================


def _build_baseline_profile(
    callable_funcs: Dict,
    entrypoints: List[Dict],
) -> Dict[str, Any]:
    """
    Build baseline profile — what's expected to execute at runtime.

    The agent compares observed execution against this baseline:
    - expected_functions: functions the static analysis says are reachable
    - expected_entrypoints: all known entry points into the application
    """
    expected_functions = set()
    packages = callable_funcs.get("packages", {})

    for pkg_data in packages.values():
        for func_name, func_data in pkg_data.get("functions", {}).items():
            if func_data.get("is_reachable", True):
                expected_functions.add(func_name)

    expected_entrypoints = sorted(set(ep.get("handler", "") for ep in entrypoints if ep.get("handler")))

    return {
        "expected_functions": sorted(expected_functions),
        "expected_entrypoints": expected_entrypoints,
        "function_count": len(expected_functions),
        "entrypoint_count": len(entrypoints),
    }


# =============================================================================
# RADR CAPABILITIES
# =============================================================================


def _build_radr_capabilities(
    internal_eps: Optional[Dict],
    callable_funcs: Dict,
) -> Dict[str, Any]:
    """Build radr_capabilities section documenting coverage level."""
    # Determine which entrypoint types were detected
    ep_types = set()
    if internal_eps:
        for ep in internal_eps.get("entrypoints", []):
            ep_types.add(ep.get("type", ""))

    stats = callable_funcs.get("statistics", {})

    return {
        "entrypoint_coverage": {
            "http_handlers": True,
            "queue_consumers": "queue" in ep_types,
            "schedulers": "timer" in ep_types,
            "background_threads": "thread" in ep_types,
            "startup_hooks": "startup" in ep_types,
            "signal_handlers": "signal" in ep_types,
            "cli_commands": "cli" in ep_types,
        },
        "call_graph_confidence": {
            "static_edges": stats.get("total_app_to_lib_edges", 0),
            "lib_functions_tracked": stats.get("total_lib_functions_called", 0),
            "reachable_lib_functions": stats.get("reachable_lib_functions", 0),
            "confidence_level": "high_for_idiomatic_paths",
        },
        "limitations": [
            "reflection_not_fully_resolved",
            "dynamic_imports_marked_unknown",
            "ffi_boundaries_not_crossed",
        ],
    }


# =============================================================================
# CORRELATED SIGNALS
# =============================================================================


def _build_correlated_signals(report: Optional[Dict]) -> List[Dict[str, Any]]:
    """
    Extract correlated multi-signal findings from report.

    These represent compound risk: e.g. a reachable CVE in code that also
    handles secrets or has CWE weaknesses.
    """
    signals = []
    if not report:
        return signals

    # Extract secrets count
    detailed = report.get("detailed_findings", {})
    secrets = detailed.get("secrets", {}).get("findings", [])
    if secrets:
        signals.append(
            {
                "signal_type": "secrets",
                "count": len(secrets),
                "severity": "HIGH",
            }
        )

    # Extract CWE count
    cwes = detailed.get("cwe", {}).get("findings", [])
    if cwes:
        signals.append(
            {
                "signal_type": "code_weaknesses",
                "count": len(cwes),
                "severity": "MEDIUM",
            }
        )

    # Extract malware count
    malware = detailed.get("malware", {}).get("findings", [])
    if malware:
        signals.append(
            {
                "signal_type": "malware",
                "count": len(malware),
                "severity": "CRITICAL",
            }
        )

    return signals


# =============================================================================
# SIGNING
# =============================================================================


def _compute_digest(manifest_bytes: bytes) -> str:
    """Compute SHA-256 digest of manifest content."""
    return "sha256:" + hashlib.sha256(manifest_bytes).hexdigest()


def _sign_manifest(
    manifest_path: Path,
    key_path: str,
) -> Optional[Dict[str, str]]:
    """
    Sign manifest with cosign.

    Returns signature metadata or None if signing fails/unavailable.
    """
    try:
        result = subprocess.run(
            ["cosign", "sign-blob", "--key", key_path, "--yes", str(manifest_path)],
            capture_output=True,
            text=True,
            timeout=30,
        )
        if result.returncode == 0:
            return {
                "algorithm": "cosign",
                "signature": result.stdout.strip(),
            }
        else:
            logger.warning(f"cosign signing failed: {result.stderr.strip()}")
    except FileNotFoundError:
        logger.debug("cosign not found in PATH, skipping signing")
    except subprocess.TimeoutExpired:
        logger.warning("cosign timed out after 30s")
    except Exception as e:
        logger.debug(f"Signing failed: {e}")

    return None


# =============================================================================
# MAIN COMPILER
# =============================================================================


def compile_manifest(
    scan_dir,
    image_tag=None,
    image_digest=None,
    sign_key=None,
    output_path=None,
):
    """
    Compile scan results into an agent-ready RADR manifest.

    Args:
        scan_dir: Directory containing scan outputs (Path or str)
        image_tag: Container image tag (e.g. ghcr.io/acme/backend:v1.2.3)
        image_digest: Container image digest (e.g. sha256:abc123...)
        sign_key: Path to cosign private key for signing
        output_path: Where to write manifest.json (Path or str, optional)

    Returns:
        dict: Compiled manifest dictionary

    The manifest merges data from four RADR prerequisite phases:
        R1 provenance.json → repo/commit/branch/tag/image metadata
        R2 callable-functions.json → probe_targets + active_findings
        R3 internal-entrypoints.json → entrypoints list
        Scan report → CVE data, secrets, CWE for correlated signals
    """
    scan_dir = Path(scan_dir)
    logger.info(f"Compiling RADR manifest from {scan_dir}")

    # ── Step 1: Load all input files ──────────────────────────────────────
    provenance = _load_json(scan_dir / "provenance.json") or {}
    callable_funcs = _load_json(scan_dir / "callable-functions.json") or {"packages": {}, "statistics": {}}
    internal_eps = _load_json(scan_dir / "internal-entrypoints.json")
    scan_meta = _load_json(scan_dir / "scan-manifest.json") or {}
    report = _load_report(scan_dir)

    loaded = sum(1 for x in [provenance, callable_funcs.get("packages"), internal_eps, report] if x)
    logger.info(f"  Loaded {loaded}/4 input files")

    # ── Step 2: Extract provenance ────────────────────────────────────────
    # Support both key formats: source_provenance (from collect_provenance)
    # and source (shortened). Same for build/ci and image.
    source_prov = provenance.get("source_provenance", provenance.get("source", {}))
    build_prov = provenance.get("build_provenance", provenance.get("ci", {}))
    image_prov = provenance.get("image_provenance", provenance.get("image", {}))

    # CLI overrides take precedence
    if image_tag:
        image_prov["image_tag"] = image_tag
    if image_digest:
        image_prov["image_digest"] = image_digest

    # ── Step 3: Build manifest sections ───────────────────────────────────
    probe_targets = _build_probe_targets(callable_funcs, report)
    entrypoints = _build_entrypoints(internal_eps, report)
    active_findings = _build_active_findings(callable_funcs, report)
    baseline = _build_baseline_profile(callable_funcs, entrypoints)
    radr_caps = _build_radr_capabilities(internal_eps, callable_funcs)
    correlated = _build_correlated_signals(report)

    # ── Step 4: Assemble manifest ─────────────────────────────────────────
    manifest = {
        "manifest_version": MANIFEST_VERSION,
        "schema_version": SCHEMA_VERSION,
        "generated_at": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
        # Provenance
        "repo": source_prov.get("remote_url", source_prov.get("repository", "")),
        "commit": source_prov.get("commit_sha", ""),
        "branch": source_prov.get("branch", ""),
        "tag": source_prov.get("tag", ""),
        # Image
        "image_tag": image_prov.get("image_tag", image_tag or ""),
        "image_digest": image_prov.get("image_digest", image_digest or ""),
        # Build context
        "build": {
            "ci_provider": build_prov.get("ci_provider", ""),
            "ci_run_id": build_prov.get("ci_run_id", ""),
            "ci_run_url": build_prov.get("ci_run_url", ""),
            "scanner_version": scan_meta.get("scanner_version", provenance.get("scanner_version", "")),
        },
        # RADR capabilities & coverage
        "radr_capabilities": radr_caps,
        # Entrypoints (HTTP + internal)
        "entrypoints": entrypoints,
        # Probe targets (language-specific monitoring config)
        "probe_targets": probe_targets,
        # Active findings (CVEs with callable function mapping)
        "active_findings": active_findings,
        # Correlated multi-signal findings
        "correlated_signals": correlated,
        # Baseline profile (expected runtime behavior)
        "baseline_profile": baseline,
        # Anomaly detection configuration
        "anomaly_detection": {
            "mode": "observe_and_compare",
            "alert_on": ["impossible", "unmodeled_dynamic"],
            "baseline_window_days": 7,
        },
    }

    # ── Step 5: Compute content digest ────────────────────────────────────
    manifest_bytes = json.dumps(manifest, indent=2, sort_keys=True).encode("utf-8")
    manifest["digest"] = _compute_digest(manifest_bytes)

    # ── Step 6: Write output ──────────────────────────────────────────────
    if output_path:
        output_path = Path(output_path)
        output_path.parent.mkdir(parents=True, exist_ok=True)
        with open(output_path, "w") as f:
            json.dump(manifest, f, indent=2)
        logger.info(f"  Manifest written to {output_path}")

        # ── Step 7: Sign if requested ─────────────────────────────────────
        if sign_key:
            sig = _sign_manifest(output_path, sign_key)
            if sig:
                manifest["signature"] = sig
                with open(output_path, "w") as f:
                    json.dump(manifest, f, indent=2)
                logger.info("  Manifest signed with cosign")

    # ── Summary ───────────────────────────────────────────────────────────
    stats = callable_funcs.get("statistics", {})
    logger.info(
        f"  Manifest compiled: "
        f"{stats.get('total_packages', 0)} packages, "
        f"{stats.get('total_lib_functions_called', 0)} functions, "
        f"{len(entrypoints)} entrypoints, "
        f"{len(active_findings)} findings"
    )

    return manifest
