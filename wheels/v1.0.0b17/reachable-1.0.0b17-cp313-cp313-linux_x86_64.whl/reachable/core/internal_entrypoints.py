#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.

"""
Internal Entrypoint Detection for RADR (v5.5).

Current entrypoint detection is HTTP-centric (Flask routes, Express handlers,
Go HTTP handlers). This misses 40-65% of production execution originating from:
  - Timers & schedulers (setTimeout, cron, @Scheduled)
  - Message queues (Kafka, RabbitMQ, SQS consumers)
  - Background threads (goroutines, asyncio tasks, Thread)
  - Startup hooks (@PostConstruct, init(), module-level code)
  - Signal handlers (SIGTERM, process.on)
  - CLI subcommands (Click, argparse, cobra)

Detection strategy:
  1. Scan call graph for calls to known entrypoint-creating functions
  2. Scan function names for decorator/annotation patterns
  3. Scan imports for framework indicators
  4. Output typed entrypoints with framework and schedule info

Usage:
    from reachable.core.internal_entrypoints import detect_internal_entrypoints

    entrypoints = detect_internal_entrypoints(
        call_graph=analyzer.call_graph,
        all_functions=analyzer.all_functions,
        imports_map=analyzer.imports_map,
        function_imports=analyzer.function_imports,
    )
    # Returns list of InternalEntrypoint dicts
"""

import logging
import re
from dataclasses import asdict, dataclass
from typing import Any, Dict, List, Optional, Set

logger = logging.getLogger(__name__)


# =============================================================================
# ENTRYPOINT TYPE DEFINITIONS
# =============================================================================


@dataclass
class InternalEntrypoint:
    """Detected internal entrypoint."""

    function: str  # Fully qualified function name
    type: str  # Category: timer, queue, thread, startup, signal, cli, event
    framework: str  # Framework: celery, asyncio, kafka, spring, etc.
    handler: str  # Short function name
    schedule: Optional[str] = None  # Cron expression or interval if applicable
    confidence: str = "HIGH"  # HIGH, MEDIUM, LOW
    detection_reason: str = ""  # Why this was detected

    def to_dict(self) -> Dict[str, Any]:
        d = asdict(self)
        if d["schedule"] is None:
            del d["schedule"]
        return d


# =============================================================================
# PATTERN DEFINITIONS PER LANGUAGE
# =============================================================================

# Each pattern: (callee_pattern, entrypoint_type, framework, confidence)
# callee_pattern matches against callees in the call graph

PYTHON_CALL_PATTERNS = [
    # --- Timers & Schedulers ---
    (r"schedule\.every", "timer", "schedule", "HIGH"),
    (r"schedule\.run_pending", "timer", "schedule", "MEDIUM"),
    (r"apscheduler\.\w+\.add_job", "timer", "apscheduler", "HIGH"),
    (r"celery\.task|\.delay\b|\.apply_async", "queue", "celery", "HIGH"),
    (r"huey\.\w+\.task", "timer", "huey", "HIGH"),
    # --- Message Queues ---
    (r"pika\.\w+\.basic_consume", "queue", "rabbitmq", "HIGH"),
    (r"kafka\.\w+consumer", "queue", "kafka", "HIGH"),
    (r"boto3\.\w+sqs\.\w+receive", "queue", "sqs", "HIGH"),
    (r"redis\.\w+\.subscribe", "queue", "redis-pubsub", "HIGH"),
    (r"kombu\.\w+\.consume", "queue", "kombu", "HIGH"),
    # --- Background Threads/Tasks ---
    (r"threading\.Thread", "thread", "threading", "HIGH"),
    (r"multiprocessing\.Process", "thread", "multiprocessing", "HIGH"),
    (r"concurrent\.futures\.\w+Executor", "thread", "concurrent.futures", "HIGH"),
    (r"asyncio\.create_task", "thread", "asyncio", "HIGH"),
    (r"asyncio\.ensure_future", "thread", "asyncio", "HIGH"),
    (r"asyncio\.gather", "thread", "asyncio", "MEDIUM"),
    (r"loop\.create_task", "thread", "asyncio", "HIGH"),
    # --- Signal Handlers ---
    (r"signal\.signal", "signal", "signal", "HIGH"),
    (r"atexit\.register", "startup", "atexit", "HIGH"),
    # --- Startup Hooks ---
    (r"app\.before_request|app\.before_first_request", "startup", "flask", "HIGH"),
    (r"app\.on_event\(.*startup", "startup", "fastapi", "HIGH"),
    (r"app\.add_event_handler", "startup", "starlette", "HIGH"),
]

PYTHON_FUNC_NAME_PATTERNS = [
    # Decorator-style entrypoints detected by function naming
    (r"celery_task_|task_\w+_handler", "queue", "celery", "MEDIUM"),
    (r"on_message|message_handler|consume_\w+", "queue", "generic", "MEDIUM"),
    (r"background_\w+|bg_\w+|worker_\w+", "thread", "generic", "LOW"),
    (r"cron_\w+|scheduled_\w+|periodic_\w+", "timer", "generic", "MEDIUM"),
    (r"signal_handler|on_sigterm|on_sigint|handle_signal", "signal", "generic", "HIGH"),
    (r"setup|teardown|on_startup|on_shutdown", "startup", "generic", "MEDIUM"),
]

JAVASCRIPT_CALL_PATTERNS = [
    # --- Timers ---
    (r"setTimeout", "timer", "node", "MEDIUM"),
    (r"setInterval", "timer", "node", "HIGH"),
    (r"node.cron\.\w+\.schedule", "timer", "node-cron", "HIGH"),
    (r"cron\.schedule", "timer", "node-cron", "HIGH"),
    (r"agenda\.\w+\.define", "timer", "agenda", "HIGH"),
    # --- Message Queues ---
    (r"amqplib\.\w+\.consume", "queue", "rabbitmq", "HIGH"),
    (r"kafkajs\.\w+\.subscribe", "queue", "kafka", "HIGH"),
    (r"bull\.\w+\.process", "queue", "bull", "HIGH"),
    (r"sqs\.\w+receiveMessage", "queue", "sqs", "HIGH"),
    # --- Signal/Events ---
    (r"process\.on", "signal", "node", "HIGH"),
    (r"process\.once", "signal", "node", "HIGH"),
    # --- Startup ---
    (r"app\.listen", "startup", "express", "HIGH"),
    (r"server\.listen", "startup", "http", "HIGH"),
]

JAVASCRIPT_FUNC_NAME_PATTERNS = [
    (r"on[A-Z]\w+Handler", "event", "generic", "MEDIUM"),
    (r"consumer|subscriber|listener", "queue", "generic", "MEDIUM"),
    (r"worker|background|cron|scheduler", "timer", "generic", "LOW"),
]

GO_CALL_PATTERNS = [
    # --- Goroutines (detected by 'go func()' pattern in call graph) ---
    # Note: AST-level 'go' keyword isn't in the call graph, but we can detect
    # functions passed to concurrency primitives
    (r"time\.AfterFunc", "timer", "time", "HIGH"),
    (r"time\.NewTicker", "timer", "time", "HIGH"),
    (r"time\.NewTimer", "timer", "time", "HIGH"),
    (r"time\.Tick\b", "timer", "time", "HIGH"),
    # --- Signal Handlers ---
    (r"signal\.Notify", "signal", "os/signal", "HIGH"),
    (r"signal\.NotifyContext", "signal", "os/signal", "HIGH"),
    # --- Message Queues ---
    (r"sarama\.\w+\.Consume", "queue", "kafka", "HIGH"),
    (r"amqp\.\w+\.Consume", "queue", "rabbitmq", "HIGH"),
    (r"nats\.\w+\.Subscribe", "queue", "nats", "HIGH"),
    # --- HTTP Servers (startup) ---
    (r"http\.ListenAndServe", "startup", "net/http", "HIGH"),
    (r"grpc\.NewServer", "startup", "grpc", "HIGH"),
]

GO_FUNC_NAME_PATTERNS = [
    (r"^init$", "startup", "go-init", "HIGH"),  # Go init() functions
    (r"Handler$|Subscriber$|Consumer$", "event", "generic", "MEDIUM"),
    (r"Worker$|Background|Cron", "timer", "generic", "LOW"),
]

JAVA_FUNC_NAME_PATTERNS = [
    # Annotation-based entrypoints (detected by naming convention since
    # annotations show up in function metadata or naming)
    (r"@Scheduled|scheduled\w+", "timer", "spring", "HIGH"),
    (r"@PostConstruct|postConstruct|afterPropertiesSet", "startup", "spring", "HIGH"),
    (r"@PreDestroy|preDestroy|destroy", "startup", "spring", "HIGH"),
    (r"@KafkaListener|kafkaListener|onMessage", "queue", "spring-kafka", "HIGH"),
    (r"@RabbitListener|rabbitListener", "queue", "spring-amqp", "HIGH"),
    (r"@JmsListener|jmsListener", "queue", "spring-jms", "HIGH"),
    (r"@EventListener|eventListener|onApplicationEvent", "event", "spring", "HIGH"),
    (r"@Async|async\w+Task", "thread", "spring", "HIGH"),
    (r"CommandLineRunner|ApplicationRunner", "startup", "spring-boot", "HIGH"),
    (r"ServletContextListener|contextInitialized", "startup", "servlet", "HIGH"),
]

JAVA_CALL_PATTERNS = [
    (r"ExecutorService\.\w+submit", "thread", "java.util.concurrent", "HIGH"),
    (r"ScheduledExecutorService\.\w+schedule", "timer", "java.util.concurrent", "HIGH"),
    (r"CompletableFuture\.supplyAsync", "thread", "java.util.concurrent", "HIGH"),
    (r"Timer\.\w+schedule", "timer", "java.util", "HIGH"),
    (r"Runtime\.addShutdownHook", "signal", "java.lang", "HIGH"),
]


# =============================================================================
# DETECTION ENGINE
# =============================================================================


def _match_call_patterns(
    call_graph: Dict[str, Set[str]],
    patterns: list,
    language: str,
) -> List[InternalEntrypoint]:
    """
    Scan call graph for calls matching entrypoint-creating patterns.

    When app function X calls threading.Thread(..., target=Y), the entrypoint
    is X (the caller that spawns the background work).
    """
    results = []
    seen = set()

    for caller, callees in call_graph.items():
        if not caller.startswith("app."):
            continue

        for callee in callees:
            callee.lower()
            for pattern, ep_type, framework, confidence in patterns:
                if re.search(pattern, callee, re.IGNORECASE):
                    key = (caller, ep_type, framework)
                    if key not in seen:
                        seen.add(key)
                        results.append(
                            InternalEntrypoint(
                                function=caller,
                                type=ep_type,
                                framework=framework,
                                handler=caller.split(".")[-1] if "." in caller else caller,
                                confidence=confidence,
                                detection_reason=f"{language}: calls {callee} (matches {pattern})",
                            )
                        )

    return results


def _match_func_name_patterns(
    all_functions: Set[str],
    patterns: list,
    language: str,
) -> List[InternalEntrypoint]:
    """
    Scan function names for patterns indicating internal entrypoints.
    """
    results = []
    seen = set()

    for func in all_functions:
        if not func.startswith("app."):
            continue

        simple_name = func.split(".")[-1] if "." in func else func

        for pattern, ep_type, framework, confidence in patterns:
            if re.search(pattern, simple_name, re.IGNORECASE):
                key = (func, ep_type)
                if key not in seen:
                    seen.add(key)
                    results.append(
                        InternalEntrypoint(
                            function=func,
                            type=ep_type,
                            framework=framework,
                            handler=simple_name,
                            confidence=confidence,
                            detection_reason=f"{language}: name matches {pattern}",
                        )
                    )

    return results


def _detect_import_based_entrypoints(
    all_functions: Set[str],
    imports_map: Dict[str, str],
    function_imports: Dict[str, Set[str]],
) -> List[InternalEntrypoint]:
    """
    Detect entrypoints from import patterns.

    If a function imports celery, it likely defines tasks.
    If a function imports asyncio, it likely creates async entrypoints.
    """
    framework_imports = {
        "celery": ("queue", "celery"),
        "dramatiq": ("queue", "dramatiq"),
        "huey": ("queue", "huey"),
        "apscheduler": ("timer", "apscheduler"),
        "schedule": ("timer", "schedule"),
        "kafka": ("queue", "kafka"),
        "pika": ("queue", "rabbitmq"),
        "kombu": ("queue", "kombu"),
        "nats": ("queue", "nats"),
    }

    results = []
    seen = set()

    for func, libs in function_imports.items():
        if not func.startswith("app."):
            continue

        for lib_import in libs:
            base_import = lib_import.split(".")[0].lower()
            if base_import in framework_imports:
                ep_type, framework = framework_imports[base_import]
                key = (func, ep_type, framework)
                if key not in seen:
                    seen.add(key)
                    results.append(
                        InternalEntrypoint(
                            function=func,
                            type=ep_type,
                            framework=framework,
                            handler=func.split(".")[-1] if "." in func else func,
                            confidence="LOW",
                            detection_reason=f"imports {lib_import}",
                        )
                    )

    return results


def detect_internal_entrypoints(
    call_graph: Dict[str, Set[str]],
    all_functions: Set[str],
    imports_map: Optional[Dict[str, str]] = None,
    function_imports: Optional[Dict[str, Set[str]]] = None,
    detected_languages: Optional[List[str]] = None,
) -> Dict[str, Any]:
    """
    Detect internal (non-HTTP) entrypoints across all languages.

    Args:
        call_graph: Function call graph
        all_functions: All known functions
        imports_map: Module import mapping
        function_imports: Per-function import tracking
        detected_languages: Languages detected in the project

    Returns:
        Dict with structure:
        {
            "schema_version": "1.0",
            "statistics": { "total": N, "by_type": {...}, "by_framework": {...} },
            "entrypoints": [ { "function": ..., "type": ..., ... }, ... ]
        }
    """
    imports_map = imports_map or {}
    function_imports = function_imports or {}
    detected_languages = detected_languages or []

    all_entrypoints: List[InternalEntrypoint] = []

    # Detect languages from function prefixes if not provided
    any(lang.lower() in ("python", "py") for lang in detected_languages) or any(
        ".py." in f or f.endswith(".py") for f in all_functions
    )

    any(lang.lower() in ("javascript", "typescript", "js", "ts") for lang in detected_languages)

    any(lang.lower() in ("go", "golang") for lang in detected_languages)

    any(lang.lower() in ("java", "kotlin", "scala") for lang in detected_languages)

    # Always run all patterns since language detection isn't always reliable
    # Call-graph patterns
    all_entrypoints.extend(_match_call_patterns(call_graph, PYTHON_CALL_PATTERNS, "Python"))
    all_entrypoints.extend(_match_call_patterns(call_graph, JAVASCRIPT_CALL_PATTERNS, "JavaScript"))
    all_entrypoints.extend(_match_call_patterns(call_graph, GO_CALL_PATTERNS, "Go"))
    all_entrypoints.extend(_match_call_patterns(call_graph, JAVA_CALL_PATTERNS, "Java"))

    # Function name patterns
    all_entrypoints.extend(_match_func_name_patterns(all_functions, PYTHON_FUNC_NAME_PATTERNS, "Python"))
    all_entrypoints.extend(_match_func_name_patterns(all_functions, JAVASCRIPT_FUNC_NAME_PATTERNS, "JavaScript"))
    all_entrypoints.extend(_match_func_name_patterns(all_functions, GO_FUNC_NAME_PATTERNS, "Go"))
    all_entrypoints.extend(_match_func_name_patterns(all_functions, JAVA_FUNC_NAME_PATTERNS, "Java"))

    # Import-based detection (Python primarily)
    all_entrypoints.extend(_detect_import_based_entrypoints(all_functions, imports_map, function_imports))

    # Deduplicate: prefer higher confidence for same function+type
    deduped: Dict[str, InternalEntrypoint] = {}
    confidence_rank = {"HIGH": 3, "MEDIUM": 2, "LOW": 1}

    for ep in all_entrypoints:
        key = f"{ep.function}:{ep.type}"
        if key not in deduped or confidence_rank.get(ep.confidence, 0) > confidence_rank.get(
            deduped[key].confidence, 0
        ):
            deduped[key] = ep

    final = list(deduped.values())

    # Build statistics
    by_type: Dict[str, int] = {}
    by_framework: Dict[str, int] = {}
    for ep in final:
        by_type[ep.type] = by_type.get(ep.type, 0) + 1
        by_framework[ep.framework] = by_framework.get(ep.framework, 0) + 1

    result = {
        "schema_version": "1.0",
        "statistics": {
            "total": len(final),
            "by_type": dict(sorted(by_type.items(), key=lambda x: x[1], reverse=True)),
            "by_framework": dict(sorted(by_framework.items(), key=lambda x: x[1], reverse=True)),
        },
        "entrypoints": [ep.to_dict() for ep in sorted(final, key=lambda x: (x.type, x.function))],
    }

    if final:
        logger.info(
            f" Internal entrypoints: {len(final)} detected "
            f"({', '.join(f'{v} {k}' for k, v in sorted(by_type.items()))})"
        )

    return result
