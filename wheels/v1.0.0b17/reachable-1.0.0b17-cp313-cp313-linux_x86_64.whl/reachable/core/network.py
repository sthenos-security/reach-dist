#!/usr/bin/env python3
# REACHABLE Network Configuration
# Copyright (c) 2026 Sthenos Security. All rights reserved.

"""
Centralized network timeout configuration to prevent hangs.

Classic Python bug: network calls without timeouts can hang indefinitely.
This module provides configurable timeouts for all network operations.

Usage:
    from reachable.core.network import NetworkConfig

    # Use default timeouts
    response = requests.get(url, timeout=NetworkConfig.API_TIMEOUT)

    # Or create custom timeout
    timeout = NetworkConfig.create_timeout(connect=5, read=10)
    response = requests.get(url, timeout=timeout)

Environment Variables:
    REACHABLE_NET_CONNECT_TIMEOUT: Default connection timeout (seconds)
    REACHABLE_NET_READ_TIMEOUT: Default read timeout (seconds)
    REACHABLE_NET_API_TIMEOUT: Timeout for quick API calls (seconds)
    REACHABLE_NET_DOWNLOAD_TIMEOUT: Timeout for downloads (seconds)
"""

import logging
import os
from typing import Tuple

logger = logging.getLogger(__name__)


class NetworkConfig:
    """
    Centralized network timeout configuration.

    All timeouts are in seconds. Set via environment variables or use defaults.
    """

    # =================================================================
    # DEFAULT TIMEOUTS (conservative values to prevent hangs)
    # =================================================================

    # Base timeouts
    DEFAULT_CONNECT_TIMEOUT = 15  # Time to establish connection
    DEFAULT_READ_TIMEOUT = 60  # Time to read response

    # Scenario-specific timeouts (tuples of (connect, read))
    API_TIMEOUT = (10, 30)  # Quick API calls (CVE lookup, etc)
    DOWNLOAD_TIMEOUT = (20, 120)  # Large downloads (threat intel, etc)
    HEALTH_CHECK_TIMEOUT = (5, 10)  # Health/status checks
    ENRICHMENT_TIMEOUT = (15, 45)  # CVE enrichment APIs

    # Total timeout (worst case scenario - for requests.get(timeout=X))
    DEFAULT_TOTAL_TIMEOUT = 90  # Single value timeout

    # =================================================================
    # ENVIRONMENT VARIABLE OVERRIDES
    # =================================================================

    @classmethod
    def _get_env_int(cls, key: str, default: int) -> int:
        """Get integer from environment variable with fallback."""
        try:
            return int(os.environ.get(key, default))
        except (ValueError, TypeError):
            return default

    @classmethod
    def get_connect_timeout(cls) -> int:
        """Get connection timeout (overridable via env)."""
        return cls._get_env_int("REACHABLE_NET_CONNECT_TIMEOUT", cls.DEFAULT_CONNECT_TIMEOUT)

    @classmethod
    def get_read_timeout(cls) -> int:
        """Get read timeout (overridable via env)."""
        return cls._get_env_int("REACHABLE_NET_READ_TIMEOUT", cls.DEFAULT_READ_TIMEOUT)

    @classmethod
    def get_api_timeout(cls) -> Tuple[int, int]:
        """Get API timeout (connect, read) tuple."""
        connect = cls._get_env_int("REACHABLE_NET_API_CONNECT", cls.API_TIMEOUT[0])
        read = cls._get_env_int("REACHABLE_NET_API_READ", cls.API_TIMEOUT[1])
        return (connect, read)

    @classmethod
    def get_download_timeout(cls) -> Tuple[int, int]:
        """Get download timeout (connect, read) tuple."""
        connect = cls._get_env_int("REACHABLE_NET_DOWNLOAD_CONNECT", cls.DOWNLOAD_TIMEOUT[0])
        read = cls._get_env_int("REACHABLE_NET_DOWNLOAD_READ", cls.DOWNLOAD_TIMEOUT[1])
        return (connect, read)

    @classmethod
    def get_health_check_timeout(cls) -> Tuple[int, int]:
        """Get health check timeout (connect, read) tuple."""
        connect = cls._get_env_int("REACHABLE_NET_HEALTH_CONNECT", cls.HEALTH_CHECK_TIMEOUT[0])
        read = cls._get_env_int("REACHABLE_NET_HEALTH_READ", cls.HEALTH_CHECK_TIMEOUT[1])
        return (connect, read)

    @classmethod
    def get_enrichment_timeout(cls) -> Tuple[int, int]:
        """Get enrichment API timeout (connect, read) tuple."""
        connect = cls._get_env_int("REACHABLE_NET_ENRICHMENT_CONNECT", cls.ENRICHMENT_TIMEOUT[0])
        read = cls._get_env_int("REACHABLE_NET_ENRICHMENT_READ", cls.ENRICHMENT_TIMEOUT[1])
        return (connect, read)

    @classmethod
    def get_total_timeout(cls) -> int:
        """Get single-value total timeout."""
        return cls._get_env_int("REACHABLE_NET_TOTAL_TIMEOUT", cls.DEFAULT_TOTAL_TIMEOUT)

    @classmethod
    def create_timeout(cls, connect: int = None, read: int = None) -> Tuple[int, int]:
        """
        Create custom timeout tuple.

        Args:
            connect: Connection timeout (uses default if None)
            read: Read timeout (uses default if None)

        Returns:
            (connect, read) tuple
        """
        connect = connect if connect is not None else cls.get_connect_timeout()
        read = read if read is not None else cls.get_read_timeout()
        return (connect, read)

    @classmethod
    def print_config(cls):
        """Print current timeout configuration (for debugging)."""
        logger.info("=" * 60)
        logger.info("REACHABLE Network Timeout Configuration")
        logger.info("=" * 60)
        logger.info(f" API calls: {cls.get_api_timeout()} (connect, read)")
        logger.info(f" Downloads: {cls.get_download_timeout()} (connect, read)")
        logger.info(f" Health checks: {cls.get_health_check_timeout()} (connect, read)")
        logger.info(f" Enrichment: {cls.get_enrichment_timeout()} (connect, read)")
        logger.info(f" Default total: {cls.get_total_timeout()}s")
        logger.info("=" * 60)
        logger.info("")
        logger.info("Environment variable overrides:")
        env_vars = [
            "REACHABLE_NET_CONNECT_TIMEOUT",
            "REACHABLE_NET_READ_TIMEOUT",
            "REACHABLE_NET_API_CONNECT",
            "REACHABLE_NET_API_READ",
            "REACHABLE_NET_DOWNLOAD_CONNECT",
            "REACHABLE_NET_DOWNLOAD_READ",
            "REACHABLE_NET_HEALTH_CONNECT",
            "REACHABLE_NET_HEALTH_READ",
            "REACHABLE_NET_ENRICHMENT_CONNECT",
            "REACHABLE_NET_ENRICHMENT_READ",
            "REACHABLE_NET_TOTAL_TIMEOUT",
        ]

        overrides = [(k, os.environ.get(k)) for k in env_vars if k in os.environ]
        if overrides:
            for k, v in overrides:
                logger.info(f" {k}={v}")
        else:
            logger.info("  (none set - using defaults)")
        logger.info("=" * 60)


# =================================================================
# HELPER FUNCTIONS FOR COMMON PATTERNS
# =================================================================


def safe_urlopen(url: str, timeout: Tuple[int, int] = None, **kwargs):
    """
    Safe wrapper for urllib.request.urlopen with timeout.

    Args:
        url: URL to open
        timeout: (connect, read) timeout tuple (uses API default if None)
        **kwargs: Additional arguments for urlopen

    Returns:
        Response object
    """
    import urllib.request

    if timeout is None:
        timeout = NetworkConfig.get_api_timeout()

    # urllib only accepts single timeout value
    total_timeout = sum(timeout)

    return urllib.request.urlopen(url, timeout=total_timeout, **kwargs)


def safe_requests_get(url: str, timeout: Tuple[int, int] = None, **kwargs):
    """
    Safe wrapper for requests.get with timeout.

    Args:
        url: URL to get
        timeout: (connect, read) timeout tuple (uses API default if None)
        **kwargs: Additional arguments for requests.get

    Returns:
        Response object
    """
    import requests

    if timeout is None:
        timeout = NetworkConfig.get_api_timeout()

    return requests.get(url, timeout=timeout, **kwargs)


def safe_requests_post(url: str, timeout: Tuple[int, int] = None, **kwargs):
    """
    Safe wrapper for requests.post with timeout.

    Args:
        url: URL to post
        timeout: (connect, read) timeout tuple (uses API default if None)
        **kwargs: Additional arguments for requests.post

    Returns:
        Response object
    """
    import requests

    if timeout is None:
        timeout = NetworkConfig.get_api_timeout()

    return requests.post(url, timeout=timeout, **kwargs)


if __name__ == "__main__":
    # Print configuration when run directly
    NetworkConfig.print_config()
