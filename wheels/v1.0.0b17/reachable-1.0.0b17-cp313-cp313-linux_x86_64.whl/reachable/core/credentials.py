#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.
"""
Secure credential storage for REACHABLE.

Resolution order (first found wins):
    1. Environment variable          ← CI/CD, always wins
    2. System keychain / secure store ← desktop dev machines
    3. None                           ← not configured

Storage backends:
    macOS:  Keychain via `security` CLI (same as gh, docker, npm)
    Linux:  AES-encrypted file (~/.reachable/auth.enc, mode 0600)

Usage:
    from reachable.core.credentials import get_credential, set_credential

    token = get_credential("github-token")       # env → keychain → None
    set_credential("github-token", "ghp_xxx")    # writes to keychain
    delete_credential("github-token")            # removes from keychain
"""

from __future__ import annotations

import hashlib
import json
import logging
import os
import platform
import subprocess
from pathlib import Path
from typing import Dict, Optional

logger = logging.getLogger(__name__)

# ═══════════════════════════════════════════════════════════════════════════
#  Credential Registry
# ═══════════════════════════════════════════════════════════════════════════

# Maps logical name → (env_var, keychain service name, description)
CREDENTIALS: Dict[str, dict] = {
    "github-token": {
        "env_vars": ["GITHUB_TOKEN", "GH_TOKEN"],
        "service": "reachable/github-token",
        "label": "GitHub Token",
        "description": "Tarball downloads (fastest), GHSA enrichment, private repo access",
        "prompt": "GitHub personal access token (ghp_...)",
        "prefix": "ghp_",
        "required": False,
        "scope_hint": "Classic token — required scope: repo (read). Enables tarball API "
        "(single-request downloads, ~5x faster than git clone) and GHSA "
        "vulnerability enrichment.",
        "create_url": "https://github.com/settings/tokens",
    },
    "github-mcp-token": {
        "env_vars": ["MCP_GITHUB_TOKEN"],
        "service": "reachable/github-mcp-token",
        "label": "GitHub MCP Token",
        "description": "MCP-server-based cloning (different permissions than git token)",
        "prompt": "GitHub MCP token (github_pat_..., optional, Enter to skip)",
        "prefix": "",
        "required": False,
        "scope_hint": "Fine-grained token — required permissions: contents:read, metadata:read. "
        "This is NOT the same token as above; MCP uses different auth scopes.",
        "create_url": "https://github.com/settings/personal-access-tokens/new",
    },
    "anthropic-api-key": {
        "env_vars": ["ANTHROPIC_API_KEY"],
        "service": "reachable/anthropic-api-key",
        "label": "Anthropic API Key",
        "description": "Enzo cloud remediation — AI-generated fix strategies (optional, uses tokens)",
        "prompt": "Anthropic API key (sk-ant-..., optional, Enter to skip)",
        "prefix": "sk-ant-",
        "required": False,
        "scope_hint": "Enzo sends only metadata to Claude (no source code). "
        "Typical cost: ~$0.01-0.05 per finding for strategy generation",
        "create_url": "https://console.anthropic.com/settings/keys",
    },
    "groq-api-key": {
        "env_vars": ["GROQ_API_KEY"],
        "service": "reachable/groq-api-key",
        "label": "Groq API Key",
        "description": "Enzo fast cloud — qwen2.5-coder-32b via Groq (~30x faster than Ollama 14b)",
        "prompt": "Groq API key (gsk_..., optional, Enter to skip)",
        "prefix": "gsk_",
        "required": False,
        "scope_hint": "Free tier available. Code snippets sent to Groq Cloud.",
        "create_url": "https://console.groq.com/keys",
    },
}


# Keychain account name (consistent across all credentials)
_KEYCHAIN_ACCOUNT = "reachctl"


# ═══════════════════════════════════════════════════════════════════════════
#  Public API
# ═══════════════════════════════════════════════════════════════════════════


def get_credential(name: str) -> Optional[str]:
    """Get credential by name.  Checks env vars first, then secure store.

    Args:
        name: Credential name (e.g. "github-token")

    Returns:
        The credential value, or None if not found anywhere.
    """
    cred = CREDENTIALS.get(name)
    if not cred:
        raise ValueError(f"Unknown credential: {name}")

    # 1. Environment variables (CI/CD path)
    for env_var in cred["env_vars"]:
        val = os.environ.get(env_var)
        if val:
            return val

    # 2. Secure store (desktop path)
    return _store_get(cred["service"])


def get_credential_source(name: str) -> str:
    """Identify where a credential is coming from.

    Returns:
        "env:VAR_NAME" | "keychain" | "encrypted-file" | "not-configured"
    """
    cred = CREDENTIALS.get(name)
    if not cred:
        return "unknown"

    for env_var in cred["env_vars"]:
        if os.environ.get(env_var):
            return f"env:{env_var}"

    val = _store_get(cred["service"])
    if val:
        return _store_name()

    return "not-configured"


def set_credential(name: str, value: str) -> bool:
    """Store a credential in the secure store.

    Args:
        name: Credential name
        value: Secret value

    Returns:
        True if stored successfully.
    """
    cred = CREDENTIALS.get(name)
    if not cred:
        raise ValueError(f"Unknown credential: {name}")
    return _store_set(cred["service"], value)


def delete_credential(name: str) -> bool:
    """Remove a credential from the secure store.

    Does NOT affect environment variables (those are set elsewhere).

    Returns:
        True if deleted (or didn't exist).
    """
    cred = CREDENTIALS.get(name)
    if not cred:
        raise ValueError(f"Unknown credential: {name}")
    return _store_delete(cred["service"])


def get_all_status() -> Dict[str, dict]:
    """Get status of all credentials.

    Returns dict of name → {configured: bool, source: str, masked: str}
    """
    result = {}
    for name, cred in CREDENTIALS.items():
        val = get_credential(name)
        source = get_credential_source(name)
        result[name] = {
            "configured": val is not None,
            "source": source,
            "label": cred["label"],
            "masked": _mask(val) if val else "",
            "description": cred["description"],
        }
    return result


def mask_value(value: str) -> str:
    """Mask a credential for display: show first 4 and last 4 chars."""
    return _mask(value)


# ═══════════════════════════════════════════════════════════════════════════
#  macOS Keychain Backend  (via `security` CLI)
# ═══════════════════════════════════════════════════════════════════════════


def _keychain_get(service: str) -> Optional[str]:
    """Read from macOS Keychain."""
    try:
        result = subprocess.run(
            ["security", "find-generic-password", "-s", service, "-a", _KEYCHAIN_ACCOUNT, "-w"],
            capture_output=True,
            text=True,
            timeout=5,
        )
        if result.returncode == 0:
            return result.stdout.strip()
    except (FileNotFoundError, subprocess.TimeoutExpired):
        pass
    return None


def _keychain_set(service: str, value: str) -> bool:
    """Write to macOS Keychain.  Updates if exists."""
    # Delete first (update-in-place not supported cleanly)
    _keychain_delete(service)
    try:
        result = subprocess.run(
            [
                "security",
                "add-generic-password",
                "-s",
                service,
                "-a",
                _KEYCHAIN_ACCOUNT,
                "-w",
                value,
                "-A",
                "-U",
            ],
            capture_output=True,
            text=True,
            timeout=5,
        )
        return result.returncode == 0
    except (FileNotFoundError, subprocess.TimeoutExpired):
        return False


def _keychain_delete(service: str) -> bool:
    """Remove from macOS Keychain."""
    try:
        subprocess.run(
            ["security", "delete-generic-password", "-s", service, "-a", _KEYCHAIN_ACCOUNT],
            capture_output=True,
            text=True,
            timeout=5,
        )
        return True  # true even if it didn't exist
    except (FileNotFoundError, subprocess.TimeoutExpired):
        return True


# ═══════════════════════════════════════════════════════════════════════════
#  Linux Encrypted File Backend
# ═══════════════════════════════════════════════════════════════════════════

_AUTH_FILE = Path.home() / ".reachable" / "auth.enc"


def _derive_key() -> bytes:
    """Derive encryption key from machine identity.

    Uses machine-id + hostname + UID as seed.  Not perfect security,
    but equivalent to what gh/docker do on Linux — protects against
    casual file access, not targeted attacks.
    """
    parts = []

    # machine-id (stable across reboots)
    for path in ["/etc/machine-id", "/var/lib/dbus/machine-id"]:
        try:
            with open(path) as f:
                parts.append(f.read().strip())
                break
        except (FileNotFoundError, PermissionError):
            pass

    # hostname + uid
    parts.append(platform.node())
    parts.append(str(os.getuid()))

    seed = ":".join(parts).encode("utf-8")
    return hashlib.sha256(seed).digest()


def _xor_crypt(data: bytes, key: bytes) -> bytes:
    """Simple XOR cipher.  Adequate for file-at-rest protection with
    a machine-derived key.  We avoid pulling in pycryptodome for a
    CLI tool that already stores secrets alongside the code it scans."""
    key_len = len(key)
    return bytes(b ^ key[i % key_len] for i, b in enumerate(data))


def _file_load() -> Dict[str, str]:
    """Load all credentials from encrypted file."""
    if not _AUTH_FILE.exists():
        return {}
    try:
        key = _derive_key()
        encrypted = _AUTH_FILE.read_bytes()
        decrypted = _xor_crypt(encrypted, key)
        return json.loads(decrypted.decode("utf-8"))
    except Exception:
        logger.debug("Failed to decrypt auth file, treating as empty")
        return {}


def _file_save(creds: Dict[str, str]) -> bool:
    """Save all credentials to encrypted file."""
    try:
        _AUTH_FILE.parent.mkdir(parents=True, exist_ok=True)
        key = _derive_key()
        plaintext = json.dumps(creds).encode("utf-8")
        encrypted = _xor_crypt(plaintext, key)
        _AUTH_FILE.write_bytes(encrypted)
        _AUTH_FILE.chmod(0o600)
        return True
    except Exception as exc:
        logger.debug("Failed to save auth file: %s", exc)
        return False


def _file_get(service: str) -> Optional[str]:
    """Read one credential from encrypted file."""
    return _file_load().get(service)


def _file_set(service: str, value: str) -> bool:
    """Write one credential to encrypted file."""
    creds = _file_load()
    creds[service] = value
    return _file_save(creds)


def _file_delete(service: str) -> bool:
    """Remove one credential from encrypted file."""
    creds = _file_load()
    creds.pop(service, None)
    if creds:
        return _file_save(creds)
    else:
        # No credentials left — delete the file
        try:
            _AUTH_FILE.unlink(missing_ok=True)
        except Exception:
            pass
        return True


# ═══════════════════════════════════════════════════════════════════════════
#  Backend Dispatch
# ═══════════════════════════════════════════════════════════════════════════


def _is_macos() -> bool:
    return platform.system() == "Darwin"


def _store_name() -> str:
    """Human-readable name of the active store."""
    return "keychain" if _is_macos() else "encrypted-file"


def _store_get(service: str) -> Optional[str]:
    if _is_macos():
        return _keychain_get(service)
    return _file_get(service)


def _store_set(service: str, value: str) -> bool:
    if _is_macos():
        return _keychain_set(service, value)
    return _file_set(service, value)


def _store_delete(service: str) -> bool:
    if _is_macos():
        return _keychain_delete(service)
    return _file_delete(service)


def _mask(value: str) -> str:
    """Mask a secret for display."""
    if not value:
        return ""
    if len(value) <= 8:
        return value[:2] + "…" + value[-2:]
    return value[:4] + "…" + value[-4:]


# ═══════════════════════════════════════════════════════════════════════════
#  GitHub Connectivity Tests
# ═══════════════════════════════════════════════════════════════════════════


def test_github_api(token: Optional[str] = None) -> dict:
    """Test GitHub API access with a token.

    If token is None, tries get_credential("github-token") automatically.

    Returns:
        {"ok": bool, "user": str, "scopes": str, "source": str, "error": str}
    """
    source = ""
    if token is None:
        # Try env vars first, then credential store
        for env_var in ["GITHUB_TOKEN", "GH_TOKEN"]:
            token = os.environ.get(env_var)
            if token:
                source = f"env:{env_var}"
                break
        if not token:
            token = _store_get(CREDENTIALS["github-token"]["service"])
            if token:
                source = _store_name()
        if not token:
            return {"ok": False, "user": "", "scopes": "", "source": "", "error": "no-token"}

    if not source:
        source = "provided"

    auth_scheme = "Bearer" if token.startswith("github_pat_") else "token"
    try:
        import urllib.error
        import urllib.request

        req = urllib.request.Request(
            "https://api.github.com/user",
            headers={
                "Authorization": f"{auth_scheme} {token}",
                "Accept": "application/vnd.github.v3+json",
                "User-Agent": "reachable-auth",
            },
        )
        with urllib.request.urlopen(req, timeout=5) as resp:
            if resp.status == 200:
                import json as _json

                data = _json.loads(resp.read())
                return {
                    "ok": True,
                    "user": data.get("login", ""),
                    "scopes": resp.headers.get("X-OAuth-Scopes", ""),
                    "source": source,
                    "error": "",
                }
    except urllib.error.HTTPError as e:
        if e.code == 401:
            return {"ok": False, "user": "", "scopes": "", "source": source, "error": "invalid-or-expired"}
        elif e.code == 403:
            # Fine-grained tokens return 403 on /user but may still work
            return {"ok": True, "user": "", "scopes": "(fine-grained)", "source": source, "error": ""}
    except Exception as exc:
        return {"ok": False, "user": "", "scopes": "", "source": source, "error": f"network: {exc}"}

    return {"ok": False, "user": "", "scopes": "", "source": source, "error": "unknown"}


def test_groq_api(key=None) -> dict:
    """Test Groq API key via /openai/v1/models.
    Returns: {"ok": bool, "source": str, "error": str, "models": int}
    """
    import urllib.error as _ue
    import urllib.request as _ur

    source = ""
    if key is None:
        val = os.environ.get("GROQ_API_KEY")
        if val:
            key, source = val, "env:GROQ_API_KEY"
        if not key:
            key = _store_get(CREDENTIALS["groq-api-key"]["service"])
            if key:
                source = _store_name()
        if not key:
            return {"ok": False, "source": "", "error": "no-key", "models": 0}
    if not source:
        source = "provided"
    try:
        req = _ur.Request(
            "https://api.groq.com/openai/v1/models",
            headers={"Authorization": f"Bearer {key}", "User-Agent": "reachable-auth"},
        )
        with _ur.urlopen(req, timeout=5) as resp:
            data = json.loads(resp.read())
            return {"ok": True, "source": source, "error": "", "models": len(data.get("data", []))}
    except _ue.HTTPError as e:
        if e.code == 401:
            return {"ok": False, "source": source, "error": "invalid-or-expired", "models": 0}
        return {"ok": True, "source": source, "error": f"HTTP {e.code}", "models": 0}
    except Exception as exc:
        return {"ok": False, "source": source, "error": f"network: {exc}", "models": 0}


def test_ssh_github() -> bool:
    """Test if SSH access to GitHub works."""
    import subprocess

    try:
        result = subprocess.run(
            ["ssh", "-T", "-o", "StrictHostKeyChecking=no", "-o", "BatchMode=yes", "git@github.com"],
            capture_output=True,
            text=True,
            timeout=10,
        )
        # GitHub returns exit code 1 with "Hi username!" on success
        combined = result.stdout + result.stderr
        return "successfully authenticated" in combined.lower()
    except (FileNotFoundError, subprocess.TimeoutExpired):
        return False


def test_github_mcp(token: Optional[str] = None) -> dict:
    """Test GitHub MCP token against the API.

    MCP tokens are fine-grained PATs — they return 403 on /user but
    work on /rate_limit and repos endpoints.

    Returns:
        {"ok": bool, "source": str, "error": str, "rate_limit": int}
    """
    source = ""
    if token is None:
        val = os.environ.get("MCP_GITHUB_TOKEN")
        if val:
            token = val
            source = "env:MCP_GITHUB_TOKEN"
        if not token:
            token = _store_get(CREDENTIALS["github-mcp-token"]["service"])
            if token:
                source = _store_name()
        if not token:
            return {"ok": False, "source": "", "error": "no-token", "rate_limit": 0}

    if not source:
        source = "provided"

    auth_scheme = "Bearer" if token.startswith("github_pat_") else "token"
    try:
        import urllib.error
        import urllib.request

        req = urllib.request.Request(
            "https://api.github.com/rate_limit",
            headers={
                "Authorization": f"{auth_scheme} {token}",
                "User-Agent": "reachable-auth",
            },
        )
        with urllib.request.urlopen(req, timeout=5) as resp:
            if resp.status == 200:
                data = json.loads(resp.read())
                limit = data.get("rate", {}).get("limit", 0)
                return {"ok": True, "source": source, "error": "", "rate_limit": limit}
    except urllib.error.HTTPError as e:
        if e.code == 401:
            return {"ok": False, "source": source, "error": "invalid-or-expired", "rate_limit": 0}
    except Exception as exc:
        return {"ok": False, "source": source, "error": f"network: {exc}", "rate_limit": 0}

    return {"ok": False, "source": source, "error": "unknown", "rate_limit": 0}


def test_anthropic_api(key: Optional[str] = None) -> dict:
    """Test Anthropic API key by hitting the models endpoint.

    Uses GET /v1/models — lightweight, no tokens consumed, just auth check.

    Returns:
        {"ok": bool, "source": str, "error": str}
    """
    source = ""
    if key is None:
        val = os.environ.get("ANTHROPIC_API_KEY")
        if val:
            key = val
            source = "env:ANTHROPIC_API_KEY"
        if not key:
            key = _store_get(CREDENTIALS["anthropic-api-key"]["service"])
            if key:
                source = _store_name()
        if not key:
            return {"ok": False, "source": "", "error": "no-key"}

    if not source:
        source = "provided"

    try:
        import urllib.error
        import urllib.request

        req = urllib.request.Request(
            "https://api.anthropic.com/v1/models",
            headers={
                "x-api-key": key,
                "anthropic-version": "2023-06-01",
                "User-Agent": "reachable-auth",
            },
        )
        with urllib.request.urlopen(req, timeout=5) as resp:
            if resp.status == 200:
                return {"ok": True, "source": source, "error": ""}
    except urllib.error.HTTPError as e:
        if e.code == 401:
            return {"ok": False, "source": source, "error": "invalid-or-expired"}
        elif e.code == 403:
            return {"ok": False, "source": source, "error": "forbidden (check key permissions)"}
        else:
            # 429, 500, etc. — key is probably valid, service issue
            return {"ok": True, "source": source, "error": f"API returned {e.code} (key accepted)"}
    except Exception as exc:
        return {"ok": False, "source": source, "error": f"network: {exc}"}

    return {"ok": False, "source": source, "error": "unknown"}
