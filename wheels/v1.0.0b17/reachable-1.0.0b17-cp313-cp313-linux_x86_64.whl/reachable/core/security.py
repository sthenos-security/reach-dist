# Copyright © 2026 Sthenos Security. All rights reserved.

"""
Security Utilities

Provides security hardening functions including:
- Rate limiting
- Request timeouts
- Input validation
- Secret redaction
"""

import hashlib
import re
import time
from functools import wraps
from pathlib import Path
from typing import Any, Callable, Optional


class RateLimiter:
    """
    Rate limiter for API calls.

    Implements token bucket algorithm.
    """

    def __init__(self, calls: int, period: float):
        """
        Initialize rate limiter.

        Args:
            calls: Maximum number of calls allowed in period
            period: Time period in seconds
        """
        self.calls = calls
        self.period = period
        self.tokens = calls
        self.last_update = time.time()

    def acquire(self):
        """Wait until a token is available."""
        while True:
            now = time.time()
            elapsed = now - self.last_update

            # Refill tokens
            self.tokens = min(self.calls, self.tokens + elapsed * (self.calls / self.period))
            self.last_update = now

            if self.tokens >= 1:
                self.tokens -= 1
                return

            # Wait for next token
            sleep_time = (1 - self.tokens) * (self.period / self.calls)
            time.sleep(sleep_time)


def rate_limit(calls: int = 100, period: float = 60):
    """
    Decorator for rate limiting function calls.

    Args:
        calls: Maximum calls allowed in period
        period: Time period in seconds

    Example:
        @rate_limit(calls=100, period=60)  # 100 calls per minute
        def fetch_api(url):
            return requests.get(url)
    """
    limiter = RateLimiter(calls, period)

    def decorator(func: Callable) -> Callable:
        @wraps(func)
        def wrapper(*args, **kwargs):
            limiter.acquire()
            return func(*args, **kwargs)

        return wrapper

    return decorator


class RequestCache:
    """Simple LRU cache for API requests."""

    def __init__(self, max_size: int = 1000):
        self.cache = {}
        self.access_times = {}
        self.max_size = max_size

    def get(self, key: str) -> Optional[Any]:
        """Get cached value."""
        if key in self.cache:
            self.access_times[key] = time.time()
            return self.cache[key]
        return None

    def set(self, key: str, value: Any):
        """Set cached value."""
        if len(self.cache) >= self.max_size:
            # Evict least recently used
            oldest_key = min(self.access_times, key=self.access_times.get)
            del self.cache[oldest_key]
            del self.access_times[oldest_key]

        self.cache[key] = value
        self.access_times[key] = time.time()


def redact_secrets(text: str) -> str:
    """
    Redact common secret patterns from text.

    Args:
        text: Input text that may contain secrets

    Returns:
        Text with secrets redacted
    """
    patterns = [
        # API Keys
        (r'(api[_-]?key|apikey)\s*[:=]\s*[\'"]?([a-zA-Z0-9_\-]{20,})[\'"]?', r"\1: [REDACTED]"),
        # GitHub tokens
        (r"(ghp|gho|ghu|ghs|ghr)_[a-zA-Z0-9]{36,}", r"[REDACTED_GITHUB_TOKEN]"),
        # AWS keys
        (r"AKIA[0-9A-Z]{16}", r"[REDACTED_AWS_KEY]"),
        # Generic tokens
        (r'(token|bearer)\s*[:=]\s*[\'"]?([a-zA-Z0-9_\-\.]{20,})[\'"]?', r"\1: [REDACTED]"),
        # Passwords
        (r'(password|passwd|pwd)\s*[:=]\s*[\'"]?([^\s\'\"]{8,})[\'"]?', r"\1: [REDACTED]"),
        # Private keys
        (
            r"-----BEGIN [A-Z ]+PRIVATE KEY-----[^-]+-----END [A-Z ]+PRIVATE KEY-----",
            r"[REDACTED_PRIVATE_KEY]",
        ),
    ]

    result = text
    for pattern, replacement in patterns:
        result = re.sub(pattern, replacement, result, flags=re.IGNORECASE)

    return result


def validate_path_safety(path: Path, allowed_root: Path) -> bool:
    """
    Validate that a path is safe (no traversal attacks).

    Args:
        path: Path to validate
        allowed_root: Root directory that path must be within

    Returns:
        True if path is safe, False otherwise
    """
    try:
        # Resolve to absolute paths
        resolved_path = path.resolve()
        resolved_root = allowed_root.resolve()

        # Check if path is within allowed root
        resolved_path.relative_to(resolved_root)
        return True
    except (ValueError, OSError):
        return False


def validate_file_size(path: Path, max_size_mb: int = 100) -> bool:
    """
    Validate file size is within limits.

    Args:
        path: File to check
        max_size_mb: Maximum allowed size in MB

    Returns:
        True if file is within size limit
    """
    max_bytes = max_size_mb * 1024 * 1024

    try:
        size = path.stat().st_size
        return size <= max_bytes
    except OSError:
        return False


def safe_json_parse(data: str, max_size_mb: int = 10) -> Optional[Any]:
    """
    Safely parse JSON with size limits.

    Args:
        data: JSON string to parse
        max_size_mb: Maximum JSON size in MB

    Returns:
        Parsed JSON object or None if invalid/too large
    """
    import json

    # Check size
    if len(data) > max_size_mb * 1024 * 1024:
        raise ValueError(f"JSON too large: {len(data)} bytes")

    try:
        return json.loads(data)
    except json.JSONDecodeError:
        return None


def compute_file_hash(path: Path, algorithm: str = "sha256") -> str:
    """
    Compute cryptographic hash of file.

    Args:
        path: File to hash
        algorithm: Hash algorithm (sha256, sha512, md5)

    Returns:
        Hex digest of file hash
    """
    hasher = hashlib.new(algorithm)

    with open(path, "rb") as f:
        while chunk := f.read(65536):  # 64KB chunks
            hasher.update(chunk)

    return hasher.hexdigest()


class SecureHTTPSession:
    """
    HTTP session with security hardening.

    Features:
    - Request timeouts
    - Rate limiting
    - Response caching
    - Secret redaction in logs
    """

    def __init__(
        self,
        timeout: int = 30,
        rate_limit_calls: int = 100,
        rate_limit_period: float = 60,
        cache_size: int = 1000,
    ):
        import requests

        self.session = requests.Session()
        self.session.headers.update({"User-Agent": "REACHABLE/2.0.0 Security Scanner"})

        self.timeout = timeout
        self.rate_limiter = RateLimiter(rate_limit_calls, rate_limit_period)
        self.cache = RequestCache(cache_size)

    def get(self, url: str, **kwargs) -> Any:
        """GET request with security hardening."""
        # Check cache
        cache_key = f"GET:{url}"
        cached = self.cache.get(cache_key)
        if cached:
            return cached

        # Rate limit
        self.rate_limiter.acquire()

        # Add timeout
        kwargs.setdefault("timeout", self.timeout)

        # Make request
        response = self.session.get(url, **kwargs)

        # Cache successful responses
        if response.status_code == 200:
            self.cache.set(cache_key, response)

        return response

    def post(self, url: str, **kwargs) -> Any:
        """POST request with security hardening."""
        # Rate limit
        self.rate_limiter.acquire()

        # Add timeout
        kwargs.setdefault("timeout", self.timeout)

        # Make request
        return self.session.post(url, **kwargs)


# Global secure session instance
_secure_session = None


def get_secure_session() -> SecureHTTPSession:
    """Get global secure HTTP session instance."""
    global _secure_session
    if _secure_session is None:
        _secure_session = SecureHTTPSession()
    return _secure_session
