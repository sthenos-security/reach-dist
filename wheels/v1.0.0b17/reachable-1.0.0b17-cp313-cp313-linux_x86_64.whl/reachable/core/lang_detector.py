#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.
# STATUS: investigate-superseded — Language detector. Check if ecosystem.py replaces this.

"""
Language Detection Helper - Shared across all modules for consistent language/ecosystem detection
"""


def detect_language_from_package(pkg_name: str) -> str:
    """
    Detect programming language/ecosystem from package name.

    Returns: 'Go', 'JavaScript', 'Python', 'Java', 'Rust', 'Other'
    """
    pkg = pkg_name.lower() if pkg_name else ""

    # Go patterns
    if pkg == "stdlib" or pkg.startswith("go1."):
        return "Go"
    if any(
        x in pkg
        for x in [
            "golang.org",
            "github.com/",
            "k8s.io",
            "gopkg.in",
            "go.uber.org",
            "google.golang.org",
            "cloud.google.com/go",
        ]
    ):
        return "Go"

    # Python patterns
    python_patterns = [
        "requests",
        "flask",
        "django",
        "numpy",
        "pandas",
        "pip",
        "setuptools",
        "pytest",
        "urllib3",
        "cryptography",
        "boto3",
        "sqlalchemy",
        "celery",
        "gunicorn",
        "uvicorn",
        "fastapi",
        "pydantic",
        "aiohttp",
        "httpx",
        "pillow",
        "scipy",
    ]
    if any(x in pkg for x in python_patterns):
        return "Python"

    # Java patterns
    java_patterns = [
        "springframework",
        "maven",
        "apache",
        "javax",
        "log4j",
        "jackson",
        "hibernate",
        "junit",
        "mockito",
        "lombok",
        "com.google",
        "org.apache",
        "io.netty",
    ]
    if any(x in pkg for x in java_patterns):
        return "Java"

    # Rust patterns
    if any(x in pkg for x in ["crates.io", "tokio", "serde", "cargo", "actix", "hyper"]):
        return "Rust"

    # JavaScript/TypeScript patterns (check after Go/Python/Java)
    # @-scoped packages are definitely npm
    if pkg.startswith("@"):
        return "JavaScript"

    js_patterns = [
        "next",
        "react",
        "vue",
        "angular",
        "express",
        "lodash",
        "webpack",
        "babel",
        "eslint",
        "typescript",
        "jest",
        "postcss",
        "braces",
        "micromatch",
        "yargs",
        "js-yaml",
        "mocha",
        "chai",
        "axios",
        "moment",
        "jquery",
        "bootstrap",
        "tailwind",
        "vite",
        "rollup",
        "esbuild",
        "prettier",
        "nodemon",
        "pm2",
        "socket.io",
        "set-value",
        "defaults-deep",
        "expand-object",
        "parse-git-config",
        "minimatch",
        "glob",
        "semver",
        "chalk",
        "commander",
        "inquirer",
        "ora",
        "debug",
    ]
    if any(x in pkg for x in js_patterns):
        return "JavaScript"

    # npm-style package names (hyphenated, no dots, no slashes)
    if "-" in pkg and "." not in pkg and "/" not in pkg:
        return "JavaScript"

    return "Other"


def detect_language_from_file(filepath: str) -> str:
    """
    Detect programming language from file path/extension.

    Returns: 'Go', 'JavaScript', 'Python', 'Java', 'Rust', 'C', 'Other'
    """
    fp = filepath.lower() if filepath else ""

    # Python
    if fp.endswith(".py") or fp.endswith(".pyx") or fp.endswith(".pyi"):
        return "Python"

    # JavaScript/TypeScript
    if any(fp.endswith(ext) for ext in [".js", ".jsx", ".ts", ".tsx", ".mjs", ".cjs"]):
        return "JavaScript"

    # Go
    if fp.endswith(".go"):
        return "Go"

    # Java
    if fp.endswith(".java") or fp.endswith(".kt") or fp.endswith(".scala"):
        return "Java"

    # Rust
    if fp.endswith(".rs"):
        return "Rust"

    # C/C++
    if any(fp.endswith(ext) for ext in [".c", ".h", ".cpp", ".hpp", ".cc", ".cxx"]):
        return "C"

    # Config files - try to detect from content
    if any(fp.endswith(ext) for ext in [".yaml", ".yml", ".json", ".toml"]):
        if "package.json" in fp or "package-lock" in fp:
            return "JavaScript"
        if "go.mod" in fp or "go.sum" in fp:
            return "Go"
        if "pyproject.toml" in fp or "requirements" in fp or "setup.py" in fp:
            return "Python"
        if "pom.xml" in fp or "build.gradle" in fp:
            return "Java"
        if "Cargo.toml" in fp:
            return "Rust"

    return "Other"


def detect_project_from_function(func_name: str) -> str:
    """
    Extract project name from function name (e.g., 'app.auth.handler.login' -> 'auth')

    Returns: project name or 'root'
    """
    if not func_name:
        return "root"

    parts = func_name.split(".")

    # Skip common prefixes
    if parts[0] in ("app", "src", "lib", "pkg"):
        if len(parts) >= 2:
            return parts[1]

    # If function name has at least 2 parts, use the first as project
    if len(parts) >= 2:
        return parts[0]

    return "root"


def detect_project_from_path(filepath: str) -> str:
    """
    Extract project name from file path.

    Returns: project name or 'root'
    """
    if not filepath:
        return "root"

    parts = filepath.replace("\\", "/").split("/")

    # Filter out common non-project directories
    skip_dirs = {
        ".",
        "..",
        "node_modules",
        "vendor",
        "venv",
        ".venv",
        "site-packages",
        "__pycache__",
        ".git",
        "dist",
        "build",
    }

    for part in parts:
        if part and part not in skip_dirs:
            # If it looks like a file, skip it
            if "." in part and not part.startswith("."):
                continue
            return part

    return "root"


def aggregate_by_language(items: dict, get_pkg_func=None) -> dict:
    """
    Aggregate items by detected language.

    Args:
        items: dict of item_name -> data
        get_pkg_func: optional function to extract package name from data

    Returns: dict of language -> count
    """
    by_lang = {}
    for name, data in items.items():
        if get_pkg_func:
            pkg = get_pkg_func(data)
        else:
            pkg = name

        lang = detect_language_from_package(pkg)
        by_lang[lang] = by_lang.get(lang, 0) + 1

    return by_lang


def aggregate_by_project(items: dict, get_funcs_func=None) -> dict:
    """
    Aggregate items by detected project.

    Args:
        items: dict of item_name -> data
        get_funcs_func: optional function to extract function names from data

    Returns: dict of project -> count
    """
    by_proj = {}
    for name, data in items.items():
        if get_funcs_func:
            funcs = get_funcs_func(data)
            if funcs:
                proj = detect_project_from_function(funcs[0] if isinstance(funcs, list) else funcs)
            else:
                proj = "root"
        else:
            proj = detect_project_from_function(name)

        by_proj[proj] = by_proj.get(proj, 0) + 1

    return by_proj


def format_breakdown(by_dict: dict, label: str = "By Language", max_items: int = 5) -> str:
    """
    Format a breakdown dict into a display string.

    Args:
        by_dict: dict of category -> count
        label: prefix label
        max_items: max items to show

    Returns: formatted string like "By Language: Go: 50, JavaScript: 23"
    """
    if not by_dict:
        return ""

    sorted_items = sorted(by_dict.items(), key=lambda x: -x[1])[:max_items]
    parts = [f"{k}: {v}" for k, v in sorted_items if v > 0]

    if not parts:
        return ""

    return f"{label}: {', '.join(parts)}"
