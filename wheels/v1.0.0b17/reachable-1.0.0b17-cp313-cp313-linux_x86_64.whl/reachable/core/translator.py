#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.
# STATUS: investigate-superseded — CI/CD provider syntax translator. Check if still needed.

"""
B. The Translator (Bridge Module)
Converts ProjectUnit objects into CI/CD provider syntax.

SINGLE RESPONSIBILITY: Translation only, no discovery or execution.
"""

import json
import logging
from typing import Dict, List

# Initialize module-level logger
logger = logging.getLogger(__name__)


class Translator:
    """
    Translates scan plans into CI/CD provider formats.

    Supports:
    - GitHub Actions (matrix strategy)
    - GitLab CI (generated config)
    - Raw JSON (for any CI/CD or local use)
    """

    @staticmethod
    def to_json(projects: List) -> Dict:
        """
        Generate raw JSON (works everywhere).

        Returns:
            Simple JSON array of projects
        """
        return {
            "total_projects": len(projects),
            "projects": [
                {
                    "project_id": p.project_id,
                    "project_name": p.project_name,
                    "language": p.language,
                    "mount_point": p.mount_point,
                    "relative_path": p.relative_path,
                    "anchor_file": p.anchor_file,
                    "context": p.context,
                }
                for p in projects
            ],
        }

    @staticmethod
    def to_github_matrix(projects: List) -> Dict:
        """
        Generate GitHub Actions matrix configuration.

        Usage in .github/workflows:
            jobs:
              discover:
                outputs:
                  matrix: ${{ steps.set-matrix.outputs.matrix }}
                steps:
                  - run: python harness.py --mode discover --format github > matrix.json
                  - id: set-matrix
                    run: echo "matrix=$(cat matrix.json)" >> $GITHUB_OUTPUT

              scan:
                needs: discover
                strategy:
                  matrix: ${{ fromJson(needs.discover.outputs.matrix) }}
                steps:
                  - run: python harness.py --mode worker --project ${{ matrix.project_id }}
        """
        return {
            "include": [
                {
                    "project_id": p.project_id,
                    "project_name": p.project_name,
                    "language": p.language,
                    "mount_point": p.mount_point,
                    "relative_path": p.relative_path,
                }
                for p in projects
            ]
        }

    @staticmethod
    def to_gitlab_config(projects: List) -> str:
        """
        Generate GitLab CI YAML configuration.

        Returns YAML string (not dict - ready to write to file).

        Usage in .gitlab-ci.yml:
            discover:
              script:
                - python harness.py --mode discover --format gitlab > generated.yml
              artifacts:
                paths: [generated.yml]

            include:
              - local: generated.yml
        """
        import yaml

        config = {}

        for project in projects:
            job_name = f"scan-{project.project_id}"

            config[job_name] = {
                "stage": "scan",
                "script": [f"python harness.py --mode worker --project {project.project_id}"],
                "variables": {
                    "PROJECT_ID": project.project_id,
                    "PROJECT_NAME": project.project_name,
                    "LANGUAGE": project.language,
                    "MOUNT_POINT": project.mount_point,
                },
                "artifacts": {"paths": [f"output/{project.project_id}/"]},
            }

        # Return YAML string
        try:
            return yaml.dump(config, default_flow_style=False)
        except Exception:
            # If yaml not available, return JSON (GitLab supports both)
            return json.dumps(config, indent=2)

    @staticmethod
    def to_local_plan(projects: List) -> Dict:
        """
        Generate plan for local sequential execution.

        Returns execution plan with estimates.
        """
        return {
            "execution_mode": "local_sequential",
            "total_projects": len(projects),
            "estimated_duration": f"{len(projects) * 2}m",
            "projects": [
                {
                    "step": idx + 1,
                    "project_id": p.project_id,
                    "command": f"python harness.py --mode worker --project {p.project_id}",
                    "mount_point": p.mount_point,
                    "language": p.language,
                }
                for idx, p in enumerate(projects)
            ],
        }


if __name__ == "__main__":
    # Test translator
    from dataclasses import dataclass, field

    @dataclass
    class TestProject:
        project_id: str
        project_name: str
        language: str
        mount_point: str
        relative_path: str
        anchor_file: str = "test.txt"
        context: dict = field(default_factory=dict)

    projects = [
        TestProject("app-python", "app", "python", "/app", "app"),
        TestProject("api-go", "api", "go", "/api", "api"),
    ]

    logger.info("=== JSON ===")
    logger.info(json.dumps(Translator.to_json(projects), indent=2))

    logger.info("\n=== GitHub Matrix ===")
    logger.info(json.dumps(Translator.to_github_matrix(projects), indent=2))

    logger.info("\n=== Local Plan ===")
    logger.info(json.dumps(Translator.to_local_plan(projects), indent=2))
