#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.

"""
Build provenance metadata collection for RADR.

Auto-detects git info (commit, branch, tag, remote, dirty status)
and CI/CD environment (GitHub Actions, GitLab CI, Jenkins, CircleCI, etc.).

This metadata flows into the scan report and ultimately into the
RADR manifest for runtime agent traceability.

Usage:
    from reachable.core.provenance import collect_provenance

    prov = collect_provenance(repo_path, cli_overrides={
        'commit': 'abc123',     # Optional: override auto-detect
        'branch': 'main',
        'tag': 'v1.2.3',
        'image': 'ghcr.io/acme/backend:v1.2.3',
    })

    # prov is a dict ready to embed in scan_metadata:
    # {
    #   "source_provenance": { "commit_sha": ..., "branch": ..., ... },
    #   "build_provenance":  { "ci_provider": ..., "ci_run_id": ..., ... },
    #   "image_provenance":  { "image_tag": ..., "image_digest": ..., ... },
    # }
"""

import logging
import os
import subprocess
from pathlib import Path
from typing import Any, Dict, Optional

logger = logging.getLogger(__name__)


def _git(repo_path: Path, *args: str, timeout: int = 5) -> Optional[str]:
    """Run a git command and return stripped stdout, or None on failure."""
    try:
        result = subprocess.run(
            ["git", *args],
            capture_output=True,
            text=True,
            cwd=str(repo_path),
            timeout=timeout,
        )
        if result.returncode == 0 and result.stdout.strip():
            return result.stdout.strip()
    except (subprocess.SubprocessError, FileNotFoundError):
        pass
    return None


def _collect_source_provenance(
    repo_path: Path,
    overrides: Dict[str, str],
) -> Dict[str, Any]:
    """Collect git source provenance (commit, branch, tag, remote, dirty)."""
    prov: Dict[str, Any] = {
        "commit_sha": None,
        "commit_sha_short": None,
        "commit_timestamp": None,
        "branch": None,
        "tag": None,
        "dirty": None,
        "remote_url": None,
        "repository": None,
    }

    # --- Auto-detect from git ---

    # Commit SHA
    sha = _git(repo_path, "rev-parse", "HEAD")
    if sha:
        prov["commit_sha"] = sha
        prov["commit_sha_short"] = sha[:8]

    # Commit timestamp (ISO 8601)
    ts = _git(repo_path, "log", "-1", "--format=%aI")
    if ts:
        prov["commit_timestamp"] = ts

    # Branch
    branch = _git(repo_path, "rev-parse", "--abbrev-ref", "HEAD")
    if branch and branch != "HEAD":
        prov["branch"] = branch
    else:
        # Detached HEAD (common in CI) — try CI env vars
        prov["branch"] = (
            os.environ.get("GITHUB_REF_NAME")
            or os.environ.get("CI_COMMIT_BRANCH")
            or os.environ.get("BRANCH_NAME")  # Jenkins
            or os.environ.get("CIRCLE_BRANCH")
            or os.environ.get("BUILDKITE_BRANCH")
            or os.environ.get("TRAVIS_BRANCH")
        )

    # Tag (exact match on HEAD, or None)
    tag = _git(repo_path, "describe", "--tags", "--exact-match", "HEAD")
    if tag:
        prov["tag"] = tag

    # Dirty working tree
    dirty_output = _git(repo_path, "status", "--porcelain")
    prov["dirty"] = dirty_output is not None and len(dirty_output) > 0

    # Remote URL
    remote = _git(repo_path, "remote", "get-url", "origin")
    if remote:
        prov["remote_url"] = remote
        prov["repository"] = _normalize_repo_url(remote)

    # --- Apply CLI overrides ---
    if overrides.get("commit"):
        prov["commit_sha"] = overrides["commit"]
        prov["commit_sha_short"] = overrides["commit"][:8]
    if overrides.get("branch"):
        prov["branch"] = overrides["branch"]
    if overrides.get("tag"):
        prov["tag"] = overrides["tag"]

    return prov


def _normalize_repo_url(remote_url: str) -> str:
    """
    Normalize git remote URL to a canonical form.

    git@github.com:acme/backend.git  →  github.com/acme/backend
    https://github.com/acme/backend.git  →  github.com/acme/backend
    """
    url = remote_url.strip()

    # SSH: git@github.com:acme/backend.git
    if url.startswith("git@"):
        url = url[4:]  # github.com:acme/backend.git
        url = url.replace(":", "/", 1)  # github.com/acme/backend.git

    # HTTPS: https://github.com/acme/backend.git
    for prefix in ("https://", "http://", "ssh://"):
        if url.startswith(prefix):
            url = url[len(prefix) :]

    # Strip trailing .git
    if url.endswith(".git"):
        url = url[:-4]

    # Strip trailing /
    url = url.rstrip("/")

    return url


def _collect_build_provenance() -> Dict[str, Any]:
    """Detect CI/CD environment and capture build metadata."""
    prov: Dict[str, Any] = {
        "ci_provider": None,
        "ci_run_id": None,
        "ci_run_url": None,
        "ci_job_name": None,
        "is_ci": False,
    }

    # GitHub Actions
    if os.environ.get("GITHUB_ACTIONS") == "true":
        server = os.environ.get("GITHUB_SERVER_URL", "https://github.com")
        repo = os.environ.get("GITHUB_REPOSITORY", "")
        run_id = os.environ.get("GITHUB_RUN_ID", "")
        prov.update(
            {
                "ci_provider": "github-actions",
                "ci_run_id": run_id,
                "ci_run_url": f"{server}/{repo}/actions/runs/{run_id}" if repo and run_id else None,
                "ci_job_name": os.environ.get("GITHUB_JOB"),
                "is_ci": True,
            }
        )
        return prov

    # GitLab CI
    if os.environ.get("GITLAB_CI") == "true":
        prov.update(
            {
                "ci_provider": "gitlab-ci",
                "ci_run_id": os.environ.get("CI_PIPELINE_ID"),
                "ci_run_url": os.environ.get("CI_PIPELINE_URL"),
                "ci_job_name": os.environ.get("CI_JOB_NAME"),
                "is_ci": True,
            }
        )
        return prov

    # Jenkins
    if os.environ.get("JENKINS_URL"):
        prov.update(
            {
                "ci_provider": "jenkins",
                "ci_run_id": os.environ.get("BUILD_NUMBER"),
                "ci_run_url": os.environ.get("BUILD_URL"),
                "ci_job_name": os.environ.get("JOB_NAME"),
                "is_ci": True,
            }
        )
        return prov

    # CircleCI
    if os.environ.get("CIRCLECI") == "true":
        prov.update(
            {
                "ci_provider": "circleci",
                "ci_run_id": os.environ.get("CIRCLE_BUILD_NUM"),
                "ci_run_url": os.environ.get("CIRCLE_BUILD_URL"),
                "ci_job_name": os.environ.get("CIRCLE_JOB"),
                "is_ci": True,
            }
        )
        return prov

    # Buildkite
    if os.environ.get("BUILDKITE") == "true":
        prov.update(
            {
                "ci_provider": "buildkite",
                "ci_run_id": os.environ.get("BUILDKITE_BUILD_NUMBER"),
                "ci_run_url": os.environ.get("BUILDKITE_BUILD_URL"),
                "ci_job_name": os.environ.get("BUILDKITE_PIPELINE_SLUG"),
                "is_ci": True,
            }
        )
        return prov

    # Travis CI
    if os.environ.get("TRAVIS") == "true":
        prov.update(
            {
                "ci_provider": "travis-ci",
                "ci_run_id": os.environ.get("TRAVIS_BUILD_ID"),
                "ci_run_url": os.environ.get("TRAVIS_BUILD_WEB_URL"),
                "ci_job_name": os.environ.get("TRAVIS_JOB_NAME"),
                "is_ci": True,
            }
        )
        return prov

    # Azure DevOps
    if os.environ.get("TF_BUILD") == "True":
        server = os.environ.get("SYSTEM_TEAMFOUNDATIONSERVERURI", "")
        project = os.environ.get("SYSTEM_TEAMPROJECT", "")
        build_id = os.environ.get("BUILD_BUILDID", "")
        prov.update(
            {
                "ci_provider": "azure-devops",
                "ci_run_id": build_id,
                "ci_run_url": (
                    f"{server}{project}/_build/results?buildId={build_id}" if all([server, project, build_id]) else None
                ),
                "ci_job_name": os.environ.get("AGENT_JOBNAME"),
                "is_ci": True,
            }
        )
        return prov

    # Generic CI detection (fallback)
    if os.environ.get("CI") in ("true", "1", "True"):
        prov.update(
            {
                "ci_provider": "unknown",
                "is_ci": True,
            }
        )
        return prov

    return prov


def _collect_image_provenance(overrides: Dict[str, str]) -> Optional[Dict[str, Any]]:
    """Collect container image provenance from CLI flags or CI environment."""
    image_ref = overrides.get("image")

    if not image_ref:
        # Try common CI env vars for image references
        image_ref = os.environ.get("REACHABLE_IMAGE") or os.environ.get("IMAGE_NAME")

    if not image_ref:
        return None

    prov: Dict[str, Any] = {
        "image_tag": image_ref,
        "image_digest": None,
    }

    # If the ref contains @sha256:, extract the digest
    if "@sha256:" in image_ref:
        parts = image_ref.split("@", 1)
        prov["image_tag"] = parts[0]
        prov["image_digest"] = parts[1]

    # CLI override for explicit digest
    if overrides.get("image_digest"):
        prov["image_digest"] = overrides["image_digest"]

    return prov


def collect_provenance(
    repo_path: Path,
    cli_overrides: Optional[Dict[str, str]] = None,
) -> Dict[str, Any]:
    """
    Collect complete build provenance for a scan.

    Args:
        repo_path: Path to the repository being scanned.
        cli_overrides: Optional dict of CLI flag overrides:
            - commit: Override auto-detected commit SHA
            - branch: Override auto-detected branch
            - tag: Override auto-detected tag
            - image: Container image reference
            - image_digest: Container image digest

    Returns:
        Dict with keys: source_provenance, build_provenance,
        and optionally image_provenance.
    """
    overrides = cli_overrides or {}

    result: Dict[str, Any] = {
        "source_provenance": _collect_source_provenance(repo_path, overrides),
        "build_provenance": _collect_build_provenance(),
    }

    image_prov = _collect_image_provenance(overrides)
    if image_prov:
        result["image_provenance"] = image_prov

    logger.debug(
        "Provenance collected: commit=%s branch=%s ci=%s",
        result["source_provenance"].get("commit_sha_short"),
        result["source_provenance"].get("branch"),
        result["build_provenance"].get("ci_provider"),
    )

    return result
