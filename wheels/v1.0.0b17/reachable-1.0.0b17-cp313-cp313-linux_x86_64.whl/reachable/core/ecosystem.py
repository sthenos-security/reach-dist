#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.

"""
Ecosystem Detector - Uses scan plan and Grype artifact type for accurate ecosystem detection
"""

from typing import Set


class EcosystemDetector:
    """Detects package ecosystems using multiple sources"""

    def __init__(self, scan_context=None):
        """
        Initialize with scan context

        Args:
            scan_context: ScanContext object with detected languages/subprojects
        """
        self.scan_context = scan_context
        self.detected_ecosystems = self._detect_from_scan_plan()

    def _detect_from_scan_plan(self) -> Set[str]:
        """Extract ecosystems from scan plan"""
        ecosystems = set()

        if not self.scan_context or not hasattr(self.scan_context, "subprojects"):
            return ecosystems

        for subproject in self.scan_context.subprojects:
            proj_type = subproject.get("type", "")
            if proj_type == "Node.js":
                ecosystems.add("npm")
            elif proj_type == "Python":
                ecosystems.add("python")
            elif proj_type == "Go":
                ecosystems.add("go")
            elif proj_type == "Rust":
                ecosystems.add("rust")

        return ecosystems

    def detect_package_ecosystem(self, package_name: str, artifact_type: str = "") -> str:
        """
        Detect ecosystem for a specific package

        Uses multiple signals:
        1. Grype artifact type (most reliable)
        2. Package name patterns
        3. Scan plan (from detected languages)

        Args:
            package_name: Package name (e.g., 'next', 'urllib3')
            artifact_type: Grype artifact type (e.g., 'npm', 'python', 'go-module')

        Returns:
            Ecosystem: 'npm', 'python', 'go', 'rust', 'unknown'
        """
        # Priority 1: Grype artifact type (most reliable)
        if artifact_type:
            if artifact_type in ("npm", "yarn"):
                return "npm"
            elif artifact_type in ("python", "wheel", "egg"):
                return "python"
            elif artifact_type in ("go-module", "go-binary"):
                return "go"
            elif artifact_type in ("cargo", "rust-crate"):
                return "rust"

        # Priority 2: Package name patterns
        # Go modules often have fully qualified names
        if (
            package_name.startswith("github.com/")
            or package_name.startswith("golang.org/")
            or package_name.startswith("gopkg.in/")
            or package_name.startswith("google.golang.org/")
        ):
            return "go"

        # Common NPM scoped packages
        if package_name.startswith("@"):
            return "npm"

        # Common Python naming
        if "-" in package_name and "/" not in package_name:
            # python-foo, foo-bar style (common in Python)
            # But could also be NPM, so check scan plan
            if "python" in self.detected_ecosystems and "npm" not in self.detected_ecosystems:
                return "python"

        # Priority 3: Scan plan context
        # If only one ecosystem detected, use it
        if len(self.detected_ecosystems) == 1:
            ecosystem = list(self.detected_ecosystems)[0]
            return ecosystem

        # If multiple ecosystems, we can't be sure without artifact_type
        # Return unknown and let the library manager try multiple registries
        return "unknown"

    def get_primary_ecosystem(self) -> str:
        """Get the primary ecosystem based on scan plan"""
        if "npm" in self.detected_ecosystems:
            return "npm"
        elif "python" in self.detected_ecosystems:
            return "python"
        elif "go" in self.detected_ecosystems:
            return "go"
        elif "rust" in self.detected_ecosystems:
            return "rust"
        return "unknown"

    def get_all_ecosystems(self) -> Set[str]:
        """Get all detected ecosystems"""
        return self.detected_ecosystems.copy()
