# Copyright © 2026 Sthenos Security. All rights reserved.


def detect_package_language(package_name: str) -> str:
    """
    Detect programming language/ecosystem from package name patterns.
    Returns: Go, JavaScript, Python, Java, Rust, or Other
    """
    if not package_name:
        return "Unknown"
    pkg = package_name.lower()

    # Go patterns (most specific first)
    # stdlib is Go's standard library
    if pkg == "stdlib" or pkg.startswith("go1."):
        return "Go"
    if any(x in pkg for x in ["golang.org", "github.com/", "k8s.io", "gopkg.in", "go.uber.org", "google.golang.org"]):
        return "Go"

    # Python patterns
    if any(
        x in pkg
        for x in [
            "requests",
            "flask",
            "django",
            "numpy",
            "pandas",
            "scipy",
            "pip",
            "setuptools",
            "pytest",
            "urllib3",
            "cryptography",
            "pillow",
            "beautifulsoup",
            "scrapy",
            "celery",
            "boto3",
            "pyyaml",
            "sqlalchemy",
        ]
    ):
        return "Python"

    # Java patterns
    if any(
        x in pkg
        for x in [
            "springframework",
            "maven",
            "apache",
            "javax",
            "org.apache",
            "com.google",
            "log4j",
            "jackson",
            "hibernate",
            "junit",
            "gradle",
        ]
    ):
        return "Java"

    # Rust patterns
    if any(x in pkg for x in ["crates.io", "tokio", "serde", "cargo"]):
        return "Rust"

    # JavaScript/TypeScript patterns (most npm packages)
    # @-scoped packages are definitely npm
    if pkg.startswith("@"):
        return "JavaScript"
    # Common npm package patterns
    js_patterns = [
        "next",
        "react",
        "vue",
        "angular",
        "express",
        "lodash",
        "webpack",
        "babel",
        "eslint",
        "typescript",
        "jest",
        "postcss",
        "braces",
        "micromatch",
        "yargs",
        "js-yaml",
        "mocha",
        "chai",
        "axios",
        "moment",
        "jquery",
        "bootstrap",
        "tailwind",
        "vite",
        "rollup",
        "esbuild",
        "prettier",
        "nodemon",
        "pm2",
        "socket.io",
        "set-value",
        "defaults-deep",
        "expand-object",
        "parse-git-config",
        "minimatch",
        "glob",
        "semver",
        "chalk",
        "commander",
        "inquirer",
        "ora",
        "debug",
    ]
    if any(x in pkg for x in js_patterns):
        return "JavaScript"

    # If package name is simple lowercase with hyphens and no dots, likely npm
    if "-" in pkg and "." not in pkg and "/" not in pkg:
        return "JavaScript"

    return "Other"


def detect_file_language(file_path: str) -> str:
    """Detect programming language from file extension"""
    if not file_path:
        return "Other"
    fp = file_path.lower()
    if fp.endswith((".py", ".pyx", ".pyi")):
        return "Python"
    elif fp.endswith((".js", ".ts", ".jsx", ".tsx", ".mjs", ".cjs")):
        return "JavaScript"
    elif fp.endswith(".go"):
        return "Go"
    elif fp.endswith((".java", ".kt", ".scala")):
        return "Java"
    elif fp.endswith(".rs"):
        return "Rust"
    elif fp.endswith((".c", ".cpp", ".cc", ".h", ".hpp")):
        return "C/C++"
    elif fp.endswith((".yml", ".yaml")):
        return "YAML"
    elif fp.endswith(".json"):
        return "JSON"
    elif fp.endswith((".env", ".sh", ".bash")):
        return "Config"
    return "Other"
