#!/usr/bin/env python3
"""
REACHABLE Comprehensive Data Quality Audit

Complete pipeline validation from Log → Raw JSON → Database → Dashboard
Checks ALL finding types, states, severities, risk scores, and reduction metrics.

This is the "smoking gun" audit to prove data quality to customers.
"""

import json
import logging
import sqlite3
import sys
from collections import defaultdict
from pathlib import Path
from typing import List, Optional

logger = logging.getLogger(__name__)

# Canonical order for finding types (must match scan log RESULTS table)
FINDING_TYPE_ORDER = ["cve", "malware", "secret", "cwe", "config", "ai", "dlp"]


def normalize_severity(sev: str) -> str:
    """Normalize non-standard severities to standard levels.

    P2.55 FIX: ERROR→CRITICAL (not HIGH). Semgrep uses ERROR as its
    highest severity for CWE findings like command injection. The CLI
    already displays these as CRITICAL — the integrity check must match.
    """
    sev = (sev or "MEDIUM").upper()
    if sev == "ERROR":
        return "CRITICAL"
    elif sev == "WARNING":
        return "MEDIUM"
    return sev


class PipelineMetrics:
    """Metrics from one stage of the pipeline."""

    def __init__(self, stage: str):
        self.stage = stage

        # Finding counts by type and reachability
        self.findings = defaultdict(lambda: {"total": 0, "reachable": 0, "unreachable": 0, "unknown": 0})

        # Severity counts (normalized)
        self.severity = {"CRITICAL": 0, "HIGH": 0, "MEDIUM": 0, "LOW": 0, "INFO": 0}

        # Risk metrics
        self.risk_score = None
        self.risk_level = None
        self.reduction_pct = None

        # Metadata
        self.files_scanned = None
        self.db_size_mb = None

        # Errors
        self.errors = []

    def total_findings(self) -> int:
        # P2.50: Exclude CONFIG from totals (not part of risk calculation)
        return sum(f["total"] for k, f in self.findings.items() if k.upper() != "CONFIG")

    def total_reachable(self) -> int:
        # P2.50: Exclude CONFIG from totals (not part of risk calculation)
        return sum(f["reachable"] for k, f in self.findings.items() if k.upper() != "CONFIG")

    def total_unreachable(self) -> int:
        # P2.50: Exclude CONFIG from totals (not part of risk calculation)
        return sum(f["unreachable"] for k, f in self.findings.items() if k.upper() != "CONFIG")


class ComprehensiveAuditor:
    """Complete data quality auditor."""

    def __init__(self, scan_path: Path):
        self.scan_path = scan_path.resolve()
        self.repo_dir = self.scan_path.parent.parent
        self.db_path = self.repo_dir / "repo.db"

    def audit_raw(self) -> PipelineMetrics:
        """Audit raw JSON files in raw/ directory (ground truth from scanners).

        v5.1.3: Reads directly from raw/*.json files instead of reachable-report.json
        which no longer exists. Each raw file is the scanner's actual output.
        """
        m = PipelineMetrics("RAW JSON")
        raw_dir = self.scan_path / "raw"

        if not raw_dir.exists():
            m.errors.append("raw/ directory not found")
            return m

        # Track per-type severity for breakdown
        m.severity_by_type = defaultdict(lambda: defaultdict(int))
        m.reachable_severity_by_type = defaultdict(lambda: defaultdict(int))

        try:
            # ── CVEs from cve-analyzed.json ──
            cve_file = raw_dir / "cve-analyzed.json"
            if cve_file.exists():
                with open(cve_file) as f:
                    cve_data = json.load(f)
                reachable_cves = cve_data.get("reachable", {})
                unreachable_cves = cve_data.get("unreachable", {})
                m.findings["cve"]["reachable"] = len(reachable_cves)
                m.findings["cve"]["unreachable"] = len(unreachable_cves)
                m.findings["cve"]["total"] = len(reachable_cves) + len(unreachable_cves)
                for cve in reachable_cves.values():
                    sev = normalize_severity(cve.get("severity", "MEDIUM"))
                    m.severity[sev] = m.severity.get(sev, 0) + 1
                    m.severity_by_type["cve"][sev] += 1
                    m.reachable_severity_by_type["cve"][sev] += 1
                for cve in unreachable_cves.values():
                    sev = normalize_severity(cve.get("severity", "MEDIUM"))
                    m.severity[sev] = m.severity.get(sev, 0) + 1
                    m.severity_by_type["cve"][sev] += 1

            # ── CWE/Secret/Config from security-findings.json ──
            sf_file = raw_dir / "security-findings.json"
            if sf_file.exists():
                with open(sf_file) as f:
                    sf_data = json.load(f)
                results_list = sf_data.get("results", sf_data.get("findings", []))
                if isinstance(results_list, list):
                    for finding in results_list:
                        # Classify same as semgrep normalizer
                        rule_id = finding.get("check_id", finding.get("rule_id", ""))
                        filepath = finding.get("path", finding.get("file", ""))
                        is_secret = finding.get("is_actual_secret", False)

                        # Determine type
                        # v5.1.3 BUG 7: Sync with normalizer SECRET_RULE_PATTERNS + message detection
                        _msg = (finding.get("extra", {}).get("message", "") or finding.get("message", "") or "").lower()
                        if (
                            is_secret
                            or _msg.startswith("secret detected:")
                            or any(
                                p in rule_id.lower()
                                for p in [
                                    "secrets.",
                                    "leaked-",
                                    "hardcoded-",
                                    "api-key",
                                    "password",
                                    "token",
                                    "credential",
                                    "access_key",
                                    "secret_key",
                                    "encryption_key",
                                ]
                            )
                        ):
                            ftype = "secret"
                        elif any(
                            filepath.lower().endswith(e)
                            for e in (
                                ".yaml",
                                ".yml",
                                ".json",
                                ".tf",
                                ".hcl",
                                ".toml",
                                ".ini",
                                ".cfg",
                                ".conf",
                                ".env",
                                ".properties",
                            )
                        ):
                            if not any(
                                filepath.lower().endswith(e)
                                for e in (".go", ".py", ".js", ".ts", ".java", ".rb", ".rs")
                            ):
                                ftype = "config"
                            else:
                                ftype = "cwe"
                        elif any(
                            p in rule_id.lower() for p in ["dockerfile.", "kubernetes.", "terraform.", "helm.", "yaml."]
                        ):
                            ftype = "config"
                        else:
                            ftype = "cwe"

                        m.findings[ftype]["total"] += 1

                        # Reachability
                        is_reach = finding.get("is_reachable")
                        reach_str = finding.get("reachability", "").lower()
                        if ftype == "config":
                            m.findings[ftype]["unknown"] += 1
                        elif is_reach is True or reach_str == "reachable":
                            m.findings[ftype]["reachable"] += 1
                        elif is_reach is False or reach_str in ("not_reachable", "unreachable"):
                            m.findings[ftype]["unreachable"] += 1
                        else:
                            m.findings[ftype]["unknown"] += 1

                        raw_sev = finding.get("extra", {}).get("severity", finding.get("severity", "WARNING"))
                        sev = normalize_severity(raw_sev)
                        m.severity[sev] = m.severity.get(sev, 0) + 1
                        m.severity_by_type[ftype][sev] += 1
                        if is_reach is True or reach_str == "reachable":
                            m.reachable_severity_by_type[ftype][sev] += 1

            # ── Malware from static-malware-extracted.json ──
            # Always check static-malware-extracted.json first (YARA + GuardDog findings)
            # then also check malware.json for additional package-level GuardDog data.
            # Both files can coexist and must be merged to get the true raw count.
            mal_file = raw_dir / "static-malware-extracted.json"
            if mal_file.exists():
                with open(mal_file) as f:
                    mal_data = json.load(f)
                findings = mal_data.get("findings", [])
                for f_item in findings:
                    # v5.2.0: always count as 'malware' regardless of finding_type in file.
                    # Old scans may have finding_type='suspicious' — that type is retired.
                    # Reachability state carries certainty; type is always 'malware'.
                    ft = "malware"
                    m.findings[ft]["total"] += 1
                    reach = f_item.get("app_reachability", "UNKNOWN").upper()
                    if reach == "REACHABLE":
                        m.findings[ft]["reachable"] += 1
                    elif reach in ("NOT_REACHABLE", "NOT REACHABLE"):
                        m.findings[ft]["unreachable"] += 1
                    else:
                        m.findings[ft]["unknown"] += 1
                    sev = normalize_severity(f_item.get("severity", "HIGH"))
                    m.severity[sev] = m.severity.get(sev, 0) + 1
                    m.severity_by_type[ft][sev] += 1
                    if reach == "REACHABLE":
                        m.reachable_severity_by_type[ft][sev] += 1

            # Also check malware.json for GuardDog package-level findings
            # (malicious_packages count — separate from YARA file findings)
            mal_json = raw_dir / "malware.json"
            if mal_json.exists():
                with open(mal_json) as f:
                    raw_mal = json.load(f)
                mal_count = raw_mal.get("malicious_packages", 0)
                if isinstance(mal_count, list):
                    mal_count = len(mal_count)
                if isinstance(mal_count, int) and mal_count > 0:
                    # Only add if not already covered by static-malware-extracted.json
                    # to avoid double-counting GuardDog package findings
                    if not mal_file.exists():
                        m.findings["malware"]["total"] += mal_count
                        m.findings["malware"]["unknown"] += mal_count

            # ── AI from ai-security.json ──
            ai_file = raw_dir / "ai-security.json"
            if ai_file.exists():
                with open(ai_file) as f:
                    ai_data = json.load(f)
                for finding in ai_data.get("findings", []):
                    m.findings["ai"]["total"] += 1
                    if finding.get("is_reachable", True):
                        m.findings["ai"]["reachable"] += 1
                    else:
                        m.findings["ai"]["unreachable"] += 1
                    sev = normalize_severity(finding.get("severity", "MEDIUM"))
                    m.severity[sev] = m.severity.get(sev, 0) + 1
                    m.severity_by_type["ai"][sev] += 1
                    if finding.get("is_reachable", True):
                        m.reachable_severity_by_type["ai"][sev] += 1

            # ── DLP from dlp-security.json ──
            dlp_file = raw_dir / "dlp-security.json"
            if dlp_file.exists():
                with open(dlp_file) as f:
                    dlp_data = json.load(f)
                for finding in dlp_data.get("findings", []):
                    m.findings["dlp"]["total"] += 1
                    if finding.get("is_reachable", True):
                        m.findings["dlp"]["reachable"] += 1
                    else:
                        m.findings["dlp"]["unreachable"] += 1
                    # DLP normalizer reads severity then adjusted_severity
                    raw_sev = finding.get("severity", finding.get("adjusted_severity", "MEDIUM"))
                    sev = normalize_severity(raw_sev)
                    m.severity[sev] = m.severity.get(sev, 0) + 1
                    m.severity_by_type["dlp"][sev] += 1
                    if finding.get("is_reachable", True):
                        m.reachable_severity_by_type["dlp"][sev] += 1

        except Exception as e:
            m.errors.append(f"Error reading raw data: {e}")
            import traceback

            m.errors.append(traceback.format_exc())

        return m

    def audit_database(self) -> PipelineMetrics:
        """Audit database (persisted scan data)."""
        m = PipelineMetrics("DATABASE")
        m.severity_by_type = defaultdict(lambda: defaultdict(int))
        m.reachable_severity_by_type = defaultdict(lambda: defaultdict(int))

        if not self.db_path.exists():
            m.errors.append("repo.db not found (--no-db mode or first scan)")
            return m

        m.db_size_mb = self.db_path.stat().st_size / 1024 / 1024

        try:
            conn = sqlite3.connect(str(self.db_path))
            conn.row_factory = sqlite3.Row
            conn.execute("PRAGMA busy_timeout=5000")  # SL-12: reduced from 30s; log if hit
            cursor = conn.cursor()

            # Get scan that matches this specific scan path
            # scan_dir in DB stores the full path to the scan directory
            cursor.execute(
                """
                SELECT * FROM scans
                WHERE scan_dir = ?
                ORDER BY id DESC LIMIT 1
            """,
                (str(self.scan_path),),
            )
            scan_row = cursor.fetchone()

            # Fallback: try with just the timestamp portion of the path
            if not scan_row:
                scan_timestamp = self.scan_path.name  # e.g., "20260130-140715-2b9f8b"
                cursor.execute(
                    """
                    SELECT * FROM scans
                    WHERE scan_dir LIKE ?
                    ORDER BY id DESC LIMIT 1
                """,
                    (f"%/{scan_timestamp}",),
                )
                scan_row = cursor.fetchone()

            # Final fallback: try matching on timestamp prefix
            if not scan_row:
                scan_prefix = self.scan_path.name[:15]  # "20260130-140715"
                cursor.execute(
                    """
                    SELECT * FROM scans
                    WHERE scan_dir LIKE ?
                    ORDER BY id DESC LIMIT 1
                """,
                    (f"%{scan_prefix}%",),
                )
                scan_row = cursor.fetchone()
                if scan_row:
                    m.errors.append("WARNING: Using partial match for scan path")

            if not scan_row:
                m.errors.append("No data for this scan in database (scan may not have completed)")
                conn.close()
                return m

            scan_id = scan_row["id"]
            m.risk_score = scan_row["risk_score"]
            m.risk_level = scan_row["risk_level"]
            try:
                m.files_scanned = scan_row["source_files_scanned"]
            except (KeyError, IndexError):
                m.files_scanned = None

            # CVE, CWE, secrets, config from findings table
            cursor.execute(
                """
                SELECT finding_type,
                       app_reachability,
                       severity,
                       COUNT(*) as count
                FROM findings
                WHERE scan_id = ?
                GROUP BY finding_type, app_reachability, severity
            """,
                (scan_id,),
            )

            for row in cursor.fetchall():
                ftype = row["finding_type"].lower()
                reach = row["app_reachability"]
                sev = normalize_severity(row["severity"])
                count = row["count"]

                m.findings[ftype]["total"] += count

                if reach == "REACHABLE":
                    m.findings[ftype]["reachable"] += count
                elif reach == "NOT_REACHABLE":
                    m.findings[ftype]["unreachable"] += count
                else:
                    m.findings[ftype]["unknown"] += count

                m.severity[sev] = m.severity.get(sev, 0) + count
                m.severity_by_type[ftype][sev] += count
                if reach == "REACHABLE":
                    m.reachable_severity_by_type[ftype][sev] += count

            # AI findings
            try:
                cursor.execute(
                    """
                    SELECT is_reachable, severity, COUNT(*) as count
                    FROM ai_findings
                    WHERE scan_id = ?
                    GROUP BY is_reachable, severity
                """,
                    (scan_id,),
                )

                for row in cursor.fetchall():
                    count = row["count"]
                    m.findings["ai"]["total"] += count

                    if row["is_reachable"]:
                        m.findings["ai"]["reachable"] += count
                    else:
                        m.findings["ai"]["unreachable"] += count

                    sev = normalize_severity(row["severity"])
                    m.severity[sev] = m.severity.get(sev, 0) + count
                    m.severity_by_type["ai"][sev] += count
                    if row["is_reachable"]:
                        m.reachable_severity_by_type["ai"][sev] += count
            except sqlite3.OperationalError:
                pass

            # DLP findings
            try:
                cursor.execute(
                    """
                    SELECT is_reachable, severity, COUNT(*) as count
                    FROM dlp_findings
                    WHERE scan_id = ?
                    GROUP BY is_reachable, severity
                """,
                    (scan_id,),
                )

                for row in cursor.fetchall():
                    count = row["count"]
                    m.findings["dlp"]["total"] += count

                    if row["is_reachable"]:
                        m.findings["dlp"]["reachable"] += count
                    else:
                        m.findings["dlp"]["unreachable"] += count

                    sev = normalize_severity(row["severity"])
                    m.severity[sev] = m.severity.get(sev, 0) + count
                    m.severity_by_type["dlp"][sev] += count
                    if row["is_reachable"]:
                        m.reachable_severity_by_type["dlp"][sev] += count
            except sqlite3.OperationalError:
                pass

            # Calculate noise reduction
            total = m.total_findings()
            unreachable = m.total_unreachable()
            if total > 0:
                m.reduction_pct = 100 * (unreachable / total)

            conn.close()

        except Exception as e:
            m.errors.append(f"Database error: {e}")

        return m

    def audit_dashboard(self) -> PipelineMetrics:
        """Audit dashboard data.json or embedded HTML data."""
        m = PipelineMetrics("DASHBOARD")

        # Prefer data.json (more reliable than parsing HTML)
        data_json_path = self.scan_path / "dashboard" / "data.json"
        dash_html_path = self.scan_path / "dashboard" / "index.html"

        data = None

        if data_json_path.exists():
            try:
                data = json.loads(data_json_path.read_text())
            except Exception as e:
                m.errors.append(f"data.json parse error: {e}")

        if data is None and dash_html_path.exists():
            try:
                content = dash_html_path.read_text()
                # Use bracket-counter instead of re.DOTALL regex — avoids O(n²) backtracking
                # on large dashboards with many findings embedded in window.dashboardData.
                import time as _time

                _t0 = _time.monotonic()
                data = None
                for line in content.splitlines():
                    idx = line.find("window.dashboardData")
                    if idx == -1:
                        continue
                    brace_start = line.find("{", idx)
                    if brace_start == -1:
                        continue
                    # Collect from brace_start to matching closing brace
                    json_chars = []
                    depth = 0
                    in_str = False
                    escape = False
                    for ch in line[brace_start:]:
                        json_chars.append(ch)
                        if escape:
                            escape = False
                            continue
                        if ch == "\\" and in_str:
                            escape = True
                            continue
                        if ch == '"':
                            in_str = not in_str
                            continue
                        if not in_str:
                            if ch == "{":
                                depth += 1
                            elif ch == "}":
                                depth -= 1
                                if depth == 0:
                                    break
                    if depth == 0:
                        try:
                            data = json.loads("".join(json_chars))
                        except Exception:
                            pass
                    break
                elapsed = _time.monotonic() - _t0
                if elapsed > 1.0:
                    logger.warning(f"Dashboard HTML parse took {elapsed:.1f}s — consider regenerating dashboard")
            except Exception as e:
                m.errors.append(f"HTML parse error: {e}")

        if data is None:
            m.errors.append("Dashboard not found")
            return m

        try:
            m.risk_score = data.get("riskScore") or data.get("risk_score")
            m.risk_level = data.get("riskLevel") or data.get("risk_level")

            # Count issues from issues array
            issues = data.get("issues", [])
            for issue in issues:
                itype = issue.get("type", "unknown").lower()
                sev = normalize_severity(issue.get("severity", "MEDIUM"))
                is_reach = issue.get("reachable", False) or issue.get("is_reachable", False)
                reach_state = issue.get("reachability_state", "").lower()

                m.findings[itype]["total"] += 1

                if is_reach or reach_state == "reachable":
                    m.findings[itype]["reachable"] += 1
                elif reach_state == "unknown":
                    m.findings[itype]["unknown"] += 1
                else:
                    m.findings[itype]["unreachable"] += 1

                m.severity[sev] = m.severity.get(sev, 0) + 1

            # P2.50 FIX: AI and DLP are now included in issues[] via loaders.py
            # _convert_ai_to_issues() and _convert_dlp_to_issues()
            # Only count from separate arrays if NOT already in issues[]

            # AI findings - only count if not already in issues[]
            ai_in_issues = m.findings.get("ai", {}).get("total", 0)
            if ai_in_issues == 0:
                ai_security = data.get("ai_security", {})
                if isinstance(ai_security, dict) and ai_security.get("total", 0) > 0:
                    m.findings["ai"]["total"] = ai_security.get("total", 0)
                    m.findings["ai"]["reachable"] = ai_security.get("reachable", 0)
                    m.findings["ai"]["unreachable"] = m.findings["ai"]["total"] - m.findings["ai"]["reachable"]
                elif isinstance(ai_security, dict):
                    ai_findings = ai_security.get("findings", [])
                    for finding in ai_findings:
                        m.findings["ai"]["total"] += 1
                        if finding.get("is_reachable"):
                            m.findings["ai"]["reachable"] += 1
                        else:
                            m.findings["ai"]["unreachable"] += 1

            # DLP findings - only count if not already in issues[]
            dlp_in_issues = m.findings.get("dlp", {}).get("total", 0)
            if dlp_in_issues == 0:
                dlp_findings = data.get("dlp_findings", []) or data.get("dlpFindings", [])
                for finding in dlp_findings:
                    m.findings["dlp"]["total"] += 1
                    if finding.get("is_reachable"):
                        m.findings["dlp"]["reachable"] += 1
                    else:
                        m.findings["dlp"]["unreachable"] += 1

        except Exception as e:
            m.errors.append(f"Dashboard error: {e}")

        return m

    def audit_panels(self, dash_data: Optional[dict] = None) -> List[str]:
        """P2.60: Validate pre-computed panel data against database.

        Checks that d.engineering.*, d.exec_summary.*, and d.funnel.*
        match direct DB queries. This ensures loaders.py is the single
        source of truth and JS is not recalculating stale values.
        """
        issues = []

        if not dash_data:
            # Load from data.json
            data_json_path = self.scan_path / "dashboard" / "data.json"
            if not data_json_path.exists():
                return ["Panel audit skipped: data.json not found"]
            try:
                dash_data = json.loads(data_json_path.read_text())
            except Exception as e:
                return [f"Panel audit error: {e}"]

        eng = dash_data.get("engineering", {})
        es = dash_data.get("exec_summary", {})
        funnel = dash_data.get("funnel", {})
        all_issues = dash_data.get("issues", [])

        if not eng:
            issues.append("PANEL: engineering data missing from dashboard")
        if not es:
            issues.append("PANEL: exec_summary data missing from dashboard")
        if not funnel:
            issues.append("PANEL: funnel data missing from dashboard")

        if not (eng and es and funnel and all_issues):
            return issues

        # --- Validate engineering panel vs issues[] ---
        def count_issues(type_filter, reach_filter=None, sev_filter=None):
            count = 0
            for f in all_issues:
                ftype = (f.get("type") or "").upper()
                if isinstance(type_filter, str):
                    if ftype != type_filter.upper():
                        continue
                elif isinstance(type_filter, (list, tuple)):
                    if ftype not in [t.upper() for t in type_filter]:
                        continue
                if reach_filter:
                    rs = f.get("reachability_state", "")
                    if not rs:
                        ir = f.get("is_reachable")
                        rs = "reachable" if ir is True else ("not_reachable" if ir is False else "unknown")
                    if rs != reach_filter:
                        continue
                if sev_filter:
                    sev = normalize_severity(f.get("severity", "MEDIUM"))
                    if sev != sev_filter:
                        continue
                count += 1
            return count

        # CVE panel checks
        cve_eng = eng.get("cve", {})
        cve_reach = count_issues("CVE", "reachable")
        cve_unknown = count_issues("CVE", "unknown")
        expected_total = cve_reach + cve_unknown
        if cve_eng.get("total", 0) != expected_total:
            issues.append(f"PANEL CVE: eng.total={cve_eng.get('total')} vs issues(reach+unkn)={expected_total}")
        if cve_eng.get("reachable", 0) != cve_reach:
            issues.append(f"PANEL CVE: eng.reachable={cve_eng.get('reachable')} vs issues={cve_reach}")

        # CWE panel checks
        cwe_eng = eng.get("cwe", {})
        cwe_reach = count_issues("CWE", "reachable")
        cwe_unknown = count_issues("CWE", "unknown")
        expected_cwe = cwe_reach + cwe_unknown
        if cwe_eng.get("total", 0) != expected_cwe:
            issues.append(f"PANEL CWE: eng.total={cwe_eng.get('total')} vs issues(reach+unkn)={expected_cwe}")

        # Config panel checks
        cfg_eng = eng.get("config", {})
        # P2.60 FIX: count_issues already uppercases type, so 'CONFIG' and 'Config'
        # both match the same issues. Do NOT add them — that double-counts.
        cfg_total = count_issues("CONFIG")
        if cfg_eng.get("total", 0) != cfg_total:
            issues.append(f"PANEL CONFIG: eng.total={cfg_eng.get('total')} vs issues={cfg_total}")

        # --- Validate exec summary vs issues[] ---
        es_crit = es.get("critical_total", 0)
        es_high = es.get("high_total", 0)

        # P2.60 FIX: Count actionable critical/high from issues.
        # Must match _build_exec_summary() logic: malware is deduped by package.
        actionable_critical = 0
        actionable_high = 0
        mal_crit_pkgs = set()  # Distinct malware packages at CRITICAL
        mal_high_pkgs = set()  # Distinct malware packages at HIGH
        for f in all_issues:
            rs = f.get("reachability_state", "")
            if not rs:
                ir = f.get("is_reachable")
                rs = "reachable" if ir is True else ("not_reachable" if ir is False else "unknown")
            if rs == "not_reachable":
                continue
            ftype = (f.get("type") or "").upper()
            sev = normalize_severity(f.get("severity", "MEDIUM"))
            if ftype in ("MALWARE", "SUSPICIOUS"):
                # Exec summary deduplicates malware by package
                pkg_key = f.get("package") or f.get("finding_id") or ""
                if pkg_key:
                    if sev == "CRITICAL":
                        mal_crit_pkgs.add(pkg_key)
                    elif sev == "HIGH":
                        mal_high_pkgs.add(pkg_key)
            else:
                if sev == "CRITICAL":
                    actionable_critical += 1
                elif sev == "HIGH":
                    actionable_high += 1
        # Add deduped malware counts
        actionable_critical += len(mal_crit_pkgs)
        actionable_high += len(mal_high_pkgs)

        if abs(es_crit - actionable_critical) > 2:
            issues.append(f"PANEL EXEC: critical_total={es_crit} vs issues_actionable_critical={actionable_critical}")
        if abs(es_high - actionable_high) > 2:
            issues.append(f"PANEL EXEC: high_total={es_high} vs issues_actionable_high={actionable_high}")

        # --- Validate funnel vs issues[] ---
        funnel_raw = funnel.get("raw_total", 0)

        # P2.60 FIX: Funnel counts malware by distinct PACKAGES, not individual findings.
        # Must replicate that logic here for a fair comparison.
        non_malware_count = 0
        malware_pkgs = set()
        issues_reach_excl_config = 0
        for f in all_issues:
            ftype = (f.get("type") or "").upper()
            if ftype == "CONFIG":
                continue
            rs = f.get("reachability_state", "")
            if not rs:
                ir = f.get("is_reachable")
                rs = "reachable" if ir is True else "unknown"
            if ftype in ("MALWARE", "SUSPICIOUS"):
                pkg_key = f.get("package") or f.get("file_path") or f.get("finding_id") or "unknown"
                malware_pkgs.add(pkg_key)
            else:
                non_malware_count += 1
            if rs == "reachable":
                issues_reach_excl_config += 1
        issues_total_excl_config = non_malware_count + len(malware_pkgs)

        if abs(funnel_raw - issues_total_excl_config) > 2:
            issues.append(f"PANEL FUNNEL: raw_total={funnel_raw} vs issues(excl config)={issues_total_excl_config}")

        if not issues:
            issues.append(" All panel validations passed")

        return issues

    def compare_stages(self, raw: PipelineMetrics, db: PipelineMetrics, dash: PipelineMetrics) -> List[str]:
        """Compare stages and return list of issues."""
        issues = []

        for ftype in FINDING_TYPE_ORDER:
            raw_f = raw.findings.get(ftype, {})
            db_f = db.findings.get(ftype, {})
            dash_f = dash.findings.get(ftype, {})

            raw_total = raw_f.get("total", 0)
            db_total = db_f.get("total", 0)
            dash_total = dash_f.get("total", 0)

            # P2.55 FIX: Tightened from >5 to >0. With DB fallback for DLP/AI,
            # raw and DB should match exactly. Any mismatch = real data loss.
            if raw_total > 0 and db_total > 0 and raw_total != db_total:
                diff = raw_total - db_total
                if diff > 0:
                    issues.append(f" {ftype.upper()}: Raw={raw_total}, DB={db_total} ({diff} deduped)")
                elif abs(diff) <= max(5, raw_total * 0.10):
                    # v5.1.3: Small increase = normalizer reclassified findings INTO this type
                    # e.g. SECRET Raw=125, DB=129 when config-file secrets get reclassified
                    issues.append(f" {ftype.upper()}: Raw={raw_total}, DB={db_total} ({abs(diff)} reclassified in)")
                else:
                    issues.append(f" {ftype.upper()}: Raw={raw_total}, DB={db_total} (MISMATCH)")

            # P2.44 check: DB has findings but dashboard shows 0
            if db_total > 0 and dash_total == 0:
                issues.append(f" P2.44 BUG: {ftype.upper()} dashboard shows 0 but DB has {db_total}")

            # Compare reachable counts
            raw_f.get("reachable", 0)
            db_reach = db_f.get("reachable", 0)
            raw_total = raw_f.get("total", 0)

            # SL-13: db_reachable > raw_reachable is legitimate when the normalizer
            # filters FP findings that happened to be reachable in raw (e.g. pattern-
            # definition files). Only flag the impossible case: db_reachable > raw_total.
            if db_reach > raw_total and raw_total > 0:
                issues.append(f"  {ftype.upper()} reachable: DB={db_reach} exceeds Raw total={raw_total} (data error)")

        # Risk score drift
        if raw.risk_score and db.risk_score and abs(raw.risk_score - db.risk_score) > 10:
            issues.append(f"  Risk score drift: Raw={raw.risk_score}, DB={db.risk_score}")

        if db.risk_score and dash.risk_score and abs(db.risk_score - dash.risk_score) > 10:
            issues.append(f"  Risk score drift: DB={db.risk_score}, Dashboard={dash.risk_score}")

        return issues

    def print_report(self, raw: PipelineMetrics, db: PipelineMetrics, dash: PipelineMetrics, issues: List[str]):
        """Print comprehensive report."""
        logger.info(" REACHABLE DATA QUALITY AUDIT (deduplicated, from DB unique records)")
        logger.info(f" Scan: {self.scan_path}")
        db_size_str = f"{db.db_size_mb:.2f} MB" if db.db_size_mb is not None else "N/A"
        logger.info(f" Database: {self.db_path} ({db_size_str})")

        # Stage comparison table
        # Note: Raw = scanner output (may have duplicates), DB/Dash = deduplicated unique records
        logger.info(
            f"{'Type':<10} {'Raw':>6} {'DB':>6} {'Dash':>6} {'Reach':>5} {'Unrch':>5} {'Unkn':>5} {'Filtered':>8}"
        )
        logger.info("─" * 68)

        # Use canonical order for finding types
        for ftype in FINDING_TYPE_ORDER:
            raw_f = raw.findings.get(ftype, {})
            db_f = db.findings.get(ftype, {})
            dash_f = dash.findings.get(ftype, {})

            raw_total = raw_f.get("total", 0)
            db_total = db_f.get("total", 0)
            dash_total = dash_f.get("total", 0)

            db_reach = db_f.get("reachable", 0)
            db_unreach = db_f.get("unreachable", 0)
            db_unknown = db_f.get("unknown", 0)

            reduction = ""
            if db_total > 0:
                pct = 100 * (db_unreach / db_total)
                reduction = f"{pct:5.1f}%"

            match = "" if abs(raw_total - db_total) <= 5 or raw_total == 0 or db_total == 0 else ""

            logger.info(
                f"{ftype.upper():<10} {raw_total:>6} {db_total:>6} {dash_total:>6} "
                f"{db_reach:>5} {db_unreach:>5} {db_unknown:>5}  {reduction:>8} {match}"
            )

        # Totals
        logger.info("─" * 68)
        raw_total = raw.total_findings()
        db_total = db.total_findings()
        dash_total = dash.total_findings()
        db_reach = db.total_reachable()
        db_unreach = db.total_unreachable()
        # P2.50: Exclude CONFIG from unknown total (not part of risk calculation)
        db_unknown = sum(f.get("unknown", 0) for k, f in db.findings.items() if k.upper() != "CONFIG")

        total_reduction = ""
        if db_total > 0:
            pct = 100 * (db_unreach / db_total)
            total_reduction = f"{pct:5.1f}%"

        logger.info(
            f"{'TOTAL':<10} {raw_total:>6} {db_total:>6} {dash_total:>6} "
            f"{db_reach:>5} {db_unreach:>5} {db_unknown:>5}  {total_reduction:>8}"
        )
        logger.info(f"{'(excl CONFIG)':<10}")

        # Severity breakdown (inline totals)
        sev_parts = []
        for sev in ["CRITICAL", "HIGH", "MEDIUM", "LOW", "INFO"]:
            count = db.severity.get(sev, 0)
            if count > 0:
                sev_parts.append(f"{sev}: {count}")
        if sev_parts:
            logger.info(f"Severity: {' | '.join(sev_parts)}")

        # Per-type severity breakdown (Raw vs DB)
        logger.info("")
        logger.info(" Severity Breakdown by Signal:")
        logger.info(f"{'Type':<10} {'Source':>6}  {'CRIT':>5} {'HIGH':>5} {'MED':>5} {'LOW':>5} {'Total':>6}")
        logger.info("─" * 55)

        raw_sbt = getattr(raw, "severity_by_type", {})
        db_sbt = getattr(db, "severity_by_type", {})

        for ftype in FINDING_TYPE_ORDER:
            raw_f = raw.findings.get(ftype, {})
            db_f = db.findings.get(ftype, {})
            raw_st = raw_sbt.get(ftype, {}) if raw_sbt else {}
            db_st = db_sbt.get(ftype, {}) if db_sbt else {}

            raw_total = raw_f.get("total", 0)
            db_total = db_f.get("total", 0)

            if raw_total > 0:
                rc = raw_st.get("CRITICAL", 0)
                rh = raw_st.get("HIGH", 0)
                rm = raw_st.get("MEDIUM", 0)
                rl = raw_st.get("LOW", 0) + raw_st.get("INFO", 0)
                logger.info(f"{ftype.upper():<10} {'Raw':>6}  {rc:>5} {rh:>5} {rm:>5} {rl:>5} {raw_total:>6}")
            if db_total > 0:
                dc = db_st.get("CRITICAL", 0)
                dh = db_st.get("HIGH", 0)
                dm = db_st.get("MEDIUM", 0)
                dl = db_st.get("LOW", 0) + db_st.get("INFO", 0)
                match = (
                    "\u2705"
                    if (raw_total == 0 or (raw_st.get("CRITICAL", 0) == dc and raw_st.get("HIGH", 0) == dh))
                    else "\u274c"
                )
                logger.info(f"{'':10} {'DB':>6}  {dc:>5} {dh:>5} {dm:>5} {dl:>5} {db_total:>6} {match}")

        logger.info("─" * 55)

        # Reachable-only severity breakdown
        db_rsbt = getattr(db, "reachable_severity_by_type", {})
        if db_rsbt:
            logger.info("")
            logger.info(" Severity Breakdown (reachable only):")
            logger.info(f"{'Type':<10} {'CRIT':>5} {'HIGH':>5} {'MED':>5} {'LOW':>5} {'Total':>6}")
            logger.info("─" * 42)
            grand = {"CRITICAL": 0, "HIGH": 0, "MEDIUM": 0, "LOW": 0}
            for ftype in FINDING_TYPE_ORDER:
                rst = db_rsbt.get(ftype, {})
                if not rst:
                    continue
                rc = rst.get("CRITICAL", 0)
                rh = rst.get("HIGH", 0)
                rm = rst.get("MEDIUM", 0)
                rl = rst.get("LOW", 0) + rst.get("INFO", 0)
                rt = rc + rh + rm + rl
                if rt > 0:
                    logger.info(f"{ftype.upper():<10} {rc:>5} {rh:>5} {rm:>5} {rl:>5} {rt:>6}")
                    grand["CRITICAL"] += rc
                    grand["HIGH"] += rh
                    grand["MEDIUM"] += rm
                    grand["LOW"] += rl
            gt = sum(grand.values())
            if gt > 0:
                logger.info("─" * 42)
                logger.info(
                    f"{'TOTAL':<10} {grand['CRITICAL']:>5} {grand['HIGH']:>5} {grand['MEDIUM']:>5} {grand['LOW']:>5} {gt:>6}"
                )

        # Risk metrics (inline)
        # P2.60a FIX: Recalculate risk_level from ALL 3 finding tables
        # (findings + ai_findings + dlp_findings). Stored value may be stale.
        # Must match calculate_risk_level() priority in metrics.py.
        calculated_risk = "LOW"
        db_findings = db.findings
        # db.findings keys are lowercase (from finding_type.lower())
        has_malware = db_findings.get("malware", {}).get("total", 0) > 0
        has_suspicious = db_findings.get("suspicious", {}).get("total", 0) > 0

        # Severity from ALL tables (db.severity aggregates findings + ai_findings + dlp_findings)
        has_critical = db.severity.get("CRITICAL", 0) > 0
        has_high = db.severity.get("HIGH", 0) > 0
        has_medium = db.severity.get("MEDIUM", 0) > 0

        # Reachable from ALL types (including AI and DLP)
        total_reachable = sum(f.get("reachable", 0) for f in db_findings.values() if isinstance(f, dict))

        if has_malware or has_suspicious:
            calculated_risk = "CRITICAL"
        elif has_critical and total_reachable > 0:
            # CRITICAL severity + reachable findings across any table
            calculated_risk = "CRITICAL"
        elif has_critical:
            # CRITICAL findings exist but reachability unknown/not_reachable
            calculated_risk = "HIGH"
        elif has_high and total_reachable > 0:
            calculated_risk = "HIGH"
        elif has_high:
            calculated_risk = "MEDIUM"
        elif total_reachable > 0:
            calculated_risk = "HIGH"
        elif has_medium:
            calculated_risk = "MEDIUM"

        risk_parts = []
        if db.risk_level != calculated_risk:
            risk_parts.append(f"Level: {db.risk_level} → {calculated_risk} (recalculated from DB)")
        else:
            risk_parts.append(f"Level: {db.risk_level}")
        if db.risk_score:
            risk_parts.append(f"Score: {db.risk_score}")
        if db.reduction_pct:
            risk_parts.append(f"Noise Reduction: {db.reduction_pct:.1f}%")
        if risk_parts:
            logger.info(f"Risk: {' | '.join(risk_parts)}")

        # P2.60: Panel validation (engineering, exec_summary, funnel)
        panel_issues = self.audit_panels()
        logger.info("")
        logger.info(" Panel Validation (P2.60):")
        for pi in panel_issues:
            logger.info(f"  {pi}")

        # Validation results
        real_panel_issues = [p for p in panel_issues if not p.startswith(" ")]
        if not issues and not any([raw.errors, db.errors, dash.errors]) and not real_panel_issues:
            logger.info(" All checks passed - data integrity confirmed")
        else:
            for err in raw.errors + db.errors + dash.errors:
                logger.info(f" {err}")
            for issue in issues:
                logger.info(f"{issue}")
            if not issues:
                logger.info(" No data consistency issues")

        return len(issues) == 0 and not any([raw.errors, db.errors, dash.errors]) and not real_panel_issues

    def print_compact_report(
        self,
        raw: PipelineMetrics,
        db: PipelineMetrics,
        dash: PipelineMetrics,
        issues: List[str],
        scan_logger=None,
    ):
        """
        Print compact audit report suitable for scan log.

        v4.6.4: Added for integration with scan completion flow.
        Shows key metrics in a condensed format that complements the RESULTS table.

        Args:
            scan_logger: Optional ReachableLogger instance for consistent formatting with timestamps
        """

        # Use logger if provided, otherwise fall back to print
        def output(msg):
            if scan_logger:
                scan_logger._write(msg)
            else:
                logger.info(str(msg))

        output("")
        output(" DATA INTEGRITY CHECK")
        output("─" * 68)

        # Quick summary
        db_total = db.total_findings()
        db.total_reachable()
        db.total_unreachable()
        dash_total = dash.total_findings()
        raw_total = raw.total_findings()

        # Check if dashboard was skipped
        dash_skipped = any("skipped" in e.lower() for e in dash.errors)

        # Check for issues (excluding dashboard-skipped errors)
        real_errors = raw.errors + db.errors
        if not dash_skipped:
            real_errors += dash.errors
        # P2.55 FIX: Also check raw vs db totals directly. compare_stages
        # only flags per-type mismatches where both are >0. This catches
        # the case where totals disagree even if per-type checks pass.
        totals_match = (raw_total == db_total) and (dash_skipped or db_total == dash_total)
        has_issues = len(issues) > 0 or any(real_errors) or not totals_match

        # Pipeline flow check
        if dash_skipped:
            output(f"  Pipeline: Raw({raw_total}) → DB({db_total}) → Dashboard(skipped)")
        else:
            output(f"  Pipeline: Raw({raw_total}) → DB({db_total}) → Dashboard({dash_total})")

        if not has_issues:
            if dash_skipped:
                output("   Raw → DB consistent (dashboard skipped)")
            else:
                output("   All stages consistent - no data loss detected")
        else:
            output("    Discrepancies detected:")
            # Show errors first (but not dashboard-skipped)
            for err in real_errors[:2]:
                output(f"      {err}")
            # Show comparison issues
            for issue in issues[:2]:
                output(f"     {issue}")
            # P2.55: Show total mismatch if not already covered by per-type issues
            if not totals_match and not issues:
                if raw_total != db_total:
                    output(f"       Total mismatch: Raw({raw_total}) ≠ DB({db_total})")
                if not dash_skipped and db_total != dash_total:
                    output(f"       Total mismatch: DB({db_total}) ≠ Dashboard({dash_total})")
            remaining = len(issues) + len(real_errors) - 4
            if remaining > 0:
                output("     Run 'reachctl audit' for full report")

        # Severity distribution (valuable info not in RESULTS table)
        output("")
        output("  Severity (all signals):")
        sev_parts = []
        for sev, icon in [("CRITICAL", ""), ("HIGH", ""), ("MEDIUM", ""), ("LOW", "")]:
            count = db.severity.get(sev, 0)
            if count > 0:
                sev_parts.append(f"{icon} {count} {sev.lower()}")
        if sev_parts:
            output(f"     {' | '.join(sev_parts)}")
        else:
            output("     No findings")

        # Reachable-only severity
        db_rsbt = getattr(db, "reachable_severity_by_type", {})
        if db_rsbt:
            reach_totals = {}
            for ftype_data in db_rsbt.values():
                for sev, count in ftype_data.items():
                    reach_totals[sev] = reach_totals.get(sev, 0) + count
            if reach_totals:
                output("  Severity (reachable only):")
                reach_parts = []
                for sev, icon in [("CRITICAL", ""), ("HIGH", ""), ("MEDIUM", ""), ("LOW", "")]:
                    count = reach_totals.get(sev, 0)
                    if count > 0:
                        reach_parts.append(f"{icon} {count} {sev.lower()}")
                if reach_parts:
                    output(f"     {' | '.join(reach_parts)}")

        output("─" * 68)


def find_latest_scan() -> Optional[Path]:
    """Find most recent scan by modification time."""
    scans_dir = Path.home() / ".reachable" / "scans"

    if not scans_dir.exists():
        return None

    latest_scan = None
    latest_time = 0

    for repo_dir in scans_dir.iterdir():
        if not repo_dir.is_dir():
            continue
        for branch_dir in repo_dir.iterdir():
            if not branch_dir.is_dir():
                continue
            # Check all scan directories, not just 'latest' symlink
            for scan_dir in branch_dir.iterdir():
                if not scan_dir.is_dir():
                    continue
                if scan_dir.name == "latest":
                    continue
                # Check for dashboard as indicator of completed scan
                if (scan_dir / "dashboard" / "index.html").exists():
                    mtime = scan_dir.stat().st_mtime
                    if mtime > latest_time:
                        latest_time = mtime
                        latest_scan = scan_dir

    return latest_scan


def run_audit(scan_path: Path, compact: bool = False, no_dashboard: bool = False, scan_logger=None) -> dict:
    """
    Run comprehensive audit and return results.

    v4.6.4: Added for integration with scan completion flow.

    Structure expected:
        ~/.reachable/scans/{repo-hash}/{branch}/{timestamp}/
        ~/.reachable/scans/{repo-hash}/repo.db  (shared per-repo database)

    Args:
        scan_path: Path to scan directory (the timestamp dir)
        compact: If True, print compact format suitable for scan log
        no_dashboard: If True, dashboard was skipped (--no-dashboard flag)
        scan_logger: Optional ReachableLogger instance for consistent output with timestamps

    Returns:
        Dict with audit results:
        - passed: bool - True if all checks passed
        - raw: PipelineMetrics - Raw JSON audit results
        - db: PipelineMetrics - Database audit results
        - dash: PipelineMetrics - Dashboard audit results
        - issues: List[str] - List of detected issues
        - skipped: bool - True if audit was skipped
        - warnings: List[str] - Non-fatal warnings
    """
    scan_path = Path(scan_path).expanduser().resolve()
    warnings = []

    if not scan_path.exists():
        return {"passed": False, "error": f"Scan directory not found: {scan_path}"}

    # Extract branch from path: scan_path.parent is the branch dir
    branch_dir = scan_path.parent
    branch_name = branch_dir.name
    repo_dir = branch_dir.parent

    # Check for repo.db at repo level
    repo_db = repo_dir / "repo.db"
    if not repo_db.exists():
        if compact:
            # Use logger if provided for consistent timestamps
            def out(msg):
                if scan_logger:
                    scan_logger._write(msg)
                else:
                    logger.info(str(msg))

            out("")
            out(" DATA INTEGRITY CHECK")
            out("─" * 68)
            out("    Skipped: No database (--no-db mode or first scan)")
            out("─" * 68)
        return {"passed": True, "skipped": True, "reason": "No database (repo.db not found)"}

    # Check for dashboard (may have been skipped with --no-dashboard)
    dashboard_dir = scan_path / "dashboard"
    if no_dashboard or not dashboard_dir.exists():
        warnings.append("Dashboard not generated (--no-dashboard)")

    try:
        auditor = ComprehensiveAuditor(scan_path)

        raw = auditor.audit_raw()
        db = auditor.audit_database()

        # Check if we found a matching scan record
        if db.total_findings() == 0 and "No data for this scan" in str(db.errors):
            # No scan record found for this specific run
            if compact:
                # Use logger if provided for consistent timestamps
                def out(msg):
                    if scan_logger:
                        scan_logger._write(msg)
                    else:
                        logger.info(str(msg))

                out("")
                out(" DATA INTEGRITY CHECK")
                out("─" * 68)
                out(f"    No data in DB for this scan (branch: {branch_name})")
                out("     Scan may not have completed or DB was trimmed")
                out("─" * 68)
            return {
                "passed": False,
                "skipped": True,
                "reason": "No scan record in database for this run",
                "warnings": warnings,
            }

        # Handle missing dashboard gracefully
        if no_dashboard or not dashboard_dir.exists():
            dash = PipelineMetrics("DASHBOARD")
            dash.errors.append("Dashboard skipped (--no-dashboard)")
        else:
            dash = auditor.audit_dashboard()

        issues = auditor.compare_stages(raw, db, dash)

        # Don't flag dashboard issues if dashboard was intentionally skipped
        if no_dashboard or not dashboard_dir.exists():
            issues = [i for i in issues if "dashboard" not in i.lower() and "P2.44" not in i]

        if compact:
            auditor.print_compact_report(raw, db, dash, issues, scan_logger=scan_logger)

        passed = len(issues) == 0 and not any([raw.errors, db.errors])
        # Don't fail on dashboard errors if dashboard was skipped
        if not no_dashboard and dashboard_dir.exists():
            passed = passed and not dash.errors

        return {
            "passed": passed,
            "raw": raw,
            "db": db,
            "dash": dash,
            "issues": issues,
            "warnings": warnings,
        }
    except Exception as e:
        return {"passed": False, "error": str(e)}


def main():
    """Run comprehensive audit."""
    import argparse

    parser = argparse.ArgumentParser(description="REACHABLE Data Quality Audit")
    parser.add_argument(
        "scan_path",
        type=Path,
        nargs="?",
        help="Scan directory to audit (e.g., ~/.reachable/scans/repo/branch/20260130-123456-abc123)",
    )
    parser.add_argument(
        "--scan-path", "-p", type=Path, dest="scan_path_opt", help="Scan directory (alternative syntax)"
    )
    args = parser.parse_args()

    # Support both positional and --scan-path
    scan_path = args.scan_path or args.scan_path_opt

    if not scan_path:
        scan_path = find_latest_scan()
        if not scan_path:
            logger.info("Error: No scans found. Run a scan first or specify scan path.")
            logger.info("Usage: reachctl audit [SCAN_PATH]")
            logger.info("       reachctl audit --scan-path PATH")
            sys.exit(1)

    # Expand ~ and resolve
    scan_path = Path(scan_path).expanduser().resolve()

    if not scan_path.exists():
        logger.info(f"Error: Scan directory not found: {scan_path}")
        sys.exit(1)

    # Verify it looks like a scan directory
    if not (scan_path / "dashboard").exists() and not (scan_path / "reachable-report.json.gz").exists():
        logger.info(f"Error: {scan_path} doesn't appear to be a valid scan directory")
        logger.info("Expected to find 'dashboard/' or 'reachable-report.json.gz'")
        sys.exit(1)

    # Run audit
    auditor = ComprehensiveAuditor(scan_path)

    raw = auditor.audit_raw()
    db = auditor.audit_database()
    dash = auditor.audit_dashboard()

    issues = auditor.compare_stages(raw, db, dash)

    passed = auditor.print_report(raw, db, dash, issues)

    sys.exit(0 if passed else 1)


if __name__ == "__main__":
    main()
