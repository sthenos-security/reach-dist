#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.
# STATUS: dev-tool — Import/dependency inspector and project discovery.

"""
A. The Inspector (Discovery Module)
Finds directories and returns ProjectUnit objects.

SINGLE RESPONSIBILITY: Discovery only, no execution logic.
"""

import json
import logging
import os
from dataclasses import asdict, dataclass, field
from typing import Dict, List

# Initialize module-level logger
logger = logging.getLogger(__name__)


@dataclass
class LanguageScanTarget:
    """One language within a project that needs scanning."""

    language: str
    anchor_file: str
    is_hermetic: bool = False
    metadata: Dict = field(default_factory=dict)


@dataclass
class ProjectUnit:
    """
    Ownership boundary (what a team maintains).

    Example:
      Project: /services/user-api
        ├── Python (requirements.txt)
        └── React (package.json)
    """

    project_id: str  # Unique ID (e.g., "user-api-python")
    project_name: str  # Human name (e.g., "user-api")
    language: str  # Language for THIS scan unit
    mount_point: str  # Absolute path
    relative_path: str  # Relative to monorepo root
    anchor_file: str  # Manifest file
    is_hermetic: bool = False  # Bazel/hermetic build
    context: Dict = field(default_factory=dict)  # Framework, manager, etc.

    def to_dict(self):
        """Convert to dictionary for JSON serialization."""
        return asdict(self)


class Inspector:
    """
    Discovery engine - finds projects in a monorepo.

    Usage:
        inspector = Inspector()
        projects = inspector.discover("/path/to/monorepo")
    """

    # Manifest files that indicate a project
    ANCHORS = {
        # Python
        "requirements.txt": "python",
        "pyproject.toml": "python",
        "setup.py": "python",
        "Pipfile": "python",
        # JavaScript/TypeScript
        "package.json": "js_ts",
        # Go
        "go.mod": "go",
        # Rust
        "Cargo.toml": "rust",
        # Java
        "pom.xml": "java",
        "build.gradle": "java",
        # Build systems
        "BUILD.bazel": "bazel",
        "CMakeLists.txt": "cpp_cmake",
        "Makefile": "makefile",
    }

    # Directories to skip (performance optimization)
    IGNORE_LIST = {
        ".git",
        "node_modules",
        "venv",
        ".venv",
        "target",
        "dist",
        ".next",
        "build",
        "__pycache__",
        "vendor",
        ".idea",
        ".vscode",
        "bin",
        "obj",
    }

    def discover(self, root_path: str) -> List[ProjectUnit]:
        """
        Discover all scannable projects in the monorepo.

        Returns a FLAT list of ProjectUnit objects.
        Each ProjectUnit = ONE scan job (project + language).

        Example:
          /services/user-api with Python + React
          Returns:
            - ProjectUnit(id="user-api-python", language="python", ...)
            - ProjectUnit(id="user-api-js_ts", language="js_ts", ...)
        """
        root_path = os.path.abspath(root_path)
        scan_units = []

        for root, dirs, files in os.walk(root_path):
            # Prune search tree in-place
            dirs[:] = [d for d in dirs if d not in self.IGNORE_LIST]

            # Find anchor files
            found_anchors = set(files) & set(self.ANCHORS.keys())

            if not found_anchors:
                continue

            # Get project name from directory
            project_name = os.path.basename(root)
            rel_path = os.path.relpath(root, root_path)

            # Process each language found in this directory
            for anchor in found_anchors:
                lang_type = self.ANCHORS[anchor]

                # Create unique project ID
                project_id = f"{project_name}-{lang_type}"

                # Detect context (framework, package manager, etc.)
                context = self._detect_context(root, files, lang_type)

                # Check if hermetic build
                is_hermetic = lang_type == "bazel"

                # Create scan unit
                unit = ProjectUnit(
                    project_id=project_id,
                    project_name=project_name,
                    language=lang_type,
                    mount_point=root,
                    relative_path=rel_path,
                    anchor_file=anchor,
                    is_hermetic=is_hermetic,
                    context=context,
                )

                scan_units.append(unit)

        return scan_units

    def _detect_context(self, root: str, files: List[str], lang: str) -> Dict:
        """Detect framework, package manager, and other metadata."""
        context = {}

        if lang == "js_ts":
            # Detect package manager
            if "pnpm-lock.yaml" in files:
                context["manager"] = "pnpm"
            elif "yarn.lock" in files:
                context["manager"] = "yarn"
            else:
                context["manager"] = "npm"

            # Detect TypeScript
            context["is_ts"] = "tsconfig.json" in files

            # Detect framework from package.json
            pkg_path = os.path.join(root, "package.json")
            if os.path.exists(pkg_path):
                try:
                    with open(pkg_path) as f:
                        data = json.load(f)
                        deps = {**data.get("dependencies", {}), **data.get("devDependencies", {})}

                        if "next" in deps:
                            context["framework"] = "Next.js"
                        elif "react" in deps:
                            context["framework"] = "React"
                        elif "vue" in deps:
                            context["framework"] = "Vue"
                        elif "angular" in deps:
                            context["framework"] = "Angular"
                        else:
                            context["framework"] = "Node.js"
                except Exception:
                    context["framework"] = "Unknown"

        elif lang == "python":
            # Detect package manager
            if "poetry.lock" in files or "pyproject.toml" in files:
                context["manager"] = "poetry"
            elif "Pipfile" in files:
                context["manager"] = "pipenv"
            else:
                context["manager"] = "pip"

            # Detect framework from requirements.txt
            req_path = os.path.join(root, "requirements.txt")
            if os.path.exists(req_path):
                try:
                    with open(req_path) as f:
                        content = f.read().lower()
                        if "django" in content:
                            context["framework"] = "Django"
                        elif "flask" in content:
                            context["framework"] = "Flask"
                        elif "fastapi" in content:
                            context["framework"] = "FastAPI"
                except Exception:
                    pass

        return context


# Standalone CLI
if __name__ == "__main__":
    import sys

    root = sys.argv[1] if len(sys.argv) > 1 else "."

    inspector = Inspector()
    projects = inspector.discover(root)

    logger.info(f"Discovered {len(projects)} scan units:")
    for p in projects:
        logger.info(f" [{p.project_id}] {p.mount_point} ({p.language})")
