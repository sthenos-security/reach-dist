# STATUS: investigate-superseded — Finding fingerprint generators. Check if dedup uses this.
"""REACHABLE v1.0 - Fingerprint Generators"""

import hashlib
from typing import Dict, List, Optional, Tuple


def generate_secret_fingerprint(
    secret_type: str,
    file_path: str,
    context_lines: List[str],
    detector_id: str,
    match_start_offset: Optional[int] = None,
    key_name: Optional[str] = None,
    column_offset: Optional[int] = None,
) -> Tuple[str, Dict]:
    normalized_context = "\n".join(line.rstrip() for line in context_lines).replace("\r\n", "\n").strip().lower()
    context_hash = hashlib.sha256(normalized_context.encode("utf-8")).hexdigest()[:8]
    base_key = f"SECRET:v1:{secret_type}:{file_path}:{context_hash}:{detector_id}"
    anchor = (
        f"offset={match_start_offset}"
        if match_start_offset is not None
        else (f"key={key_name}" if key_name else (f"col={column_offset}" if column_offset is not None else None))
    )
    full_key = base_key + (f":{anchor}" if anchor else "")
    finding_id = hashlib.sha256(full_key.encode("utf-8")).hexdigest()[:16]
    return finding_id, {
        "fingerprint_version": "v1",
        "fingerprint_base_key": base_key,
        "fingerprint_full_key": full_key,
        "fingerprint_anchor_used": anchor,
        "match_start_offset": match_start_offset,
        "offset_unit": "byte" if match_start_offset else None,
        "offset_encoding": "utf-8" if match_start_offset else None,
        "key_name": key_name,
        "column_offset": column_offset,
    }


def generate_cwe_fingerprint(
    cwe_id: str,
    file_path: str,
    function_name: str,
    sink_signature: str,
    sink_span_offset: Optional[int] = None,
    source_signature: Optional[str] = None,
) -> Tuple[str, Dict]:
    base_key = f"CWE:v1:{cwe_id}:{file_path}:{function_name}:{sink_signature}"
    anchor = (
        f"offset={sink_span_offset}"
        if sink_span_offset is not None
        else (f"src={hashlib.sha256(source_signature.encode('utf-8')).hexdigest()[:8]}" if source_signature else None)
    )
    full_key = base_key + (f":{anchor}" if anchor else "")
    finding_id = hashlib.sha256(full_key.encode("utf-8")).hexdigest()[:16]
    return finding_id, {
        "fingerprint_version": "v1",
        "fingerprint_base_key": base_key,
        "fingerprint_full_key": full_key,
        "fingerprint_anchor_used": anchor,
        "sink_span_offset": sink_span_offset,
        "offset_unit": "byte" if sink_span_offset else None,
        "offset_encoding": "utf-8" if sink_span_offset else None,
        "source_signature": source_signature,
    }


def generate_sca_fingerprint(
    ecosystem: str,
    package_name: str,
    package_version: str,
    advisory_id: str,
    dependency_path: str,
    package_purl: Optional[str] = None,
    advisory_sources: Optional[List[str]] = None,
) -> Tuple[str, Dict]:
    base_key = f"SCA:v1:{ecosystem}:{package_name}:{package_version}:{advisory_id}:{dependency_path}"
    anchor = f"purl={hashlib.sha256(package_purl.encode('utf-8')).hexdigest()[:8]}" if package_purl else None
    full_key = base_key + (f":{anchor}" if anchor else "")
    finding_id = hashlib.sha256(full_key.encode("utf-8")).hexdigest()[:16]
    return finding_id, {
        "fingerprint_version": "v1",
        "fingerprint_base_key": base_key,
        "fingerprint_full_key": full_key,
        "fingerprint_anchor_used": anchor,
        "package_purl": package_purl,
        "vuln_id": advisory_id,
        "sources": advisory_sources or [],
    }


def generate_dlp_fingerprint(
    data_type: str,
    file_path: str,
    match_window: str,
    detector_id: str,
    match_start_offset: Optional[int] = None,
    match_length: Optional[int] = None,
) -> Tuple[str, Dict]:
    normalized_window = (
        "\n".join(line.rstrip() for line in match_window.split("\n")).replace("\r\n", "\n").strip().lower()
    )
    window_hash = hashlib.sha256(normalized_window.encode("utf-8")).hexdigest()[:8]
    base_key = f"DLP:v1:{data_type}:{file_path}:{window_hash}:{detector_id}"
    anchor = (
        f"offset={match_start_offset}"
        if match_start_offset is not None
        else (f"len={match_length}" if match_length is not None else None)
    )
    full_key = base_key + (f":{anchor}" if anchor else "")
    finding_id = hashlib.sha256(full_key.encode("utf-8")).hexdigest()[:16]
    return finding_id, {
        "fingerprint_version": "v1",
        "fingerprint_base_key": base_key,
        "fingerprint_full_key": full_key,
        "fingerprint_anchor_used": anchor,
        "match_start_offset": match_start_offset,
        "offset_unit": "byte" if match_start_offset else None,
        "offset_encoding": "utf-8" if match_start_offset else None,
        "match_length": match_length,
    }


def generate_ai_fingerprint(
    rule_id: str,
    file_path: str,
    function_name: str,
    pattern_signature: str,
    pattern_span_offset: Optional[int] = None,
    sink_call_name: Optional[str] = None,
) -> Tuple[str, Dict]:
    base_key = f"AI:v1:{rule_id}:{file_path}:{function_name}:{pattern_signature}"
    anchor = (
        f"offset={pattern_span_offset}"
        if pattern_span_offset is not None
        else (f"sink={sink_call_name}" if sink_call_name else None)
    )
    full_key = base_key + (f":{anchor}" if anchor else "")
    finding_id = hashlib.sha256(full_key.encode("utf-8")).hexdigest()[:16]
    return finding_id, {
        "fingerprint_version": "v1",
        "fingerprint_base_key": base_key,
        "fingerprint_full_key": full_key,
        "fingerprint_anchor_used": anchor,
        "pattern_span_offset": pattern_span_offset,
        "offset_unit": "byte" if pattern_span_offset else None,
        "offset_encoding": "utf-8" if pattern_span_offset else None,
        "sink_call_name": sink_call_name,
    }


def generate_config_fingerprint(
    rule_id: str,
    file_path: str,
    config_path: str,
    object_selector: Optional[str] = None,
    resource_kind: Optional[str] = None,
) -> Tuple[str, Dict]:
    base_key = f"CONFIG:v1:{rule_id}:{file_path}:{config_path}"
    anchor = f"obj={object_selector}" if object_selector else (f"kind={resource_kind}" if resource_kind else None)
    full_key = base_key + (f":{anchor}" if anchor else "")
    finding_id = hashlib.sha256(full_key.encode("utf-8")).hexdigest()[:16]
    return finding_id, {
        "fingerprint_version": "v1",
        "fingerprint_base_key": base_key,
        "fingerprint_full_key": full_key,
        "fingerprint_anchor_used": anchor,
        "object_selector": object_selector,
        "resource_kind": resource_kind,
    }


def generate_malware_fingerprint(
    malware_family: str, file_path: str, file_hash: str, inner_path: Optional[str] = None
) -> Tuple[str, Dict]:
    base_key = f"MALWARE:v1:{malware_family}:{file_path}:{file_hash}"
    anchor = f"inner={hashlib.sha256(inner_path.encode('utf-8')).hexdigest()[:8]}" if inner_path else None
    full_key = base_key + (f":{anchor}" if anchor else "")
    finding_id = hashlib.sha256(full_key.encode("utf-8")).hexdigest()[:16]
    return finding_id, {
        "fingerprint_version": "v1",
        "fingerprint_base_key": base_key,
        "fingerprint_full_key": full_key,
        "fingerprint_anchor_used": anchor,
        "inner_path": inner_path,
    }
