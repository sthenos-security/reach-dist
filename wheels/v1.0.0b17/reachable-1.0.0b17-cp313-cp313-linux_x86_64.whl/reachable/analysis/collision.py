"""
REACHABLE v1.0 - Collision Detection Module (Production Hardened)
==================================================================

Production-grade collision detector with defensive coding:
- Guards against malformed input (missing id, bad JSON, wrong types)
- Graceful degradation (logs but doesn't crash)
- No silent mis-tracking (validates all assumptions)
- Clear error messages for debugging
"""

from __future__ import annotations

import hashlib
import json
import logging
from typing import Any, Dict, Set

logger = logging.getLogger(__name__)


class CollisionDetector:
    """
    Detects and resolves finding_id collisions within a scan.

    Key behavior:
    - ALWAYS tracks by base_key (for stable occurrence counts)
    - Uses set for seen_ids (faster lookup)
    - Caps resolution at exactly 50 attempts
    - Keeps raw_data as dict (prevents double-encoding)
    - Gracefully handles malformed input (logs but doesn't crash)

    Attributes:
        seen_ids: Set of finding_ids encountered so far
        base_key_counts: Occurrence count per fingerprint_base_key
        stats: Collision statistics (total, unique, collisions, resolved, unresolved)
    """

    def __init__(self) -> None:
        self.seen_ids: Set[str] = set()
        self.base_key_counts: Dict[str, int] = {}
        self.collision_group_cache: Dict[str, str] = {}  # base_key -> collision_group (cached)
        self.stats: Dict[str, int] = {
            "total": 0,
            "unique": 0,
            "collisions": 0,
            "resolved": 0,
            "unresolved": 0,
        }

    def _normalize_metadata(self, raw: Any) -> Dict[str, Any]:
        """
        Ensure raw_data is a dict.

        - dict => returned as-is
        - str => json.loads(str) if possible, else {}
        - anything else => {}

        Args:
            raw: raw_data field from finding (can be any type)

        Returns:
            Dictionary (guaranteed), empty if unable to normalize
        """
        if isinstance(raw, dict):
            return raw

        if isinstance(raw, str):
            try:
                decoded = json.loads(raw)
                return decoded if isinstance(decoded, dict) else {}
            except Exception as e:
                logger.warning("raw_data JSON decode failed: %s (treating as empty dict)", str(e)[:100])
                return {}

        # Not dict or str - unexpected type
        if raw is not None:
            logger.warning("raw_data unexpected type: %s (treating as empty dict)", type(raw).__name__)
        return {}

    def _get_collision_group(self, base_key: str) -> str:
        """
        Get collision_group hash for a base_key (cached).

        Args:
            base_key: Fingerprint base key

        Returns:
            16-char hex hash of base_key
        """
        if base_key not in self.collision_group_cache:
            self.collision_group_cache[base_key] = hashlib.sha256(base_key.encode("utf-8")).hexdigest()[:16]
        return self.collision_group_cache[base_key]

    def check_and_resolve(self, finding: Dict[str, Any]) -> Dict[str, Any]:
        """
        Check for collision and resolve if found.

        Defensive against:
        - Missing or invalid finding_id
        - Bad raw_data (wrong type, invalid JSON)
        - Missing base_key
        - Malformed metadata

        Args:
            finding: Dict with 'id' (finding_id) and raw_data

        Returns:
            Updated finding dict with collision resolved (if needed)

        Raises:
            None - all failures are logged but not raised
        """
        self.stats["total"] += 1

        #  Guard: finding_id must exist and be a non-empty string
        finding_id = finding.get("id")
        if not isinstance(finding_id, str) or not finding_id:
            logger.warning(
                "Finding missing or invalid 'id' field (type=%s), skipping collision detection",
                type(finding_id).__name__,
            )
            return finding

        #  Guard: normalize raw_data to dict (handles JSON decode failures)
        metadata = self._normalize_metadata(finding.get("raw_data") or {})

        #  Guard: base_key must exist and be a non-empty string
        base_key = metadata.get("fingerprint_base_key")
        if not isinstance(base_key, str) or not base_key:
            # No base_key means we can't track or group - pass through
            finding["raw_data"] = metadata
            return finding

        #  ALWAYS track occurrence count by base_key (even if no collision)
        self.base_key_counts[base_key] = self.base_key_counts.get(base_key, 0) + 1

        if finding_id not in self.seen_ids:
            # No collision
            self.seen_ids.add(finding_id)
            self.stats["unique"] += 1
            finding["raw_data"] = metadata
            return finding

        # COLLISION DETECTED!
        self.stats["collisions"] += 1

        # Extract namespace from base_key for logging
        namespace = base_key.split(":", 1)[0] if ":" in base_key else "UNKNOWN"

        logger.warning(
            "COLLISION: %s finding_id=%s... base_key=%s...",
            namespace,
            finding_id[:8],
            base_key[:50],
        )

        # Resolve with idx, loop until unique (exactly 50 attempts)
        #  idx starts at current occurrence count (already incremented above)
        # First collision: idx = 2 (if first instance had no idx)
        # This matches spec: "idx starts at current occurrence count"
        start = self.base_key_counts[base_key]

        for extra in range(0, 50):
            idx = start + extra
            new_full_key = f"{base_key}:idx={idx}"
            new_id = hashlib.sha256(new_full_key.encode("utf-8")).hexdigest()[:16]

            if new_id not in self.seen_ids:
                self.seen_ids.add(new_id)
                self.stats["resolved"] += 1

                # Update finding with resolved collision
                finding["id"] = new_id
                metadata["fingerprint_full_key"] = new_full_key
                metadata["fingerprint_anchor_used"] = f"idx={idx}"
                metadata["collision_resolved"] = True
                metadata["collision_group"] = self._get_collision_group(base_key)
                metadata["original_finding_id"] = finding_id
                finding["raw_data"] = metadata

                logger.info("Resolved collision with idx=%s", idx)
                return finding

        # Failed to resolve after 50 attempts
        self.stats["unresolved"] += 1
        logger.error("Failed to resolve collision for %s after 50 attempts! base_key=%s", finding_id, base_key[:50])
        finding["raw_data"] = metadata
        return finding

    def log_stats(self, finding_type: str) -> None:
        """
        Log collision statistics for monitoring.

        Args:
            finding_type: Type of findings being stored (for logging context)
        """
        logger.info(
            " COLLISION STATS [%s]: total=%s unique=%s collisions=%s resolved=%s unresolved=%s",
            finding_type,
            self.stats["total"],
            self.stats["unique"],
            self.stats["collisions"],
            self.stats["resolved"],
            self.stats["unresolved"],
        )

        if self.stats["unresolved"] > 0:
            logger.error(
                "  %s UNRESOLVED COLLISIONS for %s!",
                self.stats["unresolved"],
                finding_type,
            )
