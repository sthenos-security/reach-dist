# Copyright © 2026 Sthenos Security. All rights reserved.

"""
REACHABLE License Validation

Python wrapper for the C license extension.
Falls back to pure Python if C extension unavailable.
"""

import json
import logging
import sys
from datetime import datetime
from pathlib import Path

# Initialize module-level logger
logger = logging.getLogger(__name__)
_safe_logger = logger  # Alias for backwards compatibility

# Evaluation period
EVAL_DAYS = 30


# Windows-safe print (no emojis on Windows)
def _safe_print(msg: str):
    """Print with fallback for Windows encoding issues."""
    try:
        logger.info(str(msg))
    except UnicodeEncodeError:
        # Strip emojis for Windows
        import re

        clean = re.sub(r"[\U00010000-\U0010ffff]", "", msg)
        clean = clean.replace("", "[!]").replace("", "").replace("", "")
        logger.info(str(clean))


# Try to import C extension
_c_license = None
try:
    from reachable import _license as _c_license

    # Verify it has the expected API
    if not hasattr(_c_license, "check"):
        _c_license = None
except ImportError:
    pass


def _get_license_path() -> Path:
    """Get path to license file"""
    home = Path.home()
    return home / ".reachable" / ".lic"


def _pure_python_validate() -> dict:
    """
    Pure Python fallback for license validation.
    Less secure but functional when C extension unavailable.
    """
    license_path = _get_license_path()

    # First run - create license
    if not license_path.exists():
        license_path.parent.mkdir(parents=True, exist_ok=True)
        data = {
            "install_time": datetime.now().isoformat(),
            "version": "1",
        }
        # Simple obfuscation
        content = json.dumps(data).encode()
        obfuscated = bytes([b ^ 0x5A for b in content])
        try:
            license_path.write_bytes(obfuscated)
        except Exception:
            pass  # Can't write, allow anyway

        return {
            "valid": True,
            "days_remaining": EVAL_DAYS,
            "days_used": 0,
            "eval_period": EVAL_DAYS,
            "message": f"Evaluation started: {EVAL_DAYS} days remaining",
            "expired": False,
            "first_run": True,
        }

    # Read existing license
    try:
        obfuscated = license_path.read_bytes()
        content = bytes([b ^ 0x5A for b in obfuscated])
        data = json.loads(content.decode())

        install_time = datetime.fromisoformat(data["install_time"])
        now = datetime.now()

        days_used = (now - install_time).days
        days_remaining = EVAL_DAYS - days_used

        if days_remaining > 0:
            if days_remaining <= 7:
                msg = f"  Evaluation expiring soon: {days_remaining} days remaining"
            else:
                msg = f"Evaluation: {days_remaining} days remaining"

            return {
                "valid": True,
                "days_remaining": days_remaining,
                "days_used": days_used,
                "eval_period": EVAL_DAYS,
                "message": msg,
                "expired": False,
                "first_run": False,
            }
        else:
            return {
                "valid": False,
                "days_remaining": 0,
                "days_used": days_used,
                "eval_period": EVAL_DAYS,
                "message": " Evaluation period expired. Contact info@sthenosec.com for a license.",
                "expired": True,
                "first_run": False,
            }

    except Exception:
        # Corrupted license - reset
        try:
            license_path.unlink(missing_ok=True)
        except Exception:
            pass
        return _pure_python_validate()


def validate_license() -> dict:
    """
    Validate the evaluation license.

    Returns:
        dict with keys:
            valid: bool - True if within evaluation period
            days_remaining: int - Days left in evaluation
            days_used: int - Days since installation
            eval_period: int - Total evaluation period (30)
            message: str - Human readable status
            expired: bool - True if evaluation expired
    """
    if _c_license:
        try:
            # C module uses check() and returns different format
            result = _c_license.check()
            # Convert to our standard format
            days_remaining = result.get("days_remaining", 0)
            is_grace = result.get("is_grace", False)
            eval_days = result.get("eval_days", EVAL_DAYS)

            days_used = eval_days - days_remaining

            if is_grace:
                msg = f"  Grace period: {days_remaining} days remaining"
            elif days_remaining <= 7:
                msg = f"  Evaluation expiring soon: {days_remaining} days remaining"
            else:
                msg = f"Evaluation: {days_remaining} days remaining"

            return {
                "valid": True,
                "days_remaining": days_remaining,
                "days_used": days_used,
                "eval_period": eval_days,
                "message": msg,
                "expired": False,
                "first_run": False,
                "is_grace": is_grace,
            }
        except RuntimeError as e:
            # C module raises RuntimeError on expiration
            return {
                "valid": False,
                "days_remaining": 0,
                "days_used": EVAL_DAYS,
                "eval_period": EVAL_DAYS,
                "message": str(e),
                "expired": True,
                "first_run": False,
            }
        except Exception:
            # Fall back to Python
            pass

    return _pure_python_validate()


def get_license_info() -> dict:
    """Get raw license information for debugging"""
    if _c_license:
        try:
            info = _c_license.get_info()
            if info:
                info["license_path"] = str(_get_license_path())
            return info
        except Exception:
            pass

    license_path = _get_license_path()
    if not license_path.exists():
        return None

    try:
        obfuscated = license_path.read_bytes()
        content = bytes([b ^ 0x5A for b in obfuscated])
        data = json.loads(content.decode())
        data["license_path"] = str(license_path)
        return data
    except Exception:
        return None


def check_license_or_exit(quiet: bool = False) -> dict:
    """
    Check license and exit if expired.

    Called at CLI entry point.
    """
    result = validate_license()

    # Always show first run message
    if result.get("first_run") and not quiet:
        _safe_logger.info(f" {result['message']}")
        _safe_logger.info("For licensing information: info@sthenosec.com")

    # Show warning if expiring soon
    elif result.get("days_remaining", 0) <= 7 and result["valid"] and not quiet:
        _safe_logger.warning(result["message"])

    # Exit if expired
    if result.get("expired"):
        _safe_logger.error("REACHABLE - Evaluation Expired")
        _safe_logger.error(result["message"])
        _safe_logger.info("To continue using REACHABLE:")
        _safe_logger.info("  Contact info@sthenosec.com for a license")
        _safe_logger.info("  Visit https://sthenosec.com/reachable")
        sys.exit(1)

    return result


def print_license_status():
    """Print current license status (for reachctl license command)"""
    result = validate_license()
    info = get_license_info()

    _safe_logger.info("REACHABLE LICENSE STATUS")
    _safe_logger.info("─" * 40)

    if result["valid"]:
        _safe_logger.info("Status: Valid")
    else:
        _safe_logger.info("Status: Expired")

    _safe_logger.info(f"Evaluation: {result['days_used']} of {result['eval_period']} days used")
    _safe_logger.info(f"Days Remaining: {result['days_remaining']}")

    if info:
        if "install_time" in info:
            # C module format
            from datetime import datetime

            install_dt = datetime.fromtimestamp(info["install_time"])
            _safe_logger.info(f"Installed: {install_dt.strftime('%Y-%m-%d %H:%M:%S')}")
        elif "install_time" in info:
            # Python format
            _safe_logger.info(f"Installed: {info.get('install_time', 'Unknown')}")
        _safe_logger.info(f"License File: {info.get('license_path', 'Unknown')}")

    _safe_logger.info("")

    if result["expired"]:
        _safe_logger.info("To renew: Contact info@sthenosec.com")
    elif result["days_remaining"] <= 7:
        _safe_logger.info("  License expiring soon!")
        _safe_logger.info("   Contact info@sthenosec.com to continue using REACHABLE")


if __name__ == "__main__":
    print_license_status()
