#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.
"""
REACHABLE Hop Classification Registry (HCR)
============================================

T-AI3 / T-CG7 — Typed semantic node model + per-finding-type hop rules.

This module is the single source of truth for:
  - NodeKind  — role of every hop in a call path
  - PathNode  — typed replacement for raw string hops
  - HopRule   — per-language, per-finding-type classification rules
  - REGISTRY  — ordered list of all HopRules
  - classify_hop() — lookup API used by normalizers and the AI/DLP bridge

T-AI3 ships:
  - Full NodeKind enum (from design doc § 1)
  - PathNode + HopRule dataclasses
  - LLM API sinks (OpenAI, Anthropic, LangChain, Vercel AI SDK, Cohere, Mistral)
  - PII source patterns (request body/params, DB query, env, session)
  - Go/JS/Python danger sinks and stdlib rules from design doc § 2.1
  - HCR_RULES alias (= REGISTRY) for test compatibility

T-CG7 will extend this file with the full Go stdlib/secret/boundary rules and
the classify_hop() entrypoint, language extension modules, and versioning.

Design reference: docs/engineering/design/callgraph_engine_v2.md § 1–2
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from enum import Enum
from typing import Dict, List, Optional

# ════════════════════════════════════════════════════════════════════════════
# § 1  SEMANTIC NODE MODEL
# ════════════════════════════════════════════════════════════════════════════


class NodeKind(str, Enum):
    """Role of a single hop in a call path.  Drives icon + colour in the UI."""

    ENTRY = "entry"  # HTTP handler, main(), scheduled job, CLI cmd
    APP = "app"  # Internal application function
    TRANSFORMER = "transformer"  # Parses / extracts / converts data
    SINK_VULN = "sink_vuln"  # Vulnerable package call (CVE)
    SINK_DANGER = "sink_danger"  # Dangerous operation (CWE / AI sink)
    SINK_SECRET = "sink_secret"  # Secret transmission / credential use
    SINK_DATA = "sink_data"  # PII exfiltration (DLP sink)
    SOURCE_PII = "source_pii"  # PII source (DLP / AI LLM02)
    GUARD = "guard"  # Security control that reduces risk
    STDLIB = "stdlib"  # Stdlib intermediary — display-filtered for CVE
    BOUNDARY = "boundary"  # Dynamic/OS library boundary node
    VIA = "via"  # Intermediate 3rd-party module (transitive CVE)
    LLM_OUTPUT = "llm_output"  # LLM response (source for LLM05 reverse taint)
    AGENT = "agent"  # Agentic orchestrator node (LLM06)
    MCP_SERVER = "mcp_server"  # MCP server node
    MCP_TOOL = "mcp_tool"  # Individual MCP tool registration


@dataclass
class PathNode:
    """
    Typed replacement for raw string hops.

    Wire format (JSON in DB ``call_paths_v2`` column)::

        {
            "label": "openai.chat.completions.create",
            "kind":  "sink_danger",
            "file":  "app/services/chat.py",
            "line":  42,
            "package": "openai",
            "language": "py",
            "is_boundary": false,
            "boundary_class": "",
            "taint_exits": null
        }

    Backward compatibility: existing ``call_paths`` (List[List[str]]) columns
    are unchanged.  ``call_paths_v2`` is additive (T-AI16 / T-CG10).
    """

    label: str
    kind: NodeKind
    file: str = ""
    line: Optional[int] = None
    package: str = ""
    language: str = ""
    is_boundary: bool = False
    boundary_class: str = ""
    taint_exits: Optional[bool] = None  # None = unknown
    route: str = ""  # HTTP route/endpoint (e.g. "GET /api/users") — populated for entry nodes
    http_method: str = ""  # HTTP method if known (GET, POST, etc.)

    def to_dict(self) -> dict:
        d = {
            "label": self.label,
            "kind": self.kind.value,
            "file": self.file,
            "line": self.line,
            "package": self.package,
            "language": self.language,
            "is_boundary": self.is_boundary,
            "boundary_class": self.boundary_class,
            "taint_exits": self.taint_exits,
        }
        # Only include route/http_method when set (saves DB space)
        if self.route:
            d["route"] = self.route
        if self.http_method:
            d["http_method"] = self.http_method
        return d

    @classmethod
    def from_dict(cls, d: dict) -> "PathNode":
        return cls(
            label=d.get("label", ""),
            kind=NodeKind(d.get("kind", "app")),
            file=d.get("file", ""),
            line=d.get("line"),
            package=d.get("package", ""),
            language=d.get("language", ""),
            is_boundary=d.get("is_boundary", False),
            boundary_class=d.get("boundary_class", ""),
            taint_exits=d.get("taint_exits"),
            route=d.get("route", ""),
            http_method=d.get("http_method", ""),
        )

    @classmethod
    def from_string(cls, s: str, kind: NodeKind = NodeKind.APP) -> "PathNode":
        """Upgrade a v1 string hop to a PathNode (best-effort)."""
        return cls(label=s, kind=kind)


# ════════════════════════════════════════════════════════════════════════════
# § 2  HOP CLASSIFICATION REGISTRY
# ════════════════════════════════════════════════════════════════════════════


class HopPosition(str, Enum):
    FIRST = "first"
    MIDDLE = "middle"
    LAST = "last"


@dataclass
class HopDecision:
    kind: NodeKind
    display_action: str  # 'keep' | 'strip' | 'keep_if_last'
    taint_exits: Optional[bool]
    exploitability: float


@dataclass
class HopRule:
    """
    A single entry in the Hop Classification Registry.

    Fields
    ------
    pattern         Regex applied to the fully-qualified hop name.
    kind            NodeKind assigned when this rule matches.
    display_policy  Per-finding-type display action:
                      'keep'         — always show this hop
                      'strip'        — never show (noise)
                      'keep_if_last' — show only when it is the terminal hop
                    Keys: 'CVE' | 'CWE' | 'SECRET' | 'DLP' | 'AI'
    taint_exits     True  = taint propagates through.
                    False = taint is consumed / sanitised here.
                    None  = unknown (dynamic / reflection).
    sink_for        Finding types for which this hop is a sink:
                    ['CWE'] | ['DLP'] | ['AI', 'DLP'] | etc.
    exploitability  0.0–1.0 weight for path scoring.
    keep_for        Convenience dict: {finding_type: bool} — True if display_policy
                    is 'keep' for that type.  Auto-derived from display_policy.
    """

    pattern: str
    kind: NodeKind
    display_policy: Dict[str, str]  # {finding_type: 'keep'|'strip'|'keep_if_last'}
    taint_exits: Optional[bool]
    sink_for: List[str]
    exploitability: float

    @property
    def keep_for(self) -> Dict[str, bool]:
        """Convenience: True when display_policy == 'keep' for that type."""
        return {ft: (action == "keep") for ft, action in self.display_policy.items()}

    def matches(self, label: str) -> bool:
        return bool(re.search(self.pattern, label, re.IGNORECASE))

    def decide(self, finding_type: str, position: HopPosition) -> HopDecision:
        action = self.display_policy.get(finding_type, "keep")
        if action == "keep_if_last":
            action = "keep" if position == HopPosition.LAST else "strip"
        return HopDecision(self.kind, action, self.taint_exits, self.exploitability)


# ════════════════════════════════════════════════════════════════════════════
# § 2.1  REGISTRY — AI/LLM SINKS  (T-AI3)
# ════════════════════════════════════════════════════════════════════════════
# Display policy: strip for CVE (irrelevant), keep for AI and DLP
# (LLM API calls are the finding for prompt injection, LLM02, etc.)
# taint_exits=True: user input that reaches the LLM API exits as the prompt.

_AI_KEEP = {"CVE": "strip", "CWE": "keep", "SECRET": "strip", "DLP": "keep", "AI": "keep"}
_AI_STRIP_CWE = {"CVE": "strip", "CWE": "strip", "SECRET": "strip", "DLP": "keep", "AI": "keep"}

LLM_SINK_RULES: List[HopRule] = [
    # ── OpenAI ────────────────────────────────────────────────────────────
    HopRule(
        pattern=r"openai\.chat\.completions\.create|openai\.ChatCompletion\.create",
        kind=NodeKind.SINK_DANGER,
        display_policy=_AI_KEEP,
        taint_exits=True,
        sink_for=["AI", "DLP"],
        exploitability=1.0,
    ),
    HopRule(
        pattern=r"openai\.completions\.create|openai\.Completion\.create",
        kind=NodeKind.SINK_DANGER,
        display_policy=_AI_KEEP,
        taint_exits=True,
        sink_for=["AI", "DLP"],
        exploitability=0.9,
    ),
    HopRule(
        pattern=r"openai\.embeddings\.create|openai\.Embedding\.create",
        kind=NodeKind.SINK_DATA,
        display_policy=_AI_KEEP,
        taint_exits=True,
        sink_for=["DLP"],
        exploitability=0.7,
    ),
    HopRule(
        # Python openai v1 client: client.chat.completions.create / AsyncOpenAI
        pattern=r"\.chat\.completions\.create\b",
        kind=NodeKind.SINK_DANGER,
        display_policy=_AI_KEEP,
        taint_exits=True,
        sink_for=["AI", "DLP"],
        exploitability=1.0,
    ),
    # ── Anthropic ─────────────────────────────────────────────────────────
    HopRule(
        pattern=r"anthropic\.messages\.create|anthropic\.Anthropic.*messages",
        kind=NodeKind.SINK_DANGER,
        display_policy=_AI_KEEP,
        taint_exits=True,
        sink_for=["AI", "DLP"],
        exploitability=1.0,
    ),
    HopRule(
        pattern=r"anthropic\.completions\.create",
        kind=NodeKind.SINK_DANGER,
        display_policy=_AI_KEEP,
        taint_exits=True,
        sink_for=["AI", "DLP"],
        exploitability=0.9,
    ),
    HopRule(
        # JS/TS: client.messages.create (Anthropic SDK)
        pattern=r"\.messages\.create\(",
        kind=NodeKind.SINK_DANGER,
        display_policy=_AI_KEEP,
        taint_exits=True,
        sink_for=["AI", "DLP"],
        exploitability=1.0,
    ),
    # ── LangChain ─────────────────────────────────────────────────────────
    HopRule(
        pattern=r"langchain.*\.invoke\b|langchain.*\.run\b|LLMChain.*\.run",
        kind=NodeKind.SINK_DANGER,
        display_policy=_AI_KEEP,
        taint_exits=True,
        sink_for=["AI", "DLP"],
        exploitability=0.9,
    ),
    HopRule(
        pattern=r"langchain.*\.arun\b|langchain.*\.ainvoke\b",
        kind=NodeKind.SINK_DANGER,
        display_policy=_AI_KEEP,
        taint_exits=True,
        sink_for=["AI", "DLP"],
        exploitability=0.9,
    ),
    HopRule(
        pattern=r"AgentExecutor.*\.invoke|AgentExecutor.*\.run",
        kind=NodeKind.AGENT,
        display_policy=_AI_KEEP,
        taint_exits=True,
        sink_for=["AI"],
        exploitability=1.0,
    ),
    HopRule(
        pattern=r"langchain.*vectorstore|Chroma\.|Pinecone\.|Weaviate\.|FAISS\.",
        kind=NodeKind.SINK_DATA,
        display_policy=_AI_KEEP,
        taint_exits=True,
        sink_for=["DLP"],
        exploitability=0.7,
    ),
    # ── Vercel AI SDK (JS/TS) ─────────────────────────────────────────────
    HopRule(
        pattern=r"\bgenerateText\b|\bstreamText\b|\bgenerateObject\b|\bstreamObject\b",
        kind=NodeKind.SINK_DANGER,
        display_policy=_AI_KEEP,
        taint_exits=True,
        sink_for=["AI", "DLP"],
        exploitability=0.9,
    ),
    HopRule(
        pattern=r"\bstreamUI\b|\brenderText\b",
        kind=NodeKind.SINK_DANGER,
        display_policy=_AI_KEEP,
        taint_exits=True,
        sink_for=["AI"],
        exploitability=0.8,
    ),
    # ── Google Gemini / Vertex AI ─────────────────────────────────────────
    HopRule(
        pattern=r"google\.generativeai\.GenerativeModel|genai\.GenerativeModel",
        kind=NodeKind.SINK_DANGER,
        display_policy=_AI_KEEP,
        taint_exits=True,
        sink_for=["AI", "DLP"],
        exploitability=0.9,
    ),
    HopRule(
        pattern=r"vertexai\.(init|preview)|aiplatform\.gapic",
        kind=NodeKind.SINK_DANGER,
        display_policy=_AI_KEEP,
        taint_exits=True,
        sink_for=["AI", "DLP"],
        exploitability=0.9,
    ),
    # ── Cohere ────────────────────────────────────────────────────────────
    HopRule(
        pattern=r"cohere\.(generate|chat|embed)\b|co\.(generate|chat)\(",
        kind=NodeKind.SINK_DANGER,
        display_policy=_AI_KEEP,
        taint_exits=True,
        sink_for=["AI", "DLP"],
        exploitability=0.9,
    ),
    # ── Mistral / Ollama / Hugging Face ───────────────────────────────────
    HopRule(
        pattern=r"mistralai\.|MistralClient\.|ollama\.chat\b|ollama\.generate\b",
        kind=NodeKind.SINK_DANGER,
        display_policy=_AI_KEEP,
        taint_exits=True,
        sink_for=["AI", "DLP"],
        exploitability=0.9,
    ),
    HopRule(
        pattern=r"huggingface_hub\.|HuggingFaceHub\.|pipeline\(",
        kind=NodeKind.SINK_DANGER,
        display_policy=_AI_KEEP,
        taint_exits=True,
        sink_for=["AI", "DLP"],
        exploitability=0.8,
    ),
    # ── LLM output dangerous ops — LLM05 reverse taint ───────────────────
    HopRule(
        # eval / exec of LLM-generated content
        pattern=r"\beval\(|\bexec\(|\bexecSync\(|\bvm\.runInNewContext\(",
        kind=NodeKind.SINK_DANGER,
        display_policy={"CVE": "strip", "CWE": "keep", "SECRET": "strip", "DLP": "strip", "AI": "keep"},
        taint_exits=True,
        sink_for=["CWE", "AI"],
        exploitability=1.0,
    ),
    HopRule(
        pattern=r"\bsubprocess\.run\b|\bsubprocess\.call\b|\bsubprocess\.Popen\b",
        kind=NodeKind.SINK_DANGER,
        display_policy={"CVE": "strip", "CWE": "keep", "SECRET": "strip", "DLP": "strip", "AI": "keep"},
        taint_exits=True,
        sink_for=["CWE", "AI"],
        exploitability=1.0,
    ),
    # ── MCP sinks ─────────────────────────────────────────────────────────
    HopRule(
        pattern=r"FastMCP\b|mcp\.server\.|@server\.tool\(",
        kind=NodeKind.MCP_SERVER,
        display_policy=_AI_KEEP,
        taint_exits=True,
        sink_for=["AI"],
        exploitability=0.9,
    ),
]


# ════════════════════════════════════════════════════════════════════════════
# § 2.2  PII SOURCE PATTERNS  (T-AI14 / T-AI3 partial)
# ════════════════════════════════════════════════════════════════════════════

_PII_POLICY = {"CVE": "strip", "CWE": "strip", "SECRET": "strip", "DLP": "keep", "AI": "keep"}

PII_SOURCE_RULES: List[HopRule] = [
    # HTTP request body / query string — email, SSN, phone, address, cc
    HopRule(
        pattern=r"request\.(json|body|form)\[[\'\"]?(email|ssn|phone|address|credit_card|dob|passport)",
        kind=NodeKind.SOURCE_PII,
        display_policy=_PII_POLICY,
        taint_exits=True,
        sink_for=[],
        exploitability=0.0,
    ),
    HopRule(
        pattern=r"req\.(body|query|params)\.(email|ssn|phone|address|creditCard)",
        kind=NodeKind.SOURCE_PII,
        display_policy=_PII_POLICY,
        taint_exits=True,
        sink_for=[],
        exploitability=0.0,
    ),
    # Database query returning PII columns
    HopRule(
        pattern=r"SELECT\b.*\b(email|ssn|phone|address|credit_card|dob)\b.*\bFROM\b",
        kind=NodeKind.SOURCE_PII,
        display_policy=_PII_POLICY,
        taint_exits=True,
        sink_for=[],
        exploitability=0.0,
    ),
    # ORM model attribute access
    HopRule(
        pattern=r"\.(email|ssn|phone_number|credit_card|date_of_birth|passport_number)\b",
        kind=NodeKind.SOURCE_PII,
        display_policy=_PII_POLICY,
        taint_exits=True,
        sink_for=[],
        exploitability=0.0,
    ),
    # Session / auth user attributes
    HopRule(
        pattern=r"(session|current_user|request\.user)\.(email|ssn|phone)",
        kind=NodeKind.SOURCE_PII,
        display_policy=_PII_POLICY,
        taint_exits=True,
        sink_for=[],
        exploitability=0.0,
    ),
]


# ════════════════════════════════════════════════════════════════════════════
# § 2.3  GO + JS + PYTHON CORE RULES  (from design doc § 2.1)
# ════════════════════════════════════════════════════════════════════════════

CORE_RULES: List[HopRule] = [
    # ── Go — dangerous operation sinks (CWE) ──────────────────────────────
    HopRule(
        r"^os/exec\.",
        NodeKind.SINK_DANGER,
        {"CVE": "strip", "CWE": "keep", "SECRET": "keep_if_last", "DLP": "strip", "AI": "keep"},
        True,
        ["CWE", "AI"],
        1.0,
    ),
    HopRule(
        r"^os\.Create|os\.WriteFile|os\.OpenFile",
        NodeKind.SINK_DANGER,
        {"CVE": "strip", "CWE": "keep", "SECRET": "keep_if_last", "DLP": "keep", "AI": "keep"},
        True,
        ["CWE", "SECRET"],
        0.7,
    ),
    HopRule(
        r"^database/sql\.",
        NodeKind.SINK_DANGER,
        {"CVE": "strip", "CWE": "keep", "SECRET": "strip", "DLP": "keep", "AI": "strip"},
        True,
        ["CWE", "DLP"],
        1.0,
    ),
    HopRule(
        r"^net/http\.",
        NodeKind.SINK_DANGER,
        {"CVE": "strip", "CWE": "keep", "SECRET": "keep", "DLP": "keep", "AI": "strip"},
        True,
        ["CWE", "SECRET", "DLP"],
        0.9,
    ),
    HopRule(
        r"^log\.",
        NodeKind.SINK_DATA,
        {"CVE": "strip", "CWE": "keep_if_last", "SECRET": "keep", "DLP": "keep", "AI": "keep"},
        True,
        ["DLP", "SECRET"],
        0.5,
    ),
    # ── Go — stdlib intermediaries (strip for CVE) ────────────────────────
    HopRule(
        r"^fmt\.",
        NodeKind.STDLIB,
        {"CVE": "strip", "CWE": "strip", "SECRET": "strip", "DLP": "strip", "AI": "strip"},
        True,
        [],
        0.0,
    ),
    HopRule(
        r"^strings\.",
        NodeKind.STDLIB,
        {"CVE": "strip", "CWE": "strip", "SECRET": "strip", "DLP": "strip", "AI": "strip"},
        True,
        [],
        0.0,
    ),
    HopRule(
        r"^strconv\.",
        NodeKind.STDLIB,
        {"CVE": "strip", "CWE": "strip", "SECRET": "strip", "DLP": "strip", "AI": "strip"},
        True,
        [],
        0.0,
    ),
    HopRule(
        r"^bytes\.",
        NodeKind.STDLIB,
        {"CVE": "strip", "CWE": "strip", "SECRET": "strip", "DLP": "strip", "AI": "strip"},
        True,
        [],
        0.0,
    ),
    HopRule(
        r"^encoding/json\.",
        NodeKind.STDLIB,
        {"CVE": "strip", "CWE": "strip", "SECRET": "strip", "DLP": "strip", "AI": "strip"},
        True,
        [],
        0.0,
    ),
    HopRule(
        r"^encoding/base64\.",
        NodeKind.STDLIB,
        {"CVE": "strip", "CWE": "strip", "SECRET": "strip", "DLP": "strip", "AI": "strip"},
        False,
        [],
        0.0,
    ),
    # ── Go — dynamic OS boundary ──────────────────────────────────────────
    HopRule(
        r"^syscall\.",
        NodeKind.BOUNDARY,
        {"CVE": "strip", "CWE": "keep", "SECRET": "keep_if_last", "DLP": "strip", "AI": "keep"},
        None,
        [],
        0.5,
    ),
    HopRule(
        r"#cgo\b|\bC\.",
        NodeKind.BOUNDARY,
        {"CVE": "keep", "CWE": "keep", "SECRET": "keep", "DLP": "keep", "AI": "keep"},
        None,
        [],
        0.7,
    ),
    # ── JavaScript / Node.js — sinks ─────────────────────────────────────
    HopRule(
        r"^child_process\.",
        NodeKind.SINK_DANGER,
        {"CVE": "strip", "CWE": "keep", "SECRET": "keep", "DLP": "strip", "AI": "keep"},
        True,
        ["CWE", "AI"],
        1.0,
    ),
    HopRule(
        r"eval\(|new Function\(|vm\.runInNewContext",
        NodeKind.SINK_DANGER,
        {"CVE": "strip", "CWE": "keep", "SECRET": "strip", "DLP": "strip", "AI": "keep"},
        True,
        ["CWE", "AI"],
        1.0,
    ),
    HopRule(
        r"axios\.|fetch\(|XMLHttpRequest|got\.",
        NodeKind.SINK_SECRET,
        {"CVE": "strip", "CWE": "strip", "SECRET": "keep", "DLP": "keep", "AI": "strip"},
        True,
        ["SECRET", "DLP"],
        0.9,
    ),
    # ── Python — sinks ────────────────────────────────────────────────────
    HopRule(
        r"^subprocess\.",
        NodeKind.SINK_DANGER,
        {"CVE": "strip", "CWE": "keep", "SECRET": "keep", "DLP": "strip", "AI": "keep"},
        True,
        ["CWE", "AI"],
        1.0,
    ),
    HopRule(
        r"^os\.system\b|os\.popen\b",
        NodeKind.SINK_DANGER,
        {"CVE": "strip", "CWE": "keep", "SECRET": "strip", "DLP": "strip", "AI": "keep"},
        True,
        ["CWE", "AI"],
        1.0,
    ),
    HopRule(
        r"cursor\.execute|execute_query",
        NodeKind.SINK_DANGER,
        {"CVE": "strip", "CWE": "keep", "SECRET": "strip", "DLP": "keep", "AI": "strip"},
        True,
        ["CWE", "DLP"],
        1.0,
    ),
    HopRule(
        r"requests\.(get|post|put|patch|delete)",
        NodeKind.SINK_SECRET,
        {"CVE": "strip", "CWE": "strip", "SECRET": "keep", "DLP": "keep", "AI": "strip"},
        True,
        ["SECRET", "DLP"],
        0.9,
    ),
    HopRule(
        r"pickle\.loads|yaml\.load\(",
        NodeKind.SINK_DANGER,
        {"CVE": "strip", "CWE": "keep", "SECRET": "strip", "DLP": "strip", "AI": "strip"},
        True,
        ["CWE"],
        1.0,
    ),
]


# ════════════════════════════════════════════════════════════════════════════
# § 2.4  COMBINED REGISTRY
# ════════════════════════════════════════════════════════════════════════════

# ════════════════════════════════════════════════════════════════════════════
# § 2.4  JS/TS HCR RULES  (T-CG18)
# ════════════════════════════════════════════════════════════════════════════
# Node.js / browser-specific rules that extend CORE_RULES for JS/TS projects.
# Display policy: same conventions as CORE_RULES.

JS_RULES: List[HopRule] = [
    # ── Node.js HTTP sinks ─────────────────────────────────────────────────────────
    HopRule(
        r"^axios\.|^got\.|^node-fetch\.|^superagent\.",
        NodeKind.SINK_SECRET,
        {"CVE": "strip", "CWE": "strip", "SECRET": "keep", "DLP": "keep", "AI": "strip"},
        True,
        ["SECRET", "DLP"],
        0.9,
    ),
    HopRule(
        r"^fetch\(|globalThis\.fetch|window\.fetch",
        NodeKind.SINK_SECRET,
        {"CVE": "strip", "CWE": "strip", "SECRET": "keep", "DLP": "keep", "AI": "strip"},
        True,
        ["SECRET", "DLP"],
        0.8,
    ),
    # ── Node.js execution sinks ───────────────────────────────────────────────────
    HopRule(
        r"^child_process\.exec\b|^execSync\b|^spawnSync\b",
        NodeKind.SINK_DANGER,
        {"CVE": "strip", "CWE": "keep", "SECRET": "keep", "DLP": "strip", "AI": "keep"},
        True,
        ["CWE", "AI"],
        1.0,
    ),
    HopRule(
        r"new\s+Function\(|vm\.Script\b|vm\.runInNewContext",
        NodeKind.SINK_DANGER,
        {"CVE": "strip", "CWE": "keep", "SECRET": "strip", "DLP": "strip", "AI": "keep"},
        True,
        ["CWE", "AI"],
        1.0,
    ),
    # ── DOM / XSS sinks (browser) ──────────────────────────────────────────────
    HopRule(
        r"\.innerHTML\s*=|\.outerHTML\s*=",
        NodeKind.SINK_DANGER,
        {"CVE": "strip", "CWE": "keep", "SECRET": "strip", "DLP": "strip", "AI": "keep"},
        True,
        ["CWE"],
        1.0,
    ),
    HopRule(
        r"dangerouslySetInnerHTML|\.html\(",
        NodeKind.SINK_DANGER,
        {"CVE": "strip", "CWE": "keep", "SECRET": "strip", "DLP": "strip", "AI": "keep"},
        True,
        ["CWE"],
        0.9,
    ),
    HopRule(
        r"document\.write\(|document\.writeln\(",
        NodeKind.SINK_DANGER,
        {"CVE": "strip", "CWE": "keep", "SECRET": "strip", "DLP": "strip", "AI": "keep"},
        True,
        ["CWE"],
        1.0,
    ),
    # ── Node.js database sinks ───────────────────────────────────────────────
    HopRule(
        r"\.query\s*\(|\.execute\s*\(|\.raw\s*\(",
        NodeKind.SINK_DANGER,
        {"CVE": "strip", "CWE": "keep", "SECRET": "strip", "DLP": "keep", "AI": "strip"},
        True,
        ["CWE", "DLP"],
        1.0,
    ),
    HopRule(
        r"mongoose\.|mongodb\.|prisma\.",
        NodeKind.SINK_DANGER,
        {"CVE": "strip", "CWE": "keep_if_last", "SECRET": "strip", "DLP": "keep", "AI": "strip"},
        True,
        ["DLP"],
        0.7,
    ),
    # ── Node.js file system sinks ───────────────────────────────────────────
    HopRule(
        r"fs\.writeFile\b|fs\.appendFile\b|fs\.write\b",
        NodeKind.SINK_DANGER,
        {"CVE": "strip", "CWE": "keep", "SECRET": "keep_if_last", "DLP": "keep", "AI": "keep"},
        True,
        ["CWE", "SECRET", "DLP"],
        0.7,
    ),
    HopRule(
        r"fs\.readFile\b|fs\.readFileSync\b",
        NodeKind.STDLIB,
        {"CVE": "strip", "CWE": "strip", "SECRET": "keep", "DLP": "strip", "AI": "strip"},
        True,
        [],
        0.0,
    ),
    # ── Node.js stdlib / noise ────────────────────────────────────────────────
    HopRule(
        r"^JSON\.(parse|stringify)\b|^JSON\.",
        NodeKind.STDLIB,
        {"CVE": "strip", "CWE": "strip", "SECRET": "strip", "DLP": "strip", "AI": "strip"},
        True,
        [],
        0.0,
    ),
    HopRule(
        r"^Buffer\.|^TextDecoder\b|^TextEncoder\b",
        NodeKind.STDLIB,
        {"CVE": "strip", "CWE": "strip", "SECRET": "strip", "DLP": "strip", "AI": "strip"},
        True,
        [],
        0.0,
    ),
    HopRule(
        r"^crypto\.createHash\b|^crypto\.createHmac\b",
        NodeKind.STDLIB,
        {"CVE": "strip", "CWE": "keep_if_last", "SECRET": "keep", "DLP": "strip", "AI": "strip"},
        False,
        ["SECRET"],
        0.5,
    ),
    # ── Express / Fastify / Hapi entry points ────────────────────────────────
    HopRule(
        r"app\.(get|post|put|patch|delete|all)\s*\(|router\.(get|post|put)",
        NodeKind.ENTRY,
        {"CVE": "keep", "CWE": "keep", "SECRET": "strip", "DLP": "keep", "AI": "keep"},
        True,
        [],
        0.0,
    ),
    HopRule(
        r"fastify\.(get|post|route)\b|server\.route\b",
        NodeKind.ENTRY,
        {"CVE": "keep", "CWE": "keep", "SECRET": "strip", "DLP": "keep", "AI": "keep"},
        True,
        [],
        0.0,
    ),
    # ── Dev-only boundary (T-CG14) ───────────────────────────────────────────────
    # jest/mocha/vitest/webpack/eslint are dev tools — finding them in a call
    # path means we’re probably in a test or build file (NOT_REACHABLE signal).
    HopRule(
        r"^jest\.|^mocha\.|^vitest\.|^jasmine\.",
        NodeKind.BOUNDARY,
        {"CVE": "strip", "CWE": "strip", "SECRET": "strip", "DLP": "strip", "AI": "strip"},
        None,
        [],
        0.0,
    ),
    HopRule(
        r"^webpack\.|^esbuild\.|^rollup\.|^vite\.|^babel\.",
        NodeKind.BOUNDARY,
        {"CVE": "strip", "CWE": "strip", "SECRET": "strip", "DLP": "strip", "AI": "strip"},
        None,
        [],
        0.0,
    ),
]

REGISTRY: List[HopRule] = LLM_SINK_RULES + PII_SOURCE_RULES + JS_RULES + CORE_RULES

# Alias used by tests and downstream imports
HCR_RULES = REGISTRY


# ════════════════════════════════════════════════════════════════════════════
# § 2.5  CLASSIFY API
# ════════════════════════════════════════════════════════════════════════════


def classify_hop(
    label: str,
    finding_type: str,
    position: HopPosition = HopPosition.MIDDLE,
) -> HopDecision:
    """
    Return the display decision and NodeKind for a single hop label.

    Parameters
    ----------
    label        Fully-qualified hop name (e.g. ``openai.chat.completions.create``).
    finding_type ``'CVE'`` | ``'CWE'`` | ``'SECRET'`` | ``'DLP'`` | ``'AI'``
    position     ``HopPosition.FIRST | MIDDLE | LAST``

    Returns
    -------
    HopDecision with (kind, display_action, taint_exits, exploitability).
    ``display_action`` is always ``'keep'`` or ``'strip'`` (keep_if_last resolved).
    """
    for rule in REGISTRY:
        if rule.matches(label):
            return rule.decide(finding_type, position)

    # ── Default classification by name heuristics ─────────────────────────
    label.lower()

    # Third-party package prefix (contains a dot and starts with lowercase)
    if "." in label and not label.startswith("app.") and not label.startswith("services."):
        return HopDecision(NodeKind.VIA, "keep", True, 0.3)

    # App code default
    return HopDecision(NodeKind.APP, "keep", True, 0.5)


# T-CG16: boundary_class lookup for BOUNDARY-kind nodes
_BOUNDARY_CLASS_PATTERNS: List[tuple] = [
    (re.compile(r"^syscall\."), "os_stdlib"),
    (re.compile(r"^golang\.org/x/sys"), "os_stdlib"),
    (re.compile(r"^unsafe\."), "os_stdlib"),
    (re.compile(r"#cgo\b|\bC\."), "cgo"),
    (re.compile(r"plugin\.Open"), "dynamic_lib"),
    (re.compile(r"^reflect\."), "reflection"),
]


def _boundary_class_for(label: str) -> str:
    """T-CG16: Return boundary_class string for a BOUNDARY-kind hop label."""
    for pat, cls in _BOUNDARY_CLASS_PATTERNS:
        if pat.search(label):
            return cls
    return "os_stdlib"  # conservative default
