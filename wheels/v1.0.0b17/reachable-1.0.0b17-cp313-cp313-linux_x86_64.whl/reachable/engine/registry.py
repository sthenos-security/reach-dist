#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.

"""
Scanner Registry - Track Which Scanner Found What

Every finding is tagged with:
- found_by: Which scanner engine discovered it (Grype, Semgrep, GuardDog, etc.)
- scanner_version: Version of the scanner
- scan_timestamp: When it was found
- project_namespace: High-level project organization

This enables:
- Attribution: "This CVE was found by Grype"
- Debugging: "Why didn't Semgrep catch this?"
- Compliance: "We scanned with OWASP-approved tools"
- Analytics: "Grype found 90% of our CVEs"
"""

import json
import logging
from dataclasses import asdict, dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional

# Initialize module-level logger
logger = logging.getLogger(__name__)


@dataclass
class ScannerInfo:
    """Information about a scanner tool."""

    name: str  # "Grype", "Semgrep", "GuardDog"
    version: str  # "0.74.0"
    type: str  # "sca", "sast", "malware"
    vendor: str  # "Anchore", "r2c", "DataDog"
    description: str  # Short description


@dataclass
class Finding:
    """
    A single finding with scanner attribution.

    Examples:
    - CVE-2023-43804 found by Grype
    - Hardcoded API key found by Semgrep
    - Malicious package found by GuardDog
    """

    id: str  # CVE-2023-43804, secret-api-key-001, etc.
    type: str  # "cve", "secret", "malware", "code_smell"
    severity: str  # "CRITICAL", "HIGH", "MEDIUM", "LOW"
    title: str  # Human-readable title

    # Scanner attribution
    found_by: str  # Scanner name ("Grype", "Semgrep")
    scanner_version: str  # Scanner version
    scan_timestamp: str  # ISO timestamp

    # Project context
    project_namespace: str  # "services/user-api/python"
    project_id: str  # "user-api-python"
    language: str  # "python", "js_ts", "go"

    # Finding details
    location: Optional[Dict] = None  # File, line, column
    metadata: Dict = field(default_factory=dict)  # Scanner-specific data

    def to_dict(self):
        """Convert to dictionary."""
        return asdict(self)


class ScannerRegistry:
    """
    Registry of all scanners and their findings.

    Tracks:
    - Which scanners ran
    - What each scanner found
    - Attribution for every finding
    """

    # Known scanners
    SCANNERS = {
        "syft": ScannerInfo(
            name="Syft", version="unknown", type="sbom", vendor="Anchore", description="SBOM generation tool"
        ),
        "grype": ScannerInfo(
            name="Grype",
            version="unknown",
            type="sca",
            vendor="Anchore",
            description="Vulnerability scanner for container images and filesystems",
        ),
        "semgrep": ScannerInfo(
            name="Semgrep",
            version="unknown",
            type="sast",
            vendor="r2c / Semgrep Inc.",
            description="Static analysis tool for finding bugs and enforcing code standards",
        ),
        "guarddog": ScannerInfo(
            name="GuardDog",
            version="unknown",
            type="malware",
            vendor="DataDog",
            description="Python package malware detection",
        ),
        "socket": ScannerInfo(
            name="Socket",
            version="unknown",
            type="malware",
            vendor="Socket Inc.",
            description="JavaScript package security scanner",
        ),
        "reachable": ScannerInfo(
            name="REACHABLE",
            version="1.0.0",
            type="ast",
            vendor="REACHABLE Security",
            description="AST-based reachability analysis engine",
        ),
    }

    def __init__(self, project_namespace: str, project_id: str, language: str):
        """
        Initialize scanner registry for a project.

        Args:
            project_namespace: High-level path (e.g., "services/user-api/python")
            project_id: Unique project identifier (e.g., "user-api-python")
            language: Programming language
        """
        self.project_namespace = project_namespace
        self.project_id = project_id
        self.language = language

        # Track findings per scanner
        self.findings_by_scanner: Dict[str, List[Finding]] = {}

        # Track which scanners ran
        self.scanners_executed: List[str] = []

        # Scan start time
        self.scan_start = datetime.now().isoformat()

    def register_scanner_execution(self, scanner_name: str, version: Optional[str] = None):
        """
        Register that a scanner was executed.

        Args:
            scanner_name: Name of scanner (e.g., "grype")
            version: Version string (optional)
        """
        if scanner_name not in self.scanners_executed:
            self.scanners_executed.append(scanner_name)

        # Update version if provided
        if version and scanner_name in self.SCANNERS:
            self.SCANNERS[scanner_name].version = version

    def add_finding(
        self,
        finding_id: str,
        finding_type: str,
        severity: str,
        title: str,
        found_by: str,
        scanner_version: str = "unknown",
        location: Optional[Dict] = None,
        metadata: Optional[Dict] = None,
    ) -> Finding:
        """
        Add a finding with scanner attribution.

        Args:
            finding_id: Unique ID (CVE-2023-43804, etc.)
            finding_type: Type of finding ("cve", "secret", "malware")
            severity: Severity level
            title: Human-readable title
            found_by: Scanner name ("Grype", "Semgrep")
            scanner_version: Scanner version
            location: File/line information
            metadata: Additional scanner-specific data

        Returns:
            Finding object
        """
        finding = Finding(
            id=finding_id,
            type=finding_type,
            severity=severity,
            title=title,
            found_by=found_by,
            scanner_version=scanner_version,
            scan_timestamp=datetime.now().isoformat(),
            project_namespace=self.project_namespace,
            project_id=self.project_id,
            language=self.language,
            location=location,
            metadata=metadata or {},
        )

        # Track by scanner
        if found_by not in self.findings_by_scanner:
            self.findings_by_scanner[found_by] = []

        self.findings_by_scanner[found_by].append(finding)

        return finding

    def get_scanner_stats(self) -> Dict:
        """
        Get statistics about what each scanner found.

        Returns:
            Statistics dictionary
        """
        stats = {
            "total_scanners_executed": len(self.scanners_executed),
            "scanners": {},
            "total_findings": sum(len(f) for f in self.findings_by_scanner.values()),
        }

        for scanner_name in self.scanners_executed:
            findings = self.findings_by_scanner.get(scanner_name, [])

            # Count by severity
            severity_counts = {}
            for finding in findings:
                sev = finding.severity
                severity_counts[sev] = severity_counts.get(sev, 0) + 1

            # Count by type
            type_counts = {}
            for finding in findings:
                ftype = finding.type
                type_counts[ftype] = type_counts.get(ftype, 0) + 1

            scanner_info = self.SCANNERS.get(scanner_name, None)

            stats["scanners"][scanner_name] = {
                "total_findings": len(findings),
                "by_severity": severity_counts,
                "by_type": type_counts,
                "scanner_info": {
                    "vendor": scanner_info.vendor if scanner_info else "Unknown",
                    "type": scanner_info.type if scanner_info else "Unknown",
                    "version": scanner_info.version if scanner_info else "Unknown",
                },
            }

        return stats

    def get_all_findings(self) -> List[Finding]:
        """Get all findings across all scanners."""
        all_findings = []
        for findings in self.findings_by_scanner.values():
            all_findings.extend(findings)
        return all_findings

    def get_findings_by_scanner(self, scanner_name: str) -> List[Finding]:
        """Get findings from a specific scanner."""
        return self.findings_by_scanner.get(scanner_name, [])

    def save_to_file(self, output_path: Path):
        """
        Save registry to JSON file.

        Args:
            output_path: Path to output file
        """
        data = {
            "project_namespace": self.project_namespace,
            "project_id": self.project_id,
            "language": self.language,
            "scan_start": self.scan_start,
            "scan_end": datetime.now().isoformat(),
            "scanners_executed": self.scanners_executed,
            "scanner_stats": self.get_scanner_stats(),
            "findings": [f.to_dict() for f in self.get_all_findings()],
        }

        with open(output_path, "w") as f:
            json.dump(data, f, indent=2)

    @staticmethod
    def load_from_file(file_path: Path) -> "ScannerRegistry":
        """Load registry from JSON file."""
        with open(file_path) as f:
            data = json.load(f)

        registry = ScannerRegistry(
            project_namespace=data["project_namespace"],
            project_id=data["project_id"],
            language=data["language"],
        )

        registry.scan_start = data.get("scan_start")
        registry.scanners_executed = data.get("scanners_executed", [])

        # Reload findings
        for finding_data in data.get("findings", []):
            finding = Finding(**finding_data)
            scanner = finding.found_by
            if scanner not in registry.findings_by_scanner:
                registry.findings_by_scanner[scanner] = []
            registry.findings_by_scanner[scanner].append(finding)

        return registry


if __name__ == "__main__":
    # Test
    registry = ScannerRegistry(
        project_namespace="services/user-api/python", project_id="user-api-python", language="python"
    )

    # Register scanner executions
    registry.register_scanner_execution("grype", "0.74.0")
    registry.register_scanner_execution("semgrep", "1.50.0")

    # Add findings
    registry.add_finding(
        finding_id="CVE-2023-43804",
        finding_type="cve",
        severity="HIGH",
        title="Cookie name crafting attack in urllib3",
        found_by="Grype",
        scanner_version="0.74.0",
        location={"package": "urllib3", "version": "1.26.5"},
        metadata={"cvss_score": 7.5},
    )

    registry.add_finding(
        finding_id="secret-api-key-001",
        finding_type="secret",
        severity="CRITICAL",
        title="Hardcoded API key",
        found_by="Semgrep",
        scanner_version="1.50.0",
        location={"file": "config.py", "line": 42},
        metadata={"rule": "generic.secrets.api-key"},
    )

    # Get stats
    stats = registry.get_scanner_stats()
    logger.info(json.dumps(stats, indent=2))

    # Save
    registry.save_to_file(Path("test-registry.json"))
    logger.info("\n Saved to test-registry.json")
