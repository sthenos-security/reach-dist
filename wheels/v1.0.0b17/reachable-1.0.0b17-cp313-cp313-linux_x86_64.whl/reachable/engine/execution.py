#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.

"""
Execution Engine - Language-Specific Phase Execution

Implements clean phase-based execution with clear input/output contracts.

Key Concepts:
- Phase: Logical grouping of work (SCA, SAST, Reachability)
- Component: Specific tool within a phase (Syft, Semgrep, etc.)
- Action: What the component does
- Metadata: Input files the component reads
- Output: Files the component produces
"""

import json
import subprocess
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Callable, Dict, List, Optional

from reachable.collectors.vulns.grype import (
    VulnDBManager,
    get_grype_env,
    get_grype_path,
    get_syft_path,
)
from reachable.core.logger import logger


@dataclass
class Component:
    """
    A component is a specific tool/scanner that runs in a phase.

    Example:
        Component(
            name="SCA Worker",
            action="Scans package-lock.json for CVEs",
            metadata={"input": "package-lock.json"},
            output="sca_results.json",
            executor=run_sca_scan
        )
    """

    name: str  # "SCA Worker", "Semgrep (SAST)", etc.
    action: str  # Description of what it does
    metadata: Dict[str, str]  # Input files/config
    output: str  # Output filename
    executor: Optional[Callable] = None  # Function to run this component
    status: str = "pending"  # pending, running, success, failed
    duration: float = 0.0  # Execution time in seconds


@dataclass
class Phase:
    """
    A phase is a logical grouping of components.

    Components within a phase can run in parallel.
    Phases run sequentially (Phase 2 waits for Phase 1).

    Example:
        Phase(
            number=1,
            description="Parallel SCA + SAST",
            components=[sca_component, sast_component],
            parallel=True
        )
    """

    number: int  # Phase number (1, 2, 3...)
    description: str  # What this phase does
    components: List[Component]  # Tools that run in this phase
    parallel: bool = False  # Can components run in parallel?
    depends_on: List[int] = field(default_factory=list)  # Which phases must complete first
    status: str = "pending"  # pending, running, success, failed
    start_time: Optional[str] = None
    end_time: Optional[str] = None


class ExecutionEngine:
    """
    Executes phases for a specific language.

    Language-specific strategies:
    - Python: SCA → Clone Libs → Parallel(Reachability, SAST) → Correlation
    - Non-Python: Parallel(SCA, SAST) → Reachability → Correlation
    """

    def __init__(self, language: str, project_id: str, mount_point: str, output_dir: str):
        self.language = language
        self.project_id = project_id
        self.mount_point = Path(mount_point)
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)

        # Metadata directory for message bus
        self.metadata_dir = self.output_dir / ".metadata"
        self.metadata_dir.mkdir(parents=True, exist_ok=True)

        # Scanner registry for attribution tracking
        from reachable.engine.registry import ScannerRegistry

        # Calculate project namespace from mount point
        # e.g., /monorepo/services/user-api → services/user-api/python
        try:
            relative = self.mount_point.relative_to(Path.cwd())
            project_namespace = f"{relative}/{language}"
        except ValueError:
            # mount_point is not relative to cwd, use basename instead
            project_namespace = f"{self.mount_point.name}/{language}"

        self.scanner_registry = ScannerRegistry(
            project_namespace=project_namespace, project_id=project_id, language=language
        )

    def get_execution_plan(self) -> List[Phase]:
        """
        Get language-specific execution plan.

        Returns list of phases with components.
        """
        if self.language == "python":
            return self._get_python_plan()
        elif self.language in ["js_ts"]:
            return self._get_javascript_plan()
        elif self.language == "go":
            return self._get_go_plan()
        elif self.language in ["rust", "java"]:
            return self._get_static_language_plan()
        else:
            # Fallback: basic plan
            return self._get_basic_plan()

    def _get_python_plan(self) -> List[Phase]:
        """
        Python execution plan (SERIAL library cloning needed).

        Phase 1: SCA Worker
          └─ Component: Syft + Grype
             ├─ Metadata: requirements.txt
             └─ Output: sca_results.json

        Phase 2: Library Cloning
          └─ Component: MCP/Git Cloner
             ├─ Metadata: sca_results.json (which CVEs found)
             └─ Output: libs/ directory

        Phase 3: Parallel Analysis (DEPENDS on libs/)
          ├─ Component: AST Reachability Engine
          │  ├─ Metadata: sca_results.json, libs/
          │  └─ Output: reachability_results.json
          ├─ Component: Semgrep (SAST)
          │  ├─ Metadata: source code
          │  └─ Output: sast_findings.json
          └─ Component: GuardDog (Malware)
             ├─ Metadata: requirements.txt
             └─ Output: malware_findings.json

        Phase 4: Correlation
          └─ Component: Correlation Engine
             ├─ Metadata: ALL previous outputs
             └─ Output: final_report.json
        """
        return [
            Phase(
                number=1,
                description="SCA Worker - Scan dependencies for CVEs",
                parallel=False,
                components=[
                    Component(
                        name="SCA Worker",
                        action="Scans requirements.txt for CVEs using Syft + Grype",
                        metadata={"input": "requirements.txt", "sbom_tool": "syft", "vuln_tool": "grype"},
                        output="sca_results.json",
                        executor=self._run_sca_python,
                    )
                ],
            ),
            Phase(
                number=2,
                description="Clone Vulnerable Libraries",
                parallel=False,
                depends_on=[1],
                components=[
                    Component(
                        name="Library Cloner",
                        action="Clones source code for vulnerable libraries (MCP + Git fallback)",
                        metadata={"input": "sca_results.json", "strategy": "MCP-first, git-fallback"},
                        output="libs/",
                        executor=self._clone_libraries,
                    )
                ],
            ),
            Phase(
                number=3,
                description="Parallel Analysis - Reachability + SAST + Malware",
                parallel=True,  # Components run in parallel
                depends_on=[2],
                components=[
                    Component(
                        name="AST Reachability Engine",
                        action="Proves which CVEs are reachable in code",
                        metadata={
                            "input": "sca_results.json",
                            "libraries": "libs/",
                            "app_code": str(self.mount_point),
                        },
                        output="reachability_results.json",
                        executor=self._run_reachability,
                    ),
                    Component(
                        name="Semgrep (SAST)",
                        action="Scans code for secrets, malware patterns, and logic bugs",
                        metadata={"input": str(self.mount_point), "rules": "p/secrets, custom-malware.yaml"},
                        output="sast_findings.json",
                        executor=self._run_semgrep,
                    ),
                    Component(
                        name="ENV-001 Config Secrets",
                        action="Scans .env, configs, CI/CD for secrets Semgrep misses",
                        metadata={
                            "policy": "ENV-001",
                            "input": str(self.mount_point),
                            "targets": ".env, .git-credentials, docker-compose, K8s secrets",
                        },
                        output="env_security_findings.json",
                        executor=self._run_env_secrets,
                    ),
                    Component(
                        name="GuardDog (Malware)",
                        action="Scans Python packages for malware",
                        metadata={"input": "requirements.txt"},
                        output="malware_findings.json",
                        executor=self._run_guarddog,
                    ),
                ],
            ),
            Phase(
                number=4,
                description="Correlation Engine",
                parallel=False,
                depends_on=[3],
                components=[
                    Component(
                        name="Correlation Engine",
                        action="Combines SCA + SAST + Malware findings into composite threats",
                        metadata={
                            "inputs": [
                                "sca_results.json",
                                "reachability_results.json",
                                "sast_findings.json",
                                "malware_findings.json",
                            ]
                        },
                        output="final_report.json",
                        executor=self._run_correlation,
                    )
                ],
            ),
        ]

    def _get_javascript_plan(self) -> List[Phase]:
        """
        JavaScript/TypeScript execution plan.

        Uses flavor-aware Semgrep rulesets:
        - p/react for React apps
        - p/nextjs for Next.js apps
        - p/secrets for all JS

        Phase 1: Parallel SCA + SAST
        Phase 2: Reachability (custom AST)
        Phase 3: Correlation
        """
        # Detect framework flavor from context
        flavor = self._detect_js_flavor()

        # Choose Semgrep ruleset based on flavor
        semgrep_rules = self._get_semgrep_rules_for_js(flavor)

        return [
            Phase(
                number=1,
                description=f"Parallel SCA + SAST (Flavor: {flavor})",
                parallel=True,  # Both run simultaneously
                components=[
                    Component(
                        name="SCA Worker",
                        action="Scans package-lock.json for CVEs using Syft + Grype",
                        metadata={"input": "package-lock.json", "sbom_tool": "syft", "vuln_tool": "grype"},
                        output="sca_results.json",
                        executor=self._run_sca_static,
                    ),
                    Component(
                        name=f"Semgrep (SAST) - {flavor} flavor",
                        action=f"Scans code with {flavor}-specific rules + secrets detection",
                        metadata={"input": str(self.mount_point), "rules": semgrep_rules, "flavor": flavor},
                        output="sast_findings.json",
                        executor=self._run_semgrep_js,
                    ),
                ],
            ),
            Phase(
                number=2,
                description="AST Reachability Engine",
                parallel=False,
                depends_on=[1],
                components=[
                    Component(
                        name="AST Engine (JavaScript)",
                        action="Uses sca_results.json to prove reachability",
                        metadata={
                            "input": "sca_results.json",
                            "lock_file": "package-lock.json",
                            "app_code": str(self.mount_point),
                            "flavor": flavor,
                        },
                        output="reachability_results.json",
                        executor=self._run_reachability,
                    )
                ],
            ),
            Phase(
                number=3,
                description="Correlation Engine",
                parallel=False,
                depends_on=[2],
                components=[
                    Component(
                        name="Correlation Engine",
                        action="Combines findings into composite threats",
                        metadata={"inputs": ["sca_results.json", "sast_findings.json", "reachability_results.json"]},
                        output="final_report.json",
                        executor=self._run_correlation,
                    )
                ],
            ),
        ]

    def _get_go_plan(self) -> List[Phase]:
        """
        Go execution plan.

        KEY DIFFERENCE: govulncheck does BOTH SCA and reachability!

        Phase 1: Parallel govulncheck + SAST
        Phase 2: Correlation (no separate reachability step needed!)
        """
        return [
            Phase(
                number=1,
                description="Parallel SCA+Reachability + SAST",
                parallel=True,  # Both run simultaneously
                components=[
                    Component(
                        name="govulncheck (SCA + Reachability)",
                        action="Scans Go modules for CVEs with NATIVE reachability analysis",
                        metadata={
                            "input": str(self.mount_point),
                            "tool": "govulncheck",
                            "note": "Includes built-in reachability via CallStacks",
                        },
                        output="govulncheck_results.json",
                        executor=self._run_govulncheck,
                    ),
                    Component(
                        name="gosec + Semgrep (SAST)",
                        action="Scans for Go-specific security issues and malware patterns",
                        metadata={"input": str(self.mount_point), "tools": ["gosec", "semgrep p/golang"]},
                        output="sast_findings.json",
                        executor=self._run_go_sast,
                    ),
                ],
            ),
            Phase(
                number=2,
                description="Correlation Engine",
                parallel=False,
                depends_on=[1],
                components=[
                    Component(
                        name="Correlation Engine",
                        action="Combines govulncheck + SAST findings",
                        metadata={
                            "inputs": [
                                "govulncheck_results.json",  # Already has reachability!
                                "sast_findings.json",
                            ],
                            "note": "No separate reachability step needed for Go",
                        },
                        output="final_report.json",
                        executor=self._run_correlation,
                    )
                ],
            ),
        ]

    def _detect_js_flavor(self) -> str:
        """Detect JavaScript framework flavor."""
        # Check for Next.js
        if (self.mount_point / "next.config.js").exists() or (self.mount_point / "next.config.mjs").exists():
            return "Next.js"

        # Check for React in package.json
        pkg_json = self.mount_point / "package.json"
        if pkg_json.exists():
            try:
                with open(pkg_json) as f:
                    data = json.load(f)
                    deps = {**data.get("dependencies", {}), **data.get("devDependencies", {})}

                    if "next" in deps:
                        return "Next.js"
                    elif "react" in deps:
                        return "React"
                    elif "vue" in deps:
                        return "Vue"
                    elif "angular" in deps:
                        return "Angular"
            except Exception:
                pass

        return "Vanilla JS"

    def _get_semgrep_rules_for_js(self, flavor: str) -> str:
        """Get Semgrep ruleset based on JavaScript flavor."""
        if flavor == "Next.js":
            return "p/nextjs,p/secrets,p/ci"
        elif flavor == "React":
            return "p/react,p/secrets,p/ci"
        elif flavor == "Vue":
            return "p/vue,p/secrets,p/ci"
        elif flavor == "Angular":
            return "p/typescript,p/secrets,p/ci"
        else:
            return "p/javascript,p/secrets,p/ci"

    def _get_static_language_plan(self) -> List[Phase]:
        """
        Non-Python execution plan (lock files = static deps).

        Phase 1: Parallel SCA + SAST + Malware
          ├─ Component: SCA Worker
          │  ├─ Metadata: package-lock.json / go.sum / Cargo.lock
          │  └─ Output: sca_results.json
          ├─ Component: Semgrep (SAST)
          │  ├─ Metadata: source code
          │  └─ Output: sast_findings.json
          └─ Component: Package Malware Scanner (language-specific)
             ├─ Metadata: package manifest
             └─ Output: malware_findings.json

        Phase 2: AST Reachability Engine
          └─ Component: Reachability Analyzer
             ├─ Metadata: sca_results.json, lock file
             └─ Output: reachability_results.json

        Phase 3: Correlation
          └─ Component: Correlation Engine
             ├─ Metadata: ALL outputs
             └─ Output: final_report.json
        """
        # Determine lock file based on language
        lock_file_map = {
            "js_ts": "package-lock.json",
            "go": "go.sum",
            "rust": "Cargo.lock",
            "java": "pom.xml",
        }
        lock_file = lock_file_map.get(self.language, "dependencies.lock")

        # Build Phase 1 components
        phase1_components = [
            Component(
                name="SCA Worker",
                action=f"Scans {lock_file} for CVEs",
                metadata={"input": lock_file, "sbom_tool": "syft", "vuln_tool": "grype"},
                output="sca_results.json",
                executor=self._run_sca_static,
            ),
            Component(
                name="Semgrep (SAST)",
                action="Scans code for secrets, malware, and logic bugs",
                metadata={"input": str(self.mount_point), "rules": "p/secrets"},
                output="sast_findings.json",
                executor=self._run_semgrep,
            ),
        ]

        # Add language-specific malware detection
        if self.language == "js_ts":
            phase1_components.append(
                Component(
                    name="npm audit (Malware)",
                    action="Scans npm packages for known malware and vulnerabilities",
                    metadata={"input": "package.json", "tool": "npm audit"},
                    output="malware_findings.json",
                    executor=self._run_npm_audit,
                )
            )
        elif self.language == "rust":
            phase1_components.append(
                Component(
                    name="cargo-audit (Malware)",
                    action="Scans Rust crates for security issues",
                    metadata={"input": "Cargo.lock", "tool": "cargo-audit"},
                    output="malware_findings.json",
                    executor=self._run_cargo_audit,
                )
            )
        # Note: Go and Java don't have dedicated package malware scanners
        # They rely on SCA (Grype) which catches known malicious packages

        return [
            Phase(
                number=1,
                description="Parallel SCA + SAST + Malware",
                parallel=True,  # KEY: All run simultaneously
                components=phase1_components,
            ),
            Phase(
                number=2,
                description="AST Reachability Engine",
                parallel=False,
                depends_on=[1],
                components=[
                    Component(
                        name="AST Engine",
                        action="Uses sca_results.json to prove reachability",
                        metadata={
                            "input": "sca_results.json",
                            "lock_file": lock_file,
                            "app_code": str(self.mount_point),
                        },
                        output="reachability_results.json",
                        executor=self._run_reachability,
                    )
                ],
            ),
            Phase(
                number=3,
                description="Correlation Engine",
                parallel=False,
                depends_on=[2],
                components=[
                    Component(
                        name="Correlation Engine",
                        action="Combines findings into composite threats",
                        metadata={
                            "inputs": [
                                "sca_results.json",
                                "sast_findings.json",
                                "malware_findings.json",
                                "reachability_results.json",
                            ]
                        },
                        output="final_report.json",
                        executor=self._run_correlation,
                    )
                ],
            ),
        ]

    def _get_basic_plan(self) -> List[Phase]:
        """Fallback plan for unsupported languages."""
        return [
            Phase(
                number=1,
                description="Basic SCA Scan",
                parallel=False,
                components=[
                    Component(
                        name="SCA Worker",
                        action="Basic vulnerability scan",
                        metadata={"input": str(self.mount_point)},
                        output="sca_results.json",
                        executor=self._run_sca_basic,
                    )
                ],
            )
        ]

    # ========================================================================
    # Component Executors (actual tool invocations)
    # ========================================================================

    def _run_sca_python(self, component: Component) -> bool:
        """Execute SCA for Python (Syft + Grype)."""
        logger.info(f" Running: {component.name}")
        logger.info(f" Action: {component.action}")

        # Register scanner execution
        self.scanner_registry.register_scanner_execution("syft")
        self.scanner_registry.register_scanner_execution("grype")

        # Step 1: Generate SBOM
        sbom_path = self.output_dir / "sbom.json"
        try:
            subprocess.run(
                [str(get_syft_path()), "scan", f"dir:{self.mount_point}", "-o", f"json={sbom_path}"],
                check=True,
                capture_output=True,
                text=True,
                timeout=300,
            )

            # Extract Syft version from output
            syft_version = "unknown"
            try:
                version_result = subprocess.run([str(get_syft_path()), "version"], capture_output=True, text=True)
                if version_result.returncode == 0:
                    # Parse version from output
                    for line in version_result.stdout.split("\n"):
                        if "Version:" in line or "syft" in line.lower():
                            syft_version = line.split()[-1]
                            break
            except Exception:
                pass

            self.scanner_registry.register_scanner_execution("syft", syft_version)

        except subprocess.CalledProcessError as e:
            logger.info(f" Syft failed: {e}")
            return False

        # Step 2: Scan vulnerabilities
        vulns_path = self.output_dir / "vulns.json"
        db_mgr = VulnDBManager()
        try:
            # Ensure the vulnerability DB is fresh before scanning.
            # Pass scan_dir so TMPDIR is redirected to <scan_dir>/.grype-tmp/
            # — isolates scratch files per repo, never collides with concurrent scans.
            db_mgr.ensure_fresh(verbose=True)

            subprocess.run(
                [str(get_grype_path()), f"sbom:{sbom_path}", "-o", f"json={vulns_path}"],
                check=True,
                capture_output=True,
                text=True,
                env=get_grype_env(scan_dir=self.output_dir),
                timeout=300,
            )

            # Extract Grype version
            grype_version = "unknown"
            try:
                version_result = subprocess.run(
                    [str(get_grype_path()), "version"],
                    capture_output=True,
                    text=True,
                    env=get_grype_env(scan_dir=self.output_dir),
                )
                if version_result.returncode == 0:
                    for line in version_result.stdout.split("\n"):
                        if "Version:" in line or "grype" in line.lower():
                            grype_version = line.split()[-1]
                            break
            except Exception:
                pass

            self.scanner_registry.register_scanner_execution("grype", grype_version)

            # Parse vulnerabilities and add to registry with attribution
            with open(vulns_path) as f:
                vulns_data = json.load(f)

            matches = vulns_data.get("matches", [])
            for match in matches:
                vuln = match.get("vulnerability", {})
                artifact = match.get("artifact", {})

                cve_id = vuln.get("id", "UNKNOWN")
                severity = vuln.get("severity", "UNKNOWN")

                # Add finding to registry
                self.scanner_registry.add_finding(
                    finding_id=cve_id,
                    finding_type="cve",
                    severity=severity,
                    title=vuln.get("description", f"Vulnerability in {artifact.get('name')}"),
                    found_by="Grype",
                    scanner_version=grype_version,
                    location={
                        "package": artifact.get("name"),
                        "version": artifact.get("version"),
                        "type": artifact.get("type"),
                    },
                    metadata={
                        "cvss_score": (
                            vuln.get("cvss", [{}])[0].get("metrics", {}).get("baseScore") if vuln.get("cvss") else None
                        ),
                        "fix_versions": vuln.get("fix", {}).get("versions", []),
                        "data_source": vuln.get("dataSource"),
                    },
                )

            logger.info(f" Grype found {len(matches)} CVEs")

        except subprocess.CalledProcessError as e:
            logger.info(f" Grype failed: {e}")
            return False
        finally:
            # Always clean per-repo scratch — covers success, failure, and
            # Ctrl-C. Removes <scan_dir>/.grype-tmp/ and any grype-scratch*
            # files left inside it.
            db_mgr.cleanup_scan_scratch(self.output_dir)

        # Step 3: Combine into sca_results.json
        sca_results = {
            "sbom": sbom_path.name,
            "vulns": vulns_path.name,
            "timestamp": datetime.now().isoformat(),
            "scanners": {"syft": syft_version, "grype": grype_version},
            "cves_found": len(matches),
        }

        output_file = self.output_dir / component.output
        with open(output_file, "w") as f:
            json.dump(sca_results, f, indent=2)

        logger.info(f" Output: {component.output}")
        return True

    def _run_sca_static(self, component: Component) -> bool:
        """Execute SCA for static languages (JS, Go, Rust, Java)."""
        # Same as _run_sca_python but scans lock file
        return self._run_sca_python(component)

    def _run_sca_basic(self, component: Component) -> bool:
        """Basic SCA for unsupported languages."""
        return self._run_sca_python(component)

    def _clone_libraries(self, component: Component) -> bool:
        """Clone vulnerable libraries (Python only)."""
        logger.info(f" Running: {component.name}")
        logger.info(f" Action: {component.action}")

        # Read which CVEs were found
        sca_file = self.output_dir / "sca_results.json"
        if not sca_file.exists():
            logger.info(f" Missing: {sca_file}")
            return False

        # Use lib_manager to clone
        try:
            from reachable.integrations.lib_manager import LibraryManager

            libs_dir = self.output_dir / "libs"
            manager = LibraryManager(libs_dir, metadata_dir=self.metadata_dir)

            # Load vulns and clone
            with open(self.output_dir / "vulns.json") as f:
                vulns_data = json.load(f)

            manager.clone_vulnerable_libraries(vulns_data, verbose=True)

            # Save metrics
            metrics = manager.get_metrics_summary()
            logger.info(f" Cloned {metrics['total_success']}/{metrics['total_attempted']} libraries")
            logger.info(f" MCP: {metrics['mcp']['success']}, Git: {metrics['git']['success']}")

            return True

        except Exception as e:
            logger.info(f" Clone failed: {e}")
            return False

    def _run_semgrep(self, component: Component) -> bool:
        """Execute Semgrep SAST scan with language-specific rules."""
        logger.info(f" Running: {component.name}")
        logger.info(f" Action: {component.action}")

        # Register scanner execution
        self.scanner_registry.register_scanner_execution("semgrep")

        try:
            from reachable.collectors.secrets.semgrep import SemgrepScanner

            scanner = SemgrepScanner(cache_dir=self.metadata_dir)
            if not scanner.is_available():
                logger.info(" Semgrep not available, skipping")
                return True  # Not a failure, just skip

            # Get Semgrep version
            semgrep_version = "unknown"
            try:
                version_result = subprocess.run(["semgrep", "--version"], capture_output=True, text=True)
                if version_result.returncode == 0:
                    semgrep_version = version_result.stdout.strip()
            except Exception:
                pass

            self.scanner_registry.register_scanner_execution("semgrep", semgrep_version)

            # Language-specific rules
            rules_to_use = "p/secrets"  # Default: secrets
            custom_rules_path = None

            if self.language == "python":
                # Python: secrets + custom malware rules
                custom_rules_path = Path(__file__).parent / "semgrep-rules-malware.yaml"
                rules_to_use = "p/secrets"
            elif self.language == "js_ts":
                # JavaScript: secrets + React/JS security patterns
                custom_rules_path = Path(__file__).parent / "semgrep-rules-javascript.yaml"
                rules_to_use = "p/security-audit"

            # Scan with language-specific rules
            findings = scanner.scan_directory(self.mount_point, rules=rules_to_use)

            # If we have custom rules, scan again with those
            if custom_rules_path and custom_rules_path.exists():
                logger.info(f" Running language-specific rules: {custom_rules_path.name}")
                custom_findings = scanner.scan_directory(self.mount_point, rules=f"--config {custom_rules_path}")
                findings.extend(custom_findings)

            # Add findings to registry with attribution
            for finding in findings:
                # Determine if it's a secret, malware, or code smell
                rule_id = finding.rule_id.lower()

                if (
                    "secret" in rule_id
                    or "key" in rule_id
                    or "token" in rule_id
                    or "password" in rule_id
                    or "credential" in rule_id
                ):
                    finding_type = "secret"
                elif (
                    "malware" in rule_id
                    or "backdoor" in rule_id
                    or "obfuscation" in rule_id
                    or "exec" in rule_id
                    or "eval" in rule_id
                ):
                    finding_type = "malware"
                elif "xss" in rule_id or "injection" in rule_id or "cors" in rule_id:
                    finding_type = "vulnerability"
                else:
                    finding_type = "code_smell"

                self.scanner_registry.add_finding(
                    finding_id=f"semgrep-{finding.rule_id}-{finding.file_path}-{finding.line_number}",
                    finding_type=finding_type,
                    severity=finding.severity,
                    title=finding.message,
                    found_by="Semgrep",
                    scanner_version=semgrep_version,
                    location={
                        "file": finding.file_path,
                        "line": finding.line_number,
                        "code": finding.code_snippet[:100] if finding.code_snippet else None,
                    },
                    metadata={
                        "rule_id": finding.rule_id,
                        "secret_type": finding.secret_type if hasattr(finding, "secret_type") else None,
                        "language": self.language,
                    },
                )

            # Categorize findings
            secrets = [f for f in findings if "secret" in f.rule_id.lower() or "key" in f.rule_id.lower()]
            malware_patterns = [
                f
                for f in findings
                if "malware" in f.rule_id.lower() or "exec" in f.rule_id.lower() or "eval" in f.rule_id.lower()
            ]
            vulnerabilities = [f for f in findings if "xss" in f.rule_id.lower() or "injection" in f.rule_id.lower()]

            output_file = self.output_dir / component.output
            with open(output_file, "w") as f:
                json.dump(
                    {
                        "total_findings": len(findings),
                        "scanner": "Semgrep",
                        "version": semgrep_version,
                        "language": self.language,
                        "rules_used": rules_to_use,
                        "custom_rules": str(custom_rules_path) if custom_rules_path else None,
                        "categories": {
                            "secrets": len(secrets),
                            "malware_patterns": len(malware_patterns),
                            "vulnerabilities": len(vulnerabilities),
                            "other": len(findings) - len(secrets) - len(malware_patterns) - len(vulnerabilities),
                        },
                        "findings": [
                            {
                                "rule_id": f.rule_id,
                                "severity": f.severity,
                                "file": f.file_path,
                                "line": f.line_number,
                                "found_by": "Semgrep",  # Attribution!
                            }
                            for f in findings
                        ],
                    },
                    f,
                    indent=2,
                )

            logger.info(f" Output: {component.output} ({len(findings)} issues)")
            logger.info(" Semgrep found:")
            logger.info(f" - {len(secrets)} secrets")
            logger.info(f" - {len(malware_patterns)} malware patterns")
            logger.info(f" - {len(vulnerabilities)} security vulnerabilities")
            return True

        except Exception as e:
            logger.info(f" Semgrep failed: {e}")
            import traceback

            traceback.print_exc()
            return False

    def _run_env_secrets(self, component: Component) -> bool:
        """Execute ENV-001: Environment & Configuration Secrets Scanner.

        This scanner detects secrets that Semgrep misses in:
        - .env files (KEY=VALUE format)
        - Git credential files (.git-credentials, .netrc)
        - CI/CD pipelines (GitHub Actions, GitLab CI, etc.)
        - Cloud configs (.aws/credentials, .kube/config)
        - Docker configs (docker-compose.yml, config.json)
        - Package manager configs (.npmrc, .pypirc)
        - Kubernetes secrets (Base64 decoded)
        """
        logger.info(f" Running: {component.name}")
        logger.info(" Action: ENV-001 Config Secrets Scan")

        # Register scanner execution
        self.scanner_registry.register_scanner_execution("env_secrets", "1.0.0")

        try:
            from reachable.collectors.secrets.env import EnvSecretsScanner

            scanner = EnvSecretsScanner(
                scan_env=True,
                scan_configs=True,
                scan_cicd=True,
                scan_k8s=True,
                scan_shell=False,  # Too many false positives
                decode_base64=True,
            )

            result = scanner.scan(self.mount_point)

            # Add findings to registry with attribution
            for finding in result.findings:
                self.scanner_registry.add_finding(
                    finding_id=f"env-secrets-{finding.file_path}-{finding.line_number}-{finding.key_name}",
                    finding_type="secret",
                    severity=finding.severity.value,
                    title=finding.message,
                    found_by="ENV-001 Scanner",
                    scanner_version="1.0.0",
                    location={
                        "file": finding.file_path,
                        "line": finding.line_number,
                        "key": finding.key_name,
                    },
                    metadata={
                        "secret_type": finding.secret_type.value,
                        "category": finding.category,
                        "is_weak_secret": finding.is_weak_secret,
                        "is_base64_decoded": finding.is_base64_decoded,
                        "remediation": finding.remediation,
                    },
                )

            # Write output
            output_file = self.output_dir / component.output
            with open(output_file, "w") as f:
                json.dump(result.to_dict(), f, indent=2)

            # Print summary
            logger.info(f" Output: {component.output}")
            logger.info(" ENV-001 found:")
            logger.info(f" - {result.total_secrets_found} secrets in {len(result.files_with_secrets)} files")
            if result.secrets_by_severity:
                for sev, count in sorted(result.secrets_by_severity.items()):
                    icon = {"CRITICAL": "", "HIGH": "", "MEDIUM": ""}.get(sev, "")
                    logger.info(f" - {icon} {sev}: {count}")
            if result.forbidden_files_found:
                logger.info(f" - {len(result.forbidden_files_found)} forbidden credential files!")
            if result.base64_decoded_count:
                logger.info(f" - {result.base64_decoded_count} Base64-decoded secrets")

            return True

        except Exception as e:
            logger.info(f" ENV-001 failed: {e}")
            import traceback

            traceback.print_exc()
            return False

    def _run_guarddog(self, component: Component) -> bool:
        """Execute GuardDog malware scan (Python only)."""
        logger.info(f" Running: {component.name}")
        logger.info(f" Action: {component.action}")

        # Register GuardDog
        self.scanner_registry.register_scanner_execution("guarddog")

        try:
            from reachable.collectors.malware.guarddog import GuardDogScanner

            # Use global cache for GuardDog results (persists across scans)
            global_cache_dir = Path.home() / ".reachable-cache" / "guarddog"
            global_cache_dir.mkdir(parents=True, exist_ok=True)

            scanner = GuardDogScanner(cache_dir=global_cache_dir)
            if not scanner.is_available():
                logger.info(" GuardDog not available, skipping")
                # Create empty output so correlation doesn't fail
                output_file = self.output_dir / component.output
                with open(output_file, "w") as f:
                    json.dump({"packages": {}, "total_scanned": 0}, f)
                return True

            # Get GuardDog version
            guarddog_version = "unknown"
            try:
                version_result = subprocess.run(["guarddog", "--version"], capture_output=True, text=True)
                if version_result.returncode == 0:
                    guarddog_version = version_result.stdout.strip()
            except Exception:
                pass

            self.scanner_registry.register_scanner_execution("guarddog", guarddog_version)

            # Scan requirements.txt or directory
            results = scanner.scan_directory(self.mount_point)

            # Add findings to registry with attribution
            malicious_count = 0
            for pkg_name, pkg_result in results.items():
                if pkg_result.get("is_malicious"):
                    malicious_count += 1
                    self.scanner_registry.add_finding(
                        finding_id=f"guarddog-{pkg_name}",
                        finding_type="malware",
                        severity=pkg_result.get("risk_level", "HIGH"),
                        title=f"Malicious package detected: {pkg_name}",
                        found_by="GuardDog",
                        scanner_version=guarddog_version,
                        location={"package": pkg_name, "version": pkg_result.get("version", "unknown")},
                        metadata={
                            "detections": pkg_result.get("detections", []),
                            "confidence": pkg_result.get("confidence", "unknown"),
                        },
                    )

            output_file = self.output_dir / component.output
            with open(output_file, "w") as f:
                json.dump(
                    {
                        "scanner": "GuardDog",
                        "version": guarddog_version,
                        "packages": results,
                        "total_scanned": len(results),
                        "total_malicious": malicious_count,
                    },
                    f,
                    indent=2,
                )

            logger.info(f" Output: {component.output} ({malicious_count} malicious packages)")
            logger.info(f" GuardDog found {malicious_count} malicious packages")
            return True

        except Exception as e:
            logger.info(f" GuardDog failed: {e}")
            # Create empty output so pipeline continues
            output_file = self.output_dir / component.output
            with open(output_file, "w") as f:
                json.dump({"packages": {}, "error": str(e)}, f)
            return True  # Don't fail pipeline

    def _run_npm_audit(self, component: Component) -> bool:
        """Execute npm audit for JavaScript malware detection."""
        logger.info(f" Running: {component.name}")
        logger.info(f" Action: {component.action}")

        try:
            # Check if package.json exists
            pkg_json = self.mount_point / "package.json"
            if not pkg_json.exists():
                logger.info(" No package.json found, skipping")
                output_file = self.output_dir / component.output
                with open(output_file, "w") as f:
                    json.dump({"packages": {}, "total_scanned": 0}, f)
                return True

            # Run npm audit
            result = subprocess.run(["npm", "audit", "--json"], cwd=self.mount_point, capture_output=True, text=True)

            # npm audit returns non-zero if vulnerabilities found (that's OK)
            audit_data = json.loads(result.stdout)

            # Convert npm audit format to our format (compatible with correlation engine)
            packages = {}
            if "vulnerabilities" in audit_data:
                for pkg_name, vuln_info in audit_data["vulnerabilities"].items():
                    # Check if it's actually malware or just a vuln
                    is_malicious = any(
                        "malicious" in str(v).lower() or "trojan" in str(v).lower() for v in vuln_info.get("via", [])
                    )

                    packages[pkg_name] = {
                        "package_name": pkg_name,
                        "package_version": vuln_info.get("range", "unknown"),
                        "is_malicious": is_malicious,
                        "risk_level": "HIGH" if is_malicious else "MEDIUM",
                        "detections": [str(v) for v in vuln_info.get("via", [])],
                        "confidence": "high" if is_malicious else "medium",
                    }

            output_file = self.output_dir / component.output
            with open(output_file, "w") as f:
                json.dump({"packages": packages, "total_scanned": len(packages), "source": "npm-audit"}, f, indent=2)

            malicious_count = sum(1 for p in packages.values() if p["is_malicious"])
            logger.info(f" Output: {component.output} ({malicious_count} malicious, {len(packages)} total)")
            return True

        except FileNotFoundError:
            logger.info(" npm not found, skipping")
            output_file = self.output_dir / component.output
            with open(output_file, "w") as f:
                json.dump({"packages": {}, "error": "npm not installed"}, f)
            return True
        except Exception as e:
            logger.info(f" npm audit failed: {e}")
            output_file = self.output_dir / component.output
            with open(output_file, "w") as f:
                json.dump({"packages": {}, "error": str(e)}, f)
            return True

    def _run_cargo_audit(self, component: Component) -> bool:
        """Execute cargo-audit for Rust malware detection."""
        logger.info(f" Running: {component.name}")
        logger.info(f" Action: {component.action}")

        try:
            # Run cargo audit
            result = subprocess.run(["cargo", "audit", "--json"], cwd=self.mount_point, capture_output=True, text=True)

            audit_data = json.loads(result.stdout)

            # Convert cargo audit format to our format
            packages = {}
            if "vulnerabilities" in audit_data:
                for vuln in audit_data["vulnerabilities"]["list"]:
                    pkg_name = vuln.get("package", {}).get("name", "unknown")

                    packages[pkg_name] = {
                        "package_name": pkg_name,
                        "package_version": vuln.get("package", {}).get("version", "unknown"),
                        "is_malicious": False,  # cargo-audit focuses on vulns, not malware
                        "risk_level": vuln.get("advisory", {}).get("severity", "MEDIUM").upper(),
                        "detections": [vuln.get("advisory", {}).get("title", "")],
                        "confidence": "high",
                    }

            output_file = self.output_dir / component.output
            with open(output_file, "w") as f:
                json.dump(
                    {"packages": packages, "total_scanned": len(packages), "source": "cargo-audit"},
                    f,
                    indent=2,
                )

            logger.info(f" Output: {component.output} ({len(packages)} packages)")
            return True

        except FileNotFoundError:
            logger.info(" cargo not found, skipping")
            output_file = self.output_dir / component.output
            with open(output_file, "w") as f:
                json.dump({"packages": {}, "error": "cargo not installed"}, f)
            return True
        except Exception as e:
            logger.info(f" cargo audit failed: {e}")
            output_file = self.output_dir / component.output
            with open(output_file, "w") as f:
                json.dump({"packages": {}, "error": str(e)}, f)
            return True

    def _run_reachability(self, component: Component) -> bool:
        """Execute REACHABLE reachability analysis."""
        logger.info(f" Running: {component.name}")
        logger.info(f" Action: {component.action}")

        # Register REACHABLE as scanner
        self.scanner_registry.register_scanner_execution("reachable", "1.0.0")

        # Call main REACHABLE analyzer
        try:
            cmd = [
                "python",
                "-m",
                "reachable.engine.reachability",
                "scan",
                str(self.mount_point),
                "--sbom",
                str(self.output_dir / "sbom.json"),
                "--vulns",
                str(self.output_dir / "vulns.json"),
                "--output",
                str(self.output_dir / component.output),
            ]

            subprocess.run(cmd, check=True, capture_output=True)

            # Parse reachability results and add phantom dependencies to registry
            output_file = self.output_dir / component.output
            if output_file.exists():
                with open(output_file) as f:
                    results = json.load(f)

                # Add phantom dependencies (ghost dependencies)
                correlation = results.get("correlation", {})
                phantoms = correlation.get("phantom_dependencies", [])

                for phantom in phantoms:
                    self.scanner_registry.add_finding(
                        finding_id=f"phantom-{phantom}",
                        finding_type="phantom_dependency",
                        severity="MEDIUM",
                        title=f"Phantom dependency: {phantom} imported but not in manifest",
                        found_by="REACHABLE",
                        scanner_version="1.0.0",
                        location={"package": phantom},
                        metadata={"issue": "ghost_dependency"},
                    )

                if phantoms:
                    logger.info(f" REACHABLE found {len(phantoms)} phantom dependencies")

            logger.info(f" Output: {component.output}")
            return True

        except subprocess.CalledProcessError as e:
            logger.info(f" Reachability failed: {e}")
            return False

    def _run_semgrep_js(self, component: Component) -> bool:
        """Execute Semgrep with JavaScript flavor-specific rulesets."""
        logger.info(f" Running: {component.name}")
        logger.info(f" Action: {component.action}")

        flavor = component.metadata.get("flavor", "Vanilla JS")
        rules = component.metadata.get("rules", "p/javascript,p/secrets")

        # Register scanner execution
        self.scanner_registry.register_scanner_execution("semgrep")

        try:
            from reachable.collectors.secrets.semgrep import SemgrepScanner

            scanner = SemgrepScanner(cache_dir=self.metadata_dir)
            if not scanner.is_available():
                logger.info(" Semgrep not available, skipping")
                return True

            # Get Semgrep version
            semgrep_version = "unknown"
            try:
                version_result = subprocess.run(["semgrep", "--version"], capture_output=True, text=True)
                if version_result.returncode == 0:
                    semgrep_version = version_result.stdout.strip()
            except Exception:
                pass

            self.scanner_registry.register_scanner_execution("semgrep", semgrep_version)

            # Run with flavor-specific rules
            logger.info(f" Using {flavor} ruleset: {rules}")
            findings = scanner.scan_directory(self.mount_point, rules=rules)

            # Add findings to registry with attribution
            for finding in findings:
                # Determine finding type
                rule_id = finding.rule_id.lower()

                if "secret" in rule_id or "key" in rule_id or "token" in rule_id or "password" in rule_id:
                    finding_type = "secret"
                elif "ssrf" in rule_id or "xss" in rule_id or "injection" in rule_id:
                    finding_type = "vulnerability"
                elif "dangerous" in rule_id or "insecure" in rule_id:
                    finding_type = "code_smell"
                else:
                    finding_type = "code_smell"

                self.scanner_registry.add_finding(
                    finding_id=f"semgrep-{finding.rule_id}-{finding.file_path}-{finding.line_number}",
                    finding_type=finding_type,
                    severity=finding.severity,
                    title=finding.message,
                    found_by="Semgrep",
                    scanner_version=semgrep_version,
                    location={
                        "file": finding.file_path,
                        "line": finding.line_number,
                        "code": finding.code_snippet[:100] if finding.code_snippet else None,
                    },
                    metadata={"rule_id": finding.rule_id, "flavor": flavor, "ruleset": rules},
                )

            output_file = self.output_dir / component.output
            with open(output_file, "w") as f:
                json.dump(
                    {
                        "total_findings": len(findings),
                        "scanner": "Semgrep",
                        "version": semgrep_version,
                        "flavor": flavor,
                        "rulesets": rules,
                        "findings": [
                            {
                                "rule_id": f.rule_id,
                                "severity": f.severity,
                                "file": f.file_path,
                                "line": f.line_number,
                                "message": f.message,
                                "found_by": "Semgrep",
                            }
                            for f in findings
                        ],
                    },
                    f,
                    indent=2,
                )

            logger.info(f" Output: {component.output} ({len(findings)} issues)")
            logger.info(f" Semgrep ({flavor}): {len(findings)} issues")
            return True

        except Exception as e:
            logger.info(f" Semgrep failed: {e}")
            return False

    def _run_govulncheck(self, component: Component) -> bool:
        """Execute govulncheck (Go's native SCA + reachability tool)."""
        logger.info(f" Running: {component.name}")
        logger.info(f" Action: {component.action}")

        # Register scanner
        self.scanner_registry.register_scanner_execution("govulncheck")

        try:
            # Check if govulncheck is available
            version_check = subprocess.run(["govulncheck", "-version"], capture_output=True, text=True)

            govulncheck_version = "unknown"
            if version_check.returncode == 0:
                govulncheck_version = version_check.stdout.strip()
            else:
                logger.info(" govulncheck not available, falling back to Syft/Grype")
                # Fall back to standard SCA
                return self._run_sca_static(component)

            self.scanner_registry.register_scanner_execution("govulncheck", govulncheck_version)

            # Run govulncheck with JSON output
            result = subprocess.run(
                ["govulncheck", "-json", "./..."], cwd=self.mount_point, capture_output=True, text=True
            )

            # Parse results
            vulns_data = []
            for line in result.stdout.strip().split("\n"):
                if line:
                    try:
                        vulns_data.append(json.loads(line))
                    except Exception:
                        pass

            # Process vulnerabilities and add to registry
            reachable_cves = []
            unreachable_cves = []

            for entry in vulns_data:
                if entry.get("osv"):
                    osv = entry["osv"]
                    cve_id = osv.get("id", "UNKNOWN")

                    # Check for reachability via call_stacks
                    call_stacks = entry.get("call_stacks", [])
                    is_reachable = len(call_stacks) > 0

                    vuln_info = {
                        "cve": cve_id,
                        "summary": osv.get("summary", ""),
                        "severity": osv.get("database_specific", {}).get("severity", "UNKNOWN"),
                        "module": entry.get("module", {}).get("path", ""),
                        "version": entry.get("module", {}).get("version", ""),
                        "is_reachable": is_reachable,
                        "call_stacks": call_stacks,
                    }

                    if is_reachable:
                        reachable_cves.append(vuln_info)
                    else:
                        unreachable_cves.append(vuln_info)

                    # Add to scanner registry
                    self.scanner_registry.add_finding(
                        finding_id=cve_id,
                        finding_type="cve",
                        severity=vuln_info["severity"],
                        title=vuln_info["summary"],
                        found_by="govulncheck",
                        scanner_version=govulncheck_version,
                        location={"module": vuln_info["module"], "version": vuln_info["version"]},
                        metadata={
                            "is_reachable": is_reachable,
                            "call_stacks": call_stacks,
                            "note": "Reachability determined by govulncheck native analysis",
                        },
                    )

            # Save results
            output_file = self.output_dir / component.output
            with open(output_file, "w") as f:
                json.dump(
                    {
                        "scanner": "govulncheck",
                        "version": govulncheck_version,
                        "total_vulnerabilities": len(reachable_cves) + len(unreachable_cves),
                        "reachable_count": len(reachable_cves),
                        "unreachable_count": len(unreachable_cves),
                        "reachable_cves": reachable_cves,
                        "unreachable_cves": unreachable_cves,
                        "note": "Reachability analysis performed natively by govulncheck",
                    },
                    f,
                    indent=2,
                )

            logger.info(f" Output: {component.output}")
            logger.info(f" govulncheck: {len(reachable_cves)} reachable, {len(unreachable_cves)} unreachable")
            return True

        except subprocess.CalledProcessError as e:
            logger.info(f" govulncheck failed: {e}")
            return False
        except Exception as e:
            logger.info(f" govulncheck error: {e}")
            return False

    def _run_go_sast(self, component: Component) -> bool:
        """Execute gosec + Semgrep for Go SAST."""
        logger.info(f" Running: {component.name}")
        logger.info(f" Action: {component.action}")

        all_findings = []

        # Register scanners
        self.scanner_registry.register_scanner_execution("gosec")
        self.scanner_registry.register_scanner_execution("semgrep")

        # Try gosec first
        try:
            # Check if gosec is available
            version_check = subprocess.run(["gosec", "-version"], capture_output=True, text=True)

            if version_check.returncode == 0:
                gosec_version = version_check.stdout.strip().split()[-1] if version_check.stdout else "unknown"
                self.scanner_registry.register_scanner_execution("gosec", gosec_version)

                # Run gosec
                result = subprocess.run(
                    ["gosec", "-fmt=json", "./..."], cwd=self.mount_point, capture_output=True, text=True
                )

                # Parse gosec results
                gosec_data = json.loads(result.stdout) if result.stdout else {}
                issues = gosec_data.get("Issues", [])

                for issue in issues:
                    finding = {
                        "rule_id": issue.get("rule_id", "UNKNOWN"),
                        "severity": issue.get("severity", "MEDIUM"),
                        "file": issue.get("file", ""),
                        "line": issue.get("line", ""),
                        "message": issue.get("details", ""),
                        "found_by": "gosec",
                        "scanner": "gosec",
                        "version": gosec_version,
                    }
                    all_findings.append(finding)

                    # Add to registry
                    self.scanner_registry.add_finding(
                        finding_id=f"gosec-{issue.get('rule_id')}-{issue.get('file')}-{issue.get('line')}",
                        finding_type="code_smell",
                        severity=issue.get("severity", "MEDIUM"),
                        title=issue.get("details", ""),
                        found_by="gosec",
                        scanner_version=gosec_version,
                        location={"file": issue.get("file"), "line": issue.get("line")},
                        metadata={"rule_id": issue.get("rule_id")},
                    )

                logger.info(f" gosec: {len(issues)} issues")
        except Exception as e:
            logger.info(f" gosec not available or failed: {e}")

        # Run Semgrep with Go ruleset
        try:
            from reachable.collectors.secrets.semgrep import SemgrepScanner

            scanner = SemgrepScanner(cache_dir=self.metadata_dir)
            if scanner.is_available():
                semgrep_version = "unknown"
                try:
                    version_result = subprocess.run(["semgrep", "--version"], capture_output=True, text=True)
                    if version_result.returncode == 0:
                        semgrep_version = version_result.stdout.strip()
                except Exception:
                    pass

                self.scanner_registry.register_scanner_execution("semgrep", semgrep_version)

                # Scan with Go ruleset
                findings = scanner.scan_directory(self.mount_point, rules="p/golang,p/secrets")

                for finding in findings:
                    f = {
                        "rule_id": finding.rule_id,
                        "severity": finding.severity,
                        "file": finding.file_path,
                        "line": finding.line_number,
                        "message": finding.message,
                        "found_by": "Semgrep",
                        "scanner": "Semgrep",
                        "version": semgrep_version,
                    }
                    all_findings.append(f)

                    # Add to registry
                    self.scanner_registry.add_finding(
                        finding_id=f"semgrep-{finding.rule_id}-{finding.file_path}-{finding.line_number}",
                        finding_type="code_smell",
                        severity=finding.severity,
                        title=finding.message,
                        found_by="Semgrep",
                        scanner_version=semgrep_version,
                        location={"file": finding.file_path, "line": finding.line_number},
                        metadata={"rule_id": finding.rule_id, "language": "go"},
                    )

                logger.info(f" Semgrep (Go): {len(findings)} issues")
        except Exception as e:
            logger.info(f" Semgrep failed: {e}")

        # Save combined results
        output_file = self.output_dir / component.output
        with open(output_file, "w") as f:
            json.dump(
                {
                    "total_findings": len(all_findings),
                    "tools": ["gosec", "Semgrep"],
                    "findings": all_findings,
                },
                f,
                indent=2,
            )

        logger.info(f" Output: {component.output} ({len(all_findings)} total issues)")
        return True

    def _run_correlation(self, component: Component) -> bool:
        """Execute correlation engine."""
        logger.info(f" Running: {component.name}")
        logger.info(f" Action: {component.action}")

        try:
            from reachable.correlation import CorrelationEngine

            # Load all inputs
            sca_results = None
            sast_findings = None
            malware_findings = None

            # Check for Go-specific govulncheck results
            govulncheck_file = self.output_dir / "govulncheck_results.json"
            if govulncheck_file.exists():
                # Go project - govulncheck includes BOTH SCA and reachability
                logger.info(" Processing govulncheck results (Go)")
                with open(govulncheck_file) as f:
                    govulncheck_data = json.load(f)

                # Convert govulncheck format to standard SCA format
                sca_results = {
                    "sbom": {},  # govulncheck doesn't produce SBOM
                    "vulns": {
                        "matches": [
                            {
                                "vulnerability": {
                                    "id": cve["cve"],
                                    "severity": cve["severity"],
                                    "description": cve["summary"],
                                },
                                "artifact": {"name": cve["module"], "version": cve["version"]},
                            }
                            for cve in (
                                govulncheck_data.get("reachable_cves", [])
                                + govulncheck_data.get("unreachable_cves", [])
                            )
                        ]
                    },
                }

                # Convert govulncheck reachability to standard format
                {
                    "reachable": {
                        cve["cve"]: {
                            "verdict": "REACHABLE",
                            "evidence": cve.get("call_stacks", []),
                            "note": "Determined by govulncheck native analysis",
                        }
                        for cve in govulncheck_data.get("reachable_cves", [])
                    },
                    "unreachable": {
                        cve["cve"]: {"verdict": "UNREACHABLE", "note": "No call stacks found by govulncheck"}
                        for cve in govulncheck_data.get("unreachable_cves", [])
                    },
                }
            else:
                # Non-Go project - standard SCA + reachability flow
                # Load SCA results
                sca_file = self.output_dir / "sca_results.json"
                if sca_file.exists():
                    with open(sca_file) as f:
                        sca_meta = json.load(f)
                    # Load actual SBOM and vulns
                    sbom_file = self.output_dir / sca_meta.get("sbom", "sbom.json")
                    vulns_file = self.output_dir / sca_meta.get("vulns", "vulns.json")
                    if sbom_file.exists() and vulns_file.exists():
                        with open(sbom_file) as f:
                            sbom = json.load(f)
                        with open(vulns_file) as f:
                            vulns = json.load(f)
                        sca_results = {"sbom": sbom, "vulns": vulns}

                # Load reachability results
                reach_file = self.output_dir / "reachability_results.json"
                if reach_file.exists():
                    with open(reach_file) as f:
                        json.load(f)

            # Load SAST findings
            sast_file = self.output_dir / "sast_findings.json"
            if sast_file.exists():
                with open(sast_file) as f:
                    sast_findings = json.load(f)

            # Load malware findings
            malware_file = self.output_dir / "malware_findings.json"
            if malware_file.exists():
                with open(malware_file) as f:
                    malware_data = json.load(f)
                    # Extract packages dict (format from GuardDog, npm audit, cargo-audit)
                    malware_findings = malware_data.get("packages", {})

            # Run correlation
            engine = CorrelationEngine(
                cves=sca_results.get("vulns", {}) if sca_results else {},
                sbom=sca_results.get("sbom", {}) if sca_results else {},
                secrets_findings=sast_findings,  # Semgrep output includes secrets
                malware_packages=malware_findings,  # Package malware
                malware_code=sast_findings,  # Code malware patterns from Semgrep
                import_analysis=None,  # TODO: Add if available
            )

            correlation_results = engine.correlate()

            # Save correlation output
            output_file = self.output_dir / component.output
            with open(output_file, "w") as f:
                json.dump(correlation_results, f, indent=2)

            # Summary
            summary = correlation_results.get("summary", {})
            composite_threats = summary.get("total_composite_threats", 0)
            escalated = summary.get("escalated_packages", 0)
            attack_paths = summary.get("attack_paths_found", 0)

            logger.info(f" Output: {component.output}")
            logger.info(f" Composite Threats: {composite_threats}")
            logger.info(f" Escalated Packages: {escalated}")
            logger.info(f" Attack Paths: {attack_paths}")
            return True

        except Exception as e:
            logger.info(f" Correlation failed: {e}")
            import traceback

            logger.info(f" {traceback.format_exc()[:300]}")
            # Create minimal output so pipeline doesn't fail completely
            output_file = self.output_dir / component.output
            with open(output_file, "w") as f:
                json.dump(
                    {"status": "failed", "error": str(e), "timestamp": datetime.now().isoformat()},
                    f,
                    indent=2,
                )
            return False

    # ========================================================================
    # Execution Logic
    # ========================================================================

    def execute_all(self) -> bool:
        """Execute all phases sequentially."""
        plan = self.get_execution_plan()

        logger.info(f"\n{'=' * 70}")
        logger.info(f"EXECUTION PLAN: {self.language.upper()} ({self.project_id})")
        logger.info(f"{'=' * 70}\n")

        for phase in plan:
            logger.info(f"Phase {phase.number}: {phase.description}")
            logger.info(f" Parallel: {phase.parallel}")
            logger.info(f" Components: {len(phase.components)}")

            phase.status = "running"
            phase.start_time = datetime.now().isoformat()

            all_success = True
            for component in phase.components:
                component.status = "running"
                start = datetime.now()

                if component.executor:
                    success = component.executor(component)
                else:
                    logger.info(f" No executor for {component.name}")
                    success = False

                component.duration = (datetime.now() - start).total_seconds()
                component.status = "success" if success else "failed"

                if not success:
                    all_success = False

            phase.end_time = datetime.now().isoformat()
            phase.status = "success" if all_success else "failed"

            if not all_success:
                logger.info(f" Phase {phase.number} failed")
                return False
            else:
                logger.info(f" Phase {phase.number} complete")

            logger.info("")

        logger.info(f"{'=' * 70}")
        logger.info(" ALL PHASES COMPLETE")
        logger.info(f"{'=' * 70}\n")

        # Save scanner registry
        registry_path = self.output_dir / "scanner-registry.json"
        self.scanner_registry.save_to_file(registry_path)

        # Print scanner stats
        stats = self.scanner_registry.get_scanner_stats()
        logger.info(" SCANNER ATTRIBUTION SUMMARY")
        logger.info(f" Total Scanners: {stats['total_scanners_executed']}")
        logger.info(f" Total Issues: {stats['total_findings']}")

        for scanner_name, scanner_stats in stats["scanners"].items():
            logger.info(f"\n {scanner_name}:")
            logger.info(f" Found: {scanner_stats['total_findings']} issues")
            logger.info(f" Version: {scanner_stats['scanner_info']['version']}")
            if scanner_stats["by_type"]:
                logger.info(f" Types: {scanner_stats['by_type']}")

        logger.info(f"\n Registry saved to: {registry_path}")
        logger.info("")

        return True


if __name__ == "__main__":
    # Test
    engine = ExecutionEngine(language="js_ts", project_id="test-js", mount_point=".", output_dir="test-output")

    plan = engine.get_execution_plan()

    for phase in plan:
        logger.info(f"\nPhase {phase.number}: {phase.description}")
        logger.info(f"Parallel: {phase.parallel}")
        for comp in phase.components:
            logger.info(f" - {comp.name}")
            logger.info(f" Action: {comp.action}")
            logger.info(f" Output: {comp.output}")
