raise ImportError(
    "reachable.engine.loaders is dead code — removed as part of T-CG28 v1 purge. "
    "The dashboard uses reachable.dashboard_v2.loaders. "
    "Tests must import from there."
)
