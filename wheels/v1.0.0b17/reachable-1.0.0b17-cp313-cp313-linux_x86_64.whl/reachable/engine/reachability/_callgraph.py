#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.

"""
reachable - Build-Time Vulnerability Reachability Analyzer

Determines which CVEs are actually reachable in your code using static analysis.

Uses:
- AST parsing to build call graphs
- Syft-generated SBOM (dependencies)
- Grype-generated vulnerabilities
- Library source code for deep analysis

Output: Which CVEs are truly exploitable vs unreachable dead code
"""

import warnings

# Suppress urllib3 OpenSSL warning (common on macOS with LibreSSL)
warnings.filterwarnings("ignore", message=".*urllib3 v2 only supports OpenSSL.*")
warnings.filterwarnings("ignore", category=DeprecationWarning, module="urllib3")

import ast
import logging
from collections import defaultdict

# Initialize module-level logger
logger = logging.getLogger(__name__)

# =========================================================================
# =========================================================================


class CallGraphBuilder(ast.NodeVisitor):
    """Build call graph from Python AST with project tagging for monorepo support"""

    def __init__(self, module_name="", project_tag=""):
        self.module_name = module_name
        self.project_tag = project_tag  # e.g., 'api', 'frontend', 'shared'
        self.call_graph = defaultdict(set)  # func -> set of called functions
        self.imports = {}  # alias -> full_module_path
        self.function_imports = defaultdict(set)  # func -> set of library imports USED by this function
        self.function_metadata = {}  # func -> {project_tag, file_path, line_number}
        self.current_function = None
        self.current_file = None
        self.all_functions = set()
        self.module_level_imports = set()  # Track imports at module level

    def visit_FunctionDef(self, node):
        """Track function definitions with project metadata"""
        func_name = f"{self.module_name}.{node.name}" if self.module_name else node.name
        self.all_functions.add(func_name)

        # Store metadata for monorepo sub-root filtering
        self.function_metadata[func_name] = {
            "project_tag": self.project_tag,
            "module": self.module_name,
            "file": self.current_file,
            "line": node.lineno if hasattr(node, "lineno") else None,
        }

        # Enter function scope
        prev_function = self.current_function
        self.current_function = func_name

        # Visit function body
        self.generic_visit(node)

        # Exit function scope
        self.current_function = prev_function

    def visit_Call(self, node):
        """Track function calls AND library imports used"""
        if self.current_function:
            callee = self._get_call_name(node)
            if callee:
                # Track the call in call graph
                self.call_graph[self.current_function].add(callee)

                # Track library import usage
                # Check if this call uses a library import

                # Strategy 1: Direct match (e.g., calling 'urllib3.PoolManager')
                for alias, full_path in self.imports.items():
                    if callee.startswith(alias + ".") or callee == alias:
                        # This function uses this library import
                        self.function_imports[self.current_function].add(full_path)
                        break

                # Strategy 2: Check if base of call matches an import
                # (e.g., http.client.get where http → urllib3)
                call_base = callee.split(".")[0] if "." in callee else callee
                if call_base in self.imports:
                    self.function_imports[self.current_function].add(self.imports[call_base])

        self.generic_visit(node)

    def normalize_local_calls(self):
        """Add module prefix to local function calls after parsing"""
        if not self.module_name:
            return

        # Get just the function names (without module prefix)
        local_func_names = {f.split(".")[-1] for f in self.all_functions}

        # Fix up call graph
        normalized_graph = defaultdict(set)
        for caller, callees in self.call_graph.items():
            new_callees = set()
            for callee in callees:
                # If callee is a simple name and matches a local function, add prefix
                if "." not in callee and callee in local_func_names:
                    new_callees.add(f"{self.module_name}.{callee}")
                else:
                    new_callees.add(callee)
            normalized_graph[caller] = new_callees

        self.call_graph = normalized_graph

    def visit_Import(self, node):
        """Track: import urllib3"""
        for alias in node.names:
            name = alias.asname if alias.asname else alias.name
            full_path = alias.name
            self.imports[name] = full_path

            # Track as module-level import if not in function
            if not self.current_function:
                self.module_level_imports.add(full_path)

    def visit_ImportFrom(self, node):
        """Track: from urllib3 import PoolManager"""
        module = node.module or ""
        for alias in node.names:
            name = alias.asname if alias.asname else alias.name
            full_path = f"{module}.{alias.name}" if module else alias.name
            self.imports[name] = full_path

            # Track as module-level import if not in function
            if not self.current_function:
                self.module_level_imports.add(full_path)

    def _get_call_name(self, node):
        """Extract function/method name from Call node"""
        if isinstance(node.func, ast.Name):
            # Simple call: func()
            return node.func.id
        elif isinstance(node.func, ast.Attribute):
            # Method call: obj.method() or module.func()
            parts = []
            current = node.func
            while isinstance(current, ast.Attribute):
                parts.append(current.attr)
                current = current.value
            if isinstance(current, ast.Name):
                parts.append(current.id)
            return ".".join(reversed(parts))
        return None
