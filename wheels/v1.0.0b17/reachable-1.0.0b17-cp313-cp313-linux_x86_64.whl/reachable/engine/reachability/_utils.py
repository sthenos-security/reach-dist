#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.

"""
reachable - Build-Time Vulnerability Reachability Analyzer

Determines which CVEs are actually reachable in your code using static analysis.

Uses:
- AST parsing to build call graphs
- Syft-generated SBOM (dependencies)
- Grype-generated vulnerabilities
- Library source code for deep analysis

Output: Which CVEs are truly exploitable vs unreachable dead code
"""

import warnings

# Suppress urllib3 OpenSSL warning (common on macOS with LibreSSL)
warnings.filterwarnings("ignore", message=".*urllib3 v2 only supports OpenSSL.*")
warnings.filterwarnings("ignore", category=DeprecationWarning, module="urllib3")

import logging
from pathlib import Path
from typing import Dict

# Initialize module-level logger
logger = logging.getLogger(__name__)

# =========================================================================
# =========================================================================


def _build_via_summary(cve_list: list) -> dict:
    """v1.0.0b15: Return {via_package: count} for transitive CVEs, sorted by count desc."""
    from collections import Counter

    via: Counter = Counter()
    for c in cve_list:
        if c.get("is_transitive") and c.get("via_package"):
            via[c["via_package"]] += 1
    return dict(via.most_common())


import re as _re

# Go pseudo-version pattern: v0.0.0-YYYYMMDDHHMMSS-COMMIT or 0.0.0-YYYYMMDDHHMMSS-COMMIT
_GO_PSEUDO_RE = _re.compile(r"^v?0\.0\.0-\d{14}-[0-9a-f]{12}$")


def _get_version() -> str:
    """Read version from VERSION file (single source of truth)"""
    # Try package root first (when running from source)
    version_file = Path(__file__).parent.parent / "VERSION"
    if version_file.exists():
        return version_file.read_text().strip()
    # Try package directory (when installed)
    pkg_version_file = Path(__file__).parent / "VERSION"
    if pkg_version_file.exists():
        return pkg_version_file.read_text().strip()
    return "0.0.0"  # Unknown version


__version__ = _get_version()

# Try to import git analyzer (optional but recommended)
try:
    from reachable.correlation.cve_functions import analyze_all_cves  # noqa: F401

    GIT_ANALYZER_AVAILABLE = True
except ImportError:
    GIT_ANALYZER_AVAILABLE = False


# ─────────────────────────────────────────────────────────────────────────────
# T-CG6: Path deduplication helper
# Groups paths by the intermediate via-package; keeps ≤2 paths per group.
# Prevents 30-path explosion for transitive dependencies.
# ─────────────────────────────────────────────────────────────────────────────
def _dedup_paths_by_via(paths: list, vuln_pkg: str) -> list:
    """
    Deduplicate reachability paths by via-package grouping.
    For transitive deps reached through N app functions via the same intermediate
    package, keep ≤2 shortest paths per via-group.

    Example: 30 paths all going through crewjam/saml → golang.org/x/crypto
    reduces to 2 representative paths.
    """
    if not paths:
        return []
    if not vuln_pkg:
        # No package context — just deduplicate by identity and cap at 10
        seen = set()
        result = []
        for p in paths:
            key = tuple(p)
            if key not in seen:
                seen.add(key)
                result.append(p)
        return result[:10]

    from collections import defaultdict as _dd

    groups = _dd(list)
    vuln_pkg_lower = vuln_pkg.lower()

    for path in paths:
        # Find the hop just before the vuln package
        via = None
        for i, hop in enumerate(path):
            if vuln_pkg_lower in hop.lower() and i > 0:
                candidate = path[i - 1]
                # App code or entrypoint directly calling the vuln package = direct dep
                if candidate.startswith("app.") or candidate.startswith("<"):
                    via = "__direct__"
                else:
                    # Normalize to module root: github.com/foo/bar/v2 → github.com/foo/bar
                    parts = candidate.split("/")
                    if len(parts) >= 3 and parts[0] in (
                        "github.com",
                        "golang.org",
                        "go.uber.org",
                        "k8s.io",
                        "sigs.k8s.io",
                    ):
                        via = "/".join(parts[:3])
                    elif len(parts) >= 2:
                        via = "/".join(parts[:2])
                    else:
                        via = candidate
                break
        key = via or "__direct__"
        groups[key].append(path)

    result = []
    for _via, group in sorted(groups.items()):
        # Keep shortest 2 paths per via-group
        group_sorted = sorted(group, key=len)
        result.extend(group_sorted[:2])

    # Final dedup by identity
    seen = set()
    deduped = []
    for p in result:
        key = tuple(p)
        if key not in seen:
            seen.add(key)
            deduped.append(p)
    return deduped


# v1.0.0b15: Known Go modules with clean semver replacements for pseudo-versions.
# Maps module path → minimum clean semver that supersedes any pseudo-version.
_GO_MODULE_MIN_SEMVER: Dict[str, str] = {
    "golang.org/x/crypto": "v0.17.0",
    "golang.org/x/net": "v0.19.0",
    "golang.org/x/text": "v0.14.0",
    "golang.org/x/sys": "v0.16.0",
    "golang.org/x/term": "v0.16.0",
    "golang.org/x/oauth2": "v0.16.0",
    "golang.org/x/sync": "v0.6.0",
    "golang.org/x/tools": "v0.17.0",
    "golang.org/x/mod": "v0.15.0",
    "google.golang.org/grpc": "v1.61.0",
    "google.golang.org/protobuf": "v1.33.0",
    "github.com/golang/protobuf": "v1.5.4",
    "github.com/go-jose/go-jose": "v3.0.3",
    "gopkg.in/square/go-jose.v2": "v2.6.0",
    "github.com/go-git/go-git": "v5.11.0",
    "github.com/cloudflare/circl": "v1.3.7",
    "github.com/lestrrat-go/jwx": "v2.0.19",
    "github.com/lestrrat-go/jwx/v2": "v2.0.19",
    "k8s.io/client-go": "v0.29.2",
    "k8s.io/apiserver": "v0.29.2",
    "sigs.k8s.io/controller-runtime": "v0.17.2",
    "github.com/docker/docker": "v26.0.0",
    "github.com/opencontainers/runc": "v1.1.12",
}


def _normalize_go_fix_version(package: str, fix_version: str) -> str:
    """v1.0.0b15: Replace Go pseudo-versions with human-readable semver.

    Go pseudo-versions (0.0.0-20200124225646-8b5121be2f68) are technically
    correct minimums but confusing. Map to the first clean semver that
    supersedes the pseudo-version for known packages; fall back to "latest"
    for unknown packages.
    """
    if not fix_version or not _GO_PSEUDO_RE.match(fix_version.strip()):
        return fix_version  # Not a pseudo-version — leave untouched

    # Look up by exact module path first
    pkg_key = package.split(" ")[0].rstrip("/")  # strip version suffix if any
    if pkg_key in _GO_MODULE_MIN_SEMVER:
        return _GO_MODULE_MIN_SEMVER[pkg_key]

    # Partial match (e.g. sub-paths like golang.org/x/crypto/ssh)
    for mod, semver in _GO_MODULE_MIN_SEMVER.items():
        if pkg_key.startswith(mod):
            return semver

    # Unknown module — tell user to check pkg.go.dev
    return "latest (see pkg.go.dev)"
