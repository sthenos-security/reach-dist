#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.

"""
reachable - Build-Time Vulnerability Reachability Analyzer

Determines which CVEs are actually reachable in your code using static analysis.

Uses:
- AST parsing to build call graphs
- Syft-generated SBOM (dependencies)
- Grype-generated vulnerabilities
- Library source code for deep analysis

Output: Which CVEs are truly exploitable vs unreachable dead code
"""

import warnings

# Suppress urllib3 OpenSSL warning (common on macOS with LibreSSL)
warnings.filterwarnings("ignore", message=".*urllib3 v2 only supports OpenSSL.*")
warnings.filterwarnings("ignore", category=DeprecationWarning, module="urllib3")

import logging
from collections import deque
from typing import Dict, List

# Initialize module-level logger
logger = logging.getLogger(__name__)

# =========================================================================
# =========================================================================


class _GraphMixin:
    """Mixin — mixed into ReachabilityAnalyzer. Uses self.* freely."""

    def _build_transitive_graph(self) -> int:
        """
        Build transitive dependency graph for libraries.

        Example:
          app imports requests
          requests imports urllib3
          urllib3 imports certifi

        Result: app transitively uses [requests, urllib3, certifi]

        v1.0.0b15: Now also stores parent pointers so we can reconstruct
        the exact path from any direct dep to any transitive dep.
        self.transitive_parents[direct_lib][transitive_lib] = parent_lib

        Returns count of transitive dependencies discovered.
        """
        if not self.library_imports:
            return 0

        # v1.0.0b15: Initialize parent pointer store for chain reconstruction
        self.transitive_parents: Dict[str, Dict[str, str]] = {}

        # Build transitive closure using BFS — now with parent tracking
        transitive_deps = {}

        for lib_name in self.library_imports.keys():
            visited = set()
            parents: Dict[str, str] = {}  # transitive_lib -> parent_lib
            queue = [lib_name]

            while queue:
                current_lib = queue.pop(0)

                if current_lib in visited:
                    continue
                visited.add(current_lib)

                # Add all libraries this one imports, recording parent
                for imported_lib in self.library_imports.get(current_lib, []):
                    if imported_lib not in visited:
                        parents[imported_lib] = current_lib
                        queue.append(imported_lib)

            # Store transitive dependencies (excluding self)
            transitive_deps[lib_name] = visited - {lib_name}
            # Store parent pointers for this direct dep's transitive closure
            self.transitive_parents[lib_name] = parents

        # Now update function_imports with transitive dependencies
        # If a function imports 'requests', also add urllib3, certifi, etc.
        total_transitive = 0

        for func, direct_imports in list(self.function_imports.items()):
            transitive_set = set()

            for direct_import in direct_imports:
                # Get base library name
                lib_base = direct_import.split(".")[0]

                # Add transitive dependencies of this library
                if lib_base in transitive_deps:
                    transitive_set.update(transitive_deps[lib_base])
                    total_transitive += len(transitive_deps[lib_base])

            # Add transitive imports to function's import set
            if transitive_set:
                self.function_imports[func].update(transitive_set)

        return total_transitive

    def _get_dep_chain(self, vulnerable_package: str, direct_import: str, app_name: str = "") -> tuple:
        """
        v1.0.0b15: Reconstruct the dependency chain from app to vulnerable package.

        Uses parent pointers stored by _build_transitive_graph().

        Args:
            vulnerable_package: normalized package name of the CVE target
            direct_import:      the app-level import that eventually pulls it in
            app_name:           repository/app name for the chain root label

        Returns:
            (chain: List[str], depth: int, via_package: str)

            chain      — ordered list: [app_name, ..., vulnerable_package@version]
                         Internal app modules (local file paths, src/ paths) are omitted.
            depth      — 0 for direct, 1+ for transitive hops
            via_package — the direct dep that introduces the vuln dep (empty if direct)
        """

        def _is_internal(node: str) -> bool:
            """Return True if node looks like an internal app module, not an external package."""
            n = node.lower()
            # Local file paths or src-relative paths
            if "/" in n or n.startswith("."):
                return True
            # Common internal source directory names that slip into import graphs
            internal_prefixes = ("src.", "app.", "lib.", "internal.", "pkg.", "cmd.")
            if any(n.startswith(p) for p in internal_prefixes):
                return True
            # Single-segment names that match common app root names (not versioned packages)
            # A versioned package has letters+digits; pure short identifiers are likely internal
            # We keep it: only filter if it's the app_name itself (already added as root)
            return False

        root = app_name or getattr(self, "app_name", "") or "app"
        pkg_base = vulnerable_package.lower().replace("-", "_").replace(".", "_")
        direct_base = direct_import.split(".")[0] if direct_import else ""

        # Check if it's a direct import (depth = 0)
        direct_imports = getattr(self, "direct_imports", set())
        if pkg_base in direct_imports or pkg_base == direct_base:
            return ([root, vulnerable_package], 0, "")

        # Try to reconstruct path using parent pointers
        parents_map = getattr(self, "transitive_parents", {})
        if direct_base and direct_base in parents_map:
            parents = parents_map[direct_base]
            # Walk parent chain from vulnerable_package back to direct_base
            chain_reversed = [pkg_base]
            current = pkg_base
            for _ in range(20):  # guard against cycles
                parent = parents.get(current)
                if not parent:
                    break
                chain_reversed.append(parent)
                current = parent
            # chain_reversed = [vuln_pkg, ..., direct_base] (reversed)
            chain_reversed.reverse()
            # Prepend app root; filter internal app modules from middle nodes
            middle = [n for n in chain_reversed if not _is_internal(n)]
            chain = [root] + middle
            depth = len(chain) - 2  # hops between app and vuln pkg
            via = chain[1] if len(chain) > 1 else direct_base
            return (chain, max(depth, 1), via)

        # Fallback: two-element chain (direct → vulnerable)
        if direct_base and direct_base != pkg_base:
            return ([root, direct_base, vulnerable_package], 1, direct_base)

        return ([root, vulnerable_package], 1, "")

    def _find_entrypoints(self) -> List[str]:
        """
        Find program entrypoints comprehensively across all languages.

        Detects:
        - Python: main(), @app.route handlers, @router endpoints, handle_*, on_*
        - JavaScript: exports, handlers, index.js functions, Express routes
        - Go: main.main, http.HandleFunc handlers, ServeHTTP methods
        """
        entrypoints = []
        entrypoint_reasons = {}  # Track why each was detected

        for func in self.all_functions:
            func_lower = func.lower()
            simple_name = func.split(".")[-1].lower() if "." in func else func.lower()

            # ============================================================
            # PYTHON ENTRYPOINTS
            # ============================================================

            # main() functions
            if func.endswith(".main") or func == "main" or simple_name == "main":
                entrypoints.append(func)
                entrypoint_reasons[func] = "main function"
                continue

            # Flask/FastAPI route handlers (often contain 'route', 'endpoint', 'view')
            # These are decorated functions that handle HTTP requests
            route_indicators = ["route", "endpoint", "view", "handler", "api", "webhook"]
            if any(ind in func_lower for ind in route_indicators):
                # Check if it looks like a handler (not a utility)
                if not any(skip in func_lower for skip in ["helper", "util", "validate", "parse"]):
                    entrypoints.append(func)
                    entrypoint_reasons[func] = "route/handler pattern"
                    continue

            # Event handlers: handle_*, on_*, process_*
            handler_prefixes = ["handle_", "on_", "process_", "do_", "execute_"]
            if any(simple_name.startswith(prefix) for prefix in handler_prefixes):
                entrypoints.append(func)
                entrypoint_reasons[func] = "event handler pattern"
                continue

            # Django views often end with _view or are in views.py
            if simple_name.endswith("_view") or ".views." in func_lower:
                entrypoints.append(func)
                entrypoint_reasons[func] = "Django view"
                continue

            # CLI commands (often in cli.py or commands/)
            if ".cli." in func_lower or ".commands." in func_lower or simple_name.startswith("cmd_"):
                entrypoints.append(func)
                entrypoint_reasons[func] = "CLI command"
                continue

            # ============================================================
            # JAVASCRIPT ENTRYPOINTS
            # ============================================================

            # index.js, App.js, main.js exports
            if any(mod in func for mod in [".index.", ".app.", ".main.", ".server."]):
                entrypoints.append(func)
                entrypoint_reasons[func] = "module entry"
                continue

            # Express/Koa handlers (get, post, put, delete, patch, all)
            http_methods = ["get", "post", "put", "delete", "patch", "all", "use"]
            if simple_name in http_methods or any(simple_name.startswith(m + "_") for m in http_methods):
                entrypoints.append(func)
                entrypoint_reasons[func] = "HTTP method handler"
                continue

            # React components (start with capital letter, common patterns)
            if simple_name[0].isupper() and any(
                comp in simple_name for comp in ["page", "screen", "modal", "form", "component"]
            ):
                entrypoints.append(func)
                entrypoint_reasons[func] = "React component"
                continue

            # Export patterns
            if "export" in func_lower or simple_name in ["default", "render", "init", "start", "run", "boot"]:
                entrypoints.append(func)
                entrypoint_reasons[func] = "exported function"
                continue

            # ============================================================
            # GO ENTRYPOINTS
            # ============================================================

            # HTTP handlers (ServeHTTP, HandleFunc patterns)
            if "servehttp" in func_lower or "handlefunc" in func_lower:
                entrypoints.append(func)
                entrypoint_reasons[func] = "Go HTTP handler"
                continue

            # Handler suffix pattern common in Go
            if simple_name.endswith("handler") or simple_name.startswith("handle"):
                entrypoints.append(func)
                entrypoint_reasons[func] = "Go handler suffix"
                continue

            # gRPC handlers
            if ".pb." in func or "grpc" in func_lower:
                entrypoints.append(func)
                entrypoint_reasons[func] = "gRPC service"
                continue

        # ============================================================
        # FALLBACK: Use functions that are NEVER called (roots)
        # ============================================================
        if not entrypoints:
            # Find functions that are never called by other functions
            all_callees = set()
            for callees in self.call_graph.values():
                all_callees.update(callees)

            app_funcs = [f for f in self.all_functions if f.startswith("app.")]
            root_funcs = [f for f in app_funcs if f not in all_callees]

            if root_funcs:
                # Prioritize by name patterns
                prioritized = sorted(
                    root_funcs,
                    key=lambda f: (
                        0
                        if "main" in f.lower()
                        else (
                            1
                            if "init" in f.lower()
                            else (
                                2
                                if "start" in f.lower()
                                else 3 if "run" in f.lower() else 4 if "app" in f.lower() else 5
                            )
                        )
                    ),
                )
                entrypoints = prioritized[:20]  # Limit
                for ep in entrypoints:
                    entrypoint_reasons[ep] = "root function (never called)"

        # ============================================================
        # FINAL FALLBACK: Use all app functions (limited)
        # ============================================================
        if not entrypoints:
            app_funcs = sorted([f for f in self.all_functions if f.startswith("app.")])
            entrypoints = app_funcs[:15]
            for ep in entrypoints:
                entrypoint_reasons[ep] = "fallback (no entrypoints detected)"

        # Store reasons for debugging
        self._entrypoint_reasons = entrypoint_reasons

        return entrypoints or ["main"]

    def _compute_reachability(self, entrypoints: List[str]):
        """
        BFS from entrypoints to find reachable functions.

        Uses both exact matching and fuzzy matching to handle:
        - Different module prefix formats
        - Cross-module calls without full qualification
        - Library function calls

        Also tracks the call path from entrypoint to each reachable function.
        """
        # Build lookup indexes for faster fuzzy matching
        simple_to_full = {}  # simple_name -> list of full qualified names
        for func in self.all_functions:
            simple = func.split(".")[-1] if "." in func else func
            if simple not in simple_to_full:
                simple_to_full[simple] = []
            simple_to_full[simple].append(func)

        queue = deque(entrypoints)
        visited = set(entrypoints)

        # T-CG1: multi-parent BFS — track ALL parents per function
        # Dict[func, List[str]]; entrypoints map to []
        self.call_parents = {}
        for ep in entrypoints:
            self.call_parents[ep] = []  # entrypoint: no parents

        while queue:
            func = queue.popleft()
            self.reachable_functions.add(func)

            # Get all callees for this function
            callees = self.call_graph.get(func, set())

            for callee in callees:
                if callee in visited:
                    continue

                # Strategy 1: Exact match
                if callee in self.all_functions:
                    visited.add(callee)
                    queue.append(callee)
                    # T-CG1: append to list (multi-parent)
                    if callee not in self.call_parents:
                        self.call_parents[callee] = []
                    if func not in self.call_parents[callee]:
                        self.call_parents[callee].append(func)
                    continue

                # Strategy 2: Fuzzy match by simple name
                simple_callee = callee.split(".")[-1] if "." in callee else callee
                if simple_callee in simple_to_full:
                    # Find best match (prefer same module)
                    caller_module = ".".join(func.split(".")[:-1]) if "." in func else ""
                    candidates = simple_to_full[simple_callee]

                    best_match = None
                    for candidate in candidates:
                        if candidate in visited:
                            continue
                        candidate_module = ".".join(candidate.split(".")[:-1]) if "." in candidate else ""

                        # Same module is best
                        if candidate_module == caller_module:
                            best_match = candidate
                            break
                        # Same top-level (app vs lib) is next best
                        elif candidate.split(".")[0] == func.split(".")[0]:
                            best_match = candidate

                    if best_match is None and candidates:
                        # Just use first non-visited candidate
                        for candidate in candidates:
                            if candidate not in visited:
                                best_match = candidate
                                break

                    if best_match:
                        visited.add(best_match)
                        queue.append(best_match)
                        # T-CG1: append to list (multi-parent)
                        if best_match not in self.call_parents:
                            self.call_parents[best_match] = []
                        if func not in self.call_parents[best_match]:
                            self.call_parents[best_match].append(func)
                        continue

                # Strategy 3: Resolve through imports map
                if callee in self.imports_map:
                    full_name = self.imports_map[callee]
                    if isinstance(full_name, str) and full_name not in visited:
                        visited.add(full_name)
                        queue.append(full_name)
                    elif isinstance(full_name, list):
                        for fn in full_name:
                            if fn not in visited:
                                visited.add(fn)
                                queue.append(fn)

                # Even if we can't resolve, add to visited to avoid reprocessing
                visited.add(callee)

    def get_call_path(self, target_func: str, max_depth: int = 10) -> List[str]:
        """
        T-CG1: Return the SHORTEST path from any entrypoint to target_func.
        Uses multi-parent BFS tree (call_parents: Dict[func, List[str]]).
        Returns [] if function is not in the reachability tree.
        """
        if target_func not in self.call_parents:
            return []
        paths = self.get_all_paths(target_func, max_paths=1, max_depth=max_depth)
        return paths[0] if paths else []

    def get_all_paths(self, target_func: str, max_paths: int = 10, max_depth: int = 12) -> List[List[str]]:
        """
        T-CG1: BFS backward from target_func through multi-parent tree.
        Returns up to max_paths distinct paths from entrypoint → target_func.
        Each path is a List[str] in entrypoint-first order.
        """
        if target_func not in self.call_parents:
            return []

        results = []
        # queue items: (current_node, path_so_far_reversed)
        from collections import deque as _deque

        q = _deque([(target_func, [target_func])])

        while q and len(results) < max_paths:
            node, rev_path = q.popleft()
            if len(rev_path) > max_depth:
                results.append(list(reversed(rev_path)))
                continue
            parents = self.call_parents.get(node, [])
            if not parents:
                # Reached an entrypoint (empty list means root)
                results.append(list(reversed(rev_path)))
                continue
            for parent in parents:
                if parent in rev_path:  # cycle guard
                    continue
                q.append((parent, rev_path + [parent]))

        # Deduplicate while preserving order
        seen = set()
        deduped = []
        for p in results:
            key = tuple(p)
            if key not in seen:
                seen.add(key)
                deduped.append(p)
        return deduped

    def get_call_path_string(self, target_func: str, max_depth: int = 10) -> str:
        """T-CG1: Return the shortest path as 'main → api.handler → target'."""
        path = self.get_call_path(target_func, max_depth)
        if not path:
            return ""
        return " → ".join(path)
