#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.

"""
reachable - Build-Time Vulnerability Reachability Analyzer

Determines which CVEs are actually reachable in your code using static analysis.

Uses:
- AST parsing to build call graphs
- Syft-generated SBOM (dependencies)
- Grype-generated vulnerabilities
- Library source code for deep analysis

Output: Which CVEs are truly exploitable vs unreachable dead code
"""

import warnings

# Suppress urllib3 OpenSSL warning (common on macOS with LibreSSL)
warnings.filterwarnings("ignore", message=".*urllib3 v2 only supports OpenSSL.*")
warnings.filterwarnings("ignore", category=DeprecationWarning, module="urllib3")

import json
import logging
import shutil
import time
from collections import defaultdict
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Set

# Initialize module-level logger
logger = logging.getLogger(__name__)

from ._cve import _CveMixin
from ._export import _ExportMixin
from ._graph import _GraphMixin
from ._malware import _MalwareMixin
from ._parsers import _ParsersMixin
from ._report import _ReportMixin

# =========================================================================
# =========================================================================
from ._secrets import _SecretsMixin
from ._utils import __version__


class ReachabilityAnalyzer(
    _SecretsMixin,
    _MalwareMixin,
    _ParsersMixin,
    _GraphMixin,
    _CveMixin,
    _ExportMixin,
    _ReportMixin,
):
    """
    Reachability analysis engine.

    Methods are organised into focused mixin modules:
      _secrets.py   — secrets scanning & validation
      _malware.py   — malware / suspicious-package detection
      _parsers.py   — AST + ecosystem source parsers
      _graph.py     — call graph construction & BFS traversal
      _cve.py       — CVE mapping, classification, exploitability
      _export.py    — call graph export (JSON / Mermaid / DOT)
      _report.py    — correlation, risk scoring, report generation
    """

    def __init__(
        self,
        app_dir: Path,
        libs_dir: Optional[Path],
        sbom_file: Path,
        vulns_file: Path,
        suppressions_file: Optional[Path] = None,
        verify_secrets: bool = False,
        verbose: bool = False,
        progress_callback=None,
        # Performance optimization flags (v4.4.7)
        skip_secrets: bool = False,
        skip_cwe: bool = False,
        incremental: bool = False,
        # External findings (v4.5.18)
        ai_findings: List = None,
        ai_scan_time: float = 0.0,  # v4.5.39: AI scan timing
        dlp_scan_time: float = 0.0,
    ):  # v4.5.50: DLP scan timing
        self.app_dir = app_dir
        self.libs_dir = libs_dir
        self.sbom_file = sbom_file
        self.vulns_file = vulns_file
        self.suppressions_file = suppressions_file
        self.verify_secrets = verify_secrets  # v2.9.40: Active secret validation
        self.verbose = verbose  # v2.9.52: Control correlation engine verbosity
        self.progress_callback = progress_callback  # v4.4.2: Progress updates

        # Performance optimization flags (v4.4.7)
        self.skip_secrets = skip_secrets
        self.skip_cwe = skip_cwe
        self.incremental = incremental

        # External findings (v4.5.18)
        self.ai_findings = ai_findings or []
        self.ai_scan_time = ai_scan_time  # v4.5.39: AI scan timing
        self.dlp_scan_time = dlp_scan_time  # v4.5.50: DLP scan timing
        self.owasp_findings = []

        # Library cloning metrics (v4.5.41)
        self.lib_cloning_metrics = {
            "enabled": False,
            "total_attempted": 0,
            "total_success": 0,
            "total_failed": 0,
            "mcp_success": 0,
            "mcp_failed": 0,
            "git_success": 0,
            "git_failed": 0,
            "cache_hits": 0,
            "failed_packages": [],
            "obsolete_packages": [],
            "typosquatting_detected": [],
        }

        # Get changed files for incremental mode
        self._changed_files = None
        if incremental:
            self._changed_files = self._get_changed_files()

        # Analysis data structures
        self.call_graph = defaultdict(set)
        self.imports_map = {}
        self.function_imports = defaultdict(set)  # func -> library imports USED
        self.library_imports = defaultdict(set)  # library -> libraries it imports (for transitive tracking)
        self.all_functions = set()
        self.reachable_functions = set()
        self.call_parents = {}  # func -> List[str] of parents (multi-parent BFS, T-CG1)
        self.function_metadata = {}  # func -> {project_tag, file, line} for monorepo filtering
        self.functions_by_language = {
            "Python": set(),
            "JavaScript": set(),
            "Go": set(),
            "Java": set(),
            "Kotlin": set(),
            "Scala": set(),
            "Groovy": set(),
            "Rust": set(),
            "C": set(),
        }
        self.entrypoints = set()  # v4.4.4: Initialize early for Java/Kotlin parsing
        self.entrypoint_details = {}  # v4.4.4: Track entrypoint metadata

        # Get git info for target repo
        self.git_info = self._get_git_info()

        # Load external data
        self.sbom = self._load_json(sbom_file)
        self.vulns = self._load_json(vulns_file)

    # Directories to exclude from source file scanning
    _SKIP_DIRS = {
        "venv",
        ".venv",
        "env",
        ".env",
        "build-venv",
        "node_modules",
        "__pycache__",
        ".pytest_cache",
        ".ruff_cache",
        ".mypy_cache",
        ".git",
        ".hg",
        ".svn",
        "build",
        "dist",
        "sdist",
        "release",
        ".eggs",
        ".tox",
        ".nox",
        "vendor",
        "third_party",
        "third-party",
        "target",  # Rust/Java build output
        "_broken",
    }

    def _is_source_file(self, path: Path) -> bool:
        """Check if file is actual source code (not venv/build/cache junk)"""
        try:
            parts = path.relative_to(self.app_dir).parts
        except ValueError:
            return True  # Outside app_dir (e.g. libs), don't filter
        for part in parts:
            if part in self._SKIP_DIRS or part.endswith(".egg-info"):
                return False
        return True

    def _collect_source_files(self, directory: Path, *patterns) -> list:
        """Collect source files matching patterns, excluding non-source dirs"""
        files = []
        for pattern in patterns:
            for f in directory.rglob(pattern):
                if self._is_source_file(f):
                    files.append(f)
        return files

    def _get_git_info(self) -> Optional[dict]:
        """Get git branch and commit SHA for the target repository"""
        import subprocess

        git_dir = self.app_dir / ".git"
        if not git_dir.exists():
            # Check if parent is a git repo (subdir of repo)
            current = self.app_dir
            while current != current.parent:
                if (current / ".git").exists():
                    break
                current = current.parent
            else:
                return None  # Not a git repo

        try:
            # Get current branch
            branch_result = subprocess.run(
                ["git", "rev-parse", "--abbrev-ref", "HEAD"],
                cwd=str(self.app_dir),
                capture_output=True,
                text=True,
                timeout=5,
            )
            branch = branch_result.stdout.strip() if branch_result.returncode == 0 else None

            # Get commit SHA
            sha_result = subprocess.run(
                ["git", "rev-parse", "HEAD"], cwd=str(self.app_dir), capture_output=True, text=True, timeout=5
            )
            commit_sha = sha_result.stdout.strip() if sha_result.returncode == 0 else None

            # Get short SHA
            short_sha = commit_sha[:8] if commit_sha else None

            # Get commit date
            date_result = subprocess.run(
                ["git", "log", "-1", "--format=%ci"],
                cwd=str(self.app_dir),
                capture_output=True,
                text=True,
                timeout=5,
            )
            commit_date = date_result.stdout.strip() if date_result.returncode == 0 else None

            if branch or commit_sha:
                return {
                    "branch": branch,
                    "commit_sha": commit_sha,
                    "commit_short": short_sha,
                    "commit_date": commit_date,
                }
        except (subprocess.TimeoutExpired, FileNotFoundError, Exception):
            pass

        return None

    def _get_changed_files(self) -> Optional[Set[str]]:
        """Get list of files changed since last commit (for incremental mode)

        v4.4.7: Incremental scanning - only scan files that have changed.

        Returns:
            Set of relative file paths that have changed, or None if not a git repo
        """
        import subprocess

        git_dir = self.app_dir / ".git"
        if not git_dir.exists():
            # Not a git repo - can't do incremental
            logger.info(" Incremental mode requires git repo")
            return None

        try:
            # Get files changed since last commit (staged + unstaged)
            result = subprocess.run(
                ["git", "diff", "--name-only", "HEAD~1"],
                cwd=str(self.app_dir),
                capture_output=True,
                text=True,
                timeout=10,
            )

            if result.returncode != 0:
                # Might be first commit, try diff against empty tree
                result = subprocess.run(
                    ["git", "diff", "--name-only", "--cached"],
                    cwd=str(self.app_dir),
                    capture_output=True,
                    text=True,
                    timeout=10,
                )

            if result.returncode == 0 and result.stdout.strip():
                changed = set(result.stdout.strip().split("\n"))
                logger.info(f" Incremental: {len(changed)} files changed since last commit")
                return changed
            else:
                logger.info(" No changes detected - running full scan")
                return None

        except (subprocess.TimeoutExpired, FileNotFoundError, Exception) as e:
            logger.info(f" Incremental mode failed: {e}")
            return None

    def _clone_vulnerable_libraries(self) -> Path:
        """
        Clone source code for vulnerable libraries (v4.5.41)

        Uses LibraryManager to fetch library source code for reachability analysis.
        Supports MCP (GitHub API) with git clone fallback.

        Returns:
            Path to libs directory (created if needed)
        """

        # Determine libs directory
        if self.libs_dir:
            libs_dir = self.libs_dir
        else:
            # Auto-create libs dir in scan output location
            libs_dir = self.vulns_file.parent / "libs"

        libs_dir.mkdir(parents=True, exist_ok=True)

        # Check if we have vulnerabilities to clone for
        vuln_count = len(self.vulns.get("matches", []))
        if vuln_count == 0:
            logger.info(" No vulnerabilities found - skipping library cloning")
            return libs_dir

        try:
            from reachable.integrations.lib_manager import LibraryManager

            # Initialize manager with global cache
            manager = LibraryManager(libs_dir=libs_dir, enable_discovery=True, verbose=True, use_global_cache=True)

            # Clone vulnerable libraries
            cloned_paths = manager.clone_vulnerable_libraries(self.vulns, verbose=True)

            # Capture metrics
            metrics = manager.metrics
            self.lib_cloning_metrics = {
                "enabled": True,
                "total_attempted": metrics.get("total_attempted", 0),
                "total_success": metrics.get("mcp_success", 0) + metrics.get("git_success", 0),
                "total_failed": metrics.get("total_failed", 0),
                "mcp_success": metrics.get("mcp_success", 0),
                "mcp_failed": metrics.get("mcp_failed", 0),
                "git_success": metrics.get("git_success", 0),
                "git_failed": metrics.get("git_failed", 0),
                "npm_pack_success": metrics.get("npm_pack_success", 0),
                "cache_hits": metrics.get("cache_hits", 0),
                "cache_misses": metrics.get("cache_misses", 0),
                "failed_packages": [],
                "obsolete_packages": metrics.get("obsolete_packages", []),
                "typosquatting_detected": manager.provenance_metrics.get("typosquatting_detected", []),
                "cloned_paths": [str(p) for p in cloned_paths],
                "cleanup_bytes_freed": metrics.get("cleanup_bytes_freed", 0),
            }

            # Extract failed package details
            for pkg, method, success in metrics.get("clone_methods", []):
                if not success:
                    self.lib_cloning_metrics["failed_packages"].append({"package": pkg, "method": method})

            # Update libs_dir reference
            self.libs_dir = libs_dir

            return libs_dir

        except ImportError as e:
            logger.info(f" LibraryManager not available: {e}")
            self.lib_cloning_metrics["enabled"] = False
            return libs_dir
        except Exception as e:
            logger.info(f" Library cloning failed: {e}")
            self.lib_cloning_metrics["enabled"] = True
            self.lib_cloning_metrics["error"] = str(e)
            return libs_dir

    def analyze(self) -> dict:
        """Main analysis pipeline"""
        analysis_start_time = time.time()

        # Track step timings for performance analysis
        step_timings = {}

        # v4.5.39: Include AI scan time if provided
        if self.ai_scan_time > 0:
            step_timings["0_ai_scan"] = self.ai_scan_time

        # Helper for progress updates
        def _progress(step: int, name: str, status: str = "Complete"):
            if self.progress_callback:
                self.progress_callback(step, 14, name, status)

        logger.info(f"REACHABLE - Vulnerability Reachability Analyzer v{__version__}")
        scan_start_timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        logger.info(f" Scan Started: {scan_start_timestamp}")
        logger.info(f" Repository: {self.app_dir}")
        logger.info(f" Repo Name: {self.app_dir.name}")

        # Show git info if available
        if self.git_info:
            logger.info(f" Git Branch: {self.git_info.get('branch', 'N/A')}")
            logger.info(f" Git Commit: {self.git_info.get('commit_short', 'N/A')}")
            if self.git_info.get("commit_date"):
                logger.info(f" Commit Date: {self.git_info.get('commit_date', 'N/A')}")
        # Display language support matrix
        logger.info(" LANGUAGE SUPPORT:")
        logger.info(" Supported (Full Reachability):")
        logger.info("      • Python       - AST parsing, call graph, import tracking")
        logger.info("      • JavaScript   - AST parsing, call graph, require/import tracking")
        logger.info("      • TypeScript   - AST parsing, call graph, import tracking")
        logger.info("      • Go           - AST parsing, call graph, package tracking")
        logger.info("      • Java         - AST parsing, call graph, Maven/Gradle support")
        logger.info("      • Kotlin       - AST parsing, call graph, Android support")
        logger.info("      • Scala        - AST parsing, call graph, SBT partial")
        logger.info("      • Groovy       - AST parsing, call graph, Gradle DSL support")
        logger.info(" Partial Support:")
        logger.info("      • Rust         - Manifest scanning only (no call graph)")
        logger.info("      • Ruby         - Manifest scanning only (no call graph)")
        logger.info(" Not Yet Supported:")
        logger.info("      • C/C++        - Complex build systems, planned for future")
        logger.info("      • C#/.NET      - Planned for future release")
        logger.info("      • PHP          - Planned for future release")
        logger.info(" BUILD SYSTEM SUPPORT:")
        logger.info(" Supported: npm, pip, go mod, Maven (multi-module), Gradle (Groovy + Kotlin DSL)")
        logger.info(" Partial: Bazel, SBT (manifest extraction only)")
        logger.info(" Not Yet: CMake, Meson, Buck")

        # Step 1: Build call graph from app code
        _progress(1, "Call Path", "Parsing...")
        step1_start = time.time()
        timestamp = datetime.now().strftime("%H:%M:%S")
        logger.info(f"[{timestamp}] [1/14] Parsing application code...")
        logger.info(" Tool: Tree-sitter (multi-language AST parser)")
        logger.info(" Action: Building call graph from source code")

        # Count files by type BEFORE parsing (excludes venv, build, node_modules, etc.)
        py_files = self._collect_source_files(self.app_dir, "*.py")
        js_files = self._collect_source_files(self.app_dir, "*.js", "*.ts", "*.jsx", "*.tsx")
        go_files = self._collect_source_files(self.app_dir, "*.go")
        java_files = self._collect_source_files(self.app_dir, "*.java")
        kotlin_files = self._collect_source_files(self.app_dir, "*.kt")
        scala_files = self._collect_source_files(self.app_dir, "*.scala")
        groovy_files = self._collect_source_files(self.app_dir, "*.groovy")
        jvm_files = java_files + kotlin_files + scala_files + groovy_files
        total_files = len(py_files) + len(js_files) + len(go_files) + len(jvm_files)

        # v4.5.3 FIX: Store actual file count for dashboard metrics
        self._source_files_scanned = total_files

        logger.info(f" Scanning: {total_files} source files")
        if py_files:
            logger.info(f" └─ Python: {len(py_files)} files")
        if js_files:
            logger.info(f" └─ JavaScript/TypeScript: {len(js_files)} files")
        if go_files:
            logger.info(f" └─ Go: {len(go_files)} files")
        if jvm_files:
            jvm_detail = []
            if java_files:
                jvm_detail.append(f"Java: {len(java_files)}")
            if kotlin_files:
                jvm_detail.append(f"Kotlin: {len(kotlin_files)}")
            if scala_files:
                jvm_detail.append(f"Scala: {len(scala_files)}")
            if groovy_files:
                jvm_detail.append(f"Groovy: {len(groovy_files)}")
            logger.info(f" └─ JVM: {len(jvm_files)} files ({', '.join(jvm_detail)})")

        # Show scope of analysis
        logger.info(" ANALYSIS SCOPE:")
        logger.info(f" • Target: {self.app_dir.name}/")
        logger.info(" • Mode: UNIFIED CALL GRAPH (all code analyzed together)")
        logger.info(" • Entrypoints: Will auto-detect main() functions")
        logger.info(" • Reachability: Traces from entrypoints → ALL code")

        self._parse_directory(self.app_dir, "app")
        logger.info(" CALL GRAPH BUILT:")

        # Count functions by language using tracked sets
        py_funcs = len(self.functions_by_language.get("Python", set()))
        js_funcs = len(self.functions_by_language.get("JavaScript", set()))
        go_funcs = len(self.functions_by_language.get("Go", set()))
        java_funcs = len(self.functions_by_language.get("Java", set()))
        rust_funcs = len(self.functions_by_language.get("Rust", set()))
        c_funcs = len(self.functions_by_language.get("C", set()))

        logger.info(f" • Total functions: {len(self.all_functions)}")
        if py_funcs > 0:
            logger.info(f" └─ Python: {py_funcs}")
        if js_funcs > 0:
            logger.info(f" └─ JavaScript/TypeScript: {js_funcs}")
        if go_funcs > 0:
            logger.info(f" └─ Go: {go_funcs}")
        if java_funcs > 0:
            logger.info(f" └─ Java: {java_funcs}")
        if rust_funcs > 0:
            logger.info(f" └─ Rust: {rust_funcs}")
        if c_funcs > 0:
            logger.info(f" └─ C/C++: {c_funcs}")

        # Per-project function breakdown (for monorepos)
        funcs_by_project = {}
        for func in self.all_functions:
            if func.startswith("app."):
                parts = func.split(".")
                proj = parts[1] if len(parts) > 2 else "root"
                funcs_by_project[proj] = funcs_by_project.get(proj, 0) + 1

        if len(funcs_by_project) > 1:
            proj_parts = [
                f"{proj}: {count}" for proj, count in sorted(funcs_by_project.items(), key=lambda x: -x[1])[:5]
            ]
            logger.info(f" By Project: {', '.join(proj_parts)}")

        # Store for later use
        self.funcs_by_project = funcs_by_project

        # Call edges with per-project/per-lang breakdown
        total_edges = sum(len(v) for v in self.call_graph.values())
        logger.info(f" • Call edges: {total_edges}")

        edges_by_lang = {
            "Python": 0,
            "JavaScript": 0,
            "Go": 0,
            "Java": 0,
            "Kotlin": 0,
            "Scala": 0,
            "Groovy": 0,
        }
        edges_by_proj = {}
        for caller, callees in self.call_graph.items():
            edge_count = len(callees)
            for lang_name, funcs in self.functions_by_language.items():
                if caller in funcs:
                    edges_by_lang[lang_name] = edges_by_lang.get(lang_name, 0) + edge_count
                    break
            if caller.startswith("app."):
                parts = caller.split(".")
                proj = parts[1] if len(parts) > 2 else "root"
                edges_by_proj[proj] = edges_by_proj.get(proj, 0) + edge_count

        edges_by_lang = {k: v for k, v in edges_by_lang.items() if v > 0}
        if edges_by_lang:
            lang_parts = [f"{lang}: {count}" for lang, count in sorted(edges_by_lang.items(), key=lambda x: -x[1])]
            logger.info(f" By Language: {', '.join(lang_parts)}")
        if len(edges_by_proj) > 1:
            proj_parts = [f"{p}: {c}" for p, c in sorted(edges_by_proj.items(), key=lambda x: -x[1])[:5]]
            logger.info(f" By Project: {', '.join(proj_parts)}")

        # Find and show entrypoints with per-project/per-lang
        entrypoints = self._find_entrypoints()
        if entrypoints:
            logger.info(f" • Entrypoints found: {len(entrypoints)}")

            ep_by_lang = {
                "Python": 0,
                "JavaScript": 0,
                "Go": 0,
                "Java": 0,
                "Kotlin": 0,
                "Scala": 0,
                "Groovy": 0,
            }
            ep_by_proj = {}
            for ep in entrypoints:
                for lang_name, funcs in self.functions_by_language.items():
                    if ep in funcs:
                        ep_by_lang[lang_name] = ep_by_lang.get(lang_name, 0) + 1
                        break
                if ep.startswith("app."):
                    parts = ep.split(".")
                    proj = parts[1] if len(parts) > 2 else "root"
                    ep_by_proj[proj] = ep_by_proj.get(proj, 0) + 1

            ep_by_lang = {k: v for k, v in ep_by_lang.items() if v > 0}
            if ep_by_lang:
                lang_parts = [f"{lang}: {count}" for lang, count in sorted(ep_by_lang.items(), key=lambda x: -x[1])]
                logger.info(f" By Language: {', '.join(lang_parts)}")
            if len(ep_by_proj) > 1:
                proj_parts = [f"{p}: {c}" for p, c in sorted(ep_by_proj.items(), key=lambda x: -x[1])[:5]]
                logger.info(f" By Project: {', '.join(proj_parts)}")

            logger.info(f" {', '.join(entrypoints[:5])}{' ...' if len(entrypoints) > 5 else ''}")
        else:
            logger.info(" No explicit entrypoints (main) - using ALL functions as potential roots")

        # Save app imports before library parsing might add conflicting imports
        self.app_imports = dict(self.imports_map)

        step1_elapsed = time.time() - step1_start
        step_timings["1_parse_app"] = step1_elapsed
        _progress(1, "Call Path", f"{len(self.all_functions)} functions")
        logger.info(f" Completed in {step1_elapsed:.1f}s")

        # T9/T-CG15: JS/TS Joern callgraph (runs async after internal parse)
        # Output: raw/call-graph-js.json — consumed by normalizers/cve.py
        if js_files:
            try:
                from reachable.collectors.callgraph.js_collector import JSCallGraphCollector

                output_dir = self.vulns_file.parent
                commit_sha = (self.git_info or {}).get("commit_sha", "")
                _js_collector = JSCallGraphCollector()
                _js_cg_file = _js_collector.collect(
                    src_dir=self.app_dir,
                    output_dir=output_dir,
                    commit_sha=commit_sha,
                )
                if _js_cg_file:
                    tier = _js_collector.tier or "unknown"
                    logger.info(f" JS callgraph ({tier}): {_js_cg_file.name}")
                else:
                    logger.debug(" JS callgraph: skipped (Joern + Node.js not available)")
            except Exception as _js_err:
                import traceback

                logger.info(f" JS callgraph error: {_js_err}\n{traceback.format_exc()}")

        # Step 2: Scan for hardcoded secrets AND code weaknesses (Semgrep)
        _progress(2, "Secrets/CWE", "Scanning...")
        step2_start = time.time()
        timestamp = datetime.now().strftime("%H:%M:%S")

        # v4.4.7: Performance optimization - skip secrets/CWE if requested
        secrets_findings = None
        if self.skip_secrets and self.skip_cwe:
            logger.info(f"[{timestamp}] [2/14] Skipping secrets and CWE scanning (--quick mode)")
            logger.info(" Skipped: Semgrep secrets + CWE rules")
            logger.info(" Tip: Remove --quick for full scan")
            secrets_findings = {"findings": [], "total_findings": 0, "skipped": True}
        elif self.skip_secrets:
            logger.info(f"[{timestamp}] [2/14] Scanning for code weaknesses only (--skip-secrets)")
            logger.info(" Tool: Semgrep (CWE rules only)")
            logger.info(" Skipped: Secrets scanning")
            logger.info(f" Scanning: {total_files} source files")
            secrets_findings = self._scan_for_secrets(skip_secrets=True)  # Only CWE
        elif self.skip_cwe:
            logger.info(f"[{timestamp}] [2/14] Scanning for secrets only (--skip-cwe)")
            logger.info(" Tool: Semgrep (secrets rules only)")
            logger.info(" Skipped: CWE/SAST scanning")
            logger.info(f" Scanning: {total_files} source files")
            secrets_findings = self._scan_for_secrets(skip_cwe=True)  # Only secrets
        else:
            logger.info(f"[{timestamp}] [2/14] Scanning for secrets and code weaknesses...")
            logger.info(" Tool: Semgrep (secrets + CWE rules)")

            # Check TruffleHog availability (with Homebrew PATH fallback)
            trufflehog_available = shutil.which("trufflehog") is not None
            if not trufflehog_available:
                # Fallback: check common Homebrew/system paths not in Python's PATH
                for _candidate in ["/opt/homebrew/bin/trufflehog", "/usr/local/bin/trufflehog"]:
                    if Path(_candidate).is_file():
                        trufflehog_available = True
                        break
            if trufflehog_available:
                logger.info(" TruffleHog: Available (active secret verification + Git history)")
                # Auto-enable verification when TruffleHog is available
                if not self.verify_secrets:
                    self.verify_secrets = True
            else:
                logger.info(" TruffleHog: Not installed - limited secret detection")
                logger.info("                    • Cannot verify if secrets are active/inactive")
                logger.info("                    • Cannot scan Git history for deleted secrets")

            logger.info(" Action: Detecting credentials and code security weaknesses")
            logger.info(f" Scanning: {total_files} source files")
            secrets_findings = self._scan_for_secrets()

        # ═══════════════════════════════════════════════════════════════════════
        # ENHANCED: Also run EnvSecretsScanner for .env files and configs
        # This catches secrets that Semgrep misses (OAuth, Hydra, Kratos, etc.)
        # ═══════════════════════════════════════════════════════════════════════
        env_secrets = self._scan_env_secrets()
        if env_secrets and env_secrets.get("findings"):
            logger.info(f" ENV Scanner: {len(env_secrets.get('findings', []))} secrets in .env/configs")
            # Merge env secrets into main findings
            if not secrets_findings:
                secrets_findings = {"findings": [], "total_findings": 0}

            for finding in env_secrets.get("findings", []):
                # Convert EnvSecretsScanner format to Semgrep format
                secrets_findings["findings"].append(
                    {
                        "rule_id": f"env-{finding.get('secret_type', 'secret')}",
                        "check_id": f"reachable.env.{finding.get('secret_type', 'secret')}",
                        "severity": finding.get("severity", "ERROR"),
                        "message": finding.get("description", "Secret detected in environment file"),
                        "path": finding.get("file_path", ""),
                        "file": finding.get("file_path", ""),
                        "line": finding.get("line_number", 0),
                        "snippet": finding.get("value_preview", ""),
                        "type": finding.get("secret_type", "generic"),
                        "is_actual_secret": True,  # All env findings are real secrets
                        "finding_type": "SECRET",
                        "source": "EnvSecretsScanner",
                        "key_name": finding.get("key", ""),
                        "remediation": finding.get("remediation", []),
                    }
                )
            secrets_findings["total_findings"] = len(secrets_findings.get("findings", []))

        if secrets_findings:
            total = secrets_findings.get("total_findings", 0)
            findings_list = secrets_findings.get("findings", [])

            if total > 0:
                # Separate actual secrets (SEC-XXX) from CWE findings (code weaknesses)
                # DEFAULT to False - if not explicitly marked as secret, it's a CWE finding
                actual_secrets = [f for f in findings_list if f.get("is_actual_secret", False)]
                cwe_findings = [f for f in findings_list if not f.get("is_actual_secret", False)]

                # v4.3.1 FIX: Count CRITICAL secrets properly (was checking for 'ERROR')
                # Also count UNKNOWN as CRITICAL per security principle
                secret_critical = 0
                for f in actual_secrets:
                    severity = f.get("severity", "").upper()
                    reachability = f.get("reachability_confidence", "")

                    # Count as critical if:
                    # 1. Severity is CRITICAL or ERROR
                    # 2. OR it's HIGH severity with UNKNOWN reachability (v4.3.1 fix)
                    if severity in ["CRITICAL", "ERROR"]:
                        secret_critical += 1
                    elif severity == "HIGH" and reachability in ["UNKNOWN", "UNKNOWN_EXPLOITABLE"]:
                        secret_critical += 1  # v4.3.1: Unknown = treat as critical
                # v4.3.1 FIX: Count CRITICAL properly (was checking for 'ERROR')
                cwe_critical = sum(1 for f in cwe_findings if f.get("severity", "").upper() in ["CRITICAL", "ERROR"])

                # Classify CWE findings by policy ID
                def classify_cwe_policy(rule_id, message=""):
                    """Classify finding to CWE policy ID

                    v2.9.61: Improved classification with explicit rule pattern matching
                    to avoid misclassification (e.g., Dockerfile USER -> CWE-250, not CWE-022)
                    """
                    rule_lower = rule_id.lower()
                    text = (rule_id + " " + message).lower()

                    # ===== EXPLICIT RULE PATTERN MATCHING (highest priority) =====
                    # These patterns match specific Semgrep rule IDs to ensure correct CWE

                    # Dockerfile/container privilege issues -> CWE-250
                    if "dockerfile" in rule_lower and ("missing-user" in rule_lower or "run-as-root" in rule_lower):
                        return "CWE-250"
                    if "container" in rule_lower and ("root" in rule_lower or "privilege" in rule_lower):
                        return "CWE-250"

                    # Kubernetes/K8s privilege issues -> CWE-250
                    if ("k8s" in rule_lower or "kubernetes" in rule_lower) and "privilege" in rule_lower:
                        return "CWE-250"

                    # Direct ResponseWriter writes (Go) - check if XSS is actually possible
                    # This is often a false positive when writing non-user data like JWKS
                    if "no-direct-write-to-responsewriter" in rule_lower:
                        # Only flag as XSS if message suggests user input
                        if any(x in text for x in ["user input", "untrusted", "request", "query", "param"]):
                            return "CWE-079"
                        return "CWE-016"  # Downgrade to config issue (potential false positive)

                    # Open redirect checks - if code has URL validation, this may be a false positive
                    if "open-redirect" in rule_lower:
                        return "CWE-601"

                    # Cookie security checks
                    if "cookie-missing-secure" in rule_lower or "cookie-missing-httponly" in rule_lower:
                        return "CWE-614"

                    # ===== TEXT-BASED CLASSIFICATION (fallback) =====

                    # Container/Docker privilege escalation (check BEFORE path-traversal)
                    if any(
                        x in text
                        for x in [
                            "missing-user",
                            "run as root",
                            "runs as root",
                            "privileged container",
                            "securitycontext",
                            "allowprivilegeescalation",
                        ]
                    ):
                        return "CWE-250"

                    # Injection vulnerabilities
                    if any(x in text for x in ["xss", "cross-site scripting", "script-injection", "reflected"]):
                        return "CWE-079"
                    elif any(x in text for x in ["sql", "sqli", "sql-injection", "sqlalchemy"]):
                        return "CWE-089"
                    elif any(x in text for x in ["command-injection", "shell-injection", "os-command", "subprocess"]):
                        return "CWE-078"
                    elif any(x in text for x in ["code-injection", "eval(", "exec(", "compile("]):
                        return "CWE-094"

                    # Access control
                    elif any(x in text for x in ["path-traversal", "directory-traversal", "lfi", "rfi", "../"]):
                        return "CWE-022"
                    elif any(x in text for x in ["csrf", "cross-site-request", "forgery"]):
                        return "CWE-352"
                    elif any(x in text for x in ["redirect", "open-redirect", "url redirect"]):
                        return "CWE-601"

                    # Crypto
                    elif any(x in text for x in ["md5", "sha1", "weak-hash", "weak hash"]):
                        return "CWE-328"
                    elif any(x in text for x in ["broken crypto", "des", "rc4", "weak cipher"]):
                        return "CWE-327"
                    elif any(x in text for x in ["random", "predictable", "insecure random"]):
                        return "CWE-330"

                    # Deserialization
                    elif any(x in text for x in ["deserial", "pickle", "yaml.load", "unserialize", "marshal"]):
                        return "CWE-502"

                    # SSRF
                    elif any(x in text for x in ["ssrf", "server-side-request", "request forgery"]):
                        return "CWE-918"

                    # Privilege/permission issues (general)
                    elif any(x in text for x in ["privileged", "root user", "excessive privilege"]):
                        return "CWE-250"
                    elif any(x in text for x in ["permission", "chmod", "file mode", "0777"]):
                        return "CWE-732"

                    # Cookie security
                    elif any(x in text for x in ["cookie", "httponly", "secure flag"]):
                        return "CWE-614"

                    # Configuration
                    elif any(x in text for x in ["debug mode", "debug=true", "development mode"]):
                        return "CWE-016"

                    # Logging
                    elif any(x in text for x in ["log-injection", "sensitive-log", "password in log"]):
                        return "CWE-532"
                    elif any(x in text for x in ["missing log", "no audit", "insufficient logging"]):
                        return "CWE-778"

                    # Input validation
                    elif any(x in text for x in ["validation", "untrusted", "taint", "user input"]):
                        return "CWE-020"
                    elif any(x in text for x in ["dangerous function", "unsafe", "banned function"]):
                        return "CWE-676"

                    return "CWE-016"  # Default to misconfiguration

                # Assign CWE IDs to findings
                cwe_by_id = {}
                for finding in cwe_findings:
                    rule_id = finding.get("rule_id", "")
                    message = finding.get("message", "")
                    cwe_id = classify_cwe_policy(rule_id, message)
                    finding["cwe_id"] = cwe_id
                    cwe_by_id[cwe_id] = cwe_by_id.get(cwe_id, 0) + 1

                # Store for later analysis
                self._cwe_findings = cwe_findings
                self._actual_secrets = actual_secrets
                self._cwe_by_id = cwe_by_id
                logger.info(" SECURITY ISSUES:")
                logger.info(" ┌──────────────────────┬───────┬──────────┐")
                logger.info(f" │ {'Category':<20} │ {'Count':>5} │ {'Critical':>8} │")
                logger.info(" ├──────────────────────┼───────┼──────────┤")
                logger.info(f" │ {'SEC-XXX (secrets)':<20} │ {len(actual_secrets):>5} │ {secret_critical:>8} │")
                logger.info(f" │ {'CWE-XXX (code)':<20} │ {len(cwe_findings):>5} │ {cwe_critical:>8} │")
                logger.info(" └──────────────────────┴───────┴──────────┘")

                # v4.3.1: Show SEC breakdown for secrets (like CWE breakdown)
                if actual_secrets:
                    logger.info(" SEC ISSUES BY POLICY:")
                    sec_counts = {}
                    for secret in actual_secrets:
                        msg = secret.get("message", "").lower()
                        file_path = secret.get("file", "").lower()

                        # Classify secret by type
                        if "api" in msg or "token" in msg:
                            policy = ("SEC-001", "API Keys & Tokens")
                        elif "private" in msg or "key" in msg or ".pem" in file_path:
                            policy = ("SEC-002", "Private Keys & Certificates")
                        elif "database" in msg or "postgres" in msg:
                            policy = ("SEC-003", "Database Credentials")
                        elif "password" in msg:
                            policy = ("SEC-004", "Passwords")
                        else:
                            policy = ("SEC-005", "Other Secrets")

                        sec_counts[policy] = sec_counts.get(policy, 0) + 1

                    for (policy_id, desc), count in sorted(sec_counts.items()):
                        logger.info(f" • {policy_id}: {count:>3} - {desc}")

                # Show CWE breakdown by policy ID
                if cwe_by_id:
                    logger.info(" CWE ISSUES BY POLICY:")
                    # CWE names mapping
                    cwe_names = {
                        "CWE-079": "Cross-site Scripting (XSS)",
                        "CWE-089": "SQL Injection",
                        "CWE-078": "OS Command Injection",
                        "CWE-094": "Code Injection",
                        "CWE-022": "Path Traversal",
                        "CWE-352": "CSRF",
                        "CWE-601": "Open Redirect",
                        "CWE-327": "Broken Crypto Algorithm",
                        "CWE-328": "Weak Hash",
                        "CWE-330": "Insufficient Randomness",
                        "CWE-502": "Insecure Deserialization",
                        "CWE-918": "SSRF",
                        "CWE-016": "Configuration Weakness",
                        "CWE-250": "Unnecessary Privileges",
                        "CWE-732": "Incorrect Permissions",
                        "CWE-614": "Insecure Cookie",
                        "CWE-778": "Insufficient Logging",
                        "CWE-532": "Sensitive Info in Log",
                        "CWE-020": "Input Validation",
                        "CWE-676": "Dangerous Function",
                    }
                    for cwe_id, count in sorted(cwe_by_id.items(), key=lambda x: -x[1])[:8]:
                        name = cwe_names.get(cwe_id, "Unknown")[:28]
                        logger.info(f" • {cwe_id}: {count:>3} - {name}")

                # Calculate compliance violations
                compliance_violations = {
                    "OWASP": 0,
                    "PCI-DSS": 0,
                    "SOC2": 0,
                    "NIST-800-53": 0,
                    "CWE-TOP-25": 0,
                    "HIPAA": 0,
                    "FEDRAMP": 0,
                    "CMMC": 0,
                    "NIST-800-171": 0,
                    "DISA-STIG": 0,
                    "FISMA": 0,
                    "ISO27001": 0,
                }

                # OWASP mapping
                owasp_cwe = {
                    "A01:2021": ["CWE-022", "CWE-352", "CWE-601"],
                    "A02:2021": ["CWE-327", "CWE-328", "CWE-330"],
                    "A03:2021": ["CWE-079", "CWE-089", "CWE-078", "CWE-094", "CWE-020"],
                    "A05:2021": ["CWE-016", "CWE-250", "CWE-732", "CWE-614"],
                    "A08:2021": ["CWE-502"],
                    "A09:2021": ["CWE-778", "CWE-532"],
                    "A10:2021": ["CWE-918"],
                }
                for owasp_cat, cwes in owasp_cwe.items():
                    for cwe in cwes:
                        if cwe in cwe_by_id:
                            compliance_violations["OWASP"] += cwe_by_id[cwe]

                # PCI-DSS mapping (6.5.x controls)
                pci_cwes = ["CWE-079", "CWE-089", "CWE-078", "CWE-094", "CWE-327", "CWE-328", "CWE-502"]
                for cwe in pci_cwes:
                    if cwe in cwe_by_id:
                        compliance_violations["PCI-DSS"] += cwe_by_id[cwe]

                # SOC 2 mapping
                soc2_cwes = ["CWE-022", "CWE-352", "CWE-016", "CWE-250", "CWE-778"]
                for cwe in soc2_cwes:
                    if cwe in cwe_by_id:
                        compliance_violations["SOC2"] += cwe_by_id[cwe]

                # NIST 800-53 mapping
                nist_cwes = ["CWE-079", "CWE-089", "CWE-078", "CWE-327", "CWE-502", "CWE-020"]
                for cwe in nist_cwes:
                    if cwe in cwe_by_id:
                        compliance_violations["NIST-800-53"] += cwe_by_id[cwe]

                # CWE Top 25 (most common)
                top25_cwes = [
                    "CWE-079",
                    "CWE-089",
                    "CWE-078",
                    "CWE-022",
                    "CWE-352",
                    "CWE-502",
                    "CWE-918",
                    "CWE-020",
                ]
                for cwe in top25_cwes:
                    if cwe in cwe_by_id:
                        compliance_violations["CWE-TOP-25"] += cwe_by_id[cwe]

                # HIPAA mapping
                hipaa_cwes = ["CWE-022", "CWE-352", "CWE-327", "CWE-328", "CWE-778", "CWE-532", "CWE-502"]
                for cwe in hipaa_cwes:
                    if cwe in cwe_by_id:
                        compliance_violations["HIPAA"] += cwe_by_id[cwe]

                # FedRAMP mapping (US Federal)
                fedramp_cwes = [
                    "CWE-079",
                    "CWE-089",
                    "CWE-078",
                    "CWE-327",
                    "CWE-328",
                    "CWE-330",
                    "CWE-250",
                    "CWE-778",
                    "CWE-020",
                ]
                for cwe in fedramp_cwes:
                    if cwe in cwe_by_id:
                        compliance_violations["FEDRAMP"] += cwe_by_id[cwe]

                # CMMC 2.0 mapping (DoD)
                cmmc_cwes = [
                    "CWE-022",
                    "CWE-352",
                    "CWE-327",
                    "CWE-328",
                    "CWE-330",
                    "CWE-250",
                    "CWE-732",
                    "CWE-778",
                    "CWE-918",
                ]
                for cwe in cmmc_cwes:
                    if cwe in cwe_by_id:
                        compliance_violations["CMMC"] += cwe_by_id[cwe]

                # NIST 800-171 mapping (DoD Contractors)
                nist171_cwes = [
                    "CWE-022",
                    "CWE-352",
                    "CWE-327",
                    "CWE-328",
                    "CWE-250",
                    "CWE-732",
                    "CWE-778",
                    "CWE-918",
                    "CWE-601",
                ]
                for cwe in nist171_cwes:
                    if cwe in cwe_by_id:
                        compliance_violations["NIST-800-171"] += cwe_by_id[cwe]

                # DISA STIG mapping (Defense)
                stig_cwes = [
                    "CWE-079",
                    "CWE-089",
                    "CWE-078",
                    "CWE-020",
                    "CWE-614",
                    "CWE-352",
                    "CWE-022",
                    "CWE-250",
                    "CWE-327",
                    "CWE-532",
                ]
                for cwe in stig_cwes:
                    if cwe in cwe_by_id:
                        compliance_violations["DISA-STIG"] += cwe_by_id[cwe]

                # FISMA mapping (Federal)
                fisma_cwes = [
                    "CWE-022",
                    "CWE-352",
                    "CWE-250",
                    "CWE-778",
                    "CWE-532",
                    "CWE-016",
                    "CWE-327",
                    "CWE-918",
                    "CWE-020",
                ]
                for cwe in fisma_cwes:
                    if cwe in cwe_by_id:
                        compliance_violations["FISMA"] += cwe_by_id[cwe]

                # ISO 27001 mapping (International - Annex A controls)
                # A.8 Asset Management, A.12 Operations Security, A.14 System Acquisition
                iso27001_cwes = [
                    "CWE-022",
                    "CWE-079",
                    "CWE-089",
                    "CWE-078",
                    "CWE-327",
                    "CWE-328",
                    "CWE-250",
                    "CWE-732",
                    "CWE-778",
                    "CWE-532",
                    "CWE-352",
                    "CWE-918",
                    "CWE-020",
                    "CWE-502",
                ]
                for cwe in iso27001_cwes:
                    if cwe in cwe_by_id:
                        compliance_violations["ISO27001"] += cwe_by_id[cwe]

                # Add secrets to relevant standards
                if actual_secrets:
                    secret_count = len(actual_secrets)
                    compliance_violations["OWASP"] += secret_count  # A07:2021 Auth Failures
                    compliance_violations["PCI-DSS"] += secret_count  # 8.3.1 Authentication
                    compliance_violations["SOC2"] += secret_count  # CC6.1 Access Security
                    compliance_violations["NIST-800-53"] += secret_count  # IA-5 Authenticator Management
                    compliance_violations["CWE-TOP-25"] += secret_count  # CWE-798 Hardcoded Creds
                    compliance_violations["HIPAA"] += secret_count  # 164.312(a)(1) Access Control
                    compliance_violations["FEDRAMP"] += secret_count  # IA-5 Authenticator Management
                    compliance_violations["CMMC"] += secret_count  # IA.L1-3.5.1 Identification
                    compliance_violations["NIST-800-171"] += secret_count  # 3.5.1 Identification
                    compliance_violations["DISA-STIG"] += secret_count  # APP-SEC-3 Authentication
                    compliance_violations["FISMA"] += secret_count  # IA Identification
                    compliance_violations["ISO27001"] += secret_count  # A.9.4.3 Password Management

                # Store for report
                self._compliance_violations = {k: v for k, v in compliance_violations.items() if v > 0}

                # Show compliance violations summary (organized by sector)
                active_violations = {k: v for k, v in compliance_violations.items() if v > 0}
                if active_violations:
                    logger.info(" COMPLIANCE VIOLATIONS:")
                    # Industry standards
                    industry = ["OWASP", "PCI-DSS", "SOC2", "HIPAA", "CWE-TOP-25", "ISO27001"]
                    industry_viols = [(k, v) for k, v in active_violations.items() if k in industry]
                    if industry_viols:
                        logger.info("      Industry:")
                        for std, count in sorted(industry_viols, key=lambda x: -x[1]):
                            logger.info(f" • {std}: {count}")
                    # US Federal/Defense standards
                    federal = ["NIST-800-53", "FEDRAMP", "FISMA", "CMMC", "NIST-800-171", "DISA-STIG"]
                    federal_viols = [(k, v) for k, v in active_violations.items() if k in federal]
                    if federal_viols:
                        logger.info("      US Federal/Defense:")
                        for std, count in sorted(federal_viols, key=lambda x: -x[1]):
                            logger.info(f" • {std}: {count}")

                # Per-language breakdown
                def get_lang_from_path(file_path):
                    fp = file_path.lower()
                    if fp.endswith((".py", ".pyx", ".pyi")):
                        return "Python"
                    elif fp.endswith((".js", ".ts", ".jsx", ".tsx", ".mjs", ".cjs", ".vue")):
                        return "JavaScript"
                    elif fp.endswith(".go"):
                        return "Go"
                    elif fp.endswith((".java", ".kt", ".scala")):
                        return "Java"
                    elif fp.endswith((".yml", ".yaml")):
                        return "YAML"
                    elif "dockerfile" in fp:
                        return "Docker"
                    elif fp.endswith((".c", ".cpp", ".h")):
                        return "C/C++"
                    return "Other"

                findings_by_lang = {}
                for finding in cwe_findings + actual_secrets:
                    file_path = finding.get("file", "") or finding.get("path", "")
                    if file_path:
                        lang = get_lang_from_path(file_path)
                        findings_by_lang[lang] = findings_by_lang.get(lang, 0) + 1

                if findings_by_lang:
                    logger.info(" BY LANGUAGE:")
                    lang_parts = [
                        f"{lang}: {count}" for lang, count in sorted(findings_by_lang.items(), key=lambda x: -x[1])[:5]
                    ]
                    logger.info(f" {', '.join(lang_parts)}")

            else:
                logger.info(" No security issues detected")
        step2_elapsed = time.time() - step2_start
        step_timings["2_secrets"] = step2_elapsed
        _progress(2, "Secrets/CWE", "Complete")
        logger.info(f" Completed in {step2_elapsed:.1f}s")

        # Step 3: Parse library code if available
        _progress(3, "Library Parsing", "Scanning...")
        step3_start = time.time()
        timestamp = datetime.now().strftime("%H:%M:%S")
        if self.libs_dir and self.libs_dir.exists():
            logger.info(f"[{timestamp}] [3/14] Parsing library code...")
            logger.info(" Tool: Tree-sitter (multi-language AST parser)")
            logger.info(" Action: Building library dependency graph (transitive tracking)")

            # Count lib files
            lib_file_count = sum(
                1 for _ in self.libs_dir.rglob("*") if _.is_file() and _.suffix in [".py", ".js", ".ts", ".go", ".java"]
            )
            logger.info(f" Scanning: {lib_file_count} library source files")

            lib_funcs_before = len(self.all_functions)
            js_before = len(self.functions_by_language.get("JavaScript", set()))
            go_before = len(self.functions_by_language.get("Go", set()))
            py_before = len(self.functions_by_language.get("Python", set()))

            self._parse_directory(self.libs_dir, "lib", is_library=True)

            lib_funcs_added = len(self.all_functions) - lib_funcs_before
            js_added = len(self.functions_by_language.get("JavaScript", set())) - js_before
            go_added = len(self.functions_by_language.get("Go", set())) - go_before
            py_added = len(self.functions_by_language.get("Python", set())) - py_before

            # Build transitive dependency graph
            transitive_count = self._build_transitive_graph()

            logger.info(f" Added {lib_funcs_added} library functions")
            # Show breakdown
            lang_parts = []
            if js_added > 0:
                lang_parts.append(f"JavaScript: {js_added}")
            if go_added > 0:
                lang_parts.append(f"Go: {go_added}")
            if py_added > 0:
                lang_parts.append(f"Python: {py_added}")
            if lang_parts:
                logger.info(f" By Language: {', '.join(lang_parts)}")
            logger.info(f" Built transitive graph: {transitive_count} library dependencies")
            step3_elapsed = time.time() - step3_start
            step_timings["3_parse_libs"] = step3_elapsed
            _progress(3, "Library Parsing", "Complete")
            logger.info(f" Completed in {step3_elapsed:.1f}s")
        else:
            logger.info(f"[{timestamp}] [3/14] Skipping library parsing (no libs directory)")
            step3_elapsed = time.time() - step3_start
            step_timings["3_parse_libs"] = step3_elapsed
            _progress(3, "Library Parsing", "Skipped")
            logger.info(f" Completed in {step3_elapsed:.1f}s")

        # Step 4: Scan for malicious packages (GuardDog)
        _progress(4, "Malware Scan", "Scanning...")
        step4_start = time.time()
        timestamp = datetime.now().strftime("%H:%M:%S")
        logger.info(f"[{timestamp}] [4/14] Scanning packages for malware...")
        logger.info(" TIER 1: GuardDog (NPM/PyPI package scanner)")
        logger.info(" Policy: Detect typosquatting, code execution, data exfiltration")
        malware_detections = self._scan_for_malware()

        tier3_triggered = False
        if malware_detections:
            malicious = sum(1 for d in malware_detections.values() if d.is_malicious)
            # Check if Tier 3 was triggered
            tier3_count = sum(
                1 for d in malware_detections.values() if hasattr(d, "deep_scan_results") and d.deep_scan_results
            )
            if tier3_count > 0:
                tier3_triggered = True

            # Build per-language breakdown for ALL scanned packages
            scanned_by_lang = {}
            mal_by_lang = {}
            for pkg_name, det in malware_detections.items():
                pkg = pkg_name.lower()
                if any(x in pkg for x in ["golang.org", "github.com/", "k8s.io"]):
                    lang = "Go"
                elif pkg.startswith("@") or any(x in pkg for x in ["lodash", "react", "next", "express", "webpack"]):
                    lang = "JavaScript"
                elif "-" in pkg and "." not in pkg and "/" not in pkg:
                    lang = "JavaScript"
                elif any(x in pkg for x in ["requests", "flask", "django", "numpy"]):
                    lang = "Python"
                else:
                    lang = "Other"
                scanned_by_lang[lang] = scanned_by_lang.get(lang, 0) + 1
                if det.is_malicious:
                    mal_by_lang[lang] = mal_by_lang.get(lang, 0) + 1

            if malicious > 0:
                logger.info(f" GuardDog: Found {malicious} potentially malicious packages!")
                if mal_by_lang:
                    lang_parts = [f"{lang}: {c}" for lang, c in sorted(mal_by_lang.items(), key=lambda x: -x[1])]
                    logger.info(f" By Language: {', '.join(lang_parts)}")
            else:
                logger.info(f" GuardDog: No malware detected in {len(malware_detections)} packages")
                if scanned_by_lang:
                    lang_parts = [f"{lang}: {c}" for lang, c in sorted(scanned_by_lang.items(), key=lambda x: -x[1])]
                    logger.info(f" By Language: {', '.join(lang_parts)}")

        # Step 4b: Scan for malware patterns in code (Semgrep)
        logger.info(" TIER 2: Semgrep CWE (code pattern analysis)")
        logger.info(" Policy: Detect obfuscation, backdoors, crypto miners")
        semgrep_malware = self._scan_code_for_malware_patterns()
        if semgrep_malware and semgrep_malware.get("total_patterns", 0) > 0:
            verdict = semgrep_malware.get("verdict", "CLEAN")
            total = semgrep_malware.get("total_patterns", 0)
            risk = semgrep_malware.get("risk_score", 0)

            if verdict == "MALICIOUS":
                logger.info(f" Semgrep: MALICIOUS code patterns! ({total} patterns, risk: {risk}/100)")
            elif verdict == "LIKELY_MALICIOUS":
                logger.info(f" Semgrep: LIKELY MALICIOUS patterns ({total} patterns, risk: {risk}/100)")
            elif verdict == "SUSPICIOUS":
                logger.info(f" Semgrep: Suspicious patterns ({total} patterns, risk: {risk}/100)")
            else:
                logger.info(f" Semgrep: {total} informational patterns (risk: {risk}/100)")
        else:
            logger.info(" Semgrep: No malicious code patterns detected")

        # Step 4b2: YARA Signature Scanner (v4.6.10)
        logger.info(" TIER 2b: YARA Signature Scanner (EICAR, shellcode, supply chain)")
        yara_results = None
        self._yara_results = None
        try:
            from reachable.collectors.malware.yara import get_signature_report, scan_directory

            yara_scan = scan_directory(str(self.app_dir))
            yara_results = get_signature_report(yara_scan)
            if yara_scan.findings:
                logger.info(f" YARA: {len(yara_scan.findings)} signature match(es) — verdict: {yara_scan.verdict}")
                for match in yara_scan.findings[:5]:  # Show first 5
                    logger.info(f"   └─ {match.severity}: {match.description} in {Path(match.file).name}")
                if len(yara_scan.findings) > 5:
                    logger.info(f"   └─ ...and {len(yara_scan.findings) - 5} more")
            else:
                logger.info(
                    f" YARA: Clean ({yara_scan.files_scanned} files, {yara_scan.binaries_found} binaries scanned)"
                )
            if yara_scan.high_entropy_files:
                logger.info(f" Entropy: {len(yara_scan.high_entropy_files)} high-entropy file(s) detected")
                for ef in yara_scan.high_entropy_files[:3]:
                    logger.info(f"   └─ {Path(ef['file']).name}: entropy {ef['entropy']}/8.0 ({ef['verdict']})")
        except Exception as e:
            logger.info(f" YARA scanner error: {e}")
        self._yara_results = yara_results

        # Step 4c: Show Tier 3 if it was triggered
        if tier3_triggered:
            logger.info(" TIER 3: Deep Scanner (Entropy + AST)")
            logger.info(" Policy: Detect encrypted payloads, unpacker logic")
            logger.info(f" Activated: {tier3_count} packages analyzed (obfuscation detected)")
            logger.info(" Status: See detailed results in malware.json")

        # Step 4d: Sandbox behavioral testing (Docker-based)
        # v2.9.47: Test ALL packages by default (batch first, individual if suspicious)
        # This catches malware that static analysis misses (credential theft, network exfil)
        sandbox_results = None

        # Note: Sandbox is run from cli.py after analyze() completes
        # This placeholder indicates sandbox will run (or was skipped via --no-sandbox)
        sandbox_results = {
            "policy_id": "MALWARE-003",
            "policy_name": "Behavioral Anomaly Detection",
            "scanner": "DevNull Malware Sandbox",
            "verdict": "PENDING",
            "reason": "Sandbox runs after analysis (see cli.py)",
            "packages_tested": 0,
            "findings": [],
            "_note": "Sandbox executes ALL packages in batch mode, then individual tests if suspicious activity detected",
        }

        # Show what will happen
        if self.sbom and "artifacts" in self.sbom:
            npm_pip_count = sum(
                1
                for a in self.sbom["artifacts"]
                if a.get("type", "").lower() in ("npm", "node", "pip", "pypi", "python")
            )
            if npm_pip_count > 0:
                logger.info(f" TIER 4: Malware Sandbox (will test {npm_pip_count} npm/pip packages)")
                logger.info(" Policy: Detect credential theft, network exfil, env harvesting")
                logger.info(" Strategy: Batch test first → individual tests if suspicious")
            else:
                logger.info(" TIER 4: Malware Sandbox (no npm/pip packages to test)")
                sandbox_results["verdict"] = "SKIPPED"
                sandbox_results["reason"] = "No npm/pip packages in SBOM"

        step4_elapsed = time.time() - step4_start
        step_timings["4_malware"] = step4_elapsed
        _progress(4, "Malware Scan", "Complete")
        logger.info(f" Completed in {step4_elapsed:.1f}s")

        # Step 5: Find entrypoints
        _progress(5, "Entrypoints", "Finding...")
        step5_start = time.time()
        timestamp = datetime.now().strftime("%H:%M:%S")
        logger.info(f"[{timestamp}] [5/14] Identifying entrypoints...")
        logger.info(" Tool: AST-based pattern matching (Tree-sitter)")
        logger.info(" Policy: Detect main(), if __name__, @app.route patterns")
        entrypoints = self._find_entrypoints()
        self.entrypoints = set(entrypoints)  # STORE for CVE mapping fallback!
        logger.info(f" Found {len(entrypoints)} entrypoints")

        # Show entrypoint breakdown by language
        ep_by_lang = {"Go": 0, "JavaScript": 0, "Python": 0}
        for ep in entrypoints:
            if ep in self.functions_by_language.get("Go", set()):
                ep_by_lang["Go"] += 1
            elif ep in self.functions_by_language.get("JavaScript", set()):
                ep_by_lang["JavaScript"] += 1
            elif ep in self.functions_by_language.get("Python", set()):
                ep_by_lang["Python"] += 1

        if any(c > 0 for c in ep_by_lang.values()):
            lang_parts = [f"{lang}: {c}" for lang, c in sorted(ep_by_lang.items(), key=lambda x: -x[1]) if c > 0]
            logger.info(f" By Language: {', '.join(lang_parts)}")

        # Per-project breakdown for entrypoints
        ep_by_proj = {}
        for ep in entrypoints:
            parts = ep.split(".")
            proj = parts[1] if len(parts) > 2 and parts[0] == "app" else "root"
            ep_by_proj[proj] = ep_by_proj.get(proj, 0) + 1

        if len(ep_by_proj) > 1:
            proj_parts = [f"{proj}: {c}" for proj, c in sorted(ep_by_proj.items(), key=lambda x: -x[1])[:5] if c > 0]
            logger.info(f" By Project: {', '.join(proj_parts)}")

        for ep in sorted(entrypoints)[:5]:
            logger.info(f" • {ep}")
        if len(entrypoints) > 5:
            logger.info(f" ... and {len(entrypoints) - 5} more")
        step5_elapsed = time.time() - step5_start
        step_timings["5_entrypoints"] = step5_elapsed
        _progress(5, "Entrypoints", f"{len(entrypoints)} found")
        logger.info(f" Completed in {step5_elapsed:.1f}s")

        # RADR v5.5: Detect internal (non-HTTP) entrypoints
        try:
            from reachable.core.internal_entrypoints import detect_internal_entrypoints

            internal_eps = detect_internal_entrypoints(
                call_graph=self.call_graph,
                all_functions=self.all_functions,
                imports_map=getattr(self, "imports_map", {}),
                function_imports=getattr(self, "function_imports", {}),
                detected_languages=list(self.functions_by_language.keys()),
            )
            # Merge internal entrypoints into main set
            for ep_data in internal_eps.get("entrypoints", []):
                ep_func = ep_data.get("function", "")
                if ep_func and ep_func not in self.entrypoints:
                    entrypoints.append(ep_func)
                    self.entrypoints.add(ep_func)
            if internal_eps.get("statistics", {}).get("total", 0) > 0:
                logger.info(
                    f" +{internal_eps['statistics']['total']} internal entrypoints (timers, queues, threads, signals)"
                )
            # Save for RADR manifest
            internal_ep_file = self.vulns_file.parent / "internal-entrypoints.json"
            with open(internal_ep_file, "w") as _f:
                json.dump(internal_eps, _f, indent=2)
        except Exception as e:
            logger.debug(f"Internal entrypoint detection failed: {e}")

        # Step 6: Compute reachability
        _progress(6, "Reachability", "Computing...")
        step6_start = time.time()
        timestamp = datetime.now().strftime("%H:%M:%S")
        logger.info(f"[{timestamp}] [6/14] Computing reachability from entrypoints...")
        logger.info(" Tool: Graph traversal algorithm (BFS)")
        logger.info(" Policy: Trace all code paths from entrypoints")
        self._compute_reachability(entrypoints)

        # Calculate reachability stats by language using tracked data
        total_funcs = len(self.all_functions)
        reachable_count = len(self.reachable_functions & self.all_functions)
        unreachable_count = total_funcs - reachable_count
        reachable_pct = (reachable_count / max(1, total_funcs)) * 100

        # Break down by language using tracked sets
        py_funcs = self.functions_by_language.get("Python", set())
        js_funcs = self.functions_by_language.get("JavaScript", set())
        go_funcs = self.functions_by_language.get("Go", set())

        py_reachable = len(py_funcs & self.reachable_functions)
        js_reachable = len(js_funcs & self.reachable_functions)
        go_reachable = len(go_funcs & self.reachable_functions)

        py_total = len(py_funcs)
        js_total = len(js_funcs)
        go_total = len(go_funcs)

        logger.info(f" Reachable: {reachable_count} ({reachable_pct:.1f}%)")
        # Show breakdown
        lang_parts = []
        if go_total > 0:
            lang_parts.append(f"Go: {go_reachable}/{go_total}")
        if js_total > 0:
            lang_parts.append(f"JavaScript: {js_reachable}/{js_total}")
        if py_total > 0:
            lang_parts.append(f"Python: {py_reachable}/{py_total}")
        if lang_parts:
            logger.info(f" By Language: {', '.join(lang_parts)}")

        # Per-project reachability breakdown
        reach_by_proj = {}
        total_by_proj = {}
        for func in self.all_functions:
            if func.startswith("app."):
                parts = func.split(".")
                proj = parts[1] if len(parts) > 2 else "root"
                total_by_proj[proj] = total_by_proj.get(proj, 0) + 1
                if func in self.reachable_functions:
                    reach_by_proj[proj] = reach_by_proj.get(proj, 0) + 1

        if len(total_by_proj) > 1:
            proj_parts = []
            for proj in sorted(total_by_proj.keys(), key=lambda x: -total_by_proj[x])[:5]:
                reach = reach_by_proj.get(proj, 0)
                total = total_by_proj[proj]
                proj_parts.append(f"{proj}: {reach}/{total}")
            logger.info(f" By Project: {', '.join(proj_parts)}")

        logger.info(f" Unreachable: {unreachable_count}")

        # Per-project unreachable breakdown
        unreach_by_proj = {}
        for proj, total in total_by_proj.items():
            reach = reach_by_proj.get(proj, 0)
            unreach_by_proj[proj] = total - reach

        if unreach_by_proj and len(unreach_by_proj) > 1:
            proj_parts = [f"{p}: {c}" for p, c in sorted(unreach_by_proj.items(), key=lambda x: -x[1])[:5] if c > 0]
            if proj_parts:
                logger.info(f" By Project: {', '.join(proj_parts)}")

        # Re-analyze secrets with reachability context
        if secrets_findings and secrets_findings.get("total_findings", 0) > 0:
            logger.info(" Analyzing secret reachability...")
            secrets_findings = self._reanalyze_secrets_with_reachability(secrets_findings)

            # v4.5.4 FIX: Update _actual_secrets after reachability analysis
            # Some Semgrep findings get is_actual_secret=True during reachability analysis
            # (e.g., detected-private-key patterns) but weren't in the initial list
            if hasattr(self, "_actual_secrets"):
                all_secrets = [f for f in secrets_findings.get("findings", []) if f.get("is_actual_secret", False)]
                self._actual_secrets = all_secrets

            # v2.9.40: Validate if secrets are active (if enabled)
            if self.verify_secrets:
                logger.info(" Validating secret status (calling APIs)...")
                secrets_findings = self._validate_secrets_active(secrets_findings)

            by_reach = secrets_findings.get("by_reachability", {})
            reachable_critical = by_reach.get("reachable_critical", 0)
            reachable_other = by_reach.get("reachable_other", 0)
            total_reachable = by_reach.get("total_reachable", reachable_critical + reachable_other)
            unreachable_secrets = by_reach.get("unreachable", 0)
            total_secrets = secrets_findings.get("total_findings", 0)

            # v2.9.40: Get validation results
            validation_stats = secrets_findings.get("validation_stats", {})
            active_count = validation_stats.get("active", 0)
            inactive_count = validation_stats.get("inactive", 0)
            unverified_count = validation_stats.get("unverified", 0)

            # Build per-project breakdown for ALL secrets
            secrets_reach_by_proj = {}
            secrets_unreach_by_proj = {}
            reachable_secrets_details = []  # Collect reachable secrets with details

            for finding in secrets_findings.get("findings", []):
                path = finding.get("path", "")
                parts = path.split("/")
                proj = parts[0] if parts and parts[0] not in (".", "..", "") else "root"
                if finding.get("is_reachable", False):
                    secrets_reach_by_proj[proj] = secrets_reach_by_proj.get(proj, 0) + 1
                    # Collect details for display
                    reachable_secrets_details.append(
                        {
                            "path": path,
                            "line": finding.get("start", {}).get("line", finding.get("line", "?")),
                            "rule": finding.get("check_id", finding.get("rule_id", "")).split(".")[-1],
                            "via": finding.get("reachable_via", [])[:2],  # Top 2 functions
                            "severity": finding.get("severity", "warning"),
                            "is_secret": finding.get("is_actual_secret", False),
                            "validation": finding.get("validation", {}),
                        }
                    )
                else:
                    secrets_unreach_by_proj[proj] = secrets_unreach_by_proj.get(proj, 0) + 1

            if total_reachable > 0:
                logger.info(f" {total_reachable} secrets in REACHABLE code (exploitable!)")
                if reachable_critical > 0:
                    logger.info(f" └─ {reachable_critical} CRITICAL (API keys, tokens)")
                if reachable_other > 0:
                    logger.info(f" └─ {reachable_other} other severity")

                # v2.9.40: Show validation breakdown
                if self.verify_secrets and (active_count + inactive_count) > 0:
                    logger.info(" SECRET VALIDATION RESULTS:")
                    if active_count > 0:
                        logger.info(f" {active_count} ACTIVE (verified working) - IMMEDIATE ACTION!")
                    if inactive_count > 0:
                        logger.info(f" {inactive_count} INACTIVE (revoked/expired) - cleanup only")
                    if unverified_count > 0:
                        logger.info(f" {unverified_count} UNVERIFIED (assume active)")

                if secrets_reach_by_proj:
                    proj_parts = [
                        f"{p}: {c}" for p, c in sorted(secrets_reach_by_proj.items(), key=lambda x: -x[1])[:5]
                    ]
                    logger.info(f" By Project: {', '.join(proj_parts)}")

                # Show top 5 reachable secrets with file:line and function info
                actual_secrets = [s for s in reachable_secrets_details if s["is_secret"]][:5]
                if actual_secrets:
                    logger.info(" TOP REACHABLE SECRETS (with call path):")
                    for i, secret in enumerate(actual_secrets, 1):
                        file_loc = f"{secret['path']}:{secret['line']}"
                        via_funcs = secret["via"]
                        if via_funcs and via_funcs[0] != "<entrypoint>":
                            func_info = f" → via {via_funcs[0]}"
                            if len(via_funcs) > 1:
                                func_info += f", {via_funcs[1]}"
                        else:
                            func_info = " → <entrypoint>"

                        # v2.9.40: Show validation status
                        validation = secret.get("validation", {})
                        if validation.get("status") == "active":
                            status_icon = " ACTIVE"
                        elif validation.get("status") == "inactive":
                            status_icon = " INACTIVE"
                        else:
                            status_icon = ""

                        line = f"      {i}. [{secret['rule']}] {file_loc}{func_info}"
                        if status_icon:
                            line += f" [{status_icon}]"
                        logger.info(line)

            if unreachable_secrets > 0:
                logger.info(f" {unreachable_secrets} secrets in unreachable code (Risk: LOW)")
                if secrets_unreach_by_proj:
                    proj_parts = [
                        f"{p}: {c}" for p, c in sorted(secrets_unreach_by_proj.items(), key=lambda x: -x[1])[:5]
                    ]
                    logger.info(f" By Project: {', '.join(proj_parts)}")

            # If nothing was found reachable, show that
            if total_reachable == 0 and total_secrets > 0:
                logger.info(f" All {total_secrets} secrets in unreachable code (Risk: LOW)")
        step6_elapsed = time.time() - step6_start
        step_timings["6_reachability"] = step6_elapsed
        _progress(6, "Reachability", f"{len(self.reachable_functions)} reachable")
        logger.info(f" Completed in {step6_elapsed:.1f}s")

        # Step 7: Map CVEs to functions
        _progress(7, "CVE Mapping", "Mapping...")
        step7_start = time.time()
        timestamp = datetime.now().strftime("%H:%M:%S")
        logger.info(f"[{timestamp}] [7/14] Mapping CVEs to code locations...")
        logger.info(" Tool: Library import tracker (AST-based)")
        logger.info(" Policy: Match CVE packages to imports (direct + transitive)")

        transitive_enabled = len(self.library_imports) > 0
        if transitive_enabled:
            logger.info(f" Transitive: Enabled ({len(self.library_imports)} library dependency chains)")

        cve_mappings = self._map_cves_to_functions()

        # Debug: Show CVE count from vulns file
        vulns_count = len(self.vulns.get("matches", []) or self.vulns.get("vulnerabilities", []))

        if cve_mappings:
            total_funcs = sum(len(m.get("affected_functions", [])) for m in cve_mappings.values())
            logger.info(f" Mapped {len(cve_mappings)} CVEs to {total_funcs} functions")

            # Count direct vs transitive
            direct_count = sum(1 for m in cve_mappings.values() if not m.get("is_transitive", False))
            transitive_count = sum(1 for m in cve_mappings.values() if m.get("is_transitive", False))

            if transitive_count > 0:
                logger.info(f" • Direct imports: {direct_count} CVEs")
                logger.info(f" • Transitive deps: {transitive_count} CVEs")

            # Per-language breakdown
            cves_by_lang = {}
            cves_by_proj = {}
            for cve_id, cve_data in cve_mappings.items():
                pkg = cve_data.get("package", "").lower()

                # Comprehensive language detection
                # Go patterns
                if pkg == "stdlib" or pkg.startswith("go1."):
                    lang = "Go"
                elif any(x in pkg for x in ["golang.org", "github.com/", "k8s.io", "gopkg.in", "go.uber.org"]):
                    lang = "Go"
                # Python patterns
                elif any(
                    x in pkg for x in ["requests", "flask", "django", "numpy", "pandas", "pip", "urllib", "pytest"]
                ):
                    lang = "Python"
                # Java patterns
                elif any(x in pkg for x in ["springframework", "maven", "apache", "javax", "log4j"]):
                    lang = "Java"
                # JavaScript patterns
                elif pkg.startswith("@"):
                    lang = "JavaScript"
                elif any(
                    x in pkg
                    for x in [
                        "lodash",
                        "express",
                        "react",
                        "vue",
                        "next",
                        "webpack",
                        "babel",
                        "postcss",
                        "braces",
                        "micromatch",
                        "set-value",
                        "defaults-deep",
                        "expand-object",
                        "parse-git-config",
                        "yargs",
                        "js-yaml",
                    ]
                ):
                    lang = "JavaScript"
                elif "-" in pkg and "." not in pkg and "/" not in pkg:
                    lang = "JavaScript"  # npm-style package
                else:
                    lang = "Other"
                cves_by_lang[lang] = cves_by_lang.get(lang, 0) + 1

                # Extract project from affected functions
                funcs = cve_data.get("affected_functions", [])
                if funcs:
                    for func in funcs[:1]:  # Just use first function
                        # Skip internal placeholder functions
                        if func.startswith("__") and func.endswith("__"):
                            cves_by_proj["unknown"] = cves_by_proj.get("unknown", 0) + 1
                            break
                        parts = func.split(".")
                        proj = parts[1] if len(parts) > 2 else parts[0] if parts else "unknown"
                        cves_by_proj[proj] = cves_by_proj.get(proj, 0) + 1
                        break
                else:
                    cves_by_proj["unmapped"] = cves_by_proj.get("unmapped", 0) + 1

            # Show language breakdown
            if cves_by_lang:
                lang_parts = [f"{lang}: {count}" for lang, count in sorted(cves_by_lang.items(), key=lambda x: -x[1])]
                logger.info(f" By Language: {', '.join(lang_parts)}")

            # Show project breakdown
            if cves_by_proj and len(cves_by_proj) > 1:
                proj_parts = [
                    f"{proj}: {count}" for proj, count in sorted(cves_by_proj.items(), key=lambda x: -x[1])[:5]
                ]
                logger.info(f" By Project: {', '.join(proj_parts)}")

            # Show examples
            examples = []
            for cve_id, cve_data in list(cve_mappings.items())[:3]:
                pkg = cve_data.get("package", "unknown")
                trans_marker = "→" if cve_data.get("is_transitive") else ""
                examples.append(f"{cve_id} ({pkg}{trans_marker})")

            if examples:
                logger.info(f" Examples: {', '.join(examples)}")
        else:
            if vulns_count > 0:
                logger.info(f" CVE mapping returned 0 despite {vulns_count} vulnerabilities in scan")
                logger.info(
                    f" (entrypoints={len(getattr(self, 'entrypoints', set()))}, app_funcs={len([f for f in self.all_functions if not f.startswith('lib.')])})"
                )
            else:
                logger.info(" No CVEs found in vulnerability scan")
        step7_elapsed = time.time() - step7_start
        step_timings["7_cve_mapping"] = step7_elapsed
        _progress(7, "CVE Mapping", f"{len(cve_mappings)} CVEs mapped")
        logger.info(f" Completed in {step7_elapsed:.1f}s")

        # Step 8: Git blame analysis - REMOVED (not useful)
        # Git blame showed which functions were patched, but didn't tell us if they're reachable
        # We already have better data from import tracking + call graph

        # Step 9: Classify CVEs
        _progress(8, "CVE Classification", "Classifying...")
        step8_start = time.time()
        timestamp = datetime.now().strftime("%H:%M:%S")
        logger.info(f"[{timestamp}] [8/14] Classifying CVE reachability...")
        logger.info(" Tool: Reachability classification engine")
        logger.info(" Policy: CVE in reachable code → HIGH/CRITICAL risk, unreachable → LOW risk")
        reachable_cves, unreachable_cves = self._classify_cves(cve_mappings)
        all_cves = {**reachable_cves, **unreachable_cves}

        # Calculate severity breakdown (v4.5.3 fix: use severity field, not CVSS calculation)
        severity_counts = {"CRITICAL": 0, "HIGH": 0, "MEDIUM": 0, "LOW": 0, "UNKNOWN": 0}
        unfixed_count = 0

        for cve_id, cve_data in all_cves.items():
            # v4.5.3 FIX: Use the severity field directly (already set by Grype)
            # Only fall back to CVSS calculation if severity is missing
            severity = str(cve_data.get("severity", "")).upper()

            if severity not in ("CRITICAL", "HIGH", "MEDIUM", "LOW"):
                # Fallback: calculate from CVSS if no severity provided
                cvss_score = cve_data.get("cvss_score", 0) or 0
                if cvss_score >= 9.0:
                    severity = "CRITICAL"
                elif cvss_score >= 7.0:
                    severity = "HIGH"
                elif cvss_score >= 4.0:
                    severity = "MEDIUM"
                elif cvss_score > 0:
                    severity = "LOW"
                else:
                    severity = "UNKNOWN"

            severity_counts[severity] += 1

            # Check if fix available
            fix_state = cve_data.get("fix_state", "unknown")
            if fix_state in ["not-fixed", "wont-fix", "unknown"]:
                unfixed_count += 1

        total_cves = len(all_cves)
        logger.info(f" → TOTAL: {total_cves} CVEs")
        logger.info(f" • CRITICAL: {severity_counts['CRITICAL']}")
        logger.info(f" • HIGH: {severity_counts['HIGH']}")
        logger.info(f" • MEDIUM: {severity_counts['MEDIUM']}")
        logger.info(f" • LOW: {severity_counts['LOW']}")
        if severity_counts["UNKNOWN"] > 0:
            logger.info(f" • UNKNOWN: {severity_counts['UNKNOWN']}")

        # Per-language breakdown
        cves_by_lang = {}
        cves_by_proj = {}
        for cve_id, cve_data in all_cves.items():
            pkg_name = cve_data.get("package", "").lower()

            # Comprehensive language detection
            # Go patterns
            if pkg_name == "stdlib" or pkg_name.startswith("go1."):
                lang = "Go"
            elif any(
                x in pkg_name
                for x in [
                    "golang.org",
                    "github.com/",
                    "k8s.io",
                    "gopkg.in",
                    "go.uber.org",
                    "google.golang.org",
                ]
            ):
                lang = "Go"
            # Python patterns
            elif any(
                x in pkg_name
                for x in [
                    "requests",
                    "flask",
                    "django",
                    "numpy",
                    "pandas",
                    "pip",
                    "setuptools",
                    "pytest",
                    "urllib3",
                    "cryptography",
                ]
            ):
                lang = "Python"
            # Java patterns
            elif any(x in pkg_name for x in ["springframework", "maven", "apache", "javax", "log4j", "jackson"]):
                lang = "Java"
            # JavaScript patterns (check after Go/Python/Java)
            elif pkg_name.startswith("@"):
                lang = "JavaScript"
            elif any(
                x in pkg_name
                for x in [
                    "next",
                    "react",
                    "postcss",
                    "braces",
                    "lodash",
                    "webpack",
                    "babel",
                    "eslint",
                    "yargs",
                    "js-yaml",
                    "set-value",
                    "defaults-deep",
                    "expand-object",
                    "parse-git-config",
                    "micromatch",
                    "minimatch",
                ]
            ):
                lang = "JavaScript"
            elif "-" in pkg_name and "." not in pkg_name and "/" not in pkg_name:
                lang = "JavaScript"  # npm-style package name
            else:
                lang = "Other"

            # Extract project from affected functions
            funcs = cve_data.get("affected_functions", []) or cve_data.get("unreachable_functions", [])
            proj = "unknown"
            if funcs:
                for func in funcs[:1]:
                    # Skip internal placeholder functions
                    if func.startswith("__") and func.endswith("__"):
                        continue
                    parts = func.split(".")
                    if len(parts) >= 2:
                        proj = parts[1]
                        break

            cves_by_lang[lang] = cves_by_lang.get(lang, 0) + 1
            cves_by_proj[proj] = cves_by_proj.get(proj, 0) + 1

        # Show language breakdown
        if cves_by_lang:
            lang_parts = [
                f"{lang}: {count}" for lang, count in sorted(cves_by_lang.items(), key=lambda x: -x[1]) if count > 0
            ]
            logger.info(f" By Language: {', '.join(lang_parts[:5])}")

        # Show project breakdown (for monorepos)
        if cves_by_proj and len(cves_by_proj) > 1:
            proj_parts = [
                f"{proj}: {count}" for proj, count in sorted(cves_by_proj.items(), key=lambda x: -x[1])[:4] if count > 0
            ]
            logger.info(f" By Project: {', '.join(proj_parts)}")

        logger.info(" → FIX STATUS:")
        logger.info(f" • Fixable: {total_cves - unfixed_count}")
        logger.info(f" • No Fix: {unfixed_count}")
        logger.info(f" → REACHABLE: {len(reachable_cves)} CVEs")
        logger.info(f" → UNREACHABLE: {len(unreachable_cves)} CVEs")

        # Show top reachable CVEs with their call paths
        if reachable_cves:
            logger.info(" TOP REACHABLE CVEs (with call path):")
            sorted_reach_cves = sorted(
                reachable_cves.items(),
                key=lambda x: {"CRITICAL": 0, "HIGH": 1, "MEDIUM": 2, "LOW": 3}.get(
                    str(x[1].get("severity", "")).upper(), 4
                ),
            )[:5]
            for i, (cve_id, cve_data) in enumerate(sorted_reach_cves, 1):
                severity = str(cve_data.get("severity", "UNKNOWN")).upper()
                sev_icon = {"CRITICAL": "CRITICAL", "HIGH": "HIGH", "MEDIUM": "MEDIUM", "LOW": "LOW"}.get(
                    severity, severity
                )
                pkg = cve_data.get("package", "unknown")[:30]
                funcs = cve_data.get("reachable_functions", [])[:2]
                if funcs:
                    func_info = f" → via {funcs[0]}"
                    if len(funcs) > 1:
                        func_info += f", {funcs[1]}"
                else:
                    func_info = ""
                logger.info(f" {i}. {sev_icon} {cve_id} ({pkg}){func_info}")

        step8_elapsed = time.time() - step8_start
        step_timings["8_cve_classify"] = step8_elapsed
        _progress(8, "CVE Classification", f"{len(reachable_cves)} reachable")
        logger.info(f" Completed in {step8_elapsed:.1f}s")

        # Step 10: Fetch exploitability data (KEV, EPSS, Exploit-DB, Metasploit)
        _progress(9, "Exploitability", "Fetching...")
        step9_start = time.time()
        timestamp = datetime.now().strftime("%H:%M:%S")
        logger.info(f"[{timestamp}] [9/14] Fetching exploitability data...")
        logger.info(" Tool: CISA KEV + EPSS + Exploit-DB + Metasploit APIs")
        logger.info(" Policy: Prioritize actively exploited CVEs")
        exploitability_data = self._fetch_exploitability(all_cves)
        logger.info(f" Fetched data for {len(exploitability_data)} CVEs")

        # Per-language breakdown of exploitability data
        exploit_by_lang = {}
        for cve_id, exploit_data in exploitability_data.items():
            if cve_id in all_cves:
                pkg_name = all_cves[cve_id].get("package", "").lower()
                if any(x in pkg_name for x in ["golang.org", "github.com/", "k8s.io"]):
                    lang = "Go"
                elif pkg_name.startswith("@") or "-" in pkg_name and "." not in pkg_name:
                    lang = "JavaScript"
                else:
                    lang = "Other"
                exploit_by_lang[lang] = exploit_by_lang.get(lang, 0) + 1

        if exploit_by_lang and len(exploit_by_lang) > 1:
            lang_parts = [f"{lang}: {count}" for lang, count in sorted(exploit_by_lang.items(), key=lambda x: -x[1])]
            logger.info(f" By Language: {', '.join(lang_parts)}")

        step9_elapsed = time.time() - step9_start
        step_timings["9_exploitability"] = step9_elapsed
        _progress(9, "Exploitability", "Complete")
        logger.info(f" Completed in {step9_elapsed:.1f}s")

        # Step 11: Scan for import/manifest discrepancies (PHANTOM DEPENDENCIES)
        _progress(10, "Phantom Deps", "Scanning...")
        step10_start = time.time()
        timestamp = datetime.now().strftime("%H:%M:%S")
        logger.info(f"[{timestamp}] [10/14] Scanning import statements (phantom dependency detection)...")
        logger.info(" Tool: Import statement parser + manifest cross-reference")
        logger.info(" Policy: Flag packages imported but NOT in requirements.txt")
        import_analysis = self._analyze_imports()

        # Store for report generation
        if import_analysis:
            self._import_analysis = {
                "total_imports": len(import_analysis.imports_found),
                "phantom_count": len(import_analysis.phantom_dependencies),
                "shadow_count": len(import_analysis.shadow_imports),
                "dead_count": len(import_analysis.dead_dependencies),
                "phantom_deps": list(import_analysis.phantom_dependencies),
                "shadow_imports": list(import_analysis.shadow_imports),
                "dead_deps": list(import_analysis.dead_dependencies),
                "imports_found": list(import_analysis.imports_found),
            }

        if import_analysis:
            phantoms = len(import_analysis.phantom_dependencies)
            shadow = len(import_analysis.shadow_imports)
            dead = len(import_analysis.dead_dependencies)

            # Build per-language breakdown
            imports_by_lang = {}
            phantom_by_lang = {}
            for imp in import_analysis.imports_found:
                imp_lower = imp.lower() if isinstance(imp, str) else str(imp).lower()
                if any(x in imp_lower for x in ["golang.org", "github.com/", "k8s.io"]):
                    lang = "Go"
                elif imp_lower.startswith("@") or "-" in imp_lower and "." not in imp_lower:
                    lang = "JavaScript"
                elif any(x in imp_lower for x in ["django", "flask", "requests", "numpy"]):
                    lang = "Python"
                else:
                    lang = "Python"  # Default for imports
                imports_by_lang[lang] = imports_by_lang.get(lang, 0) + 1

            for imp in import_analysis.phantom_dependencies:
                imp_lower = imp.lower() if isinstance(imp, str) else str(imp).lower()
                if any(x in imp_lower for x in ["golang.org", "github.com/"]):
                    lang = "Go"
                elif "-" in imp_lower and "." not in imp_lower:
                    lang = "JavaScript"
                else:
                    lang = "Python"
                phantom_by_lang[lang] = phantom_by_lang.get(lang, 0) + 1

            logger.info(f" Scanned {len(import_analysis.imports_found)} imported packages")
            if imports_by_lang:
                lang_parts = [
                    f"{lang}: {count}" for lang, count in sorted(imports_by_lang.items(), key=lambda x: -x[1])
                ]
                logger.info(f" By Language: {', '.join(lang_parts)}")

            if phantoms > 0:
                logger.info(f" PHANTOM DEPS: {phantoms} (imported but NOT in manifest!)")
                logger.info(" These are INVISIBLE to SCA tools - NOT scanned for CVEs!")
                if phantom_by_lang:
                    lang_parts = [
                        f"{lang}: {count}" for lang, count in sorted(phantom_by_lang.items(), key=lambda x: -x[1])
                    ]
                    logger.info(f" By Language: {', '.join(lang_parts)}")

            if shadow > 0:
                logger.info(f" SHADOW IMPORTS: {shadow} (transitive deps imported directly)")

            if dead > 0:
                logger.info(f" DEAD DEPS: {dead} (in manifest but never imported)")
        else:
            logger.info(" Import analysis unavailable (no requirements.txt found)")
        step10_elapsed = time.time() - step10_start
        step_timings["10_phantom_deps"] = step10_elapsed
        _progress(10, "Phantom Deps", "Complete")
        logger.info(f" Completed in {step10_elapsed:.1f}s")

        # Step 12: Calculate risk levels
        _progress(11, "Risk Calc", "Calculating...")
        step11_start = time.time()
        timestamp = datetime.now().strftime("%H:%M:%S")
        logger.info(f"[{timestamp}] [11/14] Calculating CVE risk levels...")
        logger.info(" Tool: Multi-factor risk engine")
        logger.info(" Policy: Combine reachability + exploitability + severity")
        verdicts = self._calculate_verdicts(all_cves, exploitability_data)
        logger.info(f" Calculated risk for {len(verdicts)} CVEs")
        if verdicts:
            # Count by risk level (new unified model)
            level_critical = sum(1 for v in verdicts.values() if v["level"] == 1)  # CRITICAL
            level_high = sum(1 for v in verdicts.values() if v["level"] == 2)  # HIGH
            level_medium = sum(1 for v in verdicts.values() if v["level"] == 3)  # MEDIUM
            level_low = sum(1 for v in verdicts.values() if v["level"] == 4)  # LOW
            level_info = sum(1 for v in verdicts.values() if v["level"] == 5)  # INFO
            # Legacy support for old level 6 (DEPRIORITIZE)
            level_low += sum(1 for v in verdicts.values() if v["level"] == 6)

            logger.info(" Risk Breakdown:")
            if level_critical > 0:
                logger.info(f" CRITICAL: {level_critical} CVEs (SLA: 1-48 hours)")
            if level_high > 0:
                logger.info(f" HIGH: {level_high} CVEs (SLA: 7-14 days)")
            if level_medium > 0:
                logger.info(f" MEDIUM: {level_medium} CVEs (SLA: 30 days)")
            if level_low > 0:
                logger.info(f" LOW: {level_low} CVEs (SLA: 90 days - unreachable)")
            if level_info > 0:
                logger.info(f" INFO: {level_info} CVEs (No SLA - awareness only)")

            # Per-language verdict breakdown
            verdict_by_lang = {}
            verdict_by_proj = {}
            for cve_id, v in verdicts.items():
                if cve_id in all_cves:
                    cve_data = all_cves[cve_id]
                    pkg_name = cve_data.get("package", "").lower()

                    # Detect language
                    if any(x in pkg_name for x in ["golang.org", "github.com/", "k8s.io"]):
                        lang = "Go"
                    elif pkg_name.startswith("@") or "-" in pkg_name and "." not in pkg_name:
                        lang = "JavaScript"
                    elif any(x in pkg_name for x in ["django", "flask", "requests"]):
                        lang = "Python"
                    else:
                        lang = "Other"

                    if v["level"] <= 3:  # Only count high-priority
                        verdict_by_lang[lang] = verdict_by_lang.get(lang, 0) + 1

                    # Extract project
                    funcs = cve_data.get("affected_functions", [])
                    if funcs:
                        parts = funcs[0].split(".") if funcs else []
                        proj = parts[1] if len(parts) >= 2 else "root"
                        if v["level"] <= 3:
                            verdict_by_proj[proj] = verdict_by_proj.get(proj, 0) + 1

            if verdict_by_lang and sum(verdict_by_lang.values()) > 0:
                lang_parts = [
                    f"{lang}: {count}"
                    for lang, count in sorted(verdict_by_lang.items(), key=lambda x: -x[1])
                    if count > 0
                ]
                logger.info(f" High Priority By Language: {', '.join(lang_parts)}")

            if verdict_by_proj and len(verdict_by_proj) > 1:
                proj_parts = [
                    f"{proj}: {count}"
                    for proj, count in sorted(verdict_by_proj.items(), key=lambda x: -x[1])[:4]
                    if count > 0
                ]
                logger.info(f" High Priority By Project: {', '.join(proj_parts)}")
        step11_elapsed = time.time() - step11_start
        step_timings["11_risk_calc"] = step11_elapsed
        _progress(11, "Risk Calc", "Complete")
        logger.info(f" Completed in {step11_elapsed:.1f}s")

        # Step 13: Collect package health metrics (LEADING INDICATORS)
        _progress(12, "Pkg Health", "Analyzing...")
        step12_start = time.time()
        timestamp = datetime.now().strftime("%H:%M:%S")
        logger.info(f"[{timestamp}] [12/14] Analyzing package health (leading indicators of risk)...")
        logger.info(" Tool: GitHub API + package registry metadata")
        logger.info(" Policy: Detect unmaintained packages (future CVE risk)")
        health_metrics = self._collect_health_metrics()
        if health_metrics:
            total_packages = len(health_metrics)
            critical_health = sum(1 for m in health_metrics.values() if m.overall_health == "CRITICAL")
            risky_health = sum(1 for m in health_metrics.values() if m.overall_health == "RISKY")

            logger.info(f" Analyzed {total_packages} packages")

            if critical_health > 0:
                logger.info(f" CRITICAL health: {critical_health} packages (UNMAINTAINED/DEAD)")
            if risky_health > 0:
                logger.info(f" RISKY health: {risky_health} packages (supply chain risk)")

            # Per-language health breakdown
            health_by_lang = {}
            for pkg, metrics in health_metrics.items():
                pkg_lower = pkg.lower()

                # Comprehensive language detection
                # Go patterns
                if any(
                    x in pkg_lower
                    for x in [
                        "golang.org",
                        "github.com/",
                        "k8s.io",
                        "gopkg.in",
                        "go.uber.org",
                        "google.golang.org",
                    ]
                ):
                    lang = "Go"
                # Python patterns
                elif any(
                    x in pkg_lower
                    for x in [
                        "requests",
                        "flask",
                        "django",
                        "numpy",
                        "pandas",
                        "pip",
                        "setuptools",
                        "pytest",
                        "urllib3",
                    ]
                ):
                    lang = "Python"
                # Java patterns
                elif any(x in pkg_lower for x in ["springframework", "maven", "apache", "javax", "log4j", "jackson"]):
                    lang = "Java"
                # JavaScript patterns - check @ prefix first
                elif pkg_lower.startswith("@"):
                    lang = "JavaScript"
                # Common npm packages
                elif any(
                    x in pkg_lower
                    for x in [
                        "next",
                        "react",
                        "vue",
                        "angular",
                        "express",
                        "lodash",
                        "webpack",
                        "babel",
                        "eslint",
                        "typescript",
                        "jest",
                        "postcss",
                        "braces",
                        "micromatch",
                        "yargs",
                        "js-yaml",
                        "mocha",
                        "chai",
                        "axios",
                        "moment",
                        "jquery",
                        "tailwind",
                        "vite",
                        "rollup",
                        "esbuild",
                        "prettier",
                        "nodemon",
                        "socket.io",
                        "set-value",
                        "defaults-deep",
                        "expand-object",
                        "parse-git-config",
                        "csstools",
                        "sass",
                        "less",
                        "styled",
                        "emotion",
                        "glamor",
                    ]
                ):
                    lang = "JavaScript"
                # npm-style package names (hyphenated, no dots, no slashes)
                elif "-" in pkg_lower and "." not in pkg_lower and "/" not in pkg_lower:
                    lang = "JavaScript"
                # Simple lowercase names without special chars are likely npm too
                elif pkg_lower.isalnum() and pkg_lower.islower() and len(pkg_lower) > 2:
                    lang = "JavaScript"
                else:
                    lang = "Other"

                if lang not in health_by_lang:
                    health_by_lang[lang] = {"total": 0, "critical": 0}
                health_by_lang[lang]["total"] += 1
                if metrics.overall_health == "CRITICAL":
                    health_by_lang[lang]["critical"] += 1

            # Show language breakdown
            if health_by_lang and len(health_by_lang) > 1:
                lang_parts = [
                    f"{lang}: {d['total']} ({d['critical']} critical)"
                    for lang, d in sorted(health_by_lang.items(), key=lambda x: -x[1]["total"])
                ]
                logger.info(f" By Language: {', '.join(lang_parts[:4])}")

            # Per-project health breakdown (based on SBOM locations)
            health_by_proj = {}
            if self.sbom:
                for artifact in self.sbom.get("artifacts", []):
                    pkg_name = artifact.get("name", "")
                    if pkg_name in health_metrics:
                        metrics = health_metrics[pkg_name]
                        # Try to get project from locations
                        locations = artifact.get("locations", [])
                        proj = "root"
                        for loc in locations:
                            path = loc.get("path", "")
                            if "/" in path:
                                parts = path.split("/")
                                if len(parts) > 1 and parts[0] not in ("node_modules", "vendor", "."):
                                    proj = parts[0]
                                    break

                        if proj not in health_by_proj:
                            health_by_proj[proj] = {"total": 0, "critical": 0, "risky": 0}
                        health_by_proj[proj]["total"] += 1
                        if metrics.overall_health == "CRITICAL":
                            health_by_proj[proj]["critical"] += 1
                        elif metrics.overall_health == "RISKY":
                            health_by_proj[proj]["risky"] += 1

            if health_by_proj and len(health_by_proj) > 1:
                proj_parts = [
                    f"{proj}: {d['total']} ({d['critical']} critical)"
                    for proj, d in sorted(health_by_proj.items(), key=lambda x: -x[1]["critical"])[:5]
                ]
                logger.info(f" By Project: {', '.join(proj_parts)}")

            # Show top health concerns
            dead_packages = [
                (pkg, m)
                for pkg, m in health_metrics.items()
                if m.overall_health == "CRITICAL" and m.maintenance_risk == "CRITICAL"
            ]

            if dead_packages:
                logger.info(f" WARNING: {len(dead_packages)} UNMAINTAINED packages detected!")
                logger.info(" These are time bombs - future CVEs will NOT be patched.")
                for pkg, metrics in sorted(dead_packages, key=lambda x: x[1].days_since_last_commit or 0, reverse=True)[
                    :3
                ]:
                    days = metrics.days_since_last_commit
                    years = days / 365.0 if days else 0
                    logger.info(f" {pkg}: No commits in {years:.1f} years")
        else:
            logger.info(" → Health metrics unavailable (install dependencies or set GITHUB_TOKEN)")
        step12_elapsed = time.time() - step12_start
        step_timings["12_health"] = step12_elapsed
        _progress(12, "Pkg Health", "Complete")
        logger.info(f" Completed in {step12_elapsed:.1f}s")

        # v4.5.30: Enrich AI findings with call graph reachability BEFORE correlation
        # This gives AI findings actual is_reachable and call_path data
        # Uses same file-based pattern as secrets/CWE reachability
        enriched_ai_findings = self.ai_findings
        if self.ai_findings and self.reachable_functions:
            # Build file-to-functions map for AI findings (same as secrets)
            ai_reachable_files = set()
            ai_file_to_functions = {}
            for func in self.reachable_functions:
                # Extract file path from function name (module.class.func or module.func)
                parts = func.rsplit(".", 1)
                if len(parts) > 1:
                    module = parts[0]
                    func_name = parts[1]
                    # Convert module path to file path
                    file_path = module.replace(".", "/").lower()
                    ai_reachable_files.add(file_path)
                    if file_path not in ai_file_to_functions:
                        ai_file_to_functions[file_path] = []
                    ai_file_to_functions[file_path].append(func_name)

            ai_reachable_count = 0
            for finding in self.ai_findings:
                # Get file path from finding
                file_path = (
                    getattr(finding, "file_path", "") if hasattr(finding, "file_path") else finding.get("file_path", "")
                )
                if not file_path:
                    continue

                file_lower = file_path.lower().replace("\\", "/")
                file_name = file_lower.split("/")[-1]
                file_base = file_name.rsplit(".", 1)[0] if "." in file_name else file_name

                is_reachable = False
                reachable_via = []

                # Check if file is in reachable set
                for reachable_file in ai_reachable_files:
                    if file_base in reachable_file or reachable_file in file_lower:
                        is_reachable = True
                        reachable_via = ai_file_to_functions.get(reachable_file, [])[:5]
                        break

                # Update finding (handle both object and dict)
                if hasattr(finding, "is_reachable"):
                    finding.is_reachable = is_reachable
                    finding.call_path = reachable_via
                else:
                    finding["is_reachable"] = is_reachable
                    finding["call_path"] = reachable_via

                if is_reachable:
                    ai_reachable_count += 1

            if ai_reachable_count > 0:
                logger.info(f" AI findings enriched: {ai_reachable_count}/{len(self.ai_findings)} reachable")
            enriched_ai_findings = self.ai_findings

        # Step 14: Cross-threat correlation
        _progress(13, "Correlation", "Correlating...")
        step13_start = time.time()
        timestamp = datetime.now().strftime("%H:%M:%S")
        logger.info(f"[{timestamp}] [13/14] Correlating threats across all findings...")
        logger.info(" Tool: Comprehensive multi-signal correlation engine v2.0")
        logger.info(" Policy: Fuse CVE + Exploitability + Malware + Secrets + Health + AI/LLM + Attack Surface")
        correlation_results = self._correlate_threats(
            all_cves,
            exploitability_data,
            malware_detections,
            semgrep_malware,
            secrets_findings,
            health_metrics,
            ai_findings=enriched_ai_findings,  # v4.5.30: Pass enriched AI findings with reachability
            owasp_findings=self.owasp_findings,  # v4.5.18: Include OWASP Top 10 findings
        )
        if correlation_results:
            self._display_correlation_results(correlation_results, all_cves, secrets_findings, health_metrics)
        step13_elapsed = time.time() - step13_start
        step_timings["13_correlation"] = step13_elapsed
        _progress(13, "Correlation", "Complete")
        logger.info(f" Completed in {step13_elapsed:.1f}s")

        # Export call graph
        _progress(14, "Export", "Exporting...")
        step14_start = time.time()
        timestamp = datetime.now().strftime("%H:%M:%S")
        logger.info(f"[{timestamp}] [14/14] Exporting call graph...")
        logger.info(" Tool: Graph exporter (JSON)")
        logger.info(" Output: Visualize code dependencies")
        call_graph_files = self._export_call_graph()
        logger.info(f" JSON: {call_graph_files['json']}")
        if call_graph_files.get("dot"):
            logger.info(f" Graphviz DOT: {call_graph_files['dot']}")
        # RADR v5.4: Extract callable functions registry (app→lib boundary)
        try:
            from reachable.core.callable_functions import extract_callable_functions

            callable_registry = extract_callable_functions(
                call_graph=self.call_graph,
                all_functions=self.all_functions,
                reachable_functions=self.reachable_functions,
                entrypoints=getattr(self, "entrypoints", set()),
                function_metadata=getattr(self, "function_metadata", {}),
                call_parents=getattr(self, "call_parents", {}),
            )
            # Save alongside other scan outputs
            callable_file = self.vulns_file.parent / "callable-functions.json"
            with open(callable_file, "w") as cf:
                json.dump(callable_registry, cf, indent=2)
            logger.info(f" Callable functions: {callable_file}")
        except Exception as e:
            logger.debug(f"Callable functions extraction failed: {e}")

        step14_elapsed = time.time() - step14_start
        step_timings["14_export"] = step14_elapsed
        _progress(14, "Export", "Complete")
        logger.info(f" Completed in {step14_elapsed:.1f}s")
        total_scan_time = time.time() - analysis_start_time
        # v4.5.39: Include AI scan time in total for accurate percentage calculation
        total_scan_time_with_ai = total_scan_time + self.ai_scan_time + self.dlp_scan_time
        scan_end_timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        logger.info(" SCAN TIMING SUMMARY")
        logger.info(f" Scan started: {scan_start_timestamp}")
        logger.info(f" Scan completed: {scan_end_timestamp}")
        logger.info(f" Total duration: {total_scan_time_with_ai:.1f}s ({total_scan_time_with_ai / 60:.1f} minutes)")
        timing_notes = []
        if self.ai_scan_time > 0:
            timing_notes.append(f"{self.ai_scan_time:.1f}s AI/LLM")
        if self.dlp_scan_time > 0:
            timing_notes.append(f"{self.dlp_scan_time:.1f}s DLP/PII")
        if timing_notes:
            logger.info(f" (includes {', '.join(timing_notes)})")

        # Show step timing breakdown
        if step_timings:
            logger.info("   Step Breakdown:")
            step_names = {
                "0_ai_scan": "AI/LLM security scan",  # v4.5.39
                "0b_dlp_scan": "DLP/PII security scan",  # v4.5.50
                "1_parse_app": "Parse application code",
                "2_secrets": "Scan for secrets",
                "3_parse_libs": "Parse library code",
                "4_malware": "Malware detection",
                "5_entrypoints": "Find entrypoints",
                "6_reachability": "Compute reachability",
                "7_cve_mapping": "Map CVEs to code",
                "8_cve_classify": "Classify CVEs",
                "9_exploitability": "Fetch exploitability",
                "10_phantom_deps": "Phantom dependencies",
                "11_risk_calc": "Calculate risk levels",
                "12_health": "Package health",
                "13_correlation": "Threat correlation",
                "14_export": "Export call graph",
            }
            for step_key, elapsed in sorted(step_timings.items()):
                step_name = step_names.get(step_key, step_key)
                pct = (elapsed / total_scan_time_with_ai) * 100 if total_scan_time_with_ai > 0 else 0
                bar_len = int(pct / 5)  # Scale to max 20 chars
                bar = "█" * bar_len + "░" * (20 - bar_len)
                logger.info(f" {step_name:<22} {elapsed:>6.1f}s ({pct:>4.1f}%) {bar}")

        # Store timing in report metadata
        self._scan_timing = {
            "start_timestamp": scan_start_timestamp,
            "end_timestamp": scan_end_timestamp,
            "total_seconds": round(total_scan_time_with_ai, 2),
            "ai_scan_seconds": round(self.ai_scan_time, 2),
            "step_timings": step_timings,
        }

        return self._generate_report(
            reachable_cves,
            unreachable_cves,
            exploitability_data,
            verdicts,
            secrets_findings,
            malware_detections,
            semgrep_malware,
            correlation_results,
            health_metrics,
            sandbox_results,
        )

    def _is_config_finding(self, finding: Dict) -> bool:
        """Check if a CWE finding is a CONFIG issue (Dockerfile, K8s, Terraform, etc.)

        CONFIG issues have UNKNOWN reachability because their impact depends on
        deployment environment (e.g., Dockerfile USER missing may be mitigated by
        Kubernetes PodSecurityPolicies in production).
        """
        # Check if already marked as config by reachability analysis
        if finding.get("cwe_category") == "config_cwe":
            return True

        file_path = (finding.get("file_path", "") or finding.get("path", "") or "").lower()
        rule_id = (finding.get("rule_id", "") or finding.get("check_id", "") or "").lower()

        # File-based patterns
        config_file_patterns = [
            "dockerfile",
            ".yaml",
            ".yml",
            "terraform",
            ".tf",
            ".hcl",
            "kubernetes",
            "k8s",
            "helm",
            "kustomize",
            ".json",
            "cloudformation",
            "ansible",
            ".tfvars",
        ]

        # Rule-based patterns
        config_rule_patterns = [
            "dockerfile.",
            "kubernetes.",
            "terraform.",
            "helm.",
            "yaml.",
            "json.",
            "config.",
            "misconfig",
            "k8s.",
            "cloudformation.",
            "ansible.",
            "generic.ci.",
            "missing-user",
            "run-as-root",
        ]

        if any(p in file_path for p in config_file_patterns):
            return True
        if any(r in rule_id for r in config_rule_patterns):
            return True

        return False

    def _get_cwe_breakdown(self) -> Dict[str, int]:
        """Calculate CWE breakdown for code weakness findings"""
        if not hasattr(self, "_cwe_findings") or not self._cwe_findings:
            return {}

        # Return pre-computed CWE breakdown if available
        if hasattr(self, "_cwe_by_id") and self._cwe_by_id:
            return self._cwe_by_id

        # Otherwise compute it
        cwe_counts = {}

        def classify_cwe(rule_id, message=""):
            """Classify finding to CWE policy ID

            v2.9.61: Improved classification with explicit rule pattern matching
            """
            rule_lower = rule_id.lower()
            text = (rule_id + " " + message).lower()

            # ===== EXPLICIT RULE PATTERN MATCHING (highest priority) =====

            # Dockerfile/container privilege issues -> CWE-250
            if "dockerfile" in rule_lower and ("missing-user" in rule_lower or "run-as-root" in rule_lower):
                return "CWE-250"
            if "container" in rule_lower and ("root" in rule_lower or "privilege" in rule_lower):
                return "CWE-250"

            # Direct ResponseWriter writes - often false positive for non-user data
            if "no-direct-write-to-responsewriter" in rule_lower:
                if any(x in text for x in ["user input", "untrusted", "request", "query", "param"]):
                    return "CWE-079"
                return "CWE-016"

            # ===== TEXT-BASED CLASSIFICATION =====

            # Container/Docker privilege escalation (check BEFORE path-traversal)
            if any(x in text for x in ["missing-user", "run as root", "runs as root", "privileged container"]):
                return "CWE-250"

            if any(x in text for x in ["xss", "cross-site scripting", "script-injection"]):
                return "CWE-079"
            elif any(x in text for x in ["sql", "sqli", "sql-injection"]):
                return "CWE-089"
            elif any(x in text for x in ["command-injection", "shell-injection", "os-command"]):
                return "CWE-078"
            elif any(x in text for x in ["code-injection", "eval(", "exec("]):
                return "CWE-094"
            elif any(x in text for x in ["path-traversal", "directory-traversal", "lfi", "rfi"]):
                return "CWE-022"
            elif any(x in text for x in ["csrf", "cross-site-request"]):
                return "CWE-352"
            elif any(x in text for x in ["redirect", "open-redirect"]):
                return "CWE-601"
            elif any(x in text for x in ["md5", "sha1", "weak-hash"]):
                return "CWE-328"
            elif any(x in text for x in ["broken crypto", "des", "rc4", "weak cipher"]):
                return "CWE-327"
            elif any(x in text for x in ["random", "predictable"]):
                return "CWE-330"
            elif any(x in text for x in ["deserial", "pickle", "yaml.load", "unserialize"]):
                return "CWE-502"
            elif any(x in text for x in ["ssrf", "server-side-request"]):
                return "CWE-918"
            elif any(x in text for x in ["privileged", "root user"]):
                return "CWE-250"
            elif any(x in text for x in ["permission", "chmod"]):
                return "CWE-732"
            elif any(x in text for x in ["cookie", "httponly", "secure flag"]):
                return "CWE-614"
            elif any(x in text for x in ["debug mode", "development mode"]):
                return "CWE-016"
            elif any(x in text for x in ["log", "audit", "monitor"]):
                return "CWE-778"
            elif any(x in text for x in ["validation", "untrusted", "taint"]):
                return "CWE-020"
            elif any(x in text for x in ["dangerous", "unsafe"]):
                return "CWE-676"
            return "CWE-016"

        for finding in self._cwe_findings:
            rule_id = finding.get("rule_id", "")
            message = finding.get("message", "")
            cwe_id = classify_cwe(rule_id, message)
            cwe_counts[cwe_id] = cwe_counts.get(cwe_id, 0) + 1

        return cwe_counts

    def _calculate_cwe_risk_reduction(self) -> float:
        """
        Calculate the percentage of CWE risk eliminated by reachability analysis.

        v2.9.40: Proper CWE reachability metric

        Returns:
            float: Percentage of CWE findings that are unreachable (Risk: LOW)
        """
        if not hasattr(self, "_cwe_findings") or not self._cwe_findings:
            return 0.0

        total = len(self._cwe_findings)
        if total == 0:
            return 0.0

        # Count unreachable (including test-only)
        unreachable = sum(1 for f in self._cwe_findings if f.get("cwe_reachability") in ("unreachable", "test_only"))

        return round((unreachable / total) * 100, 1)
