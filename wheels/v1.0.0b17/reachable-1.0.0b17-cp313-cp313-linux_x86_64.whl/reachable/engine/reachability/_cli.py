#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.

"""
reachable - Build-Time Vulnerability Reachability Analyzer

Determines which CVEs are actually reachable in your code using static analysis.

Uses:
- AST parsing to build call graphs
- Syft-generated SBOM (dependencies)
- Grype-generated vulnerabilities
- Library source code for deep analysis

Output: Which CVEs are truly exploitable vs unreachable dead code
"""

import warnings

# Suppress urllib3 OpenSSL warning (common on macOS with LibreSSL)
warnings.filterwarnings("ignore", message=".*urllib3 v2 only supports OpenSSL.*")
warnings.filterwarnings("ignore", category=DeprecationWarning, module="urllib3")

import json
import logging
import os
import sys
from pathlib import Path

# Initialize module-level logger
logger = logging.getLogger(__name__)

# =========================================================================
# =========================================================================
from ._analyzer import ReachabilityAnalyzer
from ._report import print_summary
from ._utils import __version__


def main():
    """CLI entrypoint"""
    import argparse

    parser = argparse.ArgumentParser(
        description="reachable - Determine which CVEs are actually exploitable",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Analyze local directory
  reachable scan ./app --sbom sbom.json --vulns vulns.json

  # Analyze GitHub repository (DEFAULT: MCP mode)
  reachable scan github:owner/repo --sbom sbom.json --vulns vulns.json
  reachable scan github:psf/requests@main
  reachable scan https://github.com/django/django

  # Analyze GitHub repository (LEGACY: git clone mode)
  reachable scan github:owner/repo --git-clone --sbom sbom.json --vulns vulns.json

  # With library source code
  reachable scan ./app --libs ./libs --sbom sbom.json --vulns vulns.json

  # Save to custom location (otherwise auto-organized in ~/.reachable/)
  reachable scan ./app --sbom sbom.json --vulns vulns.json -o ./custom-output/

  # View scan history
  reachable history
  reachable history ./app --branch main -n 10

Environment Variables:
  GITHUB_TOKEN        GitHub personal access token for private repos
  REACHABLE_HOME      Override default ~/.reachable/ directory
  REACHABLE_CACHE_DIR Override cache location (shared across scans)
        """,
    )

    # Create subparsers for commands
    subparsers = parser.add_subparsers(dest="command", help="Command to run")

    # SCAN command
    scan_parser = subparsers.add_parser("scan", help="Analyze a repository for vulnerabilities")
    scan_parser.add_argument("app_dir", type=str, help="Application directory or github:owner/repo")
    scan_parser.add_argument("--libs", type=Path, help="Library source code directory (optional)")
    scan_parser.add_argument("--sbom", type=Path, required=True, help="SBOM file (from Syft)")
    scan_parser.add_argument("--vulns", type=Path, required=True, help="Vulnerabilities file (from Grype)")
    scan_parser.add_argument(
        "-o",
        "--output",
        type=Path,
        default=None,
        help="Output directory (default: auto-organized in ~/.reachable/)",
    )
    scan_parser.add_argument(
        "--branch", type=str, default=None, help="Override branch name (default: auto-detect from git)"
    )
    scan_parser.add_argument(
        "--suppressions", type=Path, help="Suppressions file (JSON) to filter CVEs/secrets/malware"
    )
    scan_parser.add_argument(
        "--git-clone",
        action="store_true",
        help="Use git clone instead of MCP mode (legacy, requires git binary)",
    )
    scan_parser.add_argument(
        "--keep-sessions",
        type=int,
        default=10,
        help="Number of scan sessions to keep per branch (default: 10)",
    )

    # HISTORY command
    history_parser = subparsers.add_parser("history", help="View scan history")
    history_parser.add_argument("repo", nargs="?", help="Repository path (optional, default: all)")
    history_parser.add_argument("-b", "--branch", type=str, help="Filter by branch")
    history_parser.add_argument("-n", "--limit", type=int, default=5, help="Max sessions per branch")
    history_parser.add_argument("--home", action="store_true", help="Show REACHABLE_HOME path")

    # Add version to main parser
    parser.add_argument("--version", action="version", version=f"reachable {__version__}")

    args = parser.parse_args()

    # Handle no command
    if not args.command:
        parser.print_help()
        sys.exit(0)

    # Handle HISTORY command
    if args.command == "history":
        from reachable.output.manager import get_reachable_home, print_scan_history

        if args.home:
            logger.info(str(get_reachable_home()))
        else:
            print_scan_history(args.repo, args.branch, args.limit)
        sys.exit(0)

    # --- SCAN command ---

    # Import output manager
    from reachable.output.manager import ScanOutputManager, cleanup_old_scans, print_scan_location

    # Handle GitHub repositories
    app_dir = args.app_dir

    if app_dir.startswith("github:") or app_dir.startswith("https://github.com/"):
        logger.info("GITHUB REPOSITORY ANALYSIS")
        try:
            from reachable.integrations.mcp_github import analyze_github_repository

            repo_path, repo_info = analyze_github_repository(
                repo_url=app_dir, use_git_clone=args.git_clone, github_token=os.getenv("GITHUB_TOKEN")
            )

            app_dir = repo_path
            logger.info(f" Repository fetched: {repo_info.full_name}")
            logger.info(f" Location: {app_dir}")

        except Exception as e:
            logger.info(f" Failed to fetch repository: {e}")
            if not args.git_clone:
                logger.info(" Tip: Try --git-clone flag for legacy mode")
            logger.info(" Tip: Set GITHUB_TOKEN environment variable for private repos")
            sys.exit(1)
    else:
        app_dir = Path(app_dir)

    # Initialize output manager (auto-creates session directory)
    output_mgr = ScanOutputManager(repo_path=str(app_dir), output_override=args.output, branch_override=args.branch)

    # Print scan location info
    print_scan_location(output_mgr)
    # Run analysis
    analyzer = ReachabilityAnalyzer(
        app_dir=app_dir,
        libs_dir=args.libs,
        sbom_file=args.sbom,
        vulns_file=args.vulns,
        suppressions_file=args.suppressions,
    )

    report = analyzer.analyze()

    # Add session info to report metadata
    if "metadata" not in report:
        report["metadata"] = {}
    report["metadata"]["session_id"] = output_mgr.session_id
    report["metadata"]["branch"] = output_mgr.branch
    report["metadata"]["output_dir"] = str(output_mgr.output_dir)
    report["metadata"]["git_info"] = output_mgr.git_info

    # RADR v5.3: Merge build provenance into report metadata
    _provenance_file = output_mgr.output_dir / "provenance.json"
    if _provenance_file.exists():
        try:
            with open(_provenance_file) as _pf:
                report["metadata"]["provenance"] = json.load(_pf)
        except Exception:
            pass

    # Save REACHABLE report using output manager
    report_path = output_mgr.get_report_path()
    with open(report_path, "w") as f:
        json.dump(report, f, indent=2)

    # Use output manager paths
    output_dir = output_mgr.output_dir
    raw_dir = output_mgr.raw_dir

    # Generate scan manifest for CI/CD coordination and distributed scanning
    scan_manifest = {
        "schema_version": "3.0",
        "scan_id": report.get("metadata", {}).get("scan_id", "unknown"),
        "generated_at": report.get("metadata", {}).get("generated_at", ""),
        "generator_version": __version__,
        "target": {
            "path": str(report.get("metadata", {}).get("analysis_target", {}).get("app_directory", "")),
            # Prefer RADR provenance over legacy git_info
            "git_commit": (
                report.get("metadata", {}).get("provenance", {}).get("source_provenance", {}).get("commit_sha")
                or (
                    report.get("metadata", {}).get("git_info", {}).get("commit")
                    if report.get("metadata", {}).get("git_info")
                    else None
                )
            ),
            "git_branch": (
                report.get("metadata", {}).get("provenance", {}).get("source_provenance", {}).get("branch")
                or (
                    report.get("metadata", {}).get("git_info", {}).get("branch")
                    if report.get("metadata", {}).get("git_info")
                    else None
                )
            ),
        },
        "components": {
            "sbom": {"status": "complete", "file": "raw/sbom.json"},
            "cves": {"status": "complete", "file": "raw/cves.json"},
            "call_graph": {"status": "complete", "file": "raw/call-graph.json"},
            "secrets": {
                "status": "complete" if report.get("security_scans", {}).get("secrets") else "skipped",
                "file": "raw/security-findings.json",
            },
            "cwe": {
                "status": (
                    "complete" if report.get("detailed_findings", {}).get("cwe", {}).get("findings") else "skipped"
                ),
                "file": "raw/cwe.json",
            },
            "malware": {
                "status": "complete" if report.get("malware_detection") else "skipped",
                "file": "raw/malware.json",
            },
            "health": {
                "status": "complete" if report.get("health_metrics") else "skipped",
                "file": "raw/health.json",
            },
            "correlation": {
                "status": "complete" if report.get("correlation") else "skipped",
                "file": "raw/correlation.json",
            },
        },
        "outputs": {
            "report": str(args.output.name),
            "dashboard": "dashboard.html",
            "vex": f"{args.output.stem}.vex.json",
            "raw_dir": "raw/",
        },
    }

    manifest_file = raw_dir / "scan-manifest.json"
    with open(manifest_file, "w") as f:
        json.dump(scan_manifest, f, indent=2)

    # Save security-findings.json with risk_assessment to raw/
    if report.get("security_scans", {}).get("secrets"):
        secrets_data = report["security_scans"]["secrets"].copy()
        # Enhance findings with risk_assessment (unified model)
        if "findings" in secrets_data:
            for finding in secrets_data["findings"]:
                is_reachable = finding.get("is_reachable", False)
                reachability = finding.get("reachability", "unknown")
                base_severity = finding.get("effective_severity", finding.get("severity", "HIGH")).upper()

                # Calculate risk based on reachability
                if is_reachable or reachability == "reachable":
                    risk = "CRITICAL" if base_severity in ("CRITICAL", "HIGH", "ERROR") else "HIGH"
                    sla = "48 hours" if risk == "CRITICAL" else "14 days"
                    verdict_action = "FIX"
                    reasoning = f"Reachable {base_severity} severity secret"
                elif reachability == "unknown":
                    risk = "HIGH"  # Assume worst case
                    sla = "14 days"
                    verdict_action = "FIX"
                    reasoning = "Reachability unknown - assume reachable (guilty until proven innocent)"
                else:
                    risk = "LOW"
                    sla = "90 days"
                    verdict_action = "MONITOR"
                    reasoning = f"Severity {base_severity} but unreachable - risk reduced to LOW"

                finding["risk_assessment"] = {
                    "severity": base_severity,
                    "risk": risk,
                    "sla": sla,
                    "verdict_action": verdict_action,
                    "reasoning": reasoning,
                }

        secrets_file = raw_dir / "security-findings.json"
        with open(secrets_file, "w") as f:
            json.dump(secrets_data, f, indent=2)

    # Save malware.json to raw/
    if report.get("security_scans", {}).get("malware_packages") or report.get("malware_detection"):
        malware_file = raw_dir / "malware.json"
        malware_data = {
            "packages": report.get("security_scans", {}).get("malware_packages", {}),
            "code_patterns": report.get("security_scans", {}).get("semgrep_malware", {}),
            "detection": report.get("malware_detection", {}),
        }
        with open(malware_file, "w") as f:
            json.dump(malware_data, f, indent=2)

    # Save health.json to raw/
    if report.get("health_metrics"):
        health_file = raw_dir / "health.json"
        with open(health_file, "w") as f:
            json.dump(report["health_metrics"], f, indent=2)

    # Save correlation.json to raw/
    if report.get("correlation"):
        correlation_file = raw_dir / "correlation.json"
        with open(correlation_file, "w") as f:
            json.dump(report["correlation"], f, indent=2)

    # Save exploitability.json to raw/
    if report.get("exploitability_data"):
        exploitability_file = raw_dir / "exploitability.json"
        with open(exploitability_file, "w") as f:
            json.dump(report["exploitability_data"], f, indent=2)

    # Save verdicts.json to raw/
    if report.get("verdicts"):
        verdicts_file = raw_dir / "verdicts.json"
        with open(verdicts_file, "w") as f:
            json.dump(report["verdicts"], f, indent=2)

    # Save policy_status.json to raw/
    if report.get("policy_status"):
        policy_file = raw_dir / "policy_status.json"
        with open(policy_file, "w") as f:
            json.dump(report["policy_status"], f, indent=2)

    # Save tool_execution_status.json to raw/
    if report.get("tool_execution_status"):
        tools_file = raw_dir / "tool_execution_status.json"
        with open(tools_file, "w") as f:
            json.dump(report["tool_execution_status"], f, indent=2)

    # Save detailed_findings.json to raw/
    if report.get("detailed_findings"):
        findings_file = raw_dir / "detailed_findings.json"
        with open(findings_file, "w") as f:
            json.dump(report["detailed_findings"], f, indent=2)

    # Save scan_timing.json to raw/
    if report.get("metadata", {}).get("scan_timing"):
        timing_file = raw_dir / "scan_timing.json"
        with open(timing_file, "w") as f:
            json.dump(report["metadata"]["scan_timing"], f, indent=2)

    # Save CVE files to raw/
    if report.get("reachable") or report.get("unreachable"):
        # Save combined cves.json
        cves_file = raw_dir / "cves.json"
        cves_data = {
            "total": len(report.get("reachable", {})) + len(report.get("unreachable", {})),
            "reachable": report.get("reachable", {}),
            "unreachable": report.get("unreachable", {}),
        }
        with open(cves_file, "w") as f:
            json.dump(cves_data, f, indent=2)

    if report.get("reachable"):
        reachable_cves_file = raw_dir / "reachable_cves.json"
        with open(reachable_cves_file, "w") as f:
            json.dump(report["reachable"], f, indent=2)

    if report.get("unreachable"):
        unreachable_cves_file = raw_dir / "unreachable_cves.json"
        with open(unreachable_cves_file, "w") as f:
            json.dump(report["unreachable"], f, indent=2)

    # Save summary.json to raw/
    if report.get("summary"):
        summary_file = raw_dir / "summary.json"
        with open(summary_file, "w") as f:
            json.dump(report["summary"], f, indent=2)

    # Save metrics.json to raw/
    if report.get("metrics"):
        metrics_file = raw_dir / "metrics.json"
        with open(metrics_file, "w") as f:
            json.dump(report["metrics"], f, indent=2)

    # Save attack_surface.json to raw/
    if report.get("detailed_findings", {}).get("attack_surface"):
        attack_surface_file = raw_dir / "attack_surface.json"
        with open(attack_surface_file, "w") as f:
            json.dump(report["detailed_findings"]["attack_surface"], f, indent=2)

    # Save threat_intel.json to raw/
    if report.get("threat_intelligence_details"):
        threat_intel_file = raw_dir / "threat_intel.json"
        with open(threat_intel_file, "w") as f:
            json.dump(report["threat_intelligence_details"], f, indent=2)

    # Save package_health.json to raw/
    if report.get("package_health"):
        package_health_file = raw_dir / "package_health.json"
        with open(package_health_file, "w") as f:
            json.dump(report["package_health"], f, indent=2)

    # Generate VEX document for compliance
    vex_output = args.output.parent / f"{args.output.stem}.vex.json"
    try:
        from reachable.reporting.vex import generate_vex_from_vera

        # Extract product info from SBOM or use defaults
        product_name = report["metadata"]["analysis_target"].get("app_directory", "Application").split("/")[-1]
        product_version = "1.0.0"  # Could be extracted from app metadata

        generate_vex_from_vera(
            vera_report_file=str(args.output),
            product_name=product_name,
            product_version=product_version,
            output_file=str(vex_output),
        )
        logger.info(f" VEX document: {vex_output}")
    except Exception as e:
        logger.info(f" VEX generation failed: {e}")

    # ═══════════════════════════════════════════════════════════════════════
    # GENERATE COMPLIANCE AUDIT REPORTS
    # Creates individual HTML reports for each compliance standard
    # ═══════════════════════════════════════════════════════════════════════
    audit_reports = {}
    try:
        from reachable.compliance import generate_all_audit_reports

        logger.info(" Generating compliance audit reports...")
        audit_reports = generate_all_audit_reports(report, str(output_dir))

        # Count generated reports (exclude _json)
        report_count = len([k for k in audit_reports.keys() if not k.startswith("_")])
        logger.info(f" Generated {report_count} compliance audit reports")

    except Exception as e:
        logger.info(f" Audit report generation failed: {e}")

    # ═══════════════════════════════════════════════════════════════════════
    # GENERATE INTERACTIVE DASHBOARD
    # Creates HTML dashboard with embedded JSON data
    # ═══════════════════════════════════════════════════════════════════════
    try:
        dashboard_template = Path(__file__).parent / "templates" / "dashboard.html"
        if dashboard_template.exists():
            dashboard_dest = output_dir / "dashboard.html"

            # Read template
            with open(dashboard_template) as f:
                template_content = f.read()

            # Create JSON string from report
            report_json = json.dumps(report, indent=2, default=str)

            # DEBUG: Verify report has data before embedding
            totals = report.get("summary", {}).get("totals", {})
            logger.info(" Dashboard data verification:")
            logger.info(f" CVEs total: {totals.get('cves_total', 'MISSING')}")
            logger.info(f" Secrets total: {totals.get('secrets_total', 'MISSING')}")
            logger.info(f" CWE total: {totals.get('cwe_total', 'MISSING')}")
            logger.info(f" JSON size: {len(report_json):,} bytes")

            # Replace the __REPORT_DATA__ placeholder with actual JSON
            # The template has: <script type="application/json" id="reportData">__REPORT_DATA__</script>
            if "__REPORT_DATA__" in template_content:
                new_content = template_content.replace("__REPORT_DATA__", report_json)
            else:
                # Fallback: inject before </body> if placeholder not found
                data_script = f'<script id="reportData" type="application/json">\n{report_json}\n</script>'
                if "</body>" in template_content:
                    new_content = template_content.replace("</body>", f"{data_script}\n</body>")
                else:
                    new_content = template_content.replace("</html>", f"{data_script}\n</html>")

            # Write the modified dashboard
            with open(dashboard_dest, "w") as f:
                f.write(new_content)

            # Verify the data was embedded correctly
            if '"cves_total":' in new_content and '"summary":' in new_content:
                logger.info(f" Dashboard: {dashboard_dest}")
                logger.info(" Report data embedded successfully")
            else:
                logger.info(f" Dashboard: {dashboard_dest}")
                logger.info(" WARNING: Report data may not be embedded correctly!")
    except Exception as e:
        logger.info(f" Dashboard generation failed: {e}")

    # Print summary
    print_summary(report)

    # List all generated raw data files
    logger.info(" RAW DATA FILES GENERATED:")

    raw_files = []

    # Core output files (in main directory)
    raw_files.append(("reachable-report.json", "Complete analysis report (canonical v3 format)"))

    # Raw debug files (in raw/ subfolder)
    if (raw_dir / "scan-manifest.json").exists():
        raw_files.append(("raw/scan-manifest.json", "CI/CD scan manifest for coordination"))
    if (raw_dir / "summary.json").exists():
        raw_files.append(("raw/summary.json", "Risk assessment, totals, and workload metrics"))
    if (raw_dir / "metrics.json").exists():
        raw_files.append(("raw/metrics.json", "All analysis metrics and statistics"))
    if (raw_dir / "cves.json").exists():
        raw_files.append(("raw/cves.json", "All CVEs (reachable + unreachable combined)"))
    if (raw_dir / "reachable_cves.json").exists():
        raw_files.append(("raw/reachable_cves.json", "Exploitable CVEs with call paths"))
    if (raw_dir / "unreachable_cves.json").exists():
        raw_files.append(("raw/unreachable_cves.json", "Unreachable CVEs (Risk: LOW)"))
    if (raw_dir / "security-findings.json").exists():
        raw_files.append(("raw/security-findings.json", "Hardcoded secrets with reachability status"))
    if (raw_dir / "malware.json").exists():
        raw_files.append(("raw/malware.json", "Malicious packages and code patterns"))
    if (raw_dir / "health.json").exists():
        raw_files.append(("raw/health.json", "Package health and maintenance metrics"))
    if (raw_dir / "exploitability.json").exists():
        raw_files.append(("raw/exploitability.json", "EPSS, KEV, Exploit-DB, Metasploit data"))
    if (raw_dir / "correlation.json").exists():
        raw_files.append(("raw/correlation.json", "Multi-signal correlation analysis"))
    if (raw_dir / "verdicts.json").exists():
        raw_files.append(("raw/verdicts.json", "Final risk verdicts per entity"))
    if (raw_dir / "policy_status.json").exists():
        raw_files.append(("raw/policy_status.json", "Security policy compliance status"))
    if (raw_dir / "tool_execution_status.json").exists():
        raw_files.append(("raw/tool_execution_status.json", "Scanner execution details"))
    if (raw_dir / "detailed_findings.json").exists():
        raw_files.append(("raw/detailed_findings.json", "Detailed findings with remediation"))
    if (raw_dir / "attack_surface.json").exists():
        raw_files.append(("raw/attack_surface.json", "Phantom deps, shadow imports"))
    if (raw_dir / "threat_intel.json").exists():
        raw_files.append(("raw/threat_intel.json", "Threat intelligence details"))
    if (raw_dir / "package_health.json").exists():
        raw_files.append(("raw/package_health.json", "Package health analysis"))
    if (raw_dir / "scan_timing.json").exists():
        raw_files.append(("raw/scan_timing.json", "Performance timing metrics"))

    # Call graph files (may be in main dir from earlier processing)
    if (output_dir / "call-graph.json").exists():
        raw_files.append(("call-graph.json", "Function call graph data"))
    if (output_dir / "call-graph.dot").exists():
        raw_files.append(("call-graph.dot", "Call graph in Graphviz DOT format"))

    # VEX and dashboard (main directory)
    if vex_output.exists():
        raw_files.append((vex_output.name, "VEX document for compliance"))
    if (output_dir / "dashboard.html").exists():
        raw_files.append(("dashboard.html", "Interactive HTML dashboard"))

    # Compliance audit reports
    if (output_dir / "compliance-report.json").exists():
        raw_files.append(("compliance-report.json", "Combined compliance assessment"))
    for std_id in ["soc2", "slsa", "ssdf", "iso27001", "fedramp", "pci_dss", "stride"]:
        audit_file = f"audit-{std_id}.html"
        if (output_dir / audit_file).exists():
            raw_files.append((audit_file, f"{std_id.upper()} audit report"))

    for fname, desc in raw_files:
        logger.info(f" {fname:<30} - {desc}")
    logger.info(f" Output directory: {output_dir.absolute()}")

    logger.info(f" Full report saved to: {output_mgr.get_report_path()}")
    logger.info(f" Dashboard: {output_mgr.get_dashboard_path()}")
    logger.info(f" Latest symlink: {output_dir.parent / 'latest'}")

    # Finalize scan session
    summary_data = {
        "cves_total": report["summary"]["totals"].get("cves_total", 0),
        "cves_reachable": report["summary"]["totals"].get("cves_reachable", 0),
        "secrets_total": report["summary"]["totals"].get("secrets_total", 0),
        "risk_level": report["summary"].get("overall_risk", {}).get("risk_level", "UNKNOWN"),
    }
    output_mgr.finalize(status="complete", summary=summary_data)

    # Cleanup old sessions (keep last N per branch)
    keep_sessions = getattr(args, "keep_sessions", 10)
    cleanup_old_scans(str(app_dir), branch=output_mgr.branch, keep=keep_sessions)

    # Exit with appropriate code
    sys.exit(0 if report["summary"]["totals"]["cves_reachable"] == 0 else 1)


if __name__ == "__main__":
    main()


# Monorepo support CLI entry point
def monorepo_main():
    """CLI entry point for monorepo scanning."""
    from reachable.monorepo.orchestrator import main as orch_main

    orch_main()


# Known minimum clean semver that supersedes common Go pseudo-versions.
# Keyed by module path (without leading "golang.org/x/" prefix where applicable).
# These are first tagged releases after the module gained proper semver tagging.
_GO_MODULE_MIN_SEMVER: dict = {
    "golang.org/x/crypto": "v0.30.0",
    "golang.org/x/net": "v0.30.0",
    "golang.org/x/text": "v0.21.0",
    "golang.org/x/sys": "v0.28.0",
    "golang.org/x/oauth2": "v0.24.0",
    "golang.org/x/sync": "v0.10.0",
    "golang.org/x/tools": "v0.28.0",
    "golang.org/x/image": "v0.23.0",
    "golang.org/x/term": "v0.27.0",
    "github.com/golang/protobuf": "v1.5.4",
}
