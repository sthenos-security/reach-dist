#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.

"""
reachable - Build-Time Vulnerability Reachability Analyzer

Determines which CVEs are actually reachable in your code using static analysis.

Uses:
- AST parsing to build call graphs
- Syft-generated SBOM (dependencies)
- Grype-generated vulnerabilities
- Library source code for deep analysis

Output: Which CVEs are truly exploitable vs unreachable dead code
"""

import warnings

# Suppress urllib3 OpenSSL warning (common on macOS with LibreSSL)
warnings.filterwarnings("ignore", message=".*urllib3 v2 only supports OpenSSL.*")
warnings.filterwarnings("ignore", category=DeprecationWarning, module="urllib3")

import ast
import logging
from pathlib import Path
from typing import Optional

# Initialize module-level logger
logger = logging.getLogger(__name__)

# =========================================================================
# =========================================================================


class _ParsersMixin:
    """Mixin — mixed into ReachabilityAnalyzer. Uses self.* freely."""

    def _analyze_imports(self) -> Optional[any]:
        """
        Analyze import statements vs. manifest (PHANTOM DEPENDENCY DETECTION)

        This is the "dual-check" approach used by professional AppSec teams:
        - Manifest (requirements.txt): What you INTENDED to install
        - Imports (code): What you ACTUALLY use

        Gaps in this mapping are CRITICAL security issues:
        1. PHANTOM DEPS: Imported but not in manifest
           → SCA tools won't scan them for CVEs!
        2. SHADOW IMPORTS: Transitive deps imported directly
           → Will break if parent removed
        3. DEAD DEPS: In manifest but never imported
           → Alert fatigue from unused CVEs

        v4.4.4: Multi-ecosystem support via phantom_detector.py

        Returns:
            ImportAnalysis or None if unavailable
        """
        # First try the new multi-ecosystem phantom detector
        try:
            from reachable.analysis.phantom import PhantomDetector

            detector = PhantomDetector(self.app_dir, self.sbom)
            results = detector.detect()

            # Convert to ImportAnalysis-like structure
            from dataclasses import dataclass

            @dataclass
            class MultiEcosystemImportAnalysis:
                imports_found: set
                phantom_dependencies: set
                shadow_imports: set
                dead_dependencies: set
                findings: list
                summary: dict

            phantom_pkgs = set()
            shadow_pkgs = set()
            dead_pkgs = set()

            for finding in results.get("findings", []):
                pkg = finding.get("package", "")
                ftype = finding.get("type", "")
                if ftype == "phantom":
                    phantom_pkgs.add(pkg)
                elif ftype == "shadow":
                    shadow_pkgs.add(pkg)
                elif ftype == "dead":
                    dead_pkgs.add(pkg)

            analysis = MultiEcosystemImportAnalysis(
                imports_found=set(),  # Will be populated by legacy scanner
                phantom_dependencies=phantom_pkgs,
                shadow_imports=shadow_pkgs,
                dead_dependencies=dead_pkgs,
                findings=results.get("findings", []),
                summary=results.get("summary", {}),
            )

            # Also store the raw results for dashboard
            self._phantom_detector_results = results

            logger.info(f" Multi-ecosystem phantom detection: {len(results.get('findings', []))} findings")
            if results.get("summary", {}).get("ecosystems_scanned"):
                logger.info(f" Ecosystems: {', '.join(results['summary']['ecosystems_scanned'])}")

            return analysis

        except ImportError:
            pass
        except Exception as e:
            logger.error(f" Phantom detector failed: {e}")

        # Fallback to legacy Python-only scanner
        try:
            from reachable.analysis.imports import analyze_import_manifest_discrepancies
        except ImportError:
            return None

        try:
            analysis = analyze_import_manifest_discrepancies(
                app_dir=str(self.app_dir), sbom_file=str(self.sbom_file) if self.sbom_file else None
            )
            return analysis
        except Exception as e:
            logger.error(f" Import analysis failed: {e}")
            return None

    def _calculate_project_tag(self, path: Path) -> str:
        """
        Calculate project tag for monorepo sub-root filtering

        Examples:
            /repo/api/auth.py -> 'api'
            /repo/frontend/app.js -> 'frontend'
            /repo/shared/utils.py -> 'shared'
        """
        try:
            rel_path = path.relative_to(self.app_dir)
            parts = str(rel_path).split("/")

            # If in root, return 'root'
            if len(parts) == 1:
                return "root"

            # Return first directory (api, frontend, shared, etc)
            return parts[0]
        except ValueError:
            # Path is not relative to app_dir (might be a library)
            return "library"

    def _parse_directory(self, directory: Path, context: str, is_library: bool = False):
        """Parse all source files (Python, JavaScript, Go, Java) in directory"""

        # Count files by type (excludes venv, build, etc.)
        python_files = self._collect_source_files(directory, "*.py")
        js_files = self._collect_source_files(directory, "*.js", "*.ts", "*.jsx", "*.tsx")
        go_files = self._collect_source_files(directory, "*.go")
        java_files = self._collect_source_files(directory, "*.java", "*.kt", "*.scala", "*.groovy")

        # Parse each language
        if python_files:
            logger.info(f" → Parsing {len(python_files)} Python files...")
            self._parse_python_directory(directory, context, is_library)

        if js_files:
            logger.info(f" → Parsing {len(js_files)} JavaScript/TypeScript files...")
            self._parse_javascript_project(directory, context)

        if go_files:
            logger.info(f" → Parsing {len(go_files)} Go files...")
            self._parse_go_project(directory, context)

        if java_files:
            logger.info(f" → Parsing {len(java_files)} Java/Kotlin/Scala/Groovy files...")
            self._parse_java_project(directory, context)

    def _parse_java_project(self, directory: Path, context: str, is_library: bool = False):
        """
        Parse Java ecosystem project (Maven, Gradle, standalone).

        Supports:
        - Maven (pom.xml) - single and multi-module
        - Gradle (build.gradle, build.gradle.kts) - Groovy and Kotlin DSL
        - Java, Kotlin, Scala, Groovy source files
        - Spring/Jakarta/Android entrypoint detection
        """
        from reachable.collectors.callgraph.java import JavaEcosystemAnalyzer

        analyzer = JavaEcosystemAnalyzer()
        result = analyzer.analyze(directory)

        project_type = result.get("project_type", "unknown")
        logger.info(f" → Detected {project_type} project")

        # Merge call graph
        call_graph = result.get("call_graph", {})
        for caller, callees in call_graph.items():
            if isinstance(callees, set):
                self.call_graph[caller].update(callees)
            else:
                self.call_graph[caller].update(set(callees))

        # Track all functions
        all_functions = result.get("all_functions", [])
        self.all_functions.update(all_functions)
        self.functions_by_language["Java"].update(all_functions)

        # Track entrypoints
        entrypoints = result.get("entrypoints", [])
        for ep in entrypoints:
            ep_name = ep.get("fqn", ep.get("name", ""))
            if ep_name:
                self.entrypoints.add(ep_name)
                # Track entrypoint type
                if not hasattr(self, "entrypoint_details"):
                    self.entrypoint_details = {}
                self.entrypoint_details[ep_name] = {
                    "type": ep.get("entrypoint_type", "http"),
                    "file": ep.get("file", ""),
                    "line": ep.get("line", 0),
                    "annotations": ep.get("annotations", []),
                }

        # Track imports for CVE matching
        function_imports = result.get("function_imports", {})
        for func, imports in function_imports.items():
            if func not in self.function_imports:
                self.function_imports[func] = set()
            self.function_imports[func].update(imports)

        # Store Java-specific metadata
        if not hasattr(self, "java_metadata"):
            self.java_metadata = {}

        self.java_metadata.update(
            {
                "project_type": project_type,
                "modules": result.get("modules", {}),
                "module_count": len(result.get("modules", {})),
                "dependencies": result.get("dependencies", {}),
                "class_count": result.get("class_count", 0),
                "entrypoint_count": result.get("entrypoint_count", 0),
            }
        )

        # Get dependencies for CVE matching (integrates with Grype)
        maven_deps = analyzer.get_dependencies_for_cve_matching()
        if maven_deps:
            if not hasattr(self, "maven_dependencies"):
                self.maven_dependencies = []
            self.maven_dependencies.extend(maven_deps)
            logger.info(f" → Found {len(maven_deps)} Maven/Gradle dependencies for CVE matching")

        logger.info(f" → Extracted {len(all_functions)} functions, {len(entrypoints)} entrypoints")

    def _parse_python_directory(self, directory: Path, context: str, is_library: bool = False):
        """Parse all Python files in directory with enhanced analysis"""
        python_files = list(directory.rglob("*.py"))

        # Calculate project tag for monorepo sub-root filtering
        self._calculate_project_tag(directory)

        from reachable.engine.reachability._callgraph import CallGraphBuilder as EnhancedCallGraphBuilder

        for py_file in python_files:
            try:
                with open(py_file, encoding="utf-8") as f:
                    source = f.read()

                # Suppress SyntaxWarnings from scanned code (e.g., invalid escape sequences)
                # This is third-party code - we're just parsing, not executing
                with warnings.catch_warnings():
                    warnings.filterwarnings("ignore", category=SyntaxWarning)
                    warnings.filterwarnings("ignore", category=DeprecationWarning)
                    tree = ast.parse(source, filename=str(py_file))

                # Get module name from path
                try:
                    rel_path = py_file.relative_to(directory)
                    module_name = str(rel_path.with_suffix("")).replace("/", ".")
                    if context:
                        module_name = f"{context}.{module_name}"
                except ValueError:
                    module_name = py_file.stem

                # Calculate file-specific project tag
                file_project_tag = self._calculate_project_tag(py_file)

                builder = EnhancedCallGraphBuilder(module_name, file_project_tag)

                builder.current_file = str(py_file)
                builder.visit(tree)

                # Normalize local function calls (add module prefix)
                builder.normalize_local_calls()

                # Merge results
                for caller, callees in builder.call_graph.items():
                    self.call_graph[caller].update(callees)

                self.all_functions.update(builder.all_functions)
                self.functions_by_language["Python"].update(builder.all_functions)
                self.imports_map.update(builder.imports)

                # Store function metadata for sub-root filtering
                if hasattr(builder, "function_metadata"):
                    self.function_metadata.update(builder.function_metadata)

                # Merge function-level import tracking
                for func, lib_imports in builder.function_imports.items():
                    self.function_imports[func].update(lib_imports)

                # Track library→library imports (for transitive dependency tracking)
                if is_library and builder.module_level_imports:
                    # Extract library name from module path
                    # e.g., "lib.urllib3.poolmanager" → "urllib3"
                    lib_name = (
                        module_name.split(".")[1]
                        if "." in module_name and module_name.startswith("lib.")
                        else module_name
                    )

                    # Track what this library imports
                    for imported_lib in builder.module_level_imports:
                        # Normalize: "urllib3" or "requests.api" → base package name
                        imported_base = imported_lib.split(".")[0]
                        if imported_base != lib_name:  # Don't track self-imports
                            self.library_imports[lib_name].add(imported_base)

            except SyntaxError as e:
                # Check for Python 2.x deprecated constructs (ur"" prefix, print statements, etc.)
                err_str = str(e).lower()
                getattr(e, "msg", "").lower() if hasattr(e, "msg") else ""

                # Detect Python 2.x ur"" string prefix (incompatible with Python 3)
                is_py2_ur_prefix = "incompatible" in err_str or "'u' and 'r'" in err_str or "u and r" in err_str

                # Also detect if parsing failed on a line containing ur" or ur'
                is_ur_string = False
                if hasattr(e, "lineno") and e.lineno:
                    try:
                        with open(py_file, encoding="utf-8", errors="ignore") as f:
                            lines = f.readlines()
                            if e.lineno <= len(lines):
                                line = lines[e.lineno - 1]
                                is_ur_string = 'ur"' in line or "ur'" in line
                    except Exception:
                        pass

                if is_py2_ur_prefix or is_ur_string:
                    logger.debug(f' Skipping {py_file.name}: deprecated 2.x construct (ur"" prefix)')
                else:
                    _pkg = py_file.relative_to(directory).parts[0] if py_file.is_relative_to(directory) else directory.name
                    _loc = f"{py_file}:{e.lineno}" if hasattr(e, "lineno") and e.lineno else str(py_file)
                    logger.warning(
                        f" Skipping unparseable file — pkg: {_pkg} | file: {_loc} | reason: {e}"
                    )
            except Exception as e:
                _pkg = py_file.relative_to(directory).parts[0] if py_file.is_relative_to(directory) else directory.name
                _loc = str(py_file)
                logger.warning(
                    f" Skipping unparseable file — pkg: {_pkg} | file: {_loc} | reason: {e}"
                )

    def _parse_javascript_project(self, directory: Path, context: str, is_library: bool = False):
        """Parse JavaScript/TypeScript project"""
        from reachable.collectors.callgraph.javascript import JavaScriptParser

        parser = JavaScriptParser()
        call_graph, imports_map, all_functions = parser.parse_directory(directory, context)

        # Merge call graph - THIS IS CRITICAL FOR REACHABILITY
        for caller, callees in call_graph.items():
            self.call_graph[caller].update(callees)

        self.all_functions.update(all_functions)
        self.functions_by_language["JavaScript"].update(all_functions)
        self.imports_map.update(imports_map)

        # Merge function metadata for reachability tracking
        if hasattr(parser, "function_metadata"):
            self.function_metadata.update(parser.function_metadata)

        # FIXED: Use parser's function_imports (tracks which functions use which packages)
        # The parser now properly tracks this during call extraction
        parser_func_imports = parser.get_function_imports()
        for func_name, imports in parser_func_imports.items():
            self.function_imports[func_name].update(imports)

        # Track library→library imports for transitive dependency graph
        if is_library:
            module_imports = parser.get_module_imports()
            for module_name, imported_libs in module_imports.items():
                # Extract library name from module path (e.g., "lib.axios.index" → "axios")
                parts = module_name.split(".")
                if len(parts) >= 2 and parts[0] == "lib":
                    lib_name = parts[1]
                else:
                    lib_name = parts[0]

                for imported_lib in imported_libs:
                    # Get base package name (e.g., "@babel/core" → "@babel/core", "lodash/merge" → "lodash")
                    if imported_lib.startswith("@"):
                        imported_base = "/".join(imported_lib.split("/")[:2])
                    else:
                        imported_base = imported_lib.split("/")[0]

                    if imported_base != lib_name:  # Don't track self-imports
                        self.library_imports[lib_name].add(imported_base)

    def _parse_go_project(self, directory: Path, context: str, is_library: bool = False):
        """Parse Go project"""
        from reachable.collectors.callgraph.go import GoParser

        parser = GoParser()
        call_graph, imports_map, all_functions = parser.parse_directory(directory, context)

        # Merge call graph - THIS IS CRITICAL FOR REACHABILITY
        for caller, callees in call_graph.items():
            self.call_graph[caller].update(callees)

        self.all_functions.update(all_functions)
        self.functions_by_language["Go"].update(all_functions)
        self.imports_map.update(imports_map)

        # Merge function metadata for reachability tracking
        if hasattr(parser, "function_metadata"):
            self.function_metadata.update(parser.function_metadata)

        # FIXED: Use parser's function_imports (tracks which functions use which packages)
        # The parser now properly tracks this during call extraction
        parser_func_imports = parser.get_function_imports()
        for func_name, imports in parser_func_imports.items():
            self.function_imports[func_name].update(imports)

        # Track library→library imports for transitive dependency graph
        if is_library:
            module_imports = parser.get_module_imports()
            for module_name, imported_libs in module_imports.items():
                # Extract library name from module path (e.g., "lib.k8s.io.client-go.pkg" → "k8s.io/client-go")
                parts = module_name.split(".")
                if len(parts) >= 2 and parts[0] == "lib":
                    # For Go, library names often have multiple parts (github.com/user/repo)
                    lib_name = ".".join(parts[1:3]) if len(parts) >= 3 else parts[1]
                else:
                    lib_name = parts[0]

                for imported_lib in imported_libs:
                    # Get base package (e.g., "github.com/pkg/errors" → "github.com/pkg/errors")
                    # For Go, we want to keep the full import path for accuracy
                    imported_base = imported_lib.split("/")[0] if "/" in imported_lib else imported_lib

                    if imported_base != lib_name:  # Don't track self-imports
                        self.library_imports[lib_name].add(imported_base)
