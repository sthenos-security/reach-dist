#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.

"""
reachable - Build-Time Vulnerability Reachability Analyzer

Determines which CVEs are actually reachable in your code using static analysis.

Uses:
- AST parsing to build call graphs
- Syft-generated SBOM (dependencies)
- Grype-generated vulnerabilities
- Library source code for deep analysis

Output: Which CVEs are truly exploitable vs unreachable dead code
"""

import warnings

# Suppress urllib3 OpenSSL warning (common on macOS with LibreSSL)
warnings.filterwarnings("ignore", message=".*urllib3 v2 only supports OpenSSL.*")
warnings.filterwarnings("ignore", category=DeprecationWarning, module="urllib3")

import json
import logging
from pathlib import Path
from typing import Dict

# Initialize module-level logger
logger = logging.getLogger(__name__)

# =========================================================================
# =========================================================================


class _ExportMixin:
    """Mixin — mixed into ReachabilityAnalyzer. Uses self.* freely."""

    def _export_call_graph(self) -> Dict[str, str]:
        """Export call graph in multiple formats"""
        import time

        # Use the same directory as other outputs (vulns.json, sbom.json, etc.)
        output_dir = self.vulns_file.parent

        # v4.3.4: Export JSON only (Mermaid/DOT removed - too slow for large repos, limited utility)
        start = time.time()
        json_file = output_dir / "call-graph.json"
        self._export_json(json_file)
        json_time = time.time() - start

        logger.info(f" → JSON export completed in {json_time:.1f}s")

        result = {
            "json": str(json_file.absolute()),
        }

        return result

    def _export_json(self, output_file: Path):
        """Export call graph as JSON (optimized for large graphs)"""
        import time

        start = time.time()

        total_functions = len(self.all_functions)

        # For very large graphs, skip full edge counting (it's slow)
        # Instead, estimate based on average edges per function
        FUNC_THRESHOLD = 10000  # If more than 10K functions, use fast path

        if total_functions > FUNC_THRESHOLD:
            # Fast path: skip detailed edge counting and edge export
            # Estimate edges (typically 3-10 edges per function)
            estimated_edges = sum(len(self.call_graph.get(f, [])) for f in list(self.call_graph.keys())[:1000])
            avg_edges = estimated_edges / min(1000, len(self.call_graph)) if self.call_graph else 0
            total_edges = int(avg_edges * len(self.call_graph))

            graph_data = {
                "statistics": {
                    "total_functions": total_functions,
                    "total_edges": total_edges,
                    "total_edges_note": "estimated",
                    "reachable_functions": len(self.reachable_functions),
                    "unreachable_functions": total_functions - len(self.reachable_functions),
                },
                "edges_skipped": True,
                "_note": f"Large graph ({total_functions} functions). Full data omitted for performance.",
            }

            # Write minimal JSON directly
            with open(output_file, "w") as f:
                json.dump(graph_data, f, indent=2)

            time.time() - start
            return

        # Standard path for smaller graphs
        total_edges = sum(len(callees) for callees in self.call_graph.values())

        # Threshold for including detailed edges
        EDGE_THRESHOLD = 50000
        skip_edges = total_edges > EDGE_THRESHOLD

        if skip_edges:
            # Lightweight export: statistics + node lists only
            graph_data = {
                "nodes": list(self.all_functions),
                "edges": [],
                "edges_skipped": True,
                "edges_count": total_edges,
                "reachable_nodes": list(self.reachable_functions),
                "unreachable_nodes": list(self.all_functions - self.reachable_functions),
                "statistics": {
                    "total_functions": total_functions,
                    "total_edges": total_edges,
                    "reachable_functions": len(self.reachable_functions),
                    "unreachable_functions": len(self.all_functions - self.reachable_functions),
                },
                "_note": f"Edge details skipped (>{EDGE_THRESHOLD} edges).",
            }
        else:
            # Full export for smaller graphs
            graph_data = {
                "nodes": list(self.all_functions),
                "edges": [
                    {"from": caller, "to": callee} for caller, callees in self.call_graph.items() for callee in callees
                ],
                "reachable_nodes": list(self.reachable_functions),
                "unreachable_nodes": list(self.all_functions - self.reachable_functions),
                "statistics": {
                    "total_functions": total_functions,
                    "total_edges": total_edges,
                    "reachable_functions": len(self.reachable_functions),
                    "unreachable_functions": len(self.all_functions - self.reachable_functions),
                },
            }

        # Write JSON (use compression for large data)
        try:
            from reachable.core.compression import save_json

            save_json(graph_data, output_file, compress=True)
        except ImportError:
            with open(output_file, "w") as f:
                json.dump(graph_data, f)

    def _export_mermaid(self, output_file: Path, app_functions: frozenset = None):
        """Export call graph as Mermaid diagram (optimized)"""
        from io import StringIO

        # Use pre-computed set or build one
        if app_functions is None:
            app_functions = frozenset(f for f in self.all_functions if f.startswith("app."))

        # Pre-compute reachable set for O(1) lookup
        reachable = self.reachable_functions

        # Use StringIO for faster string building
        buf = StringIO()
        buf.write("graph TD\n")
        buf.write("    %% Call Graph - Reachability Analysis\n\n")

        # Pre-compute safe IDs (avoid repeated string operations)
        safe_ids = {f: f.replace(".", "_").replace("-", "_") for f in app_functions}
        labels = {f: f.replace("app.app.", "").replace("app.", "") for f in app_functions}

        # Add nodes with styling
        for func in app_functions:
            safe_id = safe_ids[func]
            label = labels[func]

            if func in reachable:
                buf.write(f'    {safe_id}["{label}"]\n')
                buf.write(f"    style {safe_id} fill:#90EE90,stroke:#006400,stroke-width:2px\n")
            else:
                buf.write(f'    {safe_id}["{label}"]\n')
                buf.write(f"    style {safe_id} fill:#FFB6C1,stroke:#8B0000,stroke-width:2px\n")

        buf.write("\n")

        # Add edges (O(1) lookup with set)
        for caller in app_functions:
            if caller in self.call_graph:
                safe_caller = safe_ids[caller]
                for callee in self.call_graph[caller]:
                    if callee in app_functions:  # O(1) with frozenset
                        buf.write(f"    {safe_caller} --> {safe_ids[callee]}\n")

        buf.write("\n    %% Legend\n")
        buf.write('    legend_reachable[" REACHABLE"]\n')
        buf.write("    style legend_reachable fill:#90EE90,stroke:#006400,stroke-width:2px\n")
        buf.write('    legend_unreachable[" UNREACHABLE"]\n')
        buf.write("    style legend_unreachable fill:#FFB6C1,stroke:#8B0000,stroke-width:2px\n")

        with open(output_file, "w") as f:
            f.write(buf.getvalue())

    def _export_dot(self, output_file: Path, app_functions: frozenset = None):
        """Export call graph as Graphviz DOT format (optimized)"""
        from io import StringIO

        # Use pre-computed set or build one
        if app_functions is None:
            app_functions = frozenset(f for f in self.all_functions if f.startswith("app."))

        # Pre-compute reachable set for O(1) lookup
        reachable = self.reachable_functions

        # Use StringIO for faster string building
        buf = StringIO()
        buf.write("digraph CallGraph {\n")
        buf.write("    rankdir=TB;\n")
        buf.write("    node [shape=box, style=filled];\n\n")

        # Pre-compute safe IDs (avoid repeated string operations)
        safe_ids = {f: f.replace(".", "_").replace("-", "_") for f in app_functions}
        labels = {f: f.replace("app.app.", "").replace("app.", "") for f in app_functions}

        # Add nodes
        for func in app_functions:
            safe_id = safe_ids[func]
            label = labels[func]
            color = "lightgreen" if func in reachable else "lightpink"
            buf.write(f'    {safe_id} [label="{label}", fillcolor={color}];\n')

        buf.write("\n")

        # Add edges (O(1) lookup with set)
        for caller in app_functions:
            if caller in self.call_graph:
                safe_caller = safe_ids[caller]
                for callee in self.call_graph[caller]:
                    if callee in app_functions:  # O(1) with frozenset
                        buf.write(f"    {safe_caller} -> {safe_ids[callee]};\n")

        buf.write("\n    // Legend\n")
        buf.write('    legend [label="Legend", shape=plaintext];\n')
        buf.write('    reachable [label="REACHABLE", fillcolor=lightgreen];\n')
        buf.write('    unreachable [label="UNREACHABLE", fillcolor=lightpink];\n')
        buf.write("}\n")

        with open(output_file, "w") as f:
            f.write(buf.getvalue())
