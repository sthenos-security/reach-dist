#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.

"""
reachable - Build-Time Vulnerability Reachability Analyzer

Determines which CVEs are actually reachable in your code using static analysis.

Uses:
- AST parsing to build call graphs
- Syft-generated SBOM (dependencies)
- Grype-generated vulnerabilities
- Library source code for deep analysis

Output: Which CVEs are truly exploitable vs unreachable dead code
"""

import warnings

# Suppress urllib3 OpenSSL warning (common on macOS with LibreSSL)
warnings.filterwarnings("ignore", message=".*urllib3 v2 only supports OpenSSL.*")
warnings.filterwarnings("ignore", category=DeprecationWarning, module="urllib3")

import json
import logging
from pathlib import Path
from typing import Dict, List, Optional

# Initialize module-level logger
logger = logging.getLogger(__name__)

# =========================================================================
# =========================================================================


class _SecretsMixin:
    """Mixin — mixed into ReachabilityAnalyzer. Uses self.* freely."""

    def _scan_for_secrets(self, skip_secrets: bool = False, skip_cwe: bool = False) -> Dict:
        """Scan application code for hardcoded secrets using Semgrep

        Args:
            skip_secrets: If True, skip secrets scanning (only CWE rules)
            skip_cwe: If True, skip CWE/SAST scanning (only secrets rules)

        v4.4.7: Performance optimization - selectively run rule categories
        """
        try:
            from reachable.collectors.secrets.semgrep import SemgrepScanner
        except ImportError:
            logger.info(" Semgrep not available (install with: pip install semgrep)")
            return {}

        scanner = SemgrepScanner(cache_dir=Path.home() / ".reachable" / "cache")

        if not scanner.is_available():
            logger.info(" Semgrep not available (optional - install with: pip install semgrep)")
            return {}

        # v4.4.7: Select rule categories based on skip flags
        # 'auto' = all rules (secrets + CWE)
        # 'p/secrets' = secrets only
        # 'p/security-audit' = CWE/SAST only
        if skip_secrets and skip_cwe:
            # Both skipped - shouldn't reach here, but handle gracefully
            return {"findings": [], "total_findings": 0, "skipped": True}
        elif skip_secrets:
            # CWE only - use security-audit rules
            rules = "p/security-audit"
            logger.info(" Rules: CWE/SAST only (p/security-audit)")
        elif skip_cwe:
            # Secrets only - use secrets rules
            rules = "p/secrets"
            logger.info(" Rules: Secrets only (p/secrets)")
        else:
            # Full scan - use auto (all rules)
            rules = "auto"

        # Scan with selected ruleset
        results = scanner.scan_with_summary(self.app_dir, rules=rules, debug=self.verbose)

        # v4.5.3: source_files_scanned is now set in step [1/14] from actual file count
        # (removed broken _count_source_files() call that returned incorrect value)

        # Store scanner for later reachability analysis
        self._semgrep_scanner = scanner

        # Mark which rules were skipped for summary
        if skip_secrets:
            results["secrets_skipped"] = True
        if skip_cwe:
            results["cwe_skipped"] = True

        return results

    def _count_source_files(self, target_dir: Path) -> int:
        """
        DEPRECATED in v4.5.4: This function is no longer used.
        File count is now taken from actual scanner results in step [1/14].
        Kept for backwards compatibility.

        Original purpose: Count source code files in the target directory.

        v4.5.1: Used for dashboard "Files Scanned" metric.
        v4.5.3: No longer called - was returning incorrect counts (410 instead of 6101).

        Counts files with extensions that Semgrep analyzes:
        - Python (.py)
        - JavaScript/TypeScript (.js, .jsx, .ts, .tsx)
        - Go (.go)
        - Java (.java)
        - Ruby (.rb)
        - PHP (.php)
        - C/C++ (.c, .cpp, .h, .hpp)
        - Rust (.rs)
        - Config files (.yaml, .yml, .json, .toml)
        - Dockerfile

        Returns:
            Number of source files found
        """
        SOURCE_EXTENSIONS = {
            # Programming languages
            ".py",
            ".pyi",  # Python
            ".js",
            ".jsx",
            ".mjs",  # JavaScript
            ".ts",
            ".tsx",  # TypeScript
            ".go",  # Go
            ".java",  # Java
            ".kt",
            ".kts",  # Kotlin
            ".scala",  # Scala
            ".rb",  # Ruby
            ".php",  # PHP
            ".c",
            ".cpp",
            ".h",
            ".hpp",
            ".cc",
            ".cxx",  # C/C++
            ".cs",  # C#
            ".rs",  # Rust
            ".swift",  # Swift
            ".m",
            ".mm",  # Objective-C
            ".sh",
            ".bash",  # Shell
            # Config files (also scanned by Semgrep)
            ".yaml",
            ".yml",  # YAML
            ".json",  # JSON
            ".toml",  # TOML
            ".tf",  # Terraform
            ".hcl",  # HCL
        }

        # Special filenames without extensions
        SPECIAL_FILES = {"Dockerfile", "Makefile", "Jenkinsfile", "Vagrantfile"}

        # Directories to skip
        SKIP_DIRS = {
            "node_modules",
            "vendor",
            "venv",
            ".venv",
            "env",
            ".env",
            "__pycache__",
            ".git",
            ".svn",
            ".hg",
            "dist",
            "build",
            ".tox",
            ".pytest_cache",
            ".mypy_cache",
            "coverage",
            "target",
            "bin",
            "obj",
            ".idea",
            ".vscode",
        }

        count = 0
        target_path = Path(target_dir)

        try:
            import os

            for root, dirs, files in os.walk(target_path):
                # Skip excluded directories
                dirs[:] = [d for d in dirs if d not in SKIP_DIRS and not d.startswith(".")]

                for filename in files:
                    # Check special filenames
                    if filename in SPECIAL_FILES:
                        count += 1
                        continue

                    # Check extensions
                    ext = Path(filename).suffix.lower()
                    if ext in SOURCE_EXTENSIONS:
                        count += 1
        except Exception:
            # If walk fails, return 0
            pass

        return count

    def _scan_env_secrets(self) -> Dict:
        """
        Scan for secrets in .env files and configuration files.

        This catches secrets that Semgrep's generic rules miss:
        - OAuth client secrets (Google, Azure, etc.)
        - Ory Hydra/Kratos secrets
        - Base64-encoded private keys
        - Database passwords in .env files
        - SCIM bearer tokens
        - Weak/placeholder secrets

        Returns:
            Dict with findings in EnvSecretsScanner format
        """
        import os as os_module  # Local import to avoid issues

        try:
            from reachable.collectors.secrets.env import EnvSecretsScanner
        except ImportError:
            # EnvSecretsScanner not available - skip
            return {}

        try:
            # Initialize scanner with options
            scanner = EnvSecretsScanner(
                scan_env=True,
                scan_configs=True,
                scan_cicd=True,
                scan_k8s=True,
                decode_base64=True,
            )

            # Scan the target directory
            result = scanner.scan(self.app_dir)

            if result and result.total_secrets_found > 0:
                # Convert EnvScanResult to standard format for merging
                findings = []
                for finding in result.findings:
                    findings.append(
                        {
                            "file_path": finding.file_path,
                            "line_number": finding.line_number,
                            "key": finding.key_name,
                            "secret_type": (
                                finding.secret_type.value
                                if hasattr(finding.secret_type, "value")
                                else str(finding.secret_type)
                            ),
                            "severity": (
                                finding.severity.value if hasattr(finding.severity, "value") else str(finding.severity)
                            ),
                            "description": finding.message,
                            "value_preview": finding.value_preview,
                            "remediation": finding.remediation,
                            "is_weak": finding.is_weak_secret,
                            "is_base64": finding.is_base64_decoded,
                        }
                    )

                return {
                    "findings": findings,
                    "total": result.total_secrets_found,
                    "by_severity": result.secrets_by_severity,
                    "by_type": result.secrets_by_type,
                    "forbidden_files": result.forbidden_files_found,
                    "weak_secrets": result.weak_secrets_count,
                    "base64_decoded": result.base64_decoded_count,
                }

            return {}

        except Exception as e:
            # Log error but don't fail the scan
            if os_module.environ.get("REACHABLE_DEBUG"):
                logger.info(f" EnvSecretsScanner error: {e}")
            return {}

    def _reanalyze_secrets_with_reachability(self, secrets_findings: Dict) -> Dict:
        """Re-analyze secrets with reachability information - preserves original findings"""
        try:
            if "findings" not in secrets_findings:
                return secrets_findings

            reachable_critical = 0
            reachable_other = 0
            unreachable = 0
            cwe_count = 0  # CWE findings (code issues, not secrets) - don't affect risk

            # Build a set of reachable file paths from function metadata
            reachable_files = set()
            reachable_file_bases = set()  # Just the filename without extension

            # Map file -> reachable functions (for showing call path)
            file_to_functions = {}

            # Get file paths from function_metadata if available
            if hasattr(self, "function_metadata"):
                for func_name, metadata in self.function_metadata.items():
                    if func_name in self.reachable_functions:
                        file_path = metadata.get("file", "") or metadata.get("file_path", "")
                        if file_path:
                            file_lower = file_path.lower()
                            reachable_files.add(file_lower)
                            # Also add just the filename
                            file_name = file_path.replace("\\", "/").split("/")[-1].lower()
                            file_base = file_name.rsplit(".", 1)[0] if "." in file_name else file_name
                            reachable_file_bases.add(file_base)

                            # Track which functions are in which file
                            if file_lower not in file_to_functions:
                                file_to_functions[file_lower] = []
                            file_to_functions[file_lower].append(func_name)

            # Also extract specific file patterns from entrypoints
            # e.g., "app.auth-service.main" -> "auth-service", "main"
            if hasattr(self, "entrypoints"):
                for ep in self.entrypoints:
                    parts = ep.split(".")
                    # Only add the last 1-2 parts which are likely file names
                    if len(parts) >= 2:
                        # Add the module/file name (e.g., 'auth-service' from 'app.auth-service.main')
                        module = parts[-2] if len(parts) >= 3 else parts[-1]
                        reachable_file_bases.add(module.lower())
                        reachable_file_bases.add(module.replace("-", "_").lower())
                        reachable_file_bases.add(module.replace("_", "-").lower())

            for finding in secrets_findings.get("findings", []):
                # Check if the file containing this secret is in reachable code
                file_path = finding.get("path", "") or finding.get("file", "")

                is_reachable = False
                reachable_via = []  # Functions that make this secret reachable

                if file_path:
                    file_lower = file_path.lower()
                    file_name = file_path.replace("\\", "/").split("/")[-1].lower()
                    file_base = file_name.rsplit(".", 1)[0] if "." in file_name else file_name

                    # Method 1: Direct file path match
                    if file_lower in reachable_files:
                        is_reachable = True
                        reachable_via = file_to_functions.get(file_lower, [])[:5]

                    # Method 2: Check if this exact file basename matches a reachable file
                    # This is strict - only matches if the file name itself is reachable
                    if not is_reachable and file_base in reachable_file_bases:
                        is_reachable = True
                        # Find matching functions
                        for f_path, funcs in file_to_functions.items():
                            if file_base in f_path.lower():
                                reachable_via.extend(funcs[:3])
                        reachable_via = reachable_via[:5]

                    # Method 3: Check for files that are commonly always reachable
                    # But be VERY conservative - only true entrypoint files
                    if not is_reachable:
                        entrypoint_names = {"main", "index", "app", "server", "cmd"}
                        if file_base in entrypoint_names:
                            is_reachable = True
                            reachable_via = ["<entrypoint>"]

                    # REMOVED: Method 4 (overly broad pattern matching)
                    # The old logic marked anything with 'api', 'handler', etc as reachable
                    # which is incorrect - just being in a directory doesn't mean reachable

                finding["is_reachable"] = is_reachable
                finding["reachable_via"] = reachable_via  # loader functions that touch this file

                # T-CG3: Build FULL call chain from entrypoint → loader → file for each loader
                if is_reachable and reachable_via and reachable_via != ["<entrypoint>"]:
                    all_chains: List[List[str]] = []
                    for loader_func in reachable_via[:3]:
                        for chain in self.get_all_paths(loader_func, max_paths=2, max_depth=12):
                            if chain:
                                # Append the actual file read as the final hop
                                full_chain = chain + [f"read({file_path})"]
                                if full_chain not in all_chains:
                                    all_chains.append(full_chain)
                    if all_chains:
                        finding["reachability_chains"] = all_chains  # full entrypoint→file chains
                        primary = all_chains[0]
                    else:
                        finding["reachability_chains"] = []
                        primary = reachable_via
                else:
                    finding["reachability_chains"] = []
                    primary = reachable_via if reachable_via else ["<config_file_loaded>"]

                if is_reachable:
                    finding["call_path"] = primary  # Array for report/dashboard
                    finding["reachability_path"] = json.dumps(primary)  # JSON for database

                # ═══════════════════════════════════════════════════════════════════════
                # REACHABILITY CONFIDENCE (Three-State Model)
                # ═══════════════════════════════════════════════════════════════════════
                # CONFIRMED: Loader function found in call graph → we KNOW it's used
                # UNKNOWN: No loader found → CAN'T PROVE it's safe, assume worst case
                # CONFIRMED_NOT: Evidence it's unused (e.g., dead code analysis)
                #
                # KEY INSIGHT: "No loader found" ≠ "Not used"
                # A .pem file might be loaded via:
                #   - Dynamic import we couldn't trace
                #   - External tool invocation (openssl, kubectl)
                #   - Environment variable reference
                #   - Framework auto-discovery (Spring, Django)
                #
                # SAFETY PRINCIPLE: If we can't PROVE it's dead, assume it's live
                # ═══════════════════════════════════════════════════════════════════════
                if is_reachable and reachable_via:
                    finding["reachability_confidence"] = "CONFIRMED"
                    finding["reachability_evidence"] = f"Loader found: {', '.join(reachable_via[:3])}"
                elif is_reachable:
                    # Marked reachable via entrypoint heuristic but no specific loader
                    finding["reachability_confidence"] = "HIGH"
                    finding["reachability_evidence"] = "Entrypoint file pattern detected"
                else:
                    # NO LOADER FOUND - this is UNKNOWN, not confirmed safe!
                    finding["reachability_confidence"] = "UNKNOWN"
                    finding["reachability_evidence"] = "No loader function found in call graph"

                    # v4.3.1 CRITICAL SECURITY FIX: UNKNOWN = treat as EXPLOITABLE for risk scoring
                    # When we can't prove a secret is unreachable, assume worst case for severity
                    # This affects .env files, config files, certificates, etc.
                    # v4.5.2 FIX: Do NOT set is_reachable=True - keep reachability as UNKNOWN
                    # Dashboard will show "Unknown" but severity stays CRITICAL
                    file_path = finding.get("file", "").lower()
                    if any(
                        x in file_path
                        for x in [
                            ".env",
                            ".yaml",
                            ".yml",
                            "config",
                            "docker",
                            "secret",
                            "credential",
                            ".pem",
                            ".key",
                        ]
                    ):
                        # v4.5.2: is_reachable left unset = UNKNOWN in dashboard
                        # reachability_confidence indicates how to treat for risk scoring
                        finding["v431_fix_applied"] = "UNKNOWN treated as EXPLOITABLE for risk"
                        finding["reachability_confidence"] = "UNKNOWN_EXPLOITABLE"
                    finding["needs_human_triage"] = True
                    finding["triage_reason"] = (
                        "Could not trace how this secret is loaded. May use dynamic imports, external tools, or framework auto-discovery."
                    )

                # Classify finding type: ACTUAL SECRET vs CWE FINDING
                rule_id = finding.get("check_id", finding.get("rule_id", ""))
                message = finding.get("message", "")

                # Patterns that indicate ACTUAL secrets (not just security issues)
                SECRET_PATTERNS = [
                    "hardcoded",
                    "secret",
                    "password",
                    "api-key",
                    "api_key",
                    "apikey",
                    "token",
                    "credential",
                    "private-key",
                    "private_key",
                    "aws-",
                    "gcp-",
                    "azure-",
                    "slack-",
                    "github-token",
                    "jwt",
                    "bearer",
                    "generic-",
                    "detected-",
                    "exposed-",
                    # Additional patterns for encryption/cookie secrets
                    "encryption",
                    "cipher",
                    "cookie_secret",
                    "cookie-secret",
                    "oauth_client",
                    "oauth-client",
                    "client_secret",
                    "client-secret",
                    "database_url",
                    "database-url",
                    "connection_string",
                    "private_key_base64",
                    "certificate_base64",
                ]

                # Check if this is an actual secret vs a CWE finding
                rule_lower = rule_id.lower()
                is_actual_secret = any(pat in rule_lower for pat in SECRET_PATTERNS)

                # Also check message for secret indicators
                if not is_actual_secret:
                    msg_lower = message.lower()
                    is_actual_secret = any(
                        word in msg_lower
                        for word in [
                            "hardcoded password",
                            "hardcoded secret",
                            "api key",
                            "credential",
                            "token detected",
                            "private key",
                            "exposed secret",
                        ]
                    )

                finding["is_actual_secret"] = is_actual_secret
                finding["finding_type"] = "SECRET" if is_actual_secret else "CWE"

                # ═══════════════════════════════════════════════════════════════════════
                # CISA/NIST SECRET SEVERITY MATRIX
                # Based on CISA SSVC (Stakeholder-Specific Vulnerability Categorization)
                # and NIST SP 800-204D (2024/2025)
                # ═══════════════════════════════════════════════════════════════════════
                #
                # Two dimensions:
                # 1. Active Status: Is the secret valid/active? (default: assume active)
                # 2. Reachability: Is it in code path (main/prod) or off-path (history/dev)?
                #
                # | Scenario          | Active | Reachable | Severity | Action | Timeline    |
                # |-------------------|--------|-----------|----------|--------|-------------|
                # | Toxic Combination | Yes    | Yes       | CRITICAL | ACT    | 1-48 hours |
                # | Exposed Asset     | Yes    | No        | HIGH     | ATTEND | 7 days      |
                # | Dead Link         | No     | Yes       | MEDIUM   | TRACK  | 30 days     |
                # | Security Debt     | No     | No        | LOW      | TRACK  | 90 days     |
                #
                # KEY DEFINITIONS:
                # ─────────────────
                # ACT IMMEDIATELY (Critical):
                #   - REVOKE: Kill the credential at the provider FIRST to stop the threat
                #   - ROTATE: Issue new secret into secure vault to restore service
                #   - The "Feds" treat this as an ACTIVE BREACH (lock + key both exposed)
                #
                # ATTEND (High):
                #   - Secret is not running but is a "live key" in Git history
                #   - Attackers can find it in seconds via GitHub search
                #   - ROTATE the key first; scrubbing history is secondary
                #
                # TRACK (Medium/Low):
                #   - Secret is already DEAD (revoked at provider)
                #   - The "vulnerability" is now just text that fails audit scans
                #   - Fix to clear dashboard and pass compliance, not to stop hackers
                #
                # AUDITOR JUSTIFICATION:
                # ──────────────────────
                # - VEX (Vulnerability Exploitability eXchange): Statement that vuln is
                #   "not affected" because it is unreachable from entrypoints
                # - Compensating Controls: "Secret is active but IP whitelist restricts
                #   access to internal VPN only"
                # ═══════════════════════════════════════════════════════════════════════

                # Determine active status (default to active unless verified inactive)
                # Tools like TruffleHog can verify; we assume active by default for safety
                is_active = finding.get("is_active", finding.get("verified_active", True))
                reachability_confidence = finding.get("reachability_confidence", "UNKNOWN")

                # Generate appropriate remediation based on CISA/NIST matrix
                if is_actual_secret:
                    secret_type = rule_id.split(".")[-1] if "." in rule_id else "credential"

                    # ═══════════════════════════════════════════════════════════════════════
                    # UNKNOWN REACHABILITY: Can't prove it's safe → CRITICAL + HUMAN TRIAGE
                    # This is the "assume breach" principle from zero-trust security
                    # ═══════════════════════════════════════════════════════════════════════
                    if is_active and reachability_confidence == "UNKNOWN":
                        finding["scenario"] = "UNKNOWN_REACHABILITY"
                        finding["effective_severity"] = "CRITICAL"
                        finding["action_category"] = "TRIAGE"
                        finding["needs_human_triage"] = True
                        finding["remediation"] = {
                            "action": "TRIAGE_THEN_ACT",
                            "action_label": " CRITICAL - NEEDS HUMAN TRIAGE",
                            "priority": "CRITICAL",
                            "scenario": "Unknown Reachability",
                            "scenario_description": "Active secret with NO LOADER FOUND - cannot prove it is safe",
                            "federal_timeline": "24-72 hours (triage) + action based on finding",
                            "breach_status": "UNKNOWN - Assume worst case until proven otherwise",
                            "why_critical": "We could not find a loader function for this secret. This does NOT mean it is safe - it may be loaded via dynamic imports, external tools (openssl, kubectl), environment variables, or framework auto-discovery. ASSUME IT IS USED until you can prove otherwise.",
                            "triage_steps": [
                                f"1. INVESTIGATE: Search codebase for references to this {secret_type} file",
                                "2. CHECK: Look for dynamic loading patterns (importlib, __import__, exec, eval)",
                                "3. CHECK: Look for shell/subprocess calls that might use this file",
                                "4. CHECK: Review framework configs (Spring, Django, etc.) for auto-discovery",
                                "5. VERIFY: Check if file is included in deployment artifacts (Docker, K8s)",
                                "6. DECIDE: If ANY doubt remains, treat as TOXIC_COMBINATION and rotate immediately",
                            ],
                            "if_used": "If investigation confirms this secret IS used → Treat as TOXIC_COMBINATION, rotate immediately",
                            "if_unused": "If investigation confirms this secret is NOT used → Document evidence, downgrade to SECURITY_DEBT",
                            "default_action": "When in doubt, ROTATE. The cost of unnecessary rotation << cost of breach.",
                            "compliance_refs": [
                                "Zero Trust Principle: Never trust, always verify",
                                "CISA: Assume breach",
                                "NIST SP 800-207",
                            ],
                            "file_path": file_path,
                            "line": finding.get("start", {}).get("line", finding.get("line", "?")),
                        }
                        reachable_critical += 1

                    elif is_active and is_reachable:
                        # ═══════════════════════════════════════════════════════════════
                        # TOXIC COMBINATION: Active + In-Path = CRITICAL → ACT IMMEDIATELY
                        # This is treated as an ACTIVE BREACH by federal standards
                        # ═══════════════════════════════════════════════════════════════
                        finding["scenario"] = "TOXIC_COMBINATION"
                        finding["effective_severity"] = "CRITICAL"
                        finding["action_category"] = "ACT"
                        finding["remediation"] = {
                            "action": "ACT_IMMEDIATELY",
                            "action_label": " ACT IMMEDIATELY",
                            "priority": "CRITICAL",
                            "scenario": "Toxic Combination",
                            "scenario_description": "Active secret in production code path - treated as ACTIVE BREACH",
                            "federal_timeline": "1-48 hours",
                            "breach_status": "ACTIVE - Lock and key are both exposed",
                            "steps": [
                                f"1. REVOKE: Kill this {secret_type} at the provider IMMEDIATELY (stops the threat)",
                                "2. ROTATE: Generate new credentials into a secrets manager (restores service)",
                                "3. AUDIT: Review provider access logs for unauthorized use during exposure window",
                                "4. SECURE: Ensure new secret uses proper access controls (IP whitelist, IAM policies)",
                            ],
                            "why_critical": "Federal auditors treat this as an active breach because both the credential value and its usage location are exposed to attackers.",
                            "compliance_refs": [
                                "CISA SSVC: Immediate action",
                                "NIST SP 800-204D",
                                "SOC2 CC6.1",
                                "PCI-DSS 8.3.1",
                            ],
                            "file_path": file_path,
                            "line": finding.get("start", {}).get("line", finding.get("line", "?")),
                        }
                        reachable_critical += 1

                    elif is_active and not is_reachable and reachability_confidence != "UNKNOWN":
                        # ═══════════════════════════════════════════════════════════════
                        # EXPOSED ASSET: Active + CONFIRMED Off-Path = HIGH → ATTEND
                        # Only applies when we have evidence it's not in code path
                        # (UNKNOWN cases are handled above as CRITICAL)
                        # ═══════════════════════════════════════════════════════════════
                        finding["scenario"] = "EXPOSED_ASSET"
                        finding["effective_severity"] = "HIGH"
                        finding["action_category"] = "ATTEND"
                        finding["remediation"] = {
                            "action": "ATTEND",
                            "action_label": " ATTEND (Rotate Priority)",
                            "priority": "HIGH",
                            "scenario": "Exposed Asset",
                            "scenario_description": 'Active "live key" in git history or non-production path',
                            "federal_timeline": "7 days (current sprint)",
                            "breach_status": "POTENTIAL - Key is valid and discoverable",
                            "steps": [
                                f"1. ROTATE: Generate new {secret_type} FIRST (makes old key useless)",
                                "2. VERIFY: Confirm old secret no longer grants access",
                                "3. SCRUB: Remove from git history using BFG Repo-Cleaner (secondary priority)",
                                "4. MONITOR: Set up alerts for access attempts with old credential",
                            ],
                            "why_high": "The secret is not in running code, but it IS a live key. Attackers actively scan GitHub for exposed credentials and can exploit within minutes of discovery.",
                            "vex_justification": 'VEX status: "affected" - Secret is valid but not in execution path. Compensating control: Rotate immediately to eliminate risk.',
                            "compliance_refs": ["NIST SSDF PW.1.1", "SOC2 CC6.7", "CIS Control 16"],
                            "file_path": file_path,
                            "line": finding.get("start", {}).get("line", finding.get("line", "?")),
                        }
                        reachable_other += 1  # Still counts but lower severity

                    elif not is_active and is_reachable:
                        # ═══════════════════════════════════════════════════════════════
                        # DEAD LINK: Inactive + In-Path = MEDIUM → TRACK
                        # Secret is revoked/dead - fix for compliance, not security
                        # ═══════════════════════════════════════════════════════════════
                        finding["scenario"] = "DEAD_LINK"
                        finding["effective_severity"] = "MEDIUM"
                        finding["action_category"] = "TRACK"
                        finding["remediation"] = {
                            "action": "TRACK",
                            "action_label": " TRACK (Compliance Fix)",
                            "priority": "MEDIUM",
                            "scenario": "Dead Link",
                            "scenario_description": "Revoked/inactive secret still referenced in production code",
                            "federal_timeline": "30 days (next sprint)",
                            "breach_status": "NONE - Secret is already dead/revoked",
                            "steps": [
                                "1. VERIFY: Confirm secret is truly revoked at provider (check revocation date)",
                                "2. DOCUMENT: Log revocation evidence for audit trail",
                                "3. REMOVE: Delete hardcoded value from source code",
                                "4. REFACTOR: Replace with environment variable or secrets manager reference",
                            ],
                            "why_medium": "The vulnerability is now just a text string. You fix this to clear your dashboard and pass compliance audits, not to stop an active hacker.",
                            "vex_justification": 'VEX status: "not_affected" - Credential has been revoked at provider. Technical justification: Revocation timestamp [document here].',
                            "compliance_refs": ["SOC2 CC6.1 (cleanup)", "FedRAMP AU-6"],
                            "file_path": file_path,
                            "line": finding.get("start", {}).get("line", finding.get("line", "?")),
                        }
                        unreachable += 1  # Lower risk category

                    else:
                        # ═══════════════════════════════════════════════════════════════
                        # SECURITY DEBT: Inactive + Off-Path = LOW → TRACK
                        # Dead secret in history only - lowest priority
                        # ═══════════════════════════════════════════════════════════════
                        finding["scenario"] = "SECURITY_DEBT"
                        finding["effective_severity"] = "LOW"
                        finding["action_category"] = "TRACK"
                        finding["remediation"] = {
                            "action": "TRACK",
                            "action_label": " TRACK (Technical Debt)",
                            "priority": "LOW",
                            "scenario": "Security Debt",
                            "scenario_description": "Revoked secret exists only in git history",
                            "federal_timeline": "90 days (address when convenient)",
                            "breach_status": "NONE - Secret is dead AND not in code path",
                            "steps": [
                                "1. VERIFY: Confirm revocation status at provider",
                                "2. DOCUMENT: Record revocation evidence for auditors",
                                "3. BACKLOG: Schedule git history cleanup for maintenance window",
                                "4. SCRUB: Use BFG Repo-Cleaner when convenient",
                            ],
                            "why_low": "This is purely technical debt. The secret cannot be exploited (revoked) and is not even in your running code. Fix when capacity allows.",
                            "vex_justification": 'VEX status: "not_affected" - Credential revoked AND unreachable. Compliant with NIST SP 800-204D exploitability-based prioritization.',
                            "auditor_note": "Federal auditors accept deferral if you provide: (1) Revocation timestamp, (2) Technical justification for unreachability.",
                            "compliance_refs": ["NIST SP 800-204D (exploitability prioritization)"],
                            "file_path": file_path,
                            "line": finding.get("start", {}).get("line", finding.get("line", "?")),
                        }
                        unreachable += 1
                else:
                    # CWE finding (not a secret) - needs CODE FIX
                    finding["remediation"] = {
                        "action": "CODE_FIX",
                        "priority": "MEDIUM" if is_reachable else "LOW",
                        "steps": [f"Fix: {message[:200]}", f"See rule documentation: {rule_id}"],
                        "file_path": file_path,
                        "line": finding.get("start", {}).get("line", finding.get("line", "?")),
                    }
                    # CWE finding - track separately
                    cwe_count += 1

            # Update summary - CWE findings noted but NOT in risk score
            secrets_findings["by_reachability"] = {
                "reachable_critical": reachable_critical,
                "reachable_other": reachable_other,
                "unreachable": unreachable,
                "total_reachable": reachable_critical + reachable_other,
                "sast_findings": cwe_count,
                "note": "CWE findings use reachability analysis - only reachable CWEs affect risk",
            }

            # ═══════════════════════════════════════════════════════════════════════
            # CWE REACHABILITY ANALYSIS (v2.9.40)
            # ═══════════════════════════════════════════════════════════════════════
            # Per the attached document: "A CWE detected by a SAST tool does not
            # automatically represent a real security vulnerability. Detection
            # indicates the presence of a risky code pattern, but exploitability
            # depends on whether the code is reachable from an exposed entry point."
            # ═══════════════════════════════════════════════════════════════════════
            try:
                from reachable.correlation.cwe_reachability import CWEReachabilityAnalyzer, ReachabilityStatus

                # Initialize CWE reachability analyzer with call graph data
                # v2.9.40: Pass function_imports for library CWE stitching
                cwe_analyzer = CWEReachabilityAnalyzer(
                    call_graph=dict(self.call_graph),
                    reachable_functions=self.reachable_functions,
                    all_functions=self.all_functions,
                    entry_points=self.entry_points if hasattr(self, "entry_points") else set(),
                    function_imports=dict(self.function_imports),  # library→app stitching
                    call_parents=dict(self.call_parents),  # T-CG1/T-CG4: multi-parent dict
                    entrypoint_reasons=getattr(self, "_entrypoint_reasons", {}),  # v1.0.0b15: endpoint labels
                )

                # Analyze each CWE finding
                cwe_reachable = 0
                cwe_unreachable = 0
                cwe_config_issues = 0
                cwe_test_only = 0

                for finding in secrets_findings.get("findings", []):
                    if not finding.get("is_actual_secret", False):
                        # This is a CWE finding - analyze reachability
                        result = cwe_analyzer.analyze_finding(finding)

                        # Update finding with CWE reachability data
                        finding["cwe_reachability"] = result.reachability.value
                        finding["cwe_category"] = result.category.value
                        finding["cwe_reachable_via"] = result.reachable_via
                        finding["cwe_risk_multiplier"] = result.risk_multiplier
                        finding["compliance_mapping"] = result.compliance_mapping

                        # Update reachability flag based on CWE analysis
                        if result.reachability == ReachabilityStatus.REACHABLE:
                            finding["is_reachable"] = True
                            finding["reachable_via"] = result.reachable_via
                            # v1.0.0b15: call_path is now a full traced path from entrypoint to
                            # vulnerable function e.g. ["POST /api/users", "routes.create", "db.query"]
                            # thanks to call_parents + entrypoint_reasons passed to the analyzer.
                            call_path_value = result.reachable_via if result.reachable_via else ["<code_location>"]
                            finding["call_path"] = call_path_value  # Array for report/dashboard
                            finding["reachability_path"] = json.dumps(call_path_value)  # JSON string for database
                            cwe_reachable += 1
                        elif result.reachability == ReachabilityStatus.CONFIG_ISSUE:
                            finding["is_reachable"] = True  # Config issues always count
                            finding["cwe_category"] = "config_cwe"
                            cwe_config_issues += 1
                        elif result.reachability == ReachabilityStatus.TEST_ONLY:
                            finding["is_reachable"] = False
                            cwe_test_only += 1
                        else:
                            finding["is_reachable"] = False
                            cwe_unreachable += 1

                # Update summary with CWE reachability stats
                secrets_findings["cwe_reachability"] = {
                    "total_cwe": cwe_count,
                    "reachable": cwe_reachable,
                    "unreachable": cwe_unreachable,
                    "config_issues": cwe_config_issues,
                    "test_only": cwe_test_only,
                    "note": "Only reachable CWEs and config issues affect risk score",
                }

                # Store CWE findings for report (v2.9.40)
                self._cwe_findings = [
                    f for f in secrets_findings.get("findings", []) if not f.get("is_actual_secret", False)
                ]

                # Enhanced CWE summary output
                if cwe_count > 0:
                    logger.info(" CWE CODE WEAKNESS REACHABILITY ANALYSIS")
                    logger.info("   KEY INSIGHT: CWE Detected ≠ CWE Exploitable")
                    logger.info("   Only CWEs in executable code paths are real vulnerabilities.")

                    # Summary counts
                    logger.info("   ┌─────────────────────────────────────────────────────────┐")
                    logger.info(f"   │ {f'Total CWE Issues: {cwe_count}':<55} │")
                    logger.info("   ├─────────────────────────────────────────────────────────┤")

                    if cwe_reachable > 0:
                        logger.info(f"   │ {f'REACHABLE (in execution path): {cwe_reachable}':<55} │")
                    if cwe_unreachable > 0:
                        logger.info(f"   │ {f'UNREACHABLE (dead code): {cwe_unreachable}':<55} │")
                    if cwe_config_issues > 0:
                        logger.info(f"   │ {f'CONFIG/DEPLOY (always relevant): {cwe_config_issues}':<55} │")
                    if cwe_test_only > 0:
                        logger.info(f"   │ {f'TEST ONLY (not production): {cwe_test_only}':<55} │")

                    logger.info("   └─────────────────────────────────────────────────────────┘")

                    # Risk reduction calculation
                    if cwe_unreachable > 0:
                        reduction_pct = round((cwe_unreachable / cwe_count) * 100, 1)
                        logger.info(f" CWE Workload Reduction: {reduction_pct}%")
                        logger.info(f" {cwe_unreachable} CWEs eliminated as non-exploitable (unreachable)")

                    # Show breakdown by CWE category
                    cwe_by_category = {}
                    for finding in self._cwe_findings:
                        cat = finding.get("cwe_category", "code_cwe")
                        cwe_by_category[cat] = cwe_by_category.get(cat, 0) + 1

                    if cwe_by_category:
                        logger.info(" By Category:")
                        cat_names = {
                            "code_cwe": "   Code Vulnerabilities",
                            "config_cwe": "   Config/Infrastructure",
                            "cicd": "   CI/CD Pipeline",
                            "deploy": "   Deployment Issues",
                        }
                        for cat, count in sorted(cwe_by_category.items(), key=lambda x: -x[1]):
                            name = cat_names.get(cat, f"   {cat}")
                            logger.info(f" {name}: {count}")

                    # Show top reachable CWEs
                    reachable_cwes = [f for f in self._cwe_findings if f.get("cwe_reachability") == "reachable"]
                    if reachable_cwes:
                        logger.info(" TOP REACHABLE CWEs (require action):")
                        for i, cwe in enumerate(reachable_cwes[:5], 1):
                            file_path = cwe.get("file", cwe.get("path", ""))
                            line = cwe.get("line", cwe.get("start", {}).get("line", "?"))
                            rule = cwe.get("rule_id", cwe.get("check_id", "")).split(".")[-1][:30]
                            cwe_id = cwe.get("cwe_id", "")
                            via = cwe.get("cwe_reachable_via", [])

                            location = f"{file_path}:{line}"
                            if len(location) > 40:
                                location = "..." + location[-37:]

                            func_info = ""
                            if via and via[0] != "<entrypoint>":
                                func_info = f" via {via[0][:20]}"

                            logger.info(f" {i}. [{cwe_id}] {rule}")
                            logger.info(f" {location}{func_info}")
            except Exception as e:
                # CWE reachability analysis failed - continue without it
                logger.info(f" CWE reachability analysis skipped: {e}")

            return secrets_findings
        except Exception as e:
            logger.info(f" Could not analyze secret reachability: {e}")
            return secrets_findings

    def _validate_secrets_active(self, secrets_findings: Dict) -> Dict:
        """
        v2.9.40: Validate if discovered secrets are actually active/working.

        Uses TruffleHog's built-in verification (calls APIs to check if secrets work).
        Falls back to custom validator if TruffleHog is not available.

        This is CRITICAL for risk prioritization:
        - ACTIVE secret + Reachable = CRITICAL (immediate action, potential breach)
        - ACTIVE secret + Unreachable = HIGH (rotate immediately, in git history)
        - UNVERIFIED secret = assume active for safety

        Returns:
            secrets_findings with validation status added to each finding
        """
        findings = secrets_findings.get("findings", [])
        if not findings:
            return secrets_findings

        # Filter to actual secrets only (not SAST findings)
        actual_secrets = [f for f in findings if f.get("is_actual_secret", False)]

        if not actual_secrets:
            logger.info(" No actual secrets found to validate")
            return secrets_findings

        # Try TruffleHog first (has built-in verification)
        try:
            from reachable.collectors.secrets.trufflehog import (
                TruffleHogScanner,
                merge_trufflehog_with_semgrep,
            )

            scanner = TruffleHogScanner(
                self.app_dir,
                verify_secrets=True,  # Enable verification
                scan_git_history=False,  # Current code only for speed
            )

            if scanner.is_available():
                ver_str = scanner.trufflehog_version or "unknown"
                logger.info(f" → Using TruffleHog {ver_str} for verification (800+ detectors)...")
                th_results = scanner.scan()

                if th_results and th_results.total_findings > 0:
                    # Merge TruffleHog verification into Semgrep findings
                    merged_findings, validation_stats = merge_trufflehog_with_semgrep(th_results, findings)

                    secrets_findings["findings"] = merged_findings
                    secrets_findings["validation_stats"] = validation_stats
                    secrets_findings["validation_source"] = "trufflehog"

                    active = validation_stats.get("active", 0)
                    unverified = validation_stats.get("unverified", 0)

                    logger.info(f" TruffleHog: {active} verified active, {unverified} unverified")

                    # Update by_reachability counts based on validation
                    self._update_reachability_with_validation(secrets_findings)

                    return secrets_findings
                else:
                    logger.info(" TruffleHog found no additional secrets")
            else:
                logger.info(" TruffleHog not installed - secret detection may be limited")
                logger.info("         • Cannot scan Git history for deleted/rotated secrets")
                logger.info("         • Cannot verify if detected secrets are active or inactive")
                logger.info("         Install: brew install trufflehog")
                logger.info("         For full history: git fetch --unshallow (if shallow clone)")
        except ImportError:
            logger.info(" TruffleHog scanner module not available")
        except Exception as e:
            logger.info(f" TruffleHog scan failed: {e}")

        # Fallback: Use custom validator for known secret types
        try:
            from reachable.collectors.secrets.validator import SecretValidator

            validator = SecretValidator(timeout=10)
            logger.info(f" → Using custom validator for {len(actual_secrets)} secrets...")

            active_count = 0
            inactive_count = 0
            unverified_count = 0

            for finding in findings:
                if not finding.get("is_actual_secret", False):
                    continue

                # Try to extract secret value
                secret_value = self._extract_secret_value(finding)

                if not secret_value:
                    finding["validation"] = {
                        "status": "skipped",
                        "is_active": True,
                        "confidence": 0.0,
                        "details": "Secret value not extractable",
                        "risk_multiplier": 1.0,
                    }
                    unverified_count += 1
                    continue

                # Determine secret type
                rule_id = finding.get("check_id", finding.get("rule_id", "")).lower()
                secret_type = self._detect_secret_type(secret_value, rule_id)

                # Validate
                result = validator.validate(secret_value, secret_type, {})

                finding["validation"] = {
                    "status": result.status.value,
                    "is_active": result.is_active,
                    "confidence": result.confidence,
                    "details": result.details,
                    "identity": result.identity,
                    "risk_multiplier": result.risk_multiplier,
                }
                finding["is_active"] = result.is_active
                finding["verified_active"] = result.is_active

                if result.is_active:
                    active_count += 1
                else:
                    inactive_count += 1

            secrets_findings["validation_stats"] = {
                "active": active_count,
                "inactive": inactive_count,
                "unverified": unverified_count,
                "total_validated": active_count + inactive_count,
                "verification_enabled": True,
                "source": "custom_validator",
            }

            logger.info(f" Validated: {active_count} active, {inactive_count} inactive, {unverified_count} unverified")

            self._update_reachability_with_validation(secrets_findings)

        except ImportError:
            logger.info(" Secret validator not available")
            secrets_findings["validation_stats"] = {
                "active": 0,
                "inactive": 0,
                "unverified": len(actual_secrets),
                "verification_enabled": False,
                "error": "No validator available",
            }
        except Exception as e:
            logger.info(f" Validation error: {e}")
            secrets_findings["validation_stats"] = {
                "active": 0,
                "inactive": 0,
                "unverified": len(actual_secrets),
                "verification_enabled": True,
                "error": str(e),
            }

        return secrets_findings

    def _extract_secret_value(self, finding: Dict) -> Optional[str]:
        """Extract secret value from finding for validation"""
        import re

        # Try 'extra.lines' first (Semgrep stores matched content here)
        secret_value = finding.get("extra", {}).get("lines", "")
        if secret_value and len(secret_value) >= 10:
            return secret_value.strip()

        # Try message for patterns
        message = finding.get("message", "")
        patterns = [
            r'["\']([A-Za-z0-9+/=_-]{20,})["\']',
            r"(ghp_[A-Za-z0-9]{36})",
            r"(gho_[A-Za-z0-9]{36})",
            r"(glpat-[A-Za-z0-9_-]{20})",
            r"(AKIA[0-9A-Z]{16})",
            r"(sk_live_[A-Za-z0-9]{24,})",
            r"(sk_test_[A-Za-z0-9]{24,})",
            r"(SG\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+)",
            r"(xoxb-[0-9]+-[0-9A-Za-z]+)",
            r"(sk-[A-Za-z0-9]{48})",
        ]

        for pattern in patterns:
            match = re.search(pattern, message)
            if match:
                return match.group(1)

        return None

    def _detect_secret_type(self, secret_value: str, rule_id: str) -> str:
        """Detect secret type from value and rule"""
        s = secret_value.strip()

        if s.startswith("ghp_") or s.startswith("gho_"):
            return "github_token"
        if s.startswith("glpat-"):
            return "gitlab_token"
        if s.startswith("AKIA"):
            return "aws_access_key"
        if s.startswith("sk_live_") or s.startswith("sk_test_"):
            return "stripe_key"
        if s.startswith("SG."):
            return "sendgrid_key"
        if s.startswith("xoxb-"):
            return "slack_token"
        if s.startswith("sk-") and len(s) > 40:
            return "openai_key"
        if s.startswith("npm_"):
            return "npm_token"
        if s.startswith("eyJ"):
            return "jwt_token"

        # Check rule_id
        if "aws" in rule_id:
            return "aws_access_key"
        if "github" in rule_id:
            return "github_token"
        if "gitlab" in rule_id:
            return "gitlab_token"
        if "slack" in rule_id:
            return "slack_token"
        if "stripe" in rule_id:
            return "stripe_key"

        return "unknown"

    def _update_reachability_with_validation(self, secrets_findings: Dict) -> None:
        """Update reachability classification based on validation results"""
        findings = secrets_findings.get("findings", [])

        reachable_active = 0
        reachable_inactive = 0
        unreachable = 0

        for finding in findings:
            if not finding.get("is_actual_secret", False):
                continue

            is_reachable = finding.get("is_reachable", False)
            validation = finding.get("validation", {})
            is_active = validation.get("is_active", True)  # Assume active if unknown

            if is_reachable:
                if is_active:
                    reachable_active += 1
                else:
                    reachable_inactive += 1
            else:
                unreachable += 1

            # Update effective severity based on validation
            if not is_active and finding.get("effective_severity") == "CRITICAL":
                finding["effective_severity"] = "HIGH"
                finding["action_category"] = "ATTEND"
                finding["scenario"] = "INACTIVE_SECRET"

        # Update by_reachability
        by_reach = secrets_findings.get("by_reachability", {})
        by_reach["reachable_active"] = reachable_active
        by_reach["reachable_inactive"] = reachable_inactive
        secrets_findings["by_reachability"] = by_reach
