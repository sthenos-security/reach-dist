# Copyright © 2026 Sthenos Security. All rights reserved.
"""OperationTimer — lightweight wall-clock profiler for scan phases."""

import logging
import time

logger = logging.getLogger(__name__)


class OperationTimer:
    """v4.3.1: Track execution time for every operation"""

    def __init__(self):
        self.start_times = {}
        self.durations = {}
        self.overall_start = time.time()

    def start(self, operation):
        """Start timing an operation"""
        self.start_times[operation] = time.time()

    def end(self, operation):
        """End timing and print duration"""
        if operation in self.start_times:
            duration = time.time() - self.start_times[operation]
            self.durations[operation] = duration
            logger.info(f" Completed in {self.format_time(duration)}")
            del self.start_times[operation]
            return duration
        return 0

    def format_time(self, seconds):
        """Format time for display"""
        if seconds < 1:
            return f"{int(seconds * 1000)}ms"
        elif seconds < 60:
            return f"{seconds:.1f}s"
        else:
            mins = int(seconds / 60)
            secs = seconds % 60
            return f"{mins}m {secs:.1f}s"


# Allow running as script or module
if __name__ == "__main__" and __package__ is None:
    import sys  # noqa: E402
    from pathlib import Path  # noqa: E402

    # Running as script - add project root to path
    # This allows imports like "from reachable.reporting.vex import ..."
    sys.path.insert(0, str(Path(__file__).parent.parent))
