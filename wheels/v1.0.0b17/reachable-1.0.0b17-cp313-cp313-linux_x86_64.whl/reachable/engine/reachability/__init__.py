# Copyright © 2026 Sthenos Security. All rights reserved.
"""
reachable.engine.reachability
==============================
Re-exports every symbol that was previously importable from the flat module.
All existing import paths continue to work without change.
"""

from ._analyzer import ReachabilityAnalyzer
from ._callgraph import CallGraphBuilder
from ._cli import main, monorepo_main
from ._report import print_summary
from ._timer import OperationTimer
from ._utils import _build_via_summary, _dedup_paths_by_via, _get_version, _normalize_go_fix_version

__all__ = [
    "ReachabilityAnalyzer",
    "CallGraphBuilder",
    "OperationTimer",
    "print_summary",
    "main",
    "monorepo_main",
    "_build_via_summary",
    "_dedup_paths_by_via",
    "_get_version",
    "_normalize_go_fix_version",
]
