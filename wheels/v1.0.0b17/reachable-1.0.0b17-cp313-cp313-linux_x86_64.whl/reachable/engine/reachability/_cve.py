#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.

"""
reachable - Build-Time Vulnerability Reachability Analyzer

Determines which CVEs are actually reachable in your code using static analysis.

Uses:
- AST parsing to build call graphs
- Syft-generated SBOM (dependencies)
- Grype-generated vulnerabilities
- Library source code for deep analysis

Output: Which CVEs are truly exploitable vs unreachable dead code
"""

import warnings

# Suppress urllib3 OpenSSL warning (common on macOS with LibreSSL)
warnings.filterwarnings("ignore", message=".*urllib3 v2 only supports OpenSSL.*")
warnings.filterwarnings("ignore", category=DeprecationWarning, module="urllib3")

import logging
from pathlib import Path
from typing import Dict, List, Set, Tuple

from ._utils import GIT_ANALYZER_AVAILABLE, _dedup_paths_by_via, _normalize_go_fix_version

try:
    from reachable.correlation.cve_functions import analyze_all_cves
except ImportError:
    analyze_all_cves = None  # type: ignore[assignment]

# Initialize module-level logger
logger = logging.getLogger(__name__)


# =========================================================================
# =========================================================================


class _CveMixin:
    """Mixin — mixed into ReachabilityAnalyzer. Uses self.* freely."""

    def _generate_remediation_guidance(
        self,
        cve_id: str,
        package: str,
        current_version: str,
        fix_versions: List[str],
        fix_state: str,
        severity: str,
        description: str,
    ) -> Dict:
        """
        Generate actionable remediation guidance for a CVE

        Returns:
            Dict with:
                - action: Primary remediation action (UPGRADE/PATCH/MITIGATE/REMOVE)
                - fix_available: Boolean
                - fixed_in: Version(s) that fix the issue
                - summary: Brief remediation summary
                - steps: List of remediation steps
                - workaround: Workaround if no fix available
                - references: Links to advisories
        """
        remediation = {
            "action": "INVESTIGATE",
            "fix_available": False,
            "fixed_in": None,
            "summary": f"Investigate {cve_id} in {package}",
            "steps": [],
            "workaround": None,
            "priority": "normal",
            "estimated_effort": "medium",
            "references": [],
        }

        # Add references
        if cve_id.startswith("CVE-"):
            remediation["references"].append(f"https://nvd.nist.gov/vuln/detail/{cve_id}")
        elif cve_id.startswith("GHSA-"):
            remediation["references"].append(f"https://github.com/advisories/{cve_id}")

        # Detect ecosystem from package name
        pkg_lower = package.lower()

        # Determine if fix is available
        if fix_versions and len(fix_versions) > 0:
            remediation["fix_available"] = True
            remediation["action"] = "UPGRADE"

            # v1.0.0b15: Normalize Go pseudo-versions to clean semver
            raw_fix = fix_versions[0]
            is_go = any(
                x in pkg_lower for x in ["golang.org", "github.com/", "k8s.io", "gopkg.in", "go.uber.org", "gopkg.in"]
            )
            resolved_fix = _normalize_go_fix_version(package, raw_fix) if is_go else raw_fix
            remediation["fixed_in"] = resolved_fix

            # Generate ecosystem-specific guidance
            if is_go:
                # Go package
                remediation["summary"] = f"Upgrade {package} to {resolved_fix}"
                remediation["steps"] = [
                    f"Update go.mod: require {package} {resolved_fix}",
                    "Run: go mod tidy",
                    "Run: go build ./... && go test ./...",
                    "Verify functionality with integration tests",
                ]
                remediation["estimated_effort"] = "low"

            elif pkg_lower.startswith("@") or any(
                x in pkg_lower for x in ["lodash", "express", "react", "axios", "webpack", "next", "postcss"]
            ):
                # NPM package
                remediation["summary"] = f"Upgrade {package} to {fix_versions[0]}"
                remediation["steps"] = [
                    f"Run: npm install {package}@{fix_versions[0]}",
                    "Or update package.json and run: npm install",
                    "Run: npm audit to verify the fix",
                    "Run: npm test to verify functionality",
                ]
                remediation["estimated_effort"] = "low"

            elif any(
                x in pkg_lower for x in ["requests", "flask", "django", "urllib3", "cryptography", "numpy", "pandas"]
            ):
                # Python package
                remediation["summary"] = f"Upgrade {package} to {fix_versions[0]}"
                remediation["steps"] = [
                    f"Run: pip install '{package}>={fix_versions[0]}'",
                    "Or update requirements.txt and run: pip install -r requirements.txt",
                    "Run: pip-audit to verify the fix",
                    "Run: pytest to verify functionality",
                ]
                remediation["estimated_effort"] = "low"

            else:
                # Generic guidance
                remediation["summary"] = f"Upgrade {package} to {fix_versions[0]}"
                remediation["steps"] = [
                    f"Update {package} to version {fix_versions[0]} or later",
                    "Update dependency manifest (go.mod, package.json, requirements.txt, etc.)",
                    "Run dependency installation",
                    "Run tests to verify functionality",
                ]
                remediation["estimated_effort"] = "low"

        elif fix_state == "wont-fix":
            remediation["action"] = "MITIGATE"
            remediation["summary"] = f"No fix planned for {cve_id} - implement workaround"
            remediation["workaround"] = "Consider replacing the package or implementing input validation"
            remediation["steps"] = [
                "Evaluate if the vulnerable functionality is used",
                "Implement input validation and sanitization",
                "Consider using an alternative package",
                "Add monitoring for exploitation attempts",
            ]
            remediation["estimated_effort"] = "high"

        elif fix_state == "not-fixed":
            remediation["action"] = "MITIGATE"
            remediation["summary"] = f"No fix available yet for {cve_id}"
            remediation["workaround"] = "Monitor for updates and implement compensating controls"
            remediation["steps"] = [
                "Subscribe to security advisories for this package",
                "Evaluate if the vulnerable code path is reachable",
                "Implement compensating controls (WAF rules, input validation)",
                "Consider removing the dependency if not critical",
            ]
            remediation["estimated_effort"] = "medium"

        else:
            remediation["action"] = "INVESTIGATE"
            remediation["summary"] = f"Investigate {cve_id} - fix status unknown"
            remediation["steps"] = [
                f"Check {package} release notes for security fixes",
                "Search for workarounds in security advisories",
                "Evaluate if the vulnerable code path is reachable",
            ]

        # Set priority based on severity
        if severity in ["CRITICAL", "HIGH"]:
            remediation["priority"] = "high"
        elif severity == "MEDIUM":
            remediation["priority"] = "normal"
        else:
            remediation["priority"] = "low"

        return remediation

    def _get_cve_compliance_mapping(self, cve_id: str, severity: str) -> Dict[str, List[str]]:
        """
        Get compliance standard mapping for a CVE.

        CVEs (vulnerable components) map to OWASP A06:2021 and related controls
        for managing third-party component risk.

        Args:
            cve_id: The CVE identifier
            severity: The CVE severity (CRITICAL, HIGH, MEDIUM, LOW)

        Returns:
            Dict mapping standard names to relevant requirements
        """
        # All CVEs (vulnerable components) map to these base requirements
        base_mapping = {
            "OWASP": ["A06:2021"],  # Vulnerable and Outdated Components
            "PCI-DSS": ["6.2", "6.3.2"],  # Secure development, patch management
            "NIST-800-53": ["SI-2", "RA-5", "CM-8"],  # Flaw remediation, vuln scanning, component inventory
            "SOC2": ["CC7.1"],  # System monitoring
            "CMMC": ["SI.L1-3.14.1"],  # Flaw remediation
            "NIST-800-171": ["3.14.1"],  # Flaw remediation
        }

        # Add severity-specific requirements
        if severity in ["CRITICAL", "HIGH"]:
            base_mapping["PCI-DSS"].extend(["6.5.1", "11.2"])  # Injection flaws, internal vuln scans
            base_mapping["NIST-800-53"].extend(
                [
                    "SI-3",
                    "IR-6",
                ]
            )  # Malicious code protection, incident reporting
            base_mapping["HIPAA"] = ["164.308(a)(5)(ii)(B)"]  # Security reminders
            base_mapping["FedRAMP"] = ["SI-2", "RA-5"]  # Same as NIST

        if severity == "CRITICAL":
            # Critical CVEs have immediate action requirements
            base_mapping["CISA-BOD"] = ["BOD-22-01"]  # Binding Operational Directive
            if "HIPAA" not in base_mapping:
                base_mapping["HIPAA"] = []
            base_mapping["HIPAA"].append("164.308(a)(1)(ii)(A)")  # Risk analysis

        return base_mapping

    def _map_cves_to_functions(self) -> Dict[str, dict]:
        """Map each CVE to functions that actually USE vulnerable code via import tracking"""
        #         logger.debug(" _map_cves_to_functions() called")
        cve_map = {}

        # Get all matches from Grype output
        matches = self.vulns.get("matches", [])
        if not matches:
            # Try alternative key names used by different Grype versions
            matches = self.vulns.get("vulnerabilities", [])

        # Debug: Show how many CVEs we're processing
        if not matches:
            return cve_map

        # Track which imports are direct vs transitive
        # app_imports was saved before library parsing
        direct_imports = set()
        if hasattr(self, "app_imports"):
            for import_path in self.app_imports.values():
                # Handle both list (from JS parser) and string (from Python parser)
                if isinstance(import_path, list):
                    for imp in import_path:
                        if isinstance(imp, str):
                            # Normalize: lowercase and replace chars for matching
                            normalized = imp.lower().replace("-", "_").replace("/", "_")
                            direct_imports.add(normalized)
                elif isinstance(import_path, str):
                    normalized = import_path.lower().replace("-", "_").replace("/", "_")
                    direct_imports.add(normalized)

        # Get fallback functions ONCE (not per CVE)
        fallback_funcs = set()
        entrypoints = getattr(self, "entrypoints", set())
        if entrypoints:
            # Use all entrypoints as fallback (they're all potentially affected)
            for ep in entrypoints:
                if not ep.startswith("lib."):
                    fallback_funcs.add(ep)

        # If no entrypoints, use app functions
        if not fallback_funcs:
            app_funcs = [f for f in self.all_functions if not f.startswith("lib.") and "node_modules" not in f]
            fallback_funcs.update(app_funcs[:20])  # Use more fallback functions

        for match in matches:
            # P2.21: Extract BOTH CVE and GHSA IDs from Grype
            vuln = match.get("vulnerability", {})
            primary_id = vuln.get("id", "UNKNOWN")

            if self.verbose:
                pass
            # logger.debug(f"EXTRACT: {primary_id}, relatedVulns={len(match.get('relatedVulnerabilities', []))}")

            cve_id = None
            ghsa_id = None

            # Extract from primary ID
            if primary_id.startswith("CVE-"):
                cve_id = primary_id
            elif primary_id.startswith("GHSA-"):
                ghsa_id = primary_id

            # Extract from relatedVulnerabilities (at MATCH level, not vulnerability level!)
            for rel in match.get("relatedVulnerabilities", []):
                if isinstance(rel, dict):
                    rel_id = rel.get("id", "")
                    if rel_id.startswith("CVE-") and not cve_id:
                        cve_id = rel_id
                    elif rel_id.startswith("GHSA-") and not ghsa_id:
                        ghsa_id = rel_id

            if self.verbose:
                pass
            # logger.debug(f" P2.21: {primary_id} -> cve_id={cve_id}, ghsa_id={ghsa_id}")

            # Format display ID
            if cve_id and ghsa_id:
                if primary_id.startswith("GHSA-"):
                    display_id = f"{ghsa_id} (CVE: {cve_id})"
                else:
                    display_id = f"{cve_id} (GHSA: {ghsa_id})"
            elif ghsa_id:
                display_id = f"{ghsa_id} ( No CVE assigned)"
            elif cve_id:
                display_id = cve_id
            else:
                display_id = primary_id

            # Use primary_id for dict key (backwards compat)
            cve_id_key = primary_id

            # Get artifact info
            artifact = match.get("artifact", {})
            package = artifact.get("name", "unknown")
            version = artifact.get("version", "unknown")

            # v1.0.0b16: Extract manifest path from grype artifact locations
            # e.g. [{"path": "/requirements.txt"}] → "requirements.txt"
            _artifact_locations = artifact.get("locations", [])
            _manifest_path = ""
            if _artifact_locations and isinstance(_artifact_locations, list):
                _first_loc = _artifact_locations[0]
                if isinstance(_first_loc, dict):
                    _manifest_path = (_first_loc.get("path") or "").lstrip("/")

            # Normalize package name same way as imports
            package_normalized = package.lower().replace("-", "_").replace(".", "_").replace("/", "_")

            # Find functions that import from this package
            affected_funcs = set()
            is_transitive = False

            # Check SBOM metadata first (most accurate)
            if self.sbom:
                for sbom_artifact in self.sbom.get("artifacts", []):
                    if sbom_artifact.get("name") == package:
                        metadata = sbom_artifact.get("metadata", {})
                        is_transitive = metadata.get("is_transitive", False)
                        break

            # Fallback: Check if this package is in direct imports
            if not is_transitive:
                is_direct_import = package_normalized in direct_imports
                if not is_direct_import:
                    # Package not directly imported - likely transitive
                    is_transitive = True

            # Use function_imports (tracks actual imports per function including transitive)
            for func, lib_imports in self.function_imports.items():
                # Skip library functions - we only care about app code
                if func.startswith("lib.") or "site-packages" in func:
                    continue

                # Check if this function imports from the vulnerable package
                for lib_import in lib_imports:
                    lib_import_normalized = lib_import.lower().replace("-", "_").replace(".", "_").replace("/", "_")

                    # Match: package name appears in import path
                    # e.g., package "urllib3" matches import "urllib3.poolmanager"
                    if package_normalized in lib_import_normalized:
                        affected_funcs.add(func)
                        break

            # FIXED: Don't use aggressive fallback that marks all entrypoints as affected
            # Instead, mark as "unknown" so it can be properly categorized
            # The old logic caused 100% CVE reachability which is wrong!
            reachability_unknown = False
            if not affected_funcs:
                # We couldn't determine which functions use this package
                # This could be: transitive dep, compiled dep, or parsing limitation
                affected_funcs = {"__unknown_affected_function__"}
                reachability_unknown = True

            vuln_data = match.get("vulnerability", match)  # Handle both formats

            # Extract CVSS score (try multiple locations where Grype might store it)
            cvss_score = None
            # CRITICAL: Normalize severity to uppercase - Grype may return mixed case
            cvss_severity = str(vuln_data.get("severity", "UNKNOWN")).upper()

            # Try cvss array
            if "cvss" in vuln_data and vuln_data["cvss"]:
                for cvss_entry in vuln_data["cvss"]:
                    if "metrics" in cvss_entry:
                        metrics = cvss_entry["metrics"]
                        if "baseScore" in metrics:
                            cvss_score = float(metrics["baseScore"])
                            break

            fix_info = vuln_data.get("fix", {})
            fix_state = fix_info.get("state", "unknown")  # 'fixed', 'not-fixed', 'wont-fix', 'unknown'
            fix_versions = fix_info.get("versions", [])
            is_fixable = fix_state in ["fixed", "wont-fix"]  # Has a known fix or won't fix

            # Generate remediation guidance
            remediation = self._generate_remediation_guidance(
                cve_id=cve_id_key,
                package=package,
                current_version=version,
                fix_versions=fix_versions,
                fix_state=fix_state,
                severity=cvss_severity,
                description=vuln_data.get("description", ""),
            )

            # Filter out internal placeholder before storing
            displayed_funcs = [f for f in affected_funcs if f != "__unknown_affected_function__"]

            # logger.debug(f"STORE: key={cve_id_key}, cve={cve_id}, ghsa={ghsa_id}, display={display_id}")
            cve_map[cve_id_key] = {
                "cve": primary_id,  # Primary ID (for backwards compat)
                "cve_id": cve_id,  # P2.21: CVE ID
                "ghsa_id": ghsa_id,  # P2.21: GHSA ID
                "display_id": display_id,  # P2.21: Formatted display string
                "package": package,
                "version": version,
                "manifest_path": _manifest_path,  # v1.0.0b16: e.g. "requirements.txt"
                "severity": cvss_severity,
                "cvss_score": cvss_score,
                "description": vuln_data.get("description", ""),
                "urls": vuln_data.get("urls", []),  # P2.21: Reference URLs
                "dataSource": vuln_data.get("dataSource", ""),  # P2.21: NVD/GHSA link
                "affected_functions": sorted(displayed_funcs),
                "reachability_unknown": reachability_unknown,
                "is_fixable": is_fixable,
                "fix_state": fix_state,
                "fix_versions": fix_versions,
                "remediation": remediation,
                "is_transitive": is_transitive,
                "dependency_depth": 0,  # v1.0.0b15: populated below
                "dependency_chain": [],  # v1.0.0b15: populated below
                "via_package": "",  # v1.0.0b15: populated below
                "compliance_mapping": self._get_cve_compliance_mapping(cve_id_key, cvss_severity),
            }

        # v1.0.0b15: Populate dependency chain for all CVEs
        _app_name = getattr(self, "app_name", "") or getattr(self, "repo_name", "") or "app"
        _parents_map = getattr(self, "transitive_parents", {})
        _direct_imports_set = getattr(self, "direct_imports", set())
        for _key, _entry in cve_map.items():
            _pkg = _entry.get("package", "")
            _is_trans = _entry.get("is_transitive", False)
            _pkg_norm = _pkg.lower().replace("-", "_").replace(".", "_").replace("/", "_")

            # Find which direct dep transitively pulls in this package using transitive_parents.
            # transitive_parents = {direct_lib: {transitive_lib: parent_lib, ...}, ...}
            _direct_import = _pkg  # default (direct)
            for _direct_lib, _parents in _parents_map.items():
                _trans_norm = {k.lower().replace("-", "_").replace(".", "_"): k for k in _parents}
                if _pkg_norm in _trans_norm:
                    _direct_import = _direct_lib
                    break

            _chain, _depth, _via = self._get_dep_chain(_pkg, _direct_import, _app_name)
            _entry["dependency_depth"] = _depth if _is_trans else 0
            _entry["dependency_chain"] = _chain
            _entry["via_package"] = _via if _is_trans else ""

        return cve_map

    def _classify_cves(self, cve_mappings: Dict) -> Tuple[dict, dict]:
        """Classify CVEs with module and function-level reachability"""
        reachable = {}
        unreachable = {}

        for cve_id, cve_data in cve_mappings.items():
            affected = set(cve_data["affected_functions"])

            # Check for unknown affected functions (couldn't determine which code uses this package)
            is_unknown = "__unknown_affected_function__" in affected
            if is_unknown:
                affected.discard("__unknown_affected_function__")

            reachable_funcs = affected & self.reachable_functions
            unreachable_funcs = affected - self.reachable_functions

            # Determine reachability status
            if is_unknown and not reachable_funcs:
                # We don't know which functions use this package
                # Mark as UNKNOWN - requires investigation
                reachability_status = "UNKNOWN"
                is_reachable = False  # Conservative: don't mark as reachable without evidence
            elif reachable_funcs:
                reachability_status = "REACHABLE"
                is_reachable = True
            else:
                reachability_status = "UNREACHABLE"
                is_reachable = False

            # Build comprehensive reachability info
            result = {
                **cve_data,
                "reachable_functions": sorted(reachable_funcs),
                "unreachable_functions": sorted(unreachable_funcs),
                "reachability_status": reachability_status,
                "reachability_unknown": is_unknown,  # Flag for special handling
                "is_reachable": is_reachable,  # Boolean for verdict engine
            }

            # Add module-level reachability summary
            result["module_reachability"] = {
                "total_app_functions_using_module": len(affected),
                "reachable_app_functions": len(reachable_funcs),
                "unreachable_app_functions": len(unreachable_funcs),
                "module_status": reachability_status,
            }

            # Add function-level reachability if git analysis available
            if "git_analysis" in cve_data:
                git = cve_data["git_analysis"]
                vulnerable_funcs_data = []

                if git.get("vulnerable_functions"):
                    for vuln_func in git["vulnerable_functions"]:
                        func_name = vuln_func.get("full_path", vuln_func.get("function", ""))

                        # Determine if this specific vulnerable function is reachable
                        # Check if any app function calls into this vulnerable function
                        func_reachability = self._check_vulnerable_function_reachability(
                            func_name, vuln_func.get("module", ""), reachable_funcs
                        )

                        vulnerable_funcs_data.append(
                            {
                                "function": vuln_func.get("function", "unknown"),
                                "full_path": func_name,
                                "file": vuln_func.get("file", ""),
                                "change_type": vuln_func.get("change_type", "unknown"),
                                "reachability": func_reachability,
                            }
                        )

                result["vulnerable_functions_detail"] = vulnerable_funcs_data

                # Add analysis confidence summary
                if git.get("fix_commit"):
                    result["git_metadata"] = {
                        "commit_sha": git["fix_commit"].get("sha", ""),
                        "commit_sha_short": git["fix_commit"].get("sha_short", ""),
                        "commit_date": git["fix_commit"].get("date", ""),
                        "commit_author": git["fix_commit"].get("author", ""),
                        "commit_message": git["fix_commit"].get("message", ""),
                        "analysis_confidence": git.get("analysis_metadata", {}).get("confidence", "unknown"),
                    }

            # Classify: REACHABLE goes to reachable bucket, everything else to unreachable
            # UNKNOWN CVEs go to unreachable but are flagged for investigation
            if is_reachable:
                # T-CG2: collect ALL paths from ALL reachable funcs, then dedup by via-group
                package = cve_data.get("package", "")
                is_transitive = cve_data.get("is_transitive", False)
                raw_paths: List[List[str]] = []

                for func in list(reachable_funcs)[:10]:
                    for path in self.get_all_paths(func, max_paths=3, max_depth=12):
                        if not path:
                            continue
                        if is_transitive and package:
                            # Append the via-import then the vuln package as final hops
                            direct_imports = list(self.function_imports.get(func, set()))[:1]
                            if direct_imports and direct_imports[0] not in path:
                                path = path + [direct_imports[0], package]
                            elif package not in path:
                                path = path + [package]
                        elif package and package not in path:
                            # v1.0.0b16: Direct deps also need the vulnerable package
                            # as the terminal hop so the path shows caller → package
                            path = path + [package]
                        if path not in raw_paths:
                            raw_paths.append(path)

                # Deduplicate: keep ≤2 paths per via-group, ≤10 total
                call_paths_arrays = _dedup_paths_by_via(raw_paths, package)[:10]

                # call_paths stored as arrays (List[List[str]]) going forward
                result["call_paths"] = call_paths_arrays
                result["call_paths_count"] = len(call_paths_arrays)

                # Backward-compat: primary path as flat array for dashboard/DB
                if call_paths_arrays:
                    result["reachability_path"] = call_paths_arrays[0]
                    result["call_path"] = call_paths_arrays[0]
                reachable[cve_id] = result
            else:
                unreachable[cve_id] = result

        return reachable, unreachable

    def _check_vulnerable_function_reachability(
        self, vuln_func_path: str, module: str, reachable_app_funcs: Set[str]
    ) -> Dict:
        """
        Check if a specific vulnerable function is reachable

        Returns reachability status with confidence level:
        - CONFIRMED_REACHABLE: App directly calls this vulnerable function
        - LIKELY_REACHABLE: App calls module, vulnerable function is in module
        - UNREACHABLE: No reachable path to this function
        """

        # Check if any reachable app function calls this vulnerable function
        for app_func in reachable_app_funcs:
            if app_func in self.call_graph:
                for callee in self.call_graph[app_func]:
                    # Direct match: app calls the vulnerable function
                    if vuln_func_path in callee or callee in vuln_func_path:
                        return {
                            "status": "CONFIRMED_REACHABLE",
                            "confidence": "HIGH",
                            "reason": f"Called by {app_func}",
                            "call_path": f"{app_func} → {callee}",
                        }

                    # Module match: app calls something in the vulnerable module
                    if module and module.lower() in callee.lower():
                        # Function might be called internally
                        return {
                            "status": "LIKELY_REACHABLE",
                            "confidence": "MEDIUM",
                            "reason": f"{app_func} calls {module} (internal call to {vuln_func_path} possible)",
                            "call_path": f"{app_func} → {callee} → (internal)",
                        }

        # Check if any reachable function uses the module at all
        for app_func in reachable_app_funcs:
            if app_func in self.call_graph:
                for callee in self.call_graph[app_func]:
                    if module and module.lower() in callee.lower():
                        return {
                            "status": "POSSIBLY_REACHABLE",
                            "confidence": "LOW",
                            "reason": f"Module {module} is used, but cannot confirm this specific function",
                            "call_path": f"{app_func} → {module}.*",
                        }

        return {
            "status": "UNREACHABLE",
            "confidence": "HIGH",
            "reason": "No reachable code path found",
            "call_path": None,
        }

    def _fetch_exploitability(self, all_cves: Dict) -> Dict:
        """
        Fetch exploitability data for all CVEs

        Queries:
        - KEV (CISA Known Exploited Vulnerabilities)
        - EPSS (Exploit Prediction Scoring System)
        - Exploit-DB (public exploit availability)
        - Metasploit (weaponized exploit modules)

        Args:
            all_cves: Dict of all CVEs (reachable + unreachable)

        Returns:
            Dict mapping CVE ID -> exploitability info
        """
        try:
            from reachable.enrichment.exploitability import ExploitabilityDataFetcher, ExploitabilityInfo
        except ImportError:
            logger.info(" Exploitability module not available")
            return {}

        try:
            from reachable.collectors.vulns.ghsa import GHSAMapper

            ghsa_mapper_available = True
        except ImportError:
            ghsa_mapper_available = False

        # Extract CVE IDs and GHSA IDs
        cve_ids = list(all_cves.keys())

        if not cve_ids:
            return {}

        # Initialize fetcher with cache
        cache_dir = Path.home() / ".reachable" / "cache"
        fetcher = ExploitabilityDataFetcher(cache_dir=cache_dir)

        # Map GHSA IDs to CVE IDs
        ghsa_to_cve_map = {}
        if ghsa_mapper_available:
            ghsa_ids = [cve_id for cve_id in cve_ids if cve_id.startswith("GHSA-")]
            if ghsa_ids:
                mapper = GHSAMapper(cache_dir=cache_dir)
                ghsa_to_cve_map = mapper.get_cve_ids_batch(ghsa_ids)

        # OPTIMIZATION: Pre-fetch KEV and EPSS data in batch (instead of 1-by-1 in loop)
        logger.info(f" Fetched data for {len(cve_ids)} CVEs")
        kev_data = fetcher.fetch_kev_data()

        # Build list of CVE IDs for EPSS lookup (map GHSA to CVE first)
        epss_lookup_ids = []
        for cve_id in cve_ids:
            if cve_id.startswith("GHSA-"):
                mapped_cve = ghsa_to_cve_map.get(cve_id)
                if not mapped_cve:
                    # P2.21: Use cve_id field directly
                    cve_info = all_cves.get(cve_id, {})
                    mapped_cve = cve_info.get("cve_id")
                epss_lookup_ids.append(mapped_cve if mapped_cve else cve_id)
            else:
                epss_lookup_ids.append(cve_id)

        epss_data = fetcher.fetch_epss_scores(epss_lookup_ids)

        # Fetch data for each CVE
        exploitability_map = {}
        failed_cves = 0

        for cve_id in cve_ids:
            try:
                cve_data = all_cves.get(cve_id, {})  # SAFE ACCESS

                # Get CVSS from Grype data
                cvss_score = cve_data.get("cvss_score")
                cvss_severity = cve_data.get("severity")

                # Determine which ID to use for threat intel lookups
                lookup_id = cve_id
                mapped_cve = None

                # If this is a GHSA ID, try to get the CVE ID
                if cve_id.startswith("GHSA-"):
                    mapped_cve = ghsa_to_cve_map.get(cve_id)
                    if mapped_cve:
                        lookup_id = mapped_cve
                    # P2.21: Use cve_id field directly
                    else:
                        mapped_cve = cve_data.get("cve_id")
                        if mapped_cve:
                            lookup_id = mapped_cve
                            lookup_id = mapped_cve

                # Build exploitability info from pre-fetched data (NO API calls in loop)
                info = ExploitabilityInfo(cve_id=lookup_id, cvss_score=cvss_score, cvss_severity=cvss_severity)

                # Check KEV (pre-fetched)
                if lookup_id in kev_data:
                    info.in_kev = True
                    info.kev_date_added = kev_data[lookup_id].get("date_added")
                    info.kev_due_date = kev_data[lookup_id].get("due_date")

                # Check EPSS (pre-fetched)
                if lookup_id in epss_data:
                    info.epss_score = epss_data[lookup_id].get("score")
                    info.epss_percentile = epss_data[lookup_id].get("percentile")

                # Check Exploit-DB (if available) - SAFE
                try:
                    if fetcher._exploit_checkers_available and fetcher.exploitdb:
                        exploitdb_data = fetcher.exploitdb.check_cve(lookup_id)
                        if exploitdb_data:
                            info.exploit_db_available = True
                            info.exploit_db_count = exploitdb_data.get("exploit_count", 0)
                            info.exploit_db_verified = exploitdb_data.get("verified_count", 0)
                except Exception:
                    pass  # Exploit-DB is optional

                # Check Metasploit (if available) - SAFE
                try:
                    if fetcher._exploit_checkers_available and fetcher.metasploit:
                        metasploit_data = fetcher.metasploit.check_cve(lookup_id)
                        if metasploit_data:
                            info.metasploit_module = True
                            info.metasploit_count = metasploit_data.get("module_count", 0)
                            info.metasploit_rank = metasploit_data.get("highest_rank")
                except Exception:
                    pass  # Metasploit is optional

                # Calculate priority tier - SAFE
                try:
                    fetcher._assign_priority_tier(info)
                except Exception:
                    pass  # Priority tier calculation is optional

                exploitability_map[cve_id] = {
                    "kev": (
                        {
                            "in_catalog": info.in_kev,
                            "date_added": info.kev_date_added,
                            "due_date": info.kev_due_date,
                        }
                        if info.in_kev
                        else {"in_catalog": False}
                    ),
                    "epss": (
                        {"score": info.epss_score, "percentile": info.epss_percentile}
                        if info.epss_score is not None
                        else {}
                    ),
                    "cvss": {"score": cvss_score, "severity": cvss_severity},
                    "exploit_db": (
                        {
                            "exploit_available": info.exploit_db_available,
                            "exploit_count": info.exploit_db_count,
                            "verified_count": info.exploit_db_verified,
                        }
                        if info.exploit_db_available
                        else {"exploit_available": False}
                    ),
                    "metasploit": (
                        {
                            "module_available": info.metasploit_module,
                            "module_count": info.metasploit_count,
                            "highest_rank": info.metasploit_rank,
                        }
                        if info.metasploit_module
                        else {"module_available": False}
                    ),
                    # Include mapping info for transparency
                    "id_mapping": (
                        {
                            "original_id": cve_id,
                            "lookup_id": lookup_id,
                            "mapped_cve": mapped_cve,
                            "is_ghsa": cve_id.startswith("GHSA-"),
                        }
                        if cve_id != lookup_id
                        else None
                    ),
                }

            except Exception as e:
                # Log but continue with other CVEs - GRACEFUL FAILURE
                failed_cves += 1
                if failed_cves <= 5:
                    logger.info(f" Failed to process {cve_id}: {str(e)[:100]}")
                elif failed_cves == 6:
                    logger.info(" ... suppressing further CVE processing errors")

                # Add minimal entry so CVE isn't lost
                exploitability_map[cve_id] = {
                    "kev": {"in_catalog": False},
                    "epss": {},
                    "cvss": {
                        "score": all_cves.get(cve_id, {}).get("cvss_score"),
                        "severity": all_cves.get(cve_id, {}).get("severity"),
                    },
                    "exploit_db": {"exploit_available": False},
                    "metasploit": {"module_available": False},
                }

        if failed_cves > 0:
            success_rate = ((len(cve_ids) - failed_cves) / len(cve_ids)) * 100
            logger.info(
                f" Processed {len(cve_ids) - failed_cves}/{len(cve_ids)} CVEs successfully ({success_rate:.1f}%)"
            )

        return exploitability_map

    def _calculate_verdicts(self, all_cves: Dict, exploitability_data: Dict) -> Dict:
        """
        Calculate priority verdicts for all CVEs

        Combines reachability + exploitability to produce actionable verdicts.

        Args:
            all_cves: Dict of all CVEs with reachability info
            exploitability_data: Dict of exploitability data

        Returns:
            Dict mapping CVE ID -> verdict
        """
        try:
            from reachable.correlation.risk import RiskEngine
        except ImportError:
            try:
                from reachable.output.verdict import VerdictEngine as RiskEngine
            except ImportError:
                logger.info(" Risk module not available")
                return {}

        engine = RiskEngine()
        verdicts = {}

        for cve_id, cve_data in all_cves.items():
            # Get reachability status
            is_reachable = cve_data.get("is_reachable", False)

            # Get exploitability data
            exploit_data = exploitability_data.get(cve_id, {})

            kev_data = exploit_data.get("kev", {})
            epss_data = exploit_data.get("epss", {})
            cvss_data = exploit_data.get("cvss", {})
            exploitdb_data = exploit_data.get("exploit_db", {})
            metasploit_data = exploit_data.get("metasploit", {})

            # Get severity - try CVSS data first, then CVE data (v2.9.75)
            cvss_severity = cvss_data.get("severity") or cve_data.get("severity")

            # Calculate verdict
            verdict = engine.calculate_verdict(
                cve_id=cve_id,
                is_reachable=is_reachable,
                in_kev=kev_data.get("in_catalog", False),
                epss_score=epss_data.get("score"),
                cvss_score=cvss_data.get("score"),
                cvss_severity=cvss_severity,
                exploit_db_available=exploitdb_data.get("exploit_available", False),
                metasploit_module=metasploit_data.get("module_available", False),
            )

            verdicts[cve_id] = {
                "level": verdict.verdict_level.value,
                "name": verdict.verdict_name,
                "action_timeline": verdict.action_timeline,
                "risk_score": verdict.risk_score,
                "reasoning": verdict.reasoning,
            }

        return verdicts

    def _analyze_cve_git_history(self) -> Dict:
        """Analyze CVEs via git history to find vulnerable functions"""
        if not GIT_ANALYZER_AVAILABLE:
            return {}

        if not self.libs_dir or not self.libs_dir.exists():
            return {}

        # Build map of package names to their repo paths
        lib_repos = {}

        # Strategy 1: Check if libs_dir itself is inside a git repo
        # (handles case where libs_dir = libs/urllib3/src)
        current = self.libs_dir
        for _ in range(3):  # Check up to 3 levels up
            if (current / ".git").exists():
                # Found a git repo - extract package name
                # e.g., /path/to/libs/urllib3 → package name is 'urllib3'
                package_name = current.name
                lib_repos[package_name] = current
                break
            if current.parent == current:  # Reached root
                break
            current = current.parent

        # Strategy 2: Check for package directories under libs/ parent
        # (handles case where libs_dir = libs/ and contains urllib3/, requests/, etc.)
        libs_parent = self.libs_dir
        if libs_parent.name in ["src", "lib"]:  # If we're in src/lib, go up
            libs_parent = libs_parent.parent
            if libs_parent.name in ["urllib3", "requests"]:  # Still inside a package
                libs_parent = libs_parent.parent  # Go to libs/

        if libs_parent.exists() and libs_parent.is_dir():
            for package_dir in libs_parent.iterdir():
                if package_dir.is_dir() and not package_dir.name.startswith("."):
                    package_name = package_dir.name

                    # Check if it's a git repo
                    if (package_dir / ".git").exists():
                        lib_repos[package_name] = package_dir

        if not lib_repos:
            return {}

        try:
            # Use the git analyzer to analyze all CVEs
            git_analyses = analyze_all_cves(self.vulns, lib_repos)
            return git_analyses
        except Exception as e:
            logger.info(f" Git analysis failed: {e}")
            return {}
