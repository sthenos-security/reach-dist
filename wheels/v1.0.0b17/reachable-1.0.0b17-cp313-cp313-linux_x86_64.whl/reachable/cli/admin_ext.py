#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.
"""Admin-only commands not exposed in the main CLI."""

import logging

logger = logging.getLogger(__name__)


def network_config_command(args=None):
    """Display network timeout configurations used by REACHABLE."""
    logger.info("REACHABLE NETWORK TIMEOUT CONFIGURATION")

    timeouts = {
        "API Calls": {
            "description": "Quick lookups (EPSS, KEV, ExploitDB, Metasploit)",
            "connect": 10,
            "read": 30,
            "total": 40,
            "locations": [
                "epss_enrichment.py",
                "kev_enrichment.py",
                "exploitdb_enrichment.py",
                "metasploit_enrichment.py",
            ],
        },
        "Downloads": {
            "description": "Large file downloads (vulnerability DB, YARA rules)",
            "connect": 20,
            "read": 120,
            "total": 140,
            "locations": ["vulndb.py (grype DB download)", "yara_rules_manager.py"],
        },
        "Health Checks": {
            "description": "Fast pings (GitHub, PyPI, npm)",
            "connect": 5,
            "read": 10,
            "total": 15,
            "locations": ["health_metrics.py"],
        },
        "Enrichment": {
            "description": "Multi-step enrichment (GHSA API with rate limits)",
            "connect": 15,
            "read": 45,
            "total": 60,
            "locations": ["ghsa_enrichment.py"],
        },
    }

    for category, config in timeouts.items():
        logger.info(f"{category}")
        logger.info(f"  Purpose: {config['description']}")
        logger.info(f"  Connect: {config['connect']}s  Read: {config['read']}s  Total: {config['total']}s")
        for loc in config["locations"]:
            logger.info(f"  - {loc}")

    logger.info("")
    logger.info("PRINCIPLES")
    logger.info("  Connect < Read  — fail fast on unreachable hosts")
    logger.info("  Total = Connect + Read  — no indefinite hangs")
    logger.info("  Category-specific: health 15s / API 40s / downloads 140s")
    return 0
