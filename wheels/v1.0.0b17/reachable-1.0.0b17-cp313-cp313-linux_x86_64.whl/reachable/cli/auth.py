#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.
"""
reachctl auth — manage credentials for REACHABLE.

Commands:
    reachctl auth login              Prompt for all tokens, store securely
    reachctl auth status             Show what's configured (masked)
    reachctl auth set <name>         Set or rotate one credential
    reachctl auth remove <name>      Remove one credential from store
    reachctl auth logout             Remove all stored credentials

Credential names:
    github-token       GitHub personal access token
    github-mcp-token   GitHub MCP token (optional)
    anthropic-api-key  Anthropic API key for enzo --mode cloud --provider claude
    groq-api-key       Groq API key for enzo --mode cloud --provider groq
"""

from __future__ import annotations

import getpass
import logging

logger = logging.getLogger(__name__)


def setup_auth_parser(subparsers) -> None:
    """Add auth subcommand to main CLI parser."""
    auth_parser = subparsers.add_parser(
        "auth",
        help="Manage credentials (GitHub, Anthropic, Groq)",
        description="Store and manage authentication tokens securely. "
        "Desktop: stored in system keychain (macOS) or encrypted file (Linux). "
        "CI/CD: use pipeline secrets as environment variables instead.",
    )
    auth_subs = auth_parser.add_subparsers(dest="auth_action")

    auth_subs.add_parser(
        "login",
        help="Prompt for all tokens and store in system keychain",
    )
    auth_subs.add_parser(
        "status",
        help="Show configured credentials (masked)",
    )

    set_p = auth_subs.add_parser(
        "set",
        help="Set or rotate a single credential",
    )
    set_p.add_argument(
        "cred_name",
        metavar="NAME",
        nargs="?",
        help="Credential name (github-token, github-mcp-token, anthropic-api-key)",
    )

    rm_p = auth_subs.add_parser(
        "remove",
        help="Remove a single credential from store",
    )
    rm_p.add_argument(
        "cred_name",
        metavar="NAME",
        nargs="?",
        help="Credential name to remove",
    )

    auth_subs.add_parser(
        "logout",
        help="Remove all stored credentials",
    )


def auth_command(args) -> int:
    """Handle auth subcommands."""
    action = getattr(args, "auth_action", None)

    if action == "login":
        return _auth_login()
    elif action == "status":
        return _auth_status()
    elif action == "set":
        name = getattr(args, "cred_name", None)
        return _auth_set(name)
    elif action == "remove":
        name = getattr(args, "cred_name", None)
        return _auth_remove(name)
    elif action == "logout":
        return _auth_logout()
    else:
        _auth_status()
        print()
        print("Commands:")
        print("  reachctl auth login              Store all credentials")
        print("  reachctl auth status             Show configured credentials")
        print("  reachctl auth set <name>         Set or rotate one credential")
        print("  reachctl auth remove <name>      Remove one credential")
        print("  reachctl auth logout             Remove all stored credentials")
        print()
        print("Credential names:")
        print("  github-token, github-mcp-token, anthropic-api-key, groq-api-key")
        return 0


# ═══════════════════════════════════════════════════════════════════════════
#  Login — bulk interactive setup
# ═══════════════════════════════════════════════════════════════════════════


def _format_error(error: str) -> str:
    """Clean up raw error for display."""
    if error.startswith("network:"):
        return "unreachable (network error)"
    return error


# ═══════════════════════════════════════════════════════════════════════════
#  Login — bulk interactive setup
# ═══════════════════════════════════════════════════════════════════════════


def _auth_login() -> int:
    """Interactive credential setup.  Tests GitHub connectivity first."""
    from reachable.core.credentials import (
        CREDENTIALS,
        _store_name,
        get_credential,
        get_credential_source,
        mask_value,
        set_credential,
        test_github_api,
        test_ssh_github,
    )

    print("REACHABLE Authentication")
    print("─" * 50)
    store = _store_name()
    print(f"Credentials stored in: {store}")
    print("Press Enter to skip any token.")
    print()

    stored = 0
    skipped = 0

    # ── GitHub PAT: test existing connectivity first ──────────
    cred = CREDENTIALS["github-token"]
    print(f"  {cred['label']}")
    print(f"    {cred['description']}")

    gh = test_github_api()  # checks env vars + credential store automatically
    ssh_ok = False

    if gh["ok"]:
        user_str = f" as @{gh['user']}" if gh["user"] else ""
        scopes_str = f", scopes: {gh['scopes']}" if gh["scopes"] else ""
        print(f"    ✓ GitHub API working{user_str}{scopes_str}")
        print(f"      Source: {gh['source']}")

        try:
            value = getpass.getpass("    Rotate token? (Enter to keep): ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\nAborted.")
            return 1

        if value:
            prefix = cred.get("prefix", "")
            if prefix and not value.startswith(prefix):
                print(f"    Warning: expected prefix '{prefix}' — storing anyway")
            if set_credential("github-token", value):
                print(f"    ✓ Stored ({mask_value(value)})")
                stored += 1
            else:
                print(f"    ✗ Failed to store in {store}")
        else:
            print("    Kept existing")
            skipped += 1
    else:
        # API not working — check SSH
        ssh_ok = test_ssh_github()
        if ssh_ok:
            print("    ✓ SSH clone works (git@github.com authenticated)")
            print("    ⚠ No API token — GHSA enrichment and tarball clone unavailable")
            print(f"    {cred['scope_hint']}")
            print(f"    Create at: {cred['create_url']}")

            try:
                value = getpass.getpass("    Add API token for enrichment? (Enter to skip): ").strip()
            except (EOFError, KeyboardInterrupt):
                print("\nAborted.")
                return 1
        else:
            # Nothing works
            if gh["error"] == "invalid-or-expired":
                print(f"    ✗ Token found ({gh['source']}) but INVALID or EXPIRED")
            elif gh["error"] == "no-token":
                print("    ✗ No GitHub authentication detected")
            else:
                print(f"    \u2717 GitHub API check failed ({_format_error(gh['error'])})")
            print(f"    {cred['scope_hint']}")
            print(f"    Create at: {cred['create_url']}")

            try:
                value = getpass.getpass(f"    {cred['prompt']}: ").strip()
            except (EOFError, KeyboardInterrupt):
                print("\nAborted.")
                return 1

        if value:
            prefix = cred.get("prefix", "")
            if prefix and not value.startswith(prefix):
                print(f"    Warning: expected prefix '{prefix}' — storing anyway")

            # Validate the token they just pasted
            validation = test_github_api(value)
            if validation["ok"]:
                user_str = f" as @{validation['user']}" if validation["user"] else ""
                print(f"    ✓ Token valid{user_str}")
                scopes = validation.get("scopes", "")
                if scopes and scopes != "(fine-grained)":
                    if "repo" in scopes:
                        print("    ✓ Tarball API (fast downloads) + GHSA enrichment enabled")
                    else:
                        print("    \u26a0 Missing 'repo' scope — add it at github.com/settings/tokens")
            else:
                print(f"    \u26a0 Could not validate ({_format_error(validation['error'])}) — storing anyway")

            if set_credential("github-token", value):
                print(f"    ✓ Stored ({mask_value(value)})")
                stored += 1
            else:
                print(f"    ✗ Failed to store in {store}")
        else:
            skipped += 1
            if not ssh_ok and not gh["ok"]:
                print("    Skipped (scans will run but reachability analysis will be limited)")
            else:
                print("    Skipped")
    print()

    # ── MCP Token and Anthropic Key: always prompt ────────────
    for name in ("github-mcp-token", "anthropic-api-key", "groq-api-key"):
        cred = CREDENTIALS[name]
        source = get_credential_source(name)
        existing = get_credential(name)

        print(f"  {cred['label']}")
        print(f"    {cred['description']}")
        if existing:
            print(f"    Current: {mask_value(existing)} ({source})")
        if cred.get("scope_hint"):
            print(f"    {cred['scope_hint']}")
        if cred.get("create_url"):
            print(f"    Create at: {cred['create_url']}")

        hint = "Enter to keep" if existing else "Enter to skip"
        try:
            value = getpass.getpass(f"    Paste token ({hint}): ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\nAborted.")
            return 1

        if not value:
            skipped += 1
            if existing:
                print("    Kept existing")
            else:
                print("    Skipped")
            print()
            continue

        prefix = cred.get("prefix", "")
        if prefix and not value.startswith(prefix):
            print(f"    Warning: expected prefix '{prefix}' — storing anyway")

        if set_credential(name, value):
            print(f"    ✓ Stored ({mask_value(value)})")
            stored += 1
        else:
            print(f"    ✗ Failed to store in {store}")
        print()

    print("─" * 50)
    if stored:
        print(f"✓ {stored} credential{'s' if stored != 1 else ''} stored in {store}")
    if skipped:
        print(f"  {skipped} skipped")
    if not stored and not skipped:
        print("  Nothing changed")
    print()
    print("Verify: reachctl auth status")
    print("Remove: reachctl auth logout")

    return 0


# ═══════════════════════════════════════════════════════════════════════════
#  Status
# ═══════════════════════════════════════════════════════════════════════════


def _auth_status() -> int:
    """Show credential status with live connectivity tests."""
    from reachable.core.credentials import (
        test_anthropic_api,
        test_github_api,
        test_github_mcp,
        test_ssh_github,
    )

    print("REACHABLE Credentials")
    print("\u2500" * 50)
    print("  Testing connectivity...\n")

    # ── GitHub PAT ─────────────────────────────────────────────
    gh = test_github_api()
    ssh_ok = False
    if gh["ok"]:
        user_str = f"@{gh['user']} " if gh["user"] else ""
        print(f"  \u2713 {'GitHub Token':<22} {user_str}valid")
        print(f"    Source: {gh['source']}")
        scopes = gh.get("scopes", "")
        if scopes and scopes != "(fine-grained)":
            has_repo = "repo" in scopes
            print(f"    Scopes: {scopes}")
            if has_repo:
                print("    \u2713 Tarball API (fast downloads), GHSA enrichment")
            else:
                print("    \u26a0 Missing 'repo' scope — tarball downloads limited to public repos")
        elif scopes == "(fine-grained)":
            print("    Fine-grained token — tarball API available if contents:read granted")
    else:
        if gh["error"] == "no-token":
            ssh_ok = test_ssh_github()
            if ssh_ok:
                print(f"  \u25cb {'GitHub Token':<22} SSH clone works (no API token)")
                print("    Tarball API and GHSA enrichment unavailable")
            else:
                print(f"  \u2717 {'GitHub Token':<22} not configured")
                print("    Scans run but library source downloads will be slower")
        elif gh["error"] == "invalid-or-expired":
            print(f"  \u2717 {'GitHub Token':<22} INVALID or EXPIRED ({gh['source']})")
        else:
            print(f"  \u2717 {'GitHub Token':<22} {_format_error(gh['error'])}")

    # ── GitHub MCP ─────────────────────────────────────────────
    mcp = test_github_mcp()
    if mcp["ok"]:
        rate_str = f"rate limit: {mcp['rate_limit']}/hr" if mcp["rate_limit"] else "valid"
        print(f"  \u2713 {'GitHub MCP Token':<22} {rate_str}")
        print(f"    Source: {mcp['source']}")
    else:
        if mcp["error"] == "no-token":
            print(f"  \u2014 {'GitHub MCP Token':<22} not configured (optional)")
        elif mcp["error"] == "invalid-or-expired":
            print(f"  \u2717 {'GitHub MCP Token':<22} INVALID or EXPIRED ({mcp['source']})")
        else:
            print(f"  \u2717 {'GitHub MCP Token':<22} {_format_error(mcp['error'])}")

    # ── Anthropic API ──────────────────────────────────────────
    ant = test_anthropic_api()
    if ant["ok"]:
        print(f"  \u2713 {'Anthropic API Key':<22} valid")
        print(f"    Source: {ant['source']}")
    else:
        if ant["error"] == "no-key":
            print(f"  \u2014 {'Anthropic API Key':<22} not configured (optional, for enzo cloud)")
        elif ant["error"] == "invalid-or-expired":
            print(f"  \u2717 {'Anthropic API Key':<22} INVALID or EXPIRED ({ant['source']})")
        else:
            print(f"  \u2717 {'Anthropic API Key':<22} {_format_error(ant['error'])}")

    # ── Groq API ──────────────────────────────────────
    from reachable.core.credentials import test_groq_api

    groq = test_groq_api()
    if groq["ok"]:
        _gm = f"{groq['models']} models" if groq.get("models") else "valid"
        print(f"  ✓ {'Groq API Key':<22} {_gm}")
        print(f"    Source: {groq['source']}")
    elif groq["error"] == "no-key":
        print(f"  — {'Groq API Key':<22} not configured (optional, enzo --mode cloud --provider groq)")
    elif groq["error"] == "invalid-or-expired":
        print(f"  ✗ {'Groq API Key':<22} INVALID or EXPIRED ({groq['source']})")
    else:
        print(f"  ✗ {'Groq API Key':<22} {_format_error(groq['error'])}")

    # ── Summary ────────────────────────────────────────────────
    print()
    print("\u2500" * 50)

    issues = []
    github_ok = gh["ok"] or ssh_ok
    if not github_ok:
        if gh.get("error") == "invalid-or-expired":
            issues.append("GitHub Token — expired, rotate with: reachctl auth set github-token")
        else:
            issues.append("GitHub — not configured, run: reachctl auth login")
    if mcp.get("error") == "invalid-or-expired":
        issues.append("GitHub MCP Token — expired, rotate with: reachctl auth set github-mcp-token")
    if ant.get("error") == "invalid-or-expired":
        issues.append("Anthropic API Key — expired")
    if groq.get("error") == "invalid-or-expired":
        issues.append("Groq API Key — expired")

    if issues:
        for issue in issues:
            print(f"  \u26a0 {issue}")
    else:
        working = sum([github_ok, mcp["ok"], ant["ok"], groq["ok"]])
        print(f"  {working}/4 services reachable")
        optional = []
        if not mcp["ok"] and mcp.get("error") != "invalid-or-expired":
            optional.append("GitHub MCP Token")
        if not ant["ok"] and ant.get("error") != "invalid-or-expired":
            optional.append("Anthropic API Key")
        if not groq["ok"] and groq.get("error") != "invalid-or-expired":
            optional.append("Groq API Key")
        if not gh["ok"] and ssh_ok:
            optional.append("GitHub API Token (GHSA enrichment)")
        if optional:
            print(f"  Optional: {', '.join(optional)}")

    return 0


# ═══════════════════════════════════════════════════════════════════════════
#  Set — individual token set/rotate
# ═══════════════════════════════════════════════════════════════════════════


def _auth_set(name=None) -> int:
    """Set or rotate a single credential."""
    from reachable.core.credentials import (
        CREDENTIALS,
        _store_name,
        get_credential,
        get_credential_source,
        mask_value,
        set_credential,
    )

    if not name:
        print("Usage: reachctl auth set <name>")
        print()
        print("Available credentials:")
        for cred_name, cred in CREDENTIALS.items():
            source = get_credential_source(cred_name)
            status = f"({source})" if source != "not-configured" else "(not set)"
            print(f"  {cred_name:<22} {cred['label']:<22} {status}")
        return 1

    if name not in CREDENTIALS:
        print(f"Unknown credential: {name}")
        print(f"Available: {', '.join(CREDENTIALS.keys())}")
        return 1

    cred = CREDENTIALS[name]
    existing = get_credential(name)
    source = get_credential_source(name)
    store = _store_name()

    print(f"  {cred['label']}")
    print(f"  {cred['description']}")
    if existing:
        print(f"  Current: {mask_value(existing)} ({source})")
    if cred.get("create_url"):
        print(f"  Create at: {cred['create_url']}")

    try:
        value = getpass.getpass("  Paste new value: ").strip()
    except (EOFError, KeyboardInterrupt):
        print("\n  Aborted.")
        return 1

    if not value:
        print("  No value entered, nothing changed.")
        return 0

    prefix = cred.get("prefix", "")
    if prefix and not value.startswith(prefix):
        print(f"  Warning: expected prefix '{prefix}' \u2014 storing anyway")

    if set_credential(name, value):
        print(f"  \u2713 Stored in {store} ({mask_value(value)})")
        if source.startswith("env:"):
            env_var = source.split(":")[1]
            print(f"  Note: {env_var} env var still takes priority at runtime.")
            print(f"  Unset it for the {store} value to be used.")
    else:
        print(f"  \u2717 Failed to store in {store}")
        return 1

    return 0


# ═══════════════════════════════════════════════════════════════════════════
#  Remove — individual token removal
# ═══════════════════════════════════════════════════════════════════════════


def _auth_remove(name=None) -> int:
    """Remove a single credential from the store."""
    from reachable.core.credentials import (
        CREDENTIALS,
        _store_name,
        delete_credential,
        get_credential_source,
    )

    if not name:
        print("Usage: reachctl auth remove <name>")
        print()
        print("Available credentials:")
        for cred_name, cred in CREDENTIALS.items():
            source = get_credential_source(cred_name)
            status = f"({source})" if source != "not-configured" else "(not set)"
            print(f"  {cred_name:<22} {cred['label']:<22} {status}")
        return 1

    if name not in CREDENTIALS:
        print(f"Unknown credential: {name}")
        print(f"Available: {', '.join(CREDENTIALS.keys())}")
        return 1

    cred = CREDENTIALS[name]
    source = get_credential_source(name)
    store = _store_name()

    if source in ("keychain", "encrypted-file"):
        if delete_credential(name):
            print(f"  \u2713 {cred['label']} removed from {store}")
        else:
            print(f"  \u2717 Failed to remove from {store}")
            return 1
    elif source.startswith("env:"):
        env_var = source.split(":")[1]
        print(f"  {cred['label']} is set via {env_var}")
        print("  Unset the environment variable to remove it:")
        print(f"    unset {env_var}")
    else:
        print(f"  {cred['label']} is not stored anywhere")

    return 0


# ═══════════════════════════════════════════════════════════════════════════
#  Logout — bulk removal
# ═══════════════════════════════════════════════════════════════════════════


def _auth_logout() -> int:
    """Remove all stored credentials."""
    from reachable.core.credentials import (
        CREDENTIALS,
        _store_name,
        delete_credential,
        get_credential_source,
    )

    store = _store_name()
    print(f"Removing credentials from {store}...")

    removed = 0
    for name, cred in CREDENTIALS.items():
        source = get_credential_source(name)
        if source in ("keychain", "encrypted-file"):
            if delete_credential(name):
                print(f"  \u2713 {cred['label']} removed")
                removed += 1
            else:
                print(f"  \u2717 {cred['label']} removal failed")
        elif source.startswith("env:"):
            env_var = source.split(":")[1]
            print(f"  \u2014 {cred['label']} set via {env_var} (unset {env_var} to remove)")
        else:
            print(f"  \u2014 {cred['label']} not stored")

    if removed:
        print(f"\n\u2713 {removed} credential{'s' if removed != 1 else ''} removed from {store}")
    else:
        print("\nNo stored credentials to remove")

    return 0
