#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.
"""CLI scan operations: scan_repo, reachability analysis, database storage."""

import json
import logging
import subprocess
import sys
import time
from datetime import datetime
from pathlib import Path
from typing import List, Optional

from reachable import __version__
from reachable.cli.sandbox import run_dynamic_malware_sandbox

# Cross-module imports
from reachable.cli.utils import TeeOutput, check_github_connectivity, run_command

logger = logging.getLogger(__name__)

# ──────────────────────────────────────────────────────────────────────────
# NOTE: Historical naming inconsistency — the CLI exposes --debug but most
# internal functions accept ``verbose: bool``.  In scan_repo() below,
# ``debug_mode`` is passed as ``verbose=debug_mode`` to every helper.
# A future refactor should unify on ``debug`` everywhere; for now the two
# names are functionally identical.  The unified logger (core.logger)
# handles level filtering regardless of which flag name gates the call.
# ──────────────────────────────────────────────────────────────────────────


def generate_sbom(repo_path: Path, output_dir: Path, verbose: bool = False) -> Path:
    """Generate SBOM using Syft (reuses existing logic)"""
    from reachable.collectors.vulns.grype import get_syft_path

    if verbose:
        logger.info("[1/5] Generating SBOM...")
    sbom_file = output_dir / "sbom.json"

    # Use local syft from ~/.reachable/tools/bin/ if available
    syft_path = get_syft_path()

    result = run_command(
        [str(syft_path), "scan", f"dir:{repo_path}", "-o", "json", "-q"], "SBOM generation", capture=True
    )

    try:
        from reachable.core.compression import save_json

        sbom_data = json.loads(result)
        actual_file = save_json(sbom_data, sbom_file, compress=True)
        if verbose:
            logger.info(f" SBOM saved to {actual_file.name} (compressed)")
        return actual_file
    except ImportError:
        # Fallback to uncompressed
        sbom_file.write_text(result)
        if verbose:
            logger.info(f" SBOM saved to {sbom_file}")
        return sbom_file


def enrich_sbom_purls(sbom_file: Path, verbose: bool = False) -> tuple:
    """Enrich SBOM with canonical PURLs for private registry packages.

    Runs PURLResolver between Syft and Grype to rewrite private-registry
    PURLs (renamed mirrors, scoped wrappers) to their canonical upstream
    identities using hash-based verification.

    Returns:
        (enriched_sbom_path, resolution_map, coverage_stats)
        - enriched_sbom_path: Path to enriched SBOM (or original if no changes)
        - resolution_map: dict mapping (ecosystem, private_name) → canonical info
        - coverage_stats: dict with resolution counts
    """
    try:
        from reachable.collectors.vulns.purl_resolver import PURLResolver
    except ImportError:
        if verbose:
            logger.info("  PURLResolver not available, skipping SBOM enrichment")
        return sbom_file, {}, {}

    resolver = PURLResolver()
    try:
        enriched_path = resolver.enrich_sbom(sbom_file)
        resolution_map = resolver.get_resolution_map(enriched_path)

        # Read coverage stats from the enriched SBOM
        coverage = {}
        if enriched_path != sbom_file:
            import json as _json

            data = _json.loads(enriched_path.read_text())
            coverage = data.get("_reachable_registry_coverage", {})

        if verbose:
            resolved = len(resolution_map)
            if resolved > 0:
                logger.info(f"  PURL enrichment: {resolved} private package(s) resolved to canonical upstream")
                for (eco, orig_name), info in resolution_map.items():
                    logger.info(f"    {orig_name} → {info['canonical_name']} ({info['method']})")
            else:
                total = coverage.get("total_packages", 0)
                logger.info(f"  PURL enrichment: {total} packages all canonical, no rewrites needed")

        return enriched_path, resolution_map, coverage

    except Exception as e:
        if verbose:
            logger.warning(f"  PURLResolver failed: {e} — using original SBOM")
        return sbom_file, {}, {}


def scan_vulnerabilities(sbom_file: Path, output_dir: Path, verbose: bool = False) -> Path:
    """Scan for vulnerabilities using Grype with cached DB.

    Uses local grype from ~/.reachable/tools/bin/ and cached vulnerability
    database from ~/.reachable/cache/grype-db/. Auto-refreshes DB if > 24h old.
    """
    from reachable.collectors.vulns.grype import VulnDBManager, get_grype_path

    if verbose:
        logger.info("[2/5] Scanning for vulnerabilities...")
    vulns_file = output_dir / "vulns.json"

    # Ensure vulnerability DB is fresh (auto-refresh if > 24h old)
    db_mgr = VulnDBManager()
    db_mgr.ensure_fresh(verbose=verbose)

    # Use local grype from ~/.reachable/tools/bin/ if available
    grype_path = get_grype_path()

    actual_sbom_file = sbom_file
    temp_sbom = None

    if str(sbom_file).endswith(".gz"):
        import gzip

        # Decompress to temp file for Grype
        temp_sbom = output_dir / "sbom_temp.json"
        with gzip.open(sbom_file, "rt") as f_in:
            temp_sbom.write_text(f_in.read())
        actual_sbom_file = temp_sbom

    try:
        # Run grype with cached DB location
        result = run_command(
            [str(grype_path), f"sbom:{actual_sbom_file}", "-o", "json", "-q"],
            "vulnerability scanning",
            capture=True,
            env=db_mgr.get_grype_env(),
        )

        vulns_file.write_text(result)

        # Count vulnerabilities
        vulns_data = json.loads(result)
        vuln_count = len(vulns_data.get("matches", []))

        if verbose:
            logger.info(f" Found {vuln_count} vulnerabilities (Syft SBOM + Grype scanner)")
            logger.info(f" Results saved to {vulns_file}")

        return vulns_file
    finally:
        # Clean up temp file
        if temp_sbom and temp_sbom.exists():
            temp_sbom.unlink()


def clone_vulnerable_libs(
    vulns_file: Path, libs_dir: Path, scan_ctx=None, purl_resolutions: dict = None, verbose: bool = False
) -> tuple:
    """Clone vulnerable libraries using smart lib manager.

    Args:
        purl_resolutions: Optional dict from PURLResolver mapping
            (ecosystem, private_name) → {canonical_name, canonical_version, ...}
            Used to fetch canonical upstream source for resolved private packages.
    """
    if verbose:
        logger.info("[3/5] Cloning vulnerable library source code...")

    from reachable.integrations.lib_manager import LibraryManager

    with open(vulns_file) as f:
        vulns_data = json.load(f)

    # Pass scan context and PURL resolutions to library manager
    manager = LibraryManager(libs_dir, scan_context=scan_ctx, purl_resolutions=purl_resolutions or {})
    cloned_paths = manager.clone_vulnerable_libraries(vulns_data)

    # Capture library manager metrics (includes obsolete packages)
    lib_metrics = manager.metrics

    # IMPORTANT: Return libs_dir even if nothing was freshly cloned
    # (libraries may already exist from previous runs)
    if libs_dir.exists() and any(libs_dir.iterdir()):
        return libs_dir, lib_metrics
    elif cloned_paths:
        return libs_dir, lib_metrics
    else:
        if verbose:
            logger.info("     No vulnerable libraries found or cloning failed")
        return None, lib_metrics


def run_reachability_analysis(
    repo_path: Path,
    sbom_file: Path,
    vulns_file: Path,
    libs_dir: Optional[Path],
    output_dir: Path,
    enable_dynamic_malware: bool = True,
    debug: bool = False,
    progress_callback=None,
    ai_findings: List = None,  # v4.5.18: AI/LLM security findings
    ai_scan_time: float = 0.0,  # v4.5.39: AI scan timing for step breakdown
    dlp_scan_time: float = 0.0,  # v4.5.50: DLP scan timing for step breakdown
    sandbox_cache_ttl: int = 24,  # v4.6.10: Sandbox cache TTL in hours (0 = disable)
    force_rebuild: bool = False,  # v4.6.10: Force skip all caches including sandbox
):
    """Run reachability analysis (reuses existing reachable.py)

    Args:
        ai_findings: AI/LLM security findings (OWASP LLM Top 10)
        ai_scan_time: Time spent on AI scanning (for step breakdown)
        dlp_scan_time: Time spent on DLP scanning (for step breakdown)

    Note: OWASP Top 10 (Web) data is derived from CWE findings automatically.
    """
    # Import existing analyzer
    from reachable.engine.reachability import ReachabilityAnalyzer

    # Create and run analyzer
    analyzer = ReachabilityAnalyzer(
        app_dir=repo_path,
        libs_dir=libs_dir,
        sbom_file=sbom_file,
        vulns_file=vulns_file,
        verbose=False,  # Correlation engine verbose output disabled
        progress_callback=progress_callback,
        ai_findings=ai_findings,  # v4.5.18: AI/LLM security findings
        ai_scan_time=ai_scan_time,  # v4.5.39: AI scan timing
        dlp_scan_time=dlp_scan_time,  # v4.5.50: DLP scan timing
    )

    results = analyzer.analyze()

    # Run dynamic malware sandbox analysis if enabled
    # Note: Static malware analysis (GuardDog) always runs as part of reachability analysis
    sandbox_results = None
    if enable_dynamic_malware:
        sandbox_results = run_dynamic_malware_sandbox(
            sbom_file,
            output_dir,
            repo_dir=repo_path,
            cache_ttl_hours=0 if force_rebuild else sandbox_cache_ttl,
        )
    if sandbox_results:
        results["dynamic_malware"] = sandbox_results
        # Also add to security_scans for dashboard compatibility
        if "security_scans" not in results:
            results["security_scans"] = {}
        results["security_scans"]["dynamic_malware"] = sandbox_results

    # Save results
    logger.info("[5/5] Saving results...")

    # Helper to add timestamp to any dict
    def add_timestamp(data: dict) -> dict:
        """Add scan timestamp to JSON output"""
        data["_metadata"] = {
            "generated_at": datetime.now().isoformat() + "Z",
            "reachable_version": results.get("reachable_version", __version__),
            "schema": "REACHABLE",
        }
        return data

    # v5.1.3: reachable-report.json REMOVED — DB is single source of truth
    # Dashboard reads from repo.db; raw files kept for audit/debug.
    # Use 'reachctl export' to generate JSON/CSV from DB on demand.
    logger.info(" Core files: sbom.json, vulns.json (created earlier)")

    # raw/ directory needed for scan-manifest.json and ingester source files
    raw_dir = output_dir / "raw"
    raw_dir.mkdir(exist_ok=True)

    # Generate scan manifest for CI/CD coordination
    scan_id = results.get("metadata", {}).get(
        "scan_id", results.get("metadata", {}).get("scan_timing", {}).get("start_timestamp", "unknown")
    )
    git_info = results.get("metadata", {}).get("git_info")
    scan_manifest = {
        "schema_version": "3.0",
        "scan_id": scan_id,
        "generated_at": results.get("metadata", {}).get("generated_at", ""),
        "generator_version": results.get("reachable_version", "unknown"),
        "target": {
            "path": str(results.get("metadata", {}).get("analysis_target", {}).get("app_directory", "")),
            "git_commit": git_info.get("commit_sha") if git_info else None,
            "git_branch": git_info.get("branch") if git_info else None,
        },
        "components": {},
        "outputs": {
            "dashboard": "dashboard/index.html",
            "dashboard_data": "dashboard/data.json",
            "database": "repo.db",
        },
    }

    # 2. Save detailed data files to raw/ subfolder
    logger.info(" Saving detailed data files to raw/...")

    # CVEs - detailed findings with remediation
    if "reachable" in results or "unreachable" in results:
        # v5.1.3: Write CVE data to raw/ for ingester (replaces reachable-report.json)
        cve_raw_file = raw_dir / "cve-analyzed.json"
        cve_raw_data = {
            "reachable": results.get("reachable", {}),
            "unreachable": results.get("unreachable", {}),
        }
        with open(cve_raw_file, "w") as f:
            json.dump(cve_raw_data, f, indent=2)
        total_cves = len(cve_raw_data["reachable"]) + len(cve_raw_data["unreachable"])
        logger.info(f" raw/cve-analyzed.json ({total_cves} CVEs)")
        scan_manifest["components"]["cves"] = {"status": "complete", "file": "raw/cve-analyzed.json"}

    # Secrets - with locations and reachability
    if "security_scans" in results and "secrets" in results["security_scans"]:
        secrets_data = results["security_scans"]["secrets"]
        if secrets_data:
            secrets_data = add_timestamp(secrets_data if isinstance(secrets_data, dict) else {"findings": secrets_data})
            security_file = raw_dir / "security-findings.json"
            with open(security_file, "w") as f:
                json.dump(secrets_data, f, indent=2)
            total_secrets = secrets_data.get("total_findings", 0)
            logger.info(f" raw/security-findings.json ({total_secrets} secrets)")
            scan_manifest["components"]["secrets"] = {
                "status": "complete",
                "file": "raw/security-findings.json",
            }

    # Malware - tier 1/2/3 detections
    if "malware_detection" in results and results["malware_detection"]:
        malware_data = add_timestamp(results["malware_detection"])
        malware_file = raw_dir / "malware.json"
        with open(malware_file, "w") as f:
            json.dump(malware_data, f, indent=2)
        malicious = malware_data.get("malicious_packages", 0)
        if isinstance(malicious, list):
            malicious = len(malicious)
        logger.info(f" raw/malware.json ({malicious} malicious packages)")
        scan_manifest["components"]["malware"] = {"status": "complete", "file": "raw/malware.json"}

    # Sandbox - behavioral analysis findings
    sandbox_data = None
    if "dynamic_malware" in results and results["dynamic_malware"]:
        sandbox_data = results["dynamic_malware"]
    elif "security_scans" in results and "dynamic_malware" in results["security_scans"]:
        sandbox_data = results["security_scans"]["dynamic_malware"]
    # Legacy key fallback
    elif "sandbox" in results and results["sandbox"]:
        sandbox_data = results["sandbox"]
    elif "security_scans" in results and "sandbox" in results["security_scans"]:
        sandbox_data = results["security_scans"]["sandbox"]

    if sandbox_data:
        sandbox_data = add_timestamp(sandbox_data if isinstance(sandbox_data, dict) else {"findings": sandbox_data})
        sandbox_file = raw_dir / "sandbox.json"
        with open(sandbox_file, "w") as f:
            json.dump(sandbox_data, f, indent=2)
        verdict = sandbox_data.get("verdict", "N/A")
        findings = sandbox_data.get("findings", [])
        if not isinstance(findings, list):
            findings = []
        findings_count = len(findings)
        critical_count = sum(1 for f in findings if isinstance(f, dict) and f.get("severity") == "CRITICAL")
        logger.info(f" raw/sandbox.json (verdict: {verdict}, {findings_count} issues, {critical_count} critical)")
        scan_manifest["components"]["sandbox"] = {"status": "complete", "file": "raw/sandbox.json"}

    # Package Health - unmaintained/risky packages
    if "tool_execution_log" in results and "package_health_analyzer" in results["tool_execution_log"]:
        health_log = results["tool_execution_log"]["package_health_analyzer"]
        if health_log.get("executed"):
            health_data = add_timestamp(
                {
                    "summary": {
                        "total_packages": health_log["metrics"]["packages_analyzed"],
                        "health_distribution": health_log["metrics"]["health_distribution"],
                        "unmaintained": health_log["metrics"]["health_distribution"].get("CRITICAL", 0),
                        "risky": health_log["metrics"]["health_distribution"].get("MEDIUM", 0),
                    },
                    "findings": results.get("findings", {}).get("package_health_issues", []),
                }
            )
            health_file = raw_dir / "health.json"
            with open(health_file, "w") as f:
                json.dump(health_data, f, indent=2)
            logger.info(f" raw/health.json ({health_data['summary']['total_packages']} packages)")
            scan_manifest["components"]["health"] = {"status": "complete", "file": "raw/health.json"}

    # Correlation - threat correlations (large file, use compression)
    if "correlation" in results and results["correlation"]:
        correlation_data = add_timestamp(results["correlation"])
        correlation_file = raw_dir / "correlation.json"
        try:
            from reachable.core.compression import save_json as save_json_compressed

            actual_file = save_json_compressed(correlation_data, correlation_file, compress=True)
            total_threats = correlation_data.get("summary", {}).get("total_composite_threats", 0)
            logger.info(f" raw/{actual_file.name} ({total_threats} composite threats)")
            scan_manifest["components"]["correlation"] = {
                "status": "complete",
                "file": f"raw/{actual_file.name}",
            }
        except ImportError:
            with open(correlation_file, "w") as f:
                json.dump(correlation_data, f, indent=2)
            total_threats = correlation_data.get("summary", {}).get("total_composite_threats", 0)
            logger.info(f" raw/correlation.json ({total_threats} composite threats)")
            scan_manifest["components"]["correlation"] = {
                "status": "complete",
                "file": "raw/correlation.json",
            }

    # Attack Surface - phantom deps, shadow imports
    if "findings" in results and "attack_surface" in results["findings"]:
        attack_surface_data = add_timestamp(results["findings"]["attack_surface"])
        attack_surface_file = raw_dir / "attack_surface.json"
        with open(attack_surface_file, "w") as f:
            json.dump(attack_surface_data, f, indent=2)
        phantom = attack_surface_data.get("phantom_dependencies", {}).get("count", 0)
        logger.info(f" raw/attack_surface.json ({phantom} phantom dependencies)")
        scan_manifest["components"]["attack_surface"] = {
            "status": "complete",
            "file": "raw/attack_surface.json",
        }

    # Call graphs (keep in output_dir for easy access, also copy to raw/)
    if "call_graph_exports" in results:
        for format_name, content in results["call_graph_exports"].items():
            graph_file = output_dir / f"call-graph.{format_name}"
            with open(graph_file, "w") as f:
                f.write(content)
            # Also save to raw/
            raw_graph_file = raw_dir / f"call-graph.{format_name}"
            with open(raw_graph_file, "w") as f:
                f.write(content)
        logger.info(" call-graph.json (+ raw/)")
        scan_manifest["components"]["call_graph"] = {"status": "complete", "file": "raw/call-graph.json"}

    # Save scan manifest
    manifest_file = raw_dir / "scan-manifest.json"
    with open(manifest_file, "w") as f:
        json.dump(scan_manifest, f, indent=2)
    logger.info(" raw/scan-manifest.json (CI/CD coordination)")

    # Populate database with all findings (after raw files exist)
    # v4.5.8: Store to repo.db (per-repo database with history)
    # v4.5.10: Extract and pass risk data to DB storage
    overall_risk = results.get("summary", {}).get("overall_risk", {})
    db_risk_score = overall_risk.get("risk_score", 0)
    db_risk_level = overall_risk.get("risk_level", None)

    # v4.6.10: Convert sandbox findings to DB format for malware storage
    sandbox_findings_for_db = []
    sandbox_data_for_db = results.get("dynamic_malware") or results.get("security_scans", {}).get("dynamic_malware", {})
    if sandbox_data_for_db and sandbox_data_for_db.get("findings"):
        import hashlib

        for f in sandbox_data_for_db["findings"]:
            sev = f.get("severity", "MEDIUM")
            if sev not in ("CRITICAL", "HIGH", "MEDIUM", "LOW", "INFO"):
                sev = "MEDIUM"
            pkg = f.get("package", "unknown")
            rule = f.get("rule", "sandbox_finding")
            desc = f.get("description", "")
            evidence = f.get("evidence", "")
            # Generate stable finding_id from rule + package + description
            fid = hashlib.sha256(f"{rule}:{pkg}:{desc}".encode()).hexdigest()[:16]
            # v4.6.10: CRITICAL=malware (confirmed), else=suspicious (review)
            db_type = "malware" if sev == "CRITICAL" else "suspicious"
            sandbox_findings_for_db.append(
                {
                    "id": f"SANDBOX-{fid}",
                    "finding_type": db_type,
                    "severity": sev,
                    "risk_level": sev,  # Runtime-observed = severity is risk
                    "title": desc[:500] if desc else f"Sandbox: {rule}",
                    "description": f"Rule: {rule}. Evidence: {evidence}"[:1000],
                    "package": pkg,
                    "scanner": "sandbox",
                    "app_reachability": "REACHABLE",  # Observed at runtime
                    "reachability_confidence": "HIGH",
                    "phase": f.get("phase", "install"),
                    "local_package": f.get("local_package", False),
                }
            )

    # v5.0.1: Extract static malware findings (Semgrep + YARA) from analysis results
    static_malware_for_db = results.get("static_malware_findings", [])

    # P2.60 FIX (P0 #1): Fallback — if static_malware_findings not populated by engine,
    # extract from malware_detection results (GuardDog/YARA raw output)
    # This ensures YARA file-level findings and GuardDog package findings reach the DB
    if not static_malware_for_db:
        import hashlib as _hashlib

        malware_raw = results.get("malware_detection", {})
        if malware_raw:
            # Extract package-level findings (GuardDog format: packages dict)
            packages = malware_raw.get("packages", malware_raw.get("malicious_packages", {}))
            if isinstance(packages, dict):
                for pkg_name, pkg_data in packages.items():
                    if not isinstance(pkg_data, dict):
                        continue
                    for finding in pkg_data.get("findings", []):
                        sev = (finding.get("severity") or "HIGH").upper()
                        rule = finding.get("rule", finding.get("code", "guarddog_finding"))
                        msg = finding.get("message", finding.get("description", f"Malware pattern: {rule}"))
                        fid = _hashlib.sha256(f"{rule}:{pkg_name}:{msg}".encode()).hexdigest()[:16]
                        db_type = "malware" if sev in ("CRITICAL", "HIGH") else "suspicious"
                        # P2.60 FIX: Static malware reachability depends on context:
                        # - Install hooks (setup.py, postinstall) → REACHABLE (execute at install time)
                        # - Import-time code (__init__.py) → depends on import analysis
                        # - Function-level code → depends on call graph
                        # Default to UNKNOWN; reachability engine determines actual state
                        fpath_lower = (finding.get("file", finding.get("file_path", "")) or "").lower()
                        is_install_hook = any(
                            h in fpath_lower
                            for h in (
                                "setup.py",
                                "setup.cfg",
                                "postinstall",
                                "preinstall",
                                "install.js",
                                ".github/workflows",
                                "Makefile",
                            )
                        )
                        static_malware_for_db.append(
                            {
                                "id": f"STATIC-{fid}",
                                "finding_type": db_type,
                                "severity": sev,
                                "risk_level": sev,
                                "title": msg[:500],
                                "description": f"Rule: {rule}. Package: {pkg_name}"[:1000],
                                "package": pkg_name,
                                "version": pkg_data.get("version", ""),
                                "scanner": finding.get("scanner", "guarddog"),
                                "file": finding.get("file", finding.get("file_path", "")),
                                "line": finding.get("line", finding.get("line_number", 0)),
                                "app_reachability": "REACHABLE" if is_install_hook else "UNKNOWN",
                                "reachability_confidence": "HIGH" if is_install_hook else "LOW",
                            }
                        )
            # Extract file-level findings (YARA format: file_findings list)
            file_findings = malware_raw.get("file_findings", malware_raw.get("yara_findings", []))
            if isinstance(file_findings, list):
                for finding in file_findings:
                    if not isinstance(finding, dict):
                        continue
                    sev = (finding.get("severity") or "HIGH").upper()
                    rule = finding.get("rule", finding.get("signature", "yara_finding"))
                    fpath = finding.get("file", finding.get("file_path", finding.get("filepath", "")))
                    msg = finding.get("description", finding.get("message", f"YARA match: {rule}"))
                    fid = _hashlib.sha256(f"{rule}:{fpath}:{msg}".encode()).hexdigest()[:16]
                    db_type = "malware" if sev in ("CRITICAL", "HIGH") else "suspicious"
                    # Derive package from file path (parent directory)
                    pkg = ""
                    if fpath and "/" in fpath:
                        pkg = fpath.rsplit("/", 2)[-2] if fpath.count("/") >= 2 else fpath.rsplit("/", 1)[0]
                    # P2.60 FIX: YARA file-level reachability — same logic as GuardDog
                    fpath_lower = (fpath or "").lower()
                    is_install_hook = any(
                        h in fpath_lower
                        for h in (
                            "setup.py",
                            "setup.cfg",
                            "postinstall",
                            "preinstall",
                            "install.js",
                            ".github/workflows",
                            "Makefile",
                        )
                    )
                    static_malware_for_db.append(
                        {
                            "id": f"YARA-{fid}",
                            "finding_type": db_type,
                            "severity": sev,
                            "risk_level": sev,
                            "title": msg[:500],
                            "description": f"Rule: {rule}. File: {fpath}"[:1000],
                            "package": pkg,
                            "scanner": "yara",
                            "file": fpath,
                            "line": finding.get("line", 0),
                            "app_reachability": "REACHABLE" if is_install_hook else "UNKNOWN",
                            "reachability_confidence": "HIGH" if is_install_hook else "LOW",
                        }
                    )
            if static_malware_for_db:
                logger.info(
                    f" P2.60 FIX: Extracted {len(static_malware_for_db)} static malware findings from malware_detection for DB"
                )

    # v5.1.3: DB setup (ingester call moved to scan_repo after all raw files written)
    from reachable import __version__ as _ver
    from reachable.database.storage import RepoDatabase, get_repo_db_path

    repo_db_path = get_repo_db_path(repo_path)
    db = RepoDatabase(repo_db_path)

    # Get branch/commit from provenance
    _branch = "unknown"
    _commit = None
    _prov_file = output_dir / "provenance.json"
    if _prov_file.exists():
        with open(_prov_file) as _pf:
            _prov = json.load(_pf)
            _sp = _prov.get("source_provenance", {})
            _branch = _sp.get("branch") or "unknown"
            _commit = _sp.get("commit_sha")

    scan_id = db.start_scan(branch=_branch, commit_hash=_commit, scan_dir=str(output_dir), version=_ver)

    # v5.1.3: Write in-memory findings to raw/ so ingester can read them
    _raw_dir = output_dir / "raw"
    if sandbox_findings_for_db:
        with open(_raw_dir / "sandbox-extracted.json", "w") as _f:
            json.dump({"findings": sandbox_findings_for_db}, _f)
    if static_malware_for_db:
        with open(_raw_dir / "static-malware-extracted.json", "w") as _f:
            json.dump({"findings": static_malware_for_db}, _f)

    # v5.1.3: Ingester call moved to scan_repo() — runs AFTER AI/DLP files are written
    # Pass scan_id and db_path so scan_repo can ingest + complete scan
    db.close()

    results["_repo_db_path"] = str(repo_db_path)
    results["_scan_id"] = scan_id
    results["_output_dir"] = str(output_dir)
    results["_db_risk_score"] = db_risk_score
    results["_db_risk_level"] = db_risk_level

    # v4.6.8: Auto-maintenance after scan (checkpoint, vacuum, prune)
    try:
        from reachable.core.config import is_auto_maintenance_enabled, load_config
        from reachable.maintenance.auto import run_auto_maintenance

        if is_auto_maintenance_enabled():
            repo_db = get_repo_db_path(repo_path)
            if repo_db and repo_db.exists():
                config = load_config()
                auto_results = run_auto_maintenance(repo_db, config)

                if debug and auto_results.get("checkpointed"):
                    logger.debug(" Auto-maintenance: database checkpointed")
                if debug and auto_results.get("vacuumed"):
                    logger.debug(" Auto-maintenance: database vacuumed")
                if auto_results.get("pruned", 0) > 0 and debug:
                    logger.debug(f" Auto-maintenance: {auto_results['pruned']} old scans removed")
    except Exception as e:
        if debug:
            logger.debug(f"Auto-maintenance warning: {e}")

    return results


def _generate_dashboard(results: dict, output_dir: Path, skip: bool = False) -> None:
    """Generate Dashboard v2 (funnel visualization with Executive + Engineering views)"""
    if skip:
        logger.info(" Dashboard skipped (--no-dashboard)")
        return

    try:
        from reachable.dashboard_v2.generator import DashboardV2Generator

        generator = DashboardV2Generator()
        generator.generate_from_report(results, output_dir)
    except Exception as e:
        import traceback

        logger.info(f" Dashboard generation failed: {e}")
        logger.info(traceback.format_exc())


def print_summary(results: dict):
    """Print summary (reuses existing format)"""
    logger.info("ANALYSIS COMPLETE")
    summary = results.get("summary", {})
    totals = summary.get("totals", {})
    logger.info(" CVE Summary:")
    total_cves = totals.get("cves_total", summary.get("total_cves", 0))
    logger.info(f" Total CVEs found: {total_cves}")

    # Severity breakdown
    critical = totals.get("cves_critical", 0)
    high = totals.get("cves_high", 0)
    medium = totals.get("cves_medium", 0)
    low = totals.get("cves_low", 0)

    if critical + high + medium + low > 0:
        logger.info(" Severity Breakdown:")
        if critical > 0:
            logger.info(f" Critical: {critical}")
        if high > 0:
            logger.info(f" High: {high}")
        if medium > 0:
            logger.info(f" Medium: {medium}")
        if low > 0:
            logger.info(f" Low: {low}")
    reachable = totals.get("cves_reachable", summary.get("reachable_cves", 0))
    unreachable = totals.get("cves_unreachable", summary.get("unreachable_cves", 0))
    logger.info(f" REACHABLE: {reachable} (require immediate attention)")
    logger.info(f" UNREACHABLE: {unreachable} (Risk: LOW)")
    logger.info(f" Risk Reduction: {summary.get('risk_reduction_pct', 0):.1f}%")
    logger.info(" Code Coverage:")
    logger.info(f" Functions analyzed: {summary.get('total_functions', 0)}")
    reachable_count = summary.get("reachable_functions", 0)
    total_funcs = summary.get("total_functions", 1)
    pct = (reachable_count / total_funcs * 100) if total_funcs > 0 else 0
    logger.info(f" Reachable from entrypoints: {reachable_count} ({pct:.1f}%)")


def _get_repo_stats(repo_path: Path) -> dict:
    """
    Get repository scan statistics from repo.db.

    Returns:
        dict with branch, scan_count, first_scan_date
    """
    from reachable.database.storage import get_repo_db_path

    stats = {
        "branch": "unknown",
        "scan_count": 0,
        "first_scan_date": None,
    }

    # Get current git branch
    try:
        result = subprocess.run(
            ["git", "rev-parse", "--abbrev-ref", "HEAD"],
            capture_output=True,
            text=True,
            cwd=repo_path,
            timeout=5,
        )
        if result.returncode == 0:
            stats["branch"] = result.stdout.strip()
    except Exception:
        pass

    # Get scan history from repo.db
    try:
        import sqlite3

        repo_db_path = get_repo_db_path(repo_path)
        if repo_db_path.exists():
            conn = sqlite3.connect(str(repo_db_path))
            cursor = conn.cursor()

            # Get total scan count for this repo
            cursor.execute("SELECT COUNT(*) FROM scans WHERE status = 'complete'")
            stats["scan_count"] = cursor.fetchone()[0]

            # Get first scan date
            cursor.execute("SELECT MIN(timestamp) FROM scans")
            first = cursor.fetchone()[0]
            if first:
                stats["first_scan_date"] = first[:10]  # YYYY-MM-DD

            conn.close()
    except Exception:
        pass

    return stats


def scan_repo(args):
    """Scan an arbitrary repository"""
    from reachable import __version__
    from reachable.core.logger import OutputMode
    from reachable.core.logger import get_logger as _get_scan_logger
    from reachable.database.storage import RepoDatabase, get_repo_db_path
    from reachable.integrations.preflight import preflight_check
    from reachable.output.manager import OutputManager
    from reachable.output.modes import print_quiet_summary

    # Preflight check - ensure all tools are ready (auto-fix if missing)
    quiet_mode = getattr(args, "quiet", False)
    no_timestamps = getattr(args, "no_timestamps", False)
    preflight = preflight_check(fix=True, quiet=quiet_mode, skip_vulndb=False)
    if not preflight.ok:
        fail_icon = "FAIL:"
        logger.info(f"{fail_icon} Cannot start scan - missing dependencies:")
        for issue in preflight.issues:
            logger.info(f" - {issue}")
        logger.info("Run 'reachctl doctor' to resolve.")
        sys.exit(1)

    # Initialize structured logger
    debug_mode = getattr(args, "debug", False)

    # === CI MODE (T-CI1) ===
    # Activated by --ci flag OR CI=true env var (set by GitHub Actions, GitLab CI, etc.)
    import os as _os

    ci_mode = getattr(args, "ci", False) or _os.environ.get("CI", "").lower() in ("true", "1", "yes")

    quiet_mode = getattr(args, "quiet", False) or ci_mode  # --ci implies quiet
    fail_on_threshold = getattr(args, "fail_on", "none")
    sarif_output = getattr(args, "sarif", None)  # T-CI2: --sarif <file>

    # --ci auto-enables --fail-on critical when user hasn't explicitly set a threshold
    if ci_mode and fail_on_threshold == "none":
        fail_on_threshold = "critical"

    force_rebuild = getattr(args, "force_rebuild", False)
    no_dashboard = getattr(args, "no_dashboard", False)

    # Determine timestamps: default ON, --no-timestamps disables
    show_timestamps = not no_timestamps

    repo_path = Path(args.repo).resolve()

    # Validate path BEFORE redirecting stdout (so error is always visible)
    if not repo_path.exists():
        print(f"Error: Repository path does not exist: {repo_path}", file=sys.stderr)
        sys.exit(1)
    if not repo_path.is_dir():
        print(f"Error: Not a directory: {repo_path}", file=sys.stderr)
        sys.exit(1)

    # Initialize output manager first to get output_dir
    custom_output = Path(args.output).resolve() if args.output else None
    output_mgr = OutputManager(repo_path, custom_output, force_rebuild=force_rebuild)
    output_dir = output_mgr.scan_dir

    # Initialize logger with log file
    log_path = output_dir / "scan.log"

    scan_log = _get_scan_logger()

    # Output mode precedence: --log-format jsonl > --ci > HUMAN
    log_format = getattr(args, "log_format", "text")
    if log_format == "jsonl":
        output_mode = OutputMode.JSON
    elif ci_mode:
        output_mode = OutputMode.CI
    else:
        output_mode = OutputMode.HUMAN

    scan_log.configure(
        mode=output_mode,
        debug=debug_mode,
        quiet=quiet_mode,
        log_file=log_path,
        timestamps=show_timestamps,
    )

    # License check — must pass before scan starts
    license_info = None
    try:
        from reachable.licensing.verifier import check as _lic_check

        _lic_state = _lic_check()
        if not _lic_state.valid:
            print(_lic_state.error)
            sys.exit(1)
        license_info = {
            "type": _lic_state.license_type,
            "days_remaining": _lic_state.days_remaining,
            "status": _lic_state.status,
            "customer": _lic_state.customer,
            "expires_at": _lic_state.expires_at,
            "banner": _lic_state.banner,
        }
        # Store license state in DB (display cache — not authoritative)
        try:
            from datetime import datetime, timezone

            from reachable.database.storage import RepoDatabase, get_repo_db_path

            _lic_db_path = get_repo_db_path(repo_path)
            _lic_db = RepoDatabase(_lic_db_path)
            _lic_db.conn.execute("""
                CREATE TABLE IF NOT EXISTS license_state (
                    id            INTEGER PRIMARY KEY,
                    license_id    TEXT NOT NULL,
                    license_type  TEXT NOT NULL,
                    customer      TEXT,
                    email         TEXT,
                    expires_at    TEXT NOT NULL,
                    days_remaining INTEGER NOT NULL,
                    status        TEXT NOT NULL,
                    last_verified TEXT NOT NULL
                )
            """)
            _lic_db.conn.execute("DELETE FROM license_state")
            _lic_db.conn.execute(
                """
                INSERT INTO license_state
                  (license_id, license_type, customer, email,
                   expires_at, days_remaining, status, last_verified)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """,
                (
                    _lic_state.license_id,
                    _lic_state.license_type,
                    _lic_state.customer,
                    _lic_state.email,
                    _lic_state.expires_at,
                    _lic_state.days_remaining,
                    _lic_state.status,
                    datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
                ),
            )
            _lic_db.conn.commit()
            _lic_db.close()
        except Exception:
            pass  # DB storage is display-only, never block scan
    except SystemExit:
        raise
    except Exception:
        pass

    # Get repo stats for banner
    repo_stats = _get_repo_stats(repo_path)

    # Initialize scan context early for language/build system detection in header
    from reachable.core.context import ScanContext

    scan_ctx = ScanContext(repo_path, output_dir)

    # Print scan header with analysis scope (before tee takes over)
    scan_log.scan_start(
        repo_path.name,
        repo_path,
        __version__,
        license_info=license_info,
        repo_stats=repo_stats,
        scan_context=scan_ctx,
    )

    # Use output manager for all paths
    libs_dir = output_mgr.scan_dir / "libs"

    # Tee output to log file - suppress console unless in debug mode
    # Quiet mode also suppresses console (for CI/CD)
    # This captures all verbose output from scanners to the log file
    # while showing only our structured output on console
    console_enabled = debug_mode and not quiet_mode
    tee = TeeOutput(log_path, console_enabled=console_enabled)
    original_stdout = sys.stdout
    sys.stdout = tee

    try:
        # Validate inputs
        if not repo_path.exists():
            scan_log._write(f" Error: Repository not found: {repo_path}")
            sys.exit(1)

        if not repo_path.is_dir():
            scan_log._write(f" Error: Not a directory: {repo_path}")
            sys.exit(1)

        # scan_ctx already initialized above for header display
        if debug_mode:
            scan_ctx.print_scan_header()

        # Check GitHub connectivity (for library cloning) - only show in debug mode
        check_github_connectivity(verbose=debug_mode)

        # Print scan plan for monorepos (only in debug mode)
        if debug_mode:
            scan_ctx.print_scan_plan()

        # Save scan plan (what we're going to scan)
        scan_plan = {
            "timestamp": output_mgr.timestamp,
            "repo_path": str(repo_path),
            "repo_name": output_mgr.repo_name,
            "project_type": scan_ctx.project_type,
            "languages": scan_ctx.detected_languages,
            "is_monorepo": scan_ctx.is_monorepo,
            "subprojects": scan_ctx.subprojects,
            "file_counts": scan_ctx.total_files,
        }
        output_mgr.save_scan_plan(scan_plan)

        # Initialize scan metadata (tool versions, policies)
        scan_metadata = {
            "scan_started": output_mgr.timestamp,
            "command": " ".join(sys.argv),
            "scan_dir": str(output_dir),
            "tools_used": {},
            "policies_applied": {},
        }

        # RADR v5.3: Collect build provenance (git, CI, image)
        try:
            from reachable.core.provenance import collect_provenance

            provenance = collect_provenance(
                repo_path,
                cli_overrides={
                    "commit": getattr(args, "commit", None) or "",
                    "branch": getattr(args, "branch", None) or "",
                    "tag": getattr(args, "tag", None) or "",
                    "image": getattr(args, "image_tag", None) or "",
                    "image_digest": getattr(args, "image_digest", None) or "",
                },
            )
            scan_metadata.update(provenance)
            # Save provenance for RADR manifest compilation
            provenance_file = output_dir / "provenance.json"
            with open(provenance_file, "w") as pf:
                json.dump(provenance, pf, indent=2, default=str)
        except Exception as e:
            import traceback

            logger.warning(f"Provenance collection failed: {e}")
            traceback.print_exc()

        # Run analysis pipeline (reuses all existing logic!)
        # Step 1: Generate SBOM (reuses existing syft logic)
        scan_log.phase_start(1, "SBOM Generation", "Syft", total_phases=5)
        sbom_file = generate_sbom(repo_path, output_dir, verbose=debug_mode)
        scan_log.phase_end(1, f"Created {sbom_file.name}")

        # Step 1b: Enrich SBOM PURLs for private registry support
        # Rewrites renamed/mirrored private-registry PURLs to canonical upstream
        # identities via hash verification, so Grype matches CVEs correctly.
        sbom_file, purl_resolution_map, purl_coverage = enrich_sbom_purls(sbom_file, verbose=debug_mode)
        if purl_resolution_map:
            scan_log._write(f"  PURL: {len(purl_resolution_map)} private package(s) resolved")

        # Step 1c: Package Health & Dependency Confusion (T7)
        # Advisory-only — never counts toward vuln totals or risk score
        pkg_health_report = None
        no_health = getattr(args, "no_health", False)
        if not no_health:
            try:
                from reachable.collectors.health import PackageHealthCollector

                health_collector = PackageHealthCollector(
                    sbom_path=sbom_file,
                    purl_resolution_map=purl_resolution_map,
                    repo_path=str(repo_path),
                )
                pkg_health_report = health_collector.collect()

                # DB store happens after run_reachability_analysis() where scan_id is available
                adv_count = len(getattr(pkg_health_report, 'advisories', []))
                if adv_count > 0:
                    scan_log._write(f"  PKG_HEALTH: {adv_count} advisory(s) collected")
                else:
                    scan_log._write("  PKG_HEALTH: all packages healthy")

                # Warn if all advisories show as Transitive — likely old Syft version
                # that doesn't emit metadata.relationship for npm packages
                _advisories_all = getattr(pkg_health_report, 'advisories', [])
                if _advisories_all and not any(a.get('is_direct') for a in _advisories_all):
                    try:
                        import subprocess as _sp

                        from reachable.collectors.vulns.grype import get_syft_path as _gsp
                        _sv = _sp.check_output([str(_gsp()), 'version', '--output', 'json'],
                                               capture_output=True, timeout=5).stdout
                        import json as _j
                        _sv_str = _j.loads(_sv).get('version', '')
                        _sv_parts = [int(x) for x in _sv_str.lstrip('v').split('.')[:2] if x.isdigit()]
                        if _sv_parts and _sv_parts[0] == 0 and len(_sv_parts) > 1 and _sv_parts[1] < 90:
                            scan_log._write(
                                f"  ⚠ Supply Chain: all packages show as Transitive "
                                f"(Syft {_sv_str} does not emit relationship metadata for npm; "
                                f"upgrade to Syft ≥0.90 for accurate Direct/Transitive detection)"
                            )
                    except Exception:
                        pass
            except ImportError as e:
                if debug_mode:
                    scan_log._write(f"  Package health module not available: {e}")
            except Exception as e:
                # Package health never fails the scan
                scan_log._write(f"  Package health check error (non-fatal): {e}")
                if debug_mode:
                    import traceback as _ph_tb
                    scan_log._write(_ph_tb.format_exc())

        # T7: Write raw/health.json for scan archive
        if pkg_health_report and hasattr(pkg_health_report, 'advisories'):
            try:
                raw_dir = output_dir / "raw"
                raw_dir.mkdir(parents=True, exist_ok=True)
                health_json = {
                    "advisories": pkg_health_report.advisories,
                    "summary": {
                        "total_advisories": len(pkg_health_report.advisories),
                    },
                }
                health_file = raw_dir / "health.json"
                with open(health_file, "w") as _hf:
                    json.dump(health_json, _hf, indent=2, default=str)
                logger.info(f" raw/health.json ({len(pkg_health_report.advisories)} advisories)")
            except Exception:
                pass  # Non-fatal

        # Step 2: Scan vulnerabilities (reuses existing grype logic)
        scan_log.phase_start(2, "Vulnerability Scan", "Grype", total_phases=5)
        vulns_file = scan_vulnerabilities(sbom_file, output_dir, verbose=debug_mode)
        scan_log.phase_end(2, "CVE scan complete")

        # Step 3: Clone vulnerable libs (NEW smart cloning)
        scan_log.phase_start(3, "Library Cloning", "MCP/Git", total_phases=5)
        libs_path, lib_metrics = clone_vulnerable_libs(
            vulns_file, libs_dir, scan_ctx, purl_resolutions=purl_resolution_map, verbose=debug_mode
        )
        cloned_count = (
            lib_metrics.get("mcp_success", 0) + lib_metrics.get("git_success", 0) + lib_metrics.get("cache_hits", 0)
        )
        scan_log.phase_end(3, f"{cloned_count} libraries cloned")

        # T-CG15: JS/TS callgraph (Joern or ts-morph fallback) for npm CVE reachability
        # Run before reachability analysis so normalizer picks up call-graph-js.json
        if (
            scan_ctx
            and "javascript" in (scan_ctx.detected_languages or [])
            or any((repo_path / f).exists() for f in ("package.json", "package-lock.json"))
        ):
            try:
                from reachable.collectors.callgraph.js_collector import JSCallGraphCollector

                _js_collector = JSCallGraphCollector()
                if _js_collector.is_available():
                    _commit = None
                    _prov_file = output_dir / "provenance.json"
                    if _prov_file.exists():
                        try:
                            import json as _json

                            _prov = _json.loads(_prov_file.read_text())
                            _commit = _prov.get("source_provenance", {}).get("commit_sha", "")
                        except Exception:
                            pass
                    _js_cg = _js_collector.collect(
                        src_dir=repo_path,
                        output_dir=output_dir,
                        commit_sha=_commit or "",
                    )
                    if _js_cg:
                        scan_log._write(f" JS callgraph: {_js_collector.tier} → {_js_cg.name}")
            except Exception as _js_err:
                if debug_mode:
                    scan_log._write(f" JS callgraph skipped: {_js_err}")

        # Step 4 & 5: Reachability analysis (reuses existing reachable.py)
        scan_log.phase_start(4, "Security Analysis", "Multi-Signal Analysis", total_phases=5)
        if debug_mode:
            scan_ctx.print_phase_header(
                4,
                5,
                "Running Security Analysis",
                "Multi-Signal Analysis",
                f"Analyzing {scan_ctx.project_type} project with {', '.join(scan_ctx.detected_languages)}",
            )

        # Check dynamic malware sandbox settings
        enable_dynamic_malware = not getattr(args, "no_dynamic_malware", False)

        # v4.5.39: AI security scan ON by default (use --no-ai to skip)
        disable_ai = getattr(args, "disable_ai", False)
        ai_findings_for_correlation = []
        ai_scanner = None
        ai_scan_time = 0.0  # v4.5.39: Track AI scan timing

        if not disable_ai:
            try:
                from reachable.ai import AIScanConfig, AISecurityScanner

                ai_scan_start = time.time()
                ai_scanner = AISecurityScanner(config=AIScanConfig.full())
                ai_findings_list = list(ai_scanner.scan(repo_path))
                ai_scan_time = time.time() - ai_scan_start

                # v4.5.30: Pass AIFinding objects (not dicts) so they can be enriched with call graph reachability
                # Correlation engine handles both AIFinding objects and dicts
                ai_findings_for_correlation = ai_findings_list

                if debug_mode:
                    scan_log.info(f" AI Security: {len(ai_findings_list)} findings in {ai_scan_time:.1f}s")
            except ImportError as e:
                scan_log._write(f"  AI module not available: {e}")
            except Exception as e:
                import traceback as _ai_tb

                scan_log._write(f"  AI pre-scan error: {e}")
                scan_log._write(_ai_tb.format_exc())

        analysis_start = time.time()
        last_step_time = [analysis_start]  # Use list to allow mutation in closure
        _last_step_name = [None]  # Track for dedup

        # Spinner state — only active in non-debug mode
        import sys as _sys
        import threading as _threading
        _spinner_thread = [None]
        _spinner_stop = [False]
        _SPINNER_FRAMES = ["⠋", "⠙", "⠹", "⠸", "⠼", "⠴", "⠦", "⠧", "⠇", "⠏"]

        def _start_spinner(name: str):
            """Start a background spinner on stderr (non-debug only, TTY only)."""
            if debug_mode or not _sys.stderr.isatty():
                return
            _spinner_stop[0] = False
            def _spin():
                i = 0
                start = time.time()
                while not _spinner_stop[0]:
                    elapsed = time.time() - start
                    frame = _SPINNER_FRAMES[i % len(_SPINNER_FRAMES)]
                    _sys.stderr.write(f"\r   {frame} {name}... ({elapsed:.0f}s)")
                    _sys.stderr.flush()
                    i += 1
                    _threading.Event().wait(0.1)
                # Clear the spinner line
                _sys.stderr.write("\r" + " " * 40 + "\r")
                _sys.stderr.flush()
            t = _threading.Thread(target=_spin, daemon=True)
            t.start()
            _spinner_thread[0] = t

        def _stop_spinner():
            """Stop the spinner and wait for thread to clear the line."""
            if _spinner_thread[0] is None:
                return
            _spinner_stop[0] = True
            _spinner_thread[0].join(timeout=0.5)
            _spinner_thread[0] = None


        # Patch scan_log._write so ANY write (health metrics, colima, etc.)
        # stops the spinner first — prevents "⠋ Step... (0s)2026-03-..." interleaving.
        if not debug_mode:
            _orig_scan_log_write = scan_log._write
            def _patched_write(message, newline=True, level="INFO"):
                _stop_spinner()
                _orig_scan_log_write(message, newline=newline, level=level)
            scan_log._write = _patched_write

        def progress_callback(step: int, total: int, name: str, status: str):
            """Show sub-step progress during security analysis."""
            now = time.time()
            elapsed = now - last_step_time[0]
            # Only print on start of a new step (avoid start+complete spam)
            if status.endswith("...") or status in (
                "Parsing...",
                "Scanning...",
                "Finding...",
                "Computing...",
                "Mapping...",
            ):
                _stop_spinner()
                scan_log._write(f"   {name}...")
                _last_step_name[0] = name
                last_step_time[0] = now
                _start_spinner(name)
            elif _last_step_name[0] == name and elapsed > 1.0:
                # Step completed, took >1s — show timing
                _stop_spinner()
                scan_log._write(f"   {name} ({elapsed:.1f}s) \u2192 {status}")
                _last_step_name[0] = None
                last_step_time[0] = now

        results = run_reachability_analysis(
            repo_path,
            sbom_file,
            vulns_file,
            libs_path,
            output_dir,
            enable_dynamic_malware=enable_dynamic_malware,
            debug=debug_mode,
            progress_callback=progress_callback,
            ai_findings=ai_findings_for_correlation,  # v4.5.18: Pass AI findings for correlation
            sandbox_cache_ttl=getattr(args, "sandbox_cache_ttl", 24),
            force_rebuild=force_rebuild,
            ai_scan_time=ai_scan_time,  # v4.5.39: Pass AI scan timing for step breakdown
        )
        _stop_spinner()  # safety: clear any lingering spinner
        scan_log.phase_end(4, "Analysis complete")

        # Add library metrics to results (includes obsolete packages info)
        results["library_metrics"] = lib_metrics

        # Add PURL resolution coverage for dashboard/reporting
        if purl_coverage:
            results["purl_coverage"] = purl_coverage

        # T7: Add package health report to results + store in DB
        if pkg_health_report:
            results["package_health"] = pkg_health_report.to_dict()
            # Store advisories in DB now that scan_id is available
            _ph_db_path = results.get("_repo_db_path")
            _ph_scan_id = results.get("_scan_id")
            if _ph_db_path and _ph_scan_id:
                try:
                    from reachable.database.storage import RepoDatabase
                    _ph_db = RepoDatabase(_ph_db_path)
                    _ph_db._current_scan_id = _ph_scan_id
                    stored = _ph_db.store_package_health(pkg_health_report)
                    _ph_db.close()
                    adv_count = len(getattr(pkg_health_report, 'advisories', []))
                    if adv_count > 0:
                        scan_log._write(f"  PKG_HEALTH: {stored} advisory(s) stored in DB")
                except Exception as _ph_exc:
                    scan_log._write(f"  PKG_HEALTH: DB store failed (non-fatal): {_ph_exc}")

        # Optional: Run deployment advisories scan (IaC/config)
        if getattr(args, "enable_config_mgt", False):
            scan_log.phase_start(5, "Config Scanning", "Checkov/Semgrep", total_phases=6)

            from reachable.output.advisories import DeploymentAdvisoriesScanner, print_advisories

            use_checkov = getattr(args, "use_checkov", False)
            adv_scanner = DeploymentAdvisoriesScanner(use_checkov=use_checkov)
            adv_result = adv_scanner.scan(repo_path)

            # Save results
            adv_file = output_dir / "deployment-advisories.json"
            with open(adv_file, "w") as f:
                json.dump(adv_result.to_dict(), f, indent=2)

            # Add to results (but clearly marked as NOT in risk score)
            results["deployment_advisories"] = {
                "enabled": True,
                "included_in_risk_score": False,
                "total": len(adv_result.advisories),
                "by_category": adv_result.by_category,
                "by_severity": adv_result.by_severity,
                "source": adv_result.source,
                "output_file": str(adv_file),
            }

            scan_log.phase_end(5, f"{len(adv_result.advisories)} advisories found")

            # Print summary in debug mode
            if debug_mode:
                print_advisories(adv_result, verbose=True)
        else:
            results["deployment_advisories"] = {
                "enabled": False,
                "message": "Use --enable-config-mgt to scan IaC/deployment configs",
            }

        # T-AI1: Enrich AI findings with call graph reachability now that the engine
        # has run and results['call_graph'] contains reachable_functions + adjacency.
        if not disable_ai and ai_findings_for_correlation:
            try:
                from reachable.ai.ai_reachability_integration import integrate_ai_reachability

                cg_data = results.get("call_graph", {})
                reachable_funcs = set(cg_data.get("reachable_functions", []))
                adjacency = cg_data.get("adjacency", {})
                entrypoints = set(cg_data.get("entrypoints", []))

                if reachable_funcs:  # Only enrich when call graph data is available
                    ai_findings_for_correlation, _ai_enrich_summary = integrate_ai_reachability(
                        findings=ai_findings_for_correlation,
                        call_graph=adjacency,
                        reachable_functions=reachable_funcs,
                        entrypoints=entrypoints,
                        repo_path=repo_path,
                    )
                    if debug_mode:
                        scan_log._write(
                            f" T-AI1 enrichment: {_ai_enrich_summary['reachable_findings']}/"
                            f"{_ai_enrich_summary['total_findings']} AI findings reachable, "
                            f"{_ai_enrich_summary['guarded_findings']} guarded"
                        )
            except Exception as _ai_enrich_err:
                if debug_mode:
                    scan_log._write(f" AI enrichment skipped: {_ai_enrich_err}")

        # Save AI security results (v4.5.39: AI scan runs by default)
        if not disable_ai and ai_scanner is not None:
            # Save AI results to file
            ai_findings_list = ai_scanner._findings
            by_owasp = {}
            by_severity = {"ERROR": 0, "WARNING": 0, "INFO": 0}
            for f in ai_findings_list:
                cat = f.owasp_category or "OTHER"
                if cat not in by_owasp:
                    by_owasp[cat] = []
                by_owasp[cat].append(f.to_dict())
                by_severity[f.severity] = by_severity.get(f.severity, 0) + 1

            ai_file = output_dir / "raw" / "ai-security.json"  # v4.5.29: Move to raw/ for debug
            with open(ai_file, "w") as f:
                json.dump(
                    {
                        "total": len(ai_findings_list),
                        "by_owasp": {k: len(v) for k, v in by_owasp.items()},
                        "by_severity": by_severity,
                        "findings": [finding.to_dict() for finding in ai_findings_list],
                    },
                    f,
                    indent=2,
                    default=str,
                )

            # Count reachable and guarded
            ai_reachable = sum(1 for f in ai_findings_list if f.is_reachable)
            ai_guarded = sum(1 for f in ai_findings_list if f.guards)

            # Add to results
            results["ai_security"] = {
                "enabled": True,
                "included_in_risk_score": True,  # v4.5.18: Integrated into correlation
                "total": len(ai_findings_list),
                "reachable": ai_reachable,
                "guarded": ai_guarded,
                "by_owasp": {k: len(v) for k, v in by_owasp.items()},
                "by_severity": by_severity,
                "critical_findings": sum(1 for f in ai_findings_list if f.is_critical),
                "output_file": str(ai_file),
            }
        else:
            results["ai_security"] = {
                "enabled": False,
                "message": "AI analysis skipped (--no-ai flag)",
            }

        # v4.5.50: DLP/PII analysis (ON by default, use --no-dlp to skip)
        disable_dlp = getattr(args, "disable_dlp", False)
        dlp_scanner = None
        dlp_scan_time = 0.0

        if not disable_dlp:
            try:
                from reachable.dlp import DLPScanConfig, DLPScanner

                dlp_scan_start = time.time()
                dlp_scanner = DLPScanner(config=DLPScanConfig.full())
                dlp_findings_list = dlp_scanner.scan(repo_path)
                dlp_scan_time = time.time() - dlp_scan_start

                # Always show DLP timing (v4.5.50)
                scan_log._write(f" DLP/PII Security: {len(dlp_findings_list)} findings in {dlp_scan_time:.1f}s")
            except ImportError as e:
                scan_log._write(f"  DLP module not available: {e}")
            except Exception as e:
                import traceback as _dlp_tb

                scan_log._write(f"  DLP scan error: {e}")
                scan_log._write(_dlp_tb.format_exc())

        # Save DLP results
        if not disable_dlp and dlp_scanner is not None:
            dlp_stats = dlp_scanner.statistics

            # Save DLP results to file
            dlp_file = output_dir / "raw" / "dlp-security.json"
            with open(dlp_file, "w") as f:
                json.dump(
                    {
                        "total": dlp_stats.get("total_findings", 0),
                        "discovery_findings": dlp_stats.get("discovery_findings", 0),
                        "taint_findings": dlp_stats.get("taint_findings", 0),
                        "ai_findings": dlp_stats.get("ai_findings", 0),
                        "by_pii_type": dlp_stats.get("by_pii_type", {}),
                        "by_severity": dlp_stats.get("by_severity", {}),
                        "by_sink_type": dlp_stats.get("by_sink_type", {}),
                        "findings": [f.to_dict() for f in dlp_scanner.findings],
                    },
                    f,
                    indent=2,
                    default=str,
                )

            results["dlp_security"] = {
                "enabled": True,
                "included_in_risk_score": True,
                "total": dlp_stats.get("total_findings", 0),
                "discovery_findings": dlp_stats.get("discovery_findings", 0),
                "taint_findings": dlp_stats.get("taint_findings", 0),
                "ai_findings": dlp_stats.get("ai_findings", 0),
                "reachable": dlp_stats.get("reachable_findings", 0),
                "sanitized": dlp_stats.get("sanitized_findings", 0),
                "by_pii_type": dlp_stats.get("by_pii_type", {}),
                "by_severity": dlp_stats.get("by_severity", {}),
                "output_file": str(dlp_file),
                "scan_time": dlp_scan_time,  # v4.5.50: Track DLP scan timing
            }
        else:
            results["dlp_security"] = {
                "enabled": False,
                "message": "DLP analysis skipped (--no-dlp flag)",
            }

        # v5.1.3: ALL raw files now written. Run ingester to populate DB.
        try:
            from reachable.database.ingester import ingest as ingest_to_db
            from reachable.database.storage import RepoDatabase

            _repo_db_path = results.get("_repo_db_path")
            _scan_id = results.get("_scan_id")
            _output_dir = results.get("_output_dir")

            if _repo_db_path and _scan_id and _output_dir:
                _db = RepoDatabase(Path(_repo_db_path))
                _db._current_scan_id = _scan_id

                ingest_result = ingest_to_db(
                    scan_dir=Path(_output_dir),
                    db=_db,
                    scan_id=_scan_id,
                    skip_iac=getattr(args, "skip_iac", False),
                )

                # Complete scan with risk data
                source_files_scanned = results.get("metadata", {}).get("source_files_scanned", 0)
                _db.complete_scan(
                    duration_seconds=0,
                    risk_score=results.get("_db_risk_score", 0),
                    risk_level=results.get("_db_risk_level", "UNKNOWN"),
                    source_files_scanned=source_files_scanned,
                )

                # Auto-trim old scans
                _db.cleanup_old_scans()

                scan_log._write(
                    f" Ingester: {ingest_result.total} findings "
                    f"({ingest_result.cve_count} CVE, {ingest_result.cwe_count} CWE, "
                    f"{ingest_result.secret_count} secret, {ingest_result.malware_count} malware, "
                    f"{ingest_result.ai_count} AI, {ingest_result.dlp_count} DLP)"
                )

                # Phase 5: Persist unresolved packages to DB
                # Must run before _db.close() so DB connection is live
                try:
                    from reachable.collectors.vulns.purl_resolver import PURLResolver

                    _resolver = PURLResolver()
                    _enriched_sbom = sbom_file  # enriched path from step 1b
                    _unresolved = _resolver.persist_unresolved(_enriched_sbom, db=_db)
                    if _unresolved:
                        scan_log._write(f" PURL: {len(_unresolved)} unresolved package(s) tracked")
                except Exception as _unresolved_err:
                    if debug_mode:
                        scan_log._write(f" Unresolved tracking skipped: {_unresolved_err}")

                _db.close()

        except Exception as _ingest_err:
            import traceback as _ing_tb

            scan_log._write(f"  Ingester error: {_ingest_err}")
            scan_log._write(_ing_tb.format_exc())

        # v1.0.0b15: Coverage gap analysis
        # Runs after ingester so DB is populated. Failure never aborts scan.
        try:
            from reachable.analysis.coverage import run_coverage_analysis, store_coverage_report
            from reachable.database.storage import RepoDatabase

            # Build callgraph_packages from reachability results
            _cg_pkgs = None
            _reach_data = results.get("reachable", {})
            _unreach_data = results.get("unreachable", {})
            if _reach_data or _unreach_data:
                _cg_pkgs = set()
                for cve_data in list(_reach_data.values()) + list(_unreach_data.values()):
                    pkg = (cve_data.get("package") or cve_data.get("package_name") or "").split(" ")[0]
                    if pkg:
                        _cg_pkgs.add(pkg)

            # Load findings from DB for reachability gap analysis
            _db_findings = []
            _cov_db_path = results.get("_repo_db_path")
            _cov_scan_id = results.get("_scan_id")
            if _cov_db_path and _cov_scan_id and Path(_cov_db_path).exists():
                import sqlite3 as _csql

                _cconn = _csql.connect(str(_cov_db_path))
                _cconn.row_factory = _csql.Row
                _ccur = _cconn.cursor()
                # Fetch all finding types — coverage analyzer needs package names
                # from CVE findings for blind-spot analysis and all types for counts.
                # Previously only fetched CVE which made reachability gap analysis
                # miss packages surfaced via CWE/SECRET/MALWARE findings.
                _ccur.execute(
                    """
                    SELECT finding_type, id, package_name, package_version,
                           severity, app_reachability
                    FROM findings WHERE scan_id = ?
                """,
                    (_cov_scan_id,),
                )
                _db_findings = [
                    {
                        "finding_type": r["finding_type"],
                        "id": r["id"],
                        "package_name": r["package_name"] or "",
                        "version": r["package_version"] or "",
                        "severity": r["severity"] or "UNKNOWN",
                        "app_reachability": r["app_reachability"] or "UNKNOWN",
                    }
                    for r in _ccur.fetchall()
                ]
                _cconn.close()

            _sbom_data = {}
            _sbom_f = output_dir / "sbom.json"
            if not _sbom_f.exists():
                _sbom_f = output_dir / "sbom.json.gz"
            if _sbom_f.exists():
                try:
                    import gzip as _gz

                    opener = _gz.open if str(_sbom_f).endswith(".gz") else open
                    with opener(_sbom_f, "rt") as _sf:
                        _sbom_data = json.load(_sf)
                except Exception:
                    pass

            # Collect scanned_manifests from the scan output dir so coverage
            # analyzer doesn't have to guess via heuristics.
            _scanned_manifests = []
            _manifest_names = {
                "go.mod",
                "package.json",
                "package-lock.json",
                "requirements.txt",
                "pyproject.toml",
                "setup.py",
                "Pipfile",
                "Cargo.toml",
                "pom.xml",
                "build.gradle",
                "Gemfile",
            }
            for _mn in _manifest_names:
                if (repo_path / _mn).exists():
                    _scanned_manifests.append(_mn)

            coverage_report = run_coverage_analysis(
                project_path=str(repo_path),
                scan_id=results.get("_scan_id", "unknown"),
                metadata_dir=str(output_dir / ".metadata"),
                sbom_data=_sbom_data,
                findings=_db_findings,
                callgraph_packages=_cg_pkgs,
                analyzed_languages=list(scan_ctx.detected_languages or []),
                scanned_manifests=_scanned_manifests,
            )
            results["coverage_report"] = coverage_report

            # Persist to DB
            if _cov_db_path and _cov_scan_id:
                _cov_db = RepoDatabase(Path(_cov_db_path))
                store_coverage_report(_cov_db.conn, _cov_scan_id, coverage_report)
                _cov_db.close()

            score_pct = round(coverage_report.get("coverage_score", 0) * 100)
            gap_count = (
                len(coverage_report.get("languages", {}).get("gaps", []))
                + len(coverage_report.get("reachability_blind_spots", []))
                + len(coverage_report.get("sub_modules", []))
            )
            scan_log._write(
                f" Coverage: {score_pct}% | {gap_count} gap(s) | "
                f"{len(coverage_report.get('recommendations', []))} recommendations"
            )
        except ImportError as _cov_import_err:
            # Module not installed — expected in stripped deployments
            scan_log._write(f"  Coverage module unavailable: {_cov_import_err}")
        except Exception as _cov_err:
            # Real error — always visible regardless of --debug
            import traceback as _cov_tb

            scan_log._write(f"  Coverage analysis failed: {_cov_err}")
            scan_log._write(_cov_tb.format_exc())

        # v4.5.50: Set DLP timing for timing summary
        scan_log.set_dlp_timing(dlp_scan_time)

        # Print timing summary
        scan_log.print_timing_summary()

        # Extract results for summary — query DB as single source of truth
        # (DB has post-normalization data: FP suppression, dedup, severity remap)
        try:
            summary = results.get("summary", {})

            # Dynamic malware + AI/DLP metadata from in-memory results
            # (these details are not in the findings DB table)
            security_scans = results.get("security_scans", {})
            dynamic_malware = results.get("dynamic_malware", security_scans.get("dynamic_malware", {}))
            ai_security = results.get("ai_security", {})
            dlp_security = results.get("dlp_security", {})

            # ── Query DB for all counts (single source of truth) ────────────
            _repo_db_path = results.get("_repo_db_path")
            _scan_id = results.get("_scan_id")

            # Signal → (total, reachable, unreachable, unknown)
            _db_counts = {}
            # Signal → {severity → count}
            _db_all_sev = {}
            # Signal → {severity → count}  (reachable only)
            _db_reach_sev = {}
            # Signal → {severity → count}  (unknown only)
            _db_unkn_sev = {}

            _sev_levels = ("CRITICAL", "HIGH", "MEDIUM", "LOW")

            def _norm_db_sev(s):
                s = (s or "MEDIUM").upper()
                if s == "ERROR":
                    return "CRITICAL"
                if s == "WARNING":
                    return "MEDIUM"
                if s == "INFO":
                    return "LOW"
                return s if s in _sev_levels else "MEDIUM"

            if _repo_db_path and _scan_id and Path(_repo_db_path).exists():
                import sqlite3 as _sql

                _conn = _sql.connect(str(_repo_db_path))
                _conn.row_factory = _sql.Row
                _conn.execute("PRAGMA busy_timeout=5000")
                _cur = _conn.cursor()

                # findings table: cve, cwe, config, secret, malware, suspicious
                _cur.execute(
                    """
                    SELECT finding_type, app_reachability, severity, COUNT(*) as cnt
                    FROM findings WHERE scan_id = ?
                    GROUP BY finding_type, app_reachability, severity
                """,
                    (_scan_id,),
                )
                for row in _cur.fetchall():
                    ft = row["finding_type"].lower()
                    reach = (row["app_reachability"] or "UNKNOWN").upper()
                    sev = _norm_db_sev(row["severity"])
                    cnt = row["cnt"]

                    if ft not in _db_counts:
                        _db_counts[ft] = {"total": 0, "reachable": 0, "unreachable": 0, "unknown": 0}
                    if ft not in _db_all_sev:
                        _db_all_sev[ft] = {}
                    if ft not in _db_reach_sev:
                        _db_reach_sev[ft] = {}

                    _db_counts[ft]["total"] += cnt
                    if reach == "REACHABLE":
                        _db_counts[ft]["reachable"] += cnt
                    elif reach == "NOT_REACHABLE":
                        _db_counts[ft]["unreachable"] += cnt
                    else:
                        _db_counts[ft]["unknown"] += cnt

                    _db_all_sev[ft][sev] = _db_all_sev[ft].get(sev, 0) + cnt
                    if reach == "REACHABLE":
                        _db_reach_sev[ft][sev] = _db_reach_sev[ft].get(sev, 0) + cnt
                    elif reach not in ("NOT_REACHABLE", "NOT_APPLICABLE"):
                        _db_unkn_sev.setdefault(ft, {})
                        _db_unkn_sev[ft][sev] = _db_unkn_sev[ft].get(sev, 0) + cnt

                # ai_findings table
                try:
                    _cur.execute(
                        """
                        SELECT is_reachable, severity, COUNT(*) as cnt
                        FROM ai_findings WHERE scan_id = ?
                        GROUP BY is_reachable, severity
                    """,
                        (_scan_id,),
                    )
                    _db_counts["ai"] = {"total": 0, "reachable": 0, "unreachable": 0, "unknown": 0}
                    _db_all_sev["ai"] = {}
                    _db_reach_sev["ai"] = {}
                    for row in _cur.fetchall():
                        sev = _norm_db_sev(row["severity"])
                        cnt = row["cnt"]
                        _db_counts["ai"]["total"] += cnt
                        if row["is_reachable"]:
                            _db_counts["ai"]["reachable"] += cnt
                        else:
                            _db_counts["ai"]["unreachable"] += cnt
                        _db_all_sev["ai"][sev] = _db_all_sev["ai"].get(sev, 0) + cnt
                        if row["is_reachable"]:
                            _db_reach_sev["ai"][sev] = _db_reach_sev["ai"].get(sev, 0) + cnt
                except _sql.OperationalError:
                    pass

                # dlp_findings table
                try:
                    _cur.execute(
                        """
                        SELECT is_reachable, severity, COUNT(*) as cnt
                        FROM dlp_findings WHERE scan_id = ?
                        GROUP BY is_reachable, severity
                    """,
                        (_scan_id,),
                    )
                    _db_counts["dlp"] = {"total": 0, "reachable": 0, "unreachable": 0, "unknown": 0}
                    _db_all_sev["dlp"] = {}
                    _db_reach_sev["dlp"] = {}
                    for row in _cur.fetchall():
                        sev = _norm_db_sev(row["severity"])
                        cnt = row["cnt"]
                        _db_counts["dlp"]["total"] += cnt
                        if row["is_reachable"]:
                            _db_counts["dlp"]["reachable"] += cnt
                        else:
                            _db_counts["dlp"]["unreachable"] += cnt
                        _db_all_sev["dlp"][sev] = _db_all_sev["dlp"].get(sev, 0) + cnt
                        if row["is_reachable"]:
                            _db_reach_sev["dlp"][sev] = _db_reach_sev["dlp"].get(sev, 0) + cnt
                except _sql.OperationalError:
                    pass

                _conn.close()

            # Helper to get counts for a signal type
            def _gc(signal):
                return _db_counts.get(signal, {"total": 0, "reachable": 0, "unreachable": 0, "unknown": 0})

            def _gs(signal, level):
                return _db_all_sev.get(signal, {}).get(level, 0)

            # Map DB finding_types to CLI signal names
            cve = _gc("cve")
            secret = _gc("secret")
            cwe = _gc("cwe")
            config = _gc("config")
            malware = _gc("malware")
            suspicious = _gc("suspicious")
            ai = _gc("ai")
            dlp = _gc("dlp")

            # Malware (Static) = malware + suspicious (combined in CLI)
            malware_static_total = malware["total"] + suspicious["total"]
            malware_static_confirmed = malware["total"]
            malware_static_suspicious = suspicious["total"]
            malware_static_reachable = malware["reachable"] + suspicious["reachable"]

            # Build reachable_severity dict in format logger expects
            # {signal_name: {SEVERITY: count}}
            _reach_sev_out = {}
            _unkn_sev_out = {}
            _sig_map = {
                "cve": "cves",
                "secret": "secrets",
                "cwe": "cwe",
                "malware": "malware",
                "config": "config",
                "ai": "ai",
                "dlp": "dlp",
                "suspicious": "malware",
            }  # suspicious merges into malware
            for db_type, cli_name in _sig_map.items():
                reach_data = _db_reach_sev.get(db_type, {})
                if reach_data:
                    if cli_name not in _reach_sev_out:
                        _reach_sev_out[cli_name] = {}
                    for level, count in reach_data.items():
                        _reach_sev_out[cli_name][level] = _reach_sev_out[cli_name].get(level, 0) + count
                unkn_data = _db_unkn_sev.get(db_type, {})
                if unkn_data:
                    if cli_name not in _unkn_sev_out:
                        _unkn_sev_out[cli_name] = {}
                    for level, count in unkn_data.items():
                        _unkn_sev_out[cli_name][level] = _unkn_sev_out[cli_name].get(level, 0) + count

            # Merge suspicious severity into malware for all-signals too
            _merged_malware_sev = dict(_db_all_sev.get("malware", {}))
            for level, count in _db_all_sev.get("suspicious", {}).items():
                _merged_malware_sev[level] = _merged_malware_sev.get(level, 0) + count

            # v1.0.0b15: pull transitive counts from results summary
            _totals = results.get("summary", {}).get("totals", {})
            _cves_transitive = _totals.get("cves_transitive", 0)
            _cves_transitive_via = _totals.get("cves_transitive_via", {})

            scan_log.set_counts(
                # CVEs
                cves_total=cve["total"],
                cves_reachable=cve["reachable"],
                cves_unknown=cve["unknown"],
                cves_critical=_gs("cve", "CRITICAL"),
                cves_high=_gs("cve", "HIGH"),
                cves_medium=_gs("cve", "MEDIUM"),
                cves_low=_gs("cve", "LOW"),
                cves_transitive=_cves_transitive,
                cves_transitive_via=_cves_transitive_via,
                # Malware (static: confirmed + suspicious)
                malware_static=malware_static_total,
                malware_static_confirmed=malware_static_confirmed,
                malware_static_suspicious=malware_static_suspicious,
                malware_dynamic=dynamic_malware.get("summary", {}).get("malicious", 0) if dynamic_malware else 0,
                malware_dynamic_suspicious=(
                    dynamic_malware.get("summary", {}).get("suspicious", 0) if dynamic_malware else 0
                ),
                malware_reachable=malware_static_reachable,
                malware_count=malware_static_total,
                malware_critical=_merged_malware_sev.get("CRITICAL", 0),
                malware_high=_merged_malware_sev.get("HIGH", 0),
                malware_medium=_merged_malware_sev.get("MEDIUM", 0),
                malware_low=_merged_malware_sev.get("LOW", 0),
                # Secrets
                secrets_total=secret["total"],
                secrets_reachable=secret["reachable"],
                secrets_unknown=secret["unknown"],
                secrets_critical=_gs("secret", "CRITICAL"),
                secrets_high=_gs("secret", "HIGH"),
                secrets_medium=_gs("secret", "MEDIUM"),
                secrets_low=_gs("secret", "LOW"),
                # CWE
                cwe_total=cwe["total"],
                cwe_reachable=cwe["reachable"],
                cwe_unknown=cwe["unknown"],
                cwe_critical=_gs("cwe", "CRITICAL"),
                cwe_high=_gs("cwe", "HIGH"),
                cwe_medium=_gs("cwe", "MEDIUM"),
                cwe_low=_gs("cwe", "LOW"),
                # Config
                config_total=config["total"],
                config_critical=_gs("config", "CRITICAL"),
                config_high=_gs("config", "HIGH"),
                config_medium=_gs("config", "MEDIUM"),
                config_low=_gs("config", "LOW"),
                # AI Security
                ai_total=ai["total"],
                ai_reachable=ai["reachable"],
                ai_guarded=ai_security.get("guarded", 0),
                ai_critical=_gs("ai", "CRITICAL"),
                ai_high=_gs("ai", "HIGH"),
                ai_medium=_gs("ai", "MEDIUM"),
                ai_low=_gs("ai", "LOW"),
                # DLP/PII Security
                dlp_total=dlp["total"],
                dlp_reachable=dlp["reachable"],
                dlp_sanitized=dlp_security.get("sanitized", 0),
                dlp_critical=_gs("dlp", "CRITICAL"),
                dlp_high=_gs("dlp", "HIGH"),
                dlp_medium=_gs("dlp", "MEDIUM"),
                dlp_low=_gs("dlp", "LOW"),
                # Reachable-only and unknown-only severity breakdowns
                reachable_severity=_reach_sev_out,
                unknown_severity=_unkn_sev_out,
            )

            # Print results summary
            scan_log.print_results_summary()

            # Get risk score (v4.5.3 fix: risk is nested in overall_risk)
            overall_risk = summary.get("overall_risk", {})
            risk_score = overall_risk.get("risk_score", 0)
            risk_level = overall_risk.get("risk_level", "UNKNOWN")

            # Print scan complete banner with dashboard link
            scan_log.scan_complete(risk_score, risk_level, output_dir)

            # Print debug report if in debug mode
            scan_log.print_debug_report()

        except Exception as summary_err:
            # Make sure we see any errors in summary generation
            scan_log._write(f" Error generating summary: {summary_err}")
            import traceback

            scan_log._write(traceback.format_exc())

        # Generate dashboard
        _generate_dashboard(results, output_dir, skip=no_dashboard)

        # Create 'latest' symlink
        output_mgr.create_latest_symlink()

        # v4.6.4: Run data quality audit (only in debug mode)
        if debug_mode and not quiet_mode:
            try:
                from reachable.governance.audit import run_audit

                audit_result = run_audit(output_dir, compact=True, no_dashboard=no_dashboard, scan_logger=scan_log)
                if audit_result.get("error"):
                    scan_log._write(f"\n Audit error: {audit_result['error']}")
            except Exception as audit_err:
                scan_log._write(f"\n Audit skipped: {audit_err}")

        # Auto-trim handled by ingester flow (repo.db cleanup)

        # RADR v5.6: Compile manifest if --radr flag set
        if getattr(args, "radr", False):
            try:
                from reachable.core.manifest_compiler import compile_manifest

                manifest = compile_manifest(
                    scan_dir=output_dir,
                    image_tag=getattr(args, "image_tag", None),
                    image_digest=getattr(args, "image_digest", None),
                    output_path=output_dir / "radr-manifest.json",
                )

                # Summary counts (match manifest schema keys)
                probe_count = sum(len(probes) for probes in manifest.get("probe_targets", {}).values())
                eps = len(manifest.get("entrypoints", []))
                findings = len(manifest.get("active_findings", []))
                baseline_funcs = manifest.get("baseline_profile", {}).get("function_count", 0)
                manifest_file = output_dir / "radr-manifest.json"
                scan_log._write(
                    f" RADR manifest: {probe_count} probe targets, {eps} entrypoints, {findings} findings, {baseline_funcs} baselined functions"
                )
                scan_log._write(f" {manifest_file}")
            except Exception as radr_err:
                scan_log._write(f" RADR manifest compilation failed: {radr_err}")
                if debug_mode:
                    import traceback

                    scan_log._write(traceback.format_exc())

        # Quiet mode: print single-line summary
        if quiet_mode:
            print_quiet_summary(results, output_dir)

        # === SARIF OUTPUT (T-CI2) ===
        if sarif_output:
            try:
                import json as _json
                import os as _os

                from reachable.reporting.sarif import export_to_sarif

                sarif_path = Path(sarif_output).resolve()
                sarif_path.parent.mkdir(parents=True, exist_ok=True)

                # Auto-populate repo URI from GitHub Actions / GitLab / generic CI env.
                # Used to fill versionControlProvenance (branch + commit link in GH UI).
                _repo_uri = None
                _gh_repo = _os.environ.get("GITHUB_REPOSITORY")       # "owner/repo"
                _gh_server = _os.environ.get("GITHUB_SERVER_URL", "https://github.com")
                if _gh_repo:
                    _repo_uri = f"{_gh_server}/{_gh_repo}"
                elif _os.environ.get("CI_PROJECT_URL"):               # GitLab
                    _repo_uri = _os.environ["CI_PROJECT_URL"]
                elif _os.environ.get("BUILD_REPOSITORY_URI"):         # Azure DevOps
                    _repo_uri = _os.environ["BUILD_REPOSITORY_URI"]

                # Backfill branch/commit into scan metadata so versionControlProvenance
                # is populated even when the scan was not run inside a git checkout.
                if "scan" not in results:
                    results["scan"] = {}
                if not results["scan"].get("branch"):
                    results["scan"]["branch"] = (
                        _os.environ.get("GITHUB_REF_NAME")            # Actions
                        or _os.environ.get("CI_COMMIT_REF_NAME")      # GitLab
                        or _os.environ.get("BUILD_SOURCEBRANCHNAME")  # Azure
                        or ""
                    )
                if not results["scan"].get("commit"):
                    results["scan"]["commit"] = (
                        _os.environ.get("GITHUB_SHA")                 # Actions
                        or _os.environ.get("CI_COMMIT_SHA")           # GitLab
                        or _os.environ.get("BUILD_SOURCEVERSION")     # Azure
                        or ""
                    )

                sarif_data = export_to_sarif(results, repo_uri=_repo_uri)
                sarif_path.write_text(_json.dumps(sarif_data, indent=2))
                scan_log._write(f" SARIF written: {sarif_path}" + (f" (repo: {_repo_uri})" if _repo_uri else ""))
            except Exception as _sarif_exc:
                scan_log._write(f" SARIF export failed: {_sarif_exc}")

        # === FAIL-ON THRESHOLD + EXIT CODES (T-CI1/T-CI3) ===
        # Exit code semantics:
        #   0 = clean (no findings at or above threshold, or --fail-on none)
        #   1 = findings exist but ALL below threshold
        #   2 = threshold breached (findings >= --fail-on severity)
        exit_code = 0
        if fail_on_threshold != "none":
            from reachable.reporting.sarif import check_threshold

            should_fail, reason = check_threshold(results, fail_on_threshold)
            if should_fail:
                scan_log._write(f" CI/CD GATE FAILED: {reason}")
                scan_log._write(f" Threshold: --fail-on {fail_on_threshold}")
                exit_code = 2  # threshold breached
            else:
                scan_log._write(f" CI/CD gate passed: {reason}")
                # Exit 1 when there are ANY findings (even below threshold) so
                # CI pipelines can distinguish clean from findings-but-below-bar.
                summary = results.get("summary", {})
                totals = summary.get("totals", {})
                any_findings = (
                    totals.get("cves_reachable", 0)
                    + totals.get("secrets_reachable", 0)
                    + totals.get("cwe_reachable", 0)
                    + totals.get("malware_count", 0)
                ) > 0
                if any_findings:
                    exit_code = 1  # findings present but below threshold

        # Store exit code for later (after finally block)
        scan_exit_code = exit_code

    except Exception as e:
        # Log error with fallback to ensure visibility
        error_msg = f" Error during analysis: {e}"
        scan_log._write(error_msg)
        import traceback

        scan_log._write(traceback.format_exc())
        sys.exit(1)
    finally:
        # Close log file and restore stdout
        sys.stdout = original_stdout
        tee.close()

    # Exit with appropriate code (after finally block)
    # 0=clean, 1=findings below threshold, 2=threshold breached
    # scan_exit_code is set in the try block based on --fail-on / --ci
    if "scan_exit_code" in locals() and scan_exit_code != 0:
        sys.exit(scan_exit_code)


# v5.1.3: REMOVED - _calculate_risk_level, _extract_call_path, store_scan_to_database
# Replaced by reachable.database.ingester + normalizers.
# Risk calculation: normalizers/cve.py
# Call path extraction: normalizers/cve.py
# CWE/secret classification: normalizers/semgrep.py
# DB writes: ingester.ingest()
