#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.

"""
RADR Manifest CLI commands (v5.6).

Provides the `reachctl manifest compile` subcommand that compiles scan
results into an agent-ready manifest for the RADR runtime SDK/agent.

Usage:
    reachctl manifest compile \\
        --scan-dir .reachable/scans/latest \\
        --image-tag ghcr.io/acme/backend:v1.2.3 \\
        --image-digest sha256:abc123def... \\
        --sign --key cosign.key \\
        --output manifest.json
"""

import json
import logging
import sys
from pathlib import Path

logger = logging.getLogger(__name__)


def setup_manifest_parser(subparsers):
    """Register the 'manifest' subcommand group."""
    manifest_parser = subparsers.add_parser(
        "manifest",
        help="RADR manifest operations (compile, verify)",
        description="Compile scan results into agent-ready RADR manifests",
    )
    manifest_sub = manifest_parser.add_subparsers(dest="manifest_action", metavar="ACTION")

    # ── manifest compile ──────────────────────────────────────────────────
    compile_parser = manifest_sub.add_parser(
        "compile",
        help="Compile scan results into agent-ready manifest",
        description=(
            "Merges provenance, callable functions, internal entrypoints, "
            "and CVE data into a single manifest.json for the RADR runtime agent."
        ),
    )
    compile_parser.add_argument(
        "--scan-dir",
        "-s",
        metavar="DIR",
        required=True,
        help="Directory containing scan outputs (provenance.json, callable-functions.json, etc.)",
    )
    compile_parser.add_argument(
        "--output",
        "-o",
        metavar="FILE",
        default=None,
        help="Output manifest file path (default: <scan-dir>/radr-manifest.json)",
    )
    compile_parser.add_argument(
        "--image-tag",
        metavar="TAG",
        help="Container image tag (e.g. ghcr.io/acme/backend:v1.2.3)",
    )
    compile_parser.add_argument(
        "--image-digest",
        metavar="DIGEST",
        help="Container image digest (e.g. sha256:abc123...)",
    )
    compile_parser.add_argument(
        "--sign",
        action="store_true",
        help="Sign manifest with cosign",
    )
    compile_parser.add_argument(
        "--key",
        metavar="FILE",
        help="Path to cosign private key (required with --sign)",
    )
    compile_parser.add_argument(
        "--json",
        action="store_true",
        help="Output manifest JSON to stdout instead of file",
    )
    compile_parser.add_argument(
        "--quiet",
        "-q",
        action="store_true",
        help="Minimal output (CI-friendly)",
    )

    # ── manifest verify ───────────────────────────────────────────────────
    verify_parser = manifest_sub.add_parser(
        "verify",
        help="Verify a compiled manifest (schema + optional signature)",
        description="Validate manifest structure and optionally verify cosign signature.",
    )
    verify_parser.add_argument(
        "manifest_file",
        metavar="FILE",
        help="Path to manifest.json to verify",
    )
    verify_parser.add_argument(
        "--key",
        metavar="FILE",
        help="Path to cosign public key for signature verification",
    )

    return manifest_parser


def manifest_command(args):
    """Route manifest subcommands."""
    if not hasattr(args, "manifest_action") or args.manifest_action is None:
        print("Usage: reachctl manifest {compile,verify}")
        print("       reachctl manifest compile --scan-dir <DIR> [--output manifest.json]")
        sys.exit(1)

    if args.manifest_action == "compile":
        return _manifest_compile(args)
    elif args.manifest_action == "verify":
        return _manifest_verify(args)
    else:
        print(f"Unknown manifest action: {args.manifest_action}")
        sys.exit(1)


def _manifest_compile(args):
    """Handle `reachctl manifest compile`."""
    from reachable.core.manifest_compiler import compile_manifest

    scan_dir = Path(args.scan_dir)
    if not scan_dir.exists():
        print(f"✗ Scan directory not found: {scan_dir}")
        sys.exit(1)

    # Validate --sign requires --key
    sign_key = None
    if args.sign:
        if not args.key:
            print("✗ --sign requires --key <path-to-cosign-key>")
            sys.exit(1)
        sign_key = args.key

    if not args.quiet:
        print(f"Compiling RADR manifest from {scan_dir}")

    # Determine output path (default: radr-manifest.json in scan dir)
    if args.json:
        output_path = None
    elif args.output:
        output_path = Path(args.output)
    else:
        output_path = scan_dir / "radr-manifest.json"

    try:
        manifest = compile_manifest(
            scan_dir=scan_dir,
            image_tag=args.image_tag,
            image_digest=args.image_digest,
            sign_key=sign_key,
            output_path=output_path,
        )
    except Exception as e:
        print(f"✗ Manifest compilation failed: {e}")
        logger.debug("Compilation error", exc_info=True)
        sys.exit(1)

    # JSON-to-stdout mode
    if args.json:
        print(json.dumps(manifest, indent=2))
        return 0

    # Summary output
    if not args.quiet:
        probe_count = sum(len(probes) for probes in manifest.get("probe_targets", {}).values())
        ep_count = len(manifest.get("entrypoints", []))
        finding_count = len(manifest.get("active_findings", []))
        baseline_funcs = manifest.get("baseline_profile", {}).get("function_count", 0)

        print(f"  ✓ Probe targets: {probe_count} language runtimes")
        print(f"  ✓ Entrypoints:   {ep_count} (HTTP + internal)")
        print(f"  ✓ Findings:      {finding_count} active CVEs")
        print(f"  ✓ Baseline:      {baseline_funcs} expected functions")

        if manifest.get("signature"):
            print("  ✓ Signed with cosign")

        print(f"  → {output_path}")

    return 0


def _manifest_verify(args):
    """Handle `reachctl manifest verify`."""
    manifest_path = Path(args.manifest_file)
    if not manifest_path.exists():
        print(f"✗ Manifest not found: {manifest_path}")
        sys.exit(1)

    try:
        with open(manifest_path) as f:
            manifest = json.load(f)
    except json.JSONDecodeError as e:
        print(f"✗ Invalid JSON: {e}")
        sys.exit(1)

    # Schema validation
    errors = []
    required_fields = [
        "manifest_version",
        "generated_at",
        "probe_targets",
        "active_findings",
        "baseline_profile",
        "digest",
    ]
    for field in required_fields:
        if field not in manifest:
            errors.append(f"Missing required field: {field}")

    if manifest.get("manifest_version") != "1.0.0":
        errors.append(f"Unsupported manifest version: {manifest.get('manifest_version')}")

    # Verify digest
    stored_digest = manifest.pop("digest", None)
    manifest.pop("signature", None)  # Remove signature before digest check
    import hashlib

    recomputed = json.dumps(manifest, indent=2, sort_keys=True).encode("utf-8")
    expected = "sha256:" + hashlib.sha256(recomputed).hexdigest()
    if stored_digest and stored_digest != expected:
        errors.append(f"Digest mismatch: stored={stored_digest[:20]}... computed={expected[:20]}...")

    if errors:
        print("✗ Manifest validation failed:")
        for err in errors:
            print(f"  - {err}")
        sys.exit(1)

    print(f"✓ Manifest valid: {manifest_path}")
    print(f"  Version: {manifest.get('manifest_version')}")
    print(f"  Generated: {manifest.get('generated_at')}")
    print(f"  Commit: {manifest.get('commit', 'N/A')}")

    probe_count = sum(len(p) for p in manifest.get("probe_targets", {}).values())
    print(f"  Probe targets: {probe_count}")
    print(f"  Entrypoints: {len(manifest.get('entrypoints', []))}")
    print(f"  Active findings: {len(manifest.get('active_findings', []))}")
    print("  Digest: ✓ verified")

    return 0
