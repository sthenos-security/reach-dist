#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.
"""REACHABLE CLI - Main entry point and argument parsing."""

# Suppress urllib3/OpenSSL warnings on macOS
import warnings

warnings.filterwarnings("ignore", message=".*urllib3.*")
warnings.filterwarnings("ignore", message=".*OpenSSL.*")

import argparse
import logging
import os
import sys

# Suppress urllib3 OpenSSL warning on macOS (LibreSSL vs OpenSSL)
warnings.filterwarnings("ignore", message=".*urllib3 v2 only supports OpenSSL.*")
warnings.filterwarnings("ignore", category=DeprecationWarning, module="urllib3")

from reachable.cli.admin import admin_cache, admin_db, admin_doctor
from reachable.cli.commands import (
    audit_command,
    cleanup_command,
    config_command,
    open_dashboard,
    print_version,
    selftest,
    show_primer,
    system_command,
    top10size_command,
    vulndb_command,
)
from reachable.cli.manifest import manifest_command, setup_manifest_parser
from reachable.cli.sandbox import sandbox_command
from reachable.cli.scan import scan_repo

# Cross-module imports
from reachable.cli.utils import _check_venv_activation, setup_logger

logger = logging.getLogger(__name__)


def main():
    """Main CLI entry point"""

    # Check if venv is activated (warn if not)
    _check_venv_activation()

    parser = argparse.ArgumentParser(
        prog="reachctl",
        description="REACHABLE - Security vulnerability analysis with reachability intelligence",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  reachctl scan /path/to/repo              Scan a repository
  reachctl scan . --ci --fail-on high      CI/CD with exit code gating
  reachctl scan . --log-format jsonl       Machine-readable structured output
  reachctl dashboard --open                View results in browser
  reachctl doctor                          Check system dependencies
  reachctl export --format csv             Export findings as CSV
  reachctl primer                          Quick-start guide (paged)

© 2026 Sthenos Security. All rights reserved.
Support: info@sthenosec.com
""",
    )

    parser.add_argument("--version", "-V", action="store_true", help="Show version and exit")

    subparsers = parser.add_subparsers(dest="command", metavar="COMMAND")

    # ==========================================================================
    # scan - Main command
    # ==========================================================================
    scan_parser = subparsers.add_parser(
        "scan",
        help="Scan & discover executable risk in your code repo",
        description="Run complete security analysis on a repository",
    )
    scan_parser.add_argument("repo", metavar="PATH", help="Path to repository to scan")

    # Options
    scan_parser.add_argument(
        "--output", "-o", metavar="DIR", help="Output directory (default: ~/.reachable/scans/<repo>)"
    )
    scan_parser.add_argument(
        "--ci",
        action="store_true",
        help="CI mode: quiet output, structured exit codes, auto-enable --fail-on critical "
        "if no threshold set. Also activated automatically when CI=true env var is set.",
    )
    scan_parser.add_argument(
        "--sarif",
        metavar="FILE",
        help="Write SARIF 2.1.0 output to FILE (e.g. results.sarif). "
        "Suitable for GitHub Code Scanning, GitLab SAST, and Azure DevOps.",
    )
    scan_parser.add_argument(
        "--fail-on",
        choices=["critical", "high", "medium", "any", "none"],
        default="none",
        help="Exit non-zero if findings meet threshold (default: none)",
    )
    scan_parser.add_argument("--quiet", "-q", action="store_true", help="Minimal output (CI-friendly)")
    scan_parser.add_argument("--debug", "-d", action="store_true", help="Verbose output for debugging")
    scan_parser.add_argument(
        "--no-ai",
        "--disable-ai",
        action="store_true",
        dest="disable_ai",
        help="Skip AI/LLM security analysis (faster scans)",
    )
    scan_parser.add_argument(
        "--no-dlp", "--disable-dlp", action="store_true", dest="disable_dlp", help="Skip DLP/PII analysis"
    )
    scan_parser.add_argument(
        "--no-dashboard",
        action="store_true",
        dest="no_dashboard",
        help="Skip dashboard generation (faster CI/CD scans)",
    )
    scan_parser.add_argument(
        "--skip-iac",
        "--no-iac",
        action="store_true",
        help="Skip IaC/config scanning (Dockerfile, K8s, Terraform findings)",
    )
    scan_parser.add_argument(
        "--no-sandbox",
        "--no-dynamic-malware",
        action="store_true",
        dest="no_dynamic_malware",
        help="Skip dynamic malware sandbox analysis",
    )
    scan_parser.add_argument(
        "--no-health",
        action="store_true",
        dest="no_health",
        help="Skip package health checks (abandoned, deprecated, dependency confusion)",
    )
    scan_parser.add_argument(
        "--sandbox-cache-ttl",
        type=int,
        default=int(os.environ.get("REACHABLE_SANDBOX_CACHE_TTL", "24")),
        metavar="HOURS",
        dest="sandbox_cache_ttl",
        help="Sandbox result cache TTL in hours (default: 24, 0 to disable). Env: REACHABLE_SANDBOX_CACHE_TTL",
    )
    scan_parser.add_argument(
        "--force-rebuild",
        "--force",
        action="store_true",
        help="Force new scan (skip ALL caches: SBOM, call graph, sandbox, dashboard)",
    )

    # Output formatting options (v5.2)
    scan_parser.add_argument(
        "--no-timestamp",
        "--no-timestamps",
        action="store_true",
        dest="no_timestamps",
        help="Disable INFO prefix in output (clean message-only format)",
    )
    scan_parser.add_argument(
        "--log-format",
        choices=["text", "jsonl"],
        default="text",
        dest="log_format",
        help="Scan log output format: text (default) or jsonl (structured, for log aggregators)",
    )

    # RADR: Build provenance overrides (v5.3)
    prov_group = scan_parser.add_argument_group("provenance", "Build provenance overrides (auto-detected by default)")
    prov_group.add_argument("--commit", metavar="SHA", help="Override git commit SHA (auto-detected from git)")
    prov_group.add_argument("--branch", metavar="NAME", help="Override git branch (auto-detected from git or CI env)")
    prov_group.add_argument("--tag", metavar="TAG", help="Override git tag (auto-detected from git)")
    prov_group.add_argument(
        "--image-tag",
        metavar="TAG",
        dest="image_tag",
        help="Container image tag (e.g. ghcr.io/acme/app:v1.2.3)",
    )
    prov_group.add_argument(
        "--image-digest",
        metavar="DIGEST",
        dest="image_digest",
        help="Container image digest (e.g. sha256:abc123...)",
    )

    # RADR manifest compilation
    scan_parser.add_argument(
        "--radr", action="store_true", help="Compile RADR manifest after scan (creates radr-manifest.json)"
    )

    # ==========================================================================
    # dashboard - Generate or access scan dashboard
    # ==========================================================================
    dashboard_parser = subparsers.add_parser(
        "dashboard",
        help="Generate or access scan dashboard",
        description="Generate dashboard from scan results or get path for CI/CD artifacts",
    )
    dashboard_parser.add_argument("--repo", "-r", metavar="NAME", help="Repository name (fuzzy match) or path")
    dashboard_parser.add_argument(
        "--generate", "-g", action="store_true", help="Regenerate dashboard from scan results"
    )
    dashboard_parser.add_argument("--output", "-o", metavar="DIR", help="Output directory for generated dashboard")
    dashboard_parser.add_argument(
        "--path", "-p", action="store_true", help="Print dashboard path only (for CI/CD artifacts)"
    )
    dashboard_parser.add_argument("--open", action="store_true", help="Open dashboard in browser")
    dashboard_parser.add_argument("--list", "-l", action="store_true", help="List all available dashboards")

    # ==========================================================================
    # selftest - Run all validation tests
    # ==========================================================================
    selftest_parser = subparsers.add_parser(
        "selftest",
        help="Verify installation (quick check by default)",
        description="""Verify REACHABLE installation and run test suites.

By default runs a quick sanity check (no pytest needed, ships in wheel).
Use --unit, --integration, or --full for developer test suites (require source checkout + pytest).""",
    )
    selftest_parser.add_argument(
        "--full",
        "-f",
        action="store_true",
        help="Run ALL tests: unit + integration (dev only, requires pytest)",
    )
    selftest_parser.add_argument(
        "--unit", "-u", action="store_true", help="Run unit tests only (dev only, requires pytest)"
    )
    selftest_parser.add_argument(
        "--integration",
        "-i",
        action="store_true",
        help="Run integration tests only (dev only, requires pytest + testbed)",
    )
    selftest_parser.add_argument(
        "--coverage",
        "-c",
        action="store_true",
        help="Run with coverage report (combine with --unit or --full)",
    )
    selftest_parser.add_argument("--quiet", "-q", action="store_true", help="Minimal output")
    selftest_parser.add_argument("--quick", action="store_true", help="Quick check (default, kept for backward compat)")
    selftest_parser.add_argument(
        "--cicd",
        action="store_true",
        help="Simulate CI/CD pipeline end-to-end: fixture scan, SARIF validation, exit codes",
    )

    # ==========================================================================
    # doctor - System health check
    # ==========================================================================
    doctor_parser = subparsers.add_parser(
        "doctor",
        help="Check system dependencies and configuration",
        description="Verify all required and optional tools are available",
    )
    doctor_parser.add_argument("--no-fix", action="store_true", help="Check only, do not auto-install missing tools")
    doctor_parser.add_argument(
        "--full", action="store_true", help="Install optional tools (TruffleHog, Joern) without prompting"
    )

    # ==========================================================================
    # cleanup - Emergency maintenance (USER-FACING)
    # ==========================================================================
    cache_parser = subparsers.add_parser(
        "cache",
        help="Manage Semgrep and scan caches (advanced)",
        description="View, clear, or warm up REACHABLE caches",
    )
    cache_group = cache_parser.add_mutually_exclusive_group(required=False)  # Default to --status
    cache_group.add_argument("--status", action="store_true", help="Show cache usage and sizes (default)")
    cache_group.add_argument("--clear", action="store_true", help="Clear all caches")
    cache_group.add_argument("--clear-libs", action="store_true", help="Clear library cache only")
    cache_group.add_argument(
        "--clear-semgrep", action="store_true", help="Clear Semgrep result caches (per-repo SHA caches)"
    )
    cache_group.add_argument("--warm", action="store_true", help="Pre-warm caches for faster scans")
    cache_parser.add_argument(
        "--repo", "-r", metavar="NAME", help="Repository name (fuzzy match) - for --clear-semgrep"
    )
    cache_parser.add_argument("--force", "-f", action="store_true", help="Skip confirmation prompts")

    # ==========================================================================
    # db - Database management (v4.5.8)
    # ==========================================================================
    db_parser = subparsers.add_parser(
        "db",
        help="View, compact, and repair databases (advanced)",
        description="View status, compact, trim, or repair databases",
    )
    db_parser.add_argument("--repo", "-r", metavar="NAME", help="Repository name (fuzzy match) - default: all repos")
    db_group = db_parser.add_mutually_exclusive_group(required=False)  # Default to --status
    db_group.add_argument("--status", action="store_true", help="Show database status: sizes, WAL, bloat (default)")
    db_group.add_argument(
        "--compact", action="store_true", help="Compact databases: checkpoint WAL + VACUUM INTO if needed"
    )
    db_group.add_argument("--checkpoint", action="store_true", help="Checkpoint WAL only (fast, no vacuum)")
    db_group.add_argument("--check", action="store_true", help="Check database integrity")
    db_group.add_argument("--repair", action="store_true", help="Attempt to repair corrupted database")
    db_group.add_argument("--trim", action="store_true", help="Trim old scans (30 days / 20 per branch)")
    db_group.add_argument("--optimize", action="store_true", help="[DEPRECATED] Use --compact instead")
    db_parser.add_argument("--force", action="store_true", help="Force vacuum even if low bloat")
    db_parser.add_argument("--dry-run", action="store_true", help="Show what would be done without doing it")
    db_parser.add_argument("--verbose", "-v", action="store_true", help="Show detailed information")

    # ==========================================================================
    # primer - Quick-start guide
    # ==========================================================================
    subparsers.add_parser(
        "primer",
        help="Quick-start guide for new and advanced users",
        description="Paged reference: what REACHABLE does, first-scan basics, and advanced tuning",
    )

    # ==========================================================================
    # sandbox - Dynamic malware sandbox management
    # ==========================================================================
    sandbox_parser = subparsers.add_parser(
        "sandbox",
        help="Manage dynamic malware sandbox",
        description="Install, remove, or check status of the dynamic malware sandbox (Colima on macOS)",
    )
    sandbox_group = sandbox_parser.add_mutually_exclusive_group(required=False)  # Default to --status
    sandbox_group.add_argument("--init", action="store_true", help="Install sandbox (Colima on macOS)")
    sandbox_group.add_argument("--remove", action="store_true", help="Remove sandbox")
    sandbox_group.add_argument("--status", action="store_true", help="Check sandbox status (default)")

    # ==========================================================================
    # vulndb - Vulnerability database management
    # ==========================================================================
    vulndb_parser = subparsers.add_parser(
        "vulndb",
        help="Manage grype vulnerability database",
        description="View status, update, or clear the grype CVE database cache",
    )
    vulndb_group = vulndb_parser.add_mutually_exclusive_group(required=False)  # Default to --status
    vulndb_group.add_argument("--status", action="store_true", help="Show vulnerability DB status (default)")
    vulndb_group.add_argument("--update", action="store_true", help="Force refresh the vulnerability database")
    vulndb_group.add_argument("--reset", action="store_true", help="Delete and rebuild the database from scratch")

    # ==========================================================================
    # manifest - RADR manifest operations (v5.6)
    # ==========================================================================
    setup_manifest_parser(subparsers)

    # ==========================================================================
    # pipeline - Distributed CI/CD execution
    # ==========================================================================
    from reachable.cli.pipeline import setup_pipeline_parser

    setup_pipeline_parser(subparsers)

    # ==========================================================================
    # system - System info, storage management, cleanup
    # ==========================================================================
    system_parser = subparsers.add_parser(
        "system",
        help="Storage usage and system diagnostics (advanced)",
        description="View storage usage, manage caches, and prune old data",
    )
    system_parser.add_argument(
        "action",
        nargs="?",
        default="info",
        choices=["info", "df", "prune"],
        help="info: show system info (default), df: disk usage breakdown, prune: clean up old data",
    )
    system_parser.add_argument("--verbose", "-v", action="store_true", help="Show detailed information")
    system_parser.add_argument("--json", action="store_true", help="Output in JSON format")
    system_parser.add_argument(
        "--dry-run", action="store_true", help="Show what would be deleted without actually deleting"
    )
    system_parser.add_argument("--max-age", type=int, default=21, help="Delete scans older than N days (default: 21)")
    system_parser.add_argument("--max-scans", type=int, default=20, help="Keep only N scans per branch (default: 20)")

    # ==========================================================================
    # config - Configuration management
    # ==========================================================================
    config_parser = subparsers.add_parser(
        "config",
        help="Manage REACHABLE configuration",
        description="Configure auto-maintenance and other settings",
    )
    config_parser.add_argument(
        "config_action",
        nargs="?",
        default="status",
        choices=["status", "get", "set", "enable", "disable", "reset"],
        help="Action: status (default), get, set, enable, disable, reset",
    )
    config_parser.add_argument("key", nargs="?", help="Config key (for get/set)")
    config_parser.add_argument("value", nargs="?", help="Config value (for set)")

    # ==========================================================================
    # cleanup - Emergency maintenance
    # ==========================================================================
    cleanup_parser = subparsers.add_parser(
        "cleanup",
        help="Emergency cleanup: compact DBs and prune old scans",
        description="Run maintenance tasks to fix stuck systems",
    )
    cleanup_parser.add_argument("--dry-run", action="store_true", help="Preview what would be removed")
    cleanup_parser.add_argument("--force", action="store_true", help="Force vacuum even if bloat is low")

    # ==========================================================================
    # trends - View historical security trends (FUTURE)
    # ==========================================================================
    # NOTE: Trends command parser defined but handler not yet implemented
    # trends_parser = subparsers.add_parser(
    #     'trends',
    #     help='View historical security trends',
    #     description='Display security metrics over time (survives scan pruning)'
    # )
    # trends_parser.add_argument('--repo', '-r', metavar='NAME',
    #                            help='Repository name (fuzzy match)')
    # trends_parser.add_argument('--days', '-d', type=int, default=30,
    #                            help='Number of days to show (default: 30)')
    # trends_parser.add_argument('--branch', '-b',
    #                            help='Specific branch (default: all)')
    # trends_parser.add_argument('--type', choices=['all', 'cve', 'secret', 'cwe', 'ai', 'dlp'],
    #                            default='all',
    #                            help='Finding type to show (default: all)')
    # trends_parser.add_argument('--json', action='store_true',
    #                            help='Output in JSON format')

    # ==========================================================================
    # version - Show version
    # ==========================================================================
    version_parser = subparsers.add_parser(
        "version",
        help="Show version and tool information",
        description="Display REACHABLE version, tool paths, and installation info",
    )
    version_parser.add_argument("--wheel", "-w", action="store_true", help="Show wheel package verification info")

    # ==========================================================================
    # top10size - Repo file distribution diagnostic
    # ==========================================================================
    top10_parser = subparsers.add_parser(
        "top10size",
        help="Show top-level directory file counts (scan performance diagnostic)",
        description="Show which directories contain the most files.\n"
        "Use this to understand why scans are slow — if venv/ or "
        "node_modules/ dominates, your semgrep-exclude.txt may need updating.",
    )
    top10_parser.add_argument("path", nargs="?", default=".", help="Repository path (default: current directory)")
    top10_parser.add_argument("-n", "--top", type=int, default=10, help="Number of directories to show (default: 10)")
    top10_parser.add_argument("--all", action="store_true", help="Show all directories, not just top N")

    # ==========================================================================
    # license - License management
    # ==========================================================================
    license_parser = subparsers.add_parser(
        "license", help="View, verify, or install a license", description="Manage your REACHABLE license"
    )
    license_subparsers = license_parser.add_subparsers(dest="license_action", metavar="ACTION")
    license_subparsers.add_parser("show", help="Show current license details (default)")
    license_subparsers.add_parser("verify", help="Verify license validity and exit")
    lic_install = license_subparsers.add_parser("install", help="Install a license file")
    lic_install.add_argument("license_file", metavar="FILE", help="Path to license.json")

    # Admin command (hidden)
    admin_parser = subparsers.add_parser(
        "admin",
        help="Admin utilities (advanced)",
        description="Internal admin tools: network config, diagnostics",
    )
    admin_parser.add_argument("admin_args", nargs=argparse.REMAINDER, help=argparse.SUPPRESS)

    # Audit command
    audit_parser = subparsers.add_parser(
        "audit",
        help="Audit scan metrics and data integrity",
        description="Validate data consistency: raw JSON vs database vs dashboard",
    )
    audit_parser.add_argument("--scan-path", help="Scan directory")

    # ==========================================================================
    # registries - Private registry configuration
    # ==========================================================================
    from reachable.cli.registries import add_registries_parser

    add_registries_parser(subparsers)

    # ==========================================================================
    # aliases - Unresolved package management (Phase 5)
    # ==========================================================================
    from reachable.cli.aliases import add_aliases_parser

    add_aliases_parser(subparsers)

    # v5.1.3: Export command (DB as single source of truth)
    from reachable.cli.export import register_export_command

    register_export_command(subparsers)

    # ==========================================================================
    # auth - Credential management
    # ==========================================================================
    from reachable.cli.auth import setup_auth_parser

    setup_auth_parser(subparsers)

    # ==========================================================================
    # enzo - AI-powered remediation engine
    # ==========================================================================
    try:
        from enzo.cli import register_enzo_subcommand

        register_enzo_subcommand(subparsers)
    except ImportError:
        pass  # Enzo not installed / not available in this distribution

    # Parse arguments
    args = parser.parse_args()

    # Setup logger based on debug flag, timestamp preference, and command type
    # Non-scan commands always get clean output (no INFO prefix)
    debug_mode = getattr(args, "debug", False)
    no_timestamps = getattr(args, "no_timestamps", False)
    setup_logger(debug=debug_mode, no_timestamps=no_timestamps, command_type=args.command)

    # Handle --version flag at top level
    if getattr(args, "version", False) and args.command is None:
        print_version()
        sys.exit(0)

    # No command specified
    if not args.command:
        parser.print_help()
        sys.exit(1)

    # Check license before running any command (except license/version/doctor)
    if args.command not in ("license", "version", "doctor", "selftest", "auth", "primer"):
        try:
            from reachable.licensing.verifier import check as _license_check

            _state = _license_check()
            if not _state.valid:
                print(f"\n⛔ {_state.error}\n")
                if _state.status == "expired":
                    print("   Run: reachctl license install <license.json>")
                sys.exit(1)
            # Print license banner (suppress in quiet mode)
            if not getattr(args, "quiet", False):
                pass  # Banner printed by scan_log.scan_start() in scan.py
        except ImportError:
            pass  # License module not yet available (dev mode)

    # Route to command handlers
    if args.command == "scan":
        scan_repo(args)
    elif args.command == "dashboard":
        open_dashboard(args)
    elif args.command == "selftest":
        selftest(args)
    elif args.command == "doctor":
        admin_doctor(args)
    elif args.command == "cache":
        # Map to existing admin_cache function
        admin_cache(args)
    elif args.command == "db":
        admin_db(args)
    elif args.command == "sandbox":
        sandbox_command(args)
    elif args.command == "vulndb":
        vulndb_command(args)
    elif args.command == "system":
        system_command(args)
    elif args.command == "manifest":
        sys.exit(manifest_command(args) or 0)
    elif args.command == "pipeline":
        from reachable.cli.pipeline import pipeline_command

        sys.exit(pipeline_command(args))
    elif args.command == "primer":
        show_primer(args)
    elif args.command == "version":
        print_version(args)
    elif args.command == "admin":
        from reachable.cli.admin_ext import network_config_command

        subcmd = args.admin_args[0] if args.admin_args else None
        if subcmd == "network-config":
            sys.exit(network_config_command())
        else:
            logger.info("Usage: reachctl admin network-config")
            sys.exit(1)
    elif args.command == "config":
        config_command(args)
    elif args.command == "cleanup":
        cleanup_command(args)

    elif args.command == "top10size":
        top10size_command(args)
    elif args.command == "audit":
        sys.exit(audit_command(args))
    elif args.command == "license":
        from reachable.cli.license import license_command

        license_command(args)
    elif args.command == "export":
        from reachable.cli.export import run_export

        run_export(args)
    elif args.command == "registries":
        from reachable.cli.registries import registries_command

        registries_command(args)
    elif args.command == "aliases":
        from reachable.cli.aliases import aliases_command

        aliases_command(args)
    elif args.command == "enzo":
        # Enzo delegates to its own subparser; argparse already bound func via set_defaults
        if hasattr(args, "func"):
            args.func(args)
        else:
            # No enzo subcommand given — print enzo help
            parser.parse_args(["enzo", "--help"])
    elif args.command == "auth":
        from reachable.cli.auth import auth_command

        auth_command(args)
    else:
        parser.print_help()
        sys.exit(1)
