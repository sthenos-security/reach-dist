#!/usr/bin/env python3
# Copyright (c) 2026 Sthenos Security. All rights reserved.

"""
REACHABLE v5.1.3 - reachctl export command

One canonical format: v2 payload (schema_version: 2.0).
Client exports from repo.db. Server exports from reachable.db (D1).
Same shape, different source — enables data quality diffing.

IMPORTANT: --repo vs --repo-uri
-------------------------------
--repo      Path to the LOCAL repository you want to export.
            Used to locate repo.db:
              ~/.reachable/scans/{slug}/repo.db
            Default is "." (current directory).

--repo-uri  OPTIONAL. The GitHub/GitLab HTTPS URL of the repository.
            Only used as metadata inside SARIF output so GitHub Code
            Scanning can link findings back to the correct repo.
            Does NOT affect which database is read.
            Auto-detected from GITHUB_REPOSITORY / CI_PROJECT_URL env vars
            when running in CI — usually safe to omit.

Usage:
    # Export latest scan from current repo (run from repo root)
    reachctl export                              # v2 JSON to stdout
    reachctl export --format json                # v2 JSON (default)
    reachctl export --format csv                 # Flat CSV
    reachctl export --format summary             # Human-readable text

    # Export a specific repo by path
    reachctl export --repo ~/src/myapp
    reachctl export --repo ~/src/myapp --format summary
    reachctl export --repo ~/src/myapp --scan-id 47

    # SARIF for GitHub Code Scanning
    # --repo  = where to find the DB
    # --repo-uri = GitHub URL embedded in the SARIF (optional metadata)
    reachctl export --repo ~/src/myapp --format sarif
    reachctl export --repo ~/src/myapp --format sarif --output results.sarif
    reachctl export --repo ~/src/myapp --format sarif \
        --repo-uri https://github.com/org/myapp \
        --output results.sarif

    # Generate a GitHub Actions workflow file
    reachctl export --format github-action --output .github/workflows/reachable.yml
    reachctl export --format github-action --fail-on high --branch main \
        --output .github/workflows/reachable.yml
"""

from __future__ import annotations

import csv
import io
import json
import logging
import sys
from datetime import datetime
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from reachable.database.storage import RepoDatabase

logger = logging.getLogger(__name__)


def register_export_command(subparsers):
    """Register the 'export' subcommand with argparse."""
    parser = subparsers.add_parser(
        "export",
        help="Export scan findings from database",
        description="Query repo.db and produce output in v2 payload format.",
    )
    parser.add_argument(
        "--format",
        "-f",
        choices=["json", "csv", "summary", "sarif", "github-action"],
        default="json",
        help="Output format: json (default), csv, summary, sarif, github-action",
    )
    parser.add_argument("--scan-id", "-s", type=int, default=None, help="Specific scan ID (default: latest)")
    parser.add_argument("--output", "-o", type=str, default=None, help="Output file path (default: stdout)")
    parser.add_argument("--repo", "-r", type=str, default=".", help="Repository path (for finding repo.db)")
    parser.add_argument(
        "--repo-uri",
        type=str,
        default=None,
        help="Repository URI for SARIF versionControlProvenance "
             "(e.g. https://github.com/org/repo). Auto-detected from "
             "GITHUB_REPOSITORY / CI_PROJECT_URL env vars when not set.",
    )
    # GitHub Actions workflow generation options (--format github-action)
    parser.add_argument(
        "--fail-on",
        choices=["critical", "high", "medium", "any", "none"],
        default="high",
        help="CI gate threshold for --format github-action (default: high)",
    )
    parser.add_argument(
        "--branch",
        type=str,
        default="main",
        help="Branch to trigger the workflow on (default: main)",
    )
    parser.add_argument(
        "--python-version",
        type=str,
        default="3.11",
        choices=["3.9", "3.10", "3.11", "3.12", "3.13"],
        help="Python version for the setup-python step (default: 3.11)",
    )
    parser.add_argument(
        "--reachable-version",
        type=str,
        default=None,
        help="Pin to a specific reachable version (e.g. 1.4.2). Omit for latest.",
    )
    parser.add_argument(
        "--force",
        action="store_true",
        default=False,
        help="Overwrite existing output file (for --format github-action)",
    )
    parser.set_defaults(func=run_export)


def run_export(args):
    """Execute the export command."""
    from reachable.database.storage import RepoDatabase, get_repo_db_path

    repo_path = Path(args.repo).resolve()
    db_path = get_repo_db_path(repo_path)

    if not db_path.exists():
        print(f"Error: No database found for {repo_path}", file=sys.stderr)
        print(f"Expected: {db_path}", file=sys.stderr)
        sys.exit(1)

    db = RepoDatabase(db_path)

    # Determine scan_id
    scan_id = args.scan_id
    if scan_id is None:
        cursor = db.conn.execute("SELECT id FROM scans WHERE status='complete' ORDER BY id DESC LIMIT 1")
        row = cursor.fetchone()
        if not row:
            print("Error: No completed scans found", file=sys.stderr)
            sys.exit(1)
        scan_id = row["id"]

    if args.format == "json":
        output = export_json(db, scan_id)
    elif args.format == "csv":
        output = export_csv(db, scan_id)
    elif args.format == "summary":
        output = export_summary(db, scan_id)
    elif args.format == "sarif":
        output = export_sarif(db, scan_id, repo_uri=getattr(args, "repo_uri", None))
    elif args.format == "github-action":
        export_github_action(args)
        return  # github-action writes directly, no further output handling needed
    else:
        print(f"Error: Unknown format '{args.format}'", file=sys.stderr)
        sys.exit(1)

    # Write output
    if args.output:
        output_path = Path(args.output)
        with open(output_path, "w") as f:
            f.write(output)
        print(f"Exported scan {scan_id} ({args.format}) to {output_path}", file=sys.stderr)
    else:
        print(output)

    db.close()


# ==========================================================================
# EXPORTERS
# ==========================================================================


def export_json(db: "RepoDatabase", scan_id: int) -> str:
    """
    Export as v2 payload (schema_version: 2.0).

    Same shape as server-side GET /repos/:id/report.
    Client source: repo.db, server source: reachable.db.
    Diff the two to verify ingest data quality.
    """
    cursor = db.conn.cursor()

    scan_row = cursor.execute("SELECT * FROM scans WHERE id = ?", (scan_id,)).fetchone()
    if not scan_row:
        return json.dumps({"error": f"Scan {scan_id} not found"})
    scan = dict(scan_row)

    findings_rows = cursor.execute(
        "SELECT * FROM findings WHERE scan_id = ? ORDER BY severity, finding_type", (scan_id,)
    ).fetchall()

    ai_rows = cursor.execute("SELECT * FROM ai_findings WHERE scan_id = ?", (scan_id,)).fetchall()

    dlp_rows = cursor.execute("SELECT * FROM dlp_findings WHERE scan_id = ?", (scan_id,)).fetchall()

    audit_rows = []
    try:
        audit_rows = cursor.execute("SELECT * FROM scan_audit WHERE scan_id = ?", (scan_id,)).fetchall()
    except Exception:
        pass  # scan_audit may not exist in older DBs

    # Map findings to v2 payload shape
    findings = []
    for f in findings_rows:
        d = dict(f)
        entry = {
            "finding_type": d.get("finding_type"),
            "finding_id": d.get("finding_id"),
            "severity": d.get("severity"),
            "reachability_state": d.get("app_reachability", d.get("reachability_state", "UNKNOWN")),
            "reachability_confidence": d.get("reachability_confidence", "LOW"),
        }
        # Optional fields — only include if present
        for key in (
            "type_detail",
            "risk_level",
            "cvss_score",
            "platform_exposure",
            "fix_status",
            "fix_version",
            "file_path",
            "line_number",
            "package_name",
            "package_version",
            "title",
            "description",
            "cwe_id",
            "secret_type",
            "ghsa_id",
            "display_id",
            "scanner",
            "compliance_frameworks",
        ):
            val = d.get(key)
            if val is not None and val != "":
                # Parse JSON fields
                if key in ("compliance_frameworks",) and isinstance(val, str):
                    try:
                        val = json.loads(val)
                    except (json.JSONDecodeError, TypeError):
                        pass
                entry[key] = val
        # Reachability path
        rpath = d.get("call_paths_v2", [[]])[0] if d.get("call_paths_v2") else (d.get("reachability_path") or [])
        if rpath:
            if isinstance(rpath, str):
                try:
                    rpath = json.loads(rpath)
                except (json.JSONDecodeError, TypeError):
                    pass
            entry["reachability_path"] = rpath
        findings.append(entry)

    ai_findings = []
    for f in ai_rows:
        d = dict(f)
        entry = {"severity": d.get("severity")}
        for key in (
            "rule_id",
            "policy_id",
            "owasp_category",
            "owasp_name",
            "base_risk_score",
            "adjusted_risk_score",
            "guard_risk_reduction",
            "file_path",
            "line_start",
            "line_end",
            "message",
            "framework",
            "provider",
            "detection_source",
        ):
            val = d.get(key)
            if val is not None and val != "":
                entry[key] = val
        entry["is_reachable"] = bool(d.get("is_reachable"))
        for jkey in ("call_paths_v2", "guards"):
            val = d.get(jkey)
            if val:
                if isinstance(val, str):
                    try:
                        val = json.loads(val)
                    except (json.JSONDecodeError, TypeError):
                        pass
                entry[jkey] = val
        ai_findings.append(entry)

    dlp_findings = []
    for f in dlp_rows:
        d = dict(f)
        entry = {"severity": d.get("severity")}
        for key in (
            "rule_id",
            "finding_type",
            "pii_type",
            "pii_count",
            "sink_type",
            "sink_function",
            "base_risk_score",
            "adjusted_risk_score",
            "reachability_confidence",
            "sanitizer_type",
            "sanitizer_effectiveness",
            "file_path",
            "line_start",
            "line_end",
            "message",
            "remediation",
            "detection_source",
            "confidence",
        ):
            val = d.get(key)
            if val is not None and val != "":
                entry[key] = val
        entry["is_reachable"] = bool(d.get("is_reachable"))
        entry["sanitizer_present"] = bool(d.get("sanitizer_present"))
        for jkey in ("call_paths_v2", "regulations"):
            val = d.get(jkey)
            if val:
                if isinstance(val, str):
                    try:
                        val = json.loads(val)
                    except (json.JSONDecodeError, TypeError):
                        pass
                entry[jkey] = val
        dlp_findings.append(entry)

    scan_audit = []
    for a in audit_rows:
        d = dict(a)
        scan_audit.append(
            {
                "finding_type": d.get("finding_type"),
                "cli_count": d.get("cli_count", 0),
                "db_count": d.get("db_count", 0),
                "loss_count": d.get("loss_count", 0),
                "loss_percentage": d.get("loss_percentage", 0),
            }
        )

    report = {
        "schema_version": "2.0",
        "source": "repo.db",
        "generated_at": datetime.utcnow().isoformat() + "Z",
        "repo": scan.get("repo") or scan.get("repository", "unknown"),
        "scan": {
            "id": scan_id,
            "branch": scan.get("branch"),
            "commit_hash": scan.get("commit_hash"),
            "commit_message": scan.get("commit_message"),
            "risk_score": scan.get("risk_score"),
            "risk_level": scan.get("risk_level"),
            "total_findings": scan.get("total_findings", len(findings)),
            "reachable_findings": scan.get("reachable_findings", 0),
            "cves_total": scan.get("cves_total", 0),
            "cves_reachable": scan.get("cves_reachable", 0),
            "cves_critical": scan.get("cves_critical", 0),
            "secrets_total": scan.get("secrets_total", 0),
            "secrets_reachable": scan.get("secrets_reachable", 0),
            "cwe_total": scan.get("cwe_total", 0),
            "cwe_reachable": scan.get("cwe_reachable", 0),
            "malware_total": scan.get("malware_total", 0),
            "ai_total": scan.get("ai_total", 0),
            "ai_reachable": scan.get("ai_reachable", 0),
            "dlp_total": scan.get("dlp_total", 0),
            "dlp_reachable": scan.get("dlp_reachable", 0),
            "config_count": scan.get("config_count", 0),
            "unknown_count": scan.get("unknown_count", 0),
            "source_files_scanned": scan.get("source_files_scanned", 0),
            "duration_seconds": scan.get("duration_seconds"),
            "scanner_version": scan.get("version") or scan.get("scanner_version"),
            "scanned_at": scan.get("timestamp") or scan.get("scanned_at"),
        },
        "findings": findings,
    }
    # Only include non-empty optional sections
    if ai_findings:
        report["ai_findings"] = ai_findings
    if dlp_findings:
        report["dlp_findings"] = dlp_findings
    if scan_audit:
        report["scan_audit"] = scan_audit

    return json.dumps(report, indent=2, default=str)


def export_csv(db: "RepoDatabase", scan_id: int) -> str:
    """Export findings as flat CSV."""
    cursor = db.conn.cursor()

    findings = cursor.execute(
        "SELECT * FROM findings WHERE scan_id = ? ORDER BY severity, finding_type", (scan_id,)
    ).fetchall()

    if not findings:
        return "No findings found\n"

    output = io.StringIO()
    writer = csv.writer(output)

    # Header
    columns = [
        "finding_type",
        "finding_id",
        "severity",
        "risk_level",
        "app_reachability",
        "package_name",
        "package_version",
        "title",
        "file_path",
        "line_number",
        "cwe_id",
        "fix_status",
        "fix_version",
        "scanner",
    ]
    writer.writerow(columns)

    for f in findings:
        f_dict = dict(f)
        writer.writerow([f_dict.get(col, "") for col in columns])

    return output.getvalue()


def export_summary(db: "RepoDatabase", scan_id: int) -> str:
    """Export human-readable summary."""
    cursor = db.conn.cursor()

    scan_row = cursor.execute("SELECT * FROM scans WHERE id = ?", (scan_id,)).fetchone()

    if not scan_row:
        return f"Scan {scan_id} not found\n"
    scan = dict(scan_row)

    # Counts by type
    type_counts = cursor.execute(
        """
        SELECT finding_type, COUNT(*) as count,
               SUM(CASE WHEN app_reachability = 'REACHABLE' THEN 1 ELSE 0 END) as reachable
        FROM findings WHERE scan_id = ?
        GROUP BY finding_type
    """,
        (scan_id,),
    ).fetchall()

    lines = [
        f"REACHABLE Scan #{scan_id}",
        f"  Branch: {scan['branch']}",
        f"  Commit: {scan['commit_short'] or 'unknown'}",
        f"  Risk:   {scan['risk_level']} (score: {scan['risk_score']})",
        f"  Status: {scan['status']}",
        "",
        "Findings:",
    ]

    for row in type_counts:
        lines.append(f"  {row['finding_type']:12s}  {row['count']:4d} total  {row['reachable']:4d} reachable")

    lines.append(f"\n  TOTAL: {scan['total_findings'] or 0} findings")

    return "\n".join(lines) + "\n"


def export_sarif(db: "RepoDatabase", scan_id: int, repo_uri: str = None) -> str:
    """
    Export findings as SARIF 2.1.0.

    Builds the same dashboard data dict that loaders.py produces, then
    delegates to the canonical sarif exporter.  Auto-detects repo URI from
    GitHub Actions / GitLab / Azure DevOps environment variables when
    ``repo_uri`` is not passed explicitly.

    GitHub usage (upload to Code Scanning):
        reachctl export --format sarif --output results.sarif
        # Then in the Actions step:
        # uses: github/codeql-action/upload-sarif@v3
        # with: { sarif_file: results.sarif }
    """
    import os

    cursor = db.conn.cursor()

    # ── Resolve repo_uri from env if not passed ─────────────────────────────
    if not repo_uri:
        gh_repo = os.environ.get("GITHUB_REPOSITORY")
        gh_server = os.environ.get("GITHUB_SERVER_URL", "https://github.com")
        if gh_repo:
            repo_uri = f"{gh_server}/{gh_repo}"
        elif os.environ.get("CI_PROJECT_URL"):
            repo_uri = os.environ["CI_PROJECT_URL"]
        elif os.environ.get("BUILD_REPOSITORY_URI"):
            repo_uri = os.environ["BUILD_REPOSITORY_URI"]

    # ── Load scan metadata ───────────────────────────────────────────────────
    scan_row = cursor.execute("SELECT * FROM scans WHERE id = ?", (scan_id,)).fetchone()
    if not scan_row:
        return json.dumps({"error": f"Scan {scan_id} not found"})
    scan = dict(scan_row)

    # ── Load all findings into dashboard-shaped dict ─────────────────────────
    from reachable.dashboard_v2 import loaders as _loaders

    try:
        data = _loaders.load_from_database(db.db_path)
    except Exception:
        # Fallback: build minimal data dict from raw DB rows so the SARIF
        # exporter always has something to work with even if loaders fails.
        findings_rows = cursor.execute(
            "SELECT * FROM findings WHERE scan_id = ? ORDER BY severity", (scan_id,)
        ).fetchall()
        issues = []
        for f in findings_rows:
            d = dict(f)
            issues.append({
                "id": d.get("finding_id") or d.get("display_id"),
                "type": d.get("finding_type", "").upper(),
                "severity": d.get("severity", "MEDIUM"),
                "reachability_state": (d.get("app_reachability") or "unknown").lower(),
                "reachability_confidence": d.get("reachability_confidence"),
                "package": d.get("package_name"),
                "version": d.get("package_version"),
                "file_path": d.get("file_path"),
                "line": d.get("line_number"),
                "title": d.get("title"),
                "description": d.get("description"),
                "fix_version": d.get("fix_version"),
                "cvss_score": d.get("cvss_score"),
                "is_transitive": bool(d.get("is_transitive")),
                "via_package": d.get("via_package"),
                "is_kev": bool(d.get("is_kev")),
                "epss_score": d.get("epss_score"),
            })
        data = {
            "issues": issues,
            "scan": {
                "branch": scan.get("branch") or os.environ.get("GITHUB_REF_NAME", ""),
                "commit": scan.get("commit_hash") or os.environ.get("GITHUB_SHA", ""),
                "scan_timing": {
                    "start_timestamp": scan.get("created_at", ""),
                    "end_timestamp": scan.get("updated_at", ""),
                },
                "languages": [],
            },
            "version": scan.get("version", ""),
        }

    # Backfill branch/commit from CI env when DB doesn't have them
    scan_meta = data.setdefault("scan", {})
    if not scan_meta.get("branch"):
        scan_meta["branch"] = (
            os.environ.get("GITHUB_REF_NAME")
            or os.environ.get("CI_COMMIT_REF_NAME")
            or os.environ.get("BUILD_SOURCEBRANCHNAME", "")
        )
    if not scan_meta.get("commit"):
        scan_meta["commit"] = (
            os.environ.get("GITHUB_SHA")
            or os.environ.get("CI_COMMIT_SHA")
            or os.environ.get("BUILD_SOURCEVERSION", "")
        )

    # ── Export ───────────────────────────────────────────────────────────────
    from reachable.reporting.sarif import export_to_sarif, get_sarif_summary

    sarif_doc = export_to_sarif(data, repo_uri=repo_uri)
    summary = get_sarif_summary(sarif_doc)
    print(
        f"SARIF: {summary['total']} actionable findings "
        f"({summary['by_level'].get('error', 0)} errors, "
        f"{summary['by_level'].get('warning', 0)} warnings, "
        f"{summary['by_level'].get('note', 0)} notes)"
        + (f"  repo: {repo_uri}" if repo_uri else ""),
        file=sys.stderr,
    )
    return json.dumps(sarif_doc, indent=2)


def export_github_action(args) -> None:
    """
    Generate a GitHub Actions workflow YAML and write it to stdout or a file.

    Delegates all rendering to ``reachable.reporting.github_action``.
    Reads args: output, fail_on, branch, python_version, reachable_version, force.
    """
    from reachable.reporting.github_action import (
        generate_workflow,
        print_generation_summary,
        write_workflow,
    )

    fail_on        = getattr(args, "fail_on",           "high")
    branch         = getattr(args, "branch",            "main")
    python_version = getattr(args, "python_version",    "3.11")
    reachable_ver  = getattr(args, "reachable_version", None)
    output         = getattr(args, "output",            None)
    force          = getattr(args, "force",             False)

    try:
        if output:
            from pathlib import Path as _Path
            out_path = write_workflow(
                output_path       = _Path(output),
                fail_on           = fail_on,
                branch            = branch,
                python_version    = python_version,
                reachable_version = reachable_ver,
                overwrite         = force,
            )
            print_generation_summary(out_path, fail_on, branch, python_version)
        else:
            # stdout — useful for piping: reachctl export --format github-action > workflow.yml
            workflow = generate_workflow(
                fail_on           = fail_on,
                branch            = branch,
                python_version    = python_version,
                reachable_version = reachable_ver,
            )
            print(workflow)
            print_generation_summary(None, fail_on, branch, python_version)

    except FileExistsError as exc:
        print(f"Error: {exc}", file=sys.stderr)
        sys.exit(1)
    except (ValueError, FileNotFoundError) as exc:
        print(f"Error: {exc}", file=sys.stderr)
        sys.exit(1)
