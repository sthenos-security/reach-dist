#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.
"""
reachctl registries — manage private registry configuration.

Usage:
    reachctl registries                           show current config
    reachctl registries show [--raw]              show config (--raw: reveal token values)
    reachctl registries init                      auto-detect from env + config files
    reachctl registries test [--ecosystem <eco>]  test connectivity
    reachctl registries set <key> <value>         set a config value (dotted key path)
    reachctl registries alias add <priv> <canon>  add a PURL alias
    reachctl registries alias list                list all aliases
    reachctl registries alias remove <priv>       remove an alias
    reachctl registries namespace add <eco> <pat> add an internal namespace pattern
    reachctl registries namespace list            list all internal namespaces
    reachctl registries namespace remove <eco> <pat>
    reachctl registries path                      print path to registries.yaml
"""

import logging
import os
import sys
import time
from typing import Optional
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen

from reachable.core.registry_config import (
    add_alias,
    add_namespace,
    autodetect_registries,
    format_registries_display,
    get_all_aliases,
    get_internal_namespaces,
    get_registries_path,
    load_registries,
    remove_alias,
    remove_namespace,
    save_registries,
)

logger = logging.getLogger(__name__)

# ─────────────────────────────────────────────────────────────────────────────
# Entry point
# ─────────────────────────────────────────────────────────────────────────────


def registries_command(args=None):
    """
    Main handler for `reachctl registries`.  Dispatches to sub-commands.
    """
    subcmd = getattr(args, "registries_subcmd", None) or "show"

    dispatch = {
        "show": _cmd_show,
        "init": _cmd_init,
        "test": _cmd_test,
        "set": _cmd_set,
        "alias": _cmd_alias,
        "namespace": _cmd_namespace,
        "path": _cmd_path,
    }

    handler = dispatch.get(subcmd)
    if handler:
        handler(args)
    else:
        _cmd_show(args)


# ─────────────────────────────────────────────────────────────────────────────
# show
# ─────────────────────────────────────────────────────────────────────────────


def _cmd_show(args=None):
    raw = getattr(args, "raw", False)
    print(format_registries_display(show_raw=raw))


# ─────────────────────────────────────────────────────────────────────────────
# path
# ─────────────────────────────────────────────────────────────────────────────


def _cmd_path(args=None):
    print(get_registries_path())


# ─────────────────────────────────────────────────────────────────────────────
# init — auto-detect
# ─────────────────────────────────────────────────────────────────────────────


def _cmd_init(args=None):
    print("Detecting private registry configuration...")
    print()

    detected = autodetect_registries()
    if not detected:
        print("No private registries detected.")
        print()
        print("Nothing found in:")
        print("  Python  — $PIP_INDEX_URL / $PIP_EXTRA_INDEX_URL / pip.conf")
        print("  npm     — $NPM_CONFIG_REGISTRY / .npmrc")
        print("  Go      — $GOPROXY / $GOPRIVATE / $GONOSUMCHECK")
        print("  Maven   — ~/.m2/settings.xml")
        print()
        print(f"Edit manually: {get_registries_path()}")
        return

    cfg = load_registries()
    regs = cfg.setdefault("registries", {})

    merged = 0
    for eco, eco_cfg in detected.items():
        if eco not in regs:
            regs[eco] = eco_cfg
            merged += 1
            print(f"  ✓ {eco:<8} detected: {next(iter(eco_cfg.values()))}")
        else:
            print(f"  ~ {eco:<8} already configured (skipped)")

    if merged > 0:
        if save_registries(cfg):
            print()
            print(f"Saved {merged} new registry config(s) to {get_registries_path()}")
            print()
            print("Next steps:")
            print("  reachctl registries show          — verify the config")
            print("  reachctl registries test          — check connectivity")
            print()
            print("For internal packages with no upstream CVEs, declare their namespaces:")
            print('  reachctl registries namespace add python "acme-*"')
            print('  reachctl registries namespace add npm "@acme/*"')
            print()
            print("For renamed wrappers of public packages, add aliases:")
            print('  reachctl registries alias add "pkg:pypi/acme-crypto@" "pkg:pypi/cryptography@"')
        else:
            print()
            print("ERROR: Could not write to registries.yaml")
    else:
        print()
        print("All detected registries were already configured.")


# ─────────────────────────────────────────────────────────────────────────────
# test — connectivity
# ─────────────────────────────────────────────────────────────────────────────

_TEST_PROBES = {
    "python": lambda cfg: (cfg.get("index_url", "").rstrip("/") + "/simple/", "GET"),
    "npm": lambda cfg: (cfg.get("registry", "").rstrip("/") + "/-/ping", "GET"),
    "go": lambda cfg: (
        cfg.get("goproxy", "").split(",")[0].rstrip("/") + "/golang.org/x/crypto/@latest",
        "GET",
    ),
    "maven": lambda cfg: None,  # file-based, no network test
}


def _probe_url(url: str, token: Optional[str] = None, timeout: int = 10) -> tuple:
    """Return (status_code, elapsed_ms, error_str)."""
    try:
        headers = {"User-Agent": "reachctl-registries/1.0"}
        if token:
            headers["Authorization"] = f"Bearer {token}"
        req = Request(url, headers=headers)
        t0 = time.monotonic()
        with urlopen(req, timeout=timeout) as resp:
            elapsed = int((time.monotonic() - t0) * 1000)
            return resp.status, elapsed, None
    except HTTPError as e:
        return e.code, 0, str(e)
    except URLError as e:
        return 0, 0, str(e.reason)
    except Exception as e:
        return 0, 0, str(e)


def _cmd_test(args=None):
    from reachable.core.registry_config import get_registry_token

    ecosystem_filter = getattr(args, "ecosystem", None)

    cfg = load_registries()
    regs = cfg.get("registries", {})

    if not regs:
        print("No registries configured. Run: reachctl registries init")
        return

    print("Testing registry connectivity...")
    print()

    ok = 0
    fail = 0

    for eco, rcfg in regs.items():
        if ecosystem_filter and eco != ecosystem_filter:
            continue

        probe_fn = _TEST_PROBES.get(eco)
        if probe_fn is None:
            print(f"  {eco:<8} [no test available]")
            continue

        probe = probe_fn(rcfg)
        if probe is None:
            # Maven: file-based
            settings = rcfg.get("settings_xml", "~/.m2/settings.xml")
            expanded = os.path.expanduser(settings)
            exists = os.path.exists(expanded)
            status = "✓ EXISTS" if exists else "✗ NOT FOUND"
            print(f"  {eco:<8} {settings}  {status}")
            if exists:
                ok += 1
            else:
                fail += 1
            continue

        url, method = probe
        token = get_registry_token(eco)
        status, elapsed, err = _probe_url(url, token=token)

        if err or status >= 400:
            marker = "✗"
            fail += 1
            detail = f"HTTP {status} — {err}" if err else f"HTTP {status}"
        else:
            marker = "✓"
            ok += 1
            detail = f"HTTP {status}  ({elapsed}ms)"
            if token:
                detail += "  Auth: token present"

        print(f"  {eco:<8} {url}")
        print(f"           {marker} {detail}")
        print()

    print(f"Results: {ok}/{ok + fail} reachable", end="")
    if fail:
        print(f", {fail} error(s)")
    else:
        print()


# ─────────────────────────────────────────────────────────────────────────────
# set
# ─────────────────────────────────────────────────────────────────────────────


def _cmd_set(args=None):
    """
    Set a dotted key in registries.yaml.
    e.g.  reachctl registries set python.index_url https://...
    """
    key = getattr(args, "key", None)
    value = getattr(args, "value", None)

    if not key or value is None:
        print("Usage: reachctl registries set <key> <value>")
        print("Example: reachctl registries set python.index_url https://artifactory.company.com/api/pypi/simple")
        sys.exit(1)

    cfg = load_registries()
    parts = key.split(".")
    if len(parts) != 2:
        print("ERROR: key must be <ecosystem>.<field>  (e.g. python.index_url)")
        sys.exit(1)

    eco, field = parts
    cfg.setdefault("registries", {}).setdefault(eco, {})[field] = value

    if save_registries(cfg):
        print(f"Set registries.{eco}.{field} = {value}")
    else:
        print("ERROR: could not save registries.yaml")
        sys.exit(1)


# ─────────────────────────────────────────────────────────────────────────────
# alias
# ─────────────────────────────────────────────────────────────────────────────


def _cmd_alias(args=None):
    sub = getattr(args, "alias_subcmd", "list")

    if sub == "list":
        aliases = get_all_aliases()
        if not aliases:
            print("No aliases configured.")
            return
        print("PACKAGE ALIASES")
        print("─" * 50)
        for priv, canon in aliases.items():
            print(f"  {priv}")
            print(f"      → {canon}")

    elif sub == "add":
        private_prefix = getattr(args, "private_prefix", None)
        canonical_prefix = getattr(args, "canonical_prefix", None)
        if not private_prefix or not canonical_prefix:
            print("Usage: reachctl registries alias add <private_purl_prefix> <canonical_purl_prefix>")
            print('Example: reachctl registries alias add "pkg:pypi/acme-crypto@" "pkg:pypi/cryptography@"')
            sys.exit(1)
        if add_alias(private_prefix, canonical_prefix):
            print(f"Added alias: {private_prefix} → {canonical_prefix}")
        else:
            print("ERROR: could not save alias")
            sys.exit(1)

    elif sub == "remove":
        private_prefix = getattr(args, "private_prefix", None)
        if not private_prefix:
            print("Usage: reachctl registries alias remove <private_purl_prefix>")
            sys.exit(1)
        if remove_alias(private_prefix):
            print(f"Removed alias: {private_prefix}")
        else:
            print(f"Alias not found: {private_prefix}")
            sys.exit(1)


# ─────────────────────────────────────────────────────────────────────────────
# namespace
# ─────────────────────────────────────────────────────────────────────────────


def _cmd_namespace(args=None):
    sub = getattr(args, "namespace_subcmd", "list")

    if sub == "list":
        ns = get_internal_namespaces()
        has_any = any(v for v in ns.values())
        if not has_any:
            print("No internal namespaces configured.")
            print()
            print("Internal namespaces tell REACHABLE which packages are company-internal")
            print("(no upstream CVE equivalent) so it skips CVE hash lookup for them.")
            print()
            print('Example: reachctl registries namespace add python "acme-*"')
            return
        print("INTERNAL NAMESPACES")
        print("─" * 50)
        for eco, patterns in ns.items():
            if patterns:
                print(f"  {eco:<8} {' '.join(patterns)}")

    elif sub == "add":
        eco = getattr(args, "ecosystem", None)
        pattern = getattr(args, "pattern", None)
        if not eco or not pattern:
            print("Usage: reachctl registries namespace add <ecosystem> <pattern>")
            print('Example: reachctl registries namespace add python "acme-*"')
            print('         reachctl registries namespace add npm "@acme/*"')
            print('         reachctl registries namespace add go "go.acme.com/*"')
            sys.exit(1)
        if add_namespace(eco, pattern):
            print(f'Added internal namespace: {eco} "{pattern}"')
            print("Packages matching this pattern will be skipped during CVE lookup.")
        else:
            print("ERROR: could not save namespace")
            sys.exit(1)

    elif sub == "remove":
        eco = getattr(args, "ecosystem", None)
        pattern = getattr(args, "pattern", None)
        if not eco or not pattern:
            print("Usage: reachctl registries namespace remove <ecosystem> <pattern>")
            sys.exit(1)
        if remove_namespace(eco, pattern):
            print(f'Removed internal namespace: {eco} "{pattern}"')
        else:
            print(f'Namespace not found: {eco} "{pattern}"')
            sys.exit(1)


# ─────────────────────────────────────────────────────────────────────────────
# argparse registration helper
# ─────────────────────────────────────────────────────────────────────────────


def add_registries_parser(subparsers):
    """
    Register `reachctl registries` with argparse.

    Call this from cli/main.py where other subcommands are registered.
    """
    p = subparsers.add_parser(
        "registries",
        help="Manage private registry configuration",
        description=__doc__,
    )
    p.set_defaults(func=registries_command)
    sub = p.add_subparsers(dest="registries_subcmd")

    # show
    show_p = sub.add_parser("show", help="Display current config")
    show_p.add_argument("--raw", action="store_true", help="Show token values from environment")

    # init
    sub.add_parser("init", help="Auto-detect from environment and config files")

    # test
    test_p = sub.add_parser("test", help="Test connectivity to configured registries")
    test_p.add_argument("--ecosystem", metavar="ECO", help="Test only this ecosystem (python|npm|go|maven)")

    # path
    sub.add_parser("path", help="Print path to registries.yaml")

    # set
    set_p = sub.add_parser("set", help="Set a registry config value")
    set_p.add_argument("key", help="Dotted key (e.g. python.index_url)")
    set_p.add_argument("value", help="New value")

    # alias
    alias_p = sub.add_parser("alias", help="Manage PURL alias map")
    alias_sub = alias_p.add_subparsers(dest="alias_subcmd")
    alias_sub.add_parser("list", help="List all aliases")
    alias_add_p = alias_sub.add_parser("add", help="Add an alias")
    alias_add_p.add_argument("private_prefix", help="Private PURL prefix")
    alias_add_p.add_argument("canonical_prefix", help="Canonical PURL prefix")
    alias_rm_p = alias_sub.add_parser("remove", help="Remove an alias")
    alias_rm_p.add_argument("private_prefix", help="Private PURL prefix to remove")

    # namespace
    ns_p = sub.add_parser("namespace", help="Manage internal namespace declarations")
    ns_sub = ns_p.add_subparsers(dest="namespace_subcmd")
    ns_sub.add_parser("list", help="List all internal namespaces")
    ns_add_p = ns_sub.add_parser("add", help="Add an internal namespace pattern")
    ns_add_p.add_argument("ecosystem", help="Ecosystem (python|npm|go|maven)")
    ns_add_p.add_argument("pattern", help='Glob pattern (e.g. "acme-*")')
    ns_rm_p = ns_sub.add_parser("remove", help="Remove an internal namespace pattern")
    ns_rm_p.add_argument("ecosystem", help="Ecosystem")
    ns_rm_p.add_argument("pattern", help="Pattern to remove")

    return p


# Allow type annotation for Optional without import at module level on older Python
