#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.
"""CLI sandbox operations: dynamic malware sandbox, Colima/Docker management."""

import json
import os
import platform
import shutil
import subprocess
import sys
import time
from pathlib import Path
from typing import Optional

from reachable.core.logger import get_logger

logger = get_logger()


def run_dynamic_malware_sandbox(
    sbom_file: Path, output_dir: Path, repo_dir: Optional[Path] = None, cache_ttl_hours: int = 24
) -> Optional[dict]:
    """
    Run dynamic malware sandbox analysis on dependencies.

    Platform behavior:
    - macOS: Requires Colima (not Docker Desktop - insecure for malware testing)
    - Linux: Firecracker sandbox (not yet implemented)

    Also detects and tests LOCAL packages with install hooks (e.g. postinstall)
    that wouldn't be caught by GuardDog (which only checks registry packages).

    Static malware analysis (GuardDog) always runs separately.

    Args:
        sbom_file: Path to SBOM JSON file
        output_dir: Output directory for results

    Returns:
        Sandbox results dict or None if sandbox unavailable
    """

    system = platform.system().lower()
    logger.info("    Dynamic Malware Sandbox")
    logger.info(f" Platform: {platform.system()} ({platform.machine()})")

    start_time = time.time()

    # ==========================================================================
    # LINUX: Firecracker sandbox (not yet implemented)
    # ==========================================================================
    if system == "linux":
        logger.info("        Firecracker sandbox not yet implemented on Linux")
        logger.info("       Static malware analysis (GuardDog) still runs")
        logger.info("       Firecracker support planned for v4.7.x")
        return {
            "verdict": "NOT_RUN",
            "reason": "Firecracker sandbox not yet implemented on Linux",
            "platform": "linux",
            "packages_tested": 0,
            "findings": [],
            "static_malware": "enabled",
            "dynamic_malware": "not_implemented",
            "duration_ms": int((time.time() - start_time) * 1000),
        }

    # ==========================================================================
    # macOS: Colima + Docker jail required (Docker Desktop is insecure)
    # ==========================================================================
    if system == "darwin":
        colima_status = _check_colima_status()

        if colima_status == "not_installed":
            logger.info("        Colima not installed - dynamic sandbox skipped")
            logger.info("      ")
            logger.info("      To enable dynamic malware detection, install Colima:")
            logger.info("         brew install colima docker")
            logger.info("         colima start --cpu 2 --memory 4")
            logger.info("      ")
            logger.info("      Alternative (manual):")
            logger.info("         Download from: https://github.com/abiosoft/colima/releases")
            logger.info("      ")
            logger.info("       Static malware analysis (GuardDog) still runs")

            return {
                "verdict": "NOT_RUN",
                "reason": "Colima not installed",
                "platform": "darwin",
                "packages_tested": 0,
                "findings": [],
                "static_malware": "enabled",
                "dynamic_malware": "skipped",
                "install_instructions": "brew install colima docker && colima start",
                "duration_ms": int((time.time() - start_time) * 1000),
            }

        if colima_status == "not_ready":
            # Colima process exists but not fully functional - needs restart
            logger.info("        Colima not ready - try: colima restart")
            logger.info("       Static malware analysis (GuardDog) still runs")
            return {
                "verdict": "NOT_RUN",
                "reason": "Colima not ready - try 'colima restart'",
                "platform": "darwin",
                "packages_tested": 0,
                "findings": [],
                "static_malware": "enabled",
                "dynamic_malware": "skipped",
                "duration_ms": int((time.time() - start_time) * 1000),
            }

        if colima_status == "stopped":
            logger.info("       Starting Colima VM...")
            if not _start_colima():
                logger.info("       Failed to start Colima")
                return {
                    "verdict": "NOT_RUN",
                    "reason": "Failed to start Colima VM",
                    "platform": "darwin",
                    "packages_tested": 0,
                    "findings": [],
                    "static_malware": "enabled",
                    "dynamic_malware": "skipped",
                    "duration_ms": int((time.time() - start_time) * 1000),
                }
            logger.info("       Colima started")
        else:
            # colima_status == 'running' (Colima + Docker both accessible)
            logger.info("       Colima running (secure VM isolation)")

        # Ensure sandbox image exists
        image_result = _ensure_sandbox_image()
        if not image_result:
            # _ensure_sandbox_image already logged the specific error
            return {
                "verdict": "NOT_RUN",
                "reason": "Sandbox Docker image not available",
                "platform": "darwin",
                "packages_tested": 0,
                "findings": [],
                "static_malware": "enabled",
                "dynamic_malware": "skipped",
                "duration_ms": int((time.time() - start_time) * 1000),
            }

        # Run sandbox analysis
        logger.info("       Running behavioral analysis in Colima sandbox...")
        result = _run_colima_sandbox(sbom_file, output_dir, repo_dir=repo_dir, cache_ttl_hours=cache_ttl_hours)

        if result:
            result["platform"] = "darwin"
            result["runtime"] = "colima"
            result["static_malware"] = "enabled"
            result["dynamic_malware"] = "enabled"

        return result

    # ==========================================================================
    # Other platforms: Not supported
    # ==========================================================================
    logger.info(f" Dynamic malware sandbox not supported on {system}")
    return {
        "verdict": "NOT_RUN",
        "reason": f"Platform {system} not supported for dynamic analysis",
        "platform": system,
        "packages_tested": 0,
        "findings": [],
        "static_malware": "enabled",
        "dynamic_malware": "not_supported",
        "duration_ms": int((time.time() - start_time) * 1000),
    }


def _check_colima_status() -> str:
    """
    Check Colima installation and running status.

    Returns:
        'running' - Colima is fully operational (Docker SDK can connect)
        'not_ready' - Colima process exists but Docker not accessible
        'stopped' - Colima is installed but not running
        'not_installed' - Colima is not installed
    """
    try:
        # Check if colima command exists
        if not shutil.which("colima"):
            return "not_installed"

        # Check if colima is running
        # colima status returns 0 if running, non-zero if not
        result = subprocess.run(["colima", "status"], capture_output=True, text=True, timeout=10)

        # Check both stdout and stderr for status indicators
        output = (result.stdout + result.stderr).lower()

        if result.returncode != 0:
            if "not running" in output or "not exist" in output:
                return "stopped"
            return "stopped"

        # Colima process is running - verify Docker SDK can actually connect
        # This is the same check used by _ensure_sandbox_image() and sandbox runner
        docker_client = _get_docker_client()
        if docker_client:
            return "running"
        else:
            return "not_ready"

    except FileNotFoundError:
        return "not_installed"
    except subprocess.TimeoutExpired:
        return "stopped"
    except Exception:
        return "not_installed"


def _start_colima() -> bool:
    """
    Start Colima VM with appropriate resources for sandbox.

    Returns:
        True if Colima started successfully, False otherwise
    """
    try:
        logger.info("         (this may take 2-3 minutes on first run)")
        result = subprocess.run(
            ["colima", "start", "--cpu", "2", "--memory", "4", "--disk", "10"],
            capture_output=True,
            text=True,
            timeout=300,  # 5 min timeout
        )
        if result.returncode == 0:
            # Wait for Docker daemon to become responsive inside the VM
            import time

            for attempt in range(12):  # Up to 30 seconds
                time.sleep(2.5)
                client = _get_docker_client()
                if client:
                    return True
                if attempt == 0:
                    logger.info("         Waiting for Colima Docker engine...")
            logger.info("         Colima Docker engine did not respond after 30s")
            return False
        else:
            logger.info("         Colima start returned error")
            return False
    except subprocess.TimeoutExpired:
        logger.info("         Timeout waiting for Colima to start")
        return False
    except Exception as e:
        logger.info(f" Error: {e}")
        return False


# Global to store last docker connection error for diagnostics
_last_docker_error = None


def _get_docker_client():
    """
    Get Docker client, trying Docker context endpoint first (supports Colima).

    The Docker CLI uses 'contexts' to determine which daemon to connect to.
    This function queries the current context to get the endpoint, ensuring
    compatibility with Colima and other Docker context-based setups.

    Returns:
        docker.DockerClient or None
    """
    global _last_docker_error

    try:
        import docker  # noqa: F401
    except ImportError:
        _last_docker_error = "docker SDK not installed"
        return None

    # Method 1: Get endpoint from current Docker context (most reliable)
    # This is how `docker info` works - it uses the current context
    try:
        result = subprocess.run(
            ["docker", "context", "inspect", "--format", "{{.Endpoints.docker.Host}}"],
            capture_output=True,
            text=True,
            timeout=5,
        )
        if result.returncode == 0:
            endpoint = result.stdout.strip()
            if endpoint:
                try:
                    client = docker.DockerClient(base_url=endpoint)
                    client.ping()
                    _last_docker_error = None
                    return client
                except Exception as e:
                    _last_docker_error = f"context endpoint {endpoint}: {e}"
    except Exception as e:
        _last_docker_error = f"context inspect failed: {e}"

    # Method 2: On macOS, try known Colima socket locations
    if platform.system() == "Darwin":
        colima_sockets = [
            Path.home() / ".colima" / "default" / "docker.sock",
            Path.home() / ".colima" / "docker.sock",
        ]

        for colima_socket in colima_sockets:
            if colima_socket.exists():
                try:
                    client = docker.DockerClient(base_url=f"unix://{colima_socket}")
                    client.ping()
                    _last_docker_error = None
                    return client
                except Exception as e:
                    _last_docker_error = f"socket {colima_socket}: {e}"
                    continue

    # Method 3: Check DOCKER_HOST env var
    docker_host = os.environ.get("DOCKER_HOST")
    if docker_host:
        try:
            client = docker.DockerClient(base_url=docker_host)
            client.ping()
            _last_docker_error = None
            return client
        except Exception as e:
            _last_docker_error = f"DOCKER_HOST {docker_host}: {e}"

    # Method 4: Try default socket (works if DOCKER_HOST is set or default /var/run/docker.sock)
    try:
        client = docker.from_env()
        client.ping()
        _last_docker_error = None
        return client
    except Exception as e:
        _last_docker_error = f"from_env: {e}"
        return None


def _ensure_sandbox_image() -> bool:
    """
    Ensure the sandbox Docker image is available.
    Uses Dockerfile hash to detect if rebuild is needed (cache invalidation).

    Returns:
        True if image is available, False otherwise
    """
    import hashlib

    try:
        import docker  # noqa: F401
    except ImportError:
        logger.info("         Docker SDK not installed (pip install docker)")
        return False

    client = _get_docker_client()
    if not client:
        # Connection failed - Colima may have stopped between checks
        logger.info("           Colima connection failed")
        return False

    image_name = "reachable/sandbox:latest"

    # Find sandbox directory (build context with Dockerfile)
    # __file__ = reachable/cli/sandbox.py
    # Dockerfile is at reach-core/sandbox/Dockerfile (repo root level)
    sandbox_dir = Path(__file__).parent.parent.parent / "sandbox"
    dockerfile = sandbox_dir / "Dockerfile"

    if not dockerfile.exists():
        # Fallback: check relative to reachable/ package
        sandbox_dir = Path(__file__).parent.parent / "sandbox"
        dockerfile = sandbox_dir / "Dockerfile"

    if not dockerfile.exists():
        logger.info(f"         Dockerfile not found (searched {Path(__file__).parent.parent.parent / 'sandbox'})")
        return False

    # Compute hash of Dockerfile + key sandbox files (so shim/entrypoint changes trigger rebuild)
    hasher = hashlib.sha256()
    hasher.update(dockerfile.read_bytes())
    for extra in ["scripts/entrypoint.sh", "runner.py"]:
        extra_path = sandbox_dir / extra
        if extra_path.exists():
            hasher.update(extra_path.read_bytes())
    # Include shim source directory hash
    shims_dir = sandbox_dir / "shims"
    if shims_dir.exists():
        for go_file in sorted(shims_dir.rglob("*.go")):
            hasher.update(go_file.read_bytes())
    current_hash = hasher.hexdigest()[:12]  # Short hash for label

    # Check if image exists with matching hash
    try:
        image = client.images.get(image_name)
        cached_hash = image.labels.get("reachable.sandbox.hash", "")

        if cached_hash == current_hash:
            logger.info("       Sandbox image ready (cached)")
            return True
        else:
            logger.info(" Sandbox image outdated (rebuilding...)")
    except docker.errors.ImageNotFound:
        logger.info("       Building sandbox image (first time only)...")

    # Build image with hash label
    try:
        logger.info(f" Building from {sandbox_dir}")
        image, build_logs = client.images.build(
            path=str(sandbox_dir),
            tag=image_name,
            labels={"reachable.sandbox.hash": current_hash},
            rm=True,
            quiet=False,
        )
        logger.info("       Sandbox image built")
        return True
    except Exception as e:
        logger.info(f" Build failed: {e}")
        return False


def _run_colima_sandbox(
    sbom_file: Path, output_dir: Path, repo_dir: Optional[Path] = None, cache_ttl_hours: int = 24
) -> Optional[dict]:
    """
    Internal: Run Docker-based sandbox when Colima is available.

    Colima provides a proper VM isolation layer, making it safe to run
    potentially malicious code (unlike Docker Desktop on macOS).
    """
    # Delegate to the existing sandbox analysis logic
    return run_sandbox_analysis(sbom_file, output_dir, repo_dir=repo_dir, cache_ttl_hours=cache_ttl_hours)


def run_sandbox_analysis(
    sbom_file: Path, output_dir: Path, repo_dir: Optional[Path] = None, cache_ttl_hours: int = 24
) -> Optional[dict]:
    """
    Run behavioral sandbox analysis on dependencies (internal implementation).

    Uses hybrid testing: batch first, then individual tests if issues found.

    Args:
        sbom_file: Path to SBOM JSON file
        output_dir: Output directory for results

    Returns:
        Sandbox results dict or None if sandbox unavailable
    """
    logger.info("       Checking sandbox prerequisites...")

    # Check 1: Docker Python SDK
    docker_sdk_installed = False
    try:
        import docker  # noqa: F401

        docker_sdk_installed = True
        logger.info("    Docker SDK: installed")
    except ImportError:
        logger.info("    Docker SDK: not installed")
        logger.info("    Installing docker Python SDK...")
        import subprocess

        try:
            subprocess.check_call(
                [sys.executable, "-m", "pip", "install", "docker", "-q"],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                timeout=120,  # 2 min for pip install
            )
            docker_sdk_installed = True
            logger.info("    Docker SDK: installed successfully")
        except Exception as e:
            logger.info(f" Docker SDK: installation failed - {e}")
            logger.info("    Run manually: pip install docker")
            return {
                "verdict": "NOT_RUN",
                "reason": "Could not install docker Python SDK",
                "packages_tested": 0,
                "findings": [],
                "prerequisites": {"docker_sdk": False, "docker_daemon": False},
            }

    # Check 2: Docker daemon running (use _get_docker_client which knows about Colima)
    docker_daemon_running = False
    daemon_error = None
    client = _get_docker_client()
    if client:
        try:
            docker_daemon_running = True
            docker_version = client.version().get("Version", "unknown")
            logger.info(f" Docker daemon: running (v{docker_version})")
        except Exception as e:
            daemon_error = str(e)
            logger.info(f" Docker daemon: error getting version - {e}")
    else:
        daemon_error = _last_docker_error or "Could not connect to Docker"
        logger.info("    Docker daemon: not running")
        logger.info("    Start Docker Desktop or run: sudo systemctl start docker")

    if not docker_daemon_running:
        return {
            "verdict": "NOT_RUN",
            "reason": daemon_error or "Docker daemon not available",
            "packages_tested": 0,
            "findings": [],
            "prerequisites": {
                "docker_sdk": docker_sdk_installed,
                "docker_daemon": False,
                "error": daemon_error,
            },
        }

    # Both prerequisites met
    try:
        from reachable.metrics.comprehensive import SandboxMetrics

        from ..sandbox.runner import SandboxRunner, Verdict
    except ImportError as e:
        logger.info(f" Sandbox module not available: {e}")
        return None

    # Create runner (Docker is confirmed available, pass the Colima-aware client)
    runner = SandboxRunner(timeout=300, parallel=4, docker_client=client)

    # Parse SBOM to get packages (handles both compressed and uncompressed)
    try:
        try:
            from reachable.core.compression import load_json

            sbom = load_json(sbom_file)
        except ImportError:
            with open(sbom_file) as f:
                sbom = json.load(f)
    except Exception as e:
        logger.info(f" Could not read SBOM: {e}")
        return None

    # Extract packages from SBOM (Syft format uses 'artifacts', CycloneDX uses 'components')
    packages = []

    # Try Syft format first (artifacts), then CycloneDX (components)
    components = sbom.get("artifacts", []) or sbom.get("components", [])

    if not components:
        logger.info("     No packages found in SBOM")
        return {"verdict": "CLEAN", "reason": "No packages in SBOM", "packages_tested": 0, "findings": []}

    npm_count = 0
    pip_count = 0
    skipped_count = 0
    skipped_by_type = {}  # Track why packages were skipped

    for comp in components:
        name = comp.get("name", "")
        version = comp.get("version")

        # Syft format uses 'type', CycloneDX uses 'purl'
        pkg_type = comp.get("type", "").lower()
        purl = comp.get("purl", "")

        # Determine ecosystem
        ecosystem = None
        if pkg_type in ("npm", "node"):
            ecosystem = "npm"
            npm_count += 1
        elif pkg_type in ("pip", "pypi", "python"):
            ecosystem = "pip"
            pip_count += 1
        elif "pkg:pypi" in purl:
            ecosystem = "pip"
            pip_count += 1
        elif "pkg:npm" in purl:
            ecosystem = "npm"
            npm_count += 1
        elif pkg_type in ("go-module", "go", "golang") or "pkg:golang" in purl:
            skipped_count += 1
            skipped_by_type["Go"] = skipped_by_type.get("Go", 0) + 1
            continue  # Skip Go packages (different install mechanism)
        elif pkg_type in ("maven", "gradle", "java") or "pkg:maven" in purl:
            skipped_count += 1
            skipped_by_type["Java/Maven"] = skipped_by_type.get("Java/Maven", 0) + 1
            continue  # Skip Java packages
        elif pkg_type in ("cargo", "rust") or "pkg:cargo" in purl:
            skipped_count += 1
            skipped_by_type["Rust"] = skipped_by_type.get("Rust", 0) + 1
            continue  # Skip Rust packages
        elif pkg_type in ("gem", "ruby") or "pkg:gem" in purl:
            skipped_count += 1
            skipped_by_type["Ruby"] = skipped_by_type.get("Ruby", 0) + 1
            continue  # Skip Ruby packages
        else:
            skipped_count += 1
            skipped_by_type["Other"] = skipped_by_type.get("Other", 0) + 1
            continue  # Skip unknown ecosystems

        if name and ecosystem:
            # v4.6.10: Extract package hash from SBOM for cache integrity
            pkg_hash = ""
            for h in comp.get("hashes", []):
                if h.get("alg", "").upper() in ("SHA-256", "SHA256"):
                    pkg_hash = h.get("content", "")
                    break
            if not pkg_hash:
                # Fallback: use purl as pseudo-hash (unique per registry entry)
                pkg_hash = purl if purl else ""
            packages.append((name, ecosystem, version, pkg_hash))

    if not packages:
        reason = "No pip/npm packages found in SBOM to sandbox test"
        if skipped_count > 0:
            reason += f" ({skipped_count} Go/Java/other packages skipped)"
        logger.info(f" {reason}")
        return {
            "verdict": "CLEAN",
            "reason": reason,
            "packages_tested": 0,
            "findings": [],
            "stats": {
                "npm_packages": npm_count,
                "pip_packages": pip_count,
                "skipped_packages": skipped_count,
                "sbom_total": len(components),
            },
        }

    # Show breakdown before testing
    logger.info(f" Sandbox will test {len(packages)} packages:")
    logger.info(f" • npm: {npm_count}")
    logger.info(f" • pip: {pip_count}")
    if skipped_count > 0:
        skipped_detail = ", ".join(f"{k}: {v}" for k, v in sorted(skipped_by_type.items(), key=lambda x: -x[1]))
        logger.info(f" • skipped: {skipped_count} ({skipped_detail})")
        logger.info(" Why skipped:")
        logger.info(" • Go modules: No install-time hooks (uses go.mod declarative imports)")
        logger.info(" • Java/Maven: Build-time dependencies (Gradle/Maven manages lifecycle)")
        logger.info(" • Other: Ecosystem not yet supported for behavioral testing")
        logger.info(" Tip: These packages are still scanned by GuardDog static analysis")
    logger.info(" Running behavioral sandbox analysis...")
    logger.info(" Strategy: Batch test all → individual tests if suspicious")

    # v4.6.10: Check sandbox cache — skip packages already tested within TTL
    cached_findings = []
    cached_malicious = []
    cached_suspicious = []
    cached_clean_count = 0
    uncached_packages = []

    if cache_ttl_hours > 0:
        try:
            from reachable.database.storage import RepoDatabase, get_repo_db_path

            # T6 FIX: ScanDatabase() requires db_path — was called with no args,
            # silently throwing TypeError → caught by except → all packages re-tested.
            # Use repo-level DB (same one the rest of the pipeline uses).
            _db_path = get_repo_db_path(repo_dir) if repo_dir else None
            if _db_path is None:
                raise RuntimeError("repo_dir not available — sandbox cache skipped")
            db = RepoDatabase(_db_path)

            for pkg_tuple in packages:
                name, ecosystem, version, pkg_hash = pkg_tuple
                cached = db.get_sandbox_cache(
                    name, version, ecosystem, max_age_hours=cache_ttl_hours, pkg_hash=pkg_hash
                )
                if cached:
                    if cached["malicious"]:
                        cached_malicious.append(name)
                        cached_findings.extend(cached["findings"])
                    elif cached["suspicious"]:
                        cached_suspicious.append(name)
                        cached_findings.extend(cached["findings"])
                    else:
                        cached_clean_count += 1
                else:
                    uncached_packages.append(pkg_tuple)

            total_cached = len(cached_malicious) + len(cached_suspicious) + cached_clean_count
            if total_cached > 0:
                logger.info(f" Sandbox cache: {total_cached} packages cached ({cache_ttl_hours}h TTL)")
                if cached_malicious:
                    logger.info(f" ☢️ Cached malware: {', '.join(cached_malicious)}")
                if cached_suspicious:
                    logger.info(f" ⚠️ Cached suspicious: {', '.join(cached_suspicious)}")
                logger.info(f" ✅ Cached clean: {cached_clean_count}")
                if uncached_packages:
                    logger.info(f" 🔄 Need testing: {len(uncached_packages)} packages")
                else:
                    logger.info(" All packages cached — skipping sandbox")
        except Exception:
            uncached_packages = packages  # Cache unavailable, test all
    else:
        logger.info(" Sandbox cache: disabled (TTL=0 or --force)")
        uncached_packages = packages

    # If all packages cached, build result from cache and return early
    if not uncached_packages and (cached_malicious or cached_suspicious or cached_clean_count > 0):
        overall_verdict = "CRITICAL" if cached_malicious else ("SUSPICIOUS" if cached_suspicious else "CLEAN")
        return {
            "verdict": overall_verdict,
            "packages_tested": len(packages),
            "duration_ms": 0,
            "strategy": "cached",
            "summary": {
                "malicious": len(cached_malicious),
                "suspicious": len(cached_suspicious),
                "clean": cached_clean_count,
                "verdict_explanation": f"All {len(packages)} packages served from sandbox cache ({cache_ttl_hours}h TTL)",
            },
            "findings": cached_findings,
            "malicious_packages": cached_malicious,
            "suspicious_packages": cached_suspicious,
            "metrics": {"packages_tested": len(packages), "cache_hits": len(packages)},
            "batch": {"verdict": overall_verdict, "duration_ms": 0, "findings_count": len(cached_findings)},
            "individual_tests": 0,
            "cache": {"hits": len(packages), "misses": 0, "ttl_hours": cache_ttl_hours},
        }

    # Test only uncached packages — strip hash for runner (expects 3-tuples)
    packages_to_test = uncached_packages if uncached_packages else packages
    runner_packages = [(n, e, v) for n, e, v, _h in packages_to_test]

    # Use hybrid testing for efficiency
    def progress_callback(phase, current, total, pkg):
        if phase == "batch":
            if current == 0:
                logger.info(" Phase 1: Batch testing all packages...")
            else:
                logger.info(" Phase 1: Complete")
        elif phase == "individual":
            logger.info(f" Phase 2: Testing {pkg} ({current}/{total})...")

    try:
        result = runner.test_hybrid(runner_packages, progress_callback=progress_callback)

        # Convert to metrics for structured data
        metrics = SandboxMetrics.from_hybrid_result(result)

        # Count malicious/suspicious for risk score integration
        malicious_count = len(result.malicious_packages) if result.malicious_packages else 0
        suspicious_count = (
            len(result.batch_result.suspicious_packages) if result.batch_result.suspicious_packages else 0
        )

        # Binary model: CRITICAL = malware, CLEAN = nothing
        if result.verdict.value == "CRITICAL" and malicious_count == 0:
            malicious_count = 1  # At least one if CRITICAL verdict

        # Build result dict for JSON/dashboard
        sandbox_data = {
            "verdict": result.verdict.value,
            "capability_score": metrics.min_capability_score,
            "packages_tested": metrics.packages_tested,
            "duration_ms": result.duration_ms,
            "strategy": "hybrid",
            # Summary for risk score integration (matches sandbox_executor format)
            "summary": {
                "malicious": malicious_count,
                "suspicious": suspicious_count,
                "clean": metrics.packages_tested - malicious_count - suspicious_count,
                "verdict_explanation": {
                    "CLEAN": "No malicious behavior detected",
                    "SUSPICIOUS": "Suspicious behavior detected - review recommended",
                    "CRITICAL": "Malicious behavior confirmed - remove immediately",
                    "ERROR": "Sandbox execution failed",
                }.get(result.verdict.value, "Unknown verdict"),
            },
            "findings": [
                {
                    "rule": f.rule,
                    "severity": f.severity.value if hasattr(f.severity, "value") else str(f.severity),
                    "description": f.description,
                    "phase": f.phase,
                    "evidence": f.evidence,
                }
                for f in result.batch_result.findings
            ],
            "malicious_packages": result.malicious_packages,
            "suspicious_packages": result.batch_result.suspicious_packages,
            "metrics": metrics.to_dict(),
            "batch": {
                "verdict": result.batch_result.verdict.value,
                "duration_ms": result.batch_result.duration_ms,
                "findings_count": len(result.batch_result.findings),
            },
            "individual_tests": len(result.individual_results),
        }

        # Add individual findings
        for r in result.individual_results:
            for f in r.findings:
                sandbox_data["findings"].append(
                    {
                        "rule": f.rule,
                        "severity": f.severity.value if hasattr(f.severity, "value") else str(f.severity),
                        "description": f.description,
                        "phase": f.phase,
                        "evidence": f.evidence,
                        "package": r.package,
                    }
                )

        # Print summary with explanation
        # Log SBOM batch result (intermediate, not final verdict)
        logger.info(f" SBOM packages: {result.verdict.value} ({metrics.packages_tested} tested)")
        logger.info(f" Duration: {result.duration_ms}ms")

        # =================================================================
        # LOCAL PACKAGE TESTING
        # Detect and test local packages with install hooks (postinstall etc.)
        # These are NOT caught by GuardDog (which only checks registry pkgs)
        # Example: shai-hulud simulation in reach-testbed
        # =================================================================
        if repo_dir:
            try:
                from ..sandbox.runner import detect_local_packages_with_hooks, test_local_packages

                local_packages = detect_local_packages_with_hooks(str(repo_dir))
                if local_packages:
                    logger.info(f" Local packages with install hooks: {len(local_packages)}")
                    local_results = test_local_packages(
                        str(repo_dir), runner=runner, timeout=300, packages=local_packages
                    )

                    # Merge local package results into sandbox_data
                    local_findings = []
                    local_malicious = []
                    for lr in local_results:
                        if lr.verdict == Verdict.CRITICAL:
                            local_malicious.append(lr.package)
                        for f in lr.findings:
                            local_findings.append(
                                {
                                    "rule": f.rule,
                                    "severity": f.severity.value if hasattr(f.severity, "value") else str(f.severity),
                                    "description": f.description,
                                    "phase": f.phase,
                                    "evidence": f.evidence,
                                    "package": lr.package,
                                    "local_package": True,
                                }
                            )

                    sandbox_data["findings"].extend(local_findings)
                    sandbox_data["local_packages"] = {
                        "tested": len(local_results),
                        "packages": [
                            {
                                "name": lr.package,
                                "verdict": lr.verdict.value,
                                "findings_count": len(lr.findings),
                                "duration_ms": lr.duration_ms,
                                "capability_score": lr.capability_score,
                            }
                            for lr in local_results
                        ],
                    }

                    # Count local suspicious packages
                    local_suspicious = [lr.package for lr in local_results if lr.verdict.value == "SUSPICIOUS"]

                    if local_malicious:
                        sandbox_data["malicious_packages"] = (
                            sandbox_data.get("malicious_packages") or []
                        ) + local_malicious
                        # Escalate overall verdict if local package is CRITICAL
                        sandbox_data["verdict"] = "CRITICAL"

                    # Update summary counts so stats table / DB reflect local findings
                    sandbox_data["summary"]["malicious"] = sandbox_data["summary"].get("malicious", 0) + len(
                        local_malicious
                    )
                    sandbox_data["summary"]["suspicious"] = sandbox_data["summary"].get("suspicious", 0) + len(
                        local_suspicious
                    )
                    sandbox_data["packages_tested"] = sandbox_data.get("packages_tested", 0) + len(local_results)

                    logger.info(
                        f" Local package sandbox complete: {len(local_results)} tested, {len(local_malicious)} malicious, {len(local_suspicious)} suspicious"
                    )

            except Exception as e:
                logger.info(f" Local package testing error: {e}")

        # =================================================================
        # FINAL VERDICT (after ALL testing — SBOM + local packages)
        # =================================================================
        final_verdict = sandbox_data["verdict"]
        final_malicious = sandbox_data.get("malicious_packages") or []
        final_suspicious = sandbox_data.get("suspicious_packages") or []
        final_malicious_count = sandbox_data["summary"].get("malicious", 0)
        final_suspicious_count = sandbox_data["summary"].get("suspicious", 0)

        verdict_icon = {"CLEAN": "", "SUSPICIOUS": "⚠️", "CRITICAL": "", "ERROR": ""}.get(final_verdict, "")

        verdict_explanation = {
            "CLEAN": "No malicious install-time behavior",
            "SUSPICIOUS": f"Suspicious behavior detected ({final_suspicious_count} packages) - review recommended",
            "CRITICAL": f"MALWARE CONFIRMED ({final_malicious_count} packages) - remove immediately",
            "ERROR": "Sandbox execution failed",
        }.get(final_verdict, "")

        logger.info(f" {verdict_icon} Sandbox verdict: {final_verdict}")
        if verdict_explanation:
            logger.info(f" → {verdict_explanation}")
        if final_malicious:
            logger.info(f" Malicious packages: {', '.join(final_malicious)}")
        if final_suspicious:
            logger.info(f" Suspicious packages: {', '.join(final_suspicious[:5])}")
            if len(final_suspicious) > 5:
                logger.info(f" ... and {len(final_suspicious) - 5} more")

        # v4.6.10: Write sandbox results to cache for each tested package
        if cache_ttl_hours > 0:
            try:
                from reachable.database.storage import RepoDatabase, get_repo_db_path

                # T6 FIX: same fix as read block — use repo-level DB with path
                _db_path = get_repo_db_path(repo_dir) if repo_dir else None
                if _db_path is None:
                    raise RuntimeError("repo_dir not available — cache write skipped")
                db = RepoDatabase(_db_path)

                malicious_set = set(result.malicious_packages or [])
                suspicious_set = set(result.batch_result.suspicious_packages or [])

                # Build per-package findings map from individual results
                pkg_findings = {}
                for r in result.individual_results:
                    pkg_findings[r.package] = [
                        {
                            "rule": f.rule,
                            "severity": f.severity.value if hasattr(f.severity, "value") else str(f.severity),
                            "description": f.description,
                            "phase": f.phase,
                            "evidence": f.evidence,
                        }
                        for f in r.findings
                    ]

                cached_count = 0
                for name, ecosystem, version in packages_to_test:
                    pkg_verdict = (
                        "CRITICAL" if name in malicious_set else ("SUSPICIOUS" if name in suspicious_set else "CLEAN")
                    )
                    findings = pkg_findings.get(name, [])
                    db.cache_sandbox_result(
                        package_name=name,
                        version=version or "unknown",
                        ecosystem=ecosystem,
                        verdict=pkg_verdict,
                        findings=findings,
                        malicious=(name in malicious_set),
                        suspicious=(name in suspicious_set),
                    )
                    cached_count += 1

                logger.info(f" Sandbox cache: stored {cached_count} results ({cache_ttl_hours}h TTL)")

                # Purge stale entries (>7 days)
                purged = db.purge_sandbox_cache(max_age_hours=168)
                if purged:
                    logger.info(f" Sandbox cache: purged {purged} stale entries")
            except Exception as e:
                logger.debug(f" Sandbox cache write error: {e}")  # Non-fatal
        else:
            logger.debug(" Sandbox cache disabled (TTL=0), skipping cache write")

        # Merge cached results into sandbox_data if partial cache hit
        if cached_findings:
            sandbox_data["findings"].extend(cached_findings)
            sandbox_data["malicious_packages"] = list(
                set((sandbox_data.get("malicious_packages") or []) + cached_malicious)
            )
            sandbox_data["suspicious_packages"] = list(
                set((sandbox_data.get("suspicious_packages") or []) + cached_suspicious)
            )
            sandbox_data["summary"]["malicious"] += len(cached_malicious)
            sandbox_data["summary"]["suspicious"] += len(cached_suspicious)
            sandbox_data["summary"]["clean"] += cached_clean_count
            sandbox_data["packages_tested"] += len(cached_malicious) + len(cached_suspicious) + cached_clean_count
            sandbox_data["cache"] = {
                "hits": len(cached_malicious) + len(cached_suspicious) + cached_clean_count,
                "misses": len(packages_to_test),
                "ttl_hours": cache_ttl_hours,
            }
            # Re-evaluate overall verdict with merged results
            if cached_malicious and sandbox_data["verdict"] != "CRITICAL":
                sandbox_data["verdict"] = "CRITICAL"

        return sandbox_data

    except Exception as e:
        logger.info(f" Sandbox error: {e}")
        import traceback

        logger.debug(f" Sandbox traceback: {traceback.format_exc()}")
        return {"verdict": "ERROR", "reason": str(e), "packages_tested": len(packages), "findings": []}


def sandbox_command(args):
    """
    Manage dynamic malware sandbox.

    Platform-specific:
    - macOS: Colima (brew install/uninstall)
    - Linux: Firecracker (not yet implemented)
    """

    system = platform.system().lower()
    logger.info("REACHABLE DYNAMIC MALWARE SANDBOX")
    logger.info(f"Platform: {platform.system()} ({platform.machine()})")
    # Default to --status if no option specified
    if getattr(args, "init", False):
        _sandbox_init(system)
    elif getattr(args, "remove", False):
        _sandbox_remove(system)
    else:
        # Default behavior: show status
        _sandbox_status(system)


def _sandbox_status(system: str):
    """Check sandbox installation status"""

    if system == "darwin":
        logger.info("Checking Colima status...")
        colima_status = _check_colima_status()

        if colima_status == "not_installed":
            logger.info("  Colima:         NOT INSTALLED")
            logger.info("  Docker CLI:    " + _check_docker_cli_status())
            logger.info("  Dynamic malware sandbox is NOT available.")
            logger.info("  Run: reachctl sandbox --init")
            sys.exit(1)
        elif colima_status == "not_ready":
            logger.info("  Colima:          NOT READY (Docker not responding)")
            logger.info("  Docker CLI:    " + _check_docker_cli_status())
            logger.info("  Colima process is running but Docker daemon not accessible.")
            logger.info("  Try: colima restart")
            sys.exit(1)
        elif colima_status == "stopped":
            logger.info("  Colima:          INSTALLED but stopped")
            logger.info("  Docker CLI:    " + _check_docker_cli_status())
            logger.info("  Sandbox installed but not running.")
            logger.info("  It will auto-start during scans, or run: colima start")
        else:
            # colima_status == 'running' (Colima + Docker both accessible)
            logger.info("  Colima:         RUNNING")
            logger.info("  Docker CLI:    " + _check_docker_cli_status())

            # Check sandbox image
            image_status = _check_sandbox_image_status()
            logger.info(f" Sandbox Image: {image_status}")
            logger.info("  Dynamic malware sandbox is READY.")

    elif system == "linux":
        logger.info("  Firecracker:     NOT YET IMPLEMENTED")
        logger.info("  Linux sandbox (Firecracker) planned for v4.7.x")
        logger.info("  Static malware analysis (GuardDog) is always available.")

    else:
        logger.info(f" Platform {system} not supported for dynamic sandbox.")
        logger.info("  Static malware analysis (GuardDog) is always available.")
        sys.exit(1)


def _sandbox_init(system: str):
    """Install sandbox components"""

    if system == "darwin":
        logger.info("Installing Colima for macOS...")
        # Check if already installed
        colima_status = _check_colima_status()
        if colima_status != "not_installed":
            logger.info("   Colima is already installed")

            # Ensure Python Docker SDK is installed
            try:
                import docker  # noqa: F401

                docker.DockerClient  # Verify it's the real SDK
            except (ImportError, AttributeError):
                logger.info("   Installing Python Docker SDK...")
                try:
                    result = subprocess.run(
                        [sys.executable, "-m", "pip", "install", "docker", "-q"],
                        timeout=120,
                        capture_output=True,
                    )
                    if result.returncode == 0:
                        logger.info("   Python Docker SDK installed")
                    else:
                        logger.info("    Run manually: pip install docker")
                except Exception as e:
                    logger.info(f" Could not install Python Docker SDK: {e}")
                    logger.info("     Run manually: pip install docker")
            if colima_status == "stopped":
                logger.info("   Starting Colima...")
                if _start_colima():
                    logger.info("   Colima started")
                else:
                    logger.info("   Failed to start Colima")
                    sys.exit(1)
            elif colima_status == "not_ready":
                logger.info("    Colima not responding, restarting...")
                try:
                    subprocess.run(["colima", "stop"], timeout=60, capture_output=True)
                except Exception:
                    pass
                if _start_colima():
                    logger.info("   Colima restarted")
                else:
                    logger.info("   Failed to restart Colima")
                    logger.info("  Try manually: colima delete -f && colima start")
                    sys.exit(1)
            if _ensure_sandbox_image():
                logger.info("  Sandbox is ready!")
            else:
                logger.info("    Sandbox image not ready - will build on first scan")
            return

        # Check for brew
        if not shutil.which("brew"):
            logger.info("   Homebrew not found")
            logger.info("  Please install Homebrew first:")
            logger.info(
                '    /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"'
            )
            logger.info("  Or install Colima manually:")
            logger.info("    https://github.com/abiosoft/colima/releases")
            sys.exit(1)

        # Install colima and docker CLI via brew
        logger.info("   Installing colima and docker via Homebrew...")
        logger.info("     (this may take a few minutes)")
        try:
            result = subprocess.run(
                ["brew", "install", "colima", "docker"],
                timeout=600,  # 10 minute timeout
                capture_output=True,  # Suppress brew output
            )
            if result.returncode != 0:
                logger.info("   Installation failed")
                sys.exit(1)
        except subprocess.TimeoutExpired:
            logger.info("   Installation timed out")
            sys.exit(1)
        except Exception as e:
            logger.info(f" Installation error: {e}")
            sys.exit(1)
        logger.info("   Colima and Docker CLI installed")

        # Install Python Docker SDK
        logger.info("   Installing Python Docker SDK...")
        try:
            result = subprocess.run(
                [sys.executable, "-m", "pip", "install", "docker", "-q"], timeout=120, capture_output=True
            )
            if result.returncode == 0:
                logger.info("   Python Docker SDK installed")
            else:
                logger.info("    Python Docker SDK install failed (may already be installed)")
        except Exception as e:
            logger.info(f" Could not install Python Docker SDK: {e}")
            logger.info("     Run manually: pip install docker")

        # Start Colima
        logger.info("   Starting Colima VM...")
        logger.info("     (first start downloads VM image, may take 2-3 minutes)")
        if _start_colima():
            logger.info("   Colima started")
        else:
            logger.info("   Failed to start Colima")
            logger.info("  Try manually: colima start --cpu 2 --memory 4")
            sys.exit(1)

        # Build sandbox image
        _ensure_sandbox_image()
        logger.info(" SANDBOX INSTALLATION COMPLETE")
        logger.info("Dynamic malware detection is now enabled.")
        logger.info("Run 'reachctl scan /path/to/repo' to use it.")

    elif system == "linux":
        logger.info("    Linux sandbox (Firecracker) not yet implemented")
        logger.info("  Planned for v4.7.x")
        logger.info("  Static malware analysis (GuardDog) is always available.")
        sys.exit(0)

    else:
        logger.info(f" Platform {system} not supported")
        sys.exit(1)


def _sandbox_remove(system: str):
    """Remove sandbox components"""

    if system == "darwin":
        logger.info("Removing Colima sandbox...")
        # Check if installed
        colima_status = _check_colima_status()
        if colima_status == "not_installed":
            logger.info("    Colima is not installed")
            return

        # Stop Colima if running
        if colima_status == "running":
            logger.info("   Stopping Colima...")
            try:
                subprocess.run(["colima", "stop"], timeout=60, capture_output=True)
                logger.info("   Colima stopped")
            except Exception as e:
                logger.info(f" Failed to stop Colima: {e}")

        # Delete Colima VM
        logger.info("    Deleting Colima VM...")
        try:
            subprocess.run(["colima", "delete", "-f"], timeout=60, capture_output=True)
            logger.info("   Colima VM deleted")
        except Exception as e:
            logger.info(f" Failed to delete VM: {e}")

        # Check for brew
        if not shutil.which("brew"):
            logger.info("    Homebrew not found - cannot uninstall packages")
            logger.info("  Colima VM deleted, but binaries remain.")
            logger.info("  Remove manually if needed.")
            return

        # Uninstall via brew
        logger.info("   Uninstalling colima via Homebrew...")
        try:
            result = subprocess.run(["brew", "uninstall", "colima"], timeout=120, capture_output=True, text=True)
            if result.returncode == 0:
                logger.info("   Colima uninstalled")
            else:
                logger.info(f" Uninstall warning: {result.stderr[:100]}")
        except Exception as e:
            logger.info(f" Uninstall error: {e}")

        # Ask about docker CLI
        logger.info("    Docker CLI was NOT removed (may be used by other tools)")
        logger.info("  To remove: brew uninstall docker")
        logger.info(" SANDBOX REMOVED")
        logger.info("Dynamic malware detection is now disabled.")
        logger.info("Static malware analysis (GuardDog) still works.")

    elif system == "linux":
        logger.info("    Linux sandbox (Firecracker) not yet implemented")
        logger.info("  Nothing to remove.")

    else:
        logger.info(f" Platform {system} has no sandbox to remove")


def _check_docker_cli_status() -> str:
    """Check if docker CLI is installed"""
    if shutil.which("docker"):
        try:
            result = subprocess.run(["docker", "--version"], capture_output=True, text=True, timeout=5)
            if result.returncode == 0:
                version = result.stdout.strip().split()[2].rstrip(",")
                return f" installed (v{version})"
        except Exception:
            pass
        return " installed"
    return " not installed"


def _check_sandbox_image_status() -> str:
    """Check if sandbox Docker image exists and is up-to-date"""
    import hashlib

    global _last_docker_error

    try:
        import docker  # noqa: F401
    except ImportError:
        return " unknown (docker SDK not installed - pip install docker)"

    client = _get_docker_client()
    if not client:
        # Show the actual error from _get_docker_client
        if _last_docker_error:
            return f" unknown ({_last_docker_error})"
        else:
            return " unknown (Docker connection failed)"

    # Compute current hash
    # __file__ = reachable/cli/sandbox.py → Dockerfile at reach-core/sandbox/
    sandbox_dir = Path(__file__).parent.parent.parent / "sandbox"
    dockerfile = sandbox_dir / "Dockerfile"
    if not dockerfile.exists():
        sandbox_dir = Path(__file__).parent.parent / "sandbox"
        dockerfile = sandbox_dir / "Dockerfile"

    if dockerfile.exists():
        hasher = hashlib.sha256()
        hasher.update(dockerfile.read_bytes())
        for extra in ["scripts/entrypoint.sh", "runner.py"]:
            extra_path = sandbox_dir / extra
            if extra_path.exists():
                hasher.update(extra_path.read_bytes())
        shims_dir = sandbox_dir / "shims"
        if shims_dir.exists():
            for go_file in sorted(shims_dir.rglob("*.go")):
                hasher.update(go_file.read_bytes())
        current_hash = hasher.hexdigest()[:12]
    else:
        current_hash = None

    # Check image
    try:
        image = client.images.get("reachable/sandbox:latest")
        cached_hash = image.labels.get("reachable.sandbox.hash", "")

        if current_hash and cached_hash == current_hash:
            return f" ready (cached, hash: {cached_hash})"
        elif cached_hash:
            return "  outdated (will rebuild on next scan)"
        else:
            return " ready (no hash - legacy build)"
    except docker.errors.ImageNotFound:
        return "  not built (will build on first scan)"
    except Exception as e:
        return f" unknown ({e})"


# =============================================================================
# v4.5.51: Bug Fixes - Call Path and Risk Level Population
# =============================================================================
