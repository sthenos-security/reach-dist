#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.
"""
reachctl aliases — view and manage unresolved package suggestions.

Usage:
    reachctl aliases                       show unresolved ranked by frequency
    reachctl aliases show [--all]          show unresolved stats (--all: include resolved)
    reachctl aliases accept <name> <eco>   accept best-guess alias for a package
    reachctl aliases dismiss <name> <eco>  mark as genuinely private (no upstream)
"""

import argparse
import logging
import sys
from typing import Optional

logger = logging.getLogger(__name__)


def aliases_command(args=None):
    """Main handler for `reachctl aliases`."""
    subcmd = getattr(args, "aliases_subcmd", None) or "show"

    dispatch = {
        "show": _cmd_show,
        "accept": _cmd_accept,
        "dismiss": _cmd_dismiss,
    }

    handler = dispatch.get(subcmd)
    if handler:
        handler(args)
    else:
        _cmd_show(args)


# ─────────────────────────────────────────────────────────────────────────────
# show — ranked unresolved packages
# ─────────────────────────────────────────────────────────────────────────────


def _cmd_show(args=None):
    """Display unresolved packages ranked by occurrence_count."""
    show_all = getattr(args, "all", False)
    repo_path = getattr(args, "repo", None)

    db = _get_db(repo_path)
    if db is None:
        print("No scan database found for this repository.")
        print("  Either cd into a previously scanned repo, or use --repo /path/to/repo")
        print("  To see global aliases: reachctl registries alias list")
        return

    try:
        stats = db.get_unresolved_stats(resolved=show_all)
    except Exception as e:
        print(f"Error reading unresolved stats: {e}")
        print("This may be a database from before Phase 5. Run a new scan to populate.")
        return
    finally:
        db.close()

    if not stats:
        print("No unresolved packages found.")
        if not show_all:
            print("  (use --all to include previously resolved packages)")
        return

    # Header
    total = sum(s["occurrence_count"] for s in stats)
    print(f"UNRESOLVED PACKAGES ({len(stats)} packages, {total} total occurrences)")
    print("─" * 75)
    print()

    for s in stats:
        name = s["name"]
        version = s["version"]
        eco = s["ecosystem"]
        count = s["occurrence_count"]
        guess_purl = s.get("best_guess_purl")
        guess_conf = s.get("best_guess_confidence")
        resolved = s.get("resolved", 0)

        # Status indicator
        if resolved:
            status = "✓ RESOLVED"
        elif count >= 10:
            status = "↑ priority"
        else:
            status = ""

        print(f"  {name} {version}  ({eco})", end="")
        if status:
            print(f"  {' ' * max(0, 40 - len(name) - len(version) - len(eco))}{status}", end="")
        print()
        print(f"  ├─ seen in: {count} scan{'s' if count != 1 else ''}")

        if guess_purl and guess_conf:
            # Extract just the name from the PURL for display
            from reachable.collectors.vulns.purl_resolver import _purl_parts

            _, guess_name, guess_ver = _purl_parts(guess_purl)
            conf_pct = int(guess_conf * 100)
            print(f"  ├─ best guess: {guess_name}@{guess_ver}  ({conf_pct}% confidence)")
            print(f'  └─ to accept:  reachctl aliases accept "{name}" {eco}')
        else:
            print("  ├─ best guess: none found")
            print(f'  └─ to resolve: reachctl registries alias add "pkg:{eco}/{name}@" "pkg:{eco}/<upstream>@"')
        print()

    # Footer
    print("─" * 75)
    if not show_all:
        print("Showing open (unresolved) only. Use --all to include resolved.")
    print()
    print("Commands:")
    print("  accept <name> <ecosystem>                Accept best-guess alias")
    print("  dismiss <name> <ecosystem>               Mark as genuinely private")
    print("  registries alias add <priv> <canon>      Manual alias mapping")


# ─────────────────────────────────────────────────────────────────────────────
# accept — promote best-guess to alias
# ─────────────────────────────────────────────────────────────────────────────


def _cmd_accept(args=None):
    """Accept the best-guess fuzzy match as an alias."""
    name = getattr(args, "name", None)
    ecosystem = getattr(args, "ecosystem", None)
    repo_path = getattr(args, "repo", None)

    if not name or not ecosystem:
        print("Usage: reachctl aliases accept <package-name> <ecosystem>")
        sys.exit(1)

    db = _get_db(repo_path)
    if db is None:
        print("No scan database found. Use --repo /path/to/repo or cd into a scanned repo.")
        sys.exit(1)

    try:
        stats = db.get_unresolved_stats(resolved=False)
        match = next(
            (s for s in stats if s["name"] == name and s["ecosystem"] == ecosystem),
            None,
        )

        if not match:
            print(f"No unresolved package found: {name} ({ecosystem})")
            sys.exit(1)

        guess_purl = match.get("best_guess_purl")
        if not guess_purl:
            print(f"No best-guess available for {name} ({ecosystem}).")
            print(
                f'Add manually: reachctl registries alias add "pkg:{ecosystem}/{name}@" "pkg:{ecosystem}/<upstream>@"'
            )
            sys.exit(1)

        # Add alias via registry_config
        from reachable.core.registry_config import add_alias

        purl_prefix = match.get("purl", f"pkg:{ecosystem}/{name}@")
        # Ensure prefix ends with @
        if "@" in purl_prefix:
            purl_prefix = purl_prefix.rsplit("@", 1)[0] + "@"

        guess_prefix = guess_purl.rsplit("@", 1)[0] + "@" if "@" in guess_purl else guess_purl

        if add_alias(purl_prefix, guess_prefix):
            # Mark as resolved in DB
            version = match.get("version", "")
            db.mark_unresolved_resolved(name, version, ecosystem, resolved_by="alias")

            from reachable.collectors.vulns.purl_resolver import _purl_parts

            _, guess_name, _ = _purl_parts(guess_purl)
            print(f"✓ Added alias: {name} → {guess_name}")
            print("  Next scan will use this mapping automatically.")
        else:
            print("ERROR: Could not save alias to registries.yaml")
            sys.exit(1)
    finally:
        db.close()


# ─────────────────────────────────────────────────────────────────────────────
# dismiss — mark as genuinely private
# ─────────────────────────────────────────────────────────────────────────────


def _cmd_dismiss(args=None):
    """Mark an unresolved package as genuinely private (no upstream)."""
    name = getattr(args, "name", None)
    ecosystem = getattr(args, "ecosystem", None)
    repo_path = getattr(args, "repo", None)

    if not name or not ecosystem:
        print("Usage: reachctl aliases dismiss <package-name> <ecosystem>")
        sys.exit(1)

    db = _get_db(repo_path)
    if db is None:
        print("No scan database found. Use --repo /path/to/repo or cd into a scanned repo.")
        sys.exit(1)

    try:
        stats = db.get_unresolved_stats(resolved=False)
        match = next(
            (s for s in stats if s["name"] == name and s["ecosystem"] == ecosystem),
            None,
        )

        if not match:
            print(f"No unresolved package found: {name} ({ecosystem})")
            sys.exit(1)

        version = match.get("version", "")
        db.mark_unresolved_resolved(name, version, ecosystem, resolved_by="dismissed")

        # Add internal namespace pattern
        from reachable.core.registry_config import add_namespace

        add_namespace(ecosystem, name)

        print(f"✓ Dismissed: {name} ({ecosystem}) — marked as genuinely private")
        print("  Added to internal namespaces. Will be skipped in future scans.")
    finally:
        db.close()


# ─────────────────────────────────────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────────────────────────────────────


def _get_db(repo_path: Optional[str] = None):
    """Get a RepoDatabase for the given or current repo.

    Accepts:
      - Source repo path (e.g. /path/to/myproject)
      - Scan output directory (e.g. ~/.reachable/scans/myproject-abc123)
      - Direct path to repo.db file
    """
    try:
        from reachable.database.storage import RepoDatabase, get_repo_db_path
    except ImportError:
        return None

    from pathlib import Path

    if repo_path:
        p = Path(repo_path)
        # Direct path to repo.db
        if p.name == "repo.db" and p.exists():
            return RepoDatabase(p)
        # Scan directory containing repo.db
        if (p / "repo.db").exists():
            return RepoDatabase(p / "repo.db")
        # Source repo path → derive DB location
        db_path = get_repo_db_path(repo_path)
    else:
        # Try current directory: first check for repo.db here, then derive
        import os

        cwd = Path(os.getcwd())
        if (cwd / "repo.db").exists():
            return RepoDatabase(cwd / "repo.db")
        db_path = get_repo_db_path(os.getcwd())

    if not db_path.exists():
        return None

    return RepoDatabase(db_path)


# ─────────────────────────────────────────────────────────────────────────────
# argparse registration
# ─────────────────────────────────────────────────────────────────────────────


def add_aliases_parser(subparsers):
    """Register `reachctl aliases` with argparse."""
    p = subparsers.add_parser(
        "aliases",
        help="View and manage unresolved package suggestions",
        description=__doc__,
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    p.set_defaults(func=aliases_command)
    p.add_argument("--repo", metavar="PATH", help="Path to repo (defaults to cwd)")

    sub = p.add_subparsers(dest="aliases_subcmd")

    # show
    show_p = sub.add_parser("show", help="Show unresolved packages ranked by frequency")
    show_p.add_argument("--all", action="store_true", help="Include previously resolved packages")
    show_p.add_argument("--repo", metavar="PATH", help="Path to repo")

    # accept
    accept_p = sub.add_parser("accept", help="Accept best-guess alias")
    accept_p.add_argument("name", help="Package name")
    accept_p.add_argument("ecosystem", help="Ecosystem (python|npm|go|maven)")
    accept_p.add_argument("--repo", metavar="PATH", help="Path to repo")

    # dismiss
    dismiss_p = sub.add_parser("dismiss", help="Mark as genuinely private")
    dismiss_p.add_argument("name", help="Package name")
    dismiss_p.add_argument("ecosystem", help="Ecosystem (python|npm|go|maven)")
    dismiss_p.add_argument("--repo", metavar="PATH", help="Path to repo")

    return p
