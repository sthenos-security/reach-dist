#!/usr/bin/env python3
# Copyright (c) 2026 Sthenos Security. All rights reserved.
"""
reachctl license — license management subcommand.

Usage:
  reachctl license show                        # display current license status
  reachctl license verify                      # verify without running a scan
  reachctl license install <license.json>      # install a license file
"""

import json
import sys
from pathlib import Path


def license_command(args):
    """Dispatch license subcommands (called from main.py)."""
    action = getattr(args, "license_action", None) or "show"

    if action == "show":
        _cmd_show()
    elif action == "verify":
        _cmd_verify()
    elif action == "install":
        _cmd_install(args)
    else:
        print(f"Unknown license action: {action}", file=sys.stderr)
        sys.exit(1)


def _cmd_show():
    """Display current license status."""
    from reachable.licensing import check
    state = check()
    _print_license_state(state)


def _cmd_verify():
    """Verify license validity without running a scan."""
    from reachable.licensing import check
    state = check()
    _print_license_state(state)
    sys.exit(0 if state.valid else 1)


def _cmd_install(args):
    """Install a license file to ~/.reachable/license.json."""
    from reachable.licensing import check

    license_file = getattr(args, "license_file", None)
    if not license_file:
        print("Error: license install requires a FILE argument", file=sys.stderr)
        print("Usage: reachctl license install <license.json>", file=sys.stderr)
        sys.exit(1)

    src = Path(license_file)
    if not src.exists():
        print(f"Error: license file not found: {src}", file=sys.stderr)
        sys.exit(1)

    dst = Path.home() / ".reachable" / "license.json"

    try:
        raw = json.loads(src.read_text())
    except Exception as e:
        print(f"Error: cannot read license file: {e}", file=sys.stderr)
        sys.exit(1)

    dst.parent.mkdir(parents=True, exist_ok=True)
    dst.write_text(json.dumps(raw, indent=2))

    stamp = Path.home() / ".reachable" / ".license_install"
    if stamp.exists() and raw.get("license_type") == "trial":
        stamp.unlink()
        print("  Trial clock reset.")

    state = check()
    if state.valid:
        print("License installed successfully.")
        _print_license_state(state)
    else:
        print(f"Error: license installed but failed verification: {state.error}", file=sys.stderr)
        sys.exit(1)


def _print_license_state(state):
    """Pretty-print a LicenseState to terminal."""
    print()
    if not state.valid:
        print("  Status:   INVALID")
        print(f"  Error:    {state.error}")
        print()
        return

    status_label = {"active": "ACTIVE", "expiring_soon": "EXPIRING SOON",
                    "expired": "EXPIRED"}.get(state.status, state.status.upper())
    print(f"  Status:   {status_label}")
    print(f"  Type:     {state.license_type}")
    if getattr(state, "customer", None):
        print(f"  Customer: {state.customer}")
    if getattr(state, "email", None):
        print(f"  Email:    {state.email}")
    if getattr(state, "expires_at", None):
        print(f"  Expires:  {state.expires_at[:10]}")
    days = getattr(state, "days_remaining", None)
    if days is not None:
        print(f"  Remaining: {days} day{'s' if days != 1 else ''}")
    if getattr(state, "license_id", None):
        print(f"  ID:       {state.license_id}")
    print()
