# REACHABLE Installation & Deployment Guide

**Version 1.0.0** | January 2026

---

## Supported Platforms

| Platform | Architecture | Supported |
|----------|--------------|-----------|
| Linux | x86_64 | ✅ Yes |
| Linux | ARM64 | ✅ Yes |
| macOS | Intel (x86_64) | ✅ Yes |
| macOS | Apple Silicon (ARM64) | ✅ Yes |
| Windows | x86_64 | ❌ **Not Supported** |

> ⚠️ **Windows is not supported.** REACHABLE depends on security tools (syft, grype) that are designed for Unix-like systems. Windows users should use WSL2 (Windows Subsystem for Linux) instead.

---

## Where to Get REACHABLE

### Download Location

REACHABLE is distributed via **GitHub Releases**.

**URL:**
```
https://github.com/sthenos-security/reach-dist/releases
```

> 📧 **Don't have access?** Contact **sales@reachable.dev**

---

## Installation

### Prerequisites

| Requirement | Version | Check Command |
|-------------|---------|---------------|
| Python | 3.9 or higher | `python3 --version` |
| pip | Latest | `pip --version` |
| Git | 2.0+ | `git --version` |

### Step 1: Download

Download the wheel for your platform:

```bash
# Linux x86_64
curl -LO https://github.com/sthenos-security/reach-dist/releases/download/v1.0.0-beta1/reachable-1.0.0b0-cp311-cp311-linux_x86_64.whl

# Linux ARM64
curl -LO https://github.com/sthenos-security/reach-dist/releases/download/v1.0.0-beta1/reachable-1.0.0b0-cp311-cp311-linux_aarch64.whl

# macOS Apple Silicon
curl -LO https://github.com/sthenos-security/reach-dist/releases/download/v1.0.0-beta1/reachable-1.0.0b0-cp311-cp311-macosx_14_0_arm64.whl

# macOS Intel
curl -LO https://github.com/sthenos-security/reach-dist/releases/download/v1.0.0-beta1/reachable-1.0.0b0-cp311-cp311-macosx_13_0_x86_64.whl
```

### Step 2: Verify Integrity (Recommended)

```bash
# Download checksum
curl -LO https://github.com/sthenos-security/reach-dist/releases/download/v1.0.0-beta1/checksums.sha256

# Verify
sha256sum -c checksums.sha256
# ✅ Expected: reachable-1.0.0b0-*.whl: OK
```

### Step 3: Install

```bash
pip install reachable-1.0.0b0-*.whl
```

### Step 4: Install Required External Tools

REACHABLE requires **Syft** (SBOM) and **Grype** (CVE scanning):

**macOS:**
```bash
brew install syft grype
```

**Ubuntu/Debian:**
```bash
# Syft
curl -sSfL https://raw.githubusercontent.com/anchore/syft/main/install.sh | sudo sh -s -- -b /usr/local/bin

# Grype
curl -sSfL https://raw.githubusercontent.com/anchore/grype/main/install.sh | sudo sh -s -- -b /usr/local/bin
```

**RHEL/CentOS/Fedora:**
```bash
# Syft
curl -sSfL https://raw.githubusercontent.com/anchore/syft/main/install.sh | sudo sh -s -- -b /usr/local/bin

# Grype  
curl -sSfL https://raw.githubusercontent.com/anchore/grype/main/install.sh | sudo sh -s -- -b /usr/local/bin
```

### Step 5: Verify Installation

```bash
reachctl selftest
```

**Expected Output:**
```
✅ Python 3.11.x
✅ Syft v1.x.x
✅ Grype v0.x.x
✅ Semgrep 1.x.x
✅ All checks passed!
```

---

## Uninstalling

```bash
pip uninstall reachable
```

---

## Running Scans

### Basic Usage

```bash
reachctl scan /path/to/your/project
```

### Common Options

```bash
# Quick scan (faster, less thorough)
reachctl scan /path/to/project --quick

# Debug mode (verbose output)
reachctl scan /path/to/project --debug

# No dashboard generation
reachctl scan /path/to/project --no-dashboard
```

---

## Viewing Results

### Interactive Dashboard

After each scan, open the HTML dashboard:

**macOS:**
```bash
open ~/.reachable/scans/{project-name}/latest/dashboard/index.html
```

**Linux:**
```bash
xdg-open ~/.reachable/scans/{project-name}/latest/dashboard/index.html
```

---

## Windows Users (WSL2)

Windows is not directly supported. Use **WSL2** (Windows Subsystem for Linux):

1. Install WSL2: https://docs.microsoft.com/en-us/windows/wsl/install
2. Install Ubuntu from Microsoft Store
3. Open Ubuntu terminal
4. Follow Linux installation instructions above

---

## Troubleshooting

### Common Issues

| Issue | Solution |
|-------|----------|
| `reachctl: command not found` | Add to PATH: `export PATH="$HOME/.reachable/bin:$PATH"` |
| `syft: command not found` | Install Syft: `brew install syft` or see installation section |
| `grype: command not found` | Install Grype: `brew install grype` or see installation section |
| `Permission denied` | Run: `rm -rf ~/.reachable && bash install.sh` |
| `GitHub rate limit exceeded` | Set `GITHUB_TOKEN` environment variable |

### Getting Debug Information

```bash
# Run with verbose output
reachctl scan /path/to/project --debug

# Check tool versions
reachctl selftest

# Check REACHABLE version
reachctl --version
```

---

## Support

| Channel | Contact |
|---------|---------|
| **Email** | support@reachable.dev |
| **Enterprise** | enterprise@reachable.dev |
| **Sales** | sales@reachable.dev |

---

## Quick Reference

```
┌─────────────────────────────────────────────────────────────┐
│                 REACHABLE QUICK REFERENCE                   │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  INSTALL         pip install reachable-*.whl               │
│  UNINSTALL       pip uninstall reachable                   │
│  SCAN            reachctl scan /path/to/repo               │
│  VERIFY          reachctl selftest                         │
│  VERSION         reachctl --version                        │
│  DASHBOARD       open ~/.reachable/scans/{repo}/latest/    │
│                       dashboard/index.html                  │
│                                                             │
│  SUPPORTED: Linux, macOS                                    │
│  NOT SUPPORTED: Windows (use WSL2)                          │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

---

**© 2026 Sthenos Security. All Rights Reserved.**
