# SLA (Service Level Agreement) Framework

**Version:** 2.0.0  
**Date:** 2026-01-22  
**Status:** Active

## Overview

SLA defines remediation timelines based on **severity** (not finding type). All findings—CVE, DLP, AI, CWE, Secrets—use the same SLA once severity is determined.

**Key Principle:** SLA is driven by final severity. The severity classification system (see `dlp/SEVERITY_CLASSIFICATION.md`) determines severity, then SLA applies uniformly.

## Default SLA Timelines

| Severity | Timeline | Rationale |
|----------|----------|-----------|
| 🔴 **CRITICAL** | 24 hours | Active exploitation risk, catastrophic data exposure |
| 🟠 **HIGH** | 7 days (168 hours) | Significant risk, requires prompt attention |
| 🟡 **MEDIUM** | 30 days (720 hours) | Moderate risk, normal remediation cycle |
| 🟢 **LOW** | 90 days (2160 hours) | Minimal risk, address in regular maintenance |

## Compliance Framework SLAs

Organizations may have stricter SLAs based on compliance requirements:

### International Standards

| Framework | CRITICAL | HIGH | MEDIUM | LOW |
|-----------|----------|------|--------|-----|
| **ISO 27001** | 72h | 30d | 90d | 180d |
| **SOC 2** | 72h | 30d | 90d | N/A |

### Industry Regulations

| Framework | CRITICAL | HIGH | MEDIUM | LOW |
|-----------|----------|------|--------|-----|
| **PCI-DSS** | 24h | 30d | 90d | 180d |
| **HIPAA** | 48h | 30d | 60d | 180d |

### US Federal

| Framework | CRITICAL | HIGH | MEDIUM | LOW |
|-----------|----------|------|--------|-----|
| **FedRAMP High** | 24h | 30d | 90d | 180d |
| **FedRAMP Moderate** | 72h | 30d | 90d | 1yr |
| **FISMA High** | 24h | 30d | 90d | 180d |
| **FISMA Moderate** | 72h | 30d | 90d | 1yr |
| **NIST 800-53** | 24h | 30d | 90d | 180d |
| **NIST 800-171** | 72h | 30d | 90d | 180d |
| **CISA BOD 22-01** | 24h | - | - | - |

### Defense

| Framework | CRITICAL | HIGH | MEDIUM | LOW |
|-----------|----------|------|--------|-----|
| **CMMC Level 2** | 72h | 30d | 90d | 180d |
| **CMMC Level 3** | 24h | 30d | 90d | 180d |
| **DISA STIG** | 24h | 30d | 90d | 180d |

## SLA by Finding Type

SLA is **NOT** determined by finding type. All finding types use the same SLA once severity is established:

| Finding Type | Severity Source | SLA |
|--------------|-----------------|-----|
| **CVE** | CVSS score + reachability | Standard SLA based on final severity |
| **DLP** | Sensitivity tier × reachability | Standard SLA based on final severity |
| **AI/LLM** | OWASP LLM category + reachability | Standard SLA based on final severity |
| **CWE** | CWE severity + reachability | Standard SLA based on final severity |
| **Secrets** | Secret type + exposure | Standard SLA based on final severity |
| **Config/IaC** | Misconfiguration severity | Standard SLA based on final severity |

## SLA Exceptions

### NOT_REACHABLE Findings

Findings with `reachability_state = NOT_REACHABLE` are excluded from SLA enforcement:
- They are dead code or test data
- They should still be tracked but not counted against SLA metrics
- Dashboard shows them separately as "Review" items

### Suppressed/Accepted Risk

Findings that have been:
- Suppressed with justification
- Accepted as known risk (with expiry date)
- Marked as false positive

Are excluded from SLA calculations.

## Dashboard Display

### Action Required Panel

The dashboard groups findings by SLA urgency:

1. **"X issues require immediate attention"**
   - CRITICAL severity
   - REACHABLE or UNKNOWN reachability
   - SLA: 24 hours

2. **"X issues to fix within the next few weeks"**
   - HIGH severity
   - REACHABLE or UNKNOWN reachability
   - SLA: 7 days

3. **"X issues require review"**
   - UNKNOWN reachability (any severity)
   - Need triage to determine actual reachability

### SLA Column

The Security Issues table shows:
- Suggested remediation time (e.g., "24h", "7d", "30d")
- Color-coded by urgency
- No countdown timer (removed in v4.4.6)

## Implementation

### JavaScript (Dashboard)

```javascript
const GRC_SLA_TIMELINES = {
    'default':          { CRITICAL: 24,  HIGH: 168,  MEDIUM: 720,  LOW: 2160 },
    'pci-dss':          { CRITICAL: 24,  HIGH: 720,  MEDIUM: 2160, LOW: 4320 },
    'hipaa':            { CRITICAL: 48,  HIGH: 720,  MEDIUM: 1440, LOW: 4320 },
    'fedramp-high':     { CRITICAL: 24,  HIGH: 720,  MEDIUM: 2160, LOW: 4320 },
    // ... etc
};

function getSLA(severity, framework = 'default') {
    const timelines = GRC_SLA_TIMELINES[framework] || GRC_SLA_TIMELINES['default'];
    return timelines[severity] || timelines['MEDIUM'];
}

function formatSLA(hours) {
    if (hours <= 24) return `${hours}h`;
    if (hours <= 168) return `${Math.round(hours / 24)}d`;
    return `${Math.round(hours / 720)}mo`;
}
```

### Python (Backend)

```python
from enum import Enum
from typing import Optional

class SLATimeline(Enum):
    """SLA timelines in hours."""
    CRITICAL = 24
    HIGH = 168      # 7 days
    MEDIUM = 720    # 30 days
    LOW = 2160      # 90 days

def get_sla_hours(severity: str, framework: str = 'default') -> Optional[int]:
    """Get SLA hours for a severity level."""
    timelines = {
        'default': {'CRITICAL': 24, 'HIGH': 168, 'MEDIUM': 720, 'LOW': 2160},
        'pci-dss': {'CRITICAL': 24, 'HIGH': 720, 'MEDIUM': 2160, 'LOW': 4320},
        # ... etc
    }
    fw = timelines.get(framework, timelines['default'])
    return fw.get(severity.upper())
```

## Metrics & Reporting

### SLA Compliance Rate

```
SLA Compliance % = (Findings remediated within SLA / Total findings) × 100
```

### Mean Time to Remediate (MTTR)

Track MTTR by:
- Severity level
- Finding type
- Team/owner
- Compliance framework

### Overdue Findings

Count of findings past their SLA deadline, grouped by:
- Days overdue
- Severity
- Owner

## Changelog

- **v2.0.0** (2026-01-22): Aligned SLA with new severity classification. SLA based on final severity, not finding type.
- **v1.0.0** (2026-01-15): Initial SLA framework with compliance timelines.
