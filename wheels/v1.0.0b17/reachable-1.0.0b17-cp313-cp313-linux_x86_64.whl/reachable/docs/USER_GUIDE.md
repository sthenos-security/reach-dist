# REACHABLE User Guide

**Version 4.5.7** | Last Updated: January 2026

---

## Table of Contents

1. [Overview](#overview)
2. [System Requirements](#system-requirements)
3. [Installation](#installation)
4. [Configuration](#configuration)
5. [Running Scans](#running-scans)
6. [Understanding Results](#understanding-results)
7. [Logs and Troubleshooting](#logs-and-troubleshooting)
8. [Support](#support)

---

## Overview

REACHABLE is a vulnerability assessment platform that goes beyond traditional scanners by analyzing **reachability** — determining which vulnerabilities in your dependencies can actually be exploited based on your code's execution paths.

### Key Features

- **CVE Reachability Analysis** — Filter out 85%+ of CVE noise
- **Secrets Detection** — Find exposed credentials in code
- **DLP/PII Detection** — Detect hardcoded PII and data flowing to dangerous sinks
- **Malware Detection** — Identify malicious packages
- **Code Weakness Scanning** — CWE-based security analysis
- **AI/LLM Security** — OWASP LLM Top 10 coverage
- **Compliance Mapping** — OWASP, PCI-DSS, SOC2, HIPAA, FedRAMP, GDPR, CCPA
- **Interactive Dashboard** — Visual risk assessment

### How It Works

```
Your Code → SBOM Generation → Vulnerability Scan → Reachability Analysis → Risk Score
                                      ↓
                              Only REACHABLE issues
                              require immediate action
```

---

## System Requirements

### Supported Platforms

| Platform | Architecture | Status |
|----------|--------------|--------|
| macOS 12+ | Intel (x86_64) | ✅ Supported |
| macOS 12+ | Apple Silicon (arm64) | ✅ Supported |
| Ubuntu 20.04+ | x86_64 | ✅ Supported |
| Debian 11+ | x86_64 | ✅ Supported |
| RHEL/CentOS 8+ | x86_64 | ✅ Supported |
| Windows | x86_64 | ⚠️ WSL2 Required |

### Prerequisites

| Requirement | Version | Purpose |
|-------------|---------|---------|
| Python | 3.9+ | Runtime |
| Git | 2.0+ | Library cloning |
| Syft | Latest | SBOM generation |
| Grype | Latest | CVE scanning |

### Optional Tools

| Tool | Purpose | Install |
|------|---------|---------|
| Semgrep | CWE/Secrets scanning | `pip install semgrep` |
| TruffleHog | Active secret validation | `brew install trufflehog` |
| Docker | Behavioral sandbox | Docker Desktop |

---

## Installation

### Step 1: Download REACHABLE

Download the latest wheel from the releases page:

```bash
# Option A: Direct download
curl -LO https://github.com/ORGANIZATION/reachable-releases/releases/download/v4.5.7/reachable-4.5.7-py3-none-any.whl

# Option B: Using wget
wget https://github.com/ORGANIZATION/reachable-releases/releases/download/v4.5.7/reachable-4.5.7-py3-none-any.whl
```

> **Note:** Replace `ORGANIZATION` with the GitHub organization provided by your administrator.

### Step 2: Verify Download (Recommended)

```bash
# Download checksum file
curl -LO https://github.com/ORGANIZATION/reachable-releases/releases/download/v4.5.7/checksums.sha256

# Verify integrity
sha256sum -c checksums.sha256
# Expected output: reachable-4.5.7-py3-none-any.whl: OK
```

### Step 3: Install

```bash
# Install the wheel
pip install reachable-4.5.7-py3-none-any.whl

# Verify installation
reachctl version
```

**Expected output:**
```
REACHABLE 4.5.7
Venv: ~/.reachable/venv (4.5.7)
```

### Step 4: Install External Tools

REACHABLE requires Syft and Grype for SBOM and CVE scanning:

**macOS (Homebrew):**
```bash
brew install syft grype
```

**Linux (curl):**
```bash
# Syft
curl -sSfL https://raw.githubusercontent.com/anchore/syft/main/install.sh | sh -s -- -b /usr/local/bin

# Grype
curl -sSfL https://raw.githubusercontent.com/anchore/grype/main/install.sh | sh -s -- -b /usr/local/bin
```

### Step 5: Verify Setup

```bash
reachctl selftest
```

**Expected output:**
```
✅ Python 3.11.0
✅ Syft v1.0.0
✅ Grype v0.74.0
✅ Semgrep 1.50.0
✅ All checks passed
```

---

## Configuration

### Environment Variables

| Variable | Purpose | Default |
|----------|---------|---------|
| `REACHABLE_HOME` | Data directory | `~/.reachable` |
| `GITHUB_TOKEN` | Library cloning (private repos) | None |
| `SEMGREP_TIMEOUT` | Semgrep scan timeout | `300` (seconds) |

### Setting GitHub Token (Required for Private Libraries)

If your project depends on private GitHub repositories:

```bash
# Option 1: Export in shell
export GITHUB_TOKEN="ghp_xxxxxxxxxxxxxxxxxxxx"

# Option 2: Add to ~/.bashrc or ~/.zshrc
echo 'export GITHUB_TOKEN="ghp_xxxxxxxxxxxxxxxxxxxx"' >> ~/.zshrc

# Option 3: Use GitHub CLI
gh auth login
export GITHUB_TOKEN=$(gh auth token)
```

### Directory Structure

After first run, REACHABLE creates:

```
~/.reachable/
├── venv/                  # Python virtual environment
├── scans/                 # Scan results
│   └── {project-name}/
│       ├── latest/        # Symlink to most recent scan
│       └── {branch}/
│           └── {timestamp}/
│               ├── scan.log
│               ├── scan.db
│               ├── dashboard/
│               │   └── index.html
│               └── raw/   # (if --legacy-raw)
└── cache/                 # Downloaded libraries cache
```

---

## Running Scans

### Basic Scan

```bash
reachctl scan /path/to/your/project
```

### Common Options

```bash
# Specify output directory
reachctl scan /path/to/project --output ./results

# Enable secret validation (checks if secrets are active)
reachctl scan /path/to/project --verify-secrets

# Skip AI/LLM analysis (faster)
reachctl scan /path/to/project --no-ai

# Skip DLP/PII analysis
reachctl scan /path/to/project --no-dlp

# Skip behavioral sandbox (faster)
reachctl scan /path/to/project --no-sandbox

# Verbose output (debugging)
reachctl scan /path/to/project --debug

# Quiet mode (minimal output)
reachctl scan /path/to/project --quiet
```

### Full Options Reference

```
reachctl scan [OPTIONS] REPO

Arguments:
  REPO                    Path to repository to scan

Options:
  -o, --output PATH       Output directory (default: ~/.reachable/scans/{repo})
  -l, --libs PATH         Libraries directory (default: {output}/libs)
  --no-sandbox            Skip behavioral sandbox analysis
  --verify-secrets        Validate if secrets are active (requires network)
  --legacy-raw            Create raw/ JSON files (compatibility mode)
  --export-json           Export database to JSON after scan
  -q, --debug             Minimal output
  -v, --debug           Verbose output
  -h, --help              Show this help
```

### Example: Full Enterprise Scan

```bash
reachctl scan ~/src/my-application \
  --output ~/security-reports/my-app \
  --verify-secrets \
  --debug
```

---

## Understanding Results

### Risk Score

REACHABLE produces a risk score from 0-1000:

| Score | Level | Action |
|-------|-------|--------|
| 0-100 | LOW | Monitor |
| 101-300 | MEDIUM | Plan remediation |
| 301-600 | HIGH | Prioritize fixes |
| 601-1000 | CRITICAL | Immediate action |

### Dashboard

After each scan, an interactive HTML dashboard is generated:

```bash
# Open dashboard (macOS)
open ~/.reachable/scans/{project}/latest/dashboard/index.html

# Open dashboard (Linux)
xdg-open ~/.reachable/scans/{project}/latest/dashboard/index.html
```

### Dashboard Features

- **Noise Reduction Funnel** — Shows filtering effectiveness
- **Risk Breakdown** — By severity, type, and reachability
- **Compliance View** — Filter by OWASP, PCI-DSS, etc.
- **SLA Tracking** — By GRC framework (FedRAMP, SOC2, etc.)
- **Remediation Table** — Sortable, filterable issue list

### Issue Categories

| Category | Description | Reachability |
|----------|-------------|--------------|
| CVE | Known vulnerabilities in dependencies | ✅/❌ Analyzed |
| SECRET | Exposed credentials | ✅/❌ Analyzed |
| CWE | Code weaknesses (app code) | ✅/❌ Analyzed |
| DLP | Hardcoded PII and data flowing to sinks | ✅/❌ Analyzed |
| AI | AI/LLM security issues (OWASP LLM Top 10) | ✅/❌ Analyzed |
| CONFIG | Platform misconfigurations (Dockerfile, K8s) | ❓ Unknown |
| MALWARE | Malicious packages (confirmed) | ⚠️ Always critical |
| SUSPICIOUS | Potentially malicious packages | ⚠️ Review needed |

### Reachability States

| State | Icon | Meaning |
|-------|------|---------|
| REACHABLE | ✅ | Code path exists from entrypoint |
| NOT_REACHABLE | ⬜ | No code path found — lower priority |
| UNKNOWN | ❓ | Cannot determine (platform/config code) |

---

## Logs and Troubleshooting

### Log Locations

| Log | Location | Purpose |
|-----|----------|---------|
| Scan log | `~/.reachable/scans/{project}/{branch}/{timestamp}/scan.log` | Full scan output |
| Latest scan | `~/.reachable/scans/{project}/latest/scan.log` | Most recent scan |

### Viewing Logs

```bash
# View latest scan log
cat ~/.reachable/scans/{project}/latest/scan.log

# Follow log in real-time during scan (in another terminal)
tail -f ~/.reachable/scans/{project}/latest/scan.log

# Search for errors
grep -i error ~/.reachable/scans/{project}/latest/scan.log
```

### Common Issues

#### "Syft not found"

```bash
# Install Syft
brew install syft  # macOS
# or
curl -sSfL https://raw.githubusercontent.com/anchore/syft/main/install.sh | sh -s -- -b /usr/local/bin
```

#### "Grype not found"

```bash
# Install Grype
brew install grype  # macOS
# or
curl -sSfL https://raw.githubusercontent.com/anchore/grype/main/install.sh | sh -s -- -b /usr/local/bin
```

#### "Permission denied" errors

```bash
# Fix permissions on REACHABLE directory
chmod -R u+rwX ~/.reachable
```

#### Semgrep timeout

```bash
# Increase timeout (default 300s)
export SEMGREP_TIMEOUT=600
reachctl scan /path/to/project
```

#### "GitHub rate limit exceeded"

```bash
# Set GitHub token for authenticated requests
export GITHUB_TOKEN="ghp_xxxxxxxxxxxxxxxxxxxx"
```

#### Scan seems stuck

Large codebases may take time. Check progress:
```bash
# In another terminal
tail -f ~/.reachable/scans/{project}/latest/scan.log
```

### Resetting REACHABLE

If you encounter persistent issues:

```bash
# Clear venv and reinstall
rm -rf ~/.reachable/venv
reachctl setup

# Clear all cached data (keeps scan history)
rm -rf ~/.reachable/cache

# Full reset (removes everything)
rm -rf ~/.reachable
```

---

## Support

### Getting Help

1. **Documentation**: Check this guide and `reachctl --help`
2. **Logs**: Review scan logs for error details
3. **Support Portal**: [support.reachable.dev](https://support.reachable.dev)
4. **Email**: support@reachable.dev

### Reporting Issues

When contacting support, please include:

1. **REACHABLE version**: `reachctl version`
2. **Operating system**: `uname -a`
3. **Python version**: `python3 --version`
4. **Scan log**: `~/.reachable/scans/{project}/latest/scan.log`
5. **Error message**: Full error text

### Enterprise Support

Enterprise customers with SLA agreements can contact:

- **Priority Support**: enterprise-support@reachable.dev
- **Phone**: Available to Enterprise tier customers
- **Slack**: Private channel (if configured)

### Feature Requests

Submit feature requests via:
- Email: feedback@reachable.dev
- Support Portal: [support.reachable.dev/feedback](https://support.reachable.dev/feedback)

---

## Quick Reference

### Cheat Sheet

```bash
# Install
pip install reachable-4.5.7-py3-none-any.whl

# Basic scan
reachctl scan /path/to/repo

# With secret validation
reachctl scan /path/to/repo --verify-secrets

# View dashboard
open ~/.reachable/scans/{repo}/latest/dashboard/index.html

# View logs
cat ~/.reachable/scans/{repo}/latest/scan.log

# Check version
reachctl version

# Run self-test
reachctl selftest

# View documentation
reachctl docs              # Quick start
reachctl docs install      # Installation guide
reachctl docs guide        # Full user guide
reachctl docs --online     # Open docs website
```

### Key Paths

| Path | Purpose |
|------|---------|
| `~/.reachable/` | REACHABLE home directory |
| `~/.reachable/scans/` | All scan results |
| `~/.reachable/scans/{repo}/latest/` | Latest scan for a repo |
| `~/.reachable/scans/{repo}/latest/dashboard/` | Dashboard HTML |
| `~/.reachable/scans/{repo}/latest/scan.log` | Scan log |
| `~/.reachable/scans/{repo}/latest/scan.db` | SQLite database |

---

**© 2026 Sthenos Security. All Rights Reserved.**

REACHABLE is proprietary software. Unauthorized distribution is prohibited.

## Exporting Results

### `reachctl export` — Key Concepts

Two arguments that are commonly confused:

| Argument | Purpose | Affects DB lookup? |
|---|---|---|
| `--repo /path/to/repo` | Finds `repo.db` via the slug path under `~/.reachable/scans/` | **Yes** — this is how the DB is found |
| `--repo-uri https://github.com/org/repo` | GitHub/GitLab URL embedded as metadata inside SARIF output | **No** — only used for Code Scanning links |

`--repo` defaults to `.` (current directory). Run from your repo root and you don't need to specify it.
`--repo-uri` is optional even for SARIF — it's auto-detected from `GITHUB_REPOSITORY` / `CI_PROJECT_URL` when running in CI.

### Formats

```bash
# Human-readable summary (quickest way to see what was found)
reachctl export --repo ~/src/myapp --format summary

# Full v2 JSON payload (same schema as the server API)
reachctl export --repo ~/src/myapp --format json

# Flat CSV (for spreadsheets / ticketing imports)
reachctl export --repo ~/src/myapp --format csv --output findings.csv

# SARIF 2.1.0 — upload to GitHub Code Scanning / GitLab SAST
reachctl export --repo ~/src/myapp --format sarif --output results.sarif

# SARIF with explicit repo URL (adds versionControlProvenance metadata)
reachctl export --repo ~/src/myapp --format sarif \
    --repo-uri https://github.com/org/myapp \
    --output results.sarif

# Specific scan ID instead of latest
reachctl export --repo ~/src/myapp --scan-id 47 --format summary

# Generate a GitHub Actions workflow file
reachctl export --format github-action \
    --output .github/workflows/reachable.yml
reachctl export --format github-action \
    --fail-on high --branch main \
    --output .github/workflows/reachable.yml
```

### Uploading SARIF to GitHub Code Scanning

```yaml
# In your GitHub Actions workflow:
- name: Export SARIF
  run: |
    reachctl export --repo ${{ github.workspace }} \
      --format sarif \
      --output results.sarif

- name: Upload to Code Scanning
  uses: github/codeql-action/upload-sarif@v3
  with:
    sarif_file: results.sarif
```

Findings appear under **Security → Code scanning alerts**.
Requires GitHub Advanced Security (available on public repos and GHES/GHAS).

### SARIF Content

The SARIF report contains only **actionable findings** — `reachable` and `unknown` reachability state.
`not_reachable` findings are excluded: the call graph confirmed no exploitable path exists for those.

| Severity | SARIF level | Effect in GitHub |
|---|---|---|
| CRITICAL / HIGH (reachable) | `error` | Blocks PRs when branch protection is on |
| CRITICAL / HIGH (unknown reachability) | `warning` | Visible but non-blocking |
| MEDIUM | `warning` | Visible but non-blocking |
| LOW / INFO | `note` | Informational |

Finding types included: CVE, SECRET, CWE, MALWARE, AI/LLM, DLP/PII.
