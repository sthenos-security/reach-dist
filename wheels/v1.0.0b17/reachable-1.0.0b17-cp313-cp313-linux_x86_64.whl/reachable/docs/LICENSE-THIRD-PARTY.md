# Third-Party Licenses — REACHABLE Distribution

This document accompanies the REACHABLE wheel (`reachable-*.whl`) and
discloses all third-party software shipped inside the package or required
at runtime.

## Bundled Python Dependencies

| Package | License | SPDX |
|---------|---------|------|
| click | BSD-3-Clause | `BSD-3-Clause` |
| requests | Apache-2.0 | `Apache-2.0` |
| PyYAML | MIT | `MIT` |

These are declared in `install_requires` and pulled by pip on install.

## External Tools (not bundled — installed separately)

REACHABLE invokes the following tools via subprocess when present on
`$PATH`. They are **not** included in the wheel.

| Tool | License | Note |
|------|---------|------|
| Semgrep | LGPL-2.1 | CWE/secret/config scanning |
| TruffleHog | **AGPL-3.0** | Secret scanning (see below) |
| GuardDog | MIT | Malware detection |
| Grype | Apache-2.0 | CVE scanning |
| Syft | Apache-2.0 | SBOM generation |
| Joern | Apache-2.0 | Call graph (Java/C) |
| Git | GPL-2.0 | Repository operations |

### ⚠ AGPL-3.0 Notice — TruffleHog

TruffleHog (`trufflehog`) is licensed under AGPL-3.0. REACHABLE invokes
it as a separate process and does not link against, embed, or modify its
source. No TruffleHog code is distributed in this wheel.

Users deploying REACHABLE as a network service should review AGPL-3.0
§13 and consult legal counsel regarding compliance when exposing
TruffleHog functionality over a network.

## Dashboard UI Assets

| Library | Version | License | Delivery |
|---------|---------|---------|----------|
| Chart.js | 4.4.1 | MIT | CDN or vendored inline |

## Data Sources Queried at Scan Time

| Source | License / Terms |
|--------|-----------------|
| NVD (NIST) | Public domain |
| GitHub Advisory DB | CC-BY-4.0 |
| CISA KEV Catalog | Public domain |
| FIRST.org EPSS | CC-BY-SA-4.0 |
| OSV.dev | Apache-2.0 |
| PyPI JSON API | PSF terms |

---

The full `THIRD_PARTY_NOTICES` file with additional detail (Semgrep rule
derivations, OWASP standard attributions) is included inside the wheel
at `reachable/THIRD_PARTY_NOTICES`.

Questions: legal@sthenosec.com
