# REACHABLE Quick Start

## 1. Install

```bash
pip install reachable-4.5.7-py3-none-any.whl
```

## 2. Install Dependencies

**macOS:**
```bash
brew install syft grype
```

**Linux:**
```bash
curl -sSfL https://raw.githubusercontent.com/anchore/syft/main/install.sh | sh -s -- -b /usr/local/bin
curl -sSfL https://raw.githubusercontent.com/anchore/grype/main/install.sh | sh -s -- -b /usr/local/bin
```

## 3. Run a Scan

```bash
reachctl scan /path/to/your/project
```

## 4. View Results

```bash
# macOS
open ~/.reachable/scans/your-project/latest/dashboard/index.html

# Linux
xdg-open ~/.reachable/scans/your-project/latest/dashboard/index.html
```

## Common Commands

| Command | Description |
|---------|-------------|
| `reachctl scan <path>` | Scan a repository |
| `reachctl scan <path> --debug` | Scan with full debug output |
| `reachctl scan <path> --no-ai` | Skip AI/LLM analysis (faster) |
| `reachctl scan <path> --no-dlp` | Skip DLP/PII analysis |
| `reachctl scan <path> --ci --fail-on high` | CI mode with exit code gate |
| `reachctl dashboard --open` | Open latest dashboard in browser |
| `reachctl version` | Show version |
| `reachctl selftest` | Verify installation |
| `reachctl primer` | Full interactive reference (paged) |

## Exporting Results

```bash
# Human-readable summary of latest scan
reachctl export --repo ~/src/myapp --format summary

# SARIF for GitHub Code Scanning
# --repo = finds the database   --repo-uri = metadata only (GitHub URL)
reachctl export --repo ~/src/myapp --format sarif --output results.sarif
reachctl export --repo ~/src/myapp --format sarif \
    --repo-uri https://github.com/org/myapp \
    --output results.sarif

# CSV for ticketing / spreadsheets
reachctl export --repo ~/src/myapp --format csv --output findings.csv
```

## AI-Powered Remediation (enzo)

enzo auto-fixes security findings — generates patches, validates them, and
optionally commits clean fixes. Uses Claude API (cloud) or Ollama (local).

**Typical workflow:**

```bash
# 1. Scan first
reachctl scan ~/src/myapp

# 2. See what enzo can fix
reachctl enzo scan ~/src/myapp

# 3. Preview patches without applying anything
reachctl enzo run ~/src/myapp --dry-run

# 4. Apply fixes (local model — code never leaves your machine)
reachctl enzo run ~/src/myapp --mode local

# 5. Apply fixes (Claude API — sends source code to API)
reachctl enzo run ~/src/myapp --mode cloud

# 6. Fix one specific finding
reachctl enzo fix ~/src/myapp --finding-id CVE-2024-1234

# 7. Verify fixes with exploit payloads
reachctl enzo pentest ~/src/myapp
```

**Key flags:**

| Flag | Effect |
|------|--------|
| `--mode local` | Ollama generates patches. Code stays on machine. (default) |
| `--mode cloud` | Claude API generates patches. Source code sent to API. |
| `--mode both` | Claude advises (metadata only), Ollama writes the patch. |
| `--dry-run` | Generate patches but do not apply or commit. |
| `--reachable-only` | Only fix findings reachable in the call graph. |

**Setup:**

```bash
# Cloud mode — just set the API key, no local model needed
export ANTHROPIC_API_KEY=sk-ant-...

# Local mode — install Ollama first
brew install ollama && brew services start ollama   # macOS
curl -fsSL https://ollama.com/install.sh | sh       # Linux
reachctl enzo setup                                  # pull the model
```

See: `reachctl enzo --help`, `reachctl enzo run --help`

## CI/CD — Distributed Pipeline

```bash
# Initialize a session
SESSION=$(reachctl pipeline init /path/to/repo --json | jq -r .session_id)

# Sequential (required first — builds SBOM)
reachctl pipeline step scan --session $SESSION

# Parallel steps (run simultaneously on separate runners or background jobs)
reachctl pipeline step secrets --session $SESSION &
reachctl pipeline step malware --session $SESSION &
reachctl pipeline step health  --session $SESSION &
reachctl pipeline step iac     --session $SESSION &
reachctl pipeline step ai      --session $SESSION &
reachctl pipeline step dlp     --session $SESSION &
wait

# Finalize — merge results, generate dashboard, gate on severity
reachctl pipeline finalize --session $SESSION --fail-on high
```

Exit codes: `0` = clean, `1` = error, `2` = findings above threshold.

See pre-built workflow templates: `reach-dist-cicd/.github/workflows/`

## Logs

```bash
cat ~/.reachable/scans/<project>/latest/scan.log
```

## Support

- Email: info@sthenosec.com
- Full reference: `reachctl primer`
- Full docs: [USER_GUIDE.md](USER_GUIDE.md)
