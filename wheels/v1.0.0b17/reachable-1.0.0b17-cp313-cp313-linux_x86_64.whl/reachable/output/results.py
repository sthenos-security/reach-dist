#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.

"""
Enhanced Correlation Results - Comprehensive Security Metrics

Tracks all security dimensions:
- CVE details (severity, fix availability)
- Malware details (type, confidence, risk)
- Secrets details (type, severity, reachability)
- Attack surface metrics
- Threat intelligence
- OWASP Top 10 violations

Provides sophisticated metrics for dashboards and final JSON output.
"""

import json
import logging
from dataclasses import asdict, dataclass, field
from datetime import datetime
from typing import Dict, List

logger = logging.getLogger(__name__)


@dataclass
class CVEDetails:
    """Detailed CVE information"""

    cve_id: str
    severity: str  # CRITICAL, HIGH, MEDIUM, LOW
    cvss_score: float
    package_name: str
    package_version: str

    # Fix availability
    fix_available: bool = False
    fixed_version: str = ""
    fix_state: str = "unknown"  # fixed, wont-fix, unknown

    # Reachability
    is_reachable: bool = False
    reachable_functions: List[str] = field(default_factory=list)

    # Threat intelligence
    in_cisa_kev: bool = False
    epss_score: float = 0.0
    exploit_db_available: bool = False
    metasploit_available: bool = False

    # Age
    published_date: str = ""
    days_old: int = 0


@dataclass
class MalwareDetails:
    """Detailed malware information"""

    file_path: str
    malware_type: str  # exfiltration, backdoor, dropper, credential_harvester, etc.
    risk_level: str  # CRITICAL, HIGH, MEDIUM, LOW
    confidence: float  # 0.0 - 1.0

    # Detection sources
    detected_by: List[str] = field(default_factory=list)  # ['guarddog', 'semgrep', 'entropy', 'sast']

    # Specific indicators
    has_high_entropy: bool = False
    entropy_score: float = 0.0

    has_unpacker: bool = False
    unpacker_type: str = ""  # 'lzstring', 'aes', 'atob'

    has_obfuscation: bool = False
    obfuscation_patterns: List[str] = field(default_factory=list)

    has_evasion: bool = False
    evasion_tactics: List[str] = field(default_factory=list)

    # Network activity
    has_network_activity: bool = False
    suspicious_domains: List[str] = field(default_factory=list)

    # Provenance
    no_provenance: bool = False
    is_typosquatting: bool = False

    # Evidence
    evidence: Dict = field(default_factory=dict)


@dataclass
class SecretDetails:
    """Detailed secret information"""

    secret_type: str  # api_key, password, token, certificate, etc.
    severity: str  # CRITICAL, HIGH, MEDIUM, LOW
    file_path: str
    line_number: int

    # Reachability
    is_reachable: bool = False
    in_reachable_function: str = ""

    # Detection
    detected_by: str = ""  # 'semgrep', 'trufflehog'
    pattern_id: str = ""

    # Context
    is_in_code: bool = False
    is_in_config: bool = False
    is_in_comment: bool = False

    # Redacted value
    redacted_value: str = ""


@dataclass
class OWASPViolation:
    """OWASP Top 10 violation"""

    category: str  # Injection, Broken Authentication, etc.
    owasp_id: str  # A01, A02, etc.
    severity: str
    file_path: str
    line_number: int
    description: str
    cwe_id: str = ""


@dataclass
class AttackSurfaceMetrics:
    """Attack surface measurement"""

    # Entry points
    total_entry_points: int = 0
    exported_functions: int = 0
    api_endpoints: int = 0
    event_handlers: int = 0

    # Network exposure
    network_listeners: int = 0
    open_ports: List[int] = field(default_factory=list)

    # File system
    file_operations: int = 0
    sensitive_file_access: int = 0

    # Process operations
    child_processes: int = 0
    shell_executions: int = 0


@dataclass
class ComprehensiveCorrelationResults:
    """
    Complete correlation results with all security metrics

    This is the final JSON that gets saved and used by dashboards.
    """

    # Metadata
    scan_timestamp: str = field(default_factory=lambda: datetime.utcnow().isoformat())
    target_path: str = ""
    target_type: str = ""  # "local", "github", "monorepo"

    # === CVE Metrics ===
    total_cves: int = 0
    critical_cves: int = 0
    high_cves: int = 0
    medium_cves: int = 0
    low_cves: int = 0

    reachable_cves: int = 0
    unreachable_cves: int = 0

    cves_with_fix: int = 0
    cves_without_fix: int = 0

    # Threat intelligence
    cves_in_kev: int = 0
    cves_with_high_epss: int = 0  # > 0.7
    cves_with_exploits: int = 0

    # Detailed CVE list
    cve_details: List[CVEDetails] = field(default_factory=list)

    # === Malware Metrics ===
    total_malware_indicators: int = 0
    high_confidence_malware: int = 0  # 3+ signals

    # By type
    exfiltration: int = 0
    backdoors: int = 0
    droppers: int = 0
    credential_harvesters: int = 0
    cryptominers: int = 0
    supply_chain_attacks: int = 0

    # By detection method
    malware_by_guarddog: int = 0
    malware_by_semgrep: int = 0
    malware_by_entropy: int = 0
    malware_by_sast: int = 0
    malware_by_provenance: int = 0

    # Detailed malware list
    malware_details: List[MalwareDetails] = field(default_factory=list)

    # === Three-Tier Malware Detection Metrics ===
    malware_detection_metrics: Dict = field(
        default_factory=lambda: {
            "summary": {
                "total_packages_scanned": 0,
                "total_malicious_found": 0,
                "malicious_rate_percent": 0.0,
                "total_scan_time_ms": 0.0,
                "avg_scan_time_ms": 0.0,
                "scan_duration": None,
            },
            "tier_performance": {
                "tier1_guarddog": {
                    "packages_scanned": 0,
                    "packages_flagged": 0,
                    "detection_rate_percent": 0.0,
                    "avg_scan_time_ms": 0.0,
                    "severity_breakdown": {"critical": 0, "high": 0, "medium": 0, "low": 0},
                    "top_rules": [],
                },
                "tier2_yara": {
                    "packages_scanned": 0,
                    "packages_flagged": 0,
                    "detection_rate_percent": 0.0,
                    "avg_scan_time_ms": 0.0,
                    "severity_breakdown": {"critical": 0, "high": 0, "medium": 0, "low": 0},
                    "top_rules": [],
                },
                "tier3_deep": {
                    "packages_scanned": 0,
                    "packages_flagged": 0,
                    "detection_rate_percent": 0.0,
                    "avg_scan_time_ms": 0.0,
                    "severity_breakdown": {"critical": 0, "high": 0, "medium": 0, "low": 0},
                },
            },
            "escalation_funnel": {
                "tier1_flagged": 0,
                "tier1_to_tier2": 0,
                "tier2_to_tier3": 0,
                "tier3_confirmed": 0,
                "escalation_rate": {
                    "tier1_to_tier2_percent": 0.0,
                    "tier2_to_tier3_percent": 0.0,
                    "confirmation_rate_percent": 0.0,
                },
            },
            "malware_types": {
                "encrypted_payloads": 0,
                "obfuscated_code": 0,
                "exfiltration_attempts": 0,
                "environment_harvesting": 0,
                "install_script_abuse": 0,
            },
            "ecosystem_breakdown": {
                "npm": {"scanned": 0, "malicious": 0, "malicious_rate_percent": 0.0},
                "pypi": {"scanned": 0, "malicious": 0, "malicious_rate_percent": 0.0},
            },
            "efficiency_metrics": {
                "avg_time_per_tier": {"tier1_ms": 0.0, "tier2_ms": 0.0, "tier3_ms": 0.0},
                "tier_usage": {
                    "tier1_usage_percent": 100.0,
                    "tier2_usage_percent": 0.0,
                    "tier3_usage_percent": 0.0,
                },
                "time_saved_by_escalation": {
                    "description": "Time saved by not running expensive tiers on clean packages",
                    "potential_tier3_time_ms": 0.0,
                    "actual_tier3_time_ms": 0.0,
                    "time_saved_ms": 0.0,
                    "efficiency_gain_percent": 0.0,
                },
            },
        }
    )

    # Detailed per-package malware detections (for dashboard)
    malware_detections: Dict[str, Dict] = field(default_factory=dict)

    # === Secrets Metrics ===
    total_secrets: int = 0
    critical_secrets: int = 0
    high_secrets: int = 0

    reachable_secrets: int = 0
    unreachable_secrets: int = 0

    # By type
    api_keys: int = 0
    passwords: int = 0
    tokens: int = 0
    certificates: int = 0

    # Detailed secrets list
    secret_details: List[SecretDetails] = field(default_factory=list)

    # === OWASP Top 10 ===
    total_owasp_violations: int = 0
    owasp_by_category: Dict[str, int] = field(default_factory=dict)
    owasp_details: List[OWASPViolation] = field(default_factory=list)

    # === Attack Surface ===
    attack_surface: AttackSurfaceMetrics = field(default_factory=AttackSurfaceMetrics)

    # === Composite Risk ===
    packages_with_multiple_threats: int = 0
    functions_with_multiple_threats: int = 0
    files_with_multiple_threats: int = 0

    # High-risk combinations
    cve_plus_malware: int = 0
    cve_plus_secrets: int = 0
    malware_plus_secrets: int = 0
    all_three: int = 0

    # === Workload Reduction ===
    total_issues: int = 0
    live_issues: int = 0  # Reachable
    eliminated_issues: int = 0  # Unreachable
    workload_reduction_pct: float = 0.0
    time_saved_hours: float = 0.0

    # === Executive Summary ===
    risk_level: str = "UNKNOWN"  # CRITICAL, HIGH, MEDIUM, LOW
    overall_risk_score: int = 0  # 0-100

    top_recommendations: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict:
        """Convert to dictionary for JSON serialization"""
        return asdict(self)

    def to_json(self, indent: int = 2) -> str:
        """Convert to JSON string"""
        return json.dumps(self.to_dict(), indent=indent, default=str)

    def calculate_totals(self):
        """Calculate derived metrics"""
        # Total issues
        self.total_issues = (
            self.total_cves + self.total_malware_indicators + self.total_secrets + self.total_owasp_violations
        )

        # Live issues
        self.live_issues = self.reachable_cves + self.high_confidence_malware + self.reachable_secrets

        # Eliminated
        self.eliminated_issues = self.unreachable_cves + self.unreachable_secrets

        # Workload reduction
        if self.total_issues > 0:
            self.workload_reduction_pct = self.eliminated_issues / self.total_issues * 100
            self.time_saved_hours = self.eliminated_issues * 0.0833  # 5 min per issue

        # Overall risk score
        score = 0
        score += self.critical_cves * 10
        score += self.high_cves * 5
        score += self.high_confidence_malware * 15
        score += self.critical_secrets * 8
        score += self.cves_in_kev * 10
        score += self.packages_with_multiple_threats * 5

        self.overall_risk_score = min(score, 100)

        # Risk level
        if self.overall_risk_score >= 80:
            self.risk_level = "CRITICAL"
        elif self.overall_risk_score >= 60:
            self.risk_level = "HIGH"
        elif self.overall_risk_score >= 40:
            self.risk_level = "MEDIUM"
        elif self.overall_risk_score >= 20:
            self.risk_level = "LOW"
        else:
            self.risk_level = "MINIMAL"

    def get_dashboard_summary(self) -> Dict:
        """Get summary for HTML dashboard"""
        return {
            "executive_kpis": {
                "total_issues": self.total_issues,
                "live_issues": self.live_issues,
                "eliminated_issues": self.eliminated_issues,
                "workload_reduction_pct": round(self.workload_reduction_pct, 1),
                "time_saved_hours": round(self.time_saved_hours, 2),
            },
            "cve_breakdown": {
                "total": self.total_cves,
                "critical": self.critical_cves,
                "high": self.high_cves,
                "medium": self.medium_cves,
                "low": self.low_cves,
                "reachable": self.reachable_cves,
                "with_fix": self.cves_with_fix,
                "without_fix": self.cves_without_fix,
            },
            "malware_breakdown": {
                "total": self.total_malware_indicators,
                "high_confidence": self.high_confidence_malware,
                "by_type": {
                    "exfiltration": self.exfiltration,
                    "backdoors": self.backdoors,
                    "droppers": self.droppers,
                    "credential_harvesters": self.credential_harvesters,
                    "supply_chain": self.supply_chain_attacks,
                },
                "by_detector": {
                    "guarddog": self.malware_by_guarddog,
                    "semgrep": self.malware_by_semgrep,
                    "entropy": self.malware_by_entropy,
                    "sast": self.malware_by_sast,
                    "provenance": self.malware_by_provenance,
                },
            },
            "secrets_breakdown": {
                "total": self.total_secrets,
                "critical": self.critical_secrets,
                "reachable": self.reachable_secrets,
                "by_type": {
                    "api_keys": self.api_keys,
                    "passwords": self.passwords,
                    "tokens": self.tokens,
                    "certificates": self.certificates,
                },
            },
            "owasp_violations": {
                "total": self.total_owasp_violations,
                "by_category": self.owasp_by_category,
            },
            "attack_surface": asdict(self.attack_surface),
            "composite_threats": {
                "packages_multiple_threats": self.packages_with_multiple_threats,
                "cve_plus_malware": self.cve_plus_malware,
                "cve_plus_secrets": self.cve_plus_secrets,
                "all_three": self.all_three,
            },
            "risk_assessment": {
                "level": self.risk_level,
                "score": self.overall_risk_score,
                "recommendations": self.top_recommendations,
            },
        }

    def update_malware_metrics_from_scan(self, metrics_data):
        """
        Update malware detection metrics from MalwareDetectionMetrics object

        Args:
            metrics_data: MalwareDetectionMetrics instance from malware_metrics.py
        """
        if metrics_data is None:
            return

        # Convert metrics to dict and update
        self.malware_detection_metrics = metrics_data.to_dict()

        # Also update legacy malware counts for backward compatibility
        self.total_malware_indicators = metrics_data.total_malicious_found
        self.malware_by_guarddog = metrics_data.tier1_guarddog.packages_flagged

        # Update malware types from metrics
        if "malware_types" in self.malware_detection_metrics:
            types = self.malware_detection_metrics["malware_types"]
            self.exfiltration = types.get("exfiltration_attempts", 0)
            self.credential_harvesters = types.get("environment_harvesting", 0)

    def add_malware_detection(
        self,
        package_name: str,
        package_version: str,
        tier1_results: List[Dict] = None,
        tier2_results: List[Dict] = None,
        tier3_results: Dict = None,
        verdict: str = "MEDIUM",
        risk_score: int = 50,
    ):
        """
        Add detailed malware detection for a specific package

        Args:
            package_name: Package name
            package_version: Package version
            tier1_results: GuardDog detection results
            tier2_results: YARA detection results
            tier3_results: Deep scanner results
            verdict: CRITICAL, HIGH, MEDIUM, LOW
            risk_score: 0-100 risk score
        """
        package_key = f"{package_name}@{package_version}"

        self.malware_detections[package_key] = {
            "verdict": verdict,
            "risk_score": risk_score,
            "confidence": "HIGH" if tier3_results else "MEDIUM" if tier2_results else "LOW",
            "package_name": package_name,
            "package_version": package_version,
            "tier1_guarddog": tier1_results or [],
            "tier2_yara": tier2_results or [],
            "tier3_deep_scanner": tier3_results or {},
            "ecosystem": "npm" if "-" in package_name or "@" in package_name else "pypi",
        }


# Example usage
if __name__ == "__main__":
    # Create sample results
    results = ComprehensiveCorrelationResults(
        target_path="./myapp",
        target_type="local",
        total_cves=45,
        critical_cves=5,
        high_cves=12,
        medium_cves=20,
        low_cves=8,
        reachable_cves=15,
        unreachable_cves=30,
        cves_with_fix=35,
        cves_without_fix=10,
        total_malware_indicators=3,
        high_confidence_malware=2,
        exfiltration=1,
        backdoors=1,
        total_secrets=8,
        reachable_secrets=2,
    )

    # Calculate derived metrics
    results.calculate_totals()

    # Print summary
    logger.info(json.dumps(results.get_dashboard_summary(), indent=2))
