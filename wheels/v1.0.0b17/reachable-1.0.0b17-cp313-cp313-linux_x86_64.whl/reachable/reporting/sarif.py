#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.

"""
SARIF 2.1.0 Exporter — REACHABLE CI/CD Gate Report
====================================================

SARIF (Static Analysis Results Interchange Format) is the OASIS standard for
exchanging security findings between scanners and developer tooling:
  - GitHub Code Scanning  → inline PR annotations + Security tab
  - GitLab SAST           → Security dashboard + MR widgets
  - Azure DevOps          → Advanced Security findings
  - SonarQube / Qodana    → quality gate integration

Design principles
-----------------
1. **Actionable findings only.**
   SARIF is a CI gate report — it should block or annotate on things that
   require developer attention.  We emit only findings whose
   ``reachability_state`` is ``'reachable'`` or ``'unknown'``.
   ``'not_reachable'`` findings are excluded: the call graph confirmed no
   exploitable path, so there is nothing to block on.

2. **All security finding types.**
   CVE, SECRET, CWE, MALWARE, AI/LLM, and DLP are all emitted.  Excluding
   AI or DLP would create blind spots — a prompt-injection finding or an
   exposed PII sink is just as actionable as a CVE.

3. **Single data source.**
   All data comes from ``data['issues']`` — the same flat list that the
   dashboard reads, loaded from ``repo.db`` via ``loaders.py``.  There is no
   longer a ``reachable-report.json``; the DB is the source of truth
   (v5.1.3).  ``check_threshold()`` also reads from ``issues[]`` for
   consistency.

4. **Rule IDs are stable and hierarchical.**
   ``{TYPE}/{identifier}`` — e.g. ``CVE/CVE-2024-1234``, ``CWE/CWE-89``,
   ``SECRET/aws-access-key``, ``MALWARE/exec-base64``,
   ``AI/LLM01-prompt-injection``, ``DLP/pii-ssn``.
   Stable rule IDs mean GitHub/GitLab can track findings across PRs and
   avoid re-alerting on already-dismissed issues.

SARIF spec: https://docs.oasis-open.org/sarif/sarif/v2.1.0/sarif-v2.1.0.html
"""

import json
import logging
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from reachable import __version__

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

# REACHABLE severity → SARIF level
# CRITICAL and HIGH map to 'error' (blocks CI by default in GitHub).
# MEDIUM maps to 'warning' (visible but non-blocking).
# LOW/INFO map to 'note' (informational).
_SEV_TO_LEVEL: Dict[str, str] = {
    "CRITICAL": "error",
    "HIGH": "error",
    "MEDIUM": "warning",
    "LOW": "note",
    "INFO": "note",
}

# Reachability states that represent actionable findings.
# 'not_reachable' is excluded — call graph confirmed no exploitable path.
_ACTIONABLE_STATES = frozenset({"reachable", "unknown"})

# Severity ladder for --fail-on >= semantics
_SEVERITY_ORDER = {"critical": 3, "high": 2, "medium": 1, "low": 0, "any": -1, "none": -2}


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def export_to_sarif(
    data: Dict[str, Any],
    output_path: Optional[Path] = None,
    repo_uri: Optional[str] = None,
) -> Dict[str, Any]:
    """
    Export REACHABLE actionable findings to SARIF 2.1.0.

    Args:
        data:        Dashboard data dict (from ``loaders.get_dashboard_data()``
                     or ``data.json``).  The ``issues`` key is the primary
                     source; ``scan`` and ``metrics`` supply metadata.
        output_path: If provided, the SARIF document is written to this path
                     in addition to being returned.
        repo_uri:    Optional repository URI for artifact location context
                     (e.g. ``https://github.com/org/repo``).

    Returns:
        SARIF 2.1.0 document as a dict.
    """
    sarif = {
        "$schema": "https://raw.githubusercontent.com/oasis-tcs/sarif-spec/master/Schemata/sarif-schema-2.1.0.json",
        "version": "2.1.0",
        "runs": [_build_run(data, repo_uri)],
    }

    if output_path:
        output_path = Path(output_path)
        output_path.parent.mkdir(parents=True, exist_ok=True)
        output_path.write_text(json.dumps(sarif, indent=2))
        logger.info(f" SARIF written: {output_path}")

    return sarif


def check_threshold(
    data: Dict[str, Any],
    threshold: str,
) -> Tuple[bool, str]:
    """
    Check whether actionable findings breach the --fail-on threshold.

    ``--fail-on high`` means: exit 2 if there is at least one finding whose
    severity is HIGH **or** CRITICAL (i.e. >= high on the severity ladder).
    Only ``reachable`` and ``unknown`` findings are counted — same scope as
    the SARIF report.

    Args:
        data:      Dashboard data dict (same as ``export_to_sarif``).
        threshold: One of ``'critical'``, ``'high'``, ``'medium'``,
                   ``'any'``, ``'none'``.

    Returns:
        ``(should_fail: bool, reason: str)``
    """
    if threshold == "none":
        return False, "No threshold set"

    actionable = _get_actionable_issues(data)

    if threshold == "any":
        if actionable:
            return True, f"Found {len(actionable)} actionable finding(s)"
        return False, "No actionable findings"

    # Build severity counts at-or-above threshold
    threshold_order = _SEVERITY_ORDER.get(threshold, 0)
    breaching = [
        f for f in actionable if _SEVERITY_ORDER.get((f.get("severity") or "low").lower(), 0) >= threshold_order
    ]

    if breaching:
        by_sev: Dict[str, int] = {}
        for f in breaching:
            s = (f.get("severity") or "UNKNOWN").upper()
            by_sev[s] = by_sev.get(s, 0) + 1
        parts = ", ".join(f"{v} {k}" for k, v in sorted(by_sev.items(), reverse=True))
        return True, f"Found {len(breaching)} actionable finding(s) at or above {threshold}: {parts}"

    return False, f"No actionable findings at or above {threshold}"


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _get_actionable_issues(data: Dict[str, Any]) -> List[Dict]:
    """Return only reachable + unknown findings from the issues list."""
    return [f for f in data.get("issues", []) if (f.get("reachability_state") or "unknown") in _ACTIONABLE_STATES]


def _sarif_level(severity: str, reachability_state: str) -> str:
    """
    Map REACHABLE severity to SARIF level.

    Unknown-reachability findings are capped at 'warning' regardless of
    severity — we cannot confirm exploitability, so we should not block CI
    at the 'error' level.
    """
    level = _SEV_TO_LEVEL.get((severity or "MEDIUM").upper(), "warning")
    if reachability_state == "unknown" and level == "error":
        level = "warning"
    return level


def _location(file_path: str, line: Optional[int]) -> Dict:
    """Build a SARIF physicalLocation object."""
    loc: Dict[str, Any] = {
        "artifactLocation": {
            "uri": file_path or "unknown",
            "uriBaseId": "%SRCROOT%",
        }
    }
    if line:
        loc["region"] = {"startLine": int(line)}
    return {"physicalLocation": loc}


def _reachability_tag(reachability_state: str, confidence: Optional[str]) -> str:
    """Human-readable reachability context for SARIF message text."""
    if reachability_state == "reachable":
        return f"[REACHABLE{(' · ' + confidence) if confidence else ''}]"
    return "[UNKNOWN reachability]"


# ---------------------------------------------------------------------------
# Call path → SARIF codeFlows
# ---------------------------------------------------------------------------


def _code_flows(issue: Dict) -> List[Dict]:
    """
    Convert call_paths_v2 (List[List[PathNode-dict]]) to SARIF codeFlows.

    SARIF spec §3.36: codeFlow > threadFlow > threadFlowLocation.
    Each call path becomes one threadFlow inside a single codeFlow.
    Only emitted when call_paths_v2 is non-empty — never emit [].

    Size note: each PathNode is ~150-200 bytes; a 4-hop path ≈ 700 bytes.
    Capped at 3 paths per finding to avoid bloating large SARIF files.
    """
    raw = issue.get("call_paths_v2")
    if not raw:
        return []

    try:
        paths = json.loads(raw) if isinstance(raw, str) else raw
    except (json.JSONDecodeError, TypeError):
        return []

    if not paths:
        return []

    thread_flows = []
    for path in paths[:3]:  # cap at 3 paths per finding
        if not path:
            continue
        locations = []
        for hop in path:
            if isinstance(hop, str):
                # v1 compat: plain string hop
                tf_loc: Dict[str, Any] = {
                    "location": {
                        "message": {"text": hop},
                        "physicalLocation": {
                            "artifactLocation": {"uri": "unknown", "uriBaseId": "%SRCROOT%"}
                        },
                    }
                }
            else:
                # v2 PathNode dict
                file_path = hop.get("file") or "unknown"
                line      = hop.get("line")
                label     = hop.get("label") or ""
                kind      = hop.get("kind") or "app"
                route     = hop.get("route") or ""

                phys_loc: Dict[str, Any] = {
                    "artifactLocation": {
                        "uri": file_path,
                        "uriBaseId": "%SRCROOT%",
                    }
                }
                if line:
                    phys_loc["region"] = {"startLine": int(line)}

                msg = label
                if route:
                    msg = f"{route} → {label}"

                tf_loc = {
                    "location": {
                        "message": {"text": msg},
                        "physicalLocation": phys_loc,
                        "logicalLocations": [{"name": label, "kind": kind}],
                    }
                }

                # Mark the sink hop (last in path or kind=sink_danger/sink_warn)
                if kind in ("sink_danger", "sink_warn"):
                    tf_loc["importance"] = "essential"

            locations.append(tf_loc)

        if locations:
            # Mark entry and exit explicitly for GitHub rendering
            if locations:
                locations[0]["importance"] = "essential"   # entrypoint
                locations[-1]["importance"] = "essential"  # sink

            thread_flows.append({"locations": locations})

    if not thread_flows:
        return []

    return [{"message": {"text": "Reachable call path"}, "threadFlows": thread_flows}]


# ---------------------------------------------------------------------------
# Per-type converters  →  (sarif_result, sarif_rule)
# ---------------------------------------------------------------------------


def _issue_to_sarif(issue: Dict) -> Tuple[Dict, Dict]:
    """
    Dispatch to the correct per-type converter.

    Returns a (result, rule) tuple.  The rule dict has an 'id' field used
    for deduplication in the rules_map.
    """
    ftype = (issue.get("type") or "").upper()
    if ftype == "CVE":
        return _cve(issue)
    if ftype == "SECRET":
        return _secret(issue)
    if ftype == "CWE":
        return _cwe(issue)
    if ftype in ("MALWARE", "SUSPICIOUS"):
        return _malware(issue)
    if ftype == "AI":
        return _ai(issue)
    if ftype == "DLP":
        return _dlp(issue)
    # Unknown type — emit as generic finding so nothing is silently dropped
    return _generic(issue)


def _cve(issue: Dict) -> Tuple[Dict, Dict]:
    """
    CVE finding.

    rule_id: ``CVE/<cve-id>``  e.g. ``CVE/CVE-2024-45230``
    Includes: package, version, CVSS, EPSS, KEV flag, fix version,
              reachability state, call path summary.
    """
    cve_id = issue.get("id") or issue.get("cve_id") or "UNKNOWN"
    rule_id = f"CVE/{cve_id}"
    severity = (issue.get("severity") or "MEDIUM").upper()
    reach = issue.get("reachability_state", "unknown")
    level = _sarif_level(severity, reach)
    rtag = _reachability_tag(reach, issue.get("reachability_reason"))
    package = issue.get("package") or "unknown"
    desc = (issue.get("description") or f"{cve_id} in {package}")[:300]

    # Enrich message with threat intelligence if available
    threat_parts = []
    if issue.get("is_kev"):
        threat_parts.append("KEV-listed (actively exploited)")
    if issue.get("epss_score") is not None:
        threat_parts.append(f"EPSS {issue['epss_score']:.1%}")
    if issue.get("fix_version") or issue.get("fix_version_raw"):
        threat_parts.append(f"fix: {issue.get('fix_version') or issue.get('fix_version_raw')}")
    threat_suffix = f" | {', '.join(threat_parts)}" if threat_parts else ""

    result: Dict[str, Any] = {
        "ruleId": rule_id,
        "level": level,
        "message": {"text": f"{rtag} {cve_id} in {package}: {desc}{threat_suffix}"},
        "locations": [_location(issue.get("file_path", ""), issue.get("line"))],
        "properties": {
            "reachabilityState": reach,
            "reachabilityConfidence": issue.get("reachability_confidence"),
            "package": package,
            "fixVersion": issue.get("fix_version") or issue.get("fix_version_raw"),
            "cvssScore": issue.get("cvss_score"),
            "epssScore": issue.get("epss_score"),
            "isKev": issue.get("is_kev"),
            "isTransitive": issue.get("is_transitive"),
            "viaPackage": issue.get("via_package") or None,
        },
    }

    flows = _code_flows(issue)
    if flows:
        result["codeFlows"] = flows

    rule: Dict[str, Any] = {
        "id": rule_id,
        "name": cve_id,
        "shortDescription": {"text": f"{cve_id}: {package} vulnerability"},
        "fullDescription": {"text": desc},
        "defaultConfiguration": {"level": _SEV_TO_LEVEL.get(severity, "warning")},
        "helpUri": f"https://nvd.nist.gov/vuln/detail/{cve_id}",
        "properties": {
            "category": "vulnerability",
            "severity": severity,
            "cwe": issue.get("cwe_id") or [],
        },
    }
    return result, rule


def _secret(issue: Dict) -> Tuple[Dict, Dict]:
    """
    Secret / credential exposure finding.

    rule_id: ``SECRET/<secret-type>``  e.g. ``SECRET/aws-access-key``
    Includes: file, line, column, secret type, reachability state.
    Secret values are NEVER included — only metadata.
    """
    secret_type = issue.get("type_detail") or issue.get("secret_type") or issue.get("id") or "generic-secret"
    rule_id = f"SECRET/{secret_type}"
    severity = (issue.get("severity") or "HIGH").upper()
    reach = issue.get("reachability_state", "unknown")
    level = _sarif_level(severity, reach)
    rtag = _reachability_tag(reach, None)
    title = issue.get("title") or f"{secret_type} exposed"

    result: Dict[str, Any] = {
        "ruleId": rule_id,
        "level": level,
        "message": {"text": f"{rtag} {title}: {issue.get('description', '')[:200]}"},
        "locations": [_location(issue.get("file_path", ""), issue.get("line"))],
        "properties": {
            "reachabilityState": reach,
            "secretType": secret_type,
            "remediation": (issue.get("remediation") or {}).get("action"),
        },
    }

    rule: Dict[str, Any] = {
        "id": rule_id,
        "name": f"Exposed {secret_type}",
        "shortDescription": {"text": f"Exposed {secret_type} in source code"},
        "fullDescription": {
            "text": f"A {secret_type} was found exposed in source code with a "
            f"reachable path from an HTTP entry point. Rotate the credential immediately."
        },
        "defaultConfiguration": {"level": "error"},
        "properties": {"category": "secret", "severity": severity},
    }
    return result, rule


def _cwe(issue: Dict) -> Tuple[Dict, Dict]:
    """
    CWE / code weakness finding (from Semgrep).

    rule_id: ``CWE/<cwe-id>``  e.g. ``CWE/CWE-89``
    Includes: file, line range, OWASP Web mapping if available.
    """
    cwe_id = issue.get("cwe_id") or issue.get("id") or "CWE-UNKNOWN"
    rule_id = f"CWE/{cwe_id}"
    severity = (issue.get("severity") or "MEDIUM").upper()
    reach = issue.get("reachability_state", "unknown")
    level = _sarif_level(severity, reach)
    rtag = _reachability_tag(reach, issue.get("reachability_confidence"))
    title = issue.get("title") or cwe_id
    desc = issue.get("description") or f"Code weakness: {cwe_id}"

    result: Dict[str, Any] = {
        "ruleId": rule_id,
        "level": level,
        "message": {"text": f"{rtag} {title}: {desc[:250]}"},
        "locations": [_location(issue.get("file_path", ""), issue.get("line"))],
        "properties": {
            "reachabilityState": reach,
            "reachabilityConfidence": issue.get("reachability_confidence"),
            "containingFunction": issue.get("containing_function"),
            "owaspWeb": issue.get("compliance_mapping", {}).get("owasp_web"),
        },
    }

    flows = _code_flows(issue)
    if flows:
        result["codeFlows"] = flows

    cwe_num = cwe_id.replace("CWE-", "").lstrip("0") or "0"
    rule: Dict[str, Any] = {
        "id": rule_id,
        "name": title,
        "shortDescription": {"text": title},
        "fullDescription": {"text": desc[:500]},
        "defaultConfiguration": {"level": _SEV_TO_LEVEL.get(severity, "warning")},
        "helpUri": f"https://cwe.mitre.org/data/definitions/{cwe_num}.html",
        "properties": {"category": "code-weakness", "severity": severity},
    }
    return result, rule


def _malware(issue: Dict) -> Tuple[Dict, Dict]:
    """
    Malware / suspicious package finding (from GuardDog + YARA).

    rule_id: ``MALWARE/<detection-type>``  e.g. ``MALWARE/exec-base64``
    Always 'error' level — malware is never downgraded.
    """
    detection = issue.get("type_detail") or issue.get("scanner") or "suspicious"
    rule_id = f"MALWARE/{detection}"
    package = issue.get("package") or "unknown"
    reach = issue.get("reachability_state", "reachable")  # malware is always actionable
    desc = issue.get("description") or issue.get("title") or "Malicious behavior detected"

    result: Dict[str, Any] = {
        "ruleId": rule_id,
        "level": "error",  # malware is always error — never downgrade
        "message": {"text": f"[MALWARE] {package}: {desc[:300]}"},
        "locations": [_location(issue.get("file_path", ""), issue.get("line"))],
        "properties": {
            "reachabilityState": reach,
            "package": package,
            "detectionType": detection,
            "evidence": issue.get("evidence"),
        },
    }

    rule: Dict[str, Any] = {
        "id": rule_id,
        "name": f"Malware: {detection}",
        "shortDescription": {"text": "Malicious package detected"},
        "fullDescription": {
            "text": "A package with confirmed malicious behavior was detected. "
            "This indicates supply chain compromise. Remove and rotate any "
            "credentials accessible from this process immediately."
        },
        "defaultConfiguration": {"level": "error"},
        "helpUri": "https://owasp.org/www-project-top-10/",
        "properties": {"category": "malware", "severity": "CRITICAL"},
    }
    return result, rule


def _ai(issue: Dict) -> Tuple[Dict, Dict]:
    """
    AI/LLM security finding (OWASP LLM Top 10 / Agentic Top 10).

    rule_id: ``AI/<owasp-code>-<slug>``  e.g. ``AI/LLM01-prompt-injection``
    Includes: OWASP LLM category, file, pipeline stage context.
    """
    owasp_cat = (issue.get("owasp_llm") or issue.get("id") or "LLM-UNKNOWN").upper()
    slug = (issue.get("title") or owasp_cat).lower().replace(" ", "-")[:40]
    rule_id = f"AI/{owasp_cat}-{slug}"
    severity = (issue.get("severity") or "MEDIUM").upper()
    reach = issue.get("reachability_state", "unknown")
    level = _sarif_level(severity, reach)
    rtag = _reachability_tag(reach, None)
    title = issue.get("title") or f"{owasp_cat} finding"
    desc = issue.get("description") or ""

    _LLM_NAMES = {
        "LLM01": "Prompt Injection",
        "LLM02": "Sensitive Information Disclosure",
        "LLM03": "Supply Chain",
        "LLM04": "Data/Model Poisoning",
        "LLM05": "Improper Output Handling",
        "LLM06": "Excessive Agency",
        "LLM07": "System Prompt Leakage",
        "LLM08": "Vector / Embedding Weakness",
        "LLM09": "Misinformation",
        "LLM10": "Unbounded Consumption",
        "MCP": "MCP Security",
    }
    owasp_name = _LLM_NAMES.get(owasp_cat, owasp_cat)
    _LLM_URLS = {
        "LLM01": "https://genai.owasp.org/llmrisk/llm01-prompt-injection/",
        "LLM06": "https://genai.owasp.org/llmrisk/llm06-excessive-agency/",
        "LLM07": "https://genai.owasp.org/llmrisk/llm07-system-prompt-leakage/",
    }

    result: Dict[str, Any] = {
        "ruleId": rule_id,
        "level": level,
        "message": {"text": f"{rtag} {owasp_cat} ({owasp_name}): {title}. {desc[:200]}"},
        "locations": [_location(issue.get("file_path", ""), issue.get("line"))],
        "properties": {
            "reachabilityState": reach,
            "owaspLlm": owasp_cat,
            "owaspLlmName": owasp_name,
            "complianceMapping": issue.get("compliance_mapping"),
        },
    }

    rule: Dict[str, Any] = {
        "id": rule_id,
        "name": title,
        "shortDescription": {"text": f"{owasp_cat}: {owasp_name}"},
        "fullDescription": {"text": desc[:500] or f"OWASP LLM Top 10: {owasp_name}"},
        "defaultConfiguration": {"level": _SEV_TO_LEVEL.get(severity, "warning")},
        "helpUri": _LLM_URLS.get(owasp_cat, "https://genai.owasp.org/"),
        "properties": {"category": "ai-security", "severity": severity, "owaspLlm": owasp_cat},
    }
    return result, rule


def _dlp(issue: Dict) -> Tuple[Dict, Dict]:
    """
    DLP / data exposure finding (PII, sensitive data sinks).

    rule_id: ``DLP/<pii-type>``  e.g. ``DLP/pii-ssn``, ``DLP/pii-credit-card``
    PII sample values are NEVER included — only type and location metadata.
    """
    pii_type = (issue.get("type_detail") or issue.get("id") or "pii-unknown").lower().replace(" ", "-")
    rule_id = f"DLP/{pii_type}"
    severity = (issue.get("severity") or "MEDIUM").upper()
    reach = issue.get("reachability_state", "unknown")
    level = _sarif_level(severity, reach)
    rtag = _reachability_tag(reach, None)
    title = issue.get("title") or f"{pii_type} data exposure"
    desc = issue.get("description") or ""

    result: Dict[str, Any] = {
        "ruleId": rule_id,
        "level": level,
        "message": {"text": f"{rtag} {title}: {desc[:200]}"},
        "locations": [_location(issue.get("file_path", ""), issue.get("line"))],
        "properties": {
            "reachabilityState": reach,
            "piiType": pii_type,
            # piiSample intentionally omitted — do not put PII in SARIF output
        },
    }

    rule: Dict[str, Any] = {
        "id": rule_id,
        "name": title,
        "shortDescription": {"text": f"Sensitive data exposure: {pii_type}"},
        "fullDescription": {
            "text": f"{pii_type} data found on a reachable path. "
            f"This data may be logged, returned in API responses, "
            f"or otherwise exposed to unauthorized parties."
        },
        "defaultConfiguration": {"level": _SEV_TO_LEVEL.get(severity, "warning")},
        "helpUri": "https://owasp.org/www-project-top-ten/2021/A02_2021-Cryptographic_Failures",
        "properties": {"category": "data-protection", "severity": severity},
    }
    return result, rule


def _generic(issue: Dict) -> Tuple[Dict, Dict]:
    """Fallback for any finding type not explicitly handled."""
    ftype = (issue.get("type") or "UNKNOWN").upper()
    fid = issue.get("id") or "unknown"
    rule_id = f"{ftype}/{fid}"
    severity = (issue.get("severity") or "MEDIUM").upper()
    reach = issue.get("reachability_state", "unknown")
    level = _sarif_level(severity, reach)

    result: Dict[str, Any] = {
        "ruleId": rule_id,
        "level": level,
        "message": {"text": issue.get("title") or issue.get("description") or fid},
        "locations": [_location(issue.get("file_path", ""), issue.get("line"))],
        "properties": {"reachabilityState": reach},
    }
    rule: Dict[str, Any] = {
        "id": rule_id,
        "name": issue.get("title") or fid,
        "shortDescription": {"text": issue.get("title") or fid},
        "defaultConfiguration": {"level": level},
        "properties": {"category": ftype.lower(), "severity": severity},
    }
    return result, rule


# ---------------------------------------------------------------------------
# Run builder
# ---------------------------------------------------------------------------


def _build_run(data: Dict[str, Any], repo_uri: Optional[str]) -> Dict:
    """Build the SARIF ``run`` object from dashboard data."""

    actionable = _get_actionable_issues(data)

    sarif_results: List[Dict] = []
    rules_map: Dict[str, Dict] = {}  # rule_id → rule — deduplicated

    for issue in actionable:
        try:
            result, rule = _issue_to_sarif(issue)
            sarif_results.append(result)
            # First rule definition wins — subsequent findings of the same
            # rule_id reuse it without overwriting.
            rules_map.setdefault(rule["id"], rule)
        except Exception as exc:
            logger.warning(f" SARIF: skipped finding {issue.get('id')}: {exc}")

    # Metadata from scan section
    scan_meta = data.get("scan") or {}
    timing = scan_meta.get("scan_timing") or {}
    start_ts = timing.get("start_timestamp") or _utcnow()
    end_ts = timing.get("end_timestamp") or _utcnow()
    languages = scan_meta.get("languages") or []
    scan_ver = data.get("version") or __version__

    # Summary counts for run properties
    total_actionable = len(sarif_results)
    by_type: Dict[str, int] = {}
    for r in sarif_results:
        prefix = (r.get("ruleId") or "").split("/")[0]
        by_type[prefix] = by_type.get(prefix, 0) + 1

    tool = {
        "driver": {
            "name": "REACHABLE",
            "version": scan_ver,
            "semanticVersion": scan_ver,
            "informationUri": "https://reachable.dev",
            "rules": list(rules_map.values()),
            "properties": {
                # Advertise REACHABLE-specific capabilities so consumers know
                # why findings have reachabilityState tags.
                "reachabilityAnalysis": True,
                "callGraphTracing": True,
                "multiSignalCorrelation": True,
                "findingTypes": ["CVE", "SECRET", "CWE", "MALWARE", "AI", "DLP"],
            },
        }
    }

    invocation = {
        "executionSuccessful": True,
        "startTimeUtc": start_ts,
        "endTimeUtc": end_ts,
    }

    run: Dict[str, Any] = {
        "tool": tool,
        "invocations": [invocation],
        "results": sarif_results,
        "properties": {
            # Summary visible in GitHub Advanced Security overview
            "totalActionable": total_actionable,
            "byType": by_type,
            "riskLevel": data.get("risk_level") or "UNKNOWN",
            "languages": languages,
            # Note: only reachable+unknown findings appear above.
            # not_reachable findings are excluded — the call graph
            # confirmed no exploitable path for those.
            "reachabilityNote": (
                "This report contains only REACHABLE and UNKNOWN-reachability "
                "findings. NOT_REACHABLE findings are omitted — the call graph "
                "confirmed no exploitable path exists for those."
            ),
        },
    }

    # Artifact location (optional — adds repo context in GitHub UI)
    if repo_uri:
        run["versionControlProvenance"] = [
            {
                "repositoryUri": repo_uri,
                "branch": scan_meta.get("branch") or "",
                "revisionId": scan_meta.get("commit") or "",
            }
        ]

    return run


def _utcnow() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


# ---------------------------------------------------------------------------
# Summary helper (used by CLI for --sarif output confirmation)
# ---------------------------------------------------------------------------


# Alias for backward compatibility / selftest checks
build_sarif_report = export_to_sarif


def get_sarif_summary(sarif: Dict) -> Dict[str, Any]:
    """Return finding counts from a SARIF document (for logging/display)."""
    results = sarif.get("runs", [{}])[0].get("results", [])
    summary: Dict[str, Any] = {
        "total": len(results),
        "by_level": {"error": 0, "warning": 0, "note": 0},
        "by_type": {},
    }
    for r in results:
        level = r.get("level", "warning")
        summary["by_level"][level] = summary["by_level"].get(level, 0) + 1
        prefix = (r.get("ruleId") or "").split("/")[0]
        summary["by_type"][prefix] = summary["by_type"].get(prefix, 0) + 1
    return summary
