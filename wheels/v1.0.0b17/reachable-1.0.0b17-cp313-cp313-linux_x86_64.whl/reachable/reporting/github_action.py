#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.
"""
GitHub Actions Workflow Generator
==================================

Renders a ready-to-use GitHub Actions workflow YAML that:
  1. Runs ``reachctl scan`` with SARIF output
  2. Uploads the SARIF file to GitHub Code Scanning via ``upload-sarif``
  3. Applies a configurable ``--fail-on`` CI gate

Usage (via reachctl)::

    reachctl export --format github-action
    reachctl export --format github-action --fail-on high --branch main
    reachctl export --format github-action --output .github/workflows/reachable.yml

The template is a plain-string file at
``reachable/reporting/templates/reachable-scan.yml.tpl`` — no Jinja
dependency.  Variable slots are ``{name}`` Python str.format() tokens.
"""

from __future__ import annotations

import sys
from pathlib import Path
from typing import Optional

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

_TEMPLATE_PATH = Path(__file__).parent / "templates" / "reachable-scan.yml.tpl"

_VALID_FAIL_ON = ("critical", "high", "medium", "any", "none")
_VALID_PYTHON  = ("3.9", "3.10", "3.11", "3.12", "3.13")

_DEFAULT_FAIL_ON        = "high"
_DEFAULT_BRANCH         = "main"
_DEFAULT_PYTHON_VERSION = "3.11"
_DEFAULT_INSTALL_CMD    = "pip install reachable"


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def generate_workflow(
    fail_on: str        = _DEFAULT_FAIL_ON,
    branch: str         = _DEFAULT_BRANCH,
    python_version: str = _DEFAULT_PYTHON_VERSION,
    reachable_version: Optional[str] = None,
) -> str:
    """
    Render the GitHub Actions workflow template with the given parameters.

    Args:
        fail_on:           CI gate threshold — one of critical/high/medium/any/none.
        branch:            Branch to trigger the workflow on (push + PR target).
        python_version:    Python version for the ``setup-python`` step.
        reachable_version: Pin to a specific version (e.g. ``"1.4.2"``).
                           ``None`` installs the latest release.

    Returns:
        Rendered YAML string ready to write to ``.github/workflows/reachable.yml``.

    Raises:
        ValueError:  Invalid ``fail_on`` or ``python_version``.
        FileNotFoundError: Template file missing from the package.
    """
    # ── Validate ─────────────────────────────────────────────────────────────
    fail_on = fail_on.lower().strip()
    if fail_on not in _VALID_FAIL_ON:
        raise ValueError(
            f"Invalid --fail-on '{fail_on}'. "
            f"Must be one of: {', '.join(_VALID_FAIL_ON)}"
        )

    if python_version not in _VALID_PYTHON:
        raise ValueError(
            f"Invalid --python-version '{python_version}'. "
            f"Must be one of: {', '.join(_VALID_PYTHON)}"
        )

    # ── Build install command ─────────────────────────────────────────────────
    if reachable_version:
        install_cmd = f"pip install reachable=={reachable_version}"
    else:
        install_cmd = _DEFAULT_INSTALL_CMD

    # ── Load and render template ──────────────────────────────────────────────
    if not _TEMPLATE_PATH.exists():
        raise FileNotFoundError(
            f"Workflow template not found: {_TEMPLATE_PATH}\n"
            "This file should ship with the reachable package."
        )

    template = _TEMPLATE_PATH.read_text(encoding="utf-8")

    return template.format(
        fail_on        = fail_on,
        branch         = branch,
        python_version = python_version,
        install_cmd    = install_cmd,
    )


def write_workflow(
    output_path: Path,
    fail_on: str        = _DEFAULT_FAIL_ON,
    branch: str         = _DEFAULT_BRANCH,
    python_version: str = _DEFAULT_PYTHON_VERSION,
    reachable_version: Optional[str] = None,
    overwrite: bool     = False,
) -> Path:
    """
    Render the workflow and write it to ``output_path``.

    Creates parent directories automatically.  Refuses to overwrite an
    existing file unless ``overwrite=True``.

    Returns:
        The resolved output path.
    """
    output_path = Path(output_path).resolve()

    if output_path.exists() and not overwrite:
        raise FileExistsError(
            f"{output_path} already exists. "
            "Pass --force to overwrite, or choose a different --output path."
        )

    output_path.parent.mkdir(parents=True, exist_ok=True)

    content = generate_workflow(
        fail_on        = fail_on,
        branch         = branch,
        python_version = python_version,
        reachable_version = reachable_version,
    )

    output_path.write_text(content, encoding="utf-8")
    return output_path


def print_generation_summary(
    output_path: Optional[Path],
    fail_on: str,
    branch: str,
    python_version: str,
) -> None:
    """Print a human-readable summary after workflow generation."""
    lines = [
        "",
        "  GitHub Actions workflow generated",
        "  ──────────────────────────────────────────────────",
    ]
    if output_path:
        lines.append(f"  File:           {output_path}")
        lines.append(f"  Next step:      git add {output_path}")
    else:
        lines.append("  Output:         stdout (pipe to file or use --output)")
    lines += [
        f"  Trigger branch: {branch}",
        f"  Python:         {python_version}",
        f"  CI gate:        --fail-on {fail_on}",
        "",
        "  What happens on every push/PR:",
        "    1. reachctl scan  → builds call graph, correlates CVEs/secrets/CWEs",
        "    2. results.sarif  → uploaded to GitHub Code Scanning (Security tab)",
        "    3. Gate check     → fails the PR check if findings ≥ --fail-on",
        "",
        "  Requirements:",
        "    • Add secret: REACHABLE_LICENSE  (Settings → Secrets → Actions)",
        "    • GitHub Advanced Security enabled, OR public repository",
        "      (required for upload-sarif; remove that step if neither applies)",
        "",
        "  Docs: https://docs.reachable.dev/ci-cd",
        "",
    ]
    print("\n".join(lines), file=sys.stderr)
