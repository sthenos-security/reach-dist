#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.

"""
OWASP Classification for SAST Findings

Maps Semgrep/SAST rule IDs to OWASP Top 10 categories with risk weights.
Used by the REACHABLE risk scoring engine.

OWASP Top 10:2025 (replaces 2021):
  A01: Broken Access Control          (includes SSRF, absorbed from 2021 A10)
  A02: Security Misconfiguration      (↑ from A05:2021)
  A03: Software Supply Chain Failures (NEW — replaces Vulnerable & Outdated Components)
  A04: Cryptographic Failures         (↓ from A02:2021)
  A05: Injection                      (↓ from A03:2021)
  A06: Insecure Design                (↓ from A04:2021)
  A07: Authentication Failures        (renamed — was Identification & Authentication Failures)
  A08: Software or Data Integrity Failures (same)
  A09: Security Logging & Alerting Failures (renamed — was Logging and Monitoring Failures)
  A10: Mishandling of Exceptional Conditions (NEW)

Key changes vs 2021:
  - SSRF (was A10:2021) absorbed into A01:2025 Broken Access Control
  - Vulnerable & Outdated Components (was A06:2021) → A03:2025 Software Supply Chain Failures
  - Security Misconfiguration rises from #5 to #2
  - New: A10:2025 Mishandling of Exceptional Conditions (error handling, fail-open, null deref)

References:
  https://owasp.org/Top10/2025/
"""

import logging
import re
from dataclasses import dataclass
from enum import Enum
from typing import Tuple

logger = logging.getLogger(__name__)


class OWASPCategory(Enum):
    """OWASP Top 10:2025 Categories"""

    A01_BROKEN_ACCESS_CONTROL = "A01"  # Includes SSRF (absorbed from 2021 A10)
    A02_SECURITY_MISCONFIGURATION = "A02"  # ↑ from A05:2021
    A03_SOFTWARE_SUPPLY_CHAIN = "A03"  # NEW: replaces Vulnerable & Outdated Components
    A04_CRYPTOGRAPHIC_FAILURES = "A04"  # ↓ from A02:2021
    A05_INJECTION = "A05"  # ↓ from A03:2021
    A06_INSECURE_DESIGN = "A06"  # ↓ from A04:2021
    A07_AUTHENTICATION_FAILURES = "A07"  # Renamed from Identification & Authentication
    A08_DATA_INTEGRITY_FAILURES = "A08"  # Same
    A09_LOGGING_ALERTING_FAILURES = "A09"  # Renamed (Monitoring → Alerting)
    A10_EXCEPTIONAL_CONDITIONS = "A10"  # NEW: error handling, fail-open, null deref

    # Non-OWASP categories
    CONTAINER_SECURITY = "CONTAINER"
    CODE_QUALITY = "QUALITY"
    NOT_SECURITY = "NONE"


@dataclass
class SASTClassification:
    """Classification result for a SAST finding"""

    owasp_category: OWASPCategory
    owasp_name: str
    risk_weight_reachable: int
    risk_weight_unreachable: int
    cwe_ids: list
    description: str


# OWASP Category Definitions with Risk Weights
OWASP_DEFINITIONS = {
    OWASPCategory.A01_BROKEN_ACCESS_CONTROL: SASTClassification(
        owasp_category=OWASPCategory.A01_BROKEN_ACCESS_CONTROL,
        owasp_name="Broken Access Control",
        risk_weight_reachable=150,
        risk_weight_unreachable=38,
        cwe_ids=[
            22,
            23,
            35,
            59,
            200,
            201,
            219,
            264,
            275,
            276,
            284,
            285,
            352,
            359,
            377,
            402,
            425,
            441,
            497,
            538,
            540,
            548,
            552,
            566,
            601,
            639,
            651,
            668,
            706,
            862,
            863,
            913,
            918,
            922,
            1275,
        ],  # CWE-918 SSRF included per 2025 consolidation
        description="Broken access control including SSRF (absorbed from A10:2021). "
        "Users acting outside their intended permissions, unauthorized data access, "
        "server-side request forgery.",
    ),
    OWASPCategory.A02_SECURITY_MISCONFIGURATION: SASTClassification(
        owasp_category=OWASPCategory.A02_SECURITY_MISCONFIGURATION,
        owasp_name="Security Misconfiguration",
        risk_weight_reachable=60,
        risk_weight_unreachable=15,
        cwe_ids=[
            2,
            11,
            13,
            15,
            16,
            260,
            315,
            520,
            526,
            537,
            541,
            547,
            611,
            614,
            756,
            776,
            942,
            1004,
            1032,
            1174,
        ],
        description="Missing or improper security hardening. Affects 3% of tested applications — "
        "rose from #5 (2021) to #2 (2025). Includes exposed default accounts, "
        "unnecessary services, insecure permissions, missing headers, "
        "misconfigured cloud storage.",
    ),
    OWASPCategory.A03_SOFTWARE_SUPPLY_CHAIN: SASTClassification(
        owasp_category=OWASPCategory.A03_SOFTWARE_SUPPLY_CHAIN,
        owasp_name="Software Supply Chain Failures",
        risk_weight_reachable=80,
        risk_weight_unreachable=20,
        cwe_ids=[94, 116, 493, 494, 502, 538, 610, 829, 912, 913, 937],
        description="NEW in 2025. Breakdowns in building, distributing, or updating software. "
        "Expands 2021 A06 (Vulnerable & Outdated Components) to the full supply chain: "
        "compromised dependencies, malicious packages (typosquatting, dependency confusion), "
        "untrusted CI/CD artifacts, unverified updates.",
    ),
    OWASPCategory.A04_CRYPTOGRAPHIC_FAILURES: SASTClassification(
        owasp_category=OWASPCategory.A04_CRYPTOGRAPHIC_FAILURES,
        owasp_name="Cryptographic Failures",
        risk_weight_reachable=80,
        risk_weight_unreachable=20,
        cwe_ids=[
            261,
            296,
            310,
            319,
            320,
            321,
            322,
            323,
            324,
            325,
            326,
            327,
            328,
            329,
            330,
            331,
            335,
            336,
            337,
            338,
            339,
            340,
            347,
            523,
            720,
            757,
            759,
            760,
            780,
            818,
            916,
        ],
        description="Failure to protect data in transit and at rest, or use of weak/broken "
        "cryptographic algorithms. Dropped from #2 (2021) to #4 (2025).",
    ),
    OWASPCategory.A05_INJECTION: SASTClassification(
        owasp_category=OWASPCategory.A05_INJECTION,
        owasp_name="Injection",
        risk_weight_reachable=200,
        risk_weight_unreachable=50,
        cwe_ids=[
            20,
            74,
            75,
            77,
            78,
            79,
            80,
            83,
            87,
            88,
            89,
            90,
            91,
            93,
            94,
            95,
            96,
            97,
            98,
            99,
            100,
            113,
            116,
            138,
            184,
            470,
            471,
            564,
            610,
            643,
            644,
            652,
            917,
        ],
        description="User-supplied data sent to interpreter as part of command or query. "
        "Dropped from #3 (2021) to #5 (2025) but remains the most severe "
        "individual category by impact.",
    ),
    OWASPCategory.A06_INSECURE_DESIGN: SASTClassification(
        owasp_category=OWASPCategory.A06_INSECURE_DESIGN,
        owasp_name="Insecure Design",
        risk_weight_reachable=30,
        risk_weight_unreachable=8,
        cwe_ids=[
            73,
            183,
            209,
            213,
            235,
            256,
            257,
            266,
            269,
            280,
            311,
            312,
            313,
            316,
            419,
            430,
            434,
            444,
            451,
            472,
            501,
            522,
            525,
            539,
            579,
            598,
            602,
            642,
            646,
            650,
            653,
            656,
            657,
            799,
            807,
            840,
            841,
            927,
            1021,
            1173,
        ],
        description="Missing or ineffective control design, architectural flaws. Dropped from #4 (2021) to #6 (2025).",
    ),
    OWASPCategory.A07_AUTHENTICATION_FAILURES: SASTClassification(
        owasp_category=OWASPCategory.A07_AUTHENTICATION_FAILURES,
        owasp_name="Authentication Failures",
        risk_weight_reachable=150,
        risk_weight_unreachable=38,
        cwe_ids=[
            255,
            259,
            287,
            288,
            290,
            294,
            295,
            297,
            300,
            302,
            304,
            306,
            307,
            346,
            350,
            384,
            521,
            613,
            620,
            640,
            798,
            940,
            1216,
        ],
        description="Identity and session management weaknesses. Renamed from "
        "'Identification and Authentication Failures' (2021) to focus on "
        "authentication specifically.",
    ),
    OWASPCategory.A08_DATA_INTEGRITY_FAILURES: SASTClassification(
        owasp_category=OWASPCategory.A08_DATA_INTEGRITY_FAILURES,
        owasp_name="Software or Data Integrity Failures",
        risk_weight_reachable=60,
        risk_weight_unreachable=15,
        cwe_ids=[345, 353, 426, 494, 502, 565, 784, 829, 830, 913, 915],
        description="Code and infrastructure that does not protect against integrity violations "
        "(insecure deserialization, unsigned CI/CD artifacts, unverified updates). "
        "Distinct from A03 Supply Chain: this covers integrity within your environment, "
        "not upstream compromise.",
    ),
    OWASPCategory.A09_LOGGING_ALERTING_FAILURES: SASTClassification(
        owasp_category=OWASPCategory.A09_LOGGING_ALERTING_FAILURES,
        owasp_name="Security Logging & Alerting Failures",
        risk_weight_reachable=20,
        risk_weight_unreachable=5,
        cwe_ids=[117, 223, 532, 778],
        description="Insufficient logging, detection, monitoring, and alerting. "
        "Renamed from 'Security Logging and Monitoring Failures' (2021) to "
        "emphasize alerting — great logs with no alerts are of minimal value.",
    ),
    OWASPCategory.A10_EXCEPTIONAL_CONDITIONS: SASTClassification(
        owasp_category=OWASPCategory.A10_EXCEPTIONAL_CONDITIONS,
        owasp_name="Mishandling of Exceptional Conditions",
        risk_weight_reachable=40,
        risk_weight_unreachable=10,
        cwe_ids=[209, 252, 390, 391, 392, 393, 394, 395, 396, 397, 398, 476, 544, 636, 703, 754, 755],
        description="NEW in 2025. Applications that fail unsafely when facing unexpected inputs, "
        "resource shortages, timeouts, or internal failures. Covers improper error "
        "handling, fail-open logic, null dereferences, and other abnormal condition "
        "failures that leak secrets or bypass controls.",
    ),
    OWASPCategory.CONTAINER_SECURITY: SASTClassification(
        owasp_category=OWASPCategory.CONTAINER_SECURITY,
        owasp_name="Container Security",
        risk_weight_reachable=20,
        risk_weight_unreachable=5,
        cwe_ids=[250, 269],
        description="Container and Docker security issues (runs as root, privileged mode, etc.)",
    ),
    OWASPCategory.CODE_QUALITY: SASTClassification(
        owasp_category=OWASPCategory.CODE_QUALITY,
        owasp_name="Code Quality",
        risk_weight_reachable=10,
        risk_weight_unreachable=2,
        cwe_ids=[],
        description="General code quality and best practice issues",
    ),
    OWASPCategory.NOT_SECURITY: SASTClassification(
        owasp_category=OWASPCategory.NOT_SECURITY,
        owasp_name="Not Security Related",
        risk_weight_reachable=0,
        risk_weight_unreachable=0,
        cwe_ids=[],
        description="Non-security finding, does not affect risk score",
    ),
}


# Pattern matching for rule classification
RULE_PATTERNS = {
    # A05: Injection (CRITICAL — highest severity, check first)
    OWASPCategory.A05_INJECTION: [
        r"sql[-_]?injection",
        r"sqli",
        r"nosql[-_]?injection",
        r"ldap[-_]?injection",
        r"xpath[-_]?injection",
        r"command[-_]?injection",
        r"os[-_]?command",
        r"code[-_]?injection",
        r"expression[-_]?injection",
        r"template[-_]?injection",
        r"ssti",
        r"xss",
        r"cross[-_]?site[-_]?scripting",
        r"script[-_]?injection",
        r"html[-_]?injection",
        r"xxe",
        r"xml[-_]?external[-_]?entity",
        r"xml[-_]?injection",
        r"header[-_]?injection",
        r"crlf[-_]?injection",
        r"log[-_]?injection",
        r"eval\(",
        r"exec\(",
        r"shell[-_]?exec",
        r"subprocess",
        r"popen",
        r"system\(",
        r"dangerous[-_]?exec",
        r"unsafe[-_]?eval",
        r"untrusted[-_]?input",
    ],
    # A01: Broken Access Control (includes SSRF per 2025 consolidation)
    OWASPCategory.A01_BROKEN_ACCESS_CONTROL: [
        r"path[-_]?traversal",
        r"directory[-_]?traversal",
        r"lfi",
        r"rfi",
        r"file[-_]?inclusion",
        r"idor",
        r"insecure[-_]?direct[-_]?object",
        r"broken[-_]?access",
        r"access[-_]?control",
        r"privilege[-_]?escalation",
        r"privesc",
        r"authorization[-_]?bypass",
        r"auth[-_]?bypass",
        r"permission[-_]?bypass",
        r"open[-_]?redirect",
        r"unvalidated[-_]?redirect",
        r"csrf",
        r"cross[-_]?site[-_]?request[-_]?forgery",
        r"missing[-_]?authorization",
        r"missing[-_]?access[-_]?control",
        r"cors[-_]?misconfiguration",
        r"clickjacking",
        r"frame[-_]?injection",
        # SSRF absorbed from A10:2021 into A01:2025
        r"ssrf",
        r"server[-_]?side[-_]?request[-_]?forgery",
        r"url[-_]?injection",
        r"request[-_]?forgery",
        r"fetch[-_]?injection",
        r"unvalidated[-_]?url",
        r"arbitrary[-_]?url",
    ],
    # A07: Authentication Failures
    OWASPCategory.A07_AUTHENTICATION_FAILURES: [
        r"broken[-_]?auth",
        r"authentication[-_]?bypass",
        r"session[-_]?fixation",
        r"session[-_]?hijack",
        r"weak[-_]?password",
        r"hardcoded[-_]?password",
        r"password[-_]?in[-_]?code",
        r"credential[-_]?stuffing",
        r"brute[-_]?force",
        r"missing[-_]?auth",
        r"insecure[-_]?auth",
        r"jwt[-_]?vulnerab",
        r"token[-_]?validation",
        r"missing[-_]?verification",
        r"insecure[-_]?cookie",
        r"cookie[-_]?without[-_]?secure",
        r"cookie[-_]?without[-_]?httponly",
    ],
    # A04: Cryptographic Failures
    OWASPCategory.A04_CRYPTOGRAPHIC_FAILURES: [
        r"weak[-_]?crypto",
        r"insecure[-_]?crypto",
        r"weak[-_]?hash",
        r"insecure[-_]?hash",
        r"md5",
        r"sha1[^0-9]",
        r"des[^a-z]",
        r"3des",
        r"rc4",
        r"rc2",
        r"blowfish",
        r"ecb[-_]?mode",
        r"weak[-_]?random",
        r"insecure[-_]?random",
        r"predictable[-_]?random",
        r"math\.random",
        r"random\(\)",
        r"weak[-_]?ssl",
        r"insecure[-_]?ssl",
        r"ssl[-_]?verification[-_]?disabled",
        r"certificate[-_]?validation[-_]?disabled",
        r"hardcoded[-_]?key",
        r"hardcoded[-_]?iv",
        r"static[-_]?iv",
        r"weak[-_]?key",
        r"insufficient[-_]?key[-_]?size",
    ],
    # A02: Security Misconfiguration
    OWASPCategory.A02_SECURITY_MISCONFIGURATION: [
        r"debug[-_]?mode",
        r"debug[-_]?enabled",
        r"verbose[-_]?error",
        r"stack[-_]?trace[-_]?exposed",
        r"security[-_]?header",
        r"missing[-_]?header",
        r"x[-_]?frame[-_]?options",
        r"content[-_]?security[-_]?policy",
        r"csp[-_]?missing",
        r"hsts[-_]?missing",
        r"x[-_]?content[-_]?type[-_]?options",
        r"default[-_]?credential",
        r"default[-_]?password",
        r"admin[-_]?interface[-_]?exposed",
        r"directory[-_]?listing",
        r"sensitive[-_]?file[-_]?exposed",
        r"backup[-_]?file[-_]?exposed",
        r"git[-_]?exposed",
        r"svn[-_]?exposed",
        r"env[-_]?file[-_]?exposed",
        r"config[-_]?file[-_]?exposed",
        r"phpinfo",
        r"server[-_]?version[-_]?exposed",
    ],
    # A03: Software Supply Chain Failures (NEW in 2025)
    OWASPCategory.A03_SOFTWARE_SUPPLY_CHAIN: [
        r"supply[-_]?chain",
        r"dependency[-_]?confusion",
        r"typosquatting",
        r"malicious[-_]?package",
        r"compromised[-_]?dependency",
        r"vulnerable[-_]?component",
        r"outdated[-_]?component",
        r"known[-_]?vuln",
        r"cve[-_]?component",
        r"untrusted[-_]?artifact",
        r"unsigned[-_]?package",
        r"unverified[-_]?dependency",
        r"malware[-_]?package",
        r"guarddog",
        r"malicious[-_]?npm",
        r"malicious[-_]?pypi",
    ],
    # A08: Software or Data Integrity Failures
    OWASPCategory.A08_DATA_INTEGRITY_FAILURES: [
        r"insecure[-_]?deserialization",
        r"unsafe[-_]?deserialization",
        r"object[-_]?injection",
        r"pickle",
        r"marshal",
        r"yaml\.load",
        r"yaml\.unsafe",
        r"prototype[-_]?pollution",
        r"mass[-_]?assignment",
        r"unsigned[-_]?code",
        r"unverified[-_]?update",
        r"integrity[-_]?check[-_]?missing",
    ],
    # A10: Mishandling of Exceptional Conditions (NEW in 2025)
    OWASPCategory.A10_EXCEPTIONAL_CONDITIONS: [
        r"exception[-_]?handling",
        r"error[-_]?handling",
        r"fail[-_]?open",
        r"null[-_]?deref",
        r"null[-_]?pointer",
        r"unhandled[-_]?exception",
        r"bare[-_]?except",
        r"swallow[-_]?exception",
        r"missing[-_]?error[-_]?check",
        r"uncaught[-_]?exception",
        r"error[-_]?message[-_]?disclosure",
        r"stack[-_]?trace",
        r"sensitive[-_]?error",
    ],
    # A09: Logging & Alerting Failures
    OWASPCategory.A09_LOGGING_ALERTING_FAILURES: [
        r"log[-_]?forging",
        r"logging[-_]?sensitive[-_]?data",
        r"password[-_]?in[-_]?log",
        r"credentials[-_]?logged",
        r"pii[-_]?logged",
        r"missing[-_]?audit[-_]?log",
        r"audit[-_]?log[-_]?disabled",
    ],
    # A06: Insecure Design
    OWASPCategory.A06_INSECURE_DESIGN: [
        r"race[-_]?condition",
        r"toctou",
        r"time[-_]?of[-_]?check",
        r"missing[-_]?rate[-_]?limit",
        r"denial[-_]?of[-_]?service",
        r"dos[-_]?vulnerab",
        r"regex[-_]?dos",
        r"redos",
        r"resource[-_]?exhaustion",
        r"unbounded[-_]?allocation",
        r"infinite[-_]?loop",
        r"recursion[-_]?limit",
    ],
    # Container Security (Non-OWASP)
    OWASPCategory.CONTAINER_SECURITY: [
        r"dockerfile",
        r"docker[-_]?security",
        r"run[-_]?as[-_]?root",
        r"privileged[-_]?container",
        r"privileged[-_]?mode",
        r"cap[-_]?add",
        r"sys[-_]?admin",
        r"net[-_]?admin",
        r"host[-_]?network",
        r"host[-_]?pid",
        r"host[-_]?ipc",
        r"docker\.sock",
        r"seccomp[-_]?disabled",
        r"apparmor[-_]?disabled",
        r"missing[-_]?user",
        r"container.*root",
        r"kubernetes.*security",
        r"k8s.*security",
        r"pod[-_]?security",
    ],
}


def classify_sast_finding(rule_id: str, message: str = "") -> SASTClassification:
    """
    Classify a SAST finding by OWASP Top 10:2025 category.

    Args:
        rule_id: The Semgrep or other SAST tool rule ID
        message: Optional message/description for additional context

    Returns:
        SASTClassification with OWASP:2025 category and risk weights
    """
    combined = f"{rule_id} {message}".lower()

    # Check Container Security FIRST (specific, avoid false A01/A05 matches)
    for pattern in RULE_PATTERNS[OWASPCategory.CONTAINER_SECURITY]:
        if re.search(pattern, combined, re.IGNORECASE):
            return OWASP_DEFINITIONS[OWASPCategory.CONTAINER_SECURITY]

    # Check in severity/priority order
    priority_order = [
        OWASPCategory.A05_INJECTION,  # Highest severity
        OWASPCategory.A01_BROKEN_ACCESS_CONTROL,  # Includes SSRF
        OWASPCategory.A07_AUTHENTICATION_FAILURES,
        OWASPCategory.A04_CRYPTOGRAPHIC_FAILURES,
        OWASPCategory.A03_SOFTWARE_SUPPLY_CHAIN,  # New 2025
        OWASPCategory.A08_DATA_INTEGRITY_FAILURES,
        OWASPCategory.A02_SECURITY_MISCONFIGURATION,
        OWASPCategory.A10_EXCEPTIONAL_CONDITIONS,  # New 2025
        OWASPCategory.A06_INSECURE_DESIGN,
        OWASPCategory.A09_LOGGING_ALERTING_FAILURES,
    ]

    for category in priority_order:
        if category not in RULE_PATTERNS:
            continue
        for pattern in RULE_PATTERNS[category]:
            if re.search(pattern, combined, re.IGNORECASE):
                return OWASP_DEFINITIONS[category]

    # Generic security catch-all
    if any(word in combined for word in ["security", "vulnerab", "insecure", "unsafe"]):
        return OWASP_DEFINITIONS[OWASPCategory.CODE_QUALITY]

    return OWASP_DEFINITIONS[OWASPCategory.NOT_SECURITY]


def get_risk_weight(rule_id: str, message: str = "", is_reachable: bool = True) -> Tuple[int, SASTClassification]:
    """
    Get the risk weight for a SAST finding.

    Args:
        rule_id: The SAST rule ID
        message: Optional message for context
        is_reachable: Whether the finding is in reachable code

    Returns:
        Tuple of (risk_weight, classification)
    """
    classification = classify_sast_finding(rule_id, message)
    weight = classification.risk_weight_reachable if is_reachable else classification.risk_weight_unreachable
    return weight, classification


def is_owasp_critical(classification: SASTClassification) -> bool:
    """Check if this is a critical OWASP:2025 category (A01, A05, A07)"""
    return classification.owasp_category in {
        OWASPCategory.A01_BROKEN_ACCESS_CONTROL,
        OWASPCategory.A05_INJECTION,
        OWASPCategory.A07_AUTHENTICATION_FAILURES,
    }


def is_security_finding(classification: SASTClassification) -> bool:
    """Check if this is actually a security finding that affects risk score"""
    return classification.owasp_category != OWASPCategory.NOT_SECURITY


def get_owasp_summary() -> dict:
    """Get a summary of all OWASP:2025 categories and their weights"""
    return {
        cat.value: {
            "name": defn.owasp_name,
            "reachable_weight": defn.risk_weight_reachable,
            "unreachable_weight": defn.risk_weight_unreachable,
            "description": defn.description,
        }
        for cat, defn in OWASP_DEFINITIONS.items()
    }


# Backwards-compat alias: 2021 names → 2025 enum values
# Used by any callers that still use the old 2021 attribute names
A10_SSRF = OWASPCategory.A01_BROKEN_ACCESS_CONTROL  # SSRF → absorbed into A01:2025
A06_VULNERABLE_COMPONENTS = OWASPCategory.A03_SOFTWARE_SUPPLY_CHAIN  # A06:2021 → A03:2025
A05_SECURITY_MISCONFIGURATION = OWASPCategory.A02_SECURITY_MISCONFIGURATION  # A05:2021 → A02:2025
A03_INJECTION = OWASPCategory.A05_INJECTION  # A03:2021 → A05:2025
A04_INSECURE_DESIGN = OWASPCategory.A06_INSECURE_DESIGN  # A04:2021 → A06:2025
A02_CRYPTOGRAPHIC_FAILURES = OWASPCategory.A04_CRYPTOGRAPHIC_FAILURES  # A02:2021 → A04:2025


if __name__ == "__main__":
    test_cases = [
        ("generic.secrets.security.detected-aws-access-key", "AWS access key detected"),
        ("python.lang.security.audit.dangerous-subprocess-use", "subprocess.call with shell=True"),
        ("javascript.browser.security.insecure-document-method", "document.write used"),
        ("docker.security.missing-user", "Dockerfile does not use USER directive"),
        ("python.lang.security.audit.hardcoded-sql-expression", "SQL query with string formatting"),
        ("go.lang.security.audit.xss.direct-response-write", "Direct response write"),
        ("javascript.lang.security.audit.path-traversal", "Path traversal vulnerability"),
        ("python.lang.security.ssrf", "Server-side request forgery"),  # Now A01:2025
        ("supply-chain.malware.package", "Malicious npm package"),  # Now A03:2025
        ("error-handling.fail-open", "Missing error check leads to fail-open"),  # Now A10:2025
    ]

    logger.info("OWASP:2025 SAST Classification Test")
    logger.info("=" * 70)

    for rule_id, message in test_cases:
        classification = classify_sast_finding(rule_id, message)
        logger.info(f"\nRule: {rule_id}")
        logger.info(f" OWASP:2025 {classification.owasp_category.value} — {classification.owasp_name}")
        logger.info(
            f" Weight: {classification.risk_weight_reachable} (reachable) / {classification.risk_weight_unreachable} (unreachable)"
        )
        logger.info(f" Is Critical: {is_owasp_critical(classification)}")
