#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.

"""
OWASP LLM Top 10 Classification for AI Security Findings

Maps AI security rule IDs to OWASP LLM Top 10 (2025) categories with risk weights
and policy IDs. Used by the REACHABLE AI security module and risk scoring engine.

OWASP LLM Top 10 (2025):
- LLM01: Prompt Injection
- LLM02: Sensitive Information Disclosure
- LLM03: Supply Chain
- LLM04: Data and Model Poisoning
- LLM05: Improper Output Handling
- LLM06: Excessive Agency
- LLM07: System Prompt Leakage
- LLM08: Vector and Embedding Weaknesses
- LLM09: Misinformation
- LLM10: Unbounded Consumption

Policy ID Reference (from RISK_SCORING_MODEL.md):
- AI-001: Prompt injection (direct) - LLM01
- AI-002: Prompt injection (indirect/RAG) - LLM01
- AI-003: Sensitive data disclosure - LLM02
- AI-004: AI supply chain vulnerabilities - LLM03
- AI-005: Improper output handling - LLM05
- AI-006: Excessive agency/tool permissions - LLM06
- AI-007: System prompt leakage - LLM07
- AI-008: Unbounded resource consumption - LLM10
- AI-009: MCP tool security violations
- AI-010: Model control bypass
"""

import logging
import re
from dataclasses import dataclass, field
from enum import Enum
from typing import List, Optional, Tuple

# Initialize module-level logger
logger = logging.getLogger(__name__)


class OWASPLLMCategory(Enum):
    """OWASP LLM Top 10 2025 Categories"""

    LLM01_PROMPT_INJECTION = "LLM01"
    LLM02_SENSITIVE_DISCLOSURE = "LLM02"
    LLM03_SUPPLY_CHAIN = "LLM03"
    LLM04_DATA_POISONING = "LLM04"
    LLM05_OUTPUT_HANDLING = "LLM05"
    LLM06_EXCESSIVE_AGENCY = "LLM06"
    LLM07_PROMPT_LEAKAGE = "LLM07"
    LLM08_VECTOR_EMBEDDING = "LLM08"
    LLM09_MISINFORMATION = "LLM09"
    LLM10_UNBOUNDED_CONSUMPTION = "LLM10"

    NOT_AI_SECURITY = "NONE"


@dataclass
class AISecurityClassification:
    """Classification result for an AI security finding"""

    owasp_llm_category: OWASPLLMCategory
    owasp_llm_name: str
    policy_ids: List[str]  # REACHABLE policy IDs (AI-001, etc.)
    risk_weight_reachable: int
    risk_weight_unreachable: int
    cwe_ids: List[int]  # Related CWE IDs
    description: str
    severity: str  # CRITICAL, HIGH, MEDIUM, LOW, INFO

    # Guard-based risk reduction
    applicable_guards: List[str] = field(default_factory=list)
    max_guard_reduction: float = 0.0  # Maximum reduction when guards detected


# OWASP LLM Category Definitions with Risk Weights
OWASP_LLM_DEFINITIONS = {
    OWASPLLMCategory.LLM01_PROMPT_INJECTION: AISecurityClassification(
        owasp_llm_category=OWASPLLMCategory.LLM01_PROMPT_INJECTION,
        owasp_llm_name="Prompt Injection",
        policy_ids=["AI-001", "AI-002"],
        risk_weight_reachable=150,
        risk_weight_unreachable=40,
        cwe_ids=[77, 94],  # Command Injection, Code Injection
        description="User or external input flows to LLM prompts without proper sanitization, "
        "allowing manipulation of model behavior",
        severity="CRITICAL",
        applicable_guards=["input_validation", "injection_detection", "output_filtering"],
        max_guard_reduction=0.8,
    ),
    OWASPLLMCategory.LLM02_SENSITIVE_DISCLOSURE: AISecurityClassification(
        owasp_llm_category=OWASPLLMCategory.LLM02_SENSITIVE_DISCLOSURE,
        owasp_llm_name="Sensitive Information Disclosure",
        policy_ids=["AI-003"],
        risk_weight_reachable=80,
        risk_weight_unreachable=20,
        cwe_ids=[200, 359, 532],  # Info Exposure, Privacy Violation, Info Leak via Log
        description="PII, secrets, or sensitive data included in prompts or exposed in LLM outputs",
        severity="HIGH",
        applicable_guards=["pii_detection", "output_filtering", "data_masking"],
        max_guard_reduction=0.7,
    ),
    OWASPLLMCategory.LLM03_SUPPLY_CHAIN: AISecurityClassification(
        owasp_llm_category=OWASPLLMCategory.LLM03_SUPPLY_CHAIN,
        owasp_llm_name="Supply Chain",
        policy_ids=["AI-004"],
        risk_weight_reachable=100,
        risk_weight_unreachable=30,
        cwe_ids=[94, 502, 829],  # Code Injection, Deserialization, Untrusted Include
        description="Vulnerabilities in AI/ML packages, compromised models, or malicious plugins",
        severity="HIGH",
        applicable_guards=["dependency_scanning", "model_provenance"],
        max_guard_reduction=0.5,
    ),
    OWASPLLMCategory.LLM04_DATA_POISONING: AISecurityClassification(
        owasp_llm_category=OWASPLLMCategory.LLM04_DATA_POISONING,
        owasp_llm_name="Data and Model Poisoning",
        policy_ids=[],  # No specific detection yet
        risk_weight_reachable=60,
        risk_weight_unreachable=15,
        cwe_ids=[20],  # Improper Input Validation
        description="Malicious training data or fine-tuning that corrupts model behavior",
        severity="MEDIUM",
        applicable_guards=["data_validation", "model_versioning"],
        max_guard_reduction=0.4,
    ),
    OWASPLLMCategory.LLM05_OUTPUT_HANDLING: AISecurityClassification(
        owasp_llm_category=OWASPLLMCategory.LLM05_OUTPUT_HANDLING,
        owasp_llm_name="Improper Output Handling",
        policy_ids=["AI-005"],
        risk_weight_reachable=200,
        risk_weight_unreachable=50,
        cwe_ids=[94, 79, 89, 78],  # Code/XSS/SQLi/Cmd Injection
        description="LLM output executed or rendered without sanitization (eval, exec, innerHTML)",
        severity="CRITICAL",
        applicable_guards=["output_sanitization", "sandbox", "code_review"],
        max_guard_reduction=0.8,
    ),
    OWASPLLMCategory.LLM06_EXCESSIVE_AGENCY: AISecurityClassification(
        owasp_llm_category=OWASPLLMCategory.LLM06_EXCESSIVE_AGENCY,
        owasp_llm_name="Excessive Agency",
        policy_ids=["AI-006", "AI-009", "AI-010"],  # AI-009=MCP, AI-010=model controls (merged into LLM06)
        risk_weight_reachable=100,
        risk_weight_unreachable=25,
        cwe_ids=[250, 269],  # Execution with Unnecessary Privileges
        description="LLM/agent granted excessive permissions or autonomy (dangerous tools, no HITL)",
        severity="HIGH",
        applicable_guards=["tool_allowlist", "human_in_the_loop", "capability_restriction"],
        max_guard_reduction=0.9,
    ),
    OWASPLLMCategory.LLM07_PROMPT_LEAKAGE: AISecurityClassification(
        owasp_llm_category=OWASPLLMCategory.LLM07_PROMPT_LEAKAGE,
        owasp_llm_name="System Prompt Leakage",
        policy_ids=["AI-007"],
        risk_weight_reachable=50,
        risk_weight_unreachable=12,
        cwe_ids=[200],  # Information Exposure
        description="System prompts exposed in client code, logs, or extractable via prompt injection",
        severity="MEDIUM",
        applicable_guards=["prompt_protection", "output_filtering"],
        max_guard_reduction=0.6,
    ),
    OWASPLLMCategory.LLM08_VECTOR_EMBEDDING: AISecurityClassification(
        owasp_llm_category=OWASPLLMCategory.LLM08_VECTOR_EMBEDDING,
        owasp_llm_name="Vector and Embedding Weaknesses",
        policy_ids=[],  # No specific detection yet
        risk_weight_reachable=40,
        risk_weight_unreachable=10,
        cwe_ids=[20],  # Improper Input Validation
        description="Vulnerabilities in RAG systems, vector stores, or embedding pipelines",
        severity="MEDIUM",
        applicable_guards=["input_validation", "access_control"],
        max_guard_reduction=0.5,
    ),
    OWASPLLMCategory.LLM09_MISINFORMATION: AISecurityClassification(
        owasp_llm_category=OWASPLLMCategory.LLM09_MISINFORMATION,
        owasp_llm_name="Misinformation",
        policy_ids=[],  # Informational only
        risk_weight_reachable=20,
        risk_weight_unreachable=5,
        cwe_ids=[],
        description="Generation of false or misleading content (hallucinations, fabrications)",
        severity="LOW",
        applicable_guards=["fact_checking", "output_verification"],
        max_guard_reduction=0.3,
    ),
    OWASPLLMCategory.LLM10_UNBOUNDED_CONSUMPTION: AISecurityClassification(
        owasp_llm_category=OWASPLLMCategory.LLM10_UNBOUNDED_CONSUMPTION,
        owasp_llm_name="Unbounded Consumption",
        policy_ids=["AI-008"],
        risk_weight_reachable=30,
        risk_weight_unreachable=8,
        cwe_ids=[400],  # Uncontrolled Resource Consumption
        description="Missing rate limits, token limits, or cost controls on LLM calls",
        severity="MEDIUM",
        applicable_guards=["rate_limiting", "token_limiting", "cost_controls"],
        max_guard_reduction=0.7,
    ),
    OWASPLLMCategory.NOT_AI_SECURITY: AISecurityClassification(
        owasp_llm_category=OWASPLLMCategory.NOT_AI_SECURITY,
        owasp_llm_name="Not AI Security Related",
        policy_ids=[],
        risk_weight_reachable=0,
        risk_weight_unreachable=0,
        cwe_ids=[],
        description="Non-AI security finding, does not affect AI risk score",
        severity="INFO",
        applicable_guards=[],
        max_guard_reduction=0.0,
    ),
}


# Pattern matching for rule classification
# Maps regex patterns to OWASP LLM categories
RULE_PATTERNS = {
    # LLM01: Prompt Injection (CRITICAL)
    OWASPLLMCategory.LLM01_PROMPT_INJECTION: [
        r"llm01",
        r"prompt[-_]?inject",
        r"direct[-_]?inject",
        r"indirect[-_]?inject",
        r"rag[-_]?inject",
        r"user[-_]?input.*prompt",
        r"prompt.*user[-_]?input",
        r"taint.*prompt",
        r"prompt.*taint",
        r"fstring.*prompt",
        r"format.*prompt",
        r"template.*inject",
        r"jailbreak",
        r"dan[-_]?attack",
        r"prompt[-_]?leak",
        r"instruction[-_]?override",
        # Garak probe patterns
        r"garak[-_]?promptinject",
        r"garak[-_]?dan",
        r"garak[-_]?encoding",
        r"garak[-_]?continuation",
        r"garak[-_]?knownbadsignatures",
        r"garak[-_]?gcg",
        r"garak[-_]?snowball",
        r"garak[-_]?lmrc",
        # Corpus patterns
        r"corpus[-_]?tensortrust",
        r"corpus[-_]?promptinject",
        r"corpus[-_]?jailbreakbench",
    ],
    # LLM02: Sensitive Information Disclosure
    OWASPLLMCategory.LLM02_SENSITIVE_DISCLOSURE: [
        r"llm02",
        r"sensitive[-_]?disclos",
        r"pii[-_]?in[-_]?prompt",
        r"secret[-_]?in[-_]?prompt",
        r"credential[-_]?in[-_]?prompt",
        r"data[-_]?leak",
        r"training[-_]?data[-_]?extract",
        r"membership[-_]?inference",
        # Garak probe patterns
        r"garak[-_]?leakreplay",
        r"garak[-_]?realtoxic",
    ],
    # LLM03: Supply Chain
    OWASPLLMCategory.LLM03_SUPPLY_CHAIN: [
        r"llm03",
        r"ai[-_]?supply[-_]?chain",
        r"model[-_]?supply[-_]?chain",
        r"ml[-_]?package[-_]?vuln",
        r"langchain.*cve",
        r"openai.*cve",
        r"transformers.*cve",
        r"huggingface.*vuln",
        # Garak probe patterns
        r"garak[-_]?packagehallucination",
    ],
    # LLM05: Improper Output Handling (CRITICAL)
    OWASPLLMCategory.LLM05_OUTPUT_HANDLING: [
        r"llm05",
        r"output[-_]?handling",
        r"output[-_]?exec",
        r"llm[-_]?output.*eval",
        r"llm[-_]?output.*exec",
        r"llm[-_]?output.*shell",
        r"llm[-_]?output.*sql",
        r"llm[-_]?output.*html",
        r"llm[-_]?output.*innerhtml",
        r"response.*eval\(",
        r"response.*exec\(",
        r"code[-_]?interpreter",
        r"dangerous[-_]?exec",
        # Garak probe patterns
        r"garak[-_]?xss",
        r"garak[-_]?malwaregen",
    ],
    # LLM06: Excessive Agency
    OWASPLLMCategory.LLM06_EXCESSIVE_AGENCY: [
        r"llm06",
        r"excessive[-_]?agency",
        r"tool[-_]?permission",
        r"agent[-_]?permission",
        r"dangerous[-_]?tool",
        r"shell[-_]?tool",
        r"exec[-_]?tool",
        r"file[-_]?write[-_]?tool",
        r"network[-_]?tool",
        r"unrestricted[-_]?tool",
        r"all[-_]?tools",
        r"no[-_]?confirmation",
        r"missing[-_]?hitl",
        r"human[-_]?in[-_]?the[-_]?loop",
        # BUG 36 FIX: MCP patterns remapped here per AI-SECURITY-DETECTION-SPEC.md
        # MCP tool risks = Excessive Agency = LLM06
        r"mcp[-_]?",
        r"model[-_]?context[-_]?protocol",
        r"mcp[-_]?server",
        r"mcp[-_]?tool",
        r"mcp[-_]?resource",
        r"mcp[-_]?client",
        r"fastmcp",
        # MODEL_CONTROLS patterns also map to LLM06
        r"model[-_]?control",
        r"guard[-_]?bypass",
        r"filter[-_]?bypass",
        r"safety[-_]?bypass",
        r"content[-_]?filter",
        r"guardrail",
    ],
    # LLM07: System Prompt Leakage
    OWASPLLMCategory.LLM07_PROMPT_LEAKAGE: [
        r"llm07",
        r"system[-_]?prompt[-_]?leak",
        r"prompt[-_]?extract",
        r"system[-_]?prompt.*client",
        r"system[-_]?prompt.*log",
        r"prompt[-_]?expos",
    ],
    # LLM10: Unbounded Consumption
    OWASPLLMCategory.LLM10_UNBOUNDED_CONSUMPTION: [
        r"llm10",
        r"unbounded[-_]?consumption",
        r"no[-_]?rate[-_]?limit",
        r"missing[-_]?rate[-_]?limit",
        r"no[-_]?token[-_]?limit",
        r"missing[-_]?token[-_]?limit",
        r"resource[-_]?exhaustion",
        r"cost[-_]?control",
    ],
    # NOTE: MCP/MODEL_CONTROLS/AI_PRIMITIVE patterns merged into LLM06 (Excessive Agency)
    # per AI-SECURITY-DETECTION-SPEC.md — MCP tool risks = Excessive Agency = LLM06
    # AI primitives (generic model calls) are informational only → NOT_AI_SECURITY
}


def classify_ai_finding(rule_id: str, message: str = "", metadata: Optional[dict] = None) -> AISecurityClassification:
    """
    Classify an AI security finding by OWASP LLM category.

    Args:
        rule_id: The Semgrep or AI security rule ID (e.g., garak-dan-001, llm01.direct.python.openai)
        message: Optional message/description for additional context
        metadata: Optional rule metadata (may contain owasp_llm field)

    Returns:
        AISecurityClassification with OWASP LLM category and risk weights
    """
    # Check metadata first - direct classification
    if metadata:
        owasp_llm = metadata.get("owasp_llm") or metadata.get("owasp")
        if owasp_llm:
            owasp_llm = owasp_llm.upper()
            for cat in OWASPLLMCategory:
                if cat.value == owasp_llm:
                    return OWASP_LLM_DEFINITIONS[cat]

    combined = f"{rule_id} {message}".lower()

    # Check categories in priority order (critical first)
    priority_order = [
        OWASPLLMCategory.LLM05_OUTPUT_HANDLING,  # CRITICAL - code execution
        OWASPLLMCategory.LLM01_PROMPT_INJECTION,  # CRITICAL
        OWASPLLMCategory.LLM06_EXCESSIVE_AGENCY,  # HIGH — includes MCP + model controls
        OWASPLLMCategory.LLM02_SENSITIVE_DISCLOSURE,  # HIGH
        OWASPLLMCategory.LLM03_SUPPLY_CHAIN,  # HIGH
        OWASPLLMCategory.LLM07_PROMPT_LEAKAGE,  # MEDIUM
        OWASPLLMCategory.LLM10_UNBOUNDED_CONSUMPTION,  # MEDIUM
    ]

    for category in priority_order:
        if category not in RULE_PATTERNS:
            continue
        for pattern in RULE_PATTERNS[category]:
            if re.search(pattern, combined, re.IGNORECASE):
                return OWASP_LLM_DEFINITIONS[category]

    # Default to not AI security related
    return OWASP_LLM_DEFINITIONS[OWASPLLMCategory.NOT_AI_SECURITY]


def get_ai_risk_weight(
    rule_id: str,
    message: str = "",
    metadata: Optional[dict] = None,
    is_reachable: bool = True,
    guards_detected: Optional[List[str]] = None,
) -> Tuple[int, AISecurityClassification]:
    """
    Get the risk weight for an AI security finding.

    Args:
        rule_id: The AI security rule ID
        message: Optional message for context
        metadata: Optional rule metadata
        is_reachable: Whether the finding is in reachable code
        guards_detected: List of guard types detected on the code path

    Returns:
        Tuple of (risk_weight, classification)
    """
    classification = classify_ai_finding(rule_id, message, metadata)

    # Get base weight
    if is_reachable:
        weight = classification.risk_weight_reachable
    else:
        weight = classification.risk_weight_unreachable

    # Apply guard reduction
    if guards_detected and classification.applicable_guards:
        matching_guards = set(guards_detected) & set(classification.applicable_guards)
        if matching_guards:
            # Each matching guard reduces risk proportionally
            reduction_per_guard = classification.max_guard_reduction / len(classification.applicable_guards)
            total_reduction = min(reduction_per_guard * len(matching_guards), classification.max_guard_reduction)
            weight = int(weight * (1 - total_reduction))

    return weight, classification


def is_critical_ai_finding(classification: AISecurityClassification) -> bool:
    """Check if this is a critical AI security finding"""
    return classification.severity == "CRITICAL"


def is_ai_security_finding(classification: AISecurityClassification) -> bool:
    """Check if this is actually an AI security finding that affects risk score"""
    return classification.owasp_llm_category != OWASPLLMCategory.NOT_AI_SECURITY


def get_policy_ids_for_category(category: OWASPLLMCategory) -> List[str]:
    """Get REACHABLE policy IDs for an OWASP LLM category"""
    if category in OWASP_LLM_DEFINITIONS:
        return OWASP_LLM_DEFINITIONS[category].policy_ids
    return []


# Export summary for documentation
def get_owasp_llm_summary() -> dict:
    """Get a summary of all OWASP LLM categories and their weights"""
    return {
        cat.value: {
            "name": defn.owasp_llm_name,
            "policy_ids": defn.policy_ids,
            "severity": defn.severity,
            "reachable_weight": defn.risk_weight_reachable,
            "unreachable_weight": defn.risk_weight_unreachable,
            "cwe_ids": defn.cwe_ids,
            "description": defn.description,
            "applicable_guards": defn.applicable_guards,
            "max_guard_reduction": defn.max_guard_reduction,
        }
        for cat, defn in OWASP_LLM_DEFINITIONS.items()
        if cat != OWASPLLMCategory.NOT_AI_SECURITY
    }


if __name__ == "__main__":
    # Test classification
    test_cases = [
        ("llm01.direct.python.openai-chat", "Direct prompt injection via OpenAI", {}),
        ("garak-dan-001", "DAN jailbreak pattern from Garak", {"owasp_llm": "LLM01"}),
        ("garak-promptinject-005", "Instruction override pattern", {}),
        ("corpus-tensortrust-001", "Prompt injection from Tensor Trust", {}),
        ("llm05.exec.python.eval", "LLM output executed via eval()", {}),
        ("mcp.tool.dangerous.python.exec", "MCP tool allows code execution", {}),
        ("llm06.tool.python.shell_exec", "Tool allows shell command execution", {}),
        ("ai-primitives-base.openai-call", "OpenAI API call detected", {}),
    ]

    logger.info("OWASP LLM Classification Test")
    logger.info("=" * 80)

    for rule_id, message, metadata in test_cases:
        classification = classify_ai_finding(rule_id, message, metadata)
        weight, _ = get_ai_risk_weight(rule_id, message, metadata, is_reachable=True)

        logger.info(f"\nRule: {rule_id}")
        logger.info(f" OWASP LLM: {classification.owasp_llm_category.value} - {classification.owasp_llm_name}")
        logger.info(f" Severity: {classification.severity}")
        logger.info(f" Policy IDs: {classification.policy_ids}")
        logger.info(f" Weight: {weight} (reachable)")
        logger.info(f" CWE IDs: {classification.cwe_ids}")
        logger.info(f" Guards: {classification.applicable_guards}")
