#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.

"""
REACHABLE Security Standards Mapper

Maps security findings to multiple industry standards for comprehensive
compliance reporting across commercial, federal, and defense sectors.

SUPPORTED STANDARDS:

Technical Standards (Root Cause):
- CWE (Common Weakness Enumeration) - The technical "what"
- OWASP Top 10 2021 - High-level risk categories
- ASVS (Application Security Verification Standard) - Deep audit checklist (Levels 1-3)
- SANS/CWE Top 25 - Most dangerous software errors

Industry Compliance:
- PCI DSS 4.0 - Payment Card Industry (credit cards)
- HIPAA - Healthcare (patient data privacy)
- SOC 2 - SaaS/Cloud (Trust Service Criteria)

US Federal Government:
- NIST 800-53 Rev 5 - Security Controls for Federal Systems (FedRAMP baseline)
- NIST 800-218 (SSDF) - Secure Software Development Framework
- FISMA - Federal Information Security Management Act

US Defense / DoD:
- DISA STIG - Defense Information Systems Agency Security Technical Implementation Guides
- CMMC 2.0 - Cybersecurity Maturity Model Certification (defense contractors)
- NIST 800-171 - Protecting CUI (Controlled Unclassified Information)

Example Multi-Standard Mapping:
    Hardcoded API key maps to:
    - CWE: CWE-798 (Use of Hard-coded Credentials)
    - OWASP: A07:2021 (Identification and Authentication Failures)
    - ASVS: V2.10.4 (Secrets Management)
    - PCI DSS: 3.5 (Protect stored cryptographic keys)
    - SOC 2: CC6.1 (Logical Access Controls)
    - NIST 800-53: IA-5 (Authenticator Management)
    - DISA STIG: APP-SEC-001 (Application must not contain embedded credentials)
    - CMMC: AC.L2-3.1.19 (Encrypt CUI on mobile devices)
"""

import logging
import re
from dataclasses import dataclass, field
from enum import Enum
from typing import Dict, List, Optional, Tuple

# Initialize module-level logger
logger = logging.getLogger(__name__)

# =============================================================================
# OWASP Top 10 2021 Categories
# =============================================================================


class OWASPCategory(Enum):
    """OWASP Top 10 2021 Categories"""

    A01 = "A01:2021"  # Broken Access Control
    A02 = "A02:2021"  # Cryptographic Failures
    A03 = "A03:2021"  # Injection
    A04 = "A04:2021"  # Insecure Design
    A05 = "A05:2021"  # Security Misconfiguration
    A06 = "A06:2021"  # Vulnerable and Outdated Components
    A07 = "A07:2021"  # Identification and Authentication Failures
    A08 = "A08:2021"  # Software and Data Integrity Failures
    A09 = "A09:2021"  # Security Logging and Monitoring Failures
    A10 = "A10:2021"  # Server-Side Request Forgery


OWASP_NAMES = {
    OWASPCategory.A01: "Broken Access Control",
    OWASPCategory.A02: "Cryptographic Failures",
    OWASPCategory.A03: "Injection",
    OWASPCategory.A04: "Insecure Design",
    OWASPCategory.A05: "Security Misconfiguration",
    OWASPCategory.A06: "Vulnerable and Outdated Components",
    OWASPCategory.A07: "Identification and Authentication Failures",
    OWASPCategory.A08: "Software and Data Integrity Failures",
    OWASPCategory.A09: "Security Logging and Monitoring Failures",
    OWASPCategory.A10: "Server-Side Request Forgery",
}

# =============================================================================
# CWE Definitions with Multi-Standard Mapping
# =============================================================================


@dataclass
class CWEDefinition:
    """Complete CWE definition with multi-standard mapping"""

    cwe_id: str
    name: str
    description: str
    owasp: OWASPCategory

    # Risk scoring
    risk_weight_reachable: int
    risk_weight_unreachable: int

    # ASVS mapping (Application Security Verification Standard)
    asvs_requirements: List[str] = field(default_factory=list)
    asvs_level: int = 1  # 1, 2, or 3

    # SANS/CWE Top 25 (2023)
    sans_top_25_rank: Optional[int] = None

    # Industry Compliance
    pci_dss: List[str] = field(default_factory=list)  # PCI DSS 4.0 requirements
    hipaa: List[str] = field(default_factory=list)  # HIPAA safeguards
    soc2: List[str] = field(default_factory=list)  # SOC 2 Trust Principles

    # US Federal Government
    nist_ssdf: List[str] = field(default_factory=list)  # NIST 800-218 SSDF practices
    nist_800_53: List[str] = field(default_factory=list)  # NIST 800-53 Rev 5 controls
    fisma: List[str] = field(default_factory=list)  # FISMA impact levels

    # US Defense / DoD
    disa_stig: List[str] = field(default_factory=list)  # DISA STIG rules
    cmmc: List[str] = field(default_factory=list)  # CMMC 2.0 practices
    nist_800_171: List[str] = field(default_factory=list)  # CUI protection

    # Additional metadata
    likelihood: str = "Medium"  # Low, Medium, High
    impact: str = "Medium"  # Low, Medium, High
    remediation_effort: str = "Medium"  # Low, Medium, High


# =============================================================================
# Federal/Defense Standards Reference
# =============================================================================

# NIST 800-53 Rev 5 Control Families (for reference)
NIST_800_53_FAMILIES = {
    "AC": "Access Control",
    "AT": "Awareness and Training",
    "AU": "Audit and Accountability",
    "CA": "Assessment, Authorization, and Monitoring",
    "CM": "Configuration Management",
    "CP": "Contingency Planning",
    "IA": "Identification and Authentication",
    "IR": "Incident Response",
    "MA": "Maintenance",
    "MP": "Media Protection",
    "PE": "Physical and Environmental Protection",
    "PL": "Planning",
    "PM": "Program Management",
    "PS": "Personnel Security",
    "PT": "PII Processing and Transparency",
    "RA": "Risk Assessment",
    "SA": "System and Services Acquisition",
    "SC": "System and Communications Protection",
    "SI": "System and Information Integrity",
    "SR": "Supply Chain Risk Management",
}

# CMMC 2.0 Domains (for reference)
CMMC_DOMAINS = {
    "AC": "Access Control",
    "AM": "Asset Management",
    "AT": "Awareness and Training",
    "AU": "Audit and Accountability",
    "CA": "Configuration Management",
    "IA": "Identification and Authentication",
    "IR": "Incident Response",
    "MA": "Maintenance",
    "MP": "Media Protection",
    "PE": "Physical Protection",
    "PS": "Personnel Security",
    "RA": "Risk Assessment",
    "RE": "Recovery",
    "RM": "Risk Management",
    "SC": "Security Assessment",
    "SI": "Situational Awareness",
    "SS": "System and Communications Protection",
}

# =============================================================================
# CWE Database with Full Mappings
# =============================================================================

CWE_DATABASE: Dict[str, CWEDefinition] = {
    # =========================================================================
    # A03: Injection (CRITICAL - 200 pts reachable)
    # =========================================================================
    "CWE-89": CWEDefinition(
        cwe_id="CWE-89",
        name="SQL Injection",
        description="Improper neutralization of special elements used in an SQL command",
        owasp=OWASPCategory.A03,
        risk_weight_reachable=200,
        risk_weight_unreachable=50,
        asvs_requirements=["V5.3.4", "V5.3.5"],
        asvs_level=1,
        sans_top_25_rank=3,
        # Industry Compliance
        pci_dss=["6.2.4", "6.5.1"],
        hipaa=["164.312(a)(1)", "164.312(b)"],
        soc2=["CC6.1", "CC7.1"],
        # US Federal
        nist_ssdf=["PW.5.1", "PW.6.1"],
        nist_800_53=["SI-10", "SI-11", "SC-18"],
        fisma=["High"],
        # US Defense
        disa_stig=["APSC-DV-001460", "APSC-DV-002520"],
        cmmc=["SI.L1-3.14.1", "SI.L2-3.14.6"],
        nist_800_171=["3.14.1", "3.14.6"],
        likelihood="High",
        impact="High",
        remediation_effort="Medium",
    ),
    "CWE-79": CWEDefinition(
        cwe_id="CWE-79",
        name="Cross-site Scripting (XSS)",
        description="Improper neutralization of input during web page generation",
        owasp=OWASPCategory.A03,
        risk_weight_reachable=200,
        risk_weight_unreachable=50,
        asvs_requirements=["V5.3.3", "V14.4.1"],
        asvs_level=1,
        sans_top_25_rank=2,
        # Industry Compliance
        pci_dss=["6.2.4", "6.5.7"],
        soc2=["CC6.1"],
        # US Federal
        nist_ssdf=["PW.5.1"],
        nist_800_53=["SI-10", "SC-18"],
        fisma=["Moderate"],
        # US Defense
        disa_stig=["APSC-DV-002490", "APSC-DV-002500"],
        cmmc=["SI.L1-3.14.1"],
        nist_800_171=["3.14.1"],
        likelihood="High",
        impact="Medium",
        remediation_effort="Low",
    ),
    "CWE-78": CWEDefinition(
        cwe_id="CWE-78",
        name="OS Command Injection",
        description="Improper neutralization of special elements used in an OS command",
        owasp=OWASPCategory.A03,
        risk_weight_reachable=200,
        risk_weight_unreachable=50,
        asvs_requirements=["V5.3.8"],
        asvs_level=1,
        sans_top_25_rank=5,
        # Industry Compliance
        pci_dss=["6.2.4", "6.5.1"],
        hipaa=["164.312(a)(1)"],
        soc2=["CC6.1", "CC7.1"],
        # US Federal
        nist_ssdf=["PW.5.1"],
        nist_800_53=["SI-10", "SI-3", "SC-18"],
        fisma=["High"],
        # US Defense
        disa_stig=["APSC-DV-001460", "APSC-DV-002530"],
        cmmc=["SI.L1-3.14.1", "SI.L2-3.14.6"],
        nist_800_171=["3.14.1", "3.14.6"],
        likelihood="Medium",
        impact="High",
        remediation_effort="Medium",
    ),
    "CWE-77": CWEDefinition(
        cwe_id="CWE-77",
        name="Command Injection",
        description="Improper neutralization of special elements used in a command",
        owasp=OWASPCategory.A03,
        risk_weight_reachable=200,
        risk_weight_unreachable=50,
        asvs_requirements=["V5.3.8"],
        asvs_level=1,
        sans_top_25_rank=None,
        pci_dss=["6.2.4"],
        soc2=["CC6.1"],
        likelihood="Medium",
        impact="High",
    ),
    "CWE-611": CWEDefinition(
        cwe_id="CWE-611",
        name="XML External Entity (XXE)",
        description="Improper restriction of XML external entity reference",
        owasp=OWASPCategory.A03,
        risk_weight_reachable=200,
        risk_weight_unreachable=50,
        asvs_requirements=["V5.5.2"],
        asvs_level=1,
        sans_top_25_rank=None,
        pci_dss=["6.2.4"],
        soc2=["CC6.1"],
        likelihood="Medium",
        impact="High",
    ),
    "CWE-94": CWEDefinition(
        cwe_id="CWE-94",
        name="Code Injection",
        description="Improper control of generation of code",
        owasp=OWASPCategory.A03,
        risk_weight_reachable=200,
        risk_weight_unreachable=50,
        asvs_requirements=["V5.3.8"],
        asvs_level=1,
        sans_top_25_rank=None,
        pci_dss=["6.2.4"],
        soc2=["CC6.1"],
        likelihood="Medium",
        impact="High",
    ),
    "CWE-917": CWEDefinition(
        cwe_id="CWE-917",
        name="Expression Language Injection",
        description="Improper neutralization of special elements used in an expression language statement",
        owasp=OWASPCategory.A03,
        risk_weight_reachable=200,
        risk_weight_unreachable=50,
        asvs_requirements=["V5.3.8"],
        asvs_level=2,
        likelihood="Medium",
        impact="High",
    ),
    "CWE-90": CWEDefinition(
        cwe_id="CWE-90",
        name="LDAP Injection",
        description="Improper neutralization of special elements used in an LDAP query",
        owasp=OWASPCategory.A03,
        risk_weight_reachable=200,
        risk_weight_unreachable=50,
        asvs_requirements=["V5.3.7"],
        asvs_level=2,
        pci_dss=["6.2.4"],
        soc2=["CC6.1"],
        likelihood="Low",
        impact="High",
    ),
    # =========================================================================
    # A01: Broken Access Control (150 pts reachable)
    # =========================================================================
    "CWE-22": CWEDefinition(
        cwe_id="CWE-22",
        name="Path Traversal",
        description="Improper limitation of a pathname to a restricted directory",
        owasp=OWASPCategory.A01,
        risk_weight_reachable=150,
        risk_weight_unreachable=38,
        asvs_requirements=["V12.3.1", "V12.3.2"],
        asvs_level=1,
        sans_top_25_rank=8,
        pci_dss=["6.2.4", "6.5.8"],
        soc2=["CC6.1"],
        nist_ssdf=["PW.5.1"],
        likelihood="High",
        impact="Medium",
    ),
    "CWE-352": CWEDefinition(
        cwe_id="CWE-352",
        name="Cross-Site Request Forgery (CSRF)",
        description="Cross-site request forgery vulnerability",
        owasp=OWASPCategory.A01,
        risk_weight_reachable=150,
        risk_weight_unreachable=38,
        asvs_requirements=["V4.2.2"],
        asvs_level=1,
        sans_top_25_rank=9,
        pci_dss=["6.5.9"],
        soc2=["CC6.1"],
        likelihood="Medium",
        impact="Medium",
    ),
    "CWE-639": CWEDefinition(
        cwe_id="CWE-639",
        name="Insecure Direct Object Reference (IDOR)",
        description="Authorization bypass through user-controlled key",
        owasp=OWASPCategory.A01,
        risk_weight_reachable=150,
        risk_weight_unreachable=38,
        asvs_requirements=["V4.1.2", "V4.2.1"],
        asvs_level=1,
        sans_top_25_rank=None,
        pci_dss=["6.5.4"],
        hipaa=["164.312(a)(1)"],
        soc2=["CC6.1"],
        likelihood="High",
        impact="Medium",
    ),
    "CWE-862": CWEDefinition(
        cwe_id="CWE-862",
        name="Missing Authorization",
        description="Missing authorization check",
        owasp=OWASPCategory.A01,
        risk_weight_reachable=150,
        risk_weight_unreachable=38,
        asvs_requirements=["V4.1.1"],
        asvs_level=1,
        sans_top_25_rank=11,
        pci_dss=["7.1", "7.2"],
        hipaa=["164.312(a)(1)"],
        soc2=["CC6.1", "CC6.2"],
        likelihood="High",
        impact="High",
    ),
    "CWE-863": CWEDefinition(
        cwe_id="CWE-863",
        name="Incorrect Authorization",
        description="Incorrect authorization check",
        owasp=OWASPCategory.A01,
        risk_weight_reachable=150,
        risk_weight_unreachable=38,
        asvs_requirements=["V4.1.3"],
        asvs_level=1,
        sans_top_25_rank=None,
        pci_dss=["7.1"],
        hipaa=["164.312(a)(1)"],
        soc2=["CC6.1"],
        likelihood="Medium",
        impact="High",
    ),
    "CWE-601": CWEDefinition(
        cwe_id="CWE-601",
        name="Open Redirect",
        description="URL redirection to untrusted site",
        owasp=OWASPCategory.A01,
        risk_weight_reachable=150,
        risk_weight_unreachable=38,
        asvs_requirements=["V5.1.5"],
        asvs_level=1,
        pci_dss=["6.2.4"],
        soc2=["CC6.1"],
        likelihood="Medium",
        impact="Low",
    ),
    "CWE-269": CWEDefinition(
        cwe_id="CWE-269",
        name="Improper Privilege Management",
        description="Improper privilege management allowing escalation",
        owasp=OWASPCategory.A01,
        risk_weight_reachable=150,
        risk_weight_unreachable=38,
        asvs_requirements=["V4.3.1"],
        asvs_level=1,
        sans_top_25_rank=None,
        pci_dss=["7.1", "7.2"],
        hipaa=["164.312(a)(1)"],
        soc2=["CC6.1", "CC6.2"],
        likelihood="Medium",
        impact="High",
    ),
    # =========================================================================
    # A07: Identification and Authentication Failures (150 pts reachable)
    # =========================================================================
    "CWE-798": CWEDefinition(
        cwe_id="CWE-798",
        name="Hardcoded Credentials",
        description="Use of hard-coded credentials in source code",
        owasp=OWASPCategory.A07,
        risk_weight_reachable=150,
        risk_weight_unreachable=38,
        asvs_requirements=["V2.10.4", "V3.5.2"],
        asvs_level=1,
        sans_top_25_rank=15,
        # Industry Compliance
        pci_dss=["3.5", "8.2.1"],
        hipaa=["164.312(d)", "164.312(a)(1)"],
        soc2=["CC6.1", "CC6.7"],
        # US Federal
        nist_ssdf=["PO.5.2", "PS.1.1"],
        nist_800_53=["IA-5", "SC-12", "SC-13"],
        fisma=["High"],
        # US Defense
        disa_stig=["APSC-DV-001460", "APSC-DV-002440"],
        cmmc=["IA.L2-3.5.10", "SC.L2-3.13.11"],
        nist_800_171=["3.5.10", "3.13.11"],
        likelihood="High",
        impact="High",
        remediation_effort="Low",
    ),
    "CWE-287": CWEDefinition(
        cwe_id="CWE-287",
        name="Improper Authentication",
        description="Improper authentication allowing bypass",
        owasp=OWASPCategory.A07,
        risk_weight_reachable=150,
        risk_weight_unreachable=38,
        asvs_requirements=["V2.1.1"],
        asvs_level=1,
        sans_top_25_rank=13,
        pci_dss=["8.2", "8.3"],
        hipaa=["164.312(d)"],
        soc2=["CC6.1"],
        likelihood="High",
        impact="High",
    ),
    "CWE-384": CWEDefinition(
        cwe_id="CWE-384",
        name="Session Fixation",
        description="Session fixation vulnerability",
        owasp=OWASPCategory.A07,
        risk_weight_reachable=150,
        risk_weight_unreachable=38,
        asvs_requirements=["V3.2.1"],
        asvs_level=1,
        pci_dss=["6.5.10"],
        soc2=["CC6.1"],
        likelihood="Medium",
        impact="Medium",
    ),
    "CWE-613": CWEDefinition(
        cwe_id="CWE-613",
        name="Insufficient Session Expiration",
        description="Session does not expire or expires too slowly",
        owasp=OWASPCategory.A07,
        risk_weight_reachable=150,
        risk_weight_unreachable=38,
        asvs_requirements=["V3.3.1", "V3.3.2"],
        asvs_level=1,
        pci_dss=["8.1.8"],
        hipaa=["164.312(d)"],
        soc2=["CC6.1"],
        likelihood="Medium",
        impact="Medium",
    ),
    "CWE-521": CWEDefinition(
        cwe_id="CWE-521",
        name="Weak Password Requirements",
        description="Weak password requirements allowing guessable passwords",
        owasp=OWASPCategory.A07,
        risk_weight_reachable=150,
        risk_weight_unreachable=38,
        asvs_requirements=["V2.1.1", "V2.1.7"],
        asvs_level=1,
        pci_dss=["8.2.3"],
        soc2=["CC6.1"],
        likelihood="High",
        impact="Medium",
    ),
    # =========================================================================
    # A10: Server-Side Request Forgery (150 pts reachable)
    # =========================================================================
    "CWE-918": CWEDefinition(
        cwe_id="CWE-918",
        name="Server-Side Request Forgery (SSRF)",
        description="Server-side request forgery vulnerability",
        owasp=OWASPCategory.A10,
        risk_weight_reachable=150,
        risk_weight_unreachable=38,
        asvs_requirements=["V5.2.6"],
        asvs_level=1,
        sans_top_25_rank=19,
        pci_dss=["6.2.4"],
        soc2=["CC6.1", "CC6.6"],
        likelihood="Medium",
        impact="High",
    ),
    # =========================================================================
    # A02: Cryptographic Failures (80 pts reachable)
    # =========================================================================
    "CWE-327": CWEDefinition(
        cwe_id="CWE-327",
        name="Broken Cryptographic Algorithm",
        description="Use of a broken or risky cryptographic algorithm",
        owasp=OWASPCategory.A02,
        risk_weight_reachable=80,
        risk_weight_unreachable=20,
        asvs_requirements=["V6.2.1", "V6.2.5"],
        asvs_level=1,
        sans_top_25_rank=None,
        pci_dss=["3.4", "4.1"],
        hipaa=["164.312(e)(2)(ii)"],
        soc2=["CC6.1", "CC6.7"],
        likelihood="Medium",
        impact="High",
    ),
    "CWE-328": CWEDefinition(
        cwe_id="CWE-328",
        name="Weak Hash",
        description="Use of weak hash algorithm (MD5, SHA1)",
        owasp=OWASPCategory.A02,
        risk_weight_reachable=80,
        risk_weight_unreachable=20,
        asvs_requirements=["V6.2.1"],
        asvs_level=1,
        pci_dss=["3.4"],
        soc2=["CC6.7"],
        likelihood="Medium",
        impact="Medium",
    ),
    "CWE-330": CWEDefinition(
        cwe_id="CWE-330",
        name="Insufficient Randomness",
        description="Use of insufficiently random values",
        owasp=OWASPCategory.A02,
        risk_weight_reachable=80,
        risk_weight_unreachable=20,
        asvs_requirements=["V6.3.1"],
        asvs_level=1,
        sans_top_25_rank=None,
        pci_dss=["3.5.2"],
        soc2=["CC6.7"],
        likelihood="Medium",
        impact="Medium",
    ),
    "CWE-338": CWEDefinition(
        cwe_id="CWE-338",
        name="Weak PRNG",
        description="Use of cryptographically weak pseudo-random number generator",
        owasp=OWASPCategory.A02,
        risk_weight_reachable=80,
        risk_weight_unreachable=20,
        asvs_requirements=["V6.3.1"],
        asvs_level=1,
        pci_dss=["3.5.2"],
        soc2=["CC6.7"],
        likelihood="Medium",
        impact="Medium",
    ),
    "CWE-326": CWEDefinition(
        cwe_id="CWE-326",
        name="Inadequate Encryption Strength",
        description="Inadequate encryption strength (short keys)",
        owasp=OWASPCategory.A02,
        risk_weight_reachable=80,
        risk_weight_unreachable=20,
        asvs_requirements=["V6.2.2"],
        asvs_level=1,
        pci_dss=["3.5", "4.1"],
        hipaa=["164.312(e)(2)(ii)"],
        soc2=["CC6.7"],
        likelihood="Low",
        impact="High",
    ),
    "CWE-295": CWEDefinition(
        cwe_id="CWE-295",
        name="Improper Certificate Validation",
        description="Improper certificate validation",
        owasp=OWASPCategory.A02,
        risk_weight_reachable=80,
        risk_weight_unreachable=20,
        asvs_requirements=["V9.2.1"],
        asvs_level=1,
        sans_top_25_rank=None,
        pci_dss=["4.1"],
        soc2=["CC6.7"],
        likelihood="Medium",
        impact="High",
    ),
    "CWE-321": CWEDefinition(
        cwe_id="CWE-321",
        name="Hardcoded Cryptographic Key",
        description="Use of hard-coded cryptographic key",
        owasp=OWASPCategory.A02,
        risk_weight_reachable=80,
        risk_weight_unreachable=20,
        asvs_requirements=["V6.4.1"],
        asvs_level=1,
        pci_dss=["3.5.2"],
        soc2=["CC6.7"],
        likelihood="High",
        impact="High",
    ),
    # =========================================================================
    # A08: Software and Data Integrity Failures (60 pts reachable)
    # =========================================================================
    "CWE-502": CWEDefinition(
        cwe_id="CWE-502",
        name="Deserialization of Untrusted Data",
        description="Deserialization of untrusted data",
        owasp=OWASPCategory.A08,
        risk_weight_reachable=60,
        risk_weight_unreachable=15,
        asvs_requirements=["V5.5.1"],
        asvs_level=1,
        sans_top_25_rank=14,
        pci_dss=["6.2.4"],
        soc2=["CC6.1"],
        likelihood="Medium",
        impact="High",
    ),
    "CWE-915": CWEDefinition(
        cwe_id="CWE-915",
        name="Mass Assignment",
        description="Improperly controlled modification of dynamically-determined object attributes",
        owasp=OWASPCategory.A08,
        risk_weight_reachable=60,
        risk_weight_unreachable=15,
        asvs_requirements=["V5.1.3"],
        asvs_level=1,
        pci_dss=["6.2.4"],
        soc2=["CC6.1"],
        likelihood="Medium",
        impact="Medium",
    ),
    "CWE-1321": CWEDefinition(
        cwe_id="CWE-1321",
        name="Prototype Pollution",
        description="Improperly controlled modification of object prototype attributes",
        owasp=OWASPCategory.A08,
        risk_weight_reachable=60,
        risk_weight_unreachable=15,
        asvs_requirements=["V5.5.1"],
        asvs_level=2,
        pci_dss=["6.2.4"],
        soc2=["CC6.1"],
        likelihood="Medium",
        impact="Medium",
    ),
    # =========================================================================
    # A05: Security Misconfiguration (60 pts reachable)
    # =========================================================================
    "CWE-16": CWEDefinition(
        cwe_id="CWE-16",
        name="Configuration",
        description="Security misconfiguration",
        owasp=OWASPCategory.A05,
        risk_weight_reachable=60,
        risk_weight_unreachable=15,
        asvs_requirements=["V14.1.1"],
        asvs_level=1,
        pci_dss=["2.2"],
        soc2=["CC6.1"],
        likelihood="High",
        impact="Medium",
    ),
    "CWE-209": CWEDefinition(
        cwe_id="CWE-209",
        name="Error Message Information Exposure",
        description="Generation of error message containing sensitive information",
        owasp=OWASPCategory.A05,
        risk_weight_reachable=60,
        risk_weight_unreachable=15,
        asvs_requirements=["V7.4.1"],
        asvs_level=1,
        pci_dss=["6.5.5"],
        soc2=["CC6.1"],
        likelihood="High",
        impact="Low",
    ),
    "CWE-1004": CWEDefinition(
        cwe_id="CWE-1004",
        name="Sensitive Cookie Without HttpOnly",
        description="Sensitive cookie without HttpOnly flag",
        owasp=OWASPCategory.A05,
        risk_weight_reachable=60,
        risk_weight_unreachable=15,
        asvs_requirements=["V3.4.2"],
        asvs_level=1,
        pci_dss=["6.5.10"],
        soc2=["CC6.1"],
        likelihood="Medium",
        impact="Medium",
    ),
    "CWE-614": CWEDefinition(
        cwe_id="CWE-614",
        name="Sensitive Cookie Without Secure",
        description="Sensitive cookie in HTTPS session without Secure attribute",
        owasp=OWASPCategory.A05,
        risk_weight_reachable=60,
        risk_weight_unreachable=15,
        asvs_requirements=["V3.4.1"],
        asvs_level=1,
        pci_dss=["6.5.10"],
        soc2=["CC6.1"],
        likelihood="Medium",
        impact="Medium",
    ),
    # =========================================================================
    # A04: Insecure Design (30 pts reachable)
    # =========================================================================
    "CWE-362": CWEDefinition(
        cwe_id="CWE-362",
        name="Race Condition",
        description="Concurrent execution using shared resource with improper synchronization",
        owasp=OWASPCategory.A04,
        risk_weight_reachable=30,
        risk_weight_unreachable=8,
        asvs_requirements=["V11.1.7"],
        asvs_level=2,
        sans_top_25_rank=21,
        pci_dss=["6.2.4"],
        soc2=["CC6.1"],
        likelihood="Low",
        impact="Medium",
    ),
    "CWE-367": CWEDefinition(
        cwe_id="CWE-367",
        name="TOCTOU Race Condition",
        description="Time-of-check time-of-use race condition",
        owasp=OWASPCategory.A04,
        risk_weight_reachable=30,
        risk_weight_unreachable=8,
        asvs_requirements=["V11.1.7"],
        asvs_level=2,
        pci_dss=["6.2.4"],
        soc2=["CC6.1"],
        likelihood="Low",
        impact="Medium",
    ),
    "CWE-400": CWEDefinition(
        cwe_id="CWE-400",
        name="Resource Exhaustion",
        description="Uncontrolled resource consumption",
        owasp=OWASPCategory.A04,
        risk_weight_reachable=30,
        risk_weight_unreachable=8,
        asvs_requirements=["V11.1.4"],
        asvs_level=1,
        pci_dss=["6.2.4"],
        soc2=["CC6.1", "CC7.1"],
        likelihood="Medium",
        impact="Medium",
    ),
    "CWE-1333": CWEDefinition(
        cwe_id="CWE-1333",
        name="ReDoS",
        description="Inefficient regular expression complexity",
        owasp=OWASPCategory.A04,
        risk_weight_reachable=30,
        risk_weight_unreachable=8,
        asvs_requirements=["V5.5.4"],
        asvs_level=2,
        soc2=["CC6.1"],
        likelihood="Low",
        impact="Medium",
    ),
    # =========================================================================
    # A09: Security Logging and Monitoring Failures (20 pts reachable)
    # =========================================================================
    "CWE-117": CWEDefinition(
        cwe_id="CWE-117",
        name="Log Injection",
        description="Improper output neutralization for logs",
        owasp=OWASPCategory.A09,
        risk_weight_reachable=20,
        risk_weight_unreachable=5,
        asvs_requirements=["V7.1.1"],
        asvs_level=1,
        soc2=["CC7.2"],
        nist_800_53=["AU-3", "AU-9"],
        disa_stig=["APSC-DV-001460"],
        likelihood="Medium",
        impact="Low",
    ),
    "CWE-532": CWEDefinition(
        cwe_id="CWE-532",
        name="Sensitive Info in Logs",
        description="Insertion of sensitive information into log file",
        owasp=OWASPCategory.A09,
        risk_weight_reachable=20,
        risk_weight_unreachable=5,
        asvs_requirements=["V7.1.2"],
        asvs_level=1,
        pci_dss=["3.4"],
        hipaa=["164.312(b)"],
        soc2=["CC6.1", "CC7.2"],
        nist_800_53=["AU-3", "SC-28"],
        nist_800_171=["3.3.1"],
        disa_stig=["APSC-DV-002440"],
        likelihood="Medium",
        impact="Medium",
    ),
    # =========================================================================
    # Container Security (Non-OWASP, 20 pts reachable)
    # =========================================================================
    "CWE-250": CWEDefinition(
        cwe_id="CWE-250",
        name="Execution with Unnecessary Privileges",
        description="Running with more privileges than required (e.g., root in container)",
        owasp=OWASPCategory.A05,  # Maps to misconfiguration
        risk_weight_reachable=20,
        risk_weight_unreachable=5,
        asvs_requirements=["V14.1.1"],
        asvs_level=1,
        pci_dss=["2.2", "7.1"],
        soc2=["CC6.1", "CC6.3"],
        nist_800_53=["AC-6", "CM-7"],
        nist_800_171=["3.1.5", "3.4.6"],
        disa_stig=["APSC-DV-002380", "CNTR-K8-000360"],
        cmmc=["AC.L2-3.1.5", "CM.L2-3.4.6"],
        likelihood="High",
        impact="Medium",
    ),
}

# =============================================================================
# Pattern Matching for Rule Classification
# =============================================================================

# Maps regex patterns to CWE IDs
RULE_PATTERNS = {
    # A03: Injection
    "CWE-89": [r"sql[-_]?inject", r"sqli", r"sql[-_]?query.*user", r"execute[-_]?query"],
    "CWE-79": [
        r"xss",
        r"cross[-_]?site[-_]?script",
        r"script[-_]?inject",
        r"html[-_]?inject",
        r"innerHTML",
        r"document\.write",
    ],
    "CWE-78": [
        r"os[-_]?command",
        r"command[-_]?inject",
        r"shell[-_]?exec",
        r"subprocess",
        r"popen",
        r"system\(",
    ],
    "CWE-77": [r"command[-_]?inject", r"exec\(", r"eval\("],
    "CWE-611": [r"xxe", r"xml[-_]?external", r"xml[-_]?inject"],
    "CWE-94": [r"code[-_]?inject", r"eval", r"exec"],
    "CWE-917": [r"template[-_]?inject", r"ssti", r"expression[-_]?inject"],
    "CWE-90": [r"ldap[-_]?inject"],
    # A01: Broken Access Control
    "CWE-22": [r"path[-_]?travers", r"directory[-_]?travers", r"lfi", r"rfi", r"file[-_]?inclus"],
    "CWE-352": [r"csrf", r"cross[-_]?site[-_]?request"],
    "CWE-639": [r"idor", r"insecure[-_]?direct[-_]?object"],
    "CWE-862": [r"missing[-_]?auth", r"broken[-_]?access"],
    "CWE-863": [r"incorrect[-_]?auth", r"auth[-_]?bypass"],
    "CWE-601": [r"open[-_]?redirect", r"unvalidated[-_]?redirect"],
    "CWE-269": [r"privilege[-_]?escalat", r"privesc"],
    # A07: Auth Failures
    "CWE-798": [
        r"hardcoded[-_]?password",
        r"hardcoded[-_]?credential",
        r"hardcoded[-_]?secret",
        r"embedded[-_]?password",
    ],
    "CWE-287": [r"broken[-_]?auth", r"authentication[-_]?bypass", r"improper[-_]?auth"],
    "CWE-384": [r"session[-_]?fixation"],
    "CWE-613": [r"session[-_]?expir"],
    "CWE-521": [r"weak[-_]?password"],
    # A10: SSRF
    "CWE-918": [r"ssrf", r"server[-_]?side[-_]?request", r"url[-_]?inject"],
    # A02: Crypto
    "CWE-327": [
        r"weak[-_]?crypto",
        r"insecure[-_]?crypto",
        r"des\b",
        r"3des",
        r"rc4",
        r"blowfish",
        r"ecb[-_]?mode",
    ],
    "CWE-328": [r"weak[-_]?hash", r"insecure[-_]?hash", r"md5", r"sha1\b"],
    "CWE-330": [r"weak[-_]?random", r"insecure[-_]?random", r"insufficient[-_]?random"],
    "CWE-338": [r"math\.random", r"random\(\)", r"predictable[-_]?random"],
    "CWE-326": [r"weak[-_]?key", r"short[-_]?key", r"inadequate[-_]?encrypt"],
    "CWE-295": [r"ssl[-_]?verif.*disable", r"certificate[-_]?valid.*disable", r"verify.*false"],
    "CWE-321": [r"hardcoded[-_]?key", r"hardcoded[-_]?iv", r"static[-_]?iv", r"embedded[-_]?key"],
    # A08: Integrity
    "CWE-502": [r"deserializ", r"pickle", r"marshal", r"yaml\.load", r"yaml\.unsafe"],
    "CWE-915": [r"mass[-_]?assign"],
    "CWE-1321": [r"prototype[-_]?pollut"],
    # A05: Misconfiguration
    "CWE-16": [r"security[-_]?misconfig", r"config[-_]?error"],
    "CWE-209": [r"error[-_]?message", r"stack[-_]?trace[-_]?expos", r"verbose[-_]?error", r"debug[-_]?mode"],
    "CWE-1004": [r"httponly.*missing", r"cookie.*httponly"],
    "CWE-614": [r"secure.*missing", r"cookie.*secure"],
    # A04: Insecure Design
    "CWE-362": [r"race[-_]?condition"],
    "CWE-367": [r"toctou", r"time[-_]?of[-_]?check"],
    "CWE-400": [r"resource[-_]?exhaust", r"denial[-_]?of[-_]?service", r"dos\b"],
    "CWE-1333": [r"redos", r"regex[-_]?dos"],
    # A09: Logging
    "CWE-117": [r"log[-_]?inject", r"log[-_]?forg"],
    "CWE-532": [r"password[-_]?in[-_]?log", r"credential.*log", r"sensitive.*log"],
    # Container
    "CWE-250": [
        r"dockerfile",
        r"run[-_]?as[-_]?root",
        r"privileged[-_]?container",
        r"privileged[-_]?mode",
        r"missing[-_]?user",
        r"container.*root",
    ],
}

# =============================================================================
# Classification Functions
# =============================================================================


def classify_by_cwe(rule_id: str, message: str = "") -> Optional[CWEDefinition]:
    """
    Classify a SAST finding to a CWE.

    Args:
        rule_id: The SAST tool rule ID
        message: Optional message/description

    Returns:
        CWEDefinition if matched, None otherwise
    """
    combined = f"{rule_id} {message}".lower()

    # Check Container Security FIRST (more specific patterns)
    for pattern in RULE_PATTERNS.get("CWE-250", []):
        if re.search(pattern, combined, re.IGNORECASE):
            return CWE_DATABASE.get("CWE-250")

    # Check other CWEs
    for cwe_id, patterns in RULE_PATTERNS.items():
        if cwe_id == "CWE-250":  # Already checked
            continue
        for pattern in patterns:
            if re.search(pattern, combined, re.IGNORECASE):
                return CWE_DATABASE.get(cwe_id)

    return None


def get_owasp_category(rule_id: str, message: str = "") -> Tuple[str, str, int, int]:
    """
    Get OWASP category for a finding.

    Returns:
        Tuple of (owasp_id, owasp_name, weight_reachable, weight_unreachable)
    """
    cwe = classify_by_cwe(rule_id, message)
    if cwe:
        return (
            cwe.owasp.value,
            OWASP_NAMES[cwe.owasp],
            cwe.risk_weight_reachable,
            cwe.risk_weight_unreachable,
        )

    # Default: Code Quality
    return ("N/A", "Code Quality", 10, 2)


def get_multi_standard_mapping(rule_id: str, message: str = "") -> dict:
    """
    Get full multi-standard mapping for a finding.

    Returns:
        Dictionary with all applicable standards
    """
    cwe = classify_by_cwe(rule_id, message)

    if not cwe:
        return {
            "cwe": None,
            "owasp": "N/A",
            "owasp_name": "Code Quality",
            "asvs": [],
            "sans_top_25": None,
            "pci_dss": [],
            "hipaa": [],
            "soc2": [],
            "nist_800_53": [],
            "nist_ssdf": [],
            "nist_800_171": [],
            "disa_stig": [],
            "cmmc": [],
            "risk_weight_reachable": 10,
            "risk_weight_unreachable": 2,
        }

    return {
        "cwe": cwe.cwe_id,
        "cwe_name": cwe.name,
        "cwe_description": cwe.description,
        "owasp": cwe.owasp.value,
        "owasp_name": OWASP_NAMES[cwe.owasp],
        "asvs": cwe.asvs_requirements,
        "asvs_level": cwe.asvs_level,
        "sans_top_25": cwe.sans_top_25_rank,
        # Industry
        "pci_dss": cwe.pci_dss,
        "hipaa": cwe.hipaa,
        "soc2": cwe.soc2,
        # US Federal
        "nist_800_53": cwe.nist_800_53,
        "nist_ssdf": cwe.nist_ssdf,
        "fisma": cwe.fisma,
        # US Defense
        "nist_800_171": cwe.nist_800_171,
        "disa_stig": cwe.disa_stig,
        "cmmc": cwe.cmmc,
        # Risk
        "risk_weight_reachable": cwe.risk_weight_reachable,
        "risk_weight_unreachable": cwe.risk_weight_unreachable,
        "likelihood": cwe.likelihood,
        "impact": cwe.impact,
        "remediation_effort": cwe.remediation_effort,
    }


def get_compliance_summary(findings: List[dict]) -> dict:
    """
    Generate compliance summary across all standards.

    Args:
        findings: List of findings with rule_id and message

    Returns:
        Summary of violations by standard
    """
    summary = {
        "owasp": {},
        "cwe": {},
        "pci_dss": {},
        "hipaa": {},
        "soc2": {},
        "nist_800_53": {},
        "nist_800_171": {},
        "disa_stig": {},
        "cmmc": {},
    }

    for finding in findings:
        mapping = get_multi_standard_mapping(finding.get("rule_id", ""), finding.get("message", ""))

        if mapping["cwe"]:
            summary["cwe"][mapping["cwe"]] = summary["cwe"].get(mapping["cwe"], 0) + 1

        if mapping["owasp"] != "N/A":
            key = f"{mapping['owasp']}: {mapping['owasp_name']}"
            summary["owasp"][key] = summary["owasp"].get(key, 0) + 1

        for req in mapping.get("pci_dss", []):
            summary["pci_dss"][req] = summary["pci_dss"].get(req, 0) + 1

        for req in mapping.get("hipaa", []):
            summary["hipaa"][req] = summary["hipaa"].get(req, 0) + 1

        for req in mapping.get("soc2", []):
            summary["soc2"][req] = summary["soc2"].get(req, 0) + 1

        for req in mapping.get("nist_800_53", []):
            summary["nist_800_53"][req] = summary["nist_800_53"].get(req, 0) + 1

        for req in mapping.get("nist_800_171", []):
            summary["nist_800_171"][req] = summary["nist_800_171"].get(req, 0) + 1

        for req in mapping.get("disa_stig", []):
            summary["disa_stig"][req] = summary["disa_stig"].get(req, 0) + 1

        for req in mapping.get("cmmc", []):
            summary["cmmc"][req] = summary["cmmc"].get(req, 0) + 1

    return summary


def get_available_standards() -> dict:
    """Get list of all supported standards with descriptions."""
    return {
        "technical": {
            "cwe": "Common Weakness Enumeration - Technical root cause of vulnerabilities",
            "owasp": "OWASP Top 10 2021 - High-level risk categories",
            "asvs": "Application Security Verification Standard - Deep audit checklist (Levels 1-3)",
            "sans_top_25": "SANS/CWE Top 25 - Most dangerous software errors",
        },
        "industry_compliance": {
            "pci_dss": "PCI DSS 4.0 - Payment Card Industry Data Security Standard",
            "hipaa": "HIPAA - Health Insurance Portability and Accountability Act",
            "soc2": "SOC 2 - Service Organization Control (Trust Service Criteria)",
        },
        "us_federal": {
            "nist_800_53": "NIST 800-53 Rev 5 - Security Controls for Federal Information Systems (FedRAMP)",
            "nist_ssdf": "NIST 800-218 (SSDF) - Secure Software Development Framework",
            "fisma": "FISMA - Federal Information Security Management Act",
        },
        "us_defense": {
            "disa_stig": "DISA STIG - Defense Information Systems Agency Security Technical Implementation Guides",
            "cmmc": "CMMC 2.0 - Cybersecurity Maturity Model Certification (DoD contractors)",
            "nist_800_171": "NIST 800-171 - Protecting Controlled Unclassified Information (CUI)",
        },
    }


# =============================================================================
# Test / Demo
# =============================================================================

if __name__ == "__main__":
    logger.info("REACHABLE Security Standards Mapper")
    logger.info("=" * 70)

    test_cases = [
        ("sql-injection", "SQL query built from user input"),
        ("hardcoded-password", "Password embedded in source code"),
        ("dockerfile.missing-user", "Dockerfile does not specify USER"),
        ("weak-hash-md5", "MD5 hash algorithm used"),
        ("path-traversal", "Path traversal via user input"),
    ]

    logger.info("\nMulti-Standard Mapping Examples:")
    logger.info("-" * 70)

    for rule_id, message in test_cases:
        mapping = get_multi_standard_mapping(rule_id, message)
        logger.info(f"\nRule: {rule_id}")
        logger.info(f" CWE: {mapping.get('cwe', 'N/A')} - {mapping.get('cwe_name', '')}")
        logger.info(f" OWASP: {mapping['owasp']}: {mapping['owasp_name']}")
        logger.info(f" ASVS: {', '.join(mapping.get('asvs', [])) or 'N/A'}")
        logger.info(f" SANS Top 25: #{mapping.get('sans_top_25') or 'N/A'}")
        logger.info(f" PCI DSS: {', '.join(mapping.get('pci_dss', [])) or 'N/A'}")
        logger.info(f" HIPAA: {', '.join(mapping.get('hipaa', [])) or 'N/A'}")
        logger.info(f" NIST 800-53: {', '.join(mapping.get('nist_800_53', [])) or 'N/A'}")
        logger.info(f" DISA STIG: {', '.join(mapping.get('disa_stig', [])) or 'N/A'}")
        logger.info(f" CMMC: {', '.join(mapping.get('cmmc', [])) or 'N/A'}")
        logger.info(f" Risk Weight: {mapping['risk_weight_reachable']} pts (reachable)")

    logger.info("\n" + "=" * 70)
    logger.info("Supported Standards:")
    for category, standards in get_available_standards().items():
        logger.info(f"\n{category.upper().replace('_', ' ')}:")
        for std_id, desc in standards.items():
            logger.info(f" • {std_id}: {desc}")
