#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.

"""
Storage Management Utilities for REACHABLE

Provides disk usage analysis, cleanup, and compression functions.
Used by `reachctl system` commands.
"""

import json
import logging
import shutil
import sqlite3
import subprocess
import tarfile
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any, Dict, List, Tuple

# Initialize module-level logger
logger = logging.getLogger(__name__)


# Directories to exclude from size calculations (huge tooling dirs that cause hangs)
_SIZE_SKIP_DIRS = frozenset(
    [
        "venv",
        ".venv",
        "node_modules",
        "__pycache__",
        ".git",
        "build-venv",
        "guarddog-venv",
        "lib",
        "bin",
        "include",
    ]
)


def get_dir_size(path: Path, skip_dirs: frozenset = None) -> int:
    """Get total size of directory in bytes using 'du -sk'.

    Uses the OS du command — single syscall, no Python traversal.
    Python os.walk/rglob hangs on cache/libs/ (cloned repos with node_modules etc).
    """
    if not path.exists():
        return 0
    try:
        result = subprocess.run(["du", "-sk", str(path)], capture_output=True, text=True, timeout=60)
        if result.returncode == 0 and result.stdout:
            kb = int(result.stdout.split()[0])
            return kb * 1024
    except Exception:
        pass
    return 0


def get_file_count(path: Path) -> int:
    """Get approximate file count using 'find' — no Python traversal."""
    if not path.exists():
        return 0
    try:
        result = subprocess.run(
            ["find", str(path), "-maxdepth", "3", "-type", "f"], capture_output=True, text=True, timeout=5
        )
        if result.returncode == 0:
            return result.stdout.count("\n")
    except Exception:
        pass
    return 0


def format_size(size_bytes: int) -> str:
    """Format bytes as human-readable string."""
    if size_bytes < 1024:
        return f"{size_bytes} B"
    elif size_bytes < 1024 * 1024:
        return f"{size_bytes / 1024:.1f} KB"
    elif size_bytes < 1024 * 1024 * 1024:
        return f"{size_bytes / (1024 * 1024):.1f} MB"
    else:
        return f"{size_bytes / (1024 * 1024 * 1024):.2f} GB"


def get_top_files(path: Path, n: int = 10) -> List[Tuple[Path, int]]:
    """Get top N largest files in directory, skipping large tooling dirs.

    Uses os.walk with in-place dir pruning so we never descend into
    venv/, node_modules/, etc. — rglob cannot prune before descending.
    """
    import os

    if not path.exists():
        return []

    files = []
    try:
        for dirpath, dirnames, filenames in os.walk(str(path)):
            # Prune skip dirs IN PLACE so os.walk never descends into them
            dirnames[:] = [d for d in dirnames if d not in _SIZE_SKIP_DIRS]
            for fname in filenames:
                fpath = Path(dirpath) / fname
                try:
                    files.append((fpath, fpath.stat().st_size))
                except (OSError, PermissionError):
                    pass
    except (OSError, PermissionError):
        pass

    files.sort(key=lambda x: x[1], reverse=True)
    return files[:n]


def get_top_dirs(path: Path, n: int = 10) -> List[Tuple[Path, int]]:
    """Get top N largest immediate subdirectories."""
    if not path.exists():
        return []

    dirs = []
    try:
        for entry in path.iterdir():
            if entry.is_dir():
                size = get_dir_size(entry)
                dirs.append((entry, size))
    except (OSError, PermissionError):
        pass

    dirs.sort(key=lambda x: x[1], reverse=True)
    return dirs[:n]


def check_colima_status() -> Dict[str, Any]:
    """Check if Colima is running."""
    result = {
        "installed": False,
        "running": False,
        "vm_type": None,
        "cpu": None,
        "memory": None,
        "disk": None,
    }

    # Check if colima exists
    colima_path = shutil.which("colima")
    if not colima_path:
        return result

    result["installed"] = True

    try:
        # Check status
        proc = subprocess.run(["colima", "status"], capture_output=True, text=True, timeout=5)
        if proc.returncode == 0 and "running" in proc.stdout.lower():
            result["running"] = True
            # Parse status output
            for line in proc.stdout.split("\n"):
                line_lower = line.lower()
                if "runtime:" in line_lower:
                    result["vm_type"] = line.split(":")[-1].strip()
                elif "cpu:" in line_lower:
                    result["cpu"] = line.split(":")[-1].strip()
                elif "memory:" in line_lower:
                    result["memory"] = line.split(":")[-1].strip()
                elif "disk:" in line_lower:
                    result["disk"] = line.split(":")[-1].strip()
    except (subprocess.TimeoutExpired, FileNotFoundError, Exception):
        pass

    return result


def check_firecracker_status() -> Dict[str, Any]:
    """Check if Firecracker microVMs are running."""
    result = {
        "installed": False,
        "running": False,
        "vm_count": 0,
        "sockets": [],
    }

    # Check if firecracker exists
    fc_path = shutil.which("firecracker")
    if not fc_path:
        # Also check common locations
        for path in ["/usr/local/bin/firecracker", "/opt/firecracker/firecracker"]:
            if Path(path).exists():
                fc_path = path
                break

    if not fc_path:
        return result

    result["installed"] = True

    try:
        # Check for running firecracker processes
        proc = subprocess.run(["pgrep", "-f", "firecracker"], capture_output=True, text=True, timeout=5)
        if proc.returncode == 0 and proc.stdout.strip():
            pids = proc.stdout.strip().split("\n")
            result["running"] = True
            result["vm_count"] = len(pids)

        # Check for API sockets in .reachable
        reachable_home = Path.home() / ".reachable"
        sandbox_dir = reachable_home / "sandbox"
        if sandbox_dir.exists():
            for sock in sandbox_dir.glob("**/*.sock"):
                result["sockets"].append(str(sock))
    except (subprocess.TimeoutExpired, FileNotFoundError, Exception):
        pass

    return result


def check_docker_status() -> Dict[str, Any]:
    """Check Docker daemon status."""
    result = {
        "installed": False,
        "running": False,
        "containers": 0,
        "images": 0,
        "version": None,
    }

    docker_path = shutil.which("docker")
    if not docker_path:
        return result

    result["installed"] = True

    try:
        # Check if daemon is running
        proc = subprocess.run(
            ["docker", "info", "--format", "{{.Containers}}"], capture_output=True, text=True, timeout=5
        )
        if proc.returncode == 0:
            result["running"] = True
            result["containers"] = int(proc.stdout.strip() or 0)

        # Get version
        proc = subprocess.run(["docker", "--version"], capture_output=True, text=True, timeout=5)
        if proc.returncode == 0:
            result["version"] = proc.stdout.strip()

        # Count images
        proc = subprocess.run(["docker", "images", "-q"], capture_output=True, text=True, timeout=5)
        if proc.returncode == 0:
            result["images"] = len(proc.stdout.strip().split("\n")) if proc.stdout.strip() else 0
    except (subprocess.TimeoutExpired, FileNotFoundError, Exception):
        pass

    return result


def get_grype_db_info() -> Dict[str, Any]:
    """Get Grype vulnerability database info."""
    result = {
        "exists": False,
        "size": 0,
        "size_human": "0 B",
        "last_update": None,
        "age_hours": None,
        "path": None,
    }

    # Check REACHABLE cache location first
    grype_db_dir = Path.home() / ".reachable" / "cache" / "grype-db"
    if not grype_db_dir.exists():
        # Check default grype location
        grype_db_dir = Path.home() / ".cache" / "grype" / "db"

    if grype_db_dir.exists():
        result["exists"] = True
        result["size"] = get_dir_size(grype_db_dir)
        result["size_human"] = format_size(result["size"])
        result["path"] = str(grype_db_dir)

        # Check timestamp
        timestamp_file = grype_db_dir / ".last_update"
        if timestamp_file.exists():
            try:
                ts = timestamp_file.read_text().strip()
                result["last_update"] = ts
                last_dt = datetime.fromisoformat(ts)
                result["age_hours"] = (datetime.now() - last_dt).total_seconds() / 3600
            except Exception:
                pass

        # Check for metadata file (grype's own tracking)
        for meta in grype_db_dir.glob("**/metadata.json"):
            try:
                data = json.loads(meta.read_text())
                if "built" in data:
                    result["db_built"] = data["built"]
                if "version" in data:
                    result["db_version"] = data["version"]
            except Exception:
                pass

    return result


def get_db_table_sizes(db_path: Path) -> Dict[str, Dict[str, Any]]:
    """Get size breakdown of tables in a SQLite database."""
    result = {}
    if not db_path.exists():
        return result

    try:
        conn = sqlite3.connect(str(db_path))
        cursor = conn.cursor()

        # Get table names
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table'")
        tables = [row[0] for row in cursor.fetchall()]

        for table in tables:
            try:
                cursor.execute(f"SELECT COUNT(*) FROM {table}")  # noqa: S608
                count = cursor.fetchone()[0]

                # Estimate size by sampling
                cursor.execute(f"SELECT * FROM {table} LIMIT 1")  # noqa: S608
                row = cursor.fetchone()
                avg_row_size = len(str(row)) if row else 0
                estimated_size = count * avg_row_size

                result[table] = {
                    "rows": count,
                    "estimated_size": estimated_size,
                    "estimated_size_human": format_size(estimated_size),
                }
            except Exception:
                pass

        conn.close()
    except Exception:
        pass

    return result


def get_storage_breakdown(reachable_home: Path = None) -> Dict[str, Any]:
    """Get comprehensive storage breakdown."""
    if reachable_home is None:
        reachable_home = Path.home() / ".reachable"

    if not reachable_home.exists():
        return {"exists": False, "total": 0, "total_human": "0 B"}

    result = {
        "exists": True,
        "path": str(reachable_home),
        "total": 0,
        "total_human": "0 B",
        "components": {},
        "top_repos": [],
        "top_files": [],
    }

    # Component breakdown — compute these first, then sum for total
    # Do NOT walk reachable_home directly (venv/guarddog-venv = millions of files)
    components = {
        "scans": reachable_home / "scans",
        "cache": reachable_home / "cache",
        "tools": reachable_home / "tools",
        "sandbox": reachable_home / "sandbox",
        "logs": reachable_home / "logs",
    }

    total = 0
    for name, path in components.items():
        if path.exists():
            size = get_dir_size(path)
            total += size
            result["components"][name] = {
                "size": size,
                "size_human": format_size(size),
                "file_count": get_file_count(path),
                "path": str(path),
            }

    result["total"] = total
    result["total_human"] = format_size(total)

    # Cache sub-components
    cache_dir = reachable_home / "cache"
    if cache_dir.exists():
        result["cache_breakdown"] = {}
        for subdir in cache_dir.iterdir():
            if subdir.is_dir():
                size = get_dir_size(subdir)
                result["cache_breakdown"][subdir.name] = {
                    "size": size,
                    "size_human": format_size(size),
                }

    # Top repos by size
    scans_dir = reachable_home / "scans"
    if scans_dir.exists():
        result["top_repos"] = []
        for repo_dir, size in get_top_dirs(scans_dir, n=10):
            # Count scans in repo
            scan_count = 0
            db_path = repo_dir / "repo.db"
            db_size = 0
            branch_count = 0
            oldest_scan = None
            newest_scan = None

            if db_path.exists():
                db_size = db_path.stat().st_size
                try:
                    conn = sqlite3.connect(str(db_path))
                    cursor = conn.cursor()
                    cursor.execute("SELECT COUNT(*) FROM scans")
                    scan_count = cursor.fetchone()[0]
                    cursor.execute("SELECT COUNT(DISTINCT branch) FROM scans")
                    branch_count = cursor.fetchone()[0]
                    cursor.execute("SELECT MIN(timestamp), MAX(timestamp) FROM scans")
                    row = cursor.fetchone()
                    oldest_scan = row[0]
                    newest_scan = row[1]
                    conn.close()
                except Exception:
                    pass

            result["top_repos"].append(
                {
                    "name": repo_dir.name,
                    "size": size,
                    "size_human": format_size(size),
                    "scan_count": scan_count,
                    "branch_count": branch_count,
                    "db_size": db_size,
                    "db_size_human": format_size(db_size),
                    "oldest_scan": oldest_scan,
                    "newest_scan": newest_scan,
                }
            )

    # Top files — only computed when verbose is requested (avoid traversal)
    result["top_files"] = []

    return result


def get_system_info() -> Dict[str, Any]:
    """Get comprehensive system information."""
    reachable_home = Path.home() / ".reachable"

    info = {
        "timestamp": datetime.now().isoformat(),
        "reachable_home": str(reachable_home),
        "storage": get_storage_breakdown(reachable_home),
        "grype_db": get_grype_db_info(),
        "sandboxes": {
            "colima": check_colima_status(),
            "firecracker": check_firecracker_status(),
            "docker": check_docker_status(),
        },
    }

    return info


def print_system_info(verbose: bool = False, json_output: bool = False):
    """Print system info — no filesystem traversal, instant.

    Uses shutil.disk_usage (filesystem stats), stat() for file sizes,
    and SQLite queries for scan counts. Never walks directories.
    """
    reachable_home = Path.home() / ".reachable"

    logger.info("REACHABLE SYSTEM INFO")

    # ---- FILESYSTEM ----
    logger.info("")
    logger.info("FILESYSTEM")
    if reachable_home.exists():
        usage = shutil.disk_usage(str(reachable_home))
        pct = usage.used / usage.total * 100 if usage.total else 0

        def _fmt(b):
            for unit in ("B", "KB", "MB", "GB", "TB"):
                if b < 1024 or unit == "TB":
                    return f"{b:.1f} {unit}"
                b /= 1024

        logger.info(f"  Location:  {reachable_home}")
        logger.info(f"  Disk total:    {_fmt(usage.total)}")
        logger.info(f"  Disk used:     {_fmt(usage.used)} ({pct:.1f}%)")
        logger.info(f"  Disk free:     {_fmt(usage.free)}")
        if pct > 90:
            logger.info(f"  WARNING: disk is {pct:.0f}% full — run 'reachctl system df'")
    else:
        logger.info("  ~/.reachable does not exist yet")

    # ---- SCAN REPOS (from SQLite only, no dir traversal) ----
    logger.info("")
    logger.info("SCAN REPOSITORIES")
    scans_dir = reachable_home / "scans"
    if scans_dir.exists():
        repos = []
        for repo_dir in scans_dir.iterdir():
            if not repo_dir.is_dir():
                continue
            db_path = repo_dir / "repo.db"
            scan_count = 0
            branch_count = 0
            last_scan = None
            db_size = 0
            if db_path.exists():
                db_size = db_path.stat().st_size
                try:
                    conn = sqlite3.connect(str(db_path))
                    cursor = conn.cursor()
                    cursor.execute("SELECT COUNT(*) FROM scans")
                    scan_count = cursor.fetchone()[0]
                    cursor.execute("SELECT COUNT(DISTINCT branch) FROM scans")
                    branch_count = cursor.fetchone()[0]
                    cursor.execute("SELECT MAX(timestamp) FROM scans")
                    last_scan = cursor.fetchone()[0]
                    conn.close()
                except Exception:
                    pass
            repos.append((repo_dir.name, scan_count, branch_count, last_scan, db_size))

        repos.sort(key=lambda x: x[3] or "", reverse=True)  # sort by last scan
        if repos:
            logger.info(f"  {'Repository':<35} {'Scans':>6} {'Branches':>8} {'DB Size':>9} Last Scan")
            logger.info(f"  {'-' * 35} {'-' * 6} {'-' * 8} {'-' * 9} {'-' * 16}")
            for name, scans, branches, last, dbsz in repos:
                last_str = last[:16] if last else "never"
                logger.info(f"  {name[:35]:<35} {scans:>6} {branches:>8} {format_size(dbsz):>9} {last_str}")
        else:
            logger.info("  No scans yet")
    else:
        logger.info("  No scans directory")

    # ---- GRYPE DB (stat only) ----
    logger.info("")
    logger.info("VULNERABILITY DATABASE (Grype)")
    grype_dir = reachable_home / "cache" / "grype-db"
    if not grype_dir.exists():
        grype_dir = Path.home() / ".cache" / "grype" / "db"
    if grype_dir.exists():
        # stat the dir itself (no traversal) for mtime
        mtime = datetime.fromtimestamp(grype_dir.stat().st_mtime)
        age_hours = (datetime.now() - mtime).total_seconds() / 3600
        stale = age_hours > 24
        logger.info(f"  Location: {grype_dir}")
        logger.info(f"  Updated:  {age_hours:.1f}h ago {'(STALE)' if stale else '(fresh)'}")
        if stale:
            logger.info("  Run 'reachctl vulndb --update' to refresh")
    else:
        logger.info("  Not initialized (will download on first scan)")

    # ---- SANDBOXES ----
    logger.info("")
    logger.info("SANDBOX STATUS")
    colima = check_colima_status()
    if colima["installed"]:
        status = "Running" if colima["running"] else "Stopped"
        logger.info(f"  Colima:      {status}")
    else:
        logger.info("  Colima:      Not installed")

    fc = check_firecracker_status()
    if fc["installed"]:
        status = f"Running ({fc['vm_count']} VMs)" if fc["running"] else "Stopped"
        logger.info(f"  Firecracker: {status}")
    else:
        logger.info("  Firecracker: Not installed")

    docker = check_docker_status()
    if docker["installed"]:
        status = f"Running ({docker['containers']} containers)" if docker["running"] else "Daemon not running"
        logger.info(f"  Docker:      {status}")
    else:
        logger.info("  Docker:      Not installed")

    logger.info("")
    logger.info("Run 'reachctl system df' for disk usage details")


def prune_storage(
    max_age_days: int = 21,
    max_scans_per_branch: int = 20,
    compress_after_days: int = 14,
    dry_run: bool = False,
    verbose: bool = False,
) -> Dict[str, Any]:
    """
    Prune old scan data and compress older dashboards.

    Args:
        max_age_days: Delete scans older than this
        max_scans_per_branch: Keep only this many scans per branch
        compress_after_days: Compress dashboards older than this
        dry_run: Only show what would be deleted
        verbose: Print detailed progress

    Returns:
        Dict with cleanup statistics
    """
    reachable_home = Path.home() / ".reachable"
    scans_dir = reachable_home / "scans"

    result = {
        "scans_deleted": 0,
        "dirs_deleted": 0,
        "dirs_compressed": 0,
        "bytes_freed": 0,
        "bytes_freed_human": "0 B",
        "errors": [],
    }

    if not scans_dir.exists():
        return result

    cutoff_delete = datetime.now() - timedelta(days=max_age_days)
    cutoff_compress = datetime.now() - timedelta(days=compress_after_days)

    # Process each repository
    for repo_dir in scans_dir.iterdir():
        if not repo_dir.is_dir():
            continue

        db_path = repo_dir / "repo.db"
        if not db_path.exists():
            continue

        try:
            conn = sqlite3.connect(str(db_path))
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()

            # Get branches
            cursor.execute("SELECT DISTINCT branch FROM scans")
            branches = [row["branch"] for row in cursor.fetchall()]

            for branch in branches:
                # Find scans to delete (by count)
                cursor.execute(
                    """
                    SELECT id, scan_dir, timestamp FROM scans
                    WHERE branch = ? AND status = 'complete'
                    ORDER BY timestamp DESC
                    LIMIT -1 OFFSET ?
                """,
                    (branch, max_scans_per_branch),
                )

                scans_to_delete = list(cursor.fetchall())

                # Also delete by age
                cursor.execute(
                    """
                    SELECT id, scan_dir, timestamp FROM scans
                    WHERE branch = ? AND timestamp < ?
                """,
                    (branch, cutoff_delete.isoformat()),
                )

                scans_to_delete.extend(cursor.fetchall())

                # Dedupe by ID
                seen_ids = set()
                unique_scans = []
                for scan in scans_to_delete:
                    if scan["id"] not in seen_ids:
                        seen_ids.add(scan["id"])
                        unique_scans.append(scan)

                # Delete scans and their directories
                for scan in unique_scans:
                    scan_dir = scan["scan_dir"]
                    if scan_dir:
                        scan_path = Path(scan_dir)
                        if scan_path.exists():
                            dir_size = get_dir_size(scan_path)
                            if verbose:
                                logger.info(
                                    f" {'Would delete' if dry_run else 'Deleting'}: {scan_path} ({format_size(dir_size)})"
                                )

                            if not dry_run:
                                try:
                                    shutil.rmtree(scan_path)
                                    result["dirs_deleted"] += 1
                                    result["bytes_freed"] += dir_size
                                except Exception as e:
                                    result["errors"].append(f"Failed to delete {scan_path}: {e}")

                    if not dry_run:
                        cursor.execute("DELETE FROM scans WHERE id = ?", (scan["id"],))
                        result["scans_deleted"] += 1

                # Find scans to compress (older than compress_after_days but not deleted)
                cursor.execute(
                    """
                    SELECT id, scan_dir, timestamp FROM scans
                    WHERE branch = ? AND timestamp < ? AND timestamp >= ?
                """,
                    (branch, cutoff_compress.isoformat(), cutoff_delete.isoformat()),
                )

                for scan in cursor.fetchall():
                    scan_dir = scan["scan_dir"]
                    if scan_dir:
                        scan_path = Path(scan_dir)
                        dashboard_dir = scan_path / "dashboard"
                        archive_path = scan_path / "dashboard.tar.gz"

                        # Compress dashboard if not already compressed
                        if dashboard_dir.exists() and dashboard_dir.is_dir() and not archive_path.exists():
                            dir_size = get_dir_size(dashboard_dir)
                            if verbose:
                                logger.info(
                                    f" {'Would compress' if dry_run else 'Compressing'}: {dashboard_dir} ({format_size(dir_size)})"
                                )

                            if not dry_run:
                                try:
                                    with tarfile.open(archive_path, "w:gz") as tar:
                                        tar.add(dashboard_dir, arcname="dashboard")

                                    # Remove original if archive created successfully
                                    if archive_path.exists():
                                        shutil.rmtree(dashboard_dir)
                                        result["dirs_compressed"] += 1
                                        # Calculate savings
                                        new_size = archive_path.stat().st_size
                                        result["bytes_freed"] += dir_size - new_size
                                except Exception as e:
                                    result["errors"].append(f"Failed to compress {dashboard_dir}: {e}")

            if not dry_run:
                conn.commit()
                # Vacuum to reclaim space
                conn.execute("VACUUM")

            conn.close()

        except Exception as e:
            result["errors"].append(f"Error processing {repo_dir}: {e}")

    # Clean up orphaned cache entries
    cache_dir = reachable_home / "cache"
    if cache_dir.exists() and not dry_run:
        # Clean old semgrep cache
        semgrep_cache = cache_dir / "semgrep"
        if semgrep_cache.exists():
            for entry in semgrep_cache.iterdir():
                try:
                    mtime = datetime.fromtimestamp(entry.stat().st_mtime)
                    if mtime < cutoff_delete:
                        size = get_dir_size(entry) if entry.is_dir() else entry.stat().st_size
                        if entry.is_dir():
                            shutil.rmtree(entry)
                        else:
                            entry.unlink()
                        result["bytes_freed"] += size
                except Exception:
                    pass

    result["bytes_freed_human"] = format_size(result["bytes_freed"])
    return result


if __name__ == "__main__":
    import logging
    import sys

    if len(sys.argv) > 1 and sys.argv[1] == "prune":
        dry_run = "--dry-run" in sys.argv
        verbose = "-v" in sys.argv or "--verbose" in sys.argv
        logger.info("REACHABLE Storage Prune")
        logger.info("=" * 50)
        result = prune_storage(dry_run=dry_run, verbose=verbose)
        logger.info("\nResults:")
        logger.info(f" Scans deleted: {result['scans_deleted']}")
        logger.info(f" Directories deleted: {result['dirs_deleted']}")
        logger.info(f" Directories compressed: {result['dirs_compressed']}")
        logger.info(f" Space freed: {result['bytes_freed_human']}")
        if result["errors"]:
            logger.info("\nErrors:")
            for err in result["errors"]:
                logger.info(f" • {err}")
    else:
        verbose = "-v" in sys.argv or "--verbose" in sys.argv
        json_output = "--json" in sys.argv
        print_system_info(verbose=verbose, json_output=json_output)
