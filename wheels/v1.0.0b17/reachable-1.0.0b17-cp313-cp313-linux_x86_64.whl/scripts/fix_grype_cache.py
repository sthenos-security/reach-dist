#!/usr/bin/env python3
"""
Fix Grype DB Cache - Ensure all grype/syft subprocess calls use the shared cache.

Problems fixed:
  1. engine/execution.py calls bare ["grype", ...] and ["syft", ...] — bypasses
     get_grype_path() and get_grype_env(), so grype uses system TMPDIR for its
     download scratch files, leaving orphaned multi-GB dirs in /var/folders/...
     when interrupted.

  2. monorepo/orchestrator.py calls ["grype", ...] without env=get_grype_env(),
     so GRYPE_DB_CACHE_DIR is not set and grype re-downloads the DB every time.

Root cause: subprocess.run() calls to grype must pass:
  - cmd:  [str(get_grype_path()), ...]   — uses ~/.reachable/tools/bin/grype
  - env:  get_grype_env()                — sets GRYPE_DB_CACHE_DIR + TMPDIR

The TMPDIR redirect in get_grype_env() is the key fix for the orphaned scratch
dirs — it points grype's temp writes at ~/.reachable/cache/grype-db/.tmp/ which
VulnDBManager.update() cleans up in its finally block.
"""

import sys
from pathlib import Path

# Root of reach-core repo (this script lives in scripts/)
REPO_ROOT = Path(__file__).parent.parent

FIXES = [
    # ── execution.py ────────────────────────────────────────────────────────
    {
        "file": "reachable/engine/execution.py",
        "description": "Add grype imports",
        "old": "from reachable.core.logger import logger",
        "new": (
            "from reachable.core.logger import logger\n"
            "from reachable.collectors.vulns.grype import (\n"
            "    get_grype_path,\n"
            "    get_grype_env,\n"
            "    get_syft_path,\n"
            "    VulnDBManager,\n"
            ")"
        ),
    },
    {
        "file": "reachable/engine/execution.py",
        "description": "Fix syft SBOM scan call — use get_syft_path() + timeout",
        "old": (
            '                ["syft", "scan", f"dir:{self.mount_point}", "-o", f"json={sbom_path}"],\n'
            "                check=True,\n"
            "                capture_output=True,\n"
            "                text=True,\n"
            "            )"
        ),
        "new": (
            '                [str(get_syft_path()), "scan", f"dir:{self.mount_point}", "-o", f"json={sbom_path}"],\n'
            "                check=True,\n"
            "                capture_output=True,\n"
            "                text=True,\n"
            "                timeout=300,\n"
            "            )"
        ),
    },
    {
        "file": "reachable/engine/execution.py",
        "description": "Fix syft version check — use get_syft_path()",
        "old": '                version_result = subprocess.run(["syft", "version"], capture_output=True, text=True)',
        "new": '                version_result = subprocess.run([str(get_syft_path()), "version"], capture_output=True, text=True)',
    },
    {
        "file": "reachable/engine/execution.py",
        "description": "Fix grype scan call — use get_grype_path() + get_grype_env(scan_dir) + ensure_fresh() + timeout",
        "old": (
            "        try:\n"
            "            subprocess.run(\n"
            '                ["grype", f"sbom:{sbom_path}", "-o", f"json={vulns_path}"],\n'
            "                check=True,\n"
            "                capture_output=True,\n"
            "                text=True,\n"
            "            )"
        ),
        "new": (
            "        db_mgr = VulnDBManager()\n"
            "        try:\n"
            "            # Ensure the vulnerability DB is fresh before scanning.\n"
            "            # Pass scan_dir so TMPDIR is redirected to <scan_dir>/.grype-tmp/\n"
            "            # — isolates scratch files per repo, never collides with concurrent scans.\n"
            "            db_mgr.ensure_fresh(verbose=True)\n"
            "\n"
            "            subprocess.run(\n"
            '                [str(get_grype_path()), f"sbom:{sbom_path}", "-o", f"json={vulns_path}"],\n'
            "                check=True,\n"
            "                capture_output=True,\n"
            "                text=True,\n"
            "                env=get_grype_env(scan_dir=self.output_dir),\n"
            "                timeout=300,\n"
            "            )"
        ),
    },
    {
        "file": "reachable/engine/execution.py",
        "description": "Fix grype version check — use get_grype_path() + get_grype_env(scan_dir)",
        "old": '                version_result = subprocess.run(["grype", "version"], capture_output=True, text=True)',
        "new": (
            "                version_result = subprocess.run(\n"
            '                    [str(get_grype_path()), "version"],\n'
            "                    capture_output=True,\n"
            "                    text=True,\n"
            "                    env=get_grype_env(scan_dir=self.output_dir),\n"
            "                )"
        ),
    },
    {
        "file": "reachable/engine/execution.py",
        "description": "Add finally block to clean per-repo grype scratch on scan exit",
        "old": (
            "        except subprocess.CalledProcessError as e:\n"
            '            logger.info(f" Grype failed: {e}")\n'
            "            return False\n"
            "\n"
            "        # Step 3: Combine into sca_results.json"
        ),
        "new": (
            "        except subprocess.CalledProcessError as e:\n"
            '            logger.info(f" Grype failed: {e}")\n'
            "            return False\n"
            "        finally:\n"
            "            # Always clean per-repo scratch — covers success, failure, and\n"
            "            # Ctrl-C. Removes <scan_dir>/.grype-tmp/ and any grype-scratch*\n"
            "            # files left inside it.\n"
            "            db_mgr.cleanup_scan_scratch(self.output_dir)\n"
            "\n"
            "        # Step 3: Combine into sca_results.json"
        ),
    },
    # ── monorepo/orchestrator.py ─────────────────────────────────────────────
    {
        "file": "reachable/monorepo/orchestrator.py",
        "description": "Fix grype scan call — add env=get_grype_env()",
        "old": ('        cmd = ["grype", f"sbom:{sbom_path}", "-o", "json", "--by-cve", "-q"]'),
        "new": ('        cmd = [str(get_grype_path()), f"sbom:{sbom_path}", "-o", "json", "--by-cve", "-q"]'),
    },
    {
        "file": "reachable/monorepo/orchestrator.py",
        "description": "Add grype imports to orchestrator",
        "old": ("from reachable.collectors.vulns.grype import (\n            get_grype_env,\n"),
        "new": (
            "from reachable.collectors.vulns.grype import (\n            get_grype_env,\n            get_grype_path,\n"
        ),
    },
]


def apply_fix(fix: dict, dry_run: bool = False) -> bool:
    file_path = REPO_ROOT / fix["file"]

    if not file_path.exists():
        print(f"  ⚠️  File not found, skipping: {fix['file']}")
        return True  # Not a failure — file may not exist in all installs

    content = file_path.read_text()

    if fix["old"] not in content:
        # Check if already patched (new code already present)
        if fix["new"] in content:
            print(f"  ✅ Already patched: {fix['description']}")
            return True
        print(f"  ⚠️  Pattern not found (file may have changed): {fix['description']}")
        print(f"     Expected in {fix['file']}:")
        print("     " + fix["old"].split("\n")[0][:80])
        return False

    new_content = content.replace(fix["old"], fix["new"], 1)

    if not dry_run:
        file_path.write_text(new_content)
        print(f"  ✅ Fixed: {fix['description']}")
    else:
        print(f"  🔍 Would fix: {fix['description']}")

    return True


def main() -> int:
    dry_run = "--dry-run" in sys.argv

    print("=" * 70)
    print("REACHABLE Grype Cache Fix")
    print("=" * 70)
    print()
    print("Fixes:")
    print("  • engine/execution.py  — bare ['grype',...] → get_grype_path() + env")
    print("  • engine/execution.py  — bare ['syft',...]  → get_syft_path()")
    print("  • monorepo/orchestrator.py — add get_grype_path() + env")
    print()

    if dry_run:
        print("🔍 DRY RUN — no files will be modified")
        print()

    success = 0
    skipped = 0
    failed = 0

    current_file = None
    for fix in FIXES:
        if fix["file"] != current_file:
            current_file = fix["file"]
            print(f"\n📝 {current_file}")

        result = apply_fix(fix, dry_run=dry_run)
        if result:
            success += 1
        else:
            failed += 1

    print()
    print("=" * 70)
    print(f"✅ Fixed/already-patched: {success}")
    if failed:
        print(f"❌ Failed:               {failed}")
    print("=" * 70)

    if not dry_run and failed == 0:
        print()
        print("Next steps:")
        print("  1. Clean up orphaned scratch dirs from previous runs:")
        print("     sudo rm -rf /private/var/folders/*/*/T/grype-scratch*")
        print()
        print("  2. Clear old DB cache (forces a clean re-download):")
        print("     rm -rf ~/.reachable/cache/grype-db/")
        print()
        print("  3. Run a scan — DB will download once to ~/.reachable/cache/grype-db/")
        print("     and scratch files will stay under ~/.reachable/cache/grype-db/.tmp/")
        print()
        print("  4. Verify DB is in the right place:")
        print("     ls -lh ~/.reachable/cache/grype-db/")

    return 0 if failed == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
