#!/usr/bin/env python3
"""
Check actual DLP and CWE data in database to debug call_path issues.
"""

import json
import sqlite3
from pathlib import Path

db_path = Path("/Users/alaindazzi/.reachable/scans/reach-testbed-2943c74e/repo.db")
conn = sqlite3.connect(db_path)
conn.row_factory = sqlite3.Row
cursor = conn.cursor()

print("=" * 80)
print("DLP FINDINGS SAMPLE (checking file_path, line_start, call_path)")
print("=" * 80)

cursor.execute("""
    SELECT file_path, line_start, call_path, pii_type, sink_type
    FROM dlp_findings LIMIT 5
""")
rows = cursor.fetchall()

if not rows:
    print("  No DLP findings in database!")
else:
    for i, row in enumerate(rows, 1):
        print(f"\n  Finding {i}:")
        print(f"    file_path: {row['file_path'] or 'NULL'}")
        print(f"    line_start: {row['line_start'] or 'NULL'}")
        print(f"    pii_type: {row['pii_type']}")
        print(f"    sink_type: {row['sink_type']}")

        call_path = None
        if row["call_path"]:
            try:
                call_path = json.loads(row["call_path"])
            except:
                call_path = row["call_path"]
        print(f"    call_path: {call_path or 'NULL'}")

print("\n")
print("=" * 80)
print("CWE FINDINGS SAMPLE (checking app_reachability_path)")
print("=" * 80)

cursor.execute("""
    SELECT finding_id, finding_type, file_path, app_reachability_path, app_reachability
    FROM findings
    WHERE finding_type = 'CWE'
    LIMIT 5
""")
rows = cursor.fetchall()

if not rows:
    print("  No CWE findings in database!")
else:
    for i, row in enumerate(rows, 1):
        print(f"\n  Finding {i}:")
        print(f"    finding_id: {row['finding_id']}")
        print(f"    file_path: {row['file_path'] or 'NULL'}")
        print(f"    app_reachability: {row['app_reachability']}")

        call_path = None
        if row["app_reachability_path"]:
            try:
                call_path = json.loads(row["app_reachability_path"])
            except:
                call_path = row["app_reachability_path"]
        print(f"    app_reachability_path: {call_path or 'NULL'}")

print("\n")
print("=" * 80)
print("CVE FINDINGS SAMPLE (checking app_reachability_path)")
print("=" * 80)

cursor.execute("""
    SELECT finding_id, finding_type, package_name, app_reachability_path, app_reachability
    FROM findings
    WHERE finding_type = 'CVE' AND app_reachability = 'REACHABLE'
    LIMIT 5
""")
rows = cursor.fetchall()

if not rows:
    print("  No reachable CVE findings in database!")
else:
    for i, row in enumerate(rows, 1):
        print(f"\n  Finding {i}:")
        print(f"    finding_id: {row['finding_id']}")
        print(f"    package: {row['package_name']}")
        print(f"    app_reachability: {row['app_reachability']}")

        call_path = None
        if row["app_reachability_path"]:
            try:
                call_path = json.loads(row["app_reachability_path"])
            except:
                call_path = row["app_reachability_path"]
        print(f"    app_reachability_path: {call_path or 'NULL'}")

conn.close()
print("\n✅ Done checking database")
