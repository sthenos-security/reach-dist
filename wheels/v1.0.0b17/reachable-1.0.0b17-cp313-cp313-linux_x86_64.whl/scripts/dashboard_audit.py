#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.

"""
REACHABLE Dashboard Audit Tool v4.5.39
======================================

Comprehensive automated validation of data consistency between:
- scan.log (Log output)
- repo.db (Database storage)
- dashboard/data.json or index.html (Dashboard display)

Run after each scan to catch data discrepancies early.

Usage:
    # Audit specific scan
    python scripts/dashboard_audit.py ~/.reachable/scans/repo/branch/20260122-123456

    # Audit latest scan for a repo
    python scripts/dashboard_audit.py ~/.reachable/scans/repo --latest

    # JSON output for CI/CD
    python scripts/dashboard_audit.py /path/to/scan --json

    # Quiet mode (exit code only)
    python scripts/dashboard_audit.py /path/to/scan --quiet

Exit Codes:
    0 - All checks passed
    1 - One or more checks failed
    2 - One or more warnings (no failures)
    3 - Cannot run audit (missing files)
"""

import argparse
import json
import re
import sqlite3
import sys
from dataclasses import asdict, dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional

# =============================================================================
# DATA CLASSES
# =============================================================================


@dataclass
class AuditCheck:
    """Single audit check result"""

    name: str
    category: str
    status: str  # PASS, FAIL, WARN, SKIP
    expected: Any
    actual: Any
    message: str = ""
    details: Dict[str, Any] = field(default_factory=dict)


@dataclass
class AuditReport:
    """Complete audit report"""

    scan_path: str
    scan_id: Optional[int] = None
    branch: Optional[str] = None
    timestamp: str = ""
    checks: List[AuditCheck] = field(default_factory=list)

    def add(
        self, name: str, category: str, status: str, expected: Any, actual: Any, message: str = "", details: Dict = None
    ):
        self.checks.append(
            AuditCheck(
                name=name,
                category=category,
                status=status,
                expected=expected,
                actual=actual,
                message=message,
                details=details or {},
            )
        )

    @property
    def passed(self) -> int:
        return sum(1 for c in self.checks if c.status == "PASS")

    @property
    def failed(self) -> int:
        return sum(1 for c in self.checks if c.status == "FAIL")

    @property
    def warned(self) -> int:
        return sum(1 for c in self.checks if c.status == "WARN")

    @property
    def skipped(self) -> int:
        return sum(1 for c in self.checks if c.status == "SKIP")

    @property
    def exit_code(self) -> int:
        if self.failed > 0:
            return 1
        if self.warned > 0:
            return 2
        return 0


# =============================================================================
# MAIN AUDITOR CLASS
# =============================================================================


class DashboardAuditor:
    """
    Audits dashboard data consistency across log, database, and HTML.

    Checks:
    1. File existence and accessibility
    2. CVE count consistency (log → db → dashboard)
    3. CWE count consistency
    4. Secret count consistency
    5. AI/LLM findings consistency
    6. DLP findings consistency
    7. Reachability counts
    8. Call path population (non-NULL check)
    9. Risk level population
    10. Fix status consistency
    11. Severity distribution
    12. Total action required items
    """

    def __init__(self, scan_dir: Path):
        self.scan_dir = Path(scan_dir)
        self.repo_root = self.scan_dir.parent.parent  # branch/timestamp → repo_root

        # File paths
        self.db_path = self.repo_root / "repo.db"
        self.log_path = self.scan_dir / "scan.log"
        self.dashboard_dir = self.scan_dir / "dashboard"
        self.data_json = self.dashboard_dir / "data.json"
        self.index_html = self.dashboard_dir / "index.html"

        # Metrics storage
        self.log_metrics = {}
        self.db_metrics = {}
        self.dashboard_metrics = {}

        # Report
        self.report = AuditReport(scan_path=str(scan_dir))
        self.report.timestamp = datetime.now().isoformat()

    def run_audit(self) -> AuditReport:
        """Run complete audit and return report."""
        print(f"🔍 Auditing: {self.scan_dir}")

        # Phase 1: Validate file existence
        if not self._validate_paths():
            return self.report

        # Phase 2: Extract metrics from each source
        self._parse_log()
        self._parse_database()
        self._parse_dashboard()

        # Phase 3: Run consistency checks
        self._check_cve_counts()
        self._check_cwe_counts()
        self._check_secret_counts()
        self._check_ai_counts()
        self._check_dlp_counts()
        self._check_reachability()
        self._check_call_paths()
        self._check_risk_levels()
        self._check_fix_status()
        self._check_action_required()

        return self.report

    # =========================================================================
    # PHASE 1: FILE VALIDATION
    # =========================================================================

    def _validate_paths(self) -> bool:
        """Validate required files exist."""
        valid = True

        if not self.db_path.exists():
            self.report.add("db_exists", "files", "FAIL", "exists", "missing", f"Database not found: {self.db_path}")
            valid = False
        else:
            self.report.add("db_exists", "files", "PASS", "exists", "exists")

        if not self.log_path.exists():
            self.report.add("log_exists", "files", "FAIL", "exists", "missing", f"Log not found: {self.log_path}")
            valid = False
        else:
            self.report.add("log_exists", "files", "PASS", "exists", "exists")

        if not self.dashboard_dir.exists():
            self.report.add(
                "dashboard_exists", "files", "FAIL", "exists", "missing", f"Dashboard not found: {self.dashboard_dir}"
            )
            valid = False
        else:
            self.report.add("dashboard_exists", "files", "PASS", "exists", "exists")

        return valid

    # =========================================================================
    # PHASE 2: METRIC EXTRACTION
    # =========================================================================

    def _parse_log(self):
        """Extract metrics from scan.log"""
        try:
            content = self.log_path.read_text()
        except Exception as e:
            self.report.add("log_readable", "files", "FAIL", "readable", str(e))
            return

        # CVE counts (multiple formats)
        cve_match = re.search(r"CVE Vulnerabilities\s+(\d+)\s+(\d+)", content)
        if cve_match:
            self.log_metrics["cve_total"] = int(cve_match.group(1))
            self.log_metrics["cve_reachable"] = int(cve_match.group(2))

        # Alternative CVE format
        cve_reach = re.search(r"✅ REACHABLE: (\d+) CVEs", content)
        cve_unreach = re.search(r"❌ UNREACHABLE: (\d+) CVEs", content)
        if cve_reach:
            self.log_metrics["cve_reachable"] = int(cve_reach.group(1))
        if cve_unreach:
            self.log_metrics["cve_unreachable"] = int(cve_unreach.group(1))
            if "cve_reachable" in self.log_metrics:
                self.log_metrics["cve_total"] = self.log_metrics["cve_reachable"] + int(cve_unreach.group(1))

        # Secret counts
        secret_match = re.search(r"security_findings\.json \((\d+) secrets\)", content)
        if secret_match:
            self.log_metrics["secret_total"] = int(secret_match.group(1))

        # AI counts
        ai_stored = re.search(r"Stored (\d+) AI findings", content)
        if ai_stored:
            self.log_metrics["ai_total"] = int(ai_stored.group(1))

        ai_reach = re.search(r"AI findings enriched: (\d+)/(\d+) reachable", content)
        if ai_reach:
            self.log_metrics["ai_reachable"] = int(ai_reach.group(1))
            self.log_metrics["ai_total"] = int(ai_reach.group(2))

        # DLP counts
        dlp_match = re.search(r"DLP/PII.*?(\d+) findings", content)
        if dlp_match:
            self.log_metrics["dlp_total"] = int(dlp_match.group(1))

        # Action required
        action_match = re.search(r"ACTION REQUIRED: (\d+) issues", content)
        if action_match:
            self.log_metrics["action_required"] = int(action_match.group(1))

        reachable_match = re.search(r"Reachable \((\d+)\)", content)
        if reachable_match:
            self.log_metrics["total_reachable"] = int(reachable_match.group(1))

    def _parse_database(self):
        """Extract metrics from repo.db"""
        try:
            conn = sqlite3.connect(str(self.db_path))
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
        except Exception as e:
            self.report.add("db_readable", "files", "FAIL", "readable", str(e))
            return

        # Get latest scan ID
        cursor.execute("""
            SELECT id, branch FROM scans
            ORDER BY timestamp DESC LIMIT 1
        """)
        row = cursor.fetchone()
        if not row:
            self.report.add("scan_exists", "files", "FAIL", "scan exists", "no scans")
            conn.close()
            return

        scan_id = row["id"]
        self.report.scan_id = scan_id
        self.report.branch = row["branch"]

        # Findings by type
        cursor.execute(
            """
            SELECT finding_type, COUNT(*) as cnt,
                   SUM(CASE WHEN app_reachability = 'REACHABLE' THEN 1 ELSE 0 END) as reachable
            FROM findings WHERE scan_id = ?
            GROUP BY finding_type
        """,
            (scan_id,),
        )

        for row in cursor.fetchall():
            ftype = row["finding_type"]
            self.db_metrics[f"{ftype}_total"] = row["cnt"]
            self.db_metrics[f"{ftype}_reachable"] = row["reachable"]

        # AI findings
        cursor.execute(
            """
            SELECT COUNT(*) as total,
                   SUM(CASE WHEN is_reachable = 1 THEN 1 ELSE 0 END) as reachable
            FROM ai_findings WHERE scan_id = ?
        """,
            (scan_id,),
        )
        row = cursor.fetchone()
        self.db_metrics["ai_total"] = row["total"]
        self.db_metrics["ai_reachable"] = row["reachable"]

        # DLP findings
        cursor.execute(
            """
            SELECT COUNT(*) as total FROM dlp_findings WHERE scan_id = ?
        """,
            (scan_id,),
        )
        self.db_metrics["dlp_total"] = cursor.fetchone()["total"]

        # Call path NULL checks
        cursor.execute(
            """
            SELECT COUNT(*) as cnt FROM findings
            WHERE scan_id = ? AND (app_reachability_path IS NULL OR app_reachability_path = '')
        """,
            (scan_id,),
        )
        self.db_metrics["findings_missing_call_path"] = cursor.fetchone()["cnt"]

        cursor.execute(
            """
            SELECT COUNT(*) as cnt FROM ai_findings
            WHERE scan_id = ? AND (call_path IS NULL OR call_path = '' OR call_path = '[]')
        """,
            (scan_id,),
        )
        self.db_metrics["ai_missing_call_path"] = cursor.fetchone()["cnt"]

        cursor.execute(
            """
            SELECT COUNT(*) as cnt FROM dlp_findings
            WHERE scan_id = ? AND (call_path IS NULL OR call_path = '' OR call_path = '[]')
        """,
            (scan_id,),
        )
        self.db_metrics["dlp_missing_call_path"] = cursor.fetchone()["cnt"]

        # Risk level NULL check
        cursor.execute(
            """
            SELECT COUNT(*) as cnt FROM findings
            WHERE scan_id = ? AND (risk_level IS NULL OR risk_level = '')
        """,
            (scan_id,),
        )
        self.db_metrics["findings_missing_risk_level"] = cursor.fetchone()["cnt"]

        # Total findings
        cursor.execute("SELECT COUNT(*) FROM findings WHERE scan_id = ?", (scan_id,))
        self.db_metrics["findings_total"] = cursor.fetchone()[0]

        conn.close()

    def _parse_dashboard(self):
        """Extract metrics from dashboard HTML or data.json"""
        # Try data.json first
        if self.data_json.exists():
            try:
                data = json.loads(self.data_json.read_text())
                self._extract_from_json(data)
                return
            except:
                pass

        # Fall back to index.html
        if self.index_html.exists():
            try:
                content = self.index_html.read_text()
                self._extract_from_html(content)
            except Exception as e:
                self.report.add("dashboard_readable", "files", "WARN", "readable", str(e))

    def _extract_from_json(self, data: Dict):
        """Extract metrics from data.json"""
        # Summary section
        if "summary" in data:
            summary = data["summary"]
            # Parse strings like "41 total, 26 reachable"
            cve_match = re.search(r"(\d+) total.*?(\d+) reachable", summary.get("cves", ""))
            if cve_match:
                self.dashboard_metrics["cve_total"] = int(cve_match.group(1))
                self.dashboard_metrics["cve_reachable"] = int(cve_match.group(2))

        # Findings arrays
        if "findings" in data:
            by_type = {}
            for f in data["findings"]:
                ftype = f.get("finding_type", f.get("type", "unknown"))
                by_type[ftype] = by_type.get(ftype, 0) + 1

            for ftype, count in by_type.items():
                self.dashboard_metrics[f"{ftype}_count"] = count

        # DLP
        if "dlp_findings" in data:
            self.dashboard_metrics["dlp_total"] = len(data["dlp_findings"])

        # AI
        if "ai_findings" in data:
            self.dashboard_metrics["ai_total"] = len(data["ai_findings"])

    def _extract_from_html(self, content: str):
        """Extract metrics from index.html"""
        # DLP finding types
        dlp_ai = content.count('finding_type": "dlp_ai"')
        dlp_disc = content.count('finding_type": "dlp_discovery"')
        dlp_taint = content.count('finding_type": "dlp_taint"')
        self.dashboard_metrics["dlp_entries"] = dlp_ai + dlp_disc + dlp_taint

        # CVE summary
        cve_match = re.search(r'"summary"[^}]*"cves":\s*"(\d+) total,\s*(\d+) reachable"', content)
        if cve_match:
            self.dashboard_metrics["cve_total"] = int(cve_match.group(1))
            self.dashboard_metrics["cve_reachable"] = int(cve_match.group(2))

    # =========================================================================
    # PHASE 3: CONSISTENCY CHECKS
    # =========================================================================

    def _check_cve_counts(self):
        """Check CVE count consistency"""
        log_total = self.log_metrics.get("cve_total")
        db_total = self.db_metrics.get("cve_total")
        dash_total = self.dashboard_metrics.get("cve_total")

        # Log vs DB
        if log_total is not None and db_total is not None:
            if log_total == db_total:
                self.report.add("cve_log_db", "cve", "PASS", log_total, db_total)
            else:
                self.report.add(
                    "cve_log_db", "cve", "FAIL", log_total, db_total, f"Log has {log_total} CVEs, DB has {db_total}"
                )

        # DB vs Dashboard
        if db_total is not None and dash_total is not None:
            if db_total == dash_total:
                self.report.add("cve_db_dash", "cve", "PASS", db_total, dash_total)
            else:
                self.report.add(
                    "cve_db_dash",
                    "cve",
                    "WARN",
                    db_total,
                    dash_total,
                    f"DB has {db_total} CVEs, Dashboard shows {dash_total}",
                )

    def _check_cwe_counts(self):
        """Check CWE count consistency"""
        db_total = self.db_metrics.get("cwe_total")
        if db_total is not None:
            self.report.add("cwe_count", "cwe", "PASS", db_total, db_total, details={"db_total": db_total})

    def _check_secret_counts(self):
        """Check secret count consistency"""
        log_total = self.log_metrics.get("secret_total")
        db_total = self.db_metrics.get("secret_total")

        if log_total is not None and db_total is not None:
            if log_total == db_total:
                self.report.add("secret_log_db", "secrets", "PASS", log_total, db_total)
            else:
                diff = log_total - db_total
                self.report.add(
                    "secret_log_db",
                    "secrets",
                    "WARN",
                    log_total,
                    db_total,
                    f"Log has {log_total} secrets, DB has {db_total} ({diff} missing)",
                )

    def _check_ai_counts(self):
        """Check AI/LLM findings consistency"""
        log_total = self.log_metrics.get("ai_total")
        db_total = self.db_metrics.get("ai_total")

        if log_total is not None and db_total is not None:
            if log_total == db_total:
                self.report.add("ai_log_db", "ai_llm", "PASS", log_total, db_total)
            else:
                self.report.add(
                    "ai_log_db",
                    "ai_llm",
                    "FAIL",
                    log_total,
                    db_total,
                    f"Log has {log_total} AI findings, DB has {db_total}",
                )

    def _check_dlp_counts(self):
        """Check DLP findings consistency"""
        log_total = self.log_metrics.get("dlp_total")
        db_total = self.db_metrics.get("dlp_total")
        dash_entries = self.dashboard_metrics.get("dlp_entries")

        if log_total is not None and db_total is not None:
            if log_total == db_total:
                self.report.add("dlp_log_db", "dlp", "PASS", log_total, db_total)
            else:
                self.report.add(
                    "dlp_log_db",
                    "dlp",
                    "FAIL",
                    log_total,
                    db_total,
                    f"Log has {log_total} DLP findings, DB has {db_total}",
                )

        # Check for HTML doubling issue
        if db_total and dash_entries and dash_entries > db_total * 1.5:
            self.report.add(
                "dlp_html_doubled",
                "dlp",
                "WARN",
                db_total,
                dash_entries,
                f"Dashboard shows {dash_entries} DLP entries vs {db_total} in DB (possible duplication)",
            )

    def _check_reachability(self):
        """Check reachability data population"""
        for ftype in ["cve", "cwe", "secret"]:
            total = self.db_metrics.get(f"{ftype}_total", 0)
            reachable = self.db_metrics.get(f"{ftype}_reachable", 0)

            if total > 0:
                pct = (reachable / total) * 100
                self.report.add(
                    f"{ftype}_reachability",
                    "reachability",
                    "PASS",
                    f"{total} total",
                    f"{reachable} reachable ({pct:.0f}%)",
                )

    def _check_call_paths(self):
        """Check call path population (CRITICAL)"""
        # Findings table
        total = self.db_metrics.get("findings_total", 0)
        missing = self.db_metrics.get("findings_missing_call_path", 0)

        if total > 0:
            pct_missing = (missing / total) * 100
            if pct_missing > 80:
                self.report.add(
                    "findings_call_paths",
                    "call_paths",
                    "FAIL",
                    "< 20% missing",
                    f"{missing}/{total} missing ({pct_missing:.0f}%)",
                    "CRITICAL: Most findings lack call paths",
                )
            elif pct_missing > 50:
                self.report.add(
                    "findings_call_paths",
                    "call_paths",
                    "WARN",
                    "< 50% missing",
                    f"{missing}/{total} missing ({pct_missing:.0f}%)",
                )
            else:
                self.report.add(
                    "findings_call_paths",
                    "call_paths",
                    "PASS",
                    "< 50% missing",
                    f"{missing}/{total} missing ({pct_missing:.0f}%)",
                )

        # AI findings
        ai_total = self.db_metrics.get("ai_total", 0)
        ai_missing = self.db_metrics.get("ai_missing_call_path", 0)

        if ai_total > 0:
            pct_missing = (ai_missing / ai_total) * 100
            status = "PASS" if pct_missing < 50 else "WARN"
            self.report.add(
                "ai_call_paths",
                "call_paths",
                status,
                "< 50% missing",
                f"{ai_missing}/{ai_total} missing ({pct_missing:.0f}%)",
            )

        # DLP findings
        dlp_total = self.db_metrics.get("dlp_total", 0)
        dlp_missing = self.db_metrics.get("dlp_missing_call_path", 0)

        if dlp_total > 0:
            pct_missing = (dlp_missing / dlp_total) * 100
            if pct_missing > 80:
                self.report.add(
                    "dlp_call_paths",
                    "call_paths",
                    "FAIL",
                    "< 20% missing",
                    f"{dlp_missing}/{dlp_total} missing ({pct_missing:.0f}%)",
                    "CRITICAL: Most DLP findings lack call paths",
                )
            else:
                self.report.add(
                    "dlp_call_paths",
                    "call_paths",
                    "PASS",
                    "< 80% missing",
                    f"{dlp_missing}/{dlp_total} missing ({pct_missing:.0f}%)",
                )

    def _check_risk_levels(self):
        """Check risk_level population"""
        total = self.db_metrics.get("findings_total", 0)
        missing = self.db_metrics.get("findings_missing_risk_level", 0)

        if total > 0:
            pct_missing = (missing / total) * 100
            if pct_missing > 50:
                self.report.add(
                    "risk_levels",
                    "risk",
                    "FAIL",
                    "< 50% missing",
                    f"{missing}/{total} missing ({pct_missing:.0f}%)",
                    "SLA guidance cannot be derived without risk_level",
                )
            else:
                self.report.add(
                    "risk_levels", "risk", "PASS", "< 50% missing", f"{missing}/{total} missing ({pct_missing:.0f}%)"
                )

    def _check_fix_status(self):
        """Check fix status distribution"""
        # This would need additional DB queries
        self.report.add("fix_status", "fix", "SKIP", "N/A", "N/A", "Not implemented")

    def _check_action_required(self):
        """Check action required total"""
        log_action = self.log_metrics.get("action_required")
        db_total = (
            self.db_metrics.get("findings_total", 0)
            + self.db_metrics.get("ai_total", 0)
            + self.db_metrics.get("dlp_total", 0)
        )

        if log_action is not None:
            self.report.add(
                "action_required",
                "totals",
                "PASS",
                log_action,
                db_total,
                details={"log": log_action, "db_calculated": db_total},
            )


# =============================================================================
# OUTPUT FORMATTERS
# =============================================================================


def format_report_text(report: AuditReport) -> str:
    """Format report as human-readable text."""
    lines = [
        "=" * 70,
        "REACHABLE DASHBOARD AUDIT REPORT",
        "=" * 70,
        f"Scan: {report.scan_path}",
        f"Scan ID: {report.scan_id}",
        f"Branch: {report.branch}",
        f"Timestamp: {report.timestamp}",
        "",
        f"Results: {report.passed} PASS | {report.failed} FAIL | {report.warned} WARN | {report.skipped} SKIP",
        "-" * 70,
    ]

    # Group by category
    by_category = {}
    for check in report.checks:
        if check.category not in by_category:
            by_category[check.category] = []
        by_category[check.category].append(check)

    status_icons = {"PASS": "✅", "FAIL": "❌", "WARN": "⚠️", "SKIP": "⏭️"}

    for category, checks in by_category.items():
        lines.append(f"\n[{category.upper()}]")
        for check in checks:
            icon = status_icons.get(check.status, "?")
            lines.append(f"  {icon} {check.name}: {check.expected} → {check.actual}")
            if check.message:
                lines.append(f"     └─ {check.message}")

    lines.append("")
    lines.append("=" * 70)

    return "\n".join(lines)


def format_report_json(report: AuditReport) -> str:
    """Format report as JSON."""
    return json.dumps(
        {
            "scan_path": report.scan_path,
            "scan_id": report.scan_id,
            "branch": report.branch,
            "timestamp": report.timestamp,
            "summary": {
                "passed": report.passed,
                "failed": report.failed,
                "warned": report.warned,
                "skipped": report.skipped,
                "exit_code": report.exit_code,
            },
            "checks": [asdict(c) for c in report.checks],
        },
        indent=2,
    )


# =============================================================================
# CLI
# =============================================================================


def find_latest_scan(repo_root: Path) -> Optional[Path]:
    """Find the latest scan directory for a repo."""
    scans = []
    for branch_dir in repo_root.iterdir():
        if branch_dir.is_dir() and branch_dir.name not in ["repo.db", ".git"]:
            for scan_dir in branch_dir.iterdir():
                if scan_dir.is_dir() and (scan_dir / "scan.log").exists():
                    scans.append(scan_dir)

    if not scans:
        return None

    # Sort by name (timestamp format)
    scans.sort(key=lambda x: x.name, reverse=True)
    return scans[0]


def find_repo_dir(start_path: Path) -> Optional[Path]:
    """Find the repo directory containing repo.db."""
    # If start_path has repo.db, it's the repo dir
    if (start_path / "repo.db").exists():
        return start_path

    # Check parent directories
    for parent in [start_path.parent, start_path.parent.parent]:
        if (parent / "repo.db").exists():
            return parent

    # Search in ~/.reachable/scans/ for matching repos
    reachable_scans = Path.home() / ".reachable" / "scans"
    if reachable_scans.exists():
        for repo_dir in reachable_scans.iterdir():
            if repo_dir.is_dir() and (repo_dir / "repo.db").exists():
                # Check if start_path matches this repo
                if start_path.name in str(repo_dir) or str(repo_dir) in str(start_path):
                    return repo_dir

    return None


def main():
    parser = argparse.ArgumentParser(
        description="REACHABLE Dashboard Audit Tool",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=__doc__,
    )
    parser.add_argument("scan_path", help="Path to scan directory or repo root")
    parser.add_argument("--json", action="store_true", help="Output as JSON")
    parser.add_argument("--quiet", action="store_true", help="Only output on failure")
    parser.add_argument("--latest", action="store_true", help="Find latest scan in repo")

    args = parser.parse_args()

    scan_path = Path(args.scan_path).expanduser().resolve()

    # Handle --latest flag or if path doesn't have scan.log
    if args.latest or not (scan_path / "scan.log").exists():
        # Try to find repo root first
        repo_dir = find_repo_dir(scan_path)

        if repo_dir:
            # Found repo, now find latest scan
            latest = find_latest_scan(repo_dir)
            if latest:
                scan_path = latest
                print(f"📍 Found latest scan: {scan_path}")
            else:
                print(f"Error: No scans found in {repo_dir}", file=sys.stderr)
                sys.exit(3)
        else:
            print(f"Error: Cannot find repo.db for {scan_path}", file=sys.stderr)
            print("Try: python scripts/dashboard_audit.py ~/.reachable/scans/REPO_NAME --latest")
            sys.exit(3)

    # Run audit
    auditor = DashboardAuditor(scan_path)
    report = auditor.run_audit()

    # Output
    if args.json:
        print(format_report_json(report))
    elif not args.quiet or report.exit_code > 0:
        print(format_report_text(report))

    sys.exit(report.exit_code)


if __name__ == "__main__":
    main()
