#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.

"""
REACHABLE Release Validation Script
Validates release package before distribution.
"""

import subprocess
import sys
from pathlib import Path
from typing import List, Tuple


def validate_release(release_dir: str) -> Tuple[List[str], List[str]]:
    """
    Validate a release before packaging.

    Returns:
        Tuple of (errors, warnings)
    """
    errors = []
    warnings = []
    release_path = Path(release_dir)

    print("=" * 60)
    print("REACHABLE RELEASE VALIDATION")
    print("=" * 60)

    # 1. Check VERSION consistency
    print("\n1. Checking VERSION consistency...")
    version_files = {
        "VERSION": release_path / "VERSION",
        "reachable/VERSION": release_path / "reachable" / "VERSION",
    }

    versions_found = {}
    for name, path in version_files.items():
        if path.exists():
            versions_found[name] = path.read_text().strip()
        else:
            errors.append(f"Missing version file: {name}")

    version = ""
    if len(set(versions_found.values())) > 1:
        errors.append(f"Version mismatch: {versions_found}")
    elif versions_found:
        version = list(versions_found.values())[0]
        print(f"   ✅ Version consistent: {version}")

    # Check __init__.py reads from VERSION file
    init_file = release_path / "reachable" / "__init__.py"
    if init_file.exists():
        content = init_file.read_text()
        if "_get_version()" in content and "__version__ = _get_version()" in content:
            print("   ✅ __init__.py reads from VERSION file")
        elif "__version__" in content:
            for line in content.split("\n"):
                if "__version__" in line and "=" in line and "_get_version" not in line:
                    init_version = line.split("=")[1].strip().strip("\"'")
                    if init_version != version:
                        errors.append(f"__init__.py version ({init_version}) doesn't match VERSION file")
                    else:
                        print("   ✅ __init__.py version matches")
                    break

    # 2. Check required files exist
    print("\n2. Checking required files...")
    required_files = [
        "VERSION",
        "README.md",
        "LICENSE",
        "pyproject.toml",
        "reachctl",
        ".gitignore",
        "reachable/__init__.py",
        "reachable/reachable.py",
        "reachable/cli.py",
    ]

    for req_file in required_files:
        if (release_path / req_file).exists():
            print(f"   ✅ {req_file}")
        else:
            errors.append(f"Missing required file: {req_file}")

    # 3. Check copyright headers
    print("\n3. Checking copyright headers...")
    missing_copyright = []
    for py_file in release_path.glob("**/*.py"):
        if "__pycache__" in str(py_file):
            continue
        content = py_file.read_text()
        if "Copyright" not in content or "Sthenos Security" not in content:
            missing_copyright.append(py_file.name)

    if missing_copyright:
        errors.append(
            f"Files missing copyright: {', '.join(missing_copyright[:5])}{'...' if len(missing_copyright) > 5 else ''}"
        )
    else:
        print("   ✅ All Python files have copyright header")

    # 4. Check LICENSE file content
    print("\n4. Checking LICENSE file...")
    license_file = release_path / "LICENSE"
    if license_file.exists():
        license_content = license_file.read_text()
        required_terms = ["PROPRIETARY", "Sthenos Security", "EVALUATION", "RESTRICTIONS"]
        missing_terms = [t for t in required_terms if t not in license_content]
        if missing_terms:
            warnings.append(f"LICENSE missing terms: {missing_terms}")
        else:
            print("   ✅ LICENSE contains required terms")

    # 5. Check dashboard_v2 components
    print("\n5. Checking dashboard_v2 components...")
    dashboard_v2_files = [
        "reachable/dashboard_v2/__init__.py",
        "reachable/dashboard_v2/generator.py",
        "reachable/dashboard_v2/template.html",
    ]

    for dfile in dashboard_v2_files:
        if (release_path / dfile).exists():
            print(f"   ✅ {dfile}")
        else:
            errors.append(f"Missing dashboard_v2 file: {dfile}")

    # 6. Check for __pycache__ directories
    print("\n6. Checking for __pycache__ (should be removed)...")
    pycache_dirs = list(release_path.glob("**/__pycache__"))
    if pycache_dirs:
        errors.append(f"Found {len(pycache_dirs)} __pycache__ directories - remove before release")
    else:
        print("   ✅ No __pycache__ directories")

    # 7. Check documentation
    print("\n7. Checking documentation...")
    doc_files = [
        "docs/DASHBOARD_DESIGN.md",
        "docs/TERMINOLOGY.md",
    ]

    for doc_file in doc_files:
        if (release_path / doc_file).exists():
            print(f"   ✅ {doc_file}")
        else:
            warnings.append(f"Missing doc file: {doc_file}")

    # 8. Check release notes
    print("\n8. Checking release notes...")
    if version:
        expected_release_notes = f"RELEASE_NOTES_v{version}.md"
        if (release_path / expected_release_notes).exists():
            print(f"   ✅ {expected_release_notes}")
        else:
            warnings.append(f"Missing release notes: {expected_release_notes}")

    # 9. Verify dashboard features
    print("\n9. Checking dashboard features...")
    template_path = release_path / "reachable" / "dashboard_v2" / "template.html"
    if template_path.exists():
        template_content = template_path.read_text()

        features = {
            "Compliance links": "complianceLinkGenerators" in template_content,
            "vscode:// links": "vscode://file" in template_content,
            "Risk vs Severity clarity": "Raw Severity" in template_content,
            "Context notes": "context-note" in template_content,
        }

        for feature, present in features.items():
            if present:
                print(f"   ✅ {feature}")
            else:
                warnings.append(f"Dashboard missing: {feature}")

    # 10. Test import
    print("\n10. Testing import...")
    try:
        result = subprocess.run(
            [
                sys.executable,
                "-c",
                f"import sys; sys.path.insert(0, '{release_path}'); import reachable; print(reachable.__version__)",
            ],
            capture_output=True,
            text=True,
            timeout=10,
        )
        if result.returncode == 0:
            imported_version = result.stdout.strip()
            if imported_version == version:
                print(f"   ✅ Import successful, version: {imported_version}")
            else:
                errors.append(f"Imported version ({imported_version}) doesn't match VERSION ({version})")
        else:
            warnings.append(f"Import test failed: {result.stderr[:100]}")
    except Exception as e:
        warnings.append(f"Could not test import: {e}")

    # RESULTS
    print("\n" + "=" * 60)
    print("VALIDATION RESULTS")
    print("=" * 60)

    if errors:
        print("\n❌ ERRORS (must fix before release):")
        for error in errors:
            print(f"   • {error}")

    if warnings:
        print("\n⚠️  WARNINGS (should review):")
        for warning in warnings:
            print(f"   • {warning}")

    if not errors:
        print("\n✅ RELEASE VALIDATED - Ready to package!")
    else:
        print(f"\n❌ RELEASE FAILED - Fix {len(errors)} error(s) before release")

    return errors, warnings


if __name__ == "__main__":
    if len(sys.argv) > 1:
        release_dir = sys.argv[1]
    else:
        release_dir = str(Path(__file__).parent.parent)

    errors, warnings = validate_release(release_dir)
    sys.exit(1 if errors else 0)
