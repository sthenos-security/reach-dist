#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.

"""
Migrate logger imports from per-file logging.getLogger(__name__)
to centralized `from reachable.logger import logger`.

Required BEFORE code modularization (v5.1.1) — with getLogger(__name__),
every file move changes the logger name. Centralized import is path-independent.

What this does:
  1. Replaces `logger = logging.getLogger(__name__)` with nothing (removes line)
  2. Adds `from reachable.logger import logger` if not already present
  3. Removes `import logging` ONLY if no other logging.* usage remains
  4. Skips infrastructure files (logger.py, scan_logger.py, core/logger.py, setup.py)

Usage:
    python3 scripts/migrate-logger-imports.py --dry-run   # Preview
    python3 scripts/migrate-logger-imports.py              # Apply
    python3 scripts/migrate-logger-imports.py --verify     # Post-check
"""

import ast
import re
import sys
from pathlib import Path
from typing import Tuple

# Files to SKIP — they ARE the logging infrastructure or outside the package
SKIP_FILES = {
    "logger.py",  # reachable/logger.py — IS the centralized logger
    "scan_logger.py",  # Uses logging internally for ScanLogger
}

SKIP_PATHS = {
    "reachable/core/logger.py",  # Core logger implementation
    "reachable/core/__init__.py",  # Imports from core.logger
    "setup.py",  # Outside package
}

# The line we're replacing
OLD_PATTERN = re.compile(r"^logger\s*=\s*logging\.getLogger\(__name__\)\s*$")

# The new import line
NEW_IMPORT = "from reachable.logger import logger"


def should_skip(filepath: Path, repo_root: Path) -> bool:
    """Check if file should be skipped."""
    rel = str(filepath.relative_to(repo_root))
    if filepath.name in SKIP_FILES:
        return True
    if rel in SKIP_PATHS:
        return True
    if "__pycache__" in rel:
        return True
    if "/build/" in rel or "/venv/" in rel or "/dist/" in rel:
        return True
    # Skip test files — they may run standalone
    if rel.startswith("tests/"):
        return True
    return False


def has_other_logging_usage(content: str) -> bool:
    """Check if 'logging.' is used for anything besides getLogger(__name__)."""
    lines = content.split("\n")
    for line in lines:
        stripped = line.strip()
        # Skip the getLogger line itself
        if OLD_PATTERN.match(stripped):
            continue
        # Skip import logging
        if stripped == "import logging":
            continue
        # Skip comments
        if stripped.startswith("#"):
            continue
        # Check for any other logging.* usage
        if "logging." in stripped:
            return True
    return False


def process_file(filepath: Path, repo_root: Path, dry_run: bool = False) -> Tuple[bool, str]:
    """
    Process a single file.

    Returns: (changed, message)
    """
    try:
        content = filepath.read_text(encoding="utf-8")
    except Exception as e:
        return False, f"Read error: {e}"

    lines = content.split("\n")

    # Find the getLogger line
    getlogger_idx = None
    for i, line in enumerate(lines):
        if OLD_PATTERN.match(line.strip()):
            getlogger_idx = i
            break

    if getlogger_idx is None:
        return False, "No getLogger(__name__) found"

    # Check if centralized import already exists
    has_new_import = NEW_IMPORT in content

    # Build new lines
    new_lines = []
    import_added = False
    removed_getlogger = False
    removed_import_logging = False

    # Check if we can remove `import logging`
    other_logging = has_other_logging_usage(content)

    for i, line in enumerate(lines):
        stripped = line.strip()

        # Remove the getLogger line
        if i == getlogger_idx:
            # Also remove blank line after if it exists
            removed_getlogger = True
            # Remove trailing blank line left by removal
            if i + 1 < len(lines) and lines[i + 1].strip() == "":
                # We'll skip the blank line in next iteration
                pass
            continue

        # Skip blank line that followed removed getLogger
        if removed_getlogger and not import_added and i == getlogger_idx + 1 and stripped == "":
            continue

        # Remove `import logging` if nothing else uses it
        if stripped == "import logging" and not other_logging:
            removed_import_logging = True
            # If next line is blank (the separator after imports), keep it
            continue

        # Add our import after the last existing import (before getLogger was)
        # Strategy: add it where getLogger was
        if i == getlogger_idx + 1 and not has_new_import and not import_added:
            new_lines.append(NEW_IMPORT)
            import_added = True

        new_lines.append(line)

    # If import wasn't added yet (getLogger was at end of imports), add it
    if not has_new_import and not import_added:
        # Find last import and insert after
        last_import_idx = -1
        for i, line in enumerate(new_lines):
            stripped = line.strip()
            if stripped.startswith("import ") or stripped.startswith("from "):
                last_import_idx = i
        if last_import_idx >= 0:
            new_lines.insert(last_import_idx + 1, NEW_IMPORT)
            import_added = True

    new_content = "\n".join(new_lines)

    # Syntax check before writing
    try:
        ast.parse(new_content)
    except SyntaxError as e:
        return False, f"SYNTAX ERROR after transform: {e}"

    # Build change summary
    changes = []
    if removed_getlogger:
        changes.append("removed getLogger(__name__)")
    if import_added:
        changes.append("added centralized import")
    if removed_import_logging:
        changes.append("removed unused import logging")

    if not changes:
        return False, "No changes needed"

    summary = ", ".join(changes)

    if dry_run:
        return True, f"WOULD: {summary}"

    # Write
    try:
        filepath.write_text(new_content, encoding="utf-8")
        return True, f"✅ {summary}"
    except Exception as e:
        return False, f"Write error: {e}"


def verify_file(filepath: Path) -> Tuple[bool, str]:
    """Verify a file has correct logger setup."""
    try:
        content = filepath.read_text(encoding="utf-8")
    except:
        return False, "Can't read"

    has_old = bool(re.search(r"logger\s*=\s*logging\.getLogger\(__name__\)", content))
    has_new = NEW_IMPORT in content

    if has_old and not has_new:
        return False, "NEEDS MIGRATION"
    if has_old and has_new:
        return False, "HAS BOTH (needs cleanup)"
    if has_new:
        return True, "OK (centralized)"

    # Check if it uses logger at all
    if re.search(r"\blogger\.", content):
        return False, "USES logger BUT NO IMPORT"

    return True, "OK (no logger usage)"


def main():
    import argparse

    parser = argparse.ArgumentParser(description="Migrate to centralized logger")
    parser.add_argument("--dry-run", action="store_true", help="Preview without changes")
    parser.add_argument("--verify", action="store_true", help="Verify current state")
    parser.add_argument("--path", default="reachable", help="Directory to process")
    args = parser.parse_args()

    repo_root = Path(__file__).parent.parent
    target_dir = repo_root / args.path

    if not target_dir.exists():
        print(f"❌ Not found: {target_dir}")
        return 1

    py_files = sorted(target_dir.rglob("*.py"))

    print("=" * 70)
    if args.verify:
        print("VERIFY LOGGER IMPORTS")
    elif args.dry_run:
        print("MIGRATE LOGGER IMPORTS (DRY RUN)")
    else:
        print("MIGRATE LOGGER IMPORTS")
    print("=" * 70)
    print(f"Scanning {len(py_files)} files in {target_dir}/")
    print()

    changed = []
    skipped_infra = []
    skipped_ok = []
    errors = []

    for py_file in py_files:
        rel = py_file.relative_to(repo_root)

        if should_skip(py_file, repo_root):
            skipped_infra.append(rel)
            continue

        if args.verify:
            ok, msg = verify_file(py_file)
            if not ok:
                errors.append((rel, msg))
                print(f"  ❌ {rel}: {msg}")
            # Don't print OK files (too noisy)
        else:
            did_change, msg = process_file(py_file, repo_root, dry_run=args.dry_run)
            if did_change:
                changed.append(rel)
                print(f"  ✅ {rel}: {msg}")
            elif "error" in msg.lower() or "SYNTAX" in msg:
                errors.append((rel, msg))
                print(f"  ❌ {rel}: {msg}")
            else:
                skipped_ok.append(rel)

    print()
    print("=" * 70)
    print("SUMMARY")
    print("=" * 70)

    if args.verify:
        print(f"  Files OK:      {len(py_files) - len(errors) - len(skipped_infra)}")
        print(f"  Need fix:      {len(errors)}")
        print(f"  Infra skipped: {len(skipped_infra)}")
        if errors:
            print()
            print("Files needing migration:")
            for rel, msg in errors:
                print(f"  • {rel}: {msg}")
    else:
        print(f"  Changed:       {len(changed)}")
        print(f"  Skipped (OK):  {len(skipped_ok)}")
        print(f"  Skipped (infra): {len(skipped_infra)}")
        print(f"  Errors:        {len(errors)}")

        if changed:
            print()
            print("Changed files:")
            for f in changed:
                print(f"  • {f}")

        if errors:
            print()
            print("Errors:")
            for f, msg in errors:
                print(f"  • {f}: {msg}")

        if not args.dry_run and changed:
            print()
            print("Next steps:")
            print("  1. git diff reachable/")
            print("  2. python3 scripts/migrate-logger-imports.py --verify")
            print("  3. python3 -c 'import reachable.cli'  # smoke test")
            print("  4. ./reachctl scan ~/src/orca-toolbox")
            print("  5. git add reachable/ && git commit -m 'Migrate to centralized logger'")

    return 0 if not errors else 1


if __name__ == "__main__":
    sys.exit(main())
