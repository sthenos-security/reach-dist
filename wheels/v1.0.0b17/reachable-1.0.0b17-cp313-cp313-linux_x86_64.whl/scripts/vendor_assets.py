#!/usr/bin/env python3
# Copyright (c) 2026 Sthenos Security. All rights reserved.
"""
scripts/vendor_assets.py — Download and vendor dashboard assets for air-gapped environments.

Run this ONCE before building the dashboard template in environments without internet access:

    python3 scripts/vendor_assets.py

Then rebuild the template:

    cd reachable/dashboard_v2 && ./rebuild-template.sh

The build.py script detects the vendored files and inlines them, replacing CDN references.
The resulting template-shell.html works with no outbound network connections.

Assets vendored:
  - Chart.js 4.4.1 (UMD build) — trend charts in dashboard
    Source: https://cdn.jsdelivr.net/npm/chart.js@4.4.1/dist/chart.umd.min.js
    Dest:   reachable/dashboard_v2/split/components/vendor/chart.js.min.js
"""

from __future__ import annotations

import hashlib
import sys
import urllib.request
from pathlib import Path

# ── Asset manifest ─────────────────────────────────────────────────────────────

ASSETS = [
    {
        "name": "Chart.js 4.4.1 (UMD)",
        "url": "https://cdn.jsdelivr.net/npm/chart.js@4.4.1/dist/chart.umd.min.js",
        "dest": "reachable/dashboard_v2/split/components/vendor/chart.js.min.js",
        # SHA-256 of the expected file — protects against CDN tampering
        "sha256": None,  # Set to None to skip verification, or paste hash after first run
        "min_size": 150_000,  # bytes — sanity check
    },
]

# ── Helpers ───────────────────────────────────────────────────────────────────


def _download(url: str, dest: Path, sha256: str | None, min_size: int) -> bool:
    print(f"  Downloading {url}")
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "reachable-vendor/1.0"})
        with urllib.request.urlopen(req, timeout=30) as resp:
            data = resp.read()
    except Exception as e:
        print(f"  [FAIL] Download error: {e}")
        return False

    if len(data) < min_size:
        print(f"  [FAIL] Downloaded file is too small ({len(data)} bytes, expected >= {min_size})")
        return False

    if sha256:
        actual = hashlib.sha256(data).hexdigest()
        if actual != sha256:
            print(f"  [FAIL] SHA-256 mismatch: expected {sha256}, got {actual}")
            return False
        print("  [OK] SHA-256 verified")
    else:
        actual = hashlib.sha256(data).hexdigest()
        print(f"  [INFO] SHA-256: {actual}  (add to ASSETS manifest to enable verification)")

    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_bytes(data)
    print(f"  [OK] Saved {len(data):,} bytes → {dest}")
    return True


# ── Main ──────────────────────────────────────────────────────────────────────


def main() -> int:
    repo_root = Path(__file__).parent.parent
    print("REACHABLE vendor_assets.py — downloading dashboard assets for air-gap build")
    print(f"Repo root: {repo_root}\n")

    ok = 0
    fail = 0
    skip = 0

    for asset in ASSETS:
        dest = repo_root / asset["dest"]
        print(f"Asset: {asset['name']}")

        if dest.exists():
            size = dest.stat().st_size
            if size >= asset.get("min_size", 0):
                print(f"  [SKIP] Already exists ({size:,} bytes) — delete to re-download")
                skip += 1
                continue
            else:
                print(f"  [WARN] Existing file too small ({size} bytes), re-downloading")

        success = _download(
            url=asset["url"],
            dest=dest,
            sha256=asset.get("sha256"),
            min_size=asset.get("min_size", 0),
        )
        if success:
            ok += 1
        else:
            fail += 1
        print()

    print("─" * 60)
    print(f"Done: {ok} downloaded, {skip} skipped, {fail} failed")

    if fail:
        print("\n[ERROR] Some assets failed to download.")
        print("  Check your internet connection and try again.")
        return 1

    print("\nNext steps:")
    print("  cd reachable/dashboard_v2 && ./rebuild-template.sh")
    print("  The compiled template will inline all vendored assets.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
