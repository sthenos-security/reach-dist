#!/usr/bin/env python3
"""
Remove duplicate copyright/docstring header stubs.

Many reachability modules have a stale 2-line stub prepended:

    # Copyright © 2026 Sthenos Security. All rights reserved.
    'Some one-liner docstring.'
    #!/usr/bin/env python3                    <-- real header starts here
    # Copyright © 2026 Sthenos Security. All rights reserved.
    ...

This script detects that pattern and strips the stub, keeping the real
#!/usr/bin/env python3 header intact.

Usage:
    python scripts/fix-dup-headers.py          # dry-run (shows diffs)
    python scripts/fix-dup-headers.py --fix    # apply changes
"""

import sys
from pathlib import Path

REPO = Path(__file__).resolve().parent.parent

# Files that had the duplicate pattern when inspected
TARGETS = [
    "reachable/engine/reachability/_analyzer.py",
    "reachable/engine/reachability/_callgraph.py",
    "reachable/engine/reachability/_cli.py",
    "reachable/engine/reachability/_cve.py",
    "reachable/engine/reachability/_export.py",
    "reachable/engine/reachability/_graph.py",
    "reachable/engine/reachability/_malware.py",
    "reachable/engine/reachability/_parsers.py",
    "reachable/engine/reachability/_report.py",
    "reachable/engine/reachability/_secrets.py",
    "reachable/engine/reachability/_utils.py",
]

SHEBANG = "#!/usr/bin/env python3"

dry_run = "--fix" not in sys.argv
fixed = 0
skipped = 0

for rel in TARGETS:
    fpath = REPO / rel
    if not fpath.exists():
        print(f"  SKIP  {rel}  (not found)")
        skipped += 1
        continue

    text = fpath.read_text()
    lines = text.split("\n")

    # Find the first shebang line
    shebang_idx = None
    for i, line in enumerate(lines):
        if line.strip() == SHEBANG:
            shebang_idx = i
            break

    if shebang_idx is None or shebang_idx == 0:
        print(f"  OK    {rel}  (no stub / already clean)")
        skipped += 1
        continue

    stub_lines = lines[:shebang_idx]
    # Sanity check: stub should be short (2-3 lines) and contain copyright
    if len(stub_lines) > 5:
        print(f"  WARN  {rel}  (stub is {len(stub_lines)} lines — skipping for safety)")
        skipped += 1
        continue

    print(f"  FIX   {rel}  (removing {len(stub_lines)} stub lines)")
    for sl in stub_lines:
        print(f"        - {sl}")

    if not dry_run:
        new_text = "\n".join(lines[shebang_idx:])
        fpath.write_text(new_text)
        fixed += 1
    else:
        fixed += 1

print()
if dry_run:
    print(f"DRY RUN: {fixed} file(s) would be fixed, {skipped} skipped")
    print("Run with --fix to apply changes")
else:
    print(f"DONE: {fixed} file(s) fixed, {skipped} skipped")
