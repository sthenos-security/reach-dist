#!/usr/bin/env python3
"""
P2.54b Migration: Backfill scans table with findings-only totals.

Fixes historical scans where complete_scan() incorrectly included
DLP and AI counts in the scans summary row. The scans table should
reflect ONLY the findings table (CVE/CWE/secret/malware/config).

Usage:
    python scripts/p254b_backfill_scans.py

This scans ALL repo.db files under ~/.reachable/scans/ and corrects
every completed scan's summary counters.
"""

import sqlite3
from pathlib import Path


def backfill_repo_db(db_path: Path) -> dict:
    """Backfill one repo.db. Returns stats."""
    conn = sqlite3.connect(str(db_path))
    conn.row_factory = sqlite3.Row
    cur = conn.cursor()

    # Get all completed scans
    cur.execute("SELECT id FROM scans WHERE status = 'complete' ORDER BY id")
    scan_ids = [row["id"] for row in cur.fetchall()]

    fixed = 0
    for scan_id in scan_ids:
        # Get actual findings-only counts
        cur.execute(
            """
            SELECT
                COUNT(*) as total,
                SUM(CASE WHEN app_reachability = 'REACHABLE' THEN 1 ELSE 0 END) as reachable,
                SUM(CASE WHEN UPPER(severity) = 'CRITICAL' THEN 1 ELSE 0 END) as critical,
                SUM(CASE WHEN UPPER(severity) = 'HIGH' THEN 1 ELSE 0 END) as high,
                SUM(CASE WHEN UPPER(severity) = 'MEDIUM' THEN 1 ELSE 0 END) as medium,
                SUM(CASE WHEN UPPER(severity) = 'LOW' THEN 1 ELSE 0 END) as low,
                SUM(CASE WHEN LOWER(finding_type) = 'config' THEN 1 ELSE 0 END) as config,
                SUM(CASE WHEN app_reachability = 'UNKNOWN' THEN 1 ELSE 0 END) as unknown
            FROM findings WHERE scan_id = ?
        """,
            (scan_id,),
        )
        f = cur.fetchone()

        total_no_config = (f["total"] or 0) - (f["config"] or 0)

        # Check current scans table values
        cur.execute("SELECT total_findings, reachable_findings FROM scans WHERE id = ?", (scan_id,))
        s = cur.fetchone()

        if s["total_findings"] != total_no_config or s["reachable_findings"] != (f["reachable"] or 0):
            cur.execute(
                """
                UPDATE scans SET
                    total_findings = ?,
                    reachable_findings = ?,
                    critical_count = ?,
                    high_count = ?,
                    medium_count = ?,
                    low_count = ?,
                    config_count = ?,
                    unknown_count = ?
                WHERE id = ?
            """,
                (
                    total_no_config,
                    f["reachable"] or 0,
                    f["critical"] or 0,
                    f["high"] or 0,
                    f["medium"] or 0,
                    f["low"] or 0,
                    f["config"] or 0,
                    f["unknown"] or 0,
                    scan_id,
                ),
            )
            fixed += 1

    conn.commit()
    conn.close()
    return {"scans": len(scan_ids), "fixed": fixed}


def main():
    reachable_home = Path.home() / ".reachable" / "scans"
    if not reachable_home.exists():
        print("No ~/.reachable/scans/ directory found")
        return

    db_files = list(reachable_home.rglob("repo.db"))
    print(f"Found {len(db_files)} repo.db files\n")

    total_fixed = 0
    for db_path in sorted(db_files):
        repo_name = db_path.parent.name
        stats = backfill_repo_db(db_path)
        status = f"fixed {stats['fixed']}/{stats['scans']}" if stats["fixed"] else "all correct"
        print(f"  {repo_name}: {status}")
        total_fixed += stats["fixed"]

    print(f"\nDone. {total_fixed} scans corrected across {len(db_files)} repos.")


if __name__ == "__main__":
    main()
