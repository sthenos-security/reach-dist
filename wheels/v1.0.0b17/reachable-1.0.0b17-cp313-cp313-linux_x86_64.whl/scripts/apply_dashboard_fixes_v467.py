#!/usr/bin/env python3
"""
Dashboard v4.6.7 - Apply ALL Fixes
Patches main.js and dashboard-body.html with all 15 fixes
"""

import sys
from pathlib import Path


def apply_fixes():
    # Paths
    base = Path.home() / "src/reach-core/reachable/dashboard_v2/split/components"
    main_js = base / "scripts/main.js"
    html_file = base / "dashboard-body.html"

    if not main_js.exists():
        print(f"❌ File not found: {main_js}")
        return False

    if not html_file.exists():
        print(f"❌ File not found: {html_file}")
        return False

    print("📝 Reading files...")

    # Read main.js
    with open(main_js, "r") as f:
        js_content = f.read()

    # Read HTML
    with open(html_file, "r") as f:
        html_content = f.read()

    print("🔧 Applying fixes to main.js...")

    # Fix 1: DLP Reachability - respect sink_type
    old_dlp_merge = """            // v4.6.0: Merge DLP/PII findings into allIssues for Security Issues table
            const dlpFindings = d.dlp_findings || [];
            if (dlpFindings.length > 0) {
                dlpFindings.forEach(f => {
                    allIssues.push({
                        id: f.id || 'DLP-' + Math.random().toString(36).substr(2,6),
                        type: 'DLP',
                        severity: f.severity || 'MEDIUM',
                        is_reachable: true, // DLP findings have data flow paths by definition
                        reachability_state: 'reachable',"""

    new_dlp_merge = """            // v4.6.0: Merge DLP/PII findings into allIssues for Security Issues table
            const dlpFindings = d.dlp_findings || [];
            if (dlpFindings.length > 0) {
                dlpFindings.forEach(f => {
                    // v4.6.7: Respect sink_type for conservative reachability marking
                    let reachState, isReachable;

                    if (f.sink_type && f.sink_type !== 'unknown') {
                        // Known sink → definitely reachable
                        reachState = 'reachable';
                        isReachable = true;
                    } else {
                        // Unknown/missing sink → conservative UNKNOWN
                        reachState = 'unknown';
                        isReachable = null;
                    }

                    allIssues.push({
                        id: f.id || 'DLP-' + Math.random().toString(36).substr(2,6),
                        type: 'DLP',
                        severity: f.severity || 'MEDIUM',
                        is_reachable: isReachable,
                        reachability_state: reachState,"""

    js_content = js_content.replace(old_dlp_merge, new_dlp_merge)
    print("  ✅ Fix 1: DLP reachability (respect sink_type)")

    # Fix 2: DLP Funnel Display
    old_dlp_funnel = """            // DLP findings are all reachable by definition (they have a data flow path)
            const reachDlp = rawDlp;
            setEl('reachDlp', fmt(reachDlp));
            setEl('reachDlpPct', '(data flows)');"""

    new_dlp_funnel = """            // v4.6.7: DLP reachability (reachable + unknown, conservative)
            const dlpReachable = (d.dlp_findings || []).filter(f =>
                f.sink_type && f.sink_type !== 'unknown'
            ).length;

            const dlpUnknown = (d.dlp_findings || []).filter(f =>
                !f.sink_type || f.sink_type === 'unknown'
            ).length;

            const reachDlp = dlpReachable + dlpUnknown;  // Both actionable

            setEl('reachDlp', fmt(reachDlp));
            setEl('reachDlpPct', dlpUnknown > 0
                ? `(${dlpReachable}✅ + ${dlpUnknown}❓)`
                : '(data flows)');"""

    js_content = js_content.replace(old_dlp_funnel, new_dlp_funnel)
    print("  ✅ Fix 2: DLP funnel display with breakdown")

    # Fix 3: buildBreakdown signature
    old_breakdown_sig = "function buildBreakdown(cves, secrets, cwes, malware, ai = 0) {"
    new_breakdown_sig = "function buildBreakdown(cves, secrets, cwes, malware, ai = 0, dlp = 0) {"
    js_content = js_content.replace(old_breakdown_sig, new_breakdown_sig)
    print("  ✅ Fix 3: buildBreakdown signature (add DLP param)")

    # Fix 4: buildBreakdown body - add DLP line
    old_breakdown_body = """                if (ai > 0) parts.push(`🤖 ${ai} AI`);
                // v4.5.27: ALWAYS show breakdown (even for single signal type)
                return parts.join(' · ');"""

    new_breakdown_body = """                if (ai > 0) parts.push(`🤖 ${ai} AI`);
                if (dlp > 0) parts.push(`🔒 ${dlp} DLP`);
                // v4.5.27: ALWAYS show breakdown (even for single signal type)
                return parts.join(' · ');"""

    js_content = js_content.replace(old_breakdown_body, new_breakdown_body)
    print("  ✅ Fix 4: buildBreakdown body (add DLP display)")

    # Fix 5: Add criticalDlp calculation
    old_critical_ai = """            const criticalAi = actionable.filter(f => f.type === 'AI' && normalizeSeverity(f.severity) === 'CRITICAL').length;

            // Breakdown by type for HIGH (from actionable) - v4.5.40: Added AI"""

    new_critical_ai = """            const criticalAi = actionable.filter(f => f.type === 'AI' && normalizeSeverity(f.severity) === 'CRITICAL').length;
            const criticalDlp = actionable.filter(f => f.type === 'DLP' && normalizeSeverity(f.severity) === 'CRITICAL').length;

            // Breakdown by type for HIGH (from actionable) - v4.5.40: Added AI"""

    js_content = js_content.replace(old_critical_ai, new_critical_ai)
    print("  ✅ Fix 5: Add criticalDlp calculation")

    # Fix 6: Update buildBreakdown calls
    old_breakdown_call = "buildBreakdown(criticalCves, criticalSecrets, criticalCwes, criticalMalware, criticalAi)"
    new_breakdown_call = (
        "buildBreakdown(criticalCves, criticalSecrets, criticalCwes, criticalMalware, criticalAi, criticalDlp)"
    )
    js_content = js_content.replace(old_breakdown_call, new_breakdown_call)

    old_breakdown_call2 = "buildBreakdown(highCves, highSecrets, highCwes, highMalware, highAi)"
    new_breakdown_call2 = "buildBreakdown(highCves, highSecrets, highCwes, highMalware, highAi, 0)"
    js_content = js_content.replace(old_breakdown_call2, new_breakdown_call2)

    # Also fix the review breakdown
    old_review_breakdown = "buildBreakdown(unknownCves, unknownSecrets, unknownCwes, unknownMalware, unknownAi)"
    new_review_breakdown = "buildBreakdown(unknownCves, unknownSecrets, unknownCwes, unknownMalware, unknownAi, 0)"
    js_content = js_content.replace(old_review_breakdown, new_review_breakdown)

    print("  ✅ Fix 6: Update buildBreakdown calls")

    # Fix 7: Add fixStatusFilter event listener
    old_listeners = """        document.getElementById('complianceFilter').addEventListener('change', applyFilters);
        document.getElementById('exportBtn').addEventListener('click', exportCSV);"""

    new_listeners = """        document.getElementById('complianceFilter').addEventListener('change', applyFilters);
        document.getElementById('fixStatusFilter').addEventListener('change', applyFilters);
        document.getElementById('exportBtn').addEventListener('click', exportCSV);"""

    js_content = js_content.replace(old_listeners, new_listeners)
    print("  ✅ Fix 7: Add fixStatusFilter event listener")

    # Fix 8: Add fix status filter logic in applyFilters
    old_filter_logic = """                // Reachability filter
                const reachState = getReachabilityState(f);
                if (reachF === 'reachable' && reachState !== 'reachable') return false;
                if (reachF === 'not_reachable' && reachState !== 'not_reachable') return false;
                if (reachF === 'unknown' && reachState !== 'unknown') return false;

                // v4.4.5: Fixed compliance filter with proper matching"""

    new_filter_logic = """                // Reachability filter
                const reachState = getReachabilityState(f);
                if (reachF === 'reachable' && reachState !== 'reachable') return false;
                if (reachF === 'not_reachable' && reachState !== 'not_reachable') return false;
                if (reachF === 'unknown' && reachState !== 'unknown') return false;

                // Fix status filter
                if (fixF) {
                    const hasFixAvailable = f.fix_available === true || f.fix_status === 'fix_available';
                    const hasNoFix = f.fix_status === 'not-fixed' || f.fix_available === false;
                    if (fixF === 'fix_available' && !hasFixAvailable) return false;
                    if (fixF === 'no_fix' && !hasNoFix) return false;
                }

                // v4.4.5: Fixed compliance filter with proper matching"""

    js_content = js_content.replace(old_filter_logic, new_filter_logic)
    print("  ✅ Fix 8: Add fix status filter logic")

    # Fix 9: SLA logic for CVE fix status
    old_sla = """                // SLA - v4.4.6: just suggested time, no countdown
                const slaInfo = isReachable ? getSlaInfo(severity) : { display: '-', class: '' };
                const slaTag = slaInfo.class ? `<span class="sla-tag ${slaInfo.class}">${slaInfo.display}</span>` : '-';"""

    new_sla = """                // SLA - v4.6.7: Show for reachable, check CVE fix status
                let slaInfo = { display: '-', class: '' };

                if (isReachable) {
                    // CVEs: Check if fixable
                    if (f.type === 'CVE') {
                        const isFixable = f.fix_available === true || f.fix_status === 'fix_available' ||
                                         (f.remediation && f.remediation.fixed_in);

                        if (isFixable) {
                            slaInfo = getSlaInfo(severity);
                        } else {
                            // Unfixable CVE: no SLA timeline
                            slaInfo = { display: 'NO FIX', class: 'sla-none' };
                        }
                    }
                    // All other types: always show SLA
                    else {
                        slaInfo = getSlaInfo(severity);
                    }
                }

                const slaTag = slaInfo.class ? `<span class="sla-tag ${slaInfo.class}">${slaInfo.display}</span>` : '-';"""

    js_content = js_content.replace(old_sla, new_sla)
    print("  ✅ Fix 9: SLA logic for CVE fix status")

    # Write main.js
    print("\n💾 Writing main.js...")
    with open(main_js, "w") as f:
        f.write(js_content)

    # Now fix HTML
    print("\n🔧 Applying fixes to dashboard-body.html...")

    # Fix 10: Remove INFO from severity filter
    html_content = html_content.replace('<option value="INFO">INFO</option>\n', "")
    print("  ✅ Fix 10: Remove INFO from severity filter")

    # Fix 11: Fix Risk filter labels
    html_content = html_content.replace(">Critical Risk<", ">Critical<")
    html_content = html_content.replace(">High Risk<", ">High<")
    html_content = html_content.replace(">Medium Risk<", ">Medium<")
    html_content = html_content.replace(">Low Risk<", ">Low<")
    print("  ✅ Fix 11: Fix Risk filter labels")

    # Fix 12: Change IaC to Config
    html_content = html_content.replace('<option value="IAC">IaC</option>', '<option value="CONFIG">Config</option>')
    print("  ✅ Fix 12: Change IaC to Config")

    # Fix 13: Add Fix Status Filter
    old_reachability_filter = """                <div class="filter-group">
                    <label for="reachableFilter">Reachability:</label>
                    <select id="reachableFilter" class="filter-select">
                        <option value="">All</option>
                        <option value="reachable">Reachable</option>
                        <option value="not_reachable">Not Reachable</option>
                        <option value="unknown">Unknown</option>
                    </select>
                </div>
                <div class="filter-group">
                    <label for="complianceFilter">Compliance:</label>"""

    new_reachability_filter = """                <div class="filter-group">
                    <label for="reachableFilter">Reachability:</label>
                    <select id="reachableFilter" class="filter-select">
                        <option value="">All</option>
                        <option value="reachable">Reachable</option>
                        <option value="not_reachable">Not Reachable</option>
                        <option value="unknown">Unknown</option>
                    </select>
                </div>
                <div class="filter-group">
                    <label for="fixStatusFilter">Fix Status:</label>
                    <select id="fixStatusFilter" class="filter-select">
                        <option value="">All</option>
                        <option value="fix_available">Fix Available</option>
                        <option value="no_fix">No Fix</option>
                    </select>
                </div>
                <div class="filter-group">
                    <label for="complianceFilter">Compliance:</label>"""

    html_content = html_content.replace(old_reachability_filter, new_reachability_filter)
    print("  ✅ Fix 13: Add Fix Status Filter")

    # Write HTML
    print("\n💾 Writing dashboard-body.html...")
    with open(html_file, "w") as f:
        f.write(html_content)

    print("\n✅ All 13 fixes applied successfully!")
    print("\n📋 Next steps:")
    print("1. cd ~/src/reach-core/reachable/dashboard_v2")
    print("2. ./rebuild-template.sh")
    print("3. Run a new scan: reachable scan reach-testbed")
    print("4. Open the dashboard and verify fixes")

    return True


if __name__ == "__main__":
    try:
        success = apply_fixes()
        sys.exit(0 if success else 1)
    except Exception as e:
        print(f"❌ Error: {e}")
        import traceback

        traceback.print_exc()
        sys.exit(1)
