#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.

"""
REACHABLE AI Rules Version Tracking

Tracks upstream versions of rule sources (Garak, Corpus datasets) and detects
when our bundled rules are out of sync.

Usage:
    # Check sync status
    python scripts/ai_rules/version_tracker.py --check

    # Update all rules
    python scripts/ai_rules/version_tracker.py --update

    # Show current versions
    python scripts/ai_rules/version_tracker.py --status

The version manifest is stored at:
    reachable/ai/detectors/semgrep/VERSION_MANIFEST.yaml
"""

import argparse
import json
import subprocess
import sys
import urllib.request
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional

SCRIPT_DIR = Path(__file__).parent
REPO_ROOT = SCRIPT_DIR.parent.parent
DETECTORS_DIR = REPO_ROOT / "reachable" / "ai" / "detectors" / "semgrep"
MANIFEST_FILE = DETECTORS_DIR / "VERSION_MANIFEST.yaml"


@dataclass
class RuleSource:
    """Metadata about a rule source."""

    name: str
    source_type: str  # git, pypi, github-release, dataset
    url: str
    current_version: str
    current_commit: str
    last_synced: str
    rule_count: int
    upstream_version: Optional[str] = None
    upstream_commit: Optional[str] = None
    is_outdated: bool = False


# ════════════════════════════════════════════════════════════════════════════════
# UPSTREAM VERSION CHECKERS
# ════════════════════════════════════════════════════════════════════════════════


def get_github_latest_commit(owner: str, repo: str, branch: str = "main") -> Optional[str]:
    """Get latest commit SHA from GitHub."""
    try:
        url = f"https://api.github.com/repos/{owner}/{repo}/commits/{branch}"
        req = urllib.request.Request(url, headers={"User-Agent": "REACHABLE-VersionTracker"})
        with urllib.request.urlopen(req, timeout=10) as resp:
            data = json.loads(resp.read().decode())
            return data.get("sha", "")[:12]
    except Exception as e:
        print(f"  Warning: Could not fetch GitHub commit for {owner}/{repo}: {e}")
        return None


def get_github_latest_release(owner: str, repo: str) -> Optional[str]:
    """Get latest release tag from GitHub."""
    try:
        url = f"https://api.github.com/repos/{owner}/{repo}/releases/latest"
        req = urllib.request.Request(url, headers={"User-Agent": "REACHABLE-VersionTracker"})
        with urllib.request.urlopen(req, timeout=10) as resp:
            data = json.loads(resp.read().decode())
            return data.get("tag_name", "")
    except Exception as e:
        print(f"  Warning: Could not fetch GitHub release for {owner}/{repo}: {e}")
        return None


def get_pypi_latest_version(package: str) -> Optional[str]:
    """Get latest version from PyPI."""
    try:
        url = f"https://pypi.org/pypi/{package}/json"
        req = urllib.request.Request(url, headers={"User-Agent": "REACHABLE-VersionTracker"})
        with urllib.request.urlopen(req, timeout=10) as resp:
            data = json.loads(resp.read().decode())
            return data.get("info", {}).get("version", "")
    except Exception as e:
        print(f"  Warning: Could not fetch PyPI version for {package}: {e}")
        return None


# ════════════════════════════════════════════════════════════════════════════════
# RULE SOURCES CONFIGURATION
# ════════════════════════════════════════════════════════════════════════════════

RULE_SOURCES = {
    "garak": {
        "name": "NVIDIA Garak",
        "source_type": "git",
        "url": "https://github.com/NVIDIA/garak",
        "owner": "NVIDIA",
        "repo": "garak",
        "branch": "main",
        "check_method": "github_commit",
        "extraction_script": "garak_to_semgrep.py",
        "output_dir": "garak_derived",
    },
    "tensortrust": {
        "name": "Tensor Trust Dataset",
        "source_type": "github-release",
        "url": "https://github.com/HumanCompatibleAI/tensor-trust-data",
        "owner": "HumanCompatibleAI",
        "repo": "tensor-trust-data",
        "check_method": "github_release",
        "extraction_script": "corpus_to_semgrep.py",
        "output_dir": "corpus_derived",
    },
    "jailbreakbench": {
        "name": "JailbreakBench",
        "source_type": "pypi",
        "url": "https://pypi.org/project/jailbreakbench/",
        "package": "jailbreakbench",
        "check_method": "pypi",
        "extraction_script": "corpus_to_semgrep.py",
        "output_dir": "corpus_derived",
    },
    "promptinject": {
        "name": "PromptInject Dataset",
        "source_type": "git",
        "url": "https://github.com/agencyenterprise/PromptInject",
        "owner": "agencyenterprise",
        "repo": "PromptInject",
        "branch": "main",
        "check_method": "github_commit",
        "extraction_script": "corpus_to_semgrep.py",
        "output_dir": "corpus_derived",
    },
}


# ════════════════════════════════════════════════════════════════════════════════
# MANIFEST OPERATIONS
# ════════════════════════════════════════════════════════════════════════════════


def load_manifest() -> Dict:
    """Load the version manifest."""
    if not MANIFEST_FILE.exists():
        return {"version": "1.0", "sources": {}, "last_check": None}

    import yaml

    with open(MANIFEST_FILE) as f:
        return yaml.safe_load(f) or {"version": "1.0", "sources": {}, "last_check": None}


def save_manifest(manifest: Dict):
    """Save the version manifest."""
    import yaml

    DETECTORS_DIR.mkdir(parents=True, exist_ok=True)

    manifest["last_check"] = datetime.now().isoformat()

    with open(MANIFEST_FILE, "w") as f:
        yaml.dump(manifest, f, default_flow_style=False, sort_keys=False)


def count_rules_in_dir(dir_path: Path) -> int:
    """Count rules in a directory."""
    count = 0
    for yaml_file in dir_path.glob("*.yaml"):
        try:
            import yaml

            with open(yaml_file) as f:
                data = yaml.safe_load(f)
                if data and "rules" in data:
                    count += len(data["rules"])
        except:
            pass
    return count


# ════════════════════════════════════════════════════════════════════════════════
# COMMANDS
# ════════════════════════════════════════════════════════════════════════════════


def check_sync_status() -> List[RuleSource]:
    """Check if bundled rules are in sync with upstream."""
    print("Checking upstream versions...")
    print("=" * 60)

    manifest = load_manifest()
    results = []

    for source_id, config in RULE_SOURCES.items():
        print(f"\n{config['name']}:")

        # Get current (bundled) version
        current = manifest.get("sources", {}).get(source_id, {})
        current_version = current.get("version", "not synced")
        current_commit = current.get("commit", "")
        last_synced = current.get("last_synced", "never")

        # Get upstream version
        upstream_version = None
        upstream_commit = None

        if config["check_method"] == "github_commit":
            upstream_commit = get_github_latest_commit(config["owner"], config["repo"], config.get("branch", "main"))
            upstream_version = upstream_commit
        elif config["check_method"] == "github_release":
            upstream_version = get_github_latest_release(config["owner"], config["repo"])
        elif config["check_method"] == "pypi":
            upstream_version = get_pypi_latest_version(config["package"])

        # Determine if outdated
        is_outdated = False
        if upstream_version and current_version != "not synced":
            if config["check_method"] == "github_commit":
                is_outdated = current_commit != upstream_commit
            else:
                is_outdated = current_version != upstream_version

        # Count rules
        output_dir = DETECTORS_DIR / config["output_dir"]
        rule_count = count_rules_in_dir(output_dir) if output_dir.exists() else 0

        source = RuleSource(
            name=config["name"],
            source_type=config["source_type"],
            url=config["url"],
            current_version=current_version,
            current_commit=current_commit,
            last_synced=last_synced,
            rule_count=rule_count,
            upstream_version=upstream_version,
            upstream_commit=upstream_commit,
            is_outdated=is_outdated,
        )
        results.append(source)

        # Display status
        status = "⚠️  OUTDATED" if is_outdated else "✅ IN SYNC" if current_version != "not synced" else "❌ NOT SYNCED"
        print(f"  Status:    {status}")
        print(f"  Bundled:   {current_version} ({rule_count} rules)")
        print(f"  Upstream:  {upstream_version or 'unknown'}")
        print(f"  Last Sync: {last_synced}")

    # Save check timestamp
    save_manifest(manifest)

    return results


def update_all_rules():
    """Run all extraction scripts and update manifest."""
    print("Updating all rule sources...")
    print("=" * 60)

    manifest = load_manifest()
    if "sources" not in manifest:
        manifest["sources"] = {}

    # Group by extraction script
    scripts = {}
    for source_id, config in RULE_SOURCES.items():
        script = config["extraction_script"]
        if script not in scripts:
            scripts[script] = []
        scripts[script].append((source_id, config))

    # Run each extraction script
    for script_name, sources in scripts.items():
        script_path = SCRIPT_DIR / script_name

        if not script_path.exists():
            print(f"\n⚠️  Script not found: {script_name}")
            continue

        print(f"\nRunning {script_name}...")

        try:
            result = subprocess.run(
                [sys.executable, str(script_path), "--download"], capture_output=True, text=True, timeout=300
            )

            if result.returncode == 0:
                print("  ✅ Success")

                # Update manifest for each source this script handles
                for source_id, config in sources:
                    # Get version info
                    if config["check_method"] == "github_commit":
                        version = get_github_latest_commit(
                            config["owner"], config["repo"], config.get("branch", "main")
                        )
                        commit = version
                    elif config["check_method"] == "github_release":
                        version = get_github_latest_release(config["owner"], config["repo"])
                        commit = ""
                    elif config["check_method"] == "pypi":
                        version = get_pypi_latest_version(config["package"])
                        commit = ""
                    else:
                        version = "unknown"
                        commit = ""

                    output_dir = DETECTORS_DIR / config["output_dir"]
                    rule_count = count_rules_in_dir(output_dir)

                    manifest["sources"][source_id] = {
                        "version": version,
                        "commit": commit,
                        "last_synced": datetime.now().isoformat(),
                        "rule_count": rule_count,
                    }
            else:
                print(f"  ❌ Failed: {result.stderr[:200]}")

        except subprocess.TimeoutExpired:
            print("  ❌ Timeout")
        except Exception as e:
            print(f"  ❌ Error: {e}")

    # Save updated manifest
    save_manifest(manifest)

    print("\n" + "=" * 60)
    print("Update complete. Run --check to verify sync status.")


def show_status():
    """Show current version status."""
    manifest = load_manifest()

    print("REACHABLE AI Rules - Version Status")
    print("=" * 60)
    print(f"Last check: {manifest.get('last_check', 'never')}")
    print()

    sources = manifest.get("sources", {})

    if not sources:
        print("No rules synced yet. Run --update to sync.")
        return

    for source_id, config in RULE_SOURCES.items():
        source_data = sources.get(source_id, {})

        print(f"{config['name']}:")
        print(f"  Version:    {source_data.get('version', 'not synced')}")
        print(f"  Rules:      {source_data.get('rule_count', 0)}")
        print(f"  Last Sync:  {source_data.get('last_synced', 'never')}")
        print(f"  Output:     {config['output_dir']}/")
        print()


def generate_changelog(old_manifest: Dict, new_manifest: Dict) -> str:
    """Generate changelog for rule updates."""
    lines = []
    lines.append(f"## AI Rules Update - {datetime.now().strftime('%Y-%m-%d')}")
    lines.append("")

    for source_id, config in RULE_SOURCES.items():
        old = old_manifest.get("sources", {}).get(source_id, {})
        new = new_manifest.get("sources", {}).get(source_id, {})

        old_version = old.get("version", "none")
        new_version = new.get("version", "none")
        old_count = old.get("rule_count", 0)
        new_count = new.get("rule_count", 0)

        if old_version != new_version or old_count != new_count:
            lines.append(f"### {config['name']}")
            lines.append(f"- Version: {old_version} → {new_version}")
            lines.append(f"- Rules: {old_count} → {new_count} ({new_count - old_count:+d})")
            lines.append("")

    return "\n".join(lines)


# ════════════════════════════════════════════════════════════════════════════════
# MAIN
# ════════════════════════════════════════════════════════════════════════════════


def main():
    parser = argparse.ArgumentParser(description="Track and sync AI rule source versions")
    parser.add_argument("--check", action="store_true", help="Check if rules are in sync with upstream")
    parser.add_argument("--update", action="store_true", help="Update all rules from upstream")
    parser.add_argument("--status", action="store_true", help="Show current version status")
    parser.add_argument("--json", action="store_true", help="Output as JSON")

    args = parser.parse_args()

    if args.check:
        results = check_sync_status()

        # Summary
        outdated = [r for r in results if r.is_outdated]
        not_synced = [r for r in results if r.current_version == "not synced"]

        print("\n" + "=" * 60)
        if outdated:
            print(f"⚠️  {len(outdated)} source(s) OUTDATED - run --update")
            for r in outdated:
                print(f"   - {r.name}")
        elif not_synced:
            print(f"❌ {len(not_synced)} source(s) NOT SYNCED - run --update")
        else:
            print("✅ All rules in sync with upstream")

        # Return non-zero if outdated (for CI)
        if outdated or not_synced:
            sys.exit(1)

    elif args.update:
        update_all_rules()

    elif args.status:
        show_status()

    else:
        parser.print_help()


if __name__ == "__main__":
    main()
