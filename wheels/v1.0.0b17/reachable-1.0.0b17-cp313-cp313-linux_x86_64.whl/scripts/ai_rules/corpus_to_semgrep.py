#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.

"""
REACHABLE P6.14: Corpus Rule Extraction
=======================================
Extracts prompt injection patterns from research datasets and converts to Semgrep rules.

Supported Datasets:
- Tensor Trust (HumanCompatibleAI) - Prompt injection attacks from game
- JailbreakBench - Curated jailbreak prompts
- PromptInject - Academic prompt injection dataset

Rule ID Format: corpus-{dataset}-{number}
Examples:
  - corpus-tensortrust-001
  - corpus-jailbreakbench-005
  - corpus-promptinject-003

Policy Mapping (from RISK_SCORING_MODEL.md):
  - corpus-*-* → AI-001 (Prompt Injection) → LLM01 (default)
  - Specific patterns may map to AI-003 (Sensitive Disclosure) → LLM02

Usage:
    # Download datasets and extract rules
    python scripts/ai_rules/corpus_to_semgrep.py --download

    # Use existing dataset directory
    python scripts/ai_rules/corpus_to_semgrep.py --corpus-path /path/to/datasets

Output:
    reachable/ai/detectors/semgrep/corpus_derived/corpus-rules.yaml
    reachable/ai/detectors/semgrep/corpus_derived/MANIFEST.yaml

Copyright (c) 2026 Sthenos Security. All rights reserved.
"""

import argparse
import json
import re
import sys
import urllib.request
import zipfile
from collections import defaultdict
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Set

# ════════════════════════════════════════════════════════════════════════════════
# CONFIGURATION
# ════════════════════════════════════════════════════════════════════════════════

SCRIPT_DIR = Path(__file__).parent
REPO_ROOT = SCRIPT_DIR.parent.parent
OUTPUT_DIR = REPO_ROOT / "reachable" / "ai" / "detectors" / "semgrep" / "corpus_derived"
CACHE_DIR = Path("/tmp/reachable-corpus-cache")

# Dataset configurations
DATASETS = {
    "tensortrust": {
        "name": "Tensor Trust",
        "url": "https://github.com/HumanCompatibleAI/tensor-trust-data/archive/refs/heads/main.zip",
        "type": "zip",
        "data_path": "tensor-trust-data-main/data/",
        "file_pattern": "*.jsonl",
        "policy_id": "AI-001",
        "owasp_llm": "LLM01",
        "cwe": "CWE-77",
        "description": "Prompt injection from Tensor Trust game",
    },
    "jailbreakbench": {
        "name": "JailbreakBench",
        "url": "https://raw.githubusercontent.com/JailbreakBench/artifacts/main/jailbreak_artifacts.json",
        "type": "json",
        "policy_id": "AI-001",
        "owasp_llm": "LLM01",
        "cwe": "CWE-77",
        "description": "Curated jailbreak prompts from JailbreakBench",
    },
    "promptinject": {
        "name": "PromptInject",
        "url": "https://github.com/agencyenterprise/PromptInject/archive/refs/heads/main.zip",
        "type": "zip",
        "data_path": "PromptInject-main/data/",
        "file_pattern": "*.json",
        "policy_id": "AI-001",
        "owasp_llm": "LLM01",
        "cwe": "CWE-77",
        "description": "Academic prompt injection dataset",
    },
}

# Attack pattern keywords for filtering
ATTACK_KEYWORDS = [
    "ignore",
    "disregard",
    "forget",
    "pretend",
    "roleplay",
    "jailbreak",
    "bypass",
    "override",
    "you are now",
    "act as",
    "new instructions",
    "system:",
    "developer mode",
    "DAN",
    "do anything",
    "no restrictions",
    "unlimited",
    "uncensored",
    "ignore previous",
    "forget everything",
    "you must",
    "always respond",
    "ignore all",
    "discard",
    "stop being",
    "from now on",
    "entering",
    "mode",
    "enable",
    "activate",
    "unlock",
]

MIN_PATTERN_LENGTH = 15
MAX_PATTERN_LENGTH = 300
MAX_PATTERNS_PER_DATASET = 50


# ════════════════════════════════════════════════════════════════════════════════
# DATA CLASSES
# ════════════════════════════════════════════════════════════════════════════════


@dataclass
class ExtractedPattern:
    """A pattern extracted from a corpus dataset."""

    text: str
    dataset: str
    source_file: str
    attack_type: str = "prompt_injection"
    success_rate: float = 0.0  # If available


@dataclass
class GeneratedRule:
    """A Semgrep rule generated from extracted patterns."""

    rule_id: str
    dataset: str
    pattern_regex: str
    policy_id: str
    owasp_llm: str
    cwe: str
    description: str
    severity: str
    source_patterns: List[str] = field(default_factory=list)


# ════════════════════════════════════════════════════════════════════════════════
# DATASET DOWNLOADERS
# ════════════════════════════════════════════════════════════════════════════════


def download_file(url: str, dest: Path) -> bool:
    """Download a file from URL."""
    try:
        print(f"  Downloading: {url[:60]}...")
        req = urllib.request.Request(url, headers={"User-Agent": "REACHABLE-CorpusExtractor"})
        with urllib.request.urlopen(req, timeout=60) as resp:
            dest.parent.mkdir(parents=True, exist_ok=True)
            with open(dest, "wb") as f:
                f.write(resp.read())
        return True
    except Exception as e:
        print(f"  ❌ Download failed: {e}")
        return False


def download_dataset(dataset_id: str, config: dict, cache_dir: Path) -> Optional[Path]:
    """Download and extract a dataset."""
    dataset_dir = cache_dir / dataset_id

    if config["type"] == "zip":
        zip_path = cache_dir / f"{dataset_id}.zip"

        if not zip_path.exists():
            if not download_file(config["url"], zip_path):
                return None

        # Extract
        if not dataset_dir.exists():
            print(f"  Extracting {dataset_id}...")
            with zipfile.ZipFile(zip_path, "r") as z:
                z.extractall(cache_dir)

        # Return data path
        data_path = cache_dir / config.get("data_path", "")
        return data_path if data_path.exists() else dataset_dir

    elif config["type"] == "json":
        json_path = dataset_dir / "data.json"

        if not json_path.exists():
            dataset_dir.mkdir(parents=True, exist_ok=True)
            if not download_file(config["url"], json_path):
                return None

        return dataset_dir

    return None


# ════════════════════════════════════════════════════════════════════════════════
# PATTERN EXTRACTORS
# ════════════════════════════════════════════════════════════════════════════════


class CorpusExtractor:
    """Extracts attack patterns from corpus datasets."""

    def __init__(self, cache_dir: Path):
        self.cache_dir = cache_dir
        self.patterns: Dict[str, List[ExtractedPattern]] = defaultdict(list)
        self.seen_patterns: Set[str] = set()
        self.stats = {"datasets_processed": 0, "patterns_extracted": 0}

    def extract_all(self, download: bool = True) -> Dict[str, List[ExtractedPattern]]:
        """Extract patterns from all configured datasets."""
        print("Extracting patterns from corpus datasets...")

        for dataset_id, config in DATASETS.items():
            print(f"\n[{config['name']}]")

            # Download if needed
            if download:
                data_path = download_dataset(dataset_id, config, self.cache_dir)
                if not data_path:
                    print(f"  ⚠️ Could not download {dataset_id}")
                    continue
            else:
                data_path = self.cache_dir / dataset_id
                if not data_path.exists():
                    print(f"  ⚠️ Dataset not found: {data_path}")
                    continue

            # Extract based on dataset type
            if dataset_id == "tensortrust":
                self._extract_tensortrust(data_path, dataset_id)
            elif dataset_id == "jailbreakbench":
                self._extract_jailbreakbench(data_path, dataset_id)
            elif dataset_id == "promptinject":
                self._extract_promptinject(data_path, dataset_id)

            self.stats["datasets_processed"] += 1

        print(f"\n  Processed {self.stats['datasets_processed']} datasets")
        print(f"  Extracted {self.stats['patterns_extracted']} unique patterns")

        return dict(self.patterns)

    def _extract_tensortrust(self, data_path: Path, dataset_id: str):
        """Extract from Tensor Trust JSONL files."""
        patterns_found = 0

        for jsonl_file in data_path.rglob("*.jsonl"):
            try:
                with open(jsonl_file, "r", encoding="utf-8", errors="ignore") as f:
                    for line in f:
                        try:
                            item = json.loads(line)
                            # Tensor Trust has 'attack' field with prompt injection attempts
                            attack_text = item.get("attack", "") or item.get("prompt", "")

                            if self._is_valid_pattern(attack_text):
                                pattern = ExtractedPattern(
                                    text=attack_text,
                                    dataset=dataset_id,
                                    source_file=str(jsonl_file.name),
                                    attack_type="prompt_injection",
                                    success_rate=item.get("success_rate", 0.0),
                                )
                                if self._add_pattern(dataset_id, pattern):
                                    patterns_found += 1

                            if patterns_found >= MAX_PATTERNS_PER_DATASET:
                                break
                        except json.JSONDecodeError:
                            continue
            except Exception as e:
                print(f"  Warning: Error reading {jsonl_file}: {e}")

        print(f"  ✓ Extracted {patterns_found} patterns from Tensor Trust")

    def _extract_jailbreakbench(self, data_path: Path, dataset_id: str):
        """Extract from JailbreakBench JSON."""
        patterns_found = 0
        json_file = data_path / "data.json"

        if not json_file.exists():
            print("  ⚠️ JailbreakBench data not found")
            return

        try:
            with open(json_file, "r", encoding="utf-8") as f:
                data = json.load(f)

            # JailbreakBench structure varies, handle common formats
            prompts = []

            if isinstance(data, list):
                prompts = data
            elif isinstance(data, dict):
                # Try common keys
                for key in ["jailbreaks", "prompts", "attacks", "data"]:
                    if key in data:
                        prompts = data[key]
                        break

            for item in prompts:
                if isinstance(item, str):
                    text = item
                elif isinstance(item, dict):
                    text = item.get("prompt", "") or item.get("jailbreak", "") or item.get("text", "")
                else:
                    continue

                if self._is_valid_pattern(text):
                    pattern = ExtractedPattern(
                        text=text,
                        dataset=dataset_id,
                        source_file="jailbreak_artifacts.json",
                        attack_type="jailbreak",
                    )
                    if self._add_pattern(dataset_id, pattern):
                        patterns_found += 1

                if patterns_found >= MAX_PATTERNS_PER_DATASET:
                    break

        except Exception as e:
            print(f"  Warning: Error reading JailbreakBench: {e}")

        print(f"  ✓ Extracted {patterns_found} patterns from JailbreakBench")

    def _extract_promptinject(self, data_path: Path, dataset_id: str):
        """Extract from PromptInject JSON files."""
        patterns_found = 0

        for json_file in data_path.rglob("*.json"):
            try:
                with open(json_file, "r", encoding="utf-8", errors="ignore") as f:
                    data = json.load(f)

                # Handle both list and dict formats
                items = data if isinstance(data, list) else [data]

                for item in items:
                    if isinstance(item, dict):
                        text = item.get("prompt", "") or item.get("injection", "") or item.get("payload", "")
                    elif isinstance(item, str):
                        text = item
                    else:
                        continue

                    if self._is_valid_pattern(text):
                        pattern = ExtractedPattern(
                            text=text,
                            dataset=dataset_id,
                            source_file=str(json_file.name),
                            attack_type="prompt_injection",
                        )
                        if self._add_pattern(dataset_id, pattern):
                            patterns_found += 1

                    if patterns_found >= MAX_PATTERNS_PER_DATASET:
                        break

            except Exception:
                continue

        print(f"  ✓ Extracted {patterns_found} patterns from PromptInject")

    def _is_valid_pattern(self, text: str) -> bool:
        """Check if text is a valid attack pattern."""
        if not text or not isinstance(text, str):
            return False

        text = text.strip()

        if len(text) < MIN_PATTERN_LENGTH:
            return False
        if len(text) > MAX_PATTERN_LENGTH:
            return False

        # Must contain attack keywords
        text_lower = text.lower()
        return any(kw in text_lower for kw in ATTACK_KEYWORDS)

    def _add_pattern(self, dataset_id: str, pattern: ExtractedPattern) -> bool:
        """Add pattern if not duplicate."""
        # Use first 50 chars as hash to avoid near-duplicates
        pattern_hash = pattern.text.lower()[:50]

        if pattern_hash in self.seen_patterns:
            return False

        self.seen_patterns.add(pattern_hash)
        self.patterns[dataset_id].append(pattern)
        self.stats["patterns_extracted"] += 1
        return True


# ════════════════════════════════════════════════════════════════════════════════
# RULE GENERATION
# ════════════════════════════════════════════════════════════════════════════════


class RuleGenerator:
    """Generates Semgrep rules from extracted patterns."""

    def __init__(self):
        self.rules: List[GeneratedRule] = []

    def generate_rules(self, patterns: Dict[str, List[ExtractedPattern]]) -> List[GeneratedRule]:
        """Generate Semgrep rules from extracted patterns."""

        for dataset_id, dataset_patterns in patterns.items():
            config = DATASETS.get(dataset_id, {})

            for i, pattern in enumerate(dataset_patterns):
                # Create regex from pattern
                regex = self._pattern_to_regex(pattern.text)
                if not regex:
                    continue

                rule = GeneratedRule(
                    rule_id=f"corpus-{dataset_id}-{i + 1:03d}",
                    dataset=dataset_id,
                    pattern_regex=regex,
                    policy_id=config.get("policy_id", "AI-001"),
                    owasp_llm=config.get("owasp_llm", "LLM01"),
                    cwe=config.get("cwe", "CWE-77"),
                    description=f"{config.get('description', 'Corpus pattern')}: {pattern.text[:40]}...",
                    severity="WARNING",
                    source_patterns=[pattern.text],
                )
                self.rules.append(rule)

        return self.rules

    def _pattern_to_regex(self, text: str) -> Optional[str]:
        """Convert a text pattern to a regex suitable for Semgrep."""
        # Extract key phrases (first 10 words)
        words = text.split()[:10]
        if len(words) < 3:
            return None

        shortened = " ".join(words)

        # Escape and make flexible
        escaped = re.escape(shortened)
        flexible = re.sub(r"\\ +", r"\\s+", escaped)

        # Case insensitive flag will be set in Semgrep options
        return flexible


# ════════════════════════════════════════════════════════════════════════════════
# OUTPUT GENERATION
# ════════════════════════════════════════════════════════════════════════════════


def write_semgrep_rules(rules: List[GeneratedRule], output_dir: Path):
    """Write rules to Semgrep YAML file."""
    output_dir.mkdir(parents=True, exist_ok=True)

    yaml_content = """# REACHABLE AI Security Module - Corpus-Derived Rules
# Generated from prompt injection research datasets
# Copyright (c) 2026 Sthenos Security. All rights reserved.
#
# Sources:
#   - Tensor Trust (HumanCompatibleAI)
#   - JailbreakBench
#   - PromptInject
#
# Generated: {timestamp}
#
# Policy Mapping:
#   - AI-001: Prompt Injection (Direct) → OWASP LLM01

rules:
""".format(timestamp=datetime.now().isoformat())

    for rule in rules:
        yaml_content += f"""
  - id: {rule.rule_id}
    languages: [python, javascript, typescript, go]
    message: "{rule.description}"
    severity: {rule.severity}
    pattern-regex: "{rule.pattern_regex}"
    options:
      case_sensitive: false
    metadata:
      policy_id: {rule.policy_id}
      owasp_llm: {rule.owasp_llm}
      cwe: {rule.cwe}
      source: corpus
      source_dataset: {rule.dataset}
      category: ai-security
      confidence: medium
"""

    output_file = output_dir / "corpus-rules.yaml"
    with open(output_file, "w") as f:
        f.write(yaml_content)

    print(f"\n✓ Wrote {len(rules)} rules to {output_file}")
    return output_file


def write_manifest(rules: List[GeneratedRule], output_dir: Path):
    """Write MANIFEST.yaml with rule→policy mappings."""

    # Count by dataset
    by_dataset = defaultdict(int)
    for rule in rules:
        by_dataset[rule.dataset] += 1

    dataset_yaml = "\n".join(f"    {k}: {v}" for k, v in sorted(by_dataset.items()))

    manifest_content = f"""# REACHABLE AI Security Module - Corpus Rules Manifest
# Maps rule IDs to security policies
#
# Generated: {datetime.now().isoformat()}

manifest_version: "1.0"
source: corpus
generated_at: "{datetime.now().isoformat()}"
generator: "scripts/ai_rules/corpus_to_semgrep.py"
generator_version: "1.0.0"

# Statistics
stats:
  total_rules: {len(rules)}
  by_dataset:
{dataset_yaml}

# Datasets
datasets:
"""

    for dataset_id, config in DATASETS.items():
        manifest_content += f"""  {dataset_id}:
    name: "{config["name"]}"
    url: "{config["url"]}"
    policy_id: {config["policy_id"]}
    owasp_llm: {config["owasp_llm"]}
"""

    manifest_content += "\n# Rule Mappings\nrules:\n"

    for rule in rules:
        manifest_content += f"""  - id: "{rule.rule_id}"
    policy_id: {rule.policy_id}
    owasp_llm: {rule.owasp_llm}
    cwe: {rule.cwe}
    source_dataset: {rule.dataset}
    description: "{rule.description[:80]}"
"""

    output_file = output_dir / "MANIFEST.yaml"
    with open(output_file, "w") as f:
        f.write(manifest_content)

    print(f"✓ Wrote manifest to {output_file}")
    return output_file


# ════════════════════════════════════════════════════════════════════════════════
# MAIN
# ════════════════════════════════════════════════════════════════════════════════


def main():
    parser = argparse.ArgumentParser(description="Extract prompt injection patterns from research datasets")
    parser.add_argument("--corpus-path", type=Path, help="Path to existing corpus datasets")
    parser.add_argument("--download", action="store_true", help="Download datasets to /tmp/reachable-corpus-cache")
    parser.add_argument("--output-dir", type=Path, default=OUTPUT_DIR, help="Output directory for rules")

    args = parser.parse_args()

    print("=" * 60)
    print("REACHABLE P6.14: Corpus Rule Extraction")
    print("=" * 60)

    # Set cache directory
    if args.corpus_path:
        cache_dir = args.corpus_path
    else:
        cache_dir = CACHE_DIR

    cache_dir.mkdir(parents=True, exist_ok=True)
    print(f"\nCache directory: {cache_dir}")

    # Extract patterns
    print("\n[1/3] Extracting patterns from datasets...")
    extractor = CorpusExtractor(cache_dir)
    patterns = extractor.extract_all(download=args.download)

    if not patterns:
        print("No patterns extracted!")
        sys.exit(1)

    # Generate rules
    print("\n[2/3] Generating Semgrep rules...")
    generator = RuleGenerator()
    rules = generator.generate_rules(patterns)
    print(f"  Generated {len(rules)} rules")

    # Write output
    print("\n[3/3] Writing output files...")
    write_semgrep_rules(rules, args.output_dir)
    write_manifest(rules, args.output_dir)

    print("\n" + "=" * 60)
    print("COMPLETE")
    print("=" * 60)
    print(f"\nOutput: {args.output_dir}")
    print("\nNext steps:")
    print("  1. Review generated rules for false positives")
    print("  2. Run: python scripts/ai_rules/version_tracker.py --check")
    print("  3. Run: reachctl scan <repo> --enable-ai --debug")


if __name__ == "__main__":
    main()
