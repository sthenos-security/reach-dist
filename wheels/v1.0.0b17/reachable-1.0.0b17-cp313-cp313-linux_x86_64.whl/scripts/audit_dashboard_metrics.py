#!/usr/bin/env python3
"""
Dashboard Metrics Comprehensive Audit
Validates ALL counts from database → data.json → dashboard
Automatically finds inconsistencies

Usage: python3 audit_dashboard_metrics.py <scan_dir>
Example: python3 audit_dashboard_metrics.py ~/.reachable/scans/reach-testbed-2943c74e
"""

import json
import sqlite3
import sys
from collections import defaultdict
from pathlib import Path


class MetricsAuditor:
    def __init__(self, scan_dir):
        self.scan_dir = Path(scan_dir).expanduser()
        self.db_path = self.scan_dir / "repo.db"
        self.data_json = self.scan_dir / "dashboard" / "data.json"
        self.errors = []
        self.warnings = []

    def audit(self):
        print("=" * 80)
        print("DASHBOARD METRICS AUDIT")
        print("=" * 80)
        print(f"Scan: {self.scan_dir}")
        print(f"Database: {self.db_path}")
        print(f"JSON: {self.data_json}\n")

        if not self.db_path.exists():
            print(f"❌ Database not found: {self.db_path}")
            return False

        if not self.data_json.exists():
            print(f"❌ data.json not found: {self.data_json}")
            return False

        db_metrics = self.load_db()
        json_data = self.load_json()

        self.audit_secrets(db_metrics, json_data)
        self.audit_dlp(db_metrics, json_data)
        self.audit_action_required(json_data)
        self.audit_trends(json_data)
        self.audit_signal_quality(json_data)

        return self.report()

    def load_db(self):
        conn = sqlite3.connect(str(self.db_path))
        cur = conn.cursor()

        m = {"by_type": defaultdict(int), "by_reach": defaultdict(lambda: defaultdict(int))}

        # Total by type
        cur.execute("SELECT finding_type, COUNT(*) FROM findings GROUP BY finding_type")
        for row in cur.fetchall():
            m["by_type"][row[0]] = row[1]

        # By type + reachability
        cur.execute("""
            SELECT finding_type, app_reachability, COUNT(*)
            FROM findings GROUP BY finding_type, app_reachability
        """)
        for ftype, reach, cnt in cur.fetchall():
            m["by_reach"][ftype][reach or "unknown"] = cnt

        conn.close()
        print(f"✅ DB loaded: {sum(m['by_type'].values())} total findings\n")
        return m

    def load_json(self):
        with open(self.data_json) as f:
            data = json.load(f)
        print("✅ JSON loaded\n")
        return data

    def audit_secrets(self, db, data):
        print("🔍 AUDIT 1: Secrets Left vs Right Funnel")
        print("-" * 80)

        db_total = db["by_type"].get("secret", 0)
        db_reach = db["by_reach"]["secret"].get("reachable", 0)
        db_unknown = db["by_reach"]["secret"].get("unknown", 0)
        db_combined = db_reach + db_unknown

        json_total = data.get("metrics", {}).get("secrets_total", 0)
        json_reach = data.get("metrics", {}).get("secrets_reachable", 0)

        print(f"  DB Total: {db_total}")
        print(f"  DB Reachable: {db_reach}")
        print(f"  DB Unknown: {db_unknown}")
        print(f"  LEFT funnel should show: {db_combined} (reachable + unknown)")
        print(f"  JSON secrets_total: {json_total}")
        print(f"  JSON secrets_reachable: {json_reach}")

        if json_total != db_combined:
            self.errors.append(
                f"❌ SECRETS LEFT FUNNEL WRONG: Shows {json_total}, should show {db_combined} "
                f"({db_reach} reachable + {db_unknown} unknown)"
            )
        else:
            print("  ✅ Left funnel includes unknown correctly")

        # Check right funnel
        issues = data.get("issues", [])
        secrets_unknown_calc = len(
            [i for i in issues if i.get("type") == "SECRET" and i.get("reachability_state") == "unknown"]
        )

        expected_display = json_reach + secrets_unknown_calc
        print(f"  RIGHT funnel will show: {json_reach} + {secrets_unknown_calc} = {expected_display}")

        if expected_display != db_combined:
            self.errors.append(f"❌ SECRETS RIGHT FUNNEL WRONG: Will show {expected_display}, should be {db_combined}")
        else:
            print("  ✅ Right funnel correct")
        print()

    def audit_dlp(self, db, data):
        print("🔍 AUDIT 2: DLP Reachability (Conservative Marking)")
        print("-" * 80)

        db_total = db["by_type"].get("dlp", 0)
        db_reach = db["by_reach"]["dlp"].get("reachable", 0)
        db_unknown = db["by_reach"]["dlp"].get("unknown", 0)
        db_not_reach = db["by_reach"]["dlp"].get("not_reachable", 0)

        dlp_findings = data.get("dlp_findings", [])
        json_total = len(dlp_findings)

        print(f"  DB Total: {db_total}")
        print(f"  DB Reachable: {db_reach}")
        print(f"  DB Unknown: {db_unknown}")
        print(f"  DB Not Reachable: {db_not_reach} ⚠️")
        print(f"  JSON Total: {json_total}")

        if db_not_reach > 0:
            self.errors.append(
                f"❌ DLP NOT_REACHABLE VIOLATION: {db_not_reach} DLP marked not_reachable - "
                f"DLP must be reachable or unknown (conservative design)"
            )
        else:
            print("  ✅ No DLP marked not_reachable (correct)")

        if json_total > 0:
            # Check if dashboard respects sink_type
            with_unknown_sink = sum(1 for f in dlp_findings if f.get("sink_type") in ("unknown", None))

            print(f"  DLP with unknown sink: {with_unknown_sink}")

            if with_unknown_sink > 0:
                self.warnings.append(
                    f"⚠️ DLP: {with_unknown_sink} findings with unknown sink - "
                    f"should be marked reachability='unknown' (conservative)"
                )
        print()

    def audit_action_required(self, data):
        print("🔍 AUDIT 3: Action Required Breakdown")
        print("-" * 80)

        issues = data.get("issues", [])
        actionable = [
            i for i in issues if i.get("type") != "CONFIG" and i.get("reachability_state") in ("reachable", "unknown")
        ]

        critical = [i for i in actionable if self._norm_sev(i.get("severity")) == "CRITICAL"]

        crit_cve = len([i for i in critical if i.get("type") == "CVE"])
        crit_secret = len([i for i in critical if i.get("type") == "SECRET"])
        crit_cwe = len([i for i in critical if i.get("type") == "CWE"])
        crit_malware = len([i for i in critical if i.get("type") in ("MALWARE", "SUSPICIOUS")])
        crit_ai = len([i for i in critical if i.get("type") == "AI"])
        crit_dlp = len([i for i in critical if i.get("type") == "DLP"])

        total = len(critical)
        calc_sum = crit_cve + crit_secret + crit_cwe + crit_malware + crit_ai + crit_dlp

        print(f"  CRITICAL Actionable Total: {total}")
        print(f"    🛡️  CVE: {crit_cve}")
        print(f"    🔐 SECRET: {crit_secret}")
        print(f"    ⚠️  CWE: {crit_cwe}")
        print(f"    ☠️  MALWARE: {crit_malware}")
        print(f"    🤖 AI: {crit_ai}")
        print(f"    🔒 DLP: {crit_dlp}")
        print(f"    ➕ SUM: {calc_sum}")

        if total != calc_sum:
            self.errors.append(f"❌ ACTION REQUIRED BREAKDOWN: Total={total} but sum={calc_sum}")
        else:
            print("  ✅ Breakdown adds up correctly")

        if crit_dlp == 0 and len([i for i in issues if i.get("type") == "DLP"]) > 0:
            self.warnings.append("⚠️ DLP findings exist but none are CRITICAL - check severity assignment")
        print()

    def audit_trends(self, data):
        print("🔍 AUDIT 4: Trends Chart vs Funnel Total")
        print("-" * 80)

        m = data.get("metrics", {})
        ai = data.get("ai_security", {})
        dlp = data.get("dlp_findings", [])

        # Trends only counts CVE+CWE+AI
        trends_raw = m.get("cves_total", 0) + m.get("cwe_total", 0) + ai.get("total", 0)

        # Funnel counts all 9 types
        funnel_raw = (
            m.get("cves_total", 0)
            + m.get("secrets_total", 0)
            + m.get("cwe_total", 0)
            + m.get("malware_total", 0)
            + m.get("suspicious_total", 0)
            + m.get("config_total", 0)
            + m.get("phantom_total", 0)
            + ai.get("total", 0)
            + len(dlp)
        )

        print(f"  Trends Raw Total: {trends_raw} (CVE+CWE+AI only)")
        print(f"  Funnel Raw Total: {funnel_raw} (all 9 types)")
        print(f"  Difference: {abs(funnel_raw - trends_raw)}")

        if trends_raw != funnel_raw:
            self.errors.append(f"❌ TRENDS != FUNNEL: Trends shows {trends_raw} but funnel shows {funnel_raw}")
        else:
            print("  ✅ Trends and funnel match")
        print()

    def audit_signal_quality(self, data):
        print("🔍 AUDIT 5: Signal Quality Scope")
        print("-" * 80)

        m = data.get("metrics", {})
        ai = data.get("ai_security", {})
        dlp = data.get("dlp_findings", [])

        # What's counted
        counted = m.get("cves_total", 0) + m.get("cwe_total", 0) + ai.get("total", 0)

        # What's NOT counted
        not_counted = m.get("secrets_total", 0) + m.get("malware_total", 0) + m.get("suspicious_total", 0) + len(dlp)

        print(f"  Counted in Signal Quality: {counted} (CVE+CWE+AI)")
        print(f"  NOT Counted: {not_counted} (SECRET+MALWARE+DLP)")

        if not_counted > 0:
            self.warnings.append(
                f"⚠️ SIGNAL QUALITY: Ignoring {not_counted} findings "
                f"(secrets, malware, DLP don't have reachability filtering)"
            )
        print()

    def _norm_sev(self, s):
        if not s:
            return "MEDIUM"
        s = s.upper()
        if s == "ERROR":
            return "CRITICAL"
        if s == "WARNING":
            return "HIGH"
        return s

    def report(self):
        print("=" * 80)
        print("AUDIT RESULTS")
        print("=" * 80)

        if self.errors:
            print(f"\n❌ ERRORS ({len(self.errors)}):")
            for e in self.errors:
                print(f"  {e}")

        if self.warnings:
            print(f"\n⚠️  WARNINGS ({len(self.warnings)}):")
            for w in self.warnings:
                print(f"  {w}")

        if not self.errors and not self.warnings:
            print("\n✅ ALL CHECKS PASSED - Metrics are consistent!")
            return True

        print(f"\n{'❌ FAILED' if self.errors else '⚠️  PASSED WITH WARNINGS'}")
        return not self.errors


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python3 audit_dashboard_metrics.py <scan_dir>")
        print("Example: python3 audit_dashboard_metrics.py ~/.reachable/scans/reach-testbed-2943c74e")
        sys.exit(1)

    auditor = MetricsAuditor(sys.argv[1])
    success = auditor.audit()
    sys.exit(0 if success else 1)
