#!/usr/bin/env python3
"""
Find Python files with duplicate copyright/shebang/docstring headers.

Detects:
  1. Duplicate '# Copyright' lines
  2. Duplicate '#!/usr/bin/env python3' shebangs
  3. Duplicate module docstrings (triple-quoted blocks in first 30 lines)

Usage:
    python find_dup_copyrights.py /path/to/reachable [--fix]
"""

import re
import sys
from pathlib import Path


def check_file(fpath: Path) -> list[dict]:
    """Return list of issues found in a single file."""
    try:
        lines = fpath.read_text(errors="ignore").splitlines()
    except OSError:
        return []

    issues = []
    head = lines[:40]  # Only check first 40 lines (header zone)

    # --- 1. Duplicate copyright lines ---
    copyright_lines = [(i, l) for i, l in enumerate(head) if re.search(r"#\s*Copyright", l, re.IGNORECASE)]
    if len(copyright_lines) > 1:
        # Check if they're actually different or identical
        texts = [l.strip() for _, l in copyright_lines]
        unique = set(texts)
        if len(unique) < len(texts):
            issues.append(
                {
                    "type": "duplicate_copyright",
                    "count": len(copyright_lines),
                    "lines": [i + 1 for i, _ in copyright_lines],
                    "text": texts[0],
                }
            )

    # --- 2. Duplicate shebangs ---
    shebang_lines = [(i, l) for i, l in enumerate(head) if l.strip().startswith("#!")]
    if len(shebang_lines) > 1:
        issues.append(
            {
                "type": "duplicate_shebang",
                "count": len(shebang_lines),
                "lines": [i + 1 for i, _ in shebang_lines],
            }
        )

    # --- 3. Duplicate docstrings ---
    # Find triple-quote openings in the header
    docstring_starts = []
    for i, l in enumerate(head):
        stripped = l.strip()
        if stripped.startswith('"""') or stripped.startswith("'''"):
            docstring_starts.append(i + 1)
    if len(docstring_starts) > 2:
        # More than one open+close pair = likely duplicate
        issues.append(
            {
                "type": "duplicate_docstring",
                "count": len(docstring_starts) // 2,
                "lines": docstring_starts,
            }
        )

    # --- 4. Duplicate warnings.filterwarnings blocks ---
    warn_lines = [i for i, l in enumerate(head) if "warnings.filterwarnings" in l]
    if len(warn_lines) > 2:
        # Typically 2 filterwarnings calls is normal; >2 means duplicated block
        issues.append(
            {
                "type": "duplicate_warnings_block",
                "count": len(warn_lines),
                "lines": [i + 1 for i in warn_lines],
            }
        )

    return issues


def main():
    if len(sys.argv) < 2:
        print(f"Usage: {sys.argv[0]} <directory> [--fix]")
        sys.exit(1)

    root = Path(sys.argv[1])
    fix_mode = "--fix" in sys.argv

    if not root.is_dir():
        print(f"Error: {root} is not a directory")
        sys.exit(1)

    # Skip venv, __pycache__, .git, node_modules
    skip_dirs = {
        "venv",
        ".venv",
        "env",
        "__pycache__",
        ".git",
        "node_modules",
        ".pytest_cache",
        ".tox",
        "htmlcov",
        "dist",
        "build",
    }

    total_files = 0
    files_with_issues = 0
    all_issues = []

    for fpath in sorted(root.rglob("*.py")):
        # Skip excluded dirs
        if any(part in skip_dirs for part in fpath.parts):
            continue
        total_files += 1
        issues = check_file(fpath)
        if issues:
            files_with_issues += 1
            rel = fpath.relative_to(root)
            all_issues.append((rel, issues))

    # Report
    print(f"\nScanned {total_files} Python files under {root}\n")

    if not all_issues:
        print("✓ No duplicate headers found!")
        return

    print(f"⚠ Found issues in {files_with_issues} file(s):\n")
    print("=" * 80)

    for rel, issues in all_issues:
        print(f"\n  {rel}")
        for iss in issues:
            itype = iss["type"].replace("_", " ").title()
            lines_str = ", ".join(str(l) for l in iss["lines"])
            print(f"    ├─ {itype} on lines: {lines_str}")
            if "text" in iss:
                print(f"    │  Text: {iss['text'][:80]}")
            if "count" in iss:
                print(f"    │  Count: {iss['count']}")

    print("\n" + "=" * 80)
    print(f"\nSummary: {files_with_issues} files with duplicate headers out of {total_files} scanned")

    # Breakdown by type
    type_counts = {}
    for _, issues in all_issues:
        for iss in issues:
            t = iss["type"]
            type_counts[t] = type_counts.get(t, 0) + 1
    print("\nBy type:")
    for t, c in sorted(type_counts.items()):
        print(f"  {t.replace('_', ' ').title()}: {c} file(s)")


if __name__ == "__main__":
    main()
