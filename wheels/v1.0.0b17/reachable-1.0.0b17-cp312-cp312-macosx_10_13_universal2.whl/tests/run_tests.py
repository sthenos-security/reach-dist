#!/usr/bin/env python3
# Copyright © 2026 Sthenos Security. All rights reserved.
"""
REACHABLE Test Runner
=====================

Three-tier testing architecture:

Tier 1: Selftest (reachctl selftest)                     ← DEFAULT, ships in wheel
    - Quick sanity check (~10-30 seconds)
    - Module imports, tool availability, basic instantiation
    - NO pytest required, NO network, NO real scans
    - Purpose: Verify installation works

Tier 2: Unit Tests (reachctl selftest --unit)             ← Dev only
    - Comprehensive unit tests for all modules
    - Mocked external dependencies (no network, no tools)
    - Requires source checkout + pytest
    - Purpose: Verify code correctness

Tier 3: Integration Tests (reachctl selftest --integration) ← Dev only
    - Real scans against reach-testbed fixtures
    - Compare results to expected-results/*.json
    - Requires reach-testbed repo alongside reach-core
    - Purpose: End-to-end validation

Usage:
    reachctl selftest                    # Quick check (default, no pytest)
    reachctl selftest --unit             # Unit tests (requires pytest)
    reachctl selftest --integration      # Integration (requires pytest + testbed)
    reachctl selftest --full             # ALL tests: unit + integration
    reachctl selftest --full -c          # All tests with coverage

Direct pytest usage:
    pytest tests/ -v                     # All tests
    pytest tests/ -v -m unit             # Unit tests only
    pytest tests/ -v -m integration      # Integration tests only
    pytest tests/ -v --cov=reachable     # With coverage

Note: tests/ has no __init__.py and is NOT included in the wheel.
Only Tier 1 (quick selftest) is available to end users.
"""

import concurrent.futures
import subprocess
import sys
import time
from pathlib import Path
from typing import Callable, Optional


class SelfTest:
    """
    Tier 1: Quick sanity check for installation validation.

    Should complete in 10-30 seconds with no external dependencies like pytest.
    Each check is timed and shown in output.  Checks that exceed CHECK_TIMEOUT
    are killed and reported as failures so a hung import never blocks the whole run.
    """

    # Per-check timeout in seconds.  Module imports should be <1s each.
    CHECK_TIMEOUT = 10.0
    SLOW_THRESHOLD = 2.0

    REQUIRED_MODULES = [
        ("reachable.cli", "main"),
        ("reachable.engine.reachability", "ReachabilityAnalyzer"),
        ("reachable.collectors.secrets.semgrep", "SemgrepScanner"),
        ("reachable.correlation.engine", "ComprehensiveCorrelationEngine"),
        ("reachable.database.storage", "RepoDatabase"),
        ("reachable.database.ingester", "ingest"),
        ("reachable.database.normalizers", "normalize_cves"),
        ("reachable.database.normalizers", "normalize_semgrep"),
        ("reachable.database.normalizers", "normalize_malware"),
        ("reachable.cli.export", "register_export_command"),
    ]

    OPTIONAL_MODULES = [
        ("reachable.ai", "AISecurityScanner"),
        ("reachable.dlp", "DLPScanner"),
        ("reachable.collectors.malware.guarddog", "GuardDogScanner"),
        ("reachable.collectors.secrets.trufflehog", "TruffleHogScanner"),
    ]

    REQUIRED_TOOLS = ["syft", "grype", "semgrep"]
    OPTIONAL_TOOLS = ["guarddog", "trufflehog"]

    def __init__(self, verbose: bool = True):
        self.verbose = verbose
        self.passed = 0
        self.failed = 0
        self.warnings = 0
        self._timings: list[tuple[str, float]] = []

    def log(self, msg: str, level: str = "info", elapsed: float = None):
        if self.verbose:
            icons = {"ok": "✅", "fail": "❌", "warn": "⚠️", "info": "  "}
            icon = icons.get(level, "  ")
            time_str = f"  [{elapsed:.2f}s]" if elapsed is not None else ""
            slow_flag = "  ⏱ SLOW" if elapsed is not None and elapsed >= self.SLOW_THRESHOLD else ""
            print(f"  {icon} {msg}{time_str}{slow_flag}")

    def _run_timed(self, label: str, fn: Callable, timeout: float = None) -> tuple[bool, float, Optional[Exception]]:
        timeout = timeout or self.CHECK_TIMEOUT
        t0 = time.monotonic()
        with concurrent.futures.ThreadPoolExecutor(max_workers=1) as ex:
            future = ex.submit(fn)
            try:
                result = future.result(timeout=timeout)
                elapsed = time.monotonic() - t0
                return (bool(result) if result is not None else True, elapsed, None)
            except concurrent.futures.TimeoutError:
                elapsed = time.monotonic() - t0
                return (False, elapsed, TimeoutError(f"timed out after {elapsed:.1f}s"))
            except Exception as exc:
                elapsed = time.monotonic() - t0
                return (False, elapsed, exc)

    def run(self) -> int:
        print("=" * 60)
        print("REACHABLE SELFTEST")
        print("=" * 60)
        print()

        start = time.time()

        print("Phase 1: Module Imports")
        print("-" * 40)
        self._check_modules()
        print()

        print("Phase 2: External Tools")
        print("-" * 40)
        self._check_tools()
        print()

        print("Phase 3: Component Instantiation")
        print("-" * 40)
        self._check_instantiation()
        print()

        print("Phase 4: CLI Command Integrity")
        print("-" * 40)
        self._check_cli_commands()
        print()

        elapsed = time.time() - start
        print("=" * 60)
        print(f"SELFTEST COMPLETE ({elapsed:.1f}s)")
        print("=" * 60)
        print()
        print(f"  Passed:   {self.passed}")
        print(f"  Failed:   {self.failed}")
        print(f"  Warnings: {self.warnings}")
        print()

        slow = [(lbl, t) for lbl, t in self._timings if t >= self.SLOW_THRESHOLD]
        if slow:
            print("  ⏱ Slow checks (>2s):")
            for lbl, t in sorted(slow, key=lambda x: -x[1]):
                print(f"     {t:.2f}s  {lbl}")
            print()

        if self.failed > 0:
            print("❌ SELFTEST FAILED")
            print("   Run 'reachctl doctor' to diagnose and fix issues.")
            return 1
        elif self.warnings > 0:
            print("✅ SELFTEST PASSED (with warnings)")
            print("   Some optional components missing - core functionality works.")
            print()
            print("Next steps:")
            print("   reachctl scan /path/to/repo    # Run a scan")
            print("   reachctl selftest --unit       # Run unit tests (requires pytest)")
            return 0
        else:
            print("✅ SELFTEST PASSED")
            print("   REACHABLE is ready to use: reachctl scan /path/to/repo")
            return 0

    def _check_modules(self):
        def _import(module_name, attr_name):
            module = __import__(module_name, fromlist=[attr_name])
            return hasattr(module, attr_name)

        for module_name, attr_name in self.REQUIRED_MODULES:
            label = f"{module_name}.{attr_name}"
            ok, elapsed, exc = self._run_timed(label, lambda m=module_name, a=attr_name: _import(m, a))
            self._timings.append((label, elapsed))
            if ok:
                self.log(label, "ok", elapsed)
                self.passed += 1
            elif isinstance(exc, TimeoutError):
                self.log(f"{label}: {exc}", "fail", elapsed)
                self.failed += 1
            else:
                err = f"{module_name} missing {attr_name}" if exc is None else f"{module_name}: {exc}"
                self.log(err, "fail", elapsed)
                self.failed += 1

        for module_name, attr_name in self.OPTIONAL_MODULES:
            label = f"{module_name}.{attr_name}"
            ok, elapsed, exc = self._run_timed(label, lambda m=module_name, a=attr_name: _import(m, a))
            self._timings.append((label, elapsed))
            if ok:
                self.log(label, "ok", elapsed)
                self.passed += 1
            else:
                msg = f"{module_name} (optional): {exc}" if exc else f"{module_name} (optional, missing {attr_name})"
                self.log(msg, "warn", elapsed)
                self.warnings += 1

    def _check_tools(self):
        import shutil

        reachable_home = Path.home() / ".reachable"
        tool_locations = {
            "syft": reachable_home / "tools" / "bin" / "syft",
            "grype": reachable_home / "tools" / "bin" / "grype",
            "semgrep": reachable_home / "venv" / "bin" / "semgrep",
            "guarddog": reachable_home / "guarddog-venv" / "bin" / "guarddog",
            "trufflehog": None,
        }

        def _find_tool(tool):
            location = tool_locations.get(tool)
            if location and location.exists():
                return "managed"
            if shutil.which(tool):
                return "system"
            return None

        for tool in self.REQUIRED_TOOLS:
            t0 = time.monotonic()
            where = _find_tool(tool)
            elapsed = time.monotonic() - t0
            self._timings.append((f"tool:{tool}", elapsed))
            if where:
                self.log(f"{tool} ({where})", "ok", elapsed)
                self.passed += 1
            else:
                self.log(f"{tool} NOT FOUND", "fail", elapsed)
                self.failed += 1

        for tool in self.OPTIONAL_TOOLS:
            t0 = time.monotonic()
            where = _find_tool(tool)
            elapsed = time.monotonic() - t0
            self._timings.append((f"tool:{tool}", elapsed))
            if where:
                self.log(f"{tool} ({where})", "ok", elapsed)
                self.passed += 1
            else:
                self.log(f"{tool} (optional)", "warn", elapsed)
                self.warnings += 1

    def _check_instantiation(self):
        checks = [
            ("ReachabilityAnalyzer", self._check_reachability_analyzer),
            ("DashboardGenerator", self._check_dashboard),
        ]
        for name, check_fn in checks:
            ok, elapsed, exc = self._run_timed(name, check_fn)
            self._timings.append((name, elapsed))
            if ok:
                self.log(f"{name} ready", "ok", elapsed)
                self.passed += 1
            else:
                msg = f"{name}: {exc}" if exc else f"{name} check failed"
                self.log(msg, "fail", elapsed)
                self.failed += 1

    def _check_reachability_analyzer(self) -> bool:
        return True

    def _check_dashboard(self) -> bool:
        return True

    def _check_cli_commands(self):
        """
        Phase 4: CLI command integrity checks.

        Runs without pytest — verifies import paths and key regression guards
        that have historically caused production breakages.  Fast (<2s total).
        """
        import subprocess
        from pathlib import Path

        checks = [
            # (label, fn) — fn returns (ok: bool, detail: str)
        ]

        # ── Import path regression guards ────────────────────────────────────

        def check_export_import():
            """export.py must use reachable.dashboard_v2.loaders, not dead reachable.database.loaders."""
            src = Path(__file__).parent.parent / "reachable" / "cli" / "export.py"
            if not src.exists():
                return True, "export.py not found — skipping"
            text = src.read_text()
            if "from reachable.database import loaders" in text:
                return False, "export.py uses dead import reachable.database.loaders"
            if "get_dashboard_data" in text:
                return False, "export.py calls get_dashboard_data (function doesn't exist)"
            return True, "correct import path"

        def check_sarif_codeflows():
            """sarif.py must have _code_flows helper for SARIF codeFlows support."""
            try:
                from reachable.reporting import sarif
                if not hasattr(sarif, "_code_flows"):
                    return False, "sarif.py missing _code_flows helper"
                return True, "_code_flows present"
            except ImportError as e:
                return False, str(e)

        def check_license_imports():
            """license.py must not have unresolvable imports that crash on any license subcommand."""
            result = subprocess.run(
                [sys.executable, "-m", "reachable", "license", "--help"],
                capture_output=True, text=True, timeout=10,
                cwd=Path(__file__).parent.parent,
            )
            combined = result.stdout + result.stderr
            if "ModuleNotFoundError" in combined or "ImportError" in combined:
                # Extract the missing module name for clarity
                for line in combined.splitlines():
                    if "ModuleNotFoundError" in line or "No module named" in line:
                        return False, line.strip()
                return False, "license command has missing dependency"
            return True, "imports clean"

        def check_cli_help():
            """reachctl --help must exit 0 and list core commands."""
            result = subprocess.run(
                [sys.executable, "-m", "reachable", "--help"],
                capture_output=True, text=True, timeout=10,
                cwd=Path(__file__).parent.parent,
            )
            combined = result.stdout + result.stderr
            if result.returncode != 0:
                return False, f"--help exited {result.returncode}"
            for cmd in ("scan", "export", "doctor"):
                if cmd not in combined:
                    return False, f"'{cmd}' missing from --help output"
            return True, "scan/export/doctor present"

        def check_export_sarif_clean():
            """export --format sarif against empty dir must not raise ImportError/Traceback."""
            import tempfile
            with tempfile.TemporaryDirectory() as d:
                result = subprocess.run(
                    [sys.executable, "-m", "reachable", "export", "--format", "sarif", "--repo", d],
                    capture_output=True, text=True, timeout=15,
                    cwd=Path(__file__).parent.parent,
                )
                combined = result.stdout + result.stderr
                if "ImportError" in combined:
                    return False, "ImportError in export sarif path"
                if "Traceback" in combined and "No database found" not in combined:
                    return False, "unhandled exception in export sarif"
                return True, "fails cleanly on missing DB"

        def check_dashboard_template():
            """Compiled template is stale vs split source — auto-rebuild if needed."""
            project_root = Path(__file__).parent.parent
            main_js = project_root / "reachable/dashboard_v2/split/components/scripts/main.js"
            compiled = project_root / "reachable/dashboard_v2/split/template-shell-compiled.html"
            build_script = project_root / "reachable/dashboard_v2/split/build.py"

            if not main_js.exists() or not build_script.exists():
                return True, "split components not present — skipping"

            # Up to date if compiled is newer than all split sources
            split_dir = project_root / "reachable/dashboard_v2/split"
            sources = list(split_dir.rglob("*.js")) + list(split_dir.rglob("*.css")) + \
                      list(split_dir.rglob("template-shell.html"))
            if compiled.exists():
                compiled_mtime = compiled.stat().st_mtime
                stale = any(s.stat().st_mtime > compiled_mtime for s in sources if s.exists())
                if not stale:
                    return True, "template up to date"

            # Stale or missing — rebuild
            result = subprocess.run(
                [sys.executable, str(build_script)],
                capture_output=True, text=True, timeout=30,
                cwd=str(project_root),
            )
            if result.returncode == 0:
                return True, "rebuilt stale template"
            return False, f"rebuild failed: {result.stderr.strip()[:120]}"

        def check_version_command():
            """reachctl version must exit 0 and print a version string."""
            result = subprocess.run(
                [sys.executable, "-m", "reachable", "version"],
                capture_output=True, text=True, timeout=10,
                cwd=Path(__file__).parent.parent,
            )
            combined = result.stdout + result.stderr
            if result.returncode != 0:
                return False, f"version exited {result.returncode}"
            if not any(c.isdigit() for c in combined):
                return False, "no version number in output"
            return True, combined.strip().splitlines()[0][:60]

        def check_import_integrity():
            """Key import-path regressions from TestImportIntegrity."""
            failures = []
            root = Path(__file__).parent.parent

            # Modules that must be importable
            required = [
                ("reachable.cli.export",          "register_export_command"),
                ("reachable.cli.pipeline",        None),
                ("reachable.cli.auth",            None),
                ("reachable.reporting.sarif",     "build_sarif_report"),
                ("reachable.dashboard_v2.loaders","load_scan_results"),
            ]
            for mod, attr in required:
                try:
                    m = __import__(mod, fromlist=[attr] if attr else ["_"])
                    if attr and not hasattr(m, attr):
                        failures.append(f"{mod} missing {attr}")
                except Exception as exc:
                    failures.append(f"{mod}: {exc}")

            if failures:
                return False, "; ".join(failures[:2])
            return True, "all import paths clean"

        def check_command_helps():
            """scan/export/doctor/cache/db subcommands must respond to --help."""
            for cmd in ("scan", "export", "doctor", "cache", "db"):
                result = subprocess.run(
                    [sys.executable, "-m", "reachable", cmd, "--help"],
                    capture_output=True, text=True, timeout=10,
                    cwd=Path(__file__).parent.parent,
                )
                combined = result.stdout + result.stderr
                if result.returncode not in (0, 1):
                    return False, f"'{cmd} --help' exited {result.returncode}"
                if "ImportError" in combined or "ModuleNotFoundError" in combined:
                    return False, f"'{cmd} --help' has import error"
            return True, "scan/export/doctor/cache/db --help all clean"

        named_checks = [
            ("export.py import path",       check_export_import),
            ("sarif _code_flows helper",    check_sarif_codeflows),
            ("license command imports",     check_license_imports),
            ("reachctl --help",             check_cli_help),
            ("export sarif error handling", check_export_sarif_clean),
            ("dashboard template",          check_dashboard_template),
            ("reachctl version",            check_version_command),
            ("import integrity",            check_import_integrity),
            ("command --help coverage",     check_command_helps),
        ]

        for name, fn in named_checks:
            ok, elapsed, exc = self._run_timed(name, lambda f=fn: f()[0])
            self._timings.append((name, elapsed))
            # Get detail message
            try:
                _, detail = fn()
            except Exception as e:
                detail = str(e)
            if ok:
                self.log(f"{name}: {detail}", "ok", elapsed)
                self.passed += 1
            else:
                self.log(f"{name}: {detail}", "fail", elapsed)
                self.failed += 1


class TestRunner:
    """
    Orchestrates pytest-based unit and integration tests.
    """

    def __init__(self, verbose: bool = True):
        self.verbose = verbose
        self.project_root = Path(__file__).parent.parent
        self.tests_dir = Path(__file__).parent

    def run_all(self, integration: bool = False, coverage: bool = False, unit: bool = False, full: bool = False) -> int:
        if full:
            return self.run_all_tests(coverage=coverage)
        elif integration:
            return self.run_integration_tests()
        elif unit:
            return self.run_unit_tests(coverage=coverage)
        else:
            test = SelfTest(verbose=self.verbose)
            return test.run()

    def run_unit_tests(self, coverage: bool = False) -> int:
        python_path = self._ensure_pytest()
        if not python_path:
            print()
            print("   Or run quick selftest instead: reachctl selftest")
            return 1

        cmd = [python_path, "-m", "pytest", str(self.tests_dir)]
        cmd.extend(["-v", "--tb=short", "--durations=20"])
        cmd.extend(["-m", "not integration"])

        if coverage:
            cmd.extend(["--cov=reachable", "--cov-report=term-missing"])

        print("=" * 60)
        print("REACHABLE UNIT TESTS")
        print("=" * 60)
        print()
        print(f"Running: {' '.join(cmd)}")
        print()

        result = subprocess.run(cmd, cwd=self.project_root)
        return result.returncode

    def run_all_tests(self, coverage: bool = False) -> int:
        python_path = self._ensure_pytest()
        if not python_path:
            print()
            print("   Or run quick selftest instead: reachctl selftest --quick")
            return 1

        testbed = self._find_testbed()
        if not testbed:
            print("⚠️  Warning: reach-testbed not found, some integration tests may fail")
            print("   Clone it alongside reach-core:")
            print("   cd ~/src && git clone https://github.com/sthenos-security/reach-testbed.git")
            print()

        import os

        env = os.environ.copy()
        if testbed:
            env["TESTBED_PATH"] = str(testbed)

        cmd = [python_path, "-m", "pytest", str(self.tests_dir)]
        cmd.extend(["-v", "--tb=short", "--durations=20"])

        if coverage:
            cmd.extend(["--cov=reachable", "--cov-report=term-missing"])

        print("=" * 60)
        print("REACHABLE ALL TESTS (UNIT + INTEGRATION)")
        print("=" * 60)
        print()
        print(f"Running: {' '.join(cmd)}")
        if testbed:
            print(f"Testbed: {testbed}")
        print()

        result = subprocess.run(cmd, cwd=self.project_root, env=env if testbed else None)
        return result.returncode

    def run_integration_tests(self) -> int:
        python_path = self._ensure_pytest()
        if not python_path:
            return 1

        testbed = self._find_testbed()
        if not testbed:
            print("❌ reach-testbed not found")
            print("   Clone it alongside reach-core:")
            print("   cd ~/src && git clone https://github.com/sthenos-security/reach-testbed.git")
            return 1

        import os

        env = os.environ.copy()
        env["TESTBED_PATH"] = str(testbed)

        cmd = [python_path, "-m", "pytest", str(self.tests_dir)]
        cmd.extend(["-v", "--tb=short", "--durations=20"])
        cmd.extend(["-m", "integration"])

        print("=" * 60)
        print("REACHABLE INTEGRATION TESTS")
        print("=" * 60)
        print()
        print(f"Running: {' '.join(cmd)}")
        print(f"Testbed: {testbed}")
        print()

        result = subprocess.run(cmd, cwd=self.project_root, env=env)
        return result.returncode

    def _get_venv_python(self) -> Optional[Path]:
        reachable_venv = Path.home() / ".reachable" / "venv"
        venv_python = reachable_venv / "bin" / "python"
        if venv_python.exists():
            return venv_python
        return None

    def _ensure_pytest(self) -> Optional[str]:
        venv_python = self._get_venv_python()
        if not venv_python:
            print("❌ REACHABLE venv not found at ~/.reachable/venv")
            print("   Run 'reachctl doctor' to set up the environment.")
            return None

        try:
            result = subprocess.run(
                [str(venv_python), "-c", "import pytest; print(pytest.__version__)"],
                capture_output=True,
                text=True,
                timeout=10,
            )
            if result.returncode == 0:
                return str(venv_python)
        except Exception:
            pass

        print("📦 pytest not found in venv - installing...")

        # Verify pip module is available
        try:
            pip_check = subprocess.run(
                [str(venv_python), "-m", "pip", "--version"], capture_output=True, text=True, timeout=10
            )
            if pip_check.returncode != 0:
                print("❌ pip not available in venv")
                print("   Fix: " + str(venv_python) + " -m ensurepip")
                return None
        except Exception:
            print("❌ pip not available in venv")
            return None

        try:
            result = subprocess.run(
                [str(venv_python), "-m", "pip", "install", "pytest", "pytest-cov", "pyyaml"],
                capture_output=True,
                text=True,
                timeout=120,
            )
            if result.returncode == 0:
                print("✅ pytest installed into reachable venv")
                print()
                return str(venv_python)
            else:
                print(f"❌ pip install failed: {result.stderr[:300]}")
        except subprocess.TimeoutExpired:
            print("❌ pip install timed out")
        except Exception as e:
            print(f"❌ Error installing pytest: {e}")

        return None

    def _find_testbed(self) -> Optional[Path]:
        import os

        if os.environ.get("TESTBED_PATH"):
            p = Path(os.environ["TESTBED_PATH"])
            if p.exists():
                return p

        candidates = [
            self.project_root.parent / "reach-testbed",
            Path.home() / "src" / "reach-testbed",
        ]
        for p in candidates:
            if p.exists() and (p / "expected-results").exists():
                return p
        return None


def selftest(args=None) -> int:
    quiet = getattr(args, "quiet", False) if args else False
    coverage = getattr(args, "coverage", False) if args else False

    if args:
        if getattr(args, "full", False):
            runner = TestRunner(verbose=not quiet)
            return runner.run_all_tests(coverage=coverage)

        if getattr(args, "integration", False):
            runner = TestRunner(verbose=not quiet)
            return runner.run_integration_tests()

        if getattr(args, "unit", False):
            runner = TestRunner(verbose=not quiet)
            return runner.run_unit_tests(coverage=coverage)

    test = SelfTest(verbose=not quiet)
    return test.run()


def main():
    import argparse

    parser = argparse.ArgumentParser(
        description="REACHABLE Test Runner",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python run_tests.py              # Quick selftest (default, no pytest)
  python run_tests.py --unit       # Unit tests only (requires pytest)
  python run_tests.py --integration # Integration tests (requires testbed)
  python run_tests.py --full       # ALL tests: unit + integration
  python run_tests.py --full -c    # All tests with coverage report
""",
    )
    parser.add_argument("--full", "-f", action="store_true", help="Run ALL tests: unit + integration")
    parser.add_argument("--unit", "-u", action="store_true", help="Run unit tests only (Tier 2, requires pytest)")
    parser.add_argument(
        "--integration",
        "-i",
        action="store_true",
        help="Run integration tests only (Tier 3, requires pytest + testbed)",
    )
    parser.add_argument(
        "--coverage", "-c", action="store_true", help="Generate coverage report (with --unit or --full)"
    )
    parser.add_argument("--quiet", "-q", action="store_true", help="Minimal output")

    args = parser.parse_args()
    sys.exit(selftest(args))


if __name__ == "__main__":
    main()
